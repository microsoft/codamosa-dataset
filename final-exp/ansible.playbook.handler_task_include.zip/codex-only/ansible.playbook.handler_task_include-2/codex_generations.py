

# Generated at 2022-06-23 06:13:44.650516
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.task_include
    import ansible.playbook.handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    import os
    import yaml

    cur_dir = os.path.dirname(__file__)
    data = open(cur_dir + "/../../../lib/ansible/playbook/handler.yml").read()

    ansible.playbook.task_include.TaskInclude._apply_defaults = lambda *args, **kwargs: None
    ansible.playbook.task_include.TaskIn

# Generated at 2022-06-23 06:13:49.271932
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'name': 'test_HandlerTaskInclude_load',
        'handler': 'test_HandlerTaskInclude_load',
        'listen': 'hello'
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.get_name() == 'test_HandlerTaskInclude_load', handler.get_name()

# Generated at 2022-06-23 06:13:55.180462
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # create a mock data structure to hold our data
    data = {
        "name": "apache",
        "listen": "restart apache",
        "handlers": [ "restart apache" ]
    }
    assert Handler.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)


# Generated at 2022-06-23 06:14:06.114177
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    host = Host(name="test-host")
    block = Block(parent_block=None, role=None, task_include=None)
    task = Task(block=block, parent_role=None, task_include=None, role=None)
    play = Play()
    task_vars = dict()
    play_context = {}
    templar = Templar()

    # 1. test with role object
    role = Role()
    handler_task_include_object = Handler

# Generated at 2022-06-23 06:14:10.844521
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    d = {'listen': 'listen1', 'tasks': [{'debug': 'msg={{status}}'}]}
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    t.playbook = ''
    t.loader = ''
    t.variable_manager = ''
    handler = t.load(d)
    return handler

# Generated at 2022-06-23 06:14:12.890383
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude("test")
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:14:21.386821
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Test handler task include load')
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    myhost = Host(name='webserver')
    myhost.set_variable('ansible_ssh_host', '192.168.1.100')
    myhost.set_variable('ansible_ssh_port', 22)
    myhost.set_variable('ansible_ssh_user', 'root')
    myhost.set_variable('ansible_ssh_pass', 'secret')
    myhost.set_variable('ansible_ssh_private_key_file', '/home/user/.ssh/id_rsa')
    myhost.set_variable('ansible_connection', 'ssh')
    myhost.set_variable('ansible_shell_type', 'csh')

# Generated at 2022-06-23 06:14:30.780742
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # class TaskInclude:
    #    _valid_keywords = ['delegate_to', 'remote_user', 'run_once', 'become', 'become_user', 'sudo', 'sudo_user',
    #                       'tags', 'ignore_errors', 'register', 'only_if', 'async', 'poll', 'environment',
    #                       'when', 'first_available_file', 'include', 'static']

    # class Handler:
    #    VALID_KEYWORDS = ('name', 'listen', 'local_action', 'tasks', 'notify', 'async', 'poll')

    data = {}

    # Create a class object that contains the method to be tested
    task_include = HandlerTaskInclude()

    # Test for a local_action

# Generated at 2022-06-23 06:14:42.033718
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def check_no_load(data):
        assert HandlerTaskInclude.load(data, variable_manager=None, loader=None) is None

    def check_load(data):
        assert HandlerTaskInclude.load(data, variable_manager=None, loader=None) is not None

     # from ansible.inventory.host import Host
    data = {
        'hosts': 'all'
    }
    check_no_load(data)
    data = {
        'listen': "asdf"
    }
    check_no_load(data)
    data = {
        'listen': 'asdf',
        'hosts': 'all'
    }
    check_load(data)

# Generated at 2022-06-23 06:14:43.899282
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: complete test
    pass

# Generated at 2022-06-23 06:14:45.986550
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO
    assert False, 'Not implemented'
    # HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:14:46.449766
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:14:55.765062
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert isinstance(hti, Handler)
    assert isinstance(hti, TaskInclude)

    variables = {
        "_play_hosts": [],
        "_play_delegate_to": None,
        "_play_listen": False,
        "_play_path": '',
        "_play_basedir": '',
        "_hosts": [
            "10.0.0.1",
            "10.0.0.2",
        ],
        "_role_name": '',
        "_blocks": [],
    }

    loader = MagicMock()
    loader.path_dwim.return_value = 'a/b/c'
    vm = MagicMock()
    vm.get_vars.return_value = variables
    res = HandlerTaskInclude

# Generated at 2022-06-23 06:14:57.151154
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load is not None


# Generated at 2022-06-23 06:15:01.400522
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    tti2 = HandlerTaskInclude.load(dict(include_vars=dict(file="test.yml")))
    assert tti2._task.get_name() == 'include_vars'
    assert tti2._task.args.get('file') == 'test.yml'

# Generated at 2022-06-23 06:15:12.506289
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.errors import AnsibleError
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.variable_manager import VariableManager
    from ansible.vars.manager import VariableManager

    mock_variable_manager = VariableManager()

    data = {
        'include': './mytasks.yml'
    }

    # Test empty/invalid/missing value of 'include' key

# Generated at 2022-06-23 06:15:17.827989
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """Unit test for method load of class HandlerTaskInclude"""

    data = dict(
        file_path="../../module_utils/new_test.yml",
        task_includes=[
            dict(
                task_include=dict(
                    name="Unit test for method load of class HandlerTaskInclude",
                    static="no",
                    tags="always",
                    file="../../module_utils/new_test.yml",
                    handlers=[]
                )
            )
        ]
    )

    handler = HandlerTaskInclude.load(data)

# Generated at 2022-06-23 06:15:19.754250
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:15:31.559868
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ''' handler_task_include.py:HandlerTaskInclude '''

    # test with dict
    # contents of dict copied from test_task_include.py.test_TaskInclude
    data = { 'name': 'test',
             'action': 'include_test',
             'local_action': 'test_local_action',
             'tags':['test_tag1', 'test_tag2'],
             'when': 'test_when',
             'async': 'test_async',
             'poll': 'test_poll',
             'notify':'test_notify',
             'delegate_to':'test_delegate_to'}

    test_HandlerTaskInclude = HandlerTaskInclude.load(data)
    assert test_HandlerTaskInclude is not None
    assert test_HandlerTaskInclude._role

# Generated at 2022-06-23 06:15:35.529378
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = {"include": "my_handler_file.yml"}
    h = HandlerTaskInclude.load(data)
    assert h.get_name() == "my_handler_file.yml"

# Generated at 2022-06-23 06:15:37.195022
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # TODO write this test
    pass


# Generated at 2022-06-23 06:15:44.049239
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("===== test_HandlerTaskInclude_load")

    def get_data(filename):
        data = {}
        with open(filename, 'r') as fd:
            import yaml
            data = yaml.load(fd)
        return data

    data = get_data('../../playbooks/roles/nginx/handlers/main.yml')
    handler = HandlerTaskInclude.load(data=data)
    print(handler)

# Generated at 2022-06-23 06:15:54.852540
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._options_vars = {}

    host = Host('localhost')
    variable_manager._inventory = lambda: {'localhost': host, 'example.com': host, 'example.org': host }

    block = Block(loader=loader, variable_manager=variable_manager)
    task_include = TaskInclude(loader=loader, variable_manager=variable_manager)



# Generated at 2022-06-23 06:15:57.363223
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude(block, role, task_include)

# Generated at 2022-06-23 06:15:58.035239
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:16:05.792795
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Set up the class object
    t = HandlerTaskInclude()
    # Setup the data to be tested
    data = {'action': 'include',
            'tags': ['all'],
            'name': 'tasks/main.yml',
            'listen': 'test'}
    # Test
    handler = t.load(data)
    # Test type of return
    assert isinstance(handler, HandlerTaskInclude)
    # Test content of return
    assert handler.action == 'include'
    assert handler.tags == ['all']
    assert handler.name == 'tasks/main.yml'

# Generated at 2022-06-23 06:16:06.805074
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()

    print(h)

# Generated at 2022-06-23 06:16:13.995891
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        HandlerTaskInclude.load(
            {
                'include': 'some_include.yml'
            },
            block=None,
            role=None,
            task_include=None,
            variable_manager=None,
            loader=None
        )
    except TypeError as e:
        if 'unexpected keyword argument' in e.args[0]:
            raise Exception('Unexpected keyword argument found in HandlerTaskInclude.load')
    except Exception as e:
        if not (type(e).__name__ == 'AssertionError' and 'No handler in' in str(e)):
            raise Exception('Unexpected exception: %s' % e)

# Generated at 2022-06-23 06:16:21.759005
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert hasattr(HandlerTaskInclude,'load')
    assert callable(getattr(HandlerTaskInclude,'load',None))
    assert hasattr(HandlerTaskInclude,'VALID_INCLUDE_KEYWORDS')
    assert len(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS)>0
    handler = HandlerTaskInclude.load("test","block","role","task")
    assert hasattr(handler,'block')
    assert hasattr(handler,'role')
    assert hasattr(handler,'task')
    assert hasattr(handler,'notify')
    assert hasattr(handler,'listen')
    assert hasattr(handler,'name')
    assert hasattr(handler,'tags')

# Generated at 2022-06-23 06:16:22.267054
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
   pass

# Generated at 2022-06-23 06:16:23.841125
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_object = HandlerTaskInclude()



# Generated at 2022-06-23 06:16:24.806021
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #handler = HandlerTaskInclude()
    pass

# Generated at 2022-06-23 06:16:26.035254
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # pass
    assert 1

# Generated at 2022-06-23 06:16:27.427993
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = Host(name="test")
    return HandlerTaskInclude(host=host)

# Generated at 2022-06-23 06:16:29.972764
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None

# Generated at 2022-06-23 06:16:38.955852
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data = dict(
        name="handler1",
        listen="task1"
    )

    host = Host(name="host1")
    group = Group(name="group1")
    group.add_host(host)
    inventory = InventoryManager(
        loader=DataLoader(),
        sources=[group, ]
    )
    variable_manager = VariableManager(
        loader=DataLoader(),
        inventory=inventory,
    )

# Generated at 2022-06-23 06:16:39.564675
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:16:41.602835
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    data = dict(
        include='main.yml',
    )
    handler = t.check_options(
        t.load_data(data),
        data
    )

    assert handler is not None

# Generated at 2022-06-23 06:16:53.416508
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

# Generated at 2022-06-23 06:16:57.666271
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = ''
    block = ''
    role = ''
    task_include = ''
    variable_manager = ''
    loader = ''
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler and isinstance(handler, Handler)

# Generated at 2022-06-23 06:17:07.796166
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleParserError
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import become_loader
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task import Task
    import os
    path = "tests/functional/parser/data/handlertaskinclude.yml"
    if not os.path.exists(path):
        print('Unable to find %s' % path)
        assert(os.path.exists(path))

# Generated at 2022-06-23 06:17:09.977478
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler_task_include is not None

# Generated at 2022-06-23 06:17:18.054807
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h.VALID_INCLUDE_KEYWORDS == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert h.handler is None
    assert h.active is False
    assert h.notified_by == []
    assert h.tags == {}
    assert h.when is None
    assert h.always is False
    assert h.changed_when is None
    assert h.failed_when is None
    assert h.block is None
    assert h.role is None
    assert h.task_include is None

# Generated at 2022-06-23 06:17:21.082381
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'handler_name': 'handler_name'}
    assert HandlerTaskInclude.load(data)

# Generated at 2022-06-23 06:17:21.677747
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:17:30.462241
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    Test constructor of class HandlerTaskInclude
    """
    # Test 1: without passing parameters
    hti = HandlerTaskInclude()

    assert hti.__class__.__name__ == "HandlerTaskInclude"
    assert hti.name == ""
    assert hti.tags == set()
    assert len(hti.handlers) == 0

    # Test 2: passing values
    hti = HandlerTaskInclude(name="php-app", tags=["app", "php"], handlers=["/some/file.yml"])

    assert hti.__class__.__name__ == "HandlerTaskInclude"
    assert hti.name == "php-app"
    assert hti.tags == {"app", "php"}
    assert len(hti.handlers) == 1



# Generated at 2022-06-23 06:17:31.914398
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    handler = HandlerTaskInclude(block=data, role=data, task_include=data)

    assert handler is not None


# Generated at 2022-06-23 06:17:40.882540
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def mock_load(self, data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        pass

    class MockVariableManager(object):
        pass

    class MockLoader(object):
        pass

    class MockPlay(object):
        pass

    class MockTask(object):
        pass

    class MockRole(object):
        pass

    from ansible.utils.collection_loader import _get_collection_roles
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.template import Templar

    from ansible.compat.tests import unittest, patch
    from units.compat.mock import MagicMock, call, Mock, patch


# Generated at 2022-06-23 06:17:43.246446
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert "class AnsibleHandler" in HandlerTaskInclude.load(
        {'include': 'tasks/handler.yml', 'listen': 'Test Listen'})


# Generated at 2022-06-23 06:17:52.278107
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    block = Block(play=None)
    task = Task(block=block, parent_block=None)
    task_include = TaskInclude(play=play)
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, 'var1', 'foo')
    variable_manager.set_host_variable(host, 'var2', 'bar')


# Generated at 2022-06-23 06:18:01.706189
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    class FakeData: # pylint: disable=too-few-public-methods
        def __init__(self, module_name, module_args, delegate_to, notify, name=None):
            self.module_name = module_name
            self.module_args = module_args
            self.delegate_to = delegate_to
            self.notify = notify
            self.name = name

    class FakeModule: # pylint: disable=too-few-public-methods
        def __init__(self, name, **kwargs):
            self.name = name

    class FakeVariableManager: # pylint: disable=too-few-public-methods
        def __init__(self, host_vars, group_vars):
            self.vars = {}

# Generated at 2022-06-23 06:18:11.089623
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    p = PlayContext()
    t = Task()
    h = Host(name="127.0.0.1")
    i = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    r = Role()
    hti = HandlerTaskInclude(play_context=p, task=t, host=h, include_role=r)
    assert isinstance(hti, Handler)
    assert isinstance(hti, TaskInclude)

# Generated at 2022-06-23 06:18:11.835525
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:18:16.064144
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Test with invalid keyword
    data = { "foo": "bar" }

    expected = False
    result = HandlerTaskInclude.load(data)

    assert result == expected

    # Test with valid keyword
    data = { "listen": "bar" }

    expected = False
    result = HandlerTaskInclude.load(data)

    assert result == expected

# Generated at 2022-06-23 06:18:25.052441
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    import pytest

    #########################################################################
    #### "", "handlers", "handlers/main.yml"
    #########################################################################


# Generated at 2022-06-23 06:18:31.404182
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=True, role="role", task_include=True)
    assert handler.VALID_INCLUDE_KEYWORDS == {'listen', 'freeze_variables', 'tasks', 'vars', 'block', 'static', 'tags', 'task', 'with_items', 'name'}

# Generated at 2022-06-23 06:18:37.311901
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    fake_variable_manager = dict()
    data = dict()
    t = HandlerTaskInclude.load(data, variable_manager=fake_variable_manager)

    assert isinstance(t, HandlerTaskInclude)
    assert isinstance(t, Handler)
    assert isinstance(t, TaskInclude)

# Generated at 2022-06-23 06:18:46.265802
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    import pytest

    test_data = '''- name: Include role A
  hosts: all
  remote_user: root
  roles:
    - a'''
    data = AnsibleBaseYAMLObject.load(to_bytes(test_data))[0]
    variable_manager = VariableManager()
    loader = None
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:18:53.121198
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    block = Block()
    role = Role()
    task_include = TaskInclude()
    handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    assert(handler)

    data = {}
    handler = handler.load(data)
    assert(handler)

# Generated at 2022-06-23 06:19:04.460584
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    ))
    tqm = None


# Generated at 2022-06-23 06:19:13.929582
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from units.mock.loader import DictDataLoader

    # create the host in which the task will run
    inventory_hostname = 'webserver'
    inventory_host = Host(name=inventory_hostname)

    # create the task
    task_name = 'example'
    task_data = {
        'name': task_name,
        'include': { 'file': 'sub_task.yml' },
    }
    task_loader = DictDataLoader(task_data)
    task = Task.load(task_data, loader=task_loader)

    # create the handler

# Generated at 2022-06-23 06:19:25.029080
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    import json
    import io
    import os

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    from ansible.plugins import module_loader

    display = Display()

    group = Group('groupe')


# Generated at 2022-06-23 06:19:32.582499
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    class MockVariableManager:
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True, include_delegate_to=True, use_cache=True):
            return {'ansible_connection': 'local'}

    class MockLoader:
        def get_basedir(self):
            return './'

    data = {
        'include': './group_tasks/main.yml',
        'connection': 'local',
        'gather_facts': 'yes',
        'ignore_errors': 'yes',
    }

    handler = HandlerTaskInclude.load(
        data=data,
        variable_manager=MockVariableManager(),
        loader=MockLoader()
    )

    assert handler._role is None
    assert handler._handler_blocks == []



# Generated at 2022-06-23 06:19:36.529452
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    myvariable = 'localhost'
    myvariable1 = 'test.yml'
    myvariable2 = 'test'
    myvariable3 = 'defaults'
    myvariable4 = 'content'
    myvariable5 = 'append'
    myvariable6 = 'vars'
    data = {}
    data.update({'listen': myvariable5})
    data.update({'hosts': [myvariable]})
    data.update({'include': myvariable1})
    data.update({'name': myvariable2})
    data.update({'register': myvariable3})
    data.update({'content': myvariable4})
    data.update({'loop_control': myvariable6})
    data.update({'variables': {'x': 'y'}})
    t = HandlerTaskInclude()

# Generated at 2022-06-23 06:19:39.839714
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include="some.yaml"
    )
    handler = HandlerTaskInclude.load(data)
    assert handler._role_name == "some"
    assert handler._task_name == "main"

# Generated at 2022-06-23 06:19:43.950186
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()

# Generated at 2022-06-23 06:19:45.614392
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = HandlerTaskInclude()
    assert task_include is not None

# Generated at 2022-06-23 06:19:54.180016
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    args = {}
    args['block'] = None
    args['role'] = None
    args['task_include'] = None
    result = handler_task_include.load(data=None, variable_manager=None, loader=None, **args)

    assert result["include"] == None
    assert result["when"] == None
    assert result["static"] == None
    assert result["name"] == None
    assert result["listen"] == None
    assert result["role"] == None
    assert result["block"] == None
    assert result["action"] == None
    assert result["tags"] == None
    assert result["notify"] == None
    assert result["always_run"] == None
    assert result["delegate_to"] == None
    assert result["run_once"] == None


# Generated at 2022-06-23 06:19:57.753236
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        h = HandlerTaskInclude()
        data = {
            'name': 'handler_name',
            'include': 'play.yml',
            'listen': 'all'
        }
        h.load(data=data)
    except:
        assert False, "Failed to load in class HandlerTaskInclude"
    assert h.keys() == set(['name', 'include', 'listen', 'tags', 'when', 'register'])


# Generated at 2022-06-23 06:20:00.391615
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	HandlerTaskInclude(block="main", role="role_id", task_include="task_include")

# Generated at 2022-06-23 06:20:06.686639
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # HandlerTaskInclude(VALID_INCLUDE_KEYWORDS, load_options, load_data, load_task)
    # handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    k = HandlerTaskInclude
    v = {'a': 'a'}
    options = {'i': 'i'}
    res = k.check_options(options, v)
    print(res)
    pass


# Generated at 2022-06-23 06:20:08.832442
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-23 06:20:14.259327
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    taskInclude = TaskInclude()

    assert taskInclude.task is not None

    handlerTaskInclude = HandlerTaskInclude()

    assert handlerTaskInclude._load_role is None
    assert handlerTaskInclude._load_task is None
    assert handlerTaskInclude._load_block is None
    assert handlerTaskInclude._hosts is None
    assert handlerTaskInclude._listen is None
    assert handlerTaskInclude.name is None



# Generated at 2022-06-23 06:20:18.416993
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = TaskInclude.load({"include": "test_handler.yml"})
    handler = HandlerTaskInclude.load({"listen": "test_handler", "include": "test_handler.yml"}, task_include=task_include)

    assert handler is not None

# Generated at 2022-06-23 06:20:20.988442
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'name': 'create-a-user',
        'include': 'create-a-user.yml',
    }
    handler = HandlerTaskInclude.load(data)
    assert handler

# Generated at 2022-06-23 06:20:21.868033
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:20:23.215226
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:20:34.684636
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Create needed object type (for now)
    host = Host(name="test")
    host.set_variable("ansible_python_interpreter", "/usr/bin/python")

    u = AnsibleUnicode('test')
    block = Block()
    role = Role()
    task = Task()

    # Create a new HandlerTaskInclude object
    handler

# Generated at 2022-06-23 06:20:38.928461
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = Handler()
    handler.include = "test_include_test.test_test"
    assert handler.include == HandlerTaskInclude.load(data=handler, block=None, role=None, task_include=None, loader=None)

# Generated at 2022-06-23 06:20:43.038287
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    assert True



# Generated at 2022-06-23 06:20:44.785306
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    new_event = HandlerTaskInclude()
    import pdb; pdb.set_trace()

# Generated at 2022-06-23 06:20:56.592965
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    host = Host(name='localhost')
    play_context = PlayContext(become=True)
    variable_manager = VariableManager()

    task = Task()
    task.block = 'block1'
    assert task.block == 'block1'

    task.role = 'role1'
    assert task.role == 'role1'

    task.notify = 'notify1'
    assert task.notify == 'notify1'

    task.handler = 'handler1'
    assert task.handler == 'handler1'

    # test constructor of class HandlerTaskInclude

# Generated at 2022-06-23 06:21:05.047275
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    task = '''
    - debug:
        var=hostvars[inventory_hostname]
        verbosity=0
    '''

    task_list = HandlerTaskInclude.load(data=task, loader=loader, variable_manager=VariableManager())

    assert task_list[0]['action']['__ansible_verbosity'] == 0
    assert task_list[0]['action']['__ansible_module__'] == "debug"

# Generated at 2022-06-23 06:21:14.637719
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test with valid values
    hti = HandlerTaskInclude(block=True, role=True, task_include=True)
    assert isinstance(hti, HandlerTaskInclude)
    # Test class variables VALID_INCLUDE_KEYWORDS
    assert isinstance(hti.VALID_INCLUDE_KEYWORDS, set)
    assert len(hti.VALID_INCLUDE_KEYWORDS) == 3
    # Test static method load
    try:
        hti.load()
    except:
        assert 0
    assert 1

# Generated at 2022-06-23 06:21:16.601391
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert isinstance(hti, HandlerTaskInclude)


# Generated at 2022-06-23 06:21:23.007874
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    ansible_playbook_path = root_path + '/playbook/'
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:21:28.167865
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    myargs = {u'hosts': u'myhosts'}
    h = HandlerTaskInclude(myargs)
    assert h.is_handler()
    assert h.loop is None

#TODO: Write unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-23 06:21:29.979882
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None) == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:21:34.406884
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.base import Base

    # Test for default values
    hti = HandlerTaskInclude(role=None, task_include=None)
    assert isinstance(hti.block, Base)

    # Test for `block` is not None
    hti = HandlerTaskInclude(role=None, task_include=None, block='not None')
    assert isinstance(hti.block, Base)

# Generated at 2022-06-23 06:21:35.891253
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    H = HandlerTaskInclude()
    assert H is not None

# Generated at 2022-06-23 06:21:46.003063
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    play = Play().load({
        'name': 'foo',
        'hosts': 'all',
        'gather_facts': True,
        'tasks': [
            {'include': {'name': 'bar'}},
            {'include': {'static': 'baz'}}
        ],
        'handlers': [
            {'listen': 'bar', 'include': {'static': 'included-bar'}},
            {'listen': 'baz', 'include': {'name': 'included-baz'}}
        ]
    }, variable_manager=None, loader=None)

    assert len(play.handlers) == 2
    assert play.handlers[0]._block.name

# Generated at 2022-06-23 06:21:48.720992
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """HandlerTaskInclude._load"""
    data = dict( 
        include = dict( foo="bar" ),
        ignore_errors = True,
    )

    handler = HandlerTaskInclude.load(data)

    assert handler._attributes == dict( 
        include = dict( foo="bar" ),
        ignore_errors = True,
    )

# Generated at 2022-06-23 06:21:50.838698
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = {
        'include': 'handler.yml',
        'listen': 'test',
    }

    test_object = HandlerTaskInclude.load(task_include)
    assert test_object.include_file == 'handler.yml'
    assert test_object.listen == 'test'

# Generated at 2022-06-23 06:22:00.686396
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

    block_base_obj = Block(
        parent=None,
        role=None,
        task_include=None,
        use_role=None,
        loop=None,
    )

    # Create a instance of class Play
    play_context_obj = PlayContext()

    # Create a instance of class DataLoader
    loader_obj = DataLoader()

    # Create a instance of class InventoryManager

# Generated at 2022-06-23 06:22:11.269969
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'listen': 'on_startup', 'include': '../tasks/main.yml'}
    result = HandlerTaskInclude.load(data)
    assert result.get_tags() == ['on_startup']
    assert result.action == 'include'
    assert result.loop is None
    assert result.static is False
    assert result.name == '../tasks/main.yml'
    assert result.loop_control is None
    assert result.until is None
    assert result.retries == 3
    assert result.delay == 10
    assert result.register is None
    assert result.ignore_errors is False
    assert result.local_action is None
    assert result.when is False
    assert result.when_result is False
    assert result.post_validate is None
    assert result.failed_

# Generated at 2022-06-23 06:22:16.481497
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Constructor: handler.py")
    data = None
    block = None
    role = None
    task_include = None
    handler = HandlerTaskInclude(block, role, task_include)
    assert handler.VALID_INCLUDE_KEYWORDS == {'tasks', 'vars', 'handler', 'defaults', 'role', 'tags', 'ignore_errors', 'listen'}
    assert handler.__class__ == HandlerTaskInclude


# Generated at 2022-06-23 06:22:18.579049
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Unit test for method load of class HandlerTaskInclude")
    assert True

# Generated at 2022-06-23 06:22:30.624187
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handlers.when import When
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    block = Block()
    block.vars.update({
        'ansible_version' : {'full': '1.9.5'},
        'ansible_playbook_python' : 'Python 2.7.3',
        'ansible_managed' : '#v+',
        'ansible_filename' : 'test.yml',
        'ansible_host' : '127.0.0.1',
        'ansible_play_hosts_all' : ['127.0.0.1'],
    })
    block

# Generated at 2022-06-23 06:22:39.236988
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    # create instances
    host = Host(name="localhost")
    group = Group(name="sample_group")
    block = Block()
    task = Task()

# Generated at 2022-06-23 06:22:51.673283
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    # Test inventory
    host = Host("127.0.0.1",port=22)
    group = Group("test", host)
    inventory = InventoryManager(loader='ansible.parsing.dataloader.DataLoader')
    inventory.add_group(group)
    inventory.add_host(host)

    # Test variable
    variable_manager = VariableManager()

    # Test handler
    test_handler = HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:22:59.910774
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Load some data
    data = {'handlers': [
        {'listen': 'all', 'name': 'restart'},
        {'listen': 'restart', 'name': 'httpd'},
        {'listen': 'restart', 'name': 'nginx'}
        ]}

    # Load into Play
    p = Play().load(data, variable_manager=VariableManager(), loader=DataLoader())

    # Load into Handler
    h = HandlerTaskInclude(play=p)

    # Check data

# Generated at 2022-06-23 06:23:02.586176
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)

# Generated at 2022-06-23 06:23:12.989166
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    host = Host(name='fake_name')
    data = {'name': 'fake_name'}
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = handler_task_include.check_options(
        handler_task_include.load_data(data, variable_manager=variable_manager, loader=loader),
        data
    )
    handler.load_from_file = None
    handler.set_loader(loader)
    handler.set_host(host)


# Generated at 2022-06-23 06:23:19.747811
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.included_file import IncludedFile


    # Constract a TaskInclude instance
    t = TaskInclude()

    # Constract a Block instance
    b = Block()

    # Constract a Task instance
    task = Task()

    # Constract a IncludedFile instance
    included_file = IncludedFile()

    # Constract a Host instance
    host = Host()

    # Constract a HandlerTaskInclude instance
    handler = HandlerTaskInclude(block=b, role=task, task_include=t)

    # Constract a HandlerTaskInclude instance

# Generated at 2022-06-23 06:23:32.069766
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Create an instance of class HandlerTaskInclude
    test_object = HandlerTaskInclude()

    # Uncomment the following line to test if an instance of class HandlerTaskInclude is created
    # print(test_object)
    # Assert 'test_object' is an instance of class HandlerTaskInclude
    assert isinstance(test_object, HandlerTaskInclude)

    # Test the method load() of class HandlerTaskInclude
    # Uncomment the following lines to test it
    # test_data = {'a': 'b'}
    # test_block = None
    # test_role = None
    # test_task_include = None
    # test_variable_manager = None
    # test_loader = None
    # print(HandlerTaskInclude.load(test_data, test_block, test_role, test_task_include

# Generated at 2022-06-23 06:23:33.548194
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    t = HandlerTaskInclude()


# Generated at 2022-06-23 06:23:34.051040
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass