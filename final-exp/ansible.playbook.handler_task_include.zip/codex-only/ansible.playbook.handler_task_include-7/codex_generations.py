

# Generated at 2022-06-23 06:13:42.365881
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class AnsibleBlock():
        def __init__(self):
            self.roles = ['role1']
    class AnsiblePlay():
        def __init__(self):
            self.roles = ['role1']
    class AnsibleRole():
        def __init__(self):
            self.name = 'role1'
            self.path = '/path/to/role1'
    class AnsibleVariableManager():
        def __init__(self):
            self.extra_vars = {}
    class AnsibleLoader():
        def __init__(self):
            pass

    data = dict(
        include = dict(
            name = 'test'
        ),
        notify = dict(
            handlers = [
                dict(
                    name = 'test'
                )
            ]
        )
    )
    variable_

# Generated at 2022-06-23 06:13:42.966936
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:13:48.161557
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Here, we should test the type of HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    # and its return value
    # Here, we don't have a test example
    pass



# Generated at 2022-06-23 06:13:59.855947
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    data = b"""
    - name: Task name
      task:
        name: task name
        debug: msg=var
    """

    variable_manager = Mock()
    loader = AnsibleCollectionLoader(path='/etc/ansible/', variable_manager=variable_manager)

    handler = HandlerTaskInclude.load(
        data=data,
        variable_manager=variable_manager,
        loader=loader
    )

    assert handler.name == 'Task name'
    assert handler.block == None
    assert handler.role == None
    assert handler.task_include == None
    assert handler.tasks[0].name == 'task name'
    assert handler.tasks[0].action == 'debug'
    assert handler.tasks[0].args['msg']

# Generated at 2022-06-23 06:14:08.296953
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    host = 'myhost.com'

    handler = Handler.load(
        data=dict(
            include=dict(
                file='handler.yml',
                tasks='do it',
            ),
        ),
        variable_manager=VariableManager(loader=None, inventory=InventoryManager()),
        loader=None,
    )

    for keyword in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS:
        assert keyword in handler._attributes

    assert 'name' in handler._attributes
    assert handler._attributes['name'] == host

    assert 'include' in handler._attributes
    assert handler._attributes['include'] == 'handler.yml'

# Generated at 2022-06-23 06:14:11.250657
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler=HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler.__init__(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:14:20.547340
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ''' constructor for HandlerTaskInclude class'''
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    host = Host(name="myhost")
    group = Group(name="mygroup")
    group.add_host(host)
    variable_manager = VariableManager()
    loader = DataLoader()
    play_context =  PlayContext()
    play =  Play().load({}, variable_manager=variable_manager, loader=loader)
    variable_manager.set_inventory(host.get_group_vars())
    variable_manager.extra_v

# Generated at 2022-06-23 06:14:21.287074
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-23 06:14:24.470844
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('Testing HandlerTaskInclude class...')
    assert HandlerTaskInclude is not None
    print('HandlerTaskInclude class is good.')


# Generated at 2022-06-23 06:14:27.941645
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include.VALID_INCLUDE_KEYWORDS == set(('always', 'failed', 'ignore_errors', 'listen', 'name', 'register', 'retry', 'role', 'tags', 'when'))


# Generated at 2022-06-23 06:14:30.493336
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print(HandlerTaskInclude.load("include: some_file.yml"))

# Generated at 2022-06-23 06:14:31.137662
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:14:42.441883
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    
    from ansible.parsing.yaml import objects
    
    host = Host('127.0.0.1')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    group = Group('mygroup')
    
    task_include_data = objects.AnsibleMapping(dict(
        tasks = '/path/to/playbook/tasks/main.yml',
        handlers = '/path/to/playbook/handlers/main.yml',
    ))
    
    task_block_data

# Generated at 2022-06-23 06:14:49.684549
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Unit test for method load of class HandlerTaskInclude
    '''

    # Import needed function
    from ansible.playbook.task_include import load_list_of_tasks
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create a variable_manager
    variable_manager = VariableManager()

    # Create a loader
    loader = DataLoader()

    # Create the task name
    name = 'test_name'

    # Create the task data
    data = {
        'include': name,
        'free-form': None
    }

    # Create a HandlerTaskInclude
    handler_task_include = HandlerTaskInclude()

    # Load the handler data

# Generated at 2022-06-23 06:14:50.129151
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-23 06:15:01.716805
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class Fake_Data:
        def __init__(self):
            self.get = None
            self.get_option = None

    class Fake_EmptyData:
        def __init__(self):
            self.get = None
            self.error = None

    class Fake_Options:
        def __init__(self):
            self.keys = None

    class Fake_DataDict:
        def __init__(self):
            self.keys = None

    class Fake_Handler:
        def __init__(self):
            self.name = None

    class Fake_TaskInclude:
        pass

    class Fake_VariableManager:
        pass

    class Fake_Loader:
        pass

    fake_data = Fake_Data()
    fake_data.get = lambda x: True

# Generated at 2022-06-23 06:15:04.564515
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ''' constructor test '''
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert isinstance(hti, HandlerTaskInclude)

# Generated at 2022-06-23 06:15:10.170393
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "block": None,
        "role": None,
        "task_include": None
    }
    hti = HandlerTaskInclude.load(data=data)
    assert isinstance(hti, HandlerTaskInclude)

if __name__ == "__main__":
    test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:15:18.317758
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    yaml_data = '''
    - name: yaml_test
      hosts: yaml_test_group
      connection: local
      gather_facts: no
      tasks:
        - name: this is task1
        - name: this is task2
          include: include_tests.yaml
    '''

    print("Constructor test begining......")

    # initialize needed objects
    taskInclude = TaskInclude()
    block = Block()
    inventory = Inventory(loader=DataLoader())
    variable_manager = VariableManager()



# Generated at 2022-06-23 06:15:19.028783
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:15:30.856865
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ''' test constructer of class HandlerTaskInclude '''

    # Function 'load' can only be used with class variables
    # import unittest
    # class TestHandlerTaskInclude(unittest.TestCase):

    #     def setUp(self):
    #         self.task = HandlerTaskInclude()

    #     def test_HandlerTaskInclude(self):
    #         data = dict(
    #             include='/home/ian/git/ansible/lib/ansible/playbooks/tests/test.yml',
    #             vars=dict(one='1', two='2')
    #         )

    #         res = self.task.load(data)
    #         print(res)

    # if __name__ == '__main__':
    #     unittest.main()


# Generated at 2022-06-23 06:15:32.007934
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude('block', 'role', 'task_include')

# Generated at 2022-06-23 06:15:37.257641
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = Host("test_host")
    data = {"action": "test_action", "block": "test_block", "role": "test_role"}
    try:
        obj = HandlerTaskInclude(host=host, task_include=None, data=data)
        assert True
    except:
        assert False


# Generated at 2022-06-23 06:15:38.246954
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:15:40.345950
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test Constructor
    h = HandlerTaskInclude()
    assert(h is not None)

# Generated at 2022-06-23 06:15:51.398125
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    fake_data = dict(
        # HandlerTaskInclude specific parameters
        listen='some_label',

        # TaskInclude specific parameters
        import_role=None,
        include='fake.yaml',
        include_tasks='fake.yaml',
        include_vars='fake.yaml',
        include_role=None,
        include_tasks_from='fake.yaml',
        include_vars_from='fake.yaml',
        include_playbook='fake.yaml',
        include_from='fake.yaml',
        from_static_import='fake.yaml',
        from_static_import_role='fake.yaml'
    )
    fake_block = None
    fake_role = None
    fake_task_include = None
    fake_variable_manager = None
    fake_

# Generated at 2022-06-23 06:15:52.697967
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert (HandlerTaskInclude.load({}) is not None)

# Generated at 2022-06-23 06:15:55.030999
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t is not None


# Generated at 2022-06-23 06:15:57.632217
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO This will be implemented in future pull request
    pass

# Generated at 2022-06-23 06:16:05.485691
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "name": "Test Handler",
        "listen": "test",
        "include": "include_me.yml"
    }    
    t = HandlerTaskInclude(None, None, None)
    data = t.check_options(
            t.load_data(data, None, None),
            data
        )
    assert data.name == "Test Handler", "The name is not correctly set"
    assert data.listen == "test", "The listen is not correctly set"
    assert data.include == "include_me.yml", "The include is not correctly set"

# Generated at 2022-06-23 06:16:08.898091
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude != None

# Generated at 2022-06-23 06:16:10.674692
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude.load({"include": "roles/tomcat/tasks/main.yml"})

# Generated at 2022-06-23 06:16:15.362723
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   handler = HandlerTaskInclude(block=None, role=None, task_include=None)
   assert handler

# Generated at 2022-06-23 06:16:16.575257
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:16:22.455790
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class MockInclude(dict):
        def __init__(self, task_include):
            self.task_include = task_include
            self.listen = ''
            self.block = ''


    t = HandlerTaskInclude(block='', role='', task_include=MockInclude(''))
    handler = t.check_options(
        t.load_data({'include': 'test', 'block': 'append'}, variable_manager=None, loader=None),
        {'name': 'test task'}
    )

    assert handler['include'] == 'test'
    assert handler['tasks'] is None

# Generated at 2022-06-23 06:16:23.173527
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

# Generated at 2022-06-23 06:16:31.851407
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data_HandlerTaskInclude = {
        "handlers": {
            "name": "test",
            "listen": "test1",
        },
    }
    test_HandlerTaskInclude = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None,
    )
    test_HandlerTaskInclude.check_options(
        test_HandlerTaskInclude.load_data(data_HandlerTaskInclude),
        data_HandlerTaskInclude
    )
    print("Unit test function 'test_HandlerTaskInclude' finished")

# Generated at 2022-06-23 06:16:39.910503
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Test class constructor
    x = HandlerTaskInclude()
    assert x.__class__.__name__ == "HandlerTaskInclude"

    # Test VALID_INCLUDE_KEYWORDS
    assert isinstance(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS, set)
    assert len(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS) == 3
    assert 'include' in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert 'include_tasks' in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert 'listen' in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert 'include_role' not in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

    #

# Generated at 2022-06-23 06:16:50.591022
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = '''
    - name: Ansible register
      listen:
          on_any:
             handler: create

          on_changed:
             handler: update
          on_failed:
             handler: delete

    - name: Ansible task
      debug: msg={{ some_answer }}
    '''
    t = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert t.role is None
    assert t.task_include is None
    assert t.block is None
    assert t.handlers is not None

# Generated at 2022-06-23 06:16:51.254293
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:16:59.506781
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a HandlerTaskInclude object for tests below
    d = {'listen': 'test_listen', 'include': 'test_include'}
    handler = HandlerTaskInclude.load(d)
    assert type(handler) == HandlerTaskInclude
    assert handler.listen == 'test_listen'
    assert handler.include == [{'include': 'test_include'}]

    # Test constructor with no parameters
    handler = HandlerTaskInclude()
    assert type(handler) == HandlerTaskInclude
    assert handler.listen is None

    # Test constructor with parameters
    handler = HandlerTaskInclude(listen='my_listen')
    assert type(handler) == HandlerTaskInclude
    assert handler.listen == 'my_listen'



# Generated at 2022-06-23 06:17:01.574291
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

test_HandlerTaskInclude()


# Generated at 2022-06-23 06:17:04.149938
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)
    assert not isinstance(handler, dict)

# Generated at 2022-06-23 06:17:08.489065
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  # data1 = dict(name='localhost', port=1234)
  handler_task_include = HandlerTaskInclude();
  assert isinstance(handler_task_include, Handler)

# Generated at 2022-06-23 06:17:11.111685
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("\n\n")
    t = HandlerTaskInclude()
    print(t)
    assert (True)
    print("\n")

# Test static method load

# Generated at 2022-06-23 06:17:11.785866
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-23 06:17:13.076471
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:17:21.695779
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.template import Templar

    block = Block([])
    block.vars = dict(foo='bar')
    block.vars.update(dict(role_path='./'))

    role = Role.load({
        'role_name': 'test',
        'role_path': './',
        'defaults': {},
        'meta': {}
    })

    task_include = TaskInclude(block=block, role=role)


# Generated at 2022-06-23 06:17:27.915725
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude.load(
        data = dict(
            include = dict(
                tasks = dict(
                    task1 = dict(
                        action = dict(
                            module = 'ping',
                            args = dict(test="test"),
                            register = 'test',
                        )
                    ),
                )
            ),
        )
    )
    assert h.action == 'include'
    assert h.include == './tasks/task1.yml'



# Generated at 2022-06-23 06:17:28.530782
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:17:34.552294
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    handler = Handler()
    task = HandlerTaskInclude(block=Block(), role=Role(), task_include=TaskInclude(block=Block(), role=Role()))
    assert isinstance(task, TaskInclude)
    assert isinstance(task, Handler)


# Generated at 2022-06-23 06:17:37.304386
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.block is None
    assert handler.role is None

# Generated at 2022-06-23 06:17:48.792996
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import mock
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    import ansible.inventory
    from ansible.inventory.host import Host

    mock_block = mock.Mock(spec=PlayContext)
    mock_role = mock.Mock(spec=Task)
    mock_task_include = mock.Mock(spec=TaskInclude)
    mock_variable_manager = mock.Mock()
    mock_loader = mock.Mock()
    h = HandlerTaskInclude(
        block=mock_block,
        role=mock_role,
        task_include=mock_task_include,
    )

    data = {
        'name': 'some_handler',
        'listen': 'some_event',
    }

    h.check

# Generated at 2022-06-23 06:17:49.792264
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:17:50.898670
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj != None


# Generated at 2022-06-23 06:18:00.719856
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import Play
    from ansible.inventory import Host
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader, variable_manager, host_list=['my_host'])
    variable_manager.set_inventory(inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args='')),
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    tqm = None

# Generated at 2022-06-23 06:18:06.741367
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
    '''
    hti = HandlerTaskInclude()
    contents = '''

# Generated at 2022-06-23 06:18:18.343935
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data={'include': 'foo.yml', 'when': 'foo', 'rescue': [{'include': 'rescue-foo.yml', 'when': 'foo'}], 'always': [{'include': 'always-foo.yml', 'when': 'foo'}], 'tags': ['bar']}

    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=Task(), variable_manager=VariableManager(), loader=DataLoader())
    assert type(handler) is HandlerTaskInclude
    assert handler._role is None
    assert handler._block is None
    assert handler

# Generated at 2022-06-23 06:18:19.205475
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:18:25.691198
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test with a valid handler
    data = {}
    data['name'] = "test_handler"
    data['listen'] = "test_listen"
    data['block'] = "test_block"
    data['role'] = "test_role"
    data['tasks'] = []
    test_handler = HandlerTaskInclude.load(data, block="test_block", role="test_role", task_include="test_task_include")
    assert test_handler.name == "test_handler"
    assert test_handler.listen == "test_listen"
    assert test_handler.block == "test_block"
    assert test_handler.role == "test_role"

# Generated at 2022-06-23 06:18:27.125650
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:18:31.686597
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(
        data={
            'include': 'somefile.yml',
            'listen': 'all'
        }
    )
    assert handler.include == 'somefile.yml'
    assert handler.listen == 'all'

# Generated at 2022-06-23 06:18:43.245766
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    tasks = [
        {
            "name": "add user",
            "user": "test"
        },
        {
            "name": "add group",
            "group": "test"
        }
    ]


# Generated at 2022-06-23 06:18:43.758383
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:18:48.308401
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert issubclass(HandlerTaskInclude, Handler)
    assert issubclass(HandlerTaskInclude, TaskInclude)
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'vars', 'ignore_errors', 'freeze', 'name', 'loop', 'loop_control', 'when', 'tags', 'register', 'delegate_to', 'listen'}

# Generated at 2022-06-23 06:18:49.737865
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude(block=None, role=None, task_include=None) is not None


# Generated at 2022-06-23 06:18:58.975208
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    
    loader = DataLoader()
    variable_manager = VariableManager()
    data = dict(
        include_tasks = '../tasks/test.yaml'
    )
    host = Host(name='test_host')
    group = Group(name='group')
    group.add_host(host)
    task_include = TaskInclude(block=group, role=None)
    host.set_variable_manager(variable_manager)
    group.set_variable_manager(variable_manager)
    task_include.set_variable_manager(variable_manager)
    handler = HandlerTaskInclude.load

# Generated at 2022-06-23 06:19:10.186247
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    data = {
        "include": "{{ playbook_dir }}/main.yml",
        "include_tasks": "{{ playbook_dir }}/main.yml",
        "import_tasks": "{{ playbook_dir }}/main.yml",
    }
    # Result package should be None
    assert HandlerTaskInclude.load(data=data, variable_manager=variable_manager, loader=loader) is None


# Generated at 2022-06-23 06:19:20.379176
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handlers.notify import ActionModuleNotify
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.role import Role
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

    fake_loader_obj = object()
    fake_block_obj = Block(
        parent_block=None,
        role=Role(),
        use_role_tasks=False,
        task_include=TaskInclude(block=None, role=Role()),
        play=None
    )

# Generated at 2022-06-23 06:19:23.776785
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    include = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None
    )
    assert include.block is None
    assert include.role is None
    assert include.task_include is None

# Generated at 2022-06-23 06:19:24.256179
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:19:30.460614
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude
    #
    # simple case:
    #
    # hti.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    #
    # more complex case:
    #
    # hti.load(data, block=<Block instance>, role=<Role instance>, task_include=None, variable_manager=None, loader=None)
    #

    # simple case:
    assert type(hti.load(data={'include': 'foo'})) == HandlerTaskInclude

    # more complex case:
    # FIXME: implement
    # assert 1 == 2
    pass


# Generated at 2022-06-23 06:19:40.504404
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    # Is there is a way to mock the InventoryManager?
    # inventory = InventoryManager(loader=DataLoader())
    # inventory.parse_sources()
    
    # What is the purpose of this code?
    # if 'hosts' not in data:
    #    data['hosts'] = 'all'

    data = {
        u'name': 'action_test_handler',
        u'local_action': 'command',
        u'connection': 'local',
        u'args': 'echo 1'
    }

    context = PlayContext()
    context.setup_cache()
    # host_list = inventory.get_hosts(data['hosts'])
    # hosts = [Host(name=h.

# Generated at 2022-06-23 06:19:51.020108
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # pylint: disable=unused-variable
    test_data = '''
- name: ansible-create-directory-example
    hosts: all
    become: True
    become_user: root
    become_method: sudo
    vars:
      project_path: /var/www/ansible-default-project
      project_user: www-data
    tasks:
    - name: Create Directory
      file:
        state: directory
        path: "{{ project_path }}"
      handlers:
      - name: Create Symlinks
        include: symlinks.yml project_path="{{ project_path }}"
      tags:
      - create-directory
    tags:
    - create-directory-example
'''

    # test_load_data()

# Generated at 2022-06-23 06:19:52.134565
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:54.839012
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block="", role="", task_include="")


# Generated at 2022-06-23 06:19:58.625048
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # host = Host('localhost')
    # host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    # host_vars = HostVars(host, variables=dict())
    handler = HandlerTaskInclude()

# Generated at 2022-06-23 06:20:08.818940
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible import inventory
    from ansible import variables
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    task_include = TaskInclude.load(dict(include="helloworld.yml"))
    print("task_include=", task_include)

    # from ansible.playbook.handler import Handler
    # handler_task_include = HandlerTaskInclude.load(data=dict(include="helloworld.yml"))

    inv = inventory.Inventory()
    varMgr = variables.VariableManager(loader=None, inventory=inv)

# Generated at 2022-06-23 06:20:09.786782
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    event = HandlerTaskInclude()
    assert event

# Generated at 2022-06-23 06:20:11.985628
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude().__class__.__name__ == 'HandlerTaskInclude'
    assert HandlerTaskInclude().__module__ == 'ansible.playbook.handler_task_include'

# Generated at 2022-06-23 06:20:13.272853
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task = HandlerTaskInclude()
    assert task is not None


# Generated at 2022-06-23 06:20:19.118670
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test parameters
    data = {
        'type': 'include',
        'include': 'foo.yml',
        'static': 'yes'
    }
    block = None
    role = None
    task_include = None

    handler = HandlerTaskInclude.load(data, block, role, task_include)
    assert handler is not None
    assert handler.static

# Generated at 2022-06-23 06:20:23.967355
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # GIVEN a data as a dict
    data = {
        "name": "handler1"
    }
    # WHEN load method is executed
    handler = HandlerTaskInclude.load(
        data=data
    )
    # THEN assert if the data was loaded
    assert handler is not None

# Generated at 2022-06-23 06:20:28.032603
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert isinstance(obj, HandlerTaskInclude)
    assert isinstance(obj, Handler)
    assert isinstance(obj, TaskInclude)
    assert obj != None

# Generated at 2022-06-23 06:20:30.745389
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t is not None
    assert t.VALUE_REQUIRED == 'required'
    assert t.VALUE_ONLY is None

# Generated at 2022-06-23 06:20:35.202019
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test for empty object
    test_handler = HandlerTaskInclude()

    # Test for object initialized with known input
    test_handler = HandlerTaskInclude(block=None, role=None, task_include=None)


# Generated at 2022-06-23 06:20:35.638257
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:20:45.596976
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Configure arguments and parameters of your plug-in
    connection = 'local'
    delegate_to = None
    names = ['user-service', 'user-server']
    tasks_src = '../tasks/main.yml'
    handlers_src = '../handlers/main.yml'
    vars_src = '../vars/main.yml'

    # Defines the configuration for this plug-in (as defined in ./galaxy.yml)
    config = {
        'handler_block': {
            'module_utils': 'path/to/module_utils',
            'module_utils_arg': 'module_utils_arg'
        }
    }

    # Start of your testing code
    from ansible.plugins.loader import handler_loader
    import ansible.constants as C

# Generated at 2022-06-23 06:20:57.452281
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    #from ansible.playbook.handler import Handler
    from ansible.plugins import callback_loader
    from ansible.template import Templar


# Generated at 2022-06-23 06:21:05.544789
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    data = dict(
        include='/Users/pkulkar6/GIT/ansible_test_playbooks/include_with_args.yml'
    )
    handler = HandlerTaskInclude.load(
        data=data,
        variable_manager=None,
        loader=None
    )
    assert isinstance(handler, HandlerTaskInclude)
    assert 'include' in handler._attributes
    assert type(handler.blocks) == list
    assert handler.static is False
    assert handler.name is None
    assert handler.tags == ['all']
    assert handler.when is None
    assert handler.notify is False
    assert handler.loop is None
    assert handler.include_role is None
   

# Generated at 2022-06-23 06:21:17.697393
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  from ansible.playbook.task import Task
  from ansible.playbook.task_include import TaskInclude
  from ansible.playbook.play_context import PlayContext
  from ansible.inventory.host import Host

  args = [
    'localhost',
    'example_module',
    {
        "debug": "yes please",
        "arguments": {"one": "two"},
        "environment": {"ANSIBLE_REMOTE_USER": "root"},
        "sudo": True,
        "sudo_user": "bob",
        "remote_user": "alice",
        "volatile": ["one", "two", "three"]
    },
    'handler.yml'
  ]
  task = Task.load(*args)
  args = [task, None]
  task_include = TaskInclude.load

# Generated at 2022-06-23 06:21:23.517603
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("test_HandlerTaskInclude_load():")

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager

    data = AnsibleUnicode("something")
    block = None
    role = None
    task_include = None
    variable_manager = VariableManager()

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager)

# Generated at 2022-06-23 06:21:27.364298
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # pass
    HandlerTaskInclude.load({
        'include': "foo.yml",
        'static': "yes",
    }, task_include=TaskInclude)

# Generated at 2022-06-23 06:21:33.584020
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    #from ansible.vars import VariableManager
    #from ansible.inventory.manager import InventoryManager
    #from ansible.parsing.dataloader import DataLoader
    #from ansible.playbook.play import Play
    #from six import string_types
    #import json

    # Given a playbook and task that includes a handler
    handler = HandlerTaskInclude(block=None, role=None, task_include=TaskInclude(block=None, role=None, task=Task()))
    handler.action = 'copy'
    handler.name = 'test-handler'
    handler._role = 'test-role'
   

# Generated at 2022-06-23 06:21:34.307693
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()

# Generated at 2022-06-23 06:21:45.861242
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)

    task_include = dict(tasks={'tasks/main.yml': dict(foo='bar')})
    data = dict(include=task_include)
    handler = HandlerTaskInclude.load(data=data, task_include=task_include, variable_manager=variable_manager, loader=loader)

    assert isinstance(handler, HandlerTaskInclude)
    assert handler._block == None
    assert handler._role == None

# Generated at 2022-06-23 06:21:49.572939
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = HandlerTaskInclude()
    assert(task_include.VALID_INCLUDE_KEYWORDS == {'tasks', 'vars', 'tags', 'listen'})

# Generated at 2022-06-23 06:21:51.466343
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    Handler = HandlerTaskInclude
    x = Handler()
    assert x

# Generated at 2022-06-23 06:21:56.621432
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    t = hti.load({
        "include": "role1",
        "listen": "general"
    })
    # objects returned should be instance of Handler
    assert isinstance(t, Handler)
    assert t._role == "role1"
    assert t._listen == "general"

# Generated at 2022-06-23 06:22:08.545877
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template.template import Template
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from io import StringIO

    loader = DataLoader()
    hostvars = dict(foo='bar')
    extra_vars = dict(spam='eggs')


# Generated at 2022-06-23 06:22:12.258831
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    handler_task_include.load('role_name')
#End of test of HandlerTaskInclude class

if __name__ == "__main__":
    x = HandlerTaskInclude()
    x.load('role_name')

# Generated at 2022-06-23 06:22:13.415193
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:22:15.213730
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:22:26.663485
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:22:37.854490
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    variable_manager = MagicMock()
    loader = MagicMock()

    # PlaybookExecutionException should be raised if the attribute "include" is not defined in 'data'
    with pytest.raises(errors.AnsibleError) as exec_info:
        HandlerTaskInclude.load(data={}, block=MagicMock(), role=MagicMock(), task_include=MagicMock(), variable_manager=variable_manager, loader=loader)
    assert 'include tasks are only valid for import_playbook' in str(exec_info.value)

    # PlaybookExecutionException should be raised if the attribute "include" is not defined in 'data'

# Generated at 2022-06-23 06:22:49.873742
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block

    data = '''---
    - include: test.yml
      listen:
        - test1
        - test2
    '''
    block = Block()
    role = InventoryManager("/")
    task_include = None
    variable_manager = VariableManager()
    loader = DataLoader()
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert handler.task == "include"
    assert handler.listen == ["test1", "test2"]


# Generated at 2022-06-23 06:23:05.520881
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.module_utils.six import string_types

    # Create loader instance
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    paths = PlaybookExecutor.load_callbacks_plugins(loader)
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create Handler instance
    block = [ Task() ]

# Generated at 2022-06-23 06:23:13.905934
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-23 06:23:23.558843
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import json
    import yaml
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # JSON
    data = {"include": "site.yml"}
    handler = HandlerTaskInclude.load(data)
    assert not handler
    assert handler.data == data

    data = {"include": "site.yml", "register": "my_results"}
    handler = HandlerTaskInclude.load(data)
    assert handler
    assert handler.data == data

    data = {"include": "site.yml", "delegate_to": "localhost"}
    handler = HandlerTaskInclude.load(data)

# Generated at 2022-06-23 06:23:34.478114
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("""
####################################################
# This is a method unit test for HandlerTaskInclude method load
#
# The test json data and the instantiation of class HandlerTaskInclude
# is made in the TestHandlerUnitTest.py module
#
# To run this test, please exec the following commands:
#
#   ansible-playbook -i ../../inventory --connection=local --sudo test_HandlerTaskInclude.yml --extra-vars 'conne
#     ction_hosts=["kolla_all_in_one"]' --check
#
####################################################
""")
    print("************** TEST: HandlerTaskInclude.load *************")
    # create variable manager
    variable_manager = variable_manager.VariableManager()