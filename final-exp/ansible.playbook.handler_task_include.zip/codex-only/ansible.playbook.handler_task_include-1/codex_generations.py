

# Generated at 2022-06-23 06:13:35.410951
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    data['name'] = 'some_handler'
    block = {}
    role = {}
    task_include = {}
    handler = Handler.load(data, block=block, role=role, task_include=task_include)
    expected = data['name']

    assert handler.name == expected

# Generated at 2022-06-23 06:13:36.735382
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler=HandlerTaskInclude()
    return

# Generated at 2022-06-23 06:13:39.524514
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    includeFilePath = '/path/to/include.yaml'
    includeFile = open(includeFilePath, 'r')
    data = includeFile.read()

    handler = HandlerTaskInclude.load(data)
    assert handler == None

# Generated at 2022-06-23 06:13:50.038931
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.task      import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager       import VariableManager

    task_vars = dict(
        playbook_dir='/playbook.yml'
    )
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    loader = None

    play_context = PlayContext()
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.connection = 'ssh'
    play_context.module_name = ''
    play_context.remote_addr = ''
    play_context.port = ''
    play_context.user = ''
    play_context.network_

# Generated at 2022-06-23 06:13:55.945790
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None
    for attr in ('block', 'role', 'task_include', '_next_vars'):
        assert hasattr(handler, attr)
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler._next_vars == []

# Generated at 2022-06-23 06:14:07.067160
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def test_case(input_data, output_data, options):
        t = HandlerTaskInclude(block=None, role=None, task_include=None)
        handler = t.check_options(
            t.load_data(input_data, variable_manager=None, loader=None),
            output_data
        )
        assert handler.include_pat == options['include_pat']
        assert handler.include_file == options['include_file']
        assert handler.include_vars == options['include_vars']
        assert handler.include_handler == options['include_handler']
        assert handler.loop_control == options['loop_control']
        assert handler.loop_var == options['loop_var']
        assert handler.static == options['static']
        assert handler.when == options['when']
        assert handler.de

# Generated at 2022-06-23 06:14:09.564204
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#    data = "name: Handler test"
#    handler = HandlerTaskInclude.load(data)
#    assert handler.name == 'Handler test'

# Generated at 2022-06-23 06:14:19.556212
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    import os
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/units/inventory/fake.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    fake_task = Task()
    fake_task._role = None
    fake_task.action = 'copy'
    fake_task.args = dict(src='test', dest='test')
    fake_task.set_loader(loader=loader)
    fake_task

# Generated at 2022-06-23 06:14:29.888132
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    
    data = AnsibleVaultEncryptedUnicode('''
        name: jj
        listen: "{{ aaa }}"
        when: "{{ bbb }}"
        include: ccc
        ignore_errors: "{{ ddd }}"
        static: "{{ eee }}"
    ''')

# Generated at 2022-06-23 06:14:33.845764
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(data={'listen': 'database_restarted'})

    assert len(handler.notified_by) == 1
    assert handler.notified_by[0] == 'database_restarted'

# Generated at 2022-06-23 06:14:44.674332
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import reserved
    handler_task_include = HandlerTaskInclude()
    host = Host()
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, 'hostvars', {})
    variable_manager.set_host_variable(host, reserved.DEFAULT_HASH_BEHAVIOUR, 'merge')
    variable_manager.extra_vars = {}
    variable_manager.options_vars = []

    assert handler_task_include._load_tasks_from_block(block=[], play=None) == []

# Generated at 2022-06-23 06:14:49.903570
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    string_handler = """
    - include: add_new_user.yml
    """
    from ansible.parsing.yaml import objects

    handler = HandlerTaskInclude.load(
        objects.AnsibleMapping(string_handler),
        variable_manager={},
        loader={},
    )
    assert True

# Generated at 2022-06-23 06:15:01.443860
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Host

    host = Host("host")
    data = {
        "hosts": "all",
        "tasks": [
            {
                "action": {
                    "module": "pause",
                    "seconds": "1"
                }
            }
        ],
        "vars": {
            "var": "value"
        }
    }

    handler = HandlerTaskInclude.load(data)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'
    assert handler.block == None
    assert handler.role == None
    assert handler.task_include == None
    assert handler.name == 'handler.yml'
    assert handler.listen == 'all'
    assert handler.action._task._role == None

# Generated at 2022-06-23 06:15:04.298274
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(name='abc', tags=['abc'], when=['abc'], notify=['abc'])
    test_HandlerTaskInclude = HandlerTaskInclude.load(data)
    assert test_HandlerTaskInclude != None

# Generated at 2022-06-23 06:15:06.742078
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj


# Generated at 2022-06-23 06:15:16.180948
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleVars
    from ansible.template import Templar


    Inventory.get_variable_manager = lambda x,y: VariableManager()
    Handler.load = lambda x,y,z,task_include=None: Task()
    TaskInclude

# Generated at 2022-06-23 06:15:18.637771
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None
    print(handler)


# Generated at 2022-06-23 06:15:19.907419
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude is not None

# Generated at 2022-06-23 06:15:31.709168
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'file',
        'include_vars': {
            'file': 'foobar.yml'
        }
    }

    def new_task_include():
        return TaskInclude()

    def new_handler(block, role, task_include):
        return HandlerTaskInclude(block=block, role=role, task_include=task_include)

    import ansible.playbook.task_include as ti
    ti.TaskInclude = new_task_include
    from ansible.playbook.handler import Handler
    Handler.handler_loader_class['include'] = new_handler

    handler = HandlerTaskInclude.load(data=data)

    assert handler.get_name() == 'include'
    assert handler.get_all_vars() == {}

# Generated at 2022-06-23 06:15:43.181027
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.variable_manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    host_list = ["localhost"]
    inventory = InventoryManager(loader=None, sources=host_list)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    # variable_manager._extra_vars = {'host_list': host_list}

    play_context = PlayContext()
    play_context._hostvars = {}
    play_context._hostvars['localhost'] = {}
    module_name = 'ping'
    loader = None
    # task_queue_manager = TaskQueueManager(
    #     inventory=inventory,
    #     variable_manager=variable

# Generated at 2022-06-23 06:15:44.422211
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
	assert False

# Generated at 2022-06-23 06:15:48.847913
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    a = HandlerTaskInclude()
    assert isinstance(a.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None),  HandlerTaskInclude)

# Generated at 2022-06-23 06:15:58.237608
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    variables = dict(
        server=dict(
            host=dict(
                ansible_host='localhost',
            ),
            db=dict(
                ansible_host='127.0.0.1',
            )
        ),
        lb=dict(
            ansible_host='127.0.0.2'
        )
    )
    
    #print(variables)
    #print(type(variables))
    #print(variables.keys())
    #print(variables['server'])
    #print(variables['server'].keys())
    #print(variables['server']['host'])
    #print(variables['server']['host'].keys())

    #print(variables['lb'])
    #print(type(variables['lb']))
    #print(vari

# Generated at 2022-06-23 06:16:00.343733
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    c1 = HandlerTaskInclude()
    c2 = HandlerTaskInclude.load('test.ym')


# Generated at 2022-06-23 06:16:02.902883
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # TODO: Write the unit test
    assert False

# Generated at 2022-06-23 06:16:07.702481
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    expected =  {
        'name': 'test',
        'include': 'test.yml',
        'register': 'result',
        'window': 120
    }

    handler = HandlerTaskInclude.load(data=expected)
    assert handler.__class__ == HandlerTaskInclude
    assert handler.get_name() == 'test'

# Generated at 2022-06-23 06:16:08.904539
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()

    # assert t.load() ==

# Generated at 2022-06-23 06:16:11.682708
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    my_dict = {'name' : 'handler1'}
    assert handler.load_data(my_dict) == {'name' : 'handler1'}

# Generated at 2022-06-23 06:16:16.039975
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude



# Generated at 2022-06-23 06:16:27.875163
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    import os

    block = Block()
    role = Role()
    task = HandlerTaskInclude()
    variable_manager = VariableManager()
    loader = None

    data = dict(
        include='main.yml'
    )

    dataPath = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    include_file = os.path.join(dataPath, 'tasks', 'handlers', 'handlers_include.yaml')
    data_file = open(include_file)

# Generated at 2022-06-23 06:16:30.340024
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    print("HandlerTaskInclude: %s" % str(hti))

# Generated at 2022-06-23 06:16:34.451179
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """ This unit test is to check if the constructor of Ansible class HandlerTaskInclude works """
    try:
        handler = HandlerTaskInclude()
    except Exception:
        raise AssertionError("Failed to create the constructor of Ansible class HandlerTaskInclude")


# Generated at 2022-06-23 06:16:35.019514
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:16:38.590178
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("\nSTART test_HandlerTaskInclude")
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None
    print("Success test_HandlerTaskInclude")



# Generated at 2022-06-23 06:16:39.563417
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude


# Generated at 2022-06-23 06:16:40.143380
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:16:47.722763
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import sys
    import os
    import json
    import tempfile
    import shutil
    import pytest
    import unittest
    import ansible.inventory.host
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.plugins
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Test dependency classes
    class TestInventory(ansible.inventory.manager.InventoryManager):
        def __init__(self):
            self.loader = None
            self.variable_manager = None
            self.groups = {}
            self.hosts

# Generated at 2022-06-23 06:16:48.742624
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False


# Generated at 2022-06-23 06:16:49.990870
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-23 06:16:51.684276
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    HandlerTaskInclude.load(data)

# Generated at 2022-06-23 06:16:58.363363
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Set some parameters
    #block = 'main'
    #role = 'webserver'
    #task_include = TaskInclude(block=block, role=role)
    #document = {
    #    'include': 'some_tasks',
    #    'tasks': [{
    #        'name': 'Some task',
    #        'shell': 'echo "Hello World!"'
    #    }]
    #}

    #handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    #handler.load(document)
    pass

# Generated at 2022-06-23 06:17:01.208721
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None



# Generated at 2022-06-23 06:17:03.264448
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test without providing the 'block' parameter
    HandlerTaskInclude()

    # Test with 'block' parameter
    HandlerTaskInclude(block=None)

# Generated at 2022-06-23 06:17:04.201291
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:17:14.017776
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task

    this_task = Task()
    this_task._role = 'role'
    this_task._block = 'block'

    my_include = HandlerTaskInclude(
        block='block', role='role', task_include='task_include'
    )
    my_include.check_options = lambda x, y: x
    my_include.load_data = lambda x: x

    my_include = HandlerTaskInclude.load(
        data='data',
        block='block', role='role', task_include='task_include'
    )



# Generated at 2022-06-23 06:17:23.893288
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': 'foobar',
        'tags': ['foo','bar','baz'],
        'when': 'baz',
        'name': 'foobar'
    }
    handler = HandlerTaskInclude.load(
        data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    assert handler.action == 'include'
    assert handler.name == 'foobar'
    assert handler.tags == ['foo','bar','baz']
    assert handler.when == 'baz'
    assert handler.loop is None

# Generated at 2022-06-23 06:17:28.192734
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    print(f"handlerTaskInclude: {handlerTaskInclude}")


# Generated at 2022-06-23 06:17:34.601967
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include_tasks': {
            'name': 'include',
            'connection': 'local',
        }
    }
    handler = HandlerTaskInclude(role=None, task_include=None)
    include = handler.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    print(include)

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:17:39.022286
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data = {"include": "test.yml", "name": "test_include", "tags": "test"}
    t = HandlerTaskInclude()
    t.load(test_data)
    assert t.data == test_data
    assert t.block == None
    assert t.role == None
    assert t.task_include == None

# Generated at 2022-06-23 06:17:49.962970
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Create some data
    myblock = Block()
    myhost = Host()
    myhost.name = 'host1'
    myhost.vars['mytestvar'] = 'SomeValue'
    myhost.groups = [{"name": "testgroup"}]
    myblock.hosts.add(myhost)
    inventory = InventoryManager(loader=DataLoader())
    inventory.add_host(myhost)
    inventory.add_group('testgroup')
    inventory.add_child('testgroup', myhost)

    # Create Variable Manager

# Generated at 2022-06-23 06:17:58.752066
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    myhost = Host(name="myhost", port=22)
    mygroup = Group(name="mygroup")
    mygroup.add_host(myhost)
    host_list = [myhost]
    group_list = [mygroup]

    block = Block(play=None)


# Generated at 2022-06-23 06:18:01.544079
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert isinstance(HandlerTaskInclude.load({'include': 'test.yml'}), HandlerTaskInclude)


# Generated at 2022-06-23 06:18:11.062404
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from copy import copy
    from units.mock.loader import DictDataLoader

    t = HandlerTaskInclude()

    data = AnsibleLoader(
        None,
        variable_manager=VariableManager(),
        loader=DictDataLoader({}),
    ).load('''
        - name: test handler
          include: test.yml
          listen:
            - httpd restarted
    ''')

    vars = VariableManager()
    inventory = InventoryManager(loader=DictDataLoader({}))


# Generated at 2022-06-23 06:18:13.906678
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load({'include': '/path/to/file'})
    assert HandlerTaskInclude.load({'include': 'file.yml'})

# Generated at 2022-06-23 06:18:24.057814
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    dummy_block = {'name': 'block_name'}
    dummy_role = {'name': 'role_name'}
    dummy_task_include = {'name': 'task_include_name', 'block':'block_name'}
    dummy_data1 = {'name': 'data1'}
    dummy_data2 = {'name': 'data2'}
    dummy_data3 = {'name': 'data3'}
    dummy_data4 = {'name': 'data4'}
    dummy_data5 = {'name': 'data5'}
    dummy_data6 = {'name': 'data6'}

    h = HandlerTaskInclude.load(dummy_data1, block=dummy_block, role=dummy_role, task_include=dummy_task_include)
   

# Generated at 2022-06-23 06:18:31.404486
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Check normal constructor
    handler = HandlerTaskInclude()
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

    # Check constructor with args
    handler = HandlerTaskInclude(block=1, role=1, task_include=1)
    assert handler.block == 1
    assert handler.role == 1
    assert handler.task_include == 1

# Generated at 2022-06-23 06:18:42.998087
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.inventory.host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.hosts import Host
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.plugins import module_loader
    from ansible.template import Templar

    t1 = HandlerTaskInclude()
    host = ansible.inventory.host.Host("127.0.0.1")
    block = Block(task_include=None, role=None)
    block.vars = dict()
    block.vars["block_var"] = "block_var_value"
    block.resolve_non_vars

# Generated at 2022-06-23 06:18:43.511238
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:18:51.998130
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.task import Task
    from ansible.module_utils._text import to_text
    import json

    variable_manager = VariableManager()
    loader = DataLoader()

    host = Host(name="test", port=22)
    inventory = Inventory()
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    loader = DataLoader()
    t = Task()

    data = {}
    data['listen'] = "all"
    data['include'] = "test.yaml"

# Generated at 2022-06-23 06:18:59.126362
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import find_plugin

    task_include = TaskInclude(action=find_plugin('include'))

    data = dict(
        static='my_handlers',
        files='my_handlers',
        name='my_handlers',
        task='my_handlers',
    )

    handler = HandlerTaskInclude.load(data, task_include=task_include)

    assert handler.action == 'my_handlers'
    assert handler.args == data
    assert isinstance(handler, Task)



# Generated at 2022-06-23 06:19:00.616909
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:19:03.312031
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # The block is always None and the task_include is always none in previous tests.
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:19:03.962135
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:06.059420
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)


# Generated at 2022-06-23 06:19:14.726532
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    class HandlerTaskInclude(Handler, TaskInclude)
        def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
    '''

    print("\n\nTESTING HandlerTaskInclude.load")
    def test_body(data, block, role, task_include, variable_manager, loader):
        t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
        print("\n")
        task = t.check_options(
            t.load_data(data, variable_manager=variable_manager, loader=loader),
            data
        )
        print("\n")
        print("TEST OK")


# Generated at 2022-06-23 06:19:17.491998
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    x = HandlerTaskInclude()
    assert x is not None

# Generated at 2022-06-23 06:19:18.863493
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # create an instance of HandlerTaskInclude
    HandlerTaskInclude()

# Generated at 2022-06-23 06:19:27.979563
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # create host, group and variable_manager
    h = Host()
    g = Group()
    h.set_variable_manager(VariableManager(host_vars=HostVars(host=h, group=g), loader=None))
    g.set_variable_manager(VariableManager(host_vars=HostVars(host=h, group=g), loader=None))

    h.name = 'example.com'
    g.name = 'test-group'

    # variable_manager is required

# Generated at 2022-06-23 06:19:34.741756
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = HandlerTaskInclude.load({
        'include': 'foo.yml',
        'listen': 'on_vpn_up',
        'tags': 'bar'
    })

    assert(hasattr(data, 'listen'))
    assert(hasattr(data, 'tags'))
    assert(hasattr(data, 'include'))
    assert(not hasattr(data, 'ignore_errors'))

# Generated at 2022-06-23 06:19:37.442393
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test instantiation of the class HandlerTaskInclude
    obj = HandlerTaskInclude()


# Generated at 2022-06-23 06:19:51.049508
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Set up data for testing the constructor
    from ansible.inventory import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()
    h = Host(name='test')
    h.vars = VariableManager()
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    t1 = t.load(data={'listen': 'test'}, block=None, role=None, task_include=None, variable_manager=None, loader=dl)
    t2 = t.load(data={'listen': None}, block=None, role=None, task_include=None, variable_manager=None, loader=dl)

# Generated at 2022-06-23 06:19:51.543148
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-23 06:19:55.706943
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler_task_include is not None

# Generated at 2022-06-23 06:19:58.530646
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert issubclass(HandlerTaskInclude, Handler)
    assert issubclass(HandlerTaskInclude, TaskInclude)

#testing load function of class HandlerTaskInclude

# Generated at 2022-06-23 06:20:01.495116
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # test with no arguments
    hti = HandlerTaskInclude()

    # test with arguments
    hti = HandlerTaskInclude(1, 2, 3)

    # test with kwargs
    hti = HandlerTaskInclude(first='one', second='two', third='three')

# Generated at 2022-06-23 06:20:11.143254
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    
    # Load the handler and check that it has the right attributes
    handler = HandlerTaskInclude.load(
        data = {
            "handlers": [
                {
                    "name": "restart apache",
                    "sudo": True,
                    "service": "apache2",
                    "state": "restarted"
                }
            ]
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert handler.name == 'restart apache'
    assert handler.sudo == True
    assert handler.service == 'apache2'
    assert handler.state == 'restarted'

    # Try with a wrong value for the name attribute

# Generated at 2022-06-23 06:20:13.777533
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = None
    data = dict(
        name='test_handler',
        listen='test_handler'
    )
    handler = HandlerTaskInclude.load(data=data)
    assert handler is not None

# Generated at 2022-06-23 06:20:20.154476
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host= Host(name='localhost')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    handler = HandlerTaskInclude()
    handler.set_loader(DataLoader())
    play_context = PlayContext()
    play_context.prompt = VariableManager()
    handler.variable_manager = VariableManager()
    handler.variable_manager.extra_vars = play_context.prompt
    handler.variable_manager.options_vars = play_context.prompt
    handler.variable_manager.hostvars = dict(host=host)
    handler.variable_manager._fact_cache = dict(host=host)
    handler.task = Task()
    handler.task._role = Role()
    handler.task._role.get_default_vars = dict()
    handler.task

# Generated at 2022-06-23 06:20:32.162956
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
        Since the method load is static, we need to instance the class
        and call the method from it to be able to use the variable 'self'
        (if not, an error occurs )
    '''

    hti = HandlerTaskInclude()

    data = {
        'listen': 'my_listen',
        'name': 'A task',
        'tags': ['my_tag1']
    }

    # This option is mandatory, otherwise a error occurs
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = hti.load(data, block, role, task_include, variable_manager, loader)
    assert handler.listen == 'my_listen'
    assert handler.name == 'A task'

# Generated at 2022-06-23 06:20:39.598283
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    myblock = Block()
    myblock.vars = {'h':'1'}
    myblock.vars = {'k':'2'}
    myblock.vars = {'l':'3'}
    myblock.vars = {'m':'4'}
    myblock.vars = {'c':'5'}
    myblock.vars = {'e':'6'}
    myTask = Task()
    myTask.vars = {'a':'11'}

# Generated at 2022-06-23 06:20:47.789220
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import sys

    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '../../../..'))
    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '../..'))

    # for util methods
    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '../../../../lib/'))

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_v

# Generated at 2022-06-23 06:20:55.045274
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'name': 'boo', 'include': 'boo.yml'}
    task_include = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert isinstance(task_include, HandlerTaskInclude)
    assert task_include._role == None
    assert task_include._block == None
    assert task_include._task_include == None

# Generated at 2022-06-23 06:20:58.009306
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
    #FIXME handler = HandlerTaskInclude()
    #FIXME assert handler is HandlerTaskInclude
    #FIXME assert isinstance(handler, TaskInclude)

# Generated at 2022-06-23 06:21:06.482618
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude(block="main", role="", task_include="") != None
    assert HandlerTaskInclude(block="main", role="", task_include="") != "String"
    assert HandlerTaskInclude(block="main", role="", task_include="") != 42
    assert HandlerTaskInclude(block="main", role="", task_include="") != []
    assert HandlerTaskInclude(block="main", role="", task_include="") != {}
    assert HandlerTaskInclude(block="main", role="", task_include="") != ()
    assert HandlerTaskInclude(block="main", role="", task_include="") != range(3)
    assert str(HandlerTaskInclude(block="main", role="", task_include="")).startswith("<HandlerTask")

# Generated at 2022-06-23 06:21:08.828262
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(data=dict(name="test", listen="test"))

# Generated at 2022-06-23 06:21:19.656971
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    import ansible.utils.collection_loader as collection_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.compat import string_types

    variable_manager = VariableManager()
    variable_manager.set_inventory(HostVars())
    loader = DataLoader()



# Generated at 2022-06-23 06:21:28.579540
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task

    # create a job and load some data
    t = HandlerTaskInclude(block=None, role=None, task_include=None)

    # create the variable manager which will be shared throughout
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=DataLoader()))

    inventory_manager = variable_manager.get_inventory()
    inventory_manager.add_group('test_group')
    inventory_manager.add_host(Host(name="test_host", groups=['test_group']))
    inventory_manager.add_host

# Generated at 2022-06-23 06:21:29.476419
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO:
    pass


# Generated at 2022-06-23 06:21:39.650439
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.module_utils._text import to_bytes
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    # Create data, block, role, task_include and variable_manager
    data = {'listen': 'highstate_default'}
    host1 = Host(name='host1')
    host2 = Host(name='host2')
    hostvars1 = HostVars(host=host1, variables={})

# Generated at 2022-06-23 06:21:43.277994
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Empty task information
    data = {}

    # Instantiate object Handler and return object handler
    h = HandlerTaskInclude.load(data)

    # Return validation of object handler
    assert isinstance(h, HandlerTaskInclude)

# Generated at 2022-06-23 06:21:47.251943
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
   # Test no args
   assert HandlerTaskInclude.load(data=None) is not None

   assert HandlerTaskInclude.load(data=({
        'tags': ['foo', 'bar', 'baz'],
        'name': 'test task',
        'action': 'shell echo hello',
        'when': 'False',
        'test': 'False'
   })) is not None

# Generated at 2022-06-23 06:21:52.025696
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    pass

# Generated at 2022-06-23 06:21:58.603988
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test method with non-empty include_tasks field
    assert (HandlerTaskInclude.load({'include_tasks': 'tasks/main.yml'})
           is None)
    # Test method with empty include_tasks field
    assert HandlerTaskInclude.load({'include_tasks': ''}) is None
    # Test method with non-existent include_tasks field
    assert HandlerTaskInclude.load({'include': 'tasks/main.yml'}) is None


# Generated at 2022-06-23 06:22:05.178063
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # HandlerTaskInclude(block=None, role=None, task_include=None)
    # Test with all args
    handlerTaskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)

    # Test with all args = None
    handlerTaskInclude = HandlerTaskInclude()

    # Test with no args
    handlerTaskInclude = HandlerTaskInclude()

# Generated at 2022-06-23 06:22:13.632787
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class Host(object):
        def __init__(self, name):
            self.name = name
            self.vars = dict()
            self.get_vars = self.get_local_variables
        def get_local_variables(self):
            return self.vars

    my_host = Host("test")
    # my_host.vars = dict([("a", "b"), ("c", "d")])

    my_host_group = dict()
    my_

# Generated at 2022-06-23 06:22:21.277935
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test function load of class HandlerTaskInclude
    """

    # Init
    my_var = dict(
        debug=dict(
            msg="{{ ansible_env.HOME }} is not empty"
        )
    )

    # Test
    my_handler = HandlerTaskInclude.load(
        dict(debug=my_var),
        variable_manager=None,
        loader=None
    )

    # Assert
    assert my_handler is not None



# Generated at 2022-06-23 06:22:24.299244
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert isinstance(task, HandlerTaskInclude)


# Generated at 2022-06-23 06:22:25.796552
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert isinstance(HandlerTaskInclude(), HandlerTaskInclude)

# Generated at 2022-06-23 06:22:32.562757
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars.manager import VariableManager

    data = dict(
        name="a task name",
        notify=["handler1"],
    )

    v = VariableManager()

    HandlerTaskInclude.load(data, variable_manager=v)
    if (data['name'] != "a task name" or
        data['notify'] != ["handler1"]):
        print("TaskInclude.load method behavior is not correct")
        return False

    return True

# Generated at 2022-06-23 06:22:34.032982
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude.load(data={'include_tasks': 'tasks.yml'}, role=None)

# Generated at 2022-06-23 06:22:38.913420
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    variable_manager = ansible.vars.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    handler = HandlerTaskInclude.load(
        dict(
            include = dict(
                file = 'dummy_task.yml'
            )
        ),
        variable_manager=variable_manager,
        loader=loader
    )
    assert handler.get_include_params() == dict(file='dummy_task.yml')

# Generated at 2022-06-23 06:22:39.535213
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:22:41.134003
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None

# Generated at 2022-06-23 06:22:43.767667
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load({'name': 'test_name'})

# Generated at 2022-06-23 06:22:49.112921
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    variables = {'a': 1}
    loader = DictDataLoader({'handler_common.yml': dict(a=1)})

    h = HandlerTaskInclude.load('include: handler_common.yml', variable_manager=variables, loader=loader)

    assert h.data == dict(a=1)
    assert h.get_name() == "<dynamic>include: handler_common.yml"

# ---

# Generated at 2022-06-23 06:22:55.176069
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

    assert handler_task_include is not None

# Generated at 2022-06-23 06:22:58.966527
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Constructor with all arguments
    handlerTaskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handlerTaskInclude is not None

# Generated at 2022-06-23 06:23:08.236948
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=None)
    loader = False
    a_handler = Handler(name='a_handler')
    a_role = Role(loader, None, "test", None, None, None)
    task_include = TaskInclude('a_name', loader, None)
    a_task = Task(loader, None, None, None)
    task_include.parent = a_task
    #a_task

# Generated at 2022-06-23 06:23:11.022915
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # data = {'name': 'test'}
    handler = HandlerTaskInclude()

# Generated at 2022-06-23 06:23:17.792478
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Dummy HandlerTaskInclude class needed for instantiation
    class __TaskInclude:
        def __init__(self):
            self.task = None
            self.block = None
            self.role = None

        def load_data(self, data, variable_manager=None, loader=None):
            return data

    include = __TaskInclude()
    handler = HandlerTaskInclude(block=None, role=None, task_include=include)
    assert handler is not None

# Generated at 2022-06-23 06:23:24.406336
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task1 = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert task1.action == 'include'
    assert task1.block == None
    assert task1.delegate_to == None
    assert task1.delegate_facts == None
    assert task1.role == None
    assert task1.task_include == None
    assert task1.tags == None
    assert task1.when == None
    assert task1._pre_tasks == []
    assert task1._post_tasks == []

    task1 = HandlerTaskInclude(block=None, role=None, task_include=None, other_opt=None)
    assert task1.action == 'include'
    assert task1.block == None
    assert task1.delegate_to == None
    assert task1.delegate

# Generated at 2022-06-23 06:23:26.136206
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj != None


# Generated at 2022-06-23 06:23:26.972259
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:23:35.942932
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': 'handler.yml',
        'listen': 'test_listen'
    }

    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = t.check_options(
        t.load_data(data, variable_manager=None, loader=None),
        data
    )
    assert handler.get_path() == 'handler.yml'
    assert handler.get_handler_name() == 'test_listen'

    data = {
        'include': 'handler.yml'
    }

    t = HandlerTaskInclude(block=None, role=None, task_include=None)