

# Generated at 2022-06-23 06:13:34.253754
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    event = {"dummy_event": {}}
    handler = HandlerTaskInclude(handler=event)
    assert handler.handler == event

# Generated at 2022-06-23 06:13:44.472032
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # load data from yml file
    data = {"name": "test_template",
            "template": "src=test.j2 dest=/etc/file.txt owner=root"}
    # construct instance object of class HandlerTaskInclude
    handler = HandlerTaskInclude(data)
    # assert handler.original_attrs['name'] == handler.name
    # assert handler.original_attrs['template'] == handler.name
    assert handler.args['template'] == data['template']
    assert handler.args['name'] == data['name']
    assert handler.name == 'test_template'
    assert handler.type == 'template'
    assert handler.task_include.type == 'action'
    assert handler.task_include.name == 'template'
    assert handler.task_include.args == handler.args



# Generated at 2022-06-23 06:13:46.497431
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()


# Generated at 2022-06-23 06:13:54.372179
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """Unit test for method load of class HandlerTaskInclude."""
    import ansible.playbook.block
    import ansible.playbook.task_include

    # Create a HandlerTaskInclude object
    handler_task_include = HandlerTaskInclude(block=ansible.playbook.block.Block(), role=None, task_include=ansible.playbook.task_include.TaskInclude())

    # Set a fake "data" variable
    data = {
        'name': 'MyHandler',
        'listen': 'MyNotify'
    }

    # Call the load method of the HandlerTaskInclude object
    handler = handler_task_include.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # Check if the name of the handler is set correctly
   

# Generated at 2022-06-23 06:13:55.890566
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude.load({
        'include': 'main.yml',
        'listen': 'db',
    })
    assert handler

# Generated at 2022-06-23 06:14:07.072880
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class Fake_Block:
        name='block_1'
    class Fake_Role:
        name='role_1'
    class Fake_TaskInclude:
        name='task_include_1'
    class Fake_VariableManager:
        name='variable_manager_1'
    class Fake_Loader:
        name='loader_1'
    data = {
        'action': 'A1',
        'local_action': 'LA1',
        'args': {
            'ARG1': 'arg1',
            'ARG2': 'arg2'
        }
    }
    handler = HandlerTaskInclude.load(data, block=Fake_Block, role=Fake_Role, task_include=Fake_TaskInclude, variable_manager=Fake_VariableManager, loader=Fake_Loader)

# Generated at 2022-06-23 06:14:17.766648
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    # define a host
    host = "somehost"

    hosts = [host]

    # define a play

# Generated at 2022-06-23 06:14:29.474649
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # return class HandlerTaskInclude
    # Initialize the class
    ansible_instance = HandlerTaskInclude()

    # Get the variable_manager
    variable_manager = variable_manager_instance.variable_manager
    # temporary variable_manager
    variable_manager._options = {'host_specific_vars': '1'}

    # dummy data for load method of class HandlerTaskInclude
    data = {
        'task_include': 'main.yml', 'listen': 'extra'
    }

    # call the method
    instance = HandlerTaskInclude.load(data, variable_manager=variable_manager)
    assert instance.task_include == 'main.yml'
    assert instance.listen == 'extra'
    assert instance._role == None

    # dummy data for load method of class HandlerTaskInclude

# Generated at 2022-06-23 06:14:36.983903
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    # create a simple task for test
    handler1 = {
        'name': 'test_HandlerTaskInclude',
        'listen':'test'
    }

    # try to create a HandlerTaskInclude
    handler = HandlerTaskInclude.load(handler1, variable_manager=variable_manager, loader=loader)
    # check handler is not none
    assert(handler is not None)

# Generated at 2022-06-23 06:14:43.895833
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    block = 'tasks'
    role = 'testrole'
    task_include = TaskInclude(block=block, role=role, task_include=None)

    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    assert block == t.block
    assert role == t.role
    assert task_include == t.task_include

# Generated at 2022-06-23 06:14:47.166194
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

if __name__ == '__main__':
    # test_HandlerTaskInclude()
    # nose.runmodule()
    import logging
    logging.basicConfig(level=logging.DEBUG)
    task = {
        'include': 'some_name',
        'listen': 'somename',
        'tags': ['tag1', 'tag2']
    }
    handler = HandlerTaskInclude.load(task)
    assert handler is not None

# Generated at 2022-06-23 06:14:47.831717
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:14:48.523351
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-23 06:14:51.081053
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude) == True

test_HandlerTaskInclude()

# Generated at 2022-06-23 06:14:54.436667
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t.__class__.__name__ == 'HandlerTaskInclude'


# Generated at 2022-06-23 06:15:04.564745
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager

    def _create_host(name):
        host = Host(name=name)
        variable_manager.set_host_variable(host, 'ansible_ssh_pass', 'pass')
        return host

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
   

# Generated at 2022-06-23 06:15:13.163681
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import task_include

    variable_manager = "variable_manager"
    loader = "loader"
    block = "block"
    role = "role"
    task_include1 = "task_include"
    data = ['file', 'action']
    handler1 = HandlerTaskInclude(block, role, task_include1)
    handler2 = handler1.load(data, block, role, task_include1, variable_manager, loader)
    assert handler2.block == block
    assert handler2.role == role
    assert handler2.task_include == task_include1

# Generated at 2022-06-23 06:15:20.861985
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def test_load_data(data, variable_manager=None, loader=None):
        return None

    def test_check_options(options, data):
        return None

    handler_task_include = HandlerTaskInclude()
    handler_task_include.load_data = test_load_data
    handler_task_include.check_options = test_check_options
    result = handler_task_include.load(None)
    print(result)

    return

# Generated at 2022-06-23 06:15:21.691478
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:15:27.197776
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # 'listen' :   ['<notification-name>'],
    data = {
        "listen": "ArpNotifications",
        "handler_name": "Test_HandlerTaskInclude",
    }

    obj = HandlerTaskInclude.load(data)
    assert obj

# Generated at 2022-06-23 06:15:33.641391
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    data = {
        "name": "handler test"
    }
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    handler = HandlerTaskInclude.load(
        data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader)
    assert handler.name == "handler test"

# Generated at 2022-06-23 06:15:34.400341
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:15:46.092290
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  
  # test set up
  block=None
  role=None
  task_include=None
  data = {"asdfasdf" :"sdfsfsd"}

  # execute
  t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
  handler = t.check_options(
            t.load_data(data, variable_manager=variable_manager, loader=loader),
            data
        )
  # assert
  assert handler.substitutions is None
  assert handler.module_name == 'asdfasdf'



# Generated at 2022-06-23 06:15:47.801480
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = HandlerTaskInclude()

# Generated at 2022-06-23 06:15:56.744679
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    # Create an AnsibleDict object that mock the 'data' variable
    data = AnsibleMapping()
    data['name'] = 'test'

    variable_manager = VariableManager()

    t = HandlerTaskInclude.load(data, variable_manager=variable_manager)

    # assert the instance is of type HandlerTaskInclude
    assert isinstance(t, HandlerTaskInclude)

    # assert

# Generated at 2022-06-23 06:16:01.675828
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    Host.get_vars = Mock(return_value="foo")
    TaskInclude.validate_vars = Mock(return_value=True)
    TaskInclude.load_data = Mock(return_value="foo")
    assert HandlerTaskInclude.load("foo", block="bar", role="baz", task_include="buzz")

# Generated at 2022-06-23 06:16:05.499308
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    _host = Host('host1')
    task = Task.load({'action':{'module':'setup'}, '_line':'1', '_file':'playbook'}, variable_manager={}, loader={})
    handler = t.load({'include':'playbook','when':'ok'}, variable_manager={}, loader={})
    assert handler._raw_params == {'include':'playbook','when':'ok'}
    assert handler._attributes == {'include': 'playbook', 'when': 'ok'}
    assert handler._hosts == []
    assert handler._included_files == []
    assert handler._line

# Generated at 2022-06-23 06:16:15.028176
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = Host('test')
    assert HandlerTaskInclude(host=host, task=None)
    assert HandlerTaskInclude(host=host, task=None, ignore_errors=True)
    assert HandlerTaskInclude(host=host, task=None, ignore_errors=True, only_if=True)
    assert HandlerTaskInclude(host=host, task=None, only_if=True)
    assert HandlerTaskInclude(host=host, task=None, failed_when=True)
    assert HandlerTaskInclude(host=host, task=None, tags=['tag'])
    assert HandlerTaskInclude(host=host, task=None, when=True)
    assert HandlerTaskInclude(host=host, task=None, until=True)

# Generated at 2022-06-23 06:16:16.851240
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:16:24.165896
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


    variable_manager = VariableManager()
    loader = DataLoader()

    # mocker.patch.object(Handler, 'load')
    # mocker.patch.object(TaskInclude, 'load')
    inventory = InventoryManager(loader=loader, sources=["hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    data = dict(
        name='test',
        hosts='localhost',
        tasks=[
            dict(
                debug=dict(
                    msg='{{salutation}} {{ansible_hostname}}'
                ),
            ),
        ],
    )


# Generated at 2022-06-23 06:16:32.956038
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task = dict()
    block = dict()
    role = dict()
    import os
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    path = './'
    play_context = PlayContext()
    var_manager = VariableManager()
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[os.path.join(os.getcwd(),'tests/inventory')])

    obj = HandlerTaskInclude.load(task, block=block, role=role,
                                  task_include=dict(),
                                  variable_manager=var_manager,
                                  loader=loader)

# Generated at 2022-06-23 06:16:44.225059
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
     from ansible.playbook.block import Block
     from ansible.playbook.role import Role
     from ansible.vars import VariableManager
     from ansible.inventory import Inventory
     from ansible.parsing.dataloader import DataLoader

     block = Block(
         parent_block=None,
         role=Role(name=None, playbooks=[]),
         task_includes=[],
         role_includes=[],
         tasks=[],
         handlers=[],
         vars=[],
         defaults=[],
     )


     handler = HandlerTaskInclude.load(
         data="",
         block=block,
         role=Role(name="Role_TEST", playbooks=[]),
         task_include=None,
         variable_manager=VariableManager(),
         loader=DataLoader()
     )

# Generated at 2022-06-23 06:16:53.839757
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    data = {
        "name": "Nginx",
        "listen": "http",
    }

    handler = HandlerTaskInclude.load(
        data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=None
    )

    assert handler.name == 'Nginx'
    assert handler.listen == 'http'
    assert handler.tags == set()
    assert handler.run_once == False
   

# Generated at 2022-06-23 06:16:56.978785
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler, 'HandlerTaskInclude() failed'

if __name__ == "__main__":
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:17:06.591027
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars import VariableManager
  from ansible.inventory.manager import InventoryManager
  import os

  loader = DataLoader()
  inventory = InventoryManager(loader=loader, sources='localhost,')
  variable_manager = VariableManager(loader=loader, inventory=inventory)

  # Testing a well formed task execution
  handler = HandlerTaskInclude.load(data={'foobar': 'foobar'}, loader=loader, variable_manage=variable_manager)
  assert handler.name == 'foobar'

  # Testing task with no name
  try:
    handler = HandlerTaskInclude.load(data={}, loader=loader, variable_manage=variable_manager)
    assert False
  except Exception as e:
    assert True

  # Testing the limitation on

# Generated at 2022-06-23 06:17:09.213503
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({
        'name': 'myhandler',
        'listen': 'mytest',
    })

# Generated at 2022-06-23 06:17:09.786768
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:17:21.924245
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, host_list="test/test_handler_task_include/inventory.yaml")
    play_context = PlayContext(remote_addr='127.0.0.1', port=22, become_method='sudo', become_user='root')


# Generated at 2022-06-23 06:17:27.756334
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    h.handler_name = 'test-handler'
    h.include_role = []
    h.include_tasks = []
    h.include_playbook = ''
    h.tags = ['handler','included']
    h.loop = ''
    h.register = 'test'
    h.vars = {}
    assert h.handler_name == 'test-handler'
    assert h.tags == ['handler','included']

# Generated at 2022-06-23 06:17:28.574644
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    HandlerTaskInclude('block','role','task_include')

# Generated at 2022-06-23 06:17:38.877551
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:17:49.923216
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create a HandlerTaskInclude object
    handler_task_include = HandlerTaskInclude()

    # Get some Ansible parameters
    (block, role, task_include) = handler_task_include.parameters_for_test()

    # Create a variable manager
    variable_manager = handler_task_include.variable_manager_for_test()

    # Create a loader
    loader = handler_task_include.loader_for_test()

    # Create a data set
    data = dict(
        include=dict(
            tasks=dict(
                name='include.yml',
                options=dict(
                    tags='test0',
                    rescue=['test1', 'test2']
                )
            )
        )
    )

    handler_task_include.parameters_for_test()

    # Test method load
    handler

# Generated at 2022-06-23 06:17:52.843103
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ti = HandlerTaskInclude()
    assert(ti.VALID_INCLUDE_KEYWORDS == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS)

# Generated at 2022-06-23 06:17:54.070158
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
# TODO
# Is it correct?

# Generated at 2022-06-23 06:17:59.809875
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("******************************")
    print("Test method load of class HandlerTaskInclude")
    print("******************************")
    test_data={'handler':{'include': 'test.yml'}}
    handler=HandlerTaskInclude.load(test_data)

# Generated at 2022-06-23 06:18:06.003618
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	# Arrange
	data = '''
- include: file.yml
  static: no
  ignore_errors: yes
  listen:
    - include_task_done
'''

	# Act
	handler = HandlerTaskInclude.load(data)

	# Assert
	assert handler.name == "include_task_done"
	assert handler.block == None
	assert handler.task_include == None

# Generated at 2022-06-23 06:18:09.736346
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude('block', 'role', 'task_include')
    assert handler.__class__ == HandlerTaskInclude


# Generated at 2022-06-23 06:18:20.793761
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    fake_loader = lambda x: x

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=fake_loader, sources="/tmp")
    variable_manager.set_inventory(inventory)

    block = Block()
    role = Role()

    data = {}

    handler = HandlerTaskInclude.load(
        data=data,
        block=block,
        role=role,
        variable_manager=variable_manager,
        loader=fake_loader,
    )

    assert handler._role == role
    assert handler._block == block
    assert len(handler._dep_chain) == 1

# Generated at 2022-06-23 06:18:27.659858
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {}}
    block = Block.load({}, variable_manager=variable_manager, loader=None)
    task = Task.load(dict(action=dict(module='setup'), register='setup_facts'), block=block, role=None)
    handler_task = HandlerTaskInclude(block=None, role=Role(), task_include=task)


# Generated at 2022-06-23 06:18:36.098575
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t is not None
    data = {
        'include': 'str_name',
        'static': 'str_name',
        'files': 'str_name',
        'vars': 'str_name'
    }
    # handler = t.check_options(t.load_data(data, variable_manager=None, loader=None), data)
    t.load_data(data, variable_manager=None, loader=None)
    print(t.get_include())

#Unit test for method check_include_keywords

# Generated at 2022-06-23 06:18:37.247274
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:18:46.223770
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """ Unit test for method load of class HandlerTaskInclude

        :param data: argument to load
        :param block: argument to pass to the load method
        :param role:  argument to pass to the load method
        :param task_include:  argument to pass to the load method
        :param variable_manager:  argument to pass to the load method
        :param loader:  argument to pass to the load method
        :return: handler
    """
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    data = {'block':None, 'role':None, 'task_include':TaskInclude, 'variable_manager':None, 'loader':None}

# Generated at 2022-06-23 06:18:58.190544
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()

    inv_host = Host(name="localhost")
    inv_host.set_variable('ansible_connection', 'local')
    inv_host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    inv_host.set_variable('ansible_python_version', '2.6')
    inv_group = Group(name="ungrouped")

# Generated at 2022-06-23 06:19:01.622233
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = '''
    - include: "{{ item }}.yml"
      with_items:
        - foo
        - bar
    '''
    handler_task_include = HandlerTaskInclude.load(data)
    assert type(handler_task_include) is HandlerTaskInclude

# Generated at 2022-06-23 06:19:11.974751
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create objects for include
    data = dict()
    data['include'] = dict()
    data['include']['tasks'] = [{'version': 'v1', 'os': 'ubuntu'}]
    block = dict()
    role = dict()
    task_include = dict()
    variable_manager = dict()
    loader = dict()

    # Check if the method load returns a HandlerTaskInclude
    handlerTaskInclude = HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert isinstance(handlerTaskInclude, HandlerTaskInclude)

    # Test argument data
    data = dict()

# Generated at 2022-06-23 06:19:12.509166
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:24.055181
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include='test',
        tags=['test_tag'],
        when='test_when'
    )
    # TODO: create instances of parametrized classes
    # block = Block()
    # role = Role()
    # task_include = TaskInclude()
    # variable_manager = VariableManager()
    # loader = DataLoader()

    handler = HandlerTaskInclude.load(data)
    assert handler.handler_block.module_name is None
    assert handler.handler_block.module_args is None
    assert handler.handler_block.delegate_to is None
    assert handler.handler_block.first_available_file is None
    assert handler.handler_block.first_available_file is None
    assert handler.handler_block.environment is None
    assert handler.handler_block.loop

# Generated at 2022-06-23 06:19:28.118011
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # data for HandlerTaskInclude.load
    data = {}
    block = {}
    role = []
    task_include = {}
    variable_manager = {}
    loader = {}

    # create instance of HandlerTaskInclude
    obj = HandlerTaskInclude()
    # execute method load and validate result
    assert(obj.load(data, block, role, task_include, variable_manager, loader) == None)

# Generated at 2022-06-23 06:19:30.305004
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:19:33.932094
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    block = None
    role = None
    task_include = None
    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    assert isinstance(t, HandlerTaskInclude)

# Generated at 2022-06-23 06:19:34.645527
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:39.546651
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    taskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)
    data = {'include': 'abc.yml', 'vars':{'abc':'hello'}, 'tags':'tag1'}
    taskInclude.load_data(data)

# Generated at 2022-06-23 06:19:52.537156
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_data = dict(
        # load_data: task only uses it to check that include has a name
        name = "test_HandlerTaskInclude_load handler",
        tags = [],
        when = "always",
        import_role = dict(),
        import_tasks = dict(),
        action = None,
        listen = [],
        connection = [],
        notify = [],
        register = [],
        meta = [],
    )
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(handler_data, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    # assert handler.name == "test_HandlerTaskInclude_load handler"

# Generated at 2022-06-23 06:19:55.300449
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.block
    import ansible.playbook.task
    # TODO
    pass

# Generated at 2022-06-23 06:19:57.818071
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(data="", block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:20:04.521692
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    host = Host(name='localhost')
    task = Task()
    task._role = None
    task_vars = dict()
    task_vars['ansible_connection'] = 'local'
    task_vars['groups'] = dict(ungrouped=['localhost'])
    variable_manager = VariableManager()
    variable_manager.set_inventory(host)
    variable_manager.set_host_variable(host, 'ansible_connection', 'local')
    variable_manager.set_host_variable(host, 'ansible_python_interpreter', '/usr/bin/python')

# Generated at 2022-06-23 06:20:14.993633
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    variable_manager = None
    loader = None

    data1 = dict()
    data1.update({'name': 'test_handler'})
    data1.update({'include': '/root/test_include.yml'})
    data1.update({'listen': 'test_listen'})

    handler = HandlerTaskInclude.load(data = data1, variable_manager = variable_manager, loader = loader)
    assert handler.name == data1.get('name')
    assert handler.include == data1.get('include')
    assert handler.loop == data1.get('loop')
    assert handler.loop_with == data1.get('loop_with')
    assert handler.tags == data1.get('tags')
    assert handler.when == data1.get('when')

# Generated at 2022-06-23 06:20:23.933302
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar
    host = Host(name='127.0.0.1')
    task = Task()
    task_include = TaskInclude()
    variable_manager = VariableManager()
    loader = True
    data = 'test'

# Generated at 2022-06-23 06:20:35.157840
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.utils.vars as ans_vars
    import ansible.inventory.manager as ans_inv_mgr
    import ansible.plugins.loader as ans_loader
    import constants
    from collections import namedtuple

    host = Host(name='some_host')

    # Task

# Generated at 2022-06-23 06:20:36.379208
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load()
    assert handler

# Generated at 2022-06-23 06:20:39.772510
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test construction of an object HandlerTaskInclude
    h = HandlerTaskInclude()
    assert h.block is None
    assert h.role is None
    assert h.task_include is None


# Generated at 2022-06-23 06:20:47.856663
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.inventory.manager import InventoryManager
    
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    
    from test_common import (
        mock_class,
        mock_instance,
    )
    import mock
    import six


# Generated at 2022-06-23 06:20:59.640568
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.plays import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.loader.loader import DataLoader
    from ansible.plugins import module_loader
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.group import Group
    from ansible.template import Templar

    dataloader = DataLoader()

# Generated at 2022-06-23 06:21:03.230897
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = AnsibleHandler()
    handler.add_tasks(
        AnsibleTaskInclude(file_name="../tasks/main.yml", tasks=["tasks/main.yml"])
    )
    assert len(handler._tasks) == 1

# Generated at 2022-06-23 06:21:05.401268
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None, "HandlerTaskInclude() constructor failed"

# Generated at 2022-06-23 06:21:06.302500
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    x = HandlerTaskInclude()
    assert x is not None



# Generated at 2022-06-23 06:21:10.954700
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    # Scenario
    # 1. Create object Block
    # 2. Create object Host
    # 3. Create object VariableManager
    # 4. Create object DataLoader
    # 5. Create object HandlerTaskInclude
    # 6. Call method load()
    loader = DataLoader()
    inventory = Host("127.0.0.1", vars={})
    inventory.vars["location"] = "datacenter1"
    inventory.vars["role"] = "app"
    inventory.vars["env"] = "prod"
    inventory.vars["instance"] = "1"
    # inventory.vars = dict

# Generated at 2022-06-23 06:21:20.402595
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:21:20.820454
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
# TODO

# Generated at 2022-06-23 06:21:29.306241
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook import HandlerTaskInclude
    from ansible.inventory import Host, Group

    variable_manager = mock_ansible_instance(VariableManager)
    loader = mock_ansible_instance(Loader)

    h = HandlerTaskInclude.load({
        'name': "example",
        'listen': 'test'
    }, variable_manager=variable_manager, loader=loader)

    assert h._load_name() == 'example'
    assert h.tags is None
    assert h.when is None
    assert h.notify is None
    assert h.listen == 'test'
    assert h.hosts is None
    assert h.roles is None
    assert h.tasks is None
    assert h.always is None
    assert h.changed_when is None
    assert h.failed_when is None

# Generated at 2022-06-23 06:21:38.734680
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Define the variables
    block=None
    role=None
    task_include=None
    data = {'include': 'hello.yaml'}
    loader=None
    variable_manager=None
    handler = HandlerTaskInclude.load(
        data=data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader
    )
    # Test that the expected class was built
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:21:47.273472
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Unit test for method has_triggers
    class Mock(object):
        pass

    obj = HandlerTaskInclude()

    mock_vars = Mock()
    mock_vars.hostvars = {'group1': {}}
    mock_vars.extra_vars = {}

    obj.variable_manager = mock_vars
    obj.triggered_by = ['all']
    assert obj.has_triggers()

    obj.triggered_by = ['group1']
    assert obj.has_triggers()

    obj.triggered_by = ['test']
    assert not obj.has_triggers()

# Generated at 2022-06-23 06:21:58.792534
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    host = Host(name="inventory_hostname")
    group = Group(name="groupname")
    group.add_host(host)
    task = Task()
    task.set_loader(None)
    task.role = Role()
    block = Block(parent_block=task)
    block.vars = {}

    task_include = TaskInclude()
    task_include.vars = {}
    task_include.role = Role()


# Generated at 2022-06-23 06:22:10.171839
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    # NOTE: This test file is currently not being run by Travis. This is because
    # in order to run it, the file `test_utils.py` would need to be modified to
    # allow running this file by itself. However, I do not want to make that change
    # because then it will cause the test to be run twice, which can waste time.
    # When tests for this file are added, the way tests are run both here and in
    # Travis will need to be reevaluated. (AGS)

    # Setup for test

# Generated at 2022-06-23 06:22:10.963222
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:22:23.297800
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:22:34.406246
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # if not os.path.exists("/tmp/test_handler.yml"):
    #     raise Exception("Could not find /tmp/test_handler.yml")
    # handler = HandlerTaskInclude.load(
    #     data=file("/tmp/test_handler.yml", "r").read(),
    #     variable_manager=VariableManager([], {})
    # )
    # print("===============")
    # print("handler.name=%s" % handler.name)
    # print("handler.tags=%s" % handler.tags)
    pass


# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from ansible.errors import AnsibleParserError
from ansible.inventory.host import Host


# Generated at 2022-06-23 06:22:35.549189
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test = HandlerTaskInclude()
    assert test is not None

# Generated at 2022-06-23 06:22:36.372542
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-23 06:22:38.060947
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert isinstance(hti, Handler)
    assert isinstance(hti, TaskInclude)

# Generated at 2022-06-23 06:22:39.979369
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None

# Generated at 2022-06-23 06:22:40.576950
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:22:44.684555
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    tasks = {}
    task = HandlerTaskInclude(block=tasks, role=None, task_include=None)
    assert task is not None
    assert task.block == tasks

# Generated at 2022-06-23 06:22:48.407341
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Constructor without arguments
    handlerTaskInclude = HandlerTaskInclude()

    # Constructor with arguments
    handlerTaskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)


# Generated at 2022-06-23 06:22:50.652884
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    # check if instance is created
    assert handler_task_include is not None

# Generated at 2022-06-23 06:22:59.525537
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data = {
                    'handlers': [
                        {
                            'name': 'test',
                            'listen': ['test_handler'],
                            'include': 'tasks'
                        }
                    ]
    }
    test_loader = ""
    test_variable_manager = ""
    test_block = ""
    test_role = ""
    test_task_include = ""
    test_HandlerTaskInclude = HandlerTaskInclude.load(data=test_data, loader=test_loader, variable_manager=test_variable_manager, block=test_block, role=test_role, task_include=test_task_include)
    assert test_HandlerTaskInclude.loader         == test_loader
    assert test_HandlerTaskInclude.variable_manager == test_variable_manager
    assert test_HandlerTaskIn

# Generated at 2022-06-23 06:23:06.191404
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    input_data = dict(
        name='task test',
        listen='test_listen'
    )

    handler_task_include = HandlerTaskInclude.load(
        data=input_data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    assert handler_task_include.name == 'task test'
    assert handler_task_include.listen == 'test_listen'

# Generated at 2022-06-23 06:23:09.573314
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include,HandlerTaskInclude)


# Generated at 2022-06-23 06:23:16.094293
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "name"     : "test_name",
        "listen"   : "test_listen",
        "include"  : "test_include",
    }

    handler = HandlerTaskInclude.load(data)
    assert handler.name     == "test_name"
    assert handler.listen   == "test_listen"
    assert handler.include  == "test_include"

# Generated at 2022-06-23 06:23:23.649981
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'task', 'name', 'action', 'local_action', 'loop', 'loop_control', 'delegate_to', 'delegate_facts', 'register', 'ignore_errors', 'first_available_file', 'until', 'retries', 'delay', 'listen'}
    assert HandlerTaskInclude.VALID_INCLUDE_FILTERS == ['when', 'changed_when', 'failed_when']
    assert HandlerTaskInclude.VALID_INCLUDE_ATTRIBUTES == ['tags', 'always_run', 'notify']

# Generated at 2022-06-23 06:23:24.441841
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:23:34.895602
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   h = HandlerTaskInclude()
   assert h.handler_block is None
   assert h.static_handlers is False
   assert h.roles is None
   assert h.load_role_tasks_once is False
   assert h.block is None
   assert h.role is None
   assert h.task_include is None
   assert h.module_name is None
   assert h.loop is None
   assert h.loop_args is None
   assert h.filter is None
   assert h.filter_args is None
   assert h.tags is None
   assert h.skip_tags is None
   assert h.only_tags is None
   assert h.when is None
   assert h.loop_control is None
   assert h.name is None
   assert h.vars is None
   assert h.action == 'include'
