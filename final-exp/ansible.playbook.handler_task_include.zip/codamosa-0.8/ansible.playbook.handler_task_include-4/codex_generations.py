

# Generated at 2022-06-11 09:57:02.353178
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name='unit_test_handler'
    )

    t = HandlerTaskInclude()
    handler = t.load(data, variable_manager=None, loader=None)
    assert handler.__class__.__name__ == 'Handler'

# Generated at 2022-06-11 09:57:13.189063
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.utils.vars import combine_vars

    block = Block()
    task_include = TaskInclude()

    variable_manager = VariableManager()
    loader = DictDataLoader({})

    play_context = PlayContext()
    play_context.setup()


# Generated at 2022-06-11 09:57:22.749003
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.playbook.hosts import Hosts
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    results = dict(skipped=False, failed=False, ok=True)

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    inventory.add_host(Host('127.0.0.1'))
    inventory.add_host(Host('127.0.0.2'))

# Generated at 2022-06-11 09:57:31.992890
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def check(handler, data):
        assert handler.static is False
        assert handler.name is data.get('name')
        assert handler.tags is data.get('tags')
        assert handler.when is data.get('when')
        assert handler.register is data.get('register')
        assert handler.ignore_errors is data.get('ignore_errors')

    data = {
        'name': 'myhandler',
        'tags': [ 'foo', 'bar' ],
        'ignore_errors': True,
    }
    handler = HandlerTaskInclude.load(data)
    check(handler, data)
    handler = HandlerTaskInclude.load(data, block='pre_tasks')
    assert handler.block_name is 'pre_tasks'
    check(handler, data)

# Generated at 2022-06-11 09:57:33.070524
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler



# Generated at 2022-06-11 09:57:42.846382
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='./test/unit/ansible_test_inventory')
    variable_manager.set_inventory(inventory)

    extra_vars = load_extra_vars(loader=loader, options=None)
    variable_manager.set_extra_vars(extra_vars)

    #handler = HandlerTaskInclude.load(data={'name': '', 'listen': 'test1'}, block=None, role=None, task_include=None, variable_manager=variable_manager

# Generated at 2022-06-11 09:57:52.326104
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "include" : "my_playbook.yml",
        "hosts"   : "my_hosts"
    }
    # Test with good data
    obj = HandlerTaskInclude(block=None, role=None, task_include=None)
    obj.VALID_INCLUDE_KEYWORDS = obj.VALID_INCLUDE_KEYWORDS.union(('listen',))
    obj.check_options = lambda x, y: None
    obj.load_data = lambda x, variable_manager=None, loader=None: None
    assert None == obj.load(data=data)
    # Test with bad data
    obj = HandlerTaskInclude(block=None, role=None, task_include=None)
    obj.VALID_INCLUDE_KEYWORDS = obj

# Generated at 2022-06-11 09:58:00.760690
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    inventory = TaskQueueManager(loader=loader, variable_manager=variable_manager,
                                 passwords={})
    play_context = PlayContext(variable_manager=variable_manager, loader=loader)
    block = Block()
    task = Task()
    role = Role()


# Generated at 2022-06-11 09:58:02.152760
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("\nStarting test_HandlerTaskInclude_load")



# Generated at 2022-06-11 09:58:04.582426
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    et = HandlerTaskInclude()
    assert et.VALID_INCLUDE_KEYWORDS == {'freeform', 'listen', 'tasks', 'name', 'vars'}

# Generated at 2022-06-11 09:58:06.696771
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()

# Generated at 2022-06-11 09:58:12.977903
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    # initializing objects
    variable_manager = VariableManager()
    block = Block()
    block._play.hosts = "127.0.0.1"
    task = Task()
    task._role = None
    task_include = TaskInclude()
    task_include._role = None

    # creating a valid input data
    data = {
        "mode": "0777",
        "path": "",
        "owner": "root",
        "group": "root"
    }

    # calling tested method

# Generated at 2022-06-11 09:58:13.747997
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
# End of unit test

# Generated at 2022-06-11 09:58:14.267882
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:58:22.916532
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Block as None
    test_1 = HandlerTaskInclude(block=None)
    assert test_1.block is None
    assert test_1.name == "task"
    assert test_1.role is None
    assert test_1.tags is None
    assert test_1.when is None
    assert test_1.any_errors_fatal is None
    assert test_1.notify is []
    assert test_1.run_once is False
    assert test_1.free_form is False
    assert test_1.action == "meta"
    assert test_1.loop is None
    assert test_1.loop_args is None
    assert test_1.until is None
    assert test_1.retries == 0
    assert test_1.delay is None
    assert test_1.register is None
   

# Generated at 2022-06-11 09:58:26.121491
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Test to load.
    '''
    handler = HandlerTaskInclude.load(
        data={
            'import_playbook': 'test_playbook',
            'name': 'Test handler',
            'listen': 'Test handler'
        }
    )

# Generated at 2022-06-11 09:58:34.901307
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    class MockTask(object):

        def __init__(self, name, args):
            self.name = name
            self.args = args
            self.run_once = False
            self.when = None
            self.notify = []
            self.delegate_to = None
            self.loop = None
            self.loop_args = None
            self.until = None
            self.retries = 3
            self.always_run = False
            self.register = None
            self.changed_when = None
            self.failed_when = None

        def __repr__(self):
            return self.name

        def copy(self):
            raise Exception('copy not implemented')

        def serialize(self):
            raise Exception('serialize not implemented')


# Generated at 2022-06-11 09:58:38.735315
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "name": "test handler",
        "listen": "test listen",
        "include_tasks": "test include_tasks",
    }
    handler = HandlerTaskInclude.load(data=data)
    assert handler.listen == "test listen"
    assert handler.include_tasks == "test include_tasks"

# Generated at 2022-06-11 09:58:39.528501
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    a = HandlerTaskInclude()

# Generated at 2022-06-11 09:58:44.223539
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    expected_handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert handler == expected_handler

# Generated at 2022-06-11 09:58:46.635126
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()


# Generated at 2022-06-11 09:58:52.370193
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # arrange
    data={'include': "fake.yml", 'ignore_errors': False}
    block=None
    role=None
    task_include=None
    variable_manager=None
    loader=None

    # act
    result = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    # assert
    assert result.task is not None
    assert isinstance(result.task,TaskInclude)
    assert result.task.filename == data['include']

# Generated at 2022-06-11 09:59:00.470386
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.default import CallbackModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

    # Prepare the configuration
    # pylint: disable=line-too-

# Generated at 2022-06-11 09:59:01.595326
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t is not None


# Generated at 2022-06-11 09:59:02.112943
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 09:59:09.528212
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.playbook.helpers import load_list_of_tasks

    handler_task_include = HandlerTaskInclude()
    handler = handler_task_include.load(
        {'include': 'four.yml'},
        block=lambda: None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    assert isinstance(handler, Handler)
    assert isinstance(handler, HandlerTaskInclude)

    assert handler._role is None
    assert handler.task_include is None
    assert handler.tags == set()

    assert handler.has_triggered is False
    assert handler.triggered_by_any_host_event is True
    assert handler.triggered_by_host_

# Generated at 2022-06-11 09:59:17.542742
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    #
    host1 = Host(name="host1")
    host2 = Host(name="host2")
    group = Group(name="test")
    group.add_host(host1)

# Generated at 2022-06-11 09:59:20.532465
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("test_HandlerTaskInclude_load")

    # Check load method with data
    # assert equals(expected, HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None))
    assert True # TODO: implement your test here


# Generated at 2022-06-11 09:59:25.191320
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'name' : 'test_host',
        'hosts' : 'test_host',
        'listen' : 'test_host',
        'handler' : 'test_host',
        'include' : 'test_host',
    }
    task = HandlerTaskInclude.load(data)
    print(task.__dict__)
    assert task.listen == 'test_host'
    
 # Unit test for method include of class HandlerTaskInclude

# Generated at 2022-06-11 09:59:28.881751
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    block=Block(play=None)
    task=Task(block=block, role=None)
    include=HandlerTaskInclude(block=block, role=None, task_include=task)
    assert include

# Generated at 2022-06-11 09:59:32.422951
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler


# Generated at 2022-06-11 09:59:34.241821
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handlerTaskInclude is not None

# Generated at 2022-06-11 09:59:35.359434
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    Test HandlerTaskInclude class init()
    """
    HandlerTaskInclude()

# Generated at 2022-06-11 09:59:39.158735
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    role = None
    block = None
    task_include = True
    data = {"key": "value"}
    handler = HandlerTaskInclude.load(data, block, role, task_include)
    
    assert data['key'] == handler._attributes['key']

# Generated at 2022-06-11 09:59:40.474405
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: Define unit tests for method load of class HandlerTaskInclude
    assert True

# Generated at 2022-06-11 09:59:50.849863
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'_raw_params': 'my_handler.yml', '_uses_delegate_to': True, '_uses_become': True, '_role_name': 'test_role', '_task_name': 'first_line'}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler_task_include = HandlerTaskInclude.load(
        data=data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader
    )
    assert handler_task_include.name == 'my_handler.yml'
    assert handler_task_include.block == block
    assert handler_task_include.role == role
    assert handler_

# Generated at 2022-06-11 09:59:59.249641
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'handlers':
            {'test_handler':
                {'listen':'test_listen',
                 'include':'test_include'
                 }
            },
        'listen':
            {'test_listen':
                {'include':'test_include'
                },
            },
        'include':
            {'test_include':
                {'task':
                    {'async':2,
                     'poll':2,
                     'role':'test_role',
                     'include':'test_include'
                    },
                }
            }
    }

    handler = HandlerTaskInclude.load(data)
    assert(handler)

# Generated at 2022-06-11 10:00:07.854714
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import yaml

    variable_manager = VariableManager()
    loader = DataLoader()

    yaml_data = """
---
- hosts:
  - localhost
  tasks:
    - debug:
        msg: test handler
    - name: foo handlers
      meta: flush_handlers
    - debug:
        msg: test tasks
"""

    data = yaml.load(yaml_data)

# Generated at 2022-06-11 10:00:16.511990
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    handler = HandlerTaskInclude.load({'name': 'Foo', 'listen': "all"}, variable_manager=variable_manager, loader=loader, )

    assert isinstance(handler, HandlerTaskInclude)
    assert handler.name == 'handlers'
    assert handler.tasks[0].name == 'Foo'
    assert handler.block.name == 'Foo'
    assert handler.block.tasks[0].name == 'Foo'
    assert handler.block.t

# Generated at 2022-06-11 10:00:22.260094
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    h = Host('localhost')
    handlers = [
        {
            'name': 'localhost',
            'include': 'handlers/firewall_add.yml'
        },
    ]

    handler = HandlerTaskInclude.load(handlers[0], h)
    assert handler._role is None
    assert handler._block is None
    assert handler._parent is None
    assert isinstance(handler._task_include, HandlerTaskInclude)
    assert handler._play is None
    assert handler.static is False

# Generated at 2022-06-11 10:00:31.233101
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    h = Host(name='test_host')
    t = Task()
    b = Block()
    HandlerTaskInclude(block=b, role=h, task_include=t)

# Generated at 2022-06-11 10:00:39.764713
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
      This testcase try to use fake data which come from Developer
      to test method load of class HandlerTaskInclude
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:00:40.704704
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None

# Generated at 2022-06-11 10:00:41.574736
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "Test not implemented"

# Generated at 2022-06-11 10:00:48.876720
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from units.mock.vault_secret import MockVaultSecret
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop


# Generated at 2022-06-11 10:00:55.673894
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    sys.path.append('/home/vagrant/ansible_devenv/library')
    import copy
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    loader = DataLoader()
    hostname = 'host'
    myhost = Host(name=hostname)
    groupname = 'group'
    mygroup

# Generated at 2022-06-11 10:01:02.487909
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleError
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    inventory = Inventory(loader=None, variable_manager=VariableManager(), host_list=[])

    data = dict(
        name = "my handler",
        include = "my include",
        become = False,
    )

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    pc = PlayContext()
    inc_block = Block(block=None, role=None, play_context=pc, task_vars=dict(), role_params=dict())

    task = Task()

    handler = HandlerTaskInclude

# Generated at 2022-06-11 10:01:07.089389
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import pytest
    import ansible.errors
    with pytest.raises(ansible.errors.AnsibleParserError):
        HandlerTaskInclude.load({
            "include": {"notify" : ["handler1"]},
            "notify": ["handler2"]
        })

    with pytest.raises(ansible.errors.AnsibleParserError):
        HandlerTaskInclude.load({
            "include": {"notify" : ["handler1"]},
            "listen": "some_handler"
        })

# Generated at 2022-06-11 10:01:10.711326
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    main = dict(
        name = "task_name",
        listen = "test_listener",
    )
    task = HandlerTaskInclude.load(main)
    assert task.name == "task_name"
    assert task.listen == "test_listener"

# Generated at 2022-06-11 10:01:14.154862
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': 'tasks/main.yml',
        'tags': ['another_tag', 'console_debug']
    }

    handler = HandlerTaskInclude.load(data)
    assert handler.get_name() == 'tasks/main.yml'

# Generated at 2022-06-11 10:01:32.552683
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Unit test for method load of class HandlerTaskInclude.
    '''
    # Invalid parameters ######################################################
    # Data is neither dict nor string
    data = 42
    assert HandlerTaskInclude.load(data) is None

    # Invalid data ############################################################
    # Data is dictionary but contains no string
    data = {
        'first_element': 42,
        'other_element': 'value',
    }
    assert HandlerTaskInclude.load(data) is None

    # Data is not a valid handler name
    data = 'toto'
    assert HandlerTaskInclude.load(data) is None

    # Data is a valid handler name
    data = 'toto'
    Handler.get_handler = lambda name: True
    assert HandlerTaskInclude.load(data) is not None

    #

# Generated at 2022-06-11 10:01:33.181400
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:01:34.074996
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude


# Generated at 2022-06-11 10:01:36.346497
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    this is just a syntax nits check
    """

    data = {}
    hti = HandlerTaskInclude(data, None, None)
    assert hti

# Generated at 2022-06-11 10:01:37.031157
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 10:01:48.169967
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()

    # Make some test hosts
    test_host = Host(name="test_host")

    # Set some variables
    variable_manager.set_host_variable(host=test_host, varname='ansible_user', value='root')

    # Make a test inventory
    test_inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    test_inventory.add_host(host=test_host, group='local')
    variable_manager.set_inventory(test_inventory)

    # Load data

# Generated at 2022-06-11 10:01:51.139809
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "block": None,
        "role": None,
        "task_include": None,
        "variable_manager": None,
        "loader": None,
    }
    a = HandlerTaskInclude.load(data)

# Generated at 2022-06-11 10:01:54.874637
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include='../tasks/main.yml',
        tags='foo',
        ignore_errors='yes'
    )
    handler = HandlerTaskInclude.load(data)
    print(handler.get_vars())
    print(handler.tags)
    print(handler.run_once)
    print(handler.ignore_errors)
    print(handler.action)
    print(handler.loop)


# Generated at 2022-06-11 10:02:03.988526
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    print('Testing HandlerTaskInclude.load...')

    from ansible.playbook.play_context import PlayContext

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.playbook.handler import Handler

    # Create Vars
    inventory_manager = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)
    play_context = PlayContext()

    # Create HandlerTaskInclude instance
    handler_task_include = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None,
    )

    assert handler_

# Generated at 2022-06-11 10:02:12.188718
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    from ansible.plugins.loader import find_plugin
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.callback import CallbackBase

    class CallbackModule(CallbackBase):
        def __init__(self):
            super(CallbackModule, self).__init__()
            self.disabled = True

    callback = CallbackModule()
    options = None
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:02:41.117558
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data = '''
    - debug:
        msg: "hello world"
    '''

    task_include = TaskInclude.load(data)
    block = Block(task_include)

    handler = HandlerTaskInclude.load(data, block)
    assert handler.block is block
    assert handler.task_include is task_include

    role = Role.load({})
    task_include = TaskInclude.load(data)
    block = Block(task_include)

    handler

# Generated at 2022-06-11 10:02:42.207154
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """Handler includes may not be loaded at runtime
    """
    pass

# Generated at 2022-06-11 10:02:49.695639
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.ini import InventoryParser
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    hosts_file = """
    [windows]
    localhost ansible_connection=local
    """

    hosts = InventoryParser(loader=DataLoader(), sources=hosts_file).parse_inventory()
    group = hosts.get_group('windows')
    group._vars = {'ansible_connection':'local'}
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=hosts)

# Generated at 2022-06-11 10:02:55.133995
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = [{'handlers': ['main', 'fail']}, {'handlers': 'main'}]
    block = 'main'
    role = 'main'
    task_include = 'task_include'
    variable_manager = 'variable_manager'
    loader = 'loader'

    handler_task_include = HandlerTaskInclude()
    handler_task_include.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-11 10:03:03.869512
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.task_include import TaskInclude
    #from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    task_handler = {
        u'name': u'Test Handler',
        u'include': u'Some file'
    }
    data = task_handler.copy()

    # Test empty data
    o = Handler.load({}, block=None, role=None, task_include=None)
    assert o == None

    # Test bad type of data
    o = Handler.load(1, block=None, role=None, task_include=None)
    assert o == None

    # Test old way
    data.pop(u'include')

# Generated at 2022-06-11 10:03:15.341325
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    data = {
        'include_tasks': {
            'file': 'test/test_handler_task_include.yaml',
            'name': 'handler'
        }
    }
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    ansible_root = os.path.join(os.environ['HOME'], 'ansible')
    current_folder = os.path.join(ansible_root, 'test/unit/modules/test_handler_task_include')
    file = os.path.join(current_folder, 'test_handler_task_include.yaml')
    handler = HandlerTaskInclude.load(data, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:03:16.768938
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'name', 'listen'}

# Generated at 2022-06-11 10:03:17.291356
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:03:20.705009
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data = {u'static': u'/usr/share/my-data', u'options': {u'listen': u'event1'}, u'hosts': u'host1'}
    handler = HandlerTaskInclude.load(data=test_data)
    assert handler.action == 'include'

# Generated at 2022-06-11 10:03:30.343717
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        _raw = "Hello world",
        name = "Hello_world",
        tasks = "Hello_world.yml",
        when = "shell.rc == 0",
        notify = ["restart httpd"],
        listeners = ["restart mysql"],
        meta = dict()
    )
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    assert handler._raw == data['_raw']
    assert handler.name == data['name']
    assert handler.when == data['when']
    assert handler._notify == data['notify']
    assert handler._listen == data['listeners']

# Generated at 2022-06-11 10:04:10.799252
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-11 10:04:18.248282
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    # Create dummy classes
    v = VariableManager()
    l = DataLoader()
    # Create an instance
    hti = HandlerTaskInclude()
    # Create an handler with a task and a block
    data = {'block': {'name': 'foo'}, 'tasks': [{'name': 'foobar'}]}
    handler = hti.load(data, block=Block(), role=Role(), task_include=Task(), variable_manager=v, loader=l)

# Generated at 2022-06-11 10:04:26.117850
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Prepare

# Generated at 2022-06-11 10:04:26.941640
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # ToDo
    assert 0

# Generated at 2022-06-11 10:04:27.502332
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass



# Generated at 2022-06-11 10:04:34.564705
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.vars.variable import Variable

    loader = DataLoader()

    variable_manager = VariableManager()

# Generated at 2022-06-11 10:04:35.679002
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-11 10:04:38.566585
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'foo': 'bar'}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    assert HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader).data == data

# Generated at 2022-06-11 10:04:48.122474
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import pprint
    from collections import MutableMapping
    data = {
        'include': 'hoge.yml',
        'tasks': 'tasks/main.yml',
        'name': 'hoge'
    }
    handler = HandlerTaskInclude.load(data)
    assert data == handler._task._attributes
    assert 'name' in handler._task._attributes
    assert isinstance(handler._task._attributes['name'], str)
    assert 'include' in handler._task._attributes
    assert isinstance(handler._task._attributes['include'], str)
    assert 'tasks' in handler._task._attributes
    assert isinstance(handler._task._attributes['tasks'], str)
    assert 'include_role' in handler._task._attributes

# Generated at 2022-06-11 10:04:48.628095
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    pass

# Generated at 2022-06-11 10:06:10.376923
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  yaml = {'name': 'test.yml', 'static': 'yes'}

  class Block:
    def __init__(self):
      self.vars = {}
      self.all_children = []

  class Role:
    def __init__(self):
      self.vars = {}

  class TaskInclude:
    def __init__(self):
      self.vars = {}

  handler_task_include = HandlerTaskInclude(block=Block(), role=Role(), task_include=TaskInclude())
  handler = handler_task_include.load(data=yaml)

  assert handler.static == 'yes'


# Generated at 2022-06-11 10:06:16.175684
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'name': 'test handler',
        'include': 'test_handler.yml',
        'listen': ['test_signal']
    }
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(
        data, block, role, task_include, variable_manager, loader
    )

    assert handler.get_name() == 'test handler'
    assert handler.get_path() == 'test_handler.yml'
    assert handler.get_tags() == ['test_signal']

# Generated at 2022-06-11 10:06:20.436734
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class Dummy:
        def get_vars(self):
            return {}
    t = HandlerTaskInclude()
    data = {'name': 'xyz'}
    variable_manager = Dummy()
    handler = t.load(data, variable_manager=variable_manager)
    assert handler.name == 'xyz'

# Generated at 2022-06-11 10:06:26.066673
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    b = Block()
    i = IncludedFile()
    r = Role()
    t = Task()
    v = VariableManager()
    h = HandlerTaskInclude.load(data={}, block=b, role=r, task_include=t, variable_manager=v)


# Generated at 2022-06-11 10:06:26.558182
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 10:06:28.525075
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t is not None
    assert isinstance(t, HandlerTaskInclude)



# Generated at 2022-06-11 10:06:29.258507
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:06:38.739715
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible import utils
    from ansible.playbook import task
    from ansible.playbook.play import Play
    from ansible.playbook import block
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    class MyTaskInclude(TaskInclude):

        def load(self, ds, block=None, role=None, task_include=None, variable_manager=None, loader=None):
            results = []
            for d in ds:
                # FIXME(retr0h): This doesn't return any results
                results.append(Task.load(d, block, role, task_include, variable_manager, loader))
            return results


# Generated at 2022-06-11 10:06:40.510861
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import json
    data = json.dumps({
        "listen" : "test_task"
    })
    HandlerTaskInclude.load(data)

# Generated at 2022-06-11 10:06:43.002515
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'listen': "localhost", 'name': 'My handler'}
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
