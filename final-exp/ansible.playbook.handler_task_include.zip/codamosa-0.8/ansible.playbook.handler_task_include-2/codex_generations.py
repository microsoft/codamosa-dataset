

# Generated at 2022-06-11 09:57:10.037009
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    load_data = {
        "block": None, 
        "role": None, 
        "task_include": None
    }


# Generated at 2022-06-11 09:57:11.327221
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()


# Generated at 2022-06-11 09:57:17.342990
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.base import Base
    d = dict((x,y) for x,y in {'name': '', 'block': [], 'delegate_to': '', 'listen': '', 'run_once': [], 'when': [], 'args': [], 'include': []}.items())
    hti = HandlerTaskInclude(**d)
    assert hti.name == ''
    assert isinstance(hti.block, list)

# Generated at 2022-06-11 09:57:18.608794
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: write test
    pass


# Generated at 2022-06-11 09:57:19.174815
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 09:57:20.912604
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert isinstance(t.VALID_INCLUDE_KEYWORDS,set)

# Generated at 2022-06-11 09:57:25.027511
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a new HandlerTaskInclude object
    handler_task_include = HandlerTaskInclude()
    # Check if the object is an instance of the class HandlerTaskInclude
    assert(isinstance(handler_task_include, HandlerTaskInclude))
    # Check if the function check_options is an instance method of class HandlerTaskInclude
    assert(callable(getattr(handler_task_include, 'check_options', None)))

# Generated at 2022-06-11 09:57:33.612053
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    options = None
    loader = DataLoader()
    variable_manager = VariableManager()

    # instantiate inventory
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager.set_inventory(inventory)
    hosts = inventory.get_hosts()

# Generated at 2022-06-11 09:57:40.455291
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
#     handler = Handler(load({
#         'include': 'foo.yml',
#         'tags': ['a', 'b'],
#         'listen': 'test_listen'
#     }, variable_manager=variable_manager, loader=loader))
#     assert_equal(loader.path_dwim('foo.yml'), handler._task_include.get_name())
#     assert_equal(['a', 'b'], handler.tags)
#     assert_equal('test_listen', handler.listen)

# Generated at 2022-06-11 09:57:49.714829
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    constructor_tasks = []
    yaml_constructor_tasks = []
    yaml_parser_tasks = []
    failed = False

# Generated at 2022-06-11 09:57:59.538975
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    This function is testing method load of class HandlerTaskInclude.

    Loads a task from a data structure,
    and saves a reference in its parent block, if any.
    """

    # Creates an object HandlerTaskInclude with valid parameters
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)

    # Creates an object data
    data = {'action': {'__line__': 1}, 'meta': {}}

    # Creates an object variable_manager
    variable_manager = None

    # Creates an object loader
    loader = None

    # Call method load and return the result
    result = handler.load(data, variable_manager=variable_manager, loader=loader)

    # Compare the result with the expected value

# Generated at 2022-06-11 09:58:07.410933
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Unit test for method HandlerTaskInclude.load()
    """
    hti = HandlerTaskInclude()
    m_load_data = Mock(return_value='load_data')
    m_check_options = Mock(return_value='check_options')
    hti.load_data = m_load_data
    hti.check_options = m_check_options
    result = hti.load('data', variable_manager='variable_manager', loader='loader')
    assert result == 'check_options'
    m_load_data.assert_called_with('data', variable_manager='variable_manager', loader='loader')
    m_check_options.assert_called_with('load_data', 'data')

# Generated at 2022-06-11 09:58:09.279177
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  HandlerTaskInclude.load(data={}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-11 09:58:17.500132
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unified import UnifiedVariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    TaskInclude.VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS.union(('key',))

# Generated at 2022-06-11 09:58:18.689854
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj is not None


# Generated at 2022-06-11 09:58:19.666863
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()


# Generated at 2022-06-11 09:58:20.677927
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude is not None

# Generated at 2022-06-11 09:58:26.559292
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'tasks/mytasks.yml',
        'listen': 'myevent'
    }

    handler = HandlerTaskInclude.load(data)

    assert handler.task_include.task is None
    assert handler.task_include.name == 'tasks/mytasks.yml'
    assert handler.task_include.static is False
    assert handler.task_include.tags is None
    assert handler.task_include.when is None

    assert handler.listen == 'myevent'

# Generated at 2022-06-11 09:58:35.277595
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = "host1"
    handler = 'all'
    task = dict(action=dict(module='shell', args='ls'), register='shell_out')
    block = None
    handler = HandlerTaskInclude(host, handler, task, block)
    assert handler.task == task

    handler_task = dict(action=dict(module='shell', args='ls'), register='shell_out')
    handler = HandlerTaskInclude(block=block, handler=handler_task)
    assert handler.task == handler_task

    handler_task = dict(action=dict(module='shell', args='ls'), register='shell_out')
    handler_task_include = dict(hosts="host1", action=dict(module='shell', args='ls'), register='shell_out')

# Generated at 2022-06-11 09:58:36.757918
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h_task_include = HandlerTaskInclude()
    assert h_task_include is not None