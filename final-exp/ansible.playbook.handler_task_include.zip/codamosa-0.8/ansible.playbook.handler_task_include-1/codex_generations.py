

# Generated at 2022-06-11 09:57:09.447608
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext

    dummy_block = None
    dummy_task_include = None
    dummy_variable_manager = None
    dummy_loader = None
    dummy_data = {
        'name': 'test'
    }

    task = HandlerTaskInclude.load(dummy_data, block=dummy_block, task_include=dummy_task_include, variable_manager=dummy_variable_manager, loader=dummy_loader)

    assert task.name == 'test'
    assert isinstance(task.block, dict)


# a test class for testing unhandled exception

# Generated at 2022-06-11 09:57:10.089553
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False



# Generated at 2022-06-11 09:57:20.399708
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """ HandlerTaskInclude - Test load method """

    # Test normal operation
    hti = HandlerTaskInclude()

    hti.load_data = Mock(return_value={"include": "somefile.yml"})
    hti.check_options = Mock(return_value={"meta": 'some_meta'})
    result = hti.load(data={"include": "somefile.yml"}, block=0)
    assert result == {"include": "somefile.yml", "meta": 'some_meta'}

    hti.load_data = Mock(return_value={})
    hti.check_options = Mock(return_value={})
    result = hti.load(data={"include": "somefile.yml"}, block=0)
    assert result == {}

# Generated at 2022-06-11 09:57:22.372630
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	handler = HandlerTaskInclude()
	assert isinstance(handler, HandlerTaskInclude)
	assert HandlerTaskInclude.__name__ == 'HandlerTaskInclude'


# Generated at 2022-06-11 09:57:27.283676
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Host, Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    h1 = Host(name='host1')
    i1 = Inventory(hosts=[h1])

    v = VariableManager()
    v.add_host_var(host=h1, var=HostVars(vars=HostVarsVars(ansible_port="22")))


# Generated at 2022-06-11 09:57:35.875189
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create a Host
    host = Host('localhost')
    # Create a variable manager
    variable_manager = AnsibleVariableManager()
    loader = AnsibleLoader()
    # Create a task include
    task_include = TaskInclude(host=host, variable_manager=variable_manager, loader=loader)
    # Create a handler task include
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=task_include)

    data = {
        'name': 'task_name',
        'ignore_errors': 'True',
        'action': '/bin/true',
    }
    handler = HandlerTaskInclude.load(data=data, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-11 09:57:43.684698
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Arguments for the constructor of HandlerTaskInclude class
    data = "handler.yml"
    block = "block"
    role = "role"
    task_include = "task_include"
    variable_manager = "variableManager"
    loader = "loader"
    handler = HandlerTaskInclude(block, role, task_include)

    # Test class variable
    print(handler.VALID_INCLUDE_KEYWORDS)

    # Test class method
    handler.load(data, block, role, task_include, variable_manager, loader)


# Test class method load()

# Generated at 2022-06-11 09:57:47.522762
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # assert isinstance(HandlerTaskInclude, Host)
    assert issubclass(HandlerTaskInclude, Handler)
    assert issubclass(HandlerTaskInclude, TaskInclude)

    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))

# Generated at 2022-06-11 09:57:52.174248
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	from ansible.inventory.host import Host
	from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
	obj = AnsibleBaseYAMLObject()
	hti = HandlerTaskInclude(block=obj, role=None, task_include=None)
	assert hti != None


# Generated at 2022-06-11 09:57:53.450340
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
# end of unit test for method load of class HandlerTaskInclude
