

# Generated at 2022-06-11 09:57:10.091605
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()


# Generated at 2022-06-11 09:57:11.829084
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-11 09:57:13.589431
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """Unit test for constuctor of class HandlerTaskInclude."""
    assert HandlerTaskInclude()

# Generated at 2022-06-11 09:57:14.349890
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 09:57:23.513324
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="ping",
        tags=["test", "ping"],
        when="ansible_facts.inventory_hostname == 'was'",
        listen="http_handler",
    )
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    print(handler)
    assert handler['name'] == "ping"
    assert handler['tags'] == ["test", "ping"]
    assert handler['when'] == "ansible_facts.inventory_hostname == 'was'"
    assert handler['listen'] == "http_handler"


# Generated at 2022-06-11 09:57:32.090470
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory_manager)

    data = dict(
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader
    )
    assert HandlerTaskInclude.load(data) == HandlerTaskInclude()


# Generated at 2022-06-11 09:57:33.178404
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    handler.to_bytes()

# Generated at 2022-06-11 09:57:33.683850
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	pass

# Generated at 2022-06-11 09:57:40.045243
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = Handler.load({
        u'listen': u'test_listen',
        u'name': u'test_name',
        u'include': u'test_include',
        u'include_tasks': u'test_include_tasks'
    })
    assert handler.listen == u'test_listen'
    assert handler.name == u'test_name'
    assert handler.include == u'test_include'
    assert handler.include_tasks == u'test_include_tasks'

# Generated at 2022-06-11 09:57:42.583536
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(
        {
            'include': 'test.yml',
            'listen': 'test_listen'
        }
    )

# Generated at 2022-06-11 09:57:48.557110
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_dict = {
        'name': 'test handler',
        'include': 'test.yml',
        'listen': 'test'
    }
    handler = HandlerTaskInclude(**test_dict)
    assert handler.name == test_dict['name']
    assert handler.include == test_dict['include']
    assert handler.listen == test_dict['listen']


# Generated at 2022-06-11 09:57:49.264682
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 09:57:54.671858
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # OPTIONALKEYWORDNAME = {'k': 'v'}
    # handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    # ret = handler.check_options(
    #     handler.load_data(OPTIONALKEYWORDNAME, variable_manager=None, loader=None),
    #     OPTIONALKEYWORDNAME
    # )
    assert True



# Generated at 2022-06-11 09:57:58.323849
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        action=dict(
            module='command',
            args='ls'
        ),
        when='ansible_os_family == "Debian"'
    )

    handler = HandlerTaskInclude.load(
        data,
        variable_manager=None,
        loader=None
    )

    

# Generated at 2022-06-11 09:57:59.310365
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()



# Generated at 2022-06-11 09:58:01.671209
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',)))

# Generated at 2022-06-11 09:58:04.054275
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'tasks', 'when', 'notify', 'files', 'listen'}

# Generated at 2022-06-11 09:58:05.702696
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # handler = HandlerTaskInclude()
    # print(handler)
    pass



# Generated at 2022-06-11 09:58:08.452877
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == 
        set(['tags', 'when', 'name', 'tasks', 'handlers', 'strategy', 'vars', 'defaults', 'register', 'listen']))

# Generated at 2022-06-11 09:58:12.559733
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    module = 'test_module'
    args = 'test_args'
    action = {'key': 'val', 'module': module, 'args': args}
    name = 'test_name'
    tags = ('test_tag_1', 'test_tag_2')
    handler = HandlerTaskInclude(action=action,block=None, name=name, tags=tags)

    assert handler.action == action
    assert handler.block == None
    assert handler.name == name
    assert handler.tags == tags


# Generated at 2022-06-11 09:58:23.738856
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)

    inventory = InventoryManager(loader=DataLoader())
    inventory.add_group(group)

    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    data = dict(
        name="test handler",
        include='tasks/test_include.yml',
        listen='test_handler_task_include',
    )


# Generated at 2022-06-11 09:58:32.842828
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-11 09:58:39.056718
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include1': {'a': 'A', 'b': 'B'}}
    variable_manager = 'variable_manager'
    loader = 'loader'
    expected_result = {'include1': {'a': 'A', 'b': 'B', 'name': 'include1', 'static': False}, 'name': 'include1', 'static': False}  # noqa pylint: disable=line-too-long
    actual_result = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert expected_result == actual_result



# Generated at 2022-06-11 09:58:47.593723
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleParserError

    # TODO: (jtyr) create a test for the case where block, role and task_include are None
    blocks = [Block.load(dict(hosts=['host1']), play=dict(name='PLAY_NAME'))]

# Generated at 2022-06-11 09:58:48.191749
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:58:56.376546
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.attribute import Attribute
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 09:59:03.760517
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    h = HandlerTaskInclude()
    assert h._valid_include_keys == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

    host = Host(name='localhost')
    variables = VariableManager()
    myvars_proxy = UnsafeProxy({'foo': 'bar'})
    variables.set_host_variable(host, "myvars", myvars_proxy)
    h._get_next_id(host, variables)
    assert 'localhost' in h._include_cache
    assert h._include_cache['localhost'] == myvars_proxy
    del h._include_cache['localhost']

# Generated at 2022-06-11 09:59:06.415409
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  data = "{'include': '{{item}}', 'with_items': [1, 2, 3]}"
  handler = HandlerTaskInclude.load(data)
  print(handler)

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-11 09:59:06.869387
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:15.137505
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data           = dict(
        include = "some_task_name"
    )
    block          = None
    role           = None
    task_include   = None
    variable_manager = None
    loader         = None
    handler_task_include   = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    if not isinstance(handler_task_include, HandlerTaskInclude):
        raise AssertionError('handler_task_include should be an instance of HandlerTaskInclude')

    if handler_task_include._name != 'some_task_name':
        raise AssertionError('handler_task_include._name should be some_task_name')


# Generated at 2022-06-11 09:59:22.016761
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Constructor of class HandlerTaskInclude
    hti = HandlerTaskInclude()

    # Check the type of hti
    assert isinstance(hti, HandlerTaskInclude)

# Generated at 2022-06-11 09:59:23.367775
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.included_file
    assert HandlerTaskInclude.load({}) != None

# Generated at 2022-06-11 09:59:31.496549
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("start test_HandlerTaskInclude_load")

    from ansible.playbook.test_helpers import AnsiblePlaybook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host

    ansible_playbook = AnsiblePlaybook()
    AnsiblePlaybook.__print__ = lambda x: print(x.__dict__)

    block = Block()
    role = None
    task_include = TaskInclude()

    # Load the handler task include object with bad data
    block = Block()
    role = None
    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)

# Generated at 2022-06-11 09:59:32.079585
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:37.216924
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#     h = HandlerTaskInclude.load(data='manage_syslog_queue', 
#                                 block=None, 
#                                 role=None, 
#                                 task_include=None, 
#                                 variable_manager=None, 
#                                 loader=None)
#     assert h.__class__.__name__ == 'HandlerTaskInclude'
#     assert h._task.__class__.__name__ == 'TaskInclude'

# Generated at 2022-06-11 09:59:39.920035
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    result = HandlerTaskInclude.load(None)
    assert result is None, "Expected: {}, Actual: {}".format(None, result)



# Generated at 2022-06-11 09:59:50.510986
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import pytest
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext

    # HandlerTaskInclude.load constructs the Handler instance by calling Handler.load
    # The only difference between the two is that HandlerTaskInclude makes a call
    # to HandlerTaskInclude.check_options with the handler and the data parameters.
    # Hence, I will test HandlerTaskInclude.load by testing HandlerTaskInclude.check_options,
    # and skipping over the calls to Handler.load and TaskInclude.load.


# Generated at 2022-06-11 09:59:51.064642
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:00:00.943019
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.vars_plugin import HostVars
    from ansible.inventory.vars_plugin import VarsPlugin
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    playbook = PlaybookExecutor()

    data = {'include': 'foo.yml'}

    host = Host(name='host')
    group = Group(name='group')

    group.add_host(host)


# Generated at 2022-06-11 10:00:05.209706
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_handler_task_include = HandlerTaskInclude
    print("Handler Task Include type: {}".format(type(test_handler_task_include)))
    assert type(test_handler_task_include) == type
    assert issubclass(test_handler_task_include, Handler)
    assert issubclass(test_handler_task_include, TaskInclude)


# Generated at 2022-06-11 10:00:17.755327
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  # Init the HandlerTaskInclude object
  hti = HandlerTaskInclude()
  # Test to see if the type of the object is HandlerTaskInclude
  # Selected the assertIsInstance method to test the type of an object
  assertIsInstance(hti,HandlerTaskInclude)

# Generated at 2022-06-11 10:00:26.200252
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import sys
    import ansible.playbook
    from ansible.playbook.play_context import PlayContext
    import ansible.utils.vars as ansible_vars
    from ansible.parsing.dataloader import DataLoader
    import ansible.vars
    import ansible.inventory

    variableManager2 = ansible.vars.VariableManager()
    loader2 = DataLoader()
    variableManager2._extra_vars = dict()
    variableManager2.set_inventory(ansible.inventory.hosts.Inventory(loader=loader2))
    variableManager2.set_play_context = PlayContext()

    file_name = 'ansible/playbook/tasks/handler_task_include.yml'

# Generated at 2022-06-11 10:00:27.722129
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	print("test_constructor_HandlerTaskInclude")
	default = HandlerTaskInclude()
	assert default is not None

# Generated at 2022-06-11 10:00:32.354980
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ansible = Ansible()
    ansible.initialize_test()

    assert HandlerTaskInclude(block=None, role=None, task_include=None) is not None
    assert HandlerTaskInclude(block=None, role=None, task_include=None) is not None
    assert HandlerTaskInclude(block=None, role=None, task_include=None) is not None



# Generated at 2022-06-11 10:00:33.815849
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = TaskInclude()
    assert handler.__class__.__name__ == "HandlerTaskInclude"

# Generated at 2022-06-11 10:00:42.220892
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[Host(name="hostname")])
    variable_manager.set_inventory(inventory)

    block = Block()
    role = Role()
    task = Task()


# Generated at 2022-06-11 10:00:49.495498
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Random number for the testing
    import random

    # Create a fake block, role, task_include, variable_manager and a loader
    block = "block"
    role = "role"
    task_include = "task_include"
    variable_manager = "variable_manager"
    loader = "loader"

    # Create an instance of class HandlerTaskInclude
    HandlerTaskInclude_test = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    # Change the value of the variable VALID_INCLUDE_KEYWORDS for testing
    actual = HandlerTaskInclude_test.VALID_INCLUDE_KEYWORDS
    new = random.randint(0,1000)
    HandlerTaskInclude_test.VALID_INCLUDE_KEYWORDS = new

    # Create

# Generated at 2022-06-11 10:00:56.236634
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args='')),
            ]
        )


# Generated at 2022-06-11 10:00:56.897303
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass



# Generated at 2022-06-11 10:01:01.521561
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import ansible.playbook
    import ansible.inventory
    # vars = dict()
    # host = ansible.inventory.host()
    # loader = ansible.playbook.BaseLoader()

    # assert HandlerTaskInclude.load(
    #     dict(include='/path/to/file'),
    #     variable_manager=vars,
    #     loader=loader
    # ) is not None
    assert HandlerTaskInclude.load({'include': 'my_role'}) is not None

# Generated at 2022-06-11 10:01:21.996785
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:01:31.245195
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import sys
    import test_utils as utils
    try:
        from ansible.playbook.task import Task
        from ansible.playbook.block import Block
        from ansible.playbook.role import Role
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
    except:
        print("failed=True msg='ansible is required for this unit test'")
        sys.exit(1)
    varm = VariableManager()
    host_list = utils.TestData.hosts
    group_list = utils.TestData.groups
    inventory = InventoryManager(loader=None, sources=host_list+group_list)
    task_list = utils.TestData.tasks

# Generated at 2022-06-11 10:01:32.513829
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h


# Generated at 2022-06-11 10:01:35.981552
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'name': 'test'}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    assert HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader) is not None

# Generated at 2022-06-11 10:01:36.660623
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

# Generated at 2022-06-11 10:01:40.983062
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    t = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    # assert that t is not null
    assert (t is not None)

# Generated at 2022-06-11 10:01:51.263588
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.block import Block

    from ansible.playbook.role import Role

    from ansible.playbook.task import Task

    from ansible.vars import VariableManager

    from ansible.parsing.dataloader import DataLoader

    block = Block()
    task = Task()
    role = Role()
    variable_manager = VariableManager()
    loader = DataLoader()

    task_include = TaskInclude()
    task_include.load(dict(name="hello"))

    data = dict(name="hello")
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    assert type(handler.task_include) == TaskInclude

# Generated at 2022-06-11 10:01:54.287239
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-11 10:02:02.441091
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create the original task include object
    original_task_include = TaskInclude.load({'include': "play-tasks.yml"}, loader=None)

    # Create a new handler object
    handler = HandlerTaskInclude(block=None, role=None, task_include=original_task_include)

    # Create the new task include object
    new_task_include = handler.check_options(
        handler.load_data({'include': "play-tasks.yml"}, loader=None),
        {'include': "play-tasks.yml"}
    )

    # Check the instance of the new task include object
    assert isinstance(new_task_include, HandlerTaskInclude)

# Generated at 2022-06-11 10:02:10.696498
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    variables = {}
    uut = HandlerTaskInclude()
    target = ['name']
    
    assert uut.listen == None
    assert uut.block == None
    assert uut.role == None
    assert uut.task_include == None
    assert uut.notify == target
    assert uut.name == 'Notifiation added'
    assert uut.when == 'always'
    assert uut.run_once == False
    assert uut.tags == ['always']
    assert uut.only_if == ''
    assert uut.loop == ''
    assert uut.environment == {}
    assert uut.loop_args == None
    assert uut.register == None
    assert uut.ignore_errors == False
    assert uut.until == ''

# Generated at 2022-06-11 10:02:53.334064
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:02:56.972070
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    variables = None
    data = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    assert HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-11 10:02:58.596707
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Function name must be 'test_*' to be unit test
    pass

# Generated at 2022-06-11 10:02:59.461168
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False


# Generated at 2022-06-11 10:03:00.211245
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 10:03:01.776039
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler

# Generated at 2022-06-11 10:03:09.194548
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    host = Host()
    block = Block()
    task = Task()

    handler = HandlerTaskInclude(host=host, block=block, task=task)
    assert handler._host == host
    assert handler._block == block
    assert handler._task == task
    assert handler._role is None
    assert handler._task_include is None
    assert handler._shared_loader_obj == None


# Load a basic handler task

# Generated at 2022-06-11 10:03:15.979021
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    variable_manager = {}
    loader = {}
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert handler is not None
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.handler_vars is None
    assert handler.static is False
    assert handler._included_file is None
    assert handler._included_path is None
    assert handler.tags is None

# Generated at 2022-06-11 10:03:16.847988
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 10:03:26.502114
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load('play', dict(
        hosts=['client'],
        gather_facts='no',
        tasks=[dict(
            name='task',
            include_tasks='tasks.yaml'
        )],
        handlers=[dict(
            name='handler',
            include_tasks='tasks.yaml'
        )]
    ), variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-11 10:04:56.307075
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    data = {
        'listen': 'notify',
        'handler_name': 'test_HandlerTaskInclude_load',
        'tasks':[
            {
                "fail": {
                    "msg": "Task Failed"
                }
            }
        ]
    }
    hosts = []
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'hostvars': {}
    }
    handler = HandlerTaskInclude.load(
        data=data,
        variable_manager=variable_manager,
    )



# Generated at 2022-06-11 10:05:05.344323
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class Block:
        def __init__(self):
            self.vars = dict()
        def get_vars(self):
            return self.vars
    class Data:
        variable_manager = None
        loader = None
    class VariableManager:
        def __init__(self, L):
            self.L = L
        def get_vars(self, loader=None, play=None, host=None, task=None):
            return self.L
    class Loader:
        pass
    class Options:
        handlers = None
    data = Data()
    data.variable_manager = VariableManager(dict())
    data.loader = Loader()
    data.block = Block()
    data.options = Options()
    data.options.handlers = "not None"


# Generated at 2022-06-11 10:05:11.799089
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode,AnsibleMapping,AnsibleSequence
    from ansible.inventory.host import Host
    from ansible.parsing.utils.addresses import parse_address
    from ansible.vars.manager import VariableManager
    data = {'listen': 'test', 'name': 'test'}
    data = AnsibleMapping(data)
    block = AnsibleMapping({})
    role = None
    task_include = None
    variable_manager = VariableManager()
    loader = None

    handler = HandlerTaskInclude()
    handler= handler.load(data, block, role, task_include, variable_manager, loader)
    validate_fields(handler.listen, ["test"])

# Generated at 2022-06-11 10:05:22.362540
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Constructor test when valid parameters are passed
    data = "test-handler-task-include"
    block = "test-block"
    role = "test-role"
    task_include = "test-task-include"
    handler = HandlerTaskInclude.load(data, block, role, task_include)
    assert handler.block == block
    assert handler.role == role
    assert handler.task_include == task_include
    assert handler.static_vars == dict()
    assert handler.static_vars == dict()
    assert handler.include_failed == False
    assert handler.include_variables.get_vars() == dict()
    assert handler.name == data
    assert handler.notified_by == list()
    assert handler.triggered_by == list()
    assert handler.tags == list()
   

# Generated at 2022-06-11 10:05:27.093288
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    hti = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert hti is not None

# Generated at 2022-06-11 10:05:30.242443
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(dict(name = 'test'), dict(foo = 'bar'))
    assert handler.get_name() == 'test'
    assert handler._load_role() is None
    assert handler._load_tags() == ''
    assert handler.action == 'include'


# Generated at 2022-06-11 10:05:41.917751
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    dl = DataLoader()
    vM = VariableManager()
    iM = InventoryManager(dl, vM)
    # vM.set_inventory(iM)

    # Create an empty inventory
    # iM.add_host(Host('testhost'))
    # print(iM.get_hosts())

    # Create a dictionary to load as data
    data = {'include': 'test_playbooks/HandlerTaskInclude.yml'}

    # Create and load the HandlerTaskInclude
    hTI = HandlerTaskInclude.load(data, loader=dl, variable_manager=vM)
    # print(hTI)

    #

# Generated at 2022-06-11 10:05:47.257729
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.tests import Base

    import ansible.playbook.handler as handler
    from ansible.playbook.tests.unit.test_handler import ModuleMock
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os

    config = Base.mock_config()
    variable_manager = VariableManager()
    loader = DataLoader()
    playbook_path = os.path.join(os.path.dirname(__file__), '..', '.', 'test_playbook.yml')


# Generated at 2022-06-11 10:05:47.795841
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:05:54.529268
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # First we create a fake Host object
    h = Host(name='fake-host')

    # Then we create an InventoryManager and a host's group
    i = InventoryManager(loader=loader)
    g = i.groups.create('fake-group')

    # Then, we add the Host object previously created to the group
    g.add_host(h)

    # We define the variables
    v = VariableManager(loader=loader, inventory=i)

    # We create a dictionary