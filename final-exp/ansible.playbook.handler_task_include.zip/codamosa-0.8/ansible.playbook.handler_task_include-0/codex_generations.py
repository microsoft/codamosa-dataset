

# Generated at 2022-06-11 09:57:08.799182
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        return HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert load(dict(include='a.yml'), block=dict(name='block'))
    assert load(dict(include='a.yml', listen='block'), block=dict(name='block'))
    assert not load(dict(include='a.yml', listen='other_block'), block=dict(name='block'))

# Generated at 2022-06-11 09:57:12.551693
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'name': 'test',
        'tags': ['tag1','tag2','tag3'],
        'when': 'not failed'
    }

    handler = HandlerTaskInclude.load(data)
    assert handler

# Generated at 2022-06-11 09:57:14.402672
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Testing constructor of class HandlerTaskInclude")
    assert True
    
    

# Generated at 2022-06-11 09:57:23.512447
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    fake_block1 = Block('fake_block1')
    fake_block1._parent = fake_block1

    fake_host = Host()
    fake_host.name = 'fake_host'

    fake_task = Task()
    fake_task._role = fake_task
    fake_task

# Generated at 2022-06-11 09:57:24.110020
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:57:24.702718
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    return

# Generated at 2022-06-11 09:57:31.846749
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    class BaseTaskInclude:
        def __init__(self):
            self.name = 'include'
            self.args = []
    data = {
        'include': {
            'tasks': 'tasks.yml'
        }
    }
    class Block:
        pass
    handler = HandlerTaskInclude.load(Block(), data, task_include=BaseTaskInclude())
    assert handler.name == 'tasks.yml'
    assert handler.args == []
    assert handler.tags == []
    assert handler.when == []
    assert handler.only_if == []
    assert handler.not_if == []

# Generated at 2022-06-11 09:57:36.336379
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.play as play
    import ansible.playbook.task as task
    host = play.Play()
    task = task.Task()
    handler = HandlerTaskInclude(block=task, role=task, task_include=task)
    handler.check_options(handler.load_data(data=None, variable_manager=None, loader=None), data=None)
    handler.run()

# Generated at 2022-06-11 09:57:37.154340
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-11 09:57:46.871503
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    t = HandlerTaskInclude()
    h = Host()
    i = Host()
    storedir = '/tmp/ansible-test-host'
    name = 'testhost'
    vars = {}
    groups = []
    port = 22
    remote_user = 'root'
    connection = 'smart'
    inventory = h
    variable_manager = VariableManager()
    loader = DataLoader()
    block = [{'when': {'cond': 'False'}}, {'when': {'cond': 'True'}}]
    role = None
    task_include = None


# Generated at 2022-06-11 09:57:49.576568
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()

    # AnsibleModule
    assert obj


# Generated at 2022-06-11 09:57:58.360593
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    host = Host('testhost')
    group = Group('testgroup')
    host.add_group(group)
    inventory = InventoryManager(loader=DataLoader(), sources=None)
    inventory.add_host(host)
    groups = inventory.groups
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.set_inventory(inventory)
    variable_manager.add_group_vars(host.groups[0], {"testvar1": "value1"})

# Generated at 2022-06-11 09:58:07.337556
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from unittest import TestCase
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.ini import InventoryParser
    from ansible.inventory.yaml import InventoryYAMLParser
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-11 09:58:12.513173
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = "include_role: name={{ role_name }}"
    loader = ""
    variable_manager = ""
    task_include = "include_role"
    role = ""
    block = ""

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert isinstance(handler, HandlerTaskInclude)
    assert hasattr(handler, "action")
    assert hasattr(handler, "task_include")
    assert handler.block == block
    assert handler.role == role
    assert handler.task_include == task_include

# Test VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-11 09:58:13.537948
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    a = HandlerTaskInclude()
    assert(isinstance(a, Handler))

# Generated at 2022-06-11 09:58:22.163772
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)

    block = Block()
    block.roles.append('testRoleName')

    task_include = {
        'name': 'testTaskIncludeName',
        'listen': 'testListen'
    }


# Generated at 2022-06-11 09:58:26.912252
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler1 = HandlerTaskInclude()
    handler2 = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler3 = HandlerTaskInclude(block=None, role=None, task_include=None, play=None)
    handler4 = HandlerTaskInclude(block=None, role=None, task_include=None, play=None, task=None)
    print(handler1, handler2, handler3, handler4)

# Generated at 2022-06-11 09:58:29.783976
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude(block='all', role='test', task_include='test')
    assert isinstance(h, HandlerTaskInclude)
    assert isinstance(h, Handler)
    assert isinstance(h, TaskInclude)


# Generated at 2022-06-11 09:58:38.533056
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Check if error is raised when invalid keywords are used
    try:
        handler = HandlerTaskInclude(listen='all')
        assert False, "HandlerTaskInclude does not raise error when invalid keywords are used."
    except AssertionError as e:
        raise e
    except Exception:
        pass

    # Check if error is raised when only_tags and skip_tags are specified together
    try:
        handler = HandlerTaskInclude(
            include='test.yml',
            only_tags=['first', 'second'],
            skip_tags=['third', 'fourth'],
            tags=['fifth', 'sixth'],
        )
        assert False, "HandlerTaskInclude does not raise error when only_tags and skip_tags are specified together."
    except AssertionError as e:
        raise e

# Generated at 2022-06-11 09:58:46.997800
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.block import BlockInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins import callback_loader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # construct blocks for test
    block = Block([])
    block.name = "TestBlock"
    block.rescue = TaskInclude.load(data=dict(include='tasks/rescue.yml'))
    block.always = TaskInclude.load(data=dict(include='tasks/always.yml'))

    # construct handler

# Generated at 2022-06-11 09:58:57.388376
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import ansible.playbook.play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    def _validate_against_dict(d, obj):
        for k in d:
            assert k in vars(obj), "Key %s not in vars()" % k
            assert obj[k] == d[k], "Key %s values do not match: %s != %s" % (k, obj[k], d[k])

    loader = DataLoader()

# Generated at 2022-06-11 09:58:57.819525
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:05.457515
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources =['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    handler_data = dict()
    handler_data['name'] = 'test'

    handler = HandlerTaskInclude.load(
        data=handler_data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader
    )

    assert isinstance(handler, HandlerTaskInclude)


# Generated at 2022-06-11 09:59:13.776359
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.vault import mock_vault_secrets

    mock_unfrackpath_noop()

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DictDataLoader({}), inventory=inventory)

    data = {'include_tasks': 'name', 'listen': ['task1']}
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=DictDataLoader({}))
   

# Generated at 2022-06-11 09:59:20.825061
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("HandlerTaskInclude_load")

    # initiating variables
    block=None
    role=None
    task_include=None
    
    # set variable data
    data = {"notify": [1, 2, 3]}
    variable_manager=None
    loader=None
    
    # call load
    # handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    # handler = HandlerTaskInclude.load("foo")
    # handler = HandlerTaskInclude.load(data={"foo": "bar"})
    handler = HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    # print handler.
    #

# Generated at 2022-06-11 09:59:29.032996
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play = Play()
    handler = HandlerTaskInclude.load(data={'include': 'shell.yml'}, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-11 09:59:37.035682
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Initialize a HandlerTaskInclude object without any arguments
    task_include = HandlerTaskInclude()

    # Initialize a HandlerTaskInclude object with arguments
    args = dict(
        name="Example",
        tasks=[dict(action=dict(
            module="shell",
            args="echo hello"
        ))]

    )
    task_include2 = HandlerTaskInclude(**args)

    # Check if task_include and task_include2 are instances of the class HandlerTaskInclude
    assert isinstance(task_include, HandlerTaskInclude)
    assert isinstance(task_include2, HandlerTaskInclude)

    # Check if the objects initialized from data have the same properties as the original objects
    assert task_include2.name == "Example"
    assert len(task_include2.tasks) == 1
    assert task_include

# Generated at 2022-06-11 09:59:42.689757
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)
    # Check if VALID_INCLUDE_KEYWORDS is correct
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'name', 'listen', 'vars', 'static', 'tags', 'when',
                                                         'block', 'register', 'ignore_errors'}

# Generated at 2022-06-11 09:59:44.581003
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert isinstance({}, dict)

# Generated at 2022-06-11 09:59:52.129614
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='tests/inventory/hosts_one')
    variable_manager.set_inventory(inventory)

    block = Block()
    task = Task()

    task_include = TaskInclude(block=block)
    block.set_task_include(task_include)

    include = {
        'name': 'include',
        'include': 'loader_include.yml',
    }
    handler = HandlerTaskInclude.load

# Generated at 2022-06-11 09:59:57.601980
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-11 10:00:04.638908
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext

    data = [
        {
            "name": "install nginx",
            "tags": ["nginx"],
            "listen": "restart webserver"
        },
        {
            "name": "install php",
            "tags": ["php"]
        }
    ]
    blocks = []
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(data, blocks, role, task_include, variable_manager, loader)

    assert handler.notify

# Generated at 2022-06-11 10:00:10.890393
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_data = dict(
        name='test',
        listen=['test_listen'],
        tasks=[
            dict(
                shell='/bin/false',
            )
        ]
    )
    handler = HandlerTaskInclude.load(my_data)
    assert handler.name == 'test'
    assert handler.listen == ['test_listen']
    assert handler.tasks[0].module_name == 'shell'
    assert handler.tasks[0].args['_raw_params'] == '/bin/false'

# Generated at 2022-06-11 10:00:13.122077
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''
    Unit test for constructor of class HandlerTaskInclude
    '''
    test_staticmethod_load = HandlerTaskInclude.load
    assert test_staticmethod_load is not None

# Generated at 2022-06-11 10:00:21.297254
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host

    handler = HandlerTaskInclude()
    assert handler is not None
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None
    data = {'include': 'tasks/main.yml'}
    handler = HandlerTaskInclude.load(data)
    assert handler is not None
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert handler is not None

    # TODO: Replace next line with working code
    # host = Host()
    # handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None, host=host)

# Generated at 2022-06-11 10:00:30.003564
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible import utils
    from ansible.inventory import Inventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    mygroup = Group('mygroup')
    mygroup.vars = {'ansible_connection': 'local'}
    myhost = Host(name = 'localhost')
    myhost.vars = {'ansible_python_interpreter': '/usr/bin/python'}
    mygroup.add_host(myhost)
    inventory = Inventory(loader = None)
    inventory.add_group(mygroup)

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    loader = DataLoader()

    task_

# Generated at 2022-06-11 10:00:36.693060
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    host = Host('fake_host', '192.168.0.1')

    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, 'host_var', 'host_val')

    # Create data variable, which contains include_tasks
    data = {
        'name': 'include_task_name',
        'include_tasks': './fake_task.yml'
    }

    # Create object with HandlerTaskInclude class
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager)

    assert handler.task_include is not None

# Generated at 2022-06-11 10:00:44.462182
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Set up data
    data = {"include": "my_include"}
    block = "test block"
    role = "test_role"
    task_include = "test task include"
    variable_manager = "test var manager"
    loader = "test loader"

    # Create the object and test method
    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    handler = t.check_options(
        t.load_data(data, variable_manager=variable_manager, loader=loader),
        data
    )

    # Assertions
    assert handler.loop is None
    assert handler.item is None
    assert handler.name == "my_include"
    assert handler.tags == ''
    assert handler.loop_control == {}
    assert handler.when == []

# Generated at 2022-06-11 10:00:51.444751
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    loader = 'fake_loader'
    block = Block()
    role = 'fake_role'
    task_include = None

    data = { 'handler': 'fake_handler' }
    hti = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include)
    assert isinstance(hti, Handler)
    assert type(hti.action) is Task
    assert hti.action.name == 'fake_handler'

    data = { 'handlers': [ 'fake_handler_1', 'fake_handler_2' ] }
   

# Generated at 2022-06-11 10:00:52.149840
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 10:01:02.696509
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Testing load() method of class HandlerTaskInclude
    """
    pass

# Generated at 2022-06-11 10:01:10.767956
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['127.0.0.1,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    data = dict(
        name='This is a name',
        include=dict(
            tasks='task_name.yml'
        )
    )

    handler = HandlerTaskInclude.load(data=data, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    assert handler.block == None, handler.block
    assert handler.role == None, handler.role
    assert handler.task_include

# Generated at 2022-06-11 10:01:19.564632
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    _loader = DictDataLoader({
        hot_tasks_handler: """
        - name: task1
          shell: /usr/bin/somecommand
          when: ansible_os_family == 'RedHat'
        """,
        hot_main: """
        - name: handler
          include_tasks: tasks_handler
          listen: "{{ hot_test_var }}"
        """,
        hot_vars: """
        hot_test_var: 'test_value'
        """
    })

    _variable_mgr = VariableManager()
    _variable_mgr.extra_vars = {'hot_test_var': 'test_value'}


# Generated at 2022-06-11 10:01:28.411093
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ob = HandlerTaskInclude(
        block = {
            "name" : "My Task Include"
        },
        role = {
            "name" : "My Role"
        },
        task_include = {
            "name" : "My Task Include from Task"
        }
    )

    ob.task_include = {
        "name" : "My Task Include from Task - 2"
    }
    print(ob.task_include)


# Generated at 2022-06-11 10:01:37.095949
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import find_plugin
    from ansible.template import Templar
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    plugin_loader = find_plugin(TaskInclude.__name__, "./")
    handler_task_include_load = plugin_loader.get('handler_task_include')

# Generated at 2022-06-11 10:01:39.533540
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    return handler



# Generated at 2022-06-11 10:01:49.610385
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    import ansible

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.handler import Handler

    import os.path
    import yaml

    handler = None
    data = """
        - name: ansible_facts
        - name: setup
    """
    try:
        handler = HandlerTaskInclude.load(data, variable_manager=None, loader=None)
    except:
        pass
    finally:
        assert isinstance(handler, Handler) == True
        assert handler.get_name() == "ansible_facts"
        assert handler.get_action() == "setup"

# Generated at 2022-06-11 10:01:52.585570
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = "handler1.yml"

    host_results = HandlerTaskInclude.load(data)
    assert isinstance(host_results, HandlerTaskInclude)
    assert host_results.static_vars == {}
    assert host_results._block is None

# Generated at 2022-06-11 10:02:01.410672
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
	import os
	import sys

	test_path = os.path.dirname(os.path.realpath(__file__))
	sys.path.append(test_path)
	from PlaybookTest import PlaybookTest
	playbook_path = test_path[0:test_path.rfind('/')]
	playbook_name = "test.yml"

	test = PlaybookTest(playbook_path, playbook_name)
	inventory = test.get_inventory()
	variable_manager = test.get_variable_manager()
	loader = test.get_loader()
	playbook_file = test.get_playbook_file()
	playbook = playbook_file.playbook

	play = playbook.get_plays()[0]
	base_dir = os.path.dirname(playbook_path)


# Generated at 2022-06-11 10:02:08.530978
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    
    # create task_include_data
    task_include_data = {
        "name": "include_tasks",
        "_raw_params": "test.yml"
    }

    # create data
    data = {
        "listen": "task1",
        "include": "include_tasks"
    }

    handler = HandlerTaskInclude.load(data, task_include=task_include_data)
    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-11 10:02:36.238534
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    class Object(object):
        pass
    data = dict(
        name="test_handler",
        tags=["test", "handler"],
        ignore_errors=True,
        tasks=[dict(action=dict(module="debug", args="var=test_variable")),
               dict(action=dict(module="debug", args="var=test_variable"))]
    )

    context = PlayContext()
    ansible = Object()
    ansible.play_context = context
    context.hostvars = {'127.0.0.1': {'ansible_connection': 'local', 'ansible_python_interpreter': '/usr/bin/python'}}
    class Host(object):
        pass
    h = Host()
    h.name = "localhost"



# Generated at 2022-06-11 10:02:38.340244
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    pass

# Generated at 2022-06-11 10:02:41.426916
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    print("HandlerTaskInclude Method load:")
    print("If you see no ERROR, it is all right")
    handler = t.load(None)
    print("HandlerTaskInclude Method load:", handler)


# Generated at 2022-06-11 10:02:42.744166
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti != None

test_HandlerTaskInclude()

# Generated at 2022-06-11 10:02:43.573856
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()


# Generated at 2022-06-11 10:02:44.763303
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-11 10:02:48.316283
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    handler = HandlerTaskInclude.load({'include_tasks': '/tmp/test', 'listen': 'mail_server'})
    assert isinstance(handler, TaskInclude)
    assert isinstance(handler, Task)
    assert isinstance(handler, Handler)
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.static

# Generated at 2022-06-11 10:02:57.181356
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    def check_options(self, data, ds):

        # load all attributes set in any role/task/include statement
        for attr in data:
            if attr not in self.VALID_INCLUDE_KEYWORDS:
                raise AnsibleError("%s is not a valid include keyword" % attr)
            setattr(self, attr, data[attr])

        # set defaults for missing attributes, if specified
        for attr in self.DEFAULT_ATTR_FILTER:
            if not hasattr(self, attr):
                default = self.DEFAULT_ATTR_FILTER[attr](ds)
                setattr(self, attr, default)

        # special validation steps

# Generated at 2022-06-11 10:02:58.880917
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-11 10:03:03.725341
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # test_data = dict(name='test', include='include', delegate_to='localhost')
    #
    # t = HandlerTaskInclude()
    #
    # handler = t.load(test_data)
    #
    # assert handler.get_name() == test_data['name']
    # assert handler.include == test_data['include']
    # assert handler.delegate_to == test_data['delegate_to']
    pass

# Generated at 2022-06-11 10:03:42.517628
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 10:03:46.680763
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # create an instance of HandlerTaskInclude
    h = HandlerTaskInclude(None, None, None)

    # create a test data
    data = {
        "include": {
            "tasks": "tasks.yml"
        }
    }
    # call the load method
    res = h.load(data, None, None, None, None)

    # assert the result...
    assert h.__class__.__name__ == 'HandlerTaskInclude'


# Generated at 2022-06-11 10:03:47.446931
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test method load of class HandlerTaskInclude with different values
    """

# Generated at 2022-06-11 10:03:49.667537
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        action=dict(
            module='command',
            args='/bin/foo'
        ),
        listen='all'
    )

    handler = HandlerTaskInclude.load(data)
    assert handler.get_name() == 'command'

# Generated at 2022-06-11 10:03:50.113169
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 10:03:52.136778
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(
        block=None,
        role=None)
    assert handler


# Generated at 2022-06-11 10:03:55.502425
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        args=dict(
            debug="msg='{{y}},{{y}},{{y}}'"
        ),
        name="test_handler",
        tags=['always', 'test']
    )
    assert HandlerTaskInclude.load(data).name == "test_handler"
    assert HandlerTaskInclude.load(data).tags == ['always', 'test']

# Generated at 2022-06-11 10:03:58.423018
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    import pprint
    pprint.pprint(HandlerTaskInclude)
    pprint.pprint(handler_task_include)

#    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-11 10:04:00.725744
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task = dict(action=dict(module='test'))
    handler = HandlerTaskInclude.load(task)
    assert handler.action == task['action']

# Generated at 2022-06-11 10:04:07.755405
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    host = Host()
    block = Block(play=None)
    task = Task()
    handler = Handler()
    host_vars_dict= {"ansible_ssh_host":"80.85.91.33"}
    host_vars = HostVars(host=host, variables=host_vars_dict)
    variable_manager = VariableManager()
    variable_manager._host_vars_cache = {host.name: host_vars}
    variable_manager._fact_cache = {}
    variable_