

# Generated at 2022-06-11 09:57:04.475667
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:57:10.140841
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        u'include': {
            u'file': u'new.yml',
            u'name': u'new.yml',
        },
        u'tags': [],
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.name == u'new.yml'
    assert handler.run_once == False
    assert handler.delegate_to == None
    assert handler.when == None

# Generated at 2022-06-11 09:57:11.404929
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-11 09:57:13.303124
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # There is no goal to test the working of the code
    # there is only code coverage purpose
    HandlerTaskInclude()

# Generated at 2022-06-11 09:57:14.455062
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 09:57:15.071173
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:57:23.862675
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.errors import AnsibleParserError

    add_all_plugin_dirs()

    # Construct objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, 'localhost,127.0.0.1')
    variable_manager.set_inventory(inventory)
    play_context = {}
    block_task

# Generated at 2022-06-11 09:57:32.631466
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import test_loader
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
   

# Generated at 2022-06-11 09:57:33.108186
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:57:33.615267
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:57:39.608220
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert isinstance(h, HandlerTaskInclude)
    assert h.VALID_INCLUDE_KEYWORDS == set(
        ['name', 'tasks', 'register', 'ignore_errors', 'delegate_to', 'run_once', 'tags', 'when', 'vars', 'notify', 'listen']
    )

# Generated at 2022-06-11 09:57:49.077438
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Run unit tests for HandlerTaskInclude().load method
    """
    from ..base import AnsibleModule
    from ..vars.manager import VariableManager
    from ..playbook.play import Play
    from ..playbook.task import Task
    from ..playbook.block import Block
    from ..playbook.playbook import Playbook
    from ..inventory.host import Host
    from ..inventory.group import Group
    from ..inventory.inventory import Inventory
    from ..plugins import action_loader
    from ..plugins.strategy import StrategyBase
    from ..plugins.strategy.linear import StrategyModule
    from ..plugins.strategy.free import StrategyModuleFree
    from ..plugins.strategy.debug import StrategyModuleDebug
    import unittest


# Generated at 2022-06-11 09:57:57.951141
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import os
    import json
    import requests
    import ansible.playbook.task_include
    from ansible.playbook.role_include import include_role
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    # basic example
    # not sure how to write unit test

    # full options covered example

    # uri
    task_list = [
        {'include_role': {'name': 'test', 'static': 'yes', 'tasks_from': 'abc', 'vars': {'var1': 'value1', 'var2': 'value2'}}},
    ]
    role_info = include_role(
        play=None,
        task=task_list[0]['include_role']
    )

# Generated at 2022-06-11 09:57:59.539174
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)



# Generated at 2022-06-11 09:58:05.547090
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.yaml_loader import YAMLLoader

    task_include = TaskInclude()
    block = Block()
    task = Task()
    loader = YAMLLoader()
    h = HandlerTaskInclude(block=block, role=task, task_include=task_include)

    return h

# Generated at 2022-06-11 09:58:06.055630
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-11 09:58:07.485799
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_handlerTaskInclude = HandlerTaskInclude()
    assert handler_handlerTaskInclude is not None

# Generated at 2022-06-11 09:58:08.355971
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    raise NotImplementedError


# Generated at 2022-06-11 09:58:09.487499
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h is not None

# Generated at 2022-06-11 09:58:10.372210
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:58:21.600283
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    class MockVariableManagerData(object):
        def __init__(self):
            self.extra_vars = {}

    class MockVariableManager(object):
        def __init__(self):
            self.data = MockVariableManagerData()

        def get_vars(self, loader, task_vars=None, include_hostvars=False):
            return self.data.extra_vars

    class MockBlock(object):
        def __init__(self):
            self.name = 'block_name'

    class MockIncludeTask(object):
        def __init__(self):
            self.task_include = 'task_include_name'


# Generated at 2022-06-11 09:58:22.762531
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    handler.handler_name

# Generated at 2022-06-11 09:58:31.564877
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Test load")
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)


# Generated at 2022-06-11 09:58:32.651283
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print()


# Generated at 2022-06-11 09:58:33.136148
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 09:58:35.139604
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = HandlerTaskInclude()
    assert task_include is not None
    assert task_include.__class__.__name__ == 'HandlerTaskInclude'



# Generated at 2022-06-11 09:58:35.921080
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO
    assert False

# Generated at 2022-06-11 09:58:44.223538
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
#    from ansible.playbook.play_context import PlayContext

    test_host = Host(name='test_host')
    test_playbook_task = Task(name='test_playbook_task')
    test_block = Block()
#    test_play_context = PlayContext()

    test_loader = 10
    test_variable_manager = 20

    test_data = {'listen': 'test_listen',
                 'handlers': 'test_handlers',
                 'name': 'test_name',
                 'tags': 'test_tags',
                 'when': 'test_when'}

    test_block_data = {'block': test_block}
    test

# Generated at 2022-06-11 09:58:52.559381
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.playbook.play_context import PlayContext

    h = Host("hostname")
    g = Group("groupname")
    g.add_host(h)

    i = Inventory("hostname-inventory")
    i.add_group(g)

    task = Task()

    t = TaskInclude()

    task_include = t.load

# Generated at 2022-06-11 09:58:55.944674
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handlerTaskInclude = HandlerTaskInclude()

    print('\nhandlerTaskInclude = {0}\n'.format(handlerTaskInclude))
    print('handlerTaskInclude.__dict__ = {0}\n'.format(handlerTaskInclude.__dict__))



# Generated at 2022-06-11 09:59:02.456074
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include = HandlerTaskInclude()

    assert handler_task_include is not None

# Generated at 2022-06-11 09:59:09.843391
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # fix up imports so the unit tests can run
    HandlerTaskInclude.TaskInclude = TaskInclude
    HandlerTaskInclude.Host = host
    
    h = HandlerTaskInclude.load(dict(include="task_name", with_items=["item1", "item2"]))
    assert(h)
    
    assert(isinstance(h, HandlerTaskInclude))
    assert(isinstance(h, TaskInclude))
    assert(isinstance(h, Handler))
    
    the_host = host()
    h.name = "the_handler"
    h.handler_block = h.block = "the_block"
    h.role = "the_role"
    h.task_include = "the_task_include"
    h.DO_NOT_RUN = False

# Generated at 2022-06-11 09:59:17.293852
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import json

    #json_data = '{"name":"test"}'
    #data = json.loads(json_data)
    #hti = HandlerTaskInclude(None)
    #r = hti.load(data, variable_manager=None, loader=None)
    #print(r)

    json_data = '''
{
   "name":"test",
   "include":{
      "playbook":"play2.yml"
   },
   "listen":"test2"
}
'''
    data = json.loads(json_data)
    hti = HandlerTaskInclude(None)
    r = hti.load(data, variable_manager=None, loader=None)
    print(r.get_name())

# Generated at 2022-06-11 09:59:17.869028
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:25.228059
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # case 1
    data = {
        'include':'main.yml',
        'files':['files/file1','files/file2'],
        'static':'yes'
    }
    task_include = HandlerTaskInclude()
    task_include.load(data)
    assert task_include.static == 'yes'
    assert task_include.files == ['files/file1', 'files/file2']
    assert not task_include.only_tags
    assert not task_include.only_tasks

    # case 2
    data = {
        'include':'main.yml',
        'listen':'run_handler_task'
    }
    task_include = HandlerTaskInclude()
    task_include.load(data)

# Generated at 2022-06-11 09:59:25.706672
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:26.239464
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 09:59:28.676357
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_obj = HandlerTaskInclude()

    assert test_obj.block == None
    assert test_obj.role == None
    assert test_obj.task_include == None

# Generated at 2022-06-11 09:59:29.499167
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert 1 == 1, 'test stub'

# Generated at 2022-06-11 09:59:29.992739
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:40.512258
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 09:59:41.146818
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:51.172204
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Setup mocks.
    class MockHost(object):
        def __init__(self, name):
            self.name = name

    class MockVariableManager(object):
        @staticmethod
        def options():
            return object()

        @staticmethod
        def extra_vars():
            return object()

    class MockDataLoader(object):
        @staticmethod
        def load_from_file(p):
            return object()

        @staticmethod
        def path_dwim_relative(self, p, base_path, follow, create):
            return p

        @staticmethod
        def get_basedir(self, p):
            return p

    class MockBlock(object):
        def __init__(self):
            self.vars = MockVariableManager()

# Generated at 2022-06-11 09:59:53.330121
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    return None
    # FIXME: test disabled until Handler can be tested better
    # handler = HandlerTaskInclude()
    # assert handler is not None

# Generated at 2022-06-11 09:59:55.053731
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Inside test_HandlerTaskInclude")
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-11 10:00:04.361091
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Check that load return an HandlerTaskInclude instance
    obj = HandlerTaskInclude()
    data = dict(
        name="test name",
        listen="test listen",
        tags="test tags",
        remote_user="test remote user",
        sudo="test sudo",
        sudo_user="test sudo user",
        vault_password_file="test vault password file",
        become="test become",
        become_method="test become method",
        become_user="test become user",
        no_log="test no log",
        environment="test environment",
        local_action="test local action",
        connection="test connection"
    )
    handler = obj.load(data)
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.name() == "test name"
    assert handler.tags() == "test tags"

# Generated at 2022-06-11 10:00:11.242170
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include': 'foo', 'tags': ['bar', 'baz'],
            'when': 'ansible_os_family == "Debian"', 'name': 'test me'}
    # block = FakeBlock()
    # role = FakeRole()
    # task_include = FakeTaskInclude()
    # variable_manager = FakeVariableManager()
    # loader = FakeLoader()
    handler = HandlerTaskInclude.load(
        data, block=None, role=None, task_include=None,
        variable_manager=None, loader=None)
    assert handler.get_name() == 'test me'

# Generated at 2022-06-11 10:00:19.303296
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-11 10:00:19.876784
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:00:20.917325
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude()
    handler.load()

# Generated at 2022-06-11 10:00:42.453501
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    v = HandlerTaskInclude()
    
test_HandlerTaskInclude()

# Generated at 2022-06-11 10:00:44.301637
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load({}, [], None, None, None, None)
    assert handler is not None

# Generated at 2022-06-11 10:00:51.295365
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager

    yaml_data = {}
    yaml_data['name'] = 'fake_handler'
    yaml_data['listen'] = 'fake_handler'

    fake_block = Block(None, None, 'fake_block', 1, 1, None)
    fake_task_include = TaskInclude(None)
    fake_variable_manager = VariableManager()

    test_handler_task_include = HandlerTaskInclude(block=fake_block, role=None, task_include=fake_task_include)


# Generated at 2022-06-11 10:00:51.763174
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:00:52.216024
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:00:58.870807
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block    
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    ############
    block = Block()
    role = Role()
    task = Task()
    
    path = 'tests/data/handlertaskinclude.yml'
    task_data = Task.load_data_from_file(file_name=path, variable_manager=None, loader=None)
    
    task_include = task.load(data=task_data, play=block, variable_manager=None, loader=None)
    

# Generated at 2022-06-11 10:01:05.957278
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create mocks
    block_data = dict(
        tasks=[
            dict(
                debug=dict(
                    var=123,
                )
            ),
        ]
    )

    block_data_handler = dict(
        debug=dict(
            var=123,
        )
    )

    block_name="test_block"

    play_context=PlayContext()
    play_context._set_task_and_variable_override("handler")

    data_loader=Data

# Generated at 2022-06-11 10:01:14.851678
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-11 10:01:18.946670
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="Test include",
        tags="test",
        become="true",
        become_user='root',
        include="test_handler_include.yml",
        listen="fired_when_changed",
    )

    assert isinstance(HandlerTaskInclude.load(data), HandlerTaskInclude)



# Generated at 2022-06-11 10:01:27.605619
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    argv = []
    argv.append('ansible-playbook')
    argv.append('playbook.yml')
    config = ansible.utils.config.Config(parser=ansible.utils.config.Config.parser.yaml, defaults=None, env_vars=None, args=argv)
    config.settings['inventory'] = ansible.inventory.Inventory('/etc/ansible/hosts')
    config.settings['module_name'] = 'setup'
    config.settings['module_path'] = None
    config.settings['forks'] = 1
    config.settings['timeout'] = 5
    config.settings['remote_user'] = None
    config.settings['ask_pass'] = False
    config.settings['private_key_file'] = None
    config.settings['ssh_common_args']

# Generated at 2022-06-11 10:02:15.748229
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    data = {
        "include_tasks": "foo.yml",
        "vars": {
            "foo": "bar"
        },
        "static": "all",
        "delegate_to": "127.0.0.1",
        "loop": "{{ my_hosts }}",
        "loop_control": {
            "label": "{{ my_label }}",
            "loop_var": "my_hosts"
        }
    }
    task = hti.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert task.include is "foo.yml"
    assert task.name is None
    assert task.role is None

# Generated at 2022-06-11 10:02:23.681245
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = {
        "include": "name.yml",
        "name": "name",
        "meta": "meta.yml",
        "tags": "tags",
        "options": "options",
        "free-form": "free-form",
        "tasks": "tasks",
        "block": "block"
    }

    # Asserts that check_options is called correctly
    check_options_called = False

    class TaskIncludeStub(object):

        def __init__(self, task_include):
            self.task_include = task_include

        def check_options(self, host, task):
            assert host == 'host'
            assert task == data
            return 'task'


# Generated at 2022-06-11 10:02:24.081972
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 10:02:24.495527
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:02:25.565869
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-11 10:02:26.777954
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

# Generated at 2022-06-11 10:02:35.071162
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class HandlerData:
        def __init__(self, name, tasks=None, when=None, changed_when=None, become=False, become_user=None,
                     become_method=None, sudo=False, sudo_user=None, run_once=False, connection='local',
                     ignore_errors=False, check=False, tags=None, register=None, delegate_to=None, raw=None,
                     environment=None, depends_on=None, listen=None):
            self.name = name
            self.tasks = tasks
            self.when = when
            self.changed_when = changed_when
            self.become = become
            self.become_user = become_user
            self.become_method = become_method
            self.sudo = sudo
            self.sudo_user = sudo_user
           

# Generated at 2022-06-11 10:02:37.970764
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('Testing constructor of HandlerTaskInclude')
    h = HandlerTaskInclude()
    print(h)


# Generated at 2022-06-11 10:02:42.818518
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def assert_HandlerTaskInclude_load_result(data, block, role, task_include):
        t = HandlerTaskInclude()
        result = t.load(data, block=block, role=role, task_include=task_include)
        assert data == result.load_data(data), 'load_data() returns incorrect dict.'

    # test with empty expression
    assert_HandlerTaskInclude_load_result({}, [], 'role', 'include_task')

# Generated at 2022-06-11 10:02:44.211185
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.role
    print(ansible.playbook.role.role_include)

# Generated at 2022-06-11 10:04:16.099197
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.plays import Play
    from ansible.playbook.included_file import IncludedFile

    manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-11 10:04:18.895941
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        block=None,
        role=True,
        task_include=None
        )
    t = HandlerTaskInclude.load(data)
    assert t.block is None
    assert t.role is True
    assert t.task_include is None

# Generated at 2022-06-11 10:04:27.008714
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.attribute import Attribute
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.plugins.loader import become_loader
    from collections import namedtuple

    playbook_tuple = namedtuple("playbook", ["become_pass"])

    # TODO(gondor) This test fails because the data loader can't determine the
    # correct become plugins when running without an inventory.  It needs some
    # way to access the variables in play_context so that it can determine the
    # correct value.
    #
    # See https://github.com/ansible/ansible/issues/27978
    return


# Generated at 2022-06-11 10:04:27.540593
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:04:30.574345
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    variable_manager = ''
    loader = ''
    data = ''
    block = ''
    role = ''
    task_include = ''

    assert HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:04:34.817623
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#    data = {'include': 'x', 'static': 'y'}
#    blocks = Mock()
#    role = Mock()
#    task_include = Mock()
#    variable_manager = Mock()
#    loader = Mock()
#    handler_task_include = HandlerTaskInclude(blocks, role, task_include)
#    handler_task_include.load(data, blocks, role, task_include, variable_manager, loader)



# Generated at 2022-06-11 10:04:40.794305
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    variable_manager = None
    loader = None
    data_dict = {'block': None, 'role': None, 'task_include': None, 'loop': '', 'static': '', 'delegate_to': '', 'first_available_file': '', 'delegate_facts': '', 'when': '', 'name': '', 'vars': '', 'index': '', 'warn': '', 'loop_control': '', 'with_first_found': ''}
    return_value = HandlerTaskInclude.load(data=data_dict, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    print(return_value)
    print("\nOK")

# Generated at 2022-06-11 10:04:48.527829
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test empty constructor
    try:
        x = HandlerTaskInclude()
    except:
        raise AssertionError("HandlerTaskInclude(): empty constructor test failed")
    # test that default arguments work
    try:
        x = HandlerTaskInclude(block='handlers', role=None, task_include=None)
    except:
        raise AssertionError("HandlerTaskInclude(): second constructor test failed")


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-v', __file__]))

# Generated at 2022-06-11 10:04:49.204285
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:04:49.717208
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude