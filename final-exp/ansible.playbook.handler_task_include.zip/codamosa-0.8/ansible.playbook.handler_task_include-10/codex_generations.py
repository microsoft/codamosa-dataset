

# Generated at 2022-06-11 09:57:04.233527
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    d = {
        'include': 'somefile',
        'static': 1,
        'options': {'verbose': 1},
    }
    x = HandlerTaskInclude()
    # assert x.check_options( x.load_data(d), d) == None
    assert x.check_options( x.load_data(d), d) == None

# Generated at 2022-06-11 09:57:12.657401
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include='',
        paths='',
        name='',
        when='',
        tags='',
        listen='',
        discover='',
        meta='',
    )

    h = HandlerTaskInclude.load(data)
    assert not h.discover
    assert h.block is None
    assert h.role is None
    assert h.when == ''
    assert h.tags == ''
    assert h.notify == []
    assert h.listen == ''
    assert h.meta == ''
    assert h.always == []
    assert h.changed_when == ''
    assert h.failed_when == ''

# Generated at 2022-06-11 09:57:16.600885
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # evalue expect
    # iexpect =
    # handler =
    # assert handler == iexpect, "HandlerTaskInclude.load()"
    # assert handler.__class__.__name__ == 'Handler', "HandlerTaskInclude.load()"
    pass

# Generated at 2022-06-11 09:57:19.444563
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler
    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)

# Generated at 2022-06-11 09:57:20.837713
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert isinstance(HandlerTaskInclude(), HandlerTaskInclude)


# Generated at 2022-06-11 09:57:28.783975
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-11 09:57:31.022989
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_handler = HandlerTaskInclude()
    assert isinstance(my_handler, HandlerTaskInclude)
    assert my_handler.__class__.__name__ == "HandlerTaskInclude"

# Generated at 2022-06-11 09:57:32.195965
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    a = HandlerTaskInclude()
    assert a is not None

# Generated at 2022-06-11 09:57:32.961055
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()

# Generated at 2022-06-11 09:57:33.784135
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 09:57:36.180964
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: implement me
    print("Not implemented")


# Generated at 2022-06-11 09:57:40.556724
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'loop': "{{ query('ec2_instances_with_tag', instance_tags) }}",
        'name': 'test'
    }
    obj = HandlerTaskInclude.load(data)
    assert obj.get_name() == 'test'
# end of test_HandlerTaskInclude

# Generated at 2022-06-11 09:57:49.440046
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    handler = HandlerTaskInclude.load(dict(
        name="Command Task",
        listen=dict(
            test="cmd"
        )
    ),
        task_include=None,
        variable_manager=variable_manager,
        loader=loader)

    handler.validate()

    host = inventory.get_host('localhost')
    handler.set_loader(loader)
    handler.set_host(host)
    handler.run()

# Generated at 2022-06-11 09:57:57.353265
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #h = Handler()
    data = {'tasks': {'include': [{'name': 'common.yml'}]}}
    t = HandlerTaskInclude.load(data)
    assert t._block is None
    assert t._role is None
    #assert t._parsed_from is None
    assert t._action is None
    assert t._args is None
    assert t._loop is None
    assert t._loop_control is None
    assert t._notify is None
    assert t._register is None
    assert t._unless is None
    assert t._when is None
    assert t._changed_when is None
    assert t._failed_when is None

# Test for function check_options()

# Generated at 2022-06-11 09:57:59.271084
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'include': 'test'}
    handler = HandlerTaskInclude.load(data)
    assert handler is not None

# Generated at 2022-06-11 09:58:03.359398
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include': 'sample.yml'}
    block = []
    role = []
    task_include = []
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler.include == 'sample.yml'

# Generated at 2022-06-11 09:58:04.872752
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-11 09:58:07.261808
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    valid_include_keywords = HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == valid_include_keywords

# Generated at 2022-06-11 09:58:12.462985
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  handler = HandlerTaskInclude()
  assert handler is not None
  assert handler.block is None
  assert handler.dynamic_name is None
  assert handler.handler_name is None
  assert handler.role is None
  assert handler.task_include is None
  assert handler.tags is None
  assert handler.template is None
  assert handler.when is None
  assert handler.loop is None
  assert handler.loop_control is None
  assert handler.delegate_to is None
  assert handler.delegate_facts is False
  assert handler.notify is None
  assert handler.any_errors_fatal is True
  assert handler.always_run is False

# Generated at 2022-06-11 09:58:12.924824
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:58:24.058822
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible import inventory
    from ansible.playbook.shortcuts import load_list_of_blocks
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders

    # Prepare input data

# Generated at 2022-06-11 09:58:33.134014
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    popen = ''
    host = Host(name="localhost", port=22)
    group = Group(name="all")
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    variable_manager.set_inventory(inventory)
    data = dict(
        name='handler test'
    )
    t = HandlerTaskIn

# Generated at 2022-06-11 09:58:41.251077
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    data = {
        'include': ['asdf.asdf'],
        'name': 'asdasdf'
    }
    block = Block.load(data, task_include=None, role=None, play_context=PlayContext(), variable_manager=VariableManager(loader=None, inventories=InventoryManager()))
    task = HandlerTaskInclude.load(data, block=block, role=None, task_include=None, variable_manager=VariableManager(loader=None, inventories=InventoryManager()), loader=None)
    assert task.action == 'include'

# Generated at 2022-06-11 09:58:42.411365
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: implement test
    pass


# Generated at 2022-06-11 09:58:45.828256
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
     d = {'include': '{{ bar }}', 'tags': 'foo'}
     h = HandlerTaskInclude.load(d)
     assert h._attrs[u'include'] == '{{ bar }}'
     assert h._attrs[u'tags'] == 'foo'

# Generated at 2022-06-11 09:58:46.332768
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-11 09:58:50.325643
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = {
        'include': 'main.yml',
        'listen': 'test_event',
    }

    include = HandlerTaskInclude.load(
        data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None,
    )

    assert include.listen == 'test_event'

# Generated at 2022-06-11 09:58:51.678561
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(TaskInclude(name='fake'))
    assert handler is not None

# Generated at 2022-06-11 09:58:53.280139
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load({"include": "tasks/pre.yml"})

# Generated at 2022-06-11 09:58:57.080012
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Initialize class and check variable
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'delegate_to', 'tasks', 'vars', 'tags', 'ignore_errors', 'only_if', 'notify', 'when', 'first_available_file', 'handlers', 'listen'}

# Generated at 2022-06-11 09:59:09.420878
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager)
    handler_task_include = HandlerTaskInclude()


# Generated at 2022-06-11 09:59:17.421897
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host

    task_include = HandlerTaskInclude.load(
        data={'include': 'test_include.yml'},
        variable_manager=None,
        loader=None
    )
    assert task_include.static_include_tasks == ['test_include.yml']
    assert task_include.dynamic is False
    assert task_include.block is None
    assert task_include.role is None

    host = Host(name='example.com')

    handler = Handler.load(
        data={'listen': "TASK_INCLUDE_STARTED"},
        block=None,
        role=None,
        task_include=task_include,
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-11 09:59:20.432058
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    #
    # Unit test: ansible.playbook.handler.HandlerTaskInclude load()
    #

    # NOTE: Currently a no-op, simply need to make sure that it executes without error
    task_include = HandlerTaskInclude.load({})
    print(task_include)



# Generated at 2022-06-11 09:59:28.523658
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # HandlerTaskInclude.VALID_INCLUDE_KEYWORDS = set(('action', 'free_form', 'handlers', 'name', 'tags', 'tasks', 'when', 'listen'))
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == set(('action', 'free_form', 'handlers', 'name', 'tags', 'tasks', 'when', 'listen'))
    test_data = {
        'hosts': 'host.com',
        'name': 'my task',
        'tags': ['one','two','three'],
        'when': 'some condition',
        'listen': 'another task',
    }
    test_handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert test_data['name']

# Generated at 2022-06-11 09:59:29.114508
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = Handl

# Generated at 2022-06-11 09:59:31.599433
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude(
        block=None, role=None, task_include=None
    ).VALID_INCLUDE_KEYWORDS == set(['tasks', 'vars', 'options', 'tags', 'when', 'listen'])

# Generated at 2022-06-11 09:59:34.659844
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # data = dict(hosts="host_name", name="task_name", listen="handler_name")
    # h_t_i = HandlerTaskInclude(data)
    print("ok")


if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-11 09:59:39.458540
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    
    h = Host()
    g = Group()
    test_HandlerTaskInclude = HandlerTaskInclude(block=h, role=g)
    assert test_HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'name', 'tags', 'listen'}

# Generated at 2022-06-11 09:59:40.391123
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: implement the test
    pass

# Generated at 2022-06-11 09:59:41.097037
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 09:59:51.534784
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-11 09:59:57.451572
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a dictionary to test with
    data = dict(
        name="test_name",
        tasks=[dict(
            action="test_action",
            args=dict(test_args=True))])

    # Create the HandlerTaskInclude
    handler = HandlerTaskInclude(data)

    # Check that all of the parameters were set correctly
    assert handler.get_name() == "test_name"
    assert handler.block
    assert handler.block_args



# Generated at 2022-06-11 10:00:06.754805
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    import os
    import yaml

    # Prepare the test variables
    inventory = InventoryManager(loader=DataLoader(), sources="localhost,")
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    inventory.set_variable_manager(variable_manager)

# Generated at 2022-06-11 10:00:15.381177
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    hti = HandlerTaskInclude
    # Test 1
    ansible_dict = {'block': 'main', 'include': 'list_include.yml', 'listen': 'test'}
    var_manager = None
    task_include = None
    role = None
    block = None
    loader = None
    t = hti(task_include=task_include, block=block, role=role)
    #try:
    #    hti.load(ansible_dict, block='main', role=role, task_include=task_include, 
    #        variable_manager=var_manager, loader=loader)
    #except RuntimeError as e:
    #    print(e)
    # Test 2

# Generated at 2022-06-11 10:00:23.512868
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Create mock objects
    class MockData:
        pass
    class MockBlock:
        pass
    class MockRole:
        pass
    class MockTask:
        pass
    class MockVariableManager:
        pass
    class MockLoader:
        pass
    class MockHandler:
        def __init__(self, block, role, handler_block):
            self.block = block
            self.role = role
            self.handler_block = handler_block

    data = MockData()
    block = MockBlock()
    role = MockRole()
    task = MockTask()
    variable_manager = MockVariableManager()
    loader = MockLoader()
    handler = MockHandler(block, role, task)

    # Define side effects and return values of mock objects
    MockHandler.check_options.return_value = handler
    MockHandler.load

# Generated at 2022-06-11 10:00:27.976243
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = TaskInclude()
    task_include._load_name = 'include'
    t = HandlerTaskInclude(task_include=task_include)
    t._load_name = 'handler'
    data = {}
    data['include'] = "all"
    data['listen'] = "some_name"
    handler = t.load(data)

    assert handler._listen == "some_name"

# Generated at 2022-06-11 10:00:37.013479
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()

    default_host = Host(name="127.0.0.1", port=22)
    variable_manager.set_inventory(loader.load_inventory([default_host]))

    task_vars = dict()

    play_context = PlayContext()

# Generated at 2022-06-11 10:00:39.458862
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert hti is not None

# Generated at 2022-06-11 10:00:46.835123
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.scripts.modules.extras import ModuleReplacer
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.compat.six import StringIO
    from ansible.errors import AnsibleError
    from units.mock.loader import DictDataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group


# Generated at 2022-06-11 10:00:50.029793
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'name': 'test_handler'}
    def test_function():
        return data
    HandlerTaskInclude.check_options = test_function
    HandlerTaskInclude.load_data = test_function
    temp = HandlerTaskInclude(data)
    assert temp.check_options(temp.load_data(data), data)

# Generated at 2022-06-11 10:01:13.140921
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'a.yml',
        'listen': 'all',
    }

    handler = HandlerTaskInclude.load(data=data)
    assert handler.tags == ['all']

# Generated at 2022-06-11 10:01:14.339693
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Testing class HandlerTaskInclude")

    print(" Testing the method load")

# Generated at 2022-06-11 10:01:23.340118
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # data_list, host, play_context, loader, templar and variables object
    # will be used in the constructor of class HandlerTaskInclude
    data_list = {'include':'path_list', 'listen':'event_list'}
    host = type('Host', (object,), {'vars':{}})()
    play_context = type('PlayContext', (object,), {})()
    loader = type('DataLoader', (object,), {})()
    templar = type('Templar', (object,), {})()
    variables = type('VariableManager', (object,), {})()

    # call the constructor of class HandlerTaskInclude
    handler = HandlerTaskInclude(host, play_context, data_list, loader, templar, variables)

    # get the value of data_list

# Generated at 2022-06-11 10:01:25.101157
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    assert HandlerTaskInclude.load(data).__class__.__name__ == 'HandlerTaskInclude'


# Generated at 2022-06-11 10:01:30.603150
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import json
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    loader = None
    block = None
    role = None
    task_include = None
    variable_manager = VariableManager()
    data = json.loads("""{"listen":"role1"}""")
    HandlerTaskInclude.load(data, block=None, role=None, task_include=None,
        variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:01:39.634672
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from collections import namedtuple

    host_data = HostVars(ic=None, name='test', port=22)
    Option = namedtuple('Option', ['name', 'default', 'required', 'inherit', 'private', 'no_log'])
    Options = namedtuple('Options', ['boolean', 'synonyms', 'string', 'spec', 'choices', 'question', 'no_ask_vars', 'ask_which_vars'])

# Generated at 2022-06-11 10:01:44.013700
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="test",
        tags=['alert', 'foo']
    )
    handler = HandlerTaskInclude.load(data)
    assert handler.name == "test"
    assert handler.tags == ['alert', 'foo']

# Generated at 2022-06-11 10:01:46.697531
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(data = {'include':{'task': 'crazy_include'}})
    assert handler.path == 'crazy_include'

# Generated at 2022-06-11 10:01:54.589137
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data = {}

    inventory = InventoryManager(loader=DataLoader())
    role = Role.load(dict(name='test'), variable_manager=VariableManager(), loader=DataLoader(), use_handlers=False)
    block = Block(play=Play().load(dict(name='test', hosts=['localhost']), variable_manager=VariableManager(), loader=DataLoader()))

# Generated at 2022-06-11 10:02:01.709640
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''
    Construct a handler with include example:
    handlers:
      - name: restart memcache
        include: /path/to/handlers/memcache_restart.yml

    '''
    data = {"include": "/path/to/handlers/memcache_restart.yml"}
    handler = HandlerTaskInclude.load(data)
    assert handler is not None
    assert handler._handler_name == "restart memcache"
    assert handler._use_task_includes
    assert handler._task_includes == ['/path/to/handlers/memcache_restart.yml']


# Generated at 2022-06-11 10:02:43.360578
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:02:44.108966
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load('test.yml')

# Generated at 2022-06-11 10:02:47.090776
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    a = HandlerTaskInclude(block=None, role=None, task_include=None,)
    assert a._valid_attrs == set(['block','role','task_include'])
    assert a.block is None
    assert a.role is None
    assert a.task_include is None

# Generated at 2022-06-11 10:02:55.489035
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class test():
        x = None
        def __init__(self, x=None):
            self.x = x

    # Test1 : valid inputs
    actual = HandlerTaskInclude.load(data={'file': 'file', 'hosts': 'hosts', 'listen': 'listen'})
    expected = test(x=1)

    assert type(actual) == type(expected)

    # Test2 : valid inputs
    actual = HandlerTaskInclude.load(data={'file': 'file', 'hosts': 'hosts'})
    expected = test(x=1)

    assert type(actual) == type(expected)

    # Test3 : invalid inputs

# Generated at 2022-06-11 10:02:57.805366
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("test_HandlerTaskInclude_load: START")
    pass
    print("test_HandlerTaskInclude_load: END")


# Generated at 2022-06-11 10:03:01.065813
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None
    )
    assert handler is not None
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None

# Generated at 2022-06-11 10:03:12.235156
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    from collections import namedtuple

    Options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection','module_path', 'forks', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check'])

# Generated at 2022-06-11 10:03:12.743138
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:03:13.800790
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False # TODO


# Generated at 2022-06-11 10:03:15.369228
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)

# Generated at 2022-06-11 10:04:47.506777
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    import os

    dataLoader = DataLoader()
    variableManager = VariableManager()
    play = Play()
    play.name = 'testPlay'
    role = Role()
    role.name = 'testRole'
    block = Block()
    block.name = 'testBlock'
    block.parent = play
    task_include = TaskInclude()
    task_include.name = 'testTaskInclude'

# Generated at 2022-06-11 10:04:50.404058
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}

    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = t.load(data, None, None, None, None, None)
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-11 10:04:56.563531
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Testing method load of class HandlerTaskInclude")

    # TODO: create an instance with real data, then perform tests
    # TODO: also test the method with blocks and handlers

    #t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    #handler = t.check_options(
    #    t.load_data(data, variable_manager=variable_manager, loader=loader),
    #    data
    #)

    # assertEquals(expected, ha_cluster.members_for(node.name))

# Generated at 2022-06-11 10:05:04.368902
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test without parameters
    h = HandlerTaskInclude()
    assert h.action == 'meta'
    assert h.block == None
    assert h.role == None
    assert h.task_include == None
    assert h.tags == None
    assert h.when == None

    # Test with parameters
    h = HandlerTaskInclude(action='meta', block=None, role=None, task_include=None, tags=None, when=None)
    assert h.action == 'meta'
    assert h.block == None
    assert h.role == None
    assert h.task_include == None
    assert h.tags == None
    assert h.when == None

# Generated at 2022-06-11 10:05:08.592868
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    var_manager = ""
    loader = ""
    data = {
        'include': './test.yml',
        'tasks': {
            'foo': {
                'action': 'setup'
            },
            'bar': {
                'action': 'setup'
            }
        }
    }
    assert HandlerTaskInclude.load(data, variable_manager=var_manager, loader=loader)



# Generated at 2022-06-11 10:05:10.968143
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        test_handler_task_include = HandlerTaskInclude()

    except Exception:
        print ("Test failed")
        return -1

    else:
        print ("Test passed")
        return 0


# Generated at 2022-06-11 10:05:21.404715
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import pdb
    pdb.set_trace()
    # data = {'some_config': 'some_value', 'other': 'other_value'}
    data = {
        'hosts': 'appserver',
        'listen': 'some_event',
        'include_role': {
        'name': 'myrole'
        }
    }

    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include,
                                      variable_manager=variable_manager, loader=loader)

    assert handler.get_name() == 'myrole'
    assert handler.loop is False
    assert handler.run_once is False

# Generated at 2022-06-11 10:05:27.212626
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('TEST: test_HandlerTaskInclude()')
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)
test_HandlerTaskInclude()

# Generated at 2022-06-11 10:05:38.077326
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    blocks = []
    t_data = dict(include='test.yml')

    result = HandlerTaskInclude.load(t_data, blocks, variable_manager=variable_manager, loader=loader)
    assert result.get_name() == 'test.yml'
    assert result._task.get_name() == 'test.yml'
    assert result._role is None
    assert result._block is None
    assert result._any_errors_fatal is False
    assert result._

# Generated at 2022-06-11 10:05:38.603229
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass