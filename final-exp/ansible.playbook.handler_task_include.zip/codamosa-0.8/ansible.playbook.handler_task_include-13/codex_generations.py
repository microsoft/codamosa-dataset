

# Generated at 2022-06-11 09:57:13.485873
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # test that the validate method is called
    def validate_mock(self, data):
        return data
    HandlerTaskInclude.check_options = validate_mock

    # test that the correct values are passed to task_include
    def load_data_mock(self, data, variable_manager=None, loader=None):
        assert data == {'a': 'b'}
        assert variable_manager == 'variable_manager'
        assert loader == 'loader'
        return {'a': 'b'}
    HandlerTaskInclude.load_data = load_data_mock

    # call load and assert the values

# Generated at 2022-06-11 09:57:14.193662
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    pass

# Generated at 2022-06-11 09:57:23.389524
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Define the file path
    data_file_path = '../../tasks/include_vars.yml'

    # Define the data
    data = {
        'name': 'Test HandlerTaskInclude',
        'include': data_file_path,
        'loop': '{{ username }}',
    }

    # Define the block
    block = None

    # Define the role
    role = None

    # Define the task_include
    task_include = None

    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task

    # Create the Inventory object
    inventory = InventoryManager()

    # Create VariableManager object for handle the variables
    variable_manager

# Generated at 2022-06-11 09:57:24.839804
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    mt = HandlerTaskInclude()
    assert(mt) == HandlerTaskInclude

# Generated at 2022-06-11 09:57:28.861626
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # data = { 'include': 'test.yml' }
    data = { 'include': 'test.yml', 'name': 'test', 'loop': '{{ list }}' }
    test_obj = HandlerTaskInclude()
    res = test_obj.check_options( data, data)
    assert res == data['name']



# Generated at 2022-06-11 09:57:35.798260
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = """---
- hosts: 127.0.0.1
  remote_user: root
  tasks:
    - name: This is a test
      shell: echo hello
  handlers:
    - name: This is a handler
      shell: echo hello
    - include: playbook.yml
"""
    loader = None
    variable_manager = None
    block = None
    role = None
    task_include = None

    handler_task_include = Handler.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    print(handler_task_include)


# Generated at 2022-06-11 09:57:45.531023
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.registry import InventoryRegistry

    # Dummy inventory

# Generated at 2022-06-11 09:57:54.254208
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = TaskInclude()
    task_include.name = 'some name'
    task_include.action = 'some action'
    handler = HandlerTaskInclude(block=None, role=None, task_include=task_include)

    # test1: test with no data and invalid_key
    handler_task_include = handler.load({}, [], [])

    assert handler_task_include is not None
    assert handler_task_include == handler

    # test2: test with valid data and valid_key
    data = {
        'include': 'foo',
        'listen': 'bar'
    }

    handler_task_include2 = handler.load(data, [], [])

    assert handler_task_include2 is not None

# Generated at 2022-06-11 09:57:56.063550
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("\nTest: test_HandlerTaskInclude_load()\n")
    import ansible.playbook
    impor

# Generated at 2022-06-11 09:57:57.838410
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
	h = HandlerTaskInclude()
	data = [{'include': 'some test task'}]
	h.load(data)


# Generated at 2022-06-11 09:58:00.563164
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    T = HandlerTaskInclude()
    assert T

# Unit test to check validity of Ansible keyword

# Generated at 2022-06-11 09:58:08.073977
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = { "listen": "NOTIFY_HANDLER", "name": "task1"}
    block = None
    role = "test_role_name"
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert handler.name == "task1"
    assert handler.notify == ["NOTIFY_HANDLER"]
    assert handler.block is None
    assert handler.role == "test_role_name"
    assert isinstance(handler.task_include, Handler) is True

# Generated at 2022-06-11 09:58:09.279208
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task = HandlerTaskInclude()
    assert task is not None

# Generated at 2022-06-11 09:58:10.584647
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-11 09:58:18.276353
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible import errors
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    loader = DictDataLoader({
        "playbook/include_tasks/foo.yml": """
        - debug: msg="foo is included"
        """,
        "playbook/include_tasks/bar.yml": """
        - debug: msg="bar is included"
        """,
    })

    variable_manager = VariableManager()
    inventory = Inventory(
        loader=loader,
        variable_manager=variable_manager,
        host_list=[
            Host(name="localhost", variables=dict(foo="foo_var", bar="bar_var"))
        ]
    )
    inventory.subset("localhost")

    host = inventory.get

# Generated at 2022-06-11 09:58:19.854818
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj=HandlerTaskInclude(block=None, role=None, task_include=None)
    assert obj

# Generated at 2022-06-11 09:58:20.414262
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 09:58:28.845329
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    h = Host("localhost")
    im = InventoryManager("")
    im.add_host(h)

    v = VariableManager()
    l = DataLoader()

    t = TaskInclude()
    b = Block(play=None, parents=[], serial=0)
    hti = HandlerTaskInclude(block=b, task_include=t)
    hti.load(data={'name': 'test'}, variable_manager=v, loader=l)

# Generated at 2022-06-11 09:58:35.617499
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    import ansible.playbook.handler as handler_module
    from ansible.playbook.block import Block

    # This is the object to be loaded.
    data = [
        'myhandler',
        {
            'listen': 'myevent'
        }
    ]

    variable_manager = None
    loader = None

    h = handler_module.Handler.load(data, variable_manager=variable_manager, loader=loader)

    assert h is not None
    assert h.name == 'myhandler'
    assert h.block.name == 'myevent'
    assert h.block.block is None

# Generated at 2022-06-11 09:58:43.918849
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  data = {'include': '/path/to/my/tasks/main.yml',
          'static': '/path/to/my/tasks/static.yml',
          'name': 'Demo task include',
          'vars': {'var1': 'value1'}
         }

  block = None
  role = None
  task_include = None
  variable_manager = None
  loader = None

  #The test_handler.py:12: test_HandlerTaskInclude()
  try:
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
  except Exception as e:
    assert False, "test_HandlerTaskInclude() failed: " + str(e)
  else:
    assert True

#--------------------------------------------------------------------------


# Generated at 2022-06-11 09:58:54.722245
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    loader = DictDataLoader({
        "all/tasks/main.yml": """
---
- shell: echo hello world
  when: True
  register: echo_hello

- shell: echo "{{ echo_hello.stdout }}"
  when: echo_hello.rc == 0
""",
        "all/handlers/main.yml": """
---
- meta: clear_host_errors

- include: tasks/main.yml
  listen: "{{ echo_hello.rc == 1 }}"
"""}
)
    variable_manager = VariableManager()
    vm = variable_manager.get_vars(loader=loader, play=None)


# Generated at 2022-06-11 09:58:57.146712
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    data = dict(include="pass")
    t.load_data(data)
    data2 = dict(include="pass", handler="pass")
    t.check_options(t.load_data(data, data2))

# Generated at 2022-06-11 09:59:02.798618
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Create instances
    data = dict(
        name = "myhandler",
        listen = "myevent",
        tasks = [
            dict(
               name = "my task"
            )
        ]
    )
    t = HandlerTaskInclude()
    handler = t.check_options(
        t.load_data(data),
        data
    )

    assert(handler.name == "myhandler")
    assert(handler.listen == "myevent")
    assert(handler.tasks[0].name == "my task")
    assert(handler.action == "my task")

# Generated at 2022-06-11 09:59:10.467936
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import os
    import json

    curr_directory = os.path.dirname(os.path.abspath(__file__))
    password = open(os.path.join(curr_directory, 'password.key'), 'rb').read().strip()
    data_loader = DataLoader()
    inventory = InventoryManager(loader=data_loader, sources=['localhost,' + curr_directory + '/inventory'])
    host = inventory.get_host('localhost')
    play_context = PlayContext(become_pass=password, port=22, remote_user='vagrant')
    variable_

# Generated at 2022-06-11 09:59:12.499285
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.__class__.__name__ == "HandlerTaskInclude"


# Generated at 2022-06-11 09:59:17.511738
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    block = { }
    role = None
    task_include = "test"

    data = {
        "include": "/home/ansible/playbook.yml",
        "static": True,
        "tags": "a,b,c",
    }

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    h = HandlerTaskInclude.load(data, block, role, task_include)
    # print(h.args)
    assert h.action == TaskInclude.action

# Generated at 2022-06-11 09:59:18.889852
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-11 09:59:20.466318
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        h = HandlerTaskInclude()
    except:
        assert False, "Can't create instance of this class"


# Generated at 2022-06-11 09:59:27.559196
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test object initialization
    handler = HandlerTaskInclude()

    # Test loading of playbook with existing path
    filename = 'ansible/playbooks/playbook.yml'
    handler = HandlerTaskInclude.load({'include': filename})
    host = Host()
    list_task = handler.load_tasks_from_datastore()
    
    # Test loading of task list with non existing path
    filename = 'non/existing/playbook.yml'
    handler = HandlerTaskInclude.load({'include': filename})
    host = Host()
    list_task = handler.load_tasks_from_datastore()
    assert list_task == [], "The task list should be empty"

# Generated at 2022-06-11 09:59:28.440685
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    x = HandlerTaskInclude()
    assert x

# Generated at 2022-06-11 09:59:33.549941
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:36.316773
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    dict = {'when': 'always', 'static': 'yes', 'name': 'test__handler_task_include'}
    handler_task_include = HandlerTaskInclude.load(dict)
    assert handler_task_include is not None

# Generated at 2022-06-11 09:59:37.262440
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 09:59:48.767521
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = "[test]\nlocalhost\n"
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    h = HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    assert h.__dict__['block'] == None
    assert h.__dict__['role'] == None
    assert h.__dict__['loop'] == None
    assert h.__dict__['name'] == None
    assert h.__dict__['meta'] == None
    assert h.__dict__['any_errors_fatal'] == False
    assert h.__dict__['ignore_errors'] == False
    assert h.__dict__['tags'] == []
    assert h

# Generated at 2022-06-11 09:59:53.423275
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # create an empty object of class HandlerTaskInclude
    handleTask = HandlerTaskInclude()

    # assert that the object is not null
    assert handleTask is not None

    # assert that the function check_options works properly
    assert handleTask.check_options(1,1) == 1

    # assert that the function load_data works properly
    assert handleTask.load_data(1,1,1) == 1

    # assert that the function load works properly
    assert handleTask.load(1,1,1,0,0,0) is not None

    # assert that the function validate works properly
    assert handleTask.validate() == 0

    # assert that function VALID_INCLUDE_KEYWORDS is not null
    assert handleTask.VALID_INCLUDE_KEYWORDS is not None

# Generated at 2022-06-11 09:59:54.774779
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(None, None, None)
    assert handler is not None

# Generated at 2022-06-11 10:00:04.164704
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Unit test for method load of class HandlerTaskInclude
    '''
    # get a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars({'alvaro':'hola'})
    variable_manager.options_vars = load_extra_vars({'alvaro':'hola'})

    # get a loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # try to load a handler task
    data = {
        'handlers': 'hello',
        'name': 'this is when my handler is listening',
    }

    # get the handler
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)

    # check that the

# Generated at 2022-06-11 10:00:11.359560
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.variables import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # call module
    host = Host('localhost')
    variable_manager = VariableManager()
    loader = DataLoader()
    data = {
        'include': 'a.yml'
    }
    handler = HandlerTaskInclude.load(data)

    # get data to compare
    handlers = [ {}, {} ]
    handler = [ handler ]
    # call method
    assert handler == handlers


# Generated at 2022-06-11 10:00:11.929280
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:00:14.022617
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler,HandlerTaskInclude)
    assert isinstance(handler,Handler)
    assert isinstance(handler,TaskInclude)

# Generated at 2022-06-11 10:00:25.430840
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # This method is tested by test_playbook_include.test_handler_include
    # TaskInclude.load() is called in HandlerTaskInclude.load()
    pass

# Generated at 2022-06-11 10:00:26.850367
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'name': 'Super'}
    h = HandlerTaskInclude.load(data)

# Generated at 2022-06-11 10:00:35.926922
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test an include vars with explicit name (string) in a block
    data = dict(
        include='test_include_vars_string_block.yml',
        tags=['include_vars_block'],
        when='include_vars_block'
    )

    loader = DictDataLoader({
        'test_include_vars_string_block.yml': """
            - debug:
                msg: 'my name is {{ include_vars_block }}'
        """
    })

    variable_manager = VariableManager()

    task = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)

    assert task._role is None
    assert task._block is None
    assert task._task_include is None
    assert task._static is False

    assert task._handler is not None

# Generated at 2022-06-11 10:00:43.762945
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
#     data = {
#         'block': 'Block',
#         'role': 'Role',
#         'task_include': 'Task_Include',
#     }
#     handler_task_include = HandlerTaskInclude()
#     assert handler_task_include.block == 'Block'
#     assert handler_task_include.role == 'Role'
#     assert handler_task_include.task_include == 'Task_Include'

# def test_HandlerTaskInclude_load():
#     data = {
#         'include': 'Include',
#     }
#     variable_manager = None
#     loader = None
#     handler_task_include = HandlerTaskInclude()
#     handler_task_include.load(data, variable_manager=variable_manager, loader=loader)
#     assert handler

# Generated at 2022-06-11 10:00:44.265593
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:00:51.295033
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #
    # We initialize the object
    #
    h = HandlerTaskInclude.load(
        {'name': {'first': 'Joe', 'last': 'Johnson'}},
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    print(h)
    json_obj2 = {'play': {'hosts': ['all'], 'user': 'root', 'gather_facts': 'yes'}}


# Run test with python3 -e test_HandlerTaskInclude_load.py
if __name__ == "__main__":
    import sys
    import doctest

    failed, tests = doctest.testmod()
    sys.exit(failed)

    test_HandlerTaskInclude_load()

# Generated at 2022-06-11 10:00:57.872087
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import os
    import io
    import json
    import ansible.constants as C
    from ansible.errors import AnsibleParserError
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.task_include import TaskInclude

    loader = DataLoader()
    host = Host(name="test_host")
    group = Group(name="test_group")

# Generated at 2022-06-11 10:01:01.387546
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Unit test for method load of class HandlerTaskInclude
    """

    hti = HandlerTaskInclude()
    hti.check_options = Mock(return_value=hti)
    hti.load_data = Mock(return_value='data')

    result = hti.load(data='data')

    assert result == 'data'


# Generated at 2022-06-11 10:01:08.971398
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    data = dict(
        name="test-handler",
        include=dict(
            file="/path/to/tasks.yml"
        )
    )

    handler = HandlerTaskInclude.load(
        data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader,
    )

    assert handler

    data = dict(
        name="test-handler",
        include=dict(
            tasks="path/to/tasks.yml"
        )
    )


# Generated at 2022-06-11 10:01:10.126557
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    args = {}
    # assert HandlerTaskInclude.load(args) == {}

# Generated at 2022-06-11 10:01:29.228502
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:01:38.467185
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

    # create an Host object
    host = Host(name='172.18.0.13')

    # create an object to represent the cli args passed to ansible-playbook
    options = object()

    # create an PlayContext object
    play_context = PlayContext(become_method='sudo', become_user='root', connection='ssh', remote_addr='172.18.0.13', port=22, forks=2, remote_user='ec2-user', passwords={}, private_key_file='/home/vagrant/.ssh/id_rsa')

    # create a Block object

# Generated at 2022-06-11 10:01:47.354705
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a HandlerTaskInclude object
    hti = HandlerTaskInclude()

    # Assert that all attributes are of the proper type
    assert isinstance(hti.block, list)
    assert isinstance(hti.listen, list)
    assert isinstance(hti.tasks, list)
    assert isinstance(hti.task_include, bool)
    assert isinstance(hti.all_vars, bool)
    assert isinstance(hti._role, list)
    assert isinstance(hti.TYPE, type)
    assert isinstance(hti.VALID_INCLUDE_KEYWORDS, set)

    print("test_HandlerTaskInclude PASSED")

# Generated at 2022-06-11 10:01:50.966694
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None
    #assert isinstance(handler_task_include.get_strategy(), NoStrategy)
    #assert isinstance(handler_task_include.get_host(), Host)

# Generated at 2022-06-11 10:01:56.357824
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import os

    current_dir = os.getcwd()
    current_path = os.path.join(current_dir, 'ansible')
    yml_file = os.path.join(current_path, 'hosts')
    yml_path = os.path.join(current_path, 'playbook.yml')
    inventory = InventoryManager(loader=DataLoader(), sources=yml_file)

    variable_manager = VariableMana

# Generated at 2022-06-11 10:02:05.661283
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import ansible.playbook.play
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    data = {}

    # Construct play
    play = Play()
    play.name = 'test_play'
    play.hosts = "localhost"
    play.gather_facts = "no"

    # Construct role include
    role_include = RoleInclude()
    role_include.name = "test_role_include"
    role_include.role = "test_role"

    # Construct handler
    handler = HandlerTaskInclude(block=None, role=None, task_include=role_include)
    handler.name = "test"

    assert handler.play == None
    assert handler.name == "test"

    # Testing load
    handler = HandlerTaskIn

# Generated at 2022-06-11 10:02:08.323302
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = "include_tasks: action.yml"
    handler = HandlerTaskInclude.load(data)
    assert handler is not None
    assert handler.filename == "action.yml"

# Generated at 2022-06-11 10:02:15.819308
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    # test validation of full dict of handler including unimplemented
    # keywords
    handler = t.load({'tasks': [{'debug': {'msg': 'I worked'}}, {'debug': {'msg': 'I failed'}}],
                      'run_once': True,
                      'name': 'test',
                      'notify': ['test_handler'],
                      'listen': ['test_handler'],
                      'foo': 'bar'},
                     variable_manager=None, loader=None)
    # test handler.tasks
    assert isinstance(handler.tasks, list)
    assert len(handler.tasks) == 2
    assert handler.tasks[0]['debug']['msg'] == 'I worked'

# Generated at 2022-06-11 10:02:16.338926
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:02:18.055109
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_number = 0
    handler = HandlerTaskInclude(task_number)
    assert handler

# Generated at 2022-06-11 10:02:56.452671
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    return True

# Generated at 2022-06-11 10:03:05.345190
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import json
    import tempfile

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a DataLoader, used to load inventory and variables
    loader = DataLoader()

    # Create a host
    host = Host("host1")

    # Create a group
    group = Group("test_group")

    # Create an inventory manager, this will be populated with the hosts and groups
    # we will create later
    inventory_manager = InventoryManager(loader=loader, sources=None)

    # Add the group to inventory manager, this will also add all hosts in the

# Generated at 2022-06-11 10:03:12.350713
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert type('xyz') == type(HandlerTaskInclude.load(None))
    assert type(u'xyz') == type(HandlerTaskInclude.load(None))
    assert 'xyz' == HandlerTaskInclude.load('xyz')
    assert 'xyz' == HandlerTaskInclude.load(u'xyz')
    assert 'event' == HandlerTaskInclude.load(u'event')

# Generated at 2022-06-11 10:03:15.587701
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    hti._load_data = lambda x, y, z: 'Data loaded'
    hti.check_options = lambda x, y: 'Options checked'

    assert isinstance(hti.load('test', variable_manager='test'), str)

# Generated at 2022-06-11 10:03:23.914209
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import json
    import os

    # Load the configuration and inventory
    with open('tests/functional/inventory.json') as _inventory_file:
        inventory = json.load(_inventory_file)

    with open('tests/functional/playbook.yml', 'r') as _task_file:
        yaml_obj = _task_file.read()

    data = yaml_obj.encode('utf-8')
    block = None
    role = None
    task_include = None
    variable_manager = ansible.vars.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()

    # Set the hosts and variables
    variable_manager.extra_vars = {}
    variable_manager.set_inventory(ansible.inventory.Inventory(loader, inventory))

    # Load the handler

# Generated at 2022-06-11 10:03:31.422399
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # load method needs a lot of parameters, hence using a valid data
    data = {
        'name': 'test',
        'include': 'test',
        'handler': 'test',
        'tags': ['test', 'test2'],
    }
    # run the method
    handler = HandlerTaskInclude.load(data)
    assert handler.name == 'test'
    assert handler.include == 'test'
    assert handler.tags == ['test', 'test2']



# Generated at 2022-06-11 10:03:33.591403
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#     h = HandlerTaskInclude
#     h.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:03:41.045809
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    var_manager = VariableManager()
    loader = DataLoader()
    host = Host("localhost")
    block = Block()
    task = Task()
    role = Role()

    handler = HandlerTaskInclude(block, role, task)
    assert handler is not None

    handler = Handler.load("include: test123.yml", block, role, task, var_manager, loader)
    assert handler is not None
    assert handler._role is role
    assert handler._block is block
    assert handler._task_include is task

# Generated at 2022-06-11 10:03:47.783608
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    blk = Block(parent_block=None, role=None, task_include=None)
    rol = Role('amos', 'amos', parent_role=None)
    tas = Task(play=None, ds=None, template=None)
    incl = TaskInclude(parent_block=None, role=None, task_include=None, anyway=False)

    # proper handler

# Generated at 2022-06-11 10:03:48.422576
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 10:05:05.186942
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 10:05:11.430413
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import strip_internal_keys
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    
    class VariableManager_mock:
        def __init__(self):
            self.options_vars = {}
        def set_inventory(self, inventory):
            self.inventory = inventory

# Generated at 2022-06-11 10:05:12.322041
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 10:05:12.808981
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:05:16.517909
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    print("Testing HandlerTaskInclude.load")

    #####################################################
    # TODO: Some proper unit testing will follow soon...
    #####################################################
    pass

# Generated at 2022-06-11 10:05:17.024375
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-11 10:05:18.283399
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti is not None

# Generated at 2022-06-11 10:05:19.355819
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-11 10:05:20.507802
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h=HandlerTaskInclude()

# Generated at 2022-06-11 10:05:30.271228
# Unit test for method load of class HandlerTaskInclude