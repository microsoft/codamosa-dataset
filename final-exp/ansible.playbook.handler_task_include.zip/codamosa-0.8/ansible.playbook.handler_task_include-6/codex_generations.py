

# Generated at 2022-06-11 09:57:12.865373
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  f = open('test/unittests/handler.yml')
  ymlstr = f.read()
  # handler test
  vars={}
  # setup variables
  vars['awsRegion'] = 'us-west-2'
  vars['awsVpcId'] = 'vpc-aa8c0ad2'
  vars['awsSubnetId'] = 'subnet-d16b0eb9'
  vars['awsInstanceType'] = 't2.micro'
  vars['awsKeyPair'] = 'marian-test-keypair'
  vars['awsImageId'] = 'ami-81e27df8'
  vars['awsSecurityGroup'] = 'sg-4f9c6b24'
  vars['awsS3Bucket'] = 'ansible-base'
  #

# Generated at 2022-06-11 09:57:22.408338
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Check that an exception is raised when a value is not of type `dict`
    task_include = HandlerTaskInclude()
    try:
        task_include.load('', None)
        assert False
    except AssertionError:
        assert True

    # Check that an exception is raised when the task has not keywords
    try:
        task_include.load({}, None)
        assert False
    except AssertionError:
        assert True

    # Check that an exception is raised when the task has a keyword not in VALID_TASK_KEYWORDS
    try:
        task_include.load({'foo': 'bar'}, None)
        assert False
    except AssertionError:
        assert True

    # Check that an exception is raised when the task has no name

# Generated at 2022-06-11 09:57:29.021017
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.base import Base
    class Handler(object):
        def __init__(self):
            self.block = Base()
            self.notify = []


    data = dict(
        name='test_handler_task_include',
        tasks='task.yml',
    )
    handler = HandlerTaskInclude.load(data, Handler())


    assert handler.name == 'test_handler_task_include'
    assert handler.block.name == 'tasks'
    assert handler.notify == []
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-11 09:57:30.567406
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None

# Generated at 2022-06-11 09:57:31.166417
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

# Generated at 2022-06-11 09:57:40.507785
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import VariableResolver
    import ansible.constants as C

    h = Host('hostname')

    loader = C._create_loader_class()()

    t = Task()
    t.block = 'block1'
    t.vars = VariableManager()

    ht = Handler()
    ht.block = t.block
    ht.task = t
    ht.vars = t.vars

    d = dict()
    d['include'] = 'foobar.yml'
    d['ignore_errors'] = False
    d['listen'] = 'foo'


# Generated at 2022-06-11 09:57:41.131978
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 09:57:50.322788
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        listen = ['install'],
        tasks = [
            dict(
                shell = 'action_add_host'
            )
        ]
    )
    handler = HandlerTaskInclude.load(data, variable_manager=None, loader=None)
    assert handler.tasks_list[0].args['action'] == "add_host"

    data = dict(
        listen = ['install'],
        tasks = [
            dict(
                shell = 'action_add_host',
                args = dict(
                    hostname = "haha.com"
                )
            )
        ]
    )
    handler = HandlerTaskInclude.load(data, variable_manager=None, loader=None)
    assert handler.tasks_list[0].args['action'] == "add_host"
    assert handler

# Generated at 2022-06-11 09:57:59.184375
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play

    play = Play.load(dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict())),
            dict(include="example"),
        ]
    ), loader=None)

    task_include = play.handlers.get("example")
    assert task_include.static, "When 'include' is used in a handler section it must be a static include"
    assert task_include.blocks[0].name == "example", "The name of the included block must be equal to the name of included file"
    assert task_include.tasks[0].has_static_block(), "Task must have a static block"
    assert task_include.tasks[0].static_blocks

# Generated at 2022-06-11 09:58:01.000302
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None
    #print(handlerTaskInclude)

# Generated at 2022-06-11 09:58:03.604365
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #TODO: This needs to be written
    # return None
    pass

# Generated at 2022-06-11 09:58:10.398623
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(inventory="/foo/bar")
    variable_manager = VariableManager(loader=None, inventory=inventory)

    data = {
        'name': 'foo',
        'listen': 'bar',
        'block': 'baz',
        'tags': ['foo'],
    }

    result = HandlerTaskInclude.load(data, variable_manager=variable_manager)
    assert result.name == 'foo'
    assert result.listen == 'bar'
    assert result.block == 'baz'
    assert result.tags == ['foo']

# Generated at 2022-06-11 09:58:11.197822
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 09:58:13.091575
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert collector.Object(handler_task_include) == collector.Object(block=None, role=None, task_include=None)

# Generated at 2022-06-11 09:58:21.676835
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

    data = {
        'list': 'all',
        'listen': 'test_listen',
    }

    handler = HandlerTaskInclude.load(
        data,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader
    )


# Generated at 2022-06-11 09:58:22.200032
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 09:58:29.634262
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
	data = [dict(include = {'role': 'testrole'}, listen = dict(testevent = dict()))]
	block = None
	role = None
	task_include = None
	variable_manager = None
	loader = None
	handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
	assert handler.__dict__ == {'block': None, 'role': None, 'task_include': None, '_role_name': 'testrole', '_listen': {'testevent': {}} }
	assert handler.listen() == dict(testevent=dict())

# Generated at 2022-06-11 09:58:38.424661
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.block import Block

    data = dict(
        include = 'main.yml',
        name = 'foobar',
        listen = 'test_start'
    )

    block = Block()
    inventory = Inventory()
    var = VariableManager(loader=None, inventory=inventory)
    include = TaskInclude()

    handler_task_include = HandlerTaskInclude(block=block, role=None, task_include=include)
    handler_task_include.load(data, block, None, include, var, None)

    assert handler_task_include._role == None

# Generated at 2022-06-11 09:58:46.248446
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import mock
    import sys

    def mocked_load_data(data, **kwargs):
        return {'include': 'include.yml'}

    with mock.patch.object(TaskInclude, 'load_data', mocked_load_data):
        with mock.patch('os.path.exists', return_value=True):
            with mock.patch.object(TaskInclude, '_load_role', return_value=True):
                with mock.patch.object(HandlerTaskInclude, 'check_options', return_value=True):
                    sys.modules['ansible.plugins.action'] = mock.Mock()
                    handler = HandlerTaskInclude.load(data={'include': 'include.yml'})
                    assert handler is not None

# Generated at 2022-06-11 09:58:46.752979
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:58:53.188500
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    data = {
        'name': 'name',
        'listen': 'listen',
        'when': 'when',
    }
    handler = hti.load(data)
    assert handler.name == 'name'
    assert handler.listen == 'listen'
    assert handler.when == 'when'

# Generated at 2022-06-11 09:58:54.783012
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''this is a unit test for the constructor of the class HandlerTaskInclude'''
    assert True

# Generated at 2022-06-11 09:59:02.303194
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import os

    # AnsibleUnicode inside PlaybookIncludeHandler, TaskInclude, Task
    # TaskInclude inside PlaybookIncludeHandler, Task
    # Task inside PlaybookIncludeHandler

    def run_class(tar, data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        return tar.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    # Test case when data is not a dict
    payload = 'test'
    ret = run_class

# Generated at 2022-06-11 09:59:09.708050
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    import ansible.vars.hostvars
    import sys
    from ansible.vars.hostvars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    hostvars = HostVars(None, '', {'a': 'a'})

    host = Host(name='host1')
    group = Group(name='group1')


# Generated at 2022-06-11 09:59:10.456607
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:16.501699
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)

    # Test for VALID_INCLUDE_KEYWORDS
    assert 'listen' in hti.VALID_INCLUDE_KEYWORDS

    # Test for load(), but will also test for load_data() and check_options()
    handler_ = hti.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # Test for __repr__()
    assert "HandlerTaskInclude" in repr(hti)

# Generated at 2022-06-11 09:59:20.060895
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	data={}
	data['include'] = "func.yml"
	data['args'] = {"a": "b"}

	handler = HandlerTaskInclude.load(data)
	assert(handler.get_name() == "func.yml")
	assert(isinstance(handler, HandlerTaskInclude))
	assert(data['include'] == "func.yml")

# Generated at 2022-06-11 09:59:21.083696
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    mytest = HandlerTaskInclude.load("handler.yaml", "handler")

# Generated at 2022-06-11 09:59:29.338746
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    block = Block()
    role = Role()
    block._role = role
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}
    variable_manager.template_hosts = {}
    variable_manager.set_inventory(None)
    templar = Templar(variable_manager=variable_manager)

# Generated at 2022-06-11 09:59:37.450992
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from os.path import dirname, join
    from sys import path
    path.append(join(dirname(__file__), '..'))
    from lib.units import replace_lf_with_crlf

    loader=DataLoader()
    task = Task()
    host = 'localhost'
    block = Block([task])

    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_hosts'])
    host = inventory.get_host(host)
    play_context = {}

   

# Generated at 2022-06-11 09:59:51.708777
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include_data = {
        'include': 'myplaybook.yml',
        'file': 'myplaybook.yml',
        '_raw_params': 'myplaybook.yml',
        'tags': 'foo',
        '_uses_shell': False,
        '_raw_file': 'myplaybook.yml',
        '_role': 'role1',
        '_role_path': '/path/to/roles/role1',
        '_task': 'mytask',
        'listen': ['myhandler']
    }

    t = HandlerTaskInclude(block=None, role='role1', task_include=None)


# Generated at 2022-06-11 09:59:52.298365
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:00:01.910281
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    task_include = Task()


# Generated at 2022-06-11 10:00:10.188130
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block="all", role="testrole", task_include="testtaskinclude")
    # Check whether the values of the attribute are properly set.
    assert handler.block == "all"
    assert handler.role == "testrole"
    # The attributes _load_name, name, _parent and tags are set to None.
    assert handler._load_name is None
    assert handler.name is None
    assert handler._parent is None
    assert handler.tags is None
    # The dictionary VALID_INCLUDE_KEYWORDS is properly set.
    assert handler.VALID_INCLUDE_KEYWORDS == set(['listen', 'name', 'register', 'static', 'tags'])
# End of test_HandlerTaskInclude()

# Generated at 2022-06-11 10:00:12.078376
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    my_include = HandlerTaskInclude()
    my_include.load(data=data)
    return my_include


# Generated at 2022-06-11 10:00:13.550407
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include


# Generated at 2022-06-11 10:00:14.384077
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude == type(HandlerTaskInclude())

# Generated at 2022-06-11 10:00:15.249385
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: write
    assert(False)

# Generated at 2022-06-11 10:00:23.365058
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.utils.vars import combine_vars
    import yaml
    import pytest

    play_context = PlayContext()
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'

    all_vars = combine_vars(loader=False, params={}, inject={},
                            role_params={}, new_play=True)

    # Test of HandlerTaskInclude.load

# Generated at 2022-06-11 10:00:24.283148
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "TODO"


# Generated at 2022-06-11 10:00:42.359551
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.task import Task

    variable_manager = VariableManager()
    loader = None
    inventory = Inventory('hosts', variable_manager, loader)
    inventory.add_host(Host(name='test', port=22, variables=dict()))
    variable_manager.set_inventory(inventory)

    task = Task()
    task.load(dict(name='test task', include='test.yml'))

    handler_task_include = HandlerTaskInclude()
    handler = handler_task_include.load(dict(name='test handler', include='test.yml'), block=task, variable_manager=variable_manager)

    assert task.name == 'test task'
    assert handler

# Generated at 2022-06-11 10:00:44.725891
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    block=None
    role=None
    task_include=None
    handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    assert type(handler) == HandlerTaskInclude

# Generated at 2022-06-11 10:00:51.727145
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import json
    import sys
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase

    class CallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'test'

        def v2_runner_on_ok(self, result, **kwargs):
            host = result._host
            print(json.dumps({host.name: result._result}, indent=4))


# Generated at 2022-06-11 10:00:52.183925
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 10:00:52.901588
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO
    pass

# Generated at 2022-06-11 10:00:59.717879
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include = 'test.yml',
        static = False,
        register = 'test_register',
        # test all values for the boolean variables
        ignore_errors = False,
        first_available_file = False,
        no_log = False
    )
    test_block = None
    test_role = None
    test_task_include = None
    test_variable_manager = None
    test_loader = None
    instance_HandlerTaskInclude = HandlerTaskInclude(block=test_block, \
    role=test_role, task_include=test_task_include)

# Generated at 2022-06-11 10:01:06.666704
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    try:
        import ansible.parsing.yaml.objects
        print(ansible.parsing.yaml.objects)
        import ansible.inventory.host
        print(ansible.inventory.host)
        from ansible.playbook.handler import Handler
        print(Handler)
        from ansible.playbook.task_include import TaskInclude
        print(TaskInclude)
    except ImportError as e:
        print(e)
        assert False

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    HandlerTaskInclude = Handler
    HandlerTaskInclude = TaskInclude

    group = Group('group1')
    host = Host('host1')
    group.add_host(host)
    data = dict

# Generated at 2022-06-11 10:01:09.755539
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	# instantiate a HandlerTaskInclude object
	data = {"include":[{}], "include_role":[{}], "include_tasks":[{}]}
	handler_task_include = HandlerTaskInclude()
	handler_task_include.load(data)

# Generated at 2022-06-11 10:01:10.767614
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

# Generated at 2022-06-11 10:01:19.564296
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include': 'some.yaml'}

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources=['/tmp'])

    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    handler.run(inventory_manager, variable_manager, loader)

# Generated at 2022-06-11 10:01:50.830258
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    meta = """---
- name: install
  apt: name=nginx state=installed

- name: config test
  template: src=config/nginx.conf.j2 dest=/etc/nginx/nginx.conf owner=root group=root mode=0644
  listen: restart nginx
"""
    import yaml

    ds = yaml.load(meta)

    # entry = ds[0]
    # entry['hosts'] = 'target'
    # print(entry)
    # h = HandlerTaskInclude.load(entry)
    # print(h.__dict__)

    entry = ds[1]
    entry['hosts'] = 'target'
    print(entry)
    h = HandlerTaskInclude.load(entry)
    print(h.__dict__)


# Generated at 2022-06-11 10:01:52.272097
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t is not None
    assert task_include is not None

# Generated at 2022-06-11 10:01:53.028180
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "TODO"

# Generated at 2022-06-11 10:01:56.340631
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include_tasks': {
            'static': '{{ return_file_contents(filename) }}'
        }
    }
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    HandlerTaskInclude.load(data)

# Generated at 2022-06-11 10:01:57.581847
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:01:59.051578
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)


# Generated at 2022-06-11 10:02:00.915122
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hd = HandlerTaskInclude()
    hdload = hd.load(handler_data)
    hdload.dump()


# Generated at 2022-06-11 10:02:03.505725
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(data=dict(name='test', listen='test'), block=None, role=None, task_include=None, variable_manager=None, loader=None) is not None

# Generated at 2022-06-11 10:02:11.820012
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    playbook = Playbook.load(os.path.join(os.path.dirname(__file__), "../../../data/playbooks/test_include_role.yml"))
    inv = Inventory(loader=None, host_list=[])
    inv.add_group(Group('test_group_1'))

# Generated at 2022-06-11 10:02:15.177256
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        include="abc",
        name="cde",
        tags=["tag1"],
    )
    tti = HandlerTaskInclude.load(data)
    assert tti.include == "abc"
    assert tti.name == "cde"
    assert tti.tags == ["tag1"]


# Generated at 2022-06-11 10:02:58.262071
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()

# Generated at 2022-06-11 10:03:00.816348
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # instanciar Tarefa com um arquivo yaml como parametro
    # chamar Metodo load
    # verificar se retorna um Handler
    assert True == "TODO"

# Generated at 2022-06-11 10:03:06.696340
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create a new 'HandlerTaskInclude' object.
    t = HandlerTaskInclude()
    t.check_options = lambda data, d: data
    t.load_data = lambda data, variable_manager = None, loader = None: data
    data = dict(
        handler_name='test'
    )
    # Test that the value returned by 'load' is equal to the value returned by 'check_options'
    assert HandlerTaskInclude.load(data) == data


# Generated at 2022-06-11 10:03:11.024844
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    block = None
    role = None
    task_include = None
    data = None
    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    t.check_options(t.load_data(data),data)


# Generated at 2022-06-11 10:03:12.932356
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print(HandlerTaskInclude.load(''))

# Generated at 2022-06-11 10:03:17.504872
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    block1 = Block()
    block2 = Block()

    def test_load(data, expected_data, expected_results):
        class MockVariableManager(VariableManager):
            def __init__(self, *args, **kwargs):
                self.vars = dict()

            def get_vars(self, loader, path, entities):
                return self.vars

        variable_manager = MockVariableManager()
        variable_manager.vars = expected_vars


# Generated at 2022-06-11 10:03:19.035063
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    Host("test_host")
    Handler("test_handler")
    HandlerTaskInclude("test_handlerTaskInclude")

# Generated at 2022-06-11 10:03:20.818375
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#        print 'TESTING METHOD test_HandlerTaskInclude_load'
#        print 'NOT IMPLEMENTED YET'

# Generated at 2022-06-11 10:03:21.552486
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hi = HandlerTaskInclude()


# Generated at 2022-06-11 10:03:32.703738
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    data = '''
        - name: test
          gather_facts: yes
          tasks:
            - yum:
                name: httpsd
                state: installed
          handlers:
            - name: restart apache
              service: name=httpd state=restarted
    '''


# Generated at 2022-06-11 10:04:58.416721
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'other.yml',
        'foo': 'bar'
    }
    HandlerTaskInclude.load(data)

# Generated at 2022-06-11 10:05:04.734270
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include = 'foo.yml',
        static = 'all',
        name = 'foo'
    )
    from ansible.playbook.task_include import TaskInclude
    t = HandlerTaskInclude(block=None, role=None, task_include=TaskInclude())
    h = t.check_options(t.load_data(data), data)
    assert h.task_include.static is True
    assert h.task_include.include == 'foo.yml'

# Generated at 2022-06-11 10:05:05.299025
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:05:11.210221
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.host import Host
    print("Running test_HandlerTaskInclude()")
    # Code for some hosts
    hosts = [Host(name="test_host", port=100, variables=dict())]
    # Get a handler
    handler1 = HandlerTaskInclude.load(
        data={'name': AnsibleUnicode('yay')},
        role='test_role',
        loader=None,
        hosts=hosts,
        variable_manager=None,
        block=''
    )
    # Check the result
    assert(isinstance(handler1, HandlerTaskInclude))
    assert(handler1.name == 'yay')
    assert(handler1.role == 'test_role')

# Generated at 2022-06-11 10:05:12.055336
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler != None

# Generated at 2022-06-11 10:05:22.817583
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data_valid = {
        'handlers': [
            {
                'include': 'zebra.yml',
                'name': 'zebra-handler'
            }
        ]
    }
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.block import Block
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    path_to_yaml = '../tests/integration/inventory/inventory.yml'
    inventory = InventoryManager(loader=loader, sources=[path_to_yaml])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:05:30.685160
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': 'ping.yml',
        'listen': 'start_server',
        'ignore_errors': False,
        'static': 'yes',
        'tags': ['some_tag', 'another_tag']
    }

    host = "localhost"
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = "loader"

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler.name == "include"
    assert handler.args == data
    assert handler.block == block
    assert handler.task_include == task_include

# Generated at 2022-06-11 10:05:41.950941
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.template.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    vars_manager = VariableManager()
    my_vars = {'myvar': 'myvalue', 'myvar2': 'myvalue2'}

# Generated at 2022-06-11 10:05:47.125409
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include.__class__.__name__ == 'HandlerTaskInclude'
    assert handler_task_include.VALID_INCLUDE_KEYWORDS == frozenset(['roles', 'tasks', 'handlers', 'listen'])
    assert handler_task_include.attribute_name == 'handlers'
    assert handler_task_include.role is None
    assert handler_task_include.task_include is None
    assert handler_task_include.include_role is None
    assert handler_task_include.include_task is None
    assert handler_task_include.include_file is None

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-11 10:05:52.616678
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    fake_data = None
    fake_block = None
    fake_role = None
    fake_task_include = None
    fake_variable_manager = None
    fake_loader = None
    handler = HandlerTaskInclude.load(fake_data, block=fake_block, role=fake_role,
                                      task_include=fake_task_include,
                                      variable_manager=fake_variable_manager, loader=fake_loader)
    assert isinstance(handler, HandlerTaskInclude)


# vim: ai sts=4 et sw=4