

# Generated at 2022-06-11 09:57:03.238789
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:57:13.640668
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    host = 'host'
    handler = 'handler'
    port = '22'
    user = 'user'
    password = 'pwd'
    host_info = {'host': host, 'port': port, 'user': user, 'password': password}
    hosts = []
    hosts.append(host_info)

    task = 'task'

    # Initialized the handler(task) for task, all the tasks have only one handler
    handler_task = HandlerTaskInclude(side_effect_handler=hosts, tasks=[task])

    # Test get_handler_list
    assert handler_task.get_handler_list() == [task]

    # Test get_handler_name
    assert handler_task.get_handler_name() == task

    # Test get_original_item
    assert handler_task.get_original_item

# Generated at 2022-06-11 09:57:16.831432
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ht = HandlerTaskInclude()
    assert isinstance(ht, HandlerTaskInclude)
    assert isinstance(ht, Handler)
    assert isinstance(ht, TaskInclude)


# Generated at 2022-06-11 09:57:18.976573
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert(handler_task_include.__class__.__name__ == 'HandlerTaskInclude')

# Generated at 2022-06-11 09:57:25.773069
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import json
    import os
    import sys
    import tempfile

    from ansible.plugins import module_loader, action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.shlex import shlex_split
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a 'fake' inventory
    hosts_dict = {
        'example_host': {
            'hosts': ['fake_example_host']
        }
    }
    inventory = InventoryManager(loader=DataLoader())
    inventory.add_group('all')

# Generated at 2022-06-11 09:57:30.446793
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """ constructor test """

    handler1 = HandlerTaskInclude()
    assert handler1 is not None

    handler2 = HandlerTaskInclude(block=None)
    assert handler2 is not None

    handler3 = HandlerTaskInclude(block="all")
    assert handler3 is not None

    handler4 = HandlerTaskInclude(block="main")
    assert handler4 is not None
    

# Generated at 2022-06-11 09:57:31.420874
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler == None

# Generated at 2022-06-11 09:57:37.822893
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="test",
        action="test_action",
        listen="test_listen"
    )
    block = dict()
    role = dict()
    task_include = dict()
    variable_manager = dict()
    loader = dict()
    expected_handler = dict(
        name="test",
        action="test_action",
        listen="test_listen"
    )
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert handler == expected_handler

# Generated at 2022-06-11 09:57:47.618281
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    task_include = dict(
        name='test'
    )
    data = dict(
        name='name',
        tags='tags',
        when='when',
        delegate_to='delegate_to',
        remote_user='remote_user',
        connection='connection',
        sudo='sudo',
        sudo_user='sudo_user',
        gather_facts='gather_facts',
        any_errors_fatal='any_errors_fatal',
        serial='serial',
        ignore_errors='ignore_errors',
        listen='listen',
        include='include',
        run_once='run_once'
    )

    hti = HandlerTaskInclude(task_include=task_include, block=None, role=None)

# Generated at 2022-06-11 09:57:48.238942
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:57:51.419126
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert test is not None

# Generated at 2022-06-11 09:57:53.459915
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'test.yml',
        'tags': ['tag1', 'tag2']
    }

# Generated at 2022-06-11 09:58:02.001244
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.plugins.loader import action_loader
    from ansible.utils import context_objects as co
    fh = open('../../ansible/modules/system/ping.py', 'r')
    lines = fh.read()
    fh.close()
    module = action_loader._get_module_class('ping', lines)
    setattr(module, '_uses_shell', False)
    setattr(module, '_uses_must_pass', False)
    setattr(module, '_uses_module_implementation', False)
    h = Host()
    h.set_variable('inventory_hostname', 'localhost')
    inven = co.GlobalVars({'some_var': 1})
    h.set_variable_manager(inven)
    data

# Generated at 2022-06-11 09:58:06.131805
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name='test',
        file='test.yaml',
        action='include',
        when='1 == 2'
    )
    handler = HandlerTaskInclude.load(data)
    assert handler.name == 'test'
    assert handler.action == 'include'
    assert handler.when == '1 == 2'

# Generated at 2022-06-11 09:58:06.962859
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
#    handler = HandlerTaskInclude()

# Generated at 2022-06-11 09:58:11.284214
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    h = HandlerTaskInclude.load(dict(name="handlername", debug=True, listen='foo'))
    assert h.get_name() == "handlername"
    assert h.get_action() is None
    assert h.get_tags() == []
    assert h.get_when() is None
    assert h.get_listen() == 'foo'
    assert h.get_loop() is None
    assert h.get_notify() == []

# Generated at 2022-06-11 09:58:13.712158
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('TESTING HandlerTaskInclude')
    obj_handler_task_include = HandlerTaskInclude()
    print('[HANDLER TASKINCLUDE] --> {}'.format(obj_handler_task_include.load()))

# Generated at 2022-06-11 09:58:16.768214
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test hosts
    block = None
    role = None
    task_include = None
    test_obj = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    assert test_obj.name == ""


# Generated at 2022-06-11 09:58:23.738756
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    for h in [
        dict(
            name='test',
            listen='test',
            tasks=[
                dict(action=dict(module='debug', msg='ok'))
            ]
        ),
        dict(
            name='test',
            listen='test',
            tasks=[
                dict(debug=dict(msg='ok'))
            ]
        )
    ]:
        block = Block()

        task = Task.load(
            h,
            block=block
        )

        assert 1 == len(block.block)

# Generated at 2022-06-11 09:58:32.843546
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # HandlerTaskInclude is subclass of Handler and TaskInclude.
    assert issubclass(HandlerTaskInclude, Handler)
    assert issubclass(HandlerTaskInclude, TaskInclude)

    # HandlerTaskInclude constructor should have the same number of parameters of superclass Handler
    # Handler(name, block=None, role=None, task_include=None)
    assert len(Handler.__init__.__code__.co_varnames) == len(HandlerTaskInclude.__init__.__code__.co_varnames)

    # HandlerTaskInclude constructor should have the same number of parameters of superclass TaskInclude
    # TaskInclude(block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-11 09:58:37.651482
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # assert isinstance(HandlerTaskInclude(), Handler) and \
    #        isinstance(HandlerTaskInclude(), TaskInclude)
    pass

# Test load method

# Generated at 2022-06-11 09:58:46.093740
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = [
        "action: setup",
        "listen: check_pack",
    ]
    t = HandlerTaskInclude()
    handler = t.load(data)

    assert handler.name == "check_pack"
    assert handler.action == { 'action': "setup" }
    assert handler.include == None
    assert handler.loop is None
    assert handler.name == "check_pack"
    assert handler.notify ==  []
    assert handler.tags == []
    assert handler.when == None
    assert handler.when_reversed == False
    assert handler.loop_control == {}
    assert handler.always_run == False
    assert handler.delegate_to == None
    assert handler.transport == None
    assert handler.register == None
    assert handler.loop_with_items == None

# Generated at 2022-06-11 09:58:47.253689
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load('data', 'block', 'role', 'task_include')

# Generated at 2022-06-11 09:58:51.987356
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: This test should be much more thorough, but I need to figure out how to mock the call to super().load_data
    # with Monkeypatch or Mock.
    variable_manager = "foo"
    loader = "bar"
    data = dict(
        include_tasks="baz.yml"
    )
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert handler.filename == "baz.yml"

# Generated at 2022-06-11 09:59:00.065802
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    b = Block(play=Play().load({'name': 'foobar'}))
    t = HandlerTaskInclude(block=b, task_include=RoleInclude().load({'name': 'example'}))
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 09:59:07.538280
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test method load in ansible.playbook.handler_task_include
    """
    import copy
    import sys

    # Required in test
    from ansible.errors import AnsibleParserError
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.unicode import unicode_wrap

    # set test values
    task_include_name = 'include_tasks'
    task_include_data = dict(
        name='helloworld',
        static='static',
        static2='static2'
    )

    # Get object based on class HandlerTaskInclude
    handler_task_include = HandlerTaskInclude()

    # Get attributes and methods
    attrs_methods = dir(HandlerTaskInclude)

    # print

# Generated at 2022-06-11 09:59:15.824120
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    host_1 = Host(name="host_1")
    host_2 = Host(name="host_2")
    group_1 = Group(name="group_1")
    group_1.add_host(host_1)
    group_1.add_host(host_2)
    group_1.push(host_1, 'test', 'a')
    group_1.push(host_2, 'test', 'b')
    inventory = Inventory(loader=DataLoader())
    inventory.add_group(group_1)

    variable_manager = VariableManager()
    variable

# Generated at 2022-06-11 09:59:23.038267
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include_tasks': "{{ role_path }}/foo.yml",
        'vars': {'variable_one': '1'},
        'vars_prompt': {'variable_two': '3'},
        'vars_files': {'variable_three': '3'},
        'listen': 'test'
    }
    vars = {}
    h = HandlerTaskInclude(variable_manager=vars, loader=None)
    assert h.include == "{{ role_path }}/foo.yml"
    assert h.vars == {'variable_one': '1'}
    assert h.vars_prompt == {'variable_two': '3'}
    assert h.vars_files == {'variable_three': '3'}
    assert h.list

# Generated at 2022-06-11 09:59:31.247018
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.utils.listify_paths import listify_paths
    from ansible.module_utils.parsing.convert_bool import boolean

    class Object(object):
        pass

    m_task = Object()
    m_task.block = Block()
    m_task.block.vars = Object()
    m_task.block.vars.hostvars

# Generated at 2022-06-11 09:59:40.225283
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import json
    import sys
    import copy

    # -----
    # Setup
    # -----

    # Setup for this unit test
    #
    # These files are generated during one run of ``ansible-playbook``
    # and are saved in this repo for checking output or test purposes.

    # Read the environment variables set in Makefile
    script_dir = os.getenv('script_dir')
    project_dir = os.getenv('project_dir')

    # Set the absolute path to ``test_data`` and ``test_output`` folder
    test_data_dir = os.path.join(script_dir, "test_data")
    test_output_dir = os.path.join(script_dir, "test_output")

    # Create the path to the input file for this unit test
    test_input_

# Generated at 2022-06-11 09:59:52.283077
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader, variable_manager, 'localhost')
    variable_manager.set_inventory(inventory)

    task = Task()
    task._role = None
    task._block = None
    task.vars = dict(a=10, b=20)
    task.host_vars = dict(a=1, b=2)
    task.host = "localhost"


# Generated at 2022-06-11 10:00:01.910120
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    unit-test:
    test:
    - name: 1
      listen: "copy"
      include: "copy.yml"
      tags:
      - debug
      - copy
    '''
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variables = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-11 10:00:10.851438
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    my_loader = DataLoader()
    my_inventory = InventoryManager(loader=my_loader, sources=['my_hosts'])
    my_variable_manager = VariableManager(loader=my_loader, inventory=my_inventory)
    my_play_context = PlayContext()
    my_play_context.variable_manager = my_variable_manager

    my_block = Block()
    my_block.play_context = my_play_context
   

# Generated at 2022-06-11 10:00:14.023105
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {"name": "task1"}
    task_include = TaskInclude()
    block = []
    role = None
    try:
        Handler.load(data, block, role, task_include)
    except :
        print("test failed")

    print("test success")

# Generated at 2022-06-11 10:00:15.215595
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert isinstance(HandlerTaskInclude(), HandlerTaskInclude)


# Generated at 2022-06-11 10:00:17.196977
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'listen', 'include', 'tasks', 'vars', 'handlers', 'pre_tasks'}

# Generated at 2022-06-11 10:00:25.576078
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    INVENTORY = {
        "server": {
            "hosts": [
                "server1"
            ],
            "vars": {
                "greeting": "Hello"
            }
        },
        "client": {
            "hosts": [
                "client1"
            ],
            "vars": {
                "greeting": "Howdy"
            }
        }
    }

# Generated at 2022-06-11 10:00:32.388882
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert issubclass(HandlerTaskInclude, Handler)
    assert issubclass(HandlerTaskInclude, TaskInclude)

    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)

    # Test 1: Check the VALID_INCLUDE_KEYWORDS of HandlerTaskInclude
    assert handler_task_include.VALID_INCLUDE_KEYWORDS.__contains__("listen")

    # Test 2: Check the load method
    assert isinstance(HandlerTaskInclude.load(None, None, None, None, None, None), HandlerTaskInclude)

# Generated at 2022-06-11 10:00:40.824660
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        listen='all',
        name='all is well',
        handler='{{ test_handler_path }}'
    )

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    import tempfile

    with tempfile.NamedTemporaryFile(delete=False) as fh:
        fh.write('#!/usr/bin/python\n# ignore me...')
        fh.close()

        mock_loader = Mock(file_name=fh.name)
        mock_loader.get_basedir.return_value = '/home/test/roles/foo/'
        mock_variable_manager = Mock()

# Generated at 2022-06-11 10:00:48.250990
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskIncludeArgs

    from ansible.playbook.play_context import PlayContext

    from collections import namedtuple
    from ansible.vars.manager import VariableManager

    # Mock data

# Generated at 2022-06-11 10:00:59.349034
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load({}, {})

# Generated at 2022-06-11 10:01:01.287906
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'include': 'foobar', 'foo': 'bar'}
    assert HandlerTaskInclude.load(data=data) is not None



# Generated at 2022-06-11 10:01:02.276883
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    obj = HandlerTaskInclude()
    assert isinstance(obj, HandlerTaskInclude)

# Generated at 2022-06-11 10:01:10.001741
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        from ansible.playbook.play_context import PlayContext
        from ansible.vars import VariableManager
    except ImportError as e:
        import sys
        sys.modules[__name__].__dict__.pop('_ansible_test_dont_write_bytecode')
        del e
        from ansible.playbook.play_context import PlayContext
        from ansible.vars import VariableManager

    import copy
    import sys
    import datetime
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play


# Generated at 2022-06-11 10:01:17.085467
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  from ansible.vars import VariableManager
  from ansible.inventory import Inventory
  from ansible.parsing.dataloader import DataLoader
  test_HandlerTaskInclude = HandlerTaskInclude()
  loader = DataLoader()
  inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost')
  test_HandlerTaskInclude.load(data = 'test_HandlerTaskInclude',block = 'test_HandlerTaskInclude',role = 'test_HandlerTaskInclude',task_include = 'test_HandlerTaskInclude',variable_manager = inventory.get_variable_manager(),loader = loader)

# Generated at 2022-06-11 10:01:18.286095
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None 


# Generated at 2022-06-11 10:01:21.027930
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # obj = HandlerTaskInclude()
    # obj.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert True == True # TODO: implement your test here


# Generated at 2022-06-11 10:01:27.795049
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Note: no skip or condationals
    # data, meta
    assert HandlerTaskInclude.load({'include': 'vars/some.yml'})
    assert HandlerTaskInclude.load({'include': 'vars/some.yml', 'name': 'hello'})
    assert HandlerTaskInclude.load({'include': 'vars/some.yml', 'with_items': "{{ items }}"})
    assert HandlerTaskInclude.load({'include': 'vars/some.yml', 'with_items': "{{ items }}", 'loop_control': {'loop_var': 'item'}})

# Generated at 2022-06-11 10:01:30.394781
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(name='task_name', block=None, role=None, task_include=None)
    assert t.name == 'task_name'

# Generated at 2022-06-11 10:01:30.929709
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 10:01:51.811334
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:02:00.585402
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    block = Block()
    block.vars.update({'var1': 'foo'})
    block.vars.update({'var2': 'bar'})

    task_include = Task()
    data = {'block': block,
            'role': None,
            'task_include': task_include,
            'var1': 'foo',
            'var2': 'bar',
            'var3': None,
            'var4': None,
            'listen': None
           }
    handler = HandlerTaskInclude(data['block'], data['role'], data['task_include'])
    assert handler.block == data['block']
    assert handler.role

# Generated at 2022-06-11 10:02:02.518802
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    t = HandlerTaskInclude()

    data = {'name': 'test',
            'include': 'somefile'}
    t.load(data)

# Generated at 2022-06-11 10:02:11.026504
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    print("HandlerTaskInclude.load")

    handler = HandlerTaskInclude.load(
        {
            'include': 'included.yml',
            'static': '/etc/hosts',
            'loop': 'all',
            'loop_control': {
                'loop_var': 'item'
            },
            'tags': ['tag1', 'tag2'],
            'register': 'result_of_included_file'
        },
        loader=None,
        variable_manager=None
    )

    assert handler.static == '/etc/hosts'
    assert handler.loop == 'all'
    assert handler.tags == ['tag1', 'tag2']
    assert handler.register == 'result_of_included_file'
    assert handler.loop_control.loop_var == 'item'
    assert handler

# Generated at 2022-06-11 10:02:13.038711
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'handler': 'test.yaml'}
    handler = HandlerTaskInclude.load(data)


if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-11 10:02:15.367246
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        HandlerTaskInclude(role="role", block="block")
    except:
        assert False, "Fails to create a HandlerTaskInclude"
    assert True


# Generated at 2022-06-11 10:02:15.891102
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 10:02:21.496001
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'name': 'foo',
        'include': 'bar',
        'static': ['foo.yaml']
    }
    handler = HandlerTaskInclude(data=data)
    assert handler.name == 'foo'
    assert handler.include_role == None
    assert handler.include_tasks == 'bar'
    assert handler.exclude_tasks == []
    assert handler.include_vars == []
    assert handler.include_files == []
    assert handler.include_handler == []
    assert handler.tags == []
    assert handler.when == None

# Generated at 2022-06-11 10:02:22.657762
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Here is a good test case (when we have implemented it)
    pass

# Generated at 2022-06-11 10:02:31.255188
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    h = HandlerTaskInclude()
    d = {'hosts': 'a'}
    h.load(d)
    assert d.get('hosts') == 'a'
    assert d.get('ignore_errors') == False
    assert d.get('become') == False
    assert d.get('become_user') == 'root'
    assert d.get('sudo') == True
    assert d.get('sudo_user') == 'root'
    assert d.get('remote_user') == 'root'
    assert d.get('connection') == 'smart'
    assert d.get('gather_facts') == True
    assert d.get('name') == 'a'
    assert d.get('when') == []
    assert d.get('tags') == []
