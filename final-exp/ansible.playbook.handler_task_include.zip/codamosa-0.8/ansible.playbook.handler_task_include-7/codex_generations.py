

# Generated at 2022-06-11 09:57:06.650908
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = { "include": "mytaskfile" }
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    hti = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert hti is not None
    assert hti.get_name() == 'mytaskfile'


# Generated at 2022-06-11 09:57:17.259922
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = HandlerTaskInclude()

    import unittest
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block

# Generated at 2022-06-11 09:57:21.492621
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: Make unit test
    # data = ""
    # block = ""
    # role = ""
    # task_include = ""
    # variable_manager = ""
    # loader = ""
    # assert HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader) ==

    pass

# Generated at 2022-06-11 09:57:26.886272
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti is not None
    assert hti.__class__.__name__ == 'HandlerTaskInclude'
    # assert hti.block is not None
    # assert hti.role is not None
    # assert hti.task_include is not None
    assert hti.handler_include is None
    assert hti.module_name is None
    assert hti.module_args is None
    assert hti.module_vars is None
    assert hti.register is None
    assert hti.ignore_errors is None
    assert hti.only_if is None
    assert hti.loop is None
    assert hti.when is None
    assert hti.run_once is None
    assert hti.notify is None
    assert hti.delegate_to is None

# Generated at 2022-06-11 09:57:28.741205
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    testHandlerTaskInclude = HandlerTaskInclude()
    assert testHandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {"listen"}

# Generated at 2022-06-11 09:57:29.621121
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude()

# Generated at 2022-06-11 09:57:33.071712
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    values = hti.load({'type': 'task', 'args': {'a': 'b'}})
    assert values['args']['type'] == 'task', "Invalid type"
    assert values['args']['a'] == 'b', "Invalid args values"



# Generated at 2022-06-11 09:57:33.959691
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ti=HandlerTaskInclude()

# Generated at 2022-06-11 09:57:43.830324
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    c = HandlerTaskInclude()
    c.block = None
    c.role = None
    c.task_include = None

    variable_manager = VariableManager()
    variable_manager.set_inventory(mock_Inventory())
    variable_manager.extra_vars = dict()

    data = dict(
        include='test_play.yml'
    )

    # the method needs a PlayContext object
    c.play_context = PlayContext()
    # ...and a templar for the include tasks
    c.templar = Templar(loader=None, variables=variable_manager)

    # two files are loaded with the loader:
    # - test_play.

# Generated at 2022-06-11 09:57:45.675916
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handlerTaskInclude is not None

# Generated at 2022-06-11 09:57:49.918973
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    print('HandlerTaskInclude: {0}'.format(hti))

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-11 09:57:51.469791
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HATI = HandlerTaskInclude()


# Generated at 2022-06-11 09:57:59.961462
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude

    import unittest2 as unittest

    class HandlerTaskIncludeTestCase(unittest.TestCase):

        def setUp(self):
            pass

        def test_HandlerTaskInclude(self):
            ri = RoleInclude()
            block = Block(role=ri)
            data = Base().load_data({'name': 'test'}, variable_manager=None, loader=None)
            handler = HandlerTaskInclude(block=block, task_include=None).load_data(data, variable_manager=None, loader=None)

# Generated at 2022-06-11 09:58:00.524669
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:58:08.034791
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    handler_data = dict(
        name = 'all',
        listen = 'restart apache2'
    )
    handler = HandlerTaskInclude.load(handler_data, loader=loader)
    assert handler._attributes['name'] == 'all'
    assert isinstance(handler._attributes['name'], AnsibleUnicode)
    assert handler._attributes['listen'] == 'restart apache2'
    assert isinstance(handler._attributes['listen'], AnsibleUnicode)

# Generated at 2022-06-11 09:58:13.565824
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    import os
    import yaml
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join('..', 'files' , 'handler.yml'), 'r') as f:
        handler = yaml.safe_load(f)
    variable_manager = VariableManager(loader=None, inventory=None)

# Generated at 2022-06-11 09:58:22.201936
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def mocked_load_data(*args, **kwargs):
        return {}

    data = {
        'a': 'b',
        'c': 'd'
    }
    task_include = MagicMock()
    task_include.return_value = task_include
    task_include.load_data.side_effect = mocked_load_data
    variable_manager = MagicMock()
    variable_manager.return_value = variable_manager
    variable_manager.get_vars.return_value = {}
    loader = MagicMock()
    loader.return_value = loader
    loader.get_basedir.return_value = ''

    # Testing with valid parameter
    handler = HandlerTaskInclude.load(data, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 09:58:25.193642
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Testing Constructor using default values
    default_handler = HandlerTaskInclude( block=None, role=None, task_include=None)
    assert not default_handler.block
    assert not default_handler.role
    assert not default_handler.task_include




# Generated at 2022-06-11 09:58:27.515305
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    t.load({'handler': 'main.yml'})
    print('Invoke method load of class HandlerTaskInclude')

# Generated at 2022-06-11 09:58:30.322232
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    obj = HandlerTaskInclude(block=None, role=None, task_include=None)
    obj.load(data={}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-11 09:58:33.834283
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude



# Generated at 2022-06-11 09:58:34.572720
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO
    pass

# Generated at 2022-06-11 09:58:41.176638
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Mocking data
    # TODO: use real data
    data = {
        'handler': {
            'listen': 'My listen',
            'name': 'My name',
            'include': 'My include',
            'tags': 'My tag'
        }
    }

    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    assert handler.listen == 'My listen'
    assert handler.name == 'My name'
    assert handler.tags == ['My tag']
    # TODO: assert handler has the same type of task_include

# Generated at 2022-06-11 09:58:43.594732
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler = HandlerTaskInclude.load(
        data={
            'include': 'some_include',
            'listen': 'some_listen'
        }
    )

    print(handler.handler_name)

# Generated at 2022-06-11 09:58:49.074754
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: create a method in test/utils or somwhere else that return a boolean if
    # the test has been correctly implemented. (e.g. return True/False)
    # Then this test should be deleted.
    data = {
        'include': 'hello.yml',
        'static': 'all',
        'files': '*.txt',
        'name': 'test_include',
        'tags': ['tag1'],
    }
    HandlerTaskInclude.load(data)

# Generated at 2022-06-11 09:58:57.115030
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import become_loader, connection_loader, callback_loader, action_loader

    hosts = [Host(name="host1",
                  port=22,
                  vars=dict(ansible_ssh_host="localhost"),
                  groups=[Group(name="ungrouped")])]

    v_m = VariableManager(loader=None,hosts=hosts)

    v_m.set_host_variable(hosts[0], "foo", "bar")

    data = {"include6": "foobar", "include6_with_vars": "foobar2"}

    # need to test this by mocking
    # handler = HandlerTaskInclude.load(data, variable

# Generated at 2022-06-11 09:59:03.136658
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.include is None
    assert handler._parent_role is None
    assert handler.owner is None
    assert handler.name is None
    assert handler.notify is None
    assert handler.listen is None
    assert handler.when is None
    assert handler.only_if is None
    assert handler.changed_when is None
    assert handler.failed_when is None


# Generated at 2022-06-11 09:59:06.082888
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = '''
- name: handler task include
  include: tasks/{{ item }}
  with_items:
    - foo
    - bar
'''
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler.load(data)

# Generated at 2022-06-11 09:59:09.527467
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'my_role',
        'listen': 'my_role_listen',
    }

    handler = HandlerTaskInclude.load(data)

    assert handler.listen == 'my_role_listen', 'Should be equivalent'
    assert handler.include == 'my_role', 'Should be equivalent'

# Generated at 2022-06-11 09:59:17.512957
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleParserError

    block_data = dict(
        tasks=[
            dict(
                action=dict(
                    module='shell',
                shell='/usr/bin/uptime',
                )
            )
        ]
    )


# Generated at 2022-06-11 09:59:26.126813
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude("test_data", "test_block", "test_role", "test_task_include")
    assert handler != None
    assert handler.block == "test_block"
    assert handler.role == "test_role"
    assert handler.task_include == "test_task_include"
    # TODO


# Generated at 2022-06-11 09:59:34.377076
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test no error values in data
    data = dict()
    data["block"] = 'main'
    data["role"] = 'foobar'
    t = HandlerTaskInclude(block='main', role='foobar')

    data["include"] = dict()
    data["include"]["foo"] = "bar"
    result = t.load(data)
    assert result["include"] == dict()

    # Test values with no error
    data = dict()
    data["block"] = 'main'
    data["role"] = 'foobar'
    t = HandlerTaskInclude(block='main', role='foobar')

    data["include"] = dict()
    data["include"]["foo"] = "bar"
    data["include"]["bar"] = "foo"
    data["tags"] = "foobar"
   

# Generated at 2022-06-11 09:59:45.662581
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a host
    host = Host("127.0.0.1")

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=DataLoader(), sources=('127.0.0.1,',)))

    # Create a HandlerTaskInclude and include a task
    handler_task_include = HandlerTaskInclude.load({'include': 'file'}, host, variable_manager=variable_manager, loader=DataLoader())
    handler_task_included = handler_task_include.task_included.copy()
    handler_task_in

# Generated at 2022-06-11 09:59:48.323795
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert False, "TODO"

# Generated at 2022-06-11 09:59:55.249245
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "include": {
            "name": "test-include",
            "hosts": "hosts-test"
        }
    }
    loader_mock = None
    block_mock = None
    role_mock = None
    variable_manager_mock = None
    task_include_mock = None
    handler = HandlerTaskInclude.load(data, block=block_mock, role=role_mock, task_include=task_include_mock, variable_manager=variable_manager_mock, loader=loader_mock)
    assert handler.include is not None

# Generated at 2022-06-11 10:00:04.519446
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-11 10:00:13.434636
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple

    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-11 10:00:21.590078
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    # Path to source yaml files
    source = os.path.join(os.path.dirname(__file__), '../../../test/unit/playbook/data/handler')

    # Data to be passed to method load of class HandlerTaskInclude
    action_plugin_path = ['../../../plugins/actions']
    action_loader.add_directory(action_plugin_path[0])
    variable_manager = VariableManager()
    loader = DataLoader()
    
    for file_name in os.listdir(source):
        data = {}

        # All include keywords are loaded in dictionary data

# Generated at 2022-06-11 10:00:28.235884
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # data = dict()
    # t = HandlerTaskInclude(block=None, role=None, task_include=None)
    # handler = t.check_options(
    #     t.load_data(data, variable_manager=None, loader=None),
    #     data
    # )
    # handler = HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    h = HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert h is not None

# Generated at 2022-06-11 10:00:37.261549
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.task_include
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    group = Group('all')
    host = Host(name='localhost')
    group.add_host(host)
    inventory.add_group(group)
    var_mgr = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:00:47.929314
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:00:49.493568
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(role="test.yml", task_include="test.yml")
    if handler:
        pass


# Generated at 2022-06-11 10:00:54.220849
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Load the FakeTaskInclude data into the class
    """
    #create a fake data
    fake_data = {
        'listen': 'test-tag',
        'include': 'test_file'
    }

    # create a FakeTaskInclude class.
    handler = HandlerTaskInclude.load(fake_data)

    # check its attribute
    assert handler.listen is not None
    assert handler.listen == 'test-tag'
    assert handler._role is None
    assert isinstance(handler._block, type(None))

# Generated at 2022-06-11 10:01:01.017573
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="dummy_handler",
        listen="dummy_event",
        local_action="shell echo 'hello'"
    )
    handler = HandlerTaskInclude.load(data)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'
    assert handler._candidate_fqcn == 'ansible.playbook.handler.HandlerTaskInclude'
    assert handler._name == 'dummy_handler'
    assert handler._block == None
    assert handler._role == None
    assert handler._task_include == None
    assert handler._tags == set()
    assert handler._when == set()
    assert handler._notify is None
    assert handler._notified_by == set()
    assert handler._loop == None
    assert handler._loop_args == dict()
    assert handler._listen

# Generated at 2022-06-11 10:01:08.023376
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_fail import TaskFail
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    included_file1 = IncludedFile(
        filename="/A/B/C/tasks/main.yml",
        first_line_in_structure=5,
        args={'first_task': True},
        parent_block=None
    )

# Generated at 2022-06-11 10:01:12.245343
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = None
    data = '{"include": "my-handler.yml"}'

    handler = HandlerTaskInclude.load(data)
    print(handler)
    #assert handler.__class__.__name__ == 'Handler'

# Main method for testing

# Generated at 2022-06-11 10:01:20.739703
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager

  play_context = dict(
    network_os='ios',
    become=False,
    become_method=None,
    become_user=None,
    check=False,
    diff=False,
    verbosity=0,
    listhosts=None,
    listtasks=None,
    listtags=None,
    syntax=None,
    sudo_user='jarryd',
    remote_user='jarryd',
  )

  group = dict(
    all={
      'hosts': {
        'r1': dict(
          ansible_host='192.168.0.1',
          ansible_network_os='ios'
        )
      }
    }
  )
  groups

# Generated at 2022-06-11 10:01:25.566268
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    val = dict(
        include=dict(
            role=dict(name='master'),
            tasks=dict(foo='Some module to run')
        )
    )
    handler = HandlerTaskInclude.load(val)
    if hasattr(handler, 'tasks') and isinstance(handler.tasks, list):
        print('Pass')
    else:
        raise AssertionError('Failed')

# Generated at 2022-06-11 10:01:26.447302
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 10:01:26.925047
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:01:55.244093
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    block = None
    role = "test_role"
    task_include = TaskInclude()

    myhost = Host()
    myhost.name = "localhost"
    myhost.set_variable("var1", "val1")
    myhost.set_variable("var2", "val2")


# Generated at 2022-06-11 10:02:04.387105
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    import os
    import yaml

    filename = os.path.join(os.path.dirname(__file__), '../../../../../examples/handlers/main.yml')
    with open(filename, 'r') as stream:
        file_content = yaml.safe_load(stream)

# Generated at 2022-06-11 10:02:12.562845
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host = Host(name="test")
    group = Group(name="test")
    variable_manager = VariableManager()
    loader = DataLoader()

    task_include_data = dict(name="test")

    task_include = HandlerTaskInclude.load(
        task_include_data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader,
    )

    assert isinstance(task_include, TaskInclude)
    assert isinstance(task_include, Handler)

# Generated at 2022-06-11 10:02:20.396713
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    mock_obj1 = {}
    mock_obj2 = {}
    mock_obj3 = {}
    mock_obj4 = {}
    mock_obj5 = {}

    # HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    HandlerTaskInclude.load(mock_obj1)
    HandlerTaskInclude.load(mock_obj2, block=mock_obj3)
    HandlerTaskInclude.load(mock_obj4, block=mock_obj5, role=mock_obj1)
    HandlerTaskInclude.load(mock_obj2, block=mock_obj3, role=mock_obj4, task_include=mock_obj5)

# Generated at 2022-06-11 10:02:22.553668
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """Check that we can call the method load of class HandlerTaskInclude"""
    print("Test load of class HandlerTaskInclude")
    tt = HandlerTaskInclude()
    data = {}
    tt.load(data)

# Generated at 2022-06-11 10:02:23.826566
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    print(handler_task_include)

# Generated at 2022-06-11 10:02:32.329947
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict()
    data['hosts'] = 'aHost1'
    data['vars'] = dict()
    data['vars']['var1'] = 1  # note: value must be same type as variable being set
    data['tasks'] = 'listen'
    data['tasks']['listen'] = 'var1/a/b/c'

    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    assert handler is not None
    assert handler.hosts == 'aHost1'
    assert handler.vars == {'var1': 1}
    assert handler.tasks == 'var1/a/b/c'
    assert handler.name == 'listen'

# Generated at 2022-06-11 10:02:41.466823
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    #from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    #from ansible.playbook.role import Role
    #from ansible.playbook.role_include import RoleInclude
    #from ansible.playbook.handler import Handler
    from ansible.plugins.callback import CallbackBase

    options = None

# Generated at 2022-06-11 10:02:42.274063
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True == False, "Not implemented"

# Generated at 2022-06-11 10:02:49.758469
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os

    from ansible.inventory.manager import InventoryManager

    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import find_plugin_filepaths
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
   

# Generated at 2022-06-11 10:03:36.671460
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h=HandlerTaskInclude()
    assert h.VALID_INCLUDE_KEYWORDS == set(['listen','role','tasks','task','name','import_role','include','import_tasks','vars','files','with_items','block','blockinfile','local_action','tags','ignore_errors','ignore_unavailable','register','loop','loop_control','delegate_to','until','run_once','serial','notify','when','async','poll','failed_when','changed_when','environment'])

# Generated at 2022-06-11 10:03:38.344713
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    data = {
        'include': 'foo.yml',
    }
    t.load(data)

# Generated at 2022-06-11 10:03:45.400816
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from test.unit.mock.loader import DictDataLoader

    variable_manager = DictDataLoader()

    # test 
    task_include = Task()
    block = Block()
    block.vars = {
        'foo': 'bar'
    }

    data = [{
        'foo': 'bar',
        'include': 'tasks/test.yml',
    }]

    handler = HandlerTaskInclude.load(data, block, role=None, task_include=task_include, variable_manager=variable_manager, loader=DictDataLoader())
    assert handler is not None
    assert handler.name == 'tasks/test.yml'

# Generated at 2022-06-11 10:03:51.187972
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Check the option of HandlerTaskInclude
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'with_items', 'ignore_errors', 'delegate_to', 'with_fileglob', 'with_sequence', 'with_first_found', 'loop_control', 'register', 'with_subelements', 'with_nested', 'with_random_choice', 'with_flattened', 'with_together', 'with_inventory_hostnames', 'with_dict', 'when', 'when_no_match', 'with_subelements', 'ignore_errors', 'with_fileglob', 'with_first_found', 'when', 'when_no_match', 'with_subelements', 'listen'}

# Generated at 2022-06-11 10:03:58.209973
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_host = Host(name="myhost", port=2)

    data = dict(
        include='/home/ansible/play.yml',
        # include='/home/ansible/play.yml'  # task_include won't execute the play
        name='second play',
        listen='',
        connection='local',
    )
    block = Block(
        parent=None,
        role=None,
        task_include=TaskInclude(),
        use_handlers=False,
        handlers=None
    )
    role = my_host.get_vars()["ansible_role"]

    task_include = TaskInclude(block=block, role=role)

    handler = HandlerTaskInclude(
        block=block, role=role, task_include=task_include
    )
    handler_

# Generated at 2022-06-11 10:03:58.649847
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:04:05.721275
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    liste_vars_sed_no_action = '''{
                "_raw_params": "sed -i \"s/e/f/g\" /home/manny/file; rm file", 
                "_uses_shell": true, 
                "action": "command", 
                "args": {
                    "_raw_params": "sed -i \"s/e/f/g\" /home/manny/file; rm file", 
                    "_uses_shell": true
                }
            }'''
     
    # liste_vars_when_not_present = '''{
    #             "action": "command", 
    #             "args": {
    #                 "_raw_params": "ls /home/manny/b", 
    #                 "_uses_shell": true
    #             }, 
    #

# Generated at 2022-06-11 10:04:06.525755
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  assert False, "No test"

# Generated at 2022-06-11 10:04:07.624807
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:04:14.872531
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    constructor_test = HandlerTaskInclude()
    assert constructor_test

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="localhost,")
    variable_manager.set_inventory(inventory)
    default_handler_data = dict( include = 'some_handler_name.yaml')
    default_handler = HandlerTaskInclude.load(default_handler_data, variable_manager=variable_manager, loader=loader)
    assert default_handler._parent is None