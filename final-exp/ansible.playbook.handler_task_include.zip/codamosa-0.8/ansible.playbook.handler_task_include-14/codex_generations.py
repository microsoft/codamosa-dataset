

# Generated at 2022-06-11 09:57:04.910529
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({}) == "handler_task_include_load_return"

# Generated at 2022-06-11 09:57:08.542911
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "include": "mytask.yml",
  }
  #TODO: Find a way to make this work without mocking
  #handler = HandlerTaskInclude.load(data)
  #assert handler.validate_and_copy() == True

# Generated at 2022-06-11 09:57:19.139781
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible import inventory
    from ansible.playbook.hosts import Host
    from ansible.playbook.play import Play

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    def test_include(path):
        return b'{"a":{"foo":1,"bar":2}}'

    loader = DataLoader()
    loader.set_basedir("/fake/basedir")
    loader.set_file_finder(test_include)

    inventory = inventory.Inventory("/fake")
    host = Host("127.0.0.1")
    host.set_variable("foo", "bar")
    host.set_variable("bar", "foo")
   

# Generated at 2022-06-11 09:57:22.334445
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    block = "test block"
    handler = Handler.load(
        dict(
            name="test",
        ),
        block=block,
    )
    assert block == handler._block
    assert handler._role is None
    assert handler._task_include is None

# Generated at 2022-06-11 09:57:23.421423
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-11 09:57:28.377242
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task = {
        'include': 'playbook.yml'
    }

    handler = HandlerTaskInclude.load(data=task, task_include=TaskInclude.load(task))
    assert handler.get_name() == 'INCLUDE'
    assert handler.get_action() == 'playbook.yml'
    assert handler.loop is None
    assert handler._task is None

# Generated at 2022-06-11 09:57:36.885195
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task

    # test constructor without arguments
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)

    # test constructor with arguments
    block = Block()
    role = IncludeRole()
    task = Task()

    handler = HandlerTaskInclude(block, role, task)
    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, Handler)

# Generated at 2022-06-11 09:57:46.627326
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Unit test for method load of class HandlerTaskInclude.
    """
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.ini import InventoryParser
    from ansible.inventory.script import InventoryScript
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import os

    # Define global variables

# Generated at 2022-06-11 09:57:55.393784
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # set up
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    ds = dict(
        name = "Test HandlerTaskInclude",
        include = "test.yml",
        with_items = [
            "handler1",
            "handler2"
        ]
    )
 
    # set up the handler
    handler = HandlerTaskInclude.load(ds)

    # assert
    assert handler is not None
    assert handler._role == None
    assert handler._block == None
    assert handler.name == 'Test HandlerTaskInclude'
    assert handler._included_file == 'test.yml'
    assert handler._role is None
    assert handler._notify is None

# Generated at 2022-06-11 09:57:58.397358
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.block import Block
    block = Block()
    included_file = IncludedFile()
    HandlerTaskInclude.load('data', block, None, included_file, None, None)

# Generated at 2022-06-11 09:58:09.552632
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.loader import find_plugin_filenames
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    block = AnsibleBaseYAMLObject()
    role = AnsibleBaseYAMLObject()
    task_include = AnsibleBaseYAMLObject()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    variable_manager.options_vars= dict()
    variable_manager.options_vars['inventory'] = Host(name = 'localhost')
    variable_manager.options_vars['vault_password'] = 'password'
    variable_manager.options_

# Generated at 2022-06-11 09:58:12.106160
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # HandlerTaskInclude(block=None, role=None, task_include=None, use_handlers=False, use_tasks=False, use_vars=False)
    HandlerTaskInclude({})

# Generated at 2022-06-11 09:58:20.222200
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    fake_loader = DictDataLoader({
        "role.yml": '''
            ---
                tasks:
                  - name: A task
                    debug: msg="hello"
                handlers:
                  - name: A handler
                    debug: msg="world"
        ''',
        "subtask.yml": '''
            ---
                tasks:
                  - name: A subtask
                    debug: msg="subtask"
        ''',
    })


# Generated at 2022-06-11 09:58:22.877371
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(static="../../static_hosts",connections="s",tasks="../tasks/main.yml")
    app = HandlerTaskInclude()
    assert app.load(data)



# Generated at 2022-06-11 09:58:31.658461
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    assert hti.load({"include": "test.test"}, role={"name": "test"}, loader=None) is not None
    assert hti.load({"include": "test.test", "register": "item"}, role={"name": "test"}, loader=None) is not None
    assert hti.load({"include": "test.test", "loop": "item", "register": "item"}, role={"name": "test"}, loader=None) is not None
    assert hti.load({"include": "test.test", "with_items": [{"item": "item"}], "register": "item"}, role={"name": "test"}, loader=None) is not None

# Generated at 2022-06-11 09:58:32.728662
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load()

# Generated at 2022-06-11 09:58:40.722893
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.ini import InventoryParser
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    loader = DataLoader()
    ip = InventoryParser(loader=loader)
    inv_data = "host1 ansible_host=host1.example.com"
    host1 = ip.parse_hosts([inv_data])["host1"]
    group = Group("all")
    group.add_host(host1)
    inventory = ip.inventory
    inventory.add_group(group)

# Generated at 2022-06-11 09:58:42.010078
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Method load of class HandlerTaskInclude:
    """
    pass

# Generated at 2022-06-11 09:58:47.326951
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # check load() method
    data = {'listen': 'handler_name', 'include': 'roles/my_role/handlers/my_handler.yml'}
    obj_handler = HandlerTaskInclude.load(data)
    assert obj_handler.listen == 'handler_name'
    assert obj_handler.action == 'include'
    assert obj_handler.include == 'roles/my_role/handlers/my_handler.yml'


# Generated at 2022-06-11 09:58:47.938504
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass