

# Generated at 2022-06-11 09:57:09.484469
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Create an instance of class HandlerTaskInclude
    t = HandlerTaskInclude()
    t.check_options = mock_check_options
    t.load_data = mock_load_data

    # Create a temporary file 'example.yml'
    example_file = tempfile.NamedTemporaryFile(delete=False)
    file_name = example_file.name
    example_file.close()

    # Create a temporary file 'fail.yml'
    fail_file = tempfile.NamedTemporaryFile(delete=False)
    fail_name = fail_file.name
    fail_file.close()

    # Define two data structures
    correct_data = {'handlers': {'test_handler': {'include': {'name': file_name}}}}

# Generated at 2022-06-11 09:57:20.188321
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #from ansible.inventory.host import Host
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # create block, role and vairable_manager
    block = Block()
    role = Role()
    variable_manager = VariableManager()
    # create data dictionary

# Generated at 2022-06-11 09:57:25.596064
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    result = HandlerTaskInclude.load(data={}, block=2, role='3', task_include=4, variable_manager=5, loader=6)
    assert result != None
    assert isinstance(result, HandlerTaskInclude)
    assert result.block == 2
    assert result.name == '3'
    assert result.task_include == 4
    assert result.variable_manager == 5
    assert result._loader == 6
    assert len(result.tags) == 0
    assert len(result.when) == 0
    assert result.only_if == None
    assert result.notify == {}
    assert result.loop == []
    assert result._included_file == None

# Generated at 2022-06-11 09:57:26.236551
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:57:31.166143
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict()
    block = 'null'
    role = 'null'
    task_include = 'null'
    variable_manager = 'null'
    loader = 'null'
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    assert(handler.__class__.__name__ == 'HandlerTaskInclude')

# Generated at 2022-06-11 09:57:31.992378
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 09:57:41.580956
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'test_include',
        'listen': 'test_listen',
        'include_tasks': 'test_include_tasks',
        'loop': 'test_loop',
        'loop_control': 'test_loop_control'}
    taskInclude = HandlerTaskInclude.load(data)

    def get_private_variable(private_variable_name):
        return getattr(taskInclude, private_variable_name)

    assert get_private_variable('_validate_options')() == None
    assert get_private_variable('_task') == None

    assert get_private_variable('_role') == None
    assert get_private_variable('_block') == None
    assert get_private_variable('_task_include') == None


# Generated at 2022-06-11 09:57:47.264006
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_data = {
        'include': 'tasks/main.yml',
        'tags': ['always']
    }

    handler_object = HandlerTaskInclude.load(data=test_data)
    handler_data = handler_object.get_data()

    assert handler_object is not None
    assert handler_data is not None
    assert handler_data['include'] == 'tasks/main.yml'
    assert handler_data['tags'] == ['always']



# Generated at 2022-06-11 09:57:55.012221
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="test_HandlerTaskInclude_load",
        include="another_task",
        include_files=["other_task_include.yml"],
        include_vars=["other_task_include_vars.yml"],
        static="yes",
        static_vars=["other_task_static_vars.yml"]
    )
    handler_task_include = HandlerTaskInclude.load(
        data=data,
        block=None, role=None, task_include=None,
        variable_manager=None, loader=None
    )
    print(handler_task_include)

# Generated at 2022-06-11 09:57:56.459588
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include = HandlerTaskInclude();

    assert(handler_task_include is not None)



# Generated at 2022-06-11 09:57:59.349357
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None


# Generated at 2022-06-11 09:58:06.620148
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
#        include_data = [{
#            "name" : "redis",
#            "with_items" : "{{ redis_instances }}",
#            "with_file" : "configs/{{ item.name }}.conf",
#            "include" : "redis_handler.yml",
#            "listen" : "redis_restarted",
#            "first_available_file" : [ "{{ item.name }}.conf", "/etc/{{ item.name }}.conf" ]
#        }]
#        handler = HandlerTaskInclude.load(include_data)
#        assert handler.static is True

# Generated at 2022-06-11 09:58:07.114233
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:58:08.265801
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    assert False, "TODO: implement test"

# Generated at 2022-06-11 09:58:09.713718
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict()
    assert HandlerTaskInclude.load(data) == None


# Generated at 2022-06-11 09:58:12.475821
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    d = {}
    d['ignore_errors'] = False
    d['tasks'] = {'collect_facts': {'action': {'module': 'setup'}}}
    d['notify'] = ['HandlerTest']
    return d

# Generated at 2022-06-11 09:58:20.801853
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import json
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary playbook
    playbook_path = os.path.join(tmp_dir, "test_handler.yml")
    with open(playbook_path, "w") as f:
        f.write("""
---
- hosts: localhost
  tasks:
    - name: Dummy task
      debug:
        msg: Dummy task

    - include: my_handlers.yml
""")

    # Create a temporary handler file
    handler_path = os.path.join(tmp_dir, "my_handlers.yml")

# Generated at 2022-06-11 09:58:29.225960
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    data = OrderedDict({
        "name": "test",
        "listen": "test",
        "include_tasks": [
            "test.yml",
        ],
    })

    block = None
    role = None
    task_include = None
    variable_manager = VariableManager()
    loader = DataLoader()

    # mock a inventory
    inventory = InventoryManager(loader=loader, sources=["localhost"])
   

# Generated at 2022-06-11 09:58:32.988764
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    data["name"] = "abcde"
    data["block"] = ""
    data["role"] = ""
    data["task_include"] = ""
    data["_variable_manager"] = ""
    data["_loader"] = ""
    handler = HandlerTaskInclude()

# Generated at 2022-06-11 09:58:33.626339
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 09:58:39.589700
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    # Create a HandlerTaskInclude with all parameters and validate the returned object
    t = HandlerTaskInclude(block=Task(), role=None, task_include=TaskInclude())
    assert t != None

# Generated at 2022-06-11 09:58:40.399339
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "TODO"

# Generated at 2022-06-11 09:58:41.632361
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # mock the Handler Task Include object
    task = HandlerTaskInclude([])

# Generated at 2022-06-11 09:58:43.364512
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t is not None


# Generated at 2022-06-11 09:58:46.481112
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test = HandlerTaskInclude()
    assert test.VALID_INCLUDE_KEYWORDS == {'block', 'tasks', 'role', 'listen'}

# Generated at 2022-06-11 09:58:54.995921
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from AnsiballZ_ansible.ansible.inventory.host import Host
    from AnsiballZ_ansible.ansible.playbook.task_include import TaskInclude
    mock_variables = [{"name": "test"}]

    HandlerTaskInclude_class_instance = HandlerTaskInclude(mock_variables)
    # Test if the __init__() method of HandlerTaskInclude class
    # raises an Exception on setting the attribute 'action' to a non-instance

    # of TaskInclude class
    with pytest.raises(Exception):
        HandlerTaskInclude_class_instance.action = "Test"

    # Assign a Mock object to the attribute 'action' of
    # HandlerTaskInclude instance

# Generated at 2022-06-11 09:58:56.276292
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # init HandlerTaskInclude object
    handler = HandlerTaskInclude()
    print(handler.load)


# Generated at 2022-06-11 09:59:03.934136
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block

    
    def fake_load_data(arg1, arg2, arg3):
        return arg1

    
    # Create temp file for handler tasks
    with tempfile.NamedTemporaryFile(delete=False) as test_file:
        test_file.write(b'{"tasks": ["sample handler task"]}')
    
    test_data = {
        'include_tasks': test_file.name
    }
    test_variable_manager = None
    test_loader = None
    
    # Create temporary HandlerTaskInclude object with mock methods

# Generated at 2022-06-11 09:59:11.669245
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    import yaml
    import os

    curpath = os.path.dirname(os.path.abspath(__file__))
    yamlpath = os.path.join(curpath, 'data/ansible.yml')

    _host = Host(name='host')
    _hostvars = HostV

# Generated at 2022-06-11 09:59:12.929381
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Test HandlerTaskInclude load')

# Generated at 2022-06-11 09:59:20.825002
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    handler = handler_task_include.load('tasks/main.yml', None, None, None, None, None)
    assert handler.get_name() == 'main'
    assert handler.get_static_import_role() == 'static_import_role'

# Generated at 2022-06-11 09:59:29.033195
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-11 09:59:36.982211
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block

    # Subclass of class PlaybookBase
    class PlaybookBase(object):
        def __init__(self):
            self._basedir = './'

    # Create the object 'playbook' which is an instance of the class PlaybookBase
    playbook = PlaybookBase()

    # Create the object 'loader' which is an instance of the class DataLoader
    loader = DataLoader()

    # Create the object 'inventory' which is an instance of the class InventoryManager
    inventory = InventoryManager(loader=loader, sources='./hosts')

    # Create the object 'variable_manager' which is an instance of the class Variable

# Generated at 2022-06-11 09:59:40.858171
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler = HandlerTaskInclude()
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# ==============
# TEST FOR:
#    HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
# ==============


# Generated at 2022-06-11 09:59:47.318993
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name='handler_task_include',
        file='./handler.yml',
        static=1,
        handlers=dict(handlers=[])
    )

    data_loaded = HandlerTaskInclude.load(data)
    assert data_loaded.get_name() == 'handler_task_include'

# Generated at 2022-06-11 09:59:51.118211
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    
    block = Block()
    task_include = TaskInclude()
    HandlerTaskInclude.load(
        "handler.yml",
        block=block,
        task_include=task_include
    )
    
    

# Generated at 2022-06-11 09:59:52.582595
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(None, block=None, role=None)

# Generated at 2022-06-11 09:59:53.578536
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO
    pass

# Generated at 2022-06-11 09:59:56.721874
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': 'somefile.yml'
    }
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    t.check_options(t.load_data(data), data)

# Generated at 2022-06-11 10:00:06.075289
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    data = {}
    block = None
    role = None
    task_include = None

    extra_vars = {}

# Generated at 2022-06-11 10:00:20.374106
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def ProgrammaticHost(host_name):
        return {'name': host_name}

    data = {
        'include': 'foo.yml',
        'static': [ProgrammaticHost('host1'), ProgrammaticHost('host2')]
    }
    variable_manager = None
    loader = None
    HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:00:21.297812
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load({})

# Generated at 2022-06-11 10:00:22.986862
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print ('')
    data_example = {'listen': 'update_file'}
    print (HandlerTaskInclude.load(data_example))

# Generated at 2022-06-11 10:00:27.491298
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data=dict(
        name='Test handler',
  )
  # load handler

# Generated at 2022-06-11 10:00:29.730439
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)


# Generated at 2022-06-11 10:00:33.206135
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Constructor of class HandlerTaskInclude")

    t = HandlerTaskInclude(block=None, role=None, task_include=None)

    assert t.valid_attrs == TaskInclude.VALID_INCLUDE_ATTRIBUTES.union(('listen',)), \
        "Method load() return invalid value"

# Generated at 2022-06-11 10:00:41.688699
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from .mock import patch, Mock
    from ansible.parsing.mod_args import ModuleArgsParser

    # Create mock objects
    data = {}
    block = Mock()
    role = Mock()
    task_include = Mock()
    variable_manager = Mock()
    loader = Mock()

    # Mock the return value of method check_options of object t
    patched_check_options = patch.object(HandlerTaskInclude, 'check_options')
    patched_check_options.return_value = []

    # Mock the return value of method load_data of object t
    patched_load_data = patch.object(TaskInclude, 'load_data')
    patched_load_data.return_value = {}

    # Test normal case

# Generated at 2022-06-11 10:00:44.125469
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include='some.yml',
    )

    handler = HandlerTaskInclude.load(data)
    assert handler.name == 'some.yml'



# Generated at 2022-06-11 10:00:45.125234
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
    # handler = HandlerTaskInclude.load()


# Generated at 2022-06-11 10:00:48.317843
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include': 'action_plugins/debug.py', 'tags': 'debug'}
    t = HandlerTaskInclude(None, None, None)
    handler = t.check_options(
        t.load_data(data, None, None),
        data
    )
    assert(isinstance(handler, HandlerTaskInclude))

# Generated at 2022-06-11 10:01:17.755285
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    yaml_content = """
---
- hosts: localhost
  connection: local
  tasks:
    - name: task a
      command: /bin/true
    - name: task b
      command: /bin/true
    - name: task c
      command: /bin/true
    - name: task d
      command: /bin/true
    - include: included.yaml
    - name: task e
      command: /bin/true
    - include: included.yaml
    - name: task f
      command: /bin/true

"""
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-11 10:01:26.525030
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()

    example_host = Host("example.com")
    variable_manager.set_host_variable(example_host, "example", "example")

    play_context = PlayContext()


# Generated at 2022-06-11 10:01:32.441022
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Mock Handlertaskinclude class
    class MockHandlerTaskInclude(HandlerTaskInclude):
        pass

    mock_handler = MockHandlerTaskInclude()
    example_yml_file = {
        'include': 'example.yml',
        'vars': {'example1': 'test1', 'example2': 'test2'}
    }

    # Method load is called for dict example_yml_file
    assert isinstance(mock_handler, HandlerTaskInclude)



# Generated at 2022-06-11 10:01:42.328674
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    FakeInventory = ansible.vars.manager.wrap_dict({
        'hosts': [
            'host1',
            'host2'
        ],
        'groups': {
            'group1': {
                'hosts': ['host1'],
                'vars': {
                    'abc': 'def'
                }
            }
        },
        '_meta': {
            'hostvars': {
                'host1': {
                    'ghi': 'jkl'
                }
            }
        }
    })
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-11 10:01:52.062204
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # TEST 1: Create a Host object, which is used in tests further down
    host_name = 'localhost'
    host = Host(host_name)

    # TEST 2: Create a VaribaleManager object, which is used in tests further down
    options = {'syntax': 'yaml', 'vault_password': 'password'}
    loader = DataLoader()
    inventory = Inventory(loader, [host])
    variables = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # TEST 3: Create a HandlerTaskInclude object, which is being tested
    block_name

# Generated at 2022-06-11 10:02:00.836777
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # create all necessary object for loading a task 
    # and evaluating it's conditions
    host = Host(name="test-host.example.org")
    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # a block without a name is a meta task, hence it is always included
    block = Block(host=host)

    # test with empty data
    data = None
    handler_task_include = HandlerTaskInclude.load(
        data,
        block=block,
        variable_manager=templar
    )
    assert handler

# Generated at 2022-06-11 10:02:09.607093
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import action_loader, cache_loader
    from ansible.utils.vars import combine_vars

    class TestVarsModule(object):
        def __init__(self, host, task, play_context, new_stdin):
            pass


# Generated at 2022-06-11 10:02:10.114848
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 10:02:10.931318
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 10:02:18.701935
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == set(['tasks', 'tags', 'ignore_errors', 'when', 'listen'])

    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None
    assert handler_task_include.VALID_INCLUDE_KEYWORDS == set(['tasks', 'tags', 'ignore_errors', 'when', 'listen'])
    assert handler_task_include.block is None
    assert handler_task_include.only_tags is None
    assert handler_task_include.skip_tags is None
    assert handler_task_include.conditional is None
    assert handler_task_include.action == 'include'
    assert handler_task_include.name is None
    assert handler_task_include.when is None

# Generated at 2022-06-11 10:03:03.868894
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(
        dict(
            include="foo.yml",
            with_items=["1", "2", 3, 4],
            name="{{item}}"
        ),
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-11 10:03:04.528204
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert 0 == 0

# Generated at 2022-06-11 10:03:15.840264
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    dataloader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(dataloader.load('test'))
    host = Host(name='test')
    variable_manager.set_host_variable(host, 'ansible_ssh_common_args', '')

    handler = HandlerTaskInclude.load(
        {
            'name': 'test',
            'include': 'test_include',
            'listen': 'test_listen'
        },
        variable_manager=variable_manager,
        loader=dataloader
    )

    assert handler.name == 'test'

# Generated at 2022-06-11 10:03:24.521318
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()

    i = Inventory(loader=loader, variable_manager=variable_manager)
    h = Host(name='myhost')
    i.add_host(h)
    g = Group(name='all')
    i.add_group(g)
    g.add_host(h)

    variable_manager.set_inventory(i)


# Generated at 2022-06-11 10:03:29.249307
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-11 10:03:29.742732
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-11 10:03:37.915897
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    test_handler_vars = dict(
        handlers='test_handler.yml',
        tasks='test_task.yml',
        name='test'
    )
    test_handler_data = dict(
        name='listen_test',
        listen='test'
    )

    test_task_vars = dict(
        handlers='test_handler.yml',
        name='test_task'
    )
    test_task_data = dict

# Generated at 2022-06-11 10:03:38.703965
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: Write some tests here
    pass

# Generated at 2022-06-11 10:03:40.086800
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude()

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-11 10:03:41.115863
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    print (handler.name)

# Generated at 2022-06-11 10:05:04.969330
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:05:11.029206
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    file_name = 'pre_tasks.yml'
    name_list = ['pre task 1', 'pre task 2']

    from ansible.playbook.play import Play

    task_include = HandlerTaskInclude()
    task_include.set_loader(Play()._loader)

    task_include._load_included_file(file_name)
    task_include._load_included_file(file_name)
    task_include._load_included_file(file_name)
    task_include._load_included_file(file_name)

    assert task_include.statically_loaded_files == [file_name]

    task_include._get_handler_names()

    assert task_include.handlers == []
    assert task_include.handler_blocks == name_list

# Generated at 2022-06-11 10:05:14.058832
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    #handler = t.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    #assert handler == "handler"

# Generated at 2022-06-11 10:05:21.030182
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        u'when': u'status != ok',
        u'block': u'',
        u'role': u'',
        u'variable_manager': u'',
        u'loader': u'',
        u'include': u'',
        u'task_include': u'',
        u'listen': u'',
        u'static': True
    }

    handler = HandlerTaskInclude.load(data)
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-11 10:05:28.133001
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name='test_include',
        include='test_task.yml',
        roles=['test_role1'],
        tasks='test_task.yml',
        handlers='test_handler.yml',
        with_items='test_item.yml',
        block="tasks",
        when='test_expression',
    )
    test_include = HandlerTaskInclude(None)

    assert test_include.load(data)

# Generated at 2022-06-11 10:05:38.076828
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    sample_text = '''
    - include: tasks.yml
    '''
    host = Host('127.0.0.1')
    block  = Block()
    role = Role()
    variable_manager = VariableManager()
    loader = DataLoader()

    handler = HandlerTaskInclude.load(sample_text, block, role, None, variable_manager, loader)
    assert type(handler) == HandlerTaskInclude

# Generated at 2022-06-11 10:05:39.216748
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t is not None

# Generated at 2022-06-11 10:05:46.108143
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    from units.mock.loader import DictDataLoader

    hosts = [Host(name='server1', port=22)]
    block = Block(
        parent_block=None,
        role=None,
        task_includes=[]
    )
    task_include = TaskInclude(
        name='task include',
        play=None,
        play_context=PlayContext(remote_addr='server1', ports=[], remote_user='root')
    )

# Generated at 2022-06-11 10:05:53.644309
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-11 10:05:59.991396
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude(block=['block'], role='role', task_include='task_include')
    assert hti.block == ['block']
    assert hti.role == 'role'
    assert hti.task_include == 'task_include'
