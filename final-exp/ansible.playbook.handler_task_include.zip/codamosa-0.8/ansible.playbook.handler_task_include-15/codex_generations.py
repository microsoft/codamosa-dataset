

# Generated at 2022-06-11 09:57:12.967534
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    hosts = {
        "testhost": Host(name="testhost", variables=dict(ansible_connection='local')),
    }
    inventory = InventoryManager(loader=loader, sources='localhost,')
    inventory.hosts = hosts
    variable_manager.set_inventory(inventory)

    data = [dict(include='fail', ignore_errors=True, when='False'),
            dict(include='fail', ignore_errors=True, when='True'),
            ]
    handler = HandlerTaskInclude.load(data)

# Generated at 2022-06-11 09:57:13.488469
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:57:22.987459
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    h = HandlerTaskInclude()
    block = Block()

    data = dict(
        include = dict(
            name="var_name",
            static="var_static",
        )
    )
    static_vars = dict(
        var_static="I come from static"
    )

    # Create a play to handle the static vars
    play_ds = dict(
        name="test_play",
        hosts="test_host",
        gather_facts="no",
        roles=[],
        vars=static_vars,
    )
    play = Play.load(play_ds)

    # Create the

# Generated at 2022-06-11 09:57:32.195682
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.hosts import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # Setup - create dummy variables
    host = Host(name="test")
    block = Block(task_include=Task(action="test"))
    block._role_name = "test"
    var_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=var_manager)

    # Test
    data = {"include": "handler.yml"}

# Generated at 2022-06-11 09:57:35.410410
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name = "notify",
        connection = "local"
    )

    h = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    assert h != None

# Generated at 2022-06-11 09:57:41.180775
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    block = Block()
    role = Role()
    task_include = TaskInclude()

    handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    assert isinstance(handler, HandlerTaskInclude)


# Generated at 2022-06-11 09:57:42.474070
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    res = HandlerTaskInclude.load()
    assert res is not None

# Generated at 2022-06-11 09:57:44.142576
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    x = HandlerTaskInclude()


if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-11 09:57:53.575184
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/test_hosts')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()

    host = inventory.get_host('testhost')
    my_task = {'name': 'testtask', 'ignore_errors': True, 'listen': 'my_handler'}
    my_handler = {'name': 'my_handler', 'listen': 'all', 'tags': ['handler1']}
    handler = HandlerTaskInclude

# Generated at 2022-06-11 09:58:02.116262
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # start testing code
    # ini file block for "file 1"
    block1 = [
        {
            'include': 'file2.yml',
            'listen': 'test_event'
        }
    ]

    # ini file block for "file 2"
    block2 = [
        {
            'include': 'file3.yml',
            'listen': 'test_event2'
        }
    ]

    # ini file block for "file 3"
    block3 = [
        {
            'include': 'file4.yml',
            'listen': 'test_event3'
        }
    ]

    # ini file block for "file 4"
    block4 = [
        {
            'name': 'test_task'
        }
    ]

    # test case

# Generated at 2022-06-11 09:58:07.643269
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = "name: test"
    handler = HandlerTaskInclude.load(data)
    assert handler.action == 'include'
    assert handler.name == 'test'
    assert handler.include_type == 'tasks'
    assert handler.static == False
    assert handler.block == None
    assert handler.attribute == 'tasks'
    assert handler.task == None

# Generated at 2022-06-11 09:58:13.410691
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.extra_vars = {"env": "qa", "qa_environment_var": "qa_value"}
    loader = DataLoader()

    play_context = PlayContext()

    name = 'main.yml'

# Generated at 2022-06-11 09:58:22.049345
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'hosts': 'all', 'name': 'a message', 'listen': 'a', 'any_errors_fatal': True,
        'tasks': [{'action': {'module': 'debug', 'args': {'msg': 'Hello World'}}}],
    }

    handler = HandlerTaskInclude.load(data)
    assert handler.name == 'a message'
    assert handler.block is None
    assert handler.role is None
    assert handler.tags == []
    assert handler.any_errors_fatal is True
    assert handler.hosts == ['all']
    assert handler.tasks[0].action.module == 'debug'
    assert handler.tasks[0].action.args['msg'] == 'Hello World'
#
# # Unit test for method compile of class HandlerTaskInclude
#

# Generated at 2022-06-11 09:58:27.438782
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # VariableManager and DataLoader objects are not used in this test
    variable_manager, loader = None, None

    # Create the dict of data that the handler will load using the class method
    data = {
                'name': 'My handler',
                'include': 'my_tasks',
            }

    # Load the data, result is a Handler object
    handler = HandlerTaskInclude.load(data)

    assert handler.name == 'My handler'
    assert handler.include == 'my_tasks'



# Generated at 2022-06-11 09:58:28.238603
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude



# Generated at 2022-06-11 09:58:29.558958
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-11 09:58:34.436302
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name = "test_name",
        listen = "test_listen",
        tasks = "test_tasks"
    )
    task_include = TaskInclude()
    task_include_task_include = HandlerTaskInclude(task_include=task_include)
    task_include_task_include.load(data)
    assert task_include_task_include.name == "test_name"

# Generated at 2022-06-11 09:58:35.209293
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-11 09:58:42.230911
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {u'listen': u'foo', u'name': u'coco'}
    t = HandlerTaskInclude()
    handler = t.check_options(
        t.load_data(data),
        data
    )
    assert handler.__class__.__name__ == 'Handler'
    assert handler.__module__ == 'ansible.playbook.handler'
    assert handler.name.__class__.__name__ == 'Name'
    assert handler.name.__module__ == 'ansible.playbook.name'
    assert handler.notify is None
    assert handler.listen == [u'foo']
    assert handler.tags == []

# Generated at 2022-06-11 09:58:45.974263
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(

    )

    task = HandlerTaskInclude.load(data)
    assert task is not None
    assert type(task) is HandlerTaskInclude
    assert task.block is None
    assert task.role is None
    assert task.task_include is None
    assert task._attributes == dict()

# Generated at 2022-06-11 09:58:48.969233
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 09:58:56.506547
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#     block = None
#     role = None
#     task_include = None
#     data1 = {'include_tasks': 'tests/files/handlers/test_handler_include.yml'}
#     data2 = {'include': 'tests/files/handlers/test_handler_include.yml'}
#     variable_manager = ansible.vars.VariableManager()
#     loader = ansible.parsing.dataloader.DataLoader()
#     task = HandlerTaskInclude()
#     assert task.load(data1,block,role,task_include,variable_manager,loader)
#     assert task.load(data2,block,role,task_include,variable_manager,loader)

# Generated at 2022-06-11 09:58:59.838128
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''
    @summary: Test case for HandlerTaskInclude constructor
    '''


    test_data = {'name': 'test', 'include': 'test'}

    valid_handler_task_include = HandlerTaskInclude.load(test_data)

    assert isinstance(valid_handler_task_include, HandlerTaskInclude)



# Generated at 2022-06-11 09:59:01.293126
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    a = HandlerTaskInclude()
# Tests whether HandlerTaskInclude constructor returns a correct value

# Generated at 2022-06-11 09:59:05.324849
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    name= 'test'
    connection= 'ssh'
    action= dict()
    action.update( {'action': 'ping'} )
    test_instance= HandlerTaskInclude(block= None,
                                      role= name,
                                      task_include= action,
                                      connection= connection)
    assert test_instance.name == name
    assert test_instance.connection == connection
    assert test_instance.action == action

# Generated at 2022-06-11 09:59:06.081805
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-11 09:59:08.166857
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj.VALID_INCLUDE_KEYWORDS == {"vars", "group_by", "when", "tags", "listen"}
    assert obj.name == "include"

# Generated at 2022-06-11 09:59:14.542897
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    data = { 'include': 'my tasks' }
    block = None
    role = None
    task_include = None
    variable_manager = VariableManager()
    loader = None
    host = None
    file_name = "my_inventory_file"

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.include_file == "my tasks"

# Generated at 2022-06-11 09:59:15.008075
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 09:59:22.148410
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    host = Host(name="test.example.com")
    host.vars = HostVars(
        host=host,
        variables=dict(example_var="test")
    )

    group = Group(name='example_group')
    group.hosts.add(host)


# Generated at 2022-06-11 09:59:34.975035
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    data = {
        "name": "test_task_include",
        "hosts": "localhost",
        "listen": "teste"
    }
    variable_manager = None
    loader = None
    handler = t.load(data, block=None, role=Role(), task_include=TaskInclude(), variable_manager=variable_manager, loader=loader)
    assert handler is not None

# Generated at 2022-06-11 09:59:40.990095
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import VariableManager

    # load a inventory file
    inv_obj = InventoryManager(["./test/unit/inventory/test_inventory"])

    # create a variable manager
    var_mgr  = VariableManager(loader=None, inventory=inv_obj)

    # create a HandlerTaskInclude object
    handler_task_include = HandlerTaskInclude()
    handler_task_include.load_data({})

# Generated at 2022-06-11 09:59:51.102001
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Create an instance of class HandlerTaskInclude
    # without arguments
    HandlerTaskInclude_instance = HandlerTaskInclude()

    # Create an instance of class TaskInclude
    TaskInclude_instance = TaskInclude()

    # Mock the method load
    TaskInclude_instance.load = Mock(return_value=True)
    HandlerTaskInclude_instance.check_options = Mock(return_value=True)
    HandlerTaskInclude_instance.load_data = Mock(return_value=True)

    # Call the method load
    HandlerTaskInclude.load('data', block='block', role='role',
                            task_include='task_include',
                            variable_manager='variable_manager',
                            loader='loader')

    # Check that the method load called the method load of class TaskInclude
    TaskInclude_instance

# Generated at 2022-06-11 10:00:00.983362
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Unit test for method load of class HandlerTaskInclude
    """
    # FIXME: not yet implemented
    # host = Host()
    # host.set_variable('var_a', 'var_a')
    # host.set_variable('var_b', 'var_b')
    #
    # block = Block()
    # block.set_variable('var_a', 'var_a')
    # block.set_variable('var_b', 'var_b')
    #
    # role = Role()
    # role.set_variable('var_a', 'var_a')
    # role.set_variable('var_b', 'var_b')
    #
    # t_inc = TaskInclude()
    # t_inc.set_variable('var_a', 'var_a')
    #

# Generated at 2022-06-11 10:00:06.714775
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # set up test objects
    vm = DummyVars()
    loader = DummyLoader()

    # set up test data
    data = dict(
        name = "bar",
        listen = "foo"
    )

    # run test
    t = HandlerTaskInclude.load(
        data = data,
        variable_manager = vm,
        loader = loader
    )

    # check the results
    assert t.name == "bar"
    assert t.listen == "foo"





# Generated at 2022-06-11 10:00:15.380998
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import sys
    import pytest

    TEST_DIR = os.path.dirname(os.path.realpath(__file__))
    LIB_DIR = os.path.join(TEST_DIR, '..', 'library')
    if LIB_DIR not in sys.path:
        sys.path.append(LIB_DIR)

    from module_utils.common.validation import ValidationException

    data = dict(
        name='notify_me_if_cool',
        listen='cool_event',
        block=None,
        role=None,
        task_include=None
    )


# Generated at 2022-06-11 10:00:21.373157
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    var_manager = "test_variable_manager"
    loader = "test_loader"
    data = {
        'name': 'test',
        'include': 'test_include',
        'static': {
            'test': 'test_dict'
        }
    }
    h = HandlerTaskInclude.load(data, task_include=None, variable_manager=var_manager, loader=loader)

    assert(h.static == { 'test': 'test_dict'})

    assert(h.variable_manager == var_manager)
    assert(h.loader == loader)

# Generated at 2022-06-11 10:00:30.041703
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def check_input(data, variable_manager, loader):
        return data

    def check_options(self, handler, data):
        if 'name' in data:
            assert handler.name == data['name']
        if 'listen' in data:
            assert handler.name == data['listen']
        assert data['action'] == 'include'
        assert data['_raw_params'] == 'a.yml'
        return handler

    HandlerTaskInclude.check_options = check_options
    TaskInclude.check_input = check_input

    data = dict(
        name='test_handler',
        action='include',
        listen='test_handler',
        _raw_params='a.yml'
    )

    handler = HandlerTaskInclude.load(data, None, None, None, None, None)



# Generated at 2022-06-11 10:00:38.559887
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # tasks:
    #   - debug: var=a
    #   - debug: var=b
    # handlers:
    #   - include: test_handlers.yml
    #   - include: test_handlers.yml
    #     listen: test_include

    # Setup stuff
    data = {
        "include": "test_handlers.yml",
    }
    class MockBlock:
        def __init__(self, name):
            self.name = name

    mock_block = MockBlock('handlers')

    # Test with no additional data
    handler = HandlerTaskInclude.load(data, block=mock_block)
    assert handler['file'] == 'test_handlers.yml'

    # Add listen keyword
    data['listen'] = 'test_include'
    handler = HandlerTask

# Generated at 2022-06-11 10:00:40.309485
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude({}, None, None)
    assert obj

# Test for class HandlerTaskInclude - Test for the method 'load'

# Generated at 2022-06-11 10:00:50.787616
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-11 10:00:55.674277
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude()
    data = dict(
        name = 'Ansible Test',
        action = dict(
            module = 'shell',
            args = 'echo "Hello Ansible"',
        ),
    )
    handler = h.load(data)

    if handler.name != 'Ansible Test':
        raise Exception('name is wrong')

    if handler.action._attributes['module'] != 'shell':
        raise Exception('module is wrong')

    if handler.action._attributes['args'] != 'echo "Hello Ansible"':
        raise Exception('args is wrong')

# Generated at 2022-06-11 10:00:58.680135
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        when = '',
        name = '',
        listen = ''
    )
    t = HandlerTaskInclude()
    handler = t.check_options(
        t.load_data(data, variable_manager=None, loader=None),
        data
    )
    assert isinstance(handler, Handler)

# Generated at 2022-06-11 10:00:59.138201
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

# Generated at 2022-06-11 10:01:06.209133
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    args = dict(
        data=dict(include=dict(file='test.yaml')),
        block=['some_task', 'listen'],
        role="The Role Name",
        task_include=['some_task', 'listen'],
        variable_manager=['some_task', 'listen'],
        loader=['some_task', 'listen'],
    )
    h = HandlerTaskInclude.load(**args)
    assert isinstance(h, HandlerTaskInclude)
    #assert isinstance(h.task_include, TaskInclude)
    #assert isinstance(h.task_include.tasks, object)
    #assert h.task_include.tasks.__class__.__name__ == 'list'
    #assert len(h.task_include.tasks) == 1
   

# Generated at 2022-06-11 10:01:15.192294
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # init args
    data = {
        'handlers': {
            'include': {'a': 'b'}
        }
    }
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    # Load handler
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    # Assert basic load, need to assert in all files under 'library'
    assert isinstance(handler, HandlerTaskInclude)
    
    # Assert load_data
    assert handler.block == block
    assert handler.role == role
    assert handler.task_include == task_include
    assert handler.static is False
    assert handler.tasks == [{'a': 'b'}]



# Generated at 2022-06-11 10:01:18.205575
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'all',
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.uid == 'include.all'
    assert handler.name == 'all'
    assert handler.static == True

# Generated at 2022-06-11 10:01:24.725636
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    a = t.load(data = {
        'include': {
            'file': 'file_name',
            'static': False,
            'name': 'include_task',
            'listen': 'listen_task'
        }
    })
    b = HandlerTaskInclude(
            file_name = 'file_name',
            static = False,
            name = 'include_task',
            listen = 'listen_task'
        )

    assert a.__dict__ == b.__dict__


# Generated at 2022-06-11 10:01:33.627747
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop


# Generated at 2022-06-11 10:01:35.793375
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: write unit test
    # assert <expr>, <msg>
    raise NotImplementedError()
