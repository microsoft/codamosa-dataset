

# Generated at 2022-06-11 09:57:13.149738
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    data = dict()
    data['name'] = 'name'
    data['tags'] = ['tag']
    data['when'] = 'when'
    data['async'] = 1
    data['poll'] = 2

    my_loader = DataLoader()
    host = 'localhost'

# Generated at 2022-06-11 09:57:14.243705
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude()


# Generated at 2022-06-11 09:57:23.424175
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.parsing.utils.loader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()
    block = Block()
    host = Host(name="127.0.0.1")
    role = Role()
    task_include = TaskInclude()

    play.hosts.add(host)
    play.set_variable_manager(variable_manager)


# Generated at 2022-06-11 09:57:25.576147
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include': [], 'tasks': {}, 'handlers': {}}
    t = HandlerTaskInclude.load(data)

# Generated at 2022-06-11 09:57:34.162117
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    datastructure = AnsibleMapping(loader=loader)
    datastructure.update({
        "name": "test",
        "listen": "test"
    })

    extra_vars = load_extra_vars(loader=loader, variables=None)
    task_include = AnsibleMapping(loader=loader)
    task_include.update({
        "tags": AnsibleSequence(loader=loader)
    })

# Generated at 2022-06-11 09:57:44.029166
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.helpers import load_list_of_blocks

    data = {'name': 'task list', 'tasks': [{'shell': 'ls'}]}
    block = Block()
    role = Role()
    task_include = TaskInclude()
    handler = HandlerTaskInclude.load(data, block, role, task_include)

    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler.block, Block)
    assert isinstance(handler.role, Role)
    assert isinstance(handler.task_include, TaskInclude)

# Generated at 2022-06-11 09:57:53.450749
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    # create an ansible hosts file
    hosts = '''
[test]
localhost
    '''
    inventory = InventoryManager(loader=None, sources=hosts)
    task_vars = dict()
    play_context = PlayContext()
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # create a task to test
    t = { u'listen': u'all' }

    # create a HandlerTaskInclude instance
    h = HandlerTaskInclude(block=None, role=None, task_include=None)

    # load the

# Generated at 2022-06-11 09:58:02.002157
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def test_load(data):
        t = HandlerTaskInclude()
        return t.load(data)

    # Load a role handler by name
    data = {'name': 'test_role'}
    handler = test_load(data)
    assert len(handler._handlers['test_role']) == 1

    # Load a role handler by dict
    data = {'name': {'role': 'test_role'}}
    handler = test_load(data)
    assert len(handler._handlers['test_role']) == 1

    # Load a handler from a task
    data = {'include': 'test_task.yml'}
    handler = test_load(data)
    assert len(handler._handlers['test_task']) == 1

    # Load a handler from a task with an alias

# Generated at 2022-06-11 09:58:06.774588
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    data = dict(
        include=list(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS),
        ignore_errors = True
    )

    handler = HandlerTaskInclude.load(
        data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    assert handler.task_include

# Generated at 2022-06-11 09:58:10.903422
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)

    print(handlerTaskInclude.VALID_INCLUDE_KEYWORDS) #result: set(['free-form', 'with_items', 'vars', 'include_tasks', 'tags', 'static', 'roles'])


if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-11 09:58:22.349440
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    # create a host
    h = Host("myhostname", port=22)
    # create a group
    g = Group("mygroupname")
    g.add_host(h)
    # create an inventory
    im = InventoryManager(loader=DataLoader(), sources='')
    im.add_group(g)
    # create variable manager
    v = VariableManager()
    v.set_inventory(im)

    # create a handler

# Generated at 2022-06-11 09:58:23.474491
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import pdb; pdb.set_trace()
    pass

# Generated at 2022-06-11 09:58:27.666483
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.VALID_INCLUDE_KEYWORDS == set(['tasks', 'handlers', 'vars', 'defaults', 'meta', 'listen'])

# Generated at 2022-06-11 09:58:28.164486
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-11 09:58:35.581480
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_data = dict(
        name='handler_name',
        tasks=[
            dict(action=dict(module='shell', args='ls'))
        ]
    )
    hti = HandlerTaskInclude()
    handler = hti.load(
        test_data,
        dict(playbook=dict(hosts=['testhost'])),
        variable_manager=None,
        loader=None
    )
    assert handler.name == 'handler_name'
    assert len(handler._tasks) == 1
    assert handler._tasks[0].action.__class__.__name__ == 'ActionModule'
    assert handler._tasks[0].action.args == 'ls'

# Generated at 2022-06-11 09:58:36.759518
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(data='{"name": "task"}')
    # TBD

# Generated at 2022-06-11 09:58:37.808788
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()


# Generated at 2022-06-11 09:58:38.598615
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()


# Generated at 2022-06-11 09:58:46.751844
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'file_name',
        'static': True,
        'ignore_errors': True,
        'loop': 'items',
        'loop_control': 'loop_control',
    }
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert handler.block == None
    assert handler.role == None
    assert handler.task_include == None
    assert handler.name == 'file_name'
    assert handler.static == True
    assert handler.ignore_errors == True
    assert handler.loop == 'items'
    assert handler.loop_control == 'loop_control'
    assert handler.include_tasks == None



# Generated at 2022-06-11 09:58:52.173108
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import TaskBlock
    from ansible.inventory.host import Host

    data = {'include': 'foo'}
    block = TaskBlock(role=None)
    role  = None
    task_include = HandlerTaskInclude()

    result = HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include)

    # check for an instance of a class
    assert isinstance(result, HandlerTaskInclude), "%s is not an instance of HandlerTaskInclude" % result

# Generated at 2022-06-11 09:59:05.226828
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar

    data = {'hosts': 'localhost'}
    variable_manager = None
    task_include = IncludedFile()

    host = Host(name='localhost', port=22)
    block = Block(hosts=[host], task_include=task_include)

    handler = HandlerTaskInclude \
            .load(data, block=block, variable_manager=variable_manager, task_include=task_include)
    handler_dict = handler.get_vars()

    assert type(handler) is HandlerTaskInclude
    assert type(handler_dict) is dict
    assert handler_dict['hosts'] == data['hosts']



# Generated at 2022-06-11 09:59:13.526791
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.variables.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import create_default_vars

    # Create a task to load
    data = {
        'name': 'Configure Apache',
        'local_action': 'apt package={{item}} state=latest update_cache=yes',
        'with_items': ['apache2','apache2-doc','apache2-utils','libapache2-mod-php5']
    }

    # Create a block and assign it to the task
    block = Block()

    # Create a role and assign it to the block
    role = Role()
    role._role_name = 'apache'
    role._parent

# Generated at 2022-06-11 09:59:20.566372
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    import os
    import ansible.playbook
    import ansible.inventory

    # create a valid playbook
    filename = 'test_playbook.yml'
    test_data = '''---
- hosts: localhost
  tasks:
    - name: Test
      debug:
        msg: "test1"
    - name: Test2
      debug:
        msg: "test2"
    - include: test_playbook2.yml

- hosts: localhost
  tasks:
    - name: Test
      debug:
        msg: "test1"
    - name: Test2
      debug:
        msg: "test2"
    - include:
        file: test_playbook2.yml
        tasks:
          - test3
'''
    file = open(filename, 'w')

# Generated at 2022-06-11 09:59:22.180365
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    print('HandlerTaskInclude init:', handler_task_include)


# Generated at 2022-06-11 09:59:27.963053
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(
        role=None,
        task_include=None,
        block=None,
        _local_action="include_tasks",
        _task_vars={},
        _play_name="TEST",
        _role_names=["ROLE1"]
    )

    assert handler._play_name == "TEST"
    assert handler._role_names == ["ROLE1"]
    assert handler._local_action == "include_tasks"
    assert handler._task_vars == {}

# Generated at 2022-06-11 09:59:35.892431
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import json
    import ansible.playbook.role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    results_handler_callback = lambda self, host, res: res

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader, variable_manager, 'localhost')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 09:59:38.128135
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(None, None, None, None, None, None)
    HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-11 09:59:40.597879
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(data={'include':'test.yaml'}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-11 09:59:50.933696
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Testing HandlerTaskInclude_load")
    # code to test
    def foo():
        pass
    def bar():
        pass
    def baz():
        pass

    block = {'bar': bar}
    role = {'baz': baz}
    TaskInclude.add_constructor('foo', foo)
    handler_task_include = HandlerTaskInclude()
    handler_task_include.load(data={'foo': 'bar', 'baz': 'baz'}, block=block, role=role)

    # assert result
    assert handler_task_include._role == {'baz': baz}
    assert handler_task_include._block == {'bar': bar}
    assert handler_task_include._task_include == {}

# Generated at 2022-06-11 09:59:52.304891
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	# Test handler TaskInclude constructor
	h1 = HandlerTaskInclude()

# Generated at 2022-06-11 10:00:06.870797
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar

    block = Block(play=Play())
    role = Role()
    task_include = TaskInclude()

    #
    # Test exception raised when data is not a dictionary
    #
    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    data = []
    try:
        t.load(data)
    except Exception as e:
        assert isinstance

# Generated at 2022-06-11 10:00:09.947534
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Note: The test passes if the method runs without exceptions.
    HandlerTaskInclude.load(
        data={
            'action': 'start',
            'listen': 'foo',
            'name': 'test'
        }
    )

# Generated at 2022-06-11 10:00:10.812779
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "TODO"

# Generated at 2022-06-11 10:00:18.909575
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import combine_vars
    from ansible.vars.unsafe_proxy import fix_unsafe_proxy
    from ansible.plugins.loader import get_var_loader

    block = Block(play=None, parent_block=None)
    role = Role()


# Generated at 2022-06-11 10:00:20.137146
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h is not None

# Generated at 2022-06-11 10:00:28.360356
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    t = HandlerTaskInclude()
    # test case 1: no include_tasks
    data = {
        "tasks": [
            {
                "debug": {
                    "msg": "it is a test"
                }
            }
        ],
        "listen": "test"
    }

    handler = t.load(data)
    assert handler.block == None
    assert handler.dynamic is False
    assert handler.role is None
    assert handler.tasks == [{"debug": {"msg": "it is a test"}}]
    assert handler.name == ''
    assert handler.handler_blocks == {}
    assert handler.include_tasks == []
    assert handler.include_handlers == []
    assert handler.parent_block

# Generated at 2022-06-11 10:00:37.478040
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.errors import AnsibleParserError

    class MockVariableManager(object):
        def __init__(self):
            self.template_class = MockTemplate()
            self.extra_vars = {}
            self.host_vars = {}
            self.group_vars = {}

    def load_data(self, data, variable_manager=None, loader=None):
        self._attributes = {}
        self._task_type = 'include'
        super(HandlerTaskInclude, self).load_data(data, variable_manager=variable_manager, loader=loader)
        if self._block and not self._role:
            raise AnsibleParserError("'include' tasks must use the 'roles:' directive when used in a block")

# Generated at 2022-06-11 10:00:45.131946
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'listen': 'service name',
        'only_tags': ['t1', 't2', 't3'],
        'tags': ['t4', 't5', 't6']
    }

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    p = PlayContext()
    # add_tqm_variables(variable_manager, loader=loader, play=p)

# Generated at 2022-06-11 10:00:48.907203
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    validate_data = {
        'action': 'test',
        'notify': ['handler_task_include'],
        'tags': ['include_handler_task_include'],
    }
    handler_task_include = HandlerTaskInclude(data=validate_data)
    assert handler_task_include.data == handler_task_include.check_options(validate_data, validate_data)

# Generated at 2022-06-11 10:00:49.404093
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-11 10:01:01.919416
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.template import Templar
    host = "127.0.0.1"
    name = "test_task"
    role = Role()
    block = Block()
    handler = HandlerTaskInclude()
    play_context = PlayContext(remote_user="testuser", remote_password="testpass", port="123")
    task_include = TaskInclude()
    task_include.set_loader(Templar(loader=None, variables=None))
    task_include.set_block_list([block])
    task_include.set_parent_block(block)
    task_include.set_play(play_context)
    task_include.set_

# Generated at 2022-06-11 10:01:07.553878
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    HandlerTaskInclude:load() method unit test.
    '''

    data = {
        'handlers': [
            'main.yml',
            {
                'name': 'my_handler',
                'include_tasks': {
                    'file': 'tasks/include.yml'
                }
            }
        ]
    }

    # Unit test for method load of class HandlerTaskInclude
    handler_task_include = HandlerTaskInclude.load(data)

    assert handler_task_include.get_name() == data['handlers'][1]['include_tasks']['file']

# Generated at 2022-06-11 10:01:16.944183
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.base import Base
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Set up data object needed by load
    data = AnsibleUnicode("")

    # Set up block object needed by load
    blocks = [Base()]
    hosts = [Host(name="localhost"), Host(name="otherhost")]
    block = Block(play=None, role=None, task_include=None, use_role=None, handlers=[])

# Generated at 2022-06-11 10:01:25.717636
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # load the inventory
    variable_manager = VariableManager()
    loader = DictDataLoader({
        "some_inventory": """
            [all]
            localhost ansible_connection=local
            [some_group]
            localhost ansible_connection=local
        """,
    })
    inventory = InventoryManager(loader=loader, sources=["some_inventory"])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 10:01:29.518287
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({'include': 'tasks'}) is not None
    assert HandlerTaskInclude.load({'include': 'handlers'}) is not None
    assert HandlerTaskInclude.load({'include': 'tasks', 'listen': 'handler_name'}) is not None

# Generated at 2022-06-11 10:01:31.090304
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert isinstance(t, object)


# Generated at 2022-06-11 10:01:40.011205
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = {'include': 'test.yml'}
    ret = HandlerTaskInclude.load(data)
    assert ret.action == 'include'
    assert ret.args['name'] == 'test.yml'

    data = {'include': 'test.yml', 'tasks': [{'action': {'module': 'hoge'}}]}
    ret = HandlerTaskInclude.load(data)
    assert ret.action == 'include'
    assert ret.args['name'] == 'test.yml'

    # data = {'include': 'test.yml', 'tasks': [{'action': {'module': 'hoge'}}], 'listen': 'foo'}
    # ret = HandlerTaskInclude.load(data)
    # assert ret.action == 'include'
    # assert ret.args

# Generated at 2022-06-11 10:01:41.054383
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-11 10:01:51.331295
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Handlers can be loaded with the same function as tasks, because
    the TaskInclude class is used for both.  However, it is more
    difficult to test the differences between them.
    '''

    def check_valid(data):
        '''
        `data` is a dict that should be accepted by the load() method.
        '''

        result = HandlerTaskInclude.load(data)
        assert isinstance(result, Handler)

    def check_not_valid(data):
        '''
        `data` is a dict that should not be accepted by the load() method.
        '''

        from ansible.errors import AnsibleParserError
        try:
            result = HandlerTaskInclude.load(data)
        except AnsibleParserError:
            pass

# Generated at 2022-06-11 10:01:52.376918
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-11 10:02:11.441021
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    host = Host('127.0.0.1',port=22)
    block = Block('127.0.0.1',port=22)
    task_include = TaskInclude()
    variable_manager = VariableManager()
    variable_manager.set_inventory(host.get_vars())
    ansible_vars = variable_manager.get_vars(host=host, include_hostvars=True, include_delegate_to=False)
    task_include = TaskInclude()
    task_include._load_tags = ['abc']

# Generated at 2022-06-11 10:02:13.178037
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(
        data = {
            "include" : "include_handler"
            },
        variable_manager = None,
        loader = None
    )

# Generated at 2022-06-11 10:02:16.143730
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  # mock_loader=None, mock_variable_manager=None, mock_block=None, mock_role=None, mock_task_include=None, mock_data=None):
    assert 0 == HandlerTaskInclude.load(None, None, None, None, None, None)

# Generated at 2022-06-11 10:02:17.122846
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()

# Generated at 2022-06-11 10:02:17.798678
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-11 10:02:24.886647
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-11 10:02:33.713277
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    val_data = { 'listen': ['test_handler_listen'], 'name': 'test_handler_name' }
    val_block = { 'name': 'test_handler_block_name' }
    val_role = { 'name': 'test_handler_role_name' }
    val_task_include = { 'name': 'test_handler_task_include_name' }
    val_variable_manager = { 'name': 'test_handler_variable_manager_name' }
    val_loader = { 'name': 'test_handler_loader_name' }


# Generated at 2022-06-11 10:02:35.110433
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None

# Generated at 2022-06-11 10:02:36.582112
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()

# Generated at 2022-06-11 10:02:38.514539
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    print("HandlerTaskInclude: ", handler_task_include)

# Generated at 2022-06-11 10:03:12.235619
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def check_HandlerTaskInclude_load_return_type(arg):
        assert isinstance(arg, HandlerTaskInclude)

    # fake ansible.playbook.block.Block
    class FakeBlock:
        pass

    fake_block = FakeBlock()

    # fake role
    class FakeRole:
        pass

    fake_role = FakeRole()

    # fake ansible.playbook.task_include.TaskInclude
    class FakeTaskInclude:
        pass

    fake_task_include = FakeTaskInclude()

    # fake ansible.vars.manager.VariableManager
    class FakeVariableManager:
        pass

    fake_variable_manager = FakeVariableManager()

    # fake ansible.parsing.dataloader.DataLoader
    class FakeDataLoader:
        pass

    fake_data_loader = FakeData

# Generated at 2022-06-11 10:03:20.533347
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-11 10:03:31.505092
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    # basic instantiation of a Host (with nothing)
    my_host = Host(name="my_host")
    my_group = Group(name="my_group")
    my_group.add_host(my_host)
    my_groups = []
    my_groups.append(my_group)

    variable_manager = VariableManager()
    variable_manager.set_inventory(my_groups)

    # basic instantiation of a PlayContext (with nothing)
    my_play_context = PlayContext()

    # test for valid data

# Generated at 2022-06-11 10:03:38.627244
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    play = Play()
    play.name = 'test_play'
    play.hosts = [u'localhost']

    # Non-trivial case
    td = {
        u'include_tasks': {
            u'file': u'roles/test/tasks/main.yml',
            u'name': u'Test'
        }
    }

    handler = HandlerTaskInclude.load(td, block=play, play_context={})

    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, TaskInclude)
    assert handler.action == 'include_tasks'
    assert handler.name == 'Test'
    assert handler.file == 'roles/test/tasks/main.yml'

# Generated at 2022-06-11 10:03:43.019368
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = {}
    role = {}
    block = {}
    data = {}
    variable_manager = {}
    loader = {}
    hti = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert(hti.loader == loader)
    assert(hti.block == block)
    assert(hti.role == role)
    assert(hti.task_include == task_include)



# Generated at 2022-06-11 10:03:49.425497
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class Masque(object):
        def __init__(self,  **kwargs):
            self.__dict__.update(kwargs)
        def __repr__(self):
            return '%s(**%r)' % (self.__class__.__name__, self.__dict__)

    data = {'handlers': {'always': {'listen': 'all'}}}
    block = Masque(name='all')
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    print(handler._block)
    print(handler._valid_attrs)
    print(handler.notify)
    print(handler._listen_callback_notify)

# Generated at 2022-06-11 10:03:57.052057
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.variable_manager import VariableManager
    from ansible.inventory.vars import Variable
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VarsManager

    inventory = InventoryManager(loader=DataLoader())
    host_localhost = Host(name='localhost')
    host_localhost.set_variable('foo', 'bar')
    host_localhost.set_variable('baz', ['a', 'b', 'c'])
    host_localhost.set_variable('spam', dict(a='b'))

# Generated at 2022-06-11 10:04:01.288883
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
	data = { 'x' : 'y' }
	block = MockBlock()
	role = MockRole()
	task_include = MockTaskInclude()
	variable_manager = MockVariableManager()
	loader = MockLoader()
	assert isinstance(HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader), HandlerTaskInclude)


# Generated at 2022-06-11 10:04:03.324396
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #print("This is a HandlerTaskInclude test.")
    HandlerTaskInclude.load(None, None, None, None, None, None)
    #print("Finished the HandlerTaskInclude test.")


# Generated at 2022-06-11 10:04:07.251732
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(
        data,
        block,
        role,
        task_include,
        variable_manager,
        loader)

    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-11 10:04:53.003338
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    obj = HandlerTaskInclude.load({})
    assert obj.__class__.__name__ == "HandlerTaskInclude"

# Generated at 2022-06-11 10:04:53.450883
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 10:05:02.578826
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Unit test for method load of class HandlerTaskInclude
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.attribute import FieldAttribute

    def load_data(self, data, validate_only=False):
        data = super(VariableManager, self).load_data(data, validate_only=validate_only)

        if isinstance(data, list):
            new_data = []
            for d in data:
                if isinstance(d, dict):
                    new_data.append(self.add_fallbacks(d))
        elif isinstance(data, dict):
            new_data = self.add_fallbacks(data)

        return new_

# Generated at 2022-06-11 10:05:06.185399
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'tasks':'tasks.yml'}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    assert HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader) is not None

# Generated at 2022-06-11 10:05:06.996226
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-11 10:05:14.317440
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    import os

    dataloader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=dataloader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    role = Role()
    block = Block()
    task = Task()
    block.set_name('test_block')
    role.set_name('test_role')
    task.set_name('test_task')

# Generated at 2022-06-11 10:05:21.684595
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
#
# def test_load():
#     pass
#
# def test_validate_dependencies():
#     pass
#
# # Unit test for the method get_valid_attributes()
# def test_get_valid_attributes():
#
#     # Create an object to unit test
#     valid_attributes = TaskInclude.VALID_ATTRIBUTES
#
#     # Perform the unit test
#     t = Handler()
#     assert t.get_valid_attributes() == valid_attributes

# Generated at 2022-06-11 10:05:25.060402
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    from ansible.playbook.block import Block

    t = HandlerTaskInclude()
    t.block = Block()
    t.task_include = None

    assert(isinstance(t,HandlerTaskInclude))

# Generated at 2022-06-11 10:05:32.252214
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['localhost']))
    variable_manager.set_play_context(PlayContext(variable_manager=variable_manager, loader=loader))

# Generated at 2022-06-11 10:05:42.066413
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    verify_data={
        'hosts': 'all',
        'tasks': [
            {
                'name': 'Big switch',
                'local_action': {
                    'module': 'migrate_setup',
                    'server': '{{ inventory_hostname }}',
                    'password': '{{ cli_password }}'
                }
            }
        ]
    }
    data = {
        'include': '_big_switch.yml'
    }
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert handler.static  == '_big_switch.yml'
    assert handler.data == verify_data