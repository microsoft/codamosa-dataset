

# Generated at 2022-06-11 09:57:07.005590
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    d = dict()
    d['name'] = 'test'
    d['test'] = 'test'
    d['listen'] = 'test'

    HandlerTaskInclude.load(d)


# Generated at 2022-06-11 09:57:09.934874
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({"include": "foo.yml"}) is not None
    assert HandlerTaskInclude.load({"include": "foo.yml", "forks": "5"}) is not None

# Generated at 2022-06-11 09:57:20.539253
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'handlers': [
            {
                'name': 'test2',
                'listen': 'ok',
                'include_tasks': {
                    'foo': 'bar',
                    'file': '/tmp/test.yml',
                    'static': True,
                    'listen': 'ok'
                }
            }
        ]
    }
    handlers = HandlerTaskInclude.load(data)
    assert handlers[0].name == 'test2'
    assert handlers[0].listen == 'ok'
    assert handlers[0].task_include.foo == 'bar'
    assert handlers[0].task_include.file == '/tmp/test.yml'
    assert handlers[0].task_include.static == True
    assert handlers[0].task_include.listen == 'ok'

# Generated at 2022-06-11 09:57:21.695671
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude()
    assert h

# Unit test TaskInclude static method load

# Generated at 2022-06-11 09:57:26.989320
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = {}
    host["name"] = "test_host"
    host["vars"] = {
        "variable": "value",
    }
    hosts = [ "test_host" ]
    play = {}
    blocks = []
    play["name"] = "test_play"
    play["hosts"] = hosts
    play["connection"] = "local"
    play["vars"] = {
        "variable": "value",
        "hostvars": {}
    }
    play["vars"]["hostvars"][host["name"]] = host["vars"]

# Generated at 2022-06-11 09:57:35.556666
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.block == None
    assert handler.role == None
    assert handler.task_include == None

    # Test for the correct execution of each method of the class
    data = {
        "block" : "block",
        "role" : "role",
        "task_include" : "task_include",
    }
    handler = HandlerTaskInclude.load(data, block="block", role="role", task_include="task_include")
    assert handler.block == data['block']
    assert handler.role == data['role']
    assert handler.task_include == data['task_include']

    loader = None

# Generated at 2022-06-11 09:57:37.337397
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    handler.load_data('/tmp/ansible/test/test.yml', True)

# Generated at 2022-06-11 09:57:46.438162
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_HandlerTaskInclude = ["listen: some_name"]
    my_HandlerTaskInclude_obj = HandlerTaskInclude.load(my_HandlerTaskInclude)
    print("\n"+str(my_HandlerTaskInclude_obj))

    assert my_HandlerTaskInclude_obj.block == None
    assert my_HandlerTaskInclude_obj.role == None
    assert my_HandlerTaskInclude_obj.task_include == None
    assert my_HandlerTaskInclude_obj.loop is None
    assert my_HandlerTaskInclude_obj.loop_args == []
    assert my_HandlerTaskInclude_obj.loop_with_items == []
    assert my_HandlerTaskInclude_obj.listen == "some_name"

# Generated at 2022-06-11 09:57:47.702223
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert (handler != None)

# Generated at 2022-06-11 09:57:51.603614
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block='block', role='role', task_include='task_include')

    assert handler._block == 'block'
    assert handler._role == 'role'
    assert handler._task_include == 'task_include'



# Generated at 2022-06-11 09:57:55.618960
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    
    pass

# Generated at 2022-06-11 09:58:04.463560
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class MockAnsibleModule:
        def __init__(self):
            self.params=dict()
        def params(self):
            return self.params
    class MockVars:
        def add_host(self,host):
            return
        def update_vars(self,vars):
            return
        def get_vars(self,vars):
            return
    class MockPlay:
        def __init__(self):
            self.host=host
        def get_vars(self,host):
            return
    class MockHost:
        def __init__(self,name):
            self.name=name
        def name(self):
            return self.name
    class MockTask:
        def __init__(self,name=None):
            self.name=name

# Generated at 2022-06-11 09:58:09.284541
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name='Restart Apache',
        include='restart_apache.yml',
        listen='restart_apache'
    )
    handler = HandlerTaskInclude.load(data)
    assert handler._name == 'Restart Apache'
    assert handler._task_include._role == ''
    assert handler._task_include._task_files == ['restart_apache.yml']

# test equality

# Generated at 2022-06-11 09:58:17.500595
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    import os

    inventory = {
        "client": {
            "hosts": ["192.168.0.1"]
        }
    }
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=["localhost"])
    groups = []
    for group_name in inventory:
        group = Group(name=group_name)

# Generated at 2022-06-11 09:58:26.281933
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os, sys
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    path = os.path.dirname( __file__ )
    f_open = open(path + '/../../../../examples/handlers/main.yml')
    f_data = f_open.read()
    f_open.close()

    pb = Play().load(f_data, variable_manager=VariableManager(), loader=None)
    handler = pb._handlers.pop()

    assert handler.name == 'restart apache'
    assert handler._listen == 'httpd'
    assert handler._include is None
    assert handler._loop is None
    assert handler._when == 'apache2_restart'

# Generated at 2022-06-11 09:58:29.784361
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = "test"
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = t.check_options(
        t.load_data(data, variable_manager=None, loader=None),
        data
    )
    assert handler



# Generated at 2022-06-11 09:58:38.532525
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import TaskVars
    from ansible.parsing.dataloader import DataLoader
    import yaml

    data = {
        'name' : 'Test handler task include',
        'block' : 'Test',
        'include' : {
            'tasks' : 'test_include.yml'
        }
    }


# Generated at 2022-06-11 09:58:45.738216
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    data = dict(
        name = 'something'
      , tasks = [dict(action='name={{stuff}} with some stuff')]
    )
    block = None
    role = None
    task_include = None
    variable_manager = VariableManager()
    loader = DataLoader()
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert(handler.name == 'something')
    assert(handler.tasks[0].name == 'name={{stuff}} with some stuff')

# Generated at 2022-06-11 09:58:54.083812
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop as mock_unfrackpath
    from units.mock.path import mock_open_if_exists
    load_args = (
        dict(
            include="test_include.yml",
            tasks=dict(main=dict(debug=dict(msg="included_debug"))),
        ),
        Block,
        None,
        None,
        VariableManager,
        DictDataLoader,
    )

    handler_task_include

# Generated at 2022-06-11 09:58:55.109242
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-11 09:58:59.722971
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = dict(
        handler=dict(
            tasks=dict(include="tasks/main.yml")
        )
    )
    handler = HandlerTaskInclude.load(data)
    assert handler is not None

# Generated at 2022-06-11 09:59:00.218420
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-11 09:59:01.370106
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #TODO: implement this test
    return


# Generated at 2022-06-11 09:59:02.835819
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # HandlerTaskInclude.load
    assert False # TODO: implement your test here


# Generated at 2022-06-11 09:59:10.454766
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.playbook.role import Role

    inventory = Inventory()
    variable_manager = ansible.vars.VariableManager(inventory)
    loader = ansible.parsing.dataloader.DataLoader()

    # minimal data for task include
    data = dict(
        name='include test',
        include='to_include',
        listen='all',
    )

    # minimal data for meta
    role = Role.load(
        dict(
            name='role_with_meta',
            default_vars=dict(
                hello='world',
            ),
            meta=dict(
                to_implement='abstraction',
            ),
        ),
        variable_manager=variable_manager,
        loader=loader
    )

    bloc = ansible.playbook.block

# Generated at 2022-06-11 09:59:12.930175
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ''' handler_task_include.py:HandlerTaskInclude '''


# if __name__ == "__main__":
#     m = HandlerTaskInclude()

# Generated at 2022-06-11 09:59:20.002567
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.reserved import  Reserved
    from collections import defaultdict

    # note: no vars and no loader
    variable_manager = VariableManager()
    variable_manager._fact_cache = defaultdict(dict)

    # note: no loader
    loader = None

    # note: no role
    role = None

    # block is playbook
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
   

# Generated at 2022-06-11 09:59:24.895601
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "include": "../../library/",
        "_raw_params": "bar"
    }

    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    hti = HandlerTaskInclude.load(
        data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader
    )
    print(hti)


# Generated at 2022-06-11 09:59:29.217925
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'name': 'debug-hello', 'include': 'debug.yml'}
    h = HandlerTaskInclude()
    h.load(data)
    assert h.block == None
    assert h.role == None
    assert h.task_include == None
    # assert h.loop == 'hosts'
    # assert h.name == 'debug'

# Generated at 2022-06-11 09:59:29.720490
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass