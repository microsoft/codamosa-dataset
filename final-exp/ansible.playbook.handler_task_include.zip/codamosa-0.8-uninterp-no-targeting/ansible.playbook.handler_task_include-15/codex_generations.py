

# Generated at 2022-06-21 00:32:22.420706
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import pwd
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.clean import module_response
    h = HandlerTaskInclude()
    home = os.path.expanduser('~')
    test_host = Host(name='test_host')
    test_host.vars['ansible_python_interpreter'] = AnsibleUnsafeText('/usr/bin/python')
    test_host.vars['ansible_user'] = AnsibleUnsafeText('ansible_user')
    test_host.groups = [InventoryManager('localhost'), ]
    test_host.groups[0].get_host(host_name=test_host)
   

# Generated at 2022-06-21 00:32:30.996104
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = [{'listen': 'test', 'include': 'include.yml'}] # data is a list
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'
    assert handler.loop is None
    assert handler.block == block
    assert handler.role == role
    assert handler.include_role == task_include

# Generated at 2022-06-21 00:32:37.653881
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        tasks=u'/home/user/playbook.yml',
        connection='local',
        become=False,
        become_user='',
        remote_user='',
        environment=dict(),
        args=dict(),
        any_errors_fatal=False,
        listen='notify_name',
    )
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    assert HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-21 00:32:42.943349
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = "foo.yml"
    example = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = example.load(data)
    assert handler is not None

# Generated at 2022-06-21 00:32:46.001102
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.block is None
    assert handler.task_include is None

# Generated at 2022-06-21 00:32:52.419197
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # test constructor (without arg)
    test_HandlerTaskInclude = HandlerTaskInclude(
        block = None,
        role = None,
        task_include = None,
    )

    test_HandlerTaskInclude = HandlerTaskInclude(
        block = "test_block",
        role = "test_role",
        task_include = "test_task_include",
        _role_block  = "test_role_block"
    )

# Generated at 2022-06-21 00:33:01.153477
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader=DataLoader()
    variable_manager=VariableManager()
    inventory=InventoryManager(loader, variable_manager, None)
    dest=Group(name='dest')
    inventory.add_group(dest)
    host=Host(name='host1')
    dest.add_host(host)

    data = dict(
        include = dict(
            file = 'main.yml'
        )
    )


# Generated at 2022-06-21 00:33:12.583139
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class DummyTaskInclude:
        def __init__(self):
            self.class_name = 'DummyTaskInclude'

        def load_data(self, data, variable_manager=None, loader=None):
            return 'result_of_load_data'

        def check_options(self, obj, data):
            return 'result_of_check_options'

    class DummyVariableManager:
        def __init__(self):
            self.class_name = 'DummyVariableManager'

    class DummyLoader:
        def __init__(self):
            self.class_name = 'DummyLoader'

    class DummyBlock:
        def __init__(self):
            self.class_name = 'DummyBlock'

    data = 'the_data'
    block = DummyBlock()
    role

# Generated at 2022-06-21 00:33:21.378664
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role import Role

    loader = DictDataLoader({
        "test.yml": """
        - include_tasks: test2.yml
          tags:
            - always
          when: always
        """
    })

    def load_file(filename):
        with open(filename, 'r') as f:
            return f.read()

    inventory = Inventory('localhost', loader=loader)
    play = Play().load(load_file("test.yml"), loader=loader, variable_manager=None)
    role = Role()
    when = 'always'


# Generated at 2022-06-21 00:33:23.048933
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    a = HandlerTaskInclude()

if __name__ == "__main__":
    print(test_HandlerTaskInclude())

# Generated at 2022-06-21 00:33:35.571083
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    p = PlayContext()
    data = {"listen": "some event callback"}
    variable_manager = VariableManager()
    loader = DictDataLoader(
        {
            "some_file_name": """
            - name: some task
              delegate_to:
            """
        }
    )
    variable_manager.set_inventory(Inventory(loader=loader))
    variable_manager.set_loader(loader)

    handler_task_include = HandlerTaskInclude()
    handler = handler_task_include.load(data, variable_manager=variable_manager, loader=loader)

    assert handler.get_name() == "some event callback"
    assert len(handler._tasks) == 1

# Generated at 2022-06-21 00:33:36.125316
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-21 00:33:44.481556
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    def check_load(data, expected):
        handler = HandlerTaskInclude.load(data)
        assert isinstance(handler, Handler)
        assert isinstance(handler, HandlerTaskInclude)
        assert isinstance(handler, TaskInclude)
        assert isinstance(handler.block, Block)
        assert handler.role is None
        assert isinstance(handler.task_include, TaskInclude)

# Generated at 2022-06-21 00:33:53.486353
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name = '?',
        become = '?',
        become_user = '?',
        listen = '?',
        remote_user = '?',
        tags = '?',
        tasks = '?',
        vars = '?'
    )
    handler = HandlerTaskInclude.load(data)
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.action._attributes['become'] == '?'
    assert handler.action._attributes['become_user'] == '?'
    assert handler.action._attributes['listen'] == '?'
    assert handler.action._attributes['name'] == '?'
    assert handler.action._attributes['remote_user'] == '?'

# Generated at 2022-06-21 00:33:56.699898
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        type='include', include='test.yml'
    )

    handler = HandlerTaskInclude.load(
        data
    )

# Generated at 2022-06-21 00:33:58.619055
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler



# Generated at 2022-06-21 00:34:00.443378
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test the constructor
    t = HandlerTaskInclude()
    assert t is not None
    assert isinstance(t, TaskInclude)
    assert isinstance(t, Handler)

# Generated at 2022-06-21 00:34:01.970191
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#######################################################################


# Generated at 2022-06-21 00:34:09.534524
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bo = HandlerTaskInclude(block=None, role=None, task_include=None)
    print(bo.VALID_INCLUDE_KEYWORDS)
    print(bo.__class__.__name__)
    print(bo.__doc__)
    print(bo.__dict__)
    print(bo.__module__)
    print(bo.__weakref__)


# Generated at 2022-06-21 00:34:19.606833
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = '''
    - include: test.yml
      listen: name1
      tags:
        - foo
        - bar
      when: 1 > 3
    '''
    variable_manager, loader = mock_load(data)
    task_include = HandlerTaskInclude()
    result = task_include.load(data, variable_manager=variable_manager, loader=loader)
    assert result.tags == ['foo', 'bar']

# end of test_HandlerTaskInclude_load()


# Generated at 2022-06-21 00:34:33.398337
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Create object of class HandlerTaskInclude
    handler = HandlerTaskInclude()

    assert handler.__dict__ == {'_role': None, '_parent': None, '_block': None, '_files': [], '_static_files': [], '_tasks': [], '_included_files': [], '_role_names': [], '_tasks_included': [], '_include_role_tasks': [], '_role_params': {}, '_use_tags': False, 'tags': [], 'run_once': False, '_role': None, '_parent': None, '_block': None}

    assert handler._role == None
    assert handler._parent == None
    assert handler._block == None
    assert handler.tags == []
    assert handler.run_once == False

# Generated at 2022-06-21 00:34:35.367719
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-21 00:34:45.472276
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test case 1:
    data1 = '''
    - name: Test case with listen attribute
      action: ping
      listen: test_event
    '''
    task_include = HandlerTaskInclude()
    handler1 = task_include.load(data1)

    assert(handler1.name == 'Test case with listen attribute')
    assert(handler1.action == 'ping')
    assert(handler1.listen == 'test_event')

    # Test case 2:
    data2 = '''
    - name: Test case with listen attribute
      action: ping
    '''
    handler2 = task_include.load(data2)

    assert(handler2.name == 'Test case with listen attribute')
    assert(handler2.action == 'ping')
    assert(handler2.listen is None)

# Generated at 2022-06-21 00:34:57.211667
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test valid case where listeners are present as a dictionary
    data = {
        'include': 'main.yml',
        'listen': 'restart'
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.listen == 'restart'
    assert handler.include == 'main.yml'

    # Test valid case where listeners are present as a list
    data = {
        'include': 'main.yml',
        'listen': ['restart', 'reload']
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.listen == ['restart', 'reload']
    assert handler.include == 'main.yml'

    # Test invalid case where listeners are present as a list and string

# Generated at 2022-06-21 00:35:06.243415
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """ Tests whether the load method of class HandlerTaskInclude works as intended. """
    # Initialize the objects needed to test the load method
    variable_manager = 'variable_manager'
    loader = 'loader'
    data = 'data'
    block = 'block'
    role = 'role'
    task_include = 'task_include'
    # Execute the method load and return its results
    return_value = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    # Assert that the load method returns a HandlerTaskInclude object
    assert isinstance(return_value, HandlerTaskInclude)


# Generated at 2022-06-21 00:35:14.618863
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


if __name__ == "__main__":

    import sys
    import unittest
    from mock import patch

    # Needed to run unit-test on method load of class HandlerTaskInclude
    from ansible.module_utils.facts import Facts
    from ansible.plugins.loader import callback_loader, module_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Patch Ansible Facts
    def get_ansible_version(self):
        return '2.5.5'
    setattr(Facts, 'get_ansible_version', get_ansible_version)

    # Patch Ansible Loader

# Generated at 2022-06-21 00:35:25.226885
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-21 00:35:26.356973
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # is there anything to test here?
    pass

# Generated at 2022-06-21 00:35:27.187844
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-21 00:35:35.374149
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    myinv = Inventory(loader=None, variable_manager=VariableManager())
    myinv.set_variable('ansible_user', 'root')
    myinv.set_variable('ansible_ssh_pass', 'password')
    myinv.set_variable('ansible_sudo_pass', 'password')
    myinv.set_variable('ansible_sudo_exe', '/usr/bin/sudo')
    myinv.set_variable('ansible_connection', 'ssh')
    myinv.set_variable('ansible_ssh_common_args', '')
    myinv.set_variable('ansible_ssh_executable', None)
    myinv.set_variable('ansible_shell_type', 'sh')



# Generated at 2022-06-21 00:35:52.575008
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.handler
    import ansible.inventory.host
    import ansible.vars.hostvars

    data = {'hosts': 'all', 'name': 'web', 'listen': 'yes'}

    block = ansible.playbook.block.Block()

    loader = ansible.parsing.dataloader.DataLoader()

    variable_manager = ansible.vars.variable_manager.VariableManager()
    variable_manager.extra_vars = {}

    variable_manager._fact_cache = ansible.vars.hostvars.HostVars(loader=loader, variable_manager=variable_manager)

    Load = HandlerTaskInclude.load
    handler = Load(data=data, block=block, variable_manager=variable_manager, loader=loader)

    # verify that handler was

# Generated at 2022-06-21 00:35:55.559863
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test with no data, expect false
    handler = HandlerTaskInclude.load(None)
    assert not handler

    # TODO: need more test cases

# Generated at 2022-06-21 00:35:56.914917
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  assert HandlerTaskInclude() != None

# Generated at 2022-06-21 00:36:04.811273
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class StaticVariableManager:
        def __init__(self, hostvars={}):
            self.hostvars = hostvars

    class StaticLoader:
        pass

    class StaticData:
        def __init__(self, name='name', tasks=[]):
            self.name = name
            self.tasks = tasks

    class StaticBlock:
        def __init__(self, name='name', parent=[], handlers=[]):
            self.name = name
            self.parent = parent
            self.handlers = handlers

    class StaticRole:
        def __init__(self, task_blocks=[], handlers_blocks=[]):
            self.task_blocks = task_blocks
            self.handlers_blocks = handlers_blocks

    class StaticTaskInclude:
        pass

    data = StaticData()

    block = Static

# Generated at 2022-06-21 00:36:15.191070
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    def create():
        return HandlerTaskInclude(block=None, role=None, task_include=None)

    assert create().__class__ == HandlerTaskInclude
    assert create().__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-21 00:36:17.201519
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-21 00:36:19.157308
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    print(hti)

# Generated at 2022-06-21 00:36:20.749958
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load('foo.yml') == None

# Generated at 2022-06-21 00:36:33.356057
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.helpers import load_list_of_tasks

    host = Host('h1', variable_manager=VariableManager())
    group = Group('g1', variable_manager=VariableManager())
    group.add_host(host)

# Generated at 2022-06-21 00:36:40.347300
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # HandlerTaskInclude.load() returns Handler object
    def _load(data):
        t = HandlerTaskInclude()
        return t.load(data)

    # HandlerTaskInclude.load() throws error if name is not present
    try:
        _load({})
    except:
        pass
    else:
        raise AssertionError("HandlerTaskInclude.load({}) didn't raise an error on missing name")


# Generated at 2022-06-21 00:36:50.439267
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-21 00:36:57.393812
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude(block=None, role=None, task_include=None).__dict__ == {'_block': None, '_role': None, '_task_include': None, '_attribute_errors': {}, '_ds': {}, '_dep_chain': None}


# Generated at 2022-06-21 00:37:02.423085
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load(): 
    data = {}
    block = {}
    role = {'path': '/home/kakel/projects/ansible-playbooks/roles/create-users'}
    task_include = {}
    variable_manager = {}
    loader = {}
    HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-21 00:37:04.353100
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TestHandlerTaskInclude.test_load()
    # TODO: implement
    pass

# Generated at 2022-06-21 00:37:05.531143
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include': 'common.yml'}
    assert HandlerTaskInclude.load(data)

# Generated at 2022-06-21 00:37:10.513798
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    
    # Testing Validation of include file
    assert HandlerTaskInclude.load({}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # Testing Validation of include file with listen keyword
    assert HandlerTaskInclude.load({'listen': None}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-21 00:37:14.392572
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # An object constructed with valid keyword arguments
    obj = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert obj is not None



# Generated at 2022-06-21 00:37:15.888537
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()

# Generated at 2022-06-21 00:37:25.898549
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from units.mock.vars_plugin import TestVarsModule

    # host selection
    loader, inventory, variable_manager = (
        TestVarsModule().setup_inventory_manager()
    )
    play = Play().load({
        'name': 'test',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'include': {'filename': 'main.yml'}}
        ]
    }, variable_manager=variable_manager, loader=loader)

    # create a task include
    t = HandlerTaskInclude()
    t.variable_manager = variable_manager

# Generated at 2022-06-21 00:37:28.604443
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = {
        'include': {
            'name': 'foo.yml',
        }
    }

    HandlerTaskInclude.load(handler)

# Generated at 2022-06-21 00:37:55.807097
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'
    assert handler.block == None
    assert handler.role == None
    assert handler.task_include == None
    assert handler.tags == set()
    assert handler.when == ''
    assert handler.name == 'handler'


# Generated at 2022-06-21 00:37:59.783067
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    block=None
    role=None
    task_include=None
    variable_manager=None
    loader=None

    # Constructor test
    hd = HandlerTaskInclude.load(data,block,role,task_include,variable_manager,loader)
    assert hd

if __name__ == "__main__":
    test_HandlerTaskInclude()

# Generated at 2022-06-21 00:38:03.075018
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None

# Generated at 2022-06-21 00:38:12.413850
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    
    data = {}
    data['handlers'] = {
        'handlers': {
            'test_handler': {
                'tasks': [
                    { 'test_task_1': { 'test_task_1': 'test_task_1' } },
                    { 'test_task_2': { 'test_task_2': 'test_task_2', 'block': { 'test_block': 'test_block' } } }
                ]
            }
        }
    }

    block = None
    role = None
    variable_manager = None
    loader = None
    
    handler_task_include = HandlerTaskInclude(block=block, role=role, task_include=None)
    handler = handler_task_include.load(data, variable_manager=variable_manager, loader=loader)

    assert handler

# Generated at 2022-06-21 00:38:15.135932
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    assert "listen" in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-21 00:38:23.655854
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create a test HandlerTaskInclude object
    handler_task_include = HandlerTaskInclude()

    # Create a test include data
    test_include = {
        'include' : 'test_file',
        'tasks': [
            {'name': 'test_task'}
        ]
    }

    # Call the method with the test data
    handler = handler_task_include.load(test_include)

    # Create a test HandlerTaskInclude Object from the method
    test_handler = HandlerTaskInclude(block=None, role=None, task_include=test_include)

    # Assert that the created test HandlerTaskInclude object is equal to the method's
    assert (test_handler._task == handler._task)
    assert (test_handler._block == handler._block)

# Generated at 2022-06-21 00:38:24.998214
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # handler = HandlerTaskInclude()
    assert True

# Generated at 2022-06-21 00:38:26.665719
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict()
    res = HandlerTaskInclude.load(data)
    assert res is not None


# Generated at 2022-06-21 00:38:40.407136
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True
    #     """
    #     Test with several different files
    #     """
    #     variable_manager = ansible.vars.VariableManager()
    #     loader = ansible.parsing.dataloader.DataLoader()

    #     for i in (
    #         dict(filename='valid01.yaml', error=None),
    #         dict(filename='valid02.yaml', error=None),
    #         dict(filename='valid03.yaml', error=None),
    #         dict(filename='invalid01.yaml', error='Unsupported parameter for import_playbook: missing'),
    #     ):
    #         with pytest.raises(i['error']):
    #             data_path = os.path.normpath(os.path.join(os.path.dirname(

# Generated at 2022-06-21 00:38:51.471337
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role.tasks import Task as RoleTask
    from ansible.playbook.handler import Handler
    import os
    import sys

    pwd = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, pwd + "/lib")

    from data import load_data
    from play_context import PlayContext

# Generated at 2022-06-21 00:39:32.745982
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskIncludeTest = HandlerTaskInclude()
    assert handlerTaskIncludeTest is not None

# Generated at 2022-06-21 00:39:42.577817
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # arrange
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.variable_manager import VariableManager
    from ansible.template import Templar

    data = dict(
        block=Block(),
        role=Role(),
        task_include=TaskInclude(),
    )
    block = data['block']
    block._task_cache = dict()
    task = Task()
    task._block = block
    block._task_cache[1] = task
    t = TaskInclude()

    # act

# Generated at 2022-06-21 00:39:46.862689
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    variables = dict(handler_listen='my_host')

    handler = HandlerTaskInclude.load(
        data=dict(
            include='some_file',
            listen='{{handler_listen}}'
        ),
        variable_manager=variables
    )

    assert handler.listen == 'my_host'
    assert handler.notify_list == ['my_host']

# Generated at 2022-06-21 00:39:55.079554
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    Host = None # Stub for unit test
    handler = HandlerTaskInclude()
    handler.check_options(None, None)
    handler.load(None, variable_manager=None, loader=None)
    handler.check_keywords(None, None)
    handler.get_includes(Host, variable_manager=None, loader=None, templar=None)

# Generated at 2022-06-21 00:39:57.572179
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    # TODO
    assert False


# Generated at 2022-06-21 00:40:07.122035
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.check_name('include')
    assert not HandlerTaskInclude.check_name('fubar')
    assert HandlerTaskInclude.check_name('incluDE')
    assert not HandlerTaskInclude.check_name('fubar')
    assert not HandlerTaskInclude.check_name('include_tasks')

    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t.block is None
    assert t.role is None
    assert t.task_include is None

# Generated at 2022-06-21 00:40:15.944811
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # data = {'key1': 'val1', 'key2': 'val2'}
    # variable_manager.set_host_variables(host, self._load_vars(host.vars))
    # self._set_unreachable_hosts(hosts)
    # _loader = DataLoader()
    # handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=_loader)
    assert True

# Generated at 2022-06-21 00:40:22.182846
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
#     my_dict = {
#         'name': 'all',
#         'notify': 'all',
#         'listen': 'all',
#     }
#     my_task_include = {
#         'name': 'all',
#         'include_role': 'all',
#         'listen': 'all',
#     }
#     my_role = None
#     my_block = None
#     variable_manager = None
#     loader = None
#
#     # Test with different values of dict
#     handler = HandlerTaskInclude.load(
#         my_dict,
#         block=my_block,
#         role=my_role,
#         task_include=my_task_include,
#         variable_manager=variable_manager,
#         loader=loader
#    

# Generated at 2022-06-21 00:40:23.043294
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert 1 == 1

# Generated at 2022-06-21 00:40:26.023100
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(data=[], block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-21 00:41:46.533689
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:41:48.029491
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()

# Generated at 2022-06-21 00:41:52.149772
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_obj = HandlerTaskInclude.load(data={'listen': 'testing'}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    assert handler_obj is not None

# Generated at 2022-06-21 00:41:52.808051
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-21 00:42:02.677335
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#     host = ansible.inventory.host.Host(name='webserver')
#     t = HandlerTaskInclude(
#         block=None,
#         role=None,
#         task_include=None,
#         )
#     t.load(
#         data={
#             'name': 'start nginx',
#             'listen': 'nginx started'
#             },
#         block=None,
#         role=None,
#         task_include=None,
#         variable_manager=None,
#         loader=None
#         )

# Generated at 2022-06-21 00:42:07.278555
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a handler.
    HandlerTaskInclude.load(data={},
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None)

# Generated at 2022-06-21 00:42:08.222597
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:42:11.010264
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    hti = HandlerTaskInclude()
    assert hti is not None

    # TODO: test other things