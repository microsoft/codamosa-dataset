

# Generated at 2022-06-21 00:32:13.366138
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass #TODO: Implement


# Generated at 2022-06-21 00:32:14.653898
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-21 00:32:15.967270
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude is not None

# Generated at 2022-06-21 00:32:23.679139
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # GIVEN
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    hosts = [
        'example_host1',
        'example_host2',
        'example_host3',
    ]
    test_data_loader = DataLoader()
    test_inventory = Inventory(loader=test_data_loader, hosts=hosts)
    test_variable_manager = VariableManager(loader=test_data_loader, inventory=test_inventory)
    block = None
    role = None
    task_include = HandlerTaskInclude(block=block, role=role)
    test_data = dict(
        debug=dict(
            msg='test_msg'
        )
    )
    # WHEN
    test_HandlerTaskIn

# Generated at 2022-06-21 00:32:28.889330
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name='testinclude', 
        include='handler_tasks.yml'
    )
    task_include = TaskInclude.load(data)
    handler = HandlerTaskInclude.load(data)

    assert task_include.name == 'testinclude'
    assert handler.name == 'testinclude'

# Generated at 2022-06-21 00:32:30.751568
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # TODO
    # test for HandlerTaskInclude.load and HandlerTaskInclude.load_data
    pass

# Generated at 2022-06-21 00:32:39.327142
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Define fixtures
    data = {
        'listen': 'ok_handler',
        'include': 'tasks/main.yml'
    }
    block = 'no_block'
    role = 'no_role'
    task_include = 'no_task_include'
    variable_manager = 'no_variable_manager'
    loader = 'no_loader'

    # Create object and call method
    obj_HandlerTaskInclude = HandlerTaskInclude(
        block=block,
        role=role,
        task_include=task_include
    )
    handler = obj_HandlerTaskInclude.load(
        data,
        block,
        role,
        task_include,
        variable_manager,
        loader
    )

    # Assertions

# Generated at 2022-06-21 00:32:41.401869
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude();
    assert handlerTaskInclude

# Generated at 2022-06-21 00:32:45.402444
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    rt = HandlerTaskInclude()

    assert rt.block == None

    assert rt.role == None

    assert rt.task_include == None


# Generated at 2022-06-21 00:32:56.077225
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.templating import Template
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from collections import namedtuple
    from io import StringIO

    Opts = namedtuple('Opts', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection', 'module_path'])