

# Generated at 2022-06-21 00:32:22.852135
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert isinstance(h, TaskInclude)
    assert isinstance(h, Handler)
    assert isinstance(h.block, TaskInclude.BLOCK_LIST)
    assert isinstance(h.task_include, TaskInclude)
    assert isinstance(h.VALID_INCLUDE_KEYWORDS, set)
    assert isinstance(h.VALID_INCLUDE_KEYWORDS, TaskInclude.VALID_INCLUDE_KEYWORDS)
    assert h._check_name is True
    assert h._use_containers is True


# Generated at 2022-06-21 00:32:23.653577
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
	pass

# Generated at 2022-06-21 00:32:33.800120
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.task

    playbook = ansible.playbook.PlayBook()
    block = ansible.playbook.block.Block()
    task = ansible.playbook.task.Task()
    task_include = ansible.playbook.task_include.TaskInclude()
    handler_task_include = HandlerTaskInclude(block=block, task=task, task_include=task_include)

    data = ''
    assert handler_task_include.load(data) == None

    data = {
        'name': 'test handler'
    }
    assert handler_task_include.load(data) == None

    data = {
        'name': 'test handler',
        'listen': 'hello world'
    }

# Generated at 2022-06-21 00:32:41.164979
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'name': 'testHandler'}
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    t = handler.load_data(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert t['name'] == 'testHandler'
    assert t['ignore_errors'] == False
    assert t['listen'] is None
    assert t['_block'] is None

    t = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert t['name'] == 'testHandler'
    assert t['ignore_errors'] == False
    assert t['listen'] is None
    assert t['_block'] is None

# Generated at 2022-06-21 00:32:46.191032
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    data = {
        "listen": "webservers",
        "include": "foo.yml"
    }
    VariableManager._variables = {}  # forcing update
    block = Block()
    role = RoleInclude()
    task_include = TaskInclude()
    ctx = PlayContext()
    ctx.variable_manager = VariableManager()


# Generated at 2022-06-21 00:32:48.764866
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block='', role='', task_include='')
    assert handler is not None

# Generated at 2022-06-21 00:32:50.713393
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj is not None

# Generated at 2022-06-21 00:32:56.969103
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test with no value for option `block`
    assert HandlerTaskInclude.load({'include': 'tasks/foo.yml'}) == 'include'

    # Test with value for option `block`
    assert HandlerTaskInclude.load({'include': 'tasks/foo.yml'}, block='handler-foo') == 'include'

# Generated at 2022-06-21 00:33:01.738734
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # setup_class(cls)
    #     t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    #     assert id(t) == id(t)
    #     pass
    pass

# Generated at 2022-06-21 00:33:10.155927
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    data = {
        'include': 'my.yml',
        'when': 'notified',
        'listen': 'my_handler'
    }
    block = Block()
    role = None
    task_include = TaskInclude(block=block)

    obj = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    handler = obj.load(data)

    assert handler

    assert handler._role is None
    assert handler._block == block
    assert handler._task is task_include
    assert handler._loader is None
    assert handler._when == 'notified'
    assert handler._only_if is None
    assert handler._name is not None
    assert isinstance

# Generated at 2022-06-21 00:33:13.982892
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None


# Generated at 2022-06-21 00:33:18.984940
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    # test constructor
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler._role is None
    assert handler._block is None

# Generated at 2022-06-21 00:33:25.432944
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        debug=dict(msg="test"),
        include=dict(include_playbook="playbook"),
        delegate_to=dict(host="host"),
        listen=dict(handler_name="handler")
    )
    handler = HandlerTaskInclude.load(data)
    print(handler)

# Generated at 2022-06-21 00:33:27.701146
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = { 'include': 'some_name' }
    tI = HandlerTaskInclude.load(data)

# Generated at 2022-06-21 00:33:36.970441
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        handler='copy',
        src='/etc/foo.conf',
        dest='/etc/bar.conf'
    )

    handler = HandlerTaskInclude.load(data)
    assert handler.action == 'copy'
    assert handler.name == 'copy'
    assert handler.args == dict(
        src='/etc/foo.conf',
        dest='/etc/bar.conf'
    )

# Generated at 2022-06-21 00:33:38.041414
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert 1 == 1


# Generated at 2022-06-21 00:33:39.690187
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()

# Generated at 2022-06-21 00:33:51.862992
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleError
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    def load_data(self, data, variable_manager=None, loader=None):
        return data

    # TODO: test `task_include`
    block = None
    role = Role()
    task_include = TaskInclude()


# Generated at 2022-06-21 00:33:53.265722
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h

# Generated at 2022-06-21 00:34:03.470857
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    host1 = Host('host1')
    host2 = Host('host2')
    host3 = Host('host3')
    host4 = Host('host4')
    host5 = Host('host5')
    host6 = Host('host6')

    host1.set_variable('ansible_ssh_host','IP')
    host2.set_variable('ansible_ssh_host','IP')
    host3.set_variable('ansible_ssh_host','IP')
    host4.set_variable('ansible_ssh_host','IP')
    host5.set_variable('ansible_ssh_host','IP')
    host