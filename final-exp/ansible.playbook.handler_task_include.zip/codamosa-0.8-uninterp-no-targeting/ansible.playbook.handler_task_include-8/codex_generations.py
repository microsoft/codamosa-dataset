

# Generated at 2022-06-21 00:32:14.230048
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude_load()
    assert isinstance(
        handler, Handler
    ), 'HandlerTaskInclude_load should return a Handler instance'

# Generated at 2022-06-21 00:32:23.035045
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.module_utils.urls import open_url
    import pytest

    class TestPlayContext(PlayContext):
        CLICONF_PLUGINS = (
            'url',
            'connection',
            'cli',
        )

        def __init__(self):
            super(TestPlayContext, self).__init__()

            self.pipelining = True

        def _set_plugin_options(self, opts):
            pass

    class TestLoader:

        def __init__(self):
            self._tasks = {
                'test_task': Task()
            }


# Generated at 2022-06-21 00:32:25.098679
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj is not None


# Generated at 2022-06-21 00:32:28.432089
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_obj = HandlerTaskInclude
    assert isinstance(handler_task_include_obj, HandlerTaskInclude)

# Unitest for method "load" of class HandlerTaskInclude

# Generated at 2022-06-21 00:32:30.352955
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # static method load
    assert HandlerTaskInclude.load == load

# Generated at 2022-06-21 00:32:39.082373
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def run(data, outcome):
        handler = HandlerTaskInclude.load(
            data,
            variable_manager=dict(),
            loader=dict(),
        )

        assert handler.get_name() == outcome.get('get_name()'), \
            'handler.get_name() == outcome.get(\'get_name()\')'
        assert handler.loop == outcome.get('loop'), 'handler.loop == outcome.get(\'loop\')'
        assert handler.use_task_loop == outcome.get('use_task_loop'), \
            'handler.use_task_loop == outcome.get(\'use_task_loop\')'

    # 1
    data = {
        'include': {
            'name': 'test',
        },
        'name': 'test',
    }

# Generated at 2022-06-21 00:32:46.403139
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude()
    context = {
      'name': 'debug',
      'handler': 'start',
      'include': 'main.yml'
    }
    handler = h.load(context)
    assert handler.name == 'debug'
    assert handler.handler == 'start'
    assert handler.include == 'main.yml'

# Generated at 2022-06-21 00:32:46.790096
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:32:51.454126
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {u'name': u'test', u'include': u'foo'}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler._play is not None

# Generated at 2022-06-21 00:32:52.246185
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:32:56.649043
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))


# Generated at 2022-06-21 00:33:09.897097
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import pytest

    # Test all keywords required for handler
    data = dict(
        name="test",
        delegate_to="localhost",
    )

    # Create task
    h = HandlerTaskInclude.load(data=data, block=None, role=None, task_include=None)

    # Test defaults
    assert h._role == None, "_role should be None"

    # Test overrides

# Generated at 2022-06-21 00:33:20.650381
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, call

    class TestHandlerTaskInclude(unittest.TestCase):

        # Testing the code calls inside the constructor __init__ of class HandlerTaskInclude
        @patch.object(TaskInclude, 'load_data')
        @patch.object(TaskInclude, 'check_options')
        def test_check_options(self, TaskInclude_check_options_mock, TaskInclude_load_data_mock):
            TaskInclude_load_data_mock.return_value = patch
            TaskInclude_check_options_mock.return_value = patch
            HandlerTaskInclude_obj = HandlerTaskInclude()


# Generated at 2022-06-21 00:33:23.288902
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "include": "./include.yml",
        "tags": "always"
    }
    t = HandlerTaskInclude.load(data)
    assert t.name == "include.yml"

# Generated at 2022-06-21 00:33:25.288861
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('In test_HandlerTaskInclude()')
    assert True


# Generated at 2022-06-21 00:33:27.295230
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Tests if the constructor of class HandlerTaskInclude is correct
    handlerTaskInclude = HandlerTaskInclude()
    if not isinstance(handlerTaskInclude, HandlerTaskInclude):
        print("Class HandlerTaskInclude constructor is incorrect")


# Generated at 2022-06-21 00:33:31.632001
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    file = 'tests/fixtures/handler_task_include_test.yml'
    data = {}

    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert(handler is not None)

# Generated at 2022-06-21 00:33:35.615149
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {
        'block', 'connection', 'delegate_facts', 'listen', 'name', 'private',
        'run_once', 'tags', 'task', 'vars', 'when'
    }

# Generated at 2022-06-21 00:33:42.235739
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Unit test: ansible.playbook.handler.HandlerTaskInclude._load
    '''
    print('\n=== BEGIN test_HandlerTaskInclude_load ====')

    data = dict(
        include = 'tasks/first_include.yml',
        list = ['a', 'b', 'c'],
        listen = ['one', 'two', 'three'],
    )

    h = HandlerTaskInclude.load(data)
    # print(h)
    assert isinstance(h, HandlerTaskInclude)

    print('=== END test_HandlerTaskInclude_load ====')

# Generated at 2022-06-21 00:33:47.311498
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    t = HandlerTaskInclude()

    # TODO:
    # write test for:
    # if isinstance(data, TaskInclude):
    #     raise AnsibleError("HandlerTaskInclude does not support recursive includes")
    pass

# Generated at 2022-06-21 00:33:54.662087
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'when', 'name', 'loop', 'static', 'ignore_errors', 'tags', 'listen', 'tasks'}

# Generated at 2022-06-21 00:34:02.698568
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	from ansible.inventory.manager import InventoryManager
	from ansible.vars.manager import VariableManager

	inventory = InventoryManager(['tests/test_inventory.ini'])
	variable_manager = VariableManager(inventory)
	variable_manager._extra_vars = {}

	test_data = '''
- {include: tests/test_handler_task_include.yml, listen: task_start_handler}
'''
	data = HandlerTaskInclude.load(test_data, variable_manager=variable_manager)

	assert data._listen == 'task_start_handler'
	assert data._block._unblock == 'always'

# Generated at 2022-06-21 00:34:11.902725
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    data = dict(
        include='handler1.yml',
        static='handler1.yml',
        name='handler1.yml',
        tags=['handler1'],
        _raw_params='handler1',
    )

    block = None
    role = RoleDefinition.load('', {}, None, None)
    task_include = TaskInclude.load(data)
    variable_manager = VariableManager()
    loader = Templar(variables=variable_manager)

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler.name == 'handler1.yml'

# Generated at 2022-06-21 00:34:23.582806
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.plugins import filter_loader  # used to register filter plugins
    filter_loader.add_directory('./lib/ansible/plugins/filter')

    variable_manager = DummyVars()
    variable_manager.add_section('vars')
    variable_manager.set_variable('vars', 'AMS_SITE_LIST', ['AMS', 'LON', 'FRD'])


# Generated at 2022-06-21 00:34:28.553756
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    This method creates a new Handler, which is a TaskInclude
    """
    pass

# Generated at 2022-06-21 00:34:29.858318
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-21 00:34:33.116474
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_handler_task_include = HandlerTaskInclude()
    assert my_handler_task_include is not None

# Generated at 2022-06-21 00:34:44.016188
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    # Create a fake block
    block = Block()
    loader = lookup_loader('dummy')
    # Create a fake context
    pc = PlayContext()
    # Create a fake task_include
    task_include = 'dummy test'
    # Create a fake data
    data = 'dummy test'
    # Create a fake variable_manager
    variable_manager = 'dummy test'
    # Create a HandlerTaskInclude
    hti = HandlerTaskInclude.load(data=data, block=block, task_include=task_include, variable_manager=variable_manager, loader=loader)
    # Check the values of the object

# Generated at 2022-06-21 00:34:44.625574
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert 0

# Generated at 2022-06-21 00:34:47.065779
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Ansible: test_HandlerTaskInclude_load")
    my_handler = HandlerTaskInclude()
    #TODO: test_HandlerTaskInclude_load
    pass



# Generated at 2022-06-21 00:35:02.222240
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task_include import TaskInclude

    v = VaultLib()
    v._load_decryption_keys()
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    data = AnsibleBaseYAMLObject.load(
        """
            - debug:
                var: test_me
        """, variable_manager=variable_manager, loader=None, vaults=v)

# Generated at 2022-06-21 00:35:06.492255
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    #print("handler: ", handler)

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-21 00:35:07.399038
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-21 00:35:07.890508
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:35:15.112086
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import ansible.constants as C

    play_context = PlayContext()
    play_context.load()
    templar = Templar(loader=None, variables={})

    loader = None
    variable_manager = None

# Generated at 2022-06-21 00:35:17.636024
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(data={}, block={'name': 'test'}, role={'name': 'test'}, task_include={'name': 'test'}) is not None

# Generated at 2022-06-21 00:35:19.890472
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    Test case for the HandlerTaskInclude class constructor.
    """
    pass

# Generated at 2022-06-21 00:35:31.491799
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'common.yml'
    }
    handler = HandlerTaskInclude.load(data, loader=None)

    assert handler is not None
    assert handler.static is False
    assert handler.block is None
    assert handler.role is None
    assert handler._role is None
    assert handler.task_include is None
    assert handler.task_includes is None
    assert handler.handler is None
    assert handler.name == data['include']
    assert handler.tags == set()
    assert handler.when is None
    assert handler.only_if is None
    assert handler.not_if is None
    assert handler.loop is None
    assert handler.loop_args is None

# Generated at 2022-06-21 00:35:41.108019
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Setup the test data
    data = dict(include=dict(somepath=dict(tasks=list())))

    # Run the method and make sure it accepts unexpected list and dict

    arg_validate_kwargs = dict(
        data=data,
        block=dict(),
        role=dict(),
        task_include=None,
        variable_manager=dict(),
        loader=dict()
    )
    result = HandlerTaskInclude.load(**arg_validate_kwargs)

    # Verify the results
    assert result is not None

# Generated at 2022-06-21 00:35:54.907506
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    import pytest

    # Preparing mock data
    # Preparing mock data
    block = Block()
    block.vars = dict()
    block.block = dict(
        tasks=[dict(action=dict(module='debug', args=dict(msg='Hi')))]
    )

# Generated at 2022-06-21 00:36:15.232069
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import json
    from ansible.errors import AnsibleError, AnsibleSyntaxError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()

    # test invalid reference
    data = {'include': {'invalid': 'invalid'}}
    try:
        HandlerTaskInclude.load(data)
        mock_exception('HandlerTaskInclude.load() syntax error', AnsibleSyntaxError)
    except AnsibleSyntaxError as exception:
        pass

    # test list
    data = {'include': {'list': ['foo', 'bar']}}
    handler = HandlerTaskInclude.load(data)
    assert handler is not None

    # test file

# Generated at 2022-06-21 00:36:25.052806
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   from ansible.inventory.host import Host
   from ansible.parsing.yaml.objects import AnsibleMapping
   from ansible.vars import VariableManager
   from ansible.template import Templar
   from ansible.utils.vars import combine_vars
   import ansible.constants as C

   # setup context for scope value
   inventory = Host('test')
   variable_manager = VariableManager(loader=None)
   variable_manager._fact_cache = {inventory: {}}
   variable_manager.set_inventory(inventory)
   block = AnsibleMapping()
   variable_manager.set_globals(block.vars)
   templar = Templar(loader=None, variables=variable_manager)

# Generated at 2022-06-21 00:36:25.832888
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:36:36.149108
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {"include_dir": "/etc/ansible/handlers", "include": "*.yml"}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    handler.load_data(data, variable_manager=variable_manager, loader=loader)
    handler.check_options(data, data)
    handler.__class__.load(data, block, role, task_include, variable_manager, loader)
    handler.__class__.VALID_INCLUDE_KEYWORDS
    handler.evaluate_tags(tags=None, skip_tags=None)
    handler.evaluate_conditional(conditional=None, all_vars=None)
   

# Generated at 2022-06-21 00:36:37.489533
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-21 00:36:45.265285
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager

    inventory = [
        Host(name="localhost", port=22),
        Host(name="other", port=22),
        Group(name="group1"),
        Group(name="group2")
    ]
    variable_manager = VariableManager()
    loader = DataLoader()

    task = Task()
    block = Block()
    role = Role()

    handler = HandlerTaskInclude.load

# Generated at 2022-06-21 00:36:55.269949
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Attempt to create object of class HandlerTaskInclude with all necessary parameters
    test_object = HandlerTaskInclude(block=None, role=None, task_include=None)

    # Attempt to create object of class HandlerTaskInclude with all available parameters
    test_object = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None,
        private_pyeclib=None,
        _include_hash=None,
        _search_path=None,
        _file_name=None,
        _line_number=None,
        _environment=None,
        _parent_block=None,
        _role=None,
        _task_include=None,
        loop=None
    )

# Generated at 2022-06-21 00:37:03.461455
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Constructor without arguments
    t = HandlerTaskInclude()
    assert t.__class__.__name__ == 'HandlerTaskInclude'
    assert t.task_include.__class__.__name__ == 'TaskInclude'

    # Constructor with arguments
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t.__class__.__name__ == 'HandlerTaskInclude'
    assert t.block == None
    assert t.role == None
    assert t.task_include == None

# Generated at 2022-06-21 00:37:04.450661
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj



# Generated at 2022-06-21 00:37:04.892846
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-21 00:37:34.138026
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Create dummies for the method to load

    data = {'include': 'foo.yml'}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    # Load the method normally
    obj_HandlerTaskInclude = HandlerTaskInclude()
    obj_handler = obj_HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    # Print the output of the load method
    print("OUTPUT: {}".format(obj_handler))

    # Assertions
    assert obj_handler.__class__.__name__ == 'Handler'
    assert obj_handler.block is None
    assert obj_handler.role is None
    assert obj_handler.task_include is None
    assert obj_handler.name is None


# Generated at 2022-06-21 00:37:34.918396
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:37:43.964995
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    def task_include_load(data, variable_manager=None, loader=None):
        return TaskInclude.load(data, variable_manager, loader)

    def handler_load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        return HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    def meta_load(data, variable_manager=None, loader=None):
        return HandlerTaskInclude(block, role, task_include).load_data(data, variable_manager, loader)


# Generated at 2022-06-21 00:37:47.608492
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude(None, None, None)
    print(handlerTaskInclude.VALID_INCLUDE_KEYWORDS)

test_HandlerTaskInclude()

# Generated at 2022-06-21 00:37:51.286911
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # This method is not testable
    # It relies on class Host, which is defined in another module
    # and on the global variable C
    return

# Generated at 2022-06-21 00:37:58.361526
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    include_class = HandlerTaskInclude.load(
        data={
            "include": "some_handler_name.yml",
            "name": "some identifiable name",
            "listen": "all"
        }
    )
    assert isinstance(include_class, HandlerTaskInclude)
    assert include_class._role is None
    assert include_class._block is None
    assert include_class._task_include is None

# Generated at 2022-06-21 00:38:10.725458
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    # Example vars for test_HandlerTaskInclude_load
    block_name = "example_block"
    test_block = Block(block_name)
    test_host = Host('test_host')
    test_hostvars = {'test_host': {}}
    test_variable_manager = VariableManager(loader=None, hosts=test_host, variables=test_hostvars)
    test_data = {'name': 'test_handler', 'tags': ['test']}

    # Create a handler task without tags
    test_handler = HandlerTaskInclude

# Generated at 2022-06-21 00:38:14.355410
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   handler = HandlerTaskInclude()
   print(handler)

# Testing class HandlerTaskInclude
test_HandlerTaskInclude()

# Generated at 2022-06-21 00:38:18.571322
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    def test_load():
        handler = HandlerTaskInclude(block=None, role=None, task_include=None)
        # handler.load()
        return handler
    handler = test_load()
    assert handler is not None
    # print(handler)

# Generated at 2022-06-21 00:38:19.624551
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass