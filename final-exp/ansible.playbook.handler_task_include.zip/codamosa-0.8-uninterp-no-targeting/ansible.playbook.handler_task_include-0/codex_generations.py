

# Generated at 2022-06-21 00:32:15.904612
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    l = dict(
        name="mytask",
        include_handler=dict(
            include='myinclude'
        )
    )

    h = HandlerTaskInclude.load(l)
    assert isinstance(h, HandlerTaskInclude)
    assert h.validate() == True
    assert h.include_tasks == 'myinclude'


# Generated at 2022-06-21 00:32:21.559787
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({"include": "somefile.yml"})
    assert HandlerTaskInclude.load({"include": "somefile.yml", "tags": "tag1"})
    assert HandlerTaskInclude.load({"include": "somefile.yml", "when": "ansible_os_family=='RedHat'"})
    assert HandlerTaskInclude.load({"include": "somefile.yml", "listen": "add_network_config"})

# Generated at 2022-06-21 00:32:26.499761
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_inc = HandlerTaskInclude()
    print(handler_task_inc.VALID_INCLUDE_KEYWORDS)
    assert False

if __name__ == "__main__":
    test_HandlerTaskInclude()

# Generated at 2022-06-21 00:32:27.713257
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task = HandlerTaskInclude()
    assert True

# Generated at 2022-06-21 00:32:39.140312
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    myhost = Host()
    myhost.name = "host0"
    hostList = []
    hostList.append(myhost)
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    inventory.add_group('group0')
    inventory.add_host(host=Host(name='host0'), group='group0')
    var_manager = VariableManager()
    var_manager.set_inventory(inventory)

    mytask = Task()
    myblock = Block()
    myblock

# Generated at 2022-06-21 00:32:52.544492
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    host = Host(name="localhost")
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    task = HandlerTaskInclude(block=None, role=None, task_include=None)

    #assert task.__class__.__name__ == "HandlerTaskInclude"
    #assert task.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))
    #assert task.include_tasks == task.include_tasks
    #

# Generated at 2022-06-21 00:33:00.609653
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #create a test HandlerTaskInclude object
    test_HandlerTaskInclude = HandlerTaskInclude()

    #confirm that test_HandlerTaskInclude has correct parameter
    assert test_HandlerTaskInclude.valid_include_keywords == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

    #confirm that test_HandlerTaskInclude has correct metod
    assert test_HandlerTaskInclude.check_options == TaskInclude.check_options
    assert test_HandlerTaskInclude.load_data == TaskInclude.load_data
    assert test_HandlerTaskInclude.load == HandlerTaskInclude.load
    assert test_HandlerTaskInclude.load_file == TaskInclude.load_file

# Generated at 2022-06-21 00:33:07.940688
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': '{{ play_dir }}/handlers/main.yml',
        'listen': 'test event',
        'tags': ['test']
    }
    handler = HandlerTaskInclude.load(data)
    assert handler is not None
    assert handler
    assert handler.tags == ['test']

# Generated at 2022-06-21 00:33:20.004543
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.variable_manager import VariableManager

    my_data = """
      - name: "task one"
        debug:
          msg: "task one succeeded"
      - include_role:
          name: test
    """

    def get_file_path_mock(file_name, source_basedir):
        if source_basedir is None or source_basedir == '/':
            return '%s/%s' % (self.get_dir_path_mock(file_name), file_name)

        return '%s/%s' % (source_basedir, file_name)


# Generated at 2022-06-21 00:33:31.856564
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible
    from ansible import constants as C
    from ansible.errors import AnsibleParserError
    data = dict(
        handler_file='test/handler/test.yml',
        name='Test Handler'
    )
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(
        data, block, role, task_include, variable_manager, loader
    )
    assert type(handler) == Handler
    assert handler.name == 'Test Handler'
    assert type(handler.blocks) == list
    assert type(handler.file_name) == str
    # assert handler.file_name == C.DEFAULT_HANDLER_PATH + '/test/handler/test.yml'
    # TODO: Set up

# Generated at 2022-06-21 00:33:42.374423
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()

    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-21 00:33:52.233793
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #Arguments required to instantiate object of HandlerTaskInclude
    block = None
    role = None
    task_include = TaskInclude()
    data = {'tasks':'tasks/main.yaml'}
    #object of HandlerTaskInclude class
    HandlerTaskInclude_instance =  HandlerTaskInclude(block, role, task_include)
    # test if the object is instance of class HandlerTaskInclude
    assert isinstance(HandlerTaskInclude_instance, HandlerTaskInclude)
    #test if the constructor takes 4 arguments.
    assert HandlerTaskInclude.__init__.__code__.co_argcount == 4
    #validate return value of load method
    assert isinstance(HandlerTaskInclude.load(data), HandlerTaskInclude)

# Generated at 2022-06-21 00:33:55.988390
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.VALID_INCLUDE_KEYWORDS == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-21 00:33:57.333711
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude



# Generated at 2022-06-21 00:34:01.388996
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = TaskInclude(None, None, None)

    handler_task_include = HandlerTaskInclude(None, None, task_include)
    handler_task_include.load({'name': 'test', 'hosts': 'all', 'listen': 'teardown'})
    assert handler_task_include.listen == ['teardown']

# Generated at 2022-06-21 00:34:03.002765
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	# TODO: write me
	pass

# Generated at 2022-06-21 00:34:13.038052
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.plugins.loader import PluginLoader
    import pprint
    import ansible.constants as C

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'should_do': True}

    # Create a loader
    loader = PluginLoader(
        'action',
        'freebsd_service',
        'ansible.plugins.action.freebsd_service'
    )

    # Create a block object
    from ansible.playbook.block import Block
    block = Block()

    # Create a role object
    from ansible.playbook.role import Role
    role = Role()

    # Create a task object
    from ansible.playbook.task import Task
    task_include = Task()

    # Create a HandlerTaskInclude object
    handler = Handler

# Generated at 2022-06-21 00:34:17.569709
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, TaskInclude)
    assert isinstance(handler, Handler)


# Generated at 2022-06-21 00:34:20.804276
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))==HandlerTaskInclude.VALID_INCLUDE_KEYWORDS


# Generated at 2022-06-21 00:34:24.144037
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include = HandlerTaskInclude()
    assert handler_task_include



# Generated at 2022-06-21 00:34:27.589789
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-21 00:34:30.278638
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert isinstance(t, TaskInclude)
    #assert isinstance(t, Host)

# Generated at 2022-06-21 00:34:42.716078
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from unittest import TestLoader, TextTestRunner
    from unittest import TestCase, TestSuite


    class Test_HandlerTaskInclude(TestCase):

        def runTest(self):
            loader = TestLoader()
            suite = TestSuite((
                loader.loadTestsFromTestCase(self),
            ))
            runner = TextTestRunner()
            runner.run(suite)

        def test_listen(self):

            import os

            from ansible.vars import VariableManager
            from ansible.inventory import Inventory
            from ansible.parsing.dataloader import DataLoader
            from ansible.playbook import Playbook
            from ansible.playbook.play import Play



# Generated at 2022-06-21 00:34:43.622100
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-21 00:34:46.934536
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'main.yml',
    }
    dynamic_task_list = HandlerTaskInclude.load(data)

# Generated at 2022-06-21 00:34:48.525861
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h != None

# Generated at 2022-06-21 00:34:59.032897
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class HandlerTaskInclude_check_options:
        def __init__(self):
            self.result = None

        def __call__(self, options, data):
            self.result = (options, data)
            return None

    class HandlerTaskInclude_load_data:
        def __call__(self, options, variable_manager=None, loader=None):
            assert variable_manager == 'variable_manager'
            assert loader == 'loader'
            return options

    class TaskInclude:
        VALID_INCLUDE_KEYWORDS = 'VALID_INCLUDE_KEYWORDS'

    class Data:
        def __init__(self):
            self.data = 'data'
        def get(self, a, b):
            assert a == 'handler'
            assert b == True

# Generated at 2022-06-21 00:34:59.678545
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert True

# Generated at 2022-06-21 00:35:00.293851
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-21 00:35:10.885597
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict()
    valid_data = dict()
    data['foo'] = 'xyz'
    block = 'xyz'
    role = 'xyz'
    task_include = 'xyz'
    variable_manager = 'xyz'
    loader = 'xyz'

    handler_task_include = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    assert handler_task_include.load(data, block=block, role=role, task_include=task_include, variable_manager = variable_manager, loader = loader) is not None

# Generated at 2022-06-21 00:35:25.547632
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Host, Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-21 00:35:31.788868
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Test: test_HandlerTaskInclude_load")
    playbooks = ['../../../../elasticsearch/roles/redhat/tasks/main.yml']
    data = {
        "name": "elasticsearch-install",
        "include": {
            "name": "elasticsearch_install",
            "playbooks": playbooks
        }
    }
    assert HandlerTaskInclude.load(data) is not None

# Generated at 2022-06-21 00:35:32.552987
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-21 00:35:34.821578
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-21 00:35:36.914290
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    return handlerTaskInclude

# Generated at 2022-06-21 00:35:40.982501
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'hosts': 'all',
        'gather_facts': 'no',
        'listen': 'stop',
        'tasks': [
            {'command': 'echo "Hello World"'},
            {'include': {
                'name': 'dynamic.yml'
            }}
        ]
    }
    h = HandlerTaskInclude.load(data)
    assert h is not None

# Generated at 2022-06-21 00:35:48.359153
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    c = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert c.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))
    assert isinstance(c, Handler)
    assert isinstance(c, TaskInclude)

# Generated at 2022-06-21 00:35:49.252872
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:35:54.192441
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = """{"include": "test_include.yaml"}"""
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    # assert handler.include_tasks == 'test_include.yaml'
    assert handler.include_role == 'test_include.yaml'

# Generated at 2022-06-21 00:35:54.955075
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-21 00:36:00.503387
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    pass

# Generated at 2022-06-21 00:36:13.034691
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    yaml_input = """
    - name: Handler to create a new netgroup entry
      include_tasks: new_netgroup.yml

    - name: Handler to create a new user account
      include_tasks: new_user.yml
    """

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    h_task_include = HandlerTaskInclude.load(yaml_input, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 00:36:24.982734
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # The test data
    data = {
        "name": "test",
        "include": "test.yml",
        "always_run": True,
        "ignore_errors": True,
        "run_once": True,
        "listen": "some_event",
        "tags": ["tag1", "tag2"],
        "register": "the_result",
        "local_action": "test",
    }

    # Expected instantiation of HandlerTaskInclude

# Generated at 2022-06-21 00:36:35.487035
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.association import Association
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    import ansible.constants as C
    import ansible.utils.template as template
    import os
    import tempfile
    import yaml

    # Create a temporary file
    tmp = tempfile.NamedTemporaryFile()

    # Create the Ansible loader object
    loader = DataLoader()

    # Create an Ansible variable manager object
    variable_manager = VariableManager()

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create an Ansible file object

# Generated at 2022-06-21 00:36:41.700981
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert type(handler) == HandlerTaskInclude
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.VALID_INCLUDE_KEYWORDS == {'conditional', 'defaults', 'vars', 'static', 'listen'}
    assert handler.VARS_CACHE_ENABLED is False


# Generated at 2022-06-21 00:36:48.770359
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include = HandlerTaskInclude()

    handler_task_include.block = None
    handler_task_include.role = None
    handler_task_include.task_include = None

    data = {
        'name': 'Test handler include unit test',
        'block': 'foo',
        'include': 'wombat',
        'ignore_errors': 'bar',
        'listen': 'cheese'
    }

    handler = handler_task_include.load(data, block=None, role=None, task_include=None)

    assert handler.block == 'foo'
    assert handler.name == 'Test handler include unit test'
    assert handler.action._role == None
    assert handler.action._task_include == None
    assert handler.action.listen == 'cheese'

# Generated at 2022-06-21 00:36:56.761054
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Setup
    role = {'vars': {'foo': 'bar'}}
    loader = None
    data = {'tasks': 'test/test_include_role.yml'}
    task_include = TaskInclude.load(data=data, block=None, role=role, task_include=None, loader=None)
    block = None
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context._options = {}

# Generated at 2022-06-21 00:36:58.432600
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude(block=[], role=[], task_include=[])
    assert obj is not None
    assert isinstance(obj, Handler)
    assert isinstance(obj, TaskInclude)

# Generated at 2022-06-21 00:37:05.954289
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def test_Builder_load(data, expected):  
        t =  HandlerTaskInclude.load(data)
        assert data['name'] == expected['name']
        assert data['include'] == expected['include']
        assert data['handler'] == expected['handler']
        
    data = {
        "include": {
            "name": "name",
            "include": "include",
            "handler": "handler"
        },
        "name": "name",
        "handler": "handler"
    }
    expected = {
        'name': 'name',
        'include': 'include',
        'handler': 'handler'
    }
    test_Builder_load(data, expected)

# Generated at 2022-06-21 00:37:09.046357
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({'include': 'tasks/foo.yml'}) == HandlerTaskInclude.load(
        {'include': 'tasks/foo.yml', 'name': 'foo'})

# Generated at 2022-06-21 00:37:20.953630
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #TODO: finish test
    # h = HandlerTaskInclude()
    pass

# Generated at 2022-06-21 00:37:27.525391
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Check if the class `HandlerTaskInclude` is really able to import a playbook.
    """
    handler = HandlerTaskInclude.load({'import_playbook': 'my_playbook.yml'})
    assert handler._block.role is None
    assert handler._playbook.filename == 'my_playbook.yml'

# Generated at 2022-06-21 00:37:28.155382
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:37:33.224244
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'name': 'Ansible-handler'}
    task_include_obj = HandlerTaskInclude()
    handler = task_include_obj.load(data)
    assert handler.name == 'Ansible-handler'

# Generated at 2022-06-21 00:37:34.519420
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'included.yml',
        'hosts': 'all',
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.include == data['include']

# Generated at 2022-06-21 00:37:36.651682
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.action is None

# Generated at 2022-06-21 00:37:44.377820
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader

    fake_loader = DictDataLoader({
        "foo": """
        - name: this task is run WITH_NOTIFY condition is true
          debug: msg="notify was called"
        """,
        "bar": """
        - name: this task is run WITH_LOOP condition is true
          debug: msg="loop was called"
        """
    })

    hosts = ['localhost', 'otherhost']
    inventory = InventoryManager(loader=fake_loader, sources=hosts)
    variable_manager = VariableManager(loader=fake_loader, inventory=inventory)

    # create a play with a single task


# Generated at 2022-06-21 00:37:45.103428
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:37:55.002100
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role

    block = Block()
    counters = play_counters()
    block._play = play(counters)

    host = Host()
    block._play.set_loader(loader())
    block._play.set_variable_manager(variable_manager())

    task = Task()
    task = task.load({'action': {'module': 'ping'}}, block, host)

    block.add_task(task)

    role = Role()
    role = role

# Generated at 2022-06-21 00:37:57.572776
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "include": "all",
        "name": "Updating"
    }
    HandlerTaskInclude(data)


# Generated at 2022-06-21 00:38:30.538140
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Set up the HandlerTaskInclude object
    # from ansible.playbook.handler import Handler
    # from ansible.playbook.task_include import TaskInclude
    # from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    task_data = {
        'name': 'test task',
        'hosts': 'testhost',
        'action': 'testaction',
        'local_action': 'testlocalaction',
    }


# Generated at 2022-06-21 00:38:38.203142
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'name': 'Test',
        'include': 'handler_task.yaml',
        'listen': "TestListener"
    }

    # noinspection PyBroadException
    try:
        handler = HandlerTaskInclude.load(data)
    except:
        assert False, "HandlerTaskInclude.load() did not parse data correctly"

# Generated at 2022-06-21 00:38:39.046836
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-21 00:38:50.888479
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test empty constructor
    handler1 = HandlerTaskInclude()
    assert handler1.block == None
    assert handler1.role == None
    assert handler1.task_include == None

    # test constructor with one parameter
    handler2 = HandlerTaskInclude(block = "block")
    assert handler2.block == "block"
    assert handler2.role == None
    assert handler2.task_include == None

    # test constructor with two parameters
    handler3 = HandlerTaskInclude(block = "block", role = 100)
    assert handler3.block == "block"
    assert handler3.role == 100
    assert handler3.task_include == None

    # test constructor with three parameters
    handler4 = HandlerTaskInclude(block = "block", role = 100, task_include = "task")

# Generated at 2022-06-21 00:38:53.440978
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test = TaskInclude.load({'include': "provision_base.yml"})
    assert test

# Generated at 2022-06-21 00:39:01.768810
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create a temporary file and write the data
    temp_file = tempfile.NamedTemporaryFile(mode="w", encoding='utf-8')

    temp_file.write("""
    - include_tasks: stuff.yml
      name: hello, world
    """)

    temp_file.seek(0)

    # test for new behavior, include file must exist or else exception is thrown
    with pytest.raises(yaml.YAMLError):
        task = HandlerTaskInclude.load(temp_file.read().encode('utf-8'))

    temp_file.close()

# Generated at 2022-06-21 00:39:02.654761
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:39:13.664755
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.attribute import Attribute
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data = {'foo': 'bar', 'name': 'baz'}
    variable_manager = VariableManager()
    loader = DataLoader()

    handler = HandlerTaskInclude.load(data,
                                      block=None,
                                      role=None,
                                      task_include=None,
                                      variable_manager=variable_manager,
                                      loader=loader)

    assert handler.name == 'baz'
    assert handler.foo == 'bar'
    assert handler.task is None
    assert handler.role is None
    assert handler.block is None
    assert handler.task_include is None
    assert isinstance(handler.handler, Attribute)

# Generated at 2022-06-21 00:39:20.470849
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude(): 
    data = {}
    block = None
    role = None    
    task_include = None
    variable_manager = None
    loader = None
    t = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    print(t)
    assert t is not None

test_HandlerTaskInclude()

# Generated at 2022-06-21 00:39:26.183310
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    print(type(t))
    print(t.__dict__)
    print(t.VALID_INCLUDE_KEYWORDS)
    print(TaskInclude.VALID_INCLUDE_KEYWORDS)



# Generated at 2022-06-21 00:40:16.989989
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'
    assert handler.get_name() == '<NO-TASK>'
    assert handler._role is None
    assert handler._block is None

# Generated at 2022-06-21 00:40:29.276043
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Set up a TaskInclude class object
    task_include = TaskInclude()

    # Set up a data dictionary with TaskInclude class 
    # attributes and other attributes which are not
    # defined in TaskInclude class
    data = dict(
        block=None,
        connection=None,
        delegate_to=None,
        environment={},
        ignore_errors=None,
        listen=None,
        module_args={},
        name=None,
        no_log=None,
        poll=0,
        register=None,
        remote_user=None,
        role=None,
        run_once=None,
        sudo=None,
        task_include=task_include,
        until=None,
        when=None
    )

    # Create a HandlerTaskInclude class object
    handler_task

# Generated at 2022-06-21 00:40:39.638996
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Template
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager))
    variable_manager.extra_vars

# Generated at 2022-06-21 00:40:49.454611
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    host = Host('example')
    play_context = PlayContext(play=Play.load({'name': 'test', 'hosts': ['example']}))
    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader)
    action_loader.add_directory('')
    t = HandlerTaskInclude(block=None, role=None, task_include=None)


# Generated at 2022-06-21 00:40:57.975482
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        handlers='/var/tmp/handlers',
        tasks='ok',
    )
    handler = HandlerTaskInclude ( block=None, role=None, task_include=None)
    res_handler = handler.load_data(data, variable_manager=None, loader=None)
    assert res_handler['name'] == data['handlers'], "HandlerTaskInclude failed with wrong res_handler name %s" % (res_handler['name'])
    assert res_handler['block'] == data['handlers'], "HandlerTaskInclude failed with wrong res_handler block %s" % (res_handler['block'])

# Generated at 2022-06-21 00:41:08.255048
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    variable_manager = None
    loader = None

    # block = Block()
    # role = Role()

    block = None
    role = None

    host = None
    task_include = TaskInclude(block=block, role=role)

    data = {
        "tasks": "tasks/main.yaml",
        "handlers": "handlers/main.yaml",
        "vars": "vars/main.yaml"
    }


# Generated at 2022-06-21 00:41:14.001048
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display

    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:41:16.524794
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:41:20.969088
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    with open('sample_tasks.yml', 'r') as sample_tasks_file:
        sample_tasks = sample_tasks_file.read()
    print(sample_tasks)
    # TODO: code here...

# Generated at 2022-06-21 00:41:33.570232
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.script import InventoryScript
    from ansible.plugins.loader import find_plugin
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inv = InventoryManager(loader=DataLoader())
    inv.add_group(Group('test'))
    inv.add_host(Host('node01'), group='test')

    v = VariableManager(loader=DataLoader(), inventory=inv)
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
