

# Generated at 2022-06-21 00:32:15.435266
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass



# Generated at 2022-06-21 00:32:18.110962
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Instance a HandlerTaskInclude without parameters
    HandlerTaskInclude()


# Generated at 2022-06-21 00:32:30.305180
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # create object TaskInclude (which is a parent of HandlerTaskInclude)
    ti = TaskInclude()

    # create dictionary with required and some optional parameters for HandlerTaskInclude.load()
    data = dict(
        name = 'test',
        tasks = ['tasks'],
        handlers = ['handlers']
    )

    # load data to HandlerTaskInclude
    handler = HandlerTaskInclude.load(data)

    # check instance of HandlerTaskInclude
    if isinstance(handler,HandlerTaskInclude) == False:
        raise AssertionError('HandlerTaskInclude.load() did not return an instance of HandlerTaskInclude class')
        return

    # check if values set in data dictionary were successfully set in HandlerTaskInclude

# Generated at 2022-06-21 00:32:39.376423
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name='test',
        listen="restart-web",
        tasks = {
            'task' : {
                'action' : {
                    'module' : 'command',
                    'args' : 'whoami',
                },
            },
        },
    )
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None)
    print("name of handler: {}".format(handler.name))
    print("listen of handler: {}".format(handler.listen))
    print("type of handler: {}".format(type(handler)))

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-21 00:32:40.233168
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-21 00:32:53.244042
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.vars.manager import VariableManager

    h = HandlerTaskInclude()
    assert h._included_file is None
    assert h._role is None
    assert h._task_include is not None
    assert isinstance(h._block, Play)
    assert h._info is None

    # check __init__()
    nm = 'notify_tomcat_restart_' + str(1)
    tn = 'restart tomcat when deploy is done'
    li = ["tomcat"]
   

# Generated at 2022-06-21 00:33:01.521242
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test the HandlerTaskInclude.load() function
    """

    # Test data for load()

# Generated at 2022-06-21 00:33:02.508238
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude({'include':'src/tests/playbooks/include_check.yml', 'forks': 12}) # construct a HandlerTaskInclude

# Generated at 2022-06-21 00:33:06.341368
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'listen': 'test_listen',
        'action': 'test_action',
        'tags': 'test_tags',
        'when': 'test_when',
        'async': 'test_async',
        'poll': 'test_poll',
        'delegate_to': 'test_delegate_to',
        'delegate_facts': 'test_delegate_facts',
        'loop': 'test_loop',
        'loop_with_items': 'test_loop_with_items',
        'run_once': 'test_run_once',
    }

    t = HandlerTaskInclude()


# Generated at 2022-06-21 00:33:18.586752
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os

    current_dir = os.path.dirname(__file__)
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=current_dir + '/hosts')

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory)

    host = inventory.get_host('host1')

    variable_manager.set_host_variable(host, 'ansible_python_interpreter', 'fake_interpreter')
    variable_manager.set_host_variable(host, 'ansible_connection', 'fake_connection')

# Generated at 2022-06-21 00:33:27.369241
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict()
    data['name'] = "test-name"
    data['tags'] = ["test-tag"]
    data['include'] = "include.yml"
    data['listen'] = "test-listen"
    
    handler = HandlerTaskInclude.load(data)
    print ("HandlerTaskInclude: ", handler)

# test_HandlerTaskInclude()

# Generated at 2022-06-21 00:33:36.866197
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    data = {
        'name'      : 'test_handlertaskinclude',
        'include'   : 'test1.yml',
        'listen'    : 'test_listen',
    }
    handler = HandlerTaskInclude.load(
        data=data,
        block=Block(),
        task_include=TaskInclude(
            loader=DataLoader(),
            variable_manager=VariableManager(),
        ),
    )


# Generated at 2022-06-21 00:33:39.635421
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        HandlerTaskInclude()
    except AttributeError:
        pass
    except Exception:
        assert False, 'HandlerTaskInclude() raised Exception instead of AttributeError'



# Generated at 2022-06-21 00:33:51.829667
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    print('Hello!')

    import yaml
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    my_inventory = InventoryManager(loader=DataLoader(), sources=['my_hosts'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=my_inventory)

    # Create variable for HandlerTaskInclude
    # Dictionary of variable 'data'
    data = {
        'include': 'tasks/main.yml',
        'name': 'Include main.yml'
    }

    print(yaml.dump(data, default_flow_style=False))
    print('')


# Generated at 2022-06-21 00:34:02.702961
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """ Test for HandlerTaskInclude.load method """
    data = {
        'name': 'test',
        'listen': 'yes',
        'static': ['foo', 'bar']
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.name == 'test'
    assert handler.orig_name == 'test'
    assert handler.listen is True
    static = handler.static
    assert isinstance(static, list)
    assert static == ['foo', 'bar']
    assert handler.file is None
    assert handler.action is None

    data['name'] = 'other'
    data['when'] = 'listen_failed'
    handler = HandlerTaskInclude.load(data)
    assert handler.name == 'other'
    assert handler.orig_name == 'other'

# Generated at 2022-06-21 00:34:11.903369
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create a HandlerTaskInclude object
    hti = HandlerTaskInclude()

    # Create the ansible loader object
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # Create the variable manager object
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    # Create a play
    from ansible.playbook.play import Play

# Generated at 2022-06-21 00:34:13.538942
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude() is not None

# Generated at 2022-06-21 00:34:24.242036
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Arrange
    # data and block are required to create a HandlerTaskInclude object
    data = {}
    block = None
    handler = HandlerTaskInclude(block=block)

    # Mock of method check_options
    def mock_check_options(self, task, data):
        return task

    # Mock of method load_data
    def mock_load_data(self, data, **kwargs):
        # Important, we have to return a task or the real method check_options
        # will raise an exception
        return {}

    # monkeypatch the private methods check_options and load_data
    HandlerTaskInclude._check_options = mock_check_options
    HandlerTaskInclude._load_data = mock_load_data

    # Act and Assert
    assert handler.load(data) is not None

# Generated at 2022-06-21 00:34:34.564323
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from collections import namedtuple
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task

    # Create blocks
    block1 = namedtuple('Block', ['name', 'block_vars', 'task_vars', 'vars', 'dynamic_block_vars', 'dynamic_vars', 'parent_block', 'host_block_var'])('block1', {}, {}, {}, {}, {}, '', '')
    # Create block2 as parent of block1

# Generated at 2022-06-21 00:34:39.290516
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # This is the data that we need to pass to the method
    data = {}

    # Check if load method returns value that is not None
    handler = HandlerTaskInclude.load(data)
    assert handler != None

# Generated at 2022-06-21 00:34:49.285022
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_data = {
        'name': 'test1',
        'listen': 'test',
        'include': 'test'
    }
    handler = HandlerTaskInclude.load(handler_data)
    assert handler.name == 'test1'
    assert handler.listen == 'test'
    assert handler.get_vars() == {}

# Generated at 2022-06-21 00:34:56.478228
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    raw_data = """
    name: Test task include
    ignore_errors: yes
    loop: "{{ list_of_things }}"
    """

    # Set up task include object
    task_include = HandlerTaskInclude(block=None, role=None, task_include=None)

    # Load data
    data = task_include.load_data(raw_data)

    # Test
    assert data['name'] == 'Test task include'
    assert data['ignore_errors'] == True
    assert data['loop'] == "{{ list_of_things }}"

# Generated at 2022-06-21 00:35:08.077257
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import plugin_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.basic import AnsibleModule
    import ansible.constants as C
    import json

    module_loader = AnsibleModule(argument_spec={})
    module_loader._load_path = C.DEFAULT_MODULE_PATH
    module_loader.HASH_BEHAVIOUR = "replace"

    loader = plugin_loader()
    loader.all(module_loader)

    play

# Generated at 2022-06-21 00:35:08.976046
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()

# Generated at 2022-06-21 00:35:15.350353
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude('block', 'role', 'task_include')


# Generated at 2022-06-21 00:35:20.672856
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    target = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert target.VALID_INCLUDE_KEYWORDS == {'tags', 'tasks', 'vars', 'name', 'block', 'variables', 'listen'}

# Generated at 2022-06-21 00:35:32.553975
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a sample handler object
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'listhosts', 'listtasks', 'listtags', 'syntax'])
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 00:35:34.805508
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude != None

# Generated at 2022-06-21 00:35:35.813737
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-21 00:35:44.910754
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t.block == None
    assert t.role == None
    assert t.task_include == None
    assert t.notify == None
    assert t.listen == None
    assert t.tags == ['all']
    assert t.when == None
    assert t.only_if == None
    assert t.async_val == 0
    assert t.poll == 0
    assert t.transport == 'smart'
    assert t.run_once == False
    assert t.name == 'dummy_task'
    assert t.args == None
    assert t.action == None
    assert t.delegate_to == None
    assert t.first_available_file == None
    assert t.until == None

# Generated at 2022-06-21 00:35:56.645974
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    test_object = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert (test_object is not None)

# Generated at 2022-06-21 00:36:04.677973
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test without block, role and task_include
    handler = HandlerTaskInclude()

    assert isinstance(handler, HandlerTaskInclude)

    # Test with block
    block = []
    handler = HandlerTaskInclude(block=block)

    assert isinstance(handler, HandlerTaskInclude)
    assert handler._block == block

    # Test with role
    role = {}
    handler = HandlerTaskInclude(role=role)

    assert isinstance(handler, HandlerTaskInclude)
    assert handler._role == role

    # Test with task_include
    task_include = {}
    handler = HandlerTaskInclude(task_include=task_include)

    assert isinstance(handler, HandlerTaskInclude)
    assert handler._task_include == task_include

    # Test with block, role and task_include
    block = []
   

# Generated at 2022-06-21 00:36:15.157826
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from collections import namedtuple

    task = Task()
    variable_manager = object()
    loader = object()
    block = object()
    role = object()
    task_include = object()

    handler = HandlerTaskInclude(block, role, task_include)
    assert handler.task_include is not None
    assert handler.task_include.name is None
    assert handler.task_include.free_form is None
    assert handler.task_include.role is None
    assert handler.task_include.tags is None
    assert handler.task_include.any_tags is None
    assert handler.task_include.not_tags is None
    assert handler.task_include.only_tags is None

# Generated at 2022-06-21 00:36:22.601692
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = TaskInclude()
    data = {'name': 'test1', 'listen': 'test1'}
    block = 'test block'
    role = 'test role'
    variable_manager = 'variable_manager'
    loader = 'loader'
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler != None
    assert handler.name == data['name']
    assert handler.listen == data['listen']

# Generated at 2022-06-21 00:36:23.601463
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:36:29.927206
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	data = dict(
		action        = dict(module='something', args='whatever'),
		when          = 'something',
		register      = 'something',
		ignore_errors = 'something',
		delegate_to   = 'something',
		listen        = 'something'
	)

	block = None
	role = None
	task_include = None
	variable_manager= None
	loader = None

	handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)
	handler = handler.check_options(
		handler.load_data(data, variable_manager=variable_manager, loader=loader),
		data
	)
	assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-21 00:36:38.853543
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor import play_context
    from ansible.playbook.play import Play

    def load_data(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        return TaskInclude.load(data, block, role, task_include, variable_manager, loader)

    def check_options(t, data):
        return TaskInclude.check_options(t, data)

    inventory = Inventory("/tmp/ciao")
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = play_context.PlayContext()

    #begin from method load of class Handler

# Generated at 2022-06-21 00:36:40.081602
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: This test needs to be rewritten!
    pass


# Generated at 2022-06-21 00:36:43.114669
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude.load(data=dict(
        include='whatever',
        name='test'
    ))
    assert handler._block == None

# Generated at 2022-06-21 00:36:53.566956
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Invalid initialization.
    t = HandlerTaskInclude()
    assert t is not None
    assert t.block is None
    assert t.role is None
    assert t.task_include is None

    # Valid initialization.
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t is not None
    assert t.block is None
    assert t.role is None
    assert t.task_include is None

    t = HandlerTaskInclude(block=1, role=2, task_include=3)
    assert t is not None
    assert t.block == 1
    assert t.role == 2
    assert t.task_include == 3



# Generated at 2022-06-21 00:37:10.907257
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    # from ansible.inventory.manager import InventoryManager

    var_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-21 00:37:21.040374
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Prepare mocks
    class MockTaskInclude:
        def check_options(self, include_tasks, data):
            return {
                        'name': include_tasks
                    }
        def load_data(self, data, variable_manager, loader):
            return {
                        'name': include_tasks
                    }
    mock_task_include = MockTaskInclude()

    # Test
    handler = HandlerTaskInclude.load(
                    {
                        'include_tasks': 'my_tasks.yml'
                    }, task_include=mock_task_include)
    assert handler

# Generated at 2022-06-21 00:37:22.030650
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-21 00:37:26.044292
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include='some_role',
    )
    handler = HandlerTaskInclude.load(data)
    assert handler.attributes['include'] == 'some_role'



# Generated at 2022-06-21 00:37:29.971533
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'name': 'foo', 'action': 'bar'}
    handler = HandlerTaskInclude.load(
        data=data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-21 00:37:41.987994
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import pytest
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    h = HandlerTaskInclude()
    h.task_name = lambda: None
    h.block = None
    h.role = None

    h.task = Task()
    h.task.block = lambda: None
    h.task.role = lambda: None

    v = HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert v == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))

    task_include = TaskInclude()
    task_include.block = lambda: None
    task_include.role = lambda: None

# Generated at 2022-06-21 00:37:43.309453
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-21 00:37:45.740685
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    objHndlerTaskInclude = HandlerTaskInclude()
    assert objHndlerTaskInclude is not None

# Generated at 2022-06-21 00:37:47.732185
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude().__class__.__name__ == 'HandlerTaskInclude'



# Generated at 2022-06-21 00:37:59.846861
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # sample passing data to be handled
    data = {
        'include': 'some-name.yml',
        'tasks': ['task1', 'task2'],
        'vars': {'a': 1, 'b': 2},
        'listen': 'yes'
    }

    # sample block data to be injected
    block = [
        {'name': 'task1', 'action': {'module': 'shell'}, 'args': {'command': 'echo 1'}},
        {'name': 'task2', 'action': {'module': 'shell'}, 'args': {'command': 'echo 2'}}
    ]

    # instantiate the object
    handler = HandlerTaskInclude(block=block)

    # invoke method to be tested
    result = handler.load(data)

    # check result
   

# Generated at 2022-06-21 00:38:31.882855
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Configuration
    config = ConfigManager()
    config.verify_python_version()
    config.set_variable_manager_class('ansible.vars.manager.VariableManager')
    config.set_inventory_manager_class('ansible.inventory.manager.InventoryManager')
    config.set_executor_class('ansible.executor.task_queue_manager.TaskQueueManager')
    config.set_loader_class('ansible.parsing.dataloader.DataLoader')
    config.set_variable_manager_class('ansible.vars.manager.VariableManager')

# Generated at 2022-06-21 00:38:33.105294
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None

# Generated at 2022-06-21 00:38:43.559951
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = dict(
        domain=None,
        tasks=None,
        _role=None,
        static=True,
        vars=dict(),
        vars_prompt=dict(),
    )

    data = dict(
        include=dict(
            name='something',
        )
    )

    handler = HandlerTaskInclude.load(data=data, task_include=task_include)
    # attrs = ['block', 'ignore_errors', 'listen', 'name', 'notify', 'register', 'role', 'tasks', 'when']
    for attr in ('block', 'ignore_errors', 'listen', 'name', 'notify', 'register', 'role', 'tasks', 'when'):
        assert attr in handler.__dict__

# Generated at 2022-06-21 00:38:54.607059
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.block
    import ansible.playbook.play_context
    import ansible.vars.hostvars
    import ansible.template.vars
    b = ansible.playbook.block.Block()
    pc = ansible.playbook.play_context.PlayContext()
    ti = ansible.playbook.task_include.TaskInclude()
    hv = ansible.vars.hostvars.HostVars(vars=[])
    t = ansible.template.vars.Vars(loader=None, variable_manager=None, templar=None)

    # TODO: Test following lines
    hti = HandlerTaskInclude(block=b, role=None, task_include=ti)
    hti.load({})

# Generated at 2022-06-21 00:38:56.279410
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    pass

# Generated at 2022-06-21 00:39:04.197283
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include': 'test1.yaml'}
    variable_manager = {}
    loader = {}
    try:
        hti = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    except Exception as e:
        assert False, "Exception was raised: %s" % e.message

    # Some attributes where set in the object, so I commented them
    # assert hti.name == 'test1.yaml', 'Name should be \'test1.yaml\' but it is %s' % hti.name
    # assert hti.path == 'test1.yaml', 'Path should be \'test1.yaml\' but it is %s' % hti.path

# Generated at 2022-06-21 00:39:14.395018
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    import os

    loader = None
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    host = Host('test_host')

    file_name = os.path.realpath(__file__)
    file_directory = os.path.dirname(file_name)
    directory_name = os.path.basename(file_directory)
    directory_parent = os.path.dirname(file_directory)
    test_handlers_directory = os.path.join(directory_parent, 'test_handlers')


# Generated at 2022-06-21 00:39:18.155410
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   # Create fake block to pass with handler
   # block = Block(block=block, role=role)
   # handler = Handler
   pass

# Generated at 2022-06-21 00:39:25.440299
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='localhost')
    variable_manager.set_inventory(inventory)

    data = {
        "handlers": [
            {
                "listen": "all",
                "name": "restart web servers",
                "shell": "/sbin/restart httpd"
            }
        ]
    }


# Generated at 2022-06-21 00:39:33.601775
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # 1. try to load handler without required argument:
    # data
    handler = HandlerTaskInclude(None)
    with pytest.raises(TypeError) as excinfo:
        handler.load()
    assert "too few arguments" in str(excinfo.value)

    # 2. try to load handler with some required argument:
    # data
    with pytest.raises(TypeError) as excinfo:
        handler.load(dict())
    assert "too few arguments" in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        handler.load(dict(), loader=object())
    assert "too few arguments" in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        handler.load(dict(), variable_manager=object())
   

# Generated at 2022-06-21 00:40:29.042240
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop as mock_unfrackpath
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.errors import AnsibleError
    from ansible.playbook.included_file import IncludedFile

    names = ('action', 'async', 'poll', 'register', 'ignore_errors')

# Generated at 2022-06-21 00:40:39.514098
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    my_loader = DataLoader()
    my_inventory = InventoryManager(loader=my_loader, sources='')
    my_variable_manager = VariableManager(loader=my_loader, inventory=my_inventory)
    my_variable_manager.set_play_context(PlayContext(play=None))
    my_templar = Templar(loader=my_loader, variables=my_variable_manager)


# Generated at 2022-06-21 00:40:45.148651
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Initialize parameters for constructor of class HandlerTaskInclude
    block = None
    role = None
    task_include = None
    hti = HandlerTaskInclude(block, role, task_include)
    # Check if it is an instance of class HandlerTaskInclude
    assert isinstance(hti, HandlerTaskInclude)

# Generated at 2022-06-21 00:40:55.652859
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
        handler = t.check_options(
            t.load_data(data, variable_manager=variable_manager, loader=loader),
            data
        )

        return handler
    data = {'include': 'handler_action.yml', 'static': None, 'loop': [], 'loop_control': {}, 'listen': []}
    assert load(data) is None

# Generated at 2022-06-21 00:40:58.311738
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("no test, need to understand the params")


# Generated at 2022-06-21 00:41:03.831481
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(
        {
            "include": "some_handler_task.yml",
            "listen": "some_event"
        },
        None,
        None,
        None,
        None,
        None
    )

# Generated at 2022-06-21 00:41:16.124838
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test various combination of parameters of the load() method of HandlerTaskInclude
    """

    # test_no_params
    task_include = HandlerTaskInclude.load(
        dict(
            name='test_no_params',
            include='roles/foo/tasks/bar.yml'
        )
    )
    assert task_include.__class__.__name__ == 'HandlerTaskInclude'
    assert task_include.get_name() == 'test_no_params'
    assert task_include.tags == []
    assert task_include.when == ''
    assert task_include.only_tags == []
    assert task_include.except_tags == []
    assert task_include.include == 'roles/foo/tasks/bar.yml'
    assert task_include.static is False
   

# Generated at 2022-06-21 00:41:16.915177
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-21 00:41:17.693079
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-21 00:41:26.198524
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()

    variable_manager.extra_vars = {
        "test_var": "test_value",
        "test_inventory": ["1.1.1.1", "2.2.2.2"],
        "test_hash": {'k1': 'val1', 'k2': 'val2'}
    }

    variable_manager.set_inventory(Inventory(loader=DataLoader(), variable_manager=variable_manager, host_list=['1.1.1.1']))

    context = PlayContext()

    handler_