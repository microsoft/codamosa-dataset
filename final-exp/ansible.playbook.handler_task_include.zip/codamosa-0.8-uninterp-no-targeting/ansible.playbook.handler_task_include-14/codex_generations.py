

# Generated at 2022-06-21 00:32:21.222115
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'block': None,
        'role': None,
        'task_include': None,
        'variable_manager': None,
        'loader': None,
    }
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = t.check_options(
        t.load_data(data, variable_manager=None, loader=None),
        data
    )

    assert handler is not None

# Generated at 2022-06-21 00:32:24.353023
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Default constructor of HandlerTaskInclude class
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is None

# Generated at 2022-06-21 00:32:34.276172
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    myhost = Host('localhost')
    myhost.set_variable('name', 'localhost')
    myhost.set_variable('ansible_python_interpreter', '/usr/bin/python')
    myhost.set_variable('ansible_connection', 'local')
    myhost.set_variable('ansible_ssh_port', '22')
    myhost.set_variable('ansible_ssh_user', 'test')
    myhost.set_variable('ansible_ssh_pass', 'password')


# Generated at 2022-06-21 00:32:38.849679
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # create task include
    t1 = TaskInclude(task_include=None)

    # create handler task include
    t2 = HandlerTaskInclude(block=None, role=None, task_include=t1)

    # task_include is an instance of TaskInclude
    assert isinstance(t2, HandlerTaskInclude)

    # task_include is an instance of TaskInclude
    assert isinstance(t2.task_include, TaskInclude)

# Generated at 2022-06-21 00:32:40.377423
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO
    return

# Generated at 2022-06-21 00:32:41.337101
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:32:48.980571
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
      handler = Handler.load(data={"listen": "test-handler"}, block=None, role=None, task_include=HandlerTaskInclude, variable_manager=None, loader=None)
      assert handler is not None
      assert handler.tags == set()
      assert handler.when == ['always']
      assert handler.name == 'test-handler'



# Generated at 2022-06-21 00:32:49.904293
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:32:52.439985
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handlerTask = HandlerTaskInclude()
    handlerTask.load_data()
    handlerTask.check_options()

# Generated at 2022-06-21 00:32:53.760700
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "Test is missing"

# Generated at 2022-06-21 00:33:08.182520
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=["localhost"]))
    block = Block()
    data = {'listen': 'test_listen'}
    handler = HandlerTaskInclude.load(data, block=block, variable_manager=variable_manager, loader=loader)
    handler._load_tasks()
    assert handler.tasks == [{'include': 'tasks/test_listen.yml', 'tags': ['test_listen']}]



# Generated at 2022-06-21 00:33:20.090401
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    
    host1 = Host(name="host1")
    block1 = Block(hosts=host1)
    taskInclude = HandlerTaskInclude()
    data1 = {
        'include': {
            'name': 'include-tasks'
        },
        'listen': 'name_event',
        'name': 'name_handler'
    }
    result1 = taskInclude.load(data1, block=block1)
    assert result1 != None
    assert result1.block == block1
    assert result1.argument_validation_failed != False
    assert result1.name == "name_handler"
    assert result1._listen == "name_event"
    assert result1.loop != None

# Generated at 2022-06-21 00:33:20.949482
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:33:25.000415
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == set(['include', 'include_role', 'include_tasks', 'listen'])

# Generated at 2022-06-21 00:33:28.436777
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'name': 'handler',
            'include': 'main.yml',
            'listen': 'all'}
    handler = HandlerTaskInclude()
    handler.load(data)


# Generated at 2022-06-21 00:33:28.986024
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-21 00:33:33.424564
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    task_include = TaskInclude()
    handlerTaskInclude = HandlerTaskInclude(task_include=task_include)
    assert handlerTaskInclude is not None
    

# Generated at 2022-06-21 00:33:42.479464
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    h1 = Host("localhost")
    h2 = Host("localhost")
    h3 = Host("localhost")
    h1.set_variable("ansible_connection", "local")
    h2.set_variable("ansible_connection", "local")
    h3.set_variable("ansible_connection", "local")

# Generated at 2022-06-21 00:33:49.782994
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create instances of HandlerTaskInclude
    obj_HandlerTaskInclude = HandlerTaskInclude.load(
        data=["task.yml"],
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None,
    )

    # Check the class of the obj_HandlerTaskInclude
    assert(obj_HandlerTaskInclude.__class__ == TaskInclude)


# Generated at 2022-06-21 00:33:54.884459
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_array = []
    data = {'include': 'test_include'}
    HandlerTaskInclude.load(data=data)