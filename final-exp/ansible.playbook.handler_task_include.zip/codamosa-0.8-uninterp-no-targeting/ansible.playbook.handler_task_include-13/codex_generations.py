

# Generated at 2022-06-21 00:32:23.423757
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Running test_HandlerTaskInclude_load()")
    class CustomOptionalAttr(str):
        def __new__(cls):
            return str.__new__(cls, 'CustomOptionalAttr')

    class CustomMandatoryAttr(str):
        def __new__(cls):
            return str.__new__(cls, 'CustomMandatoryAttr')

    class CustomHandlerTaskInclude(HandlerTaskInclude):
        def __init__(self, *args, **kwargs):
            self.VALID_INCLUDE_KEYWORDS = self.VALID_INCLUDE_KEYWORDS.union(
                ('custom_optional_attr',)
            )
            self.VALID_INCLUDE_ATTRIBUTES = self.VALID_INCLUDE_ATTRIBUT

# Generated at 2022-06-21 00:32:26.578612
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    data = dict(
        name='some_handler',
        listen='some_var'
    )

    handler = HandlerTaskInclude.load(data)

# Generated at 2022-06-21 00:32:28.723320
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-21 00:32:35.491511
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager

    data = {}
    data['include'] = 'foo'

    handler = HandlerTaskInclude.load(data, block=Block(), variable_manager=VariableManager())
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.name == data['include']



# Generated at 2022-06-21 00:32:36.280471
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Just used for construct the class")

# Generated at 2022-06-21 00:32:40.261678
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    with pytest.raises(AssertionError):
        HandlerTaskInclude()
    with pytest.raises(AssertionError):
        HandlerTaskInclude(block=None, role=None, task_include=None)
    with pytest.raises(AssertionError):
        HandlerTaskInclude(None, None, None)
    with pytest.raises(AssertionError):
        HandlerTaskInclude(None)

# Generated at 2022-06-21 00:32:53.478224
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    host1 = Host(name='test1')
    host1.set_variable('testvar','testvalue')
    group1 = Group(name='group1')
    group1.add_host(host1)
    inventory = InventoryManager(loader=None, sources=[])
    inventory.add_group(group1)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    task = HandlerTaskInclude.load(data={}, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=None)

    assert task is not None

# Generated at 2022-06-21 00:32:58.013618
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(
        block = 'a block',
        role = 'a role',
        task_include = 'a task include'
        )

    assert handler.block == 'a block'
    assert handler.role == 'a role'
    assert handler.task_include == 'a task include'


# Generated at 2022-06-21 00:33:10.748474
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    Syntax:
    handler:
        - include: <path_to_handler>
    """
    variable_manager = Mock()
    loader = Mock()
    role=Mock()
    block=Mock()
    task_include=Mock()

    # case: include handler
    data = {}
    data['include'] = 'handler/main.yml'
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    # test attributes after loading include handler
    assert handler.include is 'handler/main.yml'

    # case: include handler with tags
    data = {}
    data['include'] = 'handler/main.yml'
    data['tags'] = ['tag1', 'tag2']

# Generated at 2022-06-21 00:33:19.077596
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(data={}, task_include=None)
    assert HandlerTaskInclude.load(data='', task_include=None)
    assert HandlerTaskInclude.load(data=None, task_include='')
    assert HandlerTaskInclude.load(data='', task_include='localhost')
    assert HandlerTaskInclude.load(data={}, task_include='localhost', variable_manager={})
    assert HandlerTaskInclude.load(data={}, task_include='localhost', variable_manager={}, loader={})

# Generated at 2022-06-21 00:33:26.174623
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Format:
    #try:
    #except:
    #    print("didn't work")
    #    raise Exception()
    #return None
    #try:
    #    t = HandlerTaskInclude()
    #except:
    #    print("didn't work")
    #    raise Exception()
    #return None
    return None


if __name__ == "__main__":
    # Unit test for constructor of class HandlerTaskInclude
    test_HandlerTaskInclude()
    # test_HandlerTaskInclude()
    print("We are still here")

# Generated at 2022-06-21 00:33:28.211145
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    path = "./playbooks/handler.sample"
    HandlerTaskInclude.load(path)

# Generated at 2022-06-21 00:33:40.700352
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task_include import TaskInclude

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    host = inventory.get_host

# Generated at 2022-06-21 00:33:46.782270
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Arrange
    data = dict(
        name='test',
        action={
            'module':'test',
            'args':{}
        }
    )
    block = object()
    role = object()
    task_include = object()
    variable_manager = object()
    loader = object()

    # Act
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    # Assert
    assert handler.action['module'] == 'test'
    assert handler.block == block

# Generated at 2022-06-21 00:33:52.064906
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Comprueba que el metodo load() funciona correctamente y devuelve un objeto HandlerTaskInclude
    """
    # Inicializamos un objeto HandlerTaskInclude
    obj = HandlerTaskInclude()
    # Datos incorrectos para prueba
    data = {}
    # Realizamos la llamada al metodo load(), y comprobamos que se ha ejecutado correctamente
    assert( issubclass(obj.load(data), HandlerTaskInclude) )

# Generated at 2022-06-21 00:34:01.107899
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # construct a valid PlaybookIncludeHandler
    try:
        data = {}
        data['include'] = 'foo'
        data['include_vars'] = 'foo'
        data['listen'] = 'foo'
        handler = HandlerTaskInclude.load(data)
        assert False, "Simple load of a HandlerTaskInclude did not raise an exception"
    except:
        pass

    # construct a valid HandlerTaskInclude
    data = {}
    data['listen'] = 'foo'
    handler = HandlerTaskInclude.load(data)
    assert handler.listen == 'foo'

# Generated at 2022-06-21 00:34:10.557717
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h._LOAD_ATTRIBUTES == {
        'block': None,
        'dont_log': None,
        'env': None,
        'loop': None,
        'loop_args': None,
        'loop_with_items': None,
        'name': None,
        'notify': None,
        'role': None,
        'tags': None,
        'task_include': None,
        'vars_files': None,
        'when': None,
        'with_items': None
    }

# Generated at 2022-06-21 00:34:18.208208
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(
        data=data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader
    )

# Generated at 2022-06-21 00:34:19.814132
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    (HandlerTaskInclude) -> handler
    """
    pass

# Generated at 2022-06-21 00:34:25.485412
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    variable_manager = object()
    loader = object()
    data = object()
    handler = HandlerTaskInclude(data, variable_manager, loader)
    assert handler.variable_manager == variable_manager
    assert handler.loader == loader


# Generated at 2022-06-21 00:34:28.844062
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-21 00:34:37.690413
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'name': 'dummy',
        'listen': 'dummy',
        'include': 'dummy.yml'
    }

    handler = HandlerTaskInclude.load(data=data)
    assert handler._name == data['name']
    assert handler._block == None
    assert handler._listen == data['listen']
    assert handler._include == data['include']
    assert handler._loop == None
    assert handler._when == None

# Generated at 2022-06-21 00:34:46.682209
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    ############################################################################
    # I put this code in test_HandlerTaskInclude_load because the load method
    # of HandlerTaskInclude class is static so I cannot mock the attributes
    # of my instance of HandlerTaskInclude.
    ############################################################################

    from ansible.playbook import task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from io import  BytesIO

    filename = 'handler.yml'
    yaml_file = BytesIO(b'---\n- name: handler tag test\n  tags: [tag1,tag2]')
   

# Generated at 2022-06-21 00:34:51.296929
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        obj = HandlerTaskInclude()
        print(str(obj))
    except:
        #logging.debug("Exception in test_HandlerTaskInclude()", exc_info=1)
        pass
    return


# Generated at 2022-06-21 00:35:02.016067
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # test handler content
    data = {
        "name": "all",
        "listen": ["test_trigger"],
        "tasks": [
            {
                "debug": {
                    "msg": "This is a test."
                }
            }
        ]
    }

    # the host file represents a single host
    host = Host()

# Generated at 2022-06-21 00:35:03.419334
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   task = HandlerTaskInclude()



# Generated at 2022-06-21 00:35:12.100687
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_block = 'HandlerBlock'
    test_role = 'Role'
    test_task_include = 'TaskInclude'
    test_handler = HandlerTaskInclude(block=test_block, role=test_role, task_include=test_task_include)
    assert test_handler.block == test_block
    assert test_handler.role == test_role
    assert test_handler.task_include == test_task_include

# Unit test object of class HandlerTaskInclude
test_handler = HandlerTaskInclude(block='HandlerBlock', role='Role', task_include='TaskInclude')

# Generated at 2022-06-21 00:35:17.166995
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'name': 'uptime'}
    task = HandlerTaskInclude(data)
    assert task.get_vars() == {'name': 'uptime'}
    assert task.name == 'Uptime'

# Generated at 2022-06-21 00:35:19.984030
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """ Test case for handler task include """
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-21 00:35:32.305577
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-21 00:35:40.080742
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host

    # Mock
    task_include = TaskInclude()
    task_include.load = lambda data, block=None, role=None, task_include=None, variable_manager=None, loader=None: TaskInclude()
    task_include.check_options = lambda data, data2: TaskInclude()

    handler = HandlerTaskInclude(block=None, role=None, task_include=task_include)

    # Run
    assert handler.load(data=None, block=None, role=None, task_include=task_include, variable_manager=None, loader=None)

# Generated at 2022-06-21 00:35:47.314775
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    obj = HandlerTaskInclude()
    #def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
    # obj.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    pass


# Generated at 2022-06-21 00:35:52.432365
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    HandlerTaskInclude.VALID_INCLUDE_KEYWORDS.add('listen')

    data = dict(
        name = 'test1',
        listen = 'test2'
    )

    t = HandlerTaskInclude(
        block = None,
        role = None,
        task_include = None
    )

    result = t.load(data)

    assert isinstance(result, HandlerTaskInclude)

# Generated at 2022-06-21 00:35:53.226941
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:35:57.360916
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {"name", "tags", "when", "started_by", "static", "delegate_to", "delegate_facts", "listen"}

# Generated at 2022-06-21 00:36:01.114088
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    print(task_include)


if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-21 00:36:13.439714
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    ## arrange
    data = dict(
        static='test',
        tasks='test_tasks.yml',
    )
    block=None
    role=None
    task_include=None
    variable_manager=None
    loader=None

    ## act
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    ## assert
    assert isinstance(handler, HandlerTaskInclude)

    ## assert
    assert handler.block == block
    assert handler.role == role
    assert handler.task_include == task_include
    assert handler.name == handler.get_name()
    assert handler.tags == handler.get_tags()
    assert handler.static == dict(static='test')
    assert handler.tasks == ['test_tasks.yml']

# Generated at 2022-06-21 00:36:21.230431
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()

    playbooks = [ 'test.yml' ]

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:36:31.772574
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': {
            'task': {
                'tags': 'my-special-tag',
                'file': 'my/special/path.yml'
            }
        }
    }

    handler = HandlerTaskInclude.load(
        data,
        variable_manager={},
        loader={},
    )

    assert handler is not None
    # pprint.pprint(handler.task_include.get_vars())
    # pprint.pprint(handler.task_include.get_tasks())
    assert handler._tqm is None
    assert handler.block is None

# Generated at 2022-06-21 00:36:40.631403
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play = Play().load({}, variable_manager=variable_manager, loader=DataLoader())
    play._included_file = 'test'
    result = HandlerTaskInclude.load({'test': 'ok'}, play=play, variable_manager=variable_manager, loader=DataLoader())
    assert result.get_name() == 'test'
    assert result.args.get('test') == 'ok'

# Generated at 2022-06-21 00:36:54.559180
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from units.mock.vars import MockVars
    from units.mock.variable_manager import MockVariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = {
        'name': 'testHandler',
        'listen': 'testHandler',
        'include': ['first_task', 'second_task'],
    }
    loader = DictDataLoader({})
    variable_manager = MockVariableManager()
    inventory = MockInventory()
    variable_manager.set_inventory(inventory)
    play_context

# Generated at 2022-06-21 00:36:58.970059
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None


# Generated at 2022-06-21 00:37:09.076632
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import find_plugin_loader
    from ansible.plugins.loader import get_all_plugin_names
    from ansible.plugins.loader import get_plugin_class
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    import os
    import yaml
    # create a host
    hosts = Host(name="localhost")

    # create a new variable manager
    variable_manager = VariableManager()
    variable_manager.set_host_variable(hosts, "app_path", os.path.expanduser('~'))
    # load the handler file
    loaders = get_all_plugin_loaders()
    loader = find_plugin_loader('include')
    # get all

# Generated at 2022-06-21 00:37:18.924132
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    block = None
    role = None
    task_include = None
    data = {
        'type': 'handler',
        'name': 'test_HandlerTaskInclude',
        'include': 'test_include.yml'
    }
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler is not None
    assert handler.get_name() == 'test_HandlerTaskInclude'

# Generated at 2022-06-21 00:37:31.024336
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.task_include
    import ansible.playbook.handler
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    import ansible.constants as C

    # TODO: write unit tests for the following methods:
    # load_extra_vars
    # load_options_vars
    # _load_machine_vars

    # Common code for the test cases

# Generated at 2022-06-21 00:37:38.593284
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    var_manager = FakeVariableManager()
    loader = FakeLoader()
    data = 'test_handler.yaml'
    handler = HandlerTaskInclude.load(
            data, None, None, None, var_manager, loader
    )
    assert handler.get_name() == 'include'
    assert handler.get_args() == 'test_handler.yaml'



# Generated at 2022-06-21 00:37:39.867396
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()

# Generated at 2022-06-21 00:37:41.587592
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import mock
    assert True

# Generated at 2022-06-21 00:37:45.681995
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Creation of object by calling the constructor of class HandlerTaskInclude
    handler_task_include_obj = HandlerTaskInclude()
    # To check the object is created properly or not
    assert handler_task_include_obj

# Generated at 2022-06-21 00:37:53.488910
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Testing handler task include')
    
    variable_manager = MagicMock()
    variable_manager.get_vars.return_value = {'listen': 'port 80'}

    loader = MagicMock()
    loader.get_basedir.return_value = ''

    
    data = dict(
        listen='port 80',
        name='Apache2 restart'
    )
    
    # Expected result
    result = dict(
        name='Apache2 restart',
        listen='port 80',
        tasks=[
            dict(
                action=dict(
                    module='service',
                    args=dict(
                        name='apache2',
                        state='restarted',
                    )
                ),
                async_val='0',
                name='Restart Apache2 service'
            )
        ]
    )

   

# Generated at 2022-06-21 00:38:07.972371
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #__import__('pprint').pprint(HandlerTaskInclude.load({'include': 'foo.yml'})._attributes)
    #__import__('pprint').pprint(HandlerTaskInclude.load({'include': 'foo.yml'}, variable_manager=VariableManager())._attributes)
    assert False

# Generated at 2022-06-21 00:38:10.068616
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-21 00:38:13.641525
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    args = {}
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None

# Generated at 2022-06-21 00:38:18.534056
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler is not None

# Generated at 2022-06-21 00:38:28.465253
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = "127.0.0.1"
    port = "22"
    user = "root"
    passwd = "123456"
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    host = Host(host)
    loader = DataLoader()
    inventory = VariableManager(loader=loader)

    h = HandlerTaskInclude(host=host, port=port, user=user, passwd=passwd)

# Generated at 2022-06-21 00:38:30.129098
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  HandlerTaskInclude()

# Generated at 2022-06-21 00:38:42.466095
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.plugins.callback import CallbackBase

    blk = Block(play=Play.load({'name': 'foo'}))

# Generated at 2022-06-21 00:38:53.711598
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    yaml_data = """
---
- hosts: host1
  tasks:
  - include: file.yml
    list: [1, 2]
    # empty list
    tags: []
    # empty dict
    when: {}
    # will not pass
    listen: foo
    vars:
      - name: 'foo'
        value: 'bar'
        # empty dict
        meta: {}
      - name: 'foo1'
        value: 'bar1'
        # empty string
        meta: ''
    vars_files:
      - foo.yml
    vars_prompt:
      - name: 'foo'
        prompt: 'foo prompt'
        private: no
        confirm: yes
        encrypt: 'no'
        salt_size: 6
        salt: 'salt_str'
"""

# Generated at 2022-06-21 00:38:57.929412
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    # Expected value of variable h is an object of class HandlerTaskInclude
    assert isinstance(h, HandlerTaskInclude)

# Generated at 2022-06-21 00:39:04.599932
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include_vars=dict(
            file="{{item}}"
        ),
        loop=["/tmp/path1", "/tmp/path2"],
        list_hosts=True,
        register="file_contents"
    )
    task_include = HandlerTaskInclude(None, None)
    include_task = task_include.load(data)
    assert include_task.include_type == "vars"
    assert include_task.loop == "/tmp/path1"
    assert include_task.loop_args == dict(file="{{item}}")
    assert include_task.loop_with == "item"
    assert isinstance(include_task.loop_items, list)
    assert len(include_task.loop_items) == 2
    assert include_task.loop_items[0]

# Generated at 2022-06-21 00:39:23.486057
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data_input={u'files': [u'../../common/handlers/main.yml'], u'vars': {}, u'name': u'Restart Apache', u'listen': [u'Restart Apache'], u'include': u'../../common/handlers/main.yml'}
    handler = HandlerTaskInclude.load(data_input)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-21 00:39:26.662429
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'listen': 'hello'}
    t = HandlerTaskInclude.load(data)
    assert t.listen == 'hello'

# Generated at 2022-06-21 00:39:31.507252
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(TaskInclude())
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'action', 'name', 'tags', 'task_args', 'when', 'static', 'vars', 'with_items', 'without_items', 'with_file', 'with_filetree', 'with_first_found', 'with_dict', 'with_sequence', 'with_nested', 'when', 'listen'}

# Generated at 2022-06-21 00:39:32.893398
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti

# Generated at 2022-06-21 00:39:42.635060
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #
    # Basic init test from Host
    #
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert hti is not None
    assert hti.action is None
    assert hti.block is None
    assert hti.ignore_errors is False
    #assert hti.include is None
    #assert hti.include_tasks is None
    assert hti.loop is None
    #assert hti.playbook is None
    assert hti.role is None
    assert hti.tags is []
    assert hti.task_include is None
    assert hti.when is None
    assert hti.with_items is None
    assert hti.with_fileglobs is None
    assert hti.with_first_found is None

# Generated at 2022-06-21 00:39:49.648777
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    def mock_load_data(self, data, variable_manager=None, loader=None):
        return data

    h = HandlerTaskInclude(block=None, role=None, task_include=Task())
    h.load_data = mock_load_data

    data = dict(
        include = 'tasks/foo.yaml'
    )
    host = HandlerTaskInclude.load(data, block=None, role=None, task_include=Task(), variable_manager=None, loader=None)
    assert host.static is True
    assert host._parent is None
    assert host.get_vars() == dict()
    assert host.get_name() == 'tasks/foo.yaml'
    assert host.get_

# Generated at 2022-06-21 00:39:54.812841
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)

    data = dict(
        name='A handler name',
        listen='some event',
        tasks='tasks to run when the event fires',
        handler_type='notify'
    )
    handler = handler.load(data)

    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)


# Generated at 2022-06-21 00:39:58.585292
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    group = Group("test_group_for_HandlerTaskInclude_load")
    group.hosts["test_host_for_HandlerTaskInclude_load"] = Host("test_host_for_HandlerTaskInclude_load")

    variable_manager = VariableManager()
    loader = DataLoader()

    handler = HandlerTaskInclude.load({"listen":"test_group_for_HandlerTaskInclude_load"},
                                       block=None,
                                       role=None,
                                       task_include=None,
                                       variable_manager=variable_manager,
                                       loader=loader)


# Generated at 2022-06-21 00:40:04.544219
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block='listen_state:started', role='all', task_include='main.yml')
    assert handler.block == 'listen_state:started' and handler.role == 'all' and handler.task_include == 'main.yml'

# Generated at 2022-06-21 00:40:11.442855
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook import role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    inventory = InventoryManager(["localhost"])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.extra_vars = {
        "ansible_connection": "local",
        "ansible_python_interpreter": "/usr/bin/python",
    }

    # test the situation without a role
    data = {"include": "foo.yml"}
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager)
    assert handler.get_name() == ""

    # test the situation of a handler referencing its parent role


# Generated at 2022-06-21 00:40:43.649323
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    
    loader = DataLoader()
    results_callback = lambda *args, **kwargs: None
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader,
                                 sources=["127.0.0.1"])

    inventory.add_group("tokyocabinet")

# Generated at 2022-06-21 00:40:44.339513
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:40:51.340503
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Testing with a dictionary.
    d = {u'from_colon': u'../host_vars/hosts:host_a', u'from': u'host_vars/hosts'}
    hti = HandlerTaskInclude.load(d)
    assert hti.from_file == u'../host_vars/hosts'
    assert hti.from_yaml == u'host_vars/hosts'

    # Testing with a TaskInclude.
    # ti = TaskInclude.load(d)
    # hti = HandlerTaskInclude.load(ti)
    # assert hti.from_file == u'../host_vars/hosts'
    # assert hti.from_yaml == u'host_vars/hosts'

    # Testing with a dictionary containing a listen field.

# Generated at 2022-06-21 00:40:56.698160
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert hti.state == 'init'
    assert hti.block == None
    assert hti.role == None
    assert hti.task_include == None
    assert isinstance(hti.VALID_INCLUDE_KEYWORDS,set)


# Generated at 2022-06-21 00:41:04.018877
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        handler = dict(
            tasks = 'test_tasks',
            name = 'test_name',
            listen = 'test_listen'
        )
    )
    handler = HandlerTaskInclude.load(data)
    assert handler.listen == 'test_listen'
    assert handler.action == 'test_tasks'

# Generated at 2022-06-21 00:41:10.513642
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    task_include = Task(name="TASK_INCLUDE", is_handler=True)
    role = Role()
    block = Block.load(
        data=dict(
            handlers=dict(
                handlers_vars=dict(
                    listen="test_listen",
                    include="test_include"
                )
            )
        ),
        play=task_include,
        role=role,
        task_include=task_include,
        variable_manager=None,
        loader=None
    )

    data = AnsibleMapping()

# Generated at 2022-06-21 00:41:15.079144
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    params = {}
    handlers = []
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(params, block=block, role=role, task_include=task_include)

    handlers.append(handler)

# Generated at 2022-06-21 00:41:25.708505
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    h = Host(name='testhost', port=22)
    b = Block(
        play=Play().load(dict(name="test play", hosts=['all'], gather_facts='no')),
        task=Task().load(dict(name="test task", action=dict(module="copy", args=dict(src="/tmp/test", dest="/tmp/test2")))),
        role=None,
        implicit='yes',
        parent_block=None,
    )


# Generated at 2022-06-21 00:41:36.372603
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    with pytest.raises(Exception) as e:
        task = Handler()
    assert "Cannot use Handler() directly" in str(e)

    with pytest.raises(Exception) as e:
        task = Handler(block=dict())
    assert "Handler requires a `listen` attribute" in str(e)
    assert "did you mean to use a TaskInclude?" in str(e)

    with pytest.raises(Exception) as e:
        task = Handler(block=dict(role=dict(name="test")))
    assert "Handler requires a `listen` attribute" in str(e)
    assert "did you mean to use a TaskInclude?" in str(e)

    with pytest.raises(Exception) as e:
        task = Handler(block=dict(listen="test"))

# Generated at 2022-06-21 00:41:40.310833
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'tasks': 'main.yml'}
    task = HandlerTaskInclude.load(data)
    assert isinstance(task, HandlerTaskInclude)