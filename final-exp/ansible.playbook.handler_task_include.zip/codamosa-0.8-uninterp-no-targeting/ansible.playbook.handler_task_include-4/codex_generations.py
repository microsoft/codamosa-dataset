

# Generated at 2022-06-21 00:32:22.829809
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.utils.vars import combine_vars


    # Setup a fake inventory

# Generated at 2022-06-21 00:32:25.449616
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = HandlerTaskInclude()
    assert task_include is not None


# Generated at 2022-06-21 00:32:35.089469
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import Role
    from ansible.playbook import Playbook
    from ansible.playbook import Play
    from ansible.playbook import Task
    from ansible.playbook import Block
    from ansible.playbook.connection_info import ConnectionInfo
    inventory = {} #TODO how to dependency inject this?
    variable_manager = {} #TODO how to dependency inject this?
    loader = {} #TODO how to dependency inject this?

    # Create some playbooks, roles, and hosts.
    playbooks = dict(
        main = dict(
            name = "main",
            hosts = ["multiplex"],
            roles = ["role1","sub_role1"]
        )
    )

# Generated at 2022-06-21 00:32:37.397627
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Verifies that the object in question is generated correctly
    assert HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-21 00:32:39.640895
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()

# Generated at 2022-06-21 00:32:46.392857
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include.__class__.__name__ == "HandlerTaskInclude"
    assert handler_task_include.block is None
    assert handler_task_include.role is None
    assert handler_task_include.task_include is None


# Generated at 2022-06-21 00:32:56.650646
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    # initialize variables
    data = dict(
        name = 'Test Handler',
        listen = 'Test Listener',
        tasks = [
            dict(action = dict(module = 'debug', args = dict(msg = 'test')))
        ]
    )
    block = None
    role = None
    task_include = None
    variable_manager = VariableManager()
    loader = DataLoader()
    # call method
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager=variable_manager, loader=loader)
    # check conditions
    assert handler is not None
    assert handler.name == 'Test Handler'

# Generated at 2022-06-21 00:33:06.223724
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a dict of options for the HandlerTaskInclude instance.
    opts_dict = dict(
        name='foo',
        block=None,
        role=None,
        task_include=None
    )

    hti = HandlerTaskInclude(**opts_dict)
    assert hti.get_name() == 'foo'
    assert hti.get_all_parents() == []
    assert hti.get_dep_chain() == []
    assert hti.get_ancestors() == []

# Generated at 2022-06-21 00:33:14.333164
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = '''
    - ping:
        name: this is the name
'''
    import ansible.inventory.host
    # t = ansible.playbook.task_include.TaskInclude()
    t = HandlerTaskInclude()
    h = t.load(data, variable_manager=None, loader=None)
    assert isinstance(h, HandlerTaskInclude)
    # assert isinstance(h.task, ansible.playbook.task.Task)
    assert h.task.name == 'ping'

# Generated at 2022-06-21 00:33:20.278137
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    data = dict(
        tags=['tag1', 'tag2'],
        include='test__handler.yml'
    )

    # defined test values
    block = 'Test Block'
    role = 'Test role'
    task_include = 'Test task include'
    variable_manager = 'Test variable_manager'
    loader = 'Test loader'

    HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:33:24.047406
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:33:27.954802
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude(block=None, role=None, task_include=None)

    assert h._block is None
    assert h._role is None
    assert h._task_include is None

# Generated at 2022-06-21 00:33:32.079128
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Testing HandlerTaskInclude")
    handler = HandlerTaskInclude()
    print("Type of HandlerTaskInclude is ", type(handler))

# Generated at 2022-06-21 00:33:34.543056
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  t = HandlerTaskInclude(block=None, role=None, task_include=None)
  assert t is not None

# Generated at 2022-06-21 00:33:42.862696
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    host = Host(name="myhost")
    variable_manager.set_host_variable(host, 'ansible_ssh_port', 22)

    handler = HandlerTaskInclude.load(
        data=dict(
            include='replace_me',
            notify=['notify_service'],
            exclude=['exclude_host'],
            when='some_condition',
            listen='some_event'
        ),
        variable_manager=variable_manager,
        loader=loader,
    )
    assert handler is not None
    assert handler.include, 'replace_me'

# Generated at 2022-06-21 00:33:50.517852
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Do not manually edit
    data = {
        'block': 'block',
        'role': 'role',
        'task_include': 'task_include',
        'variable_manager': 'variable_manager',
        'data': 'data',
        'loader': 'loader'
    }

    obj = HandlerTaskInclude(**data)

    assert obj.block == data['block']
    assert obj.role == data['role']
    assert obj.task_include == data['task_include']


# Generated at 2022-06-21 00:33:53.762658
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handlerTaskInclude != None

# Generated at 2022-06-21 00:33:55.775288
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load(dict(include='molecule_role'))

# Generated at 2022-06-21 00:33:59.226262
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.block
    block = ansible.playbook.block.Block()
    data = {'include': 'somefile.yml', 'listen': 'testable'}
    handler = HandlerTaskInclude.load(data, block=block)
    assert handler.include == data['include'] and handler.listen == data['listen']

# Generated at 2022-06-21 00:34:07.161455
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti.block == None
    assert hti.role == None
    assert hti.task_include == None
    assert isinstance(hti.VALID_INCLUDE_KEYWORDS, set)
    assert hti.VALID_INCLUDE_KEYWORDS >= {'tasks', 'listen'}

# Generated at 2022-06-21 00:34:15.912782
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    d = {'listen': 'stop_listen', 'include': './test.yml'}
    task = HandlerTaskInclude()
    task.load(d)
    assert task.listen == 'stop_listen'
    assert task.include == './test.yml'

# Generated at 2022-06-21 00:34:25.175986
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    block = Block.load(
        dict(
            name='main',
            tasks=[
                dict(
                    name='dummy_task',
                    action=dict(module='dummy')
                )
            ]
        ),
        play=None,
        variable_manager=VariableManager(),
        loader=DataLoader()
    )


# Generated at 2022-06-21 00:34:37.248521
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    def get_hosts(hosts, group):
        import copy
        results = []
        for host in hosts:
            h = copy.copy(host)
            h.groups = [group]
            results.append(h)
        return results

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    host_1 = inventory.get_host(name='127.0.0.1')
    host_2 = inventory.get_host(name='localhost')
    host_1.groups = ['ungrouped']
   

# Generated at 2022-06-21 00:34:39.307235
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()

    assert h is not None

# Generated at 2022-06-21 00:34:41.633390
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'list': 'test_listen.yml'}
    res = HandlerTaskInclude.load(data)
    assert isinstance(res, Handler)

# Generated at 2022-06-21 00:34:44.077101
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    x = HandlerTaskInclude()
    assert x is not None

# Generated at 2022-06-21 00:34:49.285342
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

    assert handler_task_include.VALID_INCLUDE_KEYWORDS == handler_task_include.VALID_INCLUDE_KEYWORDS.union(('listen',))

# Generated at 2022-06-21 00:34:59.527726
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerlist = HandlerTaskInclude.load(
        data={
            "include": {
                "file": "playbook_dir/handlers/default.yml",
                "ignore_errors": False,
                "listen": [
                    "host1",
                    {"name": "host2"},
                    {"name": "host3", "tags": "role1"},
                    {"group": "a", "tags": "role2"},
                    {"group": ["b", "c"], "tags": "role3"},
                    {"group": "d", "tags": ["role4", "role5"]}
                ]
            }
        },
        block={},
        task_include={})
    assert len(handlerlist) == 1
    assert handlerlist[0].get_name() == "include"
    assert handlerlist[0].get_variables

# Generated at 2022-06-21 00:35:00.486083
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-21 00:35:08.577570
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # _handler_task_include=TaskInclude.load(
    data = {
        "include": "file.yml",
        "static": True
    }
    _handler_task_include = HandlerTaskInclude.load(data)

    if _handler_task_include.static:
        print("Success")
    else:
        print("Failure")
