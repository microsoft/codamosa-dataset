

# Generated at 2022-06-21 00:32:23.423742
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(
        u'import_tasks',
        u'handler_task_include',
        name=u'/tmp/ansible_handler_task_include.yml',
        private=dict(
            _raw_params=u'/tmp/ansible_handler_task_include.yml'
        )
    )
    assert t._attributes['_name'] == u'import_tasks'
    assert t._attributes['_parent'] == u'handler_task_include'
    assert t._attributes['name'] == u'/tmp/ansible_handler_task_include.yml'
    assert t._attributes['private']['_raw_params'] == u'/tmp/ansible_handler_task_include.yml'



# Generated at 2022-06-21 00:32:34.628168
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("test_HandlerTaskInclude_load")
    # Test for all keywords.
    data = dict(
        name="a-task",
        listen="{{var1}}",
        connection="network_cli",
        tasks=["task1", "task2"],
        rescue=["task1", "task2"],
        always=["task1", "task2"],
        other=["task1", "task2"]
    )

    h = HandlerTaskInclude.load(
        data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert h.name == 'a-task', "HandlerTaskInclude did not load all fields. Result: %s" % h

    # Test keywords to listen var1

# Generated at 2022-06-21 00:32:36.062320
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # load = HandlerTaskInclude.load
    # assert load() == ''
    assert True == True

# Generated at 2022-06-21 00:32:42.424383
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['{{inventory}}'])

    variable_manager = VariableManager(loader=loader, inventory=inventory)

    task_include = {
        'listen': "stop",
    }
    data = {
        'block': 'first_block',
        'tasks': ['tasks.main'],
        'hosts': ['server1', 'server2'],
    }

    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, task_include=task_include)


# Generated at 2022-06-21 00:32:43.103213
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert(HandlerTaskInclude)

# Generated at 2022-06-21 00:32:51.663890
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    # the name of this class is "HandlerTaskInclude" and not "Handler"
    assert h.__class__.__name__ == "HandlerTaskInclude"
    # the parent classes of this class are Handler, TaskInclude
    assert h.__class__.__bases__ == (Handler, TaskInclude)
    # the keys of the include_vars argument of HandlerTaskInclude.load should be
    # 'tasks'
    assert "tasks" in HandlerTaskInclude.load.func_defaults[0]

# Generated at 2022-06-21 00:32:55.619383
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_obj = HandlerTaskInclude()
    assert issubclass(type(handler_task_include_obj), Handler)
    assert issubclass(type(handler_task_include_obj), TaskInclude)

# Generated at 2022-06-21 00:32:57.797442
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load(data = {
        'include': 'test.yml'
    })

# Generated at 2022-06-21 00:32:59.306587
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert(issubclass(HandlerTaskInclude, Handler))

# Generated at 2022-06-21 00:33:02.588506
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    #Asserting the class name
    assert handler.__class__.__name__ == "HandlerTaskInclude"

# Generated at 2022-06-21 00:33:07.940620
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Create a task
    handler = HandlerTaskInclude()

    print("Print handler")
    print(handler)

    assert(handler != None)


# Generated at 2022-06-21 00:33:20.004929
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    # Write temporary file
    handler1_yaml_file = os.path.join(tmpdir, 'handler1.yaml')

# Generated at 2022-06-21 00:33:26.921157
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory_manager = InventoryManager(
        loader=None,
        sources=[
            'hosts_to/hosts'
        ]
    )

    inventory_manager.add_group(
        Group(
            name='test_group',
            hostnames=['test_host'],
            group_vars={'group_var': 'test_value'},
            vars={'group_var2': 'test_value2'}
        )
    )


# Generated at 2022-06-21 00:33:27.998223
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load(None)


# Generated at 2022-06-21 00:33:30.424229
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-21 00:33:39.116834
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        include=dict(
            file='/var/tmp/simple.yml',
            tasks='include_tasks'
        )
    )

    test_obj = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None
    )
    obj = test_obj.check_options(
        test_obj.load_data(data, variable_manager=None, loader=None),
        data
    )
    assert obj is not None

# vim: set expandtab shiftwidth=4:

# Generated at 2022-06-21 00:33:50.154836
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = Host(name='localhost')
    variable_manager = VariableManager()

    handler = Handler(
        task=None,
        block=None,
        role=None,
        task_include=None,
        args=dict(),
    )
    handler.set_loader(None)
    handler.set_inventory(None)
    handler.set_variable_manager(variable_manager)
    handler.set_hosts(host)
    handler.set_play_context(PlayContext())
    handler.set_task_context(None)

    handler.check_requested_oneliner()

    assert handler.action == "nothing"

    handler.run()

# Generated at 2022-06-21 00:33:54.405694
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        _raw_params="test.yml",
        _role_name="test.yml",
        _block=None,
        _task=None,
        _parent=None,
        _role=None,
        _play=None,
        _loader=None,
        _variable_manager=None,
        _block=None,
        _task_include=None,
    )
    handler = HandlerTaskInclude()
    assert handler.block == data['_block']
    assert handler.role == data['_role']
    assert handler.task_include == data['_task_include']

# Generated at 2022-06-21 00:34:04.215418
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('\n===== test_HandlerTaskInclude_load()')
    """
    测试HandlerTaskInclude类中load方法，该方法用于加载一个角色的所有handler
    """
    # Load handler
    from ansible.playbook.play import Play


# Generated at 2022-06-21 00:34:11.807675
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def mock_load(self,data,block=None,role=None,task_include=None,variable_manager=None,loader=None):
        return data
    HandlerTaskInclude.load = mock_load
    data = {
        "tasks": {
            "handlers": [
                "listen: test_handlers",
                "include: test_roles/test_role/tasks/main.yml",
                "include_tasks: test_include_tasks.yml"
            ]
        }
    }
    results = HandlerTaskInclude.load(data=data,task_include="task_include")
    assert results == data

# Generated at 2022-06-21 00:34:24.577682
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Get a Handler
    import os
    import unittest.mock as mock

    data = {}
    data["listen"] = True
    data["include"] = "test.yml"
    
    data["static"] = "static.yml"
    data["static"] = os.path.expanduser(data["static"])

    block = mock.MagicMock()
    role = mock.MagicMock()
    task_include = mock.MagicMock()
    variable_manager = mock.MagicMock()
    loader = mock.MagicMock()

    handler = HandlerTaskInclude.load(
        data=data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader,
    )

# Generated at 2022-06-21 00:34:34.744014
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    vault_secrets_files = None
    variable_manager = VariableManager(loader=loader, vault_secrets_files=vault_secrets_files)
    inventory = InventoryManager(loader=loader, sources=None, vault_password='test')
    variable_manager.set_inventory(inventory=inventory)

    data = '''
    - service:
        name: httpd
      listen: 'start httpd'
      notify:
      - restart httpd
    '''

    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:34:41.579238
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    """
    Used for testing HandlerTaskInclude class
    """
    t = HandlerTaskInclude()
    data = {'include': 'a.yml', 'tags': ['b']}
    retval = t.load(data)
    assert retval.include is not None
    assert retval.loop is None
    assert retval.tags == ['b']

    data = {'include': 'a.yml', 'loop': {'var': 'a', 'items': '{{a}}'}}
    retval = t.load(data)
    assert retval.include is not None
    assert retval.loop is not None
    assert retval.tags is None

    data = {'include': 'a.yml', 'loop': '{{a}}'}
    retval = t.load(data)

# Generated at 2022-06-21 00:34:54.580881
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    block = Block(
        parent_block=Play().block,
        role=Role(),
        task_include=TaskInclude(),
        use_handlers=True,
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader()
    )
    block._load_block_roles()

# Generated at 2022-06-21 00:34:55.322318
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    return

# Generated at 2022-06-21 00:35:00.006489
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Define a test variable
    data = 'some test data'

    # Construct the HandlerTaskInclude instance
    handler_task_include = HandlerTaskInclude.load(data)

    # assert that the constructor did not return None
    assert handler_task_include is not None

# Generated at 2022-06-21 00:35:07.539864
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert h.__doc__ == "Include handlers from a file or a task list"
    assert h.name =="include"
    assert h.block==None
    assert h.role==None
    assert h.task_include==None

# Generated at 2022-06-21 00:35:10.560416
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "listen" : "song"
    }
    result = HandlerTaskInclude.load(data)
    assert result == NotImplemented


# Generated at 2022-06-21 00:35:23.350919
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.providers import DefaultVariableMapping
    from ansible.vars.providers import HostVarsVars
    from ansible.vars.providers import GroupVarsVars
    from ansible.vars.providers import FactVarsVars
    from ansible.vars.providers import TaskVarsVars
    from ansible.vars.providers import PackageVarsVars
    from ansible.vars.providers import FileVarsVars
    from ansible.vars.providers import PlayVarsVars

    group = Group()
    host = Host()
   

# Generated at 2022-06-21 00:35:25.130882
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj is not None