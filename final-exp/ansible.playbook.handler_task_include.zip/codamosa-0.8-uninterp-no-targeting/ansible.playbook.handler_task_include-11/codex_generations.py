

# Generated at 2022-06-21 00:32:19.140323
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude( block=None, role=None, task_include=None)
    print('handler:', handler)

# Generated at 2022-06-21 00:32:24.711026
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(mydata_dict, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert True, "load() method of class HandlerTaskInclude  unit test is not implemented"

# Generated at 2022-06-21 00:32:34.656614
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # mock imports
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins import callback_loader
    import sys

    # mock objects
    block = Block()
    role = 'role'
    loader = callback_loader.get('dummy')
    data = {"block": "main", "include": "../something.yml"}
    hti_t = HandlerTaskInclude(block='main', role=role, task_include='../something.yml')

# Generated at 2022-06-21 00:32:40.774504
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name="template configuration files",
        listen="restart httpd",
        tags=["always"],
    )
    handler = HandlerTaskInclude.load(data)
    assert hasattr(handler, 'name')
    assert handler.name == "template configuration files"
    assert hasattr(handler, 'listen')
    assert handler.listen == "restart httpd"
    assert hasattr(handler, 'tags')
    assert handler.tags == ['always']
    assert not hasattr(handler, 'when')
    assert not hasattr(handler, 'notify')
    assert not hasattr(handler, 'delegate_to')
    assert not hasattr(handler, 'local_action')
    assert not hasattr(handler, 'poll')

# Generated at 2022-06-21 00:32:53.531548
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.ansible_vars import AnsibleVars
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import wrap_var

    task_include = TaskInclude(block=None, role=None)
    handler = HandlerTaskInclude(block=None, role=None, task_include=task_include)

    ansible_vars = AnsibleVars()

# Generated at 2022-06-21 00:33:07.941037
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    block = Block(
        parent_block=None,
        role=Role(),
        task_include=TaskInclude(),
    )

    task = Task()
    handler_task_include = HandlerTaskInclude(block, Role(), task)

# Generated at 2022-06-21 00:33:09.021549
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:33:20.328730
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["test/test_playbooks/hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    handler = HandlerTaskInclude.load({'include': 'test/test_playbooks/handler_tasks.yml'}, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)

    assert handler is not None
    assert handler.task is not None
    assert handler.task.action is not None
    assert handler.task.action.module is not None

# Generated at 2022-06-21 00:33:29.605838
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook import HandlerTaskInclude
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory("", variable_manager=variable_manager)

    data = dict(
        include="some_task_list",
        static="all",
        tags=["tag1", "tag2"],
        ignore_errors=True
    )
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-21 00:33:37.185280
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import json
    import pytest
    #play_source = HandlerTaskInclude.load(json.load('{"include": "my_handlers.yaml"}'), None)
    play_source = HandlerTaskInclude.load(json.load(open('test/unit/fixtures/playbooks/handlers_include.json')), None)
    assert play_source.__class__.__name__ is 'HandlerTaskInclude'

# Generated at 2022-06-21 00:33:51.347795
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-21 00:33:52.709470
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#     assert True

# Generated at 2022-06-21 00:33:58.736817
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.role import Role
    #from ansible.inventory.host import Host
    #h1 = Host("Server1", "Server1")
    handler = HandlerTaskInclude.load({
        "include": "test.yml",
        "static": "all"
    })

    assert handler is not None

# Generated at 2022-06-21 00:34:00.886984
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()

# Generated at 2022-06-21 00:34:03.715956
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)

# Generated at 2022-06-21 00:34:10.345931
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('In test_HandlerTaskInclude')
    # Initialize the object
    t = HandlerTaskInclude()

    # Check instance attributes
    assert type(t) == HandlerTaskInclude
    assert t.action == 'include'
    assert t.loop is None
    assert t.notify == []
    assert t.only_if == None
    assert t.until == None
    assert t.when == None

# Generated at 2022-06-21 00:34:22.764265
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    def load(data, *args, **kwargs):
        return HandlerTaskInclude.load(data, *args, **kwargs)

    Host = type('Host', (object,), {})
    handler = load({'include': 'yum.yml'}, block=Block(), role=Role(), variable_manager=None, loader=None)
    assert isinstance(handler, HandlerTaskInclude)
    handler = load({'include_role': 'yum.yml'}, block=Block(), role=Role(), variable_manager=None, loader=None)
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-21 00:34:24.764420
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:34:33.931627
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    mock_loader = None

    host_vars = dict(hostvars=dict(host1=dict(ansible_host='127.0.0.1')))
    inventory = InventoryManager(loader=mock_loader, sources=host_vars)
    variable_manager = VariableManager(loader=mock_loader, inventory=inventory)

    raw_data = dict(
        name='test',
        listen='test'
    )

    handler_task_obj = HandlertaskInclude()
    handler_task_obj.load(raw_data, variable_manager=variable_manager, loader=mock_loader)

# Generated at 2022-06-21 00:34:35.367505
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-21 00:34:44.451011
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Example data from yaml
    data = {
        'include': 'all - debug',
        'listen': ['fixture_handler']
    }

    # Load data into handler object
    handler = HandlerTaskInclude.load(data)

    # Check whether all attributes are as expected
    assert handler.name == 'include',  "Incorrect name"

    assert isinstance(handler.tags, list), "Incorrect type for handler.tags"
    assert handler.tags == [], "Incorrect handler.tags"

    assert handler.when is None, "Incorrect handler.when"

# Generated at 2022-06-21 00:34:45.412352
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "TODO"

# Generated at 2022-06-21 00:34:57.153961
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block
    # from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    # roles_vars = dict(roles_name1=dict(role_vars="cmd_path"))
    # variable_manager = VariableManager(loader=DataLoader())
    # variable_manager.set_vars(host_vars)
    # variable_manager.set_vars(group_vars)
    # variable_manager.set_vars(roles_vars)
    # host = Host()
    # host_vars = dict(cmd_path

# Generated at 2022-06-21 00:35:07.922573
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #print("from HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)")
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    options = dict(inventory=['localhost, '], privilege_escalation=False, sudo_user='bob')
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=options['inventory'])
    variable_manager.set_inventory(inventory)

    play = Play()
    play.load('bob', variable_manager, loader)
    # play.set_variable_manager(variable

# Generated at 2022-06-21 00:35:15.128465
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    b = Block()

    handler = HandlerTaskInclude.load(dict(include="test.yml"), block=b, task_include=None)
    assert handler.handler_block == b, handler.handler_block
    assert handler.include_role == "test.yml", handler.include_role
    assert handler.notify_list is None, handler.notify_list
    assert handler.set_fact is None, handler.set_fact
    assert handler.pre_tasks is None, handler.pre_tasks
    assert handler.post_tasks is None, handler.post_tasks

    handler = HandlerTaskInclude.load(dict(include="test.yml", notify="restart-services"), block=b, task_include=None)

# Generated at 2022-06-21 00:35:18.171876
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Unit test for method load of class HandlerTaskInclude.
    """
    # Check if method load is correctly instantiating a HandlerTaskInclude object
    pass
    # Check if method load is correctly handling the 'listen' keyword
    pass

# Generated at 2022-06-21 00:35:19.642753
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t


# Generated at 2022-06-21 00:35:32.114494
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler1 = HandlerTaskInclude.load(
        data=dict(
            include='single_include_no_vars.yml'
        ),
        block=dict(
            plays=[]
        ),
    )

    handler2 = HandlerTaskInclude.load(
        data=dict(
            include='single_include_no_vars_nested.yml'
        ),
        block=dict(
            plays=[]
        ),
    )

    handler3 = HandlerTaskInclude.load(
        data=dict(
            include='single_include_vars.yml'
        ),
        block=dict(
            plays=[]
        ),
    )


# Generated at 2022-06-21 00:35:34.309728
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	test_class = HandlerTaskInclude()
	assert test_class != None

# Generated at 2022-06-21 00:35:35.177039
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:35:40.253632
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:35:43.178538
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    Make sure that HandlerTaskInclude loads up
    """

    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-21 00:35:52.253501
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude()
    assert h is not None
    assert h.action is None
    assert h.block is None
    assert h.changed_when is None
    assert h.name is None
    assert h.notify is None
    assert h.register is None
    assert h.retries is None
    assert h.role is None
    assert h.task_include is None
    assert h.until is None
    assert h.tags == ['always']
    assert h.when is None
    assert h.ignore_errors is False
    assert h.static is False
    assert h.delegate_to is None

# Generated at 2022-06-21 00:36:03.016000
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    import pytest

    # Create the inventory, with host and group
    # FIXME: Do not hardcode paths
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='test/integration/inventory')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a simple play, with one task in it

# Generated at 2022-06-21 00:36:03.998068
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:36:13.678851
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play

    # create needed objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    data = {}

    t = HandlerTaskInclude.load(
        data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader
    )
    assert t is None

# Generated at 2022-06-21 00:36:24.517463
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # testing sample 1
    data = dict(
      name        = 'test',
      hosts       = 'test_hosts',
      tasks       = 'test_tasks'
    )

    result = HandlerTaskInclude.load(data)
    assert result._attributes['name'] == 'test'
    assert result._attributes['hosts'] == 'test_hosts'
    assert result._attributes['tasks'] == 'test_tasks'

    # testing sample 2
    data = dict(
      name        = 'test',
      hosts       = 'test_hosts',
      tasks       = 'test_tasks',
      include     = 'task_include_file.yml'
    )

    result = HandlerTaskInclude.load(data)
    assert result._attributes['name'] == 'test'
    assert result._

# Generated at 2022-06-21 00:36:27.339343
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-21 00:36:30.933903
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

    assert handler.block == None
    assert handler.all_blocks == None
    assert handler.loop == None
    assert handler.role == None
    assert handler.task_include == None

# Generated at 2022-06-21 00:36:35.731767
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    HandlerTaskInclude: load
    '''

    HandlerTaskInclude.load(data={}, block=None, role=None, task_include=None, variable_manager=None, loader=None)


# Generated at 2022-06-21 00:36:47.107953
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti is not None

# Generated at 2022-06-21 00:36:50.835084
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-21 00:37:03.898365
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.tests.unit.test_task_include import MockTaskInclude
    
    mock_data = {
        'name': 'task1',
        'action': 'test'
    }
    task_include = MockTaskInclude()
    handler = HandlerTaskInclude.load(mock_data, task_include=task_include)
    assert handler.name == "task1"

    mock_data = {
        'name': 'task1',
        'action': 'test',
        'listen': 'done'
    }
    with pytest.raises(AssertionError) as e:
        HandlerTaskInclude.load(mock_data, task_include=task_include)


# Generated at 2022-06-21 00:37:04.570108
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task = HandlerTaskInclude()

# Generated at 2022-06-21 00:37:12.554718
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    host = 'host1'
    name = 'handler_task'
    play = 'play1'
    role = 'role1'
    task = 'task1'
    block = 'block1'
    playbooks = ['playbook1.yml', 'playbook2.yml']
    file_name = 'file1.yml'
    task_vars = {}

    data = {}
    data['playbooks'] = playbooks
    data['file_name'] = file_name
    data['task_name'] = task
    data['task_vars'] = task_vars
    data['name'] = name
    data['play'] = play
    data['role'] = role

    handler = HandlerTaskInclude.load(data)
    assert(handler.name == name)
    assert(handler.play == play)


# Generated at 2022-06-21 00:37:24.475423
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Host
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    ds = dict(
        name='test_inventory',
        hosts=["host1", "host2", "host3"],
        configure_for_ansible=True,
    )
    i = load_inventory_from_dict(ds)
    h = Host('foobar')
    variable_manager.set_host_variable(h, 'item', 'val1')
    variable_manager.set_host_variable(h, 'item', 'val2')

# Generated at 2022-06-21 00:37:33.898561
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler._block == None
    assert handler._role == None
    assert handler._task_include == None
    assert handler._parent == None
    assert handler._play == None
    assert handler._play_context == None
    assert handler._loader == None
    assert handler._variable_manager == None
    assert handler._included == False
    assert handler._static == False
    assert handler._always_run == False
    assert handler._notify == []
    assert handler._tags == []
    assert handler._when == []
    assert handler._failed_when == []
    assert handler._changed_when == []
    assert handler._run_once == False
    assert handler._register == None
    assert handler._ignore_errors == False
    assert handler._max_

# Generated at 2022-06-21 00:37:43.576084
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import os
    import sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block

    host_list = ['localhost', 'otherhost']
    print("test_HandlerTaskInclude: host_list: {}".format(host_list))
    block = Block()
    host = Host(name='localhost')
    print("host: {}".format(host))
    block.hosts.add(host)

# Generated at 2022-06-21 00:37:52.590023
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-21 00:38:00.367843
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    def _assert_object_attributes(handler, handler_data):
        for attr in handler_data:
            assert hasattr(handler, attr)
            assert getattr(handler, attr) == handler_data[attr]

    handler_data = {
        'name': 'test_handler',
        'tags': ['tag1', 'tag2'],
        'register': 'foobar',
        'ignore_errors': True,
        'listen': 'test',
    }
    handler = HandlerTaskInclude.load(handler_data, loader=None)
    _assert_object_attributes(handler, handler_data)

# Generated at 2022-06-21 00:38:26.651603
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Testing with full data arguments
    handler = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None
    )
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler._listen is None
    assert handler.handler is None
    assert handler.name is None

# Generated at 2022-06-21 00:38:29.179976
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.VALID_INCLUDE_KEYWORDS == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS



# Generated at 2022-06-21 00:38:30.490664
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert True

# Generated at 2022-06-21 00:38:42.609297
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-21 00:38:50.109336
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    t.check_options(t.load_data({}),"{}")
    t.check_options(t.load_data({},{"option": {"option1": "A", "option2": "B"}, "other_option": "value"}),"{}")
    t = HandlerTaskInclude()
    t.check_options(t.load_data({}),"")
    t = HandlerTaskInclude()
    t.check_options(t.load_data({}),"")



# Generated at 2022-06-21 00:38:53.298309
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = ["localhost"]
    t = HandlerTaskInclude(host, task_include=None)
    assert t.get_vars() == {}


# Generated at 2022-06-21 00:38:59.809570
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import json
    import os.path

    with open(os.path.join(os.path.split(__file__)[0], "test_handler_task_include.json"), "r") as f:
        data = json.load(f)

    handler = HandlerTaskInclude.load(data)
    result = handler.serialize()
    assert result == data

# Generated at 2022-06-21 00:39:00.759093
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:39:03.162301
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None

# Generated at 2022-06-21 00:39:09.038059
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "when" : "failed"
    }

    handler = HandlerTaskInclude.load(data)

    assert handler.__class__.__name__ == 'HandlerTaskInclude'
    assert handler.when == 'failed'


# Generated at 2022-06-21 00:39:54.793332
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(
        dict(include="tasks/foo.yml", with_items=["blah"])
    )
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.get_name() == "tasks/foo.yml"


# Generated at 2022-06-21 00:39:58.568852
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load({'include_tasks':'name.yml'})
    assert str(handler) == '<HandlerTaskInclude (include_tasks:name.yml)>'

    handler = HandlerTaskInclude.load({'include_tasks':'name.yml', 'listen':'test'})
    assert str(handler) == '<HandlerTaskInclude (include_tasks:name.yml listen:test)>'

    handler = HandlerTaskInclude.load({'include_tasks':'name.yml', 'listen':['test', 'test2']})
    assert str(handler) == '<HandlerTaskInclude (include_tasks:name.yml listen:test,test2)>'


# Generated at 2022-06-21 00:40:09.582647
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block

    print(dir(HandlerTaskInclude))
    print(help(HandlerTaskInclude))
    # Code to create input values
    block = Block.load(
        dict(
            tasks=[
                dict(
                    include="some_handler_with_listen.yml",
                    listen="LVS_DEPLOYED"
                )
            ]
        ),
        role=dict(),
        task_include=dict(),
        variable_manager=dict(),
        loader=dict()
    )

    data = dict(
        name="notify_haproxy",
        listener="LVS_DEPLOYED"
    )

    # Call to function under test

# Generated at 2022-06-21 00:40:20.375510
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.taggable import Taggable
    from ansible.vars.hostvars import HostVars
    block = included_file = role = role_include = taggable = task = None
    host = HostVars()
    print(Taggable.load({'tags':['foo']}))

# Generated at 2022-06-21 00:40:30.508287
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'listen': "start_app",
        'ignore_errors': True,
        'include': '/home/taks/application.yml',
        'tags': ['example','fruits']
    }
    handler = HandlerTaskInclude.load(data=data)
    assert handler._task.get_name() == 'task include'
    assert handler._task.loop is None
    assert handler._task.tags == ['example', 'fruits']
    assert handler._task.when is None
    assert handler._task.only_if is None
    assert handler._task.async_val is None
    assert handler._task.poll is None
    assert handler._task.become == False
    assert handler._task.become_user is None
    assert handler._task.listen == 'start_app'
    assert handler

# Generated at 2022-06-21 00:40:32.985943
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Unit test for method load of class HandlerTaskInclude
    '''

    assert()

# Generated at 2022-06-21 00:40:34.960527
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-21 00:40:41.581645
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-21 00:40:45.477955
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('\nIn test_HandlerTaskInclude_load')
    # TODO: write test for method load of class HandlerTaskInclude
    try:
        assert False
    except AssertionError:
        raise



# Generated at 2022-06-21 00:40:51.523740
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert "tasks" in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert "handlers" in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert "listen" in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-21 00:42:08.777404
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:42:13.246840
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    loader = None
    variable_manager = None
    h = HandlerTaskInclude()
    h1 = HandlerTaskInclude(block=None, role=None, task_include=None)
    h2 = HandlerTaskInclude(block=None, role=None, task_include=None)


# Generated at 2022-06-21 00:42:24.088873
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
         "include": "name.yml",
         "hosts": "hostgroup"
    }

    handler = HandlerTaskInclude.load(data)

    assert (handler._role is None)
    assert (handler._block is None)
    assert (handler._task_include is None)
    assert (handler._static_include is None)
    assert (handler._static_include_role is None)
    assert (isinstance(handler._errors, list))
    assert (isinstance(handler._tasks, list))
