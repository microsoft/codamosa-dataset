

# Generated at 2022-06-21 00:32:23.370340
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    #import sys
    # reload(sys)
    # sys.setdefaultencoding('utf-8')

    # init variables

# Generated at 2022-06-21 00:32:33.649629
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_data = dict(
        listen='testListen',
        name='test',
    )
    test_role = dict(name='testRole', default_vars=dict(), vars=dict(),
                     tasks=[dict(action=dict(module='testModule', args='testArgs'))])

    test_roles = [test_role]
    test_play = dict(roles=test_roles)

    handler = HandlerTaskInclude.load(test_data, block=False, role=test_role, task_include=test_data, play=test_play)
    handler.validate()

    assert handler.listen == 'testListen'
    assert handler.name == 'test'
    assert handler.notify == ['test']
    assert handler.static is not None
    assert handler.ignore_errors is not None




# Generated at 2022-06-21 00:32:35.764609
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude(
        task_include=None
    )
    h.load_data()
    h.check_options()

# Generated at 2022-06-21 00:32:42.230973
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    valid_data = {
        'include':  ['test', 'test2'],
    }

    # test with valid data, but with invalid keywords
    handler = HandlerTaskInclude.load(valid_data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert handler.name == 'include'
    assert handler.args == dict(valid_data)

    del valid_data['include']
    valid_data['listen'] = 'test'


# Generated at 2022-06-21 00:32:54.347874
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    import ansible.inventory.manager

    x = ansible.inventory.manager.InventoryManager(ansible.inventory.loader.Loader(), variable_manager=None, loader=None)
    host = Host(name='test_host_0')
    host.set_variable('ansible_ssh_host', '192.168.1.1')
    hs = x.pattern_match_hosts("test_host_0")


# Generated at 2022-06-21 00:33:05.067896
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    block = Block()
    role = Role()
    task_include = TaskInclude()

    h = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    assert(h._parent is None)
    assert(h._role is role)
    assert(h._block is block)
    assert(h._loader is None)
    assert(isinstance(h._attributes, dict))
    assert(len(h._attributes) == 0)

# Generated at 2022-06-21 00:33:17.194437
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #first we mock the arguments we would get from the playbook
    block = []

    #second we mock what we need to have as a return from the TaskInclude.load_data method
    task_include_return_value =  {'a': 1, 'b': True, 'c': 'foo'}

    #third we mock the TaskInclude.check_options return value, the method returns just the first argument it gets
    check_options_return_value = handler_task_include_load_data_return_value = {'a': 1, 'b': True, 'c': 'foo'}
    #finally, we build the mock object with the mocked methods
    task_include = build_mock_handler_task_include_load(task_include_return_value, check_options_return_value)

    #now we call the method we want

# Generated at 2022-06-21 00:33:18.038766
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #
    assert True

# Generated at 2022-06-21 00:33:30.800917
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError

    loader = None
    variable_manager = VariableManager()
    variable_manager._options = {}
    variable_manager._variable_manager_status = 1
    variable_manager._extra_vars = None
    variable_manager._vars_from_files = None
    variable_manager._vars_from_inventory = None
    variable_manager._vars_from_main = None
    variable_manager._fact_cache = {}
    variable_manager._cache_dir = "/var/tmp"
    variable_manager._cache_key = "test_variable_manager"
    variable_manager._errors = []
   

# Generated at 2022-06-21 00:33:33.630667
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load({})
    assert HandlerTaskInclude.load({},variable_manager=None)
    assert HandlerTaskInclude.load({'name':'test'},variable_manager=None)

# Generated at 2022-06-21 00:33:38.865686
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    a = HandlerTaskInclude()
    print(type(a))
    print(a)

# ansible-playbook test_handler.yml -i test_inventory --tags=test_handler_1
# test_handler_1

# Generated at 2022-06-21 00:33:47.589703
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    print('Test load without valid keyword: ')
    data = {
        'name': 'filters',
        'action': '/home/test/test.yml',
        'test': True,
        'when': "test",
        'listen': "test",
        'tags': "test"
    }
    handler = HandlerTaskInclude.load(data)
    print(handler.get_name())

# Generated at 2022-06-21 00:33:48.638609
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "TODO"

# Generated at 2022-06-21 00:33:50.916346
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude


# Generated at 2022-06-21 00:33:56.346551
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # set var_manager with a fake one
    var_manager = None
    # set loader with a fake one
    loader = None
    # init data
    data = {}

    play = HandlerTaskInclude.load(data=data, variable_manager=var_manager, loader=loader)

# Generated at 2022-06-21 00:33:59.427900
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert isinstance(handler, Handler) and isinstance(handler, TaskInclude)

# Generated at 2022-06-21 00:34:04.425542
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    obj = {'include': 'boom.yml', 'version': 2}
    t = HandlerTaskInclude.load(obj)
    assert t.static is False
    assert t.filename == 'boom.yml'

# Generated at 2022-06-21 00:34:09.856673
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include = './main.yml',
        static = './static.yml',
        private = './private.yml'
    )
    hti = HandlerTaskInclude.load(data)
    assert hti.get_vars() == data

# Generated at 2022-06-21 00:34:12.807597
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-21 00:34:13.611455
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = 'A'
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-21 00:34:22.060759
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Tests that loading HandlerTaskInclude instances via the load method works.
    """
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.variables.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-21 00:34:33.433083
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    data1 = dict(
        include=dict(
            name="test",
            static=["foo"],
            block=Block.load(
                dict(
                    handlers=["foo"],
                    tasks=["bar"],
                    rescue=["baz"],
                    always=["biz"],
                    roles=["foo"]
                )
            ),
            when=dict(a=1),
            tags=["foo"],
            ignore_errors=True,
            register="quux",
            vars=dict(a=1, b=2)
        )
    )

   

# Generated at 2022-06-21 00:34:34.813412
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_handler_task_include = HandlerTaskInclude()
    assert test_handler_task_include is not None

# Generated at 2022-06-21 00:34:36.936751
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    x = dict(
        handlers='x.y.z'
    )
    HandlerTaskInclude.load(x, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-21 00:34:43.115875
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    block = Block()
    block._role = 'role'
    block._parent = block
    block._role_name = 'role_name'

    task_include = TaskInclude()
    task_include._role = 'role'
    task_include._parent = block
    task_include._role_name = 'role_name'

    data = {"name": "handler",
            "listen": "handler_name"
           }

    # Testing if the returned object is an instance of

# Generated at 2022-06-21 00:34:55.543437
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import os.path
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    PLAYBOOK = """
- name: construct a host
  hosts: localhost
  connection: local
  tasks:
    - name: fetch a variable
      debug:
        var: foo
    - name: construct a variable
      set_fact:
        foo: bar
    - name: construct a hash
      set_fact:
        foo:
          bar: baz
"""
    inventory = InventoryManager(loader=DataLoader(), sources=os.path.join(os.path.dirname(__file__), './inventory'))

# Generated at 2022-06-21 00:35:03.490328
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    h = Host('hostname')
    g = Group('groupname')
    loader = DataLoader()
    variable_manager = VariableManager()
    h.set_variable_manager(variable_manager)
    g.set_variable_manager(variable_manager)

    data = {
        'include': 'test.yml',
        'hosts': 'hostname',
        'tasks': 'mytasks.yml'
    }

    include = HandlerTaskInclude.load(data, loader=loader, variable_manager=variable_manager)
    assert type(include.include) == str

# Generated at 2022-06-21 00:35:04.985075
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-21 00:35:08.077003
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    assert_raises(AnsibleError, HandlerTaskInclude.load, dict(foo='bar'), dict())

# Generated at 2022-06-21 00:35:11.111342
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    class Block():
        pass

    class Role():
        pass

    class TaskInclude():
        pass

    obj = HandlerTaskInclude(block=Block(), role=Role(), task_include=TaskInclude())

    assert obj

# Generated at 2022-06-21 00:35:19.335422
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include
    assert handler_task_include.VALID_INCLUDE_KEYWORDS == set(['tags', 'when', 'name', 'become', 'become_method', 'become_user', 'listen'])

# Generated at 2022-06-21 00:35:19.767367
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:35:28.711144
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # This is a directory including all test input files.
    test_input_dir = "./tests/test_inputs/"

    # We use to run the test with the first available file.
    test_input_dir = test_input_dir + "1.handler_task_include_input.yml"

    # Call the method under test with initial values loaded from yaml file.
    handler = HandlerTaskInclude.load(data=test_input_dir)

    print("\n\nResult of testing method load of class HandlerTaskInclude for input file: " + test_input_dir)
    print("\nTest returns: " + str(handler))



# Generated at 2022-06-21 00:35:35.884385
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    output = HandlerTaskInclude.load(data={"action": "test_action", "loop": "test_loop", "with_items": "test_with_items", "register": "test_register", "always_run": "test_always_run", "delegate_to": "test_delegate_to", "sudo": "test_sudo", "sudo_user": "test_sudo_user", "remote_user": "test_remote_user", "environment": "test_environment", "first_available_file": "test_first_available_file", "when": "test_when", "tags": "test_tags", "async": "test_async", "poll": "test_poll", "ignore_errors": "test_ignore_errors", "listen": "test_listen"})

    assert output.action == 'test_action'

# Generated at 2022-06-21 00:35:41.506063
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti.VALID_INCLUDE_KEYWORDS == set(('tasks', 'handlers', 'pre_tasks', 'post_tasks', 'always_run', 'first_available_file', 'any_errors_fatal', 'ignore_errors', 'listen'))

# Generated at 2022-06-21 00:35:53.741828
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = Host(name='host1')
    ds = dict (
        name = 'test',
        listen = 'all',
        tasks = ['task1', 'task2'],
        handlers = ['handler1', 'handler2']
    )
    ha = HandlerTaskInclude.load(ds, host, 'role1')
    assert ha.name == 'test', "Name is not 'test'"
    assert ha.role == 'role1', "Role name is not 'role1'"
    assert ha.block == host, "Block is not 'host'"
    assert ha.listen == 'all', "Listen is not 'all'"
    assert ha.tasks == [ 'task1', 'task2'], "Tasks are not 'task1, task2'"

# Generated at 2022-06-21 00:35:57.902309
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert not h.block
    assert not h.dynamic_block
    assert not h.dynamic_task

# Generated at 2022-06-21 00:36:00.284207
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None


# Generated at 2022-06-21 00:36:11.283929
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # required args:
    data = 'foo'
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # options args:
    block = 'foo'
    role = 'foo'
    task_include = 'foo'

    HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager)

# Generated at 2022-06-21 00:36:23.717639
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple
    from ansible.utils.vars import combine_vars
    from ansible.inventory.inventory import Inventory
    Options = namedtuple('Options', ['connection','module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    options = Options(connection='smart', module_path='/path/to/mymodules', forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 00:36:43.165814
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultSecret
    import json
    import yaml
    from collections import namedtuple

    loader = None
    results_callback = None
    variable_manager = VariableManager()
    inventory = Host(name='127.0.0.1')
    play_context = namedtuple('PlayContext', 'become_method become_user become_flags')
    play_context.hostvars=HostVars(variable_manager)
    play_context.become_method = None
    play_context.become_user = None
    play_context.become_

# Generated at 2022-06-21 00:36:47.358796
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    handler = t.check_options(
        t.load_data(data, variable_manager=variable_manager, loader=loader),
        data
    )

    assert handler is not None
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    # assert handler.__class__ is HandlerTaskInclude
    assert handler.__class__.__name__ is 'HandlerTaskInclude'
    assert handler._valid_include_keywords is HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert handler._valid_include_

# Generated at 2022-06-21 00:36:54.258363
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    data = dict(
        name="test handler",
        include="template.yml",
        tags=["always"],

    )
    block=Block()
    role=Role()
    task_include=TaskInclude()
    variable_manager=VariableManager()
    loader = MockLoader()
    handler_task_include=HandlerTaskInclude()
    assert handler_task_include.load(data, block, role, task_include, variable_manager, loader)
    assert handler_task_include.name == "test handler"


# Generated at 2022-06-21 00:37:05.399287
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.include_vars import IncludeVars

    variable_manager = VariableManager()

    # mock Host and Group
    variable_manager.host_vars = {
        'localhost': {
            'name': 'localhost',
            'group': 'all',
            'ansible_connection': 'local',
            'a': 1,
            'c': {'a': 1, 'b': 2},
            'b': [1, 2, 3],
            'd': {'a': [1, 2]},
            'z': False
        }
    }

# Generated at 2022-06-21 00:37:05.961290
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    raise NotImplementedError

# Generated at 2022-06-21 00:37:06.429568
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:37:11.729202
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {"include": "check_yum.yml", "listen": "yum_update_available", "name": "handler"}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:37:24.056896
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    def assert_equal(key,val1,val2):
        assert val1 == val2
    data = dict(
        name="test",
        listen="test"
    )
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler_task_include = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-21 00:37:33.632908
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    # Prepare test data
    block = Block(None)
    block._role = None
    block._parent = None
    block._role_params = {}
    block._task_blocks = []
    block._always_run = False
    block._dep_chain = []
    block._loop_block = None

    task_include = None

    data = {'tags': ['one', 'two', 'three'], 'handler': 'debug.foo'}

    # Instantiate class HandlerTaskInclude
    handler_task_include = HandlerTaskInclude(block=block, role=None, task_include=task_include)

    # Call method load

# Generated at 2022-06-21 00:37:43.219071
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from .fixture_loader import load_fixture
    from .mock import patch

    data = load_fixture('handler_task_include_load')
    with patch('ansible.playbook.role.Role.get_role_path') as mock_get_role_path:
        mock_get_role_path.return_value='/tmp/myrole'
        handler = HandlerTaskInclude.load(
            data,
            block=[],
            role=None,
            task_include=None,
            variable_manager=None,
            loader=None,
        )
    
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)
    assert 'handlers/include_handler.yml' == handler.include


# Generated at 2022-06-21 00:38:07.972502
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude.load(data={
        'name': 'test'
    })
    handler.serialize()
    handler.validate()
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-21 00:38:15.900791
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
     print("\nUnitTest == test_HandlerTaskInclude_load ==\n")

     data = { 
         "include": "{{ include_tasks_file }}", 
         "vars": { 
             "include_tasks_file": "common-tasks.yml" 
         } 
     }

     HandlerTaskInclude.load(data)

# Generated at 2022-06-21 00:38:23.960452
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    h = Host('foo')
    v = VariableManager()
    p = HandlerTaskInclude.load({'include':'my_file.yml'}, variable_manager=v)

    # Ensure the handler object is loaded properly
    assert isinstance(p, HandlerTaskInclude)

    # Ensure the attributes are set to expected values
    assert p._valid_attrs == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert isinstance(p.static, bool)
    assert isinstance(p.delegate_to, bool)
    assert isinstance(p.loop, bool)
    assert p.loop_control == {}
    assert p.changed_when == 'changed'

# Generated at 2022-06-21 00:38:25.369118
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-21 00:38:34.496064
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    from ansible.vars.hostvars import HostVars

    from ansible.vars.task_vars import TaskVars

    # create a mock group and add a mock host to it
    group = Group('test_group')
    group.add_host(Host('test_host'))

    # create a mock inventory object and load the group into it
    inventory = [group]

    group.set_variable('test_vault_var', AnsibleVaultEncryptedUnicode('secret_1'))
    group.set

# Generated at 2022-06-21 00:38:35.356633
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:38:44.947869
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test with no variable manager
    data = {
        u'include': u'somehost.yml'
    }
    included = HandlerTaskInclude.load(
        data=data,
        variable_manager=None,
        loader=None)

    assert included is not None
    assert included._role is None
    assert included._task_include is None
    assert included._parent is None
    assert included._block is None
    assert included._name == u'include'
    assert included._filename == u''
    assert included._static is True
    assert 'somehost.yml' in included._loader.list_all_roles()
    assert included._tags == set()
    assert included._when is None
    assert included._loop is None
    assert included._any_errors_fatal is False
    assert included._ignore_errors is False

# Generated at 2022-06-21 00:38:46.172910
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None
#

# Generated at 2022-06-21 00:38:48.902735
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = Handler(task = "a_task_name")
    assert t._attributes['name'] == "a_task_name", "Default Handler name is not None"


# Generated at 2022-06-21 00:38:55.153264
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "name": "test",
        "include": "include_me.yml"
    }
    t = HandlerTaskInclude.load(data)
    assert t.name == data["name"]
    assert t.include_role.name == data["include"]



# Generated at 2022-06-21 00:39:43.062603
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-21 00:39:43.884902
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:39:45.588269
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert(isinstance(h, HandlerTaskInclude))


# Generated at 2022-06-21 00:39:51.256989
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'name': '_', 'include': '_'}
    handler = HandlerTaskInclude.load(data)
    assert isinstance(handler, HandlerTaskInclude)
    assert handler._role.get_name() == '_'

# Generated at 2022-06-21 00:39:59.083131
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data_1 = {
        'include': 'test_roles/test_handler_task_include/tasks/test_handler_task_include.yml',
        'listen': 'start_test_handler_task_include',
    }

    test_HandlerTaskInclude = HandlerTaskInclude(data=test_data_1)
    assert test_HandlerTaskInclude.include == 'test_roles/test_handler_task_include/tasks/test_handler_task_include.yml'
    assert test_HandlerTaskInclude.listen == 'start_test_handler_task_include'

# Generated at 2022-06-21 00:40:07.990025
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert isinstance(h, Handler)
    assert isinstance(h, TaskInclude)
    # assert isinstance(h, Host)
    assert isinstance(h, HandlerTaskInclude)

    assert h.block is None
    assert h.role is None
    assert h.task_include is None
    assert h.VALID_INCLUDE_KEYWORDS == set(['delegate_to', 'run_once', 'tags', 'tasks', 'listen'])


# Generated at 2022-06-21 00:40:19.723225
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    myHandler = HandlerTaskInclude()
    assert myHandler



# [DEFAULT]
# inventory = /home/ansible/ansible-inventory/inventory
# remote_user = root
# vault_password_file = /home/ansible/ansible-inventory/vault-password-file
#
# # logging is off by default unless this path is defined
# log_path = /home/ansible/ansible-inventory/ansible-log.log
#
# # if set, always use this private key file for authentication, same as
# # if passing --private-key to ansible or ansible-playbook
# # private_key_file = /path/to/file
#
# # if set, always use this and never look into the configured private_key_file
# # or ~/.ssh/id_rsa, same as if passing --

# Generated at 2022-06-21 00:40:21.065274
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-21 00:40:30.857435
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    play = Play().load({
        "name": "test-play",
        "hosts": "all",
        "gather_facts": "no",
        "tasks": [
            {
                "include": "tasks/main.yml"
            }
        ]
    }, variable_manager=None, loader=None)

    block = Block().load(None, play=play, task_include=None, role=None, use_handlers=True, variable_manager=None, loader=None)
    role_include = RoleInclude().load(None, block=block, play=play, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-21 00:40:36.890815
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    variable_manager = "variable_manager"
    loader = "loader"
    handler = HandlerTaskInclude.load(data, variable_manager, loader)
    assert handler.__class__.__name__ == "HandlerTaskInclude"


# Test case
if __name__ == '__main__':
    data = {"include": "test_file"}
    test_HandlerTaskInclude(data)
    print("Success")

# Generated at 2022-06-21 00:42:01.838635
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude
    assert handler is not None
    # TODO: Check if these work
    # handler.load()
    # handler.check_options()
    # handler.load_data()

# Generated at 2022-06-21 00:42:14.191443
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    test_loader = DataLoader()
    test_inventory = InventoryManager(loader = test_loader)
    test_variable_manager = VariableManager()

    test_variable_manager.set_inventory(test_inventory)

    test_role  = Role()
    test_block = Block()

    test_task = Task()
    test_task.set_loader(test_loader)
    test_task.set_variable_