

# Generated at 2022-06-21 00:32:23.248661
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #import sys
    #sys.path.append("../../lib")
    #from ansible.inventory.host import Host
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskIncludeLoader
    #from ansible.vars import VariableManager
    #from ansible.errors import AnsibleError
    #from ansible.parsing.dataloader import DataLoader
    #from ansible.utils.display import Display
    #from ansible.config.manager import ConfigManager
    #from ansible.plugins import module_loader
    #from ansible.plugins.loader import handler_loader

    #display = Display()

    #variable_manager = VariableManager()
    #variable_manager.extra_vars = {'my

# Generated at 2022-06-21 00:32:33.351915
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ..loader import DataLoader
    from ..vars import VariableManager
    from ..inventory import Inventory
    from ..playbook.play_context import PlayContext

    def get_variable_manager(loader, inventory):
        return VariableManager(loader=loader, inventory=inventory)

    def get_loader(variable_manager):
        return DataLoader()

    def get_inventory(variable_manager):
        return Inventory(loader=None, variable_manager=variable_manager, host_list=['localhost'])

    def get_play_context(variable_manager):
        return PlayContext(variable_manager=variable_manager)

    variable_manager = get_variable_manager(get_loader, get_inventory)
    play_context = get_play_context(variable_manager)
    serializer = None
    loader = DataLoader()


# Generated at 2022-06-21 00:32:40.916909
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-21 00:32:47.010825
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'handlers': 'start_server'
    }
    print("\n")
    print("HandlerTaskInclude:", HandlerTaskInclude.load(data))

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-21 00:32:47.884873
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:32:48.631664
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-21 00:32:51.102223
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(None, None)
    assert handler_task_include is not None

# Generated at 2022-06-21 00:32:54.793960
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    p = PlayContext()
    t = HandlerTaskInclude(block=p)
    data = {'listen': 'XXX'}
    t.load(data)
    assert t._listen == 'XXX'

# Generated at 2022-06-21 00:32:56.076456
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h is not None

# Generated at 2022-06-21 00:32:56.710471
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:33:09.897065
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load({"listen": ["ssh"], "include": "my_playbook.yml"}, block=list(), role=list(), task_include=list(), variable_manager=list(), loader=list()) is not None
    assert HandlerTaskInclude.load({"include": "my_playbook.yml"}, block=list(), role=list(), task_include=list(), variable_manager=list(), loader=list()).get_name() == "my_playbook.yml"
    assert HandlerTaskInclude.load({"include": "my_playbook.yml"}, block=list(), role=list(), task_include=list(), variable_manager=list(), loader=list()).get_items() is None

# Generated at 2022-06-21 00:33:11.733307
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()

# Generated at 2022-06-21 00:33:18.460195
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict()
    block = dict()
    role = dict()
    task_include = dict()
    variable_manager = dict()
    loader = dict()
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler is not None
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-21 00:33:31.054510
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    print('\n=== test of ./lib/ansible/playbook/handler_task_include.py  ===')
    print('--- Check load ---')

    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    ## type
    print('\ntest 1')
    data = {
        'include': 'main.yml',
        'first': '2',
        'second': ['a', 'b'],
        'third': {'a': 1, 'b': 2}
    }
    expected = data['include']
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    actual = handler._include_name
    print('Expected:', expected)
    print('Actual:  ', actual)


# Generated at 2022-06-21 00:33:35.717544
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    l = []
    for x in l:
        s = HandlerTaskInclude(x)
        # Check if s is an object of class HandlerTaskInclude
        assert isinstance(s, HandlerTaskInclude)


# Generated at 2022-06-21 00:33:40.669738
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = HandlerTaskInclude(block=None, role=None, task_include=None)

    assert task_include.check_options(task_include.load_data({}, variable_manager={}, loader={}), {}) is True

    assert task_include.check_options(task_include.load_data({'listen': 'test'}, variable_manager={}, loader={}), {}) is True


# Generated at 2022-06-21 00:33:49.457455
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars.manager import VariableManager
    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    raw_data = {
        "name": "include copy",
        "include": "test_include.yaml"
    }

    data = [raw_data]


# Generated at 2022-06-21 00:34:01.932985
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data = '''
    - include: /path/to/file.yml
      tags:
        - tag1
        - tag2
      when: tag1 in tags or tag2 in tags and not tag3 in tags
    '''
    block = None
    role = None
    task_include = None
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:34:03.496707
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude.load()

# Generated at 2022-06-21 00:34:06.533959
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude('action==>reboot', 'name==>my_playbook')
    HandlerTaskInclude('action==>reboot')

# Generated at 2022-06-21 00:34:14.938345
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Executing test_HandlerTaskInclude...")

    data = dict()
    data['name'] = "test_HandlerTaskInclude"
    data['include'] = "test_HandlerTaskInclude.yml"

    handler = HandlerTaskInclude.load(data=data)
    if handler.name == "test_HandlerTaskInclude" \
            and handler.get_path() == "test_HandlerTaskInclude.yml":
        print("Test passed. ")
    else:
        print("Test failed" + handler.name + "!=" + "test_HandlerTaskInclude" + " or " + handler.get_path() + "!=" + "test_HandlerTaskInclude.yml")

    other_data = dict()
    other_data['name'] = "test_HandlerTaskInclude_other"
    other_

# Generated at 2022-06-21 00:34:16.038990
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('Executing constructor test for class HandlerTaskInclude.')
    HandlerTaskInclude()

# Generated at 2022-06-21 00:34:18.784996
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    TaskInclude.add_handler_to_loader()
    Handler.add_handler_to_loader()
    task_include_handler = TaskInclude.load()
    task_include_handler.check_options()
    assert task_include_handler.static()

# Generated at 2022-06-21 00:34:19.933153
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
#     t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    return

# Generated at 2022-06-21 00:34:32.721095
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    loader = 'loader_loader'
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['test/ansible/hosts'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    task = Task().load({'name':'test task', 'action':'test action'}, variable_manager=variable_manager, loader=loader)
    block = 'block_block'
    role = 'role_role'

# Generated at 2022-06-21 00:34:39.874515
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.digest.md5sum import md5sum
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.utils.addresses import parse_address
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import become_loader

    my_host_name = 'myhost'
    my_host = Host(name=my_host_name)
    my_host_vars = dict(ansible_ssh_host='127.0.0.1')
    my_host.vars = my_host_vars
    my_host_inventory = dict(my_host)

    # Mock

# Generated at 2022-06-21 00:34:42.785185
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test if function load returns a HandlerTaskInclude
    # object when called with valid arguments
    assert HandlerTaskInclude.load({}, role='')

# Generated at 2022-06-21 00:34:50.076294
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import tempfile
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play

    host_name = "myhost"
    playbook_file = tempfile.NamedTemporaryFile()

    myhost = Host(name=host_name)
    myhost.set_variable("playbook_dir", "/playbook/dir")
    myhost.set_variable("inventory_dir", "/inventory/dir")
    myhost.set_variable("inventory_file", "/inventory/file")
    myhost.set_variable("inventory_dirs", "/inventory/dirs")


# Generated at 2022-06-21 00:34:53.419431
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = Handler.load({"listen": "foo"}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.listen is not None

# Generated at 2022-06-21 00:35:04.930957
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(data={"include": "a_task.yml"}, task_include=True, block=None, role=None)

## Unit test for method validate_names of class HandlerTaskInclude
#def test_HandlerTaskInclude_validate_names():
#    assert HandlerTaskInclude.validate_names(names=["foo.yml", "bar.yml"])
#
## Unit test for method get_vars of class HandlerTaskInclude
#def test_HandlerTaskInclude_get_vars():
#    assert HandlerTaskInclude.get_vars(
#                    host=Host("127.0.0.1"),
#                    task={"foo": "bar"},
#                    include_params={"x": "y"},
#                    task_vars=dict(),
#                    variables=VariableManager

# Generated at 2022-06-21 00:35:18.045141
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.vars.manager import VariableManager

    from ansible.template import Templar
    from ansible.config.manager import ConfigManager
    from ansible.vars.clean import clean_facts
    from ansible.vars.hostvars import HostVars
    def lookup_loader(name, paths=None):
        return loader

    def variable_manager_constructor(loader=None, inventory=None):
        return VariableManager(loader=loader, inventory=inventory, version_info=version_info)

    ConfigManager._instance = None
    config = ConfigManager(parser='configparser')
    loader = config.get_plugin_loader()
    templar = Templar(loader=loader)
    inventory = MagicMock()
   

# Generated at 2022-06-21 00:35:30.311659
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_handler = HandlerTaskInclude(block=None, role=None, task_include=None)

    test_data = {'include_tasks': '/tmp/test_tasks.yml', 'listen': 'test_some_event'}
    test_result = test_handler.check_options(
        test_handler.load_data(test_data, variable_manager=None, loader=None),
        test_data
    )['tasks']

    expected_result = [{'name': 'test_include_tasks', 'when': []},
                       {'include_role': {'name': '/tmp/test_tasks.yml'}},
                       {'listen': 'test_some_event'}
                      ]

    assert test_result == expected_result

# Generated at 2022-06-21 00:35:37.756450
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    v = {'hosts': 'all'}
    d = {'listen': 'restart apache', 'name': 'handler_task_include'}
    h = HandlerTaskInclude.load(d)
    assert h.data == d
    assert h.block._load_name == 'handler_task_include'
    assert h.block == h.task

# Generated at 2022-06-21 00:35:44.154942
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None
    )

    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.name == None

    handler = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None,
        name="myhandler"
    )

    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.name == "myhandler"

# Generated at 2022-06-21 00:35:54.853323
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    #from ansible.parsing.dataloader import DataLoader
    #from ansible.playbook.play import Play
    #from ansible.playbook.play_context import PlayContext
    #from ansible.executor.task_queue_manager import TaskQueueManager
    #from ansible.executor.playbook_executor import PlaybookExecutor
    #from ansible.playbook.task import Task
    #loader = DataLoader()
    loader = None
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host()
    inventory.add_host(host)
    #play_source = dict

# Generated at 2022-06-21 00:35:58.250745
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="foo",
        include="baz"
        )
    variable_manager = None
    loader = None
    task = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.name == data['name']
    assert task.include == data['include']

# Generated at 2022-06-21 00:36:00.094647
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()


# Generated at 2022-06-21 00:36:01.880022
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude.load({'name': 'test_handler'})

# Generated at 2022-06-21 00:36:06.036268
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert(HandlerTaskInclude("test.handler").name == "test.handler")
    assert(HandlerTaskInclude("test.handler").action == "test.handler")

# Generated at 2022-06-21 00:36:07.935181
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    global handler
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)


# Generated at 2022-06-21 00:36:25.965941
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # For now, HandlerTaskInclude is a subclass of Handler, and
    # TaskInclude.  The only difference is in their load function.  As
    # a result, this test aims to test that the load function works.
    hti = HandlerTaskInclude()

    # Make sure the load method works with a valid case.
    valid_data = {
        'include_tasks': 'test',
        'listen': 'test'
    }
    assert(hti.load(valid_data, block=None, role=None, task_include=None, variable_manager=None, loader=None))

    # Make sure the load method works with an invalid case.
    invalid_data = {
        'include_tasks': 'test',
        'listen': 'test',
        'invalid_keyword': 5
    }
   

# Generated at 2022-06-21 00:36:31.928123
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """ constructor of class HandlerTaskInclude"""

    from ansible.inventory.host import Host
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    h = HandlerTaskInclude()
    Host()



# Generated at 2022-06-21 00:36:32.845160
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:36:35.871605
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(
        block=None, 
        role=None, 
        task_include=None
        )



# Generated at 2022-06-21 00:36:36.674051
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-21 00:36:44.889397
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    data = dict(
        include="test_include",
        include_tasks="test_include_tasks",
        include_role="test_include_role",
        include_vars="test_include_vars",
        include_files="test_include_files",
        include_vars_files="test_include_vars_files",
        loop="test_loop",
        with_items="test_with_items",
        listen="test_listen",
    )

    variable_manager = VariableManager()
    loader = None
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources='')
    t = HandlerTaskInclude

# Generated at 2022-06-21 00:36:55.390648
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    h = HandlerTaskInclude.load(
        data=dict(
            include=dict(
                tasks='test.yml'
            )
        ),
        block=Block.load(
            data=dict(
                handlers='test.yml'
            ),
            play=None,
            variable_manager=VariableManager(),
            loader=DataLoader()
        ),
        variable_manager=VariableManager(),
        loader=DataLoader()
    )
    assert len(h._tasks) == 1
    assert isinstance(h._tasks[0], TaskInclude)

# Generated at 2022-06-21 00:37:01.508852
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        u"include": u"/tmp/test_handler_task_include.yml"
    }
    handler_task_include = HandlerTaskInclude()
    handler = handler_task_include.load(data)

    assert handler.get_name() == u"/tmp/test_handler_task_include.yml"

# Generated at 2022-06-21 00:37:08.113669
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    e = None
    try:
        h = HandlerTaskInclude.load(dict(name='test'), variable_manager=None, loader=None)
        print("test_HandlerTaskInclude_load() [PASS]")
    except Exception as e:
        print("test_HandlerTaskInclude_load() [FAIL]")
        print("Exception: ", str(e))

# Generated at 2022-06-21 00:37:09.141015
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assertTrue(HandlerTaskInclude())