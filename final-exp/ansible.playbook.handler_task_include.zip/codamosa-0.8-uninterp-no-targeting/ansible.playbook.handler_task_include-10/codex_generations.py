

# Generated at 2022-06-21 00:32:23.076153
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block = Block(None)
    role = "role_name"
    task_include = "task_include_name"
    variable_manager = VariableManager()
    loader = DataLoader()

    data = {
        "name": "my_handler_name",
        "listen": "my_handler_listen"
    }

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert isinstance(handler, HandlerTaskInclude)
    assert handler.block == block
    assert handler.role == role
    assert handler.task_include == task_

# Generated at 2022-06-21 00:32:25.732523
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert isinstance(HandlerTaskInclude(), HandlerTaskInclude)
    assert isinstance(HandlerTaskInclude(), TaskInclude)

# Generated at 2022-06-21 00:32:35.242064
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''
    c = HandlerTaskInclude(block, role, task_include)
    '''
    ###
    # Test a normal case
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    import ansible.inventory
    host1 = ansible.inventory.host.Host(name='host1')
    task1 = Task(name='task1', action='action1', delegate_to=host1)
    task2 = Task(name='task2', action='action2', delegate_to=host1)
    block1 = Block(role=RoleInclude(path='path1', name='name1'), block=[task1, task2])
    task_include1 = TaskInclude(name='task_include1')
   

# Generated at 2022-06-21 00:32:41.885265
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-21 00:32:49.280076
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    data = {'listen': 'foo'}
    block = None
    role = None
    task_include = None
    handler = HandlerTaskInclude.load(
        data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager='variable_manager',
        loader='loader'
    )

    print(handler)

# Generated at 2022-06-21 00:32:59.934875
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data_properties = [
        'block',
        'when',
        'name',
        'first_available_file',
        'local_action',
        'local_action_args',
        'notify',
        'listen',
        'register',
        'static',
        'run_once',
        'delegate_to',
        'delegate_facts',
        'failed_when',
        'changed_when',
        'until',
        'retries',
        'delay',
        'environment',
        'args',
        'tags',
        'ignore_errors',
        'role',
        'ignore_errors',
        'any_errors_fatal'
    ]


# Generated at 2022-06-21 00:33:04.475549
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({
        u'name': u'insert at top',
        u'include': {
            u'name': u'test.yml'
        }
    })

# Generated at 2022-06-21 00:33:10.321994
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("\nIn test_HandlerTaskInclude()...")
    # Create a dummy class
    class Block:
        pass

    # Create a new instance of HandlerTaskInclude
    t = HandlerTaskInclude(block=Block(),
                           role=None,
                           task_include=None)
    assert t.block == Block()
    print("Passed!")

test_HandlerTaskInclude()

# Generated at 2022-06-21 00:33:16.576717
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(data={
        'name': 'Example',
        'handler_path': 'foo/bar/baz.yml',
        'listen': 'foobar'
    })
    assert handler.action == 'foobar'
    assert handler.action == 'foobar'

# Generated at 2022-06-21 00:33:24.476749
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    included_file = "included_file"
    task_include = _task.TaskInclude(included_file)
    handler = _handler.HandlerTaskInclude({}, task_include)
    assert handler.handler is None
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include == task_include
    assert not handler.subset
    assert not handler.static


# Generated at 2022-06-21 00:33:36.660378
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task, Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    from copy import deepcopy

    loader = DataLoader()
    inventory = { }

# Generated at 2022-06-21 00:33:37.202272
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:33:39.857483
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    # assert handler.__class__.__name__ == "HandlerTaskInclude"
    assert handler.VALID_INCLUDE_KEYWORDS.union(('listen',))

# Generated at 2022-06-21 00:33:40.974709
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:33:43.217908
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-21 00:33:53.049710
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory('localhost'))

    block = Block()
    host = Host('localhost')
    group = Group('test')
    group.add_host(host)
    block.set_parent_group(group)

    t = HandlerTaskInclude()
    handler = t.load({"include": "foo.yml"}, block=block, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:33:59.505577
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude.load(
        data={
            "include": "tasks/main.yml",
            "listen": "task_name"
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    # assert isinstance(hti, HandlerTaskInclude)

# Generated at 2022-06-21 00:34:00.745712
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-21 00:34:12.274959
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.vars import VariableManager
    from ansible.inventory import Host, Inventory
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = None
    host = Host(name='localhost')
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[host])
    play_context = PlayContext()

    block = Block(
        task_list=[],
        role=None,
        always=False,
        loop='item',
        loop_with=None,
        name=None
    )

    role = None

    task_include = None


# Generated at 2022-06-21 00:34:13.892139
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    x = HandlerTaskInclude()
    assert x

# Generated at 2022-06-21 00:34:17.277881
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:34:26.010305
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    import mock

    t = Task()
    t._role = mock.MagicMock()
    t._role.get_path = mock.MagicMock(return_value='/my/roles/foo')
    t._role.name = "foo"

    a = Host(name="somehost")
    b = Host(name="otherhost")

    ti = HandlerTaskInclude(block=t, role=t._role)
    ti.load_data({'include': 'tasks/main.yml'})

    ht = HandlerTaskInclude(block=t, role=t._role, task_include=ti)
    ht.load_data({'listen': 'foo'})

    assert ht.notify is None


# Generated at 2022-06-21 00:34:30.089723
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    example = {"include": "somefile.yml"}
    assert HandlerTaskInclude.load(example) is not None
    assert type(HandlerTaskInclude.load(example)) is HandlerTaskInclude

# Generated at 2022-06-21 00:34:42.456838
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.block
    from ansible.playbook.task import Task
    
    h = HandlerTaskInclude()
    data = {}
    block = ansible.playbook.block.Block()
    role = None
    task_include = Task()
    task_include.name = 'test_task_name'
    loader = None
    variable_manager = None
    print(h.load(data, block, role, task_include, variable_manager, loader))
    ansible.playbook.task_include.TaskInclude.VALID_INCLUDE_KEYWORDS = HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert(h.load(data, block, role, task_include, variable_manager, loader))


# Generated at 2022-06-21 00:34:47.639753
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # create a host for testing
    # h = Host('foo')
    a = HandlerTaskInclude()
    data = {'name':"Test Name", 'keyword': "Test Keyword"}
    result = a.load(data)

    # check if result is a valid HandlerTaskInclude class
    assert isinstance(result, HandlerTaskInclude), "result is a valid HandlerTaskInclude class"

    # check the validity of the keyword
    assert result.keyword == "Test Keyword", "Keyword was successfully loaded"

# Generated at 2022-06-21 00:34:49.745250
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    return t

# Generated at 2022-06-21 00:34:50.536990
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:35:01.858396
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    display = Display()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-21 00:35:07.330005
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(
        data=dict(
            listen=dict(
                module_name='foobar',
                arguments=dict(
                    test='test',
                    test2='test2'
                )
            )
        )
    ).listen == 'foobar'

# Generated at 2022-06-21 00:35:11.796675
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('\n{0}::{1}'.format(__name__, sys._getframe().f_code.co_name))

    # host = Host(name='dummy')
    # handler = Handler()
    # handler.set_loader(DictDataLoader({}))
    # handler.parent = host



# Generated at 2022-06-21 00:35:23.612269
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
    # FIXME: mock_loader should be assigned to a real mock object
    # FIXME: mock_task_include should be assigned to a real mock object
    # FIXME: mock_variable_manager should be assigned to a real mock object
    # result = HandlerTaskInclude.load(data=mock_data, task_include=mock_task_include, variable_manager=mock_variable_manager, loader=mock_loader)
    # FIXME: validate result

# Generated at 2022-06-21 00:35:26.618505
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Create a valid data structure for a handler
    data = {'name': 'foo'}
    
    # Try to load the handler with the data structure
    handler = HandlerTaskInclude.load(data)

# Generated at 2022-06-21 00:35:34.921218
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=["localhost"])
    loader = None
    variable_manager = None
    p = Play().load(
        {
            'hosts': 'localhost',
            'handlers': [
                'main.yml',
                {'name': 'another.yml'},
                {'include': 'third.yml'}
            ]
        },
        variable_manager=variable_manager,
        loader=loader
    )


# Generated at 2022-06-21 00:35:38.200627
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block='Tasks', role='role_name', task_include='task_includer')


# Generated at 2022-06-21 00:35:42.020188
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Testing HandlerTaskInclude.load()")
    handler_task_include = HandlerTaskInclude()
    result = handler_task_include.load({'include': 'tasks/main.yml'})
    print(result)
    assert result is not None

# Generated at 2022-06-21 00:35:42.796494
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude


# Generated at 2022-06-21 00:35:54.267536
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from unittest import mock
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.errors import AnsibleError


    # __init__(self, block=None, role=None, task_include=None, use_handlers=False, fail_on_missing=False)
    #
    # Instance of class Block is passed to block.
    block = Block()
    #
    # Instance of class TaskInclude is passed to task_include.
    task_include = TaskInclude()

    # instance of class HandlerTaskInclude is created.
    h = HandlerTaskInclude(block=block, role=None, task_include=task_include)

    # __init__ funtion raises an exception when 'block' is not instance of class Block.
   

# Generated at 2022-06-21 00:36:01.212456
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-21 00:36:13.520709
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import find_plugin_filters

    block = Block()
    host = Host('localhost')
    task = Task()
    task_include = TaskInclude()
    
    # handler = Handler.load(data, block=block, role=role, task_include=task_include

# Generated at 2022-06-21 00:36:24.981978
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # (1) Constructor for HandlerTaskInclude with arguments
    # handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    # (2) Constructor for HandlerTaskInclude without arguments
    handler = HandlerTaskInclude()

    # (3) Constructor for HandlerTaskInclude without arguments
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)

    # (4) Constructor for HandlerTaskInclude with keyword arguments
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)