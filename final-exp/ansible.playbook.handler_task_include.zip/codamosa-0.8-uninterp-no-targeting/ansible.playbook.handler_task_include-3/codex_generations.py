

# Generated at 2022-06-21 00:32:21.117388
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = TaskInclude()

    handler = HandlerTaskInclude(block=None, role=None, task_include=task_include)

    assert handler.VALID_INCLUDE_KEYWORDS == task_include.VALID_INCLUDE_KEYWORDS.union(('listen',))
    assert handler.block == None
    assert handler.role == None
    assert handler.task_include == task_include


# Generated at 2022-06-21 00:32:22.095735
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:32:30.136250
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import mock
    from ansible.playbook.block import Block

    load_data_mock = mock.MagicMock(return_value="hello")
    check_options_mock = mock.MagicMock(return_value="hello")

    t = HandlerTaskInclude.load(
        data="data",
        block=Block(),
        loader=mock.MagicMock(),
        variable_manager=mock.MagicMock(),
    )
    assert t.load_data == load_data_mock
    assert t.check_options == check_options_mock

# Generated at 2022-06-21 00:32:32.970749
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler= HandlerTaskInclude.load(data=None)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-21 00:32:39.333959
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    host = object()
    handler = HandlerTaskInclude.load(
        {
            'name': 'fake handler',
            'include': 'fake include'
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=object(),
        loader=object()
    )
    handler._load_included_file()
    handler._load_role_tasks()
    handler.evaluate_roles(host)
    handler.evaluate_conditional(host)



# Generated at 2022-06-21 00:32:46.000238
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti.VALID_INCLUDE_KEYWORDS == ('name', 'action', 'local', 'ignore_errors', 'only_if', 'not_if', 'sudo', 'sudo_user', 'tags', 'when', 'register', 'delegate_to', 'listen')

# Generated at 2022-06-21 00:32:47.476276
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass



# Generated at 2022-06-21 00:32:50.135961
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Construct default object
    handler = HandlerTaskInclude()


# Execute unit test
if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-21 00:32:50.912378
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-21 00:33:00.665552
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    v = VariableManager()
    loader = DataLoader()
    i = InventoryManager(loader=loader, sources=['tests/ansible/inventory/dynamic_inventory.py'])
    play = Play().load({'name': 'handler_task_include', 'hosts': 'all'}, variable_manager=v, loader=loader)

# Generated at 2022-06-21 00:33:10.371585
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.persistent_fact_dict import PersistentFactDict

    ################################################
    #                                              #
    #                                              #
    # Configuration of the playbook (main.yml)     #
    #                                              #
    #                                              #
    ################################################

# Generated at 2022-06-21 00:33:20.781769
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import ansible.playbook
    import ansible.inventory
    import ansible.utils
    import ansible.constants as C
    import os


# Generated at 2022-06-21 00:33:24.026876
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        include="../tasks/main.yml",
        static="Yes",
        something_new="something new"
    )

    handler = HandlerTaskInclude.load(data)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'
    assert handler.something_new == data['something_new']
    assert handler.static is True

# Generated at 2022-06-21 00:33:24.537259
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-21 00:33:35.718676
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """ This is how we use HandlerTaskInclude class in ansible/playbook/__init__.py (git 6c4cb1d)
    """
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)

    handler_TaskInclude = HandlerTaskInclude()
    handler_TaskInclude.block = Block()
    handler_TaskInclude.role = None
    handler_TaskInclude.task_include = None

    # First, we pretend we are in ansible/playbook/__init__.py (git 6c4cb1d).
    # We call the handler's load() method.


# Generated at 2022-06-21 00:33:38.567138
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert obj.block == None
    assert obj.role == None
    assert obj.task_include == None

# Generated at 2022-06-21 00:33:39.692414
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-21 00:33:40.516616
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-21 00:33:42.542339
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()

# Generated at 2022-06-21 00:33:47.601137
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data='notify: test-notify'
    h=HandlerTaskInclude.load(data)
    assert(h.name == 'test-notify')
    assert(h.action == 'notify')
    assert(h.args == None)

# Generated at 2022-06-21 00:34:00.887236
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create sample variable_manager object.
    variable_manager = object

    # Create sample data.
    data = object

    # Create sample loader object.
    loader = object

    # Create sample block object.
    block = object

    # Create sample role object.
    role = object

    # Create sample task_include object.
    task_include = object

    # Create object of class HandlerTaskInclude.
    handler_task_include = HandlerTaskInclude.load(data,
                                                   block=block,
                                                   role=role,
                                                   task_include=task_include,
                                                   variable_manager=variable_manager,
                                                   loader=loader)

# Generated at 2022-06-21 00:34:02.528605
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
#     handler = HandlerTaskInclude()

# Generated at 2022-06-21 00:34:11.744818
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Good example for test case-1 for loading a handler
    # data value for case-1: handler_defn(var)::handler name
    data_handler1 = dict(handler_defn='listen: "{{ httpd_port }}"')
    handler1 = HandlerTaskInclude.load(data=data_handler1)
    assert handler1 != None

    # Good example for test case-2 for loading a handler
    # data value for case-2: name
    data_handler2 = dict(name='listen: "{{ httpd_port }}"')
    handler2 = HandlerTaskInclude.load(data=data_handler2)
    assert handler2 != None

    # Bad example for test case-3 for loading a handler
    # data value for case-3: list

# Generated at 2022-06-21 00:34:23.491737
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a fake Block object
    block = Block(
        role=None,
        task_include=None,
        use_block_args=True
    )

    # Create a fake task_include object
    task_include = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None
    )

    # Create a fake role object
    role = AnsibleMapping(
        [
            ('name', 'foo'),
            ('meta', AnsibleMapping()),
            ('tasks', AnsibleSequence())
        ]
    )

    # Create a fake loader object

# Generated at 2022-06-21 00:34:25.486657
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-21 00:34:28.175388
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude()
    assert h.load(dict(include="aaa.yml"))

# Generated at 2022-06-21 00:34:36.465302
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.defaults import DEFAULTS
    from ansible.playbook.dynamic_include import IncludeDymanic
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.vars import GroupVars
    from ansible.inventory.vars import Host

# Generated at 2022-06-21 00:34:38.445484
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-21 00:34:47.030787
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    # Create the objects needed to call load method
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # data to be loaded
    data = {
        'name': 'test'
    }

    # Call the load method


# Generated at 2022-06-21 00:34:52.140923
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'handlers': [{'name': 'Test handler', 'listen': 'Test'}]}
    # TODO: add parameters for this function and create a test for it
    h = HandlerTaskInclude.load(data)
    assert 'Test handler' == h.name
    assert 'Test' == h.listen