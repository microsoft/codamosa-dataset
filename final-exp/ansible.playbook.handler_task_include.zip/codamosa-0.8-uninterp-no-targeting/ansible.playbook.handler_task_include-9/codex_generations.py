

# Generated at 2022-06-21 00:32:15.764668
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    c = HandlerTaskInclude()

# Generated at 2022-06-21 00:32:23.423076
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test Case 1
    data = {'handler': {'tasks': ['test_check_all_passed'], 'name': 'test_handler'}}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler.tasks == ['test_check_all_passed']
    assert handler.name == 'test_handler'


# Generated at 2022-06-21 00:32:26.567407
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude.load({'include': 'vars.yml'}, variable_manager='', loader='')
    assert h._task

# Generated at 2022-06-21 00:32:35.692546
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data = dict()
    test_data['include'] = "include.yml"
    test_data['tags'] = ["tags1", "tags2"]
    test_data['tasks'] = "tasks.yml"
    test_data['name'] = "/path/to/include.yml"

    handler = HandlerTaskInclude.load(test_data)

    assert handler is not None
    assert handler._parent is None
    assert handler._role is None
    assert handler._block is None
    assert handler._task_include is None
    assert handler._name == test_data['name']
    assert handler._tags == test_data['tags']
    assert handler._when is None
    assert handler._always is None
    assert handler._changed_when is None
    assert handler._failed_when is None
    assert handler._register

# Generated at 2022-06-21 00:32:37.138813
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

# Unit test to check of the load method of class HandlerTaskInclude

# Generated at 2022-06-21 00:32:38.186722
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    with pytest.raises(TypeError):
        HandlerTaskInclude()

# Generated at 2022-06-21 00:32:43.812377
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {u'listen': u'foo', u'include': u'bar'}
    handler = HandlerTaskInclude.load(data)
    assert handler.include == 'bar'
    assert handler.listen == 'foo'

# Generated at 2022-06-21 00:32:44.559488
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()


# Constructor of class HandlerTaskInclude

# Generated at 2022-06-21 00:32:55.548137
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.task_include
    import ansible.playbook.task
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.parsing.vault

    host = ansible.inventory.host.Host(name='127.0.0.1')
    host.set_variable('ansible_connection', 'local')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    inventory = ansible.inventory.Inventory(host_list=[host])

    task_include = ansible.playbook.task_include.TaskInclude()
    task_include.block = ansible.playbook.Handler()
    task_include.role = None
    task_include.task

# Generated at 2022-06-21 00:32:56.696874
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-21 00:33:04.315693
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    foo = HandlerTaskInclude(block=None, role=None, task_include=None)
    foo.check_options(data=None, ds=None)
    assert foo.VALID_INCLUDE_KEYWORDS == {'static', 'tasks', 'vars', 'tags', 'listen'}

# Generated at 2022-06-21 00:33:14.163973
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Initiate a play context
    play_context = PlayContext()

    # Initiate a task include
    task_include = TaskInclude()

    # Initiate a block
    block = Block()

    # Initialise a handler_task_include to load
    handler_task_include = HandlerTaskInclude()

    # Handler task and action

# Generated at 2022-06-21 00:33:15.528049
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-21 00:33:22.166423
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.role import Role

    hosts = [
        Host(name="localhost"),
    ]
    loader = DictDataLoader({
        "handlers/main.yml": """
        - name: handler1
          action: command echo 1
        - name: handler2
          action: command echo 2
        """,
        "handlers/extra.yml": """
        - name: handler3
          action: command echo 3
        - name: handler4
          action: command echo 4
        """
    })
    variable_manager = VariableManager()


# Generated at 2022-06-21 00:33:27.111451
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(
        {
            'include': 'include_me.yaml',
        },
        block={},
        role={},
        task_include={},
        variable_manager={},
        loader={}
    )

# Generated at 2022-06-21 00:33:36.702050
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    task_block = UnsafeProxy({})
    task = HandlerTaskInclude.load({'include': 'foo', 'listen': 'bar'}, task_block)
    # (c) 2013, Michael DeHaan <michael.dehaan@gmail.com>
    assert task.include == 'foo'
    # (c) 2012-2014, Michael DeHaan <michael.dehaan@gmail.com>
    assert task.tags == tuple()
    assert task.block is task_block
    assert task.any_errors_fatal
    assert not task.when
    assert task.notify == []
    # assert task.loop is None
    assert task.changed_when == ''
    assert task.failed_when == ''

# Generated at 2022-06-21 00:33:39.482324
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'foo.yml',
        'tags': ['test']
    }
    assert HandlerTaskInclude.load(data)
    assert HandlerTaskInclude.load(data, role=True)

# Generated at 2022-06-21 00:33:51.759741
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include' : 'test'}
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    t.load(data)

    data = { 'include' : {'file' : 'test'} }
    t.load(data)

    data = { 'include' : [ 'test' ] }
    t.load(data)

    data = { 'include' : [ {'file' : 'test'} ] }
    t.load(data)

    data = { 'include' : [ [{'file' : 'test'}] ] }
    t.load(data)

    data = { 'include' : [ [{'file' : ''}] ] }
    t.load(data)


# Generated at 2022-06-21 00:34:02.665998
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = ["rabbitmq_user",
            {"name": "bob",
             "password": "sekret",
             "vhost": "/",
             "state": "present",
             "tags": ["rabbit", "user"]}]
    block = None
    role = None
    task_include = None
    variable_manager = {}
    loader = None

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert handler.static is False
    assert handler.name == 'bob'
    assert handler.run_once is False
    assert handler.notify is []
    assert handler.listen is None
    assert handler.include_tasks is None
    assert handler.include_handlers is None
    assert handler.include_vars is None

# Generated at 2022-06-21 00:34:09.494095
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = h.load(data, block=None, role=None, task_include=None)
    assert handler.get_name() == 'name'
    assert handler.get_handler_path() == 'path'
    assert handler.once is True

