

# Generated at 2022-06-25 05:13:38.468326
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_1 = HandlerTaskInclude()

# Generated at 2022-06-25 05:13:44.929066
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    data = 'variable_manager'
    block = {'kwargs': 'foo'}
    task_include = {}
    variable_manager = 'foo'
    loader = 'n/a'
    handler_task_include_0.load(data, block, task_include, variable_manager, loader)
    return None

# Generated at 2022-06-25 05:13:45.779137
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # print("Calling method load from HandlerTaskInclude")
    HandlerTaskInclude.load()

# Generated at 2022-06-25 05:13:46.332143
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:13:48.337026
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Testing load of HandlerTaskInclude class")
    handler_task_include_1 = HandlerTaskInclude()

# Generated at 2022-06-25 05:13:57.999844
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude(name='test_HandlerTaskInclude')
    handler_task_include_2 = HandlerTaskInclude(name='test_HandlerTaskInclude', block=None)
    handler_task_include_3 = HandlerTaskInclude(name='test_HandlerTaskInclude', block=None, role=None)
    handler_task_include_4 = HandlerTaskInclude(name='test_HandlerTaskInclude', block=None, role=None, task_include=None)


# def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):

# Generated at 2022-06-25 05:14:02.891695
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Create the object that will be tested
    handler_task_include_0 = HandlerTaskInclude()

    data = []
    variable_manager = {}
    loader = {}

    # Execute the method load of the object handler_task_include_0 with the following parameters:
    # data, variable_manager, loader
    # Expected: handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = handler_task_include_0.load(data, variable_manager=variable_manager, loader=loader)

    assert handler is not None

# Generated at 2022-06-25 05:14:05.639888
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:09.222046
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Must take only one argument
    assert HandlerTaskInclude.__init__.__code__.co_argcount == 1
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None

# Generated at 2022-06-25 05:14:10.378836
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:15.833376
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:22.699524
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    data = {u'include':
                {u'include': u'roles/foo/tasks/main.yml',
                 u'name': u'include'}
            }
    loader = 'loader'
    block = None
    role = None
    task_include = None
    variable_manager = None
    assert loader == 'loader'

    handler_task_include_0.load(data, block=block, role=role,
        task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert loader == 'loader'


# Generated at 2022-06-25 05:14:26.989763
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load()


# Generated at 2022-06-25 05:14:27.829356
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    ...


# Generated at 2022-06-25 05:14:31.915293
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include_0 = TaskInclude()
    handler_task_include_0 = HandlerTaskInclude(block=None, role=R_0, task_include=task_include_0)
    assert handler_task_include_0 is not None


# Generated at 2022-06-25 05:14:34.732404
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # No test yet, only loading of modules implemented
    print("No test yet, only loading of modules implemented")

# Generated at 2022-06-25 05:14:45.122978
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
       handler_task_include = HandlerTaskInclude()
       # print("Successfully created instance of HandlerTaskInclude()")
    except:
       print("Failed to create instance of HandlerTaskInclude()")


# # Unit test for show() of class HandlerTaskInclude
# def test_show():
#     try:
#        handler_task_include = HandlerTaskInclude()
#        handler_task_include.show()
#        # print("Successfully called show() of HandlerTaskInclude")
#     except:
#        print("Failed to call show() of HandlerTaskInclude")

# # Unit test for reset() of class HandlerTaskInclude
# def test_reset():
#     try:
#        handler_task_include = HandlerTaskInclude()
#        handler_task_include.reset()
#        #

# Generated at 2022-06-25 05:14:54.232078
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_1 = HandlerTaskInclude()
    assert isinstance(handler_task_include_1, HandlerTaskInclude)

    handler_task_include_2 = HandlerTaskInclude()
    assert handler_task_include_1 == handler_task_include_2

    handler_task_include_3 = HandlerTaskInclude()
    handler_task_include_3.tags = ['test']
    assert handler_task_include_1 != handler_task_include_3

    handler_task_include_4 = HandlerTaskInclude()
    handler_task_include_4.notify = ['test']
    assert handler_task_include_1 != handler_task_include_4

    handler_task_include_5 = HandlerTaskInclude()
    handler_task_include_5.listen = ['test']
    assert handler_

# Generated at 2022-06-25 05:14:58.896450
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # assertion of invalid include keywords
    assert HandlerTaskInclude.load(dict(invalid='invalid'), variable_manager=None, loader=None) is None

    # assertion of invalid include handler action
    assert HandlerTaskInclude.load(dict(include='invalid'), variable_manager=None, loader=None) is None

    # assertion of valid include handler action
    assert HandlerTaskInclude.load(dict(include='valid'), variable_manager=None, loader=None) is not None

# Generated at 2022-06-25 05:15:04.046218
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.__class__.__name__ == 'HandlerTaskInclude'
    assert handler_task_include_0.VALID_INCLUDE_KEYWORDS == set([])


# Generated at 2022-06-25 05:15:10.885374
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude(variable_manager = dict(), loader = dict())

# Generated at 2022-06-25 05:15:11.725874
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()


# Generated at 2022-06-25 05:15:13.771935
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create an instance of the class
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.__class__ is HandlerTaskInclude

# Generated at 2022-06-25 05:15:20.784628
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(data=mock_data_0, block=mock_data_1, role=mock_data_2, task_include=mock_data_3, variable_manager=mock_data_4, loader=mock_data_5)

# Generated at 2022-06-25 05:15:21.608673
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_1 = HandlerTaskInclude()


# Generated at 2022-06-25 05:15:23.888590
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert isinstance(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS, set)
    assert isinstance(HandlerTaskInclude(), HandlerTaskInclude)
    assert isinstance(HandlerTaskInclude.load(data='', block=None, role=None, task_include=None, variable_manager=None, loader=None), HandlerTaskInclude)

# Generated at 2022-06-25 05:15:26.145847
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert isinstance(handler_task_include_0._load_file('', '', '', '', ''), HandlerTaskInclude)

# Generated at 2022-06-25 05:15:29.280663
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    data = dict(name='myhandler')
    result = handler_task_include.load(data=data)
    assert result.name == 'myhandler'


# Generated at 2022-06-25 05:15:30.155705
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # instantiate HandlerTaskInclude object
    handler_task_include_1 = HandlerTaskInclude()


# Generated at 2022-06-25 05:15:33.656429
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    data = dict(
        listen = ''
    )
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler_task_include_0.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-25 05:15:46.519243
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:15:54.698727
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    include_file_0 = {'include_file_0': './templates/test_ansible_module.yml'}
    include_file_1 = {'include_file_1': './templates/test_ansible_module.yml'}
    include_file_2 = {'include_file_2': './templates/test_ansible_module.yml'}
    include_file_3 = {'include_file_3': './templates/test_ansible_module.yml'}
    include_files_list = [include_file_0, include_file_1, include_file_2, include_file_3]
    loader_0 = {'loader_0': None}

# Generated at 2022-06-25 05:15:56.150239
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    handler_task_include.load()


# Generated at 2022-06-25 05:15:58.003230
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None


# Generated at 2022-06-25 05:16:01.411166
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t.name == 'meta' and t.tasks == [], "HandlerTaskInclude() constructor failed"


# Generated at 2022-06-25 05:16:07.096897
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude(block=None)
    handler_task_include_2 = HandlerTaskInclude(block=None, tasks=[], role=None)
    handler_task_include_3 = HandlerTaskInclude(block=None, tasks=[], role=None, task_include=None)
    handler_task_include_4 = HandlerTaskInclude(
        block=None, tasks=[], role=None, task_include=None, listen=[]
    )


# Generated at 2022-06-25 05:16:10.912074
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_0 = HandlerTaskInclude()

#
# AUTHORS:
#   Ansible Core Team
#
# NAME:
#   HandlerTaskInclude
#
# SYNOPSIS:
#   HandlerTaskInclude(self, *args, **kwargs)
#
# DESCRIPTION:
#
# RETURNS:
#   N/A #
# RAISES:
#   N/A
#

# Generated at 2022-06-25 05:16:17.893633
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    data = 'task_include_0'
    block = 'play'
    role = 'role_0'
    task_include = 'task_include_0'
    variable_manager = 'var_manager_0'
    loader = 'loader_0'

    # Run the method under test
    result = handler_task_include.load(
        data, block, role, task_include, variable_manager, loader
    )

    # Verify the result
    assert(result != None)

# Generated at 2022-06-25 05:16:19.702904
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()

# Generated at 2022-06-25 05:16:29.389623
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ########
    # parsing:

    loader = None

    # name: balanced
    # file: /home/user/Projects/ansible/test/integration/targets/inventory_include_vars/group_vars/all
    # mode: 0600


# Generated at 2022-06-25 05:16:52.167541
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:16:57.126380
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Testing load method of class HandlerTaskInclude")

    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load()


# Generated at 2022-06-25 05:16:59.511322
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include,HandlerTaskInclude)


# Generated at 2022-06-25 05:17:09.236471
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_1 = HandlerTaskInclude()
    
    # Example to be tested
    data = '''\n
      handler:
        - meta: flush_handlers'''
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    expected = TaskInclude()
    actual = TaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert actual == expected, actual


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 05:17:13.668350
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)
    assert handler_task_include is not None
    assert handler_task_include.__class__.__name__ == 'HandlerTaskInclude'


# Generated at 2022-06-25 05:17:15.065141
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h is not None


# Generated at 2022-06-25 05:17:20.730956
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude.load()
    assert handler_task_include_0 is None

if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-25 05:17:26.106930
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'ignore_errors', 'listen', 'when', 'name', 'tags'}

# Generated at 2022-06-25 05:17:28.828184
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_0 = HandlerTaskInclude()
    # handler_task_include.load(data)
    # The method load is not implemented
    # assert False



# Generated at 2022-06-25 05:17:31.870517
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None




# Generated at 2022-06-25 05:17:56.139232
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.load(str_0, str_1)

# Generated at 2022-06-25 05:18:04.622107
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)

# Generated at 2022-06-25 05:18:11.294791
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_1 = b'\xea'
    str_2 = '0y'
    str_3 = ';E2O'
    int_1 = -14
    handler_task_include_2 = HandlerTaskInclude(int_1)
    handler_task_include_3 = HandlerTaskInclude(bytes_1)
    var_1 = handler_task_include_2.load(str_2, str_3)

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:18:17.825984
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)


# Generated at 2022-06-25 05:18:27.961225
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    int_0 = -527
    handler_task_include_0 = HandlerTaskInclude(int_0)
    bytes_0 = b'\xfa'
    str_0 = 'gRnE\rOQ3n9; "Iy4D'
    str_1 = '\x0c#'
    handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)
    handler_task_include_1.load(str_0, str_1)

if __name__ == "__main__":
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:18:35.306025
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\x86'
    str_0 = '  0i'
    str_1 = 'V7xu&;/'
    int_0 = -898
    handler_task_include_0 = HandlerTaskInclude(str_1)
    var_0 = handler_task_include_0.load(str_1, str_0)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)
    handler_task_include_1 = HandlerTaskInclude(int_0)


# Generated at 2022-06-25 05:18:40.605439
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)


# Generated at 2022-06-25 05:18:44.252034
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\xf6'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.check_options(int_0, str_0)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)


# Generated at 2022-06-25 05:18:50.897993
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)


# Generated at 2022-06-25 05:18:51.662140
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-25 05:19:36.004950
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-25 05:19:40.031161
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_0 = HandlerTaskInclude(int_0)

# Generated at 2022-06-25 05:19:47.109257
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)


# Generated at 2022-06-25 05:19:51.504932
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude(1)
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)


# Generated at 2022-06-25 05:19:59.656891
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)


# Generated at 2022-06-25 05:20:01.579828
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

# Generated at 2022-06-25 05:20:03.508477
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-25 05:20:10.802993
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)
    handler_task_include_1.load(str_1, str_0)


# Generated at 2022-06-25 05:20:12.048023
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_HandlerTaskInclude = HandlerTaskInclude()
    assert isinstance(my_HandlerTaskInclude, HandlerTaskInclude)


# Generated at 2022-06-25 05:20:16.395861
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        test_case_0()
    except SystemExit as exception:
        assert exception.code == 0


# Tested module
from ansible.playbook.handler_task_include import HandlerTaskInclude

# Tested method
from ansible.playbook.handler_task_include import load

# Global variables
from ansible.playbook.handler_task_include import VALID_INCLUDE_KEYWORDS


# Generated at 2022-06-25 05:21:47.226906
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True == True

# Generated at 2022-06-25 05:21:49.138436
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('In test_HandlerTaskInclude')
    assert(test_case_0())


# Generated at 2022-06-25 05:21:53.277385
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)

# Generated at 2022-06-25 05:21:54.394110
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

# vim: set expandtab sts=4 ts=4 sw=4 et

# Generated at 2022-06-25 05:22:00.390351
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    int_0 = 1770266314
    str_0 = '- 3'
    str_1 = '!N\x15'
    bytes_0 = b'q{r'
    handler_task_include_0 = HandlerTaskInclude(int_0)
    assert isinstance(handler_task_include_0, HandlerTaskInclude)
    assert isinstance(handler_task_include_0, Handler)
    assert isinstance(handler_task_include_0, TaskInclude)
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)
    assert isinstance(handler_task_include_1, HandlerTaskInclude)
    assert isinstance(handler_task_include_1, Handler)

# Generated at 2022-06-25 05:22:05.096818
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    assert handler_task_include_0.action == int_0
    var_0 = handler_task_include_0.load(str_0, str_1)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)
    # assert handler_task_include_1.action == bytes_0


# Generated at 2022-06-25 05:22:07.782008
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # construct handler_task_include_obj of type class HandlerTaskInclude
    handler_task_include_obj = HandlerTaskInclude()
    assert handler_task_include_obj is not None

# Generated at 2022-06-25 05:22:12.385602
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xfa'
    str_2 = '\x0c#'
    str_3 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_0.load(str_2, str_3)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)


# Generated at 2022-06-25 05:22:18.479838
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = '{'
    int_0 = 0
    str_1 = 'RJ?\n)Q2O 3,9H3\x0c+F S'
    str_2 = '\x0ci/d\x0c'
    int_1 = -125
    handler_task_include_1 = HandlerTaskInclude.load(str_0, str_1, str_2, int_1)

# Generated at 2022-06-25 05:22:25.217441
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xfa'
    str_0 = '\x0c#'
    str_1 = 'gRnE\rOQ3n9; "Iy4D'
    int_0 = -725
    handler_task_include_0 = HandlerTaskInclude(int_0)
    handler_task_include_1 = HandlerTaskInclude(bytes_0)
    var_0 = handler_task_include_0.load(str_0, str_1)
    print("var_0 = " + str(var_0))
    print("handler_task_include_0.VALID_INCLUDE_KEYWORDS = " + str(handler_task_include_0.VALID_INCLUDE_KEYWORDS))