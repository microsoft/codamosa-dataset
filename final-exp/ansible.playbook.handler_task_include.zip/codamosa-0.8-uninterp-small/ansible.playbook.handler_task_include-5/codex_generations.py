

# Generated at 2022-06-25 05:13:50.442544
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''handler_task_include = HandlerTaskInclude()'''
    assert handler_task_include_0.name is None
    assert handler_task_include_0.free_form is None
    assert handler_task_include_0.tags is None
    assert handler_task_include_0.run_once is False
    assert handler_task_include_0.when is None
    assert handler_task_include_0.action is None
    assert handler_task_include_0.loop is None
    assert handler_task_include_0.delegate_to is None
    assert handler_task_include_0.register is None
    assert handler_task_include_0.notify is None
    assert handler_task_include_0.loop_control is None
    assert handler_task_include_0.role is None
    assert handler_

# Generated at 2022-06-25 05:13:51.563605
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:13:57.235841
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("\n\n\n\nUnit test for constructor of class HandlerTaskInclude")
    handler_task_include = HandlerTaskInclude()
    print("\nThe HandlerTaskInclude object is :" , handler_task_include)


# Generated at 2022-06-25 05:14:00.710031
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include.load

# Generated at 2022-06-25 05:14:05.394717
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti_obj = HandlerTaskInclude()
    hti_obj.load()


# Generated at 2022-06-25 05:14:08.903465
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # build a object for test
    handler_task_include = HandlerTaskInclude()

    # test attr '_valid_attrs'
    assert getattr(handler_task_include, '_valid_attrs') == {'block': None, 'listen': None}

    # test attr 'listen'
    handler_task_include.listen = ['a']
    assert handler_task_include.listen == ['a']

# Generated at 2022-06-25 05:14:09.627745
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    assert True



# Generated at 2022-06-25 05:14:16.379092
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        handler_task_include_0 = HandlerTaskInclude()
    except NameError as err:
        assert (False), "constructor() raised NameError unexpectedly!"
    else:
        pass
    try:
        handler_task_include_1 = HandlerTaskInclude(
            block=None,
            name=None,
            role=None,
            task_include=None
        )
    except NameError as err:
        assert (False), "constructor() raised NameError unexpectedly!"
    else:
        pass
    try:
        handler_task_include_2 = HandlerTaskInclude(
            block=None,
            name=None,
            role=None,
            task_include=None
        )
    except NameError as err:
        assert (False), "constructor() raised NameError unexpectedly!"

# Generated at 2022-06-25 05:14:22.043262
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler = HandlerTaskInclude.load(data=None)
    output = handler.name
    assert output == ''


# Generated at 2022-06-25 05:14:25.765570
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:30.014769
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude.load(str_0, tuple_0)

# Generated at 2022-06-25 05:14:32.972882
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = '22H|Xk&nFn'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)



# Generated at 2022-06-25 05:14:37.045612
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)


# Generated at 2022-06-25 05:14:40.967235
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_1 = 'x_Z+N0Y&C)c'
    tuple_1 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_1 = handler_task_include_1.load(str_1, tuple_1)


# Generated at 2022-06-25 05:14:44.462769
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 's?6U-vh'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(str_0, tuple_0)

# Generated at 2022-06-25 05:14:53.533509
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    dict_0 = {'&b`#': 'neApL-S=l', '@A/1': 'E)z(N*j', 'tH&p': 'Y/t>y^t$', 'x5': 'HXjp#Pm)Z', 'L3%c': 'P$h%2F[y'}
    str_1 = '`gJZO-'
    str_2 = 'l>+O'
    tuple_0 = (str_2, str_1)
    str_3 = 'JNM?|'
    str_4 = 'FJ.r'
    tuple_1 = (str_4, str_3)
    str_5 = '8>(l'

# Generated at 2022-06-25 05:14:57.880093
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    tuple_0 = (set(), False)
    str_0 = 'Qfq@N-^9X'
    dict_0 = {'UU^\\': str_0}

    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(dict_0, tuple_0)


# Generated at 2022-06-25 05:15:01.945721
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude() # TODO: what class should this be?


# Generated at 2022-06-25 05:15:08.404398
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test set up
    global str_0, tuple_0
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()

    # Test code
    var_0 = handler_task_include_0.load(str_0, tuple_0)

    # Test assertions
    assert var_0 != None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:15:11.760520
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)


# Generated at 2022-06-25 05:15:16.301558
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)


# Generated at 2022-06-25 05:15:17.628055
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        handler_task_include_0 = HandlerTaskInclude()
        assert handler_task_include_0 != None
    except:
        assert False


# Generated at 2022-06-25 05:15:21.026573
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)
    assert (var_0 is not None)


# Generated at 2022-06-25 05:15:27.801072
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    result = handler_task_include_0.load(str_0, tuple_0)
    assert result is None



# Generated at 2022-06-25 05:15:31.006941
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # str_0 = 'dYsY&F6/zB3'
    # tuple_0 = None
    # handler_task_include_0 = HandlerTaskInclude()
    # var_0 = handler_task_include_0.load(str_0, tuple_0)
    assert False


# Generated at 2022-06-25 05:15:36.383889
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("test 1 : test_HandlerTaskInclude_load")
    global handler_task_include_0
    handler_task_include_0 = HandlerTaskInclude()

    global tuple_0
    tuple_0 = None

    global str_0
    str_0 = '#'

    handler_task_include_0.load(str_0, tuple_0)

    global str_0
    str_0 = 'dYsY&F6/zB3'

    handler_task_include_0.load(str_0, tuple_0)

    global str_0
    str_0 = ''

    handler_task_include_0.load(str_0, tuple_0)



# Generated at 2022-06-25 05:15:41.899726
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Testing: constructor of class HandlerTaskInclude")
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.get_name() == None
    
    

# Generated at 2022-06-25 05:15:45.135175
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.check_options(handler_task_include_0.load_data(str_0, tuple_0), str_0)
    assert var_0 == None


# Generated at 2022-06-25 05:15:50.780428
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ansible_play_0 = HandlerTaskInclude()
    ansible_play_1 = HandlerTaskInclude()

    assert ansible_play_0 != ansible_play_1


# Generated at 2022-06-25 05:15:55.742044
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_data = 'dYsY&F6/zB3'
    test_block = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(test_data, test_block)


# Test the method __len__ of class HandlerTaskInclude

# Generated at 2022-06-25 05:16:06.849234
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'qeB:7(uX%fI'
    str_1 = 'QPx;c%z$I7='
    str_2 = 'Xrmy1/&#b%c'
    tuple_0 = None
    dict_0 = dict()
    dict_0['host'] = str_2
    dict_0['key_1'] = str_1
    dict_0['key_0'] = str_0
    HandlerTaskInclude_load(str_0, str_1, tuple_0, dict_0)


# Generated at 2022-06-25 05:16:09.169663
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = ''
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)

# Generated at 2022-06-25 05:16:20.162786
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = '$'
    list_0 = []
    dict_0 = {}
    tuple_0 = (str_0,)
    handler_task_include_0 = HandlerTaskInclude()
    ansible_py_data_0 = handler_task_include_0.load(tuple_0, dict_0, list_0)
    str_1 = 'X'
    dict_1 = ansible_py_data_0
    d_set_0 = set(dict_1)
    tuple_1 = ('f', str_1, str_1, str_1, str_0, str_1, str_1)
    tuple_2 = ('2',)
    dict_2 = ansible_py_data_0
    d_set_1 = set(dict_2)

# Generated at 2022-06-25 05:16:24.262129
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    dict_0 = dict()
    task_include_0 = TaskInclude(dict_0)
    handler_task_include_0 = HandlerTaskInclude(task_include_0)

# Generated at 2022-06-25 05:16:26.082830
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Test_HandlerTaskInclude_load")
    test_case_0()

test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:16:29.880491
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    return handler_task_include_0


# Generated at 2022-06-25 05:16:33.902866
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:16:36.671933
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    input_1 = '5n_v()|7O>8'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(input_1, tuple_0)
    assert var_0 is not None

# Generated at 2022-06-25 05:16:38.777908
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        assert hasattr(HandlerTaskInclude, 'load')
    except:
        pass


# Generated at 2022-06-25 05:16:44.178124
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = '/G'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)
    var_3 = HandlerTaskInclude.load(str_0, tuple_0)

    str_0 = 'KjY'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(str_0, tuple_0)
    var_5 = HandlerTaskInclude.load(str_0, tuple_0)


# Generated at 2022-06-25 05:16:56.090361
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True == True


# Generated at 2022-06-25 05:17:02.887802
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)
    var_0 = handler_task_include_0.check_options()
    var_0 = handler_task_include_0.get_vars()
    var_0 = handler_task_include_0.name
    var_0 = handler_task_include_0.tags
    var_0 = handler_task_include_0.when
    var_0 = handler_task_include_0.notify
    var_0 = handler_task_include_0.from_task
    var_0 = handler_task_include_0.from_play
    var

# Generated at 2022-06-25 05:17:12.796152
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude(block=var_0, role=var_0, task_include=var_0)
    str_0 = 'Module.not_a_real_one'
    int_0 = 1
    str_1 = 'connection'
    int_1 = 2000
    str_2 = 'gather_facts'
    int_2 = 1
    str_3 = 'sudo'
    int_3 = 2
    str_4 = 'sudo_user'
    str_5 = '8p9$#0o/'
    str_6 = 'sudo_pass'
    str_7 = 'Ta&Dno8*'
    str_8 = 'sudo_exe'
    list_0 = []
    str_9 = 'c%69^QK@'
    str_10

# Generated at 2022-06-25 05:17:20.991736
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    tuple_1 = None
    tuple_2 = None
    loader_0 = None
    handler_task_include_0 = HandlerTaskInclude.load(
        str_0,
        tuple_0,
        tuple_1,
        tuple_2,
        loader=loader_0
    )

# Generated at 2022-06-25 05:17:31.583323
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test basic construction
    handler_task_include_1 = HandlerTaskInclude()
    assert handler_task_include_1.loop is None
    assert handler_task_include_1.loop_args is None

    data = {
        'include': 'bar.yml'
    }

    handler_task_include_2 = HandlerTaskInclude.load(data)
    assert handler_task_include_2.includes == ['bar.yml']

    str_2 = '/mzTA/'
    handler_task_include_3 = HandlerTaskInclude.load(str_2)
    assert handler_task_include_3.includes == ['/mzTA/']

# Generated at 2022-06-25 05:17:37.660683
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    assert handler_task_include_0.load(str_0, tuple_0) != None


# Generated at 2022-06-25 05:17:41.038673
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()
    pass

# Generated at 2022-06-25 05:17:44.627728
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    (str_0, tuple_0) = ('dYsY&F6/zB3', None)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)
    assert var_0 == 'dYsY&F6/zB3'


# Generated at 2022-06-25 05:17:47.198740
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(str_0, tuple_0)

# Generated at 2022-06-25 05:17:50.990976
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

test_HandlerTaskInclude()

# Generated at 2022-06-25 05:18:18.154321
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # This test assumes that class HandlerTaskInclude has been defined.
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)
    assert var_0 is not None


# Generated at 2022-06-25 05:18:24.692163
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)


# Generated at 2022-06-25 05:18:29.360835
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_1 = 'W1as0BwV7Bg'
    tuple_1 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    var_1 = handler_task_include_1.load(str_1, tuple_1)


# Generated at 2022-06-25 05:18:29.994931
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: Fix test
    pass


# Generated at 2022-06-25 05:18:34.029231
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = None
    tuple_0 = ()
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(str_0, tuple_0)
    handler_task_include_0.load(str_0, tuple_0, variable_manager=None)


# Generated at 2022-06-25 05:18:38.037480
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.get_name() == '', 'HandlerTaskInclude constructor sets name to empty string.'
    assert handler_task_include_0.get_tasks() == [], 'HandlerTaskInclude constructor sets tasks to empty list.'


# Generated at 2022-06-25 05:18:42.909912
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.handler import Handler
    handler_0 = Handler()
    handler_task_include_0 = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler_task_include_1 = HandlerTaskInclude(block=handler_0, role=None, task_include=None)
    assert isinstance(handler_task_include_1, HandlerTaskInclude)
    assert isinstance(handler_task_include_1, Handler)


# Generated at 2022-06-25 05:18:46.368891
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'N'
    tuple_0 = HandlerTaskInclude()
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(str_0, tuple_0)


# Generated at 2022-06-25 05:18:55.881978
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    var_0 = handler_task_include_0.load(str_0, tuple_0)

    assert var_0 is not None

    str_1 = 'b5F5+jm5'
    handler_task_include_1 = HandlerTaskInclude()
    var_1 = handler_task_include_1.load(str_1, tuple_0)

    assert var_1 is not None

    str_2 = 'sMv;3qM('
    handler_task_include_2 = HandlerTaskInclude()
    var_2 = handler_task_include_2.load(str_2, tuple_0)


# Generated at 2022-06-25 05:19:01.207063
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # case 0
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 05:19:55.890599
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude(var_1, var_2)
    str_0 = 'gU6'
    tuple_0 = None
    tuple_1 = ()
    tuple_2 = (None, None)
    var_3 = handler_task_include_0.load(str_0, tuple_0)
    var_3 = handler_task_include_0.load(tuple_1)
    var_3 = handler_task_include_0.load(tuple_2)


# Generated at 2022-06-25 05:20:05.864292
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 05:20:11.109874
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Set up mock ansible environment
    host = Host()

    # Construct module instantiation arguments
    data = u''
    block = None
    role = None
    task_include = None

    # Construct expected return value
    return_value = u''

    # Instantiate and call module
    module = HandlerTaskInclude()
    result = module.load(data, block, role, task_include)

    # Verify the results
    assert result == return_value



# Generated at 2022-06-25 05:20:11.996176
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)


# Generated at 2022-06-25 05:20:14.420087
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Ensures the handler loading method does successfully execute.
    '''
    str_0 = ''
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(str_0, tuple_0)


# Generated at 2022-06-25 05:20:17.541832
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'YiLq3evzDB2'
    tuple_0 = None
    var_0 = handler_task_include_0.load(str_0, tuple_0)


# Generated at 2022-06-25 05:20:26.246695
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  str_0 = '&+ZfT0S(^N'
  tuple_0 = (),
  handler_task_include_0 = HandlerTaskInclude(str_0, tuple_0)
  str_1 = 'environment'
  tuple_1 = (),
  var_0 = handler_task_include_0.load(str_1, tuple_1)

  str_2 = 'environment'
  tuple_2 = (),
  var_1 = handler_task_include_0.load(str_2, tuple_2)

  str_3 = 'environment'
  tuple_3 = (),
  var_2 = handler_task_include_0.load(str_3, tuple_3)

# Generated at 2022-06-25 05:20:31.210674
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = '8W'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(str_0, tuple_0)

# Generated at 2022-06-25 05:20:34.821040
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = 'dYsY&F6/zB3'
    handler_task_include_0 = HandlerTaskInclude(data)
    assert isinstance(handler_task_include_0, HandlerTaskInclude)
    assert isinstance(handler_task_include_0, Handler)
    assert isinstance(handler_task_include_0, TaskInclude)

# Generated at 2022-06-25 05:20:38.018830
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'lE/!\u0006N\x00\u0002'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)



# Generated at 2022-06-25 05:22:22.039604
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        HandlerTaskInclude().load()
    except TypeError:
        print('TypeError caught: load() takes 2 positional arguments but 3 were given')
    # Test for constructor of class HandlerTaskInclude
    assert HandlerTaskInclude().__class__ is HandlerTaskInclude
    assert HandlerTaskInclude().__init__.__class__ is object.__init__
    # Test for method HandlerTaskInclude.load of class HandlerTaskInclude
    assert HandlerTaskInclude().load().__class__ is HandlerTaskInclude
    assert HandlerTaskInclude().load().__init__.__class__ is object.__init__


# Generated at 2022-06-25 05:22:24.030833
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)


# Generated at 2022-06-25 05:22:24.628045
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude() != None


# Generated at 2022-06-25 05:22:27.136222
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'dYsY&F6/zB3'
    tuple_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(str_0, tuple_0)
    return var_0


# Generated at 2022-06-25 05:22:28.319355
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)

# Generated at 2022-06-25 05:22:29.334396
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:22:36.353997
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_2 = HandlerTaskInclude('J#~qh')
    assert handler_task_include_2.block == 'J#~qh'
    assert handler_task_include_2.handler is None
    assert handler_task_include_2.play_context is None
    assert handler_task_include_2.loop is None
    assert handler_task_include_2.playbook is None
    assert handler_task_include_2.role is None
    assert handler_task_include_2.task_include is None
    assert handler_task_include_2.loader is None
    assert handler_task_include_2.variable_manager is None
    assert handler_task_include_2.only_tags is None
    assert handler_task_include_2.skip_tags is None
    assert handler_task_include

# Generated at 2022-06-25 05:22:37.138031
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-25 05:22:40.081446
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class_0 = HandlerTaskInclude()
    str_0 = 'mgrx_a-X%1{d50'
    tuple_0 = None
    tuple_1 = None
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(str_0, tuple_0, tuple_1)


# Generated at 2022-06-25 05:22:41.353572
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load()
    assert var_0 == None