

# Generated at 2022-06-25 05:13:42.611855
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    # Asserts the creation of HandlerTaskInclude instance
    assert handler_task_include is not None


# Generated at 2022-06-25 05:13:44.029059
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_1 = HandlerTaskInclude()

# Generated at 2022-06-25 05:13:46.629686
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()
    handler_task_include_3 = HandlerTaskInclude()
    handler_task_include_4 = HandlerTaskInclude()

# Generated at 2022-06-25 05:13:47.893763
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-25 05:13:52.160216
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler1 = HandlerTaskInclude()
    handler2 = HandlerTaskInclude(name='handler2')
    handler3 = HandlerTaskInclude(task=handler1)
    handler4 = HandlerTaskInclude(block=handler2)
    handler5 = HandlerTaskInclude(variable_manager=handler3)
    handler6 = HandlerTaskInclude(loader=handler4)
    handler7 = HandlerTaskInclude(block=handler5, variable_manager=handler6,
                                  loader=handler1)


if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:13:54.620825
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # handler_task_include_1 = HandlerTaskInclude.load()
    assert True


# Generated at 2022-06-25 05:13:59.537634
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    data = {'a': 'b'}
    handler = handler_task_include_1.load(
        data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert handler

# Generated at 2022-06-25 05:14:00.666476
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-25 05:14:05.148461
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:06.572744
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.load()


# Generated at 2022-06-25 05:14:12.718015
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # unit test for load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = ''
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)


# Generated at 2022-06-25 05:14:14.224786
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None


# Generated at 2022-06-25 05:14:19.705172
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    c_str_0 = 'e.*%'
    c_list_0 = ['a']
    c_str_1 = ';!ViLl'
    handler_task_include_0 = HandlerTaskInclude()
    int_0 = random.randint(0, 9)
    str_0 = 'bx!.{YA-U$O_h'
    list_0 = ['z']
    c_str_2 = 'Csnx#'
    tuple_0 = (list_0, c_list_0)
    str_1 = 'a;<\x14N!_o}V'
    var_0 = handler_task_include_0.load(c_str_0, str_0, tuple_0)
    int_1 = random.randint(0, 9)
    var_1 = handler

# Generated at 2022-06-25 05:14:23.259768
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  handler_task_include_0 = HandlerTaskInclude()
  assert type(handler_task_include_0) == HandlerTaskInclude


# Generated at 2022-06-25 05:14:28.451961
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'y1*'
    tuple_0 = ()
    handler_task_include_0.load(str_0, str_0, tuple_0)
    print(tuple_0)
    print(':::')


# Generated at 2022-06-25 05:14:39.776057
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'j.TT,4'
    tuple_0 = ()
    handler_task_include_1 = handler_task_include_0.load(str_0, str_0, tuple_0)
    handler_task_include_2 = HandlerTaskInclude()
    str_1 = 'j.TT,4'
    tuple_1 = ()
    handler_task_include_3 = handler_task_include_2.load(str_1, str_1, tuple_1)
    handler_task_include_4 = HandlerTaskInclude()
    str_2 = 'j.TT,4'
    tuple_2 = ()

# Generated at 2022-06-25 05:14:45.212364
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Initialize test_case_0
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'j.TT,4'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)
    # Not sure how to check the output of this. Need to check for an attribute.


# Generated at 2022-06-25 05:14:54.259930
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # handler_task_include_0 = HandlerTaskInclude()
    # str_0 = 'w'
    # str_1 = 'b/C'
    # tuple_0 = ()
    # tuple_1 = (str_0, str_1)
    # var_0 = handler_task_include_0.load(str_0, str_0, tuple_1)
    #
    # print(var_0)

    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'm,t'
    str_1 = ''
    tuple_0 = ()
    tuple_1 = (str_0, str_1)
    var_0 = handler_task_include_0.load(str_0, str_1, tuple_1)

# Generated at 2022-06-25 05:14:57.092136
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'J.TT,4'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)

# Generated at 2022-06-25 05:15:05.176797
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    str_1 = 'j.TT,4'
    tuple_1 = ()
    var_1 = handler_task_include_1.load(str_1, str_1, tuple_1, str_1, str_1)

if __name__ == "__main__":
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:15:11.663568
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    str_1 = 'f,0'
    tuple_1 = ()
    handler_task_include_1.load(str_1, str_1, tuple_1)

    assert handler_task_include_1.action in ['include']


# Generated at 2022-06-25 05:15:16.646526
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("TestHandlerTaskInclude.test_HandlerTaskInclude_load()")
    # init data
    data = {
        'action': 'set_fact',
        'args': {
            'key': 'value'
        }
    }
    # init class object
    handler_task_include = HandlerTaskInclude()
    # load data
    handler = handler_task_include.load(data, data)
    # check result
    assert handler == data, 'unit test failed!'



# Generated at 2022-06-25 05:15:26.252864
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'a.TEST,6'
    str_1 = 'a.TEST,6'
    str_2 = '/home/admin/test_scenarios/test_case_5/tasks/main.yml'
    str_3 = '/home/admin/test_scenarios/test_case_5/handler_task.yml'
    str_4 = '/home/admin/test_scenarios/test_case_5/role/a.TEST/tasks/main.yml'
    str_5 = '/home/admin/test_scenarios/test_case_5/role/b.TEST/tasks/main.yml'

# Generated at 2022-06-25 05:15:29.715679
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'nginx_handler'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)


# Generated at 2022-06-25 05:15:31.766174
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'j.TT,4'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)
    assert (var_0 == False)


# Generated at 2022-06-25 05:15:34.004211
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        str_0 = 'v.3q'
        tuple_0 = ()
        handler_task_include_0 = HandlerTaskInclude(str_0, str_0, tuple_0)
    except Exception:
        print("Exception when calling constructor for HandlerTaskInclude")
        raise


# Generated at 2022-06-25 05:15:34.772832
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-25 05:15:45.743840
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert sorted(handler_task_include_0.include_keywords) == sorted(["include", "import_playbook", "include_role", "import_tasks"])

    str_0 = 'A.A'
    str_1 = 'L.L'
    str_2 = 'B.B'
    str_3 = 'i.T'
    str_4 = 'j.TT,4'
    str_5 = 'j.T'
    str_6 = 'C.C'
    str_7 = 'j.T,U'
    tuple_0 = ()
    tuple_1 = ('L.L',)
    handler_task_include_1 = HandlerTaskInclude(block=str_7, role=tuple_0)
    handler_

# Generated at 2022-06-25 05:15:49.412051
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:15:57.046956
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'j.TT,4'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)
    var_1 = handler_task_include_0.load(str_0, str_0, tuple_0)
    var_2 = handler_task_include_0.load(str_0, str_0, tuple_0)
    var_3 = handler_task_include_0.load(str_0, str_0, tuple_0)

# Generated at 2022-06-25 05:16:03.456435
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'j.TT,4'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)



# Generated at 2022-06-25 05:16:08.959906
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        handler_task_include_0 = HandlerTaskInclude()
        str_0 = 'k.HH,5'
        tuple_0 = ()
        handler_task_include_0.load(str_0, str_0, tuple_0)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 05:16:19.874443
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()
    str_0 = 'j.TT,4'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)
    str_0 = 'r.7'
    tuple_0 = ()
    var_0 = handler_task_include_1.load(str_0, str_0, tuple_0)
    str_0 = 't.tt'
    tuple_0 = ()
    var_1 = handler_task_include_2.load(str_0, str_0, tuple_0)

# Generated at 2022-06-25 05:16:24.687072
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'j.TT,4'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)

# Generated at 2022-06-25 05:16:27.395689
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'J.TT,4'
    tuple_0 = ()
    handler_task_include_0.load(str_0, str_0, tuple_0)

# Generated at 2022-06-25 05:16:29.802971
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:16:34.078940
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    data_0 = 'j.TT,4'
    block_0 = 'j.TT,4'
    role_0 = ()
    variable_manager_0 = None
    loader_0 = None
    var_0 = handler_task_include.load(data_0, block_0, role_0, variable_manager=variable_manager_0, loader=loader_0)

# Generated at 2022-06-25 05:16:36.795954
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'j.TT,4'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)


# Generated at 2022-06-25 05:16:43.897129
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h0 = HandlerTaskInclude()
    h0._role = None
    h0._block = None
    h0._task_include = None

    h1 = HandlerTaskInclude()
    h1._role = None
    h1._block = None
    h1._task_include = None

    h2 = HandlerTaskInclude()
    h2._role = None
    h2._block = None
    h2._task_include = None

    h3 = HandlerTaskInclude()
    h3._role = None
    h3._block = None
    h3._task_include = None

    h4 = HandlerTaskInclude()
    h4._role = None
    h4._block = None
    h4._task_include = None

    h5 = HandlerTaskInclude()
    h5._role = None
   

# Generated at 2022-06-25 05:16:50.096022
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = 'j.TT,4'
    tuple_0 = ()
    var_0 = handler_task_include_0.load(str_0, str_0, tuple_0)
    s = './test/files/test_playbook_include.yml'
    handler_task_include_0.load(s, s)
    s = './test/files/test_playbook_include.j2'
    handler_task_include_0.load(s, s)