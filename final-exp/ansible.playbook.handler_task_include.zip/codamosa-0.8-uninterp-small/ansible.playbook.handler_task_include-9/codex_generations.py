

# Generated at 2022-06-25 05:13:50.285988
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-25 05:13:51.130604
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:13:54.477161
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_1 = HandlerTaskInclude()
    print(dir(handler_task_include_1))


# Generated at 2022-06-25 05:14:01.677048
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    data = [
        {
            'handlers': {
                'list_of_templates': {
                    'files': [
                        '{{ item }}'
                    ],
                    'with_items': [
                        'hosts.j2',
                        'services.j2',
                        'aliases.j2'
                    ]
                }
            }
        }
    ]
    variable_manager = Mock()
    loader = Mock()
    handler_task_include_0.load(data, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 05:14:03.765272
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    print(handler_task_include_0.load())


# Generated at 2022-06-25 05:14:04.893746
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test load
    """

    t = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:07.209491
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude.load()
    handler_task_include_1 = HandlerTaskInclude.load()

# Generated at 2022-06-25 05:14:11.395503
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
# test_case_0()


if __name__ == '__main__':
    import  pytest
    pytest.main()

# Generated at 2022-06-25 05:14:18.245446
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.task_include is None
    assert handler_task_include_0.block is None
    assert handler_task_include_0.role is None

# Generated at 2022-06-25 05:14:25.102419
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()

    assert handler_task_include_0.__class__.__name__ == 'HandlerTaskInclude'


# Walk-through the code
handler_task_include_0 = HandlerTaskInclude()
handler_task_include_0.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-25 05:14:29.417649
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.load()



# Generated at 2022-06-25 05:14:31.834552
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.load('test_data') == 'test_data'

# Generated at 2022-06-25 05:14:36.567175
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include_obj = HandlerTaskInclude()
    print('\n===== HandlerTaskInclude::test_HandlerTaskInclude:: START =====')
    print('\n\n===== HandlerTaskInclude::test_HandlerTaskInclude:: END =====')



# Generated at 2022-06-25 05:14:38.951438
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(data='', block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-25 05:14:40.288192
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    return handler_task_include_0.block

# Generated at 2022-06-25 05:14:42.653212
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = handler_task_include_0.load({})


# Generated at 2022-06-25 05:14:44.262251
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_1 = HandlerTaskInclude()
    task_include_1 = TaskInclude()
    data = '''
    - name: test
    include: task.yml
    '''
    task_include_1.load(data)
    handler_task_include_1.load(data)

# Generated at 2022-06-25 05:14:45.575733
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_load_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:47.796193
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert type(handler_task_include_0) == HandlerTaskInclude


# Generated at 2022-06-25 05:14:50.768346
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert(isinstance(handler_task_include_0, HandlerTaskInclude))


# Generated at 2022-06-25 05:14:56.407631
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:15:06.802527
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """Constructor test"""
    handler_task_include_0 = HandlerTaskInclude()
    assert not hasattr(handler_task_include_0, 'block')
    assert not hasattr(handler_task_include_0, 'role')
    assert not hasattr(handler_task_include_0, 'task_include')
    assert not hasattr(handler_task_include_0, 'tags')
    assert not hasattr(handler_task_include_0, 'when')
    assert not hasattr(handler_task_include_0, 'environment')
    assert not hasattr(handler_task_include_0, 'only_if')
    assert not hasattr(handler_task_include_0, 'not_if')
    assert not hasattr(handler_task_include_0, 'first_available_file')
    assert not hasattr

# Generated at 2022-06-25 05:15:15.662959
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    try:
        handler_task_include_1.load()
        assert False
    except:
        assert True
    try:
        handler_task_include_1.load(None)
        assert False
    except:
        assert True
    try:
        handler_task_include_1.load(None, None)
        assert False
    except:
        assert True
    try:
        handler_task_include_1.load(None, None, None)
        assert False
    except:
        assert True
    try:
        handler_task_include_1.load(None, None, None, None)
        assert False
    except:
        assert True

# Generated at 2022-06-25 05:15:16.224967
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

# Generated at 2022-06-25 05:15:17.889664
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    print(handler_task_include == None)
    assert(handler_task_include != None)


# Generated at 2022-06-25 05:15:24.583049
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print()
    # Test with good config
    print("Test with good config:")

# Generated at 2022-06-25 05:15:27.533518
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # handler_task_include_0 = HandlerTaskInclude()
    # handler_task_include_0.load()
    pass

test_case_0()
test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:15:31.799845
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    handler_task_include.status = "new"

    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'_raw_params', '_params', 'block', 'block_var', 'dynamic', 'ignore_errors', 'loop', 'loop_control', 'loop_with_items', 'name', 'tags', 'task', 'vars', 'when'}

# Generated at 2022-06-25 05:15:33.675271
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # handler_task_include_1 = HandlerTaskInclude()
    # handler_task_include_1.load()
    pass


# Generated at 2022-06-25 05:15:44.565706
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Check 1: load_data, load
    handler_include_0 = None
    handler_include_0 = HandlerTaskInclude.load({
        'include': 'foo.yml'
    })
    assert handler_include_0.task_include.filename == 'foo.yml'

    # Check 2: load_data, load
    handler_include_1 = None
    handler_include_1 = HandlerTaskInclude.load({
        'include': 'foo.yml',
        'with_items': ['bar1', 'bar2']
    })
    assert handler_include_1.task_include.with_items == ['bar1', 'bar2']

    # Check 3: load_data, load
    handler_include_2 = None

# Generated at 2022-06-25 05:16:00.220842
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\x0f\xfd\x15\x0e\x0c\x8a\xed\x1f\xa9\x1b\xe2\xcd\xdb\x18\xe8\x8f'
    bytes_1 = b'\x03\x1a\xe3\x84\xa3c\xe0\xe8\x1e\xf2\xa1\x99\x8a\x0c+\xab\xaa'
    bytes_2 = b'\xa7\xfd\x8b\x86\xac\x10\xf1\x8f\x9b\x18\xdb\xe4\xcb\xf1\x1f\xab'

# Generated at 2022-06-25 05:16:01.684431
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # given
    # when
    # then
    result = 1
    assert result == 1

# Generated at 2022-06-25 05:16:09.027222
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Testing method load of class HandlerTaskInclude...')
    # Test case 0
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)
    print('Test case 0: ', end='')
    try:
        assert var_0.backup_name == '.~\x1a\xdd(\xed\xdb\xc0\xd3!.bak'
    except AssertionError:
        print('assert var_0.backup_name == ".~\\x1a\\xdd(\\xed\\xdb\\xc0\\xd3!.bak" failed')

# Generated at 2022-06-25 05:16:14.074254
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    test case for HandlerTaskInclude class load
    """

    test_case_0()

if __name__ == "__main__":
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:16:19.429168
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  handler_task_include_0 = HandlerTaskInclude(None)
  bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
  assert True == handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:16:23.680299
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-25 05:16:27.473799
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    handler_task_include_0.load(bytes_0)


# Generated at 2022-06-25 05:16:29.804331
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass



# Generated at 2022-06-25 05:16:36.872501
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'--\xbf\x14\xba\xa9\xfb\xf6\xee\xfb'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)
    print(var_0)
    bool_0 = True
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)
    print(var_0)
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_0 = False

# Generated at 2022-06-25 05:16:42.438753
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    list_0 = []
    var_0 = handler_task_include_0.load(list_0)

# Generated at 2022-06-25 05:16:58.436364
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xce@-\xfe\x94\xebd\x93'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)


# Generated at 2022-06-25 05:17:02.932526
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0._load_tasks() is None
    str_0 = 'listen'
    bytes_0 = b'\t,\x90\x01\x8d\x87\xf1\xca\x9f\xc1\xad\xd2\x80q\x03\x8e\x84\xaf\xba\xb9\x8b'
    assert handler_task_include_0.load(bytes_0, str_0) is None

# Generated at 2022-06-25 05:17:04.609370
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:17:07.831060
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b']\xa0\x00\x00'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    # ValueError raised on error
    handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:17:09.815840
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # assert that load() returns a HandlerTaskInclude object
    assert isinstance(test_case_0(), HandlerTaskInclude)


# Generated at 2022-06-25 05:17:12.432623
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:17:19.948266
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'

    handler_task_include_0 = HandlerTaskInclude(False)
    var_0 = handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:17:27.897721
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        HandlerTaskInclude.load()
        raise Exception('Test failed.')
    except Exception as e:
        print(str(e))
        # AssertionError
        print(str(e.__class__))
        assert str(e.__class__) == "<class 'TypeError'>"

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:17:28.893576
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:17:34.465239
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)
    assert var_0 == handler_task_include_0
    handler_task_include_0.check_name(bytes_0)

# Generated at 2022-06-25 05:18:00.644638
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #assert HandlerTaskInclude.__doc__ == doc str of HandlerTaskInclude
    assert HandlerTaskInclude.__doc__ == "Creates a list of tasks to be run sequentially."

    # self.task_include = TaskInclude()

    #assert self.load == instance method of HandlerTaskInclude
    #assert HandlerTaskInclude.load == class method of HandlerTaskInclude


# Generated at 2022-06-25 05:18:07.283862
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:18:11.966815
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test case for load method of HandlerTaskInclude.
    """

    # Test case for method load
    # Test case for method load of class HandlerTaskInclude

# Generated at 2022-06-25 05:18:18.582025
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('\n\nExecuting test case - HandlerTaskInclude_load():\n')
    bytes_0 = b'\x1b'
    bool_0 = True
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    string_0 = handler_task_include_0.load(bytes_0)
    string_1 = '\x1b'
    assert string_0 == string_1
    print('Test case passed')


# Generated at 2022-06-25 05:18:24.817990
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(b'~\x1a\xdd(\xed\xdb\xc0\xd3!')


# Generated at 2022-06-25 05:18:30.053655
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b"8"
    bool_0 = True
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    # Load dict parameter into HandlerTaskInclude object
    handler_task_include_0.load(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:18:34.061495
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    byte_0 = b'\xad\x8b\x15\xfd\x1c\x81\x9f\xea\x09'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    handler_task_include_0.load(byte_0)

# Generated at 2022-06-25 05:18:36.524847
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_handler = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_handler = False
    handler_task_include = HandlerTaskInclude(bool_handler)
    var = handler_task_include.load(bytes_handler)


# Generated at 2022-06-25 05:18:39.787943
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    if b'exclude\r' is True:
        bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
        bool_0 = False
        handler_task_include_0 = HandlerTaskInclude(bool_0)
        var_0 = handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:18:41.607090
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude(False)
    assert isinstance(handler_task_include_0, HandlerTaskInclude)


# Generated at 2022-06-25 05:19:27.959823
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == frozenset({'tags', 'listen', 'listen_once', 'name', 'connection', 'serial', 'any_errors_fatal', 'delegate_to', 'first_available_file', 'vars', 'block', 'tasks', 'when', 'environment', 'ignore_errors', 'become', 'become_method', 'become_user', 'register', 'with_items', 'loop_control', 'until', 'notify', 'delay', 'local_action', 'transport'})

# Generated at 2022-06-25 05:19:29.988867
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude(False)
    assert isinstance(handler_task_include_0, HandlerTaskInclude)


# Generated at 2022-06-25 05:19:33.145933
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("\nTesting HandlerTaskInclude.load")
    test_case_0()

# Generated at 2022-06-25 05:19:39.668611
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data_0 = b'"P\xcd\x9d\xc9\n\x0c\x06"'
    block_0 = None
    role_0 = None
    task_include_0 = None
    variable_manager_0 = None
    loader_0 = None
    handler_task_include_0 = HandlerTaskInclude.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)

    assert handler_task_include_0 != None



# Generated at 2022-06-25 05:19:42.972208
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:19:51.926105
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    bool_0 = False
    dict_0 = dict()
    dict_1 = dict()
    byte_0 = bytes()
    byte_1 = bytes()
    byte_2 = bytes()
    byte_3 = bytes()
    byte_4 = bytes()
    byte_5 = bytes()
    byte_6 = bytes()
    byte_7 = bytes()
    byte_8 = bytes()
    int_0 = 0
    dict_0['action'] = 'notify'
    dict_0['name'] = 'restart_haproxy'
    list_0 = list()
    dict_1['action'] = '/etc/init.d/haproxy reload'
    dict_2 = dict()
    dict_1['name'] = 'restart command'
    dict_

# Generated at 2022-06-25 05:19:58.586506
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)
    assert var_0 == None


# Generated at 2022-06-25 05:20:05.203043
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:20:05.856043
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert hasattr(HandlerTaskInclude, 'load')

# Generated at 2022-06-25 05:20:06.639612
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = bool
    handler_task_include_0 = HandlerTaskInclude(bool_0)

# Generated at 2022-06-25 05:21:35.225327
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = True
    handler_task_include_0 = HandlerTaskInclude(t)
    assert isinstance(handler_task_include_0, HandlerTaskInclude) is True


# Generated at 2022-06-25 05:21:37.960713
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b"\x8b\x03\xb7\x0e\xa0\x98W\xae\x0b\x04\x8e\xae\x0f"
    handler_task_include_0 = HandlerTaskInclude(False)
    var_0 = handler_task_include_0.load(bytes_0)


# Generated at 2022-06-25 05:21:39.041611
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0() # TODO:


# Generated at 2022-06-25 05:21:44.223881
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    if handler_task_include_0.load() != None:
        raise Exception('Failed to assert that HandlerTaskInclude.load() has the expected return value.')
    if handler_task_include_0.load() != None:
        raise Exception('Failed to assert that HandlerTaskInclude.load() has the expected return value.')


# Generated at 2022-06-25 05:21:51.169984
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'~\x1a\xdd(\xed\xdb\xc0\xd3!'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)

if __name__ == '__main__':
    test_HandlerTaskInclude()
    print('TEST OK')

# Generated at 2022-06-25 05:21:52.393214
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)


# Generated at 2022-06-25 05:21:55.210871
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\x15\x92\xc7\x19\xd5\xccL\xd3\xed\x8d'
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    var_0 = handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:22:04.637265
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    int_0 = 1
    bool_0 = True
    bool_1 = False
    handler_task_include_0 = HandlerTaskInclude(int_0, bool_0, bool_1)
    handler_task_include_0.check_options(bytes_0)
    handler_task_include_0.check_types(bytes_0)
    handler_task_include_0.check_vars(bytes_0)
    handler_task_include_0.load_data(bytes_0)
    handler_task_include_0.load(bytes_0)

# Generated at 2022-06-25 05:22:06.376624
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    result = False
    HandlerTaskInclude(result)
    assert True


# Generated at 2022-06-25 05:22:14.789858
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase