

# Generated at 2022-06-25 05:13:42.284656
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()



# Generated at 2022-06-25 05:13:44.654150
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None, 'HandlerTaskInclude object is not instantiated'

# Generated at 2022-06-25 05:13:46.140075
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.load(None, None, None, None) is None


# Generated at 2022-06-25 05:13:48.721155
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = handler_task_include_0.load()


# Generated at 2022-06-25 05:13:49.072267
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	pass

# Generated at 2022-06-25 05:13:49.706836
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_load_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:13:53.488320
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert isinstance(HandlerTaskInclude.load(data={}, block=None, role=None, task_include=None, variable_manager=None, loader=None), HandlerTaskInclude)
    # assert isinstance(HandlerTaskInclude.load(data={}, block=None, role=None, task_include=None, variable_manager=None, loader=None), dict)
    assert isinstance(HandlerTaskInclude.load(data={'anykey': 'anyvalue'}, block=None, role=None, task_include=None, variable_manager=None, loader=None), HandlerTaskInclude)
    # assert isinstance(HandlerTaskInclude.load(data={'anykey': 'anyvalue'}, block=None, role=None, task_include=None, variable_manager=None, loader=None), dict)

# Generated at 2022-06-25 05:13:58.711839
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    try:
        result = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    except TypeError:
        result = False
    assert result == True

# Generated at 2022-06-25 05:14:01.562887
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load()


# Generated at 2022-06-25 05:14:06.697763
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude.load(data='', block='', role='', task_include='', variable_manager='', loader='')
    assert handler_task_include_1.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-25 05:14:09.654411
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    int_0 = -9
    str_0 = 'task'
    bool_1 = True
    list_0 = None
    float_0 = -226.35259
    handler_task_include_0 = HandlerTaskInclude(bool_0, int_0, str_0, bool_1, list_0)


# Generated at 2022-06-25 05:14:12.663977
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    list_0 = None
    float_0 = -3297.2263
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:14:15.660625
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = True
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = handler_task_include_0.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-25 05:14:19.362581
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    inp = {
        'block': None,
        'role': None,
        'task_include': None,
        'variable_manager': None,
        'loader': None
    }
    out = HandlerTaskInclude.load(**inp)
    assert out

# Generated at 2022-06-25 05:14:25.643468
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0 = HandlerTaskInclude(bool_0, list_0, float_0)
    assert isinstance(handler_task_include_0, HandlerTaskInclude)


# Generated at 2022-06-25 05:14:30.186077
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    if not type(handler_task_include_0.load(bool_0, list_0, float_0)) is HandlerTaskInclude:
        raise Exception('Unexpected return value from HandlerTaskInclude.load(' + str(bool_0) + ', ' + str(list_0) + ', ' + str(float_0) + ')')

# Generated at 2022-06-25 05:14:31.916046
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    list_0 = None
    float_0 = -1046.569
    handler_task_include_0 = HandlerTaskInclude(bool_0, list_0, float_0)

# Generated at 2022-06-25 05:14:37.476334
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    list_0 = None
    float_0 = -817.3
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)
    # assert False, ("Expected exception to be raised")


# Generated at 2022-06-25 05:14:47.391152
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # No exception raised.
    try:
        # Expected return values
        expected_result = "Expected result"

        # Expected Parameter Values
        bool_0 = False
        list_0 = None
        float_0 = -1145.349

        # Calling method
        handler_task_include_0 = HandlerTaskInclude()
        handler_task_include_1 = handler_task_include_0.load(bool_0, list_0, float_0)
    except Exception as e:
        # Exception occurred, unexpected result
        raise AssertionError("No exception should be thrown, got {0}".format(e))
    else:
        # Check if the method returned the correct result
        assert_equals(handler_task_include_1, expected_result)



# Generated at 2022-06-25 05:14:52.073036
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0 = HandlerTaskInclude(bool_0, list_0, float_0, bool_0)


# Generated at 2022-06-25 05:15:01.394808
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # First, call .load() with a single argument...
    #    def load(self, data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
    # test_case_0
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)
    # test_case_1
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:15:07.671690
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    str_0 = handler_task_include_0.load(bool_0, list_0, float_0)
    assert (str_0 == '_')

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:15:09.701247
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None


# Generated at 2022-06-25 05:15:17.077466
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # assert 0, "Require more tests"
    # First we create an instance of the class we want to test
    handler_task_include = HandlerTaskInclude()

    # Then create the assert methods to test different cases
    def test_case_0():
        bool_0 = False
        list_0 = None
        float_0 = -1145.349
        var_0 = handler_task_include.load(bool_0, list_0, float_0)
    # Add as many tests as you want
    def test_case_123():
        assert var_0 == list_0
    # finally call all tests
    test_case_0()
    test_case_123()

# Generated at 2022-06-25 05:15:21.663440
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    list_0 = []
    float_0 = -10.0
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:15:26.441314
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.load(None) is None


# Generated at 2022-06-25 05:15:30.489170
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)


if __name__ == '__main__':
    pass

# Generated at 2022-06-25 05:15:33.216440
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:15:36.051951
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)

# Generated at 2022-06-25 05:15:43.205914
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Setup
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()

    # Invocation
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)

    # Verification
    assert var_0 == None

# Generated at 2022-06-25 05:15:48.734555
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True == True

# Generated at 2022-06-25 05:15:53.217166
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)

# Generated at 2022-06-25 05:15:56.487146
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

# Generated at 2022-06-25 05:15:57.537931
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        test_case_0()
    except Exception as e:
        print("Exception from test case:", e)

# vi: sts=4 sw=4 et

# Generated at 2022-06-25 05:16:01.666183
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_1 = True
    handler_task_include_0 = HandlerTaskInclude()

    test_case_0()

# Generated at 2022-06-25 05:16:05.059500
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:16:09.204160
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data_0 = HandlerTaskInclude()
    block_0 = None
    role_0 = None
    task_include_0 = None
    variable_manager_0 = None
    loader_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:16:20.162280
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # print('test_HandlerTaskInclude')
    bool_0 = None
    list_0 = None
    float_0 = 1607.3
    handler_task_include_0 = HandlerTaskInclude(bool_0, list_0, float_0)
    bool_1 = 0
    list_1 = None
    float_1 = 1629.0
    handler_task_include_1 = HandlerTaskInclude(bool_1, list_1, float_1)
    bool_2 = 0
    list_2 = None
    float_2 = -3896.19
    handler_task_include_2 = HandlerTaskInclude(bool_2, list_2, float_2)
    float_3 = -124.76
    bool_3 = 0
    list_3 = None

# Generated at 2022-06-25 05:16:23.680841
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    dict_0 = dict()
    handler_0 = HandlerTaskInclude(False, dict_0)


# Generated at 2022-06-25 05:16:26.958064
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)



# Generated at 2022-06-25 05:16:39.320548
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    list_0 = None
    float_0 = -9961.36
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:16:40.324449
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349


# Generated at 2022-06-25 05:16:44.152449
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)
    assert True


# Generated at 2022-06-25 05:16:51.353015
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()

    assert(handler_task_include_0.load(bool_0, list_0, float_0).__dict__ == handler_task_include_0.__dict__)


# Generated at 2022-06-25 05:16:55.789351
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:17:00.663977
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Params for test
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    # Create instances of HandlerTaskInclude
    handler_task_include_0 = HandlerTaskInclude()
    # Run method load
    handler_task_include_0.load(bool_0, list_0, float_0)

# Generated at 2022-06-25 05:17:04.636164
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_1 = None
    float_1 = -1126.42
    handler_task_include_1 = HandlerTaskInclude()
    ansible_type_1 = {'boolean': True, 'list': [], 'float': 220.331}
    ansible_type_0 = handler_task_include_1.load(ansible_type_1, list_1, float_1)

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:17:07.865819
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)

# Generated at 2022-06-25 05:17:12.424362
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:17:18.839010
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # these will raise exceptions if the attributes do not exist
    has_attribute(HandlerTaskInclude, "handler")
    has_attribute(HandlerTaskInclude, "handler_blocks")

# Generated at 2022-06-25 05:17:44.260404
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Test: load of class HandlerTaskInclude")
    handler_task_include_0 = HandlerTaskInclude()
    # assert handler_task_include_0.load("opt_0", "opt_1", "opt_2")
    # print("Pass: load of class HandlerTaskInclude")


# Generated at 2022-06-25 05:17:46.431272
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Call test_case_0
    test_case_0()
    pass


# Generated at 2022-06-25 05:17:57.530529
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)
    if var_0.name != "listen":
        print('FAIL, var_0.name should be "listen", but is :  '+var_0.name)
    bool_0 = False
    str_0 = "handler.yml"
    str_1 = "FAKELISTEN"
    handler_task_include_1 = HandlerTaskInclude()
    with pytest.raises(AssertionError):
        handler_task_include_1.check_options(bool_0, str_0, str_1)



# Generated at 2022-06-25 05:18:05.557049
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    dict_0 = dict()
    dict_0['key_0'] = 'value_0'
    dict_0['key_1'] = 'value_1'
    dict_0['key_2'] = 'value_2'
    dict_0['key_3'] = 'value_3'
    dict_0['key_4'] = 'value_4'
    dict_0['key_5'] = 'value_5'
    dict_0['key_6'] = 'value_6'
    dict_0['key_7'] = 'value_7'
    dict_0['key_8'] = 'value_8'
    dict_0['key_9'] = 'value_9'
    dict_0['key_10'] = 'value_10'


# Generated at 2022-06-25 05:18:10.147242
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: Implement unit test for method load of class HandlerTaskInclude
    raise NotImplementedError


# Generated at 2022-06-25 05:18:10.925326
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-25 05:18:16.804385
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)
    assert var_0.name == 'include'

# Generated at 2022-06-25 05:18:19.985651
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    # Ensure __init__
    assert handler_task_include_0 is not None



# Generated at 2022-06-25 05:18:30.362505
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude(
    )

# Generated at 2022-06-25 05:18:31.086239
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:19:11.994027
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = None
    handler_task_include_0 = HandlerTaskInclude(list_0)
    handler_task_include_0.check_options()

# Generated at 2022-06-25 05:19:17.726216
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    list_0 = None
    float_0 = 7.4795
    handler_task_include_0 = HandlerTaskInclude(bool_0, list_0, float_0)

# Generated at 2022-06-25 05:19:22.781553
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = 0
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    assert getattr(handler_task_include_0, '_task_blocks') is not None

    bool_0 = 0
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:19:25.587547
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:19:29.176676
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Arrange
    bool_0 = False
    list_0 = None
    float_0 = -1145.349

    # Act
    handler_task_include_0 = HandlerTaskInclude()

    # Assert
    result = handler_task_include_0.load(bool_0, list_0, float_0)
    assert result is not None

# Generated at 2022-06-25 05:19:32.537857
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-25 05:19:34.829268
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    list_0 = None
    float_0 = -963.43
    handler_task_include_0 = HandlerTaskInclude(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:19:37.465045
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load()
# ------------------------------------------------------------------------------


# ------------------------------------------------------------------------------

# Generated at 2022-06-25 05:19:41.967309
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # test default parameter values with assert statements
    bool_0 = True
    list_0 = [1, 2, 3, 4, 5]
    float_0 = 1.0
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)
    assert var_0 is None

# Generated at 2022-06-25 05:19:48.156060
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    list_0 = False
    float_0 = -1.855
    str_0 = None
    handler_task_include_0 = HandlerTaskInclude()
    assert isinstance(handler_task_include_0, HandlerTaskInclude)

    handler_task_include_0.load(bool_0, list_0, float_0, str_0)


# Generated at 2022-06-25 05:21:11.758805
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(bool_0, list_0, float_0)

# Generated at 2022-06-25 05:21:13.608925
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # TODO: Implement a full test for this class
    pass


# Generated at 2022-06-25 05:21:17.189271
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # This testcase will check if class HandlerTaskInclude loads properly
    assert True == True, 'Testcase failed : Class HandlerTaskInclude did not load'
#test_HandlerTaskInclude_load

# Local Variables:
# compile-command: "pytest -v"
# End:

# Generated at 2022-06-25 05:21:23.730152
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Clone of test_case_0
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)

    bool_1 = True
    list_1 = 'This is a test.'
    float_1 = -200.205
    handler_task_include_1 = HandlerTaskInclude()
    var_1 = handler_task_include_1.load(bool_1, list_1, float_1)

    bool_2 = True
    list_2 = 'This is a test.'
    float_2 = -200.205
    handler_task_include_2 = HandlerTaskInclude()

# Generated at 2022-06-25 05:21:27.588962
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    if handler_task_include_0.load(True) is not None:
        raise Exception('Failed to assert handler_task_include_0.load(True) is None')

# Generated at 2022-06-25 05:21:32.544907
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("test_case_0")
    test_case_0()

# Run test funcs
test_HandlerTaskInclude()

# Generated at 2022-06-25 05:21:35.379694
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:21:37.880549
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)


# Generated at 2022-06-25 05:21:41.323183
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:21:45.299166
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    list_0 = None
    float_0 = -1145.349
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(bool_0, list_0, float_0)
    assert var_0.listen  == false