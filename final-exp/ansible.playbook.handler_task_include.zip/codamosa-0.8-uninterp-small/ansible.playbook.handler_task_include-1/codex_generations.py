

# Generated at 2022-06-25 05:13:43.833486
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()
    handler_task_include_2.load(HandlerTaskInclude.load)


# Generated at 2022-06-25 05:13:44.953737
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:13:46.871277
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    
    handler_task_include = HandlerTaskInclude()

    assert handler_task_include is not None, 'Unable to create an instance of class HandlerTaskInclude'
    assert isinstance(handler_task_include, HandlerTaskInclude), 'Object is not of type HandlerTaskInclude'

# Generated at 2022-06-25 05:13:49.946727
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 05:14:00.823509
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    list_0 = ['foo']
    str_0 = 'listen: foo'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['ansible_ssh_port'] = 22
    dict_1['ansible_ssh_host'] = '10.0.0.1'
    dict_0['inventory_hostname'] = 'host1'
    dict_1['inventory_hostname'] = 'host2'
    list_1 = ['foo']
    list_0.append(dict_1)
    list_1.append(dict_0)
    handler_task_include_0.load(list_1, str_0, list_0, dict_1, dict_0, list_0)


# Generated at 2022-06-25 05:14:05.891500
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #print('\n\n##\n## Unit tests for HandlerTaskInclude.\n##')
    print('\n\n## Please implement me!')
    test_case_0()

# Generated at 2022-06-25 05:14:15.295160
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    try:
        handler_task_include_0.load()
    except:
        pass
    handler_task_include_0 = HandlerTaskInclude()
    try:
        handler_task_include_0.load(name='sometask')
    except:
        pass
    handler_task_include_0 = HandlerTaskInclude()
    try:
        handler_task_include_0.name = 'sometask'
        handler_task_include_0.load(name='sometask')
    except:
        pass
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:23.554209
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-25 05:14:28.729933
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    variable_manager = None
    handler_task_include = HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert isinstance(handler_task_include, HandlerTaskInclude)

# Generated at 2022-06-25 05:14:30.094673
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:33.865390
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:36.695523
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'block', 'free_form', 'listen', 'role'}



# Generated at 2022-06-25 05:14:38.310068
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude.load()


# Generated at 2022-06-25 05:14:39.732693
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:42.833680
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert isinstance(hti, HandlerTaskInclude)
    assert isinstance(hti, Handler)
    assert isinstance(hti, TaskInclude)


# Generated at 2022-06-25 05:14:46.166981
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    _handler_task_include = HandlerTaskInclude() # with param
    _handler_task_include.load(data='', block='', role='', task_include='', variable_manager='', loader='')


# Generated at 2022-06-25 05:14:47.333554
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:50.674814
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
# No argument
    try:
        handler_task_include_0.load()
    except TypeError:
        pass

# Generated at 2022-06-25 05:14:55.049696
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Check if HandlerTaskInclude.__init__ is called when we create an object of HandlerTaskInclude
    with patch.object(HandlerTaskInclude, '__init__', return_value=None) as mock_HandlerTaskInclude:
        handler_task_include = HandlerTaskInclude()
        mock_HandlerTaskInclude.assert_called_with()


# Generated at 2022-06-25 05:15:01.088005
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    tqm = TaskQueueManager()
    data = {"tasks": {}}
    variable_manager = VariableManager()
    playbook_dir = os.path.dirname(os.path.realpath(__file__))
    loader_0 = DataLoader()
    result = handler_task_include_1.load(data, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader_0)
    assert isinstance(result, list)
    assert len(result) == 0


# Generated at 2022-06-25 05:15:10.444535
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)
    var_0 = HandlerTaskInclude()
    var_1 = list_0
    var_2 = [set_0, set_0]
    var_3 = var_0.load(var_2, var_1)



# Generated at 2022-06-25 05:15:15.580804
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)
    assert handler_task_include_0.VALID_INCLUDE_KEYWORDS == {'tasks', 'reset_connection', 'vars_files', 'roles', 'vars', 'listen', 'tags'}, 'Incorrect value for HandlerTaskInclude.VALID_INCLUDE_KEYWORDS'

# Generated at 2022-06-25 05:15:19.042619
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(list_0, list_0)


# Generated at 2022-06-25 05:15:26.001273
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)


# Generated at 2022-06-25 05:15:30.346688
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert isinstance(HandlerTaskInclude(), HandlerTaskInclude)
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    handler_task_include_1 = HandlerTaskInclude(static_tasks=list_0)
    assert isinstance(handler_task_include_1, HandlerTaskInclude)

# Generated at 2022-06-25 05:15:37.384892
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    bool_0 = True
    tuple_0 = ()
    list_0 = [bool_0, bool_0, '', tuple_0, tuple_0, tuple_0]
    var_0 = handler_task_include_0.load(list_0, list_0)

# Generated at 2022-06-25 05:15:38.089779
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert test_case_0() == None

# Generated at 2022-06-25 05:15:45.706245
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # "The list_0 return value should be the same as the var_0"
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)
    assert var_0 == list_0

# Generated at 2022-06-25 05:15:53.093090
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)

# Generated at 2022-06-25 05:15:57.414016
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Testing constructor for HandlerTaskInclude")
    handler_task_include_0 = HandlerTaskInclude()
    assert (handler_task_include_0 is not None)



# Generated at 2022-06-25 05:16:07.562681
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        handler_task_include_0 = HandlerTaskInclude()
    except NameError as e:
        assert False, "Failed to instantiate class with HandlerTaskInclude()"


# Generated at 2022-06-25 05:16:11.962733
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

# Generated at 2022-06-25 05:16:16.531113
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    # Constructor of class HandlerTaskInclude
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)


# Generated at 2022-06-25 05:16:27.222720
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)
    bool_1 = True
    set_1 = {bool_1, bool_1}
    list_1 = [set_1, set_1, bool_1, bool_1]
    handler_task_include_1 = HandlerTaskInclude(list_1)
    var_1 = handler_task_include_1.load(list_1, list_1)

    assert var_0 == var_1

# Generated at 2022-06-25 05:16:32.303482
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)

# Generated at 2022-06-25 05:16:35.786940
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    list_1 = []
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_1)

# Generated at 2022-06-25 05:16:38.932055
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'task', 'tags', 'ignore_errors', 'listen'}


# Generated at 2022-06-25 05:16:45.052930
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)



# Generated at 2022-06-25 05:16:47.107195
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:16:50.465399
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:17:06.018753
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.__init__()
    assert isinstance(handler_task_include_0, HandlerTaskInclude)


# Generated at 2022-06-25 05:17:10.211255
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = [{True}, False, {False}]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)

# Generated at 2022-06-25 05:17:10.953756
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert True


# Generated at 2022-06-25 05:17:14.548503
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Arrange
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()

    # Act and Assert
    assert isinstance(handler_task_include_0.load(list_0, list_0), HandlerTaskInclude)

# Generated at 2022-06-25 05:17:16.553534
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = set()
    list_0 = list()
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(list_0, list_0)


# Generated at 2022-06-25 05:17:21.179045
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)


# Generated at 2022-06-25 05:17:27.703670
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)

# Generated at 2022-06-25 05:17:32.213389
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(None, None)

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:17:38.389957
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)

# test_case_0 ==========

# Generated at 2022-06-25 05:17:41.414710
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(list_0, list_0)


# Generated at 2022-06-25 05:18:12.318045
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    bool_1 = True
    dict_0 = dict()
    dict_1 = dict()
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    str_0 = ""
    str_1 = ""
    str_2 = ""
    str_3 = ""
    str_4 = ""
    str_5 = ""
    str_6 = ""
    str_7 = ""
    str_8 = ""
    str_9 = ""
    str_10 = ""
    str_11 = ""
    str_12 = ""
    str_13 = ""
    str_14 = ""
    str_15 = ""
    str_16 = ""
    str_17 = ""
    str_18 = ""
    str_19 = ""
   

# Generated at 2022-06-25 05:18:15.443985
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Test 1
    run_test(test_case_0)

test_cases = (
    test_case_0
)


# Generated at 2022-06-25 05:18:16.352413
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert test_case_0() == None

# Generated at 2022-06-25 05:18:22.773597
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    bool_1 = False
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)
    if var_0:
        raise Exception("False")

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 05:18:31.097308
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    list_0 = list()
    handler_task_include_0 = HandlerTaskInclude.load(list_0, list_0)
    assert handler_task_include_0.get_name() == ''
    assert handler_task_include_0.get_tags() == set()
    assert handler_task_include_0.get_when() == set()
    assert handler_task_include_0.notify == set()
    assert handler_task_include_0.only_tags == set()
    assert handler_task_include_0.local_action == ''
    assert handler_task_include_0.handler is False
    assert handler_task_include_0.until is set()
    assert handler_task_include_0.retries == 3
    assert handler_task_include_0.register == ''

# Generated at 2022-06-25 05:18:37.220741
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Setup
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    bool_0 = True
    handler_task_include_1.load('', False)
    handler_task_include_1.load('', bool_0)
    handler_task_include_1.load('', False)
    handler_task_include_1.load('', bool_0)
    handler_task_include_1.load('', bool_0)
    handler_task_include_1.load('', False)
    handler_task_include_1.load('', False)
    handler_task_include_1.load('', bool_0)
    handler_task_include_1.load('', bool_0)

# Generated at 2022-06-25 05:18:41.989422
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Check if the method "load" of class "HandlerTaskInclude" return the proper results.
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)
    assert var_0 == list_0


# Generated at 2022-06-25 05:18:43.663228
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:18:44.876239
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True == True


# Generated at 2022-06-25 05:18:46.895032
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.load(list, list)


# Generated at 2022-06-25 05:19:31.241928
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        HandlerTaskInclude.load(('E[Y)0#`G9#0^.:*',))
    except ValueError as exception_0:
        assert str(exception_0) == 'Only one included yaml is permitted per task'

    else:
        raise Exception('Exception not thrown')

# Generated at 2022-06-25 05:19:40.524869
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = [{True, True}, {True, True}, True, True]
    HandlerTaskInclude.load(list_0, list_0)
    list_0 = [{True, True}, {True, True}, True, True]
    HandlerTaskInclude.load(list_0, list_0)
    list_0 = [{True, True}, {True, True}, True, True]
    HandlerTaskInclude.load(list_0, list_0)
    list_0 = [{True, True}, {True, True}, True, True]
    HandlerTaskInclude.load(list_0, list_0)


if __name__ == "__main__":
    test_case_0()
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:19:43.534435
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude(list_0)


# Generated at 2022-06-25 05:19:49.443453
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)
    assert not var_0.notify



# Generated at 2022-06-25 05:19:53.055047
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("in test_HandlerTaskInclude_load")

# Generated at 2022-06-25 05:19:57.570426
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    dict_0 = dict()
    set_0 = {bool_0, bool_0}
    list_0 = [bool_0, dict_0, set_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)



test_case_0()

# Generated at 2022-06-25 05:20:05.105647
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    list_0 = [{True, True}, {True, True}, True, True]
    var_0 = handler_task_include_0.load(list_0, list_0)
    assert var_0 == handler_task_include_0

# Generated at 2022-06-25 05:20:06.463833
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Running unit test for method load of class HandlerTaskInclude')
    test_case_0()

# Test suite

# Generated at 2022-06-25 05:20:07.273116
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True == True

if __name__ == "__main__":
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:20:09.392638
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)


# Generated at 2022-06-25 05:21:35.978905
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Hello, world')


# Generated at 2022-06-25 05:21:41.289251
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert(isinstance(handler_task_include_0,HandlerTaskInclude))


# Generated at 2022-06-25 05:21:47.461289
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:21:49.592123
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include_0 = HandlerTaskInclude()
    assert isinstance(handler_task_include_0, HandlerTaskInclude)



# Generated at 2022-06-25 05:21:50.302673
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:21:50.755537
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-25 05:21:59.966822
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = ['listen', 'listen', ('listen',), ('listen', 'listen', 'listen', 'listen', 'listen', 'listen', 'listen')]
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(list_0, list_0)
    list_1 = [list_0, list_0, list_0]
    handler_task_include_1 = HandlerTaskInclude()
    try:
        var_1 = handler_task_include_1.load(list_1)
    except TypeError:
        pass
    list_1 = [list_0, list_0]
    handler_task_include_1 = HandlerTaskInclude()

# Generated at 2022-06-25 05:22:03.005456
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(list_0, list_0)

# Generated at 2022-06-25 05:22:11.866297
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Input data type test
    bool_0 = True
    bool_1 = False
    task_include_0 = TaskInclude()
    handler_task_include_0 = HandlerTaskInclude()
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, set_0, bool_0, bool_0]
    var_0 = handler_task_include_0.load(list_0, list_0)
    assert var_0 is not None
    assert isinstance(var_0, HandlerTaskInclude)
    set_1 = {bool_0, bool_1}
    set_2 = {bool_1, bool_1}
    tuple_0 = (bool_0, bool_1, bool_0, bool_1, bool_1, bool_0)
    tuple_1

# Generated at 2022-06-25 05:22:13.265525
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()