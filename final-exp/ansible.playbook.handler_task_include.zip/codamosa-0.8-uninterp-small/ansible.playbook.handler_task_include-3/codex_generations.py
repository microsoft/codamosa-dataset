

# Generated at 2022-06-25 05:13:46.985874
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    loader = None
    variable_manager = None
    task_include = None
    role = None
    block = None
    data = None

    # handler_task_include_1 = HandlerTaskInclude()
    # handler_task_include_1.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-25 05:13:50.706986
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("test_HandlerTaskInclude_load(): starting")
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load({'a':'b', 'c': 'd'})
    print("test_HandlerTaskInclude_load(): finished")


# Generated at 2022-06-25 05:13:53.372528
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_load_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:13:54.333058
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:01.124425
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None
    assert handler_task_include.block is None
    assert handler_task_include.task_include is None
    assert handler_task_include.role is None
    assert handler_task_include.tags == []
    assert handler_task_include.when == []
    assert handler_task_include.failed_when == []
    assert handler_task_include.rescue == []
    assert handler_task_include.always == []



# Generated at 2022-06-25 05:14:06.903928
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_0 = HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:14:13.502529
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Tests the load method of the HandlerTaskInclude class.
    '''
    handler_task_include_load = HandlerTaskInclude()
    
    # The following call to load() is not expected to return a
    # HandlerTaskInclude object, so we test to make sure it doesn't
    assert not isinstance(handler_task_include_load.load(), HandlerTaskInclude)

    # The following call to load() is expected to return a
    # HandlerTaskInclude object, so we test to make sure it does
    assert isinstance(HandlerTaskInclude.load(), HandlerTaskInclude)

# Generated at 2022-06-25 05:14:14.917281
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()



# Generated at 2022-06-25 05:14:15.599522
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:18.017554
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load([])


# Generated at 2022-06-25 05:14:21.633287
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()



# Generated at 2022-06-25 05:14:22.923189
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()



# Generated at 2022-06-25 05:14:30.587254
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_1 = HandlerTaskInclude(
        action={'listen': 'shutdown'},
        block=None,
        delegate_to=None,
        loop={},
        name=None,
        notify=[],
        register=None,
        retries=0,
        role=None,
        run_once=False,
        always_run=False,
        tags=[],
        when=True,
        errors='strict',
        task_include=None,
        until=[],
        delegate_facts=False,
        any_errors_fatal=False
    )
    assert handler_task_include_1 is not None

# Generated at 2022-06-25 05:14:33.050042
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()

    # Test with invalid args
    try:
        handler_task_include_1.load(data=None)
    except TypeError:
        pass


if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:14:34.729641
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:36.903207
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    assert handler_task_include_1.load()


# Generated at 2022-06-25 05:14:47.293523
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.module_utils._text import to_bytes
    from ansible.utils.vars import combine_vars

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=None)

    variable_manager.set_inventory(inventory)

    source = b'block: - block: - ping: - include: block.yml'
    variable_manager._options = {'_ansible_vault_password': 'prout'}
    block_host_vars = {'ansible_host': '127.0.0.1'}

# Generated at 2022-06-25 05:14:52.889085
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    data = dict()
    block = dict()
    role = dict()
    task_include = dict()
    variable_manager = dict()
    loader = dict()

    assert type(handler_task_include_1.load(data, block, role, task_include, variable_manager, loader)) == HandlerTaskInclude


# Generated at 2022-06-25 05:14:56.055093
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.load(data=None,block=None,role=None,task_include=None,variable_manager=None,loader=None) == handler_task_include_0

# Generated at 2022-06-25 05:15:02.533770
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()

    play_context_0 = PlayContext()
    connection_0 = Connection()

    inventory_0 = Inventory()
    host_0 = Host()
    host_0.address = '172.27.1.1'
    inventory_0.get_hosts = MagicMock(return_value=[host_0])

    variable_manager_0 = VariableManager(loader=None, inventory=inventory_0)
    variable_manager_0.extra_vars = load_file(os.getcwd() + '/unit/test_json/extra_vars.json')

    data = {}

# Generated at 2022-06-25 05:15:09.432604
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:15:10.443334
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-25 05:15:18.251392
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include_task_include_0 = TaskInclude()

    handler_task_include_0 = HandlerTaskInclude(task_include=task_include_task_include_0)
    data = {
        'include': 'some_file'
    }
    handler = HandlerTaskInclude.load(data)

    assert isinstance(handler, HandlerTaskInclude)
    assert handler.dyntag is None
    assert handler.block is None
    assert handler.tags is None
    assert handler.when is None
    assert handler.only_if is None
    assert handler.name is None
    assert handler.notify is None
    assert handler.listen is None
    assert handler.loop is None
    assert handler.until is None
    assert handler.run_once is False
    assert handler.first_available_file is None

# Generated at 2022-06-25 05:15:21.219708
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(
        data={},
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-25 05:15:29.473450
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # handler_0_0 = HandlerTaskInclude.load(
    #     data={},
    #     block=None,
    #     role=None,
    #     task_include=None,
    #     variable_manager=None,
    #     loader=None
    # )

    handler_0 = HandlerTaskInclude.load(
        data=dict(),
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-25 05:15:34.617756
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

# Generated at 2022-06-25 05:15:37.447723
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    # Test with a handler and argument
    handler_task_include_0.load()
    # Test with handler_task_include_0 and argument
    handler_task_include_0.load()



# Generated at 2022-06-25 05:15:40.782451
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()
    assert handler_task_include_1 == handler_task_include_2

# Generated at 2022-06-25 05:15:46.825459
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    # data = None
    # block = None
    # role = None
    # task_include = None
    # variable_manager = None
    # loader = None
    handler_task_include.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert(True)

# Generated at 2022-06-25 05:15:50.150503
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.__class__ == HandlerTaskInclude

# Generated at 2022-06-25 05:15:57.965023
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti_0 = HandlerTaskInclude(b'\x80\x9c\x06\x9f\xef')
    assert hti_0.uuid is not None


# Generated at 2022-06-25 05:16:03.417735
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    assert handler_task_include_0.load(str_0, str_0) == None

# Generated at 2022-06-25 05:16:12.048400
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'PVgSdQRTvx'
    handler_task_include_0 = HandlerTaskInclude()
    bytes_0 = b'Y\xef)\xf0\x9e\x9b\x02\xe3\xe2\x01\x02\x1cE\xfc'
    var_0 = handler_task_include_0.load(str_0, str_0)
    var_1 = handler_task_include_0.load(str_0, str_0)
    str_1 = '+dS$n\x7fJ^'
    var_2 = handler_task_include_0.load(str_0, str_0)
    var_3 = handler_task_include_0.load(str_0, str_0)


# Generated at 2022-06-25 05:16:12.725170
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True == True

# Generated at 2022-06-25 05:16:21.087912
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-25 05:16:26.580566
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = '*]y'
    bytes_0 = b'\x03\xfa\xac\xaa\xc8\xfd'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    var_0 = handler_task_include_0.load(str_0, str_0)

# Generated at 2022-06-25 05:16:30.535740
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:16:36.411579
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    handler_task_include_1 = handler_task_include_0.load(str_0, str_0)


if __name__ == '__main__':
    import sys
    if sys.version_info.major < 3:
        sys.exit()
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:16:40.225942
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("\n test_HandlerTaskInclude: ")
    b'\xf9\x8a\xda\xc1\x10\x1d\x8d\xda\x94\x0c\x9f8\xc9\x1b'
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 05:16:40.744141
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert True


# Generated at 2022-06-25 05:17:00.739430
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'm\xdf'
    bytes_0 = b'v.\xab\x82\xfe\xf5\x9e\xb3\x0c\xac'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    str_1 = 'i\x97\xee\x1c\xab\x0e\xe3'
    handler_task_include_0.load(str_1)



# Generated at 2022-06-25 05:17:04.723675
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:17:10.080088
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test case 1: no input
    # Expected result:
    test_case_0()

    # Test case 2: unknown input
    # Expected result:
    test_case_0()



# Generated at 2022-06-25 05:17:19.227619
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = '\x1c\xa3\x8b\x13'
    bytes_0 = b'\x8a\xac\xf2\x98\xed\x7f\xce\x0c'
    handler_task_include_0 = HandlerTaskInclude(name=str_0, block=None, role=bytes_0, task_include=None)
    handler_task_include_1 = HandlerTaskInclude(name=str_0, block=bytes_0, role=bytes_0, task_include=None)
    handler_task_include_2 = HandlerTaskInclude(name=str_0, block=bytes_0, role=bytes_0, task_include=bytes_0)

# Generated at 2022-06-25 05:17:23.749074
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    handler_task_include_1 = handler_task_include_0.load(str_0, str_0)

# Generated at 2022-06-25 05:17:33.315299
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'M/pz#'
    bytes_0 = b'^\xea\x90\xe1\x9e\x94\x1b\xed\x84\x18'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    assert isinstance(handler_task_include_0, HandlerTaskInclude) == True

    str_1 = 'r#`7<k~'
    handler_task_include_1 = HandlerTaskInclude(str_1)
    assert isinstance(handler_task_include_1, HandlerTaskInclude) == True

    var_0 = HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert var_0 != None

    str_1 = 'EtzU;nC'

# Generated at 2022-06-25 05:17:33.710721
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:17:37.659072
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.VALID_INCLUDE_KEYWORDS == set(['name', 'handlers', 'listen', 'vars', 'tasks'])

# Generated at 2022-06-25 05:17:45.922430
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'P\x14\x9b\xa9\xbe\xbe\xef\xbe\xbb\xde\x0e\xa6\xb9\xd9\x96\x8d\x07'
    is_unix_0 = HandlerTaskInclude.is_unix_path(str_0)
    handler_task_include_0 = HandlerTaskInclude(str_0)

if __name__ == '__main__':
    # test_case_0()

    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:17:50.890382
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'hv!\x7f\xca\x92\x08]-\x1f'
    bytes_0 = b'\x0b\x08*\xba\xf6\\\xf6\x1c\xd6\x9f\x0b'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    var_0 = handler_task_include_0.load(str_0, str_0)

# Generated at 2022-06-25 05:18:17.711009
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    assert isinstance(handler_task_include_0, HandlerTaskInclude)



# Generated at 2022-06-25 05:18:25.754325
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = ':-\x04\xe9'
    str_1 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    var_1 = handler_task_include_0.load(str_0, str_1)


# Generated at 2022-06-25 05:18:32.687806
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'T'
    data_0 = 'o\x01\x1a\xaa\xa4\n\x1e\x8e\x0f\x13\xab\xee\x9f'
    block_0 = '\x90\x8e\xa7\x7f\xaf\x16\xc6\x8f\x083'

# Generated at 2022-06-25 05:18:39.347697
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    str_1 = 'k\xad\xa4\x85'
    var_0 = handler_task_include_0.load(str_0, str_0, str_1)
    return var_0


# Generated at 2022-06-25 05:18:45.598935
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    def test(a, b, c):
        handler_task_include_0 = HandlerTaskInclude(a, b, c)
        assert handler_task_include_0.block == a
        assert handler_task_include_0.role == b
        assert handler_task_include_0.task_include == c

        handler_task_include_1 = HandlerTaskInclude(b, c)
        assert handler_task_include_1.block == b
        assert handler_task_include_1.role == c
        assert handler_task_include_1.task_include is None

        handler_task_include_2 = HandlerTaskInclude(c, c)
        assert handler_task_include_2.block == c
        assert handler_task_include_2.role == c
        assert handler_task_include_2.task_include

# Generated at 2022-06-25 05:18:53.497228
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    str_1 = 'D3:)^hGIzu5'
    bytes_1 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_1 = HandlerTaskInclude(bytes_1)


# Generated at 2022-06-25 05:18:58.695391
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert 'listen' in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert 'tags' in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert 'tasks' in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert 'handlers' in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert 'when' in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert 'name' in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-25 05:19:03.843250
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)

    # Call the load method
    var_0 = handler_task_include_0.load(str_0, str_0)


# Generated at 2022-06-25 05:19:15.472589
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_1 = 'R!_nh4\x05\x1e\x00'
    bytes_1 = b'\xef\xf3\xec\x8e\x07\xa2\x08K\xdd\x1f'
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_1 = HandlerTaskInclude(str_0)
    var_1 = handler_task_include_1.load(str_1, str_0)
    handler_task_include_0 = HandlerTaskInclude(bytes_1)
    var_0 = handler_task_include_0.load(bytes_1, str_0)

# Generated at 2022-06-25 05:19:19.374881
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Tests load() of HandlerTaskInclude.
    """
    test_cases = [
        {"str": 'D3:)^hGIzu5', "bytes": b'u\xce\x04\xd6\x93c\x15\xda\x1f~'},
        {"str": 'D3:)^hGIzu5', "bytes": b'u\xce\x04\xd6\x93c\x15\xda\x1f~'},
        {"str": 'D3:)^hGIzu5', "bytes": b'u\xce\x04\xd6\x93c\x15\xda\x1f~'}
    ]
    for test_case in test_cases:
        str_0 = test_case["str"]

# Generated at 2022-06-25 05:20:06.126560
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    assert 0 is HandlerTaskInclude.load('')

# Generated at 2022-06-25 05:20:08.561589
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    assert not test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:20:09.366524
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude(b'D3:)^hGIzu5') is not None


# Generated at 2022-06-25 05:20:20.124838
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'hL\x13\xa8\x94\xe9\xdf\x1f\xe8\xdeA?\x15\xc6'
    bytes_0 = b'\xa8\x81\xb5k\xf5\x0c\x8f\x0b\x11\x02i\xdb'
    block_array_0 = [None, None, None]
    block_array_0[0] = None
    block_array_0[1] = None
    block_array_0[2] = None
    var_0 = HandlerTaskInclude(block_array_0)
    var_0.load(str_0, bytes_0)
    str_1 = 'D3:)^hGIzu5'

# Generated at 2022-06-25 05:20:23.919106
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    var_0 = HandlerTaskInclude.load(bytes_0, str_0, bytes_0, str_0)

# Generated at 2022-06-25 05:20:30.044563
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    str_1 = 'D3:)^hGIzu5'
    str_2 = 'D3:)^hGIzu5'
    str_3 = 'D3:)^hGIzu5'
    str_4 = 'D3:)^hGIzu5'
    str_5 = 'D3:)^hGIzu5'
    test_case_0(str_0, str_1, str_2, str_3, str_4, str_5)
    str_5 = 'D3:)^hGIzu5'
    str_4 = 'D3:)^hGIzu5'
    str_3 = 'D3:)^hGIzu5'

# Generated at 2022-06-25 05:20:36.457630
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    var_0 = handler_task_include_0.load(str_0, str_0)

# Generated at 2022-06-25 05:20:41.501816
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'R"kH;n'
    str_1 = 'B:m#M'
    # call function function load of object handler_task_include_0
    HandlerTaskInclude.load(str_1, str_0)


# Generated at 2022-06-25 05:20:46.499677
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import sys
    import ansible.playbook.handler
    import ansible.playbook.task
    var_0 = ansible.playbook.handler.Handler()
    var_1 = ansible.playbook.task.Task()
    var_2 = ansible.playbook.handler.HandlerTaskInclude(var_0, var_1)
    var_2.load('D3:)^hGIzu5', 'D3:)^hGIzu5')

# Generated at 2022-06-25 05:20:56.076232
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = '\x08\x80\x03\x8a2\xb9\x91\xcb\xd4'
    bytes_0 = b'\x04\x12\x89\t\xc9\x0e\x88\xb5$'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)

    # Testing method load of class HandlerTaskInclude
    str_1 = 'azZny\x96\x8e\x9b\x9c'
    bytes_1 = b'\x0e\xcf\x18\x01\x07\xf3\xc3\x06'
    handler_task_include_2 = handler_task_include_0.load(str_1, str_1)

test_case_0()
test_HandlerTask

# Generated at 2022-06-25 05:22:43.926956
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Initialize the object
    handler_task_include_0 = HandlerTaskInclude(b'u\xce\x04\xd6\x93c\x15\xda\x1f~')
    # Asserts
    var_0 = handler_task_include_0.load(b'\xbc\xdb\x80\xdf\xad\x1b\x8a\x07\xde\xf0\xcd\x8f', b'\xbc\xdb\x80\xdf\xad\x1b\x8a\x07\xde\xf0\xcd\x8f')
    assert var_0 is None
    # Test HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert HandlerTaskInclude.VALID_INCLUDE_

# Generated at 2022-06-25 05:22:47.202937
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Unit test for method load of class HandlerTaskInclude
    '''
    handler_task_include_instance = HandlerTaskInclude()
    data = ''
    block = ''
    role = ''
    task_include = ''
    variable_manager = ''
    loader = ''

    ret = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert ret == False

# Generated at 2022-06-25 05:22:53.202392
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    str_1 = '68\x14\x84F\x17\xef\x16\xa6\x1a\xda\x12\x9e\x14\x83\x1e\xef\x1b\x10.\xdf\x14'
    handler_task_include_0 = HandlerTaskInclude(str_1)
    bytes_0 = b'O\x1a\x9d\x1e\xba|\x14\xec>\x07\x9a\xa1\xe4\xf9\x83\x1f\xc4\x00\x08'
    var_0 = handler_task_include_0.load(bytes_0, str_0)


# Generated at 2022-06-25 05:23:01.194634
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    str_1 = '\n'
    var_0 = handler_task_include_0.load(str_0, str_0)
    var_1 = handler_task_include_0.load(str_0, str_1)


# Generated at 2022-06-25 05:23:01.627554
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-25 05:23:02.301440
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-25 05:23:08.844306
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'r"\x91\x95\x8a\x5a\x9c'
    str_1 = '\x89\xcf\x08\x0f\x8d'
    handler_task_include_0 = HandlerTaskInclude(str_1)
    str_2 = '\xad\xb2\xc1\xd9O\x88'
    str_3 = '\x14\xee\xb4\x8f\xfe'
    str_4 = 'a\x04\x89\x1c\xce\x1c'
    str_5 = '\xb3\x03c\xc8\xfc\x00'
    handler_task_include_0.load(str_4, str_5)


# Generated at 2022-06-25 05:23:10.911628
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    str_0 = 'A'
    bytes_0 = bytearray(str_0)
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    assert str_0 == str(handler_task_include_0)


# Generated at 2022-06-25 05:23:13.789845
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    str_0 = 'D3:)^hGIzu5'
    bytes_0 = b'u\xce\x04\xd6\x93c\x15\xda\x1f~'
    handler_task_include_0 = HandlerTaskInclude(bytes_0)
    var_0 = handler_task_include_0.load(str_0, str_0)

# Generated at 2022-06-25 05:23:17.084187
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()