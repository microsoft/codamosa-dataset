

# Generated at 2022-06-25 05:13:42.092469
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude.load({"handler": "include"}, None, None)


# Generated at 2022-06-25 05:13:43.805233
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include

# Generated at 2022-06-25 05:13:50.338578
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude.load(
        {
            "include_tasks": "somefile.yml",
            "listen": "foo"
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    h = HandlerTaskInclude.load(
        {
            "include_tasks": "somefile.yml",
            "tags": "foo"
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-25 05:13:53.511402
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()

# Unit testing for function HandlerTaskInclude.load_data

# Generated at 2022-06-25 05:13:55.439636
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None

# Generated at 2022-06-25 05:14:03.269368
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Initialize class
    handler_task_include_1 = HandlerTaskInclude()

    global data
    data = None

    global block
    block = None

    global role
    role = None

    global task_include
    task_include = None

    global variable_manager
    variable_manager = None

    global loader
    loader = None

    # Try to load a task include
    handler_task_include_1.load(data, block, role, task_include, variable_manager, loader)

    # Check if the task include has been loaded successfully
    assert isinstance(handler_task_include_1, HandlerTaskInclude)
    assert isinstance(handler_task_include_1.DYNAMIC_COUNT, int)

# Generated at 2022-06-25 05:14:05.481706
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

    data = dict()
    data['include'] = '{{ test_handler_0_include }}'

    # handler = handler_task_include_0.load(data)

# Generated at 2022-06-25 05:14:10.386616
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None
    assert handler_task_include_0._task.action == 'whatever'

# Generated at 2022-06-25 05:14:13.422460
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include = HandlerTaskInclude()
    assert(None == handler_task_include._included_files)
    assert('' == handler_task_include._role_name)
    assert(None == handler_task_include._block)
    assert(None == handler_task_include._task)

# Generated at 2022-06-25 05:14:23.326410
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    load_0_data = [
        'tasks/all.yml'
    ]
    load_0_block = None
    load_0_role = None
    load_0_task_include = None
    load_0_variable_manager = None
    load_0_loader = None

    # Test for correct type
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude.load( \
        load_0_data, \
        load_0_block, \
        load_0_role, \
        load_0_task_include, \
        load_0_variable_manager, \
        load_0_loader \
    )
    assert isinstance(handler_task_include_1, Handler)

    # Test created task
    load_1_

# Generated at 2022-06-25 05:14:29.876497
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    assert handler_task_include_1 is not None
    print("Testing HandlerTaskInclude.load()")

    # Set up test parameters
    data_0 = {"listen": "all", "include": "myfile.yml"}

    handler_task_include_1.load(data_0)
    print("Finished testing HandlerTaskInclude.load()")


# Generated at 2022-06-25 05:14:36.162449
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    case_0 = {'include': 'main.yml'}
    handler_task_include_0 = HandlerTaskInclude.load(case_0)
    assert 'main.yml' == handler_task_include_0.static_include.static_loader.path_name
# assert handler_task_include_0.static_include.static_loader.playbook_basedir == os.path.abspath(os.curdir)

    case_1 = {'include': 'main.yml', 'with_items': [1, 2, 3]}
    handler_task_include_1 = HandlerTaskInclude.load(case_1)
    assert handler_task_include_1.static_include.static_loader.path_name == 'main.yml'
    assert handler_task_include_1.static_include.loop

# Generated at 2022-06-25 05:14:38.951353
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler_task_include is not None


# Generated at 2022-06-25 05:14:39.417259
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:40.208985
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None


# Generated at 2022-06-25 05:14:42.200792
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 != None

# Generated at 2022-06-25 05:14:50.787493
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude(
        task_include=TaskInclude(
            _task=None,
            _role=None,
            _loader=None,
            _variable_manager=None,
            _parent_block=None,
            _play=None,
            _loader_cache={},
            _role_names={}
        ),
        block=None,
        role=None,
    )

    test_data_0 = [
        {'listen': 'restart apache'},
        {'listen': 'restart nginx'},
    ]

    handler_task_include_0.load(
        data=test_data_0,
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-25 05:14:58.702848
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert type(handler_task_include.VALID_INCLUDE_KEYWORDS) == set
    assert handler_task_include.VALID_INCLUDE_KEYWORDS == set([
        'when', 'ignore_errors', 'delegate_to', 'loop', 'run_once', '_raw_params',
        'tags', 'register', 'notify', 'first_available_file', 'until', 'notified_by',
        'listen'])
    assert handler_task_include._task_include_variables == set([])
    assert handler_task_include.include_tasks_files == []
    assert handler_task_include._handler_name == None

# Generated at 2022-06-25 05:14:59.143114
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-25 05:15:07.740405
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # The function call to test
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # Additional tests:
    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'

    assert handler == 'something'
