

# Generated at 2022-06-25 05:13:46.915967
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = None
    bytes_0 = None
    handler_task_include_0 = HandlerTaskInclude(list_0, bytes_0)
    data_1 = None
    loader_0 = None
    variable_manager_0 = None
    handler_task_include_1 = HandlerTaskInclude.load(data_1, loader_0, variable_manager_0)
    assert handler_task_include_1.__class__.__name__ == 'HandlerTaskInclude'
    assert handler_task_include_1.task.__class__.__name__ == 'TaskInclude'


# Generated at 2022-06-25 05:13:48.266793
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True


# Generated at 2022-06-25 05:13:50.328827
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = None
    bytes_0 = None
    handler_task_include_1 = HandlerTaskInclude(list_0, bytes_0)
    assert handler_task_include_1 != None

# Generated at 2022-06-25 05:13:58.850928
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = None
    bytes_0 = None
    handler_task_include_0 = HandlerTaskInclude(list_0, bytes_0)
    data_0 = None
    block_0 = None
    role_0 = None
    task_include_0 = None
    variable_manager_0 = None
    loader_0 = None
    handler_task_include_0.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:14:00.633423
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    if not isinstance(HandlerTaskInclude.load(), HandlerTaskInclude):
        assert False
    else:
        assert True


# Generated at 2022-06-25 05:14:07.114733
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''
    test_HandlerTaskInclude()
    '''
    # Create a new instance of class HandlerTaskInclude with parameters: 'list_0', 'bytes_0'
    list_0 = None
    bytes_0 = None
    handler_task_include_0 = HandlerTaskInclude(list_0, bytes_0)



# Generated at 2022-06-25 05:14:10.456248
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()  # create an HandlerTaskInclude object


# Generated at 2022-06-25 05:14:16.431314
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = None
    bytes_0 = None
    variable_manager_0 = None
    task_include_0 = None
    handler_task_include_0 = HandlerTaskInclude(list_0, bytes_0)
    data = str()
    loader = None

    # Test when handler has a listen attribute.
    data = dict(
        name="test",
        include="awesome_handler",
        listen="test_event"
    )
    handler_task_include_0.load(data)
    handler = handler_task_include_0.load(data, task_include=task_include_0)
    assert handler.name == 'test'
    assert handler.listen == 'test_event'

# Generated at 2022-06-25 05:14:20.781277
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-25 05:14:30.539755
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test case with compliance test-case 32
  
    list_0 = None
    bytes_0 = None
    handler_task_include_0 = HandlerTaskInclude(list_0, bytes_0)

    # Test case with compliance test-case 33
  
    list_0 = None
    bytes_0 = None
    handler_task_include_0 = HandlerTaskInclude(list_0, bytes_0)

    # Test case with compliance test-case 34
  
    list_0 = None
    bytes_0 = None
    handler_task_include_0 = HandlerTaskInclude(list_0, bytes_0)

    # Test case with compliance test-case 35
  
    list_0 = None
    bytes_0 = None
    handler_task_include_0 = HandlerTaskInclude(list_0, bytes_0)