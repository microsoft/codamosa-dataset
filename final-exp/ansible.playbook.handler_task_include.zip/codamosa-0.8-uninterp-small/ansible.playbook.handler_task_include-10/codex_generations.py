

# Generated at 2022-06-25 05:13:42.760947
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Testing HandlerTaskInclude.load")
    hti = HandlerTaskInclude.load(None)

# Generated at 2022-06-25 05:13:46.870934
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    data = {
        'name' : 'test_case_0',
        'include' : 'test_case_1'
    }
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler_task_include_1.load(data=data, block=block, role=role, task_include=task_include,
                variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 05:13:53.777337
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    handler_task_include_0 = HandlerTaskInclude(
        block = None,
        role = None,
        task_include = None
    )
    handler = handler_task_include.load(
        data = '',
        block = None,
        role = None,
        task_include = None,
        variable_manager = None,
        loader = None
    )
    assert(handler == None)

# Generated at 2022-06-25 05:14:02.515362
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude.load('handler: task: test', block=None, role=None, task_include=None, variable_manager=None, loader=None)
    # Answer:
    assert hti.block == None
    assert hti.role == None
    assert hti.task_include == None
    assert hti.include_role == None
    assert hti.include_playbook == None
    assert hti.include_tasks == None
    assert hti.loop == None
    assert hti.handler_block.name == 'test'
    assert hti.name == 'handler'
    assert hti.block == None
    assert hti.when == None
    assert hti.tags == ['all']
    assert hti.action == 'handler'
    assert hti.register == None
    assert hti

# Generated at 2022-06-25 05:14:03.998060
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:05.461123
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    print(handler_task_include_1)

# Generated at 2022-06-25 05:14:07.461772
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None


# Generated at 2022-06-25 05:14:10.489574
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:12.402038
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-25 05:14:23.015364
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1_data = dict({"block": "Listen and respond to events",
                                        "role": "listen",
                                        "task_include": "test_task",
                                        "variable_manager": "manager",
                                        "loader": "test_loader"})
    handler_task_include_1_result = handler_task_include_1.load(handler_task_include_1_data)
    assert handler_task_include_1_result == {"block": "Listen and respond to events",
                                             "role": "listen",
                                             "task_include": "test_task",
                                             "variable_manager": "manager",
                                             "loader": "test_loader"}