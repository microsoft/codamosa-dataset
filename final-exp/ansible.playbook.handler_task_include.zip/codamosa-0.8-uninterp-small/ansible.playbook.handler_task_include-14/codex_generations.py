

# Generated at 2022-06-25 05:13:42.390106
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    Test the constructor of class HandlerTaskInclude.
    """
    handler_task_include = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None
    )

    assert handler_task_include != None


# Generated at 2022-06-25 05:13:44.771224
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 != None


# Generated at 2022-06-25 05:13:48.337693
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict()
    handler_task_include_0 = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler_task_include_1 = HandlerTaskInclude(block=None, role=None, task_include=None, **data)
    handler_task_include_2 = HandlerTaskInclude(block=None, role=None, task_include=None, data=data)


if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:13:55.394323
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data0 = dict(
        name='handler_task_include',
        include='task_include.yaml',
        listen='restart_services'
    )
    exclude0 = ['name', 'tasks']
    config0 = handler_task_include = HandlerTaskInclude(name='handler_task_include',
                                                        include='task_include.yaml',
                                                        listen='restart_services')
    assert all(getattr(config0, k) == v for k, v in data0.items() if k not in exclude0)

# Generated at 2022-06-25 05:14:00.977397
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    method_args = {'block': None, 'role': None, 'task_include': None}
    method_kwargs = {'data': {u'include': u'once.yml', u'ignore_errors': True, u'listen': u'start'}}
    handler_task_include_obj_0 = HandlerTaskInclude.load(**method_kwargs)
    print(handler_task_include_obj_0)


# Generated at 2022-06-25 05:14:07.593222
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    # TODO: load() doesn't work without passing required variables
    # handler_task_include_0.load(
    #     data,
    #     block=None,
    #     role=None,
    #     task_include=None,
    #     variable_manager=None,
    #     loader=None
    # )


# Generated at 2022-06-25 05:14:08.931049
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude.load(data=None)
    assert handler_task_include_0 != None

# Generated at 2022-06-25 05:14:10.665653
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude(block=None, role='role', task_include=None)

# Generated at 2022-06-25 05:14:16.771475
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # assert handler_task_include_0 is not None
    handler_task_include_1 = HandlerTaskInclude(block=None)
    # assert handler_task_include_1 is not None
    handler_task_include_2 = HandlerTaskInclude(block=None, role=None)
    # assert handler_task_include_2 is not None
    handler_task_include_3 = HandlerTaskInclude(block=None, role=None, task_include=None)
    # assert handler_task_include_3 is not None
    handler_task_include_4 = HandlerTaskInclude(block=None, role=None, task_include=None, loader=None)
    # assert handler_task_include_4 is not None


# Generated at 2022-06-25 05:14:22.892583
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None, "can't construct HandlerTaskInclude instance"
    assert isinstance(handler_task_include_0, HandlerTaskInclude), "handler_task_include_0 is not an instance of class HandlerTaskInclude"


# Generated at 2022-06-25 05:14:27.121250
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    handler = handler_task_include_1.load()


# Generated at 2022-06-25 05:14:28.224702
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:35.017748
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1_id = id(handler_task_include_1)

    handler = handler_task_include_1.load(data = '', block = '', role = '', task_include = '', variable_manager = '', loader = '')
    assert handler == handler_task_include_1
    assert id(handler) == handler_task_include_1_id

# Generated at 2022-06-25 05:14:40.544632
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    data = '''---
- name: test
  somevar: foo
'''
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = handler_task_include_1.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 05:14:42.154448
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude.load(data=dict(
        name="cat",
        src="~/.ansible/tmp/foo",
        remote_src=False,
        fail_on_missing=False,
    ))


# Generated at 2022-06-25 05:14:47.796206
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    data = {'include': {'tasks': 'tasks'}}
    block = {}
    role = {}
    task_include = {}
    variable_manager = {}
    loader = {}
    handler = handler_task_include_0.load(data, block, role, task_include, variable_manager, loader)
    assert handler == handler_task_include_0


# Generated at 2022-06-25 05:14:49.229581
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:52.624384
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

    # 1. function params_to_args
    # 2. function validate
    # 3. function copy
    # 4. function load
    # 5. function check_options

    pass


# Generated at 2022-06-25 05:14:53.834915
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.load() == None

# Generated at 2022-06-25 05:15:00.923518
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = handler_task_include_0.load(
        {
            'hosts': 'localhost',
            'connection': 'local',
            'become': None,
            'roles': {
                'app': {
                    'handlers': {
                        'main': {
                            'include': {
                                'tasks': ['test-include.yml']
                            }
                        }
                    }
                }
            }
        },
        block='main',
        role='app'
    )

    assert handler_task_include_1.get_name == 'MAIN'
    assert handler_task_include_1.tasks[0].name == 'TEST-INCLUDE.YML'