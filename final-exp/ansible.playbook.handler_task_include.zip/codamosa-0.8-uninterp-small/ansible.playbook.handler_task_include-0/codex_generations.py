

# Generated at 2022-06-25 05:13:38.505069
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-25 05:13:49.215970
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # simple case for vars
    handler_task_include = HandlerTaskInclude()
    handler_task_include.playbook = ""
    handler_task_include.play = ""
    handler_task_include.vars = []

# Generated at 2022-06-25 05:13:57.724519
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  # Parameters
    data = 0
    block = 0
    role = 0
    task_include = 0
    variable_manager = 0
    loader = 0
    # Return value
    handler_task_include_load_return_value = 0
    # Execution
    handler_task_include_load_return_value = HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    # Verification
    assert handler_task_include_load_return_value == 0


# Generated at 2022-06-25 05:13:59.187174
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include_1 = HandlerTaskInclude()
    assert handler_task_include_1.task_include is None

# Generated at 2022-06-25 05:14:05.544814
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

    assert handler_task_include._block is None
    assert handler_task_include._role is None
    assert handler_task_include._task_include is None
    assert handler_task_include.include is None
    assert handler_task_include.name is None
    assert handler_task_include.loop is None
    assert handler_task_include.when is None
    assert handler_task_include.tags is None
    assert handler_task_include.errors is None
    assert handler_task_include.always is None
    assert handler_task_include.other_block is None
    assert handler_task_include.static is None
    assert handler_task_include.static_vars is None
    assert handler_task_include.parent is None
    assert handler_task_include.default_v

# Generated at 2022-06-25 05:14:07.264529
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:08.594207
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude.load({},{})
    assert isinstance(handler_task_include_1,HandlerTaskInclude)

# Generated at 2022-06-25 05:14:13.085440
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    # handler_task_include_0.task_include = TaskInclude()
    handler_task_include_0.block = {}
    # handler_task_include_0.task_include.file = 'test'
    handler_task_include_0.VALID_INCLUDE_KEYWORDS = set(('test'))
    assert handler_task_include_0.load('test') == False

# Generated at 2022-06-25 05:14:13.811232
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:14.734006
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:21.646041
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_1 = HandlerTaskInclude()
    assert(handler_task_include_1 is not None)


# Generated at 2022-06-25 05:14:23.666349
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

    handler_task_include_0.load()

    assert True

# Generated at 2022-06-25 05:14:26.518382
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    assert False, "Test Not Implemented"


# Generated at 2022-06-25 05:14:28.912248
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.__class__.__name__ == 'HandlerTaskInclude'
    assert isinstance(handler_task_include_0,Handler)

# Generated at 2022-06-25 05:14:29.529081
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:14:32.505377
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert(handler_task_include != None)


# Generated at 2022-06-25 05:14:36.107310
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()



# Generated at 2022-06-25 05:14:37.521370
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:38.447424
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.get_name() == 'handler'



# Generated at 2022-06-25 05:14:40.637100
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert isinstance(handler_task_include_0, HandlerTaskInclude)



# Generated at 2022-06-25 05:14:45.169670
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    print(handler_task_include_0)


# Generated at 2022-06-25 05:14:54.270804
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()
    handler_task_include_2.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    handler = handler_task_include_1.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-25 05:14:54.997900
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-25 05:14:58.133397
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)

# Generated at 2022-06-25 05:15:00.155577
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(None)
    assert type(var_0) == HandlerTaskInclude


# Generated at 2022-06-25 05:15:04.920306
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    result = HandlerTaskInclude()
    assert (result.listen is None)
    assert (result.block is None)
    assert (result.role is None)
    assert (result.task_include is None)


# Generated at 2022-06-25 05:15:07.962770
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = {"parameters": "a param"}
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(set_1)



# Generated at 2022-06-25 05:15:09.995439
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        test_case_0()
    except Exception as e:
        assert False, str(e)
    assert True

# Generated at 2022-06-25 05:15:16.131667
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(set_1)
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load(set_1)
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:15:17.661450
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    print(handler_task_include_0)


# Generated at 2022-06-25 05:15:26.682554
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude(set_1, set_0)    
    handler_task_include_0.set_loader_options(set_1)

# Generated at 2022-06-25 05:15:27.655893
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-25 05:15:30.597934
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)

# Generated at 2022-06-25 05:15:33.166480
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    var_0 = HandlerTaskInclude()
    var_1 = None
    var_2 = {var_1, var_1, var_1, var_1}
    var_3 = var_0.load(var_2)



# Generated at 2022-06-25 05:15:38.354070
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)
    set_2 = {set_0, set_0, set_0, set_0}
    handler_task_include_1 = HandlerTaskInclude()
    var_1 = handler_task_include_1.load(set_2, block=set_1)
    set_3 = {set_0, set_0, set_0, set_0}
    handler_task_include_2 = HandlerTaskInclude()
    var_2 = handler_task_include_2.load(set_3, block=set_1, role=set_2)


# Generated at 2022-06-25 05:15:41.433461
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  var_0 = HandlerTaskInclude()
  set_0 = None
  set_1 = {set_0, set_0, set_0, set_0}
  var_1 = var_0.load(set_1)


# Generated at 2022-06-25 05:15:46.353613
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)

# Generated at 2022-06-25 05:15:55.027496
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # task_include_0
    task_include_0 = TaskInclude()
    # handler_task_include_0
    handler_task_include_0 = HandlerTaskInclude(task_include_0)


if __name__ == "__main__":
    import sys
    import __main__
    if __name__ != '__main__':
        print('running as imported module')
    else:
        print('running as main program')
        test_case_0()

        test_HandlerTaskInclude()

# Generated at 2022-06-25 05:15:57.613532
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None
    assert isinstance(handler_task_include_0, HandlerTaskInclude)


# Generated at 2022-06-25 05:16:03.427006
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = {'run_once': 'when'}
    set_1 = {'include': 'when'}
    handler_task_include_0 = HandlerTaskInclude(
        block=set_0,
        task_include=set_1
    )
    print(repr(handler_task_include_0))



# Generated at 2022-06-25 05:16:16.587852
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_1 = {0, 0, 0, 0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)

# Generated at 2022-06-25 05:16:20.559193
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {None, None, None, None}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:16:23.193264
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude()
    h.load(None)

# Generated at 2022-06-25 05:16:27.115620
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:16:31.683803
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    data = set_1
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(data)

# Generated at 2022-06-25 05:16:34.044200
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

    data_0 = {}

    try:
        handler_task_include_0.load(data_0)
    except:
        pass


# Generated at 2022-06-25 05:16:37.008234
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = {'name': 'test_0', 'children': []}
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:16:43.903538
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)


test_case_0()
test_HandlerTaskInclude()

# Generated at 2022-06-25 05:16:48.065558
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = set()
    dict_0 = dict()
    dict_1 = dict()
    dict_0['data'] = dict_1
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(dict_0)

# Generated at 2022-06-25 05:16:48.559241
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:17:12.967572
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.get_handler_name()
    var_1 = handler_task_include_0.get_name()


# Generated at 2022-06-25 05:17:20.991531
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = {'r'}
    set_1 = {set_0, set_0, set_0, set_0}
    set_2 = {'t'}
    set_3 = {set_2, set_2, set_2, set_2}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_3)

# Generated at 2022-06-25 05:17:27.080605
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:17:27.831547
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:17:32.007286
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = None
    set_1 = set()
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)

# Generated at 2022-06-25 05:17:38.804920
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    arg_0 = set()
    arg_1 = None
    arg_2 = None
    arg_3 = None
    arg_4 = None
    arg_5 = None
    obj_0 = HandlerTaskInclude.load(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)

    assert obj_0 is not None
    assert str(type(obj_0)) == "<class 'ansible.playbook.handler.HandlerTaskInclude'>"


# Generated at 2022-06-25 05:17:47.574653
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import pytest
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    with pytest.raises(TypeError):
        HandlerTaskInclude(block='')
    with pytest.raises(TypeError):
        HandlerTaskInclude(block='')
    with pytest.raises(TypeError):
        HandlerTaskInclude(block='')
    with pytest.raises(TypeError):
        HandlerTaskInclude(block='', role='')
    with pytest.raises(TypeError):
        HandlerTaskInclude(block='', role='', task_include='')
    HandlerTaskInclude(block=Block(), role=Role(), task_include=Task())

# Generated at 2022-06-25 05:17:54.269586
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    int_0 = handler_task_include_0.load(set_1)
    assert int(0) == int_0

# Generated at 2022-06-25 05:17:58.243083
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)

# Generated at 2022-06-25 05:18:02.545746
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'data': [34, 65, 5, 9, 1, 42], 'data_1': [
        24, 16, 9, 10, 69, 8, 9, 5, 34, 2, 9]}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(data)


# Generated at 2022-06-25 05:18:46.938083
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("In load...")
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:18:47.467653
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-25 05:18:53.087459
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # define a set of valid options
    block = {}
    role = {}
    task_include = {}

    handler_task_include = HandlerTaskInclude(block, role, task_include)
    assert(handler_task_include.block == block)
    assert(handler_task_include.role == role)
    assert(handler_task_include.task_include == task_include)


# Generated at 2022-06-25 05:19:00.122708
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    assert handler_task_include_0.load() != handler_task_include_1.load()
    assert handler_task_include_0.load() != handler_task_include_1.load()
    assert handler_task_include_0.load() != handler_task_include_1.load()
    assert handler_task_include_0.load() != handler_task_include_1.load()
    assert handler_task_include_0.load() != handler_task_include_1.load()
    set_0 = True
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0

# Generated at 2022-06-25 05:19:09.209747
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # local variable "data"
    data = {'data': 'This is a sample string'}
    data_0 = {'data': 'This is a sample string'}
    # local variable "block"
    block = {'block': 'This is a sample string'}
    block_0 = {'block': 'This is a sample string'}
    # local variable "role"
    role = {'role': 'This is a sample string'}
    role_0 = {'role': 'This is a sample string'}
    # local variable "task_include"
    task_include = {'task include': 'This is a sample string'}
    task_include_0 = {'task include': 'This is a sample string'}

    # object of class HandlerTaskInclude

# Generated at 2022-06-25 05:19:14.462954
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:19:16.642445
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)
    assert var_0 is not None


# Generated at 2022-06-25 05:19:18.931472
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:19:22.267346
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create an instance of HandlerTaskInclude
    handler_task_include_1 = HandlerTaskInclude()
    # Load the data in handler_task_include_1
    result = handler_task_include_1.load(data)
    # Check the value of the result
    assert result == True


# Generated at 2022-06-25 05:19:24.959179
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:20:55.425615
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude()



# Generated at 2022-06-25 05:20:59.660595
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(set_1)


# Generated at 2022-06-25 05:21:02.128089
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False # TODO: implement your test here



# Generated at 2022-06-25 05:21:05.292880
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    dict_0 = {}
    handler_task_include_0 = HandlerTaskInclude()
    ansible_playbook_handler_0 = handler_task_include_0.load(dict_0)
    print(ansible_playbook_handler_0.block)


# Generated at 2022-06-25 05:21:07.505244
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)
    
    

# Generated at 2022-06-25 05:21:14.219513
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}

    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)

# Generated at 2022-06-25 05:21:19.289537
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)

if __name__ == '__main__':
    test_HandlerTaskInclude_load()
    test_case_0()

# Generated at 2022-06-25 05:21:23.648689
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:21:27.748716
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = None
    set_1 = {set_0, set_0, set_0, set_0}
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_1)

# Generated at 2022-06-25 05:21:31.671809
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # dummy test
    # assert 1 == 1
    assert 1 == 1

