

# Generated at 2022-06-25 05:13:44.105505
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude.load()
    assert handler_task_include_0.uuid == 'f55c6606-15e9-4d38-86be-f99c96efaeea'



# Generated at 2022-06-25 05:13:51.417180
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude.load(data=dict(
        # first_handler
        name="first_handler",
        # /usr/local/ansible/library/test_handler.yaml
        include='/usr/local/ansible/library/test_handler.yaml',
    ), variable_manager=None, loader=None, block=None, task_include=None, role=None)
    assert handler_task_include_0.include is '/usr/local/ansible/library/test_handler.yaml'
    assert handler_task_include_0.static_include is False
    assert handler_task_include_0.static_import is False
    assert handler_task_include_0.static is False
    assert handler_task_include_0.parent is None


# Generated at 2022-06-25 05:13:54.960807
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

    handler_task_include_0.load()


# Generated at 2022-06-25 05:13:57.623286
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("In test_HanlderTaskInclude_load")
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:03.060976
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude({})
    handler_task_include_2 = HandlerTaskInclude({"include": "* & !leaf1", "ignore_errors": True})
    handler_task_include_3 = HandlerTaskInclude(block="block_1", role="role_1", task_include="task_include_1")
    handler_task_include_4 = HandlerTaskInclude()
    handler_task_include_4.exclude_hosts = ["leaf1"]
    handler_task_include_4.include_hosts = ["*"]


# Generated at 2022-06-25 05:14:04.544612
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:14:10.344275
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    data = {}
    block = HandlerTaskInclude()
    role = HandlerTaskInclude()
    task_include = HandlerTaskInclude()
    variable_manager = HandlerTaskInclude()
    loader = HandlerTaskInclude()
    handler = handler_task_include_1.load(data, block, role, task_include, variable_manager, loader)
    assert handler is not None


# Generated at 2022-06-25 05:14:12.262181
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    # test_case_0
    handler_task_include_0 = HandlerTaskInclude.load(data)


# Generated at 2022-06-25 05:14:19.870265
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test the method load of class HandlerTaskInclude
    """
    data = {}
    handler_task_include_0 = HandlerTaskInclude.load(
        data=data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert handler_task_include_0 is not None


# Generated at 2022-06-25 05:14:23.955092
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None
    print("Testcase test_HandlerTaskInclude : PASSED!")


# Generated at 2022-06-25 05:14:26.889202
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-25 05:14:32.753117
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    h = HandlerTaskInclude.load(
        data={
            "include":
                {
                "file": "test_string"
                },
            "role": "test_string",
            "block":
                {
                "expand": "False"
                }
            }
        )

    h = HandlerTaskInclude.load(
        data={
            "include":
                {
                "name": "test_string"
                },
            "role": "test_string",
            "block":
                {
                "expand": "False"
                }
            }
        )


# Generated at 2022-06-25 05:14:34.471704
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude.load()

# Generated at 2022-06-25 05:14:42.998285
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

    try:
        handler_task_include_0.load('/path/to/file')
    except Exception as e:
        assert(False)

    try:
        handler_task_include_0.load('/path/to/file', variable_manager='')
    except Exception as e:
        assert(False)

    try:
        handler_task_include_0.load('/path/to/file', variable_manager='', loader='')
    except Exception as e:
        assert(False)
    assert(handler_task_include_0)

# Generated at 2022-06-25 05:14:45.800560
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    context = dict()
    assert isinstance(handler_task_include_1.load(context), HandlerTaskInclude)


# Generated at 2022-06-25 05:14:46.426054
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    return

# Generated at 2022-06-25 05:14:50.786984
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    data = {"block": "block"}
    block = "block"
    role = "role"
    task_include = "task_include"
    variable_manager = "variable_manager"
    loader = "loader"
    handler_task_include_0 = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-25 05:14:52.854796
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include = HandlerTaskInclude()

    assert handler_task_include is not None, 'HandlerTaskInclude object is not created'



# Generated at 2022-06-25 05:14:53.409820
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:14:55.303143
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None


# Generated at 2022-06-25 05:15:01.610314
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    HandlerTaskInclude().load(data)
    

# Generated at 2022-06-25 05:15:09.662886
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = ['c', 'l', '1', 'u', '-', 'e', '1', 'p', 'o', 'z']
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = -1746193632
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)

if __name__ == "__main__":
    test_case_0()
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:15:14.143380
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    list_0 = []
    handler_task_include_1 = HandlerTaskInclude()
    int_0 = 7166
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)

# Generated at 2022-06-25 05:15:15.316746
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()



# Generated at 2022-06-25 05:15:17.649387
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False
    #t = HandlerTaskInclude()
    #int_0 = t.load(str_0, list_0, int_1, str_1, str_2)
    #assert int_0 == 0


# Generated at 2022-06-25 05:15:26.578865
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    assert var_0.name == "handler_task_include_0"
    assert var_0._parent == "handler_task_include_0,int_0,handler_task_include_0,list_0"


# Generated at 2022-06-25 05:15:30.347332
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude(Handler(), HandlerTaskInclude())
    try:
        handler = handler_task_include_0.load(handler_task_include_0, handler_task_include_0)
        assert 0
    except:
        assert 1


# Generated at 2022-06-25 05:15:33.594381
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)

# Generated at 2022-06-25 05:15:36.277897
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    list_0 = []
    int_0 = 1576
    list_1 = []
    handler_task_include_1 = handler_task_include_0.load(list_0, int_0, list_0, list_1)
    assert handler_task_include_1 is not None

# Generated at 2022-06-25 05:15:45.988380
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Unit test for parameter data of method load of class HandlerTaskInclude
    data_0 = {
      "listen": "restart nginx"
    }
    # Unit test for parameter block of method load of class HandlerTaskInclude
    block_0 = {
      "listen": "restart nginx"
    }
    # Unit test for parameter role of method load of class HandlerTaskInclude
    role_0 = {
      "listen": "restart nginx"
    }
    # Unit test for parameter task_include of method load of class HandlerTaskInclude
    task_include_0 = {
      "listen": "restart nginx"
    }
    # Unit test for parameter variable_manager of method load of class HandlerTaskInclude

# Generated at 2022-06-25 05:16:01.802354
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = ['z+', '\x10\x10\x00\x12', 'O1', 'L\x0e\x08', '', '@Zr', '\x0b5']
    handler_task_include_0 = HandlerTaskInclude(list_0)
    list_1 = ['\x1c\x00', '', '\ot', 'C-\t', '\n', '', '\r', '\r\r']
    int_0 = 731
    handler_task_include_1 = HandlerTaskInclude()
    try:
        var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_1)
    except NotImplementedError:
        print('FAIL')

# Generated at 2022-06-25 05:16:08.809307
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    assert not hasattr(handler_task_include_0, 'block')
    assert not hasattr(handler_task_include_0, 'role')
    assert not hasattr(handler_task_include_0, 'task_include')


# Generated at 2022-06-25 05:16:15.551342
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_1 = []
    handler_task_include_0 = HandlerTaskInclude(list_1)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_1)

# Generated at 2022-06-25 05:16:25.422921
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude(handler_task_include_0, handler_task_include_0, handler_task_include_0, handler_task_include_0)
    handler_task_include_2 = HandlerTaskInclude()
    handler_task_include_0 = handler_task_include_2.load(handler_task_include_1, handler_task_include_1, handler_task_include_1, handler_task_include_0, handler_task_include_0, handler_task_include_1)


# Generated at 2022-06-25 05:16:27.744024
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    assert isinstance(handler_task_include_0, HandlerTaskInclude) == True


# Generated at 2022-06-25 05:16:32.604579
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_1 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)

# Generated at 2022-06-25 05:16:40.792265
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    char_0 = u'g{"P8'
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, char_0, list_0, handler_task_include_0, list_0)
    # FAIL: expected <TaskInclude> but got <HandlerTaskInclude>
    assert not var_0
    str_0 = u'5,5\\_25'
    handler_task_include_2 = HandlerTaskInclude()
    var_1 = handler_task_include_2.load(str_0, handler_task_include_1, list_0, handler_task_include_0, list_0)


# Generated at 2022-06-25 05:16:50.042368
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 607
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    var_1 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    var_2 = handler_task_include_1.check_options(handler_task_include_0, list_0)
    str_0 = handler_task_include_1._load_block_var('s h', handler_task_include_0)
    str_1 = handler_task_

# Generated at 2022-06-25 05:16:51.386797
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:16:55.455685
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-25 05:17:09.073189
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert False, "Test if the object is an instance of a define class"



# Generated at 2022-06-25 05:17:09.816365
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

# Generated at 2022-06-25 05:17:13.277629
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)

    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:17:20.799513
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)


# Generated at 2022-06-25 05:17:32.268245
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 724
    handler_task_include_1 = HandlerTaskInclude(int_0)
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    var_1 = handler_task_include_1.copy(handler_task_include_0, handler_task_include_0)
    int_1 = 5304
    handler_task_include_2 = HandlerTaskInclude(int_1)
    var_2 = handler_task_include_1.check_options(handler_task_include_2, handler_task_include_1)


# Generated at 2022-06-25 05:17:33.818655
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert callable(HandlerTaskInclude.load)
    assert HandlerTaskInclude.load
    test_case_0()

# Generated at 2022-06-25 05:17:42.362215
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    var_1 = handler_task_include_1.check_options(var_0, list_0)
    handler_task_include_2 = HandlerTaskInclude(list_0)
    handler_task_include_3 = HandlerTaskInclude(list_0, list_0)
    handler_task_include_4 = HandlerTaskInclude(list_0, list_0, list_0)

# Generated at 2022-06-25 05:17:45.608606
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True == True


# Generated at 2022-06-25 05:17:47.090436
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)


# Generated at 2022-06-25 05:17:54.747498
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    assert var_0 == None

# Generated at 2022-06-25 05:18:16.078750
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)

# Generated at 2022-06-25 05:18:24.434680
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)

    # Test attribute 'block'
    handler_task_include_1 = HandlerTaskInclude()
    assert handler_task_include_1.block is None

    handler_task_include_2 = HandlerTaskInclude()
    list_0 = []
    handler_task_include_2.block = list_0
    assert handler_task_include_2.block is not None

    # Test attribute 'task_include'
    handler_task_include_3 = HandlerTaskInclude()
    assert handler_task_include_3.task_include is None

    handler_task_include_4 = HandlerTaskInclude()
    list_0 = []
    handler_task_include_4.task_include = list_0
    assert handler_

# Generated at 2022-06-25 05:18:30.576477
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)

    assert var_0 == handler_task_include_1


# Generated at 2022-06-25 05:18:35.166035
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    assert isinstance(var_0, HandlerTaskInclude)


# Generated at 2022-06-25 05:18:39.430800
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)


# Generated at 2022-06-25 05:18:45.651974
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-25 05:18:55.056759
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Define variables and configure object
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)

    # Check for valid object type
    if not isinstance(handler_task_include_0, HandlerTaskInclude) or not isinstance(handler_task_include_1, HandlerTaskInclude):
        raise Exception("Object constructor test failed!")

if __name__ == "__main__":
    test_case_0()
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:19:02.469486
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)


# Generated at 2022-06-25 05:19:04.501254
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    assert isinstance(handler_task_include_0, HandlerTaskInclude)

# Generated at 2022-06-25 05:19:08.665244
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    dict_0 = dict()
    handler_task_include_1 = HandlerTaskInclude.load(dict_0)
    assert handler_task_include_1.vars is dict_0


# Generated at 2022-06-25 05:19:54.474120
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass  #TODO: implement your test here


# Generated at 2022-06-25 05:19:59.994792
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data_0 = HandlerTaskInclude()
    block_0 = ''
    role_0 = ''
    task_include_0 = ''
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    handler_task_include_0 = HandlerTaskInclude()
    dict_0 = dict()
    handler_task_include_1 = handler_task_include_0.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)
    handler_task_include_1.check_options(dict_0, dict_0)


# Generated at 2022-06-25 05:20:06.504529
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    assert False # FIXME: implement your test here


# Generated at 2022-06-25 05:20:08.312613
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        list_0 = []
        handler_task_include_0 = HandlerTaskInclude(list_0)
        assert False
    except RuntimeError as e:
        assert True
    try:
        handler_task_include_0 = HandlerTaskInclude()
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-25 05:20:10.983938
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    int_0 = 1
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, handler_task_include_0)
    del handler_task_include_1
    # Test for equality: string_0 and string_1
    assert var_0 != "CkZs", "test_HandlerTaskInclude_load"

# Generated at 2022-06-25 05:20:17.383422
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    assert var_0 == 0


# Generated at 2022-06-25 05:20:21.292629
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.get_name() == u'include'
    assert handler_task_include_0.listen is None
    assert handler_task_include_0.hashed_file is None
    assert handler_task_include_0.loop is None
    assert handler_task_include_0.loop_args is None
    assert handler_task_include_0.loop_control is None
    assert handler_task_include_0.loop_with is None
    assert handler_task_include_0.loop_with_fileglob is None
    assert handler_task_include_0.loop_with_index is None
    assert handler_task_include_0.loop_with_index_var is None
    assert handler_task_include_0.loop_

# Generated at 2022-06-25 05:20:25.468416
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    assert var_0 == HandlerTaskInclude()


# Generated at 2022-06-25 05:20:31.404452
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0)


# Generated at 2022-06-25 05:20:35.383700
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # list_0 = []
    handler_task_include_0 = HandlerTaskInclude()
    # int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, 1576, handler_task_include_0, [])


# Generated at 2022-06-25 05:22:12.877112
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)

# Generated at 2022-06-25 05:22:15.136468
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-25 05:22:18.451730
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude.load(handler_task_include_1, handler_task_include_0, int_0, list_0)

# Generated at 2022-06-25 05:22:22.455214
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    data_0 = []
    block_0 = None
    role_0 = None
    task_include_0 = None
    variable_manager_0 = None
    loader_0 = None
    handler_task_include_0.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:22:25.393588
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
    assert var_0 is None

test_case_0()

# Generated at 2022-06-25 05:22:28.466000
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 564
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)


# Generated at 2022-06-25 05:22:33.560710
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 645
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)


if __name__ == "__main__":
    var_0 = test_case_0()
    test_HandlerTaskInclude_load()

    print(var_0)

# Generated at 2022-06-25 05:22:39.420809
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)

# Generated at 2022-06-25 05:22:45.837117
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # 
    handler_task_include_data = {}
    # 
    handler_task_include_block = None
    # 
    handler_task_include_role = None
    # 
    handler_task_include_task_include = None
    # 
    handler_task_include_variable_manager = None
    # 
    handler_task_include_loader = None
    # 
    handler_task_include_0 = HandlerTaskInclude(handler_task_include_data, handler_task_include_block, handler_task_include_role, handler_task_include_task_include)

# Generated at 2022-06-25 05:22:48.224503
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = []
    handler_task_include_0 = HandlerTaskInclude(list_0)
    int_0 = 1576
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, int_0, handler_task_include_0, list_0)
