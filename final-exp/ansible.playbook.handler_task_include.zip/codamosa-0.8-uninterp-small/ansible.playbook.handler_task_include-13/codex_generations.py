

# Generated at 2022-06-25 05:13:42.540224
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    # None is not implemented
    pass

# Generated at 2022-06-25 05:13:46.299204
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    bool_0 = False
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    handler_task_include_0.load(dict_0, dict_1, dict_2)



# Generated at 2022-06-25 05:13:49.119753
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  # data is of type dict:
  #    role=None, loader=None, task_include=None, block=None, variable_manager=None
  handler_task_include_1 = HandlerTaskInclude.load()

# Generated at 2022-06-25 05:13:51.285100
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    map_0 = {}
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    handler_task_include_0.load(map_0)


# Generated at 2022-06-25 05:13:58.987321
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data_0 = {"include" : {"with_items": [1, 2, 3, 4], "include": "foobar.yml"}}
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    dict_0 = handler_task_include_0.load_data(data_0)
    handler_task_include_0.check_options(dict_0, data_0)


# Generated at 2022-06-25 05:14:05.416707
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    bool_0 = True
    bool_1 = False
    data_0 = {'include': '', 'tasks': [{'name': 'foo'}], 'tags': ['a']}
    assert HandlerTaskInclude.load(data_0, bool_0) == handler_task_include_0
    assert HandlerTaskInclude.load(data_0, bool_1) == handler_task_include_0
    assert HandlerTaskInclude.load(data_0, bool_0) != handler_task_include_0
    assert HandlerTaskInclude.load(data_0, bool_1) != handler_task_include_0

# Generated at 2022-06-25 05:14:11.705374
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    string_0 = '_'
    string_1 = 'file'
    string_2 = ''
    string_3 = 'r'

    with open(string_2, string_3, 1) as handle_0:
        string_4 = handle_0.read()
    data_0 = string_4
    HandlerTaskInclude.load(data_0)


# Generated at 2022-06-25 05:14:23.239405
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class_0 = HandlerTaskInclude()
    # Tests for methods of the same name in class TaskInclude
    bool_0 = True
    bool_1 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    list_0 = ['include', 'fail', 'ignore_errors']
    str_0 = 'ignore_errors'
    str_1 = 'include'
    str_2 = 'ignore_errors'
    str_3 = 'include'
    str_4 = 'ignore_errors'
    # Test with required argument (data)
    test_data_0 = {"handler": "slack", "listen": "slack-big-news"}
    result_0 = HandlerTaskInclude.load(test_data_0)

# Generated at 2022-06-25 05:14:29.627845
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    dict_0 = dict()
    block_0 = None
    role_0 = None
    task_include_0 = None
    variable_manager_0 = None
    loader_0 = None
    handler_task_include_0.load(dict_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 05:14:37.235453
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    data_0 = {}
    block_0 = None
    role_0 = None
    task_include_0 = None
    variable_manager_0 = None
    loader_0 = None
    handler = HandlerTaskInclude.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)
    assert handler is not None


# Generated at 2022-06-25 05:14:42.419436
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-25 05:14:44.551615
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0._attributes['listen'] == 'Not Implemented'

# Generated at 2022-06-25 05:14:49.914684
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()

    assert handler_task_include_1.load()

    # Fails because of missing argument "data"
    # handler_task_include_1.load(data)
    # Fails because of missing argument "data"
    # handler_task_include_1.load(data)
    # Fails because of missing argument "data"
    # handler_task_include_1.load(data)

# Generated at 2022-06-25 05:14:54.709554
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.static != {}
    assert handler_task_include_0.load_data != {}
    assert handler_task_include_0.check_type != {}
    assert handler_task_include_0.check_options != {}
    assert handler_task_include_0.load_tasks_from_files != {}
    assert handler_task_include_0.load_tasks_from_file != {}

# Generated at 2022-06-25 05:14:58.834635
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_0 = HandlerTaskInclude()
    data = {'tasks': [{'include_tasks': 'test_value'}]}
    variable_manager = Mock()
    loader = Mock()
    handler = handler_task_include_0.load(data, variable_manager, loader)
    #assert handler.tasks[0].include_filename == 'test_value'



# Generated at 2022-06-25 05:15:00.582058
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-25 05:15:04.996174
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    handler = handler_task_include.load(data='', block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-25 05:15:07.186694
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(block='TEST_BLOCK')
    assert handler_task_include.__class__.__name__ == 'HandlerTaskInclude'
    assert handler_task_include._block == 'TEST_BLOCK'



# Generated at 2022-06-25 05:15:11.671992
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()

if __name__ == "__main__":
    test_case_0()
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:15:13.336311
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()

    # Check the return value of method load
    assert handler_task_include_1.load() == None


# Generated at 2022-06-25 05:15:17.642758
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert isinstance(HandlerTaskInclude(), HandlerTaskInclude)


# Generated at 2022-06-25 05:15:20.962725
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude(listen=None, tags=None, only_tags=False, skip_tags=False)
    print(handler_task_include)


# Generated at 2022-06-25 05:15:22.211051
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    x=HandlerTaskInclude()
    assert(x.load())

# Generated at 2022-06-25 05:15:26.739310
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    assert handler_task_include_1 is not None


# Generated at 2022-06-25 05:15:28.905225
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert isinstance(handler_task_include_0, TaskInclude)


# Generated at 2022-06-25 05:15:30.022230
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()


# Generated at 2022-06-25 05:15:35.610081
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    handler_task_include_load = handler_task_include.load()


# Generated at 2022-06-25 05:15:45.967920
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    TEMP = dict(
        type="listen",
        name="rabbitmq",
        tags=["rabbitmq"],
        notify=["restart rabbitmq"]
    )

# Generated at 2022-06-25 05:15:48.655159
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()

    assert handler_task_include_1.load() is False



# Generated at 2022-06-25 05:15:50.301178
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    objHandlerTaskInclude = HandlerTaskInclude()
    objHandlerTaskInclude.load()

# Generated at 2022-06-25 05:16:04.692916
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.VALID_INCLUDE_KEYWORDS = set(('vars',))
    handler_task_include_1.load()
    handler_task_include_1.VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.VALID_INCLUDE_KEYWORDS = set(('tasks',))
    handler_task_include_1.load()
    handler_task_include_1.VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS
    handler_task_include_1 = HandlerTaskInclude

# Generated at 2022-06-25 05:16:05.990941
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:16:07.411728
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude(  )
    assert handler_task_include_0 is not None

# Generated at 2022-06-25 05:16:12.534623
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_data = {
        'include': 'include.yml',
        'vars': {'some_var': 4, 'some_other_var': [1, 'a', 5], 'var_with_no_value': None},
        'tags': ['tag1', 'tag2', 'tag3'],
        'ignore_errors': False,
        'force_handlers': True,
        'always_run': False,
    }
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load(test_data, block=[], role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-25 05:16:15.176592
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

    # Check if the method load is callable
    assert callable(getattr(HandlerTaskInclude, "load")) == True


# Generated at 2022-06-25 05:16:18.057977
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include = HandlerTaskInclude()
    result = handler_task_include.load()
    assert result is None



# Generated at 2022-06-25 05:16:19.898462
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
#    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-25 05:16:25.713567
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = handler_task_include_0.load(data={}, block={}, role={}, task_include={}, variable_manager={}, loader={})
    assert isinstance(handler_task_include_1, HandlerTaskInclude)


# Generated at 2022-06-25 05:16:26.553519
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:16:34.863689
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    data_0 = dict({'import_playbook': '/etc/ansible/playbooks/check_seafile.yml'})
    block_0 = None
    role_0 = None
    task_include_0 = None
    variable_manager_0 = None
    loader_0 = None

    assert handler_task_include_0.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0) != None, "Expected values differ!"


# Generated at 2022-06-25 05:16:42.690348
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude(None, None, None)
    assert isinstance(handler_task_include_0, HandlerTaskInclude)


# Generated at 2022-06-25 05:16:47.023345
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)

# Generated at 2022-06-25 05:16:54.948449
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    var_0 = HandlerTaskInclude(block, role, task_include)
    data = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    tuple_0 = (None, None, None, None, None, None)
    tuple_1 = (None, None, None, None, None)
    tuple_2 = (None, None, None, None, None)
    tuple_3 = (None, None, None, None, None)
    tuple_4 = (None, None, None, None, None)
    var_1 = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert var_1 == None
    # assert var_1.__class__.__name__ == 'NoneType'


#

# Generated at 2022-06-25 05:16:58.691961
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)

# Generated at 2022-06-25 05:17:01.070527
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)


# Generated at 2022-06-25 05:17:05.432013
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None


# Generated at 2022-06-25 05:17:08.507608
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-25 05:17:13.208630
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    tuple_1 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_1 = handler_task_include_1.load(handler_task_include_0, tuple_0, tuple_1)


# Generated at 2022-06-25 05:17:14.704524
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-25 05:17:22.303191
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    Pass = True
    try:
        # Unit test for load
        handler_task_include_0 = HandlerTaskInclude()
        tuple_0 = None
        handler_task_include_1 = HandlerTaskInclude()
        var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)
    except Exception as err:
        Pass = False
        print("Test for constructor of class HandlerTaskInclude Failed")
    assert Pass
    # Unit test for load of class HandlerTaskInclude
    assert Pass is True
test_HandlerTaskInclude()

# Generated at 2022-06-25 05:17:35.748802
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_0 = HandlerTaskInclude()
    section_0 = None
    list_0 = None
    tuple_0 = None
    list_1 = []
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, section_0, list_0, tuple_0, list_1)


# Generated at 2022-06-25 05:17:39.373095
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.task_include == None
    assert handler_task_include_0.role == None
    assert handler_task_include_0.block == None


# Generated at 2022-06-25 05:17:40.215109
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # This is a stub test
    return


# Generated at 2022-06-25 05:17:45.575399
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)
    var_1 = handler_task_include_0.get_name()
    var_2 = handler_task_include_1.get_name()
    assert var_0 is None
    assert var_1 == 'tasks'
    assert var_2 == 'handlers'


# Generated at 2022-06-25 05:17:48.942411
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test method call with args: {'block': None, 'role': None, 'task_include': None}
    test_case_0()
    # Test method call with args: {'block': None, 'role': None, 'task_include': None}
    test_case_0()

# Generated at 2022-06-25 05:17:55.890167
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.set_loader(loader_0)
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.set_variable_manager(variable_manager_0)
    handler_task_include_1.set_loader(loader_1)

    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)


# Generated at 2022-06-25 05:18:01.508177
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        HandlerTaskInclude(Handler())
    except:
        print("HandlerTaskInclude constructor parameter error")
        return False
    return True


# Generated at 2022-06-25 05:18:06.255521
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None,  'HandlerTaskInclude() test failed'


# Generated at 2022-06-25 05:18:12.522053
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)

# Generated at 2022-06-25 05:18:17.105099
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)

# Generated at 2022-06-25 05:18:37.395785
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-25 05:18:40.861536
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        if HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == set(['vars', 'tasks', 'handlers', 'pre_tasks', 'post_tasks']):
            return 0
        else:
            return 1
    except Exception as e:
        return 1
    

# Generated at 2022-06-25 05:18:45.689067
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)
    assert var_0 is None


# Generated at 2022-06-25 05:18:46.652227
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_case_0()

# Generated at 2022-06-25 05:18:56.117139
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler = Handler(None)
    handler_task = HandlerTaskInclude(block=handler, task_include=None)
    assert(handler_task._play is None)

    handler = HandlerTaskInclude(block=handler, task_include=None)
    assert(handler_task._play is None)

    handler = Handler(None)
    assert(handler_task._play is None)

    handler_task = HandlerTaskInclude(block=None, task_include=handler)
    assert(handler_task._play is None)

    handler_task = HandlerTaskInclude(block=handler, task_include=handler)
    assert(handler_task._play is None)

    handler_task = HandlerTaskInclude(block=None, task_include=None)
    assert(handler_task._play is None)

    handler_task = HandlerTaskIn

# Generated at 2022-06-25 05:19:05.954956
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()
    handler_task_include_3 = HandlerTaskInclude()
    handler_task_include_4 = HandlerTaskInclude()
    var_0 = handler_task_include_4.load(handler_task_include_3, tuple_0)
    var_1 = HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    handler_task_include_5 = HandlerTaskInclude()
    tuple_1 = None
    var_2 = handler_task_include_5.load(handler_task_include_3, tuple_1)
    handler_task_include_6 = HandlerTaskInclude()
    handler

# Generated at 2022-06-25 05:19:12.279356
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert repr(handler_task_include_0) == "<HandlerTaskInclude (name=None)>"
    assert handler_task_include_0.block == None
    assert handler_task_include_0.role == None
    assert handler_task_include_0.task_include == None
    assert handler_task_include_0.only_if == None
    assert handler_task_include_0.until == None
    assert isinstance(handler_task_include_0.name, str)
    assert handler_task_include_0.notify == []
    assert handler_task_include_0.changed_when == 'False'
    assert handler_task_include_0.failed_when == 'False'
    assert handler_task_include_0.tags == []

# Generated at 2022-06-25 05:19:23.162354
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.VALID_INCLUDE_KEYWORDS == frozenset(('listen', 'include', 'tasks', 'when', 'ignore_errors', 'vars', 'delegate_to', 'delegate_facts', 'register', 'run_once', 'tags', 'name'))

# Generated at 2022-06-25 05:19:24.865464
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_2 = HandlerTaskInclude()
    handler = HandlerTaskInclude()
    handler_task_include_2.load(handler)

# Generated at 2022-06-25 05:19:29.108893
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    arg_0 = None
    tuple_0 = None
    tuple_1 = None
    var_0 = HandlerTaskInclude.load(handler_task_include_0, arg_0, tuple_0, tuple_1)
    # var_0 should be an instance of HandlerTaskInclude (or subclass)
    var_0.load()


# Generated at 2022-06-25 05:20:16.476883
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)

# Generated at 2022-06-25 05:20:23.851490
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_in = None
    data_in = None
    handler_task_include_out = HandlerTaskInclude.load(handler_task_include_in, data_in)
    assert handler_task_include_out is None

if __name__ == "__main__":
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:20:26.572301
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)


# Generated at 2022-06-25 05:20:32.208559
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)


# Generated at 2022-06-25 05:20:34.855034
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'tasks', 'listen', 'vars', 'handler'}, 'Must be TaskInclude.VALID_INCLUDE_KEYWORDS union {listen}'

# Generated at 2022-06-25 05:20:37.752571
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)


# Generated at 2022-06-25 05:20:40.731715
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)


# Generated at 2022-06-25 05:20:49.561987
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #   Variable manager has the following hash:
    #        var_manager['test_var'] = 'test_value'
    #   Test the following conditionals:
    #        'no_log': True
    #        'register': 'test_reg'
    #        'ignore_errors': True
    #        'connection': 'local'
    #        'sudo': True
    #        'sudo_user': True
    #        'run_once': True
    #        'when': True
    #        'tags': True
    #        'listen': True

    # Initialize the handler object with no data
    handler_task_include_0 = HandlerTaskInclude()

    # The StringInFile handler is not supported
    # handler_task_include_0_data = """
    # asdf
    # - string: dest=/tmp/

# Generated at 2022-06-25 05:20:51.493312
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)


# Generated at 2022-06-25 05:20:58.194898
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)
    assert var_0 == None

# Generated at 2022-06-25 05:22:38.224266
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.name = ""
    handler_task_include_0.tasks = []
    handler_task_include_0.block = ""
    handler_task_include_0.tags = []
    handler_task_include_0.skip_tags = []
    handler_task_include_0.register = ""
    handler_task_include_0.environment = ""
    handler_task_include_0.no_log = ""
    handler_task_include_0.always_run = ""
    handler_task_include_0.any_errors_fatal = ""
    handler_task_include_0.serial = ""
    handler_task_include_0.action = "include"
    handler_task_include_0.when = ""
   

# Generated at 2022-06-25 05:22:40.519717
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)

# Generated at 2022-06-25 05:22:43.265320
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)
    assert isinstance(var_0, HandlerTaskInclude) is True


# Generated at 2022-06-25 05:22:45.671516
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)


# Generated at 2022-06-25 05:22:47.716645
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)
    assert var_0 is None
    

# Generated at 2022-06-25 05:22:50.886035
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    string_0 = 'This is a string!'
    dict_0 = dict()
    dict_0['k1'] = string_0
    dict_0['k0'] = string_0
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load(handler_task_include_0, dict_0)

# Generated at 2022-06-25 05:22:52.362260
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)
    assert var_0 == None


# Generated at 2022-06-25 05:22:58.074578
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)
    print('Unit test case 3, method name: load')
    print(var_0)
    assert var_0 is not None

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:23:02.747121
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    data_0 = {}
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(data_0, tuple_0)



# Generated at 2022-06-25 05:23:05.969907
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = None
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(handler_task_include_0, tuple_0)
    pass
