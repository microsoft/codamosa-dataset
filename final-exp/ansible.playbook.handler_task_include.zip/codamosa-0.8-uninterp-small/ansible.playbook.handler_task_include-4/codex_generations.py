

# Generated at 2022-06-25 05:13:45.346947
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler_task_include = HandlerTaskInclude()
    assert handler_task_include.name == '__none__', handler_task_include.name
    assert handler_task_include.role_name == '', handler_task_include.role_name
    assert handler_task_include.tags == [], handler_task_include.tags

# Generated at 2022-06-25 05:13:46.308317
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    print("Success: HandlerTaskInclude")

# Generated at 2022-06-25 05:13:48.594502
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    result = handler_task_include_0.load()


# Generated at 2022-06-25 05:13:51.525510
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''
    def __init__(self, block=None, role=None, task_include=None):
    '''
    _task_include_0 = TaskInclude()
    handler_task_include_0 = HandlerTaskInclude(block=None, role=None, task_include=_task_include_0)

# Generated at 2022-06-25 05:13:53.513919
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:13:55.831471
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()

    assert handler_task_include_0 == handler_task_include_1

# Generated at 2022-06-25 05:14:01.934938
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include_load_1 = HandlerTaskInclude.load(data='', block=None, role=None, task_include=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 05:14:04.733914
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:14:06.184697
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load({'name': 'foo'})

# Generated at 2022-06-25 05:14:09.993356
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_1 = HandlerTaskInclude()
    data = '{"include": "tasks/a.yml"}'
    data_1 = '{"listen": "test"}'
    handler_task_include_1.check_options(handler_task_include_1.load_data(data), data)
    handler_task_include_1.check_options(handler_task_include_1.load_data(data_1), data_1)

# Generated at 2022-06-25 05:14:23.239235
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test with an invalid dict
    invalid_dict = {
        "hosts": "all",
        "include_tasks": [
            "tasks/main.yml",
            "tasks/package.yml"
        ]
    }

    handler_task_include_0 = HandlerTaskInclude()
    with pytest.raises(AnsibleParserError):
        handler_task_include_0.load(invalid_dict)

    # Test with a valid dict
    handler_task_include_1 = HandlerTaskInclude()

# Generated at 2022-06-25 05:14:29.628908
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = handler_task_include_0.load(tuple_0)
    assert handler_task_include_1 == handler_task_include_0

if __name__ == "__main__":
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:14:34.415159
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    float_0 = -653.92
    tuple_0 = (float_0,)
    HandlerTaskInclude()
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)


# Generated at 2022-06-25 05:14:37.965021
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(tuple_0)


# Generated at 2022-06-25 05:14:41.661069
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)

# Generated at 2022-06-25 05:14:44.953868
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)


# Generated at 2022-06-25 05:14:48.284972
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    float_0 = -444.01
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)


# Generated at 2022-06-25 05:14:48.867719
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:14:53.081960
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(arg=arg, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    return var_0

# Generated at 2022-06-25 05:14:55.012632
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load()


# Generated at 2022-06-25 05:15:03.715126
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
    except:
        # test case failed
        print('Test case failed.')


# Generated at 2022-06-25 05:15:05.236536
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Create an instance of HandlerTaskInclude
    handler_task_include_0 = HandlerTaskInclude()

    # Load the method
    assert handler_task_include_0.load() == None


# Generated at 2022-06-25 05:15:07.375735
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)
    assert var_0 is None, "Return value of HandlerTaskInclude.load() is not None"

# Generated at 2022-06-25 05:15:12.175053
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)
    assert var_0 != None, "handler_task_include_0.load() did not match expected value None"

if __name__ == '__main__':
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:15:15.000142
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)
    assert var_0 is not None


# Generated at 2022-06-25 05:15:16.089113
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        HandlerTaskInclude()
        assert(True)
    except:
        assert(False)


# Generated at 2022-06-25 05:15:17.772912
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_1 = handler_task_include_0.load(tuple_0)

# Generated at 2022-06-25 05:15:20.149992
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.check_options(
        handler_task_include_0.load_data(tuple_0),
        tuple_0
    )

# Generated at 2022-06-25 05:15:24.760620
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()



# Generated at 2022-06-25 05:15:26.072506
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()
# END class HandlerTaskInclude

# Generated at 2022-06-25 05:15:33.286727
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude(tuple_0)
    var_0 = handler_task_include_0.load(tuple_0)


# Generated at 2022-06-25 05:15:35.858939
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -871.17
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)

# Generated at 2022-06-25 05:15:41.868367
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Initialize a HandlerTaskInclude object
    handler_task_include_0 = HandlerTaskInclude()

    # Check all attributes
    # assert handler_task_include_0



# Generated at 2022-06-25 05:15:46.139436
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    float_1 = -467.24
    tuple_1 = (float_1,)
    handler_task_include_1 = HandlerTaskInclude()
    assert isinstance(handler_task_include_1, HandlerTaskInclude)


# Generated at 2022-06-25 05:15:50.912086
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    # Two assertions, simple and a compound 'pythonic' one
    assert isinstance(t, Handler)
    assert isinstance(t, object) and isinstance(t, HandlerTaskInclude)

# Generated at 2022-06-25 05:15:57.925015
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    float_0 = 39.15
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(tuple_0)
    #assert handler_task_include_0 is not None and handler_task_include_0.__class__ == HandlerTaskInclude
    #assert handler_task_include_0.block is None
    #assert handler_task_include_0.notify is None
    #assert handler_task_include_0.listen is None


# Generated at 2022-06-25 05:15:59.473242
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:16:02.127993
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert isinstance(handler, HandlerTaskInclude) == True

# Generated at 2022-06-25 05:16:06.029840
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:16:09.457814
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    try:
        var_0 = handler_task_include_0.load(tuple_0)
    except Exception as exception_0:
        assert type(exception_0) == ValueError

# Generated at 2022-06-25 05:16:20.276378
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load(-467.24)

# Generated at 2022-06-25 05:16:24.349756
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    float_0 = -821.20
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:16:28.946559
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)

# Generated at 2022-06-25 05:16:37.848542
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import handlers
    from ansible.playbook import handler

    data = {
        'hosts': 'all',
        'name': 'Example of handler'
    }

    var_manager = VariableManager()
    var_manager.set_inventory(
        inventory=DataLoader().load_inventory(
            inventory=['127.0.0.1']
        )
    )

    h = HandlerTaskInclude.load(data)

    assert isinstance(h, handler.HandlerTaskInclude)
    assert isinstance(h.action, handlers.Action)

# Generated at 2022-06-25 05:16:49.256807
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    float_0 = -225.14
    str_0 = str(float_0)
    tuple_0 = (str_0,)
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.load(tuple_0)
    # Should Not Throw Exception

    tuple_1 = ()
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load(tuple_1)
    # Should Not Throw Exception

if __name__ == "__main__":
    from ansible.utils.display import Display
    display = Display()
    display.deprecated('Deprecated class used in module.  Will be removed in 2.4', version=2.3)
    test_HandlerTaskInclude()
    test_case_0()

# Generated at 2022-06-25 05:16:50.878477
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert 0 == 0


# Generated at 2022-06-25 05:16:55.014236
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)



# Generated at 2022-06-25 05:16:58.519405
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Unit test for method load of class HandlerTaskInclude
    '''
    # Test 0
    test_case_0()

# Generated at 2022-06-25 05:16:59.712965
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None



# Generated at 2022-06-25 05:17:07.138925
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test Constructor method
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.__init__()
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.get_name() == 'handler', handler_task_include_0.get_name()

# Generated at 2022-06-25 05:17:33.948730
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    list_0 = []
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude(block=list_0, deps=tuple_0)
    assert handler_task_include_0 is not None
    assert len(handler_task_include_0.tags) == 0
    assert handler_task_include_0.block == list_0
    assert handler_task_include_0.always is False
    assert handler_task_include_0.never is False
    handler_task_include_0.load(tuple_0)


# Generated at 2022-06-25 05:17:35.611806
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader) == 'HandlerTaskInclude'

# Generated at 2022-06-25 05:17:40.215358
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = 10.01
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
#     HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    test_case_0()

print(test_case_0())

# Generated at 2022-06-25 05:17:47.376085
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    int_10 = -674
    str_0 = 'T@T=Lh'
    True_0 = True
    int_0 = -826
    float_4 = -4.0
    int_1 = -919
    int_6 = -746
    float_2 = -6.0
    float_0 = -8.0
    float_3 = -5.0
    int_3 = -822
    int_5 = -742
    int_7 = -745
    list_0 = [int_10, str_0, True_0, int_0, float_4, int_1, int_6, float_2, float_0, float_3, int_3, int_5, int_7]
    str_9 = 'G'

# Generated at 2022-06-25 05:17:57.676489
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # ensure a named handler can be loaded
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()
    handler_task_include_3 = HandlerTaskInclude()
    handler_task_include_4 = HandlerTaskInclude()
    handler_task_include_5 = HandlerTaskInclude()
    handler_task_include_6 = HandlerTaskInclude()
    handler_task_include_7 = HandlerTaskInclude()
    handler_task_include_8 = HandlerTaskInclude()
    handler_task_include_9 = HandlerTaskInclude()
    handler_task_include_10 = HandlerTaskInclude()
    handler_task_include_11 = HandlerTaskInclude()

# Generated at 2022-06-25 05:18:01.042686
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  handler_task_include_0 = HandlerTaskInclude()
  float_0 = -467.24
  tuple_0 = (float_0,)
  var_0 = handler_task_include_0.load(tuple_0)

# Generated at 2022-06-25 05:18:12.318855
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    float_0 = 6.9
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude(handler_task_include_0, tuple_0)
    handler_task_include_0 = HandlerTaskInclude(handler_task_include_0, tuple_0, handler_task_include_0)
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:18:16.998737
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)
    assert var_0 == float_0


# Generated at 2022-06-25 05:18:22.598668
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)
    return var_0


# Generated at 2022-06-25 05:18:24.960105
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  handler_task_include_0 = HandlerTaskInclude()
  return handler_task_include_0

# Generated at 2022-06-25 05:19:05.987802
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    HandlerTaskInclude.load(tuple_0)


# Generated at 2022-06-25 05:19:06.490931
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-25 05:19:12.648462
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Tests for when parameter 'variable_manager' is not provided
    float_0 = -467.24
    tuple_0 = (float_0,)

    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)

    # Tests for whether parameter 'variable_manager' is of correct type
    list_0 = ['elkhart', 'vera', 'nigel', 'uganda', 'travis', 'conga', 'bismarck', 'dustin', 'wade', 'alfonso', 'kitty', 'uruguay']
    assert isinstance(list_0, list)
    
    tuple_1 = (list_0,)
    handler_task_include_1 = HandlerTaskInclude()

# Generated at 2022-06-25 05:19:18.105780
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = 554.58
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)

# Generated at 2022-06-25 05:19:20.921691
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = ['tmp0']
    handler_task_include_0 = HandlerTaskInclude()
    tuple_0 = (list_0,)
    assert handler_task_include_0.load(tuple_0) == True

# Generated at 2022-06-25 05:19:22.520436
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -220.25
    tuple_0 = (float_0,)
    HandlerTaskInclude.load(tuple_0)

# Generated at 2022-06-25 05:19:23.224262
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()

# Generated at 2022-06-25 05:19:25.823410
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    float_0 = -598.76
    tuple_0 = (float_0,)
    handler_task_include_0.load(tuple_0)


# Generated at 2022-06-25 05:19:26.635662
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    x = HandlerTaskInclude()

# Generated at 2022-06-25 05:19:27.373279
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass


# Generated at 2022-06-25 05:20:58.162215
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # float_0 = .8084649585030369
    # tuple_0 = (float_0,)
    # handler_task_include_0 = HandlerTaskInclude()
    # HandlerTaskInclude.load(handler_task_include_0, tuple_0)
    return None


# Generated at 2022-06-25 05:20:59.855728
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert callable(getattr(HandlerTaskInclude, 'load'))

# Generated at 2022-06-25 05:21:10.671074
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-25 05:21:14.254174
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(tuple_0)

# Generated at 2022-06-25 05:21:18.057688
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0.VALID_INCLUDE_KEYWORDS == set(['when', 'run_once'])


# Generated at 2022-06-25 05:21:19.170163
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  handler_task_include_0 = HandlerTaskInclude()


# Generated at 2022-06-25 05:21:29.748006
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    #
    # Import section
    #

    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

    __tracebackhide__ = True

    class HandlerTaskInclude(Handler, TaskInclude):

        VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))

        @staticmethod
        def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
            t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
            handler = t.check_options(
                t.load_data(data, variable_manager=variable_manager, loader=loader),
                data
            )

           

# Generated at 2022-06-25 05:21:34.909512
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    handler_task_include_0 = HandlerTaskInclude()
    assert isinstance(handler_task_include_0, Handler) is True
    assert isinstance(handler_task_include_0, TaskInclude) is True


# Generated at 2022-06-25 05:21:37.288195
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    tuple_0 = (tuple(),)
    handler_task_include_0 = HandlerTaskInclude()
    try:
        handler_task_include_0.load(tuple_0)
    except TypeError:
        return 1
    else:
        return 0

# Generated at 2022-06-25 05:21:45.441940
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    float_0 = -467.24
    tuple_0 = (float_0,)
    handler_task_include_0 = HandlerTaskInclude()
    def side_effect_load(arg_0, arg_1, arg_2):
        dct = {
            'block': {},
            'task_include': {},
            '_variable_manager': arg_2
        }
        return dct

    handler_task_include_0.load = side_effect_load
    handler_task_include_0.load(tuple_0, arg_2=None)
