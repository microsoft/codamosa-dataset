

# Generated at 2022-06-25 05:13:49.248933
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # from ansible.playbook.block import Block
    # from ansible.playbook.handler_task_include import HandlerTaskInclude
    # from ansible.playbook.task import Task
    # from ansible.playbook.task_include import TaskInclude
    # from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    var = None
    task_0 = MagicMock(name='task_0')
    task_0.get_name.return_value = 'task_0'
    task_0.action = 'action_0'
    task_0.name = 'name_0'
    task_0.tags = ['tags_0']
    task_0.when = None
    task_0.notify = []

# Generated at 2022-06-25 05:14:00.152132
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert TaskInclude.VALID_INCLUDE_KEYWORDS == {
        'tags', 'freeform_tags', 'when', 'ignore_errors', 'import_role',
        'vars', 'listen', 'delegate_to', 'register'
    }
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {
        'tags', 'freeform_tags', 'when', 'ignore_errors', 'import_role',
        'vars', 'listen', 'delegate_to', 'register'
    }
    assert Handler.VALID_INCLUDE_KEYWORDS == {
        'tags', 'freeform_tags', 'when', 'ignore_errors', 'import_role',
        'vars', 'listen', 'delegate_to', 'register'
    }

# Generated at 2022-06-25 05:14:02.965771
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    bool_1 = False
    data = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler_task_include_0.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-25 05:14:07.502874
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    bool_1 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0, bool_1)
    print('unit_test:HandlerTaskInclude')
    #assert handler_task_include_0.task_include is None
    #assert handler_task_include_0._role == None


# Generated at 2022-06-25 05:14:11.798841
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    list_0 = list()
    unknown_b_0 = list_0
    task = HandlerTaskInclude(unknown_b_0)
    handler_task_include_0 = task.load(unknown_b_0)
    print(handler_task_include_0)


# Generated at 2022-06-25 05:14:18.570143
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = False
    handler_task_include_0 = HandlerTaskInclude(bool_0)
#
#     assert handler_task_include_0.block is None
#     assert handler_task_include_0.role is None


# Generated at 2022-06-25 05:14:22.239687
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    return handler_task_include_0

# Generated at 2022-06-25 05:14:27.488246
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_0 = True
    data_0 = bool_0
    handler_task_include_0 = HandlerTaskInclude(bool_0)
    assert isinstance(HandlerTaskInclude.load(data_0), Handler)

# Generated at 2022-06-25 05:14:29.517074
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bool_0 = True
    handler_task_include_0 = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler_task_include_0.validate()

# Generated at 2022-06-25 05:14:35.214293
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data_0 = {}
    role_0 = None
    variable_manager_0 = None
    loader_0 = None
    handler_task_include_0 = HandlerTaskInclude.load(data_0, role=role_0, variable_manager=variable_manager_0, loader=loader_0)
    assert handler_task_include_0 is not None

# Generated at 2022-06-25 05:14:41.786582
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)


# Generated at 2022-06-25 05:14:48.891538
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\x07\x84\x9c\x8b'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)

# Test of method load_data of class HandlerTaskInclude

# Generated at 2022-06-25 05:14:57.275783
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\x86\xc8!\xf4\xd6\x06\xe3\x11\xa9\x05\x82\xd2\xc6\x1d\xb7\xcf\xa2\x10\xd9\x13\xf3\x0e\x1a'
    long_0 = long(2663)
    int_0 = 1215551290
    bytes_1 = b'\x1e\x04\x11\xa2\xc8'
    dict_0 = dict()
    dict_0['bytes_1'] = bytes_1
    dict_0['int_0'] = int_0
    dict_0['long_0'] = long_0
    dict_0['bytes_0'] = bytes_0
    int_1 = 69
    dict

# Generated at 2022-06-25 05:15:06.796106
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(handler_task_include_1, bytes_0, set_0)

if __name__ == "__main__":
    test_HandlerTaskInclude()

# Generated at 2022-06-25 05:15:14.252667
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'l\x05\xb3q\x9f\xd2\xc2o\xb5\xf1\x94\xea\xcf\xab\x81R\x9c'
    set_0 = set()
    dict_0 = {}
    bool_0 = False
    bytes_1 = b'\xb8\x1a\x04\x92\xfb\xe7\xfa\x9d\xfb\x9a\xfb\xa4'
    handler_task_include_0 = HandlerTaskInclude()
    var_0 = handler_task_include_0.load(set_0, bool_0, bytes_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 05:15:21.446711
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)
    module_0 = handler_task_include_1
    assert isinstance(module_0, HandlerTaskInclude)
    assert handler_task_include_0 == var_0

# Unit test stub for module HandlerTaskInclude

# Generated at 2022-06-25 05:15:23.895473
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # @TODO: Add tests of method load of class HandlerTaskInclude
    pass


# Generated at 2022-06-25 05:15:29.996760
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\x01'
    int_0 = -1
    bool_0 = True
    handler_task_include_0 = HandlerTaskInclude(int_0, bool_0, bytes_0)
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load(bytes_0, bytes_0, handler_task_include_0, bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:15:39.390868
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)

    # test case load
    assert (var_0 == set_0)


# Generated at 2022-06-25 05:15:48.164310
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bool_1 = False
    tuple_1 = (bool_1,)
    dict_0 = {'alt': {}, 'listen': {}, 'import_playbook': {}, 'import_tasks': {}, 'register': {}, 'include_vars': {}, 'any_errors_fatal': {}, 'loop': {}, 'when': {}}
    # TODO: invariant dict_0: dict
    dict_0 = dict_0
    dict_1 = {}
    dict_1 = dict_1
    # TODO: type-check
    handler_task_include_0 = HandlerTaskInclude(dict_1, tuple_1)
    handler_task_include_0.load(dict_0, dict_1, dict_1)


# Generated at 2022-06-25 05:15:52.918854
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        HandlerTaskInclude()
    except:
        assert False


# Generated at 2022-06-25 05:16:01.180821
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-25 05:16:03.105521
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.check_options(None, None)

# Generated at 2022-06-25 05:16:06.747158
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: NOTE! I did not write this unit test, but it was generated automatically
    pass


# Generated at 2022-06-25 05:16:08.070334
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 05:16:17.933664
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)
    assert True

# Generated at 2022-06-25 05:16:28.588364
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)
    assert var_0.file == b'MR\xa0\xf3\xe5r\xb7\xaaP'
    assert var_0.name == b'MR\xa0\xf3\xe5r\xb7\xaaP'
    assert var_0

# Generated at 2022-06-25 05:16:35.139480
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)


# Generated at 2022-06-25 05:16:35.862908
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:16:38.745135
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Not done yet')
    # handler_task_include_0 = HandlerTaskInclude()
    # assert handler_task_include_0.load(data = 'string') == 'Handler'


# Generated at 2022-06-25 05:16:45.257954
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = set()
    block = HandlerTaskInclude()
    role = b''
    task_include = HandlerTaskInclude()
    variable_manager = None
    loader = None
    handler_task_include = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler_task_include is not None


# Generated at 2022-06-25 05:16:54.533255
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xb9\x03\x13\x8d\xf7\x0bT\xc1'

# Generated at 2022-06-25 05:17:03.386570
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    set_0 = {b'\xec\xefF\x95\x89\x9f\x9a\xb4\x0e', b'\xec\xefF\x95\x89\x9f\x9a\xb4\x0e', b'\xec\xefF\x95\x89\x9f\x9a\xb4\x0e'}
    handler_task_include_0 = HandlerTaskInclude(b'\xec\xefF\x95\x89\x9f\x9a\xb4\x0e', (False,))
    handler_task_include_1 = HandlerTaskInclude()

# Generated at 2022-06-25 05:17:08.009078
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test case where the params are the default value
    # Testing class constructor without parameters
    handler_task_include_0 = HandlerTaskInclude()
    module_0 = handler_task_include_0

    # Test case where the params is not the default value
    handler_task_include_1 = HandlerTaskInclude(str_0, tuple_0)
    module_0 = handler_task_include_1


# Generated at 2022-06-25 05:17:15.731061
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\x0e\x98\xfc^\xd8@\xfa\x90'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    assert handler_task_include_0.block == bytes_0
    assert handler_task_include_0.role == tuple_0
    handler_task_include_1 = HandlerTaskInclude()
    assert handler_task_include_1.role == tuple()
    assert handler_task_include_1.block == ""


# Generated at 2022-06-25 05:17:22.416074
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)

# Generated at 2022-06-25 05:17:26.296650
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 != None


# Generated at 2022-06-25 05:17:33.852543
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    set_1 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)
    assert set_1 == set_0


# Generated at 2022-06-25 05:17:34.680770
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()


# Generated at 2022-06-25 05:17:43.150281
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'\xc9\xed\xd8\x01\x85\x0f\x8c'
    bytes_1 = b'\x83\xd6\x1e\x87\x0c\x85\xc8'
    bytes_2 = b'I\x9d\x8e\xed\xdd\x01\xce'
    bytes_3 = b'\x14\xb9\x8d\x04\x80\x1f\x08'
    bytes_4 = b'\x7f\xf9\x85r\xaf\xa0\x90\x1b'
    bytes_5 = b'\xe9\x9e\x12\xae\xfa\xb1\x1d'

# Generated at 2022-06-25 05:17:55.391309
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_3 = HandlerTaskInclude()
    assert handler_task_include_3.load() != 0,"handler_task_include_3.load failed."

if __name__ == '__main__':
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:17:57.812441
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False # TODO: implement your test here
    # assert var_0 == hasattr(set_0, '__iter__')

# Generated at 2022-06-25 05:18:04.527592
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)
    assert var_0 is not None
    assert type(var_0) == HandlerTaskInclude

# Generated at 2022-06-25 05:18:08.633541
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_1.load(None, None, None)
    assertTrue(isinstance(handler_task_include_1, Handler))


# Generated at 2022-06-25 05:18:10.178990
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert callable(HandlerTaskInclude.load)


# Generated at 2022-06-25 05:18:17.673673
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'a\x0b\xc9\xc4\x12\x00\xdf\x00\xbd\xc7\x1b\xdd\x9e\x14\x11\xf2'
    len_0 = len(bytes_0)
    tuple_0 = (len_0,)
    str_0 = str(bytes_0)
    dict_0 = {tuple_0: str_0}
    HandlerTaskInclude(bytes_0, dict_0)

# Generated at 2022-06-25 05:18:27.260438
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None
    assert handler_task_include_0.block is None
    assert handler_task_include_0.role is None
    assert handler_task_include_0.task_include is None
    handler_task_include_1 = HandlerTaskInclude(bytes_0, tuple_0)
    assert handler_task_include_1 is not None
    assert handler_task_include_1.block is not None
    assert handler_task_include_1.role is not None
    assert handler_task_include_1.task_include is None


# Generated at 2022-06-25 05:18:35.132511
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\xf3\xd3'
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (tuple_0, bool_0)
    set_0 = {tuple_1, bool_0, bool_0}
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)

# Generated at 2022-06-25 05:18:38.633740
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_0 = HandlerTaskInclude()
    assert handler_task_include_0 is not None, \
        "Failed to instantiate HandlerTaskInclude"


# vim: ff=unix:ts=4:sw=4:tw=78:noai:expandtab

# Generated at 2022-06-25 05:18:44.420639
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # check if method load of class HandlerTaskInclude returns the expected values
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)
    assert isinstance(var_0, HandlerTaskInclude) == True

# Generated at 2022-06-25 05:19:08.955901
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:19:17.266268
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = {b'K\xdd', b"\x84'\x8c\xda\x15\xaf\xe9", b'\xeb\xa7\xec"\xda\x8e\x1f'}
    bool_0 = False
    tuple_0 = (bool_0, bool_0)
    handler_task_include_0 = HandlerTaskInclude(b'\xd9\xc5\x01\xd5\x02\x8c\x0e', tuple_0)
    handler_task_include_0.load(set_0)


# Generated at 2022-06-25 05:19:22.476095
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)


# Generated at 2022-06-25 05:19:24.651336
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test case data
    data = {}
    assert HandlerTaskInclude.load(data) == None
    assert HandlerTaskInclude.load(data) == None
    assert HandlerTaskInclude.load(data) == None

# Generated at 2022-06-25 05:19:32.096919
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-25 05:19:33.143379
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert False, "Testcase not implemented"


# Generated at 2022-06-25 05:19:42.072902
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()

    try:
        handler_task_include_0.load()
        # AssertionError raised
    except AssertionError:
        assert True
        # return
    except Exception:
        raise AssertionError
        # return
    else:
        raise AssertionError

    set_0 = set()
    dict_0 = {'index': 0}
    list_0 = [1]
    handler_task_include_2 = handler_task_include_1.load(set_0, dict_0, list_0)
    dict_1 = dict_0
    dict_1['index'] = 0

# Generated at 2022-06-25 05:19:50.368451
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'\x12Q\xdb\xcc\xbe\xae\xb2'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)

if __name__ == "__main__":
    test_case_0()
    test_HandlerTaskInclude_load()

# Generated at 2022-06-25 05:19:53.434244
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.__doc__ == TaskInclude.__doc__

# Generated at 2022-06-25 05:19:54.684550
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:20:34.376073
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True==True


# Generated at 2022-06-25 05:20:41.920548
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = {b'\x8dz\x14\x99\x9c\x8a', b'*\xa1\n\x0c\x8aF\xc2'}
    bool_0 = False
    int_0 = 0
    str_0 = 'c\x8fi\xc4\x1aB\xbc\xe1'
    tuple_0 = (bool_0, int_0, str_0)
    handler_task_include_0 = HandlerTaskInclude(str_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, str_0)


# def test_case_HandlerTaskInclude():
#     bytes_0

# Generated at 2022-06-25 05:20:48.818513
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TEST CASE: 0
    test_case_0()
    # TEST CASE: 1
    set_0 = {b'\xe5\xdc\x1f\x94\xe6\x99j\x8f\x97\x1b\xf9\x11\x19\xef\x11', b'\xcc\x91\x02\xd9\x9a\xed\xaf\xec\xed\xf9T\xad\xda\x07\x1b\x03', b'\x7f\xbe\xdc\x95\x17\x0d\xa0\xbc\x1f\xef\x90\x0c\x9f\x84\x09\x8a'}
    bool_0 = False

# Generated at 2022-06-25 05:20:55.066603
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)


# Generated at 2022-06-25 05:21:01.779950
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    bytes_0 = b'e\x02\xd4\x1c\xdc\xe6\xd9\x02\x10\xee\x8c\xc1'
    set_0 = {bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)


# Generated at 2022-06-25 05:21:09.251620
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Test Case 0 / Edge case input
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)

    # Test Case 1 / Normal case

# Generated at 2022-06-25 05:21:13.537809
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_case_0()
    # def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):



# Generated at 2022-06-25 05:21:21.604362
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    set_0 = {"2f9cc9f9", "{'src', 'zvcd', 'args', 'zvcd', 'become', 'zvcd', 'user', 'zvcd'}"}
    tuple_0 = ()
    handler_task_include_0 = HandlerTaskInclude(set_0, tuple_0)
    set_1 = {"2f9cc9f9", "{'src', 'zvcd', 'args', 'zvcd', 'become', 'zvcd', 'user', 'zvcd'}"}
    tuple_1 = ()
    handler_task_include_1 = HandlerTaskInclude(set_1, tuple_1)
    bytes_0 = b'\x1cf\x89'

# Generated at 2022-06-25 05:21:27.621201
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b'MR\xa0\xf3\xe5r\xb7\xaaP'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bool_0 = False
    tuple_0 = (bool_0,)
    handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
    handler_task_include_1 = HandlerTaskInclude()
    var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)

# Generated at 2022-06-25 05:21:37.604224
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create instance of class HandlerTaskInclude and test __init__()
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()
    handler_task_include_2 = HandlerTaskInclude()
    handler_task_include_3 = HandlerTaskInclude()
    handler_task_include_4 = HandlerTaskInclude()
    handler_task_include_5 = HandlerTaskInclude.load(None)
    handler_task_include_6 = HandlerTaskInclude.load(None)
    handler_task_include_7 = HandlerTaskInclude.load(None)
    handler_task_include_8 = HandlerTaskInclude.load(None)
    # Testing __init__() with multiple arguments
    # Test case 0

# Generated at 2022-06-25 05:23:18.575272
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    with pytest.raises(NotImplementedError) as excinfo:
        bytes_0 = b'*\xbf\xd8\x94\x13\xbaa\x9a\x97\xe4_\x07\x0f\x18\xea'
        set_0 = {bytes_0, bytes_0, bytes_0}
        bool_0 = False
        tuple_0 = (bool_0,)
        handler_task_include_0 = HandlerTaskInclude(bytes_0, tuple_0)
        handler_task_include_1 = HandlerTaskInclude()
        var_0 = handler_task_include_1.load(set_0, handler_task_include_0, bytes_0)
    assert "abstract method load" in str(excinfo.value)

# Generated at 2022-06-25 05:23:23.107116
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create object.
    object = HandlerTaskInclude()
    # Check if object is of type HandlerTaskInclude.
    assert isinstance(object, HandlerTaskInclude)


# Generated at 2022-06-25 05:23:26.690027
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-25 05:23:31.481246
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert test_case_0() is None

# -------------------------------------------------------------------
# Testing class: HandlerInclude


# Generated at 2022-06-25 05:23:40.798088
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    bytes_0 = b"`"
    bool_0 = False
    str_0 = ""