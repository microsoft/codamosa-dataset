

# Generated at 2022-06-23 19:29:51.289284
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter(None, None)
    assert formatter_plugin.format_options.get('json', {}).get('format')


# Generated at 2022-06-23 19:29:55.039514
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    my_dict = {
        'json': {
            'indent': 4,
            'sort_keys': False,
            'format': True
        },
        'explicit_json': True
    }

    JSONFormatter(**my_dict)
    my_dict = {
        'json': {
            'indent': 2,
            'sort_keys': True,
            'format': False
        },
        'explicit_json': False
    }

    JSONFormatter(**my_dict)
# end of test_JSONFormatter


# Generated at 2022-06-23 19:30:04.644450
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options_json_format = True
    format_options_json_indent = 1
    format_options_json_sort_keys = True
    format_options_json = { 'format': format_options_json_format,
            'indent': format_options_json_indent,
            'sort_keys': format_options_json_sort_keys }
    format_options_color_scheme = { '1': {'attribute': '3', 'value': '2'}}
    format_options_colors = { 'color_scheme': format_options_color_scheme }
    format_options = {'json': format_options_json, 'colors': format_options_colors}
    explicit_json = True

# Generated at 2022-06-23 19:30:12.490895
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import BuiltinPluginManager
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.output import get_formatter
    from httpie.output.streams import get_output_stream
    import os.path
    import tempfile

    # get_output_stream() is a private function, but we need it to fetch
    # the output stream to the console.
    stdout = get_output_stream('stdout', is_terminal=True)

    # since we are reusing the code from HTTPie, we will need to create
    # an instance of the PluginManager from httpie.plugins module
    plugin_manager = BuiltinPluginManager()

    # now, we need to create a formatter based on the previous
    # configuration. We need to use the default config file to do so.
    # get_

# Generated at 2022-06-23 19:30:15.933144
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    Json_format = JSONFormatter(
        **{'format_options': {'json': {'indent': 0, 'format': True, 'sort_keys': False}}, 'explicit_json': True})
    assert Json_format.enabled is True

# Generated at 2022-06-23 19:30:16.827714
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass


# Generated at 2022-06-23 19:30:20.258402
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	test = JSONFormatter()
	assert test.kwargs == {}, "not implemented"
	assert test.format_options == {'json':{'format':False, 'indent':4 ,'sort_keys':False}}, "not implemented"
	assert test.enabled == False, "not implemented"


# Generated at 2022-06-23 19:30:21.085647
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()
    assert True

# Generated at 2022-06-23 19:30:32.158769
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    text = """
              {
                  "key": [1, 2, 3, 4],
                  "foo": "bar",
                  "false": false
              }
          """
    json_formatter = JSONFormatter(
        kwargs={'explicit_json': False},
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            },
            'colors': {
                'request_method': 'blue',
                'header': 'yellow',
                'header_value': 'cyan',
                'error_name': 'red',
                'error_message': 'red'
            }
        }
    )

# Generated at 2022-06-23 19:30:33.229454
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.enabled == True
    assert jf.kwargs == {}

# Generated at 2022-06-23 19:30:36.639971
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    expected_json_formatted_body = '{\n    "result": 1\n}'
    body = '{"result": 1}'
    json_formatter = JSONFormatter(explicit_json=True, format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert expected_json_formatted_body == json_formatter.format_body(body=body, mime='json')

# Generated at 2022-06-23 19:30:47.104628
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.name == "JSON"
    assert formatter.plugin_type == "formatter"
    assert formatter.description == "JSON-format values"
    assert formatter.options == {
        "format": {
            "help": "Enables json-formatting for the response",
            "type": bool,
            "default": False,
            "action": "store_true"
        },
        "indent": {
            "help": "Set indentation level for the json-formatted output",
            "type": int,
            "default": 2
        },
        "sort_keys": {
            "help": "Sort keys in json-formatted output",
            "type": bool,
            "default": False,
            "action": "store_true"
        }
    }

# Generated at 2022-06-23 19:30:57.023536
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(format_options={"json":{"format":True,"indent":4,"sort_keys":True}},explicit_json=True).format_body('{"arr":[1,2,3],"obj":{"a":1},"x":"y"}', 'json') == '{\n    "arr": [\n        1,\n        2,\n        3\n    ],\n    "obj": {\n        "a": 1\n    },\n    "x": "y"\n}'

# Generated at 2022-06-23 19:31:00.076937
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True
        }
    })
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n  "a": "b"\n}'


# Generated at 2022-06-23 19:31:01.618918
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter(explicit_json=False)

# Generated at 2022-06-23 19:31:12.010955
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import plugin_manager

    json_plugin = plugin_manager.get_plugin_instances(JSONFormatter)[0]
        
    assert json_plugin.format_body(body='''{"a":1}''', mime="json") == '''{
    "a": 1
}'''

    assert json_plugin.format_body(body='''{"a":2}''', mime="json") == '''{
    "a": 2
}'''

    assert json_plugin.format_body(body='''{"a":3}''', mime="json") == '''{
    "a": 3
}'''

    assert json_plugin.format_body(body='''{"a":4}''', mime="json") == '''{
    "a": 4
}'''

# Generated at 2022-06-23 19:31:21.166051
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert(JSONFormatter(format_options={"json": {"format": True}}, kwargs={"explicit_json": True}).format_body("{\"hello\": \"world\"}", "json") == '{\n    "hello": "world"\n}')
    assert(JSONFormatter(format_options={"json": {"format": True}}, kwargs={"explicit_json": False}).format_body("{\"hello\": \"world\"}", "json") == '{\n    "hello": "world"\n}')
    assert(JSONFormatter(format_options={"json": {"format": False}}, kwargs={"explicit_json": True}).format_body("{\"hello\": \"world\"}", "json") == '{\n    "hello": "world"\n}')

# Generated at 2022-06-23 19:31:23.648280
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    json_formatter = JSONFormatter()
    assert json_formatter.__dict__['kwargs']


# Generated at 2022-06-23 19:31:33.078609
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Function to test the constructor of class JSONFormatter.
    
    # Using 'with' function, open json file and store it in variable 'f'
    with open('config.json') as f:
        # Load the contents of json file into a variable 'config'.
        config = json.load(f)
    # Fetch default format of output as 'formatting'.
    formatting = config['formatting']
    
    # Create object of class JSONFormatter and store it in variable 'obj'.
    obj = JSONFormatter(formatting)
    # Assert that obj is instance of class JSONFormatter.
    assert isinstance(obj, JSONFormatter)
    # Assert that obj is not instance of other class.    
    assert not isinstance(obj, FormatterPlugin)


# Generated at 2022-06-23 19:31:39.485063
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options = {'json' : {'format': False, 'sort_keys':False, 'indent':2}})
    assert json_formatter.format_body('{"key": "value"}', 'json') == '{"key": "value"}'
    assert json_formatter.format_body('{"key": "value"}', 'text') == '{"key": "value"}'
    assert json_formatter.format_body('{"key": "value"}', 'json') == '{"key": "value"}'

# Generated at 2022-06-23 19:31:43.777385
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 1}'
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}})
    assert formatter.format_body(body, 'json') == '{\n    "a": 1\n}'


# Unit tests for method format_body of class JSONFormatter when body is invalid JSON

# Generated at 2022-06-23 19:31:52.447911
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.builtin import JSONFormat
    def do_test(mime, body, expected):
        formatter = JSONFormatter(
            format_options = JSONFormat()
        )
        assert formatter.format_body(body, mime) == expected

    # no json
    do_test("text/plain", "test", "test")
    do_test("application/xml", "<test></test>", "<test></test>")

    # json
    do_test("application/json", '{"test": "test"}', '{"test": "test"}')
    do_test("application/json", '{"test": "test"}', '{"test": "test"}')

    # explicit json
    do_test("text/plain", '{"test": "test"}', '{"test": "test"}')

# Generated at 2022-06-23 19:32:02.008000
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={'json': {'format': True, 'indent': 4,
                                 'sort_keys': True}},
        explicit_json=True,
        output_options={'group_responses': True, 'max_concurrent': 1},
        session={'path': None}
    )
    assert formatter is not None
    assert formatter.enabled is True
    assert formatter.kwargs == {'explicit_json': True}
    assert formatter.format_options == {'json': {'format': True, 'indent': 4,
                                                 'sort_keys': True}}
    assert formatter.output_options == {'group_responses': True,
                                        'max_concurrent': 1}
    assert formatter.session == {'path': None}

# Generated at 2022-06-23 19:32:10.729540
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py2
    from httpie.compat import is_windows

    if is_py2:
        assert JSONFormatter().format_body('{"a": "\u041f\u0440\u0438\u0432\u0456\u0442"}', None) == '{"a": "Привіт"}'
    else:
        assert JSONFormatter().format_body('{"a": "\u041f\u0440\u0438\u0432\u0456\u0442"}', None) == '{\n    "a": "Привіт"\n}'


# Generated at 2022-06-23 19:32:13.877682
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    print('testing constructor of class JSONFormatter')
    jsonformatter = JSONFormatter()
    assert jsonformatter.format_options['json']['format'] == True
    print('passed test of constructor')

if __name__ == '__main__':
    test_JSONFormatter()

# Generated at 2022-06-23 19:32:16.665222
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    json_test = '{"test":"test"}'
    assert formatter.format_body(json_test, 'json') == json.dumps(json.loads(json_test))

# Generated at 2022-06-23 19:32:19.419257
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    instance = JSONFormatter(format_options=('json', True), kwargs=('explicit_json', True))
    assert instance.enabled == True
    assert instance.kwargs['explicit_json'] == True
    assert type(instance.kwargs) == type(dict())
    assert type(instance) == type(JSONFormatter)


# Generated at 2022-06-23 19:32:27.957458
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import JSONFormatter
    from io import StringIO
    import json
    formatter = JSONFormatter(
        format_options={
            "json": {
                "format": True,  # always
                "indent": 2,
                "sort_keys": True
            }
        },
        stream=StringIO(),
        color=None,
        explicit_json=False,
        style=None
    )
    body = '{"a": 1, "b": [2,3], "c": {"d": 4}}'
    assert formatter.format_body(body, 'json') == json.dumps(
        obj=json.loads(body),
        indent=2,
        sort_keys=True,
        ensure_ascii=False
    ) + '\n'



# Generated at 2022-06-23 19:32:33.439983
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    data = '{"hello":"world"}'
    test = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}})
    assert test.format_body(data, 'application/json') == '{\n  "hello": "world"\n}'

# Generated at 2022-06-23 19:32:40.353496
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format = JSONFormatter()
    assert format.fmt_options == format.format_options
    assert format.fmt_options['json']['format'] == format.format_options['json']['format']
    assert format.fmt_options['json']['sort_keys'] == format.format_options['json']['sort_keys']
    assert format.fmt_options['json']['indent'] == format.format_options['json']['indent']
    assert not format.kwargs['explicit_json']

# Generated at 2022-06-23 19:32:46.428415
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import httpie.plugins
    httpie.plugins.__path__
    json_formatter = JSONFormatter(kwargs={'explicit_json':True}, format_options={"json":{'format':True,"indent":2,"sort_keys":True}})
    import pytest
    with pytest.raises(TypeError):
        json_formatter = JSONFormatter(kwargs={'explicit_json':True})


# Generated at 2022-06-23 19:32:47.433345
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter_obj = JSONFormatter()
    assert json_formatter_obj.enabled == True


# Generated at 2022-06-23 19:32:48.291116
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.enabled == True

# Generated at 2022-06-23 19:32:52.879172
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	json_formatter = JSONFormatter(format_options={
		'json': {
			'format': True,
			'sort_keys': True,
			'indent': None
		}
	}, explicit_json=True)
	assert json_formatter.enabled
	assert json_formatter.kwargs['explicit_json']


# Generated at 2022-06-23 19:33:02.398041
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Case 1:
    #   The body is a json string.
    #   The content type (mime) is 'application/json'.
    #   The format option's json option is enabled.
    #   The format option's json option's indent is 4.
    #   The format option's json option's sort_keys is enabled.
    #   The format option's explicit_json option is disabled.
    # Expect:
    #   The json is formatted.
    options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        },
        'explicit_json': False,
    }

# Generated at 2022-06-23 19:33:12.749310
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(format_options={'json': {'indent': None,
                                                'format': True,
                                                'sort_keys': False}})
    # First test with json formatted response body
    input_test = ({'test': 'test'}, 'application/json')
    expected_output = '{"test": "test"}'
    output = jf.format_body(*input_test)
    assert output == expected_output

    # Test with json formatted response body and json content type
    input_test = ('{"test": "test"}', 'application/json')
    expected_output = '{"test": "test"}'
    output = jf.format_body(*input_test)
    assert output == expected_output

    # Test with json formatted response body and javascript content type

# Generated at 2022-06-23 19:33:22.331370
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(**{'explicit_json': True, 'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}})
    formatter.kwargs = {
            'explicit_json': True,
            'format_options': {
                'json': {
                    'format': True,
                    'indent': 4,
                    'sort_keys': True,
                },
            },
        }
    # body with valid JSON
    body = '{"name": "Tom", "greeting": "Hello!"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '''{
    "greeting": "Hello!",
    "name": "Tom"
}'''
    # body with invalid JSON
   

# Generated at 2022-06-23 19:33:26.062567
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  from httpie.plugins.builtin import JSONFormatter

  fp = JSONFormatter({'explicit_json': False, 'json': {'format': True, 'indent': None, 'sort_keys': False}})
  assert fp.enabled == True
  assert fp.kwargs['explicit_json'] == False
  assert fp.format_options['json'] == {'format': True, 'indent': None, 'sort_keys': False}



# Generated at 2022-06-23 19:33:32.943977
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test1: enable
    formatter = JSONFormatter(format_options={"json":{"format": True, "indent": 3, "sort_keys": False}})
    assert formatter.enabled is True
    # Test2: disable
    formatter = JSONFormatter(format_options={"json":{"format": False, "indent": 3, "sort_keys": False}})
    assert formatter.enabled is False

    # Test3: set indent
    assert formatter.format_options['json']['indent'] == 3
    # Test4: set sort keys
    assert formatter.format_options['json']['sort_keys'] is False

# Generated at 2022-06-23 19:33:39.480752
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    mime = 'application/json'
    body = '{"id":1,"body":"my_body"}'
    assert json_formatter.format_body(body, mime) == '{\n    "body": "my_body",\n    "id": 1\n}'
    mime = 'application/html'
    body = '<html><body>Hello, World!</body></html>'
    assert json_formatter.format_body(body, mime) == body

# Generated at 2022-06-23 19:33:43.425503
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 1, "b": 2}'
    formatter = JSONFormatter(kwargs={'explicit_json': False})
    assert formatter.format_body(body, 'application/json') == '''{
 "a": 1,
 "b": 2
}'''

    formatter = JSONFormatter(kwargs={'explicit_json': True})
    assert formatter.format_body(body, 'application/json') == '''{
 "a": 1,
 "b": 2
}'''

# Generated at 2022-06-23 19:33:46.512557
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter()
    assert test
    assert test.format_options['json']['format']
    assert test.kwargs['explicit_json']

# Generated at 2022-06-23 19:33:50.743533
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()
    assert formatter_plugin.format_options['json']['indent'] == 2
    assert formatter_plugin.format_options['json']['sort_keys'] == False


# Generated at 2022-06-23 19:34:01.218582
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Case 1: format_options['json']['format'] = 'on'
    # Case 1.1: mime = 'json'
    assert JSONFormatter.format_body("""{"key": "value"}""", 'json') \
        == json.dumps(obj={"key": "value"}, sort_keys=False, ensure_ascii=False, indent=4)
    # Case 1.2: mime = 'javascript'
    assert JSONFormatter.format_body("""{"key": "value"}""", 'javascript') \
        == json.dumps(obj={"key": "value"}, sort_keys=False, ensure_ascii=False, indent=4)
    # Case 1.3: mime = 'text'

# Generated at 2022-06-23 19:34:10.040123
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options = {
            'color': 'auto',
            'colors': {
                'header': 'green',
                'punctuation': 'cyan',
            },
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            },
            'pprint': True,
            'styles': {
                'headers': {
                    'color': 'green',
                    'bold': True,
                },
                'url': {
                    'color': 'blue',
                    'underline': True,
                },
            },
        }
    )

    # Test members
    assert formatter.enabled == True

# Generated at 2022-06-23 19:34:21.804652
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:34:29.807020
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(**{
        'format_options': {
            'json': {
                'indent': 2,
                'sort_keys': True,
                'format': True
            }
        },
        'explicit_json': True
    })

    assert(formatter.enabled)
    assert(formatter.format_options == {
        'json': {
            'indent': 2,
            'sort_keys': True,
            'format': True
        }
    })
    assert(formatter.kwargs['explicit_json'])


# Generated at 2022-06-23 19:34:36.411286
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Given
    json_str = '{"a": 1, "b": 2}'
    mime = 'application/json; charset=utf-8'
    formatter = JSONFormatter()

    # When
    actual = formatter.format_body(json_str, mime)

    # Then
    assert actual == '{\n' + '    "a": 1,\n    "b": 2\n}\n'

# Generated at 2022-06-23 19:34:37.387720
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	assert True


# Generated at 2022-06-23 19:34:46.070487
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from pretend import stub
    import json

    # Create a stub for the class FormatterPlugin. Get a dummy body, mime,
    # kwargs, explicit_json and indent.
    f = JSONFormatter(**{'format_options': {'json': {'format': True,
                                                     'sort_keys': True,
                                                     'indent': 4}}})
    # Create a json string
    body = '{"test": "value"}'
    # Create a list of mime types
    mime = 'application/json'
    # Create a list of kwargs
    kwargs = {'explicit_json': False}
    # Give a dummy value for the variables explicit_json and indent
    explicit_json = False
    indent = 4
    # Call the method format_body
    out = f.format_body

# Generated at 2022-06-23 19:34:53.809370
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    formatter_plugin = JSONFormatter(format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        output_options={
            'pretty': True,
            'colors': False,
            'stream': 0
        }
    )
    assert formatter_plugin is not None

    assert formatter_plugin.enabled
    assert not formatter_plugin.kwargs['explicit_json']
    assert formatter_plugin.format_options == \
        {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        }

# Generated at 2022-06-23 19:35:03.694908
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_str = '{"a": "A", "b": "B"}'
    fp = JSONFormatter(format_options= {'json': {'format': True, 'indent': 2}}, explicit_json=False)
    assert fp.format_body(json_str, 'json') == '{\n  "a": "A",\n  "b": "B"\n}'
    fp = JSONFormatter(format_options= {'json': {'format': True, 'indent': 2}}, explicit_json=True)
    assert fp.format_body(json_str, 'javascript') == '{\n  "a": "A",\n  "b": "B"\n}'

# Generated at 2022-06-23 19:35:04.428218
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass

# Generated at 2022-06-23 19:35:08.479077
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	f = JSONFormatter(formatter_options={ 'json': {'format': False, 'sort_keys': True, 'indent': 0} })
	assert f.format_options['json']['format'] == False
	assert f.format_options['json']['sort_keys'] == True
	assert f.format_options['json']['indent'] == 0


# Generated at 2022-06-23 19:35:10.762252
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        test = JSONFormatter()
        test.format_body("test", "text")
        print("Unit test for JSONFormatter successful")
    except:
        print("Unit test for JSONFormatter unsuccessful")

# Generated at 2022-06-23 19:35:17.951109
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{"explicit_json": False})
    json_formatter.enabled = True
    json_formatter.format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }
    }
    body = '{"message": "Hello, world!"}'
    mime = 'json'
    expected_output = '{\n  "message": "Hello, world!"\n}'
    assert json_formatter.format_body(body, mime) == expected_output

# Generated at 2022-06-23 19:35:28.214128
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_body = '{"test": "test"}'
    json_formatter = JSONFormatter()
    assert json_formatter.format_body(body=json_body, mime='json') == json.dumps(json.loads(json_body), indent=4, sort_keys=False, ensure_ascii=False)
    assert json_formatter.format_body(body=json_body, mime='javascript') == json.dumps(json.loads(json_body), indent=4, sort_keys=False, ensure_ascii=False)
    assert json_formatter.format_body(body=json_body, mime='text') == json.dumps(json.loads(json_body), indent=4, sort_keys=False, ensure_ascii=False)
    assert json_formatter.format_

# Generated at 2022-06-23 19:35:28.724206
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-23 19:35:35.379742
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            },
            'colors': {
                'request_method': True,
                'request_url': True,
                'status': True,
            }
        }
    )
    assert json_formatter.enabled is True


# Generated at 2022-06-23 19:35:36.928080
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        import json
    except ImportError:
        assert False
    else:
        assert True


# Generated at 2022-06-23 19:35:42.958427
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mock_response = b'''{
        "code": 200,
        "person": {
            "name": "Chase",
            "age": 25
        },
        "developers": [
            {
                "name": "Gilles",
                "age": 27
            },
            {
                "name": "John",
                "age": 30
            },
            {
                "name": "David",
                "age": 28
            }
        ]
    }
    '''
    json_formatter = JSONFormatter(environment=None, **{'explicit_json': True})
    result = json_formatter.format_body(mock_response, 'application/json')
    print(result)

# Generated at 2022-06-23 19:35:50.636882
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf=JSONFormatter(explicit_json=True,format_options={'json':{'format':True,'sort_keys':True,'indent':True}})
    assert jf.format_body('{"foo":["bar","baz"],"baz":true}','application/javascript')=='{\n    "baz": true,\n    "foo": [\n        "bar",\n        "baz"\n    ]\n}'
    assert jf.format_body('{"foo":["bar","baz"],"baz":true}','application/json')=='{\n    "baz": true,\n    "foo": [\n        "bar",\n        "baz"\n    ]\n}'

# Generated at 2022-06-23 19:36:00.078917
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'sort_keys': False,
                'format': False,
                'indent': 4
            }
        },
        explicit_json=False
    )
    assert formatter.enabled is False
    assert formatter.kwargs == {
        'explicit_json': False
    }
    assert formatter.format_options == {
        'json': {
            'sort_keys': False,
            'format': False,
            'indent': 4
        }
    }


# Generated at 2022-06-23 19:36:09.095513
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    test_data = {
        'k1': 'v1',
        'k2': 'v2',
        'k3': ['v3', 'v4', 'v5']
    }
    body = '{ "k1": "v1", "k2": "v2", "k3": ["v3", "v4", "v5"] }'

    jsonFormatter = JSONFormatter(format_options = {
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 3,
                'max_array_lines': 10,
                'max_string_length': 50,
            }
        })

    # Formatting is enabled and MIME type is json

# Generated at 2022-06-23 19:36:10.946597
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormat = JSONFormatter()
    jsonFormat.__init__()
    return jsonFormat


# Generated at 2022-06-23 19:36:12.885649
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert (json_formatter.enabled == json_formatter.format_options['json']['format'])

# Generated at 2022-06-23 19:36:24.899734
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    '''
    Test JSONFormatter().format_body()
    '''
    
    # Test with a valid json
    json_string = '{"name": "John Doe", "age": 21}'

# Generated at 2022-06-23 19:36:35.117169
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for indent
    # First test for mime "application/json"
    # Test for false explicit_json
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    body = '''{"status": "OK", "count": -1}'''
    mime = "application/json"
    outBody = formatter.format_body(body, mime)
    expectedBody = '''{
    "count": -1, 
    "status": "OK"
}'''
    assert outBody == expectedBody

    # Test for true explicit_json

# Generated at 2022-06-23 19:36:39.942454
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
       'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    })
    body = '{"foo": "bar"}'
    mime = 'application/json'
    expected = '''{
    "foo": "bar"
}'''
    assert formatter.format_body(body, mime) == expected



# Generated at 2022-06-23 19:36:45.868151
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        kwargs={'explicit_json': True},
        format_options={
            'json':
                {'format': True,
                 'indent': 2,
                 'sort_keys': True,
                 }
        })
    assert json_formatter.format_body(
        '{"b":1, "a":2}',
        'application/json') == '{\n  "a": 2, \n  "b": 1\n}'

# Generated at 2022-06-23 19:36:52.518538
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert(json_formatter.format_body(
        '{"a": 1}', 'application/json') == '{\n    "a": 1\n}')
    assert(json_formatter.format_body(
        '{"b": 1}', 'application/json') == '{\n    "b": 1\n}')
    assert(json_formatter.format_body(
        '{"a": 1}', 'text/html') == '{"a": 1}')
    assert(json_formatter.format_body(
        '{"a": 1', 'application/json') == '{"a": 1')

# Generated at 2022-06-23 19:36:59.289653
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.plugins.builtin.json_formatter
    from httpie.core import Formatter, FormattedHttpResponse
    from httpie.plugins.builtin.json_formatter import JSONFormatter
    resp = FormattedHttpResponse(Formatter(), 'json', b'{"name": "bob"}')
    json_formatter = JSONFormatter(kwargs={'explicit_json': True})
    actual = json_formatter.format_body(resp.body, 'json')
    v = json.loads(actual)
    assert v['name'] == 'bob'

# Generated at 2022-06-23 19:37:01.345014
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Test 1
    body = '{"test": "test"}, {"test": "test"}'
    mime = 'json'
    formatter = JSO

# Generated at 2022-06-23 19:37:01.950846
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-23 19:37:06.991586
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    formatter = JSONFormatter(kwargs={
        'explicit_json': True,
        'format_options': {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        }
    })
    assert(isinstance(formatter, JSONFormatter))
    assert(isinstance(formatter, FormatterPlugin))


# Generated at 2022-06-23 19:37:15.721692
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import os
    import sys
    import tempfile
    import pytest
    from httpie.core import main
    os.environ['HTTPIE_JSON_AS_STREAM'] = 'true'
    os.environ['HTTPIE_SORT_KEYS'] = 'true'
    os.environ['HTTPIE_INDENT'] = '2'
    try:
        del os.environ['HTTPIE_VERIFY']
    except KeyError:
        pass
    sys.stdout.write(
        main(args=[
            '--json', 'https://httpbin.org/post',
        ],stdin=tempfile.TemporaryFile())
    )

# Generated at 2022-06-23 19:37:16.380484
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    httpie.plugins.JSONFormatter.format_body()

# Generated at 2022-06-23 19:37:23.374610
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test the case when format_options has normal json sub key
    format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }

    # Run
    formatter_plugin = JSONFormatter(format_options=format_options,
                                     explicit_json=False,
                                     color_scheme={})

    # Verify
    assert formatter_plugin.format_options[
        'json']['format'] == True
    assert formatter_plugin.format_options[
        'json']['indent'] == 4
    assert formatter_plugin.format_options[
        'json']['sort_keys'] == True

    # Test the case when format_options has no json sub key

# Generated at 2022-06-23 19:37:24.027896
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert 1 == 1

# Generated at 2022-06-23 19:37:31.320277
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    formatter = JSONFormatter()
    formatter.kwargs['explicit_json'] = False
    formatter.format_options['json']['format'] = False
    body = '{"foo":"bar"}'
    mime = 'json'
    expected = '{"foo":"bar"}'
    actual = formatter.format_body(body, mime)
    assert expected == actual, 'not match'
    # Test case 2
    formatter = JSONFormatter()
    formatter.kwargs['explicit_json'] = True
    formatter.format_options['json']['format'] = False
    body = '{"foo":"bar"}'
    mime = 'json'
    expected = '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 19:37:38.795823
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {'json': {'format': True,
                            'sort_keys': False,
                            'indent': False}}
    kwargs = {'explicit_json': False, 'is_json': True, 'format_options': format_options}
    formatter = JSONFormatter(**kwargs)
    assert formatter.enabled == True



# Generated at 2022-06-23 19:37:48.849911
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from typing import Type

    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': None,
                'sort_keys': False
            }
        },
        explicit_json=False,
        alphabetize_headers=False,
        colors=256,
        headers={},
        style={},
        verify=True,
        stream=None,
        writer_cls=None
    )

    assert json_formatter.format_body(
        body='{"hello": "world"}',
        mime='json'
    ) == '{\n    "hello": "world"\n}'

    json_formatter.format_options['json']['indent'] = 2

# Generated at 2022-06-23 19:38:00.546371
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class Dummy:
        pass
    env = Dummy()
    env.explicit_json = False
    env.format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    }
    test_body = '[{"bag":1, "zebra":2}, {"tree":3, "banana":4}]'
    json_formatter = JSONFormatter(env=env, kwargs=env)

# Generated at 2022-06-23 19:38:05.215614
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arguments
    body = '{"a":"a", "b":1, "c":true, "d":null}'
    mime = 'application/json'

    # Mocked function
    def json_loads(body: str)->str:
        return body

    def json_dumps(obj, sort_keys, ensure_ascii, indent):
        return '{"a":"a","b":1,"c":true,"d":null}'

    formatter = JSONFormatter(
        format_options={
            'json':{
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        explicit_json=False,
        colors=False
    )

    # Patch the method of JSONFormatter
    formatter.json.loads = json_loads
    form

# Generated at 2022-06-23 19:38:08.873278
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # New object a formatter plugin
    fmt = JSONFormatter(format_options={}, session=None)

    # Check result
    assert fmt.enabled == True


# Generated at 2022-06-23 19:38:18.123582
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options = {'json' : {'format': True, 'sort_keys': False, 'indent': 0}})
    assert formatter.format_body('{"foo": "bar"}', 'application/json') == '{"foo": "bar"}'
    assert formatter.format_body('{"foo": "bar"}', 'application/javascript') == '{"foo": "bar"}'
    assert formatter.format_body('{"foo": "bar"}', 'text/plain') == '{"foo": "bar"}'
    assert formatter.format_body('{"foo": "bar"}', 'application/pdf') == '{"foo": "bar"}'

# Generated at 2022-06-23 19:38:19.719307
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    JSONFormatter.format_body('test', 'application/json')


# Generated at 2022-06-23 19:38:29.363776
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import tests.abc
    import json
    import os

    with open(os.path.join(os.path.dirname(__file__),'../httpie/formatters/__init__.py'), "rt") as f1:
        with open(os.path.join(os.path.dirname(__file__),'../httpie/plugins/builtin.py'), "rt") as f2:
            f1_content = f1.read()
            f2_content = f2.read()
            test_result = tests.abc.test_abc(f1_content, f2_content, 20418)
            if test_result == True:
                print("[+]Constructor of JSONFormatter is ABC-compliant!")

# Generated at 2022-06-23 19:38:37.069494
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json=True, format_options={"json": {"sort_keys": True, "format": True, "indent": 4}})
    input = '{"msg": "hello world", "email": "c@c.com"}'
    output = json_formatter.format_body(body=input, mime="application/json")
    assert output == "{\n    \"msg\": \"hello world\",\n    \"email\": \"c@c.com\"\n}"

# Generated at 2022-06-23 19:38:45.210166
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonformat = JSONFormatter()
    jsonformat.format_options['json'] = {
        'format': True,
        'sort_keys': False,
        'indent': None
    }
    jsonformat.kwargs = {
        'explicit_json': False,
    }
    body = '{"a":1}'
    mime = 'application/json'
    res = jsonformat.format_body(body, mime)
    assert res == '{\n    "a": 1\n}'

    body = '{"a":1}'
    mime = 'text/html;charset=utf-8'
    res = jsonformat.format_body(body, mime)
    assert res == '{"a":1}'

# Generated at 2022-06-23 19:38:51.931917
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fp = JSONFormatter()
    assert fp.format_body("{'name': 'John', 'age': 30}", 'text/json') == '{"age": 30, "name": "John"}'
    assert fp.format_body("{'name': 'John', 'age': 30}", 'text/html') == "{'name': 'John', 'age': 30}"

# Generated at 2022-06-23 19:38:55.754493
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter(format_options={'indent': 4,
                                                  'sort_keys': True},
                                  explicit_json=True)
    assert jsonFormatter.enabled
    assert jsonFormatter.kwargs['explicit_json']


# Generated at 2022-06-23 19:39:05.079789
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(body='{"test": "test"}', format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}}).format_body() == '{\n    "test": "test"\n}'
    assert JSONFormatter(body='{"test": "test"}', format_options={'json': {'format': True, 'sort_keys': False, 'indent': 4}}).format_body() == '{\n    "test": "test"\n}'
    assert JSONFormatter(body='{"test": "test"}', format_options={'json': {'format': True, 'sort_keys': True, 'indent': None}}).format_body() == '{\n    "test": "test"\n}'

# Generated at 2022-06-23 19:39:15.449266
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    """
    Test formatted json output
    """
    input_body = """{
  "id": "1",
  "name": "foo",
  "price": 123,
  "tags": [
    "bar",
    "eek"
  ],
  "stock": {
    "warehouse": 300,
    "retail": 20
  }
}"""
    output_body = """{
    "id": "1",
    "name": "foo",
    "price": 123,
    "tags": [
        "bar",
        "eek"
    ],
    "stock": {
        "warehouse": 300,
        "retail": 20
    }
}"""
    assert json_formatter.format_body(input_body, 'application/json')

# Generated at 2022-06-23 19:39:21.757614
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(format_options={'json': {'format': 'format', 'sort_keys': 'sort_keys', 'indent': 'indent'}, 'colors': {'color': 'color', 'style': 'style', 'bg': 'bg'}}, explicit_json=False, colors=True)
    assert jf.enabled == 'format'
    assert jf.format_options == {'json': {'format': 'format', 'sort_keys': 'sort_keys', 'indent': 'indent'}, 'colors': {'color': 'color', 'style': 'style', 'bg': 'bg'}}
    assert jf.kwargs['explicit_json'] == False
    assert jf.kwargs['colors'] == True


# Generated at 2022-06-23 19:39:28.259079
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import JSONFormatter

    valid_json_string = '{"email": "emil@example.com"}'
    invalid_json = '{"email": "emil@example.com}'

    assert JSONFormatter().format_body(valid_json_string, "") == '{\n    "email": "emil@example.com"\n}'
    assert JSONFormatter().format_body(invalid_json, "") == invalid_json

# Generated at 2022-06-23 19:39:37.398664
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest

    # Instantiate a JSONFormatter object
    json_formatter = JSONFormatter()

    # Test 1:
    # Explicitly set 'json' mime type.
    # Check that the body is correctly formated and returned.
    body = '{\n "key1": "value1",\n "key2": "value2",\n "key3": "value3"\n}'
    mime = 'json'
    body_formatted = json_formatter.format_body(body, mime)
    assert body_formatted == '{\n "key1": "value1",\n "key2": "value2",\n "key3": "value3"\n}'
    assert type(body_formatted) == type(body)

    # Test 2:
    # Explicitly set another mime

# Generated at 2022-06-23 19:39:47.629061
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """To run this test independently, run the following command from the
    root directory of the program.

        python3 -m unittest -v test_JSONFormatter

    """
    from unittest import TestCase
    from httpie.plugins import FormatterPlugin
    import json

    class DummyJSONFormatter(FormatterPlugin):

        def __init__(self, **kwargs):
            # We don't pass any kwargs here.
            super().__init__(**{})

    class TestObject(TestCase):

        def test_valid_json_string_with_explicit_json_kwarg(self):
            json_test_string = '[{"test": "test"}, {"test": "test"}]'
            dummy_json_formatter = DummyJSONFormatter(explicit_json=True)

# Generated at 2022-06-23 19:39:49.748660
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_fmt = JSONFormatter()
    body = json_fmt.format_body('{"a": "true"}', 'application/json')
    assert body == '{\n    "a": "true"\n}'
    body = json_fmt.format_body('{"a": "true"}', 'text/html')
    assert body == '{"a": "true"}'