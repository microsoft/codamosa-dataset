

# Generated at 2022-06-23 19:29:59.152464
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    ff_test = JSONFormatter(format_options={'json': {'format': True, 'indent': 4,'sort_keys': True}})
    body_test = ff_test.format_body('{"ciao": "mondo"}', "json")
    assert body_test == '{\n    "ciao": "mondo"\n}'

# Generated at 2022-06-23 19:30:02.109572
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsformatter = JSONFormatter(kwargs={'explicit_json': False, 'json': {'format': False, 'indent': 4, 'sort_keys': True}})
    assert jsformatter.enabled == False


# Generated at 2022-06-23 19:30:11.569311
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http
    # Test: JSON formatting of body of response with mime type as application/json
    result = http('GET http://httpbin.org/response-headers?Content-Type=application/json',
                  error_exit_ok=True)
    assert result.exit_status == ExitStatus.OK
    assert result.stderr == ''
    assert result.json == {"Content-Type": "application/json"}

    # Test: JSON formatting of body of response with mime type as default text/html
    result = http('GET http://httpbin.org/response-headers?Content-Type=default',
                  error_exit_ok=True)
    assert result.exit_status == ExitStatus.OK
    assert result.stderr == ''

# Generated at 2022-06-23 19:30:15.335529
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{'test':'test'}"
    mime = "json"
    assert '{\n    "test": "test"\n}' == JSONFormatter().format_body(body, mime)

# Generated at 2022-06-23 19:30:18.946342
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs={'explicit_json': False}
    assert json_formatter.format_body(body='{"a": "b", "c": "d"}', mime='text') is '{"a": "b", "c": "d"}'

# Generated at 2022-06-23 19:30:24.996712
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs['explicit_json'] = True
    assert formatter.format_body('{"a":1,"b":2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a":1,"b":2}', 'xjson') == '{"a":1,"b":2}'

# Generated at 2022-06-23 19:30:32.013822
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"name":"John","age":30,"cars":[ "Ford", "BMW", "Fiat" ]}'
    formatter = JSONFormatter()
    assert formatter.format_body(body=body, mime='json') == body
    assert formatter.format_body(body=body, mime='javascript') == body
    assert formatter.format_body(body=body, mime='text') == body
    assert formatter.format_body(body=body, mime='html') == body

# Generated at 2022-06-23 19:30:39.759634
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    assert formatter.format_body('123', 'json') == '"123"'
    assert formatter.format_body('123', 'javascript') == '"123"'
    assert formatter.format_body('123', 'text') == '"123"'

    assert formatter.format_body('{}', 'json') == '{}'
    assert formatter.format_body('{}', 'javascript') == '{}'
    assert formatter.format_body('{}', 'text') == '{}'

    assert formatter.format_body('{"a":1}', 'json') == '{"a": 1}'
    assert formatter.format_body('{"a":1}', 'javascript') == '{"a": 1}'

# Generated at 2022-06-23 19:30:48.815219
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(explicit_json=False,
                      format_options={'json':
                                      {'format': False, 'sort_keys': False, 'indent': 0}
                                      })
    body = '[{"a": 1, "b": 2, "c": 3}]'
    mime = 'json'
    assert f.format_body(body, mime) == '[\n    {\n        "a": 1, \n        "b": 2, \n        "c": 3\n    }\n]'
    mime = 'text'
    assert f.format_body(body, mime) == '[\n    {\n        "a": 1, \n        "b": 2, \n        "c": 3\n    }\n]'
    mime = 'text/plain'

# Generated at 2022-06-23 19:30:51.250072
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter({'json':{'format':True, 'sort_keys':False, 'indent':2}})
    assert formatter.enabled == True


# Generated at 2022-06-23 19:31:00.078829
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class FormatTester(object):
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.format_options = kwargs['format_options']

    # Test that body is correctly formatted
    body = '{"foo":"bar"}'
    mime = 'json'
    kwargs = {
        'format_options': {
            'json': {
                'format': True,
                'indent': None,
                'sort_keys': False,
            }
        },
        'explicit_json': False
    }
    formatter = JSONFormatter(**kwargs)
    formatter.kwargs = kwargs
    formatter.kwargs['format_options'] = kwargs['format_options']

# Generated at 2022-06-23 19:31:02.258131
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': False,
                'indent': 3,
                'sort_keys': True
            }
        }
    )
    assert(formatter is not None)


# Generated at 2022-06-23 19:31:12.599226
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    instance = JSONFormatter()
    instance.format_options['json']['format'] = True
    instance.kwargs['explicit_json'] = True
    instance.format_options['json']['indent'] = 2
    instance.format_options['json']['sort_keys'] = True
    # test valid json
    formatted_body = instance.format_body('{"a": 5, "b": 3}', 'json')
    assert formatted_body == '{\n  "a": 5,\n  "b": 3\n}'
    # test invalid json
    formatted_body = instance.format_body('{"a": 5, "b": 3', 'json')
    assert formatted_body == '{"a": 5, "b": 3'
    # test json not set in content-type

# Generated at 2022-06-23 19:31:17.570571
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().format_options['json']['format'] == False
    assert JSONFormatter().format_options['json']['sort_keys'] == True
    assert JSONFormatter().format_options['json']['indent'] == 2
    assert JSONFormatter().kwargs['explicit_json'] == False
    assert JSONFormatter().enabled == False


# Generated at 2022-06-23 19:31:24.394328
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    # [Test 1] Only indent and sort_keys option, JSON valid
    json.loads(formatter.format_body(body='{"a": 1}', mime='application/json'))
    json.loads(formatter.format_body(body='{"b": 1}', mime='application/json'))

    # [Test 2] Only indent and sort_keys option, JSON invalid
    formatter.format_body(body='{"a": 1', mime='application/json')

    # [Test 3] Explicit json and indent and sort_keys option, JSON valid
    formatter.kwargs['explicit_json'] = True
    json.loads(formatter.format_body(body='{"a": 1}', mime='application/json'))

# Generated at 2022-06-23 19:31:33.427546
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fp = JSONFormatter()

# Generated at 2022-06-23 19:31:34.529325
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter


# Generated at 2022-06-23 19:31:43.321737
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    x = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    y = JSONFormatter(format_options={'json': {'format': False, 'sort_keys': True, 'indent': 4}})

    assert "a" == x.format_body("a", "whatever")
    assert '[1, 2, 3]' == x.format_body('[1, 2, 3]', "whatever")
    assert '{\n    "a": 1,\n    "b": 2\n}' == x.format_body('{"a": 1, "b": 2}', "whatever")

# Generated at 2022-06-23 19:31:49.216421
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 0
            },
            'colors': {
                'header': 'yellow',
                'body': 'white'
            },
            'styles': {
                'header': 'bold',
                'body': 'normal'
            }
        }
    )

# Generated at 2022-06-23 19:31:52.717160
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"foo": "bar"}'
    mime = 'json'
    formatter_plugin = JSONFormatter(explicit_json=True, format_options={"json": {"sort_keys":True, "indent":4}})
    formatted_body = formatter_plugin.format_body(body, mime)
    assert formatted_body == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 19:32:02.047604
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {
        'format': True,
        'sort_keys': True,
        'indent': 2}},
                                    kwargs={'explicit_json': False})
    body = json_formatter.format_body('{"b": "bbb", "a": "aaa"}', 'json')
    assert body == ('{\n'
                    '  "a": "aaa",\n'
                    '  "b": "bbb"\n'
                    '}')
    body = json_formatter.format_body('{"b": "bbb", "a": "aaa"}', 'html')
    assert body == '{"b": "bbb", "a": "aaa"}'

# Generated at 2022-06-23 19:32:10.775436
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    )
    formatter.kwargs = {'explicit_json': True}

    # 1. mime: application/json and body is a valid json
    mime = 'application/json'
    body = json.dumps({'a': 1, 'c': 2, 'b': 3})
    expected = json.dumps({'a': 1, 'c': 2, 'b': 3}, sort_keys=True, indent=4, ensure_ascii=False)
    assert formatter.format_body(body, mime) == expected

    # 2. mime: application/json and body is not a valid json
    mime = 'application/json'

# Generated at 2022-06-23 19:32:14.893466
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json':{'format': True, 'sort_keys':True, 'indent':4}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options == {'json':{'format': True, 'sort_keys':True, 'indent':4}}


# Generated at 2022-06-23 19:32:25.937809
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fp = JSONFormatter()
    assert fp.format_body('1', 'text') == '1'
    assert fp.format_body('1', 'json') == '1'
    assert fp.format_body('{"a": 1}', 'json') == '{"a": 1}'
    assert fp.format_body('{"a": 1}', 'text') == '{"a": 1}'
    assert fp.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert fp.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert fp.format_body('{"a": 1}', '') == '{"a": 1}'

# Generated at 2022-06-23 19:32:31.365613
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    obj = {
        "test": 1,
        "test_2": "test"
    }
    my_json = json.dumps(obj)
    formatter = JSONFormatter()
    formatter.format_options['json']['indent'] = 4
    assert formatter.format_body(body=my_json, mime='application/json') == my_json

# Generated at 2022-06-23 19:32:41.607419
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test 1
    expected = '{"foo": "bar"}'
    assert expected == json.dumps(obj={'foo': 'bar'}, sort_keys=False, ensure_ascii=False, indent=4)

    # Test 2
    expected = '{"foo": "bar"}'
    assert expected == json.dumps(obj={'foo': 'bar'}, sort_keys=True, ensure_ascii=False, indent=4)

    # Test 3
    expected = '{"foo": "bar"}'
    assert expected == json.dumps(obj={'foo': 'bar'}, sort_keys=False, ensure_ascii=True, indent=4)

    # Test 4
    expected = '{"foo": "bar"}'

# Generated at 2022-06-23 19:32:47.281413
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '''{
        "foo": "bar",
        "baz": "qux",
        "corge": null
    }'''
    assert json_formatter.format_body(body, "application/json") == '''{
        "baz": "qux",
        "corge": null,
        "foo": "bar"
    }'''

# Generated at 2022-06-23 19:32:54.952809
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    data = '{"first_name": "Jhon", "last_name": "Doe",' \
           '"age": 24, "married": false}'
    assert JSONFormatter().format_body(data, 'application/json') == \
        '{\n    "age": 24,\n    "first_name": "Jhon",\n    "last_name":' \
        ' "Doe",\n    "married": false\n}'
    assert JSONFormatter().format_body(data, 'json') == \
        '{\n    "age": 24,\n    "first_name": "Jhon",\n    "last_name":' \
        ' "Doe",\n    "married": false\n}'

# Generated at 2022-06-23 19:33:03.658777
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Testing of method format_body() of class JSONFormatter. This method is called by JSONFormatter.format()
    if format_options['json']['format'] is True.
    :return:
    """
    json_formatter = JSONFormatter()
    body_str = '{"this_is":"json"}'
    mime = 'application/json'  # Valid 'json' mime_type
    expected_str = '{\n    "this_is": "json"\n}'
    assert json_formatter.format_body(body_str, mime) == expected_str
    # If mime_type is not 'json', 'javascript' or 'text' (no explicit JSON in the request),
    # then original body_str is returned
    mime = 'text/plain'

# Generated at 2022-06-23 19:33:05.220691
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(**{})
    assert isinstance(json_formatter, JSONFormatter)

# Generated at 2022-06-23 19:33:13.818551
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for method format_body of class JSONFormatter,
    # if request mime is JSON or contains JSON
    # and body is not JSON, it should not be modified
    class MockJSONFormatter(JSONFormatter):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.kwargs = kwargs
            self.format_options = {
                'json': {
                    'format': True,
                    'indent': None,
                    'sort_keys': False
                }
            }
        def format_headers(self, headers):
            pass
    not_json_body = "body without brackets"
    body_json = MockJSONFormatter().format_body(not_json_body, "json")
    assert body_json == not_json_body

# Generated at 2022-06-23 19:33:15.077462
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jo = JSONFormatter()
    assert jo.enabled == False


# Generated at 2022-06-23 19:33:20.899551
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": "b"}'
    formatter = JSONFormatter(format_options={
        'colors': {'body': 'red'},
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    })
    assert formatter.format_body(body=body, mime='application/json') == body

# Generated at 2022-06-23 19:33:28.266174
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'indent': 4, 'sort_keys': False, 'format': True}}, explicit_json=False)
    assert formatter.enabled is True
    assert formatter.kwargs['explicit_json'] is False
    assert formatter.kwargs['format_options'] == {'json': {'indent': 4, 'sort_keys': False, 'format': True}}


# Generated at 2022-06-23 19:33:37.149628
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=False)
    assert formatter.format_options == {
        "json": {
            "format": False,
            "indent": 2,
            "sort_keys": True,
        },
        "colors": {
            "request_method": None,
            "remote_user": None,
            "remote_server": None,
            "status_code": None,
            "total_time": None,
        },
    }
    assert formatter.enabled == False
    assert formatter.kwargs == {
        "explicit_json": False,
    }

# Generated at 2022-06-23 19:33:43.937211
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.formatter import JSON_FORMAT_CONFIG
    j = JSONFormatter(JSON_FORMAT_CONFIG)
    assert j.format_body('{ "id": 1 }', 'json') == '{\n    "id": 1\n}'
    assert j.format_body('{ "id": 1 }', 'javascript') == '{\n    "id": 1\n}'
    assert j.format_body('{ "id": 1 }', 'text') == '{\n    "id": 1\n}'
    assert j.format_body('{ "id": 1 }', 'html') == '{ "id": 1 }'



# Generated at 2022-06-23 19:33:54.120416
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{}', 'json') == '{}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"b": 2, "a": 1}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-23 19:34:01.128138
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_json_object = """{
        "key": "value"
    }"""
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 12,
            'sort_keys': True
        }
    }, kwargs={'explicit_json': False})
    assert formatter.format_body(test_json_object, 'json') == """{
            "key": "value"
        }"""

# Generated at 2022-06-23 19:34:09.664880
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import JSONFormatter
    env = Environment()
    plugin_manager.register(JSONFormatter)
    # test json
    env.config['json'] = {
        'format': True,
        'sort_keys': True,
        'indent': True
    }
    json_formatter = plugin_manager.get('JSONFormatter')
    assert json_formatter.kwargs['explicit_json'] == False
    assert json_formatter.format_options['json']['sort_keys'] == True
    assert json_formatter.format_options['json']['indent'] == True
    assert json_formatter.format_options['json']['format'] == True

# Generated at 2022-06-23 19:34:21.464424
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    # Input is a valid JSON
    body = '{"key1":"value1"}'
    expected = '{"key1": "value1"}'
    actual = formatter.format_body(body=body, mime='application/json')
    assert actual == expected

    # Input is not a valid JSON
    body = '{"key1":"value1"'
    expected = '{"key1":"value1"'
    actual = formatter.format_body(body=body, mime='application/json')
    assert actual == expected

    # Input is a valid JSON
    body = '{"key1":"value1"}'
    expected = '{"key1":"value1"}'
    actual = formatter.format_body(body=body, mime='text/html')
    assert actual == expected

    # Input is

# Generated at 2022-06-23 19:34:29.508120
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print("\n==== Start Testing JSONFormatter.format_body ====")
    fp = JSONFormatter()
    body = "this is a test string"
    mime = "not json"
    assert fp.format_body(body, mime) == body
    body = '{"name": "charles"}'
    mime = "application/json"
    assert fp.format_body(body, mime) == '{\n    "name": "charles"\n}'
    print("==== End of Testing JSONFormatter.format_body ====")


# Generated at 2022-06-23 19:34:33.963111
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=True,
                              format_options={"json": {"indent": 2}})
    assert formatter.format_options['json']['indent'] == 2



# Generated at 2022-06-23 19:34:43.538641
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import BuiltinPluginManager
    from httpie import ExitStatus
    manager = BuiltinPluginManager()
    processor = JSONFormatter(manager=manager)
    obj = {
        "a": [1, 2, 3],
        "b": {
            "d": [1, 2, 3],
            "e": [1, 2, 3]
        }
    }
    obj_bytes = json.dumps(obj).encode('utf-8')
    kwargs = {
        'headers': None,
        'explicit_json': True,
        'output_options': None,
        'style': None,
        'format_options': {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        }
    }

# Generated at 2022-06-23 19:34:48.385922
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = FormatterPlugin(format_options={'json': {'format': True, 'indent': 2, 'sort_keys':False}})
    assert f.format_options['json']['format'] == True
    assert f.format_options['json']['indent'] == 2
    assert f.format_options['json']['sort_keys'] == False


# Generated at 2022-06-23 19:34:55.401102
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Unit test for method format_body of class JSONFormatter.
    """

    # Test case when JSONFormatter is initialized with explicit_json=True
    json_formatter = JSONFormatter(explicit_json=True)

    # Test a case when the content is json
    json_str = """{
        "property_name": "property_value",
        "another_property": "another_property_value"
    }"""
    formatted_json_str = json_formatter.format_body(
        body=json_str,
        mime='application/json'
    )
    assert formatted_json_str == """{
    "another_property": "another_property_value",
    "property_name": "property_value"
}"""

    # Test a case when the content is not json
    non_json_

# Generated at 2022-06-23 19:35:05.172603
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import requests
    from httpie._compat import urlopen

    def get_plugin():
        return JSONFormatter(kwargs={'explicit_json':False})

    def test_json_format(url):
        # Request for headers and body
        r = requests.get(url)
        headers, body = r.headers, r.content if r.encoding == 'utf-8' else r.content.decode('utf-8')
        # Get JSON formatter plugin
        plugin = get_plugin()
        # Run format_body method
        fbody = plugin.format_body(body, headers['content-type'])
        # Get the same body directly from URL
        r = urlopen(url)
        url_body = r.read().decode('utf-8')

# Generated at 2022-06-23 19:35:12.638580
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        formats=['json'],
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False,
        syntax=None,
        colors=None,
        style=None,
        streams=None,
        stdin_isatty=False
    )

    # Test with JSON body
    body = '{ "key1" : "value1", "key2" : "value2" }'
    res = formatter.format_body(body, 'application/json')
    assert res == '{\n    "key1": "value1",\n    "key2": "value2"\n}'

    # Test with invalid JSON body

# Generated at 2022-06-23 19:35:23.698696
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    request = {
        "url": "https://httpbin.org/post",
        "headers": {"content-type": "application/json"},
        "data": {"some": "data"}
    }

    plugin = JSONFormatter(explicit_json=False,
                           format_options={"json": {"format": True,
                                                    "indent": 2,
                                                    "sort_keys": True}},
                           **request)

    assert plugin.format_body("{}", "application/json") == "{}"
    assert plugin.format_body("{}", "application/javascript") == "{}"
    assert plugin.format_body("{}", "text") == "{}"
    assert plugin.format_body("{}", "") == "{}"



# Generated at 2022-06-23 19:35:30.873866
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_format = JSONFormatter(None, {'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    mime = ['application/json', 'text/json', 'application/javascript']
    body = '{"aaa": 1, "bbb": 2, "ccc": 3, "ddd": 4, "eee": 5, "fff": 6}'
    assert json_format.format_body(body, mime) == '{\n  "aaa": 1,\n  "bbb": 2,\n  "ccc": 3,\n  "ddd": 4,\n  "eee": 5,\n  "fff": 6\n}'

# Generated at 2022-06-23 19:35:40.129619
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # JSONFormatter(mime=application/json)
    assert JSONFormatter(mime='application/json').format_body('1', 'application/json') == '1'
    assert JSONFormatter(mime='application/json').format_body('[1,2]', 'application/json') == '1,2'
    assert JSONFormatter(mime='application/json').format_body('{}', 'application/json') == '{}'
    assert JSONFormatter(mime='application/json').format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert JSONFormatter(mime='application/json').format_body('[1,2]', 'application/json') == '1,2'

# Generated at 2022-06-23 19:35:48.878201
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    obj = {
        'a': 'b',
        'zxc': 123,
        'zd': 'ert',
    }
    mime = 'json'
    body = '{"a": "b", "zxc": 123, "zd": "ert"}'
    formatter = JSONFormatter(mime=mime, body=body, explicit_json=False, format_options={'json': {'format': True, 'ensure_ascii': True, 'indent': 4, 'sort_keys': False}})
    expected_res = json.dumps(
                    obj=obj,
                    sort_keys=False,
                    ensure_ascii=True,
                    indent=4
                )
    assert formatter.format_body(body, mime) == expected_res
    mime = 'json'
   

# Generated at 2022-06-23 19:35:50.702717
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert isinstance(formatter, FormatterPlugin)
    assert formatter.enabled

# Unit tests for format_body method of class JSONFormatter

# Generated at 2022-06-23 19:35:53.124413
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.core import main

    from httpie.plugins.json_formatter import JSONFormatter
    assert main.FORMATTERS_MAP['json'] == JSONFormatter

# Generated at 2022-06-23 19:35:54.057144
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-23 19:35:58.891010
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{"test": "value"}', '') == '{\n    "test": "value"\n}'
    assert JSONFormatter(explicit_json=True).format_body('{"test": "value"}', '') == '{\n    "test": "value"\n}'


# Generated at 2022-06-23 19:36:08.191490
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from .responses import Response
    from .http import HttpRequest
    from httpie.compat import str
    from httpie.formatters import JSONFormatter
    from collections import OrderedDict

    request = HttpRequest('http://example.org/')
    response = Response()
    response.http_version = 'HTTP/1.1'
    response.status_code = '200'
    response.reason = 'OK'
    response.headers = OrderedDict()
    response.headers['Connection'] = 'close'
    response.headers['Content-Type'] = 'application/json'
    response.headers['Server'] = 'SimpleHTTP/0.6 Python/2.7.12'
    response.headers['Date'] = 'Tue, 27 Dec 2016 12:12:27 GMT'

# Generated at 2022-06-23 19:36:15.144614
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    x = JSONFormatter()
    # Given a JSON body,
    # expect that it stays the same
    assert x.format_body('{"a":1}', 'json') == '{"a":1}'
    # expect that it stays the same
    assert x.format_body('{"a":1}', 'text') == '{"a":1}'
    # expect that it stays the same
    assert x.format_body('{"a":1}', 'javascript') == '{"a":1}'
    # Given a plain body,
    # expect that it stays the same
    assert x.format_body('Non-JSON', 'text') == 'Non-JSON'
    # expect that it stays the same
    assert x.format_body('Non-JSON', 'anything-else') == 'Non-JSON'

# Generated at 2022-06-23 19:36:20.967609
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter({
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert jsonformatter.enabled
    assert jsonformatter.format_options == {'json': {
        'format': True,
        'indent': 4,
        'sort_keys': True
    }}


# Generated at 2022-06-23 19:36:26.282685
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "[{}, {}]"
    mime = "application/json"

    formatter = JSONFormatter()
    body = formatter.format_body(body, mime)
    expected_body = json.dumps(
        obj=[{}, {}],
        sort_keys=True,
        ensure_ascii=False,
        indent=4
    )
    assert body == expected_body

# Generated at 2022-06-23 19:36:34.262708
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    mime = 'json'
    json_str = '''{\
        "full_name": "Kenneth Reitz", \
        "favorite_numbers": [7, 9, 42]\
    }'''

    formatted_json = json_formatter.format_body(json_str, mime)

    expected = '''{
        "favorite_numbers": [
            7,
            9,
            42
        ],
        "full_name": "Kenneth Reitz"
    }'''

    assert formatted_json == expected

# Generated at 2022-06-23 19:36:39.604348
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    plugin = JSONFormatter()
    json_str = '''{
        "key": "value",
        "key2": "value2"
    }'''
    html_str = '<html></html>'
    assert plugin.format_body(json_str, 'json') == json_str
    assert plugin.format_body(json_str, 'text') == json_str
    assert plugin.format_body(html_str, 'text') == html_str

# Generated at 2022-06-23 19:36:41.383851
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.color_mode == 'auto'
    assert not formatter.enabled


# Generated at 2022-06-23 19:36:46.709809
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fixture = {'json': {'format': True, 'indent': 1, 'sort_keys': True}}
    plugin = JSONFormatter(format_options=fixture)
    assert plugin.format_options['json']['format'] == True
    assert plugin.format_options['json']['indent'] == 1
    assert plugin.format_options['json']['sort_keys'] == True


# Generated at 2022-06-23 19:36:47.656218
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert 1 == 1


# Generated at 2022-06-23 19:36:54.400151
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}},
        explicit_json=True
    )
    assert formatter.enabled == True
    assert formatter.kwargs == {'explicit_json': True}


# Generated at 2022-06-23 19:36:56.089406
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(**json_kwargs)
    assert formatter.kwargs == json_kwargs

# Generated at 2022-06-23 19:37:04.802717
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  import pytest
  # Test instantiation of JSON Formatter plugin
  # as well as the default-setting functionality
  jsonf = JSONFormatter(format_options = 
    {'json': {'ensure_ascii': True, 'indent': 4, 'sort_keys': False}})
  assert jsonf.format_options['json']['format'] == True
  assert jsonf.format_options['json']['indent'] == 4
  assert jsonf.format_options['json']['sort_keys'] == False
  assert jsonf.format_options['json']['ensure_ascii'] == True
  with pytest.raises(KeyError):
      jsonf.format_options['json']['foo']


# Generated at 2022-06-23 19:37:10.647052
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    with http('--json', 'GET', 'http://localhost:8585/_headers') as r:
        assert r.exit_status == ExitStatus.OK
        assert HTTP_OK in r

# Generated at 2022-06-23 19:37:19.181134
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    class JSONFormatter(object):

        def __init__(self):
            self.format_options = {
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4
            }
        }
            self.kwargs = {
                'explicit_json': True
            }

        def format_body(self, body: str, mime: str) -> str:
            return body

    assert JSONFormatter().format_options['json']['format']
    assert JSONFormatter().kwargs['explicit_json']

# Generated at 2022-06-23 19:37:19.708782
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-23 19:37:29.299969
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Prepare data
    body = '{"name": "value"}'

    # Prepare JSONFormatter obj
    args = {'explicit_json': True,
            'json_sort_keys': False,
            'json_indent': 8}
    json_formatter = JSONFormatter(**args)

    # Assert
    assert json_formatter.format_body(body=body, mime='unrecognized/mime') == body
    assert json_formatter.format_body(body=body, mime='application/json') != body
    assert json_formatter.format_body(body=body, mime='application/json') == ('{\n'
    '        "name": "value"\n'
    '}' )

# Generated at 2022-06-23 19:37:32.200069
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(
        format_options={
            # this is the only line we care about
            'json': {'format': True, 'sort_keys': False, 'indent': 4}
        },
        explicit_json=False,
        color=False
    )


# Generated at 2022-06-23 19:37:35.760626
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter({'json': {'format': True}})
    assert formatter.enabled == True

# Generated at 2022-06-23 19:37:36.334787
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_formatter = JSONFormatter()

# Generated at 2022-06-23 19:37:47.735770
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py26
    from httpie.plugins import FormatterPlugin

    json_formatter = JSONFormatter()

    if not is_py26:
        assert True
    else:
        pass

    content_type = 'application/json'

# Generated at 2022-06-23 19:37:54.377383
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 2
            }
        },
        explicit_json=True
    )
    assert json_formatter.enabled
    assert not json_formatter.format_options['json']['sort_keys']
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.kwargs['explicit_json']


# Generated at 2022-06-23 19:37:58.400463
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter(
        format_options = {
            "json": {
                "format": True,
                "sort_keys": False,
                "indent": 4
            }
        }
    )
    return j


# Generated at 2022-06-23 19:38:02.916816
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from click.testing import CliRunner
    from httpie.cli import main
    from httpie.compat import is_windows
    from httpie.output.formatters import JSONFormat

    runner = CliRunner()
    result = runner.invoke(
        main, ['--json']
    )
    assert result.exit_code == 0
    assert JSONFormat().format_options['json']['format'] == True

# Generated at 2022-06-23 19:38:12.315910
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.format_options = {
        'json': {
            'format': 0,
            'sort_keys': 0,
            'indent': 0,
            'align_keys': 0,
            'allow_multiple_values': 0,
            'preserve_multiple_values': 0
        }
    }
    
    test_data = json.dumps({'key': 'value'})
    
    assert formatter.format_body(test_data, 'json') == json.dumps(json.loads(test_data), sort_keys=False, indent=None, ensure_ascii=True)
    

# Generated at 2022-06-23 19:38:13.993600
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter is not None

# Generated at 2022-06-23 19:38:23.238193
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.builtin import JSONOutputFormat
    from httpie import ExitStatus
    from utils import http, HTTP_OK, CRLF
    from pygments.lexers.json import JsonLexer
    from pygments.formatters import TerminalFormatter

    json_data = {'k1': 'v1', 'k2': [1,2]}
    json_bytes = json.dumps(json_data, sort_keys=True, indent=2)

    formatter_plugin = JSONFormatter(format_options={'json': {
        'format': True,
        'sort_keys': True,
        'indent': 2
    }})


# Generated at 2022-06-23 19:38:26.828466
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert not JSONFormatter().format_options['json']['format']
    assert JSONFormatter(format_options={
        'json': {'format': False}
    }).format_options['json']['format']


# Generated at 2022-06-23 19:38:34.896334
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    assert formatter.format_body('{}', 'application/json') == '{\n}'
    assert formatter.format_body('{}', 'text/html') == '{}'
    assert formatter.format_body('{}', 'text/javascript') == '{\n}'
    assert formatter.format_body('', 'text/javascript') == ''
    assert formatter.format_body('"not json"', 'text/javascript') == '"not json"'



# Generated at 2022-06-23 19:38:43.162657
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.cli.parser import parse_key_value
    from httpie.plugins import build_format_options

    json_formatter = JSONFormatter(**{
        'format_options': build_format_options({
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            },
        }),
        'explicit_json': False,
    })

    args = parse_key_value('')
    formatter = json_formatter.format_body
    assert formatter('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter('', 'json') == ''
    assert formatter('', 'text') == ''

# Generated at 2022-06-23 19:38:48.021011
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert(jf.enabled is False)
    jf = JSONFormatter(format_options={'json': {'format': True}})
    assert(jf.enabled is True)


# Generated at 2022-06-23 19:38:55.493532
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"foo": "bar"}'
    assert JSONFormatter.format_body(body, 'application/json') == body
    body = '{"foo": "bar"}'
    assert JSONFormatter.format_body(body, 'application/javascript') == body
    body = 'something not json'
    assert JSONFormatter.format_body(body, 'application/javascript') != body
    body = 'something not json'
    assert JSONFormatter.format_body(body, 'text/plain') !=  body

# Generated at 2022-06-23 19:39:02.151564
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body("ABC", "text") == "ABC"
    assert JSONFormatter().format_body("ABC", "text/x") == "ABC"
    assert JSONFormatter().format_body("ABC", "text/javascript") == "ABC"
    assert JSONFormatter().format_body("ABC", "application/json") == "ABC"
    assert '"name": "httpie"' in JSONFormatter().format_body("{\"name\": \"httpie\"}", "application/json")

# Generated at 2022-06-23 19:39:10.836675
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    args = {
        'indent': 'indent',
        'sort_keys': True
    }
    options = {
        'explicit_json': True,
        'format_options': {
            'json': args
        }
    }
    formatter = JSONFormatter(**options)
    assert formatter.format_options['json']['indent'] == args['indent']
    assert formatter.format_options['json']['sort_keys'] == args['sort_keys']
    assert formatter.kwargs['explicit_json'] == True
    assert formatter.enabled == True


# Generated at 2022-06-23 19:39:14.722856
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = dict()
    formatter['json'] = dict()
    formatter['json']['sort_keys'] = False
    formatter['json']['indent'] = 4
    formatter['json']['format'] = True
    JSONFormatter(format_options=formatter)


# Generated at 2022-06-23 19:39:23.401225
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import json
    from httpie.plugins import _format_options

    # Arrange
    token = 'application/json'
    body = '''{
        "key_one": 1,
        "key_two": "str",
        "key_three": {"dict": 3}
    }'''
    expected = '''{
    "key_one": 1,
    "key_two": "str",
    "key_three": {
        "dict": 3
    }
}'''
    formatter = json.JSONFormatter(**_format_options)
    formatter.kwargs['explicit_json'] = False

    # Act
    actual = formatter.format_body(body, token)

    # Assert
    assert expected == actual

test_JSONFormatter_format_body()

# Generated at 2022-06-23 19:39:33.027805
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    kwargs = {}
    kwargs['format_options'] = {}
    kwargs['format_options']['json'] = {}
    kwargs['format_options']['json']['format'] = True
    kwargs['format_options']['json']['sort_keys'] = True
    kwargs['format_options']['json']['indent'] = 4
    kwargs['explicit_json'] = True

    json_formatter = JSONFormatter(**kwargs)
    assert json_formatter.format_options == kwargs['format_options']
    assert json_formatter.kwargs == kwargs


# Generated at 2022-06-23 19:39:34.576513
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(json={'sort_keys': 1, 'indent': 2, 'format': True})

# Generated at 2022-06-23 19:39:40.129277
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    json_formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mimetype = 'application/json'
    expected_body = '{\n    "a": 1, \n    "b": 2\n}'

    # Act
    formatted_body = json_formatter.format_body(body, mimetype)

    # Assert
    assert formatted_body == expected_body

# Generated at 2022-06-23 19:39:49.783512
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    # Case 1: the body is not in JSON format
    body = "This is not a JSON"
    mime = "text"
    result = json_formatter.format_body(body, mime)
    assert result == body

    # Case 2: the body is in JSON format
    body = '{"key1": "value1", "key2": "value2"}'
    mime = "application/json"
    result = json_formatter.format_body(body, mime)

    # Case 2.1: sort keys is true
    json_formatter.format_options['json']['sort_keys'] = True
    mime = "application/json"
    result2 = json_formatter.format_body(body, mime)

# Generated at 2022-06-23 19:39:52.914371
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(format_options = {'format': True, 'json': {'sort_keys': True, 'indent': 2}})
    assert f.enabled == True
    assert f.format_options['json']['sort_keys'] == True
    assert f.format_options['json']['indent'] == 2
