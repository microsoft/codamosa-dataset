

# Generated at 2022-06-23 19:29:52.586447
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsf = JSONFormatter(kwargs=dict(explicit_json=True), format_options=dict(json='format'))
    assert(jsf.enabled == 'format')



# Generated at 2022-06-23 19:29:55.005201
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    s = JSONFormatter()

# Generated at 2022-06-23 19:30:01.400527
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = FormatterPlugin(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    body = '{"a": 1, "b": 2}'
    actual = json.loads(formatter.format_body(body=body, mime='application/json'))
    expected = {'a': 1, 'b': 2}
    assert actual == expected

# Generated at 2022-06-23 19:30:06.825364
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    # test 1
    value = '{"b": "c"}'
    formatter.kwargs = {'explicit_json': True}
    assert formatter.format_body(value, "test") == '{\n    "b": "c"\n}'

    # test 2
    value = '{"a": "b", "c": "d"}'
    formatter.kwargs = {'explicit_json': False}
    assert formatter.format_body(value, "test") == '{"a": "b", "c": "d"}'

# Generated at 2022-06-23 19:30:13.571808
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    maybe_json = [
        'json',
        'javascript',
        'text',
    ]
    # If JSON is explicitely requested, format even invalid JSON
    json_formatter = JSONFormatter(kwargs={'explicit_json': True})
    result_body = json_formatter.format_body('{"a":42, "b":4711}', maybe_json)
    assert result_body == '{\n    "a": 42,\n    "b": 4711\n}'
    result_body = json_formatter.format_body('{"a":42, b":4711}', maybe_json)
    assert result_body == '{"a":42, b":4711}'

    # Otherwise, don't do anything if the body is not proper JSON

# Generated at 2022-06-23 19:30:18.072327
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test format_body method of JSONFormatter class.
    """
    json_formatter = JSONFormatter()

# Generated at 2022-06-23 19:30:20.970243
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {'json': {'indent': 'indent', 'format': 'format'}}
    pretty = {'pretty': 'pretty'}
    formatter = JSONFormatter(format_options=format_options, **pretty)
    assert formatter.enabled == 'format'

# Generated at 2022-06-23 19:30:27.617280
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(**{'format_options': {
        'json': {'format': True, 'indent': 20, 'sort_keys': False}
    }})
    assert json_formatter.enabled is True
    assert json_formatter.format_options['json']['indent'] == 20
    assert json_formatter.format_options['json']['sort_keys'] is False


# Generated at 2022-06-23 19:30:29.094897
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__init__ is not None


# Generated at 2022-06-23 19:30:30.862356
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': False
            }
        }
    )


# Generated at 2022-06-23 19:30:34.078927
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from plugins import get_plugin
    plugins = get_plugin()
    json_formatter = plugins[0]
    assert isinstance(json_formatter, JSONFormatter)
    assert json_formatter.enabled


# Generated at 2022-06-23 19:30:38.479169
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(
        format_options={'json': {'format': True, 'indent': 4}},
        explicit_json=False
    ).format_options['json']['indent'] == 4
    assert JSONFormatter(
        format_options={'json': {'format': True, 'indent': 4}},
        explicit_json=False
    ).kwargs['explicit_json'] == False



# Generated at 2022-06-23 19:30:41.041557
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert isinstance(json_formatter.kwargs, dict)


# Generated at 2022-06-23 19:30:42.480212
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter=JSONFormatter()
    assert jsonFormatter is not None

# Generated at 2022-06-23 19:30:50.709660
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"a": 1, "b": 2, "c": {"aa": 1, "bb": 2}}'
    mime = 'json'
    assert json_formatter.format_body(body=body, mime=mime) == '{\n    "a": 1, \n    "b": 2, \n    "c": {\n        "aa": 1, \n        "bb": 2\n    }\n}'
    body = "{'a': 1, 'b': 2, 'c': {'aa': 1, 'bb': 2}}"
    mime = 'json'

# Generated at 2022-06-23 19:30:55.979116
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__base__ == FormatterPlugin
    assert JSONFormatter.__init__.__defaults__ == (None, None)

    import httpie.plugins
    json_formatter = JSONFormatter()
    assert json_formatter.kwargs == {
        'explicit_json': False, 'format_options': httpie.plugins.default_options}
    assert json_formatter.enabled == False
    assert not json_formatter.kwargs['explicit_json']
    assert json_formatter.kwargs['format_options']['json']['format'] == False
    assert json_formatter.kwargs['format_options']['json']['indent'] == 2
    assert json_formatter.kwargs['format_options']['json']['sort_keys'] == False

    json_form

# Generated at 2022-06-23 19:30:56.570952
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter() != None

# Generated at 2022-06-23 19:31:01.869389
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.builtin import JSONFormatter
    formatter = JSONFormatter()
    body = "{'key1': 'value1', 'key2': 'value2'}"
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "key1": "value1", \n    "key2": "value2"\n}'
    body = "{'key1': 'value1', 'key2': 'value2'}"
    mime = 'anything'
    assert formatter.format_body(body, mime) == body



# Generated at 2022-06-23 19:31:04.635697
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': False}})
    assert type(jf.format_options) == dict

# Generated at 2022-06-23 19:31:15.026395
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body('{"a":1}', 'application/json') == '{\n    "a": 1\n}'
    assert JSONFormatter.format_body('\n{"a":1}', 'text/json') == '{\n    "a": 1\n}'
    assert JSONFormatter.format_body('{"a":1}', 'application/json; charset=utf-8') == '{\n    "a": 1\n}'
    assert JSONFormatter.format_body('{"a":1}', 'application/javascript') == '{\n    "a": 1\n}'
    assert JSONFormatter.format_body('{"a":1}', 'text/plain') == '{\n    "a": 1\n}'

# Generated at 2022-06-23 19:31:18.663839
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformat = JSONFormatter(**{'json': {'format': True, 'indent': 4, 'sort_keys': True}, 'colors': 2, 'format': 'colors'})
    assert jsonformat.enabled == True
    assert jsonformat.kwargs == {'colors': 2, 'format': 'colors'}
    assert jsonformat.format_options['json']['indent'] == 4


# Generated at 2022-06-23 19:31:29.616162
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def assert_format(text, expected_formatted_text, format_options=None,
                      explicit_json=False, mime='application/json'):
        # Arrange
        formatter = JSONFormatter(format_options=format_options,
                                  explicit_json=explicit_json,
                                  mime=mime)

        # Act
        result = formatter.format_body(text, mime)

        # Assert
        assert result == expected_formatted_text

    # Input has correct JSON
    formatter_options = {
        "json": {
            "format": True,
            "sort_keys": True,
            "indent": 4
        }
    }
    text = '{"a": "b"}'

# Generated at 2022-06-23 19:31:31.762152
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] is True
    assert formatter.format_options['json']['indent'] is 4

# Generated at 2022-06-23 19:31:36.389803
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'sort_keys': True, 'format': True, 'indent': 4}})
    assert formatter.enabled == True
    assert formatter.format_options == {'json': {'sort_keys': True, 'format': True, 'indent': 4}}
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-23 19:31:37.236713
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a=JSONFormatter()
    assert a.enabled

# Generated at 2022-06-23 19:31:45.030859
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': False, 'indent': 2, 'sort_keys': False}}, kwargs={'explicit_json': False})
    body_json = '{"key": "value"}'
    body_text = 'just plain text'
    mime_json = 'application/json'
    mime_text = 'text/plain'
    assert json_formatter.format_body(body_json, mime_json) == body_json
    assert json_formatter.format_body(body_text, mime_text) == body_text

    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}}, kwargs={'explicit_json': False})


# Generated at 2022-06-23 19:31:47.116510
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert(formatter.__class__.__name__=='JSONFormatter')

# Generated at 2022-06-23 19:31:47.736703
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter != None


# Generated at 2022-06-23 19:31:58.504376
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False
    ).format_body(
        '{"id": 1}',
        'application/json'
    ) == '{\n    "id": 1\n}'

    assert JSONFormatter(
        format_options={
            'json': {
                'format': False,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False
    ).format_body(
        '{"id": 1}',
        'application/json'
    ) == '{"id": 1}'


# Generated at 2022-06-23 19:32:05.151892
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"name": "Foo", "number": 2}'
    mime = 'application/json'
    kwargs = {'explicit_json': True, 'json': {'format': True, 'indent': 2}}
    json_formatter = JSONFormatter(**kwargs)
    assert json_formatter.format_body(body=body, mime=mime) == '{\n  "name": "Foo",\n  "number": 2\n}'

# Generated at 2022-06-23 19:32:06.742090
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    c = JSONFormatter()
    c.format_body('{"abc" : "efg"}', 'application/json')

# Generated at 2022-06-23 19:32:07.286881
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-23 19:32:15.155778
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	from httpie.plugins import FormatterPlugin


# Generated at 2022-06-23 19:32:18.854079
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    tester = JSONFormatter(format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert tester.enabled


# Generated at 2022-06-23 19:32:22.988248
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.core import Formatter
    formatter = Formatter(format='JSONFormatter')
    assert formatter.__class__.__name__ is 'JSONFormatter'

# Generated at 2022-06-23 19:32:24.509374
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.format_options['json']['format'] == True

# Generated at 2022-06-23 19:32:27.549251
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    json_data = json.dumps({'key': 'value'})
    assert formatter.format_body('{', 'json') == '{'
    assert formatter.format_body(json_data, 'json') == json_data
    assert formatter.format_body(json_data, 'text') == json_data



# Generated at 2022-06-23 19:32:35.212632
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.enabled
    assert formatter.kwargs['explicit_json']
    body = '{"hello": "world"}'
    mime = 'json'
    pretty_body = json.dumps(json.loads(body), indent=4)
    assert formatter.format_body(body, mime) == pretty_body
    assert formatter.format_body('bla bla', 'mimetype') == 'bla bla'



# Generated at 2022-06-23 19:32:43.579940
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'application/json'
    json_data = {"a": 1, "b": 2, "c": 3}
    json_data_sorted = '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    # It should not modify the JSON body if the mime type is not json
    assert JSONFormatter(explicit_json=False,
                         format_options={'json': {'format': True,
                                                  'sort_keys': True,
                                                  'indent': 4}}).format_body(json.dumps(json_data), mime) == json.dumps(json_data)
    # It should not modify the JSON body if the format option is not set

# Generated at 2022-06-23 19:32:48.257961
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter()
    body = '{"name": "Test", "age": 12}'
    if jf.format_body(body, 'json') != '{\n    "age": 12,\n    "name": "Test"\n}':
        print ("[ERROR] in method format_body of class JSONFormatter")

# Generated at 2022-06-23 19:32:49.943610
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    plugin = JSONFormatter()
    assert plugin.enabled
    assert plugin.format_options['json']['format']

# Generated at 2022-06-23 19:32:53.498674
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import inspect
    import types
    assert inspect.isclass(JSONFormatter)
    assert isinstance(JSONFormatter, object)
    assert issubclass(JSONFormatter, FormatterPlugin)
    assert JSONFormatter.__name__ == 'JSONFormatter'
    assert JSONFormatter.__doc__ is not None


# Generated at 2022-06-23 19:33:00.361070
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={
        "json": {
            "format": False,
            "indent": None,
            "sort_keys": False,

        }
    }, explicit_json=False)
    assert formatter.kwargs['format_options'] == {
        "json": {
            "format": False,
            "indent": None,
            "sort_keys": False,

        }
    }
    assert formatter.kwargs['explicit_json'] == False
    assert formatter.enabled == False



# Generated at 2022-06-23 19:33:01.261007
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().format_options['json']['indent'] == 4

# Generated at 2022-06-23 19:33:04.445767
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import os
    import json
    argv = "http --json POST localhost:5000/test name=john --print=B".split()
    args = os.get_terminal_size().columns
    args = args - 45 + 1
    format_options = json.loads(open('config.json', 'r').read())
    assert JSONFormatter(argv, args, format_options), JSONFormatter(argv, args, format_options)


# Generated at 2022-06-23 19:33:07.177814
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        ignore_stdout=False,
        no_escape=False)
    assert json_formatter.ignore_stdout == False
    assert json_formatter.no_escape == False


# Generated at 2022-06-23 19:33:15.376247
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fmt = JSONFormatter()
    assert fmt is not None
    # Test a valid json body
    body = fmt.format_body(body='{"Key1": "Value1", "Key2": "Value2"}', mime="json")
    assert body == '{\n    "Key1": "Value1",\n    "Key2": "Value2"\n}'
    # Test an invalid json body
    body = fmt.format_body(body='{"Key1": "Value1", "Key2": "Value2", }', mime="json")
    assert body == '{"Key1": "Value1", "Key2": "Value2", }'
    # Test an valid json body with indention set to 0

# Generated at 2022-06-23 19:33:19.345988
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    })


# Generated at 2022-06-23 19:33:26.271970
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=True, 
                              format_options={
                                   'json': {
                                      'format': True,
                                      'indent': 4
                                  }
                              })
    assert formatter.explicit_json == True
    assert formatter.format_options['json']['format'] == True


# Generated at 2022-06-23 19:33:31.266210
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(**{'explicit_json': True, 'format_options': {'json': {'format': True, 'sort_keys': True, 'indent': 2}}})
    body = f.format_body('{"a": "c", "b": "d"}', 'application/json,text/plain')
    assert body == '{\n  "a": "c",\n  "b": "d"\n}'

# Generated at 2022-06-23 19:33:39.656365
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    import httpie.plugins.formatter.json
    json_formatter = httpie.plugins.formatter.json.JSONFormatter()

    body = json_formatter.format_body("{\"hello\": \"world\"}", "json")
    assert body == '{\n    "hello": "world"\n}'

    body = json_formatter.format_body("{\"hello\": \"world\"}", "javascript")
    assert body == '{\n    "hello": "world"\n}'

    body = json_formatter.format_body("{\"hello\": \"world\"}", "text")
    assert body == '{\n    "hello": "world"\n}'

# Generated at 2022-06-23 19:33:44.666757
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    # Case where format is enabled
    format_options = {
        'json': {
            'format': True,
            'indent': None,
            'sort_keys': False
        }
    }
    formatter = JSONFormatter(format_options=format_options)
    assert formatter.format_options['json']['format']
    assert not formatter.format_options['json']['sort_keys']

    # Case where format is disabled
    format_options = {
        'json': {
            'format': False,
            'indent': None,
            'sort_keys': False
        }
    }
    formatter = JSONFormatter(format_options=format_options)
    assert not formatter.format_options['json']['format']

# Generated at 2022-06-23 19:33:49.180567
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter
    # enabled attribute
    assert formatter.enabled == formatter.format_options['json']['format']


# Generated at 2022-06-23 19:33:50.556275
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fmt = JSONFormatter()
    assert fmt.enabled is True


# Generated at 2022-06-23 19:34:01.037580
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	test_FORMAT_OPTIONS = {
							'json':{
										'format':True,
										'sort_keys':True,
										'indent': 2
									}
							}
	test_kwargs = {'explicit_json':False}
	test_jsonformatter = JSONFormatter(FORMAT_OPTIONS=test_FORMAT_OPTIONS,**test_kwargs)
	assert test_jsonformatter.enabled == True
	assert test_jsonformatter.kwargs == test_kwargs
	assert test_jsonformatter.format_options == test_FORMAT_OPTIONS
	assert test_jsonform

# Generated at 2022-06-23 19:34:04.927615
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j = JSONFormatter()
    assert j.format_body('{}', 'json') == '{\n}'
    assert j.format_body('{}', 'application/json') == '{\n}'
    assert j.format_body('{}', 'foo/json') == '{}'

# Generated at 2022-06-23 19:34:11.438190
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fmtr = JSONFormatter()
    assert fmtr.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert fmtr.format_body('{"a": 1}', 'text/json') == '{\n    "a": 1\n}'
    assert fmtr.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert fmtr.format_body('{"a": 1}', 'text/plain') == '{\n    "a": 1\n}'
    assert fmtr.format_body('{"a": 1}', 'application/javascript') == '{\n    "a": 1\n}'

# Generated at 2022-06-23 19:34:15.476044
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['sort_keys'] == False
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['format'] == False

# Generated at 2022-06-23 19:34:26.908365
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    '''Test format_body(body: str, mime: str) -> str'''
    fmt = JSONFormatter()

    # Test 1
    json_body = '{"one": 1, "two": false, "three": ["A", "B", "C"], "four": {"A": 1}, "five": [{"A": [1, 2]}]}'
    mime = "application/json"
    body = fmt.format_body(json_body, mime)

# Generated at 2022-06-23 19:34:35.542206
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test for method format_body of class JSONFormatter.
    """

    from httpie.plugins import plugin_manager
    formatter = plugin_manager.get_formatter(
        'json',
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 2
            }
        }
    )

    code = """
    {
        "name": "Jack",
        "contacts": [5, 3, 2]
    }
    """

    result = """
    {
  "contacts": [
    5,
    3,
    2
  ],
  "name": "Jack"
}
    """

    assert formatter.format_body(code, 'json') == result



# Generated at 2022-06-23 19:34:41.505282
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**dict(json=dict(format=False, indent=2, sort_keys=True)))
    json_data = dict(response=dict(data=dict(message="Hello")))
    result = json_formatter.format_body(body=json.dumps(json_data, indent=2, sort_keys=True), mime="application/json")
    assert result == json.dumps(json_data, indent=2, sort_keys=True)

# Generated at 2022-06-23 19:34:49.315138
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'json'
    body = '{"a": 1, "b": 2}'
    kwargs = {'explicit_json': False}
    format_options = {
        'json': {
            'indent': 4,
            'format': True,
            'sort_keys': False
        }
    }
    JF = JSONFormatter(kwargs=kwargs, format_options=format_options)
    result = JF.format_body(body=body, mime=mime)
    assert result == '{\n    "a": 1,\n    "b": 2\n}'



# Generated at 2022-06-23 19:34:56.003357
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test formatting for given body, mime.
    json_formatter = JSONFormatter(format_options={'json': {'format': True,
                                                            'indent': 4,
                                                            'sort_keys': False}})
    test_body = '{"key": "value"}'
    json_formatter.format_body(test_body, 'application/json')
    assert test_body == '{\n    "key": "value"\n}'

    # Test invalid JSON body.
    test_body = 'invalid json'
    json_formatter.format_body(test_body, 'application/json')
    assert test_body == 'invalid json'

    # Test different mime.
    test_body = '{"key": "value"}'

# Generated at 2022-06-23 19:35:00.153826
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        indent = 4,
        sort_keys = True
    )
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == 1


# Generated at 2022-06-23 19:35:01.913215
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.kwargs == {}

# Generated at 2022-06-23 19:35:10.096311
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.core import main

    body = '{"foo":42}'
    mime = 'application/json'

    class args:
        json = True
        pretty = None
        explicit_json = False
        print_body_only = False
        download = False
        body = None
        body_on_error = False
        output_file = None
        stdin_isatty = False
        outfile_isatty = False

    class format_options:
        json = {'format': True, 'indent': 2, 'sort_keys': True}

    # If a JSON body is received it should be processed by json.
    assert JSONFormatter(args, format_options).format_body(body, mime) ==\
        '{\n  "foo": 42\n}'

    # If a non-JSON body

# Generated at 2022-06-23 19:35:20.196078
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    maybe_json = [
        'json',
        'javascript',
        'text',
    ]
    json_formatter = JSONFormatter(explicit_json=False, 
                                   format_options= {
                        'json': {
                            'format': True,
                            'indent': -1,
                            'sort_keys': False
                            }
                        })
    mime = 'json'
    body = '{"method": "GET"}'
    assert json_formatter.format_body(body, mime) == '{"method": "GET"}'

    body = '{"method": "GET", "body": {"id": [123, 543]}}'

# Generated at 2022-06-23 19:35:29.524362
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:35:32.841042
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}'

# Generated at 2022-06-23 19:35:41.288672
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Empty body
    assert JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}}).format_body(body='', mime='') == ''

    # Body is not JSON body
    body = '{'
    assert JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}}).format_body(body=body, mime='') == body

    # Invalid JSON, ignore.
    body = '{ this is not a JSON body }'
    assert JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}}).format_body(body=body, mime='') == body

    # Valid JSON

# Generated at 2022-06-23 19:35:42.150763
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter is not None


# Generated at 2022-06-23 19:35:47.257380
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": "b"}'
    mime = 'application/json'
    jsonFormatter = JSONFormatter(format_options={'json': {'format': True,
                                                           'sort_keys': True,
                                                           'indent': 4}},
                                  explicit_json=False)
    assert jsonFormatter.format_body(body, mime) == '{\n    "a": "b"\n}'



# Generated at 2022-06-23 19:35:53.461989
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	
	"""
	Unit test for constructor of class JSONFormatter
	"""
	
	json_formatter = JSONFormatter(**kwargs)
	
	assert json_formatter.kwargs == kwargs
	assert json_formatter.format_options == format_options
	
	

# Generated at 2022-06-23 19:35:55.743549
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().__init__().kwargs['explicit_json'] is False


# Generated at 2022-06-23 19:35:57.088523
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False

# Generated at 2022-06-23 19:36:04.551510
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(format_options={'json': {'format': True,
                                                  'indent': 2,
                                                  'sort_keys': True}}).format_body('{"foo": "bar"}', '') == '{\n  "foo": "bar"\n}'

    assert JSONFormatter(format_options={'json': {'format': True,
                                                  'indent': 2,
                                                  'sort_keys': True}}).format_body('{"foo": "bar", "a": "b"}', '') == '{\n  "a": "b",\n  "foo": "bar"\n}'

# Generated at 2022-06-23 19:36:12.732318
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py3
    kwargs = {
        'format_options': {
            'json': {
                'sort_keys': False,
                'indent': None,
                'format': True
            }
        },
        'explicit_json': False
    }
    body = '{"a": "b"}'
    f = JSONFormatter(**kwargs)
    # Indent, sort keys by name, and avoid unicode escapes to improve readability.
    if is_py3:
        expected_body = '{"a": "b"}'
    else:
        expected_body = '{"a": u"b"}'
    assert f.format_body(body=body, mime='application/json') == expected_body

# Generated at 2022-06-23 19:36:24.784438
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    contentType = "application/json; charset=utf-8"
    body = "json-test-body"
    format_options = {'json': {'sort_keys': False, 'format': True, 'indent': 2}, 'colors': {'args': '', 'data': '',
                                                                                            'error': ''},
                     'style': {'args': '', 'data': '', 'error': ''}, 'stream': {'args': '', 'data': '', 'error': ''}}
    formatter = JSONFormatter()
    formatter.kwargs = {'explicit_json': False, 'style': ''}
    formatter.format_options = format_options
    assert formatter.enabled == formatter.format_options['json']['format']

# Generated at 2022-06-23 19:36:29.757778
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"jsonrpc":"2.0","error":"400"}'
    body2 = '{"jsonrpc":"2.0","error":"400"}'
    js = JSONFormatter(**{'explicit_json': False, 'format_options': {'json': {'format': True, 'indent': 2, 'sort_keys': True}}})
    assert js.format_body(body, 'json') == body2

# Generated at 2022-06-23 19:36:31.370207
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_JSONFormatter = JSONFormatter()

    assert test_JSONFormatter.enabled == True

# Generated at 2022-06-23 19:36:40.742781
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 1, "b": 2}\n'
    jf = JSONFormatter(kwargs={'explicit_json': True},
                        format_options={'json':{'format': True,
                                                'indent': 4,
                                                'sort_keys': False}})

    assert jf.format_body(body, 'application/json') == \
        '{\n    "a": 1,\n    "b": 2\n}\n'
    
    jf = JSONFormatter(kwargs={'explicit_json': False},
                        format_options={'json':{'format': True,
                                                'indent': 4,
                                                'sort_keys': True}})


# Generated at 2022-06-23 19:36:43.044565
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test code
    from httpie import ExitStatus
    process = subprocess.Popen(
        ['http', '--json', '--print=H', 'http://httpbin.org/get'],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    process.wait()
    assert process.returncode == ExitStatus.OK
    assert b'httpbin.org' in process.stdout.read()


# Test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:36:47.873654
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    c=JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert c.enabled == True
    assert c.format_options=={'json': {'format': True, 'indent': 2, 'sort_keys': True}}


# Generated at 2022-06-23 19:36:59.511506
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.formatters.json import JSONFormatter
    from httpie.core import DEFAULT_OPTIONS
    valid_json = '{"key": "value"}'
    invalid_json = '{"key": "value\n'  # Unterminated string.

    mime_types = [
        'json',
        'javascript',
        'text',
        'application/json',
        'application/javascript',
    ]

    for mime_type in mime_types:
        # No formatting with non-JSON content type.
        formatter = JSONFormatter(
            format_options=DEFAULT_OPTIONS['json'],
            explicit_json=False,
        )
        assert formatter.format_body(valid_json, mime_type) == valid_json

        # Formatting enabled with valid JSON


# Generated at 2022-06-23 19:37:07.640509
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            },
        },
        explicit_json=False,
    )

    body = '{"a": 1, "b": [2, 3]}'
    body_result = '{\n  "a": 1,\n  "b": [\n    2,\n    3\n  ]\n}'
    assert jf.format_body(body, 'json') == body_result

    body = '[1, 2, 3]'
    body_result = '[\n  1,\n  2,\n  3\n]'
    assert jf.format_body(body, 'json') == body_result


# Generated at 2022-06-23 19:37:16.057959
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # When Content-Type is application/json or json, format body
    args = dict(
        format_options = {
            "json": {
                "format": True,
                "sort_keys": False,
                "indent": None,
            }
        },
        explicit_json = False,
    )
    assert JSONFormatter(**args).format_body(
        body = '{"name": "Tony Stark", "age": 30}',
        mime = 'application/json'
    ) == '{"name": "Tony Stark", "age": 30}'
    assert JSONFormatter(**args).format_body(
        body = '{"name": "Tony Stark", "age": 30}',
        mime = 'json'
    ) == '{"name": "Tony Stark", "age": 30}'
    # If body is

# Generated at 2022-06-23 19:37:22.926056
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import pytest
    from utils import get_test_user_agent

    # Test 1:
    # Default setup for constructor
    test_formatter = JSONFormatter()
    assert not test_formatter.enabled
    assert test_formatter.kwargs
    assert test_formatter.kwargs['explicit_json']
    assert test_formatter.kwargs['encoding']
    assert test_formatter.kwargs['user_agent'] == get_test_user_agent()

    # Test 2:
    # Setup for constructor with its own kwargs
    test_formatter = JSONFormatter(
        json={
            'format': True
        }
    )
    assert test_formatter.enabled


# Generated at 2022-06-23 19:37:33.653385
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    }
    explicit_json = False

    # Test invalid JSON
    body = 'invalid'
    mime = 'application/json'
    assert JSONFormatter(
        formatter_options=formatter_options,
        explicit_json=explicit_json,
    ).format_body(body=body, mime=mime) == body

    # Test valid JSON, rendering is disabled.
    body = '{\n  "a": 1,\n  "b": 2\n}'
    mime = 'application/json'

# Generated at 2022-06-23 19:37:42.020624
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = b'["foo","bar"]'
    mime = b'json'
    obj = json.loads(body.decode('utf-8'))
    if isinstance(obj, list):
        assert "\n" not in JSONFormatter().format_body(body.decode('utf-8'), mime.decode('utf-8'))
    else:
        assert "\n" in JSONFormatter().format_body(body.decode('utf-8'), mime.decode('utf-8'))

test_JSONFormatter_format_body()

# Generated at 2022-06-23 19:37:49.268240
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options = { 'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False,
        } })
    body = '{"arr": [1, 2], "int": 1, "name": "httpie"}'
    mime = 'json'
    expected_body = """{
  "arr": [
    1,
    2
  ],
  "int": 1,
  "name": "httpie"
}"""
    assert expected_body == formatter.format_body(body, mime)

test_JSONFormatter_format_body()

# Generated at 2022-06-23 19:37:54.101826
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"foo":"bar"}'
    mime = 'application/json'
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert json_formatter.format_body(body, mime) == body
    assert json_formatter.format_body(body, 'text/plain') == body

# Generated at 2022-06-23 19:37:55.471985
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter()
    assert test.enabled == False

# Generated at 2022-06-23 19:38:02.083383
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '["foo", {"bar":["baz", null, 1.0, 2]}]'
    ob_body = "[\n    \"foo\", \n    {\n        \"bar\": [\n            \"baz\", \n            null, \n            1.0, \n            2\n        ]\n    }\n]"
    testFormatter = JSONFormatter()
    json_body = testFormatter.format_body(body=body, mime='json')
    assert json_body == ob_body

# Generated at 2022-06-23 19:38:13.455362
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    def test_JSONFormatter_format_body_json():
        assert formatter.format_body('{"a":"b"}', 'application/json') == '{\n  "a": "b"\n}'

    def test_JSONFormatter_format_body_json_no_space():
        assert formatter.format_body('{"a":"b"}', 'application/json') == '{\n  "a": "b"\n}'

    def test_JSONFormatter_format_body_json_explicit():
        assert formatter.format_body('{"a":1}', 'random/string') == '"{\\"a\\":1}"'


# Generated at 2022-06-23 19:38:15.125894
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.enabled is True


# Generated at 2022-06-23 19:38:23.115946
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # encode_json is enabled, mime is json
    kwargs = {'explicit_json': True}
    JSONFormatter(kwargs=kwargs).format_body('{"test": 1}', 'text/json')

    # encode_json is disabled, mime is json
    kwargs = {'explicit_json': False}
    JSONFormatter(kwargs=kwargs).format_body('{"test": 1}', 'text/json')

    # encode_json is disabled, mime is not json
    kwargs = {'explicit_json': False}
    JSONFormatter(kwargs=kwargs).format_body('{"test": 1}', 'text/html')

# Generated at 2022-06-23 19:38:27.338345
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_data = {"response": "test"}
    expected_response = '{\n    "response": "test"\n}'
    json_formatter = JSONFormatter()
    assert(json_formatter.format_body(json.dumps(json_data), 'json') == expected_response)

# Generated at 2022-06-23 19:38:38.211985
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    args = ['--json-indent=0', '--json-sort-keys=0']
    formatter = JSONFormatter(args)

# Generated at 2022-06-23 19:38:39.787835
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    http_tmp = ['json', 'javascript', 'text']
    assert http_tmp is ['json', 'javascript', 'text']

# Generated at 2022-06-23 19:38:47.099459
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
	maybe_json = [
        'json',
        'javascript',
        'text',
    ]
	mime = "application/json"
	body = '[1,2,{"foo": [4,5,6]},7,8,9]'
	expected = '[\n    1,\n    2,\n    {\n        "foo": [\n            4,\n            5,\n            6\n        ]\n    },\n    7,\n    8,\n    9\n]'
	kwargs = {'explicit_json': True, 'format_options': {'json':{'sort_keys':False,'indent':2,'format':True}}}
	jf = JSONFormatter(**kwargs)
	assert jf.format_body(body,mime) == expected


	kwargs

# Generated at 2022-06-23 19:38:51.418038
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {
        'format': True,
        'indent': 2,
        'sort_keys': False
    }})
    assert formatter.enabled == True



# Generated at 2022-06-23 19:38:53.708270
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(output_options={}, format_options={}, format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': False}}, session={}, explicit_json=False)
    assert json_formatter.format_body('{"name":"value"}', 'json') == '{\n  "name": "value"\n}'

# Generated at 2022-06-23 19:39:02.229841
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    enabled = True
    format_options = {
        'json': {'format': True, 'indent': 3, 'sort_keys': False},
        'colors': {'format': True, 'request_method': 'green', 'request_headers': 'blue'}
    }
    kwargs = {'explicit_json': True}

    jf = JSONFormatter(enabled=enabled, format_options=format_options, **kwargs)
    assert jf.enabled == enabled
    assert jf.format_options == format_options
    assert jf.kwargs == kwargs



# Generated at 2022-06-23 19:39:07.732993
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(explicit_json=True)
    assert json_formatter.kwargs == {'explicit_json': True}
    assert json_formatter.format_options == {'json': {'indent': 4, 'format': True, 'sort_keys': False}}
    assert json_formatter.enabled



# Generated at 2022-06-23 19:39:09.645815
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.format_options['json']['format'] == True

# Generated at 2022-06-23 19:39:11.398021
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    actual_output = JSONFormatter()
    expected_output = True
    assert actual_output == expected_output

# Generated at 2022-06-23 19:39:18.322390
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for invalid JSON
    body = 'Testing for invalid JSON'
    mime = 'json'
    formatter = JSONFormatter()
    new_body = formatter.format_body(body, mime)
    assert(new_body == 'Testing for invalid JSON')

    # Test for valid JSON
    body = '{"name": "httpie"}'
    mime = 'application/json'
    formatter = JSONFormatter()
    new_body = formatter.format_body(body, mime)
    assert(new_body == '{\n    "name": "httpie"\n}')

# Generated at 2022-06-23 19:39:22.842751
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{"abc": "123"}', 'json') == '{"abc": "123"}'
    assert JSONFormatter().format_body('{"abc": "123"}', 'javascript') == '{\n    "abc": "123"\n}'
    assert JSONFormatter().format_body('{"abc": "123"}', 'text') == '{\n    "abc": "123"\n}'

# Generated at 2022-06-23 19:39:32.855722
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    test_json_formatter = JSONFormatter(**{
        'format_options': {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        },
        'explicit_json': False,
        'resolve_assured': False,
        'resolve_full': False,
    })

    test_json = '{"name":"Thomas", "age": 25}'
    test_mime = 'json'

    assert test_json_formatter.format_body(body=test_json, mime=test_mime) == \
        '{\n    "age": 25,\n    "name": "Thomas"\n}'

# Generated at 2022-06-23 19:39:40.869237
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie import ExitStatus
    from utils import TestEnvironment, http, HTTP_OK
    from fixtures import FILE_PATH_ARG, FILE_PATH, JSON_FILE_PATH
    data = {'some': 'data'}
    env = TestEnvironment(stdin_isatty=True)
    r = http(
        'POST',
        'http://httpbin.org/post',
        'Content-Type: application/json; charset=utf-8',
        '',
        data=json.dumps(data),
        env=env,
    )
    assert HTTP_OK in r
    assert '"some": "data"' in r
    assert 'HTTP/1.1 200 OK' in r
    # Test that we do not get UnicodeEncodeError when piping to a stream


# Generated at 2022-06-23 19:39:43.867898
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(json={'indent': 4, 'sort_keys': True, 'format': True})
    assert f.format_body({"test":"test"}, "text/html") == '{\n    "test": "test"\n}'
    assert f.format_body('{"test":"test"}', "text/html") == '{\n    "test": "test"\n}'

# Generated at 2022-06-23 19:39:52.272341
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest
    test_instance = JSONFormatter()

    original_body = """
{
    "json": "object",
    "with": {
        "nested": "structure"
    }
}"""
    expected_body = """
{
    "json": "object",
    "with": {
        "nested": "structure"
    }
}
"""
    actual_body = test_instance.format_body(original_body, "application/json")
    assert actual_body == expected_body

    original_body = """
{
    "json": "object",
    "with": {
        "nested": "structure"
    }
}
"""