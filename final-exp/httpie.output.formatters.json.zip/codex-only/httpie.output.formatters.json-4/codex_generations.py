

# Generated at 2022-06-23 19:30:03.804831
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.enabled == True

    # Test the format_body function
    mime_json = 'application/json'
    mime_invalid = 'others'
    body = '{"id": 1, "name": "JSONFormatter"}'
    body_invalid = '{"id: 1, "name": "Invalid"}'
    json_final = '{\n  "id": 1,\n  "name": "JSONFormatter"\n}'

    assert json_final == jf.format_body(body, mime_json)
    assert body == jf.format_body(body_invalid, mime_json)
    assert body == jf.format_body(body, mime_invalid)

# Generated at 2022-06-23 19:30:06.317994
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(kwargs={}, format_options={}, output_options={})
    assert jf.enabled == False



# Generated at 2022-06-23 19:30:10.641404
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"test": "1"}'
    assert formatter.format_body(body, 'application/json') == body
    assert formatter.format_body(body, 'text/javascript') == body
    assert formatter.format_body(body, 'some/invalid') == body
    assert formatter.format_body('{"test: "1"}', 'application/json') == '{"test: "1"}'

# Generated at 2022-06-23 19:30:13.493121
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f1 = FormatterPlugin()
    f2 = JSONFormatter()
    #assert f1 == f2


# Generated at 2022-06-23 19:30:15.694927
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter({'json': {'format': False, 'sort_keys': False, 'indent': ''}})


# Generated at 2022-06-23 19:30:18.950785
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={'json': {'format': True}},
        explicit_json=False
    )
    assert json_formatter.enabled
    assert not json_formatter.kwargs['explicit_json']


# Generated at 2022-06-23 19:30:26.999929
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    obj=JSONFormatter(**{'format_options' : {'json': {'format': True,'sort_keys': False,'indent': 2}}}, **{'output_options' : {'stream': 'stdout'}, 'explicit_json': False})
    assert obj.format_options == {'json': {'format': True, 'sort_keys': False, 'indent': 2}}
    assert obj.kwargs == {'output_options': {'stream': 'stdout'}, 'explicit_json': False}
    assert obj.enabled == True


# Generated at 2022-06-23 19:30:27.619821
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert True

# Generated at 2022-06-23 19:30:35.578863
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    fmt = FormatterPlugin(format_options={'json': {'format': True}})
    assert fmt.format_body('{"foo": "bar"}', 'application/json') == '{\n    "foo": "bar"\n}'
    assert fmt.format_body('{"foo": "bar"}', '') == '{\n    "foo": "bar"\n}'
    assert fmt.format_body('{"foo": "bar"}', 'txt') == '{\n    "foo": "bar"\n}'
    assert fmt.format_body('{"foo": "bar"}', 'application/cbor') == '{"foo": "bar"}'

# Generated at 2022-06-23 19:30:46.368844
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter
    tests = [
        (f({'explicit_json': True}, {'json': {'format': True}}), '{}', 'application/json', '{}'),
        (f({'explicit_json': True}, {'json': {'format': True}}), '{"a":1}', 'application/json', '{\n    "a": 1\n}'),
        (f({'explicit_json': False}, {'json': {'format': True}}), '{}', 'text/plain', '{}'),
        (f({'explicit_json': False}, {'json': {'format': True}}), '{"a":1}', 'text/plain', '{\n    "a": 1\n}'),
    ]

# Generated at 2022-06-23 19:30:56.706668
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert_JSONFormatter = JSONFormatter()
    assert type(assert_JSONFormatter.format_options) is list
    assert type(assert_JSONFormatter.format_options[0]['json']) is dict
    assert type(assert_JSONFormatter.format_options[0]['json']['format']) is bool
    assert_JSONFormatter.format_options[0]['json']['format'] == False
    assert type(assert_JSONFormatter.format_options[0]['json']['indent']) is int
    assert assert_JSONFormatter.format_options[0]['json']['indent'] == 2
    assert type(assert_JSONFormatter.format_options[0]['json']['sort_keys']) is bool

# Generated at 2022-06-23 19:31:01.236091
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options= {'json': {'format': False, 'indent': 1, 'sort_keys': True}}, kwargs={'explicit_json': True})

    assert(str(formatter.enabled) == "False")
    assert(str(formatter.format_options['json']['sort_keys']) == "True")
    assert(str(formatter.format_options['json']['indent']) == "1")
    assert(str(formatter.kwargs['explicit_json']) == "True")


# Generated at 2022-06-23 19:31:11.585333
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    # Test that a valid json value is not formatted, when format is off.
    json_input = u'{"key": "value"}'
    args = http('--json', json_input)
    assert args.exit_status == ExitStatus.OK
    assert json_input in args.stdout
    # Test that a valid json value is formatted, when format is on.
    json_input = u'{"a": "b"}'
    expected_output = u'{\n    "a": "b"\n}'
    args = http('--json=format', json_input)
    assert args.exit_status == ExitStatus.OK
    assert expected_output in args.stdout
    # Test that a valid json value is formatted and sorted, when sort_keys is

# Generated at 2022-06-23 19:31:12.556258
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter()

# Generated at 2022-06-23 19:31:14.619837
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()
    assert formatter_plugin.format_options['json']['format'] == True


# Generated at 2022-06-23 19:31:22.199161
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    response_body = "{\n    \"foo\": \"bar\"\n}"
    result = formatter.format_body(body=response_body, mime="application/json")
    assert result == "{\n    \"foo\": \"bar\"\n}"

    response_body = "{'foo': 'bar'}"
    result = formatter.format_body(body=response_body, mime="text/plain")
    assert result == "{'foo': 'bar'}"

    response_body = "{\"foo\": \"bar\"}"
    result = formatter.format_body(body=response_body, mime="application/json")
    assert result == "{\n    \"foo\": \"bar\"\n}"

# Generated at 2022-06-23 19:31:27.323552
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-23 19:31:29.129648
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test that object is created
    formatter = JSONFormatter()
    formatter.__init__()
    assert not formatter is None


# Generated at 2022-06-23 19:31:31.572513
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = b'{"a": 42}'
    assert JSONFormatter().format_body(body, 'application/json') == '{\n    "a": 42\n}'



# Generated at 2022-06-23 19:31:40.579764
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.output.formatters
    httpie.output.formatters.JSON_FORMAT_OPTIONS['indent'] = None

    assert JSONFormatter(
    ).format_body('{"hello": "world!"}', 'application/json') == '{\n' \
        '    "hello": "world!"\n' \
        '}'
    assert JSONFormatter(
    ).format_body('{"hello": "world!"}', 'text/javascript') == '{\n' \
        '    "hello": "world!"\n' \
        '}'
    assert JSONFormatter(
    ).format_body('{"hello": "world!"}', 'application/javascript') == '{\n' \
        '    "hello": "world!"\n' \
        '}'

# Generated at 2022-06-23 19:31:44.729911
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(config__format_options={
        'json': {'format': True, 'indent': 4, 'sort_keys': True},
        'colors': {'format': False, 'request': {}, 'response': {}}
    })
    assert json_formatter.format_body('{"name": "Hello JSON"}', 'json') == '{\n    "name": "Hello JSON"\n}'

# Generated at 2022-06-23 19:31:48.855337
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    """
    This test will check the constructor of the class JSONFormatter_Constructor
    will recieve the right values
    """
    # Arrange
    formatter = JSONFormatter(headers=None,
                        format_options={
                            'json': {
                                'formatter': 'JSONFormatter',
                                'format': True,
                                'indent': 2,
                                'sort_keys': True
                            }
                        },
                        explicit_json=False)
    # Act
    # Assert
    assert formatter.enabled == True



# Generated at 2022-06-23 19:31:56.637623
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        f = JSONFormatter(**{'format_options':{'json':{'format': 0}}})
    except Exception as e:
        print(e)
    assert not f.enabled
    try:
        f = JSONFormatter(**{'format_options': {'json': {'format': 1}}})
    except Exception as e:
        print(e)
    assert f.enabled


# Generated at 2022-06-23 19:32:03.499134
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(json=dict(
        format=True,
        sort_keys=False,
        indent=2))
    body = '{"key":"value"}'
    mime = 'json'
    assert jf.format_body(body, mime) == '{\n  "key": "value"\n}'
    body = '{"key":"value"}'
    mime = 'javascript'
    assert jf.format_body(body, mime) == '{\n  "key": "value"\n}'
    body = '{"key":"value"}'
    mime = 'text'
    assert jf.format_body(body, mime) == '{\n  "key": "value"\n}'

# Generated at 2022-06-23 19:32:06.488103
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
            format_options={
                'json': {
                    'format': True,
                    'sort_keys': True,
                    'indent': 0,
                }})
    assert formatter.enabled == True


# Generated at 2022-06-23 19:32:14.365777
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:32:18.065507
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from tempfile import TemporaryDirectory
    from httpie.plugins import JSONFormatter
    from pytest import approx
    with TemporaryDirectory(suffix='-httpie') as tmp:
        json_formatter = JSONFormatter(cache_dir=tmp)
        body = json_formatter.format_body('{"a": 1}', 'application/json')
        assert json.loads(body) == approx(json.loads('{"a": 1}'))

# Generated at 2022-06-23 19:32:27.338303
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # Test one example body string of json, javascript, text and
    # invalid json mime respectively
    body_list = [
        '{"foo": "bar"}',
        '{"foo": "bar"}',
        '{"foo": "bar"}',
        '{"foo": "bar"}',
    ]
    mime_list = [
        'application/json',
        'application/javascript',
        'text/plain',
        'invalid_json',
    ]
    # Check that the string formatter outputs are correct
    for i in range(4):
        assert formatter.format_body(body_list[i],mime_list[i]) == \
                '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 19:32:38.790248
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import plugin_manager
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    json_formatter = JSONFormatter(
        **(plugin_manager
            .instantiate_plugins([HTTPBasicAuth], [])
            .format_options['json'])
    )

    assert json_formatter.enabled is True
    assert json_formatter.kwargs['explicit_json'] is False
    assert json_formatter.kwargs['sort_keys'] is True
    assert json_formatter.kwargs['indent'] == 4
    assert json_formatter.kwargs['explicit_json'] is False
    assert json_formatter.binary_in or is_windows


# Generated at 2022-06-23 19:32:48.216754
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class DummyJSONFormatter(JSONFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = True

    formatter = DummyJSONFormatter(json={'sort_keys': False, 'indent': None},
                                   explicit_json=False)
    body = '{"a": 1, "b": 1}'
    res = formatter.format_body(body, 'json')
    assert res == '{\n    "a": 1,\n    "b": 1\n}'

    formatter = DummyJSONFormatter(json={'sort_keys': True, 'indent': None},
                                   explicit_json=False)
    body = '{"a": 1, "b": 1}'

# Generated at 2022-06-23 19:32:50.236096
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter({'json': {'format': True, 'indent': 4, 'sort_keys': False}}, {}).enabled

# Generated at 2022-06-23 19:32:51.086434
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().enabled == True

# Generated at 2022-06-23 19:32:57.012460
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    assert formatter.format_body('{"b":1}', 'json') == '{\n    "b": 1\n}'
    assert formatter.format_body('{"b":1}', 'javascript') == '{\n    "b": 1\n}'
    assert formatter.format_body('{"b":1}', 'text') == '{\n    "b": 1\n}'
    assert formatter.format_body('{"b":1}', 'unknown') == '{"b":1}'
    assert formatter.format_body('{"b":1}', 'json; charset=utf-8') == '{\n    "b": 1\n}'


__all__ = ('JSONFormatter',)

# Generated at 2022-06-23 19:33:05.365612
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import os
    import tests.httpie_test_configuration
    httpie_test_conf = tests.httpie_test_configuration.HTTPieTestConfiguration()

    fake_config = dict()
    fake_config['format'] = dict()
    fake_config['format']['json'] = dict()
    fake_config['format']['json']['explicit_json'] = True
    fake_config['format']['json']['format'] = True
    fake_config['format']['json']['indent'] = 2
    fake_config['format']['json']['sort_keys'] = False

    formatter = JSONFormatter(
        config=fake_config
    )


# Generated at 2022-06-23 19:33:13.963585
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1: normal case
    json_body = '{"a": 1}'
    json_formatter = JSONFormatter()
    json_formatter.kwargs['explicit_json'] = False
    json_formatter.format_options['json']['format'] = True
    json_formatter.format_options['json']['sort_keys'] = True
    json_formatter.format_options['json']['indent'] = 2
    mime = 'json'
    json_formatter.format_body(json_body, mime)
    assert json_formatter.body == '{\n  "a": 1\n}'

    # Test case 2: invalid JSON
    json_body = '{'
    json_formatter.format_body(json_body, mime)
    assert json_form

# Generated at 2022-06-23 19:33:18.710245
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  jf = JSONFormatter()
  assert isinstance(jf, JSONFormatter)
  assert hasattr(jf, "enabled")

  assert hasattr(jf, "kwargs")
  assert isinstance(jf.kwargs, dict)


# Generated at 2022-06-23 19:33:22.986061
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == False
    # todo: will test the format_body() method of class JSONFormatter, when
    #       the Httpie.run() method is implemented.

# Generated at 2022-06-23 19:33:25.432308
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import httpie
    httpie.JSONFormatter()
    assert True

# Generated at 2022-06-23 19:33:28.990644
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter({
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    }, explicit_json=True)
    assert formatter_plugin.enabled


# Generated at 2022-06-23 19:33:31.264169
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    assert f.format_body('{"name": "daniel"}', 'json') == '{\n    "name": "daniel"\n}'

# Generated at 2022-06-23 19:33:40.971083
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.cli import parser
    from httpie.core import get_response
    from vcr.cassette import Cassette
    from vcr.stubs import VCRHTTPConnection
    import pytest
    import requests

    # List of (method, url)
    test_cases = [
        ("GET" , "https://www.google.com/"),
        ("POST", "https://gethttpie.com/"),
        ("PUT" , "https://gethttpie.com/"),
        ("HEAD", "https://gethttpie.com/"),
        ("ERROR", "https://gethttpie.com/"),
    ]

    # Set up VCR and HTTPConnection

# Generated at 2022-06-23 19:33:42.516359
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().format_options['json']['format'] == False

# Generated at 2022-06-23 19:33:43.178861
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a = JSONFormatter()



# Generated at 2022-06-23 19:33:50.650274
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"hello": "world"}'
    mime = 'text/plain'
    res = JSONFormatter(format_options={'json': {'format': False}}).format_body(body, mime)
    assert res == '{"hello": "world"}'
    res = JSONFormatter(format_options={'json': {'format': True}}).format_body(body, mime)
    assert res == '{\n    "hello": "world"\n}\n'

# Generated at 2022-06-23 19:33:51.167023
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-23 19:33:53.237396
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter=JSONFormatter()
    assert formatter.enabled == True

#Unit test for format_body function of class JSONFormatter

# Generated at 2022-06-23 19:33:56.211867
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_json_formatter = JSONFormatter()
    assert test_json_formatter.format_options['json']['format'] == True



# Generated at 2022-06-23 19:34:01.217428
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(verbose=False, json={'format': True, 'indent': None, 'sort_keys': False})
    a = '{"sort_keys": false, "format": true}'
    b = '{"format": true, "sort_keys": false}'
    assert formatter.format_body(a, 'json') == b

# Generated at 2022-06-23 19:34:04.397637
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter_test = JSONFormatter(
        format_options={'json': {'format': False, 'sort_keys': True, 'indent': 4}}
        )
    assert json_formatter_test.enabled == False

# Generated at 2022-06-23 19:34:12.275377
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with dict
    assert json.loads(JSONFormatter(format_options={"json": {"format": True, "indent": "  ", "sort_keys": True}}) \
        .format_body('{"a": 1, "b": 2}', 'application/json')) == {'a': 1, 'b': 2}

    # Test with list
    assert json.loads(JSONFormatter(format_options={"json": {"format": True, "indent": "  ", "sort_keys": True}}) \
        .format_body('["a", 2, 3.3]', 'application/json')) == ["a", 2, 3.3]

    # Test with dict, JS array notation

# Generated at 2022-06-23 19:34:20.379255
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '''
    {
        "question": "What kind of bear is best?",
        "answer": "Black bear"
    }
    '''
    formatter = JSONFormatter(
        kwargs={'explicit_json': False},
        format_options={'json': {'format': True}})
    formatted_body = formatter.format_body(body=body, mime='json')
    assert formatted_body == '''
    {
        "answer": "Black bear",
        "question": "What kind of bear is best?"
    }
    '''



# Generated at 2022-06-23 19:34:30.924821
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    instance1 = JSONFormatter()
    assert not instance1.enabled
    assert instance1.kwargs == {}
    assert instance1.format_options == {
        'json': {
            'format': False,
            'indent': None,
            'sort_keys': False,
        },
        'colors': {
            'request_headers': None,
            'request_headers_strong': None,
            'request_body': None,
            'response_headers': None,
            'response_headers_strong': None,
            'response_body': None,
            'scheme': None,
            'scheme_strong': None,
            'method': None,
            'method_strong': None,
            'status': None,
            'status_strong': None,
        },
    }

    instance2 = JSONFormatter

# Generated at 2022-06-23 19:34:36.460564
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': 'True', 'sort_keys': 'True', 'indent': '2'}})
    assert JSONFormatter(format_options={'json': {'format': 'False', 'sort_keys': 'False', 'indent': '0'}})


# Generated at 2022-06-23 19:34:37.430730
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()

# Generated at 2022-06-23 19:34:46.099071
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import str
    from httpie.plugins import FormatterPlugin

    class JSONFormatter(FormatterPlugin):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['json']['format']

        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                    or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass  # Invalid JSON, ignore.

# Generated at 2022-06-23 19:34:51.684536
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON object.
    jsonFormatter = JSONFormatter(kwargs={'explicit_json': False}, format_options={'json': {'format': True, 'sort_keys':False,'indent':4}})
    str = '{"key": "value"}'
    mime = 'json'
    assert jsonFormatter.format_body(str, mime) == '{\n    "key": "value"\n}'
    # Test with invalid JSON object.
    str = '{"key: "value"}'
    mime = 'json'
    assert jsonFormatter.format_body(str, mime) == '{"key: "value"}'
    # Test with valid JSON object and json not in mime.
    str = '{"key": "value"}'
    mime = 'plain'
    assert json

# Generated at 2022-06-23 19:34:52.166339
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-23 19:34:53.199538
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter({})
    assert formatter is not None


# Generated at 2022-06-23 19:35:04.014941
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=True)
    assert formatter.format_body('name="value"', 'form') == 'name="value"'
    assert formatter.format_body('{"name": "value"}', 'json') == \
        '{"name": "value"}'
    assert formatter.format_body('name="value"', 'javascript') == \
        'name="value"'
    assert formatter.format_body('name="value"', 'text') == \
        'name="value"'
    assert formatter.format_body('{"name": "value"}', 'json') == \
        '{\n    "name": "value"\n}'

# Generated at 2022-06-23 19:35:08.364133
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        }
    )
    assert json_formatter.format_options['json']['format']
    assert json_formatter.kwargs['explicit_json'] == False


# Generated at 2022-06-23 19:35:14.834525
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    """Unit test for constructor of class JSONFormatter"""
    # Test case data
    format_options = {'json': {'format': True,
                               'indent': 2,
                               'sort_keys': False},
                      'theme': {'0': 'white',
                                '1': 'black'},
                      'colors': {'request': 'white',
                                 'response': 'black'}}
    kwargs = {'explicit_json': True,
              'output_options': {'colors': True}}

    # Perform the test
    obj = JSONFormatter(format_options=format_options, **kwargs)

    # assert the result
    assert obj.enabled is True
    assert obj.format_options == format_options
    assert obj.kwargs == kwargs


# Generated at 2022-06-23 19:35:18.500162
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    sut = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    assert (sut.enabled)
    assert (sut.format_options['json']['format'])


# Generated at 2022-06-23 19:35:23.403594
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"hello":"world"}'
    mime = 'json'
    assert '{\n    "hello": "world"\n}' == \
        JSONFormatter().format_body(body, mime)

# Generated at 2022-06-23 19:35:30.689381
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import os
    import httpie as httpiehere
    import httpie.plugins.formatter.json as jsonhere
    from httpie import main as httpieMain
    from httpie.plugins.formatter.json import JSONFormatter, __init__ as init
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.output.streams import OutStreams
    from httpie.context import Environment
    from httpie.compat import is_windows, is_osx
    from httpie.cli.exceptions import (
        ExitStatus,
        ParseError,
        OutputOptionError,
        InvalidOptionError
    )

    cj = httpiehere.plugins.formatter.pretty.PrettyJSONFormatter()
    assert isinstance(cj, jsonhere.JSONFormatter)
   

# Generated at 2022-06-23 19:35:31.285701
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-23 19:35:40.439424
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import builtin
    import httpie.output.formatters.json
    # Save the previous json formatter used by builtin plugins to restore it
    # at the end of the test
    prev_json_formatter = httpie.output.formatters.json.JSONFormatter

    class JsonTestFormatter(JSONFormatter):
        def __init__(self):
            super().__init__(
                # format options
                json={"format": True, "sort_keys": False, "indent": 4},
                # request arguments (kwargs)
                explicit_json=False,
                # httpie context
                colors=None,
            )

    # Override the json formatter used by builtin plugins
    httpie.output.formatters.json.JSONFormatter = JsonTestFormatter

    # Load builtin

# Generated at 2022-06-23 19:35:44.235795
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter({'json':{'format':1}}).format_options == {'json':{'format':1}}
    assert JSONFormatter({'json':{'format':0}}).format_options == {'json':{'format':0}}


# Generated at 2022-06-23 19:35:51.600846
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_1 = {
        'body': "{\n    \"key\": \"val\"\n}",
        'mime': "json",
        'kwargs': {'explicit_json': True},
        'format_options': {
            'json': {
                'sort_keys': True,
                'indent': 4,
                'format': True
            }
        },
        'expected': "{\n    \"key\": \"val\"\n}"
    }

# Generated at 2022-06-23 19:36:02.974992
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_format = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 0,
            'sort_keys': False,
        }
    })

    assert json_format.format_body(
        '{"a":42,"b":42}', 'json'
    ) == '{"a":42,"b":42}'

    assert json_format.format_body(
        '{"a":42,"b":42}', 'json; charset=utf-8'
    ) == '{"a":42,"b":42}'

    assert json_format.format_body(
        '{"a":42,"b":42}', 'text/json'
    ) == '{"a":42,"b":42}'


# Generated at 2022-06-23 19:36:04.128560
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled is True

# Generated at 2022-06-23 19:36:12.529454
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    #
    # Test invalid JSON.
    #
    f = JSONFormatter()
    assert f.format_body('{lorem ipsum', 'application/json') == '{lorem ipsum'
    #
    # Test valid JSON.
    #
    body = '{"foo": "bar", "baz": 123}'
    assert f.format_body(body, 'application/json') == body
    assert f.format_body(body, 'text/json') == body
    assert f.format_body(body, 'text/javascript') == body
    assert f.format_body(body, 'text/plain') == body
    assert f.format_body(body, 'text/html') == body
    #
    # Test valid JSON but ignored by f.kwargs['explicit_json'].
    #
   

# Generated at 2022-06-23 19:36:14.099144
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    assert not f.enabled

# Generated at 2022-06-23 19:36:24.032745
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == True  # default value
    formatter = JSONFormatter(explicit_json=True)
    assert formatter.kwargs['explicit_json'] == True
    formatter = JSONFormatter(format_options={"json":{"format":True}})
    assert formatter.format_options['json']['format'] == True
    formatter = JSONFormatter(kwargs={"format_options":{"json":{"format":True}}}, format_options={"json":{"format":True}})
    assert formatter.kwargs['format_options'] == {"json":{"format":True}}


# Generated at 2022-06-23 19:36:24.977988
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.enabled is False

# Generated at 2022-06-23 19:36:26.093232
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter is not None


# Generated at 2022-06-23 19:36:28.066269
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert(jsonFormatter.enabled == False)


# Generated at 2022-06-23 19:36:33.839975
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # test constructor of class with and without arguments
    json_formatter_noargs = JSONFormatter()
    json_formatter_args = JSONFormatter(explicit_json=True)

    # test values of instance variables
    assert json_formatter_noargs.kwargs == {'explicit_json': False}
    assert json_formatter_args.kwargs == {'explicit_json': True}


# Generated at 2022-06-23 19:36:42.892672
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Check format_body method with json type body
    f = JSONFormatter(json={'format': True, 'indent': 2, 'sort_keys': True})
    assert f.format_body('{"key":"value"}', 'application/json') == \
        '{\n  "key": "value"\n}'
    assert f.format_body('{"key":"value"}', 'text/json') == \
        '{\n  "key": "value"\n}'
    assert f.format_body('{"key":"value"}', 'application/javascript') == \
        '{\n  "key": "value"\n}'
    # Check format_body method without json type body
    assert f.format_body('{"key":"value"}', 'application/binary') == \
        '{"key":"value"}'

# Generated at 2022-06-23 19:36:51.870714
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json':{'format': True, 'indent': None, 'sort_keys': False}})
    # Valid JSON
    body_one = '{"foo": "bar", "baz": {"aaa": "vvv", "ccc": "ddd"}, "aaa": "aaa", "zzz": "zzz"}'
    mime_one = 'application/json'
    # Duplicate key will not be sorted
    assert formatter.format_body(body_one, mime_one) == body_one
    # Invalid JSON but valid JSON-like syntax
    body_two = '{"foo": "bar", "baz": {"aaa": "vvv", "ccc": "ddd"}, "aaa": "aaa"}'
    mime_two = 'application/json'
    assert formatter

# Generated at 2022-06-23 19:36:57.905033
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 1, "b": 0}'
    body_formatted = '{\n    "a": 1,\n    "b": 0\n}'
    assert JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,

            },
        },
        explicit_json=False
    ).format_body(body, 'application/json') == body_formatted



# Generated at 2022-06-23 19:37:06.347228
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import plugin_manager
    plugin_manager.register_plugin(JSONFormatter)
    args = '--json --json-format=indent=8,sort_keys=1'
    json_test_result = {
  "args": {
    "arg1": "val1"
  },
  "headers": {
    "Accept": "*/*",
    "Accept-Encoding": "gzip, deflate",
    "Host": "httpbin.org",
    "User-Agent": "HTTPie/0.9.8"
  },
  "origin": "81.208.243.245, 81.208.243.245",
  "url": "https://httpbin.org/get?arg1=val1"
}

    # Set the output of our test request to a variable
    json_format

# Generated at 2022-06-23 19:37:11.340330
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    pretty_json = '{\n    "key": "value"\n}'
    json_body = '{"key": "value"}'
    assert formatter.format_body(json_body, 'application/json') == pretty_json
    assert formatter.format_body(json_body, 'application/javascript') == pretty_json
    assert formatter.format_body(json_body, 'text/javascript') == pretty_json
    assert formatter.format_body(json_body, 'text/json') == pretty_json
    assert formatter.format_body(json_body, 'text/plain') == pretty_json

# Generated at 2022-06-23 19:37:13.403204
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__name__ == 'JSONFormatter'

# Generated at 2022-06-23 19:37:17.356908
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # JSONFormatter().format_body('{"a": 1, "b": 2}', 'json')

    from httpie import plugins, formats
    formats['json'] = {
        'format': True,
        'indent': 2,
        'sort_keys': True,
    }
    plugins.__httpie_plugins__ = [JSONFormatter]

    assert JSONFormatter(format_options={'json': {'indent': 4, 'sort_keys': False}}).__str__() == '<JSONFormatter>'

# Generated at 2022-06-23 19:37:25.424587
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    kwargs = {'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}, 'explicit_json': True}
    plugin = JSONFormatter(**kwargs)

    # Test with valid JSON data
    body = '{"username": "httpie", "password": "123456"}'
    mime = 'application/json'
    assert plugin.format_body(body, mime) == '{\n    "password": "123456",\n    "username": "httpie"\n}'

    # Test with invalid JSON data
    body = '{"username": "httpie", "password": "123456"}'
    mime = 'text/plain'
    assert plugin.format_body(body, mime) == body

    # Test with invalid JSON data if no automatic JSON

# Generated at 2022-06-23 19:37:36.593313
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest
    formatter = JSONFormatter(format_options=dict(json=dict(format=False)))
    assert formatter.enabled is False

    formatter = JSONFormatter(format_options=dict(json=dict(format=True)))
    assert formatter.enabled is True

    formatter = JSONFormatter(format_options=dict(json=dict(format=True,
                                                            sort_keys=True,
                                                            indent=4)))
    assert formatter.format_body(body='{"a": 1, "b": 2, "c": 3}',
                                 mime='json') ==\
        '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'


# Generated at 2022-06-23 19:37:47.985028
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
   formatter = JSONFormatter(format_options={
            'json': {
                'format': True,
                'indent': None,
                'sort_keys': False,
            },
            'colors': {
                'match': '',
                'prefix_match': '',
                'body': '',
                'status': '',
            }
        },
        format_options_specified={
            'json': True,
            'colors': False,
        },
        explicit_json=False,
        colors=False,
        unicode_nice_output=False)
   body = '[1,2,3]'
   mime = 'json'
   assert formatter.format_body(body, mime) == '[\n  1,\n  2,\n  3\n]'

# Generated at 2022-06-23 19:37:55.551302
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case: bad json
    json_string = '{"first_name": "jdoe", "last_name": "john"}'
    bad_json_string = '{"first_name": "jdoe", "last_name": "john"}'
    test_json = JSONFormatter()
    assert(test_json.format_body(json_string, 'json') ==
           '{\n    "first_name": "jdoe",\n    "last_name": "john"\n}')
    assert(test_json.format_body(bad_json_string, 'json') ==
           '{"first_name": "jdoe", "last_name": "john"}')

# Generated at 2022-06-23 19:38:00.824246
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = {'json': {'format': False, 'indent': 2, 'sort_keys': True}})
    assert not formatter.enabled

    formatter = JSONFormatter(format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled


# Generated at 2022-06-23 19:38:05.294560
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={
        'json' : {
            'format' : True,
            'indent' : 4,
            'sort_keys' : True
        }
    })
    assert formatter.enabled == True



# Generated at 2022-06-23 19:38:11.601180
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    #setup
    formatter = JSONFormatter(
        format_options = {}
    )
    body = '{"key1": "value1", "key2": "value2"}'

    #test
    actual = formatter.format_body(body=body, mime='json')

    #assert
    assert actual == '{\n    "key1": "value1", \n    "key2": "value2"\n}'

# Generated at 2022-06-23 19:38:17.034110
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(
        format_options={'json': {'format':True, 'indent':4, 'sort_keys':True}},
        explicit_json=False
    )
    result = jf.format_body('{"a": 1, "b": 2}', 'application/json')
    assert json.loads(result)=={u'a': 1, u'b': 2}

# Generated at 2022-06-23 19:38:19.374209
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })


# Generated at 2022-06-23 19:38:21.404837
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    obj = JSONFormatter()
    assert obj.enabled is False
    assert obj.kwargs == {}

# Generated at 2022-06-23 19:38:30.371284
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json':{'format':True,'indent':4,'sort_keys':True}})
    assert formatter.format_body(body='{"abc":1,"def":2}', mime='json') == ('{\n'
                                                            '    "abc": 1,\n'
                                                            '    "def": 2\n'
                                                            '}')
    assert formatter.format_body(body='{"abc":1,"def":2}', mime='text') == ('{\n'
                                                            '    "abc": 1,\n'
                                                            '    "def": 2\n'
                                                            '}')

# Generated at 2022-06-23 19:38:39.740055
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import argparse
    from json import loads

    # Test case with empty config set
    # Expected result: disabled, false, 2, false
    class TestParser(argparse.ArgumentParser):
        def __init__(self):
            super().__init__(add_help=False)

            self.add_argument( '--format',
                nargs='?',
                dest='format',
                const='json',
                default=None,
                help='Output the === response data === in a specified format')

            self.add_argument( '--explicit-json',
                action='store_true',
                default=None,
                dest='explicit_json',
                help='Attempt to encode the === response data === as JSON even if the Content-Type header is not set to application/json')

    parser = TestParser()

# Generated at 2022-06-23 19:38:47.050794
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    import httpie.input
    from httpie.plugins import JSONFormatter

    json_obj = {
        'foo': 'bar',
        'bar': 'baz',
        'baz': 'qux',
        'qux': 'quux',
        'quux': 'corge'
    }
    json_str = json.dumps(obj=json_obj).encode('utf-8')
    http_args = httpie.cli.parser.parse_args([])
    format_options = httpie.input.get_format_options(http_args)
    formatter = JSONFormatter(explicit_json=False, format_options=format_options)

    assert formatter.format_body(json_str, 'json') == json_str

# Generated at 2022-06-23 19:38:52.217028
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    kwargs = {'explicit_json': True}
    json_formatter = JSONFormatter(**kwargs)
    assert json_formatter.kwargs == kwargs
    assert json_formatter.enabled == json_formatter.format_options['json']['format']


# Generated at 2022-06-23 19:38:57.097869
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json':{'format':True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled 
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys']


# Generated at 2022-06-23 19:38:59.704043
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == False



# Generated at 2022-06-23 19:39:11.306908
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    try:
        from httpie.plugins import FormatterPlugin
    except ImportError:
        from httpie.plugins.core import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    formatter = JSONFormatter()
    formatter.enabled = True
    formatter.kwargs = dict(explicit_json=False)
    formatter.format_options = dict(json=dict(
        format=True,
        indent=2,
        sort_keys=True,
    ))
    body = '{"a": 1, "b": 2, "c": 3}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2,\n  "c": 3\n}'

# Generated at 2022-06-23 19:39:13.822717
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    instance = JSONFormatter(format_options = {
        'json': {
            'format': False,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert not instance.enabled

# Generated at 2022-06-23 19:39:16.694626
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options={'json': {'format': True, 'sort_keys': False,
             'indent': 4}}
    assert JSONFormatter(format_options=options,
                         explicit_json=True, silent=False)

# Generated at 2022-06-23 19:39:21.706266
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(explicit_json=True, format_options={"json":{"format":True,"sort_keys":True,"indent":2}})
    assert json_formatter.enabled == True
    assert json_formatter.kwargs["explicit_json"] == True
    assert json_formatter.format_options["json"]["sort_keys"] == True
    assert json_formatter.format_optio

# Generated at 2022-06-23 19:39:29.762626
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.formatter as formatter
    import httpie.output.formatters as formatters
    import httpie.output.formatters.colors as colors

    JSON_FORMAT_OPTIONS = {
        "json": {
            "format": False,
            "indent": 4,
            "sort_keys": True
        }
    }

    FORMATTER_KWARGS = {
        "colors": colors.NoColors(),
        "format_options": JSON_FORMAT_OPTIONS
    }

    def test_case(mime, input, output):
        """
        Test if the output is as expected for each test case

        """
        formatter.JSONFormatter(**FORMATTER_KWARGS)
        f = FORMATTER_KWARGS['format_options']

# Generated at 2022-06-23 19:39:31.414678
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = JSONFormatter()
    assert fp.enabled == False

# Generated at 2022-06-23 19:39:39.128413
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import formatter
    f = formatter.Foramtter()
    json_formatter = JSONFormatter(format_options=f.format_options)
    assert json_formatter.format_options == f.format_options
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == False
    assert json_formatter.format_options['json']['format'] == True
    f.all_disable()
    assert json_formatter.format_options['json']['format'] == False
    assert json_formatter.enabled == False


# Generated at 2022-06-23 19:39:45.117616
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Unit test for method format_body of class JSONFormatter
    test format data using JSONFormatter
    """
    assert JSONFormatter.format_body(
        '{"lastName": "Doe", "firstName": "John"}',
        'application/json'
    ) == '''{
    "firstName": "John",
    "lastName": "Doe"
}'''



# Generated at 2022-06-23 19:39:51.743673
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()

    def check(payload, expected, mime):
        out = f.format_body(payload, mime)
        assert out == expected
        
    check(
        '{}',                    # payload
        '{}',                    # expected
        'application/json'       # mime
    )

    check(
        '{"a": 1}',              # payload
        '{"a": 1}',              # expected
        'text/json'              # mime
    )

    check(
        '[]',                    # payload
        '[]',                    # expected
        'application/javascript' # mime
    )

# Generated at 2022-06-23 19:39:53.626898
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    input = {"test": "test"}
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    output = formatter.format_body(json.dumps(input), 'application/json')
    assert output == json.dumps(input, sort_keys=True, indent=2)

# Generated at 2022-06-23 19:40:01.908806
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from plugins import plugin_manager

    json_plugin_conf = plugin_manager.get_plugin_opt('json')
    json_plugin_conf.update({'indent': None, 'sort_keys': None})
    plugin_manager.set_plugin_opt('json', **json_plugin_conf)


    # JSON request body.
    env = TestEnvironment(stdin=b'{"a": 2, "b": 1, "c": 3}',
                          stdin_isatty=False)
    r = http('PATCH test.com/resource', '--json',
             env=env, error_exit_ok=True)
    assert HTTP_OK in r
    assert r.exit_status == ExitStatus.OK