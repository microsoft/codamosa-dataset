

# Generated at 2022-06-23 19:30:04.042839
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_format_body = JSONFormatter(**{'explicit_json': True, 'format_options': {'json': {'format': True, 'indent': 2, 'sort_keys': True}}})

# Generated at 2022-06-23 19:30:05.753297
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True

# Generated at 2022-06-23 19:30:12.916806
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(kwargs={'explicit_json': False}, format_options={
        'json': {'format': False, 'indent': 0, 'sort_keys': False}})
    # Test format_body with a text body
    assert formatter.format_body("{}", "json") == "{}"
    # Test format_body with an empty body
    assert formatter.format_body("", "json") == ""
    # Test format_body with valid JSON
    assert formatter.format_body("{\"key\":\"value\"}", "json") == "{\"key\": \"value\"}"
    # Test format_body with invalid JSON
    assert formatter.format_body("{\"key\":\"value\"}key:value", "json") == "{\"key\":\"value\"}key:value"
    # Test format

# Generated at 2022-06-23 19:30:13.545512
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    assert f is not None

# Generated at 2022-06-23 19:30:15.949249
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(error=None, options=[])
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['sort_keys'] == False
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.kwargs['explicit_json'] == False

# Generated at 2022-06-23 19:30:16.647829
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled

# Generated at 2022-06-23 19:30:17.485433
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()
    assert formatter_plugin.format_options is not None

# Generated at 2022-06-23 19:30:18.213170
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    myJsonFormatter = JSONFormatter()
    assert myJsonFormatter is not None

# Generated at 2022-06-23 19:30:20.623107
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter(explicit_json=True, format_options={'json': {'format': True}})
    assert jsonFormatter.enabled


# Generated at 2022-06-23 19:30:22.157842
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.core import http_request

    json_formatter = JSONFormatte

# Generated at 2022-06-23 19:30:33.588750
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    '''
    Test for method format_body of class JSONFormatter
    '''
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4
            }
        },
        explicit_json=True
    )

    body = '{"a": "1", "b": "2"}'
    assert formatter.format_body(body, 'json') == '{\n    "a": "1",\n    "b": "2"\n}'

    body = '{"a": "1", "b": "2"}'
    assert formatter.format_body(body, 'javascript') == '{\n    "a": "1",\n    "b": "2"\n}'


# Generated at 2022-06-23 19:30:35.314006
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j = JSONFormatter()
    assert j.format_body('{"a": "b","c": "d"}', 'json') == '{"a": "b","c": "d"}'


# Generated at 2022-06-23 19:30:37.258239
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter(
        format_options={'json': {'format': False, 'sort_keys': True, 'indent': 4}}
    )
    assert jsonformatter.enabled == False


# Generated at 2022-06-23 19:30:47.366830
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def case(kwargs, body, mime, expected):
        obj = JSONFormatter(**kwargs)
        obj.format_options['json']['indent'] = 4
        assert obj.format_body(body, mime) == expected

    case({}, "{}", "json", '{\n    \n}')
    case({}, "invalid JSON", "json", 'invalid JSON')
    case({}, "true", "json", 'true')
    case({}, "{}", "json", '{\n    \n}')
    case({}, "{}", "json", '{\n    \n}')
    case({}, "{}", "javascript", '{\n    \n}')
    case({}, "true", "text/javascript", 'true')
    case({}, "true", "text", 'true')
   

# Generated at 2022-06-23 19:30:50.263669
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert(formatter is not None)


# Generated at 2022-06-23 19:30:52.612511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{"name": "Bob"}', 'application/json') == '{\n    "name": "Bob"\n}'

# Generated at 2022-06-23 19:31:00.906476
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json':{'format':True, 'indent':2, 'sort_keys':False}})
    valid_json = b'{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body(body='{"a": 1, "b": 2}', mime='application/json') == valid_json.decode()
    assert formatter.format_body(body='{"a": 1, "b": 2}', mime='javascript') == valid_json.decode()
    assert formatter.format_body(body='{"a": 1, "b": 2}', mime='text/plain') == valid_json.decode()

# Generated at 2022-06-23 19:31:06.160270
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_format_options = {
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4,
            }
        }

    formatter = JSONFormatter(format_options=test_format_options)

    assert formatter.enabled
    assert formatter.format_options == test_format_options
    assert formatter.kwargs == {}


# Generated at 2022-06-23 19:31:07.122183
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()


# Generated at 2022-06-23 19:31:15.346988
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Create class object to be tested
    json_formatter = JSONFormatter(**{})
    # Example of JSON string
    json_string = textwrap.dedent("""\
                                {
                                  "id": 1,
                                  "name": "A green door",
                                  "price": 12.50,
                                  "tags": ["home", "green"]
                                }""")
    # Expected output
    expected = json_string
    # Get the output of tested function
    actual = json_formatter.format_body(json_string, 'json')
    # Check if there is no difference between the expected and actual output
    assert expected == actual

# Generated at 2022-06-23 19:31:23.327914
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    kwargs = {'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}, 'explicit_json': False}
    response_body = '{"a": 1, "b": 2, "c": 3}'
    assert JSONFormatter(**kwargs).format_body(response_body, 'json') == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    assert JSONFormatter(**kwargs).format_body(response_body, 'javascript') == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-23 19:31:29.476390
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json':{'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"test": "format_body()"}'
    json_body = '{\n    "test": "format_body()"\n}'
    assert formatter.format_body(body, 'json') == json_body


# Generated at 2022-06-23 19:31:34.304920
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    JSON_FORMAT_OPTIONS = {
        'json':{
            'format': True,
            'sort_keys': False,
            'indent': None,
        },
    }
    f = JSONFormatter(format_options=JSON_FORMAT_OPTIONS, explicit_json=False)
    
    body = '{"a":"b"}'
    mime = "json"
    assert f.format_body(body, mime) == body

# Generated at 2022-06-23 19:31:41.854785
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        'explicit_json': False
    })

    assert json_formatter.format_body('{"a": 4}', 'json') == '{\n  "a": 4\n}'
    assert json_formatter.format_body('{"a": 4}', 'text') == '{\n  "a": 4\n}'
    assert json_formatter.format_body('{"a": 4}', 'javascript') == '{\n  "a": 4\n}'
    assert json_formatter.format_body('{"a": 4}', 'foo') == '{"a": 4}'


# Generated at 2022-06-23 19:31:44.041286
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}})
    assert fp

# Generated at 2022-06-23 19:31:52.636115
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options=json.loads('{"json": {'
                                                                    '"format": true,'
                                                                    '"indent": 2,'
                                                                    '"sort_keys": true'
                                                                    '},'
                                                            '"colors": {'
                                                                    '"body": "blue",'
                                                                    '"header": "green"'
                                                                    '}'
                                                          '}'
                                                           ),
                                   **json.loads('{'
                                                '"explicit_json": true'
                                                '}'
                                                )
                                   )

# Generated at 2022-06-23 19:32:00.944391
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test if the json string has been formatted by JSONFormatter.
    """
    test_str = '{"name":"Trantor","stars":"1"}'
    test_obj = json.loads(test_str)
    test_debug_obj = json.dumps(
        obj=test_obj, sort_keys=False, ensure_ascii=False, indent=4)
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': False, 'indent': 4}})
    assert formatter.format_body(test_str, 'json') == test_debug_obj, \
    "JSONFormatter error: format json string failed!"

# Generated at 2022-06-23 19:32:09.813531
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.input import ParseResult
    from httpie.output import get_parser

    f = JSONFormatter(explicit_json=True,
                      format_options={'json': {'indent': 2, 'sort_keys': True}})
    p = get_parser('json', ParseResult(
        method='GET',
        scheme='http',
        host='127.0.0.1',
        path='/',
        headers={},
        auth=None,
        data=None))

    response = p(b'{"foo": "bar"}').splitlines()[0]
    assert f.format_body(response, 'json') == \
        '{\n  "foo": "bar"\n}'
    assert f.format_body(response, 'text') == response



# Generated at 2022-06-23 19:32:11.627429
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    t = JSONFormatter()
    assert t.kwargs == {}
    assert t.format_options == {}
    assert t.enabled == False

# Generated at 2022-06-23 19:32:13.649642
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    expected = {'indent': 2, 'sort_keys': False, 'format': True}
    assert JSONFormatter({'json': expected}).format_options['json'] == expected

# Generated at 2022-06-23 19:32:17.428366
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin, FormatterOptions
    from httpie.compat import str
    options = FormatterOptions(json={'sort_keys': False, 'indent': None, 'format': True})
    j = JSONFormatter(format_options=options, explicit_json=False)
    assert j.format_body(
        '{"z":1,"a":2}',
        mime='json'
    ) == '{\n    "z": 1,\n    "a": 2\n}'
    assert j.format_body(
        '{"z":1,"a":2}',
        mime='json'
    ) == '{\n    "z": 1,\n    "a": 2\n}'



# Generated at 2022-06-23 19:32:19.592534
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert not formatter.enabled


# Generated at 2022-06-23 19:32:25.083037
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(**{})
    assert jf.kwargs == {}
    assert jf.enabled is True
    assert jf.format_options['json']['indent'] == 4
    assert jf.format_options['json']['format'] is True
    assert jf.format_options['json']['sort_keys'] is False

# Generated at 2022-06-23 19:32:30.385049
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter_instance = JSONFormatter(**{'format_options': {'json': {'format': True, 'indent': None, 'sort_keys': False}}})
    assert JSONFormatter_instance.enabled == True
    assert JSONFormatter_instance.kwargs == {'format_options': {'json': {'format': True, 'indent': None, 'sort_keys': False}}}


# Generated at 2022-06-23 19:32:40.885750
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4,
            }
        },
        explicit_json=True)

    request_1 = {
        'body': json.dumps({
            'test': 'test',
            'test1': 'test1',
        }),
        'mime': 'application/json',
    }
    request_2 = {
        'body': json.dumps({
            'test': 'test',
            'test1': 'test1',
        }),
        'mime': 'text/plain',
    }
    request_3 = {
        'body': 'invalid json',
        'mime': 'application/json',
    }

    assert form

# Generated at 2022-06-23 19:32:46.758415
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options = {
            'flatten': {
                'headers': True,
                'body': True
            },
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        }
    )

    # Test if the constructor can initialize and work as intended
    assert formatter.enabled == True


# Generated at 2022-06-23 19:32:52.376781
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from json import loads
    from collections import defaultdict
    from os import path
    from json import JSONDecodeError
    from pathlib import Path
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import registry as plugin_registry
    json_path = path.join(str(Path(__file__).parent.absolute()), path.join('jsons', 'plugin_json.json'))
    with open(json_path, 'r') as f:
        try:
            plugin_json = loads(f.read())
        except JSONDecodeError:
            pass

# Generated at 2022-06-23 19:32:58.683302
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"test": "me"}'
    mime = 'application/json'
    expected_result = '{\n  "test": "me"\n}'
    result = json_formatter.format_body(body, mime)
    assert(result == expected_result)



# Generated at 2022-06-23 19:33:02.240239
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	d = {
		'json': 
			{
				'format': True,
				'indent': 4,
				'sort_keys': True
			}
		}
	assert JSONFormatter(d, None, None)


# Generated at 2022-06-23 19:33:04.063043
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        formatter = JSONFormatter()
    except Exception:
        assert False

# Generated at 2022-06-23 19:33:09.904282
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(**{
        'format_options': {'json': {'format': 'on'}},
        'explicit_json': False})

    body = '{"key": "value", "int": 12}'
    mime = 'json'
    expected_body = '{\n    "int": 12,\n    "key": "value"\n}'

    actual_body = formatter.format_body(body, mime)
    assert actual_body == expected_body

# Generated at 2022-06-23 19:33:14.787911
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 0, "b": 1}'
    mime = 'json'
    assert 'json' == JSONFormatter(format_options={'json':{
        'format':True,
        'sort_keys':True,
        'indent': 2
    }}).format_body(body=body, mime=mime)

# Generated at 2022-06-23 19:33:24.059182
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(explicit_json=True,
                      format_options={'json': {'sort_keys': True, 'indent': 2}})

    # Body is not a JSON, method should return the same body on output
    assert f.format_body('Invalid JSON', 'application/json') == 'Invalid JSON'

    # Body is a valid JSON, but its disabled (explicit_json = False)
    # Method should return the same body on output
    f.kwargs['explicit_json'] = False
    assert f.format_body('{"Enabled": "False"}', 'application/json') == '{"Enabled": "False"}'

    # Body is a valid JSON and every setting is enabled
    f.kwargs['explicit_json'] = True

# Generated at 2022-06-23 19:33:25.479497
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert True

# Generated at 2022-06-23 19:33:30.995616
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Test: class JSONFormatter, method format_body."""
    # Valid JSON as input data
    data = '{"message": "hello"}'
    mime = 'json'
    # Create an object of class JSONFormatter
    formatter = JSONFormatter(
        format_options={'json': {'format': True, 'indent': 4,
                                 'sort_keys': True}},
        explicit_json=False,
        json_indent=None,
        json_sort_keys=None,
        pretty=None,
    )
    # Check the result
    assert json.loads(formatter.format_body(data, mime)) == {'message': 'hello'}

    # Valid JSON as input data
    data = '{"message": "hello"}'
    mime = 'text'
    # Create an object

# Generated at 2022-06-23 19:33:40.968631
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert json.loads('{"key": 1 }') == \
        json.loads(JSONFormatter().format_body(
            '{"key": 1 }', 'json'))
    assert json.loads('{"key": 1 }') == \
        json.loads(JSONFormatter().format_body(
            '{"key": 1 }', 'text'))
    assert json.loads('{"key": 1 }') == \
        json.loads(JSONFormatter(explicit_json=True).format_body(
            '{"key": 1 }', 'application/json'))
    assert '{"key": 1 }' == JSONFormatter().format_body(
        '{"key": 1 }', 'application/json')

# Generated at 2022-06-23 19:33:42.516048
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == 0

# Generated at 2022-06-23 19:33:52.866078
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Inputs for this test
    test_body = '{"a":1,"b":2}'
    mime = 'application/json'
    kwargs = {
        "explicit_json": True,
        "format_options": {
            "json": {
                "format": True,
                "indent": 1,
                "sort_keys": True
            }
        }
    }

    # Expected outputs
    expected_indented_body = '{\n "a": 1,\n "b": 2\n}'

    # Create an instance of the JSONFormatter
    formatter = JSONFormatter(**kwargs)

    # Test body formatter with sort_keys=True
    assert formatter.format_body(test_body, mime) == expected_indented_body

    # Test body formatter with

# Generated at 2022-06-23 19:33:53.438424
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-23 19:33:57.404013
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    global formatter
    formatter = JSONFormatter(options={"json": {"format":True}})
    formatter.format_body('{"a":"b"}','application/json') == '{\n    "a": "b"\n}'

# Generated at 2022-06-23 19:34:02.597292
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {'json':{'format':True,
                              'indent':2,
                              'sort_keys':True}}
    formatter = JSONFormatter(format_options=format_options)
    assert formatter.enabled == True
    assert formatter.format_options == format_options
    assert formatter.kwargs == {}


# Generated at 2022-06-23 19:34:06.564070
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    this = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': False,
            }
        }
    )
    assert this.format_options['json']['format']
    assert this.format_options['json']['indent'] == 4
    assert not this.format_options['json']['sort_keys']

# Generated at 2022-06-23 19:34:17.221975
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_class = JSONFormatter()
    # Test simple JSON_Formatter
    assert test_class.format_body("{}", {}) == "{}"
    # Test JSON_Formatter with unicode in text
    assert test_class.format_body(json.dumps(
        obj={
            "flag": True,
            "char": "С",
            "num": 1
        },
        sort_keys=True,
        ensure_ascii=False,
        indent=2), {}) == '{\n  "char": "С", \n  "flag": true, \n  "num": 1\n}'
    # Test JSON_Formatter with bad data
    assert test_class.format_body("{", {}) == "{}"

# Generated at 2022-06-23 19:34:23.002015
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.format_options['json']['format'] == False
    assert formatter.kwargs['explicit_json'] == False
    assert formatter.format_options['json']['sort_keys'] == False
    assert formatter.format_options['json']['indent'] == 2
    

# Generated at 2022-06-23 19:34:25.136602
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    instance = JSONFormatter()
    instance.format_body(body='', mime='')

# Generated at 2022-06-23 19:34:27.099846
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    joj = JSONFormatter()
    assert_false(joj.enabled)


# Generated at 2022-06-23 19:34:35.682228
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:34:36.701790
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter is not None

# Generated at 2022-06-23 19:34:41.724669
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    actual_result = JSONFormatter().format_body(body='{"a": 1}', mime='json')
    expected_result = '{\n    "a": 1\n}'

    print("Actual result: " + actual_result)
    print("Expected result: " + expected_result)

    assert actual_result == expected_result

# unit test for method __init__ of class JSONFormatter

# Generated at 2022-06-23 19:34:50.918160
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={"json": {
        "format": True,
        "sort_keys": True,
        "indent": 3,
    }},
    explicit_json=True,
    colors=None)
    # Proper JSON
    body = '{"message": "Sample message", "message_id": "123"}'
    mime = "application/json"
    assert formatter.format_body(body, mime) == '{   \n   "message": "Sample message",\n   "message_id": "123"\n}'

    # Invalid JSON
    body = '{invalid: "json"}'
    mime = "application/json"
    assert formatter.format_body(body, mime) == '{invalid: "json"}'

    # Non-JSON content


# Generated at 2022-06-23 19:34:52.383557
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False

# Generated at 2022-06-23 19:34:57.446237
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test with default values
    jf = JSONFormatter()
    assert jf.get_name() == "json"
    assert jf.format_options['json']['indent'] == None
    assert jf.format_options['json']['sort_keys'] == None
    assert jf.format_options['json']['format'] == False

    # Test with custom values
    jf = JSONFormatter(indent=2, sort_keys=True)
    assert jf.get_name() == "json"
    assert jf.format_options['json']['indent'] == 2
    assert jf.format_options['json']['sort_keys'] == True
    assert jf.format_options['json']['format'] == True

    # Test with custom values and override one

# Generated at 2022-06-23 19:34:58.044702
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass

# Generated at 2022-06-23 19:35:06.389594
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    The format_body method of JSONFormatter, when called upon the string
    '{"name": "Hello World"}' with argument 'application/json',
    should return a string containing the keys in alphabetical order.
    :return:
    """
    json_formatter = JSONFormatter(**{'explicit_json': False, 'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}})
    json_str = '{"name": "Hello World"}'
    mime = 'application/json'
    assert json_formatter.format_body(json_str, mime) == '{\n    "name": "Hello World"\n}'



# Generated at 2022-06-23 19:35:13.500077
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test 1 : Test when the format options contain json
    params = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    }
    json_formatter = JSONFormatter(**params)

    assert json_formatter.format_options['json']['format'] == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True

    # Test 2 : Test when the format options do not contain json
    # This will create a new json entry in the format options

# Generated at 2022-06-23 19:35:25.006649
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    plugin = JSONFormatter()
    body_unformatted = """
    {"foo": 1} {"bar": [10,20]} {
        "baz": "a\\u0020string"
    }"""
    body_formatted = '''
    {
        "bar": [
            10,
            20
        ],
        "baz": "a string",
        "foo": 1
    } {
        "bar": [
            10,
            20
        ],
        "baz": "a string",
        "foo": 1
    } {
        "baz": "a string",
        "foo": 1
    }'''
    assert plugin.format_body(body_unformatted, 'json') == body_formatted

# Generated at 2022-06-23 19:35:26.062798
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    json_formatter.format_body(b'', 'application/json')

# Generated at 2022-06-23 19:35:33.259838
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    obj = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert obj.kwargs['explicit_json'] == False
    assert obj.format_options['json']['format'] == True
    assert obj.format_options['json']['indent'] == 4
    assert obj.format_options['json']['sort_keys'] == True

# Generated at 2022-06-23 19:35:41.434890
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from tempfile import mkstemp
    from os import remove
    from os.path import isfile
    from os.path import getsize
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.json import JSONFormatter

    fd, filename = mkstemp()
    remove(filename)

    kwargs = {
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            },
        },
    }
    assert(issubclass(JSONFormatter, FormatterPlugin))
    plugin = JSONFormatter(**kwargs)
    assert(kwargs['format_options'] == plugin.format_options)
    assert(plugin.enabled == True)


# Generated at 2022-06-23 19:35:45.987121
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }
    json_formatter = JSONFormatter(format_options=json_format_options)
    assert json_formatter.kwargs == {'explicit_json': False}
    assert json_formatter.enabled == True
    assert json_formatter.format_options == {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }


# Generated at 2022-06-23 19:35:51.016228
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = next(f for f in FormatterPlugin.get_formatters()
                     if f.__class__.__name__ == 'JSONFormatter')
    assert True == formatter.enabled
    assert '{"data": "value"}' == formatter.format_body('{"data": "value"}', 'application/json')
    assert '{"data": "value"}' == formatter.format_body('{"data": "value"}', 'text/javascript')
    assert '{"data": "value"}' == formatter.format_body('{"data": "value"}', 'text/plain')
    assert '{"data": "value"}' == formatter.format_body('{"data": "value"}', 'text/html')

# Generated at 2022-06-23 19:35:59.753239
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'sort_keys': False,
            'indent': 4,
            'format': True,
        }
    }
    kwargs = {
        'explicit_json': False,
    }
    json_formatter = JSONFormatter(format_options, kwargs)
    assert json_formatter.enabled == True
    assert json_formatter.format_options == format_options
    assert json_formatter.kwargs == kwargs


# Generated at 2022-06-23 19:36:04.166867
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    js = JSONFormatter([{'json': {'format': True, 'indent': 1, 'sort_keys': True}}])
    assert js.enabled == True
    assert js.format_options["json"]["indent"] == 1
    assert js.format_options["json"]["sort_keys"] == True



# Generated at 2022-06-23 19:36:08.993256
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'sort_keys': True, 'indent': 4, 'format': True}})
    assert json_formatter.format_options['json']['sort_keys']
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['format']


# Generated at 2022-06-23 19:36:11.128899
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    ff = JSONFormatter(format_options={'json': {'format': False}})
    assert ff.enabled is False


# Generated at 2022-06-23 19:36:12.794710
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert hasattr(formatter, 'format_options')


# Generated at 2022-06-23 19:36:20.007710
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.format_options == {'json': {'indent': 4, 'sort_keys': True}}
    json_formatter = JSONFormatter(format_options={"foo": {"bar": "baz"}})
    assert json_formatter.format_options == {"foo": {"bar": "baz"}}
    assert not json_formatter.enabled



# Generated at 2022-06-23 19:36:28.699484
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    raw_data = '{"key1": "value1", "key3": "value3", "key2": "value2"}'
    indented_data = '{\n    "key1": "value1",\n    "key2": "value2",\n    "key3": "value3"\n}'
    sorted_data = '{\n    "key1": "value1",\n    "key2": "value2",\n    "key3": "value3"\n}'
    result = json_formatter.format_body(raw_data, 'application/json')
    assert raw_data == result

    # Indentation is preserved

# Generated at 2022-06-23 19:36:36.353346
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    class DummyResponse:
        headers = {'Content-Type': 'application/json'}
        reason = 'OK'
        status_code = 200
        url = 'http://www.google.com'

    class DummyRequest:
        method = 'GET'

    class DummyArgs:
        explicit_json = False

    json_formatter = JSONFormatter(args=DummyArgs())
    assert json_formatter.format_body('{"status": 200}',
                                      mime='application/json') == '{\n    "status": 200\n}'

# Generated at 2022-06-23 19:36:44.066943
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	import pytest
	import sys
	if sys.version_info >= (3, 0):
		def test_unicode_arg_names():
			formatter = JSONFormatter(**{u'explicit_json': True})
			assert formatter.kwargs['explicit_json']
			assert isinstance(formatter.kwargs['explicit_json'], bool)
	else:
		def test_unicode_arg_names():
			with pytest.raises(TypeError):
				formatter = JSONFormatter(**{u'explicit_json': True})
				assert formatter.kwargs['explicit_json']
				assert isinstance(formatter.kwargs['explicit_json'], bool)

# Generated at 2022-06-23 19:36:52.581960
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    mime = 'json'
    body = '{"hello": "world"}'
    json_formatter = JSONFormatter(**{'explicit_json':False, 'format_options':{'json':{'format':True, 'indent':1, 'sort_keys':True}}})
    assert json_formatter.format_body(body,mime) == '{\n "hello": "world"\n}'

    mime = 'text'
    body = '{"hello": "world"}'
    json_formatter = JSONFormatter(**{'explicit_json':False, 'format_options':{'json':{'format':True, 'indent':1, 'sort_keys':True}}})

# Generated at 2022-06-23 19:37:02.171093
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from base64 import b64encode
    from httpie.plugins import builtin as builtins

    formatter = builtins[JSONFormatter.name].instance

    # plain/text
    assert formatter.format_body(
        '{"foo": "bar"}',
        'plain/text'
    ) == '{\n    "foo": "bar"\n}'

    # application/json
    assert formatter.format_body(
        '{"foo": "bar"}',
        'application/json'
    ) == '{\n    "foo": "bar"\n}'

    # application/x-www-form-urlencoded

# Generated at 2022-06-23 19:37:09.331002
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters import JSONFormatter

    # Create a 'faux' output color plugin
    class FauxOutputFormat(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = True

        def format_body(self, body: str, mime: str) -> str:
            return body

    # Create a 'faux' httpie.
    class FauxHTTPie:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # GIVEN an enabled JSONFormatter with a mocked output color plugin
    enabled_kwargs = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}


# Generated at 2022-06-23 19:37:11.553597
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  jsonform = JSONFormatter()
  assert jsonform.format_options['json']['format'] == True


# Generated at 2022-06-23 19:37:21.316571
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = formatter.format_body('{"hello": "there"}', "json")
    assert body == '{\n    "hello": "there"\n}'
    # It does not matter if the mime type is json or not
    body = formatter.format_body('{"hello": "there"}', "text")
    assert body == '{\n    "hello": "there"\n}'
    # But if the body is not valid JSON it will not format it
    body = formatter.format_body('not valid json', "text")
    assert body == 'not valid json'
    # Or when explicit_json is specified
    body = formatter.format_body('{"hello": "there"}', "text",
                                 explicit_json=True)

# Generated at 2022-06-23 19:37:26.680192
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options=dict(json=dict(indent=0, sort_keys=False, format=False)))
    assert json_formatter.format_options == dict(json=dict(indent=0, sort_keys=False, format=False))
    assert json_formatter.kwargs == dict()
    assert json_formatter.enabled == False


# Generated at 2022-06-23 19:37:34.265757
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.input import ParseResult
    from httpie.plugins import FormatterPlugin
    fp = JSONFormatter(output_options = {}, 
                       format_options = {
                           'json':{
                               'format': True,
                               'indent': 2,
                               'sort_keys': 'True'
                           }
                       },
                       parse_result = ParseResult())
    assert isinstance(fp, FormatterPlugin)

# Generated at 2022-06-23 19:37:37.449339
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(**{'json': {'indent': 2, 'format': True, 'sort_keys': True}})
    assert(formatter.kwargs == {'json': {'indent': 2, 'format': True, 'sort_keys': True}})
    assert(formatter.format_options == {'json': {'indent': 2, 'format': True, 'sort_keys': True}})
    assert(formatter.enabled == True)


# Generated at 2022-06-23 19:37:42.690066
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    }
    kwargs = {
        'format_options': format_options
    }
    assert JSONFormatter(**kwargs)

# Generated at 2022-06-23 19:37:44.594302
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test exists
    JSONFormatter

# Unit tests for func format_body

# Generated at 2022-06-23 19:37:54.855233
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import pytest
    from requests import Response
    from httpie import Context

    expected = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    }

    response = Response()
    response.status_code = 200
    response.headers = {
        'Content-Type': 'application/json'
    }
    response._content = b'{"x": "y"}'

    context = Context()
    context.options = expected

    ret = JSONFormatter(ctx=context).format_body(body=response.text, mime=response.headers['Content-Type']).encode()
    assert ret == b'{\n    "x": "y"\n}'

    # Test with application/javascript

# Generated at 2022-06-23 19:38:01.247887
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter(format_options={'json': {'format': False, 'indent': 2, 'sort_keys': False}},
                      explicit_json=False)
    assert j.enabled is False
    assert j.kwargs['explicit_json'] is False
    assert j.kwargs['format_options']['json']['indent'] == 2
    assert j.kwargs['format_options']['json']['sort_keys'] is False


# Generated at 2022-06-23 19:38:12.426320
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import sys
    from mock import Mock
    from httpie.core import io as io_module
    from httpie.core import main
    from httpie.core import do_http
    from httpie.core import version
    from httpie.core import http_version
    from httpie.core import exit_status
    from httpie.core import response
    from httpie.plugins import builtin
    from httpie.plugins import registry
    from httpie.plugins import JSONFormatter

    registry._registry._entries = []
    registry._registry._instance = None

    main_class = Mock(spec=main.HTTPie)
    main_class.output = Mock(spec=io_module.IO)
    main_class.output.stdout = Mock(spec=io_module.Stdout())
    main_class.output.stdout

# Generated at 2022-06-23 19:38:19.085626
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import HTTPieJSONAdapter
    from httpie.compat import StringIO

    _input = StringIO("""'json': {'format': True, 'indent': 4, 'sort_keys': True}""")

    parser = HTTPieJSONAdapter(_input)
    parser.parse()

    fmt = JSONFormatter(format_options=parser.format_options, explicit_json=True)
    assert fmt.enabled is True



# Generated at 2022-06-23 19:38:29.117055
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(kwargs=dict(
        explicit_json=False,
        format_options=dict(json=dict(
            format=True,
            sort_keys=True,
            indent=4
        ))),
    )

    # Test 1:
    non_json_body = b"I'm not a JSON"
    non_json_mime = 'text/html'
    json_body = json_formatter.format_body(
            body=non_json_body,
            mime=non_json_mime)
    assert json_body == non_json_body

    # Test 2:
    json_body = b'{"a":"b"}'
    non_json_mime = 'text/html'

# Generated at 2022-06-23 19:38:30.479898
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-23 19:38:39.893289
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'indent': 2,
                'sort_keys': True,
                'format': True,
            },
            'style': {
                'body': {
                    'enabled': True,
                    'theme': 'dark',
                },
                'headers': {
                    'enabled': True,
                    'theme': 'dark',
                },
            },
        },
        colors=True,
    )
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['style']['body']['enabled'] == True
    assert form

# Generated at 2022-06-23 19:38:47.170775
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    input_json = {'key': 'value'}
    input_json_str = json.dumps(obj=input_json)

    formatter = JSONFormatter({'json': {'format': False, 'sort_keys': False, 'indent': 0}})
    json_str = formatter.format_body(input_json_str, "application/json")
    assert json_str == input_json_str

    formatter = JSONFormatter({'json': {'format': True, 'sort_keys': False, 'indent': 0}})
    json_str = formatter.format_body(input_json_str, "application/json")
    assert json_str == input_json_str


# Generated at 2022-06-23 19:38:56.265475
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import plugin_manager
    json_formatter = JSONFormatter(plugin_manager=plugin_manager)
    body = json_formatter.format_body('{"foo": "bar"}', 'json')
    assert body == '{\n    "foo": "bar"\n}'
    body = json_formatter.format_body('{"foo": "bar"}', 'application/json')
    assert body == '{\n    "foo": "bar"\n}'
    body = json_formatter.format_body('{"foo": "bar"}', 'application/text')
    assert body == '{"foo": "bar"}'

# Generated at 2022-06-23 19:39:03.252440
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'indent': None, 'sort_keys': True, 'format': True}}, colors=False, style=None, theme=None, implicit_content_type=None, default_options=None)
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == None
    assert formatter.format_options['json']['sort_keys'] == True



# Generated at 2022-06-23 19:39:14.465142
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    settings = dict()
    settings['json'] = dict()
    settings['json']['format'] = True
    settings['json']['sort_keys'] = False
    settings['json']['indent'] = 2
    settings['explicit_json'] = False

    kwargs = dict()
    kwargs['settings'] = settings

    json_formatter = JSONFormatter(**kwargs)
    
    body = '{"data": [{"name": "Roland Deschain", "surname": "of Gilead", "age": 29, "class": [{"name": "Gunslinger", "level": 1}]}]}'

    mime = "json"

# Generated at 2022-06-23 19:39:23.197390
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(format_options={'json': {'format': True}})

    # No json content in body
    body = '''Not a json body'''
    assert body == jf.format_body(body, 'text/html')

    # JSON body
    body = '''{"a":1}'''
    assert body == jf.format_body(body, 'text/html')

    # With indent
    jf = JSONFormatter(format_options={
        'json': {'format': True, 'indent': 2}})
    assert '''{\n  "a": 1\n}''' == jf.format_body(body, 'text/html')

    # With sort keys

# Generated at 2022-06-23 19:39:28.028458
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    """Unit test for constructor of class JSONFormatter"""
    json_formatter = JSONFormatter(session=None, **{'json': {'format': True,
                                                             'indent': 4,
                                                             'sort_keys': True}})
    assert json_formatter
    assert json_formatter.enabled

# Generated at 2022-06-23 19:39:31.067662
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    print(json_formatter)
    assert json_formatter is not None, "Object json_formatter is not created"


# Generated at 2022-06-23 19:39:40.511110
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    assert '{}' == formatter.format_body('{}', 'json')
    assert '{}' == formatter.format_body('{}', 'javascript')
    assert '{}' == formatter.format_body('{}', 'text')
    assert '{}' == formatter.format_body('{}', 'html')
    assert '{}' == formatter.format_body('{}', 'xml')

    assert '{"a": 42}' == formatter.format_body('{"a": 42}', 'json')
    assert '{"a": 42}' == formatter.format_body('{"a": 42}', 'javascript')
    assert '{"a": 42}' == formatter.format_body('{"a": 42}', 'text')

# Generated at 2022-06-23 19:39:50.087864
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    response = """\
HTTP/1.1 200 OK
Content-Encoding: gzip
Transfer-Encoding: chunked
Content-Type: application/json;charset=UTF-8
Date: Tue, 11 Jun 2019 04:35:55 GMT
Server: nginx/1.14.0 (Ubuntu)

{"ip":"123.123.123.123"}
"""

# Generated at 2022-06-23 19:39:54.902377
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()  # kwargs is not important for formatter
    json_str = '{"key1": "value1", "key2": "value2"}'
    not_json_str = "key1=value1&key2=value2"
    result = formatter.format_body(json_str, "something")
    assert result == json_str, "There was no indentation"
    result = formatter.format_body(not_json_str, "json")
    assert result == json_str, "Incorrect indentation"