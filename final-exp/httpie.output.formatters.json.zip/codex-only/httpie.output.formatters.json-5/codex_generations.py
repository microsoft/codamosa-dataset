

# Generated at 2022-06-23 19:29:56.251337
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert isinstance(JSONFormatter(format_options=dict(),format_name='json'),
                        JSONFormatter)



# Generated at 2022-06-23 19:30:05.388072
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from pytest import raises
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from utils import TestEnvironment, httpbin

    env = TestEnvironment()
    env.stdout_isatty = True
    env.config['format'] = 'json'
    env.config['verbose'] = False
    env.config['json']['format'] = True
    env.config['json']['sort_keys'] = True
    env.config['json']['indent'] = 2
    env.config['json']['compact'] = False

    body = {'this': 'is', 'a': 'test'}
    r = http('POST', httpbin('post'), env=env, json=body)
    assert HTTP_OK in r
    assert r.json['json'] == body

    body

# Generated at 2022-06-23 19:30:07.089672
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.enabled == True


# Generated at 2022-06-23 19:30:13.679541
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.formatters import JSONFormatter
    from httpie.compat import is_windows
    body = '{"foo":"bar","baz":[123,456]}'
    mime = 'text/plain'
    format_option = {
        'json':
        {
            'format': True,
            'indent': 2,
            'sort_keys': False
        }
    }
    if is_windows:
        expected_body = '{\r\n  "foo": "bar",\r\n  "baz": [\r\n    123,\r\n    456\r\n  ]\r\n}'

# Generated at 2022-06-23 19:30:14.828870
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    assert f.format_body('{"a":1}', 'json') == '{\n    "a": 1\n}'

# Generated at 2022-06-23 19:30:22.647121
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def maybe_json(mime):
        # Actual regex from httpie/plugins/formatter/json.py
        return True if (mime.find('json') != -1
                        or mime.find('javascript') != -1
                        or mime.find('text') != -1) else False

    # Test: value error
    def json_loads_exception(msg):
        class dummy(object):
            def __init__(self, msg):
                self.msg = msg
        raise ValueError(dummy(msg))
    json.loads = json_loads_exception
    fp_json = JSONFormatter()
    mime = 'application/json'
    msg = 'invalid body'
    assert fp_json.format_body(msg, mime) == msg

    # Test: invalid json, ignore

# Generated at 2022-06-23 19:30:33.630536
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options = { "json" : { "format" : True, "indent" : 2, "sort_keys" : True }}, explicit_json = False)
    # Test case 1
    mime = 'application/json'
    body = '{"c": 3, "b": 2, "a": 1}'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2,\n  "c": 3\n}'
    # Test case 2
    mime = 'text/plain'
    assert formatter.format_body(body, mime) == '{"c": 3, "b": 2, "a": 1}'
    # Test case 3
    mime = 'application/json'

# Generated at 2022-06-23 19:30:35.072877
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(**{'explicit_json': False, 'format_options': {'json':{'format': False,'indent': 2,'sort_keys': False}}})
    assert formatter.enabled == False

# Generated at 2022-06-23 19:30:44.429727
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import UnicodeOutputPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import HTTPiePlugin

    assert isinstance(JSONFormatter(Environment()), JSONFormatter)
    assert isinstance(JSONFormatter(Environment()), HTTPiePlugin)
    assert isinstance(JSONFormatter(Environment()), FormatterPlugin)
    assert isinstance(JSONFormatter(Environment()), UnicodeOutputPlugin)


# Generated at 2022-06-23 19:30:51.282497
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter(json={'format': True, 'sort_keys': False, 'indent': 0})
    assert j.enabled == True
    assert j.format_options['json']['sort_keys'] == False
    assert j.format_options['json']['indent'] == 0

    j = JSONFormatter(json={'format': False, 'sort_keys': True, 'indent': 3})
    assert j.enabled == False
    assert j.format_options['json']['sort_keys'] == True
    assert j.format_options['json']['indent'] == 3


# class test_JSONFormatter():
#     def test_format_body(self):
#         pass



# Generated at 2022-06-23 19:31:00.076880
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {'indent': 2,
                      'explicit_json': True,
                      'sort_keys': True}

    formatter = JSONFormatter(format_options=format_options,
                              config_dir="/home/httpie/config")

    assert formatter.enabled

    # Test that JSON is formatted correctly with response
    #
    # {
    #   "k1": "v1",
    #   "k2": "v2"
    # }
    #
    # and request
    #
    # {
    #   "k1": "v1",
    #   "k2": "v2"
    # }
    body = '{ "k1": "v1", "k2": "v2" }'

# Generated at 2022-06-23 19:31:01.257414
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonf = JSONFormatter()
    assert(jsonf.format_options['json']['indent'] == 2)

# Generated at 2022-06-23 19:31:11.585624
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonF = JSONFormatter()
    jsonF.kwargs = {
        'explicit_json': True,
        'pretty': True,
        'print_body': True,
        'print_headers': True,
        'style': True
    }
    jsonF.format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    }
    body = '{"answer": 42}'
    mime = 'text/plain'
    assert jsonF.format_body(body, mime) == '{\n    "answer": 42\n}'
    body = '{"answer": 42}'
    mime = 'application/json'

# Generated at 2022-06-23 19:31:15.150535
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter({'json': {'format': True, 'indent': None, 'sort_keys': True}}, '-f', 'curl', '--json').format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'

# Generated at 2022-06-23 19:31:23.190657
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Case 'json'
    formatter_plugin_1 = JSONFormatter()
    body_1 = formatter_plugin_1.format_body( '{"foo": "bar"}', 'json')
    assert body_1 == '{\n    "foo": "bar"\n}'

    # Case 'javascript'
    formatter_plugin_2 = JSONFormatter()
    body_2 = formatter_plugin_2.format_body('{"foo": "bar"}', 'javascript')    
    assert body_2 == '{\n    "foo": "bar"\n}'

    # Case 'text'
    formatter_plugin_3 = JSONFormatter()
    body_3 = formatter_plugin_3.format_body('{"foo": "bar"}', 'text')

# Generated at 2022-06-23 19:31:31.537313
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Case 1
    plugin = JSONFormatter(format_options={"json":{"format":True,"indent":2,"sort_keys":True}},explicit_json=True)
    assert plugin.format_options == {"json":{"format":True,"indent":2,"sort_keys":True}}
    assert plugin.explicit_json == True

    # Case 2
    plugin = JSONFormatter(format_options={"json":{"format":False,"indent":1,"sort_keys":False}},explicit_json=False)
    assert plugin.format_options == {"json":{"format":False,"indent":1,"sort_keys":False}}
    assert plugin.explicit_json == False



# Generated at 2022-06-23 19:31:34.295844
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.enabled == False
    assert jf.kwargs == {}
    assert jf.format_options == {}
    assert jf.format_options['json']['format'] == True

# Generated at 2022-06-23 19:31:39.554814
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    mime = 'json'
    body = '{"key":null,"key2":[1,2,3]}'
    result = json_formatter.format_body(body=body, mime=mime)
    assert result == '{\n    "key": null,\n    "key2": [\n        1,\n        2,\n        3\n    ]\n}'



# Generated at 2022-06-23 19:31:41.855188
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    data = {'name': 'TEST'}
    body = json.dumps(data)
    mime = 'text'
    JSONFormatter().format_body(body, mime)

# Generated at 2022-06-23 19:31:45.470839
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    body = json_formatter.format_body(body='{"a": 12, "b": "abc"}', mime="json")
    assert body == '{\n  "a": 12,\n  "b": "abc"\n}'

# Generated at 2022-06-23 19:31:49.431701
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = {
        "bool_key": True,
        "false_key": False,
        "number_key": 42,
        "empty_string_key": "",
        "string_key": "42",
        "array_key": [False],
        "object_key": {
            "key": "value"
        }
    }
    body_string = json.dumps(body)
    result_string = json_formatter.format_body(body_string, 'json')
    assert body_string == result_string

# Generated at 2022-06-23 19:31:57.623922
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    with open("config.json") as fp:
        config = json.load(fp)
    format_options = config['settings']['format']
    kwargs = {}
    kwargs['explicit_json'] = False
    kwargs['format_options'] = format_options
    formatter = JSONFormatter(**kwargs)
    assert formatter.format_options['json']['format'] == True



# Generated at 2022-06-23 19:32:04.406511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    js_f = JSONFormatter()
    # Case with valid json string
    valid_json_str = '{"a": 1, "b": 2, "c": {"d": 5}}'
    assert js_f.format_body(valid_json_str, 'json') == '{\n    "a": 1,\n    "b": 2,\n    "c": {\n        "d": 5\n    }\n}'

    # Case with invalid json string
    invalid_json_str = '{"a": 1, "b": 2, "c": {"d": 5}} }'
    assert js_f.format_body(invalid_json_str, 'json') == '{"a": 1, "b": 2, "c": {"d": 5}} }'

    # Case with non-json string
    non_json_

# Generated at 2022-06-23 19:32:07.808040
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter()
    assert j.enabled == False
    assert j.kwargs == {'explicit_json': False}
    assert j.format_options == {'json': {'format': False, 'indent': 4, 'sort_keys': False}}
    assert j.kwargs.get('explicit_json') == False
    assert j.format_options.get('json')['format'] == False
    assert j.format_options.get('json')['indent'] == 4
    assert j.format_options.get('json')['sort_keys'] == False


# Generated at 2022-06-23 19:32:13.377538
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(**{
        "format_options": {
            "json": {
                "format": True,
                "indent": 4,
                "sort_keys": True,
            }
        }
    })
    assert json_formatter.format_options["json"]["format"] == True
    assert json_formatter.format_options["json"]["indent"] == 4
    assert json_formatter.format_options["json"]["sort_keys"] == True


# Generated at 2022-06-23 19:32:18.308478
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })

    assert formatter.format_body(
    '{"foo": "bar", "baz": null}',
    'json') == '{\n    "baz": null,\n    "foo": "bar"\n}'

    assert formatter.format_body(
    '{"foo": "bar", "baz": null}',
    'application/x-www-form-urlencoded') == '{"foo": "bar", "baz": null}'


# Generated at 2022-06-23 19:32:20.742631
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    test_data = {
        '{"test":2}': '{"test":2}',
        '{"test":2, "rest":3}': '{\n    "rest": 3,\n    "test": 2\n}',
    }
    for key, value in test_data.items():
        assert formatter.format_body(key, 'json') == value

# Generated at 2022-06-23 19:32:25.006419
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = \
        JSONFormatter(format_options={'json': {'format': True,
                                                'sort_keys': True,
                                                'indent': 3}},
                      explicit_json=False)
    assert json_formatter.enabled == True


# Generated at 2022-06-23 19:32:34.359219
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonf = JSONFormatter(**{"format_options": {"json": {"format": True, "indent": 4, "sort_keys": True}}})
    assert jsonf.kwargs["format_options"]["json"]["format"] == True
    assert jsonf.kwargs["format_options"]["json"]["indent"] == 4
    assert jsonf.kwargs["format_options"]["json"]["sort_keys"] == True


# Unit tests for format_body method of class JSONFormatter
# Based on: https://github.com/jkbrzt/httpie/blob/master/tests/plugin/format_response_body_tests/test_json_formatter.py

# Generated at 2022-06-23 19:32:36.634394
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json = JSONFormatter(format_options = {'json': {'format': 'format'}})

    assert json.enabled == 'format'

# Generated at 2022-06-23 19:32:44.251832
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(kwargs={
        'explicit_json': False
    }, format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    json_string = '{"test": "HTTPie"}'
    assert json_formatter.format_body(json_string, 'application/json') == '{\n    "test": "HTTPie"\n}'
    assert json_formatter.format_body(json_string, 'text/html') == '{"test": "HTTPie"}'
    json_formatter.kwargs['explicit_json'] = True

# Generated at 2022-06-23 19:32:53.110511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    #Case 1: mime is not appropriate for JSON formatting.
    #        JSONFormatter must skip formatting json in this case.
    body_test_string = json.dumps({
        "name": "scott",
        "age": "24",
        "address": "anywhere"
        });
    mime_test_string = "text/javascript"
    expected_string = '{"name": "scott", "age": "24", "address": "anywhere"}'
    new_body_test_string = json_formatter.format_body(body_test_string, mime_test_string);
    assert expected_string == new_body_test_string, "Case 1 Failed"

    #Case 2: mime is appropriate for JSON formatting, JSONFormatter must format json in this case

# Generated at 2022-06-23 19:32:57.027458
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    plugin = JSONFormatter()
    assert plugin.enabled == False
    assert plugin.format_options == {
        'json': {
            'format': False,
            'indent': 4,
            'sort_keys': False,
        }
    }


# Generated at 2022-06-23 19:33:03.246024
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})

    assert(
        json_formatter.__class__.__name__ == 'JSONFormatter')
    assert(
        json_formatter.format_options == {'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert(
        json_formatter.enabled == json_formatter.format_options['json']['format'])


# Generated at 2022-06-23 19:33:13.248949
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(output_options={})
    body = '{"name": "foo", "age": 21}'
    mime = 'json'
    formatted_body = json_formatter.format_body(body, mime)
    assert body == formatted_body
    mime = 'application/json'
    formatted_body = json_formatter.format_body(body, mime)
    assert body == formatted_body
    mime = 'application/javascript'
    formatted_body = json_formatter.format_body(body, mime)
    assert body == formatted_body
    mime = 'text'
    formatted_body = json_formatter.format_body(body, mime)
    assert body == formatted_body
    mime = 'application/xml'
    formatted_body = json_form

# Generated at 2022-06-23 19:33:22.731033
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import json
    import jsonpatch
    from httpie.plugins import FormatterPlugin

    # create data for constructor
    format_options ={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        },
        'colors': {
            'HTTPie': {
                'args': [],
                'kwargs': {},
            },
            'body': {
                'args': [],
                'kwargs': {},
            },
            'headers': {
                'args': [],
                'kwargs': {},
            },
        }
    }
    kwargs = {
        'explicit_json': True,
        'format_options': format_options,
        'is_windows': False,
    }
    # create test object


# Generated at 2022-06-23 19:33:28.305088
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test that JSON gets indentent by four spaces
    body = {"json_object": "test"}
    body = json.dumps(body)
    jf = JSONFormatter()
    body = jf.format_body(body, 'json')
    assert body == "{\n    \"json_object\": \"test\"\n}"



# Generated at 2022-06-23 19:33:31.805939
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_options = {
        'json': {
            'format': False
        }
    }
    formatter = JSONFormatter(format_options=formatter_options)
    assert formatter.format_options == formatter_options
    assert formatter.enabled is False


# Generated at 2022-06-23 19:33:41.007940
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-23 19:33:51.812822
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonFormatter = JSONFormatter()
    jsonFormatter.kwargs = {
        'explicit_json': False,
    }
    jsonFormatter.format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    }
    body = b'[[],[]]'
    mime = 'json'
    new_body = jsonFormatter.format_body(body, mime)
    assert new_body == '[[], []]'

    jsonFormatter.kwargs = {
        'explicit_json': False,
    }
    jsonFormatter.format_options = {
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 0
        }
    }
   

# Generated at 2022-06-23 19:34:02.868815
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest
    from httpie.plugins import JSON_FORMAT_OPTIONS

    # Create fake output object.
    fake_output = object()

    # Create fake context object.
    fake_context = object()

    # Create fake kwargs object.
    fake_kwargs = object()

    # Initialize JSON formatter.
    json_formatter = JSONFormatter(
        output=fake_output,
        context=fake_context,
        format_options=JSON_FORMAT_OPTIONS,  # from httpie.plugins
        kwargs=fake_kwargs,
    )

    # Enable JSON formatter.
    json_formatter.enabled = True


# Generated at 2022-06-23 19:34:04.135879
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-23 19:34:12.129926
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import tempfile
    from os import path
    from httpie.plugins import load_plugins
    from json_formatter_plugin import JSONFormatter

    my_plugins = [
        JSONFormatter(),
    ]
    my_config_dir = tempfile.mkdtemp()
    config = {
        '__meta__': {
            'config_dir': my_config_dir,
            'config_path': path.join(my_config_dir, 'config.json'),
        },
        'format': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            },
        },
    }
    load_plugins(my_plugins, config)

    formatter = JSONFormatter()

    # Valid JSON string

# Generated at 2022-06-23 19:34:19.633733
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    kwargs = {}
    formatter = JSONFormatter(**kwargs)
    assert formatter.format_body('{"test": "success"}', 'json') == \
           '{\n    "test": "success"\n}'
    assert formatter.format_body('{"test": "success"}', 'application/json') == \
           '{\n    "test": "success"\n}'
    assert formatter.format_body('{"test": "success"}', 'xml') == \
           '{"test": "success"}'

# Generated at 2022-06-23 19:34:22.156233
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter=JSONFormatter()
    assert json_formatter.format_options['json']['format']


# Generated at 2022-06-23 19:34:28.253178
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_obj = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}}, explicit_json=False, force_colors=False)
    assert json_obj.enabled == True
    assert json_obj.kwargs['explicit_json'] == False
    assert json_obj.kwargs['force_colors'] == False


# Generated at 2022-06-23 19:34:32.657835
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json=False)

    # valid JSON
    assert json_formatter.format_body(body='{"key":"value"}', mime='json') == '{\n    "key": "value"\n}'

    # invalid JSON
    assert json_formatter.format_body(body='{invalid}', mime='text') == '{invalid}'

# Generated at 2022-06-23 19:34:35.001569
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j = JSONFormatter()
    assert j.format_body('{"a":"b"}', 'json') == '{"a": "b"}'



# Generated at 2022-06-23 19:34:38.775306
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import pytest
    from httpie.plugins import FormatterPlugin
    json_fmt = JSONFormatter()
    assert isinstance(json_fmt, FormatterPlugin)
    assert json_fmt.format_options["json"]["format"] == True


# Generated at 2022-06-23 19:34:46.992573
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    # Test invalid format key
    assert len(formatter.format_options) == 1
    assert 'json' in formatter.format_options
    assert isinstance(formatter.format_options['json'], dict)
    # Test invalid format value
    assert len(formatter.format_options['json']) == 3
    assert 'format' in formatter.format_options['json']
    assert 'indent' in formatter.format_options['json']
    assert 'sort_keys' in formatter.format_options['json']
    assert isinstance(formatter.format_options['json']['format'], bool)
    assert isinstance(formatter.format_options['json']['indent'], int)

# Generated at 2022-06-23 19:34:53.415744
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Given
    formatter_plugin = JSONFormatter(kwargs={})
    mime_type, body = 'application/json', '{"key":"value"}'

    # When
    output = formatter_plugin.format_body(body, mime_type)

    # Then
    assert output == '{\n    "key": "value"\n}\n'

    # Given
    formatter_plugin = JSONFormatter(kwargs={})
    mime_type, body = 'application/json', '{"key":"value"}'

    # When
    output = formatter_plugin.format_body(body, mime_type)

    # Then
    assert output == '{\n    "key": "value"\n}\n'

    # Given
    formatter_plugin = JSONFormatter(kwargs={})
    mime_

# Generated at 2022-06-23 19:35:00.741893
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    The purpose of this method is to test the function format_body of the class JSONFormatter
    with a correct JSON.
    """
    assert JSONFormatter().format_body('{"a": 1, "b": {"c": [1, 2, 3]}}', 'json') == '{\n    "a": 1, \n    "b": {\n        "c": [\n            1, \n            2, \n            3\n        ]\n    }\n}\n'

# Generated at 2022-06-23 19:35:03.556915
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    try:
        JSONFormatter(**kwargs)
    except ValueError as e:
        print('ValueError: {}'.format(e))


# Generated at 2022-06-23 19:35:06.441056
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    kwargs = {'explicit_json': False}
    body = '{"a": "b"}'  # Valid json
    assert JSONFormatter(**kwargs).format_body(body, 'application/json') == body
    body = '{"a": "b"'  # Invalid json
    assert JSONFormatter(**kwargs).format_body(body, 'application/json') == body

# Generated at 2022-06-23 19:35:07.272074
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    t = JSONFormatter()


# Generated at 2022-06-23 19:35:07.765037
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
   assert JSONFormatter()

# Generated at 2022-06-23 19:35:13.449107
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options = {'json': {'format': True, 'indent': 4, 'sort_keys':True}})
    body = r'{"fruits": ["apple", "banana", "mango"]}'
    mime = 'application/json'
    formatted_body = formatter.format_body(body, mime)
    assert(formatted_body == r'{\n    "fruits": [\n        "apple",\n        "banana",\n        "mango"\n    ]\n}')


# Generated at 2022-06-23 19:35:24.963435
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from .plugins import FormatterPlugin
    formatter = FormatterPlugin(**{'format':'json','json':{'format':True,'indent':4,'sort_keys':False}})

    assert formatter.format_body('{"a":"b"}','application/json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a":"b"}','application/javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a":"b"}','text/html') == '{"a":"b"}'

    formatter = FormatterPlugin(**{'format':'json','json':{'format':True,'indent':0,'sort_keys':False}})

# Generated at 2022-06-23 19:35:26.008339
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter()
    assert isinstance(test, JSONFormatter)


# Generated at 2022-06-23 19:35:36.604722
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.builtin import FormatterPlugin
    from httpie import ExitStatus
    from utils import http
    from json import dumps

    env = Environment(stdin=None,
                      stdin_isatty=False,
                      stdout=None,
                      stdout_isatty=False,
                      output_options=None)

    formatter = FormatterPlugin(env,
                                format_options=dict(is_json=False),
                                color_options=dict(style='monokai'))


# Generated at 2022-06-23 19:35:43.143462
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Initialize class parameter
    kwargs = {
        'json': {
            'sort_keys':False,
            'format':True,
            'indent':2
        },
        'explicit_json':False
    }
    json_formatter = JSONFormatter(**kwargs)

    assert json_formatter.kwargs['explicit_json'] == False
    assert json_formatter.enabled == True


# Generated at 2022-06-23 19:35:48.911715
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    plugins = FormatterPlugin()
    args = [
        "--json",
        "yes",
        "--json-sort-keys",
        "yes",
        "--json-indent",
        "yes",
        "--json-explicit",
        "yes",
    ]
    args = plugins.parse_options(args)
    plugin = JSONFormatter(**args)

    assert plugin.enabled == True
    assert plugin.explicit_json == True
    assert plugin.sort_keys == True
    assert plugin.indent == True


# Generated at 2022-06-23 19:35:51.631519
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformater = JSONFormatter()
    assert isinstance(jsonformater, JSONFormatter)

# Generated at 2022-06-23 19:35:55.249389
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    instance = JSONFormatter(**{})
    assert isinstance(instance, FormatterPlugin)
    # instance.__init__()

# Generated at 2022-06-23 19:36:04.154562
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 3,
                'sort_keys': True
            }
        }
    )
    assert json_formatter.enabled is True
    assert json_formatter.kwargs['explicit_json'] is False

    json_formatter2 = JSONFormatter(
        format_options={
            'json': {
                'format': False,
                'indent': 2,
                'sort_keys': False
            }
        }
    )
    assert json_formatter2.enabled is False
    assert json_formatter2.kwargs['explicit_json'] is False



# Generated at 2022-06-23 19:36:04.857964
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert True

# Generated at 2022-06-23 19:36:09.459068
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(kwargs={})
    body = '[{"a": "A", "c": "C", "b": "B"}]'
    expected = '[\n  {\n    "a": "A",\n    "b": "B",\n    "c": "C"\n  }\n]'
    assert formatter.format_body(body, 'application/json') == expected



# Generated at 2022-06-23 19:36:16.869480
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Instance of JSONFormatter with format_options
    # to use for testing.
    instance = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
    )
    assert instance.format_options == {'json': {'format': True,
                                                'indent': 2,
                                                'sort_keys': True}}

# Generated at 2022-06-23 19:36:22.987178
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'sort_keys':True, 'indent':2, 'format':True}}).format_options == \
           {'json': {'sort_keys':True, 'indent':2, 'format':True}}
    assert JSONFormatter(kwargs={'explicit_json':True}).kwargs == 'explicit_json'


# Generated at 2022-06-23 19:36:26.658878
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(kwargs={'explicit_json': False,
                                      'prettify': 'all'})

    result = formatter.format_body('{}', 'json')
    expected = '{\n}'
    assert result == expected

    result = formatter.format_body('{}', 'text/plain')
    expected = '{}'
    assert result == expected

# Generated at 2022-06-23 19:36:37.383527
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = {
        "tags": [
            "advanced-topics",
            "installation"
        ],
        "authors": [
            {
                "name": "Kenneth Reitz",
                "id": "kennethreitz",
                "image": "https://d2aw5xe2jldque.cloudfront.net/uploads/avatars/kennethreitz.jpg",
                "number_of_posts": 19,
                "number_of_comments": 47
            }
        ],
        "title": "HTTP for Humans",
        "description": "A sane, sensible HTTP library for Python.",
        "id": "http-for-humans",
        "number_of_comments": 3
    }
    f = JSONFormatter()

# Generated at 2022-06-23 19:36:41.343753
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.client import JSON_ACCEPT
    obj = {'foo': True, 'bar': [1, 2, 3], 'baz': 'qux'}
    obj_str = json.dumps(obj=obj, indent=2)
    assert JSONFormatter().format_body(obj_str, JSON_ACCEPT) == obj_str

# Generated at 2022-06-23 19:36:42.505031
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert not formatter.enabled

# Generated at 2022-06-23 19:36:44.704908
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    print("Testing constructor of class JSONFormatter")
    jf = JSONFormatter()
    assert isinstance(jf, JSONFormatter)


# Generated at 2022-06-23 19:36:46.313979
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter is type(formatter)

# Generated at 2022-06-23 19:36:53.457110
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    '''Unit test for constructor of class JSONFormatter'''
    jf = JSONFormatter(None, None)
    return

# Generated at 2022-06-23 19:37:02.976420
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    instance = JSONFormatter()

    # Test case MIME contains json
    assert instance.format_body('{}', 'json')  == '{\n}'
    assert instance.format_body('{}', 'javascript')  == '{\n}'
    assert instance.format_body('{}', 'text')  == '{\n}'


    # Test case MIME not contains json
    assert instance.format_body('{}', 'text/html')  == '{}'
    assert instance.format_body('{}', '')  == '{}'
    assert instance.format_body('', '')  == ''

    # Test case json not valid
    assert instance.format_body('{', '')  == '{'
    assert instance.format_body('{', 'json')  == '{'



# Generated at 2022-06-23 19:37:08.376468
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from io import BytesIO
    from httpie.compat import urlopen
    from httpie.plugins import JSONFormatter
    from httpie.context import Environment
    response = urlopen('http://httpbin.org/get')
    formatter = JSONFormatter(Environment([]))
    # Set self.enabled to true so that the formatter will return the formatted body
    formatter.enabled = True
    output_obj = BytesIO()
    formatter.format_headers(response, output_obj)
    output_obj.seek(0)
    output = output_obj.read().decode('utf8')

# Generated at 2022-06-23 19:37:16.435657
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {
        'sort_keys': False,
        'indent': 2,
        'format': True
    }})

    body = '{"key": "value", "key2": "value2"}'
    mime = 'application/json'

    result = formatter.format_body(body, mime)
    assert result == '{\n  "key": "value",\n  "key2": "value2"\n}'

    body = '[1, 2, 3]'
    result = formatter.format_body(body, mime)
    assert result == '[\n  1,\n  2,\n  3\n]'

    body = '{"key": "value"}'
    mime = 'text/html'
    result = formatter.format

# Generated at 2022-06-23 19:37:18.780616
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled

# Generated at 2022-06-23 19:37:21.045560
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.enabled = self.format_options['json']['format']

    return __init__



# Generated at 2022-06-23 19:37:26.346430
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options = {
        'json': {
            'sort_keys': False,
            'indent': 4
        }
    })
    body = '{"hello": "world", "foo": "bar"}'

    assert json_formatter.format_body(body=body, mime="application/json") is not None

# Generated at 2022-06-23 19:37:33.231051
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.formatters.__init__ import FORMATTERS
    JSONFormatter = FORMATTERS['json']
    j = JSONFormatter()

    json_dict = {'key': 'value', 'key2': 'value2'}
    json_str = "{\n    \"key\": \"value\",\n    \"key2\": \"value2\"\n}"

    # Test a valid JSON object
    assert j.format_body(body=json.dumps(json_dict), mime='json') == json_str
    assert j.format_body(body=json.dumps(json_dict), mime='application/json') == json_str

    # Test an invalid JSON object
    assert j.format_body(body="{'hello': 'world'}", mime='json') == "{'hello': 'world'}"
   

# Generated at 2022-06-23 19:37:37.119699
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter({'json': {'format': True}}) \
        .format_body('{"hello": "world"}', 'json') == '{\n    "hello": "world"\n}'
    assert JSONFormatter({'json': {'format': False}}) \
        .format_body('{"hello": "world"}', 'json') == '{"hello": "world"}'
    assert JSONFormatter({'json': {'format': True}}) \
        .format_body('{"hello": "world"}', '') == '{"hello": "world"}'

# Generated at 2022-06-23 19:37:40.541924
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert type(formatter) is JSONFormatter
    assert formatter.enabled == False

# Unit tests for format_body method of class JSONFormatter

# Generated at 2022-06-23 19:37:49.941386
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.cli.exceptions import ExitStatus

    json_formatter = JSONFormatter(format_options={'json': {
        'format': True,
        'indent': 2,
        'sort_keys': True
    }})

    body_1 = json_formatter.format_body(
        body='{"foo": "bar", "a": "b"}',
        mime='application/json'
    )
    body_2 = json_formatter.format_body(
        body='{"foo": "bar", "a": "b"}',
        mime='application/javascript'
    )
    body_3 = json_formatter.format_body(
        body='{"foo": "bar", "a": "b"}',
        mime='text/plain'
    )
    body_4 = json_form

# Generated at 2022-06-23 19:38:00.340592
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        },
        'colors': {
            'method': 'red'
        }
    }
    test_kwargs = {
        'explicit_json': True
    }
    test_JSONFormatter = JSONFormatter(format_options=test_format_options, kwargs=test_kwargs)
    assert test_JSONFormatter.format_options == test_format_options
    assert test_JSONFormatter.kwargs == test_kwargs
    assert test_JSONFormatter.enabled == True



# Generated at 2022-06-23 19:38:05.043932
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pluginmanager
    pluginmanager.load_plugin_classes()

    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 4,
            }
        },
        explicit_json=False,
    )
    formatted = json_formatter.format_body('{"foo":"bar"}', 'json')
    assert json.loads(formatted) == {'foo': 'bar'}
    assert formatted == '{\n    "foo": "bar"\n}'

    formatted = json_formatter.format_body('{"foo":"bar"}', 'javascript')
    assert json.loads(formatted) == {'foo': 'bar'}
    assert formatted == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 19:38:16.043582
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Test case 1
    json_formatter_obj = JSONFormatter(**{'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}, 'explicit_json': False})
    assert json_formatter_obj.format_body(
        '{"this": "is not json"}',
        'application/json'
    ) == '{\n    "this": "is not json"\n}'

    # Test case 2
    json_formatter_obj = JSONFormatter(**{'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}, 'explicit_json': True})

# Generated at 2022-06-23 19:38:17.977604
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_obj = JSONFormatter()
    assert(not formatter_obj.enabled)


# Generated at 2022-06-23 19:38:21.277571
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter({'json': {'indent': True}})
    assert formatter.format_options == {'json': {'indent': True, 'sort_keys': False}}


# Generated at 2022-06-23 19:38:30.286900
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    def assert_format(body: str, mime: str, expected: str) -> None:
        result = json_formatter.format_body(body,mime)
        assert result == expected

    assert_format('{}', 'json', '{}') # returns the same if MIME is json

    # Indent, sort keys by name, and avoid unicode escapes to improve readability.
    assert_format('{"a":1, "b":2}', 'json', '{\n    "a": 1,\n    "b": 2\n}')
    assert_format('{"a":1, "b":2}', 'javascript', '{\n    "a": 1,\n    "b": 2\n}')

# Generated at 2022-06-23 19:38:34.952539
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins.builtin import JSONFormatter
    import json
    f = JSONFormatter(json.loads(
        """
        {
            "json": {
                "format": true,
                "indent": 4,
                "sort_keys": true
            }
        }
        """
    ))
    assert f.format_options['json']['format'] is True
    assert f.format_options['json']['indent'] == 4
    assert f.format_options['json']['sort_keys'] is True
    assert f.enabled is True
    assert f.kwargs == {}


# Generated at 2022-06-23 19:38:39.343504
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = {'json': {'format': True, 'sort_keys': True, 'indent': 2}}
    fp = JSONFormatter(kwargs={'explicit_json': False}, format_options=options)
    assert fp.enabled == True
    assert fp.kwargs == {'explicit_json': False}
    assert fp.format_options == options


# Generated at 2022-06-23 19:38:41.578957
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import sys
    import pytest
    formatter = JSONFormatter(stream=sys.stdout, env=None) # type: ignore
    assert formatter is not None


# Generated at 2022-06-23 19:38:42.666350
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormat = JSONFormatter()
    assert jsonFormat.enabled == False

# Generated at 2022-06-23 19:38:46.236832
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from .utils import mockHTTPieRequest
    formatter = JSONFormatter(**mockHTTPieRequest)
    assert formatter.format_body('{"b": "c"}','application/json') == '{\n    "b": "c"\n}'
    assert formatter.format_body('{"b": "c"}','text/plain') == '{"b": "c"}'

# Generated at 2022-06-23 19:38:57.632742
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import pytest
    plugin = JSONFormatter(format_options={'json': {'format': True,
                                                     'sort_keys': False,
                                                     'indent': 4}})
    assert plugin.enabled
    assert not plugin.format_options['json']['sort_keys']
    assert plugin.format_options['json']['indent'] == 4

    # Test invalid format options
    with pytest.raises(ValueError):
        plugin = JSONFormatter(format_options={'json': {'format': True,
                                                         'sort_keys': False,
                                                         'indent': -4}})

# Generated at 2022-06-23 19:39:01.298073
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_obj = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 4
            }
        }
    )
    assert formatter_obj.enabled is True


# Generated at 2022-06-23 19:39:09.830224
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie import args
    from httpie.plugins.builtin import JSONFormatter

    formatter = JSONFormatter(format_options=args.AvailableOptions.formatter_options)
    assert formatter is not None
    assert formatter.__class__.__name__ == 'JSONFormatter'
    assert issubclass(formatter.__class__, FormatterPlugin)
    assert formatter.enabled == formatter.format_options['json']['format']

# if __name__ == "__main__":
#     test_JSONFormatter()

# Generated at 2022-06-23 19:39:18.630359
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"array": [1, 2, 3],\n"boolean": true,\n"null": null,\n"number": 123,\n"object": {"a": "b",\n"c": "d"},\n"string": "Hello World"}'
    expected_body = '{\n    "array": [\n        1,\n        2,\n        3\n    ],\n    "boolean": true,\n    "null": null,\n    "number": 123,\n    "object": {\n        "a": "b",\n        "c": "d"\n    },\n    "string": "Hello World"\n}'
    assert formatter.format_body(body=body, mime='json') == expected_body

# Generated at 2022-06-23 19:39:20.963244
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}})


# Generated at 2022-06-23 19:39:21.740834
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter()
    assert jsonformatter.enabled == True

# Generated at 2022-06-23 19:39:23.579743
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().__init__()


# Generated at 2022-06-23 19:39:34.581391
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    string_json_1 = '{"baz":"qux","foo":"bar"}'
    string_json_2 = '{"foo": "bar", "baz": "qux"}'

    JSONFormatter_1 = JSONFormatter()
    JSONFormatter_2 = JSONFormatter(explicit_json='true')
    JSONFormatter_3 = JSONFormatter(explicit_json='false')
    JSONFormatter_4 = JSONFormatter(format_options={'json': {'indent': 2, 'sort_keys': True, 'format': True}})

    assert JSONFormatter_1.format_body('{"foo":"bar","baz":"qux"}', 'application/json') == string_json_1
    assert JSONFormatter_1.format_body('{"baz":"qux","foo":"bar"}', 'application/json')

# Generated at 2022-06-23 19:39:44.875658
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test for method format_body of class JSONFormatter
    """

    assert JSONFormatter().format_body('{"name": "value"}', 'json') \
        == '{\n    "name": "value"\n}'
    assert JSONFormatter().format_body('{"name": "value"}', 'javascript') \
        == '{\n    "name": "value"\n}'
    assert JSONFormatter().format_body('{"name": "value"}', 'text') \
        == '{\n    "name": "value"\n}'
    assert JSONFormatter().format_body('{"name": "value"}', 'plain') \
        == '{"name": "value"}'

# Generated at 2022-06-23 19:39:47.585450
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import formatter

    formatter_plugin = formatter.JSONFormatter
    formatter_plugin(format_options={'json': {'format': True}})



# Generated at 2022-06-23 19:39:50.518656
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(**{
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        }
    })
    assert json_formatter.format_options == {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }
    }
    assert json_formatter.enabled == True


# Generated at 2022-06-23 19:39:53.349479
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 3
            }
        },
        explicit_json = False
    )
    assert formatter.enabled

