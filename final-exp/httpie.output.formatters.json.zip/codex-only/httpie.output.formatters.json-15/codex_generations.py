

# Generated at 2022-06-23 19:29:55.177244
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert(JSONFormatter)



# Generated at 2022-06-23 19:29:57.663132
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	formatter = JSONFormatter(format_options={'json': {'format': True}})
	assert formatter.enabled == True


# Generated at 2022-06-23 19:30:06.177419
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.models import Environment
    from httpie.core import main
    from httpie.output.streams import piped_stdout_bytes
    env = Environment()
    with piped_stdout_bytes(env=env) as stdout:
        main([
            '-f', 'json',
            '-j',
            'https://httpbin.org/get',
            'Accept:application/json',
            'Content-Type:application/json',
            '--print', 'b',
        ], env=env)

# Generated at 2022-06-23 19:30:08.469287
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={
        'json': {
            'format': False,
            'sort_keys': False,
            'indent': None,
        }
    })

# Generated at 2022-06-23 19:30:19.225213
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        explicit_json=False,
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        },
        kwargs={}
    )
    # Case 1: Invalid JSON
    data = json_formatter.format_body('{[}', 'json')
    assert data == '{[}'
    # Case 2: Valid JSON and empty keys
    data = json_formatter.format_body('{"data": {}}', 'json')
    assert data == '{\n    "data": {}\n}'
    # Case 3: Valid JSON and simple keys

# Generated at 2022-06-23 19:30:29.811473
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    d = {
        'foo': 'bar',
        'baz': True,
        'qux': 1.5,
    }
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4,
        },
    })
    assert formatter.format_body(
        body=json.dumps(d),
        mime='application/json',
    ) == '''\
{
    "baz": true,
    "foo": "bar",
    "qux": 1.5
}'''


# Generated at 2022-06-23 19:30:32.062625
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    actual = JSONFormatter().format_body('{"test": "aabb"}', 'test')
    assert actual == '{"test": "aabb"}'

# Generated at 2022-06-23 19:30:34.360101
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  json_formatter = JSONFormatter()
  # Assert that JSONFormatter instantiation correctly sets the enabled variable
  assert json_formatter.enabled == True


# Generated at 2022-06-23 19:30:37.317755
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import httpie
    json_formatter = JSONFormatter()
    assert json_formatter.format_options == httpie.json.JSONPrettyPrinter().format_options
    assert json_formatter.format_options['json']['format'] == True


# Generated at 2022-06-23 19:30:42.611591
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    kwargs = {
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': False,
            }
        },
        'explicit_json': False
    }
    jsonFormatter = JSONFormatter(**kwargs)
    assert jsonFormatter.enabled == True

# Generated at 2022-06-23 19:30:45.440155
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert(
        {"a": 1, "b": 2} ==
        json.loads(JSONFormatter().format_body('{"a": 1, "b": 2}', 'json'))
    )

# Generated at 2022-06-23 19:30:55.831061
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1: Test case with invalid JSON
    response_data_invalid = b'"Invalid JSON"'
    response_data_valid = b'{"Valid JSON": "Success"}'
    response1 = JSONFormatter(**{'explicit_json':False, 'format_options':{'json':{'format': True, 'indent': 4, 'sort_keys': True}}})
    response2 = JSONFormatter(**{'explicit_json':True, 'format_options':{'json':{'format': True, 'indent': 4, 'sort_keys': True}}})
    response3 = JSONFormatter(**{'explicit_json':False, 'format_options':{'json':{'format': False, 'indent': 4, 'sort_keys': True}}})

# Generated at 2022-06-23 19:31:01.729516
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from requests import Response
    from httpie.plugins import FormatterPlugin
    from httpie.core import main
    from json import dumps

    class TestPlugin(FormatterPlugin):
        def format_body(self, body: str, mime: str) -> str:
            return body

        def format_headers(self, headers: dict) -> dict:
            return headers

        def format_path(self, path: str) -> str:
            return path

        def format_status(self, status_code: int, reason: str) -> str:
            return reason

    def get_formatter_plugin(kwargs):
        args = main.parse_args(args=[], kwargs=kwargs)
        main.configure(args)
        return TestPlugin(**kwargs)


# Generated at 2022-06-23 19:31:07.806081
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True,
                                                            'indent': 4,
                                                            'sort_keys': False}})

    assert json_formatter.format_options == {'json': {'format': True,
                                                      'indent': 4,
                                                      'sort_keys': False}}
    assert json_formatter.enabled == True
    assert json_formatter.kwargs == {}


# Generated at 2022-06-23 19:31:09.503814
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={"json": {"format": True}})
    assert formatter.enabled

# Generated at 2022-06-23 19:31:19.746462
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    obj1 = {'name': 'this', 'msg': 'test'}
    obj2 = {'age': '21', 'test': 'This is a test'}
    json_str1 = json.dumps(obj1, sort_keys=True, ensure_ascii=False)
    json_str2 = json.dumps(obj2, sort_keys=True, ensure_ascii=False)
    formatted_json_str1 = """'{\n  "name": "this", \n  "msg": "test"\n}'"""
    formatted_json_str2 = """'{\n  "age": "21", \n  "test": "This is a test"\n}'"""
    assert JSONFormatter(json={'format': True, 'indent': 2, 'sort_keys': True}).format_

# Generated at 2022-06-23 19:31:28.556732
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class HTTPieTest:
        plugins = None
        config = None

    formatter = JSONFormatter(
        HTTPieTest(),
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4,
            },
        },
        kwargs={
            'explicit_json': False,
        },
    )
    body = formatter.format_body(
        body='{"Foo":"Bar"}',
        mime='application/json'
    )
    assert body == '{\n    "Foo": "Bar"\n}'

# Generated at 2022-06-23 19:31:38.833114
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case - 1
    class TestClass:
        def __init__(self):
            self.format_options = dict()
            self.kwargs = dict()

        format_options = {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        }

        kwargs = {
            'explicit_json': False
        }

    # Initialize the test class
    test_obj = TestClass()

    # Test for class method "format_body"
    assert test_obj.format_body('{"name": "john", "age": 34}', 'json') == '{\n    "age": 34,\n    "name": "john"\n}'

# Generated at 2022-06-23 19:31:49.110329
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = {
            "json": {
                "format": True,
                "indent": 2,
                "sort_keys": True
            },
            "colors": {
                "match": True,
                "request_header": "blue",
                "status": "yellow",
                "body_highlight_match": "red,bold",
                "body_highlight_nomatch": None
            },
            "styles": {"body_highlight_match": "none"}
        },
        explicit_json=False, mime='json');
    assert formatter.format_options['json']['format'] == True;
    assert formatter.format_options['json']['indent'] == 2;
    assert formatter.format_options['json']['sort_keys'] == True;

# Generated at 2022-06-23 19:31:55.349557
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Given
    formatter = JSONFormatter()

    # When/Then
    assert formatter.format_body(body='{}', mime='application/json') == '{}'
    assert formatter.format_body(body='{}', mime='application/javascript') == '{}'



# Generated at 2022-06-23 19:31:56.908302
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = JSONFormatter()
    assert isinstance(fp, JSONFormatter)

# Generated at 2022-06-23 19:32:00.029056
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  formatter_plugin = JSONFormatter(kwargs = {"explicit_json": True,
                                             "format_options": "json"},
                                   format_options = {"json":{"format": True,
                                                             "indent": 2,
                                                             "sort_keys": True}})
  assert formatter_plugin.format_options["json"]["format"] is True
  assert formatter_plugin.format_options["json"]["indent"] == 2
  assert formatter_plugin.kwargs["explicit_json"] is True


# Generated at 2022-06-23 19:32:09.599791
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:32:16.861106
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={
        'json': {'format': True, 'indent': 2, 'sort_keys': True}
    })
    body = '{"number": 1}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n  "number": 1\n}'

    json_formatter = JSONFormatter(format_options={
        'json': {'format': True, 'indent': 4, 'sort_keys': False}
    })
    body = '{"number": 1}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "number": 1\n}'


# Generated at 2022-06-23 19:32:24.233116
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()

    assert type(json_formatter).__name__ == 'JSONFormatter'
    assert json_formatter.format_name == 'json'
    assert json_formatter.format_options['json']['format'] == True
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys'] == False

# Generated at 2022-06-23 19:32:26.089068
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_instance = JSONFormatter(format_options={'json': {'format': False}})
    assert formatter_instance.format_body(body='{}', mime='json') == '{}'

# Generated at 2022-06-23 19:32:28.470565
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter()
    assert jf.format_body(
        b'{"foo": "bar", "baz": 1}',
        'application/json'
    ) == '{\n    "foo": "bar",\n    "baz": 1\n}'



# Generated at 2022-06-23 19:32:39.553301
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    import pytest

    # Test format JSON
    formatter = JSONFormatter(**{'explicit_json': True,
        'format_options':
        {'json':
            {'format': True,
            'indent': 2,
            'sort_keys': True,
            'stream': True,
            }
        }
    })
    maybe_json = ['json', 'javascript', 'text']
    assert formatter.format_options['json']['format'] is True
    obj = {'name': 'Mark', 'age': 29, 'job': 'Developer'}
    body = json.dumps(obj, sort_keys=True, ensure_ascii=False, indent=2)
    body_formated = json.loads(body)
    body_formated_json = formatter.format_

# Generated at 2022-06-23 19:32:49.361344
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class MockResponse:
        def __init__(self):
            self.headers = {'content-type': 'application/json'}

    formatter = JSONFormatter(format_options={
        'json': {
            'format': True
        }
    })

    # Case: JSON formatted body is not indented
    response = MockResponse()
    assert '\n' not in formatter.format_body('{"foo":"bar"}', response), \
        "JSON formatted body is indented!"

    # Case: JSON formatted body is indented
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4
        }
    })

# Generated at 2022-06-23 19:32:53.409176
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fmt = JSONFormatter(**{
        "format_options": {
            "json": {
                "format": True,
                "indent": 2,
                "sort_keys": False
            }
        }
    })
    # Test initialization
    assert fmt.__class__ == JSONFormatter
    assert fmt.enabled == True
    assert fmt.kwargs == {}
    assert fmt.format_options['json']['format'] == True
    assert fmt.format_options['json']['indent'] == 2
    assert fmt.format_options['json']['sort_keys'] == False


# Generated at 2022-06-23 19:32:56.170491
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter(**kwargs)
    assert (jsonFormatter.enabled ==
            jsonFormatter.format_options['json']['format'])


# Generated at 2022-06-23 19:33:00.242438
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin = JSONFormatter(format_options='')
    body = '{"id": 1, "name": "Foo", "price": 123, "tags": ["Bar", "Eek"]}'
    mime = 'application/json'
    assert formatter_plugin.format_body(body, mime) == body

# Generated at 2022-06-23 19:33:04.867760
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': False
            }
        })

    assert formatter.format_body(
        body='{"a": 1, "b": 2}',
        mime='json'
    ) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-23 19:33:13.497207
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    
    from httpie import HTTPie
    from httpie.clients.http import HTTPPrettyClient
    from httpie.output.streams import build_stream

    httpie = HTTPie(
        'http',
        FormatterPlugin,
        HTTPPrettyClient,
        build_stream(),
        {'json': {'indent': 2, 'sort_keys': True, 'format': True}},
        {'explicit_json': False, 'pretty': True}
    )

    # Test with an invalid json
    body = '{"key": 1,}'
    mime = 'json'
    output = httpie.output_formatter.format_body(body, mime)
    assert output == body

    body = '{"key": 1}'
    mime = 'json'

# Generated at 2022-06-23 19:33:22.948313
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.input import ParseException
    from httpie.plugins import JSONFormatter
    from httpie.compat import is_py26
    # No json object
    jf = JSONFormatter()
    assert jf.format_body('{}', 'json') == '{}'
    assert jf.format_body('', 'json') == ''
    assert jf.format_body('', '') == ''
    # Valid json
    assert jf.format_body('{"a":"b"}', 'json') == '{\n    "a": "b"\n}'
    assert jf.format_body('{"a":"b"}', 'javascript') == '{\n    "a": "b"\n}'

# Generated at 2022-06-23 19:33:32.158001
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': 0,
            'sort_keys': False
        }
    })
    assert formatter.format_body('{}', 'application/json') == '{}'
    assert formatter.format_body('{', 'application/json') == '{'
    assert formatter.format_body('{"a": "b"}', 'application/json') == '"{\\"a\\": \\"b\\"}"'
    assert formatter.format_body('{"a": "b"}', 'application/javascript') == '"{\\"a\\": \\"b\\"}"'

# Generated at 2022-06-23 19:33:33.557477
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_format = 'JSONFormatter'


# Generated at 2022-06-23 19:33:36.510268
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(json_options=None)
    assert formatter.format_options == {'json': {'format': True, 'indent': 4, 'sort_keys': False}}
    assert formatter.enabled == True


# Generated at 2022-06-23 19:33:41.089736
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonFormatter = JSONFormatter(format_options={
        "json": {"format": True, "sort_keys": True, "indent": 4}
    }, kwargs={})
    body_formatted = jsonFormatter.format_body(
        body='{"a":1}', mime='application/json')
    assert body_formatted == '{\n    "a": 1\n}\n'

# Generated at 2022-06-23 19:33:46.950566
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(format_options={'json': {'format': True}})
    body = '{"a": 1, "c": 3, "b": 2}'
    assert f.format_body(body, mime='application/json') == body
    body = '{"a": 1, "c": 3, "b": 2}'
    assert f.format_body(body, mime='text') == body

# Generated at 2022-06-23 19:33:55.114394
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import mock
    import httpie
    import httpie.plugins
    import httpie.plugins.json.json
    httpie.plugins.JSON_ENABLED = True
    c = httpie.plugins.json.json.JSONFormatter(
        format_options={'json':
                            {'format': True,
                             'indent': 2,
                             'sort_keys': True
                             }
                        },
        explicit_json=True,
    )
    obj = {'k': 'v'}
    objStr = json.dumps(obj=obj, sort_keys=True, ensure_ascii=False, indent=2)
    body = json.dumps(obj=obj)
    assert c.format_body(body=body, mime='application/json') == objStr
    assert c.format_body

# Generated at 2022-06-23 19:34:02.592668
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    name = 'json'
    format_options = {'json': {'indent': 2, 'sort_keys': True, 'format': True}}
    colors = True
    color_scheme = 'Solarized (dark)'
    style = False
    styles = {}
    stdout = Sniffio()

    json = JSONFormatter(
        name = name,
        format_options = format_options,
        colors = colors,
        color_scheme = color_scheme,
        style = style,
        styles = styles,
        stdout = stdout
    )

    assert json.name == name
    assert json.format_options == format_options
    assert json.colors == colors
    assert json.color_scheme == color_scheme
    assert json.style == style
    assert json.stdout == stdout



# Generated at 2022-06-23 19:34:04.525005
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=False)
    assert formatter.kwargs['explicit_json'] == False

# Generated at 2022-06-23 19:34:08.425457
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    result = JSONFormatter(
        session=None,
        format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}},
        **{'explicit_json': False}
    ).format_body('{"id": 1, "name": "John Jones"}', "json")
    assert result == '{\n  "id": 1, \n  "name": "John Jones"\n}'

# Generated at 2022-06-23 19:34:18.419017
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            },
            'colors': {},
            'unicode': {}
        },
        explicit_json=True,
        colors_enabled=True
    )
    json_formatter.format_body('{"key": "value"}', 'json')
    json_formatter.format_body('{"key": "value"}', 'text')
    json_formatter.format_body('{"key": "value"}', 'javascript')

# Generated at 2022-06-23 19:34:27.901644
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json1 = JSONFormatter()
    assert json1.enabled == False

    json2 = JSONFormatter(format_options = {
        "csv": {
            "delimiter": ",",
            "format": False,
            "quoting": "QUOTE_NONNUMERIC"
        },
        "default": "csv",
        "headers": {
            "delimiter": ";",
            "format": False,
            "omit": False
        },
        "json": {
            "format": True,
            "indent": 2,
            "sort_keys": True
        },
        "style": "default"
    })
    assert json2.enabled == True

# Generated at 2022-06-23 19:34:39.864255
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Case 1
    json_body = '{"name": "httpie.org"}'
    # Case 2
    json_body1 = '{"name": "httpie.org"}'
    # Case 3
    json_body2 = '{"name": "httpie.org"}'

    json_formatter = JSONFormatter()

    # Case 1
    assert json_formatter.format_body(json_body, 'application/json') == json_body
    # Case 2
    assert json_formatter.format_body(json_body1, 'application/javascript') == json_body1
    # Case 3

# Generated at 2022-06-23 19:34:47.684314
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from fixtures import (BODY_JSON, BODY_JSON_SORTED,
                          BODY_JSON_FORMATTED, BODY_JSON_INVALID,
                          BODY_JSON_UNICODE)
    import json
    json_formatter = JSONFormatter()

    # Check that JSON is not incorrectly modified
    with open('/tmp/test', 'w') as f:
        f.write(BODY_JSON)
    with open('/tmp/test', 'r') as f:
        body = f.read()
    assert json_formatter.format_body(body, 'json') == body

    # Check that valid JSON is formatted
    assert json_formatter.format_body(BODY_JSON, 'json') == BODY_

# Generated at 2022-06-23 19:34:49.515158
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin

    jf = JSONFormatter()

    assert(isinstance(jf, FormatterPlugin))

# Generated at 2022-06-23 19:34:53.418493
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from requests import Response
    from tests.plugins import mock_response

    response = mock_response('{"hello": "world"}', 'application/json')

    # Test that output of method format_body,
    # called with a Response object, is equal to expected output.
    assert JSONFormatter(**{}).format_body(response.content, response.headers['Content-Type']) == '{"hello": "world"}'



# Generated at 2022-06-23 19:35:04.294038
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    instance = JSONFormatter(
        format_options={'json': {'format': False, 'indent': 1, 'sort_keys': True}}
    )
    assert(
        '{"a":"b"}' == instance.format_body(
            '{"a":"b"}', 'application/json'
        )
    )
    assert(
        '{"a":"b"}' == instance.format_body(
            '{"a":"b"}', 'application/javascript'
        )
    )
    assert(
        '{"a":"b"}' == instance.format_body(
            '{"a":"b"}', 'text/javascript'
        )
    )
    assert(
        '{"a":"b"}' == instance.format_body(
            '{"a":"b"}', 'text/plain'
        )
    )


# Generated at 2022-06-23 19:35:05.817112
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body(['{"a":"b"}'], 'foo') == '{"a":"b"}'

# Generated at 2022-06-23 19:35:13.091144
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.builtin import JSONBodyFormat
    from threading import Lock
    from httpie.compat import is_windows
    import os

    default_format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': not is_windows,
        }
    }

    if is_windows:
        # If a plugin sets Flask.config['JSONIFY_PRETTYPRINT_REGULAR']
        # to True, it might fail on Windows with a recursive error.
        # This makes sure that the default value is False.
        os.environ['JSONIFY_PRETTYPRINT_REGULAR'] = 'False'

    # Initialize JSONBodyFormat

# Generated at 2022-06-23 19:35:16.065664
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import pytest
    assert JSONFormatter(**{ "explicit_json":False , "format_options":{ "json":{ "format":True, "indent":4, "sort_keys":True}}})

# Generated at 2022-06-23 19:35:21.696601
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json' : {
            'format': True,
            'indent': 2,
            'sort_keys': False
        }
    }
    assert JSONFormatter(format_options, explicit_json=False,
                         style_error=None, mime=None, error=None).enabled

# Generated at 2022-06-23 19:35:26.398615
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(format_options={
        "json": {
            "format": True,
            "sort_keys": False,
            "indent": 2,
            "explicit_json": True
        },
        "colors": {
            "header": "yellow",
            "header_bg": "blue",
            "prompt": "green",
            "prompt_bg": "magenta",
            "body": "cyan",
            "body_bg": "green",
            "error": "red",
            "error_bg": "blue"
        }
    })
    assert jf.enabled == True

# Generated at 2022-06-23 19:35:32.225295
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert "{\n    \"name\": \"John Doe\",\n    \"salary\": 6000,\n    \"married\": true\n}" == \
        json_formatter.format_body("{\"name\":\"John Doe\",\"salary\":6000,\"married\":true}", "application/json")

# Generated at 2022-06-23 19:35:40.975991
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment

    formatter_plugin = FormatterPlugin(Environment())
    json_formatter = JSONFormatter(**formatter_plugin.kwargs)


# Generated at 2022-06-23 19:35:43.750078
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    dictionary = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 2
        }
    }
    formatter = JSONFormatter(format_options = dictionary)
    # Verify that the constructor values are correct
    assert formatter.format_options == dictionary
    assert formatter.enabled == True


# Generated at 2022-06-23 19:35:49.313922
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        },
        'colors': {
            'body': {
                'fg': '',
                'bg': ''
            },
            'font': {
                'bold': False,
                'italic': False,
                'underline': False
            },
            'headers': {
                'fg': '',
                'bg': ''
            },
            'params': {
                'fg': '',
                'bg': ''
            }
        },
        'format': 'pretty',
        'max_body_len': 0,
        'max_headers_len': 0
    }

# Generated at 2022-06-23 19:35:54.902766
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    func = JSONFormatter.format_body
    assert func("""{ "a": 1, "b": 2 }""", "json") == """{
  "a": 1,
  "b": 2
}"""
    assert func("""{ "a": 1, "b": 2 }""", "javascript") == """{
  "a": 1,
  "b": 2
}"""
    assert func("""{ "a": 1, "b": 2 }""", "xml") == """{ "a": 1, "b": 2 }"""

# Generated at 2022-06-23 19:36:04.471378
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(kwargs={'explicit_json': True})

    assert formatter.format_body("'abcd'", 'json') == "'abcd'"
    assert formatter.format_body('"abcd"', 'json') == '"abcd"'
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('[1, 2]', 'json') == '[\n    1,\n    2\n]'
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == \
        '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-23 19:36:06.230170
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert 'JSONFormatter' == formatter.__class__.__name__

# Generated at 2022-06-23 19:36:13.824921
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter()

    # Scenario 1: Test with explicit_json = False
    jf.kwargs['explicit_json'] = False
    assert(jf.format_body('{"a": "a", "b": "b"}', "json") == '{\n  "a": "a", \n  "b": "b"\n}')
    assert(jf.format_body('{"a": "a", "b": "b"}', "javascript") == '{\n  "a": "a", \n  "b": "b"\n}')
    assert(jf.format_body('{"a": "a", "b": "b"}', "text") == '{\n  "a": "a", \n  "b": "b"\n}')

# Generated at 2022-06-23 19:36:25.249564
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # initializes a JSONFormatter
    formatter = JSONFormatter(
        format_options = {'json': {'format': True, 'indent': None, 'sort_keys': False, 'explicit_json': False}},
        no_color = None
    )

    # unit test for when content type is 'application/json'
    assert formatter.format_body(body='{"key":"value"}', mime='application/json') == '{\n    "key": "value"\n}'

    # unit test for when explicit_json is False and content type is 'text/html'
    assert formatter.format_body(body='{"key":"value"}', mime='text/html') == '{"key":"value"}'

    # unit test for when explicit_json is True and content type is 'text/html'
    formatter

# Generated at 2022-06-23 19:36:29.314138
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False,
        }
    },
    explicit_json=False,
    )
    assert jsonformatter.enabled == True


# Generated at 2022-06-23 19:36:36.704535
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format':True,
            'sort_keys':True,
            'indent':3
        }
    }
    kwargs = {
        'format_options':format_options,
        'explicit_json':True
    }
    formatter = JSONFormatter(**kwargs)
    # test
    assert formatter.format_options == format_options
    assert formatter.kwargs == kwargs

# Unit tests for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:36:37.964288
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = JSONFormatter()
    assert fp.enabled == False


# Generated at 2022-06-23 19:36:47.659954
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from fixtures import FILE_JSON_PATH

    r = http('--form', 'POST', httpbin('/post'), '@' + FILE_JSON_PATH)
    assert HTTP_OK in r
    assert r.json['files']['file.json'] == '{"key1": "value1", "key2": "value2"}'
    assert r.json['form']['key1'] == 'value1'
    assert r.json['form']['key2'] == 'value2'

    # Valid JSON but not form data.
    r = http('--form', 'POST', httpbin('/post'), '@' + FILE_JSON_PATH,
             'key1=value1', 'key2=value2')
    assert HTTP_OK in r


# Generated at 2022-06-23 19:36:59.511974
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter({'json':{'format': True, 'indent': 4, 'sort_keys':True}}, {'explicit_json':False, 'request':{'method': 'GET', 'url': 'httpbin.org'}}).enabled
    assert not JSONFormatter({'json':{'format': False, 'indent': 4, 'sort_keys':True}}, {'explicit_json':False, 'request':{'method': 'GET', 'url': 'httpbin.org'}}).enabled
    assert not JSONFormatter({'json':{'format': False, 'indent': 4, 'sort_keys':True}}, {'explicit_json':True, 'request':{'method': 'GET', 'url': 'httpbin.org'}}).enabled

# Generated at 2022-06-23 19:37:00.367744
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True

# Generated at 2022-06-23 19:37:06.312052
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, json={'format': True, 'indent': 2, 'sort_keys': True})
    assert formatter.format_body('{"a": "A", "b": "B"}', 'json') == '{\n  "a": "A", \n  "b": "B"\n}'
    assert formatter.format_body('{"a": "A", "b": "B"}', 'json; charset=utf-8') == '{\n  "a": "A", \n  "b": "B"\n}'

# Generated at 2022-06-23 19:37:11.632163
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(**{
        'format': 'json',
        'indent': 4,
        'sort_keys': False
    })
    assert json_formatter.__class__.__name__ == 'JSONFormatter'
    assert json_formatter.format_name == 'json'


# Generated at 2022-06-23 19:37:15.469016
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = json.loads(
        '{"json": {"format": true, "indent": 2, "sort_keys": false}}')
    f = JSONFormatter(
        options=options,
        explicit_json=False)
    assert f.enabled == True
    assert f.format_options['json']['format'] == True
    assert f.format_options['json']['indent'] == 2
    assert f.format_options['json']['sort_keys'] == False



# Generated at 2022-06-23 19:37:16.873293
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter()
    assert jsonformatter.enabled == False

# Generated at 2022-06-23 19:37:19.098032
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_format = JSONFormatter(format_options={'json': {'format': True}})
    assert json_format.format_options['json']['format'] == True

# Generated at 2022-06-23 19:37:26.070955
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class JSONFormatterInit:
        def __init__(self, **kwargs):
            self.kwargs = {
                'explicit_json': False,
                'format_options': {
                    'json': {
                        'format': True,
                        'indent': 4,
                        'sort_keys': True
                    },
                },
                'stream': False
            }

        @staticmethod
        def print(*args, **kwargs):
            pass


# Generated at 2022-06-23 19:37:28.665706
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	a = JSONFormatter()
	print(a)

# Generated at 2022-06-23 19:37:30.458311
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json = JSONFormatter()
    assert json.enabled == "pretty"

# Generated at 2022-06-23 19:37:34.916152
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter(**{'explicit_json': False, 'format_options': {'json': {'format': True, 'sort_keys': True, 'indent': 4}}})
    assert jsonFormatter.enabled == True 
    assert jsonFormatter.kwargs['explicit_json'] == False
    assert jsonFormatter.format_options['json']['format'] == True
    assert jsonFormatter.format_options['json']['sort_keys'] == True
    assert jsonFormatter.format_options['json']['indent'] == 4


# Generated at 2022-06-23 19:37:39.048024
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(format_options = {'json' : {'format' : True, 'sort_keys' : True, 'indent' : 2}})
    assert f.kwargs == {'explicit_json': False}
    assert f.enabled == True
    assert f.format_options['json']['format'] == True
    assert f.format_options['json']['sort_keys'] == True
    assert f.format_options['json']['indent'] == 2


# Generated at 2022-06-23 19:37:48.994328
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    assert formatter.format_body(
        body='{"foo":"bar"}',
        mime='json'
    ) == '{\n    "foo": "bar"\n}'
    assert formatter.format_body(
        body='{"foo":"bar"}',
        mime='application/json'
    ) == '{\n    "foo": "bar"\n}'
    assert formatter.format_body(
        body='{"foo":"bar"}',
        mime='text/javascript'
    ) == '{\n    "foo": "bar"\n}'
    assert formatter.format_body(
        body='{"foo":"bar"}',
        mime='application/javascript'
    ) == '{\n    "foo": "bar"\n}'
    assert formatter

# Generated at 2022-06-23 19:37:53.694682
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=False, 
                              verbose=False, 
                              headers=True, 
                              body=True, 
                              style=None, 
                              format_options={'json': {'indent': 2, 'sort_keys': True, 'format': True}}, 
                              streams=(None, None))
    assert formatter.enabled == True


# Generated at 2022-06-23 19:38:00.048446
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    }

    # formatter is enabled when explicit_json or mimetype or json is set
    explicit_json = True
    mime = 'json'
    formatter = JSONFormatter(format_options=json_format_options, explicit_json=explicit_json, mime=mime)
    body = '{"foo": "bar"}'
    assert formatter.format_body(body, mime) == '{\n  "foo": "bar"\n}'

    explicit_json = False
    mime = 'json'

# Generated at 2022-06-23 19:38:04.761157
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    p = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert p.enabled is True
    assert p.kwargs == {}
    assert type(p.format_options) == dict
    assert p.format_options['json']['format'] == True
    assert p.format_options['json']['indent'] == 2
    assert p.format_options['json']['sort_keys'] == True


# Generated at 2022-06-23 19:38:11.714309
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs['explicit_json'] = True
    mime = 'application/json'
    json_dict = {'name': 'abc', 'age': 18}
    body = '{"age": 18, "name": "abc"}'
    json_body = '{\n  "age": 18, \n  "name": "abc"\n}'
    assert formatter.format_body(body, mime) == json_body


__all__ = ['JSONFormatter']

# Generated at 2022-06-23 19:38:15.730625
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(explicit_json=True, format_options={'json': {
        'format': False,
        'indent': 4,
        'sort_keys': True,
    }}).kwargs == {"explicit_json": True}

# Unit tests for function format_body of class JSONFormatter

# Generated at 2022-06-23 19:38:24.236657
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.streams import UnsupportedOutputStream
    formatter = JSONFormatter(
        format_options={
            'json': {'format': True, 'indent': None, 'sort_keys': True}
        },
        kwargs={'explicit_json': False}
    )
    body = '{"id":123,"username":"admin","password":"admin123"}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == \
        '{\n' \
        '    "id": 123,\n' \
        '    "password": "admin123",\n' \
        '    "username": "admin"\n' \
        '}'


# Generated at 2022-06-23 19:38:29.157059
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert (
        json.loads(
            JSONFormatter.__init__({'json': {'format': True}}).format_options
        )['json']['format'] is True
    )
    assert (
        json.loads(
            JSONFormatter.__init__({'json': {'format': False}}).format_options
        )['json']['format'] is False
    )


# Generated at 2022-06-23 19:38:39.413895
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from io import StringIO
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.compat import is_windows
    from httpie.config import Config
    from httpie.output.streams import StdOutBytesRaw
    from httpie.output.writers import (
        PathIO,
        StdOutBytesIO,
    )

    dict_data = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
    }
    # string_data = str(dict_data).replace(' ', '').replace(':', '=')
    json_data = json.dumps(dict_data)

# Generated at 2022-06-23 19:38:42.553237
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  assert JSONFormatter(
    format_options={
        'json': {
            'sort_keys': True,
            'indent': 4,
            'format': True,
        }
    },
    explicit_json=False
  )


# Generated at 2022-06-23 19:38:46.308298
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    initial_body = '{"data":"one","data2":2}'
    expected_body = '{\n    "data": "one",\n    "data2": 2\n}'

    test_formatter = JSONFormatter(json={'format': True, 'sort_keys': True, 'indent': 4})
    assert test_formatter.format_body(initial_body, 'text') == expected_body

# Generated at 2022-06-23 19:38:57.629826
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    body = {'key1': 'val1', 'key2': 'val2'}
    body_str = json.dumps(body)
    formatter = JSONFormatter()
    assert formatter.format_body(body_str, 'json') == json.dumps(body, sort_keys=False, ensure_ascii=False, indent=None)

    body = {'key1': 'val1', 'key2': 'val2'}
    body_str = json.dumps(body)
    formatter = JSONFormatter(format_options={'json': {'sort_keys': True, 'indent': 2}})
    assert formatter.format_body(body_str, 'json') == json.dumps(body, sort_keys=True, ensure_ascii=False, indent=2)

# Generated at 2022-06-23 19:38:59.753707
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(json={'format': False})
    assert json_formatter.enabled is False

# Generated at 2022-06-23 19:39:05.823482
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options=dict(json=dict(format=True, indent=2)))
    assert json_formatter.kwargs['explicit_json'] == False
    assert json_formatter.format_options['json']['format'] == True
    assert json_formatter.format_options['json']['indent'] == 2


# Generated at 2022-06-23 19:39:07.589895
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    obj = JSONFormatter()
    assert obj.enabled == False

# Generated at 2022-06-23 19:39:17.156410
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from .plugin_test import PluginTest
    p = PluginTest()

    # Simple JSON
    body = '{ "hi": "there" }'
    formatted_body = p.test_JSONFormatter.format_body(body, 'application/json')
    assert formatted_body == '{\n    "hi": "there"\n}'

    # Invalid JSON
    body = '{ "hi" "there" }'
    formatted_body = p.test_JSONFormatter.format_body(body, 'application/json')
    assert formatted_body == '{ "hi" "there" }'

    # JSON in text response
    body = '{ "hi": "there" }'
    formatted_body = p.test_JSONFormatter.format_body(body, 'text/plain')

# Generated at 2022-06-23 19:39:20.108198
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JF = JSONFormatter()
    assert JF.kwargs == {}
    assert JF.format_options == {'json': {'format': True, 'indent': 2, 'sort_keys': False}}


# Generated at 2022-06-23 19:39:29.202148
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from json import loads
    from httpie.plugins import HTTPBasicAuth
    from .fixtures import TEST_JSON
    formatter = JSONFormatter()
    body = loads(TEST_JSON)
    assert formatter.format_body(TEST_JSON, 'application/json')
    assert loads(formatter.format_body(TEST_JSON, 'application/')) == body
    assert loads(formatter.format_body(TEST_JSON, 'application/')) == body
    assert loads(formatter.format_body(TEST_JSON, 'application/javascript')) == body
    assert loads(formatter.format_body(TEST_JSON, 'text/javascript')) == body
    assert loads(formatter.format_body(TEST_JSON, 'text/text')) == body

# Generated at 2022-06-23 19:39:37.968013
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    config = {
        "json": {
            "format" : True,
            "sort_keys" : True,
            "indent" : 4,
        }
    }

    jf = JSONFormatter(format_options = config, explicit_json = False)

    assert jf.format_body('{"hello":"world"}', 'json') == '{\n    "hello": "world"\n}\n'
    assert jf.format_body('{"hello":"world"}', 'javascript') == '{\n    "hello": "world"\n}\n'
    assert jf.format_body('{"hello":"world"}', 'text') == '{\n    "hello": "world"\n}\n'
    assert jf.format_body('{"hello":"world"}', 'xml') == '{"hello":"world"}'

# Generated at 2022-06-23 19:39:48.169054
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    bJson = JSONFormatter(format_options = {"json":{"format":True,"indent":2,"sort_keys":True}})
    bJson1 = JSONFormatter(format_options = {"json":{"format":False,"indent":2,"sort_keys":True}})
    bJson2 = JSONFormatter()
    bJson3 = JSONFormatter(format_options = {"json":{"format":False,"indent":2,"sort_keys":True}})
    assert bJson.format_body("{\"a\":1, \"b\":2}", "application/json") == '{\n  "a": 1, \n  "b": 2\n}'

# Generated at 2022-06-23 19:39:54.961757
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('abcd', 'abc') == 'abcd'
    assert JSONFormatter().format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert JSONFormatter().format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert JSONFormatter().format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert JSONFormatter().format_body('{"a": 1, "b": 2}', 'abc') == '{"a": 1, "b": 2}'
   