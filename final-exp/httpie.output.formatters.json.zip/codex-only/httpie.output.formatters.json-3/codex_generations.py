

# Generated at 2022-06-23 19:29:52.257372
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_jsonformatter1 = JSONFormatter(kwargs= {'explicit_json': True}, format_options= {'json': {'format': True, 'sort_keys': False, 'indent': True}})
    assert test_jsonformatter1.enabled == True

# Generated at 2022-06-23 19:29:59.459148
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie import ExitStatus
    from httpie.compat import str
    from utils import http, HTTP_OK
    json_plugin_conf = test_config()
    runner = CliRunner()
    result = runner.invoke(
        http,
        [
            '--json',
            '--json-formatter', 'pretty',
            '--json-indent', '2',
            '--json-sort-keys',
            HTTP_OK,
        ],
        env=Environment(stdin_isatty=True,
                        colors=256,
                        stdout_isatty=True,
                        stdin=open(__file__, 'rb'),
                        stdout=open(os.devnull, 'wb'),
                        merge_environment=False),
        config=json_plugin_conf
    )
    # we should get

# Generated at 2022-06-23 19:30:02.068338
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  formatter = JSONFormatter(
      explicit_json=False,
      format_options={}
  )
  assert formatter.explicit_json == False
  assert formatter.format_options == {}

# Generated at 2022-06-23 19:30:08.589247
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter({'json': {'format': True, 'sort_keys': True, 'indent': 2}})

    assert formatter.format_body('{"a": 4}', 'application/json') == '{\n  "a": 4\n}'
    assert formatter.format_body('{"a": "b"}', 'application/json') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": [1, true, "three"]}', 'application/json') == '{\n  "a": [1, true, "three"]\n}'
    assert formatter.format_body('{"a": true}', 'application/x-www-form-urlencoded') == '{\n  "a": true\n}'

# Generated at 2022-06-23 19:30:19.304015
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(json={'format': False})
    assert json_formatter.format_body(
        body='{"a": 1}',
        mime='json',
    ) == '{"a": 1}'
    assert json_formatter.format_body(
        body='{"a": 1}',
        mime='javascript',
    ) == '{"a": 1}'
    assert json_formatter.format_body(
        body='{"a": 1}',
        mime='text',
    ) == '{"a": 1}'

    formatter = JSONFormatter(json={'format': True})
    assert formatter.format_body(
        body='{"a": 1}',
        mime='application/vnd.api+json',
    ) == '{"a": 1}'


# Generated at 2022-06-23 19:30:25.242319
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Ensure we can pass a test to format json as well as
    the httpie verbose mode.
    """
    plugin = JSONFormatter(format_options={
        'json': {
            'sort_keys': True,
            'indent': 2
        }
    },
        kwargs={'explicit_json': True}
    )

    respons_body = """
    {
      "id": 1,
      "name": "A green door",
      "price": 12.50,
      "tags": ["home", "green"]
    }
    """

    formatted_body = plugin.format_body(respons_body, 'json')


# Generated at 2022-06-23 19:30:29.380221
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == True
    assert json_formatter.kwargs == {}
    assert json_formatter.format_options == {'json': {'format': True, 'indent': 4, 'sort_keys': True}}

# Generated at 2022-06-23 19:30:30.333748
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter is not None


# Generated at 2022-06-23 19:30:34.913826
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['format'] == True
    assert json_formatter.format_options['json']['indent'] == '  '
    assert json_formatter.format_options['json']['sort_keys'] == False


# Generated at 2022-06-23 19:30:41.546800
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import platform

    format_options = {
        'json': {
            'format': False,
            'indent': 4,
            'sort_keys': True,
        },
        'colors': {
            'args': {'fg': 'green'},
            'data': {'fg': 'green'},
            'error': {'fg': 'red'},
            'headers': {'fg': 'green', 'bold': True},
            'info': {'fg': 'green'},
        },
        'colors_enabled': platform.python_version_tuple() >= ('3', '0', '0'),
        'verbose': False,
    }

    assert JSONFormatter(format_options=format_options, explicit_json=True)


# Generated at 2022-06-23 19:30:46.720007
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'application/json'
    assert JSONFormatter().format_body(
        '{"foo": "bar"}', mime
    ) == '{\n    "foo": "bar"\n}'
    assert JSONFormatter().format_body(
        '{"foo": "bar", "bar": "baz"}', mime
    ) == '{\n    "bar": "baz",\n    "foo": "bar"\n}'

# Generated at 2022-06-23 19:30:56.869156
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with content type as application/json
    formatter = JSONFormatter(explicit_json=None, json_options=None)
    body = formatter.format_body(
                body='{"a":"a1", "b":"b1", "c":"c1"}', 
                mime='application/json'
            )
    assert body == ('{\n'
                    '    "a": "a1",\n'
                    '    "b": "b1",\n'
                    '    "c": "c1"\n'
                    '}')

    # Test with content type as text/json
    formatter = JSONFormatter(explicit_json=None, json_options=None)

# Generated at 2022-06-23 19:30:58.115874
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter1 = JSONFormatter()
    assert isinstance(JSONFormatter1, JSONFormatter)

# Generated at 2022-06-23 19:30:59.727324
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = JSONFormatter()
    assert fp.format_options == {'json': {'format': True, 'indent': None, 'sort_keys': False}}


# Generated at 2022-06-23 19:31:04.180045
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    import os
    os.chdir(os.path.dirname(__file__))
    # Load the json file
    with open('test_json.json', 'r') as f:
        content = json.load(f)
    # Convert it to a string
    content = json.dumps(content, indent=2)
    # Create the JSONFormatter object
    j_f = JSONFormatter()
    # Call the method format_body with the string containing the json content
    # as first argument and the mimetype 'json' as second argument
    formatted_response = j_f.format_body(content, 'json')
    # Check if the result is the same as the initial string
    assert(formatted_response == content)

# Generated at 2022-06-23 19:31:14.619117
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    assert json_formatter.format_body('{ "a": 1 }', 'json') == '{\n  "a": 1\n}'
    assert json_formatter.format_body('{ "a": 1 }', 'application/json') == '{\n  "a": 1\n}'
    assert json_formatter.format_body('{ "a": 1 }', 'application/json; charset=utf-8') == '{\n  "a": 1\n}'

# Generated at 2022-06-23 19:31:17.347377
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] is True
    assert formatter.format_options['json']['indent'] is 4
    assert formatter.format_options['json']['sort_keys'] is True

# Generated at 2022-06-23 19:31:22.015453
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled
    assert json_formatter.kwargs == {'explicit_json': False}
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys']


# Generated at 2022-06-23 19:31:32.137142
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})

    # Tests with invalid JSONs
    assert json_formatter.format_body('{}', 'json') == '{}'
    assert json_formatter.format_body('{}', 'json') != '{\n  \n}'
    assert json_formatter.format_body('{}', 'json') != '{\n  \n}'
    assert json_formatter.format_body('{a: "123456789"}', 'json') == '{a: "123456789"}'

# Generated at 2022-06-23 19:31:41.034776
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.input import ParseResult
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth


# Generated at 2022-06-23 19:31:45.531264
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'application/json'
    body = '{"type":"person","number":1,"phone":"555-1234"}'
    expected_body = '{\n    "number": 1,\n    "phone": "555-1234",\n    "type": "person"\n}'
    jf = JSONFormatter(format_options={'json': {'indent': 4, 'sort_keys': True}})
    assert jf.format_body(body, mime) == expected_body

# Generated at 2022-06-23 19:31:46.515469
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # TODO: Add tests
    pass

# Generated at 2022-06-23 19:31:53.315163
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Simple indented JSON format
    f = JSONFormatter(format_options = {
        'json' : {
            'format' : True,
            'sort_keys' : True,
            'indent' : 4
        }
    })
    data = f.format_body(
        '{"key1":"value1", "key2":"value2"}',
        'application/json'
    )

    assert '\n' in data
    assert data.startswith('{\n')
    assert data.endswith('\n}')
    assert '    "key1" : "value1",\n    "key2" : "value2"\n' in data

    # JSON format with keys in reverse order

# Generated at 2022-06-23 19:32:02.409714
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_file = open("test_json_formatter.txt", "w")
    test_file.write("{'a': 1, 'b': 2, 'c': 3}")
    test_file.close()
    test_file = open("test_json_formatter.txt", "r")
    assert test_file.read() == "{'a': 1, 'b': 2, 'c': 3}"
    test_file.close()
    # Test formatting of the JSON body
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'indent': 3,
                'sort_keys': True,
                'format': True
            }
        },
        explicit_json=False
    )

# Generated at 2022-06-23 19:32:11.075490
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    json_formatter1 = JSONFormatter(
            format_options = {
                'json':{
                    'format':True,
                    'indent':3,
                    'sort_keys':True,
                },
            },
            explicit_json = False,
        )
    body1 = '{"a": 2, "b": 1}'
    mime1 = 'application/json'
    expected1 = '{\n   "a": 2,\n   "b": 1\n}'
    assert json_formatter1.format_body(body1, mime1)==expected1

    # Test case 2

# Generated at 2022-06-23 19:32:13.302868
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert (JSONFormatter(format_options={'json': {'format': True, 'indent': 4,
                                                   'sort_keys': False}})
            is not None)

# Generated at 2022-06-23 19:32:18.233074
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters import Formatter
    assert isinstance(FormatterPlugin, type)
    assert isinstance(Formatter, type)
    # Fixture
    def set_format_option(format):
        options = {
            'json': {
                'indent': 2,
                'sort_keys': True,
                'format': True,
            },
            'colors': {
                'header': None,
                'match': 'red',
                'body': None
            },
            'style': {
                'match': 'bold',
                'header': None,
                'body': None
            },
            'print_body_limit': None
        }

# Generated at 2022-06-23 19:32:23.900289
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    json_string = '{"a": 1, "b":2, "c":3}'
    body = formatter.format_body(json_string, 'json')
    assert body == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-23 19:32:28.934016
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter({'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    json_data = '''
    {
        "numbers": [
            1,
            2,
            3,
            4
        ],
        "letter": "A",
        "id": 5,
        "some_boolean": true
    }'''
    assert f.format_body(json_data, 'json') == '''
    {
        "id": 5,
        "letter": "A",
        "numbers": [
            1,
            2,
            3,
            4
        ],
        "some_boolean": true
    }'''

# Generated at 2022-06-23 19:32:39.794786
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    """
    Unit test for the constructor of the class JSONFormatter
    """
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class TestJSONFormatter(unittest.TestCase):
        """
        This class tests the JSONFormatter constructor.
        """
        def test_Plugin_extends_object(self):
            """
            Test if JSONFormatter extends object
            """
            self.assertTrue(issubclass(JSONFormatter, object))

        def test_Plugin_extends_FormatterPlugin(self):
            """
            Test if JSONFormatter extends FormatterPlugin
            """
            self.assertTrue(issubclass(JSONFormatter, FormatterPlugin))


# Generated at 2022-06-23 19:32:46.956952
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.explicit_json == False


# Generated at 2022-06-23 19:32:48.216405
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.enabled == True

# Generated at 2022-06-23 19:32:50.885244
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    formatter = JSONFormatter(explicit_json=False, format_options={"json": {"format": True, "sort_keys": False, "indent": 2}})
    assert formatter != None


# Generated at 2022-06-23 19:32:54.412448
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={'json': {'format': True, 'sort_keys': False, 'indent': 5}},
        explicit_json=True,
        implicit_json=True,
        style=None,
        color_scheme=None,
    )
    assert json_formatter.enabled


# Unit tests for format_body

# Generated at 2022-06-23 19:33:03.246043
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_format_options = {'params': {}, 'json': {'format': True, 'sort_keys': False, 'indent': 4}}
    test_kwargs = {'style': None, 'colors': 256, 'style_dict': {}, 'implicit_json': False, 'explicit_json': False}
    test_formatter_plugin = FormatterPlugin(format_options=test_format_options, **test_kwargs)
    test_json_formatter = JSONFormatter(format_options=test_format_options, **test_kwargs)
    assert test_formatter_plugin.format_options['json']['format'] == test_json_formatter.format_options['json']['format']
    assert test_formatter_plugin.format_options['json']['sort_keys'] == test_json

# Generated at 2022-06-23 19:33:13.247706
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'indent': 1,
                'sort_keys': True
            }
        },
        explicit_json = False
    )
    # Check if the extension of the class is 'json'
    assert json_formatter.extension == 'json'
    # Check if the enabled field is True
    assert json_formatter.enabled is True
    # Check if the proper format_options is saved
    assert json_formatter.format_options == {
            'json': {
                'format': True,
                'indent': 1,
                'sort_keys': True
            }
        }
    # Check if the explicit_json field is set to False

# Generated at 2022-06-23 19:33:19.263874
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter(): 
    tmp = JSONFormatter(format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert tmp.enabled == True
    assert tmp.kwargs == {}
    assert tmp.format_options['json']['indent'] == 4
    assert tmp.format_options['json']['sort_keys'] == True


# Generated at 2022-06-23 19:33:22.282188
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonformatter = JSONFormatter()
    print(jsonformatter.format_body('{"name": "Json"}', 'json'))

# Generated at 2022-06-23 19:33:28.214822
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie

    body = "{\"json\":\"format\"}"
    mime = "json"
    jsonFormatter = httpie.JSONFormatter()
    actual = jsonFormatter.format_body(body, mime)
    expect = '''{\n    "json": "format"\n}'''
    assert actual == expect
    body = "{\"json\":\"format\"}"
    mime = "text"
    jsonFormatter = httpie.JSONFormatter()
    actual = jsonFormatter.format_body(body, mime)
    expect = '''{\n    "json": "format"\n}'''
    assert actual == expect
    body = "{\"json\":\"format\"}"
    mime = "text"
    jsonFormatter = httpie.JSONFormatter(explicit_json=True)
    actual

# Generated at 2022-06-23 19:33:31.447796
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}}).format_body('{    "a":1}', 'json') == '{\n  "a": 1\n}'



# Generated at 2022-06-23 19:33:34.205139
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter('explicit_json=false, json.format=false')
    assert json_formatter.enabled == False

# Generated at 2022-06-23 19:33:36.808286
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    plugin = FormatterPlugin()
    # test it is an instance of FormatterPlugin
    assert isinstance(plugin, FormatterPlugin)


# Generated at 2022-06-23 19:33:40.404713
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # simple case
    assert JSONFormatter({'json': {'format': True}})
    # complex case
    assert JSONFormatter({
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 4
        }
    })


# Generated at 2022-06-23 19:33:41.835166
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter({'sort_keys':'True','indent':'True'})


# Generated at 2022-06-23 19:33:46.039176
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert "{'a': 1, 'b': 2, 'c': 3}" == formatter.format_body(
        body='{"a":1,"b":2,"c":3}',
        mime='application/json')
    assert '{"a":1,"b":2,"c":3}' == formatter.format_body(
        body='{"a":1,"b":2,"c":3}',
        mime='text/plain')

# Generated at 2022-06-23 19:33:54.984923
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    }, explicit_json=False)
    # Returns a JSON string
    assert formatter.format_body('{"a":"b"}', 'json') == \
           '{\n    "a": "b"\n}'
    # Returns a JSON string
    assert formatter.format_body('{"a":"b"}', 'javascript') == \
           '{\n    "a": "b"\n}'
    # Returns a JSON string
    assert formatter.format_body('{"a":"b"}', 'text') == \
           '{\n    "a": "b"\n}'
    # Returns an error message

# Generated at 2022-06-23 19:34:02.227827
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from os import path
    from pytest import fixture
    from httpie.cli import parser

    json_formatter = JSONFormatter(cli_args=parser.parse_args([]),
                                    format_options={"json": {"format": True,
                                                             "indent": 2,
                                                             "sort_keys": False}},
                                    explicit_json=True)

    @fixture
    def json_body():
        dirname = path.dirname(__file__)
        filename = path.join(dirname, 'json_body.json')
        with open(filename) as file:
            return file.read()

    assert json_formatter.format_body(json_body(), 'json') != json_body()
    assert json_formatter.format_body(json_body(), 'text') != json_

# Generated at 2022-06-23 19:34:10.835563
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    test_body = '{"key": "value"}'
    test_mime = 'json'
    expected = '{\n    "key": "value"\n}'
    actual = JSONFormatter().format_body(test_body, test_mime)
    assert actual == expected

    # Test case 2:
    test_body = '{"key": "value"}}'
    test_mime = 'json'
    expected = '{"key": "value"}}'
    actual = JSONFormatter().format_body(test_body, test_mime)
    assert actual == expected

    # Test case 3:
    test_body = '{"key": "value"}'
    test_mime = 'javascript'
    expected = '{\n    "key": "value"\n}'
    actual

# Generated at 2022-06-23 19:34:22.096804
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test: Invalid JSON, ignore
    assert body_invalid_json() == body_invalid_json()
    # Test: Explicit json
    assert body_explicit_json() == body_explicit_json()
    # Test: not explicit json
    assert body_not_explicit_json() == body_not_explicit_json()

body_invalid_json = lambda: json.dumps(
    obj={'key': 'value'},
    sort_keys=True,
    ensure_ascii=False,
    indent=2
) + 'invalid'

body_explicit_json = lambda: json.dumps(
    obj={'key': 'value'},
    sort_keys=True,
    ensure_ascii=False,
    indent=2
)

body_not_explicit_

# Generated at 2022-06-23 19:34:26.957536
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1:
    # Input:
    data = {"a":1}
    # Output:
    exp_res = '{\n  "a": 1\n}'
    # Test 2:
    # Input:
    # Output:
    # Test 3:
    # Input:
    # Output:

# Generated at 2022-06-23 19:34:27.606230
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass

# Generated at 2022-06-23 19:34:29.029630
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter


# Generated at 2022-06-23 19:34:40.167270
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter=JSONFormatter()
    # 1. json file
    with open('test_case_1.json') as f:
        body=f.read()

# Generated at 2022-06-23 19:34:47.159936
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.input
    import httpie.plugins.builtin.formatter
    httpie.plugins.builtin.formatter
    json_formatter = httpie.plugins.builtin.formatter.JSONFormatter()
    assert(json_formatter.format_body(
        '[{"A": "B", "C": {"D": "E"}}]',
        'application/json'
    ) == '''[
    {
        "A": "B",
        "C": {
            "D": "E"
        }
    }
]''')

# Generated at 2022-06-23 19:34:53.720571
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": "b"}'
    json_formatter = JSONFormatter()
    
    # Test for a valid JSON body
    mime = 'json'
    result = json_formatter.format_body(body, mime)
    assert result == body

    # Test for an invalid JSON body
    body = "abc"
    result = json_formatter.format_body(body, mime)
    assert result == body

    # Test for a valid JSON body and an invalid mime type
    body = '{"a": "b"}'
    mime = 'text'
    result = json_formatter.format_body(body, mime)
    assert result == body

    # Test for an invalid JSON body and an invalid mime type
    body = 'abc'
    mime = 'text'
    result = json

# Generated at 2022-06-23 19:35:04.291275
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    body_content = '{"Key1": "value1", "Key2": "value2"}'
    json_formatter = JSONFormatter(False, {})
    assert json_formatter.enabled == False
    assert json_formatter.format_body(body_content, 'json') == body_content
    json_formatter = JSONFormatter(True,
                                   {'json': {'format': True,
                                             'sort_keys': True,
                                             'indent': 4}})
    assert json_formatter.enabled == True
    body = json_formatter.format_body(body_content, 'json')
    assert body == '{\n    "Key1": "value1", \n    "Key2": "value2"\n}'

# Generated at 2022-06-23 19:35:08.026337
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{'name': 'John', 'age': 30}"
    body_after_format = '{\n  "age": 30, \n  "name": "John"\n}'
    json_format = JSONFormatter()
    assert json_format.format_body(body, '') == body_after_format

# Generated at 2022-06-23 19:35:09.088993
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=False)

    assert formatter.enabled == False

# Generated at 2022-06-23 19:35:11.766053
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.cli import parser
    format_options = parser.get_default_parser().format_options
    formatter = JSONFormatter(format_options=format_options, explicit_json=True, pretty=True)
    assert(formatter != None)


# Generated at 2022-06-23 19:35:22.847525
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False,
        }
    })

    test_body = '''
    {
    "default_profile": true,
    "_id": "54e7aabe4444444444444444",
    "username": "user1",
    "name": "K. Tsakmakis",
    "created": "2015-02-24T18:39:34.916Z",
    "__v": 0,
    "status": "active",
    "roles": [
        "user"
    ],
    "email": "user1@example.com"
    }
    '''

# Generated at 2022-06-23 19:35:29.058756
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }
    })

    body = '''
    {
      "test1": 1,
      "test2": 2
    }
    '''
    mime = 'json'
    exp = '''
    {
      "test1": 1,
      "test2": 2
    }
    '''
    res = formatter.format_body(body, mime)
    assert res == exp

# Generated at 2022-06-23 19:35:39.191405
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin

    class JSONFormatter(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['json']['format']

        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                    or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass  # Invalid JSON, ignore.

# Generated at 2022-06-23 19:35:42.851299
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert len({JSONFormatter({'json': {'format': True}}).type, JSONFormatter({'json': {'format': False}}).type}) == 1

# Tests for function format_body

# Generated at 2022-06-23 19:35:47.174498
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    c = JSONFormatter(**{'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': False}}})
    response = c.format_body(body=b'{"a": 1, "b": "2"}', mime='')
    assert response == '{\n    "a": 1,\n    "b": "2"\n}'



# Generated at 2022-06-23 19:35:58.430833
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(
        ignore_stdin=False,  # Defaults to False, True for test purposes
        default_options={
            'output_options': {},
            'style_options': {},
            'style': 'solarized-dark',
            'default_options': {
                'output_options': {
                    'stream': False
                },
                'formats': {
                    'colors': False,
                    'json': {
                        'format': False
                    }
                },
                'style': 'solarized-light'
            },
            'formats': {
                'colors': True,
                'json': {
                    'format': True
                }
            },
        }
    )
    assert f.enabled is True

# Generated at 2022-06-23 19:36:00.549622
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.kwargs == {}
    assert not formatter.enabled


# Generated at 2022-06-23 19:36:06.959117
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=False,
                              format_options={'json': {'format': False, 'indent': 0, 'sort_keys': False}})
    assert formatter.kwargs == {'explicit_json': False}
    assert formatter.format_options == {'json': {'format': False, 'indent': 0, 'sort_keys': False}}
    assert isinstance(formatter, FormatterPlugin)


# Generated at 2022-06-23 19:36:14.337917
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    i = JSONFormatter(content_type='json',
                      format_options={'json':
                                      {'format': True,
                                       'sort_keys': True,
                                       'indent': 4}},
                      explicit_json=True)
    assert i.kwargs['explicit_json'] == True
    assert i.kwargs['content_type'] == 'json'
    assert i.format_options['json']['format'] == True
    assert i.format_options['json']['sort_keys'] == True
    assert i.format_options['json']['indent'] == 4
    assert i.enabled == True


# Generated at 2022-06-23 19:36:20.681109
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Positive test case
    test1 = {
        'format': 'json',
        'indent': 4,
        'sort_keys': False
    }
    kwargs1 = {
        'explicit_json': False,
        'formatted': False,
        'format_options': {
            'json': test1
        }
    }
    j1 = JSONFormatter(**kwargs1)
    assert isinstance(j1, JSONFormatter)

    # Negative test case
    # Same as above, but with a wrong option for format_options
    kwargs2 = {
        'explicit_json': False,
        'formatted': False,
        'format_options': {
            'test': test1
        }
    }
    j2 = JSONFormatter(**kwargs2)

# Generated at 2022-06-23 19:36:22.136590
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter() != None

# Generated at 2022-06-23 19:36:23.777591
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter

# Generated at 2022-06-23 19:36:24.644409
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert isinstance(JSONFormatter(format_options = {}), JSONFormatter)

# Generated at 2022-06-23 19:36:34.359103
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    tform = JSONFormatter
    assert tform.format_body('{"key": "value"}', 'json') == \
        '{\n    "key": "value"\n}'
    assert tform.format_body('{"key": "value"}', 'javascript') == \
        '{\n    "key": "value"\n}'
    assert tform.format_body('{"key": "value"}', 'text') == \
        '{\n    "key": "value"\n}'
    assert tform.format_body('{"key": "value"}', 'xml') == \
        '{"key": "value"}'
    assert tform.format_body('<key>value</key>', 'xml') == '<key>value</key>'

# Generated at 2022-06-23 19:36:35.309062
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert(JSONFormatter())

# Generated at 2022-06-23 19:36:41.946784
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # case1:  test for invalid json
    json_formatter = JSONFormatter()
    body = 'invlid-json'
    mime = 'json'
    output = 'invlid-json'
    assert json_formatter.format_body(body, mime) == output

    # case2: test for valid json
    body = '{"key1":"value1"}'
    mime = 'json'
    output = '{\n    "key1": "value1"\n}'
    assert json_formatter.format_body(body, mime) == output

# Generated at 2022-06-23 19:36:47.786366
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter is not None
    x = JSONFormatter(**{'json': {'indent': 2, 'sort_keys': True, 'format': True}, 'explicit_json': True})
    assert x.format_options == {'json': {'indent': 2, 'sort_keys': True, 'format': True}}
    assert x.kwargs == {'explicit_json': True}
    assert x.enabled == True


# Generated at 2022-06-23 19:36:51.582275
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()
    assert formatter_plugin.enabled

# Generated at 2022-06-23 19:36:56.089945
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"c":"d"}'
    test_obj = JSONFormatter(kwargs = {'explicit_json': True}, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert test_obj.format_body(body, 'json') == '{\n  "c": "d"\n}'

# Generated at 2022-06-23 19:37:01.266490
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__init__(
        JSONFormatter,
        format_options={
            'json': {
                'format': False, 'indent': 2, 'sort_keys': True
            }
        },
        **{'output_file': None}
    )



# Generated at 2022-06-23 19:37:05.907037
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Arrange
    format_options = \
        {"json":
         {"format": True,
          "indent": None,
          "sort_keys": True}
         }
    kwargs = {"explicit_json": False,
              "format_options": format_options}
    expected = True
    # Act
    actual = JSONFormatter(**kwargs)
    # Assert
    assert actual.enabled == expected


# Generated at 2022-06-23 19:37:15.559222
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin_json = JSONFormatter(
        format_options={
            "json":{
                "format": True,
                "sort_keys": True,
                "indent": 4
            }
        }
    )

# Generated at 2022-06-23 19:37:23.044096
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # This formatter does not do any parsing or beautification if the
    # mime type is not json, javascript or text.
    body = '{"test": "body"}'
    mime = 'image'
    formatter = JSONFormatter()
    body_formatted = formatter.format_body(body, mime)
    assert body_formatted == '{"test": "body"}'

    # Any 'json', 'javascript', or 'text' in the mime type will trigger
    # the formatter to beautify the body.
    # 'application/javascript' should trigger the formatter.
    body = '{"test": "body"}'
    mime = 'application/javascript'
    formatter = JSONFormatter()
    body_formatted = formatter.format_body(body, mime)

# Generated at 2022-06-23 19:37:24.078099
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled is False

# Generated at 2022-06-23 19:37:29.467355
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    body_text = json.dumps({"result": "success", "code": 200})
    body_text_expected = json.dumps({"result": "success", "code": 200}, sort_keys=True, ensure_ascii=False, indent=4)
    fp = JSONFormatter(format_options={"json":{"format": True, "indent": 4, "sort_keys": True}})
    body_text_result = fp.format_body(body_text, 'json')
    assert body_text_result == body_text_expected

# Generated at 2022-06-23 19:37:32.357180
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    settings = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4,
        }
    }
    json = JSONFormatter(**settings)
    assert json.enabled == True
    assert json.kwargs == settings


# Generated at 2022-06-23 19:37:37.867920
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.context import Environment
    env = Environment(stdin=None, stdout=None, stderr=None)
    JFor = JSONFormatter(env)
    assert(JFor.format_options["json"]["format"] == True)


# Generated at 2022-06-23 19:37:46.196733
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Create test object
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert(formatter.enabled)
    assert(json.loads(formatter.format_body('{"hello": 1, "hi": 2}', 'application/json')) == {"hello": 1, "hi": 2})
    assert(json.loads(formatter.format_body('[1, 2, 3]', 'application/json')) == [1, 2, 3])

# Generated at 2022-06-23 19:37:52.339331
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4,
        }
    }
    kwargs = {
        'format_options':format_options,
        'explicit_json':True,
    }
    json_formatter = JSONFormatter(**kwargs)
    assert json_formatter.kwargs == kwargs



# Generated at 2022-06-23 19:38:01.368703
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"id": 1, "name": "Foo", "price": 123, "tags": ["Bar","Eek"]}'
    result = json_formatter.format_body(body, 'json')
    assert result == '{\n    "id": 1,\n    "name": "Foo",\n    "price": 123,\n    "tags": [\n        "Bar",\n        "Eek"\n    ]\n}'
    result = json_formatter.format_body(body, 'text')
    assert result == body
    result = json_formatter.format_body(body, 'nope')
    assert result == body

# Generated at 2022-06-23 19:38:04.039820
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.enabled

# Generated at 2022-06-23 19:38:05.048001
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert(JSONFormatter)

# Generated at 2022-06-23 19:38:11.375504
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}, kwargs={'explicit_json': False})
    assert json_formatter.format_options['json'] == {'format': True, 'indent': 4, 'sort_keys': True}
    assert json_formatter.kwargs['explicit_json'] == False


# Generated at 2022-06-23 19:38:17.545531
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter({'json': {'format': True, 
                                 'indent': 2, 
                                 'sort_keys': True}},
                      {'explicit_json': False})
    assert jf.format_options == {'json': {'format': True, 
                                          'indent': 2, 
                                          'sort_keys': True}}
    assert jf.kwargs == {'explicit_json': False}


# Generated at 2022-06-23 19:38:20.391988
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == False
    assert json_formatter.kwargs == {}
    assert json_formatter.format_options == {}

# Generated at 2022-06-23 19:38:25.868785
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter({'json': {'format': True, 'sort_keys': True, 'indent': 2}}, False)
    assert json_formatter.format_options == {'json': {'format': True, 'sort_keys': True, 'indent': 2}}
    assert json_formatter.kwargs == {'explicit_json': False}


# Generated at 2022-06-23 19:38:36.699810
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    args = {
        'json': {'indent': 4, 'sort_keys': True, 'format': True},
        'explicit_json': False
    }
    json_formatter = JSONFormatter(**args)
    # JSON Formatter - valid JSON
    assert json_formatter.format_body("{'test': 'test'}", 'json') == \
        '{\n    "test": "test"\n}'
    # JSON Formatter - invalid JSON
    assert json_formatter.format_body("This is not JSON", 'json') == \
        'This is not JSON'
    # JSON Formatter - JSON with lots of white spaces

# Generated at 2022-06-23 19:38:39.181332
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert json.enabled == True

# Generated at 2022-06-23 19:38:40.784903
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == True

# Generated at 2022-06-23 19:38:42.184425
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'indent': 2}})



# Generated at 2022-06-23 19:38:44.713670
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    p = JSONFormatter(format_options=dict(json=dict(format=0)))
    assert p.format_options['json']['format'] == 0
    assert p.kwargs == dict()
    assert p.enabled == 0



# Generated at 2022-06-23 19:38:56.769685
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Body is JSON with mime type 'application/json'
    json_formatter = JSONFormatter()
    body_json_mime_json = json_formatter.format_body(
        '{"id": 1, "first_name":"John" , "last_name":"Doe"}',
        'application/json'
    )
    assert body_json_mime_json == '{\n    "first_name": "John",\n    "id": 1,\n    "last_name": "Doe"\n}'

    # Body is not JSON with mime type 'application/json'
    json_formatter = JSONFormatter()

# Generated at 2022-06-23 19:38:58.228389
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    print(formatter.kwargs)
    print(formatter.format_options)

# Generated at 2022-06-23 19:39:06.081035
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(**{'format_options': {'json': {'indent': 4, 'format': True, 'sort_keys': False}}})

# Generated at 2022-06-23 19:39:09.830319
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    json_formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert json_formatter.enabled == True


# Generated at 2022-06-23 19:39:12.362105
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '[{"id": 1, "name": "alice"}, {"id": 2, "name": "bob"}]'
    mime = 'application/json'
    assert JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 0,
        }
    }).format_body(body, mime) == body

# Generated at 2022-06-23 19:39:21.427816
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}})
    assert (formatter.format_body('{"Foo": "Bar", "Baz": "Taz"}', 'application/json')
            == '{\n    "Foo": "Bar",\n    "Baz": "Taz"\n}')
    assert (formatter.format_body('{"Foo": "Bar", "Baz": "Taz"}', 'text/javascript')
            == '{\n    "Foo": "Bar",\n    "Baz": "Taz"\n}')

# Generated at 2022-06-23 19:39:22.940381
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-23 19:39:24.163300
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert isinstance(JSONFormatter(None, None), JSONFormatter)


# Generated at 2022-06-23 19:39:33.579252
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 3
            }
        },
        explicit_json=True,
        json_indent=3
    )
    assert json_formatter.enabled == True
    assert json_formatter.kwargs['explicit_json'] == True
    assert json_formatter.kwargs['json_indent'] == 3
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-23 19:39:34.915765
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert type(JSONFormatter) == type(FormatterPlugin)


# Generated at 2022-06-23 19:39:42.367737
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
	kwargs = {
		'explicit_json': False
	}
	format_options = {
		'json': {
			'format': True,
			'sort_keys': False,
			'indent': 4
		}
	}
	formatter = JSONFormatter(kwargs=kwargs, format_options=format_options,
							  stream=None)
							  
	def test_1(body, mime):
		assert formatter.format_body(body=body, mime=mime) == body

	def test_2(body, mime):
		assert formatter.format_body(body=body, mime=mime) == body


# Generated at 2022-06-23 19:39:43.927525
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Create a JSONFormatter
    jsonFormatter = JSONFormatter()
    # Test if it is disabled by default
    assert not jsonFormatter.enabled


# Generated at 2022-06-23 19:39:46.448531
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(**{
        'format_options': {
            'json': {
                'format': True
            }
        }
    })
    assert formatter.enabled

# Generated at 2022-06-23 19:39:49.501920
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }},
        explicit_json=False
    )
    assert formatter.enabled

    assert formatter.kwargs['explicit_json'] == False
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True
