

# Generated at 2022-06-23 19:29:54.524025
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True}}).enabled == True
    assert JSONFormatter(format_options={'json': {'format': False}}).enabled == False

# Generated at 2022-06-23 19:30:02.070975
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 0
            }
        },
        explicit_json=True
    )

    assert formatter.enabled is True
    assert formatter.kwargs['explicit_json'] is True
    assert formatter.kwargs['format_options'] == {
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 0
        }
    }


# Generated at 2022-06-23 19:30:04.948781
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{}', 'text/json') == '{}'

# Generated at 2022-06-23 19:30:12.869269
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie import __version__ as httpie_version
    from httpie.plugins import FormatterPlugin
    from httpie import ExitStatus

    json_format = {
        'format': True,
        'indent': 4,
        'sort_keys': True,
    }

    json_type = {
        'JSON': 'application/json',
        'raw': '',
        'urlencoded': 'application/x-www-form-urlencoded',
    }

    headers = {}

    # Invalid
    print('[test_JSONFormatter] Invalid: ')
    print('\t' + '-' * 10)

# Generated at 2022-06-23 19:30:17.884234
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options = {
            "json": {
                "format": True,
                "indent": 2,
                "sort_keys": True,
            },
            "colors": {
                "method": "green",
                "request_header": "cyan",
                "response_header": "blue",
                "status": "white",
                "title": "white",
                "error": "red",
            },
        },
    )
    json_body = '{"Person": {"name": "Vasya", "age": 18}}'
    text_body = 'no json'

# Generated at 2022-06-23 19:30:18.458428
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter() is not None


# Generated at 2022-06-23 19:30:21.301879
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"json" : "value"}', 'json') == '{\n    "json": "value"\n}'  # sorted and indented

# Generated at 2022-06-23 19:30:31.293837
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    })
    body = '{ "a": "b", "c": [1, 2, 3] }'
    assert formatter.format_body(body, 'json') == ('{\n'
                                                   '    "a": "b",\n'
                                                   '    "c": [\n'
                                                   '        1,\n'
                                                   '        2,\n'
                                                   '        3\n'
                                                   '    ]\n'
                                                   '}')

# Generated at 2022-06-23 19:30:39.298164
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    f = JSONFormatter()

    # The JSONFormatter class is a subclass of FormatterPlugin
    assert isinstance(f, FormatterPlugin)
    assert isinstance(f, JSONFormatter)

    # The body should be unchanged if it is empty or if mime is None
    assert f.format_body('', mime=None) == ''
    assert f.format_body('', mime='') == ''
    assert f.format_body('', mime='junk') == ''

    # The body should be unchanged if it is not valid json
    assert f.format_body('{', mime='json') == '{'

# Generated at 2022-06-23 19:30:43.391443
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    # Test default value of self.format_options
    assert formatter.format_options == {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        },
    }

# Generated at 2022-06-23 19:30:44.678620
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert hasattr(JSONFormatter, "__init__")


# Generated at 2022-06-23 19:30:52.286624
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    import pytest

    from httpie.plugins import JSONFormatter

    json_formatter = JSONFormatter(
        format_options = {}
    )
    json_formatter.format_options.update(
        {
            "json":
                {
                    "format": True,
                    "indent": None,
                    "sort_keys": False,
                }
        }
    )
    json_formatter.kwargs = {}
    json_formatter.kwargs["explicit_json"] = False

    assert json_formatter.format_body(
        body="{\"test\": \"test\"}",
        mime="application/json"
    ) == "{\"test\": \"test\"}"

    assert json_formatter.kwargs["explicit_json"] == True

# Generated at 2022-06-23 19:31:00.724898
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    input_value = b'{"foo": "bar"}'
    output_value_pretty = b'{\n    "foo": "bar"\n}'
    output_value_ugly = b'{"foo":"bar"}'
    json_formatter = JSONFormatter({'explicit_json': False}, {'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    json_formatter2 = JSONFormatter({'explicit_json': False}, {'json': {'format': True, 'indent': 0, 'sort_keys': True}})
    assert len(input_value) == len(json_formatter.format_body(input_value, 'application/json'))

# Generated at 2022-06-23 19:31:02.602083
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    assert f.format_options['json']['format'] != True

# Generated at 2022-06-23 19:31:04.638408
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter == JSONFormatter(False, False, None, None,
                                          False, False, False, None)


# Generated at 2022-06-23 19:31:15.029252
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print(JSONFormatter.__module__)

    import sys
    if 'httpie.plugins.JSONFormatter' not in sys.modules:
        import plugins
        sys.modules['httpie.plugins.JSONFormatter'] = plugins

    import httpie
    httpie.plugins.JSONFormatter.json = {'format': True}

    from httpie.plugins import JSONFormatter
    json_formatter = JSONFormatter()

    # JSONFormatter.format_body
    assert json_formatter.format_body('{ "foo": "bar" }', 'application/json') == '{\n  "foo": "bar"\n}'
    assert json_formatter.format_body('{ "foo": "bar" }', 'text/html') == '{ "foo": "bar" }'
    assert json_formatter.format_

# Generated at 2022-06-23 19:31:16.117260
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter != None

# Generated at 2022-06-23 19:31:23.635975
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{
        'format_options': {
            'json': {'sort_keys':True, 'indent':2, 'format':True}
        },
        'explicit_json':False,
    })
    assert json_formatter.format_body(body='{}', mime='json') == '{}'
    assert json_formatter.format_body(body='{}', mime='javascript') == '{}'
    assert json_formatter.format_body(body='{}', mime='text') == '{}'
    assert json_formatter.format_body(body='[]', mime='json') == '[]'
    assert json_formatter.format_body(body='[]', mime='javascript') == '[]'

# Generated at 2022-06-23 19:31:33.328486
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    settings = {
        'json': {
            'format': False,
            'sort_keys': True,
            'indent': 2
        },
        'colors': {
            'request': 'none',
            'response': 'none',
        },
        'headers': {
            'request': True,
            'response': True,
        },
    }
    format_options = settings['json']
    formatter = JSONFormatter(format_options=format_options)

    # Test when invalid JSON
    body = '{"name": "Aaron", "age": 18'
    mime = 'json'
    expected = '{"name": "Aaron", "age": 18'
    actual = formatter.format_body(body, mime)
    assert actual == expected

    # Test when valid JSON

# Generated at 2022-06-23 19:31:34.492551
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    instance = JSONFormatter()
    assert isinstance(instance, FormatterPlugin)

# Generated at 2022-06-23 19:31:43.322080
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    import pytest
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from tests.fixtures import URL, BIN_FILE_PATH, BIN_FILE_CONTENT, JSON_FILE

    ################################################################################
    #
    # Test format_body in JSONFormatter class,
    # when content is:
    # - [JSON]
    #
    ################################################################################
    body = {'param': 'value', 'param2': 'value2'}
    body_str = json.dumps(obj=body, ensure_ascii=True)

    #
    # Test content=[JSON]
    #

# Generated at 2022-06-23 19:31:52.331080
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.compat import BytesIO

    body = '{"foo": "bar"}'
    mime = 'application/json'

    plugin = JSONFormatter(kwargs={'explicit_json': True},
                           format_options={'json': {'format': True,
                                                    'indent': 4,
                                                    'sort_keys': True}})
    plugin.output = BytesIO()
    plugin.stdin = BytesIO(body.encode('utf8'))
    plugin.output_options = {'stdout': False}
    plugin.format_body(body, mime)

    expected = '{\n    "foo": "bar"\n}'

    assert plugin.output.getvalue().decode('utf8') == expected

# Generated at 2022-06-23 19:31:58.726077
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json':{'indent':2}})
    assert formatter.format_body('{"a":1, "b":{"c":2, "d":{"x":null}}}', 'application/json') == '{\n  "a": 1,\n  "b": {\n    "c": 2,\n    "d": {\n      "x": null\n    }\n  }\n}'

# Generated at 2022-06-23 19:32:04.098807
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    params = {"json": {"format": True, "sort_keys": True, "indent": None},
              "explicit_json": True}

    test = JSONFormatter(**params)
    assert test.enabled == True

# Unit tests for method format_body of class JSONFormatter
# Format a valid json; produce one-line json

# Generated at 2022-06-23 19:32:06.066400
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	test = {
		"json": {
			"format": True,
			"indent": 4,
			"sort_keys": True
		}
	}
	assert JSONFormatter(format_options=test, explicit_json=False)


# Generated at 2022-06-23 19:32:09.992989
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    sut = JSONFormatter(**{'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert sut.enabled == True
    assert sut.format_options == {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    assert sut.kwargs == {}


# Generated at 2022-06-23 19:32:12.476197
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.kwargs['explicit_json'] == False
    assert jsonFormatter.format_options['json']['format'] == False
    assert jsonFormatter.format_options['json']['indent'] == None
    assert jsonFormatter.format_options['json']['sort_keys'] == False


# Generated at 2022-06-23 19:32:23.443696
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(
        body='{"a": 1, "b": 2}',
        mime='application/json'
    ) == '{"a": 1, "b": 2}'
    assert formatter.format_body(
        body='{"a": 1, "b": 2}',
        mime='application/javascript'
    ) == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(
        body='{"a": 1, "b": 2}',
        mime='text/json'
    ) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-23 19:32:24.203025
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert FormatterPlugin, object
    assert JSONFormatter, object


# Generated at 2022-06-23 19:32:29.709633
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # With JSON content-type and valid JSON body.
    assert formatter.format_body('{"hello": "world"}',
                                 "application/json"
                                 ) == '{\n    "hello": "world"\n}'
    # Without JSON content-type and valid JSON body.
    assert formatter.format_body('{"hello": "world"}',
                                 "application/octet-stream"
                                 ) == '{"hello": "world"}'
    # With JSON content-type and invalid JSON body.
    assert formatter.format_body('{"hello": "world"}',
                                 "application/json"
                                 ) == '{\n    "hello": "world"\n}'
    # With text content-type and valid JSON body.

# Generated at 2022-06-23 19:32:35.585270
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=True, format_options={"json": {"indent": 4, "format": True, "sort_keys": True}})
    assert formatter.explicit_json is True
    assert format(formatter.format_options) == "{'json': {'indent': 4, 'format': True, 'sort_keys': True}}"


# Generated at 2022-06-23 19:32:43.775876
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # pylint: disable=E0602
    # pylint: disable=E0102
    # pylint: disable=E0108
    # pylint: disable=E0110
    # pylint: disable=E0112
    original_formatter = JSONFormatter.format_body(
        JSONFormatter,
        '{"test": "json"}',
        'json'
    )
    assert original_formatter == '{\n    "test": "json"\n}'

    sort_keys_formatter = JSONFormatter.format_body(
        JSONFormatter,
        '{"test": "json"}',
        'json',
        format_options={
            'json': {
                'sort_keys': True,
                'indent': 0
            }
        }
    )
    assert sort

# Generated at 2022-06-23 19:32:48.299840
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"foo": ["bar", "baz"]}'
    mime = 'application/json'
    body = formatter.format_body(body, mime)
    assert body == '{\n    "foo": [\n        "bar",\n        "baz"\n    ]\n}'

# Generated at 2022-06-23 19:32:48.943896
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()



# Generated at 2022-06-23 19:32:54.097683
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import responses
    import requests
    
    with responses.RequestsMock() as rsps:
        rsps.add(responses.GET, 'https://api.github.com/events',
            body='[{"id": "123456789"}]',
            status=200,
            content_type='application/json',
            adding_headers={'Date': 'Sun, 14 Sep 2014 05:05:46 GMT'})
        r = requests.get('https://api.github.com/events')

        assert r.text == '[{"id": "123456789"}]'

        formatter = JSONFormatter()

        assert formatter.format_body(r.text, r.headers['content-type']) == '[\n  {\n    "id": "123456789"\n  }\n]'

# Generated at 2022-06-23 19:32:59.723052
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    content_type = 'application/json'
    body = '{"user":{"name":"li","age":3}}'
    plugin = JSONFormatter({'json':{'format': True, 'indent': 4, 'sort_keys': True}})
    formated_body = plugin.format_body(body, content_type)
    assert formated_body == '{\n    "user": {\n        "age": 3,\n        "name": "li"\n    }\n}'

# Generated at 2022-06-23 19:33:00.151720
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-23 19:33:02.595277
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    result = formatter.format_body('{"a":1,"b":2,"c":3}', 'json')
    expected = '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    assert result == expected

# Generated at 2022-06-23 19:33:05.448238
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from . import formatters
    assert 'json' in formatters._formatter_plugins
    assert 'json' in formatters._formatter_plugins_by_name
    assert 'json' in formatters._formatter_plugin_names

# Generated at 2022-06-23 19:33:14.032618
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    # Call method format_body of class JSONFormatter with
    # an invalid json body
    json_body = '{"id": 1, "name": "John Doe", "occupation": "gardener"}'
    json_body = json_formatter\
        .format_body(body=json_body, mime='json')
    json_body_expected = '''{
    "id": 1,
    "name": "John Doe",
    "occupation": "gardener"
}'''
    assert json_body == json_body_expected

    # Call method format_body of class JSONFormatter with
    # an invalid json body
    json_body = '{"id": 1, "name": "John Doe", "occupation": "gardener"}'
    json_body = json_form

# Generated at 2022-06-23 19:33:23.600888
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter

# Note: this is an integration test which uses httpie itself to test the
# JSONFormatter plugin. The JSONFormatter plugin is invoked by
# `http --json` or `http http://httpbin.org/json`.
#
# The integration test writes a version of the httpie script with the
# JSONFormatter plugin enabled and then calls the httpie script to
# test the JSONFormatter plugin.
#
# The integration test has been tested on command line and works.
#
# Why is it not a unit test? Because it uses httpie to test httpie.
# (This is a pattern you sometimes see in tests.)
#
# Why not make it into a unit test? Because it is not a good unit test.
# Integration tests are good, but they are slow and they are not


# Generated at 2022-06-23 19:33:33.228575
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_body = '{"a": "b", "c": "d"}'
    assert JSONFormatter(explicit_json=True).format_body(test_body, 'json') == '{\n    "a": "b",\n    "c": "d"\n}'
    assert JSONFormatter(explicit_json=False).format_body(test_body, 'json') == '{\n    "a": "b",\n    "c": "d"\n}'
    assert JSONFormatter(explicit_json=True).format_body(test_body, 'javascript') == '{\n    "a": "b",\n    "c": "d"\n}'

# Generated at 2022-06-23 19:33:35.801460
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = {'json': {'format': True, 'sort_keys': False, 'indent': False}}
    formatter = JSONFormatter(format_options=options)
    assert formatter.format_options == options
    assert formatter.enabled == True
    assert formatter.kwargs == {}


# Generated at 2022-06-23 19:33:43.937205
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Unit test for valid json
    body = '[{"id": 1, "first_name": "Philip", "last_name": "Brown"}]'
    content_type = 'application/json'
    assert(JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 1, 'sort_keys': True}}).format_body(body, content_type) == \
           '[\n {\n  "first_name": "Philip",\n  "id": 1,\n  "last_name": "Brown"\n }\n]')

    # Unit test for invalid json
    body = '{"chiave": "valore"}] {'
    content_type = 'application/json'

# Generated at 2022-06-23 19:33:45.644493
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert isinstance(jsonFormatter, JSONFormatter)

# Generated at 2022-06-23 19:33:49.890803
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body("""{ "a": 1 }""",
                                     'text/json') == """{
    "a": 1
}"""



# Generated at 2022-06-23 19:33:59.769148
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(
        json={
            'format': True,
            'indent': None,
            'sort_keys': False,
        },
        pretty=None,
        colors=None,
        style=None,
        styles=None,
        implicit_sequence=True,
        implicit_map=True,
        treelib_chart=False,
        treelib_max_level=None,
        treelib_truncate=False,
        treelib_width=tuple(),
        kv=False,
        headers=None,
        body=None,
        style_error=None,
        auto_formatted=False,
        css_text=None,
        explicit_json=False,
    )
    assert(f.enabled==True)

# Generated at 2022-06-23 19:34:09.136231
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Unit test: JSONFormatter.format_body

    This unit test tests the format_body method of the JSONFormatter class.
    """
    # Arrange
    # Create an object JSONFormatter with mocked options.
    json_formatter_plugin = JSONFormatter(
        format_options={
            'json': {
                'sort_keys': True,
                'indent': 2
            }
        },
        explicit_json=False,
        colors=False
    )
    # Act
    # Invoke the format_body method of class JSONFormatter with a valid json
    # string and 'application/json'. Because of the mime type of the input
    # string, the method has to format the json string and to return it.

# Generated at 2022-06-23 19:34:15.791551
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{})

    json_format_body_expected_output = (
        '{\n'
        '    "success": true,\n'
        '    "foo": "bar"\n'
        '}'
    )
    json_format_body_output = json_formatter.format_body(
        '{"foo":"bar","success":true}',
        'application/json'
    )
    assert json_format_body_output == json_format_body_expected_output

    json_format_body_expected_output = (
        '{\n'
        '    "foo": "bar",\n'
        '    "success": true\n'
        '}'
    )

# Generated at 2022-06-23 19:34:18.750451
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert 'json' in formatter.format_options
    assert formatter.kwargs['explicit_json'] is False


# Generated at 2022-06-23 19:34:20.427165
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled is False

# Generated at 2022-06-23 19:34:30.319217
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        sort_keys=True,
        indent=4,
    )
    assert formatter.format_body(
        body=json.dumps({
            'foo': 'bar',
            'baz': {'qux': 1},
        }),
        mime='json',
    ) == """{
    "baz": {
        "qux": 1
    },
    "foo": "bar"
}"""
    assert formatter.format_body(
        body='{"foo": "bar", "baz": {"qux": 1}}',
        mime='text',
    ) == """{
    "baz": {
        "qux": 1
    },
    "foo": "bar"
}"""

# Generated at 2022-06-23 19:34:41.419874
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.formatters.format import get_prettifier
    def get_mime(c):
        if c == 'j': return 'json'
        if c == 'p': return 'text/plain'
        if c == 'h': return 'html'
        if c == 'x': return 'xml'
        raise ValueError('Bad character ' + c)


# Generated at 2022-06-23 19:34:42.669066
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-23 19:34:51.703742
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        },
        'colors': {
            'red': '\x1b[31m',
            'green': '\x1b[32m',
            'blue': '\x1b[34m',
            'yellow': '\x1b[33m',
            'reset': '\x1b[39m'
        },
        'html': {
            'format': False,
            'color_scheme': 'default',
            'css': [],
            'js': [],
            'baseurl': ''
        }
    }, color_options='auto', explicit_json=True)


# Generated at 2022-06-23 19:34:54.186159
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    input_json = {'json': {'format': True}}
    assert JSONFormatter(format_options=input_json).enabled

    input_json = {'json': {'format': False}}
    assert not JSONFormatter(format_options=input_json).enabled



# Generated at 2022-06-23 19:35:04.369484
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(**{'explicit_json': False, 'format_options':'{"json":{"format":True,"indent":2,"sort_keys":False}}'})
    body_dic = {
    'data': '{"is_bookmarked": false}',
    'target': 'https://putsreq.com/r520z3q6ZPsU6wjLM6dv',
    'url': 'https://putsreq.com/r520z3q6ZPsU6wjLM6dv',
    'method': 'GET'
    }
    if(f.format_body(body_dic['data'], body_dic['method'])=='{"is_bookmarked": false}'):
        print("Passed")
    else:
        print("Failed")

# Unit

# Generated at 2022-06-23 19:35:12.021570
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import requests

    # Test with a valid json-body
    formatter = JSONFormatter(kwargs=dict(explicit_json=False))
    body = '{"name": "httpie"}'
    assert formatter.format_body(body,'json') == '{\n    "name": "httpie"\n}'

    # Test with a valid json-body and explicit_json set to true
    formatter = JSONFormatter(kwargs=dict(explicit_json=True))
    body = '{"name": "httpie"}'
    assert formatter.format_body(body,'json') == '{\n    "name": "httpie"\n}'

    # Test with a valid json-body and explicit_json set to false
    formatter = JSONFormatter(kwargs=dict(explicit_json=False))
    body

# Generated at 2022-06-23 19:35:16.520079
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Check if we get valid json back after formatting
    test_json = json.dumps(obj={"testkey": "testvalue"})

    response = JSONFormatter(format_options={'json': {'format': True}}).format_body(test_json, "application/json")

    assert json.loads(response) == json.loads(test_json)


# Generated at 2022-06-23 19:35:27.296979
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from mock import Mock

    def load_json(json_str):
        return json.loads(json_str)

    json_str = '{"a": "b"}'
    json_bytes = json_str.encode('utf8')
    json_json = json.loads(json_str)
    json_dict = {'a': 'b'}
    json_list = [('a', 'b')]

    formatter = JSONFormatter(format_options=None, format_dict=None)
    args = {
        'body': json_str,
        'mime': 'text/plain',
        'explicit_json': False,
    }
    assert formatter.format_body(**args) == json_str
    assert formatter.format_body(**dict(args, body=json_bytes)) == json_

# Generated at 2022-06-23 19:35:37.589518
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.core
    # Build a test case
    request_a = httpie.core.Request('POST', 'http://endpoint.com', '{"test": "hello"}')
    request_a.headers['Content-Type'] = 'application/json'
    request_b = httpie.core.Request('POST', 'http://endpoint.com', 'test')
    request_b.headers['Content-Type'] = 'application/json'
    
    # Test case a
    # Setup
    format_a = JSONFormatter(format_options={'json':{'format':True, 'indent':2, 'sort_keys':False}}, explicit_json=True)
    formatter_a = format_a.format_body(request_a.body, request_a.headers['Content-Type'])
    # Assertion

# Generated at 2022-06-23 19:35:47.770621
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Unit test for method format_body of class JSONFormatter"""
    # Case 1:
    json_input = {}
    json_input['json'] = {}
    json_input['json']['format'] = True
    json_input['json']['sort_keys'] = True
    json_input['json']['indent'] = 4
    json_input['explicit_json'] = False
    assert JSONFormatter(**json_input).format_body('{"a":1}', 'json')  == '{\n    "a": 1\n}'
    assert JSONFormatter(**json_input).format_body('{"a":1}', 'application/javascript')  == '{\n    "a": 1\n}'

# Generated at 2022-06-23 19:35:58.788798
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    kwargs = {
        'format_options': {
            'json': {
                'indent': 4,
                'sort_keys': True,
                'format': True,
            }
        },
        'explicit_json': True
    }
    # body is json
    body = json.dumps({"one": 1, "two": 2, "three": 3})
    formatter = JSONFormatter(**kwargs)
    new_body = formatter.format_body(body, "json")
    assert new_body == '{\n    "one": 1,\n    "three": 3,\n    "two": 2\n}'

    # body is not json
    body = "abcdefg"
    formatter = JSONFormatter(**kwargs)
    new_body = formatter.format_body

# Generated at 2022-06-23 19:36:07.610082
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # True
    json_formatter = JSONFormatter()
    json_formatter_kwargs = {}
    json_formatter_kwargs['explicit_json'] = True
    json_formatter_kwargs['format_options'] = {'json': {'format': True}}
    json_formatter.set_kwargs(**json_formatter_kwargs)
    assert (json_formatter.format_body(
        '{"key": "value"}',
        'javascript'
    ) == '{\n    "key": "value"\n}')

    # True
    json_formatter = JSONFormatter()
    json_formatter_kwargs = {}
    json_formatter_kwargs['explicit_json'] = True

# Generated at 2022-06-23 19:36:14.165530
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test method JSONFormatter.format_body() with the following
    parameters:
        body = {"x": "y", "g": "h", "a": 1, "b": 2}
        mimetype = "json"
    Expecting result:
        body = {
            "a": 1,
            "b": 2,
            "g": "h",
            "x": "y"
        }
    """
    json_formatter = JSONFormatter()
    body = '{"x": "y", "g": "h", "a": 1, "b": 2}'
    mime = 'json'
    result = json_formatter.format_body(body, mime)

# Generated at 2022-06-23 19:36:25.363044
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    payload = {'key': 'value'}
    mime = 'json'
    assert '"key": "value"' in formatter.format_body(json.dumps(payload), mime)
    assert '"key": "value"' not in formatter.format_body(json.dumps(payload), 'html')
    assert formatter.format_body(json.dumps(payload), 'html') == json.dumps(payload)
    assert formatter.format_body('<html><head><title>Test<title><body>Test page</body></html>', 'text') == '<html><head><title>Test<title><body>Test page</body></html>'

# Generated at 2022-06-23 19:36:35.787674
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"foo": "bar"}'

    plugin = JSONFormatter()
    plugin.format_options['json']['format'] = True
    assert plugin.format_body(body, 'application/json') == body

    plugin.format_options['json']['format'] = False
    assert plugin.format_body(body, 'application/json') == body

    plugin = JSONFormatter()
    plugin.format_options['json']['format'] = True
    plugin.kwargs['explicit_json'] = True
    assert plugin.format_body(body, 'text/html') == body

    plugin.format_options['json']['format'] = False
    plugin.kwargs['explicit_json'] = True
    assert plugin.format_body(body, 'text/html') == body

    plugin = JSONFormatter()

# Generated at 2022-06-23 19:36:38.523344
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        JSONFormatter()
    except TypeError as error:
        assert 'Wrong number of positional arguments' in str(error)
    else:
        assert False, 'Should throw exception'



# Generated at 2022-06-23 19:36:47.829601
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-23 19:36:53.667264
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins.json_formatter import JSONFormatter
    jf = JSONFormatter(format_options={'json': {'format': True}}, kwargs={'explicit_json': True})
    assert jf.enabled == True


# Generated at 2022-06-23 19:36:54.215737
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert 1

# Generated at 2022-06-23 19:37:01.509686
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_body = '{"name": "Alex", "age": 28}'
    new_json_body = '{"age": 28, "name": "Alex"}'

    assert JSONFormatter().format_body(json_body) == json_body
    assert JSONFormatter().format_body(new_json_body, 'json') == new_json_body
    assert JSONFormatter(explicit_json=True).format_body(
        new_json_body
    ) == new_json_body
    assert JSONFormatter(explicit_json=True).format_body(
        json_body) == json_body

# Generated at 2022-06-23 19:37:03.361641
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={
        'format': True,
        'json': {
            'indent': 1,
            'sort_keys': False,
            'format': True}
    }, kwargs={'explicit_json': False}).format_options['json']['indent'] == 1


# Generated at 2022-06-23 19:37:06.679429
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    raw_json = '{"a": 1, "b": 2}'
    formatted_json = '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body(body=raw_json, mime='json') == formatted_json

# Generated at 2022-06-23 19:37:14.387790
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import JSONFormatter
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', mime='application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', mime='text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', mime='javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', mime='notjson') == '{"a": 1}'

# Generated at 2022-06-23 19:37:19.987192
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import JSONFormatter
    from .http import HttpRequest
    formatter = JSONFormatter()
    i = HttpRequest()
    formatter.format(i)
    formatter.format_body('{"a": "b"}', 'application/json')
    formatter.format_body('{"a": "b"}', 'application/javascript')
    formatter.format_body('{"a": "b"}', 'text')
    return formatter


# Generated at 2022-06-23 19:37:21.693500
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-23 19:37:31.874721
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}, 'colors': None},
                              explicit_json=True,
                              output_options={'pretty': True})
    test_dict = {"abc": 1, "cde": 2}

    output = formatter.format_body(json.dumps(test_dict), "json")
    assert output == json.dumps(test_dict, sort_keys=True, indent=4, ensure_ascii=False)

    output = formatter.format_body(json.dumps(test_dict), "javascript")
    assert output == json.dumps(test_dict, sort_keys=True, indent=4, ensure_ascii=False)


# Generated at 2022-06-23 19:37:36.452628
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    
    formatter_json = JSONFormatter()

    assert formatter_json.enabled == True
    assert formatter_json.kwargs == {}


# Generated at 2022-06-23 19:37:39.922932
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert not jsonFormatter.format_options['json']['format']



# Generated at 2022-06-23 19:37:49.481376
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # test_body_is_json is valid JSON
    test_body_is_json = '''
    {
      "jsonrpc": "2.0",
      "method": "getblockchaininfo",
      "params": [],
      "id": "curltest"
    }
    '''
    # test_body_not_json is not JSON
    test_body_not_json = '''
    {
      "jsonrpc": "2.0",
      "method": "getblockchaininfo",
      "params": [],
      "id": "curltest"
    }
    x
    '''
    # test_body_is_json_but_not_requested is valid JSON but should not be processed

# Generated at 2022-06-23 19:37:50.640538
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().format_options['json']


# Generated at 2022-06-23 19:37:58.139569
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Test JSONFormatter.format_body function."""
    # Proper JSON format
    JSONBody = '{"key": "value"}'
    assert JSONFormatter(format_options={'json':{'format':True}}).format_body(
        JSONBody, "application/json") == '{\n    "key": "value"\n}'
    assert JSONFormatter(format_options={'json':{'format':True}}).format_body(
        JSONBody, "application/javascript") == '{\n    "key": "value"\n}'
    assert JSONFormatter(format_options={'json':{'format':True}}).format_body(
        JSONBody, "text") == '{\n    "key": "value"\n}'
    # Invalid JSON format
    JSONBody = 'This is not a JSON format'

# Generated at 2022-06-23 19:38:07.399098
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import httpie.plugins.builtin
    # Input data
    format_options = {
        'json': {'format': True, 'sort_keys': True, 'indent': 4},
        'colors': {'request_method': 'green'},
        'style': None
    }
    # Test constructor
    formatter = httpie.plugins.builtin.JSONFormatter(
        format_options=format_options,
        explicit_json=True
    )
    # Checks
    assert isinstance(formatter, httpie.plugins.builtin.JSONFormatter)
    assert formatter.enabled
    assert formatter.kwargs['explicit_json']


# Generated at 2022-06-23 19:38:13.952466
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_options == {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    assert formatter.enabled == True


# Generated at 2022-06-23 19:38:19.374083
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options=dict())
    body = formatter.format_body('{"my_key": "my_value"}', 'json')
    assert body == '{\n    "my_key": "my_value"\n}'
    body = formatter.format_body('{"my_key": "my_value"}', 'html')
    assert body == '{"my_key": "my_value"}'

# Generated at 2022-06-23 19:38:21.405212
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == True

# Generated at 2022-06-23 19:38:25.271082
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonf = JSONFormatter()
    assert jsonf.enabled == False
    assert jsonf.format_options == {'json': {'format': False, 'indent': 4, 'sort_keys': False}}
    assert jsonf.kwargs == {}


# Generated at 2022-06-23 19:38:32.855867
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter('')

# Generated at 2022-06-23 19:38:38.621691
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        },
        explicit_json = True,
        compact = False,
        colors = False,
        headers = {},
        write = print,
        style = '__main__'
    )
    assert formatter.enabled == True
    assert formatter.kwargs['explicit_json'] == True


# Generated at 2022-06-23 19:38:43.100416
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    mime = 'application/json'
    body = '{"message": "Hello, world!"}'
    assert formatter.format_body(body, mime) == '{\n    "message": "Hello, world!"\n}'

# Generated at 2022-06-23 19:38:55.759428
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with a valid JSON
    body = '{"username": "test","password":"test"}'
    mime = 'application/json'
    formatter_plugin = JSONFormatter()
    new_body = formatter_plugin.format_body(body, mime)
    assert new_body == """{
  "password": "test",
  "username": "test"
}"""
    # Test with a invalid JSON
    body = '{"username": "test","password":"test"}[]'
    mime = 'application/json'
    formatter_plugin = JSONFormatter()
    new_body = formatter_plugin.format_body(body, mime)
    assert new_body == body

    # Test with a invalid JSON but using explicit_json
    body = '{"username": "test","password":"test"}[]'
    m

# Generated at 2022-06-23 19:39:00.456381
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(output_options=[], format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = "{\"foo\": \"bar\"}"
    formatted_body = formatter.format_body(body, 'json')
    assert formatted_body == body

# Generated at 2022-06-23 19:39:11.820810
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test some valid JSON
    body = '{"key1": "value1", "key2": 2}'
    mime = 'JSON'
    expected = '{\n  "key1": "value1", \n  "key2": 2\n}'
    res = JSONFormatter().format_body(body, mime)
    assert res == expected

    # Test some valid JSON, with different mime type
    body = '{"key1": "value1", "key2": 2}'
    mime = 'javascript'
    expected = '{\n  "key1": "value1", \n  "key2": 2\n}'
    res = JSONFormatter().format_body(body, mime)
    assert res == expected

    # Test some valid JSON, with other mime type

# Generated at 2022-06-23 19:39:17.430181
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Tests if a JSON str is correctly indented"""
    json_str = """{"id": {"name": "person_name", "age": "person_age"}, "type": "person"}"""
    formatter = JSONFormatter()
    assert formatter.format_body(json_str, 'json') == """{
    "id": {
        "name": "person_name",
        "age": "person_age"
    },
    "type": "person"
}"""

# Generated at 2022-06-23 19:39:22.518356
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_windows
    json_formatter = JSONFormatter()
    body = "{" \
           "'data': 'mantap'," \
           "'joss': 'gojek'" \
           "}"
    if is_windows:
        expected = "{\r\n    \"data\": \"mantap\",\r\n    \"joss\": " \
                   "\"gojek\"\r\n}"
    else:
        expected = "{\n    \"data\": \"mantap\",\n    \"joss\": " \
                   "\"gojek\"\n}"
    assert expected == json_formatter.format_body(body, 'json')

# Generated at 2022-06-23 19:39:33.541403
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:39:43.716504
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from requests import Response
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    resp = Response()
    resp.headers['content-type'] = ['application/json']
    resp.raw = '{"httpie": "HTTPie is a command line HTTP client that will make you smile"}'
    def mock_kwargs_get(key, default=None):
        return default
    resp.request.kwargs = {'get': mock_kwargs_get, 'explicit_json': False}
    def mock_format_options_get(key):
        if key == ('json', 'format'):
            return True
        if key == ('json', 'indent'):
            return 4
        if key == ('json', 'sort_keys'):
            return True


# Generated at 2022-06-23 19:39:52.176211
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.formatter.human import JSONFormatter
    kwargs = {
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            },
        },
        'explicit_json': False,
        'style': True,
        'colors': True,
    }
    body = b'{"lang": "JSON", "sample": true, "unicode": "\\u2713"}'
    mime = 'application/json'
    json_formatter = JSONFormatter(**kwargs)

# Generated at 2022-06-23 19:39:57.950958
# Unit test for method format_body of class JSONFormatter