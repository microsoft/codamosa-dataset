

# Generated at 2022-06-23 19:30:00.287775
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}},
        explicit_json=False
    )
    result = formatter.format_options['json']['format']
    assert result == True


# Generated at 2022-06-23 19:30:06.590503
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Implicitly test if the constructor is working as expected
    formatter = JSONFormatter({
        'format_options': {
            'json': {
                'format': False,
                'indent': 5,
                'sort_keys': True
            }
        }
    })
    assert formatter is not None

# Generated at 2022-06-23 19:30:09.846950
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    opts = {'json': {'sort_keys': False, 'indent': None, 'format': False}}
    formatter = JSONFormatter(format_options = opts)
    assert formatter.format_options == opts
    assert formatter.enabled == opts['json']['format']


# Generated at 2022-06-23 19:30:19.649261
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"name": "value"}'
    mime = 'application/json'

    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})

    assert json_formatter.format_body(body, mime) == body

    body = '{}'
    mime = 'application/json'

    assert json_formatter.format_body(body, mime) == body

    body = '[]'
    mime = 'application/json'

    assert json_formatter.format_body(body, mime) == body

    body = 'name: value'
    mime = 'application/json'

    assert json_formatter.format_body(body, mime) == body

# Generated at 2022-06-23 19:30:21.467304
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    print("test_JSONFormatter")
    formatter = JSONFormatter()
    assert isinstance(formatter, JSONFormatter)

# Generated at 2022-06-23 19:30:23.328104
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True

# Generated at 2022-06-23 19:30:31.201900
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fmt_json = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 1,
            'sort_keys': False,
        }
    })
    body = """
    {
        "foo": {
            "bar": 42
        }
    }
    """
    result = fmt_json.format_body(
        body=body,
        mime='application/json'
    )
    assert result == '''
    {
 "foo": {
  "bar": 42
 }
}
    '''.strip()

# Generated at 2022-06-23 19:30:39.266926
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import plugin_manager
    test_object = JSONFormatter(**plugin_manager.get_kwargs())

    plain_text_input = "<html><head><title>Not JSON</title></head></html>"
    json_example = "{"
    json_example += '"_id": "57a880057416b09d01c964c7", '
    json_example += '"index": 0, '
    json_example += '"guid": "f0c9b1ba-eb76-4919-a04b-6ae62ce9639c", '
    json_example += '"isActive": false, '
    json_example += '"balance": "$2,145.90", '
    json_example += '"picture": "http://placehold.it/32x32", '


# Generated at 2022-06-23 19:30:48.439111
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter({}, {'json': {'format': True, 'indent': 2,
                                'sort_keys': True}}).format_body('{"a": 1}',
                                                                 'json') == '{\n  "a": 1\n}'
    assert JSONFormatter({}, {'json': {'format': True, 'indent': 2,
                                'sort_keys': True}}).format_body('{"toto": "tata"}',
                                                                 'json') == '{\n  "toto": "tata"\n}'
    assert JSONFormatter({}, {'json': {'format': True, 'indent': 2,
                                'sort_keys': True}}).format_body('{"z":"1","a":"2","c":"3"}',
                                                                 'json')

# Generated at 2022-06-23 19:30:52.903118
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Fixture data
    data = '{"foo": "bar"}'

    # Create an object of the class
    formatter = JSONFormatter(**{'explicit_json': False})

    # Make the assertion
    assert json.loads(formatter.format_body(data, 'application/json')) == {"foo": "bar"}

# Generated at 2022-06-23 19:30:59.809930
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={
            'json':{
                'format': True,
                'indent': 2,
                'sort_keys':False
            },
        },
        kwargs={
            'explicit_json':False
        }
    )
    assert formatter.enabled == True
    assert formatter.kwargs['explicit_json'] == False
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == False


# Generated at 2022-06-23 19:31:00.948101
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.kwargs == {'explicit_json': False}

# Generated at 2022-06-23 19:31:11.269802
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid json
    jsonbody = '{"a":"1","b":"2","c":"3"}'
    f = JSONFormatter()
    jsonbody_formatted = f.format_body(jsonbody, 'json')

    assert jsonbody != jsonbody_formatted
    jsonbody_formatted_json = json.loads(jsonbody_formatted)
    jsonbody_json = json.loads(jsonbody)
    assert jsonbody_formatted_json == jsonbody_json

    # Test with invalid json
    jsonbody = '{"a":"1","b":"2","c":"3"}sdgs'
    f = JSONFormatter()
    jsonbody_formatted = f.format_body(jsonbody, 'json')

    assert jsonbody_formatted == jsonbody

    # Test with valid json and explicit format parameter

# Generated at 2022-06-23 19:31:20.650621
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"example": 1}', 'json') == '{\n    "example": 1\n}'
    assert formatter.format_body('{"example": 1}', 'text') == '{\n    "example": 1\n}'
    assert formatter.format_body('{"example": 1}', 'text/plain') == '{\n    "example": 1\n}'
    assert formatter.format_body('{"example": 1}', 'javascript') == '{\n    "example": 1\n}'
    assert formatter.format_body('{"example": 1}', 'application/javascript') == '{\n    "example": 1\n}'

# Generated at 2022-06-23 19:31:28.479453
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    json_formatter = JSONFormatter(**{'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': False}}, 'explicit_json': False})
    s = {'a': 1, 'b': 2}
    assert json_formatter.format_body(json.dumps(s), 'json') == json.dumps(s, indent=4, sort_keys=False, ensure_ascii=False)

# Generated at 2022-06-23 19:31:37.198036
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter({'json': {'format': True, 'sort_keys': False, 'indent': 0}})
    assert f.enabled == True
    assert f.format_options['json']['sort_keys'] == False
    assert f.format_options['json']['indent'] == 0

    f = JSONFormatter({'json': {'format': False, 'sort_keys': True, 'indent': 4}})
    assert f.enabled == False
    assert f.format_options['json']['sort_keys'] == True
    assert f.format_options['json']['indent'] == 4


# Generated at 2022-06-23 19:31:39.028586
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter_instance = JSONFormatter()
    assert JSONFormatter_instance.__class__.__name__ == 'JSONFormatter'

# Generated at 2022-06-23 19:31:46.303379
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter()
    assert jf.format_body('{"mime": "json"}', "json") == '{\n    "mime": "json"\n}'
    assert jf.format_body('{"mime": "json"}', "json") == '{\n    "mime": "json"\n}'
    assert jf.format_body('{"mime": "json"}', "text") == '{\n    "mime": "json"\n}'
    assert jf.format_body('{"mime": "json"}', "text") == '{\n    "mime": "json"\n}'
    assert jf.format_body('{"mime": "json"}', "javascript") == '{\n    "mime": "json"\n}'

# Generated at 2022-06-23 19:31:53.203357
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(**{'json':{'format':True}})
    mime = 'application/json'
    body = '{"a": 5, "b": 7}'
    output = formatter.format_body(body, mime)
    assert output == '''{\n    "a": 5,\n    "b": 7\n}'''

    formatter = JSONFormatter(**{'json':{'format':True}})
    mime = 'application/json'
    body = '{"a": 5, "b": [1, 2, 3]}'
    output = formatter.format_body(body, mime)

# Generated at 2022-06-23 19:32:02.346281
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.input import ParseResult
    from httpie.compat import urlunparse
    url = urlunparse(ParseResult(
        scheme='http',
        netloc='localhost:80',
        path='/',
        params='',
        query='',
        fragment=''
    ).geturl())

    plugin = JSONFormatter()
    plugin.kwargs = {'explicit_json': False}
    plugin.format_options = {
        'json': {
            'format': True,
            'indent': 3,
            'sort_keys': False
        }
    }
    assert plugin.format_body('{"foo": 42}', 'json') == '{\n   "foo": 42\n}'

# Generated at 2022-06-23 19:32:04.274906
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().format_options == {'json': {'indent': None, 'format': True, 'sort_keys': False}}

# Generated at 2022-06-23 19:32:06.949453
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter is not None
    assert formatter.enabled == True

# Generated at 2022-06-23 19:32:10.158861
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_JSON_formatter = JSONFormatter()
    assert test_JSON_formatter.format_options == {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    }


# Generated at 2022-06-23 19:32:13.978398
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {}
    format_options['json'] = {
        'format': True,
        'indent': 4,
        'sort_keys': True
    }
    kwargs = {'explicit_json': False}
    assert JSONFormatter(format_options = format_options, kwargs = kwargs) is not None


# Generated at 2022-06-23 19:32:17.573010
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 1}'
    mime = 'json'
    kwargs = {'explicit_json': True}
    j = JSONFormatter(**kwargs)
    assert isinstance(j.format_body(body, mime), str)

# Generated at 2022-06-23 19:32:27.461500
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    import unittest
    from httpie.plugins import FormatterPlugin, JSONFormatter
    
    class AssertJSONFormatter(JSONFormatter):
        
        def format_body(self, body: str, mime: str) -> str:
            return super().format_body(body, mime)

    class TestJSONFormatter(unittest.TestCase):
        def test_format_body(self):
            # Test handling of JSON
            formatter = AssertJSONFormatter()
            data = {'username': 'donald', 'password': 'vader'}
            jsondata = json.dumps(data) # convert to string
            mime = 'application/json'
            self.assertEqual(formatter.format_body(jsondata, mime), jsondata)

# Generated at 2022-06-23 19:32:38.566807
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options= {
        'default_options': {
            'options': {
                'json': {
                    'format': True,
                    'indent': 2,
                    'sort_keys': True
                }
            }
        },
        'user_config': {
            'options': {
                'json': {
                    'format': True,
                    'indent': 4,
                    'sort_keys': True
                }
            }
        },
        'env_options': {
            'options': {
                'json': {
                    'format': True,
                    'indent': 2,
                    'sort_keys': True
                }
            }
        }
    })

    assert formatter.enabled == True


# Generated at 2022-06-23 19:32:47.879729
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    p = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    })
    body = p.format_body('{"key1": "value1", "key2": "value2"}', 'application/json')
    assert body == '{\n    "key1": "value1",\n    "key2": "value2"\n}'

    p = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    body = p.format_body('{"key1": "value1", "key2": "value2"}', 'application/json')

# Generated at 2022-06-23 19:32:50.885995
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    # Test constructor with no arguments
    assert f is not None
    assert f.indent == 4
    assert isinstance(f, JSONFormatter)
    assert f._cls
    

# Generated at 2022-06-23 19:32:57.304783
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    p = JSONFormatter(output_file=None, format_options={
        'headers': {
            'max_len': 0
        },
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False
        },
        'pretty': False,
        'style': {
            'lookup': 'solarized-dark'
        }
    }, color=False, theme=None, no_headers=False, no_body=False,
        verbose=False, output_options={
            'colors': True,
            'formatters': [],
            'max_len': 0,
            'pretty': False,
            'style': {}
        }, no_style=False,
        headers={}, output_stream=None,
        explicit_json=False)
    mime

# Generated at 2022-06-23 19:32:58.552541
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == 'last'

# Generated at 2022-06-23 19:33:06.811355
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test the method format_body of the JSONFormatter class
    """

    # Instantiate a JSONFormatter object and a fake HTTPie response
    formatter = JSONFormatter()

# Generated at 2022-06-23 19:33:09.088874
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Instance JSONFormatter object
    json = JSONFormatter()
    # Check if the constructor is working
    assert json.enabled == False

# Generated at 2022-06-23 19:33:12.040942
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(__file__, {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    })
    assert formatter.enabled == True
    assert formatter.kwargs == {'explicit_json': False}
    assert formatter.format_options == {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    }

# Generated at 2022-06-23 19:33:13.123975
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.enabled == False

# Generated at 2022-06-23 19:33:17.184838
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test valid json string and invalid json string
    """
    plugin = JSONFormatter(format_options={"json": {"format": True}})
    result = plugin.format_body('{"a":1, "b":2}', "json")
    assert result == '{\n    "a": 1,\n    "b": 2\n}'
    result = plugin.format_body('{a":1, "b":2}', "json")
    assert result == '{a":1, "b":2}'

# Generated at 2022-06-23 19:33:22.880362
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}},
        kwargs={'explicit_json': False}
    )
    assert(formatter.enabled == True)
    assert(formatter.format_options['json']['sort_keys'] == True)
    assert(formatter.format_options['json']['indent'] == 4)
    assert(formatter.kwargs['explicit_json'] == False)



# Generated at 2022-06-23 19:33:26.406306
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter()
    assert jsonformatter.format_options['json']['format'] == True


# Generated at 2022-06-23 19:33:31.375720
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # A simple test
    assert JSONFormatter(
               format_options={
                   'json': {
                       'format': True,
                       'indent': 4,
                       'sort_keys': True,
                   }
               },
               explicit_json=False,
           ).format_body('{"a": 1, "b": 2}', 'application/json') == \
           '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-23 19:33:39.986889
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.format_options == {'json': {'format': False, 'indent': 2, 'sort_keys': True}}
    assert formatter.kwargs == {}

    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 5, 'sort_keys': False}}, kwargs={"explicit_json": True})
    assert formatter.enabled == True
    assert formatter.format_options == {'json': {'format': True, 'indent': 5, 'sort_keys': False}}
    assert formatter.kwargs == {"explicit_json": True}


# Generated at 2022-06-23 19:33:47.011522
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin = JSONFormatter(explicit_json=True)
    assert formatter_plugin.format_body(
            b'this is not json string', 'text/plain') == 'this is not json string'
    assert formatter_plugin.format_body(
            b'{}', 'text/json') == '{}'
    assert formatter_plugin.format_body(
            b'{}', 'application/json') == '{}'
    assert formatter_plugin.format_body(
            b'{}', 'application/javascript') == '{}'
    assert formatter_plugin.format_body(
            b'{}', 'text/javascript') == '{}'

# Generated at 2022-06-23 19:33:53.061805
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{
        'explicit_json': False,
        'format_options': {
            'json': {'format': True, 'indent': 4, 'sort_keys': True}
        }
    })
    body = '{"key": "value"}'
    body = json_formatter.format_body(body, mime='json')
    assert body == '''{
    "key": "value"
}\n'''

# Generated at 2022-06-23 19:33:56.830926
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    frmt = JSONFormatter()
    assert [{"baz": "qux"}] == json.loads(frmt.format_body(
        '[{"baz": "qux"}]', 'json'))



# Generated at 2022-06-23 19:34:05.688547
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"test": "123"}', "json") == "{\n    \"test\": \"123\"\n}"
    assert formatter.format_body('{"test": "123"}', "javascript") == "{\n    \"test\": \"123\"\n}"
    assert formatter.format_body('{"test": "123"}', "text") == "{\n    \"test\": \"123\"\n}"
    assert formatter.format_body('{"test": "123"}', "xml") == '{"test": "123"}'

# Generated at 2022-06-23 19:34:10.711353
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"foo":"bar","abc":"xyz"}'
    mime = 'json'
    formatter_kwargs = {
        "explicit_json": False,
        "formatter_options": {
            "json": {
                "format": True,
                "indent": 2,
                "sort_keys": False
            }
        }
    }
    formatter = JSONFormatter(**formatter_kwargs)
    assert formatter.format_body(body, mime) == '{\n  "abc": "xyz", \n  "foo": "bar"\n}'


# Generated at 2022-06-23 19:34:15.171228
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_object = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert isinstance(test_object, FormatterPlugin)
    assert test_object.enabled == True



# Generated at 2022-06-23 19:34:17.582005
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fmt = JSONFormatter()
    assert fmt.__class__.__name__ == 'JSONFormatter'
    assert fmt.enabled == True


# Generated at 2022-06-23 19:34:28.846212
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.compat import str
    class Mockkargs(object):
        def __init__(self, explicit_json, json_indent, json_sort_keys):
            self.explicit_json = explicit_json
            self.json_indent = json_indent
            self.json_sort_keys = json_sort_keys
    kwargs = Mockkargs(False, 2, True)
    format_options = {
        'json': {
            'format': True,
            'indent': kwargs.json_indent,
            'sort_keys': kwargs.json_sort_keys,
        },
    }
    formatter = JSONFormatter(format_options=format_options, **kwargs)
    assert formatter.enabled == format_options['json']['format']

# Unit

# Generated at 2022-06-23 19:34:32.692633
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fmt = JSONFormatter(**{})
    assert(fmt is not None)
    assert(hasattr(fmt, '__init__'))
    assert(hasattr(fmt, 'format_body'))

# Generated at 2022-06-23 19:34:38.039173
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.explicit_json == False
    assert formatter.format_options['json']['format'] == False
    assert formatter.format_options['json']['sort_keys'] == False
    assert formatter.format_options['json']['indent'] == 0



# Generated at 2022-06-23 19:34:40.889794
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body(
        body='{"key":"value"}',
        mime='application/json'
    ) == '{\n    "key": "value"\n}'

# Generated at 2022-06-23 19:34:41.463704
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert True

# Generated at 2022-06-23 19:34:43.700154
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import json
    from httpie.plugins import FormatterPlugin
    json_formatter = JSONFormatter()
    assert isinstance(json_formatter, FormatterPlugin)

# Generated at 2022-06-23 19:34:50.691432
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    """A unit test for testing JSONFormatter class."""
    formatter = JSONFormatter(json={'format': True, \
                                    'indent': 0, 'sort_keys': False}, \
                              explicit_json=False)
    assert formatter.enabled is True
    assert formatter.kwargs['explicit_json'] is False
    assert formatter.format_options['json']['format'] is True
    assert formatter.format_options['json']['indent'] == 0
    assert formatter.format_options['json']['sort_keys'] is False



# Generated at 2022-06-23 19:34:55.670563
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options=dict(json=dict(format=True, indent=4, sort_keys=True)),
        explicit_json=True)
    assert formatter.format_body(
        body='{"k1": 42, "k2": [1, 2, 3], "k3": "text"}',
        mime='application/json'
    ) == '{\n    "k1": 42,\n    "k2": [\n        1,\n        2,\n        3\n    ],\n    "k3": "text"\n}'

# Generated at 2022-06-23 19:34:57.512680
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{}', 'json') == '{}'


# Generated at 2022-06-23 19:35:06.953934
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Interface for customizing HTTPie output.
    class FormatterPlugin:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.format_options = {}
            self.enabled = True

    class FakeCLI:
        def __init__(self):
            self.arguments = {
                'json': {
                    'format': True,
                },
            }

        def format_options(self):
            return self.arguments

        # Specifies if the given argument is present in the list of CLI arguments
        def has_arg(self, argument):
            return argument in self.arguments

    # Creating a new formatter
    fp = FormatterPlugin(cli=FakeCLI())

    # Instantiating a JSON formatter

# Generated at 2022-06-23 19:35:15.569301
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={
        "json": {
            "format": True,
            "sort_keys": True,
            "indent": 4
        }
    })
    obj_json = {"c": 0, "b": 0, "a": 0}
    assert formatter.format_body(body=obj_json, mime='json') == "{\"c\": 0, \"b\": 0, \"a\": 0}"
    assert formatter.format_body(body=obj_json, mime='javascript') == "{\"c\": 0, \"b\": 0, \"a\": 0}"
    assert formatter.format_body(body=obj_json, mime='text') == "{\"c\": 0, \"b\": 0, \"a\": 0}"

# Generated at 2022-06-23 19:35:23.621226
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_options = {
        "json": {
            "format": True,
            "indent": 2,
            "sort_keys": True
        },
        "colors": {
            "method": "green"
        }
    }
    from httpie.plugins import FormatterPlugin
    ff = JSONFormatter(format_options=formatter_options, kwargs={"explicit_json": False})
    assert isinstance(ff, FormatterPlugin)
    assert ff.enabled is True


# Generated at 2022-06-23 19:35:27.006685
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"foo": "bar", "baz": 42}'
    mime = 'json'
    kwargs = {'explicit_json': True}
    assert json.loads(JSONFormatter(**kwargs).format_body(
        body, mime)) == json.loads(body)

# Generated at 2022-06-23 19:35:28.906122
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import json

    response = {}
    response.update(json.loads('{"format":true}'))
    assert response["format"]

# Generated at 2022-06-23 19:35:39.081585
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # case 1: body is JSON but mime type is not JSON-related
    #         --> format body
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 4,
        }
    })
    body = '{"content": "nothing to see here"}'
    mime = 'text/html; charset=utf-8'
    formatted_body = formatter.format_body(body, mime)
    assert formatted_body == '''{
    "content": "nothing to see here"
}'''

    # case 2: mime type is JSON-related and body is not JSON
    #         --> do not format body

# Generated at 2022-06-23 19:35:47.483817
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Unit test for method format_body of class JSONFormatter
    """
    body = '{"a": 1, "b": 2}'
    body_sorted_keys = '{\n  "a": 1,\n  "b": 2\n}'
    mime = 'json'
    kw = {
        'explicit_json': False,
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        }
    }

    formatter = JSONFormatter(**kw)

    assert formatter.format_body(body, mime) == body_sorted_keys



# Generated at 2022-06-23 19:35:52.867230
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    plugin = JSONFormatter(json={'indent': 0, 'sort_keys': False, 'format': True})
    assert plugin.format_options['json']['indent'] == 0
    assert plugin.key_order == ['json']

# Generated at 2022-06-23 19:36:03.142442
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class JSONFormatter:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.format_options = {
                'json': {
                    'indent': 2,
                    'sort_keys': True,
                    'format': True,
                },
                'colors': {
                    'http_error_bg': 'magenta',
                    'error_bg': 'red',
                    'error_fg': 'white',
                    'scheme': 'white_b',
                    'status': 'green',
                    'method': 'blue_b',
                    'protocol': 'green',
                    'url': 'cyan',
                    'headers': 'magenta',
                    'body': 'blue',
                },
            }
            self.enabled = True


# Generated at 2022-06-23 19:36:07.731856
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        explicit_json = False
    )
    assert formatter.enabled is True
    assert formatter.kwargs['explicit_json'] is False


# Generated at 2022-06-23 19:36:14.854407
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin

    assert (JSONFormatter
            .format_body(
                body='[{"id": 10, "name": "John Doe"}, {"id": 11, "name": "Jane Doe"}]',
                mime='json'
            ) == '[\n    {\n        "id": 10, \n        "name": "John Doe"\n    }, \n    {\n        "id": 11, \n        "name": "Jane Doe"\n    }\n]')

# Generated at 2022-06-23 19:36:16.751428
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    p = JSONFormatter()
    assert not p.enabled


# Generated at 2022-06-23 19:36:26.739315
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth
    from httpie.plugins.builtin import HTTPPasswordAuth
    from json import dumps
    from tempfile import NamedTemporaryFile
    env = Environment()
    plugin_manager.load_builtin_plugins()
    plugin_manager.load_internal_plugins()
    plugin_manager.load_external_plugins()
    JSONFormatter().update(env)
    with NamedTemporaryFile() as tf:
        msg = {'key': 'value'}
        json.dump(msg, tf)
        tf.seek(0)
        assert JSONFormatter().format_body(tf.read(), "application/json") == dumps(msg)
        HTTPBasicAuth().update(env)
       

# Generated at 2022-06-23 19:36:29.858211
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.enabled == True

if __name__ == '__main__':
    test_JSONFormatter()

# Generated at 2022-06-23 19:36:33.011779
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	k = {'json': {'format': True, 'indent': 2, 'sort_keys': True}}
	formatter = JSONFormatter(**k)
	assert formatter.enabled

# Generated at 2022-06-23 19:36:37.100369
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(json={'format': True, 'sort_keys': True, 'indent': 2})
    result = json_formatter.format_body('{"a": 1}', mime='json')
    assert result == '{\n  "a": 1\n}'

# Generated at 2022-06-23 19:36:46.608511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from types import SimpleNamespace
    from json import loads, JSONDecodeError
    formatter = JSONFormatter(
        format_options=SimpleNamespace(
            json=SimpleNamespace(
                format=True,
                indent=2,
                sort_keys=True
            )
        ),
        explicit_json=True
    )

    # Basic types
    assert 'null' == formatter.format_body('null', 'json')
    assert 'true' == formatter.format_body('true', 'json')
    assert 'false' == formatter.format_body('false', 'json')
    assert '-1' == formatter.format_body('-1', 'json')
    assert '1' == formatter.format_body('1', 'json')

# Generated at 2022-06-23 19:36:48.058748
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options = {'json': {'format': True}}).enabled
    assert not JSONFormatter(format_options = {'json': {'format': False}}).enabled


# Generated at 2022-06-23 19:36:57.406858
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    mx_formatter = JSONFormatter(
        format_options = {
            "json": {
                "format": True,
                "sort_keys": False,
                "indent": 4
            },
        },
        explicit_json = True
    )
    assert mx_formatter.format_options["json"]["format"] == True
    assert mx_formatter.format_options["json"]["sort_keys"] == False
    assert mx_formatter.format_options["json"]["indent"] == 4
    assert mx_formatter.explicit_json == True

# Generated at 2022-06-23 19:36:58.808341
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False

# Generated at 2022-06-23 19:37:04.763268
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Self-test code
    options = {
        'json': {
            'format': True,
            'indent': None,
            'sort_keys': False
        }
    }

    formatter = JSONFormatter(format_options=options)
    result = str(formatter.format_options['json'])
    expected = "{'format': True, 'indent': None, 'sort_keys': False}"
    assert result == expected, "Expected %s, got %s" % (expected, result)


# Generated at 2022-06-23 19:37:15.446809
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json':{
                'format': True,
                'indent': 2,
                'sort_keys': True,
            }
        },
        explicit_json=False,
    )

    body = '{"two": 2, "one": 1}'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{\n  "one": 1,\n  "two": 2\n}'

    body = '{"two": 2, "one": 1}'
    mime = 'text/html'
    assert json_formatter.format_body(body, mime) == '{"two": 2, "one": 1}'

    body = '{"two": 2, "one": 1}'

# Generated at 2022-06-23 19:37:18.894432
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    new_json_formatter = JSONFormatter()
    assert new_json_formatter.format_options == {'json': {'format': False, 'indent': 4, 'sort_keys': False}}
    assert new_json_formatter.kwargs == {}

# Generated at 2022-06-23 19:37:24.107932
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert(JSONFormatter().format_body("{\n  \"name\": \"httpie\"\n}")=="{\n  \"name\": \"httpie\"\n}")
    assert(JSONFormatter().format_body("{\"name\": \"httpie\"}")=="{\n  \"name\": \"httpie\"\n}")
    assert(JSONFormatter().format_body("{\"name\": \"httpie\"}", explicit_json=True)=="{\n  \"name\": \"httpie\"\n}")


# Generated at 2022-06-23 19:37:31.420771
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
	formatter=JSONFormatter()
	assert(formatter.format_body(body="{\"test\":\"ala\",\"test2\":\"bala\"}",mime="json")=="{\n  \"test\": \"ala\", \n  \"test2\": \"bala\"\n}")
	assert(formatter.format_body(body="bad json",mime="json")=="bad json")
	assert(formatter.format_body(body="{\"test\":\"ala\",\"test2\":\"bala\"}",mime="javascript")=="{\n  \"test\": \"ala\", \n  \"test2\": \"bala\"\n}")

# Generated at 2022-06-23 19:37:36.053609
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.enabled == True


# Generated at 2022-06-23 19:37:44.563527
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output import get_formatters

    json_formatter = [
        formatter for formatter in get_formatters()
        if formatter.name == 'JSONFormatter'
    ][0]

    assert json_formatter.format_body("{'a': 'b'}", '') == "{'a': 'b'}"
    assert json_formatter.format_body("{'a': 'b'}", 'json') == '{\n    "a": "b"\n}'

# Generated at 2022-06-23 19:37:54.805056
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()

    # test 1
    json_data = '{"key1":"val1", "key2":"val2"}'
    assert json_data == f.format_body(json_data, "application/json")

    # test 2
    json_data = '{"key1":"val1", "key2":"val2"}'
    assert json_data == f.format_body(json_data, "text/plain")

    # test 3
    json_data = '{"key1":"val1", "key2":"val2"}'
    assert json_data == f.format_body(json_data, "text/javascript")

    # test 4
    json_data = '{"key1":"val1", "key2":"val2"}'

# Generated at 2022-06-23 19:37:56.556632
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    plugin = JSONFormatter(None, None, None)
    assert isinstance(plugin, JSONFormatter)


# Generated at 2022-06-23 19:37:58.643673
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # TODO: Implement a unit test for this method
    assert False

# Generated at 2022-06-23 19:38:09.479224
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'text'
    body = '{"a": 1, "b": 2}'
    expected_output = '{"a": 1, "b": 2}'
    assert JSONFormatter.format_body(body, mime) == expected_output
    mime = 'javascript'
    assert JSONFormatter.format_body(body, mime) == expected_output
    mime = 'json'
    assert JSONFormatter.format_body(body, mime) == expected_output
    mime = 'text/html'
    body = '{"a": 1, "b": 2}'
    assert JSONFormatter.format_body(body, mime) == expected_output

    indent = 4
    sort_keys = True

# Generated at 2022-06-23 19:38:18.162967
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Create an instance of class JSONFormatter
    json_formatter = JSONFormatter()

    # Test if method format_body works properly, if yes, sets a flag to true
    json_test_flag = True
    # The resulting body from method format_body contains the string json_test_flag
    # which should be removed by the method, else sets the flag to false
    if b'json_test_flag' in json_formatter.format_body(b'{"json_test_flag":"json_formatter_test"}', 'application/json'):
        json_test_flag = False

    # If the flag is set to false, the test has failed
    assert json_test_flag

# Generated at 2022-06-23 19:38:28.278991
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # create instance for class FormatterPlugin
    jf = JSONFormatter(format_options={'json': {
        'format': True,
        'indent': 2,
        'sort_keys': True
    }}, explicit_json=True)
    # 1. assert body with correct json string and mime
    assert jf.format_body(
        '{"a": [1,2,3,4] }', 'json') == '{\n  "a": [\n    1,\n    2,\n    3,\n    4\n  ]\n}'
    # 2. assert invalid json
    assert jf.format_body(
        '{"a": [1,2,3,4') == '{"a": [1,2,3,4'


plugin_cls = JSONFormatter

# Generated at 2022-06-23 19:38:38.762159
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    import json
    print("***************test_JSONFormatter_format_body******************")
    formatter_plugin = FormatterPlugin()
    json_formatter = JSONFormatter(formatter=formatter_plugin,
                                   format_options={
                                       'pretty': 1,
                                       'colors': 1,
                                       'format': 1,
                                       'utf8': 1,
                                       'json': {'indent': 2, 'sort_keys': 1},
                                   },
                                   explicit_json=True,
                                   response_headers=[])
    test_body_string = "123{'a':'b'}"
    mime = 'json'
    j_body = json_formatter.format_body(test_body_string, mime)
    assert j_

# Generated at 2022-06-23 19:38:46.696376
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.cli.formatters as formatters
    formatter = JSONFormatter()
    formatter.kwargs = {'explicit_json': 'False'}

    assert formatter.format_body('{"id":1,"name":"Jack"}', 'json') == '{\n  "id": 1,\n  "name": "Jack"\n}'
    assert formatter.format_body('{"id":1,"name":"Jack"}', 'javascript') == '{\n  "id": 1,\n  "name": "Jack"\n}'
    assert formatter.format_body('{"id":1,"name":"Jack"}', 'text') == '{\n  "id": 1,\n  "name": "Jack"\n}'

# Generated at 2022-06-23 19:38:49.651333
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert(isinstance(jsonFormatter, JSONFormatter))

test_JSONFormatter()

# Generated at 2022-06-23 19:38:55.353227
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = FormatterPlugin(kwargs = {"format_options":{'json': {'format': True, 'indent': 0, 'sort_keys': True}}})
    mime = "json"
    body = '{"foo": "text", "bar": 42}'
    assert "{\n    \"bar\": 42,\n    \"foo\": \"text\"\n}" == f.format_body(body, mime)

# Generated at 2022-06-23 19:38:56.857244
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter()
    assert test.enabled == True

# Generated at 2022-06-23 19:39:05.387608
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            "json":
            {
                "format": True,
                "indent": 3,
                "sort_keys": True
            },
            "colors":
            {
                "http": True
            }
        }
    )
    body = "{\"foo\": \"bar\", \"baz\": [\"a\", \"b\", \"c\"]}"
    mime = "application/json"
    expect = "{\n   \"baz\": [\n      \"a\",\n      \"b\",\n      \"c\"\n   ],\n   \"foo\": \"bar\"\n}"
    assert json_formatter.format_body(body=body, mime=mime) == expect



# Generated at 2022-06-23 19:39:15.733294
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:39:22.154647
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.compat import pyopenssl
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['json']['format']
        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                    or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass  # Invalid

# Generated at 2022-06-23 19:39:30.873777
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test if JSON can be formatted according to settings
    """
    body = '{"test": "test"}'
    mime = 'json'
    settings = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }
    formatter = JSONFormatter(format_options=settings)
    result = formatter.format_body(body=body, mime=mime)
    if result == '{\n    "test": "test"\n}':
        assert True
    else:
        assert False

# Generated at 2022-06-23 19:39:35.281221
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(pretty=True)
    mime = 'json'
    body = '{"a": 1, "b": 2}'
    expected = '{\n    "a": 1,\n    "b": 2\n}'
    actual = f.format_body(body, mime)
    assert actual == expected

# Generated at 2022-06-23 19:39:41.057383
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Initialize a JSONFormatter object
    JF = JSONFormatter(format_options={
                    'json':{
                        'format': True,
                        'indent': 2,
                        'sort_keys': True,
                    }
                })
    # Perform tests expected of JSONFormatter object
    assert JF.enabled
    assert JF.format_options['json']['indent'] == 2
    assert JF.format_options['json']['sort_keys'] == True



# Generated at 2022-06-23 19:39:45.940252
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        },
        explicit_json=False,
        colors=False,
        # And a bunch of other stuff...
    )
    assert test.enabled

# Generated at 2022-06-23 19:39:50.675147
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": "b"}'
    jf = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        }
    )
    mime = 'text/json'
    assert jf.format_body(body, mime) == '{\n    "a": "b"\n}'

# Generated at 2022-06-23 19:39:53.706992
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    class MockFormatterPlugin:
        def __init__(self):
            self.format_options={"json": {"format": True}}
            self.kwargs={"explicit_json": True}

    jsonFormat = JSONFormatter(formatterPlugin=MockFormatterPlugin())
    assert jsonFormat.enabled == True


# Generated at 2022-06-23 19:39:59.087822
# Unit test for method format_body of class JSONFormatter