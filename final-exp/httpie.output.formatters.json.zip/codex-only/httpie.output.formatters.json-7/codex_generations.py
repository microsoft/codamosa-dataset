

# Generated at 2022-06-23 19:29:59.576021
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(format_options={'json': {'format': True, 'indent': 2,
                                                'sort_keys': True}})
    assert isinstance(jf, JSONFormatter)

# Generated at 2022-06-23 19:30:01.855137
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    r = JSONFormatter(options=dict(json=dict(format=True, sort_keys=False, indent=2)))
    assert(r.enabled == True)

# Generated at 2022-06-23 19:30:07.902968
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter()
    test.enabled = False
    test.kwargs = {'explicit_json': True}
    assert test.format_options['json']['format'] == True
    assert test.format_options['json']['indent'] == None
    assert test.format_options['json']['sort_keys'] == False

# Generated at 2022-06-23 19:30:18.785595
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case no json at all
    json_formatter = JSONFormatter(format_options={"json": {
        "format": True,
        'sort_keys': True,
        "indent": 2,
    }})
    body_test_case1 = '{"key": "value","key2": "value2"}'
    mime_test_case1 = 'text/plain'
    body_formatted1 = json_formatter.format_body(body_test_case1, mime_test_case1)
    assert body_formatted1 == '{\n  "key": "value",\n  "key2": "value2"\n}'

    # Test case with json in mime

# Generated at 2022-06-23 19:30:20.353144
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False

# Generated at 2022-06-23 19:30:21.181623
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__init__

# Generated at 2022-06-23 19:30:24.319148
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    h = {'json': {'format': False, 'sort_keys': False, 'indent': False}}
    print(JSONFormatter(format_options=h, explicit_json=False))

# Generated at 2022-06-23 19:30:31.337456
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    obj = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    assert obj.enabled == True
    assert obj.kwargs['explicit_json'] == False
    assert obj.format_options['json']['format'] == True
    assert obj.format_options['json']['sort_keys'] == True
    assert obj.format_options['json']['indent'] == 2


# Generated at 2022-06-23 19:30:36.548677
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
        json_formatter = JSONFormatter(
                format_options={
                        'json': {
                                'format': True,
                                'indent': 2,
                                'sort_keys': True,
                        }
                },
                explicit_json=True
        )
        assert hasattr(json_formatter, 'enabled')
        assert hasattr(json_formatter, 'format_options')
        assert hasattr(json_formatter, 'explicit_json')



# Generated at 2022-06-23 19:30:42.179821
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    test_inputs = {
        'body': 'This is not JSON, but something else.',
        'mime': 'text/text',
        'kwargs': {
            'explicit_json': False,
            'format_options': {
                'json': {
                    'format': True,
                    'indent': 2,
                    'sort_keys': False,
                }
            }
        }
    }

    expected_output = test_inputs['body']
    json_formatter = JSONFormatter(**test_inputs['kwargs'])

    assert(json_formatter.format_body(test_inputs['body'], test_inputs['mime']) == expected_output)

# Generated at 2022-06-23 19:30:43.625758
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  formatter = JSONFormatter()
  assert formatter.enabled == True


# Generated at 2022-06-23 19:30:50.661141
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fJson = JSONFormatter(explicit_json=True, format_options={'json': {'format': True, 'indent': 1, 'sort_keys': False}})
    assert fJson.format_body("{\"test\": True}", "text") == "{\"test\": True}"
    assert fJson.format_body("{\"test\": true}", "text") == "{\n \"test\": true\n}"
    assert fJson.format_body("{\"test\": true}", "javascript") == "{\n \"test\": true\n}"
    assert fJson.format_body("{\"test\": true}", "json") == "{\n \"test\": true\n}"



# Generated at 2022-06-23 19:30:55.937182
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        })
    body = '{"a": "b"}'
    content_type = 'application/json'
    assert formatter.format_body(body, content_type) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    content_type = 'application/javascript'
    assert formatter.format_body(body, content_type) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    content_type = 'application/text'

# Generated at 2022-06-23 19:30:57.919395
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 0,
            }
        }
    )
    assert formatter.enabled is True

# Generated at 2022-06-23 19:31:03.337301
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class JSONFormatterFake(JSONFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.kwargs = kwargs

    assert JSONFormatterFake({
        'explicit_json': False,
        'format_options': {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        }
    }).format_body('{"foo": "bar"}', 'application/json') == \
        '{\n    "foo": "bar"\n}'


# Generated at 2022-06-23 19:31:13.799216
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(**{
        'format_options': {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        'kwargs': {
            'explicit_json': True
        }
    })
    # Test that it correctly formats the JSON
    assert formatter.format_body("{\"foo\":\"bar\"}", "json") == '{\n    "foo": "bar"\n}'
    # Test that it doesn't parse other content
    assert formatter.format_body("{\"foo\":\"bar\"}", "html") == "{\"foo\":\"bar\"}"

    # Test that it doesn't parse invalid JSON

# Generated at 2022-06-23 19:31:18.536219
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter({'json': {'format': False, 'indent': '', 'sort_keys': False}})
    assert formatter.enabled == False
    formatter = JSONFormatter({'json': {'format': True, 'indent': '', 'sort_keys': False}})
    assert formatter.enabled == True


# Generated at 2022-06-23 19:31:26.250437
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json = True, kwargs = {'explicit_json': True})
    assert(formatter is not None)
    assert(formatter.format_options['json']['format'] is True)
    assert(formatter.format_options['json']['indent'] == 4)
    assert(formatter.format_options['json']['sort_keys'] is True)
    assert(formatter.explicit_json is True)

# Generated at 2022-06-23 19:31:27.940865
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json = JSONFormatter(format_options={'json': {'format': False, 'sort_keys': False, 'indent': 4}}, kwargs={'explicit_json': True})
    assert json.enabled == False

# Generated at 2022-06-23 19:31:33.231334
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()

    assert formatter_plugin.format_options['json']['sort_keys'] == False
    assert formatter_plugin.format_options['json']['indent'] == 3
    assert formatter_plugin.format_options['json']['format'] == False


# Generated at 2022-06-23 19:31:36.529996
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter({'json': {'sort_keys': False, 'format': True, 'indent': 3}})
    assert jsonFormatter.kwargs['explicit_json'] == None
    assert jsonFormatter.enabled == True

# Generated at 2022-06-23 19:31:38.057720
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        JSONFormatter()
        assert True
    except:
        assert False


# Generated at 2022-06-23 19:31:42.800304
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from mock import MagicMock
# (1) Arrange
    format_options = {"json": {"format": True}}
    format_options_mock = MagicMock(return_value=format_options)
    kwargs = {"explicit_json": True, "format_options": format_options_mock}
# (2) Act
    json_formatter = JSONFormatter(**kwargs)
# (3) Assert
    assert json_formatte

# Generated at 2022-06-23 19:31:51.952214
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import JSONFormatter
    from httpie.core import Environment
    from httpie.compat import is_py2

    env = Environment(options=dict(json=dict(format=True)))
    formatter = JSONFormatter(env, **{})

    # test_format_body_format_true_content_type_json_valid
    body = '{"key1":"value1","key2":"value2"}'
    mime = 'application/json'
    expected_body = '{\n    "key1": "value1",\n    "key2": "value2"\n}'
    expected_body = expected_body.replace('u', '') \
                                 if is_py2 else expected_body

    assert formatter.format_body(body, mime) == expected_body

    # test_

# Generated at 2022-06-23 19:31:54.581748
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert 'json' in json_formatter.format_options


# Generated at 2022-06-23 19:31:56.163138
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    assert isinstance(f, FormatterPlugin)

# Generated at 2022-06-23 19:31:57.152746
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json':{'format':False,'indent':4,'sort_keys':True}})


# Generated at 2022-06-23 19:31:58.363061
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_JSONFormatter = JSONFormatter()
    assert test_JSONFormatter.format_body('{"Test": "OK"}', "json") == '{"Test": "OK"}'

# Generated at 2022-06-23 19:32:02.091989
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': False}},
                                   explicit_json=False)
    assert json_formatter.enabled == False


# Generated at 2022-06-23 19:32:05.063217
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fmt = JSONFormatter()
    assert isinstance(fmt.format_options, dict)
    fmt = JSONFormatter(format_options={'json': {'format': True}})
    assert isinstance(fmt.kwargs, dict)

# Generated at 2022-06-23 19:32:13.376564
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import PluginManager
    from httpie.cli import CLIOptions, CLIConfig
    from httpie import core, compat
    from collections import OrderedDict
    from pygments.token import Token
    # Instantiate a plugin manager
    plugin_manager = PluginManager()
    #
    # instantiate a format options
    format_options = OrderedDict()
    format_options['json'] = {
        "format": True,
        "sort_keys": False,
        "indent": None
    }

# Generated at 2022-06-23 19:32:18.308417
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-23 19:32:20.923000
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = {'json': {'format': True, 'sort_keys': False, 'indent': 4}}, explicit_json = True)
    assert formatter.enabled == True
    assert formatter.kwargs['explicit_json'] == True
    assert formatter.kwargs['format_options'] == {'json': {'format': True, 'sort_keys': False, 'indent': 4}}


# Generated at 2022-06-23 19:32:23.176421
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().format_options['json']['format'] == True


# Generated at 2022-06-23 19:32:24.525855
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    #setup
    formatter = JSONFormatter()

    #test
    assert formatter.format_options['json']['format'] == False


# Generated at 2022-06-23 19:32:33.439776
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': '  ',
                'sort_keys': True,
            }
        },
        explicit_json=False,
    )
    # Given
    body = '{"key1":"value1","key3":"value3","key2":"value2"}'
    mime = 'application/json'
    # When
    formatted_body = json_formatter.format_body(body, mime)
    expected_body = """{
  "key1": "value1",
  "key2": "value2",
  "key3": "value3"
}"""
    # Then
    assert formatted_body == expected_body

# Generated at 2022-06-23 19:32:42.580348
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from tempfile import TemporaryDirectory
    from tempfile import NamedTemporaryFile
    from os import remove
    from shutil import copyfile
    from os.path import isfile
    from os.path import join
    from httpie.core import main
    from json import loads

    name = 'test_JSONFormatter'
    tmp_dir = TemporaryDirectory(name)

# Generated at 2022-06-23 19:32:46.806489
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert not formatter.format_options['json']['sort_keys']
    assert not formatter.format_options['json']['indent']
    assert formatter.format_options['json']['format']


# Generated at 2022-06-23 19:32:52.420774
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.streams import STDOUT_ENCODING
    formatter = JSONFormatter(
        explicit_json = False,
        stdout_isatty = False,
        format_options = dict(
            json = dict(
                format=True, 
                sort_keys=True, 
                indent=4
            )
        )
    )
    body = '''{
    "data": "data",
    "data_obj": {
        "data_obj_str": "str",
        "data_obj_num": 1
    },
    "data_arr": [
        "arr_item1",
        "arr_item2"
    ]
}'''
    mime = 'json'

# Generated at 2022-06-23 19:32:59.723243
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie import JSONFormatter
    format_options={'json': {'format': False, 'indent': 4, 'sort_keys': True}}
    kwargs={'explicit_json': False}
    formatter = JSONFormatter(format_options, **kwargs)
    assert formatter.format_options['json'] == {'format': False, 'indent': 4, 'sort_keys': True}
    assert formatter.enabled == False
    assert formatter.kwargs['explicit_json'] == False


# Generated at 2022-06-23 19:33:09.431604
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.context import Environment
    
    # Environment.format_options param is a dict with a key 'json'
    env = Environment(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}})
    
    def get_mimetype(response):
        return response.info().get('Content-Type', '').split(';')[0]
    
    # Imports
    import json, http.client
    
    # Auxiliar functions
    def to_json_obj(content):
        try:
            return json.loads(content)
        except ValueError:
            return None
    
    def get_indent(response):
        return json.dumps(to_json_obj(response), ensure_ascii=False, indent=4)
    

# Generated at 2022-06-23 19:33:11.856802
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json':{'format':True, 'sort_keys':True, 'indent':2}})
    print(formatter.format_options['json']['format']);
    print(formatter.format_options['json']['sort_keys']);
    print(formatter.format_options['json']['indent']);



# Generated at 2022-06-23 19:33:21.821921
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.cli.options import stdout_options
    fmt_opts = stdout_options['format-options']
    fmt_opts['json']['format'] = True
    fmt_opts['json']['indent'] = 4
    fmt_opts['json']['sort_keys'] = False
    json_formatter = JSONFormatter(format_options=fmt_opts, compact=False)

# Generated at 2022-06-23 19:33:27.163361
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatted = json_formatter.format_body('{"key1": "value1"}',
                                                'application/json')
    json_expected = """{
    "key1": "value1"
}"""
    assert json_formatted == json_expected

# Generated at 2022-06-23 19:33:28.709416
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-23 19:33:36.127462
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{'id': 1}"
    mime = "application/json"
    formatter = JSONFormatter(kwargs={'explicit_json': False})
    assert formatter.format_body(body, mime) == "{'id': 1}"

    formatter = JSONFormatter(kwargs={'explicit_json': True})
    assert formatter.format_body(body, mime) == '{\n    "id": 1\n}'

# Generated at 2022-06-23 19:33:38.809924
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert not formatter.enabled
    formatter = JSONFormatter(**{'format_options': {'json': {'format': True}}})
    assert formatter.enabled


# Generated at 2022-06-23 19:33:44.644645
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_with_unicode_escape = '{"hello": "World"}'
    json_pretty_with_unicode_escape = json.dumps({'hello': 'World'}, ensure_ascii=True, indent=2)
    json_pretty = json.dumps({'hello': 'World'}, ensure_ascii=False, indent=2)
    json_with_unicode_escape_indent = '{\n  "hello": "World"\n}'
    json_sorted = json.dumps({"b": 1, "a": [2, 3], "z": {"x": 4, "y": 5}}, sort_keys=True, ensure_ascii=False, indent=4)

# Generated at 2022-06-23 19:33:54.630836
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.cli import get_encoded_response
    # mock FormatterOption
    format_options = {
        "body_max_size": 4294967295,
        "colors": True,
        "reflow": True,
        "format": "json",
        "indent": 4,
        "sort_keys": True,
        "stream": False,
        "verbose": False
    }
    kwargs = {
        "stream": False,
        "verbose": False,
        "format_options": format_options,
        "explicit_json": False
    }
    formatter = JSONFormatter(**kwargs)
    assert formatter.enabled == True
    bytes_content = b'{\n    "key": "value"\n}'


# Generated at 2022-06-23 19:34:05.014324
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # json=f, explicit_json=f, mime=json
    kwargs = {
        'json': {
            'format': False,
            'indent': 2,
            'sort_keys': True,
        },
        'explicit_json': False,
        'indent': 2,
        'style': 'default',
        'styles': {},
        'format_options': {},
    }
    fmt = JSONFormatter(**kwargs)
    body = fmt.format_body('{"key": "value"}', 'json')
    assert body == '{"key": "value"}'

    # json=t, explicit_json=f, mime=json

# Generated at 2022-06-23 19:34:15.430928
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert (formatter.format_body("{\"foo\": [1,2]}", 'application/json') ==
        '{\n    "foo": [\n        1,\n        2\n    ]\n}')
    assert (formatter.format_body("{\"foo\": [3,4]}", 'application/json') ==
        '{\n    "foo": [\n        3,\n        4\n    ]\n}')
    assert (formatter.format_body("{\"foo\": [5,6]}", 'application/json') ==
        '{\n    "foo": [\n        5,\n        6\n    ]\n}')

# Generated at 2022-06-23 19:34:23.728347
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # given
    format_options = {
        "json": {
            "format": True,
            "indent": 0,
            "sort_keys": True
        }
     }
    kwargs = {
        "explicit_json": True
    }
    formatter = JSONFormatter(format_options, kwargs)
    body = '{"key":"value"}'
    mime = 'json'

    # when
    formatter.format_body(body, mime)

    # then
    assert body == '{"key":"value"}'



# Generated at 2022-06-23 19:34:33.557262
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter()
    body = '{"name": "foo"}'
    mime = "application/json"
    jf.kwargs['explicit_json'] = True
    jf.format_options['json']['indent'] = 2
    jf.format_options['json']['sort_keys'] = False
    assert jf.format_body(body, mime) == '{\n  "name": "foo"\n}'

    jf.format_options['json']['sort_keys'] = True
    assert jf.format_body(body, mime) == '{\n  "name": "foo"\n}'

    body = '{"name": "bar"\n}'
    jf.kwargs['explicit_json'] = True
    assert jf.format_

# Generated at 2022-06-23 19:34:36.654891
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter()
    assert test.format_options == {'json': {'format': True, 'indent': 4, 'sort_keys': False}}
    assert test.kwargs == {}

# Generated at 2022-06-23 19:34:41.384779
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Function to test format_body() in the JSONFormatter class
    """
    json = JSONFormatter(**{'explicit_json': True})
    assert json.format_body('{"key":"value"}', 'json') == '"{\n    \\"key\\": \\"value\\"\n}"'

# Generated at 2022-06-23 19:34:43.295302
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'indent': 2, 'sort_keys': True, 'format': False}})

# Generated at 2022-06-23 19:34:46.865838
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(explicit_json=False, format_options={'json':{'format': True, 'sort_keys': True, 'indent': 2}})
    assert (f.enabled == True)


# Generated at 2022-06-23 19:34:51.956706
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    JSONFormatter_class = JSONFormatter(
        format_options = {
            "json": {
                "format": True,
                "indent": 1,
                "sort_keys": True
            }
        },
        explicit_json = False
    )
    input_dict = {
        "key1": "value1",
        "key2": "value2"
    }
    output_str = json.dumps(
        obj=input_dict,
        sort_keys=True,
        ensure_ascii=False,
        indent=1
    )
    output_str += '\n'
    assert JSONFormatter_class.format_body(json.dumps(input_dict), 'application/json') == output_str

# Generated at 2022-06-23 19:34:53.541523
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert isinstance(JSONFormatter(format_options={"json": {"format": "enabled"}}), JSONFormatter)


# Generated at 2022-06-23 19:35:04.294502
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py26
    from httpie.context import Environment

    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        argv=None,
        config=None,
        output_options=None
    )

    formatter = JSONFormatter(env=env)

    body = '{"a": "a"}'
    assert formatter.format_body(body=body, mime='json') == body

    body = '{"a": "a"}'
    assert formatter.format_body(body=body, mime='json') == body

    if is_py26:
        body = '{u"a": u"a"}'
        assert formatter.format_body(body=body, mime='text') == body


# Generated at 2022-06-23 19:35:07.110111
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options == {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False,
        },
    }



# Generated at 2022-06-23 19:35:09.095666
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"answer": 42}', 'javascript') == '{\n    "answer": 42\n}'

# Generated at 2022-06-23 19:35:18.407028
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    # Test for valid JSON
    assert f.format_body(
        body='{"key1":"val1","key2":"val2","key3":"val3"}',
        mime='json') == '{\n    "key1": "val1",\n    "key2": "val2",\n' +\
        '    "key3": "val3"\n}'
    # Test for invalid JSON
    assert f.format_body(
        body='{"key1":"val1","key2":"val2","key3":"val3"}"',
        mime='json') == '{"key1":"val1","key2":"val2","key3":"val3"}"'
    # Test for valid JavaScript

# Generated at 2022-06-23 19:35:24.670231
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert isinstance(jf, JSONFormatter)
    assert isinstance(jf, FormatterPlugin)
    assert jf.format_options == {'json': {'format': False, 'indent': None, 'sort_keys': False}}
    assert jf.kwargs == {}
    assert jf.enabled == False


# Generated at 2022-06-23 19:35:34.260178
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Initialize objects
    formatter = JSONFormatter()
    is_exception = False

    # Case # 1: non-JSON response
    # Expected: no changes
    body = 'iii'
    mime = 'text/html'
    result = formatter.format_body(body, mime)

    # Assertion
    assert(body == result)

    # Case # 2: JSON response
    # Expected: JSON is formatted
    body = '{"aaa":123,"ccc":"...","bbb":"..."}'
    mime = 'application/json'
    result = formatter.format_body(body, mime)

    # Assertion
    assert(body != result)

    # Case # 3: 'explicit_json' parameter is true
    #           and the response is non-JSON
    # Expected

# Generated at 2022-06-23 19:35:41.984162
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    formatter = JSONFormatter({'json': {'format': True}})
    assert formatter.format_body('{"a": "b", "c": "d"}', 'json') == '{\n    "a": "b",\n    "c": "d"\n}'

    formatter = JSONFormatter({'json': {'format': False}})
    assert formatter.format_body('{"a": "b", "c": "d"}', 'json') == '{"a": "b", "c": "d"}'

    formatter = JSONFormatter({'json': {'format': True}})
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'

    formatter = JSONFormatter({'json': {'format': True}})
    assert form

# Generated at 2022-06-23 19:35:45.511121
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    kwargs = {'json': {'format': 'compact'},
              'explicit_json': True,
              'compact': False,
              'colors': False,
              'style': None}
    jsonFormatter = JSONFormatter(**kwargs)
    assert jsonFormatter.format_options['json']['format'] == 'compact'
    assert jsonFormatter.kwargs['explicit_json'] == True



# Generated at 2022-06-23 19:35:49.319660
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    global format_options
    format_options = {
        'json': {'format': True, 'indent': 4, 'sort_keys': True}
    }
    assert format_options['json']['format']
    assert format_options['json']['sort_keys']
    assert format_options['json']['indent'] == 4


# Generated at 2022-06-23 19:35:51.334140
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    actual_result = formatter.format_body('{"a":1,"b":2}', 'json')
    expected_result = '{\n  "a": 1, \n  "b": 2\n}'
    assert actual_result == expected_result

# Generated at 2022-06-23 19:36:02.975822
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs['explicit_json'] = False

    # Test for an empty string
    mime = 'json'
    body = ''
    assert json_formatter.format_body(body, mime) == '""'

    # Not JSON or JavaScript, ignore
    body = 'foo'
    mime = 'text/css'
    assert json_formatter.format_body(body, mime) == 'foo'

    # JSON containing invalid JSON
    body = '{"abc": "def"} foo'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{"abc": "def"} foo'

    # Valid JSON, but no explicit JSON format is set
    body = '{"abc": "def"}'


# Generated at 2022-06-23 19:36:06.919485
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.format_options['json']['indent'] == 8
    assert json_formatter.format_options['json']['sort_keys'] == False
    assert json_formatter.format_options['json']['format'] == True



# Generated at 2022-06-23 19:36:14.311096
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  import requests
  from httpie.client import HTTPie
  from httpie.plugins import FormatterPluginManager
  from httpie.context import Environment, EnvironmentConfig
  from httpie.cli.constants import DEFAULT_FORMAT, DEFAULT_JSON_INDENT, DEFAULT_JSON_SORT_KEYS
  client = HTTPie(formatter=FormatterPluginManager())
  conf = EnvironmentConfig()
  conf.default_options['json'] = {
      'format': True,
      'indent': DEFAULT_JSON_INDENT,
      'sort_keys': DEFAULT_JSON_SORT_KEYS,
  }

# Generated at 2022-06-23 19:36:15.739810
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.enabled


# Generated at 2022-06-23 19:36:20.535424
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False,
        }
    })
    assert formatter.format_body('{"name": "httpie"}', 'json') == '{\n  "name": "httpie"\n}'

# Generated at 2022-06-23 19:36:28.963663
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.formatters.json import JSONFormatter
    from httpie.compat import str
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    class DummyFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = False

    env = Environment(colors=256, stdin=None, stdout=None,
                      stderr=None, verify=True, debug=False,
                      headers=None, output_options=None, formatter_plugins=[
                          DummyFormatterPlugin()
                      ], output_file=None)
    jf = JSONFormatter(env=env)

    # Return body unchanged when Body is not JSON
    body = str('This is not JSON')
   

# Generated at 2022-06-23 19:36:32.160295
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter({'json' : {'format': True, 'indent': 2, 'sort_keys': False}})
    input = '{"test": "/test/", "a": 1, "b": "2"}'
    output = json_formatter.format_body(input, 'application/json')
    assert output == '{\n  "test": "/test/",\n  "a": 1,\n  "b": "2"\n}'


# Generated at 2022-06-23 19:36:33.798622
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()
    assert formatter_plugin is not None

# Generated at 2022-06-23 19:36:42.861812
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Case when body is valid JSON
    body1 = '{"name":"value1"}'
    assert body1 == JSONFormatter(explicit_json=True).format_body(body1, 'json; anything')
    # Case when body is not JSON
    body2 = 'anything'
    assert body2 == JSONFormatter(explicit_json=True).format_body(body2, 'json; anything')
    # Case when body is __not__ JSON but a HTML file
    body3 = '<html>any html code</html>'
    assert body3 == JSONFormatter(explicit_json=True).format_body(body3, 'html')
    # TODO: Add test cases for other branches
    # Case when body is __not__ JSON bu it is a text file
    # assert body3 == JSONFormatter(explicit_json=

# Generated at 2022-06-23 19:36:50.163388
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    kwargs = {'format_options': {'json': {'format': False, 'indent': 2, 'sort_keys': True}}, 'explicit_json': False}
    jsonFormatter = JSONFormatter(**kwargs)
    assert (jsonFormatter.format_options['json']['format']) == False
    assert (jsonFormatter.format_options['json']['indent']) == 2
    assert (jsonFormatter.format_options['json']['sort_keys']) == True
    assert (jsonFormatter.kwargs['explicit_json']) == False
    return


# Generated at 2022-06-23 19:36:51.971496
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    assert jf.enabled is True
    assert jf.format_options['json']['sort_keys'] is True



# Generated at 2022-06-23 19:36:54.672777
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    format_json = FormatterPlugin({'json': {'format': True}})
    format_json.format_body('{"foo": "bar"}', 'application/json') == '{u"foo": u"bar"}'

# Generated at 2022-06-23 19:37:03.568529
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': False
            },
        },
        explicit_json=False
    )
    assert j.enabled
    assert j.kwargs["explicit_json"] == False
    assert j.kwargs["format_options"] == {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False
        },
    }


# Generated at 2022-06-23 19:37:07.493794
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import mock

    format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    mock_config_dir = mock.Mock()
    mock_filename = mock.Mock()
    mock_config_dir.joinpath = mock.Mock(return_value=mock_filename)
    mock_kwargs = {'explicit_json': True}
    plugin = JSONFormatter(format_options=format_options,
                           config_dir=mock_config_dir,
                           **mock_kwargs)

    assert plugin.enabled is True
    assert plugin.format_options == format_options
    assert plugin.kwargs == mock_kwargs
    assert plugin.config_dir == mock_config_dir
    assert plugin.filename == mock_filename


# Generated at 2022-06-23 19:37:15.294187
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import JSONFormatter
    body = '[{u\'aaa\': 100, u\'bbb\': 200}, {u\'aaa\': 300, u\'bbb\': 400}]'
    mime = 'application/json'
    expected = '[{\n  "aaa": 100,\n  "bbb": 200\n}, {\n  "aaa": 300,\n  "bbb": 400\n}]'
    json_formatter = JSONFormatter(**{'format_options': {'json': {'sort_keys': False, 'indent': 2}},
                                         'explicit_json': True})
    output = json_formatter.format_body(body, mime)
    assert expected == output

# Generated at 2022-06-23 19:37:19.417472
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter({'json': {'format': False, 'sort_keys': True, 'indent': 4}})
    assert formatter.enabled == False
    formatter = JSONFormatter({'json': {'format': True, 'sort_keys': False, 'indent': 2}})
    assert formatter.enabled == True

# Generated at 2022-06-23 19:37:25.603118
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py3

    formatter = JSONFormatter()

    if is_py3:
        body_as_bytes = b'{"test": "\u0421\u0442\u0440\u043e\u043a\u0430"}'
    else:
        body_as_bytes = '{"test": "\xd0\xa1\xd1\x82\xd1\x80\xd0\xbe\xd0\xba\xd0\xb0"}'

    assert formatter.format_body(body_as_bytes.decode('utf-8'), 'json') == '{\n    "test": "Строка"\n}'

# Generated at 2022-06-23 19:37:36.829608
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import io
    import json
    import sys
    class MockStdout():
        def __init__(self):
            self.data = []
        def write(self, *args):
            self.data.append(args)

        def getvalue(self):
            return self.data

    stdout = MockStdout()
    sys.stdout = stdout

    body = {
        'data': 'foo',
        'data3': [1, 2, 3, 4]
    }

    mime = 'application/json'
    f = JSONFormatter(stdout = sys.stdout)
    f.format_body(json.dumps(body), mime)

# Generated at 2022-06-23 19:37:47.985425
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import JSONFormatter
    json_formatter = JSONFormatter()

    mime_type = 'application/json'
    # unindented json request body
    json_formatter.kwargs['explicit_json'] = False
    original_body = '{"foo":123,"bar":"baz","qux":"quux"}'
    assert json_formatter.format_body(body=original_body, mime=mime_type) == original_body

    # indented json request body
    json_formatter.kwargs['explicit_json'] = True
    indented_body = '{\n    "foo": 123,\n    "bar": "baz",\n    "qux": "quux"\n}'

# Generated at 2022-06-23 19:37:52.597670
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # arrange
    formatter = JSONFormatter()
    body = '''[
      {
        "id": 1,
        "name": "Object Name",
        "status" : "active"
      }
    ]'''

    # act
    result = formatter.format_body(body, 'json')

    # assert
    assert result == body

# Generated at 2022-06-23 19:38:02.570885
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '''
[
  {
    "employeeName": "Brett",
    "employeeCode": "E3",
    "employeeAge": "24"
  },
  {
    "employeeName": "Sara",
    "employeeCode": "E1",
    "employeeAge": "26"
  },
  {
    "employeeName": "Mark",
    "employeeCode": "E2",
    "employeeAge": "22"
  }
]'''

    json = JSONFormatter(format_options={
        "json": {
            "sort_keys": True,
            "indent": True,
        },
    })
    result = json.format_body(body, 'json')

# Generated at 2022-06-23 19:38:09.797972
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    unit test for method format_body of class JSONFormatter
    testing a normal json type
    :return:
    """
    test_json_format_json = json.dumps({'name': 'test', 'name2': 'test2'})
    formatter = JSONFormatter()
    output = formatter.format_body(test_json_format_json, 'json')
    assert output.find('\n') != -1

# Generated at 2022-06-23 19:38:19.453869
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.plugins
    import httpie.formatter
    import pprint

    # Remove all other formatters
    httpie.formatter.FORMATTERS = {'json': []}
    # Set the explicit_json parameter and the indent level
    httpie.plugins.FORMAT_OPTIONS['json']['explicit_json'] = True
    httpie.plugins.FORMAT_OPTIONS['json']['indent'] = 2

    # Create the JSONFormatter object
    json_formatter = JSONFormatter(httpie.plugins.FORMAT_OPTIONS)

    # Test some valid JSON strings

# Generated at 2022-06-23 19:38:29.296274
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    body = '{ "abc": 1, "bcd": 2, "cde": 3 }'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == body

    body = '{ "abc": 1, "bcd": 2, "cde": 3 }'
    mime = 'javascript'
    assert json_formatter.format_body(body, mime) == body

    body = '{ "abc": 1, "bcd": 2, "cde": 3 }'
    mime = 'text'
    assert json_formatter.format_body(body, mime) == body

    body = '"abc", "bcd", "cde"'
    mime = 'json'

# Generated at 2022-06-23 19:38:39.515415
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest
    from httpie.plugins.builtin import JSONFormatter
    from httpie.context import Environment
    from json import loads
    from os import environ
    from PyCurlClient.utils import install_env

    install_env(environ)
    env = Environment()

    json = {
        'one': '1',
        'two': ['2.1', '2.2'],
        'three': {
            '3.1': '3.2',
            '3.3': ['3.4', '3.5'],
        }
    }

    def get_formatter(json, body):
        formatter = JSONFormatter(env.color_style)
        formatter.kwargs = {'explicit_json': True}
        formatter.format_options = json

# Generated at 2022-06-23 19:38:46.927308
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert (
        '{\n  "a": 1,\n  "b": 2\n}' ==
        formatter.format_body(
            '{"a": 1, "b": 2}',
            'application/json'
        )
    )

    assert (
        '"normal string"' ==
        formatter.format_body(
            '"normal string"',
            'text/html'
        )
    )

    assert (
        '{\n  "a": 1,\n  "b": 2\n}' ==
        formatter.format_body(
            '{"a": 1, "b": 2}',
            'application/javascript'
        )
    )

    # Test `sort_keys` option

# Generated at 2022-06-23 19:38:51.378372
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py26

    # Prepare the test
    f = JSONFormatter()
    body = '{"hello": "world"}'
    mimes = ['json', 'text', 'javascript']

    # Execute the method under test
    result = f.format_body(body, mimes[0])

    # Check the result
    assert result == body

    # Execute the method under test
    result = f.format_body(body, mimes[1])

    # Check the result
    assert result == body

    # Execute the method under test
    result = f.format_body(body, mimes[2])

    # Check the result
    assert result == body

    # Execute the method under test
    result = f.format_body(body, 'html')

    # Check the result

# Generated at 2022-06-23 19:38:55.970279
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.context import Environment
    from httpie import __main__
    import json

    args = __main__.parser.parse_args(
        ['--json']
    )
    env = Environment(args)
    formatter = JSONFormatter(env.config)
    assert(formatter is not None)



# Generated at 2022-06-23 19:39:00.336602
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    plugin = JSONFormatter()
    assert plugin.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'


if __name__ == '__main__':
    import pytest
    pytest.main(['-vv', __file__])

# Generated at 2022-06-23 19:39:09.830152
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_json = JSONFormatter(explicit_json=False, compact=False,
                                   indent=4)
    assert formatter_json.explicit_json == False
    assert formatter_json.format_options['json']['format'] == False
    assert formatter_json.format_options['json']['sort_keys'] == False
    assert formatter_json.format_options['json']['indent'] == 4
    assert formatter_json.format_options['json']['explicit_json'] == False
    assert formatter_json.format_options['json']['compact'] == False


# Generated at 2022-06-23 19:39:18.629909
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = formatter.format_body(
        '{"a": 1, "b": null, "c": ["foo", "bar"]}',
        'application/json'
    )
    assert body == ('{\n'
                    '    "a": 1,\n'
                    '    "b": null,\n'
                    '    "c": [\n'
                    '        "foo",\n'
                    '        "bar"\n'
                    '    ]\n'
                    '}')

    formatter = JSONFormatter(explicit_json=True)
    body = formatter.format_body(
        'not json',
        'text/plain'
    )
    assert body == 'not json'

    formatter = JSONFormatter(explicit_json=True)


# Generated at 2022-06-23 19:39:22.233720
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    formatter = JSONFormatter()
    # Act
    result = formatter.format_body(
        '{"a": "b"}',
        'json'
    )    
    # Assert
    assert result == '{\n    "a": "b"\n}'


# Generated at 2022-06-23 19:39:24.811572
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter(format_options = {'json' : {'format' : 1, 'indent' : 2, 'sort_keys' : 1}})
    assert test.enabled == 1

# Generated at 2022-06-23 19:39:30.727770
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    data = {
        'Bool':True,
        'Int':2,
        'List':[2, 3]
    }
    assert JSONFormatter().format_body(json.dumps(data), 'json') == \
        json.dumps(data, sort_keys=False, ensure_ascii=False, indent=4)

# Generated at 2022-06-23 19:39:40.464164
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonformatter = JSONFormatter(format_options={'json':{'format':True}})
    assert jsonformatter.format_body(body='{"test": "test"}', mime='json') == '{\n\t"test": "test"\n}'
    assert jsonformatter.format_body(body='{"test": "test"}', mime='text') == '{\n\t"test": "test"\n}'
    assert jsonformatter.format_body(body='{"test": "test"}', mime='text/html') == '{"test": "test"}'
    assert jsonformatter.format_body(body='test', mime='text') == 'test'
    assert jsonformatter.format_body(body='test', mime='text/html') == 'test'
    assert jsonformatter.format

# Generated at 2022-06-23 19:39:50.051100
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 2
        }})

    json_str = '{ "name": "value" }'
    formatted_str = formatter.format_body(json_str, 'application/json')
    assert json_str != formatted_str
    assert formatted_str == '{\n  "name": "value"\n}'
    assert json.loads(formatted_str) == json.loads(json_str)

    non_json = 'not a json string'
    non_json_formatted = formatter.format_body(non_json, 'application/json')
    assert non_json_formatted == non_json


# Generated at 2022-06-23 19:39:56.430595
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json=False, output_options={'refresh_delay': 0.1}, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}, 'colors': {'colors': True, 'style': 'monokai', 'sort_keys': True}, 'format': 'colors'})
    assert json_formatter.format_body('{"id":"1","title":"httpie","url":"https://github.com/jkbrzt/httpie"}', 'application/json') == '{\n    "id": "1",\n    "title": "httpie",\n    "url": "https://github.com/jkbrzt/httpie"\n}'