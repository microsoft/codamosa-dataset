

# Generated at 2022-06-23 19:30:01.270503
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    p = JSONFormatter()
    assert p.__class__.__name__ == 'JSONFormatter'
    assert p.enabled is False
    assert p.kwargs == {}
    assert p.format_options == {'json': {'format': False, 'indent': 4, 'sort_keys': False}}

# Unit test: verify that the json plugin is enabled

# Generated at 2022-06-23 19:30:04.388596
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    # Create an instance of JSONFormatter() class
    formatter = JSONFormatter()
    # Get current value of variable 'JSONFormatter.enabled'
    assert formatter.enabled == False


# Generated at 2022-06-23 19:30:09.602336
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import sys

    json_string = """{"key": "value"}"""

    if sys.version_info >= (3, 0):
        json_string = json_string.encode()

    formatter = JSONFormatter()
    formatter.kwargs = {'explicit_json': True}

    result = formatter.format_body(json_string, 'json')

    assert json_string.decode('utf-8') == result

# Generated at 2022-06-23 19:30:14.339257
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()

    # Expected result
    expected_enabled = False
    expected_kwargs = {}

    # Verify outcomes
    assert formatter.enabled == expected_enabled
    assert formatter.kwargs == expected_kwargs


# Generated at 2022-06-23 19:30:15.794760
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    example = JSONFormatter()
    assert example is not None


# Generated at 2022-06-23 19:30:17.739744
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Test that the format_body function returns the body parameter unchanged
# when it is by default not a valid json string.

# Generated at 2022-06-23 19:30:24.359276
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin

    import json

    class JSONFormatter(FormatterPlugin):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['json']['format']

        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass # Invalid JSON, ignore.

# Generated at 2022-06-23 19:30:34.246344
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = "uhsfjvkbsdfjvb"
    mime = "json"
    new_body = formatter.format_body(body, mime)
    assert new_body == ""
    body = '{"id": "1", "name": "Dog"}'
    new_body = formatter.format_body(body, mime)
    assert new_body == '{\n    "id": "1",\n    "name": "Dog"\n}'
    body = '{"id": "1", "name": "Dog"}'
    new_body = formatter.format_body(body, mime)
    assert new_body == '{\n    "id": "1",\n    "name": "Dog"\n}'

# Generated at 2022-06-23 19:30:43.718944
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter({"verbose":1}, {"json":{"format":True, "indent": 2, "sort_keys": True}}).format_body("{\"cmd\":\"ls -l\"}", "application/json") == '{\n  "cmd": "ls -l"\n}'
    assert JSONFormatter({"verbose":1}, {"json":{"format":True, "indent": 2, "sort_keys": True}}).format_body("{\"cmd\":\"ls -l\"}", "text/plain") == '{\n  "cmd": "ls -l"\n}'

# Generated at 2022-06-23 19:30:47.433514
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['sort_keys'] == False
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['format'] == True
    assert formatter.kwargs['explicit_json'] == False


# Generated at 2022-06-23 19:30:57.299764
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # TODO: Extend for other cases
    RESPONSE_BODY = "{\"total\":2,\"items\":[{\"id\":1,\"name\":\"hello\",\"value\":42},{\"id\":2,\"name\":\"world\",\"value\":100}]}"
    RESPONSE_BODY_RESULT = '{\n    "items": [\n        {\n            "id": 1, \n            "name": "hello", \n            "value": 42\n        }, \n        {\n            "id": 2, \n            "name": "world", \n            "value": 100\n        }\n    ], \n    "total": 2\n}'
    format_options = {'json' : {'format' : True, 'sort_keys' : True, 'indent' : 4}}
    json_form

# Generated at 2022-06-23 19:31:00.657107
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    assert json_formatter.format_body(
        '{"key":"value"}',
        'application/json'
    ) == '{\n    "key": "value"\n}'
    assert json_formatter.format_body(
        'invalid-json',
        'text/html'
    ) == 'invalid-json'
    asse

# Generated at 2022-06-23 19:31:08.459219
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_dict = {
        "format": True,
        "indent": 4,
        "sort_keys": False,
        "explicit_json": False
    }
    formatter = JSONFormatter(format_options={"json": json_dict})
    assert formatter.enabled == True

    json_dict = {
        "format": False,
        "indent": 4,
        "sort_keys": False,
        "explicit_json": False
    }
    formatter = JSONFormatter(format_options={"json": json_dict})
    assert formatter.enabled == False


# Generated at 2022-06-23 19:31:11.490479
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(
        json={
            'format': False,
            'indent': 4,
            'sort_keys': False,
        }
    )

# Generated at 2022-06-23 19:31:19.985145
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    ret = JSONFormatter(explicit_json=False, force_json=False,
                        format_options={
                            'json': {
                                'format': True,
                                'sort_keys': True,
                                'indent': 4,
                            },
                            'colors': {
                                'header': 'blue',
                                'body': {
                                    'text': 'white',
                                    'binary': 'cyan',
                                },
                            },
                            'prettify': {
                                'all': True,
                                'body': True,
                                'minify': False,
                            },
                        })
    assert ret.enabled is True



# Generated at 2022-06-23 19:31:28.442013
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    FormatterPluginManager.load_all()
    fp = FormatterPluginManager.enabled_plugin_instances[0]
    assert fp.format_body('{"a": 1, "b": 2}', 'text/javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert fp.format_body('{"a": 1, "b": 2}', 'text/javascript') != '{\n    "a": 1,\n    "b": true\n}'

# Generated at 2022-06-23 19:31:31.396899
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body("{hello:\"world\"}", "application/json")

# Generated at 2022-06-23 19:31:40.324998
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Without indent
    json_formatter = JSONFormatter()
    json_formatter.format_options['json']['format'] = True
    json_formatter.format_options['json']['sort_keys'] = True
    json_formatter.format_options['json']['indent'] = None
    json_formatter.kwargs['explicit_json'] = True
    # Test with valid json
    body = '{"foo": "bar"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{"foo": "bar"}'
    # Test with invalid json
    body = '{"foo": "bar"} some text'
    mime = 'text'

# Generated at 2022-06-23 19:31:42.371767
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert (jsonFormatter.enabled == jsonFormatter.format_options['json']['format'])



# Generated at 2022-06-23 19:31:43.118486
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter().__init__()


# Generated at 2022-06-23 19:31:49.595367
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 1, "c": 2}'
    mime = 'json'
    fmt = JSONFormatter(format_options={'json': {
        'format': True,
        'indent': 2,
        'sort_keys': True,
    }})
    actual = fmt.format_body(body, mime)
    expected = '{\n  "a": 1, \n  "c": 2\n}'
    assert actual == expected

# Generated at 2022-06-23 19:32:01.169552
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.streams import NoOpStream
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.plugins import plugin_manager
    from httpie.context import Environment
    from httpie.compat import str

    args = parser.parse_args([])
    env = Environment(
        stdin=NoOpStream(),
        stdout=NoOpStream(),
        stderr=NoOpStream(),
        config_dir=None,
        options=args,
    )
    plugin_manager.load_internal_plugins()
    plugin_manager.load_external_plugins()

    active_plugins = list(plugin_manager.get_format(env))
    active_plugins[0].enabled = True

# Generated at 2022-06-23 19:32:09.934784
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Prepare unit test
    from httpie import ExitStatus

    class JSONFormatter_kargs:
        def __init__(self):
            self.__explicit_json = False
            self.__format_options = {
                'json' : {
                    'format' : True,
                    'indent' : 4,
                    'sort_keys' : True,
                },
            }

        @property
        def explicit_json(self):
            return self.__explicit_json

        @explicit_json.setter
        def explicit_json(self, explicit_json):
            self.__explicit_json = explicit_json

        @property
        def format_options(self):
            return self.__format_options

        @format_options.setter
        def format_options(self, format_options):
            self

# Generated at 2022-06-23 19:32:15.120910
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    test_body_1 = {'name': 'test'}
    test_body_1 = json.dumps(test_body_1)
    test_body_2 = {'name': 'te  st'}
    test_body_2 = json.dumps(test_body_2)

    assert json_formatter.format_body(test_body_1, '') != test_body_1
    assert json_formatter.format_body(test_body_2, '') != test_body_2

# Generated at 2022-06-23 19:32:20.422672
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': False
            }
        },
        explicit_json=True)
    body = '{"b": 10, "a": 11, "f": {"d": 3, "e": 2, "c": 1}}'

    assert json_formatter.format_body(body=body, mime='json') == '{\n    "b": 10,\n    "a": 11,\n    "f": {\n        "d": 3,\n        "e": 2,\n        "c": 1\n    }\n}'

# Generated at 2022-06-23 19:32:21.687709
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()

# Generated at 2022-06-23 19:32:25.191310
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    params = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    formatter_plugin = JSONFormatter(format_options=params)
    assert formatter_plugin.enabled
    assert formatter_plugin.format_options == params


# Generated at 2022-06-23 19:32:35.736010
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    maybe_json = [
        'json',
        'javascript',
        'text'
    ]
    body = """{"a": "b"}"""
    mime = "json"
    assert formatter.format_body(body, mime) is not body

    body = """{"a": "b"}"""
    mime = "text"
    assert formatter.format_body(body, mime) is not body

    body = """{"a": "b"}"""
    mime = "javascript"
    assert formatter.format_body(body, mime) is not body

    body = """{"a": "b"}"""
    mime = "abcdefg"
    assert formatter.format_body(body, mime) == body

    body = """{"a": "b"}"""


# Generated at 2022-06-23 19:32:42.278003
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': False, 'indent': 2}}, colors={'json': {'format': True, 'sort_keys': False, 'indent': 2}})
    assert formatter.kwargs['explicit_json'] == False
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['sort_keys'] == False
    assert formatter.format_options['json']['indent'] == 2

# Generated at 2022-06-23 19:32:51.948917
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    import pytest
    from plugins.json.json import JSONFormatter

    class args:
        output_options = {"style": "formatted"}
        explicit_json = False
        pretty = False
        headers = True
        all = True
        print_body = False
        print_headers = True
        print_cookies = True
        print_history = True
        style = [
            {"all": "red"},
            {"status": "blue"},
            {"redirect": "green"},
            {"error": "magenta"},
            {"headers": "yellow"},
            {"request": "bold cyan"},
            {"body": "cyan"},
            {"cookies": "yellow"},
            {"history": "cyan"}
        ]
        colors = True

# Generated at 2022-06-23 19:32:56.960576
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Assert that an HTTP response body containing JSON is formatted appropriately
    :return:
    """
    formatter = JSONFormatter()
    body = json.dumps({"key": "value"})
    assert formatter.format_body(body, 'application/json') == body
    assert formatter.format_body(body, 'application/json;charset=utf-8') == body
    assert formatter.format_body(body, 'application/javascript') == body
    assert formatter.format_body(body, 'text/javascript') == body
    assert formatter.format_body(body, 'text/plain') == body



# Generated at 2022-06-23 19:32:59.592767
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.kwargs == {}
    assert formatter.enabled == False
    assert formatter.format_options['json']['format'] == False


# Generated at 2022-06-23 19:33:08.067237
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'application/json'

    # Test for a valid JSON
    valid_json = """
    {
        "status": "OK",
        "name": "test"
    }
    """
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 0, 'sort_keys': False}})
    assert formatter.format_body(valid_json, mime) == """
    {
        "status": "OK",
        "name": "test"
    }
    """

    # Test for an invalid JSON (unclosed quotation mark)
    invalid_json = """
    {
        "status": "OK",
        "name": "test
    }
    """

# Generated at 2022-06-23 19:33:15.787638
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    form = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 3,
            'sort_keys': True
        }
    })
    body = '{"key": "value", "key2": false, "key3": null, "key4": ["a", "list"]}'
    assert form.format_body(body, 'json') == \
        '{\n' \
        '   "key": "value",\n' \
        '   "key2": false,\n' \
        '   "key3": null,\n' \
        '   "key4": [\n' \
        '      "a",\n' \
        '      "list"\n' \
        '   ]\n' \
        '}'

# Generated at 2022-06-23 19:33:22.192983
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"name":"nick"}', 'json') ==\
        '{\n    "name": "nick"\n}'
    assert json_formatter.format_body('{"name":"nick"}', 'html') == \
        '{"name":"nick"}'
    assert json_formatter.format_body("a", 'json') == "a"
    assert json_formatter.format_body("a", 'html') == "a"

# Generated at 2022-06-23 19:33:32.333130
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    obj = {
        "test": "works!",
        "httpie": "rocks!",
        "json": true
    }

    json_str = json.dumps(obj)
    json_bytes = json_str.encode("utf-8")
    json_formatter = JSONFormatter(format_options={
        "json": {
            "format": True,
            "sort_keys": True,
            "indent": 4,
        }
    })

    assert json_bytes == json_formatter.format_body(json_str, "json")

    rearranged_obj = {
        "httpie": "rocks!",
        "json": true,
        "test": "works!",
    }

    json_str = json.dumps(rearranged_obj)
    assert json_bytes == json_formatter

# Generated at 2022-06-23 19:33:41.047246
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # ansi support set to True but we do not use it
    a = JSONFormatter(None, False, True)
    # assert instance variables
    assert a.enabled == True
    a = JSONFormatter(None, True, True)
    assert a.enabled == True
    a = JSONFormatter(None, False, False)
    assert a.enabled == True
    a = JSONFormatter(None, True, False)
    assert a.enabled == True
    a = JSONFormatter(None, False, None)
    assert a.enabled == True
    a = JSONFormatter(None, True, None)
    assert a.enabled == False
    a = JSONFormatter(None, None, None)
    assert a.enabled == True
    a = JSONFormatter(None, None, False)
    assert a.enabled == True
    a

# Generated at 2022-06-23 19:33:51.811735
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print('start of test_JSONFormatter_format_body')
    # Test JSON
    json_str = """{"a":"b","c":"d","e":"f"}"""
    formatter = JSONFormatter(**{'explicit_json': True, 'format_options': {}})
    assert formatter.format_body(json_str, 'application/json') == json_str
    
    # Test non-JSON
    formatter = JSONFormatter(**{'explicit_json': False, 'format_options': {}})
    assert formatter.format_body(json_str, 'application/json') == json_str
    
    # Test non-JSON, not "application/json" mime
    assert formatter.format_body(json_str, 'application/xml') == json_str

# Generated at 2022-06-23 19:33:53.396367
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert not formatter.enabled


# Generated at 2022-06-23 19:33:58.114895
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    ''' Instantiate object of class JSONFormatterExplicit
    '''
    json_format_options = {'json' : {'sort_keys' : False,
                                     'indent' : 4,
                                     'format' : True}}
    assert JSONFormatter(format_options=json_format_options)


# Generated at 2022-06-23 19:34:02.064275
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4
            }
        }
    )
    assert json_formatter.enabled

# Generated at 2022-06-23 19:34:10.731670
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test example #1
    kwargs = {
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            },
            'colors': {
                'code': True,
            },
        },
        'explicit_json': False,
    }


# Generated at 2022-06-23 19:34:14.370938
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-23 19:34:25.534432
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    
    result = formatter.format_body(body='{"name": "Foo", "age": 20}', mime='application/json')
    expected = '{\n    "name": "Foo",\n    "age": 20\n}'
    assert result == expected

    result = formatter.format_body(body='{"name": "Foo", "age": 20}', mime='application/javascript')
    expected = '{\n    "name": "Foo",\n    "age": 20\n}'
    assert result == expected


# Generated at 2022-06-23 19:34:34.801628
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json=None)

# Generated at 2022-06-23 19:34:40.124830
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__name__ == 'JSONFormatter'
    assert JSONFormatter.__doc__ == '\n    Prepares the JSON output.\n\n    ' \
                                    'For convenience, set the environment\n    ' \
                                    'variable HTTPIE_JSON_INDENT with a number\n    ' \
                                    'to specify the number of spaces to indent\n    ' \
                                    'the JSON output.\n    '
    assert JSONFormatter.__module__ == 'httpie.plugins.json'

# Generated at 2022-06-23 19:34:43.171205
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': None,
                'sort_keys': False
            }
        },
        explicit_json=True
    )

# Generated at 2022-06-23 19:34:52.055407
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.context import Environment
    from httpie.output.streams import NoopStream
    from httpie.plugins import plugin_manager
    from httpie.formatters import JSONFormatter

    # Define output structure to test JSONFormatter against

# Generated at 2022-06-23 19:34:56.143494
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = {'json':{'format':'json', 'indent':4, 'sort_keys':True}},
        kwargs = {'explicit_json':True})
    assert 'json' in formatter.format_options['json']['format']
    assert 4 == formatter.format_options['json']['indent']
    assert True == formatter.format_options['json']['sort_keys']
    assert True == formatter.kwargs['explicit_json']
# test_JSONFormatter()



# Generated at 2022-06-23 19:35:05.857018
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from pytest import raises
    from httpie.plugins.json import JSONFormatter
    json_formatter = JSONFormatter(
        format_options={'explicit_json': False, 'json': {'format': True, 'indent': None, 'sort_keys': True}})
    assert json_formatter.format_body(body='{}\n', mime='JSON') == '{\n}\n'
    assert json_formatter.format_body(body='{ "b": [3, 4] }\n', mime='JSON') == '{\n    "b": [\n        3,\n        4\n    ]\n}\n'
    assert json_formatter.format_body(body='{}\n', mime='text/json') == '{\n}\n'
    assert json_formatter.format_body

# Generated at 2022-06-23 19:35:06.715118
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsformat = JSONFormatter()
    assert jsformat

# Generated at 2022-06-23 19:35:15.238846
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    instance = JSONFormatter()
    # 'text/html' and not explicit json
    body, mime = '{"a":[]}', 'text/html'
    assert instance.format_body(body, mime) == body
    # 'text/html' and explicit json
    body, mime = '{"a":[]}', 'text/html'
    assert instance.format_body(body, mime) == body
    # 'json' and not explicit json
    body, mime = '{"a":[]}', 'json'
    assert instance.format_body(body, mime) == '{\n    "a": []\n}'
    # 'json' and explicit json
    body, mime = '{"a":[]}', 'json'

# Generated at 2022-06-23 19:35:26.181624
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs = {
        'explicit_json': True
    }
    formatter.format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 2
        }
    }
    # Valid JSON
    assert formatter.format_body(body='{"key": "value", "key2": "value2"}', mime='json') == '{\n  "key": "value",\n  "key2": "value2"\n}'

    # Invalid JSON
    formatter.kwargs = {
        'explicit_json': False
    }

# Generated at 2022-06-23 19:35:28.203755
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.enabled



# Generated at 2022-06-23 19:35:38.397283
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Note: It should be json if that is the only format used
    formatter_one = JSONFormatter(only_format='json')
    assert formatter_one.enabled is True
    assert formatter_one.format_options['json']['format'] is True

    # Note: It should be json if that is one of the format used
    formatter_two = JSONFormatter(only_format='json,csv')
    assert formatter_two.enabled is True
    assert formatter_two.format_options['json']['format'] is True

    # Note: It should not be json if that is not one of the formats used
    formatter_three = JSONFormatter(only_format='csv')
    assert formatter_three.enabled is False
    assert formatter_three.format_options['json']['format'] is False




# Generated at 2022-06-23 19:35:44.237865
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 4
            }
        },
        explicit_json = False
    )

    assert jsonformatter.enabled == True
    assert jsonformatter.kwargs['explicit_json'] == False

# Generated at 2022-06-23 19:35:45.064419
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
        assert JSONFormatter()


# Generated at 2022-06-23 19:35:46.199328
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-23 19:35:47.948581
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options=dict(
            json=dict(
                enabled=True,
                format=False,
                sort_keys=True,
                indent=4
            )
        )
    )

    assert not formatter.enabled
    assert not formatter.kwargs['explicit_json']


# Generated at 2022-06-23 19:35:58.788950
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.plugins
    import json

    httpie.plugins.formatter_plugin_registry.remove(
        httpie.plugins.JSONFormatter
    )
    status, headers, content = httpie.plugins.JSONFormatter(None).format_body(
        '{"foo": "bar"}',
        'application/json; charset=utf-8'
    )
    assert status == 200
    assert headers == []
    assert content == json.dumps(
        obj={'foo': 'bar'},
        sort_keys=True,
        ensure_ascii=False,
        indent=4
    )
    httpie.plugins.formatter_plugin_registry.add(
        httpie.plugins.JSONFormatter
    )

test_JSONFormatter_format_body()

# Generated at 2022-06-23 19:36:02.916378
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    mime = 'json'
    body = '{"key": "value"}'

    # Print body as JSON
    assert formatter.format_body(body=body, mime=mime) == body

    # Print body as plain text
    mime='text'
    assert formatter.format_body(body=body, mime=mime) == body

# Generated at 2022-06-23 19:36:11.227414
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body("", "json") == ""
    assert JSONFormatter.format_body("a", "json") == "a"
    assert JSONFormatter.format_body("a", "image/png") == "a"
    assert JSONFormatter.format_body("a", "text/plain") == "a"
    assert JSONFormatter.format_body("a", "text") == "a"
    assert JSONFormatter.format_body('{"a": 1}', "json") == '{"a": 1}'
    assert JSONFormatter.format_body('{"a": 1, "b": [2, 3]}', "json") == '{\n    "a": 1,\n    "b": [\n        2,\n        3\n    ]\n}'

# Generated at 2022-06-23 19:36:12.885293
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False


                

# Generated at 2022-06-23 19:36:18.035601
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fmt = JSONFormatter(format_options={'json': {'format':True, 'sort_keys':True, 'indent':4}})
    assert fmt.format_options['json'] == {'format':True, 'sort_keys':True, 'indent':4}

# Generated at 2022-06-23 19:36:27.380009
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter({'json': {'format': True, 'indent': 0, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.kwargs == {}
    assert json_formatter.indent == 0
    assert json_formatter.sort_keys == True
    assert json_formatter.format_options == {'json': {'format': True, 'indent': 0, 'sort_keys': True}}

test_kwargs = {
    "format_options": {
        "json": {
            "format": True,
            "indent": 2,
            "sort_keys": False,
        }
    },
    "explicit_json": True,
}


# Generated at 2022-06-23 19:36:29.300344
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter(format_options)
    assert formatter_plugin.enabled == True


# Generated at 2022-06-23 19:36:34.358980
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter({'json': {'format': True}})
    formatted_text = formatter.format_body("""
        {
            "a": 1
        }
    """, 'application/json')

    expected = """
{
    "a": 1
}"""
    assert formatted_text == expected



# Generated at 2022-06-23 19:36:34.975073
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter

# Generated at 2022-06-23 19:36:43.547007
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-23 19:36:47.226900
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from .test_data import json_formatter_kwargs

    for kwargs in json_formatter_kwargs:
        f = JSONFormatter(**kwargs)
        assert type(f.enabled) == bool


# Generated at 2022-06-23 19:36:54.135998
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1: invalid JSON
    body = "This is not valid JSON"
    mime = 'json'
    formatter = JSONFormatter({'explicit_json': False}, {'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    assert formatter.format_body(body, mime) == body

    # Test 2: valid JSON, explicit_json
    body = '{"foo": "bar"}'
    mime = 'json'
    formatter = JSONFormatter({'explicit_json': True}, {'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    assert formatter.format_body(body, mime) == '{\n  "foo": "bar"\n}'

    # Test 3: valid JSON, not explicit_

# Generated at 2022-06-23 19:37:02.617301
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(explicit_json=True, format_options={
        'json': {
            'indent': 3,
            'format': True,
            'sort_keys': False,
        }
    })
    assert json_formatter.enabled is True, "The json formatter is not enabled"
    assert json_formatter.kwargs['explicit_json'] is True, "The explicit json is not set to true"
    assert json_formatter.format_options['json']['indent'] == 3
    assert json_formatter.format_options['json']['format'] is True
    assert json_formatter.format_options['json']['sort_keys'] is False

# Generated at 2022-06-23 19:37:08.034443
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    b = JSONFormatter()
    path = 'tests/plugins/json-formatter/test_data/test-body.json'
    with open(path, 'r') as f:
        input_body = f.read()
    output_body = b.format_body(input_body, '')

    path2 = 'tests/plugins/json-formatter/test_data/test-body-output.json'
    with open(path2, 'r') as f2:
        expected_body = f2.read()

    assert output_body == expected_body

# Generated at 2022-06-23 19:37:11.228614
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body(
        '{"a": "b"}',
        'application/json'
    ) == '\n{\n    "a": "b"\n}'

# Generated at 2022-06-23 19:37:16.482391
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    print('Unit test for constructor of class JSONFormatter')
    json_formatter = JSONFormatter()
    assert json_formatter.format_options == {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    }


# Generated at 2022-06-23 19:37:23.431597
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    json_bytes = b'{"a": "b"}'
    json_text = json_bytes.decode('utf8')
    assert JSONFormatter(format_options={
        'json': {
            'sort_keys': True,
            'indent': 2,
            'format': True,
        }}).format_body(
        body=json_bytes, mime='application/json') == json_text
    assert JSONFormatter(format_options={
        'json': {
            'sort_keys': True,
            'indent': 2,
            'format': True,
        }}).format_body(body=json_bytes, mime='text/plain') == json_text

# Generated at 2022-06-23 19:37:30.970359
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }})
    assert formatter.format_body(body='{"a": 1, "b": "hello world"}', mime='json') ==\
        '{\n  "a": 1, \n  "b": "hello world"\n}'
    assert formatter.format_body(body='{"a": 1, "b": "hello world"}', mime='javascript') ==\
        '{\n  "a": 1, \n  "b": "hello world"\n}'

# Generated at 2022-06-23 19:37:36.412340
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.enabled
    assert formatter.format_options['json']['format']

# Generated at 2022-06-23 19:37:41.070708
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with the json option enabled.
    kwargs = {
        'json': True,
        'explicit_json': True,
        'format_options': {
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 2
            }
        }
    }

    # Test with a valid json body.
    jsonString = '{"test": "json"}'
    formattedJsonString = '{\n  "test": "json"\n}'
    formatter = JSONFormatter(**kwargs)
    assert formatter.format_body(jsonString, 'application/json') == formattedJsonString

    # Test with an invalid json body.
    jsonString = '{"test: "json"}'
    formatter = JSONFormatter(**kwargs)
    assert form

# Generated at 2022-06-23 19:37:48.259893
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Not JSON mime-type.
    not_json_mime_type = "html"
    not_json_body = "some body"
    formatter_not_json_mime_type = JSONFormatter(explicit_json=False, json={"format": True, "indent": 2, "sort_keys": False})
    assert formatter_not_json_mime_type.format_body(not_json_body, not_json_mime_type) == not_json_body

    # JSON mime-type.
    json_mime_type = "json"
    json_body = "{ \"key1\": \"value1\" }"

# Generated at 2022-06-23 19:37:53.568712
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = FormatterPlugin(
        format_options = {
            'json': {
                'format': 'JSON',
                'indent': 0,
                'sort_keys': False
            }
        }
    )

    assert f.format_options['json']['format'] == 'JSON'

# Generated at 2022-06-23 19:37:57.146278
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    })
    assert j is not None
    assert j.enabled

# Generated at 2022-06-23 19:37:57.759095
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__init__

# Generated at 2022-06-23 19:38:02.099308
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    print('Testing JSONFormatter construction....')
    try:
        formatter = JSONFormatter()
    except:
        print('FAILED: An exception occurred whilst constructing an object of the JSONFormatter class.')
        return
    if not issubclass(type(formatter), JSONFormatter):
        print('FAILED: Construction of the JSONFormatter class returned an object which is not of type JSONFormatter.')
        return
    print('PASSED: Successfully constructed an object of the JSONFormatter class.')


# Generated at 2022-06-23 19:38:09.352708
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert(JSONFormatter(format_options = dict(json = dict(format=True, sort_keys=True, indent=4))).format_options['json']['format'] == True)
    assert(JSONFormatter(format_options = dict(json = dict(format=False, sort_keys=True, indent=4))).format_options['json']['format'] == False)


# Generated at 2022-06-23 19:38:14.776010
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}})

    assert formatter.kwargs == {}
    assert formatter.enabled == True
    assert formatter.format_options == {'json': {'format': True, 'indent': 2, 'sort_keys': False}}
    #assert formatter.metadata == {}


# Generated at 2022-06-23 19:38:17.469104
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=0, format_options={'json': {'format': 1, 'indent': 2, 'sort_keys': 3}})
    assert formatter.enabled == 1

# Generated at 2022-06-23 19:38:18.860390
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter is not None

# Generated at 2022-06-23 19:38:22.677281
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a = JSONFormatter(explicit_json=True, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}})
    assert a


if __name__ == "__main__":
    import pytest
    pytest.main()

# Generated at 2022-06-23 19:38:25.629584
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options = {})
    assert formatter.format_body('{"ok": true}', 'json') == '{\n    "ok": true\n}'

# Generated at 2022-06-23 19:38:34.415514
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body(b'{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert JSONFormatter().format_body(b'{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert JSONFormatter().format_body(b'{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert JSONFormatter().format_body(b'{"a": "b"}', 'image/jpeg') == '{"a": "b"}'

# Generated at 2022-06-23 19:38:37.803875
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    body = '{}'
    mime = 'application/json'
    actual = JSONFormatter().format_body(
        body=body,
        mime=mime,
    )
    expected = '{\n}'
    assert actual == expected

# Generated at 2022-06-23 19:38:46.151672
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.core import Formatter
    import json
    import os
    import sys

    python_version = sys.version_info
    if python_version.major < 3:
        json_dict = {'key1': 'value1', 'key2': 'value2'}
    else:
        json_dict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    # Create a dict to simulate the options used to create JSONFormatter (json_indent,
    # json_sort_keys, json_color, json_format)
    json_options = {
        "color": True,
        "format": True,
        "indent": 4,
        "sort_keys": True,
    }

    # Create a dict with the options used to create the Formatter instance

# Generated at 2022-06-23 19:38:57.588503
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    valid_json = '{"hello": "world"}'
    assert JSONFormatter().format_body(valid_json, "json") == valid_json
    assert JSONFormatter().format_body(valid_json, "javascript") == valid_json
    assert JSONFormatter().format_body(valid_json, "text/json") == valid_json
    assert JSONFormatter().format_body(valid_json, "Unknown") == valid_json
    assert JSONFormatter().format_body(valid_json, "Unknown; js") == valid_json

    invalid_json = '{{'
    assert JSONFormatter().format_body(invalid_json, "json") == invalid_json
    assert JSONFormatter().format_body(invalid_json, "javascript") == invalid_json

# Generated at 2022-06-23 19:39:02.962649
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	given_input = {'format_options': {'json': {'format': True, 'sort_keys': 'False', 'indent': '1'}},
					'kwargs': {'explicit_json': True}}
	result = JSONFormatter(**given_input).enabled
	expected_output = given_input['format_options']['json']['format']
	assert result == expected_output



# Generated at 2022-06-23 19:39:08.993869
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Successful (with an argument)
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    assert formatter.enabled is True
    # Successful (without any argument)
    formatter = JSONFormatter()
    assert formatter.enabled is 'on'


# Generated at 2022-06-23 19:39:12.782068
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    obj = json.loads('{"test": "test"}')
    body = json.dumps(
        obj=obj,
        sort_keys=True,
        ensure_ascii=False,
        indent=2
    )
    assert body == '{\n  "test": "test"\n}'

# Generated at 2022-06-23 19:39:21.787147
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(format_options={'json': {'format': True,
                                                  'indent': 2,
                                                  'sort_keys': True}},
                        explicit_json=True).format_body(
                            '{"test": "ok"}',
                            'application/json') == '{\n  "test": "ok"\n}'


# Generated at 2022-06-23 19:39:32.767391
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    # Test the most common case
    assert json_formatter.format_body(
        '{"x": 2, "y": 1}',
        'application/json') == '{\n    "x": 2,\n    "y": 1\n}'

    # Enable unicode escapes
    json_formatter.format_options['json']['unicode_escape'] = True
    assert json_formatter.format_body(
        '{"x": 2, "y": 1}',
        'application/json') == '{\n    "x": 2,\n    "y": 1\n}'

    # Disable sort-keys
    json_formatter.format_options['json']['sort_keys'] = False

# Generated at 2022-06-23 19:39:40.809380
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:39:41.813894
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    assert f.enabled == False

# Generated at 2022-06-23 19:39:43.524010
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled is True


# Generated at 2022-06-23 19:39:49.090952
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_options = {
        "json": {
            "format": True,
            "sort_keys": True,
            "indent": 2
        },
        "colors": {
            "enabled": True,
            "style": "auto"
        },
        "headers": {
            "enabled": True
        },
    }
    json_formatter = JSONFormatter(format_options=formatter_options, kwargs={})
    assert json_formatte

# Generated at 2022-06-23 19:39:52.714505
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    given = '''{
        "id": 1,
        "name": "Leanne Graham"
    }'''
    expected = '''{
    "id": 1,
    "name": "Leanne Graham"
}'''
    assert expected == formatter.format_body(given, 'json')



# Generated at 2022-06-23 19:39:58.525924
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'json'
    kwargs = {'explicit_json': True}
    formatter = JSONFormatter(**kwargs)

    # JSONFormatter.format_body
    # - Parameter:
    #   - body: a valid JSON string.
    #   - mime: the mime type of body.
    # - Expected output: the JSON string will be formatted
    # - Assertions: the return value of
    #   JSONFormatter.format_body matches the expected output
    body = '{"name": "httpie", "version": "0.9.9"}'
    maybe_json = [
        'json',
        'javascript',
        'text',
    ]