

# Generated at 2022-06-23 19:29:52.519903
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(
            format_options={'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }})

# Generated at 2022-06-23 19:29:54.516538
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter()

# Generated at 2022-06-23 19:30:01.400717
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Given
    formatter = JSONFormatter(**{
        'format_options': {'json': {'format': True, 'sort_keys': False, 'indent': 2}},
        'explicit_json': False
    })
    body = '{"name": "test"}'
    mime = 'json'
    # When
    result = formatter.format_body(body, mime)
    # Then
    assert result == '{\n  "name": "test"\n}'

# Generated at 2022-06-23 19:30:08.246614
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test if valid JSON is formatted correctly.
    body = '''{"a": 7, "b": "c"}'''
    mime = 'application/json'
    my_kwargs = {
        'json_indent': 2,
        'json_sort_keys': True,
        'explicit_json': True
    }
    my_format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    }
    json_formatter = JSONFormatter(
        format_options=my_format_options,
        kwargs=my_kwargs)
    result = json_formatter.format_body(body, mime)

# Generated at 2022-06-23 19:30:17.041961
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body(
        body='{"hello": "world"}',
        mime='application/json'
    ) == '{\n    "hello": "world"\n}'
    assert JSONFormatter(explicit_json=True).format_body(
        body='{"hello": "world"}',
        mime='text/html'
    ) == '{\n    "hello": "world"\n}'
    assert JSONFormatter().format_body(
        body='{"hello": "world"}',
        mime='text/html'
    ) == '{"hello": "world"}'

# Generated at 2022-06-23 19:30:26.394995
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formater = JSONFormatter()

    # Case 1: Invalid JSON
    body = '{"key": "value}'
    expected = '{"key": "value}'
    mime = 'application/json'
    actual = formater.format_body(body=body, mime=mime)
    assert actual == expected

    # Case 2: Valid JSON
    body = '{"key": "value"}'
    expected = '{\n    "key": "value"\n}'
    mime = 'application/json'
    actual = formater.format_body(body=body, mime=mime)
    assert actual == expected

    # Case 3: JSON that is not in specified mime-types
    body = '{"key": "value"}'
    expected = '{"key": "value"}'

# Generated at 2022-06-23 19:30:32.583841
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    js = JSONFormatter(
        format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}},
        kwargs={'explicit_json': False}
    )
    assert js.kwargs['explicit_json'] == False
    assert js.format_options['json'] == {'format': True, 'sort_keys': True, 'indent': 4}, 'JSONFormatter does not correctly return format options'


# Generated at 2022-06-23 19:30:37.652651
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert(JSONFormatter().format_body('{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}')
    assert(JSONFormatter().format_body('{"a": "b"}', 'text/plain') == '{\n    "a": "b"\n}')
    assert(JSONFormatter().format_body('{"a": "b"}', 'application/javascript') == '{\n    "a": "b"\n}')
    assert(JSONFormatter().format_body('{"a": "b"}', 'text/html') == '{"a": "b"}')
    assert(JSONFormatter().format_body('abc', 'text/html') == 'abc')

# Generated at 2022-06-23 19:30:42.828232
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # arrange
    body = '{"greeting": "Hello", "name": "world"}'
    mime = 'json'
    # act
    result = JSONFormatter.format_body(body, mime)
    # assert
    assert result == '{\n    "greeting": "Hello",\n    "name": "world"\n}'

# Generated at 2022-06-23 19:30:47.412154
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options = {"json":{"format":True, "indent":2, "sort_keys":False}}).enabled == True
    assert JSONFormatter(format_options = {"json":{"format":False, "indent":4, "sort_keys":False}}).enabled == False


# Generated at 2022-06-23 19:30:57.299755
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
  class MockHttpie(object):
    def __init__(self):
      self.explicit_json = False
      self.options = {
        'json': {
          'sort_keys': False,
          'indent': None,
        }
      }

  mime = 'application/javascript'
  body = '{"name": "John", "age": 30, "city": "New York"}'
  fp = JSONFormatter(MockHttpie())
  assert fp.format_body(body, mime) == '{"name": "John", "age": 30, "city": "New York"}'

  body = '{"name": "John", "age": 30, "city": "New York"}'
  fp = JSONFormatter(MockHttpie())

# Generated at 2022-06-23 19:31:00.415081
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.enabled
    assert jsonFormatter.format_options['json']['indent'] == 4
    assert jsonFormatter.format_options['json']['sort_keys'] == False
    assert jsonFormatter.format_options['json']['format'] == True
    assert jsonFormatter.kwargs['explicit_json'] == False

# Generated at 2022-06-23 19:31:03.973047
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
  f = FormatterPlugin()
  # valid JSON
  assert f.format_body('{"id":"123","name":"Bill"}', 'json') == '{\n    "id": "123",\n    "name": "Bill"\n}'

# Generated at 2022-06-23 19:31:14.439070
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    cli_args = {
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 0,
        }
    }
    kwargs = {}
    expected_body = '''{
    "arg1": [
        "val1",
        "val2"
    ],
    "arg2": [
        "val21",
        "val22"
    ]
}'''
    body = json.dumps(
        {
            "arg1": [
                "val1",
                "val2"
            ],
            "arg2": [
                "val21",
                "val22"
            ]
        }
    )
    json_formatter = JSONForm

# Generated at 2022-06-23 19:31:18.312292
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json=True)
    body = '''{"name":"foo","age":20,"gender":"male"}'''
    mime = 'application/json'
    formated_string = json_formatter.format_body(body, mime)
    assert formated_string == '''{
    "age": 20,
    "gender": "male",
    "name": "foo"
}'''

# Generated at 2022-06-23 19:31:25.641251
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_body_text = '''{
        "abc": 123
    }'''
    test_body_json = '''{
    "abc": 123
}'''
    
    test_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})

    assert test_formatter.format_body(test_body_text, 'text/json') == test_body_json

# Generated at 2022-06-23 19:31:34.109030
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    data = {
        "data": {
            "type": "request",
            "attributes": {
                "action": "send",
                "target": {
                    "type": "file",
                    "filename": "testing-httpie.json"
                },
                "headers": {
                    "Content-Type": "application/json"
                }
            }
        }
    }
    tester = JSONFormatter(kwargs={"explicit_json": False})
    mime = "text/plain"
    assert(tester.format_body(json.dumps(data), mime) == json.dumps(data))
    mime = "text/JSON"
    assert(tester.format_body(json.dumps(data), mime) == json.dumps(data))

# Generated at 2022-06-23 19:31:42.941823
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # JSONFormatter args
    format_options = {"json":{"format":True,"indent":2,"sort_keys":True}}
    kwargs = {"explicit_json":False}
    # Body to format
    body = '[ { "key": "value" }, { "key": "other value" } ]'
    mime = "json"

    # Create formatter
    formatter = JSONFormatter(format_options=format_options, kwargs=kwargs)
    # Execute method
    body = formatter.format_body(body=body, mime=mime)

    # Check that the body was formatted
    assert (body == '[\n  {\n    "key": "value"\n  },\n  {\n'
                   '    "key": "other value"\n  }\n]')

# Generated at 2022-06-23 19:31:49.457720
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter(format_options = {
        'verbose': False,
        'json': {
            'sort_keys': False,
            'indent': 4,
            'format': True
        },
        'headers': {
            'separator': ': ',
            'camel_case': False,
            'color': False
        }
    })
    assert test.enabled == True
    assert test.name == "json"


# Generated at 2022-06-23 19:32:01.133568
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test if method properly formats string
    json_formatter = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': False,
        }},
        explicit_json = False,
    )
    input_ = "{\"key1\": \"val1\"}"
    mime = "json"
    assert json_formatter.format_body(input_, mime) == '{\n    "key1": "val1"\n}'
    # Test if method does not improperly formats string

# Generated at 2022-06-23 19:32:09.935001
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    test_body = '{"foo": "bar"}'
    output = '{\n    "foo": "bar"\n}'
    assert formatter.format_body(test_body, 'application/json') == output

    test_body = '{"foo": "bar"}'
    output = '{\n    "foo": "bar"\n}'
    assert formatter.format_body(test_body, 'application/javascript') == output

    test_body = '{"foo": "bar"}'
    output = '{"foo": "bar"}'
    assert formatter.format_body(test_body, 'text/javascript') == output

    test_body = '{"foo": "bar"}'
    output = '{"foo": "bar"}'

# Generated at 2022-06-23 19:32:11.478692
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    arguments = {'json': {'indent': 4}}
    assert JSONFormatter(**arguments).format_options == {
        'json': {'sort_keys': False, 'indent': 4, 'format': False}}

# Generated at 2022-06-23 19:32:13.742312
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = FormatterPlugin()
    body = "{'foo': 'bar'}"
    mime = 'json'
    assert formatter.format_body(body, mime) == "{'foo': 'bar'}"
    body = '{"foo": "bar"}'
    assert formatter.format_body(body, mime) == "{\n    \"foo\": \"bar\"\n}"

# Generated at 2022-06-23 19:32:24.931403
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # 1st example, explicit JSON
    json_ftr = JSONFormatter(**{'explicit_json': True, 'format_options': {'json': {'format': True, 'sort_keys': True, 'indent': 2}}})
    body = '{"test": 123}'
    assert json_ftr.format_body(body, "json") == '{\n  "test": 123\n}'

    # 2nd example, implicit JSON
    json_ftr = JSONFormatter(**{'explicit_json': False, 'format_options': {'json': {'format': True, 'sort_keys': True, 'indent': 2}}})
    body = '{"test": 123}'

# Generated at 2022-06-23 19:32:35.355311
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass
    formatter = JSONFormatter()
    # dictionary
    d = {'a': 1, 'b': 2}
    n1 = formatter.format_body(d, 'json')
    assert n1 == '{\n    "a": 1,\n    "b": 2\n}'

    # dictionary
    d = {'a': 1, 'b': 2}
    n2 = formatter.format_body(d, 'javascript')
    assert n2 == '{\n    "a": 1,\n    "b": 2\n}'

    # dictionary
    d = {'a': 1, 'b': 2}
    n3 = formatter.format_body(d, 'application/json')
    assert n3 == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-23 19:32:42.049789
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	f = JSONFormatter(json= {
		'format': True,
		'indent': 4,
		'sort_keys': False
		},
	    explicit_json=False,
	    style='default')
	assert f.format_options['json']['format'] == True
	assert f.format_options['json']['indent'] == 4
	assert f.format_options['json']['sort_keys'] == False
	assert f.explicit_json == False
	assert f.style == 'default'
	

# Generated at 2022-06-23 19:32:51.756507
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-23 19:32:56.122543
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = FormatterPlugin.get_options(None)

    formatter = JSONFormatter(options)
    assert (formatter.kwargs == options['format'])
#print("Test passed")



# Generated at 2022-06-23 19:33:04.598696
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import json
    import logging
    import sys

    formatter = JSONFormatter()

    # Get rid of a noisy log entry from the HTTPie library.
    logging.getLogger('httpie.plugins.formatter.JSONFormatter').setLevel(
        logging.CRITICAL
    )

    # Test that JSONFormatter was created correctly.

# Generated at 2022-06-23 19:33:05.482755
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()


# Generated at 2022-06-23 19:33:06.004219
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass

# Generated at 2022-06-23 19:33:13.962348
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fmt = JSONFormatter()
    body = '{"a": ["b"]}'
    body_formatted = fmt.format_body(body=body, mime='json')
    assert body_formatted == '{\n    "a": [\n        "b"\n    ]\n}'
    body_formatted = fmt.format_body(body=body, mime='text')
    assert body_formatted == '{\n    "a": [\n        "b"\n    ]\n}'
    body_formatted = fmt.format_body(body=body, mime='text/plain')
    assert body_formatted == '{\n    "a": [\n        "b"\n    ]\n}'

# Generated at 2022-06-23 19:33:22.827588
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test not indent when indent argument is False
    _formatter = JSONFormatter(format_options={'json':{'format':False}})
    _json = '{"c": 3, "a": 1, "b": 2}'
    assert _json == _formatter.format_body(_json, 'application/json')

    # Test indent when indent argument is True
    _formatter = JSONFormatter(format_options={'json':{'format':True}})
    _json_indent = '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    assert _json_indent == _formatter.format_body(_json, 'application/json')


# Generated at 2022-06-23 19:33:23.829681
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-23 19:33:29.980456
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    from httpie import ExitStatus
    from utils import TestEnvironment, http, HTTP_OK

    env = TestEnvironment(stdin_isatty=True)
    r = http(
        'GET', 'http://httpbin.org/get',
        env=env,
    )
    assert HTTP_OK in r
    assert r.exit_status == ExitStatus.OK
    assert r.json == json.loads(r.text)

# Generated at 2022-06-23 19:33:40.848759
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            },
        },
        explicit_json=True,
    ).kwargs == {'explicit_json': True}

    assert JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            },
        },
        explicit_json=False,
    ).kwargs == {'explicit_json': False}


# Generated at 2022-06-23 19:33:45.905162
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter({'json': {'indent': 2, 'sort_keys': False, 'format': True}}, explicit_json=False)
    assert formatter.format_body('{"key": "value"}', 'json') == '{\n' \
                                                                '  "key": "value"\n' \
                                                                '}'
    assert formatter.format_body('{"key": "value"}', 'js') == '{\n' \
                                                              '  "key": "value"\n' \
                                                              '}'
    assert formatter.format_body('{"key": "value"}', 'text') == '{\n' \
                                                                '  "key": "value"\n' \
                                                                '}'
    assert formatter.format_body

# Generated at 2022-06-23 19:33:49.890881
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Unit test constructor of class JSONFormatter
    formatter = JSONFormatter({})
    assert formatter.format_options == {}
    assert formatter.enabled == False

# Generated at 2022-06-23 19:33:50.953832
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter()
    assert(j.enabled == False)


# Generated at 2022-06-23 19:34:01.530692
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for valid and invalid JSON.
    assert(JSONFormatter().format_body(body='{"foo": 1}', mime='text') == '{\n    "foo": 1\n}')
    assert(JSONFormatter().format_body(body='{"foo": 1', mime='text') == '{"foo": 1')
    # Test for explicit JSON.
    assert(JSONFormatter().format_body(body='{"foo": 2}', mime='text', explicit_json=True) == '{\n    "foo": 2\n}')
    # Test for JSON with sorting of keys.

# Generated at 2022-06-23 19:34:10.292006
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Test for case when json, javascript or text is in mime
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}}).format_body("""{"a": "1"}""", 'application/json') == """{
    "a": "1"
}"""
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}}).format_body("""{"a": "1"}""", 'application/javascript') == """{
    "a": "1"
}"""
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}}).format_body("""{"a": "1"}""", 'text/plain')

# Generated at 2022-06-23 19:34:18.516808
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fp = JSONFormatter(explicit_json=False, format_options=None)
    assert fp.format_body('[1,2,3]', 'json') == '[1,2,3]'
    assert fp.format_body('[1,2,3]', 'javascript') == '[1,2,3]'
    assert fp.format_body('[1,2,3]', 'text') == '[1,2,3]'
    assert fp.format_body('<html></html>', None) == '<html></html>'

# Generated at 2022-06-23 19:34:29.593869
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.input import ParseArgument
    from httpie.context import Environment
    environment = Environment(
        stdin=None, 
        stdout=None,
        stderr=None,
        stdin_isatty=None,
        stdout_isatty=None,
        stdout_is_redirected=None,
        config_dir=None,
        output_options=None,
        input_options=None,
        options=None,
        args=None)
    environment.output_options.stream = False
    environment.output_options.follow = False
    environment.output_options.continue_ = False
    environment.output_options.check_status = False
    environment.output_options.timeout = 10
    environment.output_options

# Generated at 2022-06-23 19:34:40.709133
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class JSONFormatter(FormatterPlugin):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['json']['format']

        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                    or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass  # Invalid JSON, ignore.

# Generated at 2022-06-23 19:34:43.097941
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Given
    formatter_plugin = JSONFormatter()

    # When
    result = formatter_plugin

    # Then
    assert result



# Generated at 2022-06-23 19:34:44.099791
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a = JSONFormatter()

# Generated at 2022-06-23 19:34:52.699785
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    json_input = b'{"a": "test"}'
    json_formatted = json.dumps(json.loads(json_input),indent=2, sort_keys = True)
    print("formatted json", json_formatted)
    # Test with json as content type
    env = http("--json=indent=2", "POST", "http://httpbin.org/post", body=json_input)
    assert env.status == ExitStatus.OK
    print("env.json: ", env.json)
    assert json.loads(json_formatted) == env.json
    # Test with unexpected content type

# Generated at 2022-06-23 19:35:02.465588
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from .utils import MockEnvironment
    from .utils import http
    format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4,
        },
    }
    env = MockEnvironment(
        stdin_isatty=False,
        stdout_isatty=False,
        format_options=format_options,
    )
    json_formatter = JSONFormatter(env=env)

    assert json_formatter.format_options['json']['format']
    assert json_formatter.format_options['json']['sort_keys']
    assert json_formatter.format_options['json']['indent'] == 4



# Generated at 2022-06-23 19:35:08.517326
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{"a": 1, "b": 2}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{"a": 1, "b": 2}'
    assert json_formatter.format_body('- abc', 'json') == '- abc'
    assert json_formatter.format_body('- abc', 'json') == '- abc'

# Generated at 2022-06-23 19:35:17.595837
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Unit test for method format_body of class JSONFormatter

    This test is designed to validate the correct behavior of method
    format_body of the class JSONFormatter.  This method is designed to
    format the body of a response stream to JSON.

    This method is called by the HTTPie program.

    Args:
        body: str. The body of the response to format.
        mime: str. The response's MIME type.

    Returns:
        body: str.  The formatted body of the response.
    """
    # Setup
    json_format = JSONFormatter()
    application_json = 'application/json'
    text_json = 'text/json'
    application_non_json = 'application/html'
    text_non_json = 'text/html'
    valid_json = '{"json": "valid"}'

# Generated at 2022-06-23 19:35:23.354182
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 4,
        },
    }
    formatter = JSONFormatter(format_options, {})
    assert formatter.enabled == True



# Generated at 2022-06-23 19:35:29.321126
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-23 19:35:31.698713
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a = JSONFormatter()
    assert a.format_options['json']['format'] == False


# Generated at 2022-06-23 19:35:35.812178
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = {
                                                'json':{
                                                        'format':True,
                                                        'indent':None,
                                                        'sort_keys':False
                }
                })
    assert formatter is not None


# Generated at 2022-06-23 19:35:41.346780
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    class MockFormatter(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.mock_kwargs = kwargs

    expected_kwargs = {
        'format_options': {
            'json': {
                'format': False,
                'indent': 2,
                'sort_keys': True
            }
        }
    }
    kwargs = expected_kwargs.copy()
    formatter = JSONFormatter(**kwargs)
    assert formatter.enabled == False



# Generated at 2022-06-23 19:35:45.418433
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import pytest
    from httpie.plugins import FormatterPlugin

    fixture = dict(
        json=dict(
            indent=4,
            sort_keys=True,
            format=False
        )
    )
    json_formatter = JSONFormatter(format_options=fixture, explicit_json=None)
    assert json_formatter.enabled == False
    assert json_formatter.format_options["json"]["indent"] == 4
    assert json_formatter.format_options["json"]["sort_keys"] == True
    assert isinstance(json_formatter, FormatterPlugin)

# Unit tests for format_body override method

# Generated at 2022-06-23 19:35:46.549485
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    result = JSONFormatter()
    assert result.kwargs == {}

# Generated at 2022-06-23 19:35:53.112210
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    result = dict(
        headers={},
        content='{"id": 1, "name": "John Doe"}',
        status_code=200,
        reason_phrase='')
    # Define a json object to compare with the result object
    json_obj = dict(
        status_code=200,
        content=result['content'],
        headers=result['headers'],
        reason_phrase='')

    json_plugin = FormatterPlugin()
    assert json_plugin.format_body(**result) == json.dumps(json_obj)

    json_plugin = JSONFormatter(
        format_options=dict(json={
            'format': False,
            'indent': 4,
            'sort_keys': True
        })
    )

# Generated at 2022-06-23 19:36:03.352079
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    response = json.dumps({'status': 'error'})
    json_formatter = JSONFormatter(kwargs={}, format_options={'json': {'format': False, 'sort_keys': False, 'indent': 4, 'explicit': False}})
    assert json_formatter.format_body(response, 'application/json') == response

    response = json.dumps({'status': 'error'})
    json_formatter = JSONFormatter(kwargs={}, format_options={'json': {'format': True, 'sort_keys': False, 'indent': 4, 'explicit': False}})
    assert json_formatter.format_body(response, 'application/json') == json.dumps({'status': 'error'}, indent=4, ensure_ascii=False)

    response = json.d

# Generated at 2022-06-23 19:36:08.606050
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import pytest
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.json import JSONFormatter

    test_input = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }
    test = JSONFormatter(**test_input)
    assert isinstance(test, JSONFormatter)


# Generated at 2022-06-23 19:36:19.959096
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True,
                                                       'sort_keys': True,
                                                       'indent': 2}})
    assert formatter.format_body('{"a": 2, "b": 1}', 'json') == '{\n  "a": 2, \n  "b": 1\n}'

    formatter = JSONFormatter(format_options={'json': {'format': True,
                                                       'sort_keys': True,
                                                       'indent': 0}})
    assert formatter.format_body('{"a": 2, "b": 1}', 'json') == '{"a":2,"b":1}'


# Generated at 2022-06-23 19:36:20.918566
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__init__

# Generated at 2022-06-23 19:36:25.098851
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    js = JSONFormatter(format_options={'json':{"format": True, "sort_keys": False, "indent": 2}})

# Generated at 2022-06-23 19:36:28.034251
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    print("Test JSONFormatter")
    json_format = JSONFormatter()
    assert json_format.enabled == True
    print("Unit test for constructor of class JSONFormatter PASSED")


# Generated at 2022-06-23 19:36:28.633777
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-23 19:36:31.235792
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body("{\"foo\": 1}", "json") == "{\"foo\": 1}"
    assert JSONFormatter().format_body("{\"foo\": 1}", "javascript") == "{\"foo\": 1}"
    assert JSONFormatter().format_body("{\"foo\": 1}", "text") == "{\"foo\": 1}"


# Generated at 2022-06-23 19:36:39.394329
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  # Test:
  #     def __init__(self, **kwargs):
  #         super().__init__(**kwargs)
  #         self.enabled = self.format_options['json']['format']
  # for docstring:
  #     JSONFormatter(FormatterPlugin)
  # for source code:
  #     class JSONFormatter(FormatterPlugin):
  #         def __init__(self, **kwargs):
  #             super().__init__(**kwargs)
  #             self.enabled = self.format_options['json']['format']
  assert JSONFormatter


# Generated at 2022-06-23 19:36:40.870042
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json':{'format': True}}).enabled

# Generated at 2022-06-23 19:36:45.431044
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        JSONFormatter(**{
            'format_options': {
                'json': {
                    'format': True,
                    'indent': 2,
                    'sort_keys': False
                }
            },
            'explicit_json': True
        })
    except Exception as e:
        assert False
    else:
        assert True


# Generated at 2022-06-23 19:36:53.370659
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    def format_body(body, mime):
        return JSONFormatter().format_body(body, mime)


# Generated at 2022-06-23 19:37:02.938864
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.input import ParseResult
    from pytest import fixture


# Generated at 2022-06-23 19:37:05.182047
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a = JSONFormatter(format_options={'json':{'format':None, 'sort_keys':None, 'indent':None}})
    assert a.enabled == None



# Generated at 2022-06-23 19:37:11.017049
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import json
    import os
    import httpie.plugins
    from httpie.plugins import FormatterPlugin

    httpie.plugins.__all__.append('test_JSONFormatter')
    test_json_formatter = JSONFormatter()
    assert type(test_json_formatter) == JSONFormatter


# Generated at 2022-06-23 19:37:14.776453
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a = JSONFormatter({'json': {'format': True, 'indent': 1, 'sort_keys': True}})
    assert a.enabled == True


# Generated at 2022-06-23 19:37:21.602198
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    body = '''{"hello": "world"}'''
    assert formatter.format_body(body=body, mime='json') == body

    body = '''[{"hello": "world"}]'''
    assert formatter.format_body(body=body, mime='json') == body

    body = '''{'hello': 'world'}'''
    assert formatter.format_body(body=body, mime='json') == body

    body = '''['hello', 'world']'''
    assert formatter.format_body(body=body, mime='json') == body

# Generated at 2022-06-23 19:37:24.206790
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        formatter = JSONFormatter()
        assert True
    except:
        assert False


# Generated at 2022-06-23 19:37:25.599741
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter({})
    assert isinstance(formatter, JSONFormatter)
    assert formatter is not None

# Generated at 2022-06-23 19:37:26.086839
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-23 19:37:37.223676
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    def make_mock_kwargs():
        return {
            'explicit_json': False,
            'formatted_response': False,
            'headers': False,
            'json': {'format': True},
            'pretty': False,
            'stream': False,
            'style': {'colors': True},
        }
    def make_mock_format_options():
        return json.loads('''
{
    "json": {
        "format": true,
        "indent": 4,
        "sort_keys": true
    }
}
        ''')
    def make_mock_args():
        return type('', (), {})()

# Generated at 2022-06-23 19:37:48.055053
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['format'] == True
# TEST: http --format json --json.indent 3 --json.sort-keys false --json.format false
# TEST: http --format json --json.indent 3 --json.sort-keys false --json.format true
# TEST: http --format json --json.indent 3 --json.sort-keys true --json.format false
# TEST: http --format json --json.indent 3 --json.sort-keys true --json.format true
# TEST: http --json.indent 3 --json.sort-keys false --json.format false
# TEST: http --json

# Generated at 2022-06-23 19:37:59.562439
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from mock import Mock
    from httpie import ExitStatus
    from httpie.cli import CLIConfig, CLIResponse
    from httpie.plugins import FormatterPlugin

    # Fake data for unit test
    fake_body = '{"fake": "body"}'
    fake_json = json.loads(fake_body)
    fake_mime = 'application/json'
    fake_kwargs = {
        'explicit_json': False,
        'format_options': {
            'json': {
                'format': True,
                'indent': None,
                'sort_keys': False,
            }
        },
    }
    fake_stdin = Mock()
    fake_stdin.isatty.return_value = False
    # Fake class

# Generated at 2022-06-23 19:38:04.268437
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    settings = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': True
        },
    }
    formatter = JSONFormatter(format_options=settings)
    assert formatter.enabled
    assert formatter.format_options['json']['format']
    assert formatter.format_options['json']['sort_keys']
    assert formatter.format_options['json']['indent']

# Generated at 2022-06-23 19:38:09.666758
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{ "key": "value" }', 'application/json') == '{\n    "key": "value"\n}'
    assert formatter.format_body('{ "key": "value" }', 'text/html') == '{ "key": "value" }'

# Generated at 2022-06-23 19:38:19.374113
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # given
    dummy_format_options = {'json': { 'format' : True, 'indent' : 4, 'sort_keys' : False }}
    dummy_kwargs = {}
    json_formatter = JSONFormatter(
            format_options = dummy_format_options,
            kwargs = dummy_kwargs
        )
    # when

# Generated at 2022-06-23 19:38:26.999781
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}},
                       explicit_json=False,
                       colors=0)

    import os
    script = os.path.abspath(os.path.dirname(__file__))
    fh = open(script + '/../../../../examples/data/test.json')
    string = fh.read()

    assert(jf.format_body(string, 'text') == '{\n    "key": "value"\n}')

# Generated at 2022-06-23 19:38:35.257363
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    JSONFormatter = FormatterPlugin({'json': {'format': True, 'indent': 4, 'sort_keys': True}}, {'explicit_json': False})
    formatter = JSONFormatter()
    assert formatter#.format_body('{"a": "A", "b": "B", "c": "C"}', 'json') == '{\n    "a": "A",\n    "b": "B",\n    "c": "C"\n}'


# Generated at 2022-06-23 19:38:37.190389
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter(format_options={'json':{'format':True, 'indent':4, 'sort_keys':True}})

# Generated at 2022-06-23 19:38:45.775673
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4,
            }
        },
        explicit_json=False
    )
    json_body = '''
                {
                    "compact": false,
                    "schema": "https://json-schema.org/draft/2019-09/schema",
                    "value": 20
                }
                '''
    json_body_after_formatting = '''\
{
    "compact": false,
    "schema": "https://json-schema.org/draft/2019-09/schema",
    "value": 20
}
'''

# Generated at 2022-06-23 19:38:55.123064
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    format_options = {
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 4,
        },
    }
    kwargs = {
        'explicit_json': True
    }
    json_formatter = JSONFormatter(format_options, **kwargs)
    body = json_formatter.format_body('{"key1": "value1"}', 'application/json')
    assert body == '{\n    "key1": "value1"\n}', 'format_body method of class JSONFormatter is not working correctly'

# Generated at 2022-06-23 19:39:04.631443
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': 3,
            'sort_keys': True}
    })
    assert f.format_body('{"b": "b"}', "application/json") == '{\n   "b": "b"\n}'
    assert f.format_body('{"b": "b"}', "application/wrong") == '{"b": "b"}'
    assert f.format_body('{"b": "b"}', "application/invalid-json") == '{"b": "b"}'
    assert f.format_body('{"b": "b"', "application/invalid-json") == '{"b": "b"'

# Generated at 2022-06-23 19:39:09.746964
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # arrange
    body = '{"temp": 10, "humid": 75}'
    mime = 'application/json'
    # act
    formatted_body = JSONFormatter().format_body(body, mime)
    # assert
    assert formatted_body == '{\n    "humid": 75,\n    "temp": 10\n}'

# Generated at 2022-06-23 19:39:18.596779
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import json
    from collections import namedtuple
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.compat import str, is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    # The namedtuple class is provided by the collections module.
    # It returns a subtype of tuple.
    # The arguments are the names of the fields.
    # The field's values are passed as arguments to the constructor.
    # The field names are also the instance variables.
    # The name tuple is not a reserved word in Python.

    # The namedtuple function returns a subclass of 'tuple' which has been given
    # names for each of the elements in the tuple.
    #

# Generated at 2022-06-23 19:39:22.589233
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': None,
            'sort_keys': False
        }
    }, explicit_json=False)
    assert str(formatter) == 'JSONFormatter'
    assert formatter.kwargs == {'format_options': {'json': {'format': True, 'indent': None, 'sort_keys': False}}, 'explicit_json': False}
    assert formatter.enabled == True


# Generated at 2022-06-23 19:39:23.834817
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-23 19:39:34.816374
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = FormatterPlugin({'json': {'format': False, 'sort_keys': False, 'indent': 2}})
    try:
        f.format_body('{}', 'application/json')
    except AttributeError:
        assert True
    else:
        assert False
    
    f = FormatterPlugin({'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert f.format_body('{}', 'application/json') == '{\n    \n}'
    
    f = FormatterPlugin({'json': {'format': True, 'sort_keys': True, 'indent': 4}})

# Generated at 2022-06-23 19:39:37.664729
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        from httpie.plugins import JSONFormatter
        bef = JSONFormatter()
        assert bef
    finally:
        del sys.modules['httpie.plugins']

# Generated at 2022-06-23 19:39:45.408358
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"id": "foo", "x": "bar"}'
    mime = 'json'
    options = json.loads(
        '{"json": {"indent": 2, "format": true, "sort_keys": true}}')
    formatter = JSONFormatter(format_options=options,
                              explicit_json=False)
    result = formatter.format_body(body, mime)
    expect = '{\n  "id": "foo",\n  "x": "bar"\n}'
    assert result == expect


# Generated at 2022-06-23 19:39:52.030989
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        }
    )
    assert jf.enabled

    body = '[{"a": 3, "b": 2, "c": 1}]'
    mime = 'application/json'

    def assert_json_equal(json1, json2):
        assert json.loads(json1) == json.loads(json2)

    assert_json_equal(
        jf.format_body(body, mime),
        '[\n  {\n    "a": 3,\n    "b": 2,\n    "c": 1\n  }\n]'
    )

    body = "a: b\nc: d"
   