

# Generated at 2022-06-25 18:49:41.804611
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()

    if True:
        assert (j_s_o_n_formatter.format_body('', mime='')) == ''
    if True:
        assert (j_s_o_n_formatter.format_body(
            '{"valid": "json"}', mime='json')) == '{\n    "valid": "json"\n}'
    if True:
        assert (j_s_o_n_formatter.format_body(
            '{"valid": "json"}', mime='invalid')) == '{"valid": "json"}'
    if True:
        assert (j_s_o_n_formatter.format_body(
            'invalid json', mime='json')) == 'invalid json'

# Generated at 2022-06-25 18:49:51.220962
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import TestEnvironment, http
    from json import dumps
    from collections import OrderedDict
    from utils_test import TestHTTPIE
    from httpie import ExitStatus
    from utils import http, TestEnvironment
    from fixtures import BIN_DIRECTORY
    from httpie.compat import is_windows
    args = TestHTTPIE([
        '--json',
        '--json-sort-keys',
        '--json-indent=2',
        '--pretty=all',
        BIN_DIRECTORY + '/request.http',
    ]).parser.parse_args()
    env = TestEnvironment(args=args)
    json_content_0 = '{"hello": "world"}'
    json_formatter_0 = JSONFormatter()
    response_0 = json_

# Generated at 2022-06-25 18:50:02.445383
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Case 0
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = "[1, 2, 3, 4]"
    mime_0 = "json"
    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) == "[\n  1, \n  2, \n  3, \n  4\n]"
    # Case 1
    j_s_o_n_formatter_1 = JSONFormatter()
    body_1 = "{\n  \"key\": [1, 2, 3, 4]\n}"
    mime_1 = "json"

# Generated at 2022-06-25 18:50:08.388026
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    with open('./tests/formatting_tests/json_formatter_tests.json', 'r') as json_file:
        unit_tests = json.load(json_file)

    for test in unit_tests:
        j_s_o_n_formatter_1 = JSONFormatter(output_options=test['output_options'])
        assert j_s_o_n_formatter_1.format_body(test['args'][0], test['args'][1]) == test['ret']

# Generated at 2022-06-25 18:50:10.392263
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    j_s_o_n_formatter.format_body()

# Generated at 2022-06-25 18:50:15.723435
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a":1}'
    mime = None
    j_s_o_n_formatter_test_0 = JSONFormatter()
    try:
        assert j_s_o_n_formatter_test_0.format_body(body, mime) == '{' + '\n' + '    "a": 1' + '\n' + '}'
    except AssertionError:
        raise AssertionError('Test of method format_body of class JSONFormatter failed')


# Generated at 2022-06-25 18:50:18.703794
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_arg_0 = 'abc'
    str_arg_1 = 'def'
    assert j_s_o_n_formatter_0.format_body(str_arg_0,str_arg_1) == 'abc'


# Generated at 2022-06-25 18:50:24.617765
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    j_s_o_n_formatter_0: JSONFormatter = JSONFormatter()
    j_s_o_n_formatter_0.kwargs: dict = {}
    j_s_o_n_formatter_0.kwargs['explicit_json']: bool = False
    j_s_o_n_formatter_0.format_options: dict = {}
    j_s_o_n_formatter_0.format_options['json']: dict = {}
    j_s_o_n_formatter_0.format_options['json']['sort_keys']: bool = True
    j_s_o_n_formatter_0.format_options['json']['indent']: int = 2

# Generated at 2022-06-25 18:50:30.150724
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body_0 = 'body'
    mime_0 = 'mime'
    json_object_0_0 = j_s_o_n_formatter_1.format_body(body_0, mime_0)
    assert json_object_0_0 == '"body"'


# Generated at 2022-06-25 18:50:41.284032
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    #
    #  Args:
    #      body (str): the response body.
    #
    #  Returns:
    #      str: the response body formatted with JSON.
    #
    j_s_o_n_formatter_0 = JSONFormatter()
    body = "body"
    mime = "mime"
    body1 = ""
    mime1 = ""
    body2 = "{}"
    mime2 = "text"

    if (j_s_o_n_formatter_0.format_body(body=body, mime=mime) == body):
        print("passed")
    else:
        print("failed")


# Generated at 2022-06-25 18:50:48.788248
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 18:51:00.470602
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Parameters of method format_body
    # body: str
    # mime: str
    # Invoke the method
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_2 = JSONFormatter()
    j_s_o_n_formatter_3 = JSONFormatter()
    j_s_o_n_formatter_4 = JSONFormatter()
    j_s_o_n_formatter_5 = JSONFormatter()
    j_s_o_n_formatter_6 = JSONFormatter()
    j_s_o_n_formatter_7 = JSONFormatter()
    j_s_o_n_formatter_8 = JSONFormatter()

# Generated at 2022-06-25 18:51:06.675353
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Basic test of method format_body of class JSONFormatter
    from httpie.formatters.json import JSONFormatter
    j_s_o_n_formatter_0 = JSONFormatter()
    str_0 = j_s_o_n_formatter_0.format_body((str(89) * 19), 'application/json')
    assert str_0 == '{"a": "b"}', 'Expected different value for str_0'


# Generated at 2022-06-25 18:51:10.388659
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = '{"test": "value"}'
    mime = 'test_value'
    assert j_s_o_n_formatter_0.format_body(body, mime) == '{\n    "test": "value"\n}'

# Generated at 2022-06-25 18:51:21.541519
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # unit_test_case_method_parameters_0 = (
    #     j_s_o_n_formatter_0.format_body,
    #     'body',
    #     'mime'
    # )
# #
# # # print("Unit test for method format_body of class JSONFormatter")
# # # print("Parameters:")
# # # print("body", "mime")
# # # print("Expected: A formatted body")
# # # print("Received:", j_s_o_n_formatter_0.format_body("body", "mime"))
# # # print("\n")
#
# # Unit test for method __init__ of class JSONFormatter

# Generated at 2022-06-25 18:51:25.778035
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_0 = '"text/html";charset=utf-8'
    mime_0 = ''
    assert JSONFormatter.format_body(body_0, mime_0) == '"text/html";charset=utf-8'


# Generated at 2022-06-25 18:51:33.696235
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case for attribute json.
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.json.get('format') == True
    assert j_s_o_n_formatter_1.json.get('indent') == 4
    assert j_s_o_n_formatter_1.json.get('sort_keys') == True
    assert j_s_o_n_formatter_1.json.get('explicit_json') == False
    j_s_o_n_formatter_2 = JSONFormatter(explicit_json=True)
    assert j_s_o_n_formatter_2.json.get('explicit_json') == True


# Generated at 2022-06-25 18:51:38.362496
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test data.
    body = "a string"
    mime = "text/plain"
    
    # Call the function being tested.
    result = JSONFormatter.format_body(JSONFormatter, body, mime)
    
    # Check the result.
    assert result == "a string"

# Generated at 2022-06-25 18:51:40.560970
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_body()


# Generated at 2022-06-25 18:51:42.767802
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime_0 = 'json'
    body_0 = '{"foo": "bar"}'
    json_formatter_0 = JSONFormatter()
    output_0 = json_formatter_0.format_body(body_0, mime_0)
    assert output_0 == body_0

# Generated at 2022-06-25 18:52:00.098063
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body('', 'text/xml') == ''
    assert j_s_o_n_formatter_0.format_body('', 'text/xml; charset=utf8') == ''
    assert j_s_o_n_formatter_0.format_body('', 'text/json') == ''
    assert j_s_o_n_formatter_0.format_body('', 'text/javascript; charset=utf8') == ''
    assert j_s_o_n_formatter_0.format_body('', 'text/plain') == ''

# Generated at 2022-06-25 18:52:02.041895
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert callable(JSONFormatter)

# Generated at 2022-06-25 18:52:02.626633
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter

# Generated at 2022-06-25 18:52:05.442795
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_body(body, mime)


# Generated at 2022-06-25 18:52:15.477761
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # If the input is a valid JSON object, it should be pretty-printed.
    # If it is not a valid JSON object, it should be left as-is.
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body("{\"name\": \"foo\", \"age\": 42}", '') == '{\n  "age": 42, \n  "name": "foo"\n}'
    assert j_s_o_n_formatter_0.format_body("{\"name\": \"foo\", \"age\": 42}", 'json') == '{\n  "age": 42, \n  "name": "foo"\n}'

# Generated at 2022-06-25 18:52:22.445450
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # Test with normal json data
    body_0 = '{"foo": 1, "bar": "a"}'
    mime_0 = 'json'
    expected_0 = '{\n    "bar": "a",\n    "foo": 1\n}'
    formatted_body_0 = j_s_o_n_formatter_0.format_body(body_0, mime_0)
    assert(formatted_body_0 == expected_0)
    # Test with unicode json data
    body_1 = '{"currency": "R$"}'
    mime_1 = 'json'
    expected_1 = '{\n    "currency": "R$"\n}'
    formatted_body_1 = j_s_o

# Generated at 2022-06-25 18:52:28.444041
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # Test for correct handling of string
    assert j_s_o_n_formatter_0.format_body(body = '', mime = str()) == ''
    assert j_s_o_n_formatter_0.format_body(body = '', mime = str()) == ''

# Generated at 2022-06-25 18:52:30.005531
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True == False  # TODO: implement your test here


# Generated at 2022-06-25 18:52:38.638862
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = ""
    mime = ""
    assert j_s_o_n_formatter_0.format_body(body, mime) == ""

    j_s_o_n_formatter_0 = JSONFormatter()
    body = "Body"
    mime = "text/plain"
    assert j_s_o_n_formatter_0.format_body(body, mime) == "Body"

    j_s_o_n_formatter_0 = JSONFormatter()
    body = "{}"
    mime = "text/plain"
    assert j_s_o_n_formatter_0.format_body(body, mime) == "{}"


# Generated at 2022-06-25 18:52:48.129425
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-25 18:53:06.126157
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        json_formatter_0 = JSONFormatter()
        if str(type(json_formatter_0)) == "<class 'httpie.plugins.JSONFormatter.JSONFormatter'>":
            pass
        else:
            print("Code did not run as expected: JSONFormatter")
    except:
        print("Code did not run as expected: JSONFormatter")


# Generated at 2022-06-25 18:53:09.790925
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    j_s_o_n_formatter_0 = JSONFormatter(format_options={})
    assert isinstance(j_s_o_n_formatter_0, FormatterPlugin)


# Generated at 2022-06-25 18:53:16.260952
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Initialization
    j_s_o_n_formatter_0 = JSONFormatter()
    body = '{"a":1}'
    mime = 'json'
    # Invocation
    out = j_s_o_n_formatter_0.format_body(body, mime)
    # Expected output
    assert out == '{"a": 1}'

# Generated at 2022-06-25 18:53:25.216314
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options['json']['indent'] = 4
    # j_s_o_n_formatter_0.format_options['json']['sort_keys'] = None
    # Set format_options 
    body = '[{"a": {"b": "c"}}, [1, 2, 3]]'
    mime = 'json'

    formated_body = j_s_o_n_formatter_0.format_body(body, mime)


# Generated at 2022-06-25 18:53:33.972884
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = '{"foo": "bar"}'
    mime_0 = 'application/json'
    j_s_o_n_formatter_0.format_options['json']['format'] = True
    j_s_o_n_formatter_0.format_options['json']['sort_keys'] = True
    j_s_o_n_formatter_0.format_options['json']['indent'] = 2
    j_s_o_n_formatter_0.enabled = True
    j_s_o_n_formatter_0.kwargs['explicit_json'] = False

# Generated at 2022-06-25 18:53:37.555014
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    mime = 'text'
    body = '{}'
    assert j_s_o_n_formatter_0.format_body(body, mime) == '{}'



# Generated at 2022-06-25 18:53:41.640995
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body(
        body='{}',
        mime='application/json'
    ) == '{\n}\n'

# Generated at 2022-06-25 18:53:51.233162
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter = JSONFormatter()

# Generated at 2022-06-25 18:54:01.134797
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Check that JSON is formatted as expected
    json_str = json.dumps(obj={'name': 'test', 'age': 25}, indent=2, sort_keys=True)
    json_fmt_str = JSONFormatter().format_body(json_str, 'application/json')
    assert json_fmt_str == json_str

    # Check that JSON is formatted as expected
    json_str = json.dumps(obj={'name': 'test', 'age': 25}, indent=2, sort_keys=True)
    json_fmt_str = JSONFormatter(explicit_json=True).format_body(json_str, 'text/plain')
    assert json_fmt_str == json_str

    # Check that non-JSON is not formatted
    non_json_str = 'This string is not JSON'


# Generated at 2022-06-25 18:54:02.395045
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # There is no explicit test for this method

# Generated at 2022-06-25 18:54:26.774864
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # constructor test
    assert JSONFormatter()


# Generated at 2022-06-25 18:54:27.604109
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert '1' == '1'


# Generated at 2022-06-25 18:54:30.855059
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    j_s_o_n_formatter = JSONFormatter()
    body = ""
    mime = "json"

    # Test
    result = j_s_o_n_formatter.format_body(body, mime)

    # Verify
    assert result == ""


# Generated at 2022-06-25 18:54:32.876244
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        test_case_0()
    except Exception:
        print("An unknown error occurred!")

# unit test for __init__ method of class JSONFormatter

# Generated at 2022-06-25 18:54:33.974794
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:54:36.273767
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = ""
    mime = ""
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body(body, mime) == body

# Generated at 2022-06-25 18:54:40.899693
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body("{'a':1}", "application/json") == '{\n    "a": 1\n}'

# Generated at 2022-06-25 18:54:50.101476
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = '{"Key": "Value"}'
    mime = 'json'
    _ = j_s_o_n_formatter_0.format_body(body=body, mime=mime)
    _ = j_s_o_n_formatter_0.kwargs['explicit_json']
    _ = j_s_o_n_formatter_0.format_options['json']['format']
    _ = j_s_o_n_formatter_0.format_options['json']['sort_keys']
    _ = j_s_o_n_formatter_0.format_options['json']['indent']

# Generated at 2022-06-25 18:54:56.508078
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Define arguments
    j_s_o_n_formatter_0 = JSONFormatter()
    body = "SJN"
    mime = "SJN"

    try:
        # Execute the function under test
        result = j_s_o_n_formatter_0.format_body(body, mime)

        # Test the results
        assert result is not None
    except Exception as e:
        assert False



# Generated at 2022-06-25 18:54:58.898639
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()


# Generated at 2022-06-25 18:55:56.990484
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body_1 = "hi"
    mime_1 = "json"
    assert j_s_o_n_formatter_1.format_body(
        body=body_1, mime=mime_1) == body_1
    body_2 = "hi"
    mime_2 = "json"
    assert j_s_o_n_formatter_1.format_body(
        body=body_2, mime=mime_2) == body_2
    body_3 = "hi"
    mime_3 = "json"
    assert j_s_o_n_formatter_1.format_body(
        body=body_3, mime=mime_3) == body_3
    body_

# Generated at 2022-06-25 18:55:58.509140
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test JSONFormatter.format_body() class method
    assert True


# Generated at 2022-06-25 18:56:05.991690
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-25 18:56:12.174260
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = ""
    mime = "bar"
    assert j_s_o_n_formatter_0.format_body(body, mime) == ""
    body = ""
    mime = "json"
    assert j_s_o_n_formatter_0.format_body(body, mime) == ""
    body = "{\"foo\": true}"
    mime = "bar"
    assert j_s_o_n_formatter_0.format_body(body, mime) == "{\"foo\": true}"
    body = "{\"foo\": true}"
    mime = "json"

# Generated at 2022-06-25 18:56:13.632424
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()


# Generated at 2022-06-25 18:56:18.848555
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body_0 = "{ 'name': 'John' }"
    mime_0 = 'json'
    output = j_s_o_n_formatter_1.format_body(body_0, mime_0)
    assert output == body_0

# Generated at 2022-06-25 18:56:24.462051
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = '{"x": "y"}'
    mime = 'application/json'
    result = j_s_o_n_formatter_0.format_body(body=body, mime=mime)
    assert result == '{\n    "x": "y"\n}'


# Generated at 2022-06-25 18:56:29.245493
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body('body', 'mime') == 'body'
    assert j_s_o_n_formatter_1.format_body('{"a":[1,2,3]}', 'javascript') == \
        '{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}'


# Generated at 2022-06-25 18:56:38.862281
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Tests for:  format_body
    import unittest

    class JSONFormatter_format_body_TestCase(unittest.TestCase):
        def test_000(self):
            # JSON response.
            self.assertEqual(
                JSONFormatter().format_body(
                    '''
                    {
                        "foo": "bar",
                        "baz": ["a", "b", "c"]
                    }
                    ''',
                    'application/json'
                ),
                '''
                {
                    "baz": [
                        "a",
                        "b",
                        "c"
                    ],
                    "foo": "bar"
                }
                '''.strip()
            )


# Generated at 2022-06-25 18:56:41.406660
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter(explicit_json=True)
    assert system_info['explicit_json'] == True

# Generated at 2022-06-25 18:58:58.625976
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j = rb'[{"key":"value","key2":"value2"}]'

    # Call the method
    out = j_s_o_n_formatter_0.format_body(j, None)

    # Check the result
    assert out.startswith(rb'[\n    {\n        "key": "value",\n        "key2": "value2"\n    }\n]')

# Generated at 2022-06-25 18:59:01.511538
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert (JSONFormatter.format_body("Hello World!", "Hello") != "Hello World!")
    assert (JSONFormatter.format_body("Hello World!", "Hello") == "\"Hello World!\"")
    

# Generated at 2022-06-25 18:59:07.486297
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()

    # Test case 1
    try:
        j_s_o_n_formatter_1.format_body('Lorem ipsum', 'text/plain')
    except Exception:
        assert False

    # Test case 2
    try:
        j_s_o_n_formatter_1.format_body('{"foo": "bar"}', 'text/plain')
    except Exception:
        assert False

# Generated at 2022-06-25 18:59:16.648753
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    assert json.loads(j_s_o_n_formatter_0.format_body(body="[\"item1\", \"item2\"]", mime="application/json")) == ['item1', 'item2']

    assert json.loads(j_s_o_n_formatter_0.format_body(body="{\"item1\": 1, \"item2\": 2}", mime="application/json")) == {'item1': 1, 'item2': 2}

    assert json.loads(j_s_o_n_formatter_0.format_body(body="{\"item1\": \"val1\", \"item2\": \"val2\"}", mime="application/json")) == {'item1': 'val1', 'item2': 'val2'}

# Generated at 2022-06-25 18:59:22.244900
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Testing method format_body of class JSONFormatter.

    j_s_o_n_formatter_1 = JSONFormatter()
    body_0 = '{"lol": -123, "lal": "123", "lil": ["1", "2", "3"], "lel": {"lul": {"lil": "lil"}}}'
    mime_0 = 'application/json'
    ret_0 = j_s_o_n_formatter_1.format_body(body_0, mime_0)

    assert ret_0 == body_0

# Generated at 2022-06-25 18:59:30.526437
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    argument_0 = j_s_o_n_formatter_0.enabled
    argument_1 = 'text/plain'
    argument_2 = 'json-formatter-test-input.txt'
    function_return_0 = JSONFormatter.format_body(
        j_s_o_n_formatter_0,
        argument_0,
        argument_1,
        argument_2
    )
    file = open('json-formatter-test-desired-output.txt', 'r')
    desired_output = file.read()
    file.close()
    assert function_return_0 == desired_output
