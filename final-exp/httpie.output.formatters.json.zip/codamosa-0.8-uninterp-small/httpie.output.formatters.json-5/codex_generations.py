

# Generated at 2022-06-25 18:49:39.685817
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.kwargs == {}
    assert j_s_o_n_formatter_0.format_options == {'json': {'format': False, 'indent': 2, 'sort_keys': False}}
    assert j_s_o_n_formatter_0.format_options == {'json': {'format': False, 'indent': 2, 'sort_keys': False}}
    assert j_s_o_n_formatter_0.enabled == False


# Generated at 2022-06-25 18:49:43.636149
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body(JSONFormatter, 'str', 'str') == 'str'
    assert JSONFormatter.format_body(JSONFormatter, 'str', 'str') == 'str'
    assert JSONFormatter.format_body(JSONFormatter, 'str', 'str') == 'str'

# Generated at 2022-06-25 18:49:44.927885
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter


# Generated at 2022-06-25 18:49:53.654729
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    example_input_0 = [
        [
            '{"a":1}'
        ]
    ]
    example_object_0 = JSONFormatter()
    assert example_object_0.format_body(example_input_0[0][0], example_input_0[0][0]) == '{\n    "a": 1\n}'
    example_input_1 = [
        [
            '{"a":1}'
        ]
    ]
    example_object_1 = JSONFormatter()
    assert example_object_1.format_body(example_input_1[0][0], example_input_1[0][0]) == '{\n    "a": 1\n}'
    example_input_2 = [
        [
            '{"a":1}'
        ]
    ]
    example

# Generated at 2022-06-25 18:49:55.914262
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    x = JSONFormatter()
    x.format_body('{ "header": "value" }', 'application/json')

# Generated at 2022-06-25 18:50:04.382337
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0_0 = JSONFormatter()
    body_0_0_0 = "body_0_0_0"
    mime_0_0_0 = 'mime_0_0_0'
    j_s_o_n_formatter_0_0.body = body_0_0_0
    j_s_o_n_formatter_0_0.mime = mime_0_0_0
    body_0_0_0 = j_s_o_n_formatter_0_0.format_body(body_0_0_0, mime_0_0_0)
    assert not body_0_0_0


# Generated at 2022-06-25 18:50:13.075053
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import unittest
    import json

    class TestJSONFormatter(unittest.TestCase):
        def test_JSONFormatter_format_body(self):
            j_s_o_n_formatter_0 = JSONFormatter()
            body_0 = '{"key": "value"}'
            mime_0 = 'application/json'
            self.assertEqual(j_s_o_n_formatter_0.format_body(body_0, mime_0), '{"key": "value"}', 'Arguments were: body = ' + body_0 + ', mime = ' + mime_0)
            body_1 = '{"key": "value"}'
            mime_1 = 'text/html'

# Generated at 2022-06-25 18:50:16.400997
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter = JSONFormatter(format_options={'json': {'format': False, 'indent': '2', 'sort_keys': True}}, kwargs={'explicit_json': True})
    j_s_o_n_formatter.format_body( )
    j_s_o_n_formatter.format_headers( )

# Generated at 2022-06-25 18:50:21.913535
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '"data": {"name": "John Doe", "age": 30}'
    mime = 'application/json'
    expected_result = '{"data": {"age": 30, "name": "John Doe"}}'
    j_s_o_n_formatter_1 = JSONFormatter(explicit_json=True, format_options={'json' : {'format' : True, 'indent' : 2, 'sort_keys' : True}})
    assert expected_result == j_s_o_n_formatter_1.format_body(body=body, mime=mime)

# Generated at 2022-06-25 18:50:27.180068
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body = '(╯°□°)╯︵ ┻━┻'
    mime = 'application/json'
    result = j_s_o_n_formatter_1.format_body(body, mime)
    assert result == body



# Generated at 2022-06-25 18:50:35.454041
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{}'
    mime = 'application/json'

    j_s_o_n_formatter_0 = JSONFormatter()
    result = j_s_o_n_formatter_0.format_body(body, mime)
    assert result == '{}'


# Generated at 2022-06-25 18:50:45.482131
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 3
    j_s_o_n_formatter_0 = JSONFormatter()
    # j_s_o_n_formatter_0.format_options = {}
    # j_s_o_n_formatter_0.kwargs = {}
    assert j_s_o_n_formatter_0.format_body(body='', mime='') == ''
    # j_s_o_n_formatter_0.format_options = {}
    # j_s_o_n_formatter_0.kwargs = {}
    assert j_s_o_n_formatter_0.format_body(body='', mime='json') == ''
    # j_s_o_n_formatter_0.format_options = {}
    # j_s_o_n_form

# Generated at 2022-06-25 18:50:56.476962
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_format_body_0 = JSONFormatter()
    
    assert j_s_o_n_formatter_format_body_0.format_body("\n{\"foo\": \"bar\", \"abc\": \"def\"}", "json") == "\n{\n    \"abc\": \"def\",\n    \"foo\": \"bar\"\n}"
    assert j_s_o_n_formatter_format_body_0.format_body('\n{"foo": "bar", "abc": 42, "do-it": true, "null-val": null}\n', "json") == "\n{\n    \"abc\": 42,\n    \"do-it\": true,\n    \"foo\": \"bar\",\n    \"null-val\": null\n}\n"

# Generated at 2022-06-25 18:51:04.469096
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body("{}", "text") == "{}"
    assert j_s_o_n_formatter_0.format_body("{}", "application/json") == "{}"
    assert j_s_o_n_formatter_0.format_body("{}", "application/javascript") == "{}"
    assert j_s_o_n_formatter_0.format_body("{}", "text/json") == "{}"

# Generated at 2022-06-25 18:51:07.697740
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test response is correct
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.enabled
    assert j_s_o_n_formatter_1.format_options
    assert j_s_o_n_formatter_1.kwargs


# Generated at 2022-06-25 18:51:13.732031
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Instanciate object of class JSONFormatter.
    j_s_o_n_formatter_1 = JSONFormatter()

    # Try with valid JSON.
    assert j_s_o_n_formatter_1.format_body(body='{"a":1}', mime="json") == \
           '{\n    "a": 1\n}'

    # Try with invalid JSON.
    assert j_s_o_n_formatter_1.format_body(body='"a"', mime="json") == '"a"'

    # Try with non-JSON.
    assert j_s_o_n_formatter_1.format_body(body='hi', mime="text/plain") == "hi"

# Generated at 2022-06-25 18:51:15.073632
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter is not None


# Generated at 2022-06-25 18:51:20.543470
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.kwargs['format_options']['json']['format'] == True
    assert formatter.kwargs['format_options']['json']['indent'] == 2
    assert formatter.kwargs['format_options']['json']['sort_keys'] == False
    assert formatter.kwargs['explicit_json'] == False


# Generated at 2022-06-25 18:51:30.491194
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Setup:
    from pkg_resources import resource_stream
    import os
    import io
    import sys
    import tempfile
    import shutil
    import httpie
    import httpie.plugins
    import json
    # Given:
    #       A input in the form of a plaintext json file
    # When:
    #       A httpie.plugins.json.JSONFormatter object is instantiated
    # Then:
    #       The object is constructed correctly
    json_obj = json.load(resource_stream(
        'httpie.plugins.json',
        os.path.join('tests', 'response.json')
    ))
    json_str = json.dumps(
        obj=json_obj,
        sort_keys=True,
        ensure_ascii=False,
        indent=4
    )


# Generated at 2022-06-25 18:51:34.234627
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body_0 = j_s_o_n_formatter_1.format_body(
        body=b'{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'.decode('utf-8'),
        mime='application/json'
    )
    assert body_0 is not None

# Generated at 2022-06-25 18:51:44.717037
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Unit test for method format_body of class JSONFormatter
    
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_body('{"hello":"world"}', 'json')
    
    j_s_o_n_formatter_2 = JSONFormatter()
    j_s_o_n_formatter_2.format_body('text', 'json')
    
    j_s_o_n_formatter_3 = JSONFormatter()
    j_s_o_n_formatter_3.kwargs['explicit_json'] = True
    j_s_o_n_formatter_3.format_body('{"hello":"world"}', 'text/html')
    
    j_s_o_n_formatter_

# Generated at 2022-06-25 18:51:53.539932
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    kwargs0 = {'explicit_json': False, 'indent': 2, 'sort_keys': False}
    json_formatter_0 = JSONFormatter(**kwargs0)
    mime0 = 'json'
    body0 = '''{
  "status":"success",
  "data":{
    "id":"123",
    "foo":"bar"
  }
}'''
    ret_val_0 = json_formatter_0.format_body(body0, mime0)
    expected_0 = '\n{\n  "status": "success",\n  "data": {\n    "id": "123",\n    "foo": "bar"\n  }\n}'
    assert ret_val_0 == expected_0

# Generated at 2022-06-25 18:51:58.678753
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    mime_0 = 'application/json'
    body_0 = r'{"msg": "test"}'
    body_0_json = json.loads(body_0)
    body_1 = j_s_o_n_formatter_1.format_body(body_0, mime_0)
    body_1_json = json.loads(body_1)
    assert(body_0_json == body_1_json)

# Generated at 2022-06-25 18:52:09.420743
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    #
    # A simple test to check that the response is being converted
    # to JSON at all.
    #
    #
    # BEGIN GENERATED CONTENT
    body = u'This is not JSON.'
    mime = u'html'
    j_s_o_n_formatter_0 = JSONFormatter()
    actual_body = j_s_o_n_formatter_0.format_body(body=body, mime=mime)
    expected_body = u'This is not JSON.'
    assert actual_body == expected_body
    body = u'{"a": "A"}'
    mime = u'html'
    j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:52:10.755634
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass # test_JSONFormatter_format_body


# Generated at 2022-06-25 18:52:15.706017
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body("{\n    \"foo\": 42,\n    \"bar\": \"baz\"\n}", "application/json; charset=utf-8") == "{\n    \"foo\": 42,\n    \"bar\": \"baz\"\n}"


# Generated at 2022-06-25 18:52:22.914124
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{\n  \"foo\": \"bar\"\n}"
    mime = 'application/json'
    body = JSONFormatter.format_body(body, mime)
    assert body == '{\n  \"foo\": \"bar\"\n}'
    body = '{\n  "foo": "bar"\n}'
    mime = 'application/json'
    body = JSONFormatter.format_body(body, mime)
    assert body == '{\n  \"foo\": \"bar\"\n}'
    body = '{\n  "foo": "bar"\n}'
    mime = 'application/json'
    body = JSONFormatter.format_body(body, mime)
    assert body == '{\n  \"foo\": \"bar\"\n}'

# Generated at 2022-06-25 18:52:28.488554
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    mime = "application/json"
    body = "{\n    \"foo\": \"bar\"\n}"
    assert j_s_o_n_formatter_1.format_body(body, mime) == "{\n    \"foo\": \"bar\"\n}"

# Generated at 2022-06-25 18:52:34.507368
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_0 = ''
    mime_0 = None
    JSONFormatter_instance_0 = JSONFormatter()
    try:
        JSONFormatter_instance_0.format_body(body_0, mime_0)
    except TypeError:
        pass
    else:
        raise Exception('Failed to raise expected TypeError')

# Testing of method format_body of class JSONFormatter
test_JSONFormatter_format_body()

test_case_0()

# Generated at 2022-06-25 18:52:38.419896
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_test_0 = JSONFormatter()
    result_format_body_0 = json_test_0.format_body(
        body='{ "test": "passed" }',
        mime='application/json'
    )
    assert result_format_body_0 == '{\n  "test": "passed"\n}'


# Generated at 2022-06-25 18:52:47.831566
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = ''
    mime_0 = ''
    j_s_o_n_formatter_0.format_body(body_0, mime_0)


# Generated at 2022-06-25 18:52:58.215298
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_0 = '{\"a\": 1, \"b\": 2}\n'
    str_1 = 'json'
    try:
        str_2 = j_s_o_n_formatter_0.format_body(str_0, str_1)
    except Exception as exception_0:
        print('Exception: ' + str(exception_0))
    else:
        assert str_2 == '{\n    "a": 1,\n    "b": 2\n}\n'
    str_0 = '{\"a\": 1, \"b\": 2}\n'
    str_1 = 'text'

# Generated at 2022-06-25 18:53:10.367074
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:53:15.264791
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import registry
    registry.unregister(JSONFormatter)
    registry.register(JSONFormatter)
    j = JSONFormatter()
    j.format_body("{}","json")
    registry.unregister(JSONFormatter)

# Generated at 2022-06-25 18:53:18.846496
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    body = '{"id":1,"name":"A green door","price":12.50,"tags":["home","green"]}'
    mime = 'application/json'
    test_case_0().format_body(body, mime)

# Generated at 2022-06-25 18:53:25.558239
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.kwargs = {'explicit_json': False}
    j_s_o_n_formatter_1.format_options = {'json': {'format': False, 'indent': 2, 'sort_keys': False}}
    body_2 = '{"a": "b"}'
    mime_3 = 'json'

    # Invocation
    result = j_s_o_n_formatter_1.format_body(body_2, mime_3)

    # Verification
    assert result is not None



# Generated at 2022-06-25 18:53:27.578821
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.format_options is not None
    assert JSONFormatter.explicit_json is not None

# Generated at 2022-06-25 18:53:30.586816
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    """ Class constructor test """
    def test_JSONFormatter_0():
        j_s_o_n_formatter_0 = JSONFormatter()
        assert j_s_o_n_formatter_0.__class__.__name__ == 'JSONFormatter'

# Generated at 2022-06-25 18:53:40.375085
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter(explicit_json=True)
    assert j_s_o_n_formatter_0.format_body('', None) == ''

    j_s_o_n_formatter_1 = JSONFormatter(explicit_json=False)
    assert j_s_o_n_formatter_1.format_body('', None) == ''


# Generated at 2022-06-25 18:53:49.052519
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_arg_0 = '{"a":1, "b":2}'
    str_arg_1 = 'json'
    return_value_0 = j_s_o_n_formatter_0.format_body(str_arg_0, str_arg_1)
    return_value_1 = j_s_o_n_formatter_0.format_body(str_arg_0, str_arg_1)
    assert ( return_value_0 == '{\n    "a": 1,\n    "b": 2\n}')
    assert ( return_value_1 == return_value_0 )


# Generated at 2022-06-25 18:54:02.934005
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_1 = JSONFormatter(**{})
    assert j_s_o_n_formatter_1 is not None


# Generated at 2022-06-25 18:54:09.325872
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # The following call should return the body

    obj = JSONFormatter(format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': True}}, explicit_json = False)
    obj = obj.format_body('{"name": "httpie", "version": "1.0"}', 'application/json')
    assert obj == '{\n  "name": "httpie",\n  "version": "1.0"\n}'
    del obj


# Generated at 2022-06-25 18:54:16.771507
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False,
        }
    }
    body_0 = '{"name":"value"}'
    mime_0 = 'json'
    output_0 = j_s_o_n_formatter_0.format_body(body_0, mime_0)
    assert output_0 == '{\n  "name": "value"\n}'
    body_1 = '{"a":1,"b":2}'
    mime_1 = 'javascript'
    output_1 = j_s_o_n_formatter_0.format_body

# Generated at 2022-06-25 18:54:18.993610
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert isinstance(j_s_o_n_formatter_1, JSONFormatter)


# Generated at 2022-06-25 18:54:26.776023
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    j_s_o_n_formatter_0 = JSONFormatter()
    # State
    body_0 = 's{s\'s'
    mime_0 = 's{s\'s'
    # Invocation
    result_0 = j_s_o_n_formatter_0.format_body(
        body=body_0,
        mime=mime_0
    )
    # Verification
    assert result_0 == 's{s\'s'

# Generated at 2022-06-25 18:54:32.801714
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '''{
"array": [1, 2, 3],
"boolean": true,
"color": "#82b92c",
"null": null,
"number": 123,
"object": {"a": "b", "c": "d", "e": "f"},
"string": "Hello World"
}'''
    mime = "json"
    j_s_o_n_formatter_0 = JSONFormatter()
    body_f = j_s_o_n_formatter_0.format_body(body, mime)
    assert body == body_f

# Generated at 2022-06-25 18:54:35.606799
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = ""
    mime = ""
    r0 = j_s_o_n_formatter_0.format_body(body, mime)
    assert r0 is None

# Generated at 2022-06-25 18:54:36.243300
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass

# Generated at 2022-06-25 18:54:39.768077
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()


# Generated at 2022-06-25 18:54:42.871867
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body('foo', 'bar')


# Generated at 2022-06-25 18:55:10.265422
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 0 of the formatter
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body()




# Generated at 2022-06-25 18:55:16.969386
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = '''{
    "a": {
        "b": "c"
    },
    "b": [1,2,3]
}'''
    assert j_s_o_n_formatter_0.format_body(body_0, '') == '''{
    "a": {
        "b": "c"
    },
    "b": [1, 2, 3]
}'''
    body_1 = '''{"a":{"b":"c"},"b":[1,2,3]}'''

# Generated at 2022-06-25 18:55:18.373591
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    assert True


# Generated at 2022-06-25 18:55:23.446952
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter_0 = JSONFormatter()
    json_formatter_0.kwargs = {'explicit_json': False}
    json_formatter_0.format_options = {'json': {'format': False, 'sort_keys': True, 'indent': 2}}
    json_formatter_0.format_body('hi', 'application/json')


# Generated at 2022-06-25 18:55:28.309440
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_2 = JSONFormatter(
    )
    body_1: str = 'body_0'
    mime_1: str = 'mime_0'

    # Call method
    result = j_s_o_n_formatter_2.format_body(body_1, mime_1)
    # Assertions
    assert result == 'body_0'

# Generated at 2022-06-25 18:55:36.116438
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.kwargs = {
        'explicit_json': 'true'
    }
    j_s_o_n_formatter_0.format_options = {
        'json': {
            'format': 'true',
            'sort_keys': 'true',
            'indent': 'true'
        }
    }
    j_s_o_n_formatter_0.format_body("{'a': 1}", 'application/json')


# Generated at 2022-06-25 18:55:37.899543
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_2 = JSONFormatter()




# Generated at 2022-06-25 18:55:44.596417
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = "application/json\ntext/plain\n"
    mime = ""
    assert j_s_o_n_formatter_0.format_body(body, mime) == body

# Generated at 2022-06-25 18:55:47.384517
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()


# Generated at 2022-06-25 18:55:51.164693
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs = {'explicit_json': False}
    json_formatter.format_options = {'json': {'format': False, 'sort_keys': True, 'indent': None}}

    body = b'\xef\xbb\xbf{"foo":"bar"}'
    mime = 'application/json'

    assert json_formatter.format_body(body, mime) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-25 18:57:32.243105
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_format_body_0 = JSONFormatter()
    assert j_s_o_n_formatter_format_body_0.format_body(body='hoi', mime='nadat') == 'hoi'


# Generated at 2022-06-25 18:57:43.775277
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_0 = '{"foo": "bar", "baz": "qux"}'
    mime_0 = 'application/json'
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) == '{\n    "baz": "qux",\n    "foo": "bar"\n}'
    body_1 = '{"foo": "bar", "baz": "qux"}'
    mime_1 = 'text/javascript'
    assert j_s_o_n_formatter_0.format_body(body_1, mime_1) == '{\n    "baz": "qux",\n    "foo": "bar"\n}'
    body

# Generated at 2022-06-25 18:57:48.313053
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test assertions (1)
    try:
        j_s_o_n_formatter_0 = JSONFormatter()
        body_arg_0 = "o"
        mime_arg_1 = "json"
        j_s_o_n_formatter_0.format_body(body_arg_0, mime_arg_1)
    except Exception:
        assert False


# Generated at 2022-06-25 18:57:52.262665
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    try:
        body_0 = '{}'
        mime_0 = 'text'
        j_s_o_n_formatter = JSONFormatter()
        body = j_s_o_n_formatter.format_body(body_0, mime_0)
    except Exception:
        pass
    else:
        raise Exception('ExpectedException not raised')


# Generated at 2022-06-25 18:57:57.576917
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    kwargs = {}
    kwargs['explicit_json'] = False
    j_s_o_n_formatter_1.kwargs = kwargs
    body = {u'foo': u'bar'}
    mime = u'application/json'
    result = j_s_o_n_formatter_1.format_body(body, mime)

# Generated at 2022-06-25 18:58:02.372178
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f_o_r_m_a_t_t_e_r_0 = JSONFormatter()
    s_t_r_i_n_g_0 = '{\'\\\'a\\\'\': 42}'

# Generated at 2022-06-25 18:58:07.684217
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0: str = "hello"
    mime_0: str = "application/json"
    str_0: str = j_s_o_n_formatter_0.format_body(body_0, mime_0)
    assert str_0[0] == 'h'

test_case_0()
test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:58:10.181511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass
    # [assertEqual(expected, JSONFormatter.format_body(body, mime))]
    # assertEqual(expected, JSONFormatter.format_body(body, mime))

# Generated at 2022-06-25 18:58:18.282782
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Instantiation of class JSONFormatter
    j_s_o_n_formatter_1 = JSONFormatter()
    # Calling method format_body with arguments:
    #     body=u'{"foo": ["bar", "baz"]}', mime='json'
    # should return u'{"foo": ["bar", "baz"]}'
    # and should not raise an exception.
    assert (j_s_o_n_formatter_1.format_body(u'{"foo": ["bar", "baz"]}', 'json')
            == u'{"foo": ["bar", "baz"]}')
    # Calling method format_body with arguments:
    #     body=u'{"foo": ["bar", "baz"]}', mime='javascript'
    # should return u'{"foo": ["bar", "b

# Generated at 2022-06-25 18:58:28.187159
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    j_s_o_n_formatter.format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': True}}
    j_s_o_n_formatter.kwargs = {'explicit_json': True}
    assert j_s_o_n_formatter.format_body('{"key": "value"}', 'json') == '{\n  "key": "value"\n}'
    assert j_s_o_n_formatter.format_body('{"key": "value"}', 'text/html') == '{"key": "value"}'