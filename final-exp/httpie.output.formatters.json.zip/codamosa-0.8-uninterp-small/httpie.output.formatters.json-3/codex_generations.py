

# Generated at 2022-06-25 18:49:37.919578
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_0 = "s\"%1$<s>s\"s\"s\"s"
    str_1 = "s\"%1$<s>s\"s\"s\"s"
    str_2 = j_s_o_n_formatter_0.format_body(str_0, str_1)
    assert str_2 == "s\"%1$<s>s\"s\"s\"s"

# Generated at 2022-06-25 18:49:43.718359
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    
    # Setup
    j_s_o_n_formatter_1 = JSONFormatter()
    body = "value"
    mime = "value"

    # Invocation
    result = j_s_o_n_formatter_1.format_body(body, mime)

    # Verification
    assert result is None


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 18:49:52.727191
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # TEST CASE: Invalid JSON, ignore.
    try:
        j_s_o_n_formatter_0.format_body('string:', 'json')
        assert False # exception not thrown
    except ValueError:
        pass
    # TEST CASE: Indent, sort keys by name, and avoid unicode escapes to improve readability.
    assert j_s_o_n_formatter_0.format_body('{"a": 123, "b": 456}', 'json') == '{\n    "a": 123,\n    "b": 456\n}'

# Generated at 2022-06-25 18:50:03.477478
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Default arguments of method format_body of class JSONFormatter
    j_s_o_n_formatter_1 = JSONFormatter(explicit_json=False, format_options={"json": {"format": True, "sort_keys": True, "indent": 2}}, pretty_options={"colors": {"body": "auto", "header": "auto"}, "max_linewidth": 75, "reflow_source": "auto", "reflow_method": "auto"}, style_options={"colors": True, "colors256": False, "theme": "friendly", "styles": {"header": "bold cyan", "header_key": "bold cyan", "header_value": "bold green", "body": "bold magenta", "body_key": "blue", "body_value": "green"}, "default_style": "bold dim white"})

# Generated at 2022-06-25 18:50:06.027202
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    print()
    print("Testing constructor of class JSONFormatter")
    print("===========")
    j_s_o_n_formatter_0 = JSONFormatter()


# Generated at 2022-06-25 18:50:09.814671
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    j_s_o_n_formatter_0 = JSONFormatter()
    body = "Application/json"
    mime = "text/plain"
    # Assertions
    assert j_s_o_n_formatter_0.format_body(body, mime) == "Application/json"

# Generated at 2022-06-25 18:50:17.705377
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_format_body_0 = JSONFormatter()

    #Test case 0
    body_0 = '{"status": 1, "count": 2, "result": ["one", "two"]}'
    mime_0 = 'json'
    #Expected: '{\n    "count": 2,\n    "result": [\n        "one",\n        "two"\n    ],\n    "status": 1\n}'
    assert j_s_o_n_formatter_format_body_0.format_body(body=body_0, mime=mime_0) == '{\n    "count": 2,\n    "result": [\n        "one",\n        "two"\n    ],\n    "status": 1\n}'

   

# Generated at 2022-06-25 18:50:21.593151
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter(
        color_options=None,
        format_options=None,
        theme_options=None)

    j_s_o_n_formatter_0.format_body('', 'text/html')
    j_s_o_n_formatter_0.format_body('', 'application/json')

# Generated at 2022-06-25 18:50:28.894101
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.kwargs == {'sort_keys': True, 'indent': 4, 'explicit_json': False}
    assert j_s_o_n_formatter_0.enabled == False
    assert j_s_o_n_formatter_0.format_options == {'json': {'indent': 4, 'sort_keys': True, 'format': False}}


# Generated at 2022-06-25 18:50:37.404723
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    mime = "random"
    value = j_s_o_n_formatter_0.format_body(body, mime)
    assert value == "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

# Generated at 2022-06-25 18:50:55.041820
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter._format_body({'body': 'b', 'mime': 'application/json'}) == 'b'
    assert JSONFormatter._format_body({'body': '{"test": ""}', 'mime': 'application/json'}) == '{\n    "test": ""\n}'
    assert JSONFormatter._format_body({'body': '{\'test\': \'\'}', 'mime': 'application/json'}) == '{\n    \'test\': \'\'\n}'
    assert JSONFormatter._format_body({'body': '{"test": ""}', 'mime': 'application/javascript'}) == '{\n    "test": ""\n}'

# Generated at 2022-06-25 18:51:05.368534
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    json_formatter = JSONFormatter()

    assert json_formatter.enabled is True
    # Tests that an empty string will be returned when given an empty string
    assert json_formatter.format_body(body="", mime="json") == ""
    # Tests that the given json string is not changed
    assert json_formatter.format_body(body='{"a":1, "b":2}', mime="json") == '{"a":1, "b":2}'
    # Tests that the given json string is not changed
    assert json_formatter.format_body(body='{"a":1, "b":2}', mime="javascript") == '{"a":1, "b":2}'
    # Tests that the given json string is not changed

# Generated at 2022-06-25 18:51:08.092895
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body("'1'", "text")


# Generated at 2022-06-25 18:51:11.236411
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    # Test for method format_body of class JSONFormatter
    assert j_s_o_n_formatter_1.format_body("""{"key":"value"}""", 'json') == '''{"key":"value"}'''

# Generated at 2022-06-25 18:51:19.416673
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()

    # Passing instance of class 'dict' as 'body' and passing name of class 'JSONFormatter' as 'mime' 
    j_s_o_n_formatter_2 = JSONFormatter(body = {}, mime = 'JSONFormatter')
    j_s_o_n_formatter_2.format_body(body=j_s_o_n_formatter_2.body, mime=j_s_o_n_formatter_2.mime)

# Generated at 2022-06-25 18:51:29.553632
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_0 = '{"key": "val"}'
    # Calling format_body with arguments (str_0, 'application/json')
    str_1 = j_s_o_n_formatter_0.format_body(str_0, 'application/json')
    assert str_1 == '{\n    "key": "val"\n}'
    str_2 = '{"key": "val"}'
    # Calling format_body with arguments (str_2, 'application/json')
    str_3 = j_s_o_n_formatter_0.format_body(str_2, 'application/json')
    assert str_3 == '{\n    "key": "val"\n}'

# Generated at 2022-06-25 18:51:35.887987
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Arrange
    kwargs_0 = {
        'format': True,
        'indent': 4,
        'sort_keys': False,
    }
    j_s_o_n_formatter_0 = JSONFormatter(
        **kwargs_0
    )
    assert j_s_o_n_formatter_0.enabled == True
    assert j_s_o_n_formatter_0.kwargs == {
        'explicit_json': False,
    }
    assert j_s_o_n_formatter_0.format_options == {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False,
        }
    }

# Generated at 2022-06-25 18:51:45.293830
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.kwargs = {'pretty': 'all', 'explicit_json': False, 'style': 'solarized', 'colors': 200, 'stream': False}

# Generated at 2022-06-25 18:51:48.976995
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass


if __name__ == '__main__':
    import sys
    import nose

    argv = sys.argv[:]
    argv.append('--verbose')
    argv.append('--nocapture')
    nose.main(argv=argv, defaultTest=__file__)

# Generated at 2022-06-25 18:51:50.791948
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body("") == ""

# Test for class JSONFormatter
# Test for constructor of class JSONFormatter

# Generated at 2022-06-25 18:52:01.686255
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"key":"value"}'
    mime = 'json'
    j_s_o_n_formatter_0 = JSONFormatter()
    print(j_s_o_n_formatter_0.format_body(body, mime))


# Generated at 2022-06-25 18:52:07.608267
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_str = '{}'
    mime_str = 'application/json'
    body_repr_str = '{}'
    result_str = j_s_o_n_formatter_0.format_body(body_str, mime_str)
    print(result_str)
    assert body_repr_str == result_str


# Generated at 2022-06-25 18:52:17.102122
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case for method format_body of class JSONFormatter
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body('{"a": 1}', '') == '{\n    "a": 1\n}'
    assert j_s_o_n_formatter_1.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert j_s_o_n_formatter_1.format_body('{"b": 2}', 'json') == '{\n    "b": 2\n}'
    assert j_s_o_n_formatter_1.format_body('[1, 2, 3]', 'jsonp') == '[1, 2, 3]'


# Generated at 2022-06-25 18:52:18.217810
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert True


# python -m unittest plugins/httpie/httpie/plugins/json.py

# Generated at 2022-06-25 18:52:20.521625
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body(None, None)



# Generated at 2022-06-25 18:52:22.715343
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        test_case_0()
    except Exception:
        print("Exception raised during arguments test of JSONFormatter")
        assert False
    else:
        assert True

# Generated at 2022-06-25 18:52:26.065414
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.format_body({"json": "JSON", "body": "Body"})

# Generated at 2022-06-25 18:52:29.498702
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    mime = ''
    body = ''
    assert j_s_o_n_formatter_1.format_body(body, mime) == ''

# Generated at 2022-06-25 18:52:38.037764
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"foo":1, "bar": "baz"}'
    mime = 'text/json'
    j_s_o_n_formatter_1 = JSONFormatter()

# Generated at 2022-06-25 18:52:47.558349
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_body(
        body='{"a": "A", "b": "B"}',
        mime='unknown',
    )
    j_s_o_n_formatter_1.format_body(
        body='{"a": "A", "b": "B"}',
        mime='json',
    )
    j_s_o_n_formatter_1.format_body(
        body='{"a": "A", "b": "B"}',
        mime='text',
    )

# Generated at 2022-06-25 18:53:10.960299
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    name = 'non_json'
    mime = 'application/not-json'
    body = 'This is not JSON.'
    maybe_json = ['json', 'javascript', 'text']
    assert '{"This is not JSON.": ""}' == j_s_o_n_formatter_0.format_body(body, mime)
    assert '{"This is not JSON.": ""}' == j_s_o_n_formatter_0.format_body(body, name)
    assert '{"This is not JSON.": ""}' == j_s_o_n_formatter_0.format_body(body, maybe_json)

    name = 'json_test'
    mime = 'application/json'

# Generated at 2022-06-25 18:53:22.304785
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print('test_JSONFormatter_format_body')
    formatter = JSONFormatter()


# Generated at 2022-06-25 18:53:29.863484
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # Test the body with a string
    j_s_o_n_formatter_0.format_body("String", "json")
    # Test the body with an integer
    j_s_o_n_formatter_0.format_body(1, "json")
    # Test the body with a float
    j_s_o_n_formatter_0.format_body(1.0, "json")
    # Test the body with an array
    j_s_o_n_formatter_0.format_body([1, 2, 3], "json")
    # Test the body with a tuple
    j_s_o_n_formatter_0.format_body((1, 2, 3), "json")
    # Test the body

# Generated at 2022-06-25 18:53:32.458814
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    # test constructor
    assert(isinstance(j_s_o_n_formatter_0, JSONFormatter))

# Generated at 2022-06-25 18:53:42.100129
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    body_0 = '''\
{
  "aString": "aString",
  "anArray": [ 1, 2, 3 ],
  "aNumber": 123,
  "aBoolean": true,
  "aNull": null
}'''

    assert j_s_o_n_formatter_0.format_body(body_0, 'application/json') == body_0

    body_1 = '''\
{
  "aString": "aString",
  "anArray": [ 1, 2, 3 ],
  "aNumber": 123,
  "aBoolean": true,
  "aNull": null
}'''


# Generated at 2022-06-25 18:53:51.658988
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = u'{\n    "username": "user",\n    "password": "secret"\n}'
    mime = u'json'
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body(body, mime) == u'{\n    "password": "secret",\n    "username": "user"\n}'
    body = u'{\n    "username": "user",\n    "password": "secret"\n}'
    mime = u'javascript'
    j_s_o_n_formatter_2 = JSONFormatter()

# Generated at 2022-06-25 18:53:57.327812
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()

    # Test for a class
    j_s_o_n_formatter_1.format_body([{'name': 'test name'}], 'json')


# Generated at 2022-06-25 18:53:58.692805
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert callable(JSONFormatter)
    assert isinstance(JSONFormatter(), JSONFormatter)


# Generated at 2022-06-25 18:54:01.303705
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body = '{example: json}'
    mime = 'html'
    result = j_s_o_n_formatter_1.format_body(body, mime)


# Generated at 2022-06-25 18:54:05.167540
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = ''
    mime = 'application/json'
    result = j_s_o_n_formatter_0.format_body(body, mime)



# Generated at 2022-06-25 18:54:33.914062
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body("", "") == ""

## Unit test for method __init__ of class JSONFormatter

# Generated at 2022-06-25 18:54:39.221527
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = ''
    body += '['
    body += '   1,\n'
    body += '   2,\n'
    body += '   3\n'
    body += ']\n'

    expected_body = ''
    expected_body += '[\n'
    expected_body += '   1,\n'
    expected_body += '   2,\n'
    expected_body += '   3\n'
    expected_body += ']\n'

    j_s_o_n_formatter = JSONFormatter()

    actual_body = j_s_o_n_formatter.format_body(body=body, mime='application/json')

    assert actual_body == expected_body

# Generated at 2022-06-25 18:54:49.333502
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin

    j_s_o_n_formatter_obj_0 = JSONFormatter()
    j_s_o_n_formatter_obj_0.format_options = {
        "json": {
                "format": True,
                "indent": 4,
                "sort_keys": True
        },
        "pretty": {
                "colors": False,
                "reformat": True,
                "stream": False
        }
    }

# Generated at 2022-06-25 18:54:54.896612
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    options = {"json":
                   {"format": True,
                    "indent": 4,
                    "sort_keys": True}
                }
    body = "{\n    \"hello\": \"world\"\n}"
    mime = "json"
    j_s_o_n_formatter_0 = JSONFormatter(format_options=options)
    assert j_s_o_n_formatter_0.format_body(body, mime) == body



# Generated at 2022-06-25 18:55:01.612813
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    j_s_o_n_formatter_0 = JSONFormatter()
    body = '{"b": "a", "a": "c"}'
    mime = 'json'
    body_1 = j_s_o_n_formatter_0.format_body(body, mime)
    assert body_1 == ('{\n'
                      '    "a": "c",\n'
                      '    "b": "a"\n'
                      '}')



# Generated at 2022-06-25 18:55:06.204225
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_body(
        body_1='{"foo":{"bar":"baz"}}',
        mime_1="application/json",
    )


# Generated at 2022-06-25 18:55:09.896607
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_0 = j_s_o_n_formatter_0.format_body('text/html', '{a}')
    assert str_0 == '{a}'

# Generated at 2022-06-25 18:55:16.774974
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = "abc"
    mime_0 = "def"
    maybe_j_s_o_n_0 = {
        'text',
        'javascript',
        'json',
    }
    if (True
            or any(token in mime_0 for token in maybe_j_s_o_n_0)):
        try:
            obj_0 = json.loads(body_0)
        except ValueError:
            pass  # Invalid JSON, ignore.

# Generated at 2022-06-25 18:55:21.750307
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body("{'a': 1, 'b': 2}", "json") == '{"a": 1, "b": 2}'

# Generated at 2022-06-25 18:55:27.911142
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_obj = JSONFormatter()
    j_s_o_n_formatter_obj.kwargs['explicit_json'] = False
    j_s_o_n_formatter_obj.kwargs['body'] = '{"foo": "bar"}'
    assert j_s_o_n_formatter_obj.format_body(j_s_o_n_formatter_obj.kwargs['body'], 'application/json') == '{\"foo\": \"bar\"}'

# Generated at 2022-06-25 18:57:08.711750
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = ''
    mime = 'mime'
    actual_output_0 = j_s_o_n_formatter_0.format_body(body, mime)
    expected_output_0 = ''
    assert actual_output_0 == expected_output_0


# Generated at 2022-06-25 18:57:12.215974
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = ""
    mime = ""
    assert j_s_o_n_formatter_0.format_body(body, mime) == None


test_case_0()
test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:57:17.786187
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Import JSONFormatter
    from httpie.output.formatters.json import JSONFormatter
    
    # Instantiate JSONFormatter
    j_s_o_n_formatter_0 = JSONFormatter()
    
    # Assert if format_body returns expected value
    assert j_s_o_n_formatter_0.format_body('{"a": "b"}', 'text') == '{"a": "b"}'

# Generated at 2022-06-25 18:57:22.366231
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = 'foo'
    mime = 'json'
    attribute_0 = JSONFormatter.format_body(JSONFormatter(), body, mime)
    attribute_1 = '"foo"'
    assert (attribute_0 == attribute_1)


# Generated at 2022-06-25 18:57:26.322525
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body(
        body="",
        mime="",
    ) == ""


# Generated at 2022-06-25 18:57:27.111461
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass


# Generated at 2022-06-25 18:57:33.515143
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter_0 = JSONFormatter()
    body = "b"
    mime = "b"
    json_formatter_0.format_body(body, mime)
    body = "b"
    mime = "b"
    json_formatter_0.format_body(body, mime)
    body = "b"
    mime = "b"
    json_formatter_0.format_body(body, mime)
    body = "b"
    mime = "b"
    json_formatter_0.format_body(body, mime)
    body = "b"
    mime = "b"
    json_formatter_0.format_body(body, mime)
    body = "b"
    mime = "b"
    json_formatter_

# Generated at 2022-06-25 18:57:44.472275
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    str_0 = '''[{"name": "John",
    "age": 20,
    "grades": [5, 6, 7],
    "address": {
        "street": "Some Street",
        "city": "Some City"
    }},
    {"name": "Jane",
    "age": 21,
    "grades": [5, 4, 7],
    "address": {
        "street": "Another Street",
        "city": "Another City"
    }}]'''

# Generated at 2022-06-25 18:57:47.797312
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = '{'
    mime = 'json'
    assert j_s_o_n_formatter_0.format_body(body, mime) == '{}'


# Generated at 2022-06-25 18:57:50.507268
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{}"
    mime = "text/json"
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body(body, mime) == "{}"