

# Generated at 2022-06-25 18:49:32.543729
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "some-body"
    mime = "text/plain; q=1.0, text/html; q=1.0"
    formatter = JSONFormatter()
    method_retval = formatter.format_body(body, mime)
    assert method_retval is not None


# Generated at 2022-06-25 18:49:42.966854
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.enabled = True
    j_s_o_n_formatter_0.kwargs = dict()
    j_s_o_n_formatter_0.kwargs['explicit_json'] = True
    j_s_o_n_formatter_0.kwargs['color'] = False
    j_s_o_n_formatter_0.format_options = dict()
    j_s_o_n_formatter_0.format_options['json'] = dict()
    j_s_o_n_formatter_0.format_options['json']['format'] = True

# Generated at 2022-06-25 18:49:48.397903
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0
    body = "{\"foo\": \"bar\"}"
    mime = "json"
    assert json.dumps(json.loads(j_s_o_n_formatter_0.format_body(body, mime))) == j_s_o_n_formatter_0.format_body(body, mime)

# Generated at 2022-06-25 18:49:51.342541
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = "abcd"
    mime = "application/json"
    j_s_o_n_formatter_0.format_body(body, mime)

# Generated at 2022-06-25 18:49:54.684416
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-25 18:49:57.356130
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    obj = JSONFormatter()
    assert obj.format_body("{}", "application/json") == '{\n}'


# Generated at 2022-06-25 18:50:06.104199
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    # From: https://github.com/jakubroztocil/httpie/issues/160
    body_0 = '{"key": "val"}'
    mime_0 = 'json'
    expected_0 = '{\n    "key": "val"\n}'
    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) == expected_0
    body_1 = '{"key": "val"}'
    mime_1 = 'javascript'
    expected_1 = '{\n    "key": "val"\n}'
    assert j_s_o_n_formatter_0.format_body(body_1, mime_1) == expected_1
   

# Generated at 2022-06-25 18:50:14.540513
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    assert j_s_o_n_formatter.format_body('foobar', 'json') == u'foobar'
    assert j_s_o_n_formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert j_s_o_n_formatter.format_body('{"foo": "bar", "baz": {"qux": "quux"}}', 'json') == '{\n    "foo": "bar",\n    "baz": {\n        "qux": "quux"\n    }\n}'
    assert j_s_o_n_formatter.format_body('foobar', 'javascript') == u'foobar'
   

# Generated at 2022-06-25 18:50:17.385898
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter(explicit_json=False, verbose=1,
                                        output_options={})
    assert j_s_o_n_formatter_0.format_body(
        body='',
        mime='application/json') == ''


# Generated at 2022-06-25 18:50:17.888907
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass



# Generated at 2022-06-25 18:50:32.098912
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    j_s_o_n_formatter_0 = JSONFormatter()
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'
    # AssertionError: assert 'key' == 'value'


# Generated at 2022-06-25 18:50:40.214968
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_options = {'json': {'show_all_headers': True, 'sort_keys': True, 'indent': 3, 'sort_headers': True, 'show_headers': True, 'separators': (',', ':'), 'format': True}, 'colors': {'headers': True}, 'style': 'solarized-dark'}
    j_s_o_n_formatter_2 = JSONFormatter()
    j_s_o_n_formatter_2.kwargs = {'explicit_json': True}
    j_s_o_n_formatter_3 = JSONFormatter()


# Generated at 2022-06-25 18:50:41.187013
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True  # no error thrown


# Generated at 2022-06-25 18:50:46.492322
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_1 = '{"a": 1, "b": 2}'
    mime_0 = 'application/json'
    assert j_s_o_n_formatter_0.format_body(body_1, mime_0) == '{\n    "a": 1,\n    "b": 2\n}'


# Generated at 2022-06-25 18:50:51.530898
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_arg_0 = "foo"
    str_arg_1 = "application/json"
    return j_s_o_n_formatter_0.format_body(
        str_arg_0,
        str_arg_1
    )

# Generated at 2022-06-25 18:51:02.565709
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    b_o_d_y_0 = '1'
    m_i_m_e_0 = 'json'
    a_s_s_e_r_t_0 = j_s_o_n_formatter_0.format_body(b_o_d_y_0, m_i_m_e_0) == '1'
    print(a_s_s_e_r_t_0)
    b_o_d_y_1 = '"a","b"'
    m_i_m_e_1 = 'json'

# Generated at 2022-06-25 18:51:11.236576
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter(explicit_json=False,format_options={'json': {'indent': None, 'sort_keys': False, 'format': True}})
    testvaluetestvaluetestvaluetestvaluetestvaluetestvaluetestvaluetestvalue = 'testvaluetestvaluetestvaluetestvaluetestvaluetestvaluetestvalue'
    output = j_s_o_n_formatter_1.format_body(body=testvaluetestvaluetestvaluetestvaluetestvaluetestvaluetestvalue, mime='json')

# Generated at 2022-06-25 18:51:22.510211
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # Test with body = {"foo":1, "bar":2, "bam":3}
    body = {"foo": 1, "bar": 2, "bam": 3}
    mime = "application/json"
    result = j_s_o_n_formatter_0.format_body(body, mime)
    assert isinstance(result, str)
    # Test with body = {"foo":1, "bar":2, "bam":3}
    body = {"foo": 1, "bar": 2, "bam": 3}
    mime = "application/json"
    result = j_s_o_n_formatter_0.format_body(body, mime)
    assert isinstance(result, str)
    #

# Generated at 2022-06-25 18:51:28.460301
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    json_formatter_0 = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter_0.format_body('{"a":"a"}', 'application/json') == '{\n  "a": "a"\n}'


# Generated at 2022-06-25 18:51:29.422655
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body


# Generated at 2022-06-25 18:51:42.874656
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_0 = '{\n "abcd": "efgh",\n "ijkl": "mnop"\n}'
    mime_0 = 'json'

    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body(body_0, mime_0)
    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) == '{\n    "abcd": "efgh",\n    "ijkl": "mnop"\n}\n'

# Generated at 2022-06-25 18:51:46.603916
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = b'{"foo": "bar"}'
    sig = lambda: list(map(type, j_s_o_n_formatter_0.format_body(body)))
    ref = lambda: [str, str]
    assert sig() == ref()

j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:51:55.477381
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body0 = '{"hello": "world"}'
    body1 = '{"hello": 1}'
    body2 = '{"hello": 1}'
    body3 = '{"hello": 1}'
    body4 = '{"hello": 1}'
    body5 = '{"hello": 1}'
    body6 = '{"hello": 1}'
    body7 = '{"hello": 1}'
    body8 = '{"hello": 1}'
    body9 = '{"hello": 1}'
    body10 = '{"hello": 1}'
    body11 = '{"hello": 1}'
    body12 = '{"hello": 1}'
    body13 = '{"hello": 1}'
    body14 = '{"hello": 1}'
    body15 = '{"hello": 1}'

# Generated at 2022-06-25 18:52:06.197196
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-25 18:52:14.261108
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_2 = JSONFormatter()
    assert str(j_s_o_n_formatter_2.__class__) == "<class 'httpie.plugins.JSONFormatter'>"
    assert j_s_o_n_formatter_2.__doc__ == 'A plugin for httpie that provides JSON formatting.'
    assert str(j_s_o_n_formatter_2.HEADER) == 'JSON'
    assert str(j_s_o_n_formatter_2.MIME_TYPE) == 'application/json'



# Generated at 2022-06-25 18:52:20.048799
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = ''
    mime = 'json'
    # ---
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_body(body, mime)
    # ---
    j_s_o_n_formatter_2 = JSONFormatter()
    j_s_o_n_formatter_2.format_body(body, mime)
    # ---
    j_s_o_n_formatter_3 = JSONFormatter()
    j_s_o_n_formatter_3.format_body(body, mime)

# Generated at 2022-06-25 18:52:30.788771
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.format_options = {
        'json': dict(
            format=True,
            sort_keys=True,
            indent=4,
        ),
        'colors': dict(
            syntax='none',
            headers='green',
            body='none',
            status='blue',
        ),
        'style': dict(
            multi_lines=True,
        ),
        'print_bodies': dict(
            always=True,
        ),
    }
    json_formatter.kwargs = {
        'explicit_json': True,
    }

# Generated at 2022-06-25 18:52:33.439319
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body()


# Generated at 2022-06-25 18:52:34.609104
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:52:36.182383
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    j_s_o_n_formatter_0 = JSONFormatter()



# Generated at 2022-06-25 18:53:00.647537
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body(body = '{}', mime = 'json') == '{}'
    assert j_s_o_n_formatter_1.format_body(body = '{}', mime = 'text') == '{}'
    assert j_s_o_n_formatter_1.format_body(body = '{}', mime = 'application/json') == '{}'
    assert j_s_o_n_formatter_1.format_body(body = '{}', mime = 'application/javascript') == '{}'

# Generated at 2022-06-25 18:53:10.530892
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter_0 = JSONFormatter()
    json_formatter_0.kwargs = {"explicit_json": False}
    json_formatter_0.format_options = {"json": {"format": False, "indent": 2, "sort_keys": True}}
    json_formatter_0.format_body("kKZ", "json")
    json_formatter_0.kwargs = {"explicit_json": False}
    json_formatter_0.format_options = {"json": {"format": False, "indent": 2, "sort_keys": True}}
    json_formatter_0.format_body("bpo", "json")
    json_formatter_0.kwargs = {"explicit_json": False}

# Generated at 2022-06-25 18:53:16.298785
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_arg_0 = None
    str_arg_1 = None
    str_0 = j_s_o_n_formatter_0.format_body(str_arg_0, str_arg_1)
    assert str_0 == None

# Generated at 2022-06-25 18:53:24.462044
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Ensure unicode escapes are not used (`ensure_ascii=False`).
    body = 'á'
    mime = 'json'
    assert JSONFormatter().format_body(body, mime) == '"á"'
    # Ensure unicode escapes are not used (`ensure_ascii=False`).
    body = 'é'
    mime = 'json'
    assert JSONFormatter().format_body(body, mime) == '"é"'
    # Ensure unicode escapes are not used (`ensure_ascii=False`).
    body = 'ç'
    mime = 'json'
    assert JSONFormatter().format_body(body, mime) == '"ç"'

# Generated at 2022-06-25 18:53:28.936426
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    j_s_o_n_formatter_0 = JSONFormatter()

    # Test for a string
    j_s_o_n_formatter_0.format_body("XYZ", "mime_type")

    # Test for bytes
    j_s_o_n_formatter_0.format_body(b"WXY", "mime_type")


# Generated at 2022-06-25 18:53:37.665625
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "body"
    mime = "application/json"
    content_type = "application/json"

    # Test if it is working.
    json_formatter_0 = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'sort_keys': True,
            'format': True,
            'indent': 2
        }})
    result = json_formatter_0.format_body(body, content_type)
    assert result == "body"

    # Test if it is working.
    json_formatter_1 = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'sort_keys': True,
            'format': False,
            'indent': 2
        }})

# Generated at 2022-06-25 18:53:44.619912
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    j_s_o_n_formatter_1 = JSONFormatter(
        format_options={'json': {'indent': None, 'sort_keys': True, 'format': True}},
        kwargs={'explicit_json': True}
    )
    test_body_0 = j_s_o_n_formatter_1.format_body(
        body='{"status": "success"}',
        mime='json'
    )
    assert test_body_0 == '{"status": "success"}'

# Generated at 2022-06-25 18:53:53.248458
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print('Testing format_body()')
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.kwargs = {'explicit_json': True}
    mime_0 = 'plain/text'
    json_elm_0 = '{"elem":"0"}'
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.kwargs = {'explicit_json': False}
    mime_1 = 'application/json'
    json_elm_1 = '{"elem":["0"]}'


# Generated at 2022-06-25 18:54:02.302566
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    # Test 1: Write test here
    body ='{"x": "y"}'
    mime ='bad'
    assert j_s_o_n_formatter_0.format_body(body, mime) == body
    mime ='json'
    assert j_s_o_n_formatter_0.format_body(body, mime) == body

    # Test 2: Write test here
    j_s_o_n_formatter_0.kwargs['explicit_json'] =True
    mime ='bad'
    assert j_s_o_n_formatter_0.format_body(body, mime) != body

# Generated at 2022-06-25 18:54:06.970015
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:54:36.964965
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_with_json_content_type = """{ "json": "works", "as": "expected" }"""
    body_with_json_like_content_type = """{ "json": "should", "work": "fine" }"""
    body_with_garbage = """{ invalid, garbage! }"""

    # TODO: 1. Test optional explicit_json kwarg.
    # TODO: 2. Test optional indent kwarg.
    # TODO: 3. Test optional sort_keys kwarg.

    # Call the function to be tested
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_1 = JSONFormatter(explicit_json=False)

# Generated at 2022-06-25 18:54:42.511565
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()

    body = "str"
    mime = "str"
    body_1: str
    body_1 = j_s_o_n_formatter_1.format_body(body, mime)
    assert body_1 == "str"

# Generated at 2022-06-25 18:54:46.790459
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    str = '{"a":"b"}'
    mime = 'application/json'
    assert j_s_o_n_formatter.format_body(str, mime) == '{\n    "a": "b"\n}'

# Generated at 2022-06-25 18:54:49.571929
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body("body", "mime") == "body"


# Generated at 2022-06-25 18:54:52.999554
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()

    # Call format_body with valid arguments
    assert j_s_o_n_formatter.format_body(body="test", mime="test") == "test"


# Run tests
if __name__ == '__main__':
    import pytest
    pytest.main(["-v", __file__])

# Generated at 2022-06-25 18:55:02.936425
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-25 18:55:13.220331
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    j_s_o_n_formatter_1 = JSONFormatter()
    body = "{\n   \"foo\":  \"bar\"  \n}"
    mime = "application/json"
    assert j_s_o_n_formatter_1.format_body(body, mime) == "{\n   \"foo\":  \"bar\"  \n}"

    # Test 2
    j_s_o_n_formatter_2 = JSONFormatter()
    body = "{\"foo\":\"bar\"}"
    mime = "application/json"
    assert j_s_o_n_formatter_2.format_body(body, mime) == "{\n    \"foo\": \"bar\"\n}"

    # Test 3
    j_s_o_n_formatter_3 = JSON

# Generated at 2022-06-25 18:55:24.702741
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    obj1 = {"a": 1, "b": 2}
    body = json.dumps(obj1, sort_keys=j_s_o_n_formatter_0.format_options['json']['sort_keys'], ensure_ascii=False, indent=j_s_o_n_formatter_0.format_options['json']['indent'])
    assert j_s_o_n_formatter_0.format_body(json.dumps(obj1), "application/json") == body
    obj2 = {"a": 1, "b": 2}

# Generated at 2022-06-25 18:55:34.801142
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # Implicit JSON.
    assert j_s_o_n_formatter_0.format_body('{"a": 1}', mime='application/json') == '{\n    "a": 1\n}'
    # Explicit JSON.
    assert j_s_o_n_formatter_0.format_body('{"a": 1}', mime='application/json', explicit_json=True) == '{\n    "a": 1\n}'
    # Invalid JSON.
    assert j_s_o_n_formatter_0.format_body('{"a": 1', mime='application/json') == '{"a": 1'
    # Not JSON.
    assert j_s_o_n_formatter_0.format_body

# Generated at 2022-06-25 18:55:36.965191
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert isinstance(JSONFormatter().format_body(body='body_0', mime='mime_0'), str)



# Generated at 2022-06-25 18:56:30.697884
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_body = '{"jsonrpc":"2.0","result":"f7103828d48b6e9cb3c3e72b842adc0b","id":101}'
    test_mime = 'json'
    formatter = JSONFormatter(explicit_json=False, headers=False,
                              body_blacklist=None, body_mime_set=None,
                              body_mime_include=None, body_mime_exclude=None)
    output = formatter.format_body(test_body, test_mime)
    print(output)

# Generated at 2022-06-25 18:56:32.991722
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body('', '') == ''

# Generated at 2022-06-25 18:56:34.049617
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True


# Generated at 2022-06-25 18:56:37.803264
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_body("{}", "application/json")



if __name__ == '__main__':
    import unittest

    unittest.main()

# Generated at 2022-06-25 18:56:47.548975
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = ''
    mime_0 = '+json'
    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) == ''
    body_1 = ''
    mime_1 = 'application/javascript'
    assert j_s_o_n_formatter_0.format_body(body_1, mime_1) == ''
    body_2 = '{}'
    mime_2 = 'application/json'
    assert j_s_o_n_formatter_0.format_body(body_2, mime_2) == '{}'
    body_3 = '{}'

# Generated at 2022-06-25 18:56:53.202179
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def test_case_0():
        # if body == '    ':
        #     return ''
        j_s_o_n_formatter_0 = JSONFormatter(**{'kwargs': {}})

    def test_case_1():
        j_s_o_n_formatter_1 = JSONFormatter(**{'kwargs': {}})
        # if body == '':
        #     return ''
        # if mime == 'json':
        #     return body
        # if mime == 'javascript':
        #     return indent(body, 4)
        # if 'json' in mime:
        #     return indent(body, 4)
        # if 'javascript' in mime:
        #     return indent(body, 4)
        # if 'text' in mime:
        #    

# Generated at 2022-06-25 18:57:01.168402
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # http://www.jsonschema2pojo.org/

    # Arrange
    j_s_o_n_formatter_0 = JSONFormatter()
    body = """
    {
        "items": [
            {
                "age": "40",
                "firstName": "Martha",
                "lastName": "Cox"
            },
            {
                "age": "86",
                "firstName": "Kurt",
                "lastName": "Hummel"
            }
        ],
        "submit": "Send data"
    }
    """
    mime = "application/json"

    # Act
    result = j_s_o_n_formatter_0.format_body(body, mime)

    # Assert
    # TODO: http://stackoverflow.com

# Generated at 2022-06-25 18:57:04.120939
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body = "test"
    mime = "plain/text"
    assert j_s_o_n_formatter_1.format_body(body, mime) == body

# Generated at 2022-06-25 18:57:12.992455
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    # Test case 0
    try:
        body_0 = {'name': 'file.json'}
        assert body_0 == j_s_o_n_formatter_0.format_body(
            body_0, mime='application/json'
        )
    except AssertionError:
        print('AssertionError raised.')
        # raise

    # Test case 1
    try:
        body_1 = {'name': 'file.json'}
        assert body_1 == j_s_o_n_formatter_0.format_body(
            body_1, mime='application/javascript'
        )
    except AssertionError:
        print('AssertionError raised.')
        # raise

    #

# Generated at 2022-06-25 18:57:15.142231
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = 'string'
    mime = 'text/html'
    assert JSONFormatter.format_body(body, mime) == body

# Generated at 2022-06-25 18:59:08.249985
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPluginManager
    from httpie.compat import urlencode
    from httpie.compat import urlopen
    import io
    import json
    import sys
    import os
    fd = io.StringIO()
    cw = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    cw.write = fd.write
    sys.stdout = cw
    formatter_plugin_manager = FormatterPluginManager()
    json_formatter = JSONFormatter()
    formatter_plugin_manager.add_plugin(json_formatter)
    url = 'http://localhost:8000/test/json/'
    data = b'{"json": ["What", "is", "your", "question"]}'

# Generated at 2022-06-25 18:59:10.318166
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert False, "Method 'format_body' not implemented"


# Generated at 2022-06-25 18:59:13.283125
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    str_1: str = j_s_o_n_formatter_1.format_body(body='body', mime='mime')
    assert str_1 == 'body'


# Generated at 2022-06-25 18:59:19.556954
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    j_s_o_n_formatter_1 = JSONFormatter()
    body = {"age": 38, "firstName": "John", "lastName": "Smith", "dateOfBirth": "Sat Dec 12 1981 00:00:00 GMT+0000 (UTC)"}
    mime = "application/json"
    # Act
    body = j_s_o_n_formatter_1.format_body(body, mime)
    # Assert
    assert body == '{"age": 38, "firstName": "John", "lastName": "Smith", "dateOfBirth": "Sat Dec 12 1981 00:00:00 GMT+0000 (UTC)"}'

# Generated at 2022-06-25 18:59:23.630139
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()

    # case 1
    body_1 = 'body'
    mime_1 = 'mime'
    j_s_o_n_formatter_1.kwargs['explicit_json'] = False
    j_s_o_n_formatter_1.format_optio