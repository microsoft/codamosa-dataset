

# Generated at 2022-06-25 18:49:33.578870
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body()


# Generated at 2022-06-25 18:49:38.187007
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter_1 = JSONFormatter()
    body = '{"foo": "bar"}'
    mime = 'json'
    format_body_result = json_formatter_1.format_body(body, mime)
    assert format_body_result == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-25 18:49:41.711299
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    # TODO: build test code


if __name__ == '__main__':
    test_case_0()
    test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:49:51.141252
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    r_b_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_0 = b"{\"a\": 1, \"b\": 2}"

# Generated at 2022-06-25 18:49:56.773097
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.format_options = {
        "json": {
            "format": True,
            "indent": 4,
            "sort_keys": False
        }
    }
    json_formatter.kwargs = {
        "explicit_json": False,
    }
    payload = """{"a": 1, "b": 2}"""
    expected = """
{
    "a": 1,
    "b": 2
}"""
    # empty mime type is similar to json
    assert json_formatter.format_body(payload, '') == expected
    assert json_formatter.format_body(payload, 'application/json') == expected
    assert json_formatter.format_body(payload, 'application/javascript') == expected
    assert json_

# Generated at 2022-06-25 18:50:03.096547
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options['json'].update({
        'indent': 2,
        'sort_keys': False,
    })
    assert (
        j_s_o_n_formatter_0.format_body(
            '{"foo": "bar"}',
            'application/json'
        )
        == '{\n  "foo": "bar"\n}'
    )



# Generated at 2022-06-25 18:50:09.564215
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # initialization of JSONFormatter with test data
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.enabled is False
    assert j_s_o_n_formatter_0.format_options == {'json': {'format': False, 'indent': None, 'sort_keys': False}}
    assert j_s_o_n_formatter_0.kwargs == {}
    assert isinstance(j_s_o_n_formatter_0.__init__, object)



# Generated at 2022-06-25 18:50:12.655848
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter(explicit_json=False, format_options='')
    j_s_o_n_formatter_1.format_body("""{"foo": "bar"}""", """json""")

# Generated at 2022-06-25 18:50:15.200365
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    with pytest.raises(Exception) as e:
        assert j_s_o_n_formatter_0.format_body(None, None)


# Generated at 2022-06-25 18:50:22.321833
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Object of class JSONFormatter
    j_s_o_n_formatter_0 = JSONFormatter()
    # Test attribute instance of class JSONFormatter

# Generated at 2022-06-25 18:50:33.129934
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    mime = "json"
    body = "{\"key\":\"value\"}"
    result = j_s_o_n_formatter_1.format_body(body, mime)
    assert result == body


# Generated at 2022-06-25 18:50:38.377043
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # Format JSON to multiline string.
    j_s_o_n_formatter_0.format_body(body='{"a": 1, "b": 2}', mime='json')
    assert True

# Num test cases: 1
# Num states: 39
# Num list elements: 3
# Total size: 59

# Generated at 2022-06-25 18:50:41.972729
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    body = "body"
    mime = "text"
    assert j_s_o_n_formatter.format_body(body, mime) == "body"

# Generated at 2022-06-25 18:50:48.757315
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup args
    body = 'body'
    mime = 'mime'
    json_formatter_0 = JSONFormatter()
    json_formatter_0.kwargs['explicit_json'] = True
    json_formatter_0.format_options['json']['format'] = True
    json_formatter_0.format_options['json']['indent'] = 4
    json_formatter_0.format_options['json']['sort_keys'] = False
    # Function call
    ret = json_formatter_0.format_body(
        body,
        mime,
    )
    # Check result
    assert ret == 'body'

# Generated at 2022-06-25 18:50:54.806976
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    print()
    try:
        os.remove('./test_json_formatter_0.txt')
        print(test_case_0.__name__ + ": OK")
        test_JSONFormatter()
    except:
        print(test_case_0.__name__ + ": Error")
        test_JSONFormatter()

# Generated at 2022-06-25 18:51:05.165824
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    ####
    # Set up mocks
    ####

    # Mock class MockResponse
    class MockResponse(object):

        def __init__(self, headers, status_code, content):
            self._headers = headers
            self._status_code = status_code
            self._content = content

        @property
        def headers(self):
            return self._headers

        @property
        def status_code(self):
            return self._status_code

        @property
        def content(self):
            return self._content

        def json(self):
            return {}

    # Mock class MockArgs
    class MockArgs(object):

        def __init__(self, verify):
            self.verify = verify

    # Mock class MockSession
    class MockSession(object):
        pass

    mock_response_0 = MockResponse

# Generated at 2022-06-25 18:51:09.770632
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_s_t_r = _generate_JSONFormatter_format_body_0()
    body = json_s_t_r
    mime = 'application/json'
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body(body, mime) == '[1]'


# Generated at 2022-06-25 18:51:14.884372
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    # If you fail here, you should check method format_body of class JSONFormatter
    assert j_s_o_n_formatter_1.format_body("", "") == ""


# Generated at 2022-06-25 18:51:18.517522
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert callable(JSONFormatter)
    j_s_o_n_formatter_0 = JSONFormatter()
    assert isinstance(j_s_o_n_formatter_0, JSONFormatter)

# Generated at 2022-06-25 18:51:24.342625
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs = {'explicit_json': False}
    json_formatter.format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': False}}
    assert json_formatter.format_body("{}", 'json') == '{}'

test_case_0()
test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:51:45.740309
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_1 = JSONFormatter()
    # Check that the return value of function
    # JSONFormatter.format_body() is equal to
    # JSONFormatter.format_body()
    assert j_s_o_n_formatter_1.format_body(
        body='body_str_0',
        mime='mime_str_0'
    ) == j_s_o_n_formatter_1.format_body(
        body='body_str_0',
        mime='mime_str_0'
    )
    print('Function "test_JSONFormatter" passed')
    print('Function "JSONFormatter" passed all tests')
    print('Function "JSONFormatter.__init__" passed all tests')


# Generated at 2022-06-25 18:51:54.607960
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    assert j_s_o_n_formatter.format_body("foo", "json") == "\ufeff\"foo\""
    assert j_s_o_n_formatter.format_body("foo", "javascript") == "\ufeff\"foo\""
    assert j_s_o_n_formatter.format_body("foo", "text") == "\ufeff\"foo\""
    assert j_s_o_n_formatter.format_body("foo", "foo") == "foo"
    assert j_s_o_n_formatter.format_body("{\"foo\"}", "foo") == "{\"foo\"}"

# Generated at 2022-06-25 18:51:59.242942
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_0 = '{"hello": "world"}'
    str_1 = 'application/json'
    str_2 = j_s_o_n_formatter_0.format_body(str_0, str_1)
    assert str_2 == '{\n    "hello": "world"\n}'



# Generated at 2022-06-25 18:52:02.520609
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body({"json": "{\"foo\": \"bar\"}"}, "application/json") == "{\"foo\": \"bar\"}"


# Generated at 2022-06-25 18:52:05.682379
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = ''
    mime = ''
    assert j_s_o_n_formatter_0.format_body(body, mime) == ''

# Generated at 2022-06-25 18:52:07.510263
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter_0 = JSONFormatter()
# Other tests omitted (omitting tests for attributes.)

# Generated at 2022-06-25 18:52:10.328380
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_0 = j_s_o_n_formatter_0.format_body('{}', 'application/json')
    assert body_0 == '{}'



# Generated at 2022-06-25 18:52:15.667803
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_JSONFormatter_format_body_var_0 = JSONFormatter()

    class DummyType:
        pass

    dummy_type_var_0 = 'Foo'
    dummy_type_var_1 = DummyType()
    test_JSONFormatter_format_body_var_0.format_body(
        dummy_type_var_0,
        dummy_type_var_1
    )


# Generated at 2022-06-25 18:52:19.217583
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    j_s_o_n_formatter_0 = JSONFormatter()
    # This is a static method, so the first argument is the class
    # object, not an instance.
    actual = JSONFormatter.format_body(JSONFormatter, '{"a": 42}', 'application/json')
    expected = '{"a": 42}'
    assert actual == expected

# Generated at 2022-06-25 18:52:25.541321
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = "ZmlsZSBjb25maWc="
    mime_0 = "application/x-www-form-urlencoded"
    v_0 = j_s_o_n_formatter_0.format_body(body_0, mime_0)
    assert v_0 == '"ZmlsZSBjb25maWc="'

# Generated at 2022-06-25 18:52:59.311473
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    s_e_t_t_i_n_g_s_dict_0 = dict()
    s_e_t_t_i_n_g_s_dict_0['json'] = dict()
    s_e_t_t_i_n_g_s_dict_0['json']['indent'] = 4
    s_e_t_t_i_n_g_s_dict_0['json']['format'] = True
    s_e_t_t_i_n_g_s_dict_0['json']['sort_keys'] = True
    s_e_t_t_i_n_g_s_dict_0['ssl'] = dict()

# Generated at 2022-06-25 18:53:03.013398
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert isinstance(j_s_o_n_formatter_0, JSONFormatter)


# Generated at 2022-06-25 18:53:12.857684
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-25 18:53:18.550112
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = j_s_o_n_formatter_0.format_body(":!@#$%^&*():<>?,./;'[]{}-=_+", "json")
    assert body == "\":!@#$%^&*():<>?,./;\'[]{}-=_+\""


# Generated at 2022-06-25 18:53:27.225582
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter(format_options={'json': {'indent': 5, 'sort_keys': True, 'format': True}})
    j_s_o_n_formatter_0.format_options = {'json': {'indent': 5, 'sort_keys': True, 'format': True}}
    j_s_o_n_formatter_0.format_options = {'json': {'indent': 5, 'sort_keys': True, 'format': True}}
    j_s_o_n_formatter_0.kwargs = {'explicit_json': False}
    # Test instance attribute
    assert j_s_o_n_formatter_0.format_options['json']['indent'] == 5
    # Test instance attribute
   

# Generated at 2022-06-25 18:53:35.569560
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.kwargs = dict()
    j_s_o_n_formatter_0.kwargs['explicit_json'] = bool()
    j_s_o_n_formatter_0.format_options = dict()
    j_s_o_n_formatter_0.format_options['json'] = dict()
    j_s_o_n_formatter_0.format_options['json']['indent'] = int()
    j_s_o_n_formatter_0.format_options['json']['sort_keys'] = bool()
    j_s_o_n_formatter_0.format_options['json']['format'] = bool()
    body

# Generated at 2022-06-25 18:53:42.677003
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter({'json': {'format': True, 'indent': None, 'sort_keys': False}}).format_options['json'] == {'format': True, 'indent': None, 'sort_keys': False}, 'Constructor argument JSONFormatter({\'json\': {\'format\': True, \'indent\': None, \'sort_keys\': False}}) of class JSONFormatter doesn\'t match expected value {\'json\': {\'format\': True, \'indent\': None, \'sort_keys\': False}}'


# Generated at 2022-06-25 18:53:46.742332
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{a: 1, b:3}'
    mime = 'json'
    json_formatter = JSONFormatter()
    assert json_formatter.format_body(body, mime) == '{"a": 1, "b": 3}'


# Generated at 2022-06-25 18:53:50.142430
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    string_0 = j_s_o_n_formatter_0.format_body('{}', 'application/json')
    assert string_0 == '{}'


# Generated at 2022-06-25 18:53:59.977387
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options = dict()
    j_s_o_n_formatter_0.format_options['json'] = dict()
    j_s_o_n_formatter_0.format_options['json']['format'] = False
    j_s_o_n_formatter_0.format_options['json']['sort_keys'] = False
    j_s_o_n_formatter_0.format_options['json']['indent'] = 0
    arguments = dict()

# Generated at 2022-06-25 18:54:25.032270
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_case_0()

# Generated at 2022-06-25 18:54:27.866537
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert(j_s_o_n_formatter_0.format_body(body="", mime="") == "")

# Generated at 2022-06-25 18:54:35.574648
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Format JSON
    j_s_o_n_formatter_1 = JSONFormatter(
        format_options=json.dumps({
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        }),
        explicit_json=True
    )
    body = '{"a": 1, "b": 2}'
    assert(j_s_o_n_formatter_1.format_body(body=body, mime='application/json') == '{\n  "a": 1,\n  "b": 2\n}')

    # Do not format JSON
    j_s_o_n_formatter_2 = JSONFormatter(format_options=json.dumps({'json': {'format': False}}))

# Generated at 2022-06-25 18:54:41.965670
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body_0 = '{u}'
    mime_0 = 'application/json'
    out_0 = j_s_o_n_formatter_1.format_body(body_0, mime_0)
    assert type(out_0) is str

# Generated at 2022-06-25 18:54:47.955590
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test setup
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = '{"foo": "bar"}'
    mime_0 = 'json'

    # Unit test for method format_body of class JSONFormatter
    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-25 18:54:51.237265
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def formatter_body_0():
        j_s_o_n_formatter_0 = JSONFormatter()
        body = "body"
        mime = "mime"
        assert j_s_o_n_formatter_0.format_body(body, mime) == "body"


# Generated at 2022-06-25 18:54:56.055990
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter({'json': {'indent': '4', 'sort_keys': 'false'}})
    assert '{\"age\": 24}' == j_s_o_n_formatter_0.format_body('{"age": 24}', 'application/json')

# Generated at 2022-06-25 18:55:01.080568
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body_0: str = ''
    mime_0: str = ''
    str_0: str = j_s_o_n_formatter_1.format_body(body_0, mime_0)
    assert str_0 == ''

# Generated at 2022-06-25 18:55:11.484492
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:55:12.243544
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    #TODO: implement test
    pass

# Generated at 2022-06-25 18:55:47.552830
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body = 'This is some text.'
    mime = 'text/html'
    assert j_s_o_n_formatter_1.format_body(body, mime) == "This is some text."

    j_s_o_n_formatter_2 = JSONFormatter()
    body = '{ "name": "John", "age": 42 }'
    mime = 'jsont'
    assert j_s_o_n_formatter_2.format_body(body, mime) == '{ "name": "John", "age": 42 }'



# Generated at 2022-06-25 18:55:53.403803
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print('Testing method: format_body of class: JSONFormatter')
    # Test 0
    ## input
    j_s_o_n_formatter_0 = JSONFormatter()
    body = "body"
    mime = "mime"
    ## expect
    assert j_s_o_n_formatter_0.format_body(body, mime) == "body"

# Generated at 2022-06-25 18:56:01.955979
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    result_sentinel = True
    body = json.dumps({'foo': 'bar'})
    body = j_s_o_n_formatter_0.format_body(body, 'json')
    # AssertionError: False != True : Invalid JSON, ignore.
    assert result_sentinel == (body == json.dumps(
        obj={'foo': 'bar'},
        sort_keys=j_s_o_n_formatter_0.format_options['json']['sort_keys'],
        ensure_ascii=False,
        indent=j_s_o_n_formatter_0.format_options['json']['indent']))

# Generated at 2022-06-25 18:56:06.375293
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # (format_options={'json': {'format': True, 'indent': 0, 'sort_keys': True}})
    f_o_j_0 = {
        'json': {
            'format': True,
            'indent': 0,
            'sort_keys': True
        }
    }
    j_s_o_n_formatter_0 = JSONFormatter(format_options=f_o_j_0)



# Generated at 2022-06-25 18:56:11.855055
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter(
        format_options={'json': {'format': False, 'sort_keys': True, 'indent': 4}},
        ui='',
        colors=False,
        style='solarized',
        explicit_json=False,
        output_options='',
        stdout_isatty='',
        stdin_isatty='',
        is_terminal='',
        stdin='',
        stdout='',
        stderr='',
        log_file='',
        log_level='',
        debug_flag='',
        output_format='',
    )


# Generated at 2022-06-25 18:56:19.712734
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = ""
    try:
        body = j_s_o_n_formatter_0.format_body(body, "text/plain")
    except Exception as e:
        print("Method format_body of class JSONFormatter raised exception")
        print("type " + str(type(e)))
        print("args " + str(e.args))
        print("msg " + e.msg)
        print("body " + body)
        assert False
    print("body " + body)
    assert True

# Generated at 2022-06-25 18:56:23.005998
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert _JSONFormatter__format_body("foo", "bar" == "foo")
    assert _JSONFormatter__format_body("buzz", "baz" == "buzz")

# Generated at 2022-06-25 18:56:23.869675
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass


# Generated at 2022-06-25 18:56:29.712070
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    string = None
    string = "JSON"
    string = ""
    string = "null"
    string = "4"
    string = "4.4"
    string = "true"
    string = "false"
    string = "[]"
    string = "[1,2,3]"
    string = "{}"
    string = "{'a': 1, 'b': 2, 'c': 3}"
    j_s_o_n_formatter.format_body(string, string)

test_case_0()
test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:56:32.692776
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    # Testing the constructor of JSONFormatter
    try:
         JSONFormatter()
    except Exception as e:
         print('Exception:', e)
         assert False
    else:
         assert True



# Generated at 2022-06-25 18:57:31.075013
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    mime = 'application/json'
    body = "{\"key\":\"value\"}"
    assert j_s_o_n_formatter_0.format_body(body, mime) == "{\n    \"key\": \"value\"\n}"

    j_s_o_n_formatter_1 = JSONFormatter(format_options={'json': {'indent': 0, 'sort_keys': False}})
    mime = 'application/json'
    body = "{\"key\":\"value\"}"
    assert j_s_o_n_formatter_1.format_body(body, mime) == "{\"key\": \"value\"}"

# Generated at 2022-06-25 18:57:35.652719
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    json_string_0 = '{"key": "value"}'
    assert j_s_o_n_formatter_0.format_body(json_string_0, 'application/json') == json_string_0
    

# Generated at 2022-06-25 18:57:41.677365
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    params = {
        "body": "Hello, world",
        "mime": "application/json"
    }
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body(**params) == '"Hello, world"'

# Generated at 2022-06-25 18:57:45.112891
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = dict({'key': 'value'})
    mime = 'application/json'
    j_s_o_n_formatter_0.format_body(body, mime)



# Generated at 2022-06-25 18:57:52.752379
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    result_0 = j_s_o_n_formatter_0.format_body(s_s_t_r_0_0='', m_i_m_e_0_0='json')
    assert(type(result_0) is str); print(result_0)
    result_1 = j_s_o_n_formatter_0.format_body(s_s_t_r_0_1='', m_i_m_e_0_1='javascript')
    assert(type(result_1) is str); print(result_1)

# Generated at 2022-06-25 18:58:02.462293
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from io import StringIO
    import sys
    #
    # Call method
    #
    j_s_o_n_formatter_0 = JSONFormatter()
    s_t_r_out_0 = StringIO()
    sys.stdout = s_t_r_out_0
    j_s_o_n_formatter_0.format_body('{"a": 42}', 'application/json')
    sys.stdout = sys.__stdout__
    s_t_r_out_0.seek(0)
    #
    # Assertion
    #
    assert s_t_r_out_0.read() == '"{\\n    \\"a\\": 42\\n}"\n'

# Generated at 2022-06-25 18:58:05.175486
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body(str(), str()) == str()

# Generated at 2022-06-25 18:58:12.884975
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    def test_body_0(arg_0, arg_1):
        if arg_0 == '' and arg_1 == '':
            return ''
        else:
            return 'Invalid'
    
    def test_body_1(arg_0, arg_1):
        if arg_0 == '{"a": "b"}' and arg_1 == 'application/json':
            return '{"a": "b"}'
        else:
            return 'Invalid'
    
    def test_body_2(arg_0, arg_1):
        if arg_0 == '{"a": "b"}' and arg_1 == 'text':
            return '{"a": "b"}'
        else:
            return 'Invalid'
    

# Generated at 2022-06-25 18:58:18.054813
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter_0 = JSONFormatter()
    json_formatter_0.config_values = {'json': {'sort_keys': True, 'indent': 2, 'format': True}}
    body = [""]
    mime = [""]
    actual = json_formatter_0.format_body(body[0], mime[0])
    expected = "{}"
    print(actual)
    assert actual == expected


# Generated at 2022-06-25 18:58:20.669780
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    assert isinstance(j_s_o_n_formatter.format_body('', ''), str)