

# Generated at 2022-06-25 18:49:37.386953
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    arg_0_0 = "{\n  \"key\": \"value\"\n}"
    arg_0_1 = "application/json"
    try:
        ret_0 = j_s_o_n_formatter_0.format_body(arg_0_0, arg_0_1)
    except SystemExit:
        raise
    except BaseException:
        raise
    else:
        assert ret_0 == "{\n  \"key\": \"value\"\n}"


# Generated at 2022-06-25 18:49:42.876054
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    this_body = 'First line.\nSecond line.'
    this_mime = 'text/plain'
    actual_format_body_result = j_s_o_n_formatter_0.format_body(this_body, this_mime)
    assert this_body == actual_format_body_result


# Generated at 2022-06-25 18:49:46.837107
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body(
        body='{"something": "some JSON"}',
        mime='json'
    ) == '''{
    "something": "some JSON"
}'''

# Generated at 2022-06-25 18:49:50.664538
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test0:
    j_s_o_n_formatter_0 = JSONFormatter()
    body = "body"
    mime = "mime"
    assert j_s_o_n_formatter_0.format_body(body, mime) is None


# Generated at 2022-06-25 18:49:55.321199
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_1 = JSONFormatter()
    json_input = '{"name":"Ivan Ivanov","age":23,"city":"Varna"}'
    if j_s_o_n_formatter_1.enabled:
        assert j_s_o_n_formatter_1.format_body(json_input, 'json') == '{\n    "age": 23,\n    "city": "Varna",\n    "name": "Ivan Ivanov"\n}'


# Generated at 2022-06-25 18:50:04.622095
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.strategies import just
    from hypothesis.strategies import one_of
    mime = one_of([just("json"), just("javascript"), just("text")])
    body = text(alphabet=["abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "0123456789", " -+=!@#$%^&*()_\",./\|{[]}", "\n", "\r", "\t", " "], min_size=0, max_size=1000)
    j_s_o_n_formatter_1 = JSONFormatter()

# Generated at 2022-06-25 18:50:09.769307
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    # Calling 0 parameter(s)
    body_0 = " { \"example\":\"value\" } "

    mime_0 = "application/json"


    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) is None
    #  '{\n    "example": "value"\n}'

# Generated at 2022-06-25 18:50:12.540410
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        import sys
        import __builtin__
        JSONFormatter.__base__ = __builtin__.object
        gv = JSONFormatter()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 18:50:20.090148
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options = {'json': {'format': False}}
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': True}}
    j_s_o_n_formatter_2 = JSONFormatter()
    j_s_o_n_formatter_2.format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    j_s_o_n_formatter_3 = JSONFormatter()
    j_s_o_n_form

# Generated at 2022-06-25 18:50:30.750312
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert (j_s_o_n_formatter_0.format_body("""{"a": 1}""", 'json')
            == """{"a": 1}""")
    assert (j_s_o_n_formatter_0.format_body("""{"a": 1}""", 'javascript')
            == """{"a": 1}""")

# Generated at 2022-06-25 18:50:45.951111
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = '{"a": "b", "c": "d"}'
    mime_0 = 'application/json'
    j_s_o_n_formatter_0.kwargs.explicit_json = False
    j_s_o_n_formatter_0.kwargs.sort_keys = True
    j_s_o_n_formatter_0.kwargs.indent = 4
    out = '{\n    "a": "b",\n    "c": "d"\n}'
    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) == out


# Generated at 2022-06-25 18:50:48.034883
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        j_s_o_n_formatter_0 = JSONFormatter()
    except:
        assert False

# Generated at 2022-06-25 18:50:56.385154
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter(**{'explicit_json': False, 'format_options': {'json': {'format': False, 'indent': None, 'sort_keys': True}}, 'stream': [{'Header': 'HTTP/1.1 200 OK\r\n', 'Body': '{"Hello": "World"}', 'URL': 'https://httpbin.org/json'}]})
    assert isinstance(j_s_o_n_formatter_0, JSONFormatter)


# Generated at 2022-06-25 18:51:06.634576
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print("Testing JSONFormatter.format_body()...")
    assert JSONFormatter().format_body("{}", 'application/json') == "{\n}"
    assert JSONFormatter().format_body("{}", 'application/javascript') == "{\n}"
    assert JSONFormatter().format_body("{}", 'text/plain') == "{\n}"
    assert JSONFormatter().format_body("not_json", 'text/xml') == "not_json"
    assert JSONFormatter().format_body("{}", 'text/xml') == "{\n}"
    assert JSONFormatter().format_body("{}", 'application/xml') == "\n"
    assert JSONFormatter().format_body("{}", 'text/html') == "\n"

# Generated at 2022-06-25 18:51:13.615926
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = "{\n    \"key\": \"value\",\n    \"another_key\": \"another_value\"\n}"
    mime = "json"
    assert json_formatter.format_body(body, mime) == "{\n    \"another_key\": \"another_value\",\n    \"key\": \"value\"\n}"
    body = "{\"key\":\"value\",\"another_key\":\"another_value\"}"
    mime = "json"
    assert json_formatter.format_body(body, mime) == "{\"another_key\":\"another_value\",\"key\":\"value\"}"
    body = "[{\"key\":\"value\"},{\"another_key\":\"another_value\"}]"
    mime = "json"
    assert json_formatter

# Generated at 2022-06-25 18:51:16.468396
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body('', '') == ''


# Generated at 2022-06-25 18:51:23.165978
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = "{'a': {'b': 'c'}}"
    mime = "application/json"

# Generated at 2022-06-25 18:51:29.051415
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.kwargs = dict(explicit_json=False)
    mime = str()
    # body: str = str()
    body = None
    assert j_s_o_n_formatter_1.format_body(body=body, mime=mime) == body


# Generated at 2022-06-25 18:51:31.479923
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_body(body='body', mime='mime')

# Generated at 2022-06-25 18:51:31.976015
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert True

# Generated at 2022-06-25 18:51:46.212582
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Initializing variables
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.kwargs = {'explicit_json': False}
    # test the case where maybe_json doesn't contain the given mime
    # and 'json' isn't in self.kwargs['explicit_json']
    assert(j_s_o_n_formatter_0.format_body('{}', 'txt') == '{}')
    # test the case where maybe_json contains the given mime
    # and 'json' isn't in self.kwargs['explicit_json']
    assert(j_s_o_n_formatter_0.format_body('{}', 'json') == '{}')
    # test the case where maybe_json doesn't

# Generated at 2022-06-25 18:51:51.778935
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body_0: str = j_s_o_n_formatter_1.format_body(body="[{\"test\":\"one\"},{\"test\":\"two\"}]", mime="json")
    # assert body_0 == "[\n    {\n        \"test\": \"one\"\n    },\n    {\n        \"test\": \"two\"\n    }\n]"

# Generated at 2022-06-25 18:51:59.423340
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:52:07.608838
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    body_str_str_str_0 = 'application/json'
    body_str_str_str_1 = '{  "name": "John Doe",  "age": 42}'
    body_str_str_str_1 = '{  "age": 42,  "name": "John Doe"}'
    body_str_str_str_2 = 'application/json'
    body_str_str_str_3 = '{  "age": 42,  "name": "John Doe"}'


# Generated at 2022-06-25 18:52:11.743819
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # AssertionError raised
    try:
        assert j_s_o_n_formatter_0.format_body() is None
    except AssertionError:
        pass


# Generated at 2022-06-25 18:52:14.533814
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body('', '') == ''


# Generated at 2022-06-25 18:52:21.224460
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1_body = "{'foo': 'bar'}"
    j_s_o_n_formatter_1_mime = "application/json"
    j_s_o_n_formatter_1.enabled = True
    j_s_o_n_formatter_1.kwargs = {'explicit_json': False}
    j_s_o_n_formatter_1.format_options = {'json': {'format': True, 'indent': None, 'sort_keys': False}}
    # Test line coverage
    # assert j_s_o_n_formatter_1.format_body(j_s_o_n_formatter_1_body, j_s_

# Generated at 2022-06-25 18:52:27.009634
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = '{}'
    mime = 'application/json'
    assert j_s_o_n_formatter_0.format_body(body, mime) == body

# Test of instance JSONFormatter with arguments:
# json_formatter_0 = JSONFormatter(kwargs={})

# Generated at 2022-06-25 18:52:36.519878
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 0
    j_s_o_n_formatter_0 = JSONFormatter()
    # Test case 1
    j_s_o_n_formatter_1 = JSONFormatter()
    # Test case 2
    j_s_o_n_formatter_2 = JSONFormatter()
    # Test case 3
    j_s_o_n_formatter_3 = JSONFormatter()
    # Test case 4
    j_s_o_n_formatter_4 = JSONFormatter()
    # Test case 5
    j_s_o_n_formatter_5 = JSONFormatter()
    # Test case 6
    j_s_o_n_formatter_6 = JSONFormatter()
    # Test case 7
    j_s_o_n_formatter_7 = JSONFormatter()

# Generated at 2022-06-25 18:52:41.965091
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    try:
        j_s_o_n_formatter_1 = JSONFormatter()
        j_s_o_n_formatter_1.format_body('', '')
    except Exception as e:
        print ("Test for method format_body of class JSONFormatter failed: {}".format(e))
    else:
        print ("Test for method format_body of class JSONFormatter passed")
