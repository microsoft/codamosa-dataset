

# Generated at 2022-06-25 18:49:42.311080
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=True)
    assert '{"foo": "bar"}' == formatter._format_body(
        '{"foo": "bar"}',
        None
    )
    assert '{"foo": "bar"}' == formatter._format_body(
        '{"foo": "bar"}',
        'text/plain'
    )
    assert '{"foo": "bar"}' == formatter._format_body(
        '{"foo": "bar"}',
        'text/json'
    )
    assert '{"foo": "bar"}' == formatter._format_body(
        '{"foo": "bar"}',
        'text/javascript'
    )


# Generated at 2022-06-25 18:49:45.053683
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"hello": "world"}', 'application/json') == '{\n    "hello": "world"\n}'


# Generated at 2022-06-25 18:49:47.263349
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter(format_options=None, kwargs=None)


# Generated at 2022-06-25 18:49:49.987671
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    temp_0 = j_s_o_n_formatter_0.format_body('', 'json')


# Generated at 2022-06-25 18:49:54.309852
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def try_except_0():
        j_s_o_n_formatter_0 = JSONFormatter()
        body_0 = '{}'
        mime_0 = 'json'
        # Call method
        result = j_s_o_n_formatter_0.format_body(body_0, mime_0)
        assert (result == '{\n}')
    try_except_0()


# Generated at 2022-06-25 18:49:57.899356
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # self_0 is JSONFormatter
    j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:50:06.726326
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Initialize global variable to use later in test
    global mock_arguments_0
    global mock_kwargs_0
    global mock_env_0
    global mock_options_0
    global mock_body_1
    global mock_mime_0
    global mock_body_0

# Generated at 2022-06-25 18:50:10.473568
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_1 = JSONFormatter(explicit_json=False, kwargs={})
    assert j_s_o_n_formatter_1.kwargs == {}
    assert j_s_o_n_formatter_1.explicit_json == False


# Generated at 2022-06-25 18:50:14.392549
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    obj = {'a': '4', 'b': '2', 'c': '3'}
    body = json.dumps(obj)
    # Test the default case
    assert True == j_s_o_n_formatter_0.enabled
    assert obj == json.loads(j_s_o_n_formatter_0.format_body(body, "json"))

# Generated at 2022-06-25 18:50:19.313606
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test method format_body of class JSONFormatter
    body = '''{
    "hello": "world",
    "foo": "bar",
    "baz": [
        "qux",
        "quux"
    ]
}
'''
    mime = 'json'
    json_dict = json.loads(body)
    json_formatter = JSONFormatter()
    result = json.loads(json_formatter.format_body(body, mime))
    assert json_dict == result

# Generated at 2022-06-25 18:50:23.808004
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_case_0()

# Generated at 2022-06-25 18:50:30.533740
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_0 = 'foo'
    mime_0 = 'application/json'
    j_s_o_n_formatter_0 = JSONFormatter()
    result_0 = j_s_o_n_formatter_0.format_body(body_0, mime_0)
    print(result_0)

if __name__ == '__main__':
    test_case_0()
    test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:50:35.361017
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    # Asserts constructor equals to false
    assert str(json.dumps(j_s_o_n_formatter_0.options)) == '{"highlight": false, "json": {"format": false, "indent": 4, "sort_keys": false}}'




# Generated at 2022-06-25 18:50:45.350346
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-25 18:50:56.242960
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE, BINARY_SUPPRESSED_HELP_MSG
    assert FormatterPlugin.__bases__[0] == object
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options == {'json': {'format': True, 'indent': 2, 'sort_keys': True}}
    assert j_s_o_n_formatter_0.enabled == True
    assert j_s_o_n_formatter_0.kwargs == {'explicit_json': False}
    assert j_s_o_n_formatter_0.__init__.__defaults__ == (None,)


# Generated at 2022-06-25 18:50:57.309330
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True


# Generated at 2022-06-25 18:51:07.426106
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body_1 = j_s_o_n_formatter_1.format_body("application/json", "123")
    assert body_1 == "123"
    body_2 = j_s_o_n_formatter_1.format_body("text/html", "456")
    assert body_2 == "456"
    body_3 = j_s_o_n_formatter_1.format_body("text/javascript", "{\"user\":\"foo\"}")
    assert body_3 == "{\"user\": \"foo\"}"
    body_4 = j_s_o_n_formatter_1.format_body("text/json", "{\"user\":\"foo\"}")

# Generated at 2022-06-25 18:51:08.665056
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body() == JSONFormatter()

# Generated at 2022-06-25 18:51:10.980322
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert callable(JSONFormatter)


# Generated at 2022-06-25 18:51:14.991788
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body('body', 'mime') == 'body'


# Generated at 2022-06-25 18:51:30.981300
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json

    # No JSON in input strings -> no JSON in output strings.
    no_json_string = (
        'Who is buried in Grant\'s tomb?',
    )
    assert no_json_string == j_s_o_n_formatter_0.format_body(no_json_string, 'text')
    no_json_string = (
        'Give me liberty or give me death.',
    )
    assert no_json_string == j_s_o_n_formatter_0.format_body(no_json_string, 'text')
    no_json_string = (
        'Four score and seven years ago our fathers brought forth on this '
        'continent a new nation, conceived in liberty and dedicated to the '
        'proposition that all men are created equal.',
    )
    assert no

# Generated at 2022-06-25 18:51:40.638898
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.kwargs = {}
    j_s_o_n_formatter_0.format_options = {'json': {'format': False, 'indent': 4, 'sort_keys': False}}
    j_s_o_n_formatter_0.format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': False}}
    j_s_o_n_formatter_0.format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}

# Generated at 2022-06-25 18:51:41.992288
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert type(JSONFormatter()) == json.JSONFormatter
    assert type(JSONFormatter()) != unicode


# Generated at 2022-06-25 18:51:43.431784
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert isinstance(JSONFormatter(), JSONFormatter)


# Generated at 2022-06-25 18:51:51.491217
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    #
    # Making the assertion explicitly
    #
    assert j_s_o_n_formatter_0.format_body(
        body='{"foo": "bar", "spam": "eggs"}',
        mime='application/json'
    ) == '{\n    "foo": "bar",\n    "spam": "eggs"\n}'
    #
    assert j_s_o_n_formatter_0.format_body(
        body='{"foo": "bar", "spam": "eggs"}',
        mime='text/plain'
    ) == '{"foo": "bar", "spam": "eggs"}'



# Generated at 2022-06-25 18:51:57.462127
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert 'json' in j_s_o_n_formatter_1.format_options
    assert 'format' in j_s_o_n_formatter_1.format_options['json']
    assert 'indent' in j_s_o_n_formatter_1.format_options['json']
    assert 'sort_keys' in j_s_o_n_formatter_1.format_options['json']



# Generated at 2022-06-25 18:52:00.127246
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert(j_s_o_n_formatter_1.format_body("", "") == "")


# Generated at 2022-06-25 18:52:02.078271
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass 
# Unit tests for JSONFormatter.format_body()

# Generated at 2022-06-25 18:52:02.663009
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert True == True

# Generated at 2022-06-25 18:52:05.809503
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    # Allow trailing comma
    try:
        json.loads('{1:2,}')
    except ValueError:
        pass
    # Pass
    json.loads('{1:2}')


# Generated at 2022-06-25 18:52:18.103797
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True

# Generated at 2022-06-25 18:52:18.772648
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True



# Generated at 2022-06-25 18:52:20.549123
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()


# Generated at 2022-06-25 18:52:22.753877
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.enabled = self.format_options['json']['format']

# Generated at 2022-06-25 18:52:33.964946
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = '{\n    "a": {\n        "b": "c"\n    }\n}\n'
    mime = 'application/json'
    assert j_s_o_n_formatter_0.format_body(body, mime) == '{\n    "a": {\n        "b": "c"\n    }\n}\n'
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert j_s_o_n_formatter_0.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}\n'
    body = '1'
    mime = 'application/json'


# Generated at 2022-06-25 18:52:36.483511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body("[1<", "json")


# Generated at 2022-06-25 18:52:38.896871
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    # position_keyword_only_parameter()
    j_s_o_n_formatter_0.format_body()


# Generated at 2022-06-25 18:52:48.347238
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    j_s_o_n_formatter_1 = JSONFormatter()

    test_dict = {
        "Name": "Joe",
        "ID": 12
    }

    mime = 'json'

    # Act
    result = j_s_o_n_formatter_1.format_body(str(test_dict), mime)

    # Assert
    assert result == str(test_dict)


    # Arrange
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_options = dict({
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })


# Generated at 2022-06-25 18:52:58.730339
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter( **{'format_options': {'json': {'format': False, 'indent': 4, 'sort_keys': True}}, 'explicit_json': False, 'kwargs': {'explicit_json': False, 'format_options': {'json': {'format': False, 'indent': 4, 'sort_keys': True}}}} )

# Generated at 2022-06-25 18:53:03.013855
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    # j_s_o_n_formatter_1.format_body(0, 0)
    pass