

# Generated at 2022-06-25 18:49:40.320716
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print("Test method 'format_body' of class 'JSONFormatter'")
    # __init__ is called. No action needed here.
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = "abc"
    mime_0 = "abc"
    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) == "abc"
    body_1 = ""
    mime_1 = ""
    assert j_s_o_n_formatter_0.format_body(body_1, mime_1) == ""
    body_2 = ""
    mime_2 = "j"
    assert j_s_o_n_formatter_0.format_body(body_2, mime_2) == ""
   

# Generated at 2022-06-25 18:49:47.320740
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options = {'json': {'indent': 4, 'sort_keys': True, 'format': True}}
    j_s_o_n_formatter_0.kwargs = {'explicit_json': True}
    body = b'{"foo": 1, "bar": 2}'
    mime = 'json'
    j_s_o_n_formatter_0.format_body(body, mime)

# Generated at 2022-06-25 18:49:49.412307
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    j_s_o_n_formatter = JSONFormatter()

    assert not j_s_o_n_formatter.enabled



# Generated at 2022-06-25 18:49:50.175220
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()


# Generated at 2022-06-25 18:50:00.399554
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter_0 = JSONFormatter()
    mime_0 = ''
    body_0 = '''{
    "key": "value"
}'''
    expected_result_0 = '''{
    "key": "value"
}'''
    body_1 = '''{
    "key\\": "value"
}'''
    expected_result_1 = '''{
    "key\\": "value"
}'''
    body_2 = '''{
    "key\": "value"
}'''
    expected_result_2 = '''{
    "key\": "value"
}'''
    body_3 = '''{
    "key": "value"
}'''
    expected_result_3 = '''{
    "key": "value"
}'''


# Generated at 2022-06-25 18:50:03.474901
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    j_s_o_n_formatter_0 = JSONFormatter()

    # Act
    body = j_s_o_n_formatter_0.format_body(body="", mime="")

    # Assert

# Generated at 2022-06-25 18:50:12.182546
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "body string"
    mime = "text/html"
    j_s_o_n_formatter_1 = JSONFormatter(**{'explicit_json': False})
    result = j_s_o_n_formatter_1.format_body(body, mime)
    assert result == body
    body = "{\"foo\": 42}"
    mime = "text/html"
    j_s_o_n_formatter_2 = JSONFormatter(**{'explicit_json': False})
    result = j_s_o_n_formatter_2.format_body(body, mime)
    assert result == body
    body = "{\"foo\": 42}"
    mime = "application/json"

# Generated at 2022-06-25 18:50:14.221281
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter = JSONFormatter()
    assert isinstance(j_s_o_n_formatter, JSONFormatter)


# Generated at 2022-06-25 18:50:16.361272
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1 is not None

# Unit tests for method JSONFormatter.format_body

# Generated at 2022-06-25 18:50:23.230296
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import json
    import random
    import string

    # Setup inputs
    json_data = {}
    json_data['foo'] = random.randint(0, 1000)
    json_data['bar'] = [
        random.randint(0, 1001) for i in range(random.randint(0, 100))
    ]
    json_data['baz'] = ''.join(
        [random.choice(string.printable) for i in range(random.randint(0, 100))]
    )
    json_data['foobar'] = [
        ''.join([random.choice(string.printable)
                 for i in range(random.randint(0, 100))])
        for i in range(random.randint(0, 100))
    ]

    # Setup format options
    def_format_op

# Generated at 2022-06-25 18:50:33.838036
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    # TODO
    assert j_s_o_n_formatter.format_body(j_s_o_n_formatter, j_s_o_n_formatter, j_s_o_n_formatter) == None

# Generated at 2022-06-25 18:50:35.633189
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter



# Generated at 2022-06-25 18:50:38.226915
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body() == '{"a": 1}'

# Generated at 2022-06-25 18:50:47.560745
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    unittest.TestCase.assertEqual(self=test_case_0,
                                  first=j_s_o_n_formatter_0.format_body(
                                      body='{\\"field\\": \\"value\\"}'),
                                  second='{\n    "field": "value"\n}')
    unittest.TestCase.assertEqual(self=test_case_0,
                                  first=j_s_o_n_formatter_0.format_body(
                                      body='{\'field\': \'value\'}'),
                                  second='{\n    "field": "value"\n}')

# Generated at 2022-06-25 18:50:53.614113
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # j_s_o_n_formatter_0 = JSONFormatter()
    # body = "body"
    # mime = "mime"
    # highlight = True
    # print(j_s_o_n_formatter_0.format_body(body, mime, highlight))
    pass  # TODO: implement your test here



# Generated at 2022-06-25 18:50:57.931146
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = "42"
    mime = "text"
    body_repr = j_s_o_n_formatter_0.format_body(body, mime)
    assert body_repr == "42"

# Generated at 2022-06-25 18:51:01.569081
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from urllib.parse import urlparse

    j_s_o_n_formatter_0 = JSONFormatter()
    print(j_s_o_n_formatter_0.format_body('', 'javascript'))


# Generated at 2022-06-25 18:51:10.674226
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body = '''{
	"Bike": [
		{
			"id": 1,
			"name": "BMW",
			"color": "Black"
		},
		{
			"id": 2,
			"name": "Yamaha",
			"color": "White"
		}
	]
}'''
    mime = 'json'

# Generated at 2022-06-25 18:51:18.480259
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    kwargs_0 = dict(format=True, sort_keys=False, indent=2)
    j_s_o_n_formatter_0 = JSONFormatter(format_options=dict(json=kwargs_0))
    kwargs_1 = dict(explicit_json=False, json=dict(indent=2, sort_keys=False, format=True))
    assert j_s_o_n_formatter_0.kwargs == kwargs_1


# Generated at 2022-06-25 18:51:19.929712
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # TODO: implement the test for this method.
    pass


# Generated at 2022-06-25 18:51:31.478398
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter(format_options={'json': {'sort_keys': False, 'indent': 2, 'format': True}})
    j_s_o_n_formatter_0.kwargs = {'explicit_json': True}
    assert '"key": 42' in j_s_o_n_formatter_0.format_body('{"key": 42}', 'asd;ty=6;asd')

# Generated at 2022-06-25 18:51:32.300989
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()


# Generated at 2022-06-25 18:51:34.998930
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()



# Generated at 2022-06-25 18:51:44.732003
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Local variables for 2nd call of format_body
    body_1 = '{"__class__": "Process", "name": "Alex", "pid": 1234}'
    mime_1 = 'application/json'

    # Local variables for 1st call of format_body
    body_0 = '{"__class__": "Process", "name": "Alex", "pid": 1234}'
    mime_0 = 'application/json'

    # Expected return value from 1st call of format_body
    expected_return_value_0 = '{\n    "__class__": "Process",\n    "name": "Alex",\n    "pid": 1234\n}'

    # Expected return value from 2nd call of format_body

# Generated at 2022-06-25 18:51:53.540516
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Preconditions
    body = """{"authors": [{"name": "Jane Austen", "as": {"it": "is"}},
                    {"name": "Immanuel Kant", "as": [1, 4]}],
          "categories": ["philosophy", "fiction"],
          "title": "Best books in the world" }"""
    mime = "json"
    body = str(body)
    mime = str(mime)
    j_s_o_n_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:51:55.350000
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert True # TODO: may fail later


# Generated at 2022-06-25 18:52:01.325161
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = 'foo'
    mime = 'application/json'
    ret_val_0 = j_s_o_n_formatter_0.format_body(
        body=body,
        mime=mime,
    )
    assert ret_val_0 == 'foo'

# Generated at 2022-06-25 18:52:07.258291
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter(
        format_options=None
    )
    # json.dumps(..., ensure_ascii=False) is a bit tricky to work with
    # automatically. As long as it doesn't escape, we should be fine.
    assert "{" not in j_s_o_n_formatter_1.format_body(
        body='{"stuff": "unicode stuff"}',
        mime='json'
    )

# Generated at 2022-06-25 18:52:12.136049
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    try:
        j_s_o_n_formatter_0 = JSONFormatter()
        body = "some body"
        mime = "text"
        returned_value = j_s_o_n_formatter_0.format_body(body, mime)
        assert returned_value == body
    except Exception:
        assert False

# Generated at 2022-06-25 18:52:13.476002
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body('', '')



# Generated at 2022-06-25 18:52:29.512354
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    arg0_0 = "application/json"
    arg0_1 = '{"foo": "bar"}'
    assert(JSONFormatter().format_body(arg0_1, arg0_0) == '{\n    "foo": "bar"\n}')



# Generated at 2022-06-25 18:52:32.978968
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body, mime = str(), str()
    j_s_o_n_formatter_0.format_body(body=body, mime=mime)

# Generated at 2022-06-25 18:52:35.546832
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Case 0:
    j_s_o_n_formatter_0 = JSONFormatter()
    assert (j_s_o_n_formatter_0.enabled == False)


# Generated at 2022-06-25 18:52:41.698124
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    j_s_o_n_formatter_1 = JSONFormatter()

    with open('test_JSONFormatter_format_body.json') as f:

        body = f.read()
        assert j_s_o_n_formatter_1.format_body(body, 'json') == body
        assert j_s_o_n_formatter_1.format_body(body, 'application/json') == body
        body = '{"foo": "bar"}'
        assert j_s_o_n_formatter_1.format_body(body, 'text') == body
        body = '{"foo": "bar"}'
        assert (j_s_o_n_formatter_1.format_body(body, 'foo')
                == '{"foo": "bar"}')

# Generated at 2022-06-25 18:52:43.947236
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    try:
        j_s_o_n_formatter_0 = JSONFormatter()
        assert (True)
    except:
        assert (False)


# Generated at 2022-06-25 18:52:50.875463
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    # Test method body_formatter of class JSONFormatter
    assert j_s_o_n_formatter_0.body_formatter({'data': [1, 2, 3], 'status_code': 200, 'headers': {'Content-Type': 'application/json'}}, 'application/json') == {'data': [1, 2, 3], 'status_code': 200, 'headers': {'Content-Type': 'application/json'}}


# Generated at 2022-06-25 18:52:59.800019
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    json_format_options = {
        'format': True,
        'indent': 0,
        'sort_keys': False
    }

    j_s_o_n_formatter_0 = JSONFormatter(format_options=json_format_options)


# Generated at 2022-06-25 18:53:01.215850
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert False

# Generated at 2022-06-25 18:53:07.021268
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_0 = 'Pk5CfR'
    mime_0 = 'json'
    j_s_o_n_formatter_0 = JSONFormatter()
    body_1 = j_s_o_n_formatter_0.format_body(body_0, mime_0)
    body_2 = '"Pk5CfR"'
    assert body_2 == body_1

# Generated at 2022-06-25 18:53:09.644809
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    if __name__ == '__main__':
        test_case_0()
        test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:53:40.988240
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body = "\u0001\u0080\u009F\u00A0\u00FF"
    mime = "\u0001\u0080\u009F\u00A0\u00FF"
    str_body = j_s_o_n_formatter_1.format_body(body, mime)
    assert str_body == "\u0001\u0080\u009F\u00A0\u00FF"


# Generated at 2022-06-25 18:53:41.790827
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True


# Generated at 2022-06-25 18:53:47.437246
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # test case as described at
    # https://github.com/jkbrzt/httpie/blob/master/tests/plugins/test_json.py#L16
    json_formatter = JSONFormatter()
    actual_result = json_formatter.format_body('{"a": 1}', 'json')
    assert actual_result == '{\n    "a": 1\n}'


# Generated at 2022-06-25 18:53:54.691989
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    json_format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }
    j_s_o_n_formatter_1.format_options = json_format_options
    j_s_o_n_formatter_1.kwargs['explicit_json'] = False
    body = '''{
    "users": {
        "user": [
            {
                "userdetails": {
                    "email": "john.doe@example.com",
                    "groupid": "john.doe"
                }
            }
        ]
    }
}'''
    mime = ''
    assert j_s_o_n

# Generated at 2022-06-25 18:53:57.620765
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True


# Generated at 2022-06-25 18:54:04.310106
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # These tests depend on the ordering option being set.
    _J_S_O_N_formatter_0 = JSONFormatter(**{'format_options': {'json': {'format': True, 'sort_keys': True, 'indent': 2}}})
    obj_0 = _J_S_O_N_formatter_0.format_body('[]', 'json')  # obj_0 == '[]'
    obj_1 = _J_S_O_N_formatter_0.format_body('{"foo": [1, 2, 3]}', 'json')  # obj_1 == '{\n  "foo": [\n    1,\n    2,\n    3\n  ]\n}'

# Generated at 2022-06-25 18:54:09.254472
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_body = '[{ "name": "Nathan", "age": 26, "favourite_number": 42 }]'
    formatted_body = j_s_o_n_formatter_0.format_body(test_body, "application/json")
    assert formatted_body == '[\n    {\n        "age": 26,\n        "favourite_number": 42,\n        "name": "Nathan"\n    }\n]'

# Generated at 2022-06-25 18:54:12.914607
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import str
    j_s_o_n_formatter_0 = JSONFormatter()
    str_0 = j_s_o_n_formatter_0.format_body('', '')
    assert str_0 == '', "Expected <''>, but got <{}>".format(str_0)


# Generated at 2022-06-25 18:54:20.656127
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter(log_file='_temp/run/interactive_mode/run_main/Model/log.md',
                                        log_path='_temp/run/interactive_mode/run_main/Model/',
                                        config_file='_temp/run/interactive_mode/run_main/Model/config.ini',
                                        config_path='_temp/run/interactive_mode/run_main/Model/',
                                        format_options={'json': {'indent': 0, 'format': True,
                                                                  'sort_keys': True}},
                                        kwargs={'explicit_json': False, 'headers': {}})


# Generated at 2022-06-25 18:54:26.129075
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_0 = j_s_o_n_formatter_0.format_body('{"a":1}', 'application/json')
    assert str_0 == '{"a":1}'


# Generated at 2022-06-25 18:54:52.711628
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    dictionary_of_json_formatter_objects = {
        'j_s_o_n_formatter_0': JSONFormatter(),
    }
    for key in dictionary_of_json_formatter_objects:
        j_s_o_n_formatter_0 = dictionary_of_json_formatter_objects[key]
        try:
            # Test for raises
            j_s_o_n_formatter_0.format_body(
                body='',
                mime=''
            )
        except Exception:
            pass

test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:55:02.682563
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    j_s_o_n_formatter_0 = JSONFormatter()
    # Data for method format_body of class JSONFormatter
    json_str = '{"json_key": "json_value"}'
    mimetype = 'application/json'
    # Expected result of method format_body of class JSONFormatter
    j_s_o_n_formatter_0.kwargs['explicit_json'] = False
    j_s_o_n_formatter_0.format_options['json']['format'] = True
    j_s_o_n_formatter_0.format_options['json']['sort_keys'] = False
    j_s_o_n_formatter_0.format_options['json']['indent'] = None
    result = (json.loads(json_str))

# Generated at 2022-06-25 18:55:12.981671
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter(**{"pretty": False, "indent": 2, "sorted": False, "ugly": False, "print_body": False, "explicit_json": False, "options": { "json": {"format": {"ugly": False, "sort_keys": True, "indent": 2}}}})
    assert j_s_o_n_formatter_0.format_body('', '') == ''
    assert j_s_o_n_formatter_0.format_body('{}', 'application/json') == '{}'
    assert j_s_o_n_formatter_0.format_body('{}', 'text/javascript') == '{}'

# Generated at 2022-06-25 18:55:19.279695
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # create an instance
    j_s_o_n_formatter_1 = JSONFormatter()

    # create an expected value
    expected1 = ""

    # get the actual value
    actual1 = j_s_o_n_formatter_1.format_body("", "")

    # compare
    assert expected1 == actual1



# Generated at 2022-06-25 18:55:20.546993
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body(None, 'json') == None


# Generated at 2022-06-25 18:55:22.414674
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # TODO: Test this method
    assert False


# Generated at 2022-06-25 18:55:25.288763
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body(
        body = '',
        mime = '',
    ) == ''


# Generated at 2022-06-25 18:55:28.107045
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body("foo", "foo") == "foo"

# Generated at 2022-06-25 18:55:36.189676
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body(): 
    j_s_o_n_formatter_1 = JSONFormatter()
    body = '{"foo": "bar"}'
    mime = 'json'
    assert j_s_o_n_formatter_1.format_body(body=body, mime=mime) == '{\n    "foo": "bar"\n}'
    body = '{"foo": "bar"}'
    mime = 'text'
    assert j_s_o_n_formatter_1.format_body(body=body, mime=mime) == '{\n    "foo": "bar"\n}'


# Generated at 2022-06-25 18:55:40.812598
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_0 = ".*"
    str_1 = ").*"
    str_2 = ")"
    dict_0 = dict([(123, 123), (456, 456)])
    expected_rv = json.dumps(dict_0)
    actual_rv = j_s_o_n_formatter_0.format_body(str_0, str_1, str_2)
    assert expected_rv == actual_rv

# Generated at 2022-06-25 18:56:29.896000
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    j_s_o_n_formatter_0 = JSONFormatter()
    body = '<html><body>Hello world!</body></html>'
    mime = 'text/html'

    # Act
    v = j_s_o_n_formatter_0.format_body(body, mime)

    # Assert
    # self.assertEqual(v, '<html><body>Hello world!</body></html>', msg='A=B')
    # self.assertEqual(v, '<html><body>Hello world!</body></html>', msg='A=C')
    # self.assertTrue(v != '<html><body>Hello world!</body></html>', msg='A=D')
    # self.assertTrue(v != '<html><body>Hello

# Generated at 2022-06-25 18:56:34.380953
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter(explicit_json=False, json={'format': True, 'sort_keys': True, 'indent': '  '})
    assert j_s_o_n_formatter_0.format_body('{}', 'application/json') == '{}'


# Generated at 2022-06-25 18:56:36.926395
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    assert j_s_o_n_formatter_1.format_body('', '') == ''


# Generated at 2022-06-25 18:56:46.878921
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.kwargs['explicit_json'] = False
    j_s_o_n_formatter_0.format_options['json']['format'] = True
    j_s_o_n_formatter_0.format_options['json']['indent'] = 2
    j_s_o_n_formatter_0.format_options['json']['sort_keys'] = True
    str_0 = j_s_o_n_formatter_0.format_body("{\"hi\": \"there\"}", "text/json")
    assert str_0 == '{\"hi\": \"there\"}'
    str_0 = j_s_o_n_formatter_0

# Generated at 2022-06-25 18:56:49.081175
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body('', '') == ''


# Generated at 2022-06-25 18:56:50.305854
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True, "Failed to implement this method"

# Generated at 2022-06-25 18:56:54.063825
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print("Testing JSONFormatter.format_body")
    # Unit test 0:
    j_s_o_n_formatter_0 = JSONFormatter()
    # body = 
    # mime = 
    # j_s_o_n_formatter_0.format_body(body, mime)
    # expect: 
    # raise NotImplementedError()

# Generated at 2022-06-25 18:57:01.862516
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    args_0 = {'json': {'indent': 4, 'sort_keys': True, 'format': True}}
    j_s_o_n_formatter_0 = JSONFormatter(**args_0)
    j_s_o_n_formatter_0.args = ( '', {'json': {'indent': 4, 'sort_keys': True, 'format': True}})
    j_s_o_n_formatter_0.kwargs = {'json': {'indent': 4, 'sort_keys': True, 'format': True}}
    j_s_o_n_formatter_0.format_options = {'json': {'indent': 4, 'sort_keys': True, 'format': True}}
    mime = 'json'

# Generated at 2022-06-25 18:57:11.412580
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.core import main
    from httpie.plugins.json import JSONFormatter
    from json import dumps
    from tempfile import NamedTemporaryFile

    # Test a full JSON object with indentation
    json_body = {
        "name": "Bob",
        "age": 42,
        "gender": "Male",
        "city": "Aliceville",
        "state": "AL",
        "country": "USA",
        "employer": "GitHub, Inc."
    }
    p = JSONFormatter()
    json_body = p.format_body(dumps(json_body), "application/json")
    assert '\n' in json_body

    # Test a full JSON with no indentation

# Generated at 2022-06-25 18:57:16.366201
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body = b"body"
    mime = "application/json"
    result = j_s_o_n_formatter_1.format_body(body, mime)
    assert type(result) is str
    assert json.loads(result) == body


# Generated at 2022-06-25 18:58:55.720277
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    j_s_o_n_formatter_0.kwargs['explicit_json'] = False
    j_s_o_n_formatter_0.kwargs['stream'] = False
    j_s_o_n_formatter_0.kwargs['style'] = None
    j_s_o_n_formatter_0.kwargs['colors'] = True
    j_s_o_n_formatter_0.kwargs['verbose'] = False
    j_s_o_n_formatter_0.kwargs['pretty'] = False
    j_s_o_n_formatter_0.kwargs['all'] = False

# Generated at 2022-06-25 18:59:00.696749
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_arg = 'body_arg'
    mime_arg = 'mime_arg'
    j_s_o_n_formatter_0 = JSONFormatter()
    result = j_s_o_n_formatter_0.format_body(body_arg, mime_arg)
    assert result == 'body_arg'



# Generated at 2022-06-25 18:59:05.533998
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()

    # Call method format_body
    # j_s_o_n_formatter_1.format_body()


if __name__ == '__main__':
    test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:59:16.845805
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # json, javascript, text - enable
    json_content_type_tests = [
        ('json', 'application/json'),
        ('javascript', 'application/javascript'),
        ('text', 'text/html')
    ]
    for token, mime in json_content_type_tests:
        j_s_o_n_formatter_0 = JSONFormatter()
        tempvar = j_s_o_n_formatter_0.format_body('content', 'application/{}'.format(token))
        assert tempvar == 'content'

    # json, javascript, text - disable
    json_content_type_tests = [
        ('json', 'application/json'),
        ('javascript', 'application/javascript'),
        ('text', 'text/html')
    ]
    j_s_o_n_formatter_0

# Generated at 2022-06-25 18:59:20.556176
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body('', 'text/javascript') == '{"foo":1,"bar":2}'
    assert j_s_o_n_formatter_0.format_body('foo', 'text/javascript') == '{"foo":1,"bar":2}'



# Generated at 2022-06-25 18:59:29.997275
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()

    body_0 = '{"hello": "it s me"}'
    mime_0 = 'json'

    body_1 = '{"hello": "it s me"}'
    mime_1 = 'javascript'

    body_2 = '{"hello": "it s me"}'
    mime_2 = 'text'

    body_3 = '{"hello": "it s me"}'
    mime_3 = 'text/json'

    format_body_0 = j_s_o_n_formatter_0.format_body(body_0, mime_0)
    format_body_1 = j_s_o_n_formatter_0.format_body(body_1, mime_1)
    format_body_2