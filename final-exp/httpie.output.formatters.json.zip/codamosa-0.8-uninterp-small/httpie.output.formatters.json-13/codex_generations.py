

# Generated at 2022-06-25 18:49:41.452117
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.formatter import JSONFormatter
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.configure(argparse_args=None)
    assert j_s_o_n_formatter_0.enabled == True
    assert j_s_o_n_formatter_0.kwargs == {'explicit_json': False}
    body = '{\n    "hello": "world",\n    "sorted": 42\n}'
    mime = 'text/json'

# Generated at 2022-06-25 18:49:45.862429
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body: str
    mime: str
    try:
        j_s_o_n_formatter_0 = JSONFormatter()
        body = j_s_o_n_formatter_0.format_body(body, mime)
    except:
        print('Exception: test_JSONFormatter_format_body')


# Generated at 2022-06-25 18:49:49.102425
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()
    assert JSONFormatter(format_options={'json': {'format': False, 'sort_keys': False, 'indent': 4}}, kwargs={'explicit_json': False})



# Generated at 2022-06-25 18:49:51.569528
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert_equal(JSONFormatter, j_s_o_n_formatter_0.__class__)



# Generated at 2022-06-25 18:49:58.704440
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Set up mock object
    j_s_o_n_formatter = JSONFormatter()

    # Set up method parameters
    body = 'my body'
    mime = 'my mime'

    # Invoke method
    result = j_s_o_n_formatter.format_body(body=body, mime=mime)

    # Check for method output
    assert result == 'my body'

# Generated at 2022-06-25 18:50:01.527598
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_body(
        body="",
        mime="",
    )


# Generated at 2022-06-25 18:50:03.521632
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    str_2 = j_s_o_n_formatter_1.format_body(str(''), str(''))
    assert str_2 == str('')


# Generated at 2022-06-25 18:50:07.772736
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter = JSONFormatter(
        args=(),
        config=None,
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        output_file=None,
        stdin=None
    )


# Generated at 2022-06-25 18:50:15.937468
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    text = '{  "foo" : "bar" }'
    json_text = '{\n  "foo": "bar"\n}'
    assert(JSONFormatter(explicit_json=False,
                         format_options={'json': {'format': True,
                                                  'indent': 2,
                                                  'sort_keys': True}}
                         ).format_body(text, 'text/html') == text)
    assert(JSONFormatter(explicit_json=False,
                         format_options={'json': {'format': True,
                                                  'indent': 2,
                                                  'sort_keys': True}}
                         ).format_body(text, 'application/json') == json_text)

# Generated at 2022-06-25 18:50:17.025168
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()


# Generated at 2022-06-25 18:50:24.344984
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert(isinstance(JSONFormatter(), JSONFormatter))


# Generated at 2022-06-25 18:50:29.418170
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_arg_1 = "abc"
    str_arg_2 = "abc"
    assert j_s_o_n_formatter_0.format_body(str_arg_1, str_arg_2) == "abc"


# Generated at 2022-06-25 18:50:31.024250
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_case_0()

''' Output:

'''

# Generated at 2022-06-25 18:50:37.604699
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = 'some body'
    mime = 'json'
    j_s_o_n_formatter = JSONFormatter()
    result = j_s_o_n_formatter.format_body(body, mime)
    assert result == '"some body"'


# Generated at 2022-06-25 18:50:46.530000
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fixture_a_0 = ['']
    j_s_o_n_formatter_0 = JSONFormatter()
    fixture_b_0 = ['']
    assert j_s_o_n_formatter_0.format_body(fixture_a_0[0], fixture_b_0[0]) == fixture_a_0[0]

    fixture_a_1 = ['']
    j_s_o_n_formatter_1 = JSONFormatter()
    fixture_b_1 = ['']
    assert j_s_o_n_formatter_1.format_body(fixture_a_1[0], fixture_b_1[0]) == fixture_a_1[0]



# Generated at 2022-06-25 18:50:51.155136
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Test case for function format_body of class JSONFormatter."""
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body("{\"hello\": \"world\"}", "application/json") == "{\"hello\": \"world\"}"

# Generated at 2022-06-25 18:51:02.248255
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body("", "") == ""
    assert j_s_o_n_formatter_0.format_body("", "json") == ""
    assert j_s_o_n_formatter_0.format_body('{"a": "b"}', "json") == '{"a": "b"}'
    assert j_s_o_n_formatter_0.format_body('{"a": "b"}', "text/json") == '{\n    "a": "b"\n}'

# Generated at 2022-06-25 18:51:10.969020
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    data_0 = 'test string'
    assert j_s_o_n_formatter_0.format_body(data_0, 'test string') == 'test string'
    data_1 = json.dumps({'my_key': 'my value'})
    assert j_s_o_n_formatter_0.format_body(data_1, 'json') == (
        "{\n"
        "    \"my_key\": \"my value\"\n"
        "}"
    )
    data_2 = json.dumps([1, 2, 3, 4])

# Generated at 2022-06-25 18:51:15.712288
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body_0 = ""
    mime_0 = ""
    assert j_s_o_n_formatter_0.format_body(body_0, mime_0) is None


# Generated at 2022-06-25 18:51:25.166825
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_options = None
    j_s_o_n_formatter_1.kwargs = None
    j_s_o_n_formatter_1.format_options = {'json': {'format': True, 'indent': 0, 'sort_keys': False}}
    j_s_o_n_formatter_1.kwargs = {'explicit_json': False}
    body = j_s_o_n_formatter_1.format_body("{}", "json")
    assert body == '{}'


# Generated at 2022-06-25 18:51:45.766972
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body = '''""'''
    mime = '''""'''
    assert j_s_o_n_formatter_1.format_body(body, mime) == '''""'''
    body = '''""'''
    mime = '''""'''
    assert j_s_o_n_formatter_1.format_body(body, mime) == '''""'''
    body = '''""'''
    mime = '''""'''
    assert j_s_o_n_formatter_1.format_body(body, mime) == '''""'''
    body = '''""'''
    mime = '''""'''
    assert j_s_o_n_form

# Generated at 2022-06-25 18:51:54.607668
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.kwargs = {'explicit_json': False, }
    j_s_o_n_formatter_0.format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 2, }, }
    assert j_s_o_n_formatter_0.format_body('{"a": 1}', 'application/json') == '{\n  "a": 1\n}'
    j_s_o_n_formatter_0.kwargs = {'explicit_json': True, }

# Generated at 2022-06-25 18:52:04.612837
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.kwargs['explicit_json'] = False
    j_s_o_n_formatter_0.format_options['json']['format'] = False
    j_s_o_n_formatter_0.format_options['json']['indent'] = 4
    j_s_o_n_formatter_0.format_options['json']['sort_keys'] = True

    result = j_s_o_n_formatter_0.format_body("""
    {
        "foo": "bar",
        "baz": "q"
    }
    """, "json")


    print("result = " + str(result))

# Generated at 2022-06-25 18:52:06.192209
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_0 = JSONFormatter()

    # This test case is currently assumed as failed, needs update.

# Generated at 2022-06-25 18:52:13.293924
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # If a user explicitly asks for JSON formatting, but the body
    # is not valid JSON, return the body unchanged.
    j_s_o_n_formatter_1 = JSONFormatter(**{'explicit_json': True})
    assert j_s_o_n_formatter_1.format_body(
        body="foo_bar-spam-baz",
        mime="text/plain"
    ) == "foo_bar-spam-baz"


# Generated at 2022-06-25 18:52:14.734596
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    # j_s_o_n_formatter_0.format_body(body, mime)


# Generated at 2022-06-25 18:52:16.152342
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert j_s_o_n_formatter_0.format_body() == None


# Generated at 2022-06-25 18:52:24.619320
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert JSONFormatter.format_body(j_s_o_n_formatter_0, 'ayqgq', 'json') == 'ayqgq'
    assert JSONFormatter.format_body(j_s_o_n_formatter_0, 'o', 'javascript') == 'o'
    assert JSONFormatter.format_body(j_s_o_n_formatter_0, '}jVn\xc6\x8b7', 'application/json') == '}jVn\xc6\x8b7'

# Generated at 2022-06-25 18:52:29.583884
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    j_s_o_n_formatter_0 = JSONFormatter()
    body_str = "TESTbODY"
    mime_str = "application/json"

    assert j_s_o_n_formatter_0.format_body(body_str, mime_str) == "\"TESTbODY\""

# Generated at 2022-06-25 18:52:36.345611
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # arrange
    j_s_o_n_formatter_1 = JSONFormatter()
    body = str
    mime = str
    expected = str

    # act
    result = j_s_o_n_formatter_1.format_body(body, mime)

    # assert
    assert result == expected

# unit tests end here

# execution start here

if __name__ == '__main__':
    for test in [test_case_0, test_JSONFormatter_format_body]:
        test()
    print('All unit tests passed')

# Generated at 2022-06-25 18:53:10.467067
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    if 'python' in __file__:
        import sys
        import os
        path = os.path.join(os.path.dirname(__file__), '..')
        sys.path.insert(0, path)
        from httpie.plugins import FormatterPlugin
        import pytest
        __file__ = 'httpie/plugins/json.py'
        pytest.main([__file__])
    else:
        from unittest import TestCase
        from httpie.compat import unicode
        from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
        from httpie.plugins import FormatterPlugin
        from utils import http

        body = b'{ "a": 1 }'

        class TestJSON(TestCase):

            def test_valid_json(self):
                env = TestEnvironment

# Generated at 2022-06-25 18:53:16.267913
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for method format_body.
    # Expected: This method formats the body to a human readable format
    #           if its Content-Type is json or javascript.
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'

# Generated at 2022-06-25 18:53:17.136706
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True

# Generated at 2022-06-25 18:53:20.107712
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter(**j_s_o_n_formatter_0.kwargs)
    assert j.kwargs == j_s_o_n_formatter_0.kwargs

# Generated at 2022-06-25 18:53:28.243756
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0._data_formatter_0 = JSONFormatter()

# Generated at 2022-06-25 18:53:31.522702
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    j_s_o_n_formatter_0 = JSONFormatter()
    body, mime = ("A", "application/json")
    value = j_s_o_n_formatter_0.format_body(body, mime)

    assert value == '"A"'


# Generated at 2022-06-25 18:53:38.741131
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    assert j_s_o_n_formatter.format_body(
        """{'boolFalse': False, 'boolTrue': True, 'int': -12345, 'list': [0, 1, 2], 'str': 'auto-test'}"""
        '''application/json''',
        """{"boolFalse": false, "boolTrue": true, "int": -12345, "list": [0, 1, 2], "str": "auto-test"}"""
        '''application/json'''
    )

# Generated at 2022-06-25 18:53:41.233027
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    obj = JSONFormatter()
    try:
        assert obj
    except AssertionError as e:
        print(e)
    else:
        del obj


# Generated at 2022-06-25 18:53:42.377147
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # NOTE: Refer to README.md for formatting tests.
    pass

# Generated at 2022-06-25 18:53:47.357896
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test without args
    j_s_o_n_formatter_0 = JSONFormatter()
    mime = None
    body = b''
    assert j_s_o_n_formatter_0.format_body(body, mime) == ''


test_case_0()

# vim: syntax=python

# Generated at 2022-06-25 18:54:14.363166
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"created_at":"Tue May 31 17:46:55 +0000 2011","id":73856101991652352}'
    mime = 'application/json; charset=utf-8'
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body(body, mime)

# Generated at 2022-06-25 18:54:15.138663
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    obj = JSONFormatter()

# Generated at 2022-06-25 18:54:15.764627
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_1 = JSONFormatter()

# Generated at 2022-06-25 18:54:17.075023
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()

# Unit test to check Json Formatting

# Generated at 2022-06-25 18:54:27.681296
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options['json']['indent'] = 4
    j_s_o_n_formatter_0.format_options['json']['sort_keys'] = True
    j_s_o_n_formatter_0.kwargs['explicit_json'] = False
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert j_s_o_n_formatter_0.format_body(body, mime) == (json.dumps(obj=json.loads(body), sort_keys=True, ensure_ascii=False, indent=4))

# Generated at 2022-06-25 18:54:31.542007
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options['json']['format'] = False
    str_arg_0 = j_s_o_n_formatter_0.format_body('', 'json')
    assert str_arg_0 == ''


# Generated at 2022-06-25 18:54:38.244966
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert {'json': {'format': None, 'indent': 4, 'sort_keys': True}} == j_s_o_n_formatter_0.format_options
    assert False == j_s_o_n_formatter_0.enabled
    assert {'explicit_json': False} == j_s_o_n_formatter_0.kwargs
    body = '[{"id": "00000001", "name":"example.com"},{"id": "00000002", "name":"example.org"}]'
    mime = 'json'

# Generated at 2022-06-25 18:54:48.774683
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "null"
    mime = "json"
    # Create an instance of the class that should be tested
    j_s_o_n_formatter_1 = JSONFormatter()
    # Create a mock instance of the parent class of this class if and when needed for the test
    j_s_o_n_formatter_1_parent = FormatterPlugin()
    # Replace the attributes of the instance to be tested by the mock instance and its attributes
    # TODO: Replace only the class attributes of the instance without replacing the whole instance
    j_s_o_n_formatter_1.kwargs = j_s_o_n_formatter_1_parent.kwargs

# Generated at 2022-06-25 18:54:51.093728
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.kwargs == {}, "class JSONFormatter: constructor test failed"


# Generated at 2022-06-25 18:54:59.778740
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0.format_body('{\"a\":1}', 'json') == '{\n    "a": 1\n}'
    assert j_s_o_n_formatter_0.format_body('[1,2,3]', 'text') == '[\n    1,\n    2,\n    3\n]'
    assert j_s_o_n_formatter_0.format_body('{\"a\":1}', 'text') == '{\"a\":1}'

# Generated at 2022-06-25 18:55:53.778613
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    str_arg_0 = "{}"
    str_arg_1 = "application/json"
    ret_0 = j_s_o_n_formatter_0.format_body(str_arg_0, str_arg_1)
    assert ret_0 == "{}"

# Generated at 2022-06-25 18:55:54.709046
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert callable(JSONFormatter)

# Generated at 2022-06-25 18:55:58.238098
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_options['json']['sort_keys'] = False
    j_s_o_n_formatter_0.format_options['json']['indent'] = 0
    j_s_o_n_formatter_0.format_body('{"key": "value"}', 'json')


# Generated at 2022-06-25 18:56:05.767191
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():


    # Test with valid json
    test_JSONFormatter_format_body_0 = j_s_o_n_formatter_0.format_body(
        '{"test":true}',
        'application/json'
    )
    assert test_JSONFormatter_format_body_0 == '{"test": true}'

    # Test with invalid json
    test_JSONFormatter_format_body_1 = j_s_o_n_formatter_0.format_body(
        '{"test":true}',
        'application/other-json'
    )
    assert test_JSONFormatter_format_body_1 == '{"test":true}'

    # Test with invalid json

# Generated at 2022-06-25 18:56:06.863319
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Initial logger level is WARNING
    pass


# Generated at 2022-06-25 18:56:11.426762
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j_s_o_n_formatter_1 = JSONFormatter(**{'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}, 'ignore': False, 'kwargs': {'explicit_json': False}, 'preferred': False})
    assert j_s_o_n_formatter_1.format_options['json']['format'] == True
    assert j_s_o_n_formatter_1.kwargs['explicit_json'] == False


# Generated at 2022-06-25 18:56:22.884011
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.formatters import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie import ExitStatus
    from io import StringIO

    class Mock_JSONFormatter(JSONFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['json']['format']

        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                    or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass  # Invalid JSON, ignore

# Generated at 2022-06-25 18:56:23.789581
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_case_0()



# Generated at 2022-06-25 18:56:30.637675
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    j_s_o_n_formatter_1 = JSONFormatter(
        explicit_json=False,
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': None
            }
        },
        output_options={
            'json': {
                'group_array_items': None,
                'json_mode': None
            }
        },
        render_options={
            'json': {
                'colors': True
            }
        }
    )
    body_0 = '{"a": 1}'
    mime_0 = 'application/json'
    actual_0 = j_s_o_n_formatter_1.format_body(body_0, mime_0)

# Generated at 2022-06-25 18:56:40.041324
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 2:
    j_s_o_n_formatter_2 = JSONFormatter()
    # AssertionError: Can't assert that '{ "key": "value" }' confirmed equal to
    # '{ "key": "value" }'.
    assert j_s_o_n_formatter_2.format_body('{ "key": "value" }', 'application/json') == '{ "key": "value" }', \
        "Expected: '{ \"key\": \"value\" }' Actual: '{ \"key\": \"value\" }'"
    j_s_o_n_formatter_2 = JSONFormatter()
    # AssertionError: Can't assert that '{ "key": "value" }' confirmed equal to
    # '{ "key": "value" }'.
    assert j_

# Generated at 2022-06-25 18:57:26.356640
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import registry
    registry.remove_all()

    import json
    import os
    import pathlib
    import sys
    import tempfile
    import unittest
    from httpie.core import main
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import registry
    from httpie.plugins import builtin

    from units.utils import MockEnvironment

    # Initialize registries
    builtin.DEFAULT_FORMATTERS = FormatterPlugin.load_default_formatters()
    registry.DEFAULT_FORMATTERS = FormatterPlugin.load_default_formatters()
    builtin.AVAILABLE_FORMATTERS = FormatterPlugin.find_plugin_classes()
    registry.AVAILABLE_FORMATTERS = FormatterPlugin.find_plugin

# Generated at 2022-06-25 18:57:32.344892
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter = JSONFormatter()
    j_s_o_n_formatter.kwargs = {'explicit_json': True}
    j_s_o_n_formatter.format_options = {'json': {'format': False}}
    body = '{"a": "b"}'
    mime = 'application/json'
    result = JSONFormatter.format_body(j_s_o_n_formatter, body, mime)
    assert result == '{\n    "a": "b"\n}'

if __name__ == '__main__':
    test_JSONFormatter_format_body()
    test_case_0()

# Generated at 2022-06-25 18:57:43.774170
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"success": true, "value": [{"foo": 1.1e+1, "bar": [1,2,3]}]}'
    expected = '{\n    "success": true,\n    "value": [\n        {\n            "bar": [\n                1,\n                2,\n                3\n            ],\n            "foo": 11.0\n        }\n    ]\n}'
    actual = JSONFormatter().format_body(body, 'json')
    assert expected == actual, "Expected {}, but got {}".format(expected, actual)

if __name__ == '__main__':
    from sklearn.metrics import accuracy_score


# Generated at 2022-06-25 18:57:46.015152
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    j_s_o_n_formatter_0.format_body('', '')



# Generated at 2022-06-25 18:57:51.539841
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    j_s_o_n_formatter_1.format_options = {'json': {'sort_keys': True, 'indent': 4, 'format': True}}
    j_s_o_n_formatter_1.kwargs = {'explicit_json': True}
    str_arg_0 = j_s_o_n_formatter_1.format_body("{}", "json")
    assert str_arg_0 == "{}"


# Generated at 2022-06-25 18:57:56.442373
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = 'This is sample text'
    mime = 'json'
    strigified = """{
    "key1": "value1", 
    "key2": "value2", 
    "key3": "value3"
}"""
    assert j_s_o_n_formatter_0.format_body(body, mime) == strigified

# Generated at 2022-06-25 18:58:00.654349
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    body = j_s_o_n_formatter_0.format_body("", "application/json")
    assert body == ""


# Generated at 2022-06-25 18:58:06.961727
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # case_0
    j_s_o_n_formatter_0 = JSONFormatter()
    r_0 = j_s_o_n_formatter_0.format_body("""\
    {
      "k1": "v1",
      "k2": "v2"
    }
    """, "application/json")
    assert """\
{
  "k1": "v1",
  "k2": "v2"
}
""" == r_0

# Generated at 2022-06-25 18:58:10.283454
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_0 = JSONFormatter()
    class_0 = json_0.format_body('text/html', 'text/html')
    assert class_0 is None

if __name__ == '__main__':
    test_case_0()
    test_JSONFormatter_format_body()

# Generated at 2022-06-25 18:58:12.337289
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
	j_s_o_n_formatter = JSONFormatter()
	body = "{'a': 1, 'b': 2}"
	mime = "json" # The mime of the body.
	assert type(j_s_o_n_formatter.format_body(body, mime)) == str

# Generated at 2022-06-25 18:59:08.497267
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_0 = JSONFormatter()
    assert j_s_o_n_formatter_0 == JSONFormatter()
    # Test that the method format_body of the class JSONFormatter is not
    # polymorphic.
    assert isinstance(j_s_o_n_formatter_0, JSONFormatter)
    # Test that the method format_body of the class JSONFormatter overrides
    # the method format_body of the class FormatterPlugin.
    assert issubclass(JSONFormatter, FormatterPlugin)
    assert issubclass(JSONFormatter, object)
    j_s_o_n_formatter_0.format_options = {'json': {'format': False, 'indent': 4, 'sort_keys': True}}
    assert j_s_o_n_

# Generated at 2022-06-25 18:59:16.958490
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    string_1 = "{'foo': 'bar'}"
    string_2 = j_s_o_n_formatter_1.format_body(string_1)
    assert string_2 == string_1, "Invalid string obtained"
    string_1 = "{'foo': 'bar'}"
    string_3 = "application/json"
    string_2 = j_s_o_n_formatter_1.format_body(string_1, string_3)
    assert string_2 == string_1, "Invalid string obtained"

if __name__ == '__main__':
    test_case_0()
    test_JSONFormatter_format_body()
    print("All tests passed")

# Generated at 2022-06-25 18:59:18.466866
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body("{\"a\": \"b\"}", "json") == "{\"a\": \"b\"}"

# Generated at 2022-06-25 18:59:22.171990
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    j_s_o_n_formatter_1 = JSONFormatter()
    body = '{"foo": "bar"}'
    mime = 'json'
    # print(j_s_o_n_formatter_1.format_body(body=body, mime=mime))


import unittest


# Generated at 2022-06-25 18:59:24.502965
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Test default case
    instance = JSONFormatter()
    body = 'Something complicated'
    mime = 'json'
    assert instance.format_body(body, mime) == 'Something complicated'



# Generated at 2022-06-25 18:59:30.559819
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 0
    j_s_o_n_formatter_0 = JSONFormatter()
    x_0 = j_s_o_n_formatter_0.format_body({
        'data': [1, 2, 3, 4],
        'name': 'example_data',
        'first': 'a'
    }, '/application/json')
    assert '{' in x_0
    assert x_0.count('\n') > 5

# vim: syntax=python