

# Generated at 2022-06-21 14:13:30.005364
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"hello":"world"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "hello": "world"\n}'

# Generated at 2022-06-21 14:13:41.910136
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    input_dict = dict()
    input_dict['json_str'] = '{' + '"key1": "value1", "key2": "value2"' + '}'
    input_dict['json_str'] += input_dict['json_str']  # String double.
    input_dict['json_str'] += input_dict['json_str']  # String quadruple.
    input_dict['json_mime'] = 'application/json'
    input_dict['invalid_json_str'] = '{"key": value}'  # Invalid JSON string.
    input_dict['invalid_json_mime'] = 'application/json'

# Generated at 2022-06-21 14:13:47.691164
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    class MockArgs:
        def __init__(self):
            self.json_format = False

    class MockFormatOptions:
        def __init__(self):
            self.json = {
                'format': False,
                'sort_keys': False,
                'indent': 0
            }

    args = MockArgs()
    format_options = MockFormatOptions()
    assert not JSONFormatter(args, format_options).enabled


# Unit tests for method format_body of class JSONFormatter

# Generated at 2022-06-21 14:13:56.579249
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.formatter.format_elements import get_format_from_options

    req_data = '{"test": "test"}'

    json_format = JSONFormatter(
        get_format_from_options({
            "json": {
                "format": True,
                "sort_keys": False,
                "indent": 4,
            }
        }),
    )

    assert json_format.format_body(req_data, 'application/json') == \
        '{\n    "test": "test"\n}'


# unit test for method format_body of class JSONFormatter

# Generated at 2022-06-21 14:14:07.586596
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin = JSONFormatter()
    result = formatter_plugin.format_body('{"a":1}', 'json')
    assert result == '{\n    "a": 1\n}'
    result = formatter_plugin.format_body('{"a":1}', 'javascript')
    assert result == '{\n    "a": 1\n}'
    result = formatter_plugin.format_body('{"a":1}', 'html')
    assert result == '{"a":1}'
    result = formatter_plugin.format_body('{"a":1', 'json')
    assert result == '{"a":1'
    result = formatter_plugin.format_body('{"a":1', 'javascript')
    assert result == '{"a":1'

# Generated at 2022-06-21 14:14:09.569610
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter_object = JSONFormatter()
    assert jsonFormatter_object is not None


# Generated at 2022-06-21 14:14:14.983718
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JsonFormatter = JSONFormatter(format_options = {
        'json': {
            'format': False,
            'indent': 2,
            'sort_keys': True,
        }
    }, explicit_json = False)
    assert JsonFormatter.enabled is False
    assert JsonFormatter.kwargs['explicit_json'] is False


# Generated at 2022-06-21 14:14:26.143228
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from pytest import ExitException

    json_input = u'{"name": "John Smith", "age": 31}'
    json_output = u"{'age': 31, 'name': 'John Smith'}"
    json_output2 = u"{'name': 'John Smith', 'age': 31}"
    json_output_indent = u'''\
{
    "age": 31,
    "name": "John Smith"
}'''

    # --json
    env = TestEnvironment(stdin_isatty=True, stdout_isatty=False)

# Generated at 2022-06-21 14:14:29.058474
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {'json': {'format': False, 'indent': 2, 'sort_keys': True}}
    assert JSONFormatter(format_options=format_options)



# Generated at 2022-06-21 14:14:32.676036
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a = FormatterPlugin()
    b = JSONFormatter(**a.kwargs)
    c = FormatterPlugin()
    assert a==b==c


# Generated at 2022-06-21 14:14:48.310709
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test no json, no format
    assert (JSONFormatter(
        format_options={'json': {'format': False}}
    ).format_body('content', 'text') == 'content')

    # Test no json, format
    assert (JSONFormatter(
        format_options={'json': {'format': True}}
    ).format_body('content', 'text') == 'content')

    # Test json, no format
    assert (JSONFormatter(
        format_options={'json': {'format': False}}
    ).format_body('{"content": "content"}', 'json') ==
            '{"content": "content"}')

    # Test json, format

# Generated at 2022-06-21 14:14:56.349579
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a = JSONFormatter(explicit_json=False,format_options={'json':{'format':True,'sort_keys':False,'indent':0}})
    assert a.enabled == True
    assert a.kwargs['explicit_json'] == False
    assert a.format_options['json']['format'] == True
    assert a.format_options['json']['sort_keys'] == False
    assert a.format_options['json']['indent'] == 0


# Generated at 2022-06-21 14:15:03.415407
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    }
    body = '{"hello": "world!"}'
    mime = 'application/json'

    formatter = JSONFormatter(output_options={'format': 'json'}, format_options=format_options)
    assert formatter.enabled
    assert formatter.format_body(body=body, mime=mime) == '{\n    "hello": "world!"\n}'

# Generated at 2022-06-21 14:15:07.980348
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(format_options={
        'json': {
            'sort_keys': False,
            'format': True,
            'indent': 1
        }
    })
    assert jf.format_options == {
        'json': {
            'sort_keys': False,
            'format': True,
            'indent': 1
        }
    }



# Generated at 2022-06-21 14:15:13.678625
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(**{
        'explicit_json': True,
        'format_options': {
            'json': {
                'format': True,
                'indent': None,
                'sort_keys': False
            },
            'colors': {
                'body': {},
                'headers': {},
                'status': {}
            }
        },
        'style': {}
    })
    assert formatter.enabled

# Generated at 2022-06-21 14:15:24.281694
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_str = '[{"a": 1, "b": 2}, {"a": 3, "b": 4}]'
    assert JSONFormatter({'json': {'indent': 4}}).format_body(json_str, 'json') == \
        '''[
    {
        "a": 1,
        "b": 2
    },
    {
        "a": 3,
        "b": 4
    }
]'''
    assert JSONFormatter({'json': {'indent': 4, 'sort_keys': False}}).format_body(json_str, 'json') == \
        '''[
    {
        "b": 2,
        "a": 1
    },
    {
        "b": 4,
        "a": 3
    }
]'''

# Generated at 2022-06-21 14:15:27.797309
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    tjson = {"a": "b"}
    json_string = json.dumps(tjson)
    formatter = JSONFormatter(explicit_json=True)
    assert formatter.format_body(json_string, 'json') == json_string


# Generated at 2022-06-21 14:15:29.572712
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = FormatterPlugin()
    assert f.format_options['json']['format'] is True

# Generated at 2022-06-21 14:15:33.054620
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }
    json_formatter = JSONFormatter(format_options=format_options)
    assert repr(json_formatter) == "<JSONFormatter('json')>"



# Generated at 2022-06-21 14:15:43.273898
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(kwargs=None)
    json_obj = '''
        {
          "array": [
            1,
            2,
            3
          ],
          "boolean": true,
          "null": null,
          "number": 123,
          "object": {
            "a": "b",
            "c": "d",
            "e": "f"
          },
          "string": "Hello World"
        }
        '''

# Generated at 2022-06-21 14:15:55.750946
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"name": "Joe", "age": 19, "city": "Duckburg"}'
    assert (JSONFormatter(explicit_json=False,
                          format_options={
                            'json': {
                                'indent': 2,
                                'sort_keys': True,
                                'format': True
                            }
                          }).format_body(body, 'application/json')
            == '{\n  "age": 19,\n  "city": "Duckburg",\n  "name": "Joe"\n}')

# Generated at 2022-06-21 14:16:03.381684
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{'explicit_json': False, 'format_options':{'json':{'format': True, 'indent': 4, 'sort_keys': True}}})
    body = '{"a":1, "b":2}'
    mime = 'application/json'
    expected = '{\n    "a": 1,\n    "b": 2\n}'
    actual = json_formatter.format_body(body=body, mime=mime)
    assert actual == expected

# Generated at 2022-06-21 14:16:12.639432
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_string = '{"id":418,"number":"4.18"}'
    formatter = JSONFormatter()
    # Test if formatter.format_body() returns the same string
    # when given a non-JSON body.
    assert formatter.format_body(json_string, '') == json_string
    # Test if formatter.format_body() returns a string that is
    # JSON-formatted and sorted when given a JSON body.
    assert json.loads(formatter.format_body(json_string, 'application/json')) == {
        'id': 418,
        'number': "4.18"
    }

# Generated at 2022-06-21 14:16:14.346647
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__doc__ != None
    assert JSONFormatter.format_body != None


# Generated at 2022-06-21 14:16:20.215946
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(format_options={"json":{"format":False}},
                    explicit_json = False,
                    sort_options = None,
                    colors = {"32":"green",
                              "33":"yellow",
                              "34":"blue",
                              "35":"magenta",
                              "36":"cyan",
                              "37":"white",
                              "31":"red"})
    assert (f.format_options == {"json":{"format":False}})
    assert (f.explicit_json == False)
    assert (f.sort_options == None)

# Generated at 2022-06-21 14:16:22.247743
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format':True}})
    assert formatter.enabled

# Generated at 2022-06-21 14:16:31.512785
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin = JSONFormatter(explicit_json=True)
    assert formatter_plugin.format_body('{"key": "value"}', '') == '{\n    "key": "value"\n}'
    assert formatter_plugin.format_body('{"key": "value"}', 'json') == '{\n    "key": "value"\n}'
    assert formatter_plugin.format_body('{"key": "value"}', 'javascript') == '{\n    "key": "value"\n}'
    assert formatter_plugin.format_body('{"key": "value"}', 'text') == '{\n    "key": "value"\n}'
    assert formatter_plugin.format_body('{"key": "value"}', 'xml') == '{"key": "value"}'
    assert form

# Generated at 2022-06-21 14:16:31.982189
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-21 14:16:34.234054
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.format_body('{"foo": "bar"}', 'application/json') == '{' + '\n' + '    "foo": "bar"' + '\n' + '}'

# Generated at 2022-06-21 14:16:44.425769
# Unit test for method format_body of class JSONFormatter