

# Generated at 2022-06-21 14:13:33.256007
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter()
    assert jf.format_body('{"name":"foo"}', 'application/json') == '{\n    "name": "foo"\n}'

# Generated at 2022-06-21 14:13:37.012009
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter_obj = JSONFormatter()
    assert json_formatter_obj.format_options['json']['format'] == False
    assert json_formatter_obj.kwargs == {}


# Generated at 2022-06-21 14:13:46.744160
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-21 14:13:58.169013
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # test 1: json
    mime = 'application/json'
    actual_json_body = '{"id": "1", "name":"peter"}'
    expected_json_body = '{\n "id": "1", \n "name": "peter"\n}'
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': False
            }
        },
        kwargs={
            'explicit_json': False
        }
    )

    assert json_formatter.format_body(actual_json_body, mime) == expected_json_body
    # test 2: explicit json
    mime = 'application/javascript'

# Generated at 2022-06-21 14:13:59.570803
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled

# Generated at 2022-06-21 14:14:06.653203
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.function_name == 'json'
    assert formatter.function_doc == 'JSON formatter.'
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['validate'] == True



# Generated at 2022-06-21 14:14:17.841006
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Test case 1
    json_str = """
{
    "json": "test",
    "integer": 5,
    "float": 3.3456,
    "arr": ["a", "b"],
    "obj": {"key1": "value1"}
}   
    """
    jsonObj = json.loads(json_str)
    sorted_json_str = json.dumps(jsonObj, sort_keys=True, ensure_ascii=False)
    formatter = JSONFormatter(format_options={'json':{'format': True, 'indent': 4, 'sort_keys': True}},
                              explicit_json=False,
                              output_options={'output_stream': None})
    # Note that the JSON string is not valid JSON since the indentation is not correct.
    # This is on purpose to

# Generated at 2022-06-21 14:14:23.480277
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a":{"b":"c","d":"e"}}'
    mime = 'json'
    formatter = JSONFormatter()
    assert formatter.format_body(body, mime) == '{\n    "a": {\n        "b": "c",\n        "d": "e"\n    }\n}'

# Generated at 2022-06-21 14:14:25.461614
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    ret = json_formatter.format_body("{'k': 'v'}", "application/json;")
    assert ret == '{\n    "k": "v"\n}'



# Generated at 2022-06-21 14:14:36.965887
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.formatters import JSONFormatter
    from httpie.compat import is_windows

    if is_windows:
        json_indent = 4
    else:
        json_indent = 2
    formatter = JSONFormatter({
        'json': {
                'format': True,
                'indent': json_indent,
                'sort_keys': True,
            }
    })

    body = '{"a": "b"}'
    assert formatter.format_body(body, 'application/json') == body

    body = '{"a": "b", "c": "d"}'
    result_body = '{\n  "a": "b",\n  "c": "d"\n}'
    assert formatter.format_body(body, 'application/json') == result_body

   

# Generated at 2022-06-21 14:14:47.860810
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # This unit test is only to achieve test coverage
    jf = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    if jf.enabled:
        assert jf.format_options['json']['sort_keys'] == True
    else:
        assert jf.enabled == False

# Generated at 2022-06-21 14:14:52.990970
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {"json": {"format": False, "sort_keys": True, "indent": 4}}
    jf = JSONFormatter(format_options=format_options)
    assert jf.enabled == False
    assert jf.kwargs == {}


# Generated at 2022-06-21 14:14:57.223967
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert issubclass(JSONFormatter, FormatterPlugin)
    assert formatter.enabled == True



# Generated at 2022-06-21 14:15:02.192870
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fo = {'json': {'format': True, 'sort_keys': False, 'indent': 2}}
    kwargs = {'format_options': fo, 'explicit_json': False}
    jf = JSONFormatter(**kwargs)
    assert jf.enabled == True
    assert jf.kwargs['explicit_json'] == False


# Generated at 2022-06-21 14:15:06.942647
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_options['json']['format'] is True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] is True

# Generated at 2022-06-21 14:15:11.016708
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.enabled is False
    assert jf.kwargs == {}
    assert jf.format_options == {}
    jf = JSONFormatter(format_options={'json': {'format': True}}, kwargs={})
    assert jf.kwargs == {}
    assert jf.format_options == {'json': {'format': True}}
    assert jf.enabled is True


# Generated at 2022-06-21 14:15:15.217835
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # Unit test for case: has json body
    assert formatter.format_body(body='{"test":"test"}',
                                 mime='json') == '{\n    "test": "test"\n}'
    # Unit test for case: has json body
    assert formatter.format_body(body='{"test":"test"}',
                                 mime='javascript') == '{\n    "test": "test"\n}'
    # Unit test for case: invalid body
    assert formatter.format_body(body='{"test":"test",}',
                                 mime='javascript') == '{"test":"test",}'

# Generated at 2022-06-21 14:15:25.232751
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        explicit_json=False,
        format_options={
            'json': {
                'format':True,
                'sort_keys':False,
                'indent':2
            }
        }
    )
    body = '{"a":"b"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": "b"\n}'
    #
    formatter = JSONFormatter(
        explicit_json=True,
        format_options={
            'json': {
                'format':True,
                'sort_keys':False,
                'indent':2
            }
        }
    )
    body = '{"a":"b"}'
    mime = 'javascript'
    assert formatter.format

# Generated at 2022-06-21 14:15:30.252602
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    res = JSONFormatter(format_options={'json': {'indent': 2, 'sort_keys': True, 'format': True}})
    assert res.__dict__ == {'kwargs': {}, 
                       'format_options': {'json': {'indent': 2, 'sort_keys': True, 'format': True}}, 
                       'enabled': True}


# Generated at 2022-06-21 14:15:32.546660
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True



# Generated at 2022-06-21 14:15:54.367469
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    kwargs = {
        'explicit_json':False,
        'format_options': {
            'json': {
                'format':True,
                'indent':4,
                'sort_keys':True,
            },
        },
    }
    json_formatter = JSONFormatter(**kwargs)
    assert json_formatter.format_body('{"b":2,"a":1}','') == \
            '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"b":2,"a":1}','json') == \
            '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-21 14:16:00.460886
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_cases = {
        "{'a': 1}": "{'a': 1}",
        '{"a": 1}': '{\n    "a": 1\n}',
    }
    for raw, formatted in test_cases.items():
        formatter = JSONFormatter('json', {
            'sort_keys': True,
            'indent': 4,
            'format': True,
        })
        assert formatter.format_body(raw, 'application/json') == formatted

# Generated at 2022-06-21 14:16:08.167564
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Given a json-formatted string
    str_json = '{"name":"John","age":31,"city":"New York"}'
    # When a request is made with a json body
    formatted_body = JSONFormatter().format_body(str_json, 'json')
    # Then the json should be formatted
    assert formatted_body == '{\n    "age": 31,\n    "city": "New York",\n    "name": "John"\n}'


# Generated at 2022-06-21 14:16:10.944420
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    plugin = JSONFormatter(**{'json': {'format': True}, 'explicit_json': True})
    assert plugin.format_options['json']['format'] == True

# Generated at 2022-06-21 14:16:18.551555
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

	format_options = {
		'json':{
			'JsonFormat':True,
			'indent':1,
			'sort_keys':False,
		}
	}

	class MockArgs:
		explicit_json = False

	# python -m pytest test_JSONFormatter.py
	try:
		jf = JSONFormatter(format_options=format_options, kwargs=MockArgs())
		assert jf.enabled == True
	except Exception as e:
		assert False

	# python -m pytest test_JSONFormatter.py

# Generated at 2022-06-21 14:16:19.649848
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.__init__

# Generated at 2022-06-21 14:16:28.236360
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{'explicit_json': False})
    assert json_formatter.format_body("Not a valid JSON", "") == "Not a valid JSON"
    assert json_formatter.format_body('{"a": "b"}', "json") == '{"a": "b"}'

    explicit_formatter = JSONFormatter(**{'explicit_json': True})
    assert explicit_formatter.format_body("Not a valid JSON", "") == "Not a valid JSON"
    assert explicit_formatter.format_body('{"a": "b"}', "text") == '{\n    "a": "b"\n}'

# Generated at 2022-06-21 14:16:29.450427
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True

# Generated at 2022-06-21 14:16:34.291965
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Initialize a JSONFormatter object
    test_JSONFormatter = JSONFormatter()

    # Check attributes of initialized object
    assert test_JSONFormatter.__class__.__name__ == "JSONFormatter"
    assert vars(test_JSONFormatter) == {
            'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': False}},
            'kwargs': {'explicit_json': False},
            'enabled': True
        }



# Generated at 2022-06-21 14:16:39.586755
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = {"json": {"format": True, "indent": 4, "sort_keys": True}}
    kwargs = {"json": True, "explicit_json": True}
    json_formatter = JSONFormatter(format_options=options, **kwargs)
    assert(json_formatter.enabled)
