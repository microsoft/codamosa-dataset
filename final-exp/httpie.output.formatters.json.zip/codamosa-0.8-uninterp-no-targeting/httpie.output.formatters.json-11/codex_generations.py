

# Generated at 2022-06-21 14:13:32.510886
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    args = ['--json={0}'.format(json.dumps({
        'format': True,
        'sort_keys': True,
        'indent': 2,
    }))]
    # Create JSONFormatter with argument '--json'
    formatter = JSONFormatter(args)
    # Check if JSONFormatter is enabled and if format_options contains the
    # expected values
    assert formatter.enabled and (
        formatter.format_options['json'] == {
            'format': True,
            'sort_keys': True,
            'indent': 2,
        }
    )

# Generated at 2022-06-21 14:13:39.940923
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    }
    kwargs = {
        'explicit_json': True
    }
    assert JSONFormatter(format_options=format_options, **kwargs).enabled == True
    assert JSONFormatter(format_options=format_options, **kwargs).kwargs['explicit_json'] == True


# Generated at 2022-06-21 14:13:42.083412
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_obj = JSONFormatter()
    assert test_obj.format_options['json']['format'] == True



# Generated at 2022-06-21 14:13:45.122415
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    x = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': False, 'indent': 3}})
    assert x.enabled == True

# Generated at 2022-06-21 14:13:56.394149
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class TEST_JSONFormatter(JSONFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.format_options = {
                'json': {
                    'format': True,
                    'indent': 4,
                    'sort_keys': False
                }
            }

    tested_class = TEST_JSONFormatter()

    # Test 1
    # Input:
    # - body: '{"a": "b"}'
    # - mime: 'json'
    # Expected result:
    # - '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'json'

# Generated at 2022-06-21 14:14:07.385212
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with JSON
    body = "{\n  \"body\": \"json\"\n}"
    body_formatted = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            }
        }
    ).format_body(
        body=body,
        mime="application/json"
    )
    assert body_formatted == "{\n  \"body\": \"json\"\n}"

    # Test without JSON
    body = "not json"

# Generated at 2022-06-21 14:14:15.544412
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case:
    #   forbidden values
    # Message of exception raised:
    #   "No JSON object could be decoded"
    #
    # expected_obj is the JSON object expected to be returned.

    # create a JSON body and try to load it as a JSON object
    # but with forbidden values
    body = '"test"'
    formatter = JSONFormatter()
    try:
        obj = json.loads(body)
    except ValueError:
        assert formatter.format_body(body, 'json') == ''
    else:
        assert obj == 'test'

# Generated at 2022-06-21 14:14:16.262344
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-21 14:14:26.830313
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_kwargs = {
        'format_options': {
            'json': {
                'sort_keys': False,
                'indent': 2,
                'format': True
            }
        },
        'explicit_json': False
    }
    formatter = JSONFormatter(**test_kwargs)
    json_body = '''{
        "id": "1",
        "name": "A green door",
        "price": 12.50,
        "tags": ["home", "green"]
    }'''

# Generated at 2022-06-21 14:14:37.913912
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from requests.structures import CaseInsensitiveDict
    from httpie.core import main
    from httpie.context import Environment
    from httpie.core import main
    from httpie.plugins import FormatterPluginManager

    with main.App(
            env=Environment(),
            formats=FormatterPluginManager()
    ) as app:
        formatter = JSONFormatter(format_options={
            'json': {
                'indent': None,
                'sort_keys': False,
                'format': True,
            }
        })
        assert formatter.format_body('{"a": 1}', 'json') == '{"a": 1}'
        assert formatter.format_body('{"a": 1}', 'text/json') == \
            '{\n    "a": 1\n}'
        assert formatter.format

# Generated at 2022-06-21 14:14:50.746471
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    from httpie.compat import is_py26
    from httpie.plugins import FormatterPlugin
    from json import sort_keys

    class JSONFormatter(FormatterPlugin):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['json']['format']

        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                    or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass  # Invalid JSON, ignore.

# Generated at 2022-06-21 14:15:01.140886
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    class kwargs:
        def __init__(self):
            self.explicit_json = False
    class format_options:
        def __init__(self):
            self.json = {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
    
    json_formatter = JSONFormatter(
        kwargs = kwargs(),
        format_options = format_options()
    )
    
    assert json_formatter.enabled == True
    assert json_formatter.kwargs.explicit_json == False
    assert json_formatter.format_options.json['format'] == True
    assert json_formatter.format_options.json['indent'] == 4
    assert json_formatter.format_options.json['sort_keys'] == True


# Generated at 2022-06-21 14:15:09.412629
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Test  the format_body method of class JSONFormatter"""
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    json1 = json_formatter.format_body('{"a": 2, "b": 10}', 'application/json')
    json2 = json_formatter.format_body('{"a": 2, "b": 10}', 'application/javascript')
    json3 = json_formatter.format_body('{"a": 2, "b": 10}', 'text/plain')

# Generated at 2022-06-21 14:15:10.718020
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()


# Generated at 2022-06-21 14:15:21.321293
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    import random
    data = {}
    data['key1'] = "value1"
    data['key2'] = "value2"
    data['key3'] = {}
    data['key3']['key4'] = "value4"
    data['key3']['key5'] = "value5"
    json_data = json.dumps(data, sort_keys = True, indent = 4)

    f = JSONFormatter()
    assert f.format_body(json_data, 'application/json') == json_data

    data = {}
    data['key1'] = "value1"
    data['key2'] = "value2"
    data['key3'] = {}
    data['key3']['key4'] = "value4"
    data['key3']['key5']

# Generated at 2022-06-21 14:15:24.365339
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import JSONPlugin
    json_plugin = JSONPlugin()
    formatter = json_plugin.get_formatter()
    assert formatter.format_options['json']['format'] == True


# Generated at 2022-06-21 14:15:26.037615
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    instance = JSONFormatter(kwargs=None, format_options=None)
    assert isinstance(instance, JSONFormatter)

# Generated at 2022-06-21 14:15:31.200512
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {'json': {'format': False, 'indent': 4, 'sort_keys': False}}
    kwargs = {'explicit_json': False}
    formatter = JSONFormatter(format_options=format_options, **kwargs)

    assert formatter.enabled == False
    assert formatter.format_options == format_options
    assert formatter.kwargs == kwargs


# Generated at 2022-06-21 14:15:40.510177
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': None,
            'json_lines': False,
            'sort_keys': False,
            'pretty': False
        }
    })
    formatter.format_body('{"a": "b"}', 'json') == '{"a": "b"}'
    formatter.format_body('{"a": "b"}', 'javascript') == '{"a": "b"}'
    formatter.format_body('{"a": "b"}', 'text') == '{"a": "b"}'
    formatter.format_body('{"a": "b"}', 'other') == '{"a": "b"}'


# Generated at 2022-06-21 14:15:42.250021
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True
    assert formatter.kwargs == {}

# Generated at 2022-06-21 14:15:45.756492
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    maybe_json=['json', 'javascript', 'text']
    assert JSONFormatter().kwargs['explicit_json']

# Generated at 2022-06-21 14:15:48.037162
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test1 = JSONFormatter()
    assert test1.format_body('{"test": "jkl"}', 'application/json') == '{\n    "test": "jkl"\n}'
    assert test1.format_body('{ "test": "jkl" }', 'application/javascript') == '{\n    "test": "jkl"\n}'
    assert test1.format_body('{ "test": "jkl" }', 'text/javascript') == '{\n    "test": "jkl"\n}'

# Generated at 2022-06-21 14:15:51.952840
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    """
    test_JSONFormatter tests the __init__ method of class JSONFormatter
    """
    mock_kwargs = {'format_options': {'json': {'format': True}}}
    formatter = JSONFormatter(**mock_kwargs)
    assert formatter.enabled == True


# Generated at 2022-06-21 14:15:54.844268
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-21 14:16:01.046360
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Case: Constructor is not ok
    try:
        formatter = JSONFormatter(format_options='', kwargs='')
    except:
        pass
    # Case: Constructor is ok
    formatter = JSONFormatter(format_options={'json': {"format": True, "indent": 4, "sort_keys": False}},
                              kwargs={'explicit_json': True})
    assert formatter is not None


# Generated at 2022-06-21 14:16:06.513393
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.format_options == {'json': {'format': True, 'indent': 4, 'sort_keys': False}}
    jf.format_options['json']['format'] = False
    assert jf.enabled == False


# Generated at 2022-06-21 14:16:14.179612
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    J = JSONFormatter()

    assert J.format_body('{"json": "body"}', 'json') == '{\n    "json": "body"\n}'
    assert J.format_body('{"json": "body"}', 'javascript') == '{\n    "json": "body"\n}'
    assert J.format_body('{"json": "body"}', 'text') == '{\n    "json": "body"\n}'

    assert J.format_body('{"json": "body"}', 'text/html') == '{"json": "body"}'

# Generated at 2022-06-21 14:16:24.558284
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    f = JSONFormatter()
    assert f.format_body('{"foo": "bar"}', 'json') == '{\n  "foo": "bar"\n}'
    assert (f.format_body('{"foo": "bar"}', 'javascript') ==
            '{\n  "foo": "bar"\n}')
    assert (f.format_body('{"foo": "bar"}', 'text') == '{\n  "foo": "bar"\n}')
    assert (f.format_body('{"foo": "bar"}', 'text/html') ==
            '{"foo": "bar"}')
    assert (f.format_body('{"foo": "bar"}', 'text/html; charset=utf-8') ==
            '{"foo": "bar"}')

# Generated at 2022-06-21 14:16:33.190350
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest
    from httpie.formatter import JSONFormatter
    from httpie.output.streams import OUTPUT_STREAM_NAME_BYTES
    kw = {'stdout_isatty': False, 'explicit_json': False}
    fm = JSONFormatter(format_options={'json': {'format': True,
                                                'indent': 4,
                                                'sort_keys': True}}, **kw)
    fm.stream_name = OUTPUT_STREAM_NAME_BYTES
    body = '{"a": ["b", 42]}'
    assert fm.format_body(body=body, mime='application/json') == '{\n    "a": [\n        "b",\n        42\n    ]\n}'
    # Test with explicit_json

# Generated at 2022-06-21 14:16:35.846627
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(format_options={'json' : {'indent' : 2, 'sort_keys' : False, 'format' : True}})
    assert jf.enabled

# Generated at 2022-06-21 14:16:47.041456
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Tests for json body with format option
    # Sample json data
    body = '{"abc": "xyz"}'
    formatter = JSONFormatter(format_options={'json': {'format': True,
        'indent': 4, 'sort_keys': True}})
    assert formatter.format_body(body, 'json') == '{\n    "abc": "xyz"\n}'
    assert formatter.format_body(body, 'text') == body
    assert formatter.format_body(body, 'javascript') == '{\n    "abc": "xyz"\n}'
    assert formatter.format_body(body, 'html') == body

    # Tests for json body without format option
    # Sample json data
    body = '{"abc": "xyz"}'
    formatter = JSONFormatter

# Generated at 2022-06-21 14:16:49.489553
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    if format_options['json']['format']:
        assert json_formatter.enabled == True
    else:
        assert json_formatter.enabled == False


# Generated at 2022-06-21 14:16:53.371335
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    json_data = '{"key":"value"}'
    assert formatter.format_body(json_data, 'application/json') == json_data
    assert 'key' in formatter.format_body(json_data, 'text/html')

# Generated at 2022-06-21 14:17:01.151865
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    print("JSON Formatter - format_body")

    test_strings = {
        '{"foo": "bar", "abc": "def"}':
            '{\n'
            '    "abc": "def",\n'
            '    "foo": "bar"\n'
            '}',

        '[1, 2, 0, {"a": "b"}]':
            '[\n'
            '    1,\n'
            '    2,\n'
            '    0,\n'
            '    {\n'
            '        "a": "b"\n'
            '    }\n'
            ']',

        'true': 'true',

        'false': 'false',

        'null': 'null',
    }

    formatter = JSONFormatter()

    # Act

# Generated at 2022-06-21 14:17:03.474714
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == False


# Generated at 2022-06-21 14:17:04.714081
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert isinstance(JSONFormatter(), JSONFormatter)

# Generated at 2022-06-21 14:17:08.227767
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {'indent': 4, 'sort_keys': False, 'format': True}
    formatter = JSONFormatter(format_options = format_options, args = None)
    assert(formatter.enabled == True)


# Generated at 2022-06-21 14:17:14.678533
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    import httpie.plugins
    # httpie.plugins.__file__ is read-only so need to copy to a mutable variable for testing
    import_JSONFormatter = httpie.plugins.__file__.replace('pyc', 'py').replace('pyo', 'py')
    import_JSONFormatter = import_JSONFormatter[:import_JSONFormatter.rfind('/')] + '/formatter/json.py'
    exec(open(import_JSONFormatter).read())  # load the module json.py

    # Test 1
    json_object_to_test = {'name':'John', 'age':30, 'city':'New York'}
    body = json.dumps(json_object_to_test)
    # Expected body == body in JSON format without any change.
    # In other

# Generated at 2022-06-21 14:17:18.685317
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {'json': {'format': True, 'indent': 1, 'sort_keys': True}}
    f = JSONFormatter(format_options=format_options)
    assert f.enabled == True
    assert f.kwargs['explicit_json'] == False
    assert f.format_options['json']['sort_keys'] == True


# Generated at 2022-06-21 14:17:29.582925
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{'explicit_json':True,
        'format_options':{'json':{'indent':2,'sort_keys':True,
        'format':True}}})

    test_body = '{"org": "Atlassian","repository": "stash",\
        "time": {"$date": 1338430039047}}'
    test_mime = "application/json"

    assert json_formatter.format_body(test_body, test_mime) == \
        '{\n  "org": "Atlassian",\n  "repository": "stash",\n  "time": {\n    "$date": 1338430039047\n  }\n}'