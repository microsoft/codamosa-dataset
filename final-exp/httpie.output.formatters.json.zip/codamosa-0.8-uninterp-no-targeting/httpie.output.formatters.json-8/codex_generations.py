

# Generated at 2022-06-21 14:13:37.737829
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print("\nTesting JSONFormatter.format_body()")
    json_formatter = JSONFormatter()

    # For valid JSON body
    print("1) Test for valid JSON body")
    body = '{"name":"John", "age":30, "city":"New York"}'
    expected_body = '{\n  "age": 30, \n  "city": "New York", \n  "name": "John"\n}'
    actual_body = json_formatter.format_body(body, "json")
    assert expected_body == actual_body
    print("SUCCESS: Valid JSON body formatted successfully")

    # For invalid JSON body
    print("2) Test for invalid JSON body")
    body = '{"name":"John", "age":30, "city":"New York"'
    expected_body = body
    actual

# Generated at 2022-06-21 14:13:48.173206
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    json_mime_types = [
        'json',
        'javascript',
        'text',
    ]
    expected_result = json.dumps(
        obj={
            'key_1': 'value 1',
            'key_2': 'value 2',
            'key_3': 'value 3',
            'key_4': 'value 4',
            'key_5': 'value 5'
        },
        sort_keys=True,
        ensure_ascii=False,
        indent=2
    )

# Generated at 2022-06-21 14:13:54.057609
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test valid JSON string
    body = '{"first": "John", "last": "Smith"}'
    mime = 'application/json'
    json_formatter = JSONFormatter()
    assert json_formatter.format_body(body, mime) == '{\n    "first": ' \
            '"John", \n    "last": "Smith"\n}'


# Generated at 2022-06-21 14:14:05.207668
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test that json formatter format body
    body = '{"name":"httpie","age":5}'
    mime = 'application/json'
    json_formatter = JSONFormatter(**{'explicit_json': False,
                                      'format_options': {'json': {
                                          'format': True,
                                          'indent': 2,
                                          'sort_keys': True
                                      }}})
    assert json_formatter.format_body(body, mime) == '{\n  "age": 5, \n  "name": "httpie"\n}'
    # Test that json formatter don't format body
    body = '{"name":"httpie","age":5}'
    mime = 'application/json'

# Generated at 2022-06-21 14:14:12.863918
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f_json = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    }, explicit_json=False)
    body = '{"key": ["value1", "value2"]}'
    expected_body = '{\n  "key": [\n    "value1",\n    "value2"\n  ]\n}'
    assert f_json.format_body(body, 'application/json') == expected_body

# Generated at 2022-06-21 14:14:14.168396
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    stream = JSONFormatter()
    assert stream.format_options['json']['format']

# Generated at 2022-06-21 14:14:25.466003
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    text = '{"hello": 1}'
    mime = 'json'
    # Test 1
    # Test condition: the input text conform to json grammer and the mime is json
    # Expect result: the output json text should be formatted and indented
    assert '{\n    "hello": 1\n}' == formatter.format_body(text, mime)

    # Test 2
    # Test condition: the input text conform to json grammer and the mime is not json
    # Expect result: the output json text should not be formatted and indented
    mime = 'text'
    assert '{"hello": 1}' == formatter.format_body(text, mime)

    # Test 3
    # Test condition: the input text does not conform to json grammer and the mime is json
   

# Generated at 2022-06-21 14:14:30.466800
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
                'explicit_json': False
            }
        }
    )

    assert jf.enabled == True
    assert jf.kwargs['explicit_json'] == False


# Generated at 2022-06-21 14:14:41.142500
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    formatter = JSONFormatter(kwargs={'explicit_json':True}, format_options={'json': {
                            'format': True, 'ensure_ascii': False, 'sort_keys': True, 'indent': 0}})
    assert formatter.format_body("{\"key\": \"value\"}", "json") == '{"key": "value"}'
    assert formatter.format_body("{\"key\": \"value\"}", "illegal") == '{\"key\": \"value\"}'
    assert formatter.format_body("{key: value}", "json") == '{key: value}'
    assert formatter.format_body("{key: value}", "illegal") == '{key: value}'

# Generated at 2022-06-21 14:14:47.942487
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}}, kwargs={'explicit_json': True})
    assert formatter.enabled == True
    assert formatter.kwargs['explicit_json'] == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 2
