

# Generated at 2022-06-21 14:13:39.217203
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class DummyFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = True
    dummy_plugin = DummyFormatterPlugin()
    formatter = JSONFormatter(formatter_manager=dummy_plugin)
    body = '{"foo": true, "bar": false}'
    assert formatter.format_body(body, 'json') == body
    body = '{"foo": true, "bar": false}'
    assert formatter.format_body(body, 'javascript') == body
    assert formatter.format_body(body, 'text') == body
    body = '{"foo": true, "bar": false}'
    assert formatter.format_body(body, 'application/json') == body

# Generated at 2022-06-21 14:13:47.691774
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('false', 'text/html') == 'false'
    assert json_formatter.format_body('false', 'application/json') == 'false'
    assert json_formatter.format_body('false', 'text/javascript') == 'false'
    assert json_formatter.format_body('{"test":true}', 'text/html') == '{"test":true}'
    assert json_formatter.format_body('{"test":true}', 'application/json') == '{\n    "test": true\n}'
    assert json_formatter.format_body('{"test":true}', 'text/javascript') == '{\n    "test": true\n}'

# Generated at 2022-06-21 14:13:49.472630
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    content = JSONFormatter()
    assert content.format_options == {'json': {'format': True, 'indent': 2, 'sort_keys': True}}



# Generated at 2022-06-21 14:13:50.994089
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    plugin = JSONFormatter()
    assert plugin.name == 'JSON'


# Generated at 2022-06-21 14:14:02.447943
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins.builtin import BuiltinPluginManager
    from httpie.plugins import plugin_manager
    from httpie.output.streams import ResponseWriter

    config = {
               "json": {
                   "format": True,
                   "indent": 4,
                   "sort_keys": True
               }
            }

    p = JSONFormatter(
        config=config,
        formatter=None,
        explicit_json=False,
        stdin=None,
        stdout=ResponseWriter(None, None),
        stderr=ResponseWriter(None, None),
        debug=False,
        output_options=None,
        format_options=config,
        colors=None,
        traceback=False,
        unicode_error_handler=None
    )
    return p




# Generated at 2022-06-21 14:14:07.965085
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter({'json': {'format': True, 'indent': 0, 'sort_keys': False}, 'explicit_json': False})
    json_str = '{"a":2,"b":1}'
    mime_str = 'json'
    assert formatter.format_body(json_str, mime_str) == '{"a":2,"b":1}'


# Generated at 2022-06-21 14:14:12.766875
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import httpie.plugins
    from dicts import headers
    from dicts import request
    from dicts import request
    from dicts import response
    from dicts import version
    from httpie.plugins import FormatterPlugin

    formatter = JSONFormatter(**{
        'headers': headers
    })

# Generated at 2022-06-21 14:14:23.834222
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body(
        JSONFormatter(),
        body = '{"key":"value"}',
        mime = 'javascript'
    ) == '{\n    "key": "value"\n}'
    assert JSONFormatter.format_body(
        JSONFormatter(explicit_json = True),
        body = '{"key":"value"}',
        mime = 'vnd.github.mercy-preview+json'
    ) == '{\n    "key": "value"\n}'
    assert JSONFormatter.format_body(
        JSONFormatter(),
        body = '{"key":"value"}',
        mime = 'vnd.github.mercy-preview+json'
    ) == '{\n    "key": "value"\n}'

# Generated at 2022-06-21 14:14:27.909325
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False

    formatter = JSONFormatter(explicit_json=True, format_options={'json': {'format': True}})
    assert formatter.enabled == True

    formatter = JSONFormatter(explicit_json=True, format_options={'json': {'format': False}})
    assert formatter.enabled == False


# Generated at 2022-06-21 14:14:39.257362
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    plugin = JSONFormatter(
        out_file = None,
        format_options = {u'json': {
            u'format': True, 
            u'indent': 4, 
            u'sort_keys': False}
        },
        colors = None,
        stdout_isatty = True,
        explicit_json = False,
    )
    body = '[{"key1": "val1"}, {"key2": "val2"}, {"key3": "val3"}]'
    mime = 'json'
    res = plugin.format_body(body, mime)

# Generated at 2022-06-21 14:14:51.037983
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    cases = [
        {"input": {"body": '{}', "mime": 'json'},
        "output": '{}'},
        {"input": {"body": '[1,2,3]', "mime": 'json'},
        "output": '[1,2,3]'},
        {"input": {"body": '[1,2,3]', "mime": 'plain/text'},
        "output": '[1,2,3]'},
    ]
    for case in cases:
        f = JSONFormatter(format_options={'json':{'format': True, 'sort_keys': False, 'indent': None}})
        assert f.format_body(case['input']['body'], case['input']['mime']) == case['output']

# Generated at 2022-06-21 14:15:01.409384
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    args = dict(
        json=dict(
            format=False,
            sort_keys=False,
            indent=0,
        ),
        pretty=dict(
            format=False,
            colors=False,
            style=dict()
        ),
    )
    json_formatter = JSONFormatter(**args)
    body = '{"foo": "bar"}'
    result = json_formatter.format_body(body, 'json')
    assert result == '{"foo": "bar"}'
    result = json_formatter.format_body(body, 'text')
    assert result == '{"foo": "bar"}'
    result = json_formatter.format_body(body, 'nonsense')
    assert result == '{"foo": "bar"}'


# Generated at 2022-06-21 14:15:02.742380
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = {'json': {'format': True}})
    assert formatter.enabled

# Generated at 2022-06-21 14:15:04.761457
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(**kwargs)
    assert formatter.kwargs == kwargs
    assert not formatter.enabled


# Generated at 2022-06-21 14:15:08.749277
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_options = {'json': {
        'format': True,
        'indent': 4,
        'sort_keys': True
    }}

    test_kwargs = {'explicit_json': False}

    d = JSONFormatter(format_options=test_options, **test_kwargs)

    assert d.enabled is True


# Generated at 2022-06-21 14:15:12.920364
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {}
    format_options['json'] = {}
    format_options['json']['format'] = True
    format_options['json']['indent'] = 4
    format_options['json']['sort_keys'] = True
    kwargs = {}
    kwargs['explicit_json'] = True
    json_formatter = JSONFormatter(
        format_options = format_options,
        **kwargs
    )
    assert json_formatter.enabled == True


# Generated at 2022-06-21 14:15:18.879359
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    text_json = JSONFormatter(
        format_options={
            'json': {'format': True, 'indent': 4, 'sort_keys': True}
        },
        explicit_json=False
    )
    text_json.format_body(json.dumps([1, 2, 3]), 'json') == '''[
    1,
    2,
    3
]'''

# Generated at 2022-06-21 14:15:20.618565
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True

# Generated at 2022-06-21 14:15:22.406918
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
        jsonFormatter = JSONFormatter()
        assert jsonFormatter is not None


# Generated at 2022-06-21 14:15:28.443308
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    valid_json = {"hello": "world"}
    invalid_json = '{this is not a json'
    valid_json_as_string = json.dumps(valid_json)
    formatter = JSONFormatter()
    assert formatter.format_body(body=valid_json_as_string,
        mime='application/json') == valid_json_as_string
    assert formatter.format_body(body=invalid_json,
        mime='application/json') == invalid_json

# Generated at 2022-06-21 14:15:41.932054
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        from httpie.context import Environment
    except ImportError:
        pass
    else:
        env = Environment()
        env.config.__dict__.update(
            sort_keys=True,
            json__indent=2
        )
        kwargs = dict(
            sort_keys=True,
            json__indent=2,
            explicit_json=False,
            format_options=env.config.format_options
        )
        jf = JSONFormatter(**kwargs)
        assert jf.enabled == True
        assert jf.kwargs == kwargs


# Generated at 2022-06-21 14:15:51.118608
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httptools import HttpRequestParser

    formatter = JSONFormatter()
    # Verify that the default values are set for the class
    assert formatter.kwargs == {}
    assert formatter.format_options == {
        'json': {'format': False, 'indent': 4, 'sort_keys': True}
    }
    assert formatter.enabled is False
    assert formatter.output_file is None
    assert formatter.parser is HttpRequestParser
    assert formatter.body is ''
    assert formatter.headers is ''
    assert formatter.components is []
    assert formatter.body_formatted is ''
    assert formatter.headers_formatted is ''



# Generated at 2022-06-21 14:15:52.039686
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert isinstance(JSONFormatter(), JSONFormatter)

# Generated at 2022-06-21 14:15:54.916361
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Create a formatter
    json_formatter = JSONFormatter(format_options = {'json': {'format': False}})

    # Check if formatter is disabled
    assert json_formatter.enabled == False


# Generated at 2022-06-21 14:16:06.419572
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test for constructor of class JSONFormatter with two arguments
    def test_JSONFormatter_with_2_arg():
        f = JSONFormatter(kwargs={'explicit_json': False},
            format_options={'json':{'format': True, 'indent': 4, 'sort_keys': True}})
        assert f.kwargs['explicit_json'] == False
        assert f.format_options['json'] == {'format': True, 'indent': 4, 'sort_keys': True}

    # Test for constructor of class JSONFormatter with three arguments

# Generated at 2022-06-21 14:16:13.430398
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Unit test for the constructor of the class JSONFormatter
    format_options = {
        "json": {
            "format": True,
            "indent": True,
            "sort_keys": True
        }
    }
    kwargs = {
        'explicit_json': False
    }
    jf = JSONFormatter(format_options=format_options, **kwargs)

    assert jf.enabled == True
    assert jf.kwargs['explicit_json'] == False


# Generated at 2022-06-21 14:16:15.367187
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import JSONFormatter
    formatter = JSONFormatter()
    expected = False
    assert formatter.enabled == expected


# Generated at 2022-06-21 14:16:26.163904
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test normal case
    formatter = JSONFormatter(
        format_options = {
            'colors': {
                'color': True,
                'styles': {
                    'status': {'fg': 'green'},
                    'header': {'fg': 'cyan'},
                    'body': {'fg': 'yellow'},
                    'error': {'fg': 'red'}
                }
            },
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 2
            }
        },
        kwargs = {
            'explicit_json': False
        }
    )

# Generated at 2022-06-21 14:16:34.233774
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins import FormatterPluginManager
    from httpie.plugins.builtin import JSONFormatter

# Generated at 2022-06-21 14:16:37.610051
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = JSONFormatter(format_options=dict(json=dict(format=True, indent=4, sort_keys=False)), kwargs=dict(explicit_json=False))
    assert fp.enabled == True


# Generated at 2022-06-21 14:16:43.929659
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-21 14:16:51.358992
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # JSON formatter is able to indent and sort keys by name.
    formatter = JSONFormatter()
    json_str = '''{"projectlist": ["my-project", "your-project"], "name": "John Doe"}'''
    json_obj = json.loads(json_str)
    # Test for default.
    formatted_str = formatter.format_body(json_str, 'application/json')
    assert json.loads(formatted_str) == json_obj, 'Default json formatter error.'
    # Test for indent.
    formatter.format_options['json']['indent'] = 2
    formatted_str = formatter.format_body(json_str, 'application/json')
    assert json.loads(formatted_str) == json_obj, 'Indent error.'
    # Test for sort keys.

# Generated at 2022-06-21 14:16:56.371476
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format': False,
            'indent': 3,
            'sort_keys': True
        }
    }
    formatter = JSONFormatter(format_options=format_options)
    assert formatter is not None
    assert formatter.format_options == format_options
    assert formatter.enabled == format_options['json']['format']


# Generated at 2022-06-21 14:16:59.104873
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.json import JSONPlugin
    from httpie.context import Environment

    options = JSONPlugin.parse_options(env=Environment())
    formatter = JSONFormatter(**options)
    print(formatter)


# Generated at 2022-06-21 14:17:00.419408
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	data = JSONFormatter()
	data.__init__()

# Generated at 2022-06-21 14:17:01.523850
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.enabled == False

# Generated at 2022-06-21 14:17:07.132374
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins.core import json_format_options
    formatter_plugin = JSONFormatter(
        format_options=json_format_options,
        explicit_json=False
    )
    assert formatter_plugin.format_options
    assert not formatter_plugin.kwargs['explicit_json']
    assert formatter_plugin.format_options['json']['format']

# Generated at 2022-06-21 14:17:14.066450
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_method = JSONFormatter(format_options={'json':{'format': True, 'indent': 4, 'sort_keys': True}}).format_body
    assert test_method('f', 'html') == 'f'

    json_input = '{"key": "value"}'
    assert test_method(json_input, 'html') == '''{
    "key": "value"
}'''

    assert test_method(json_input, 'json') == '''{
    "key": "value"
}'''
    assert test_method(json_input, 'javascript') == '''{
    "key": "value"
}'''
    assert test_method(json_input, 'text') == '''{
    "key": "value"
}'''


# Generated at 2022-06-21 14:17:17.267473
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = FormatterPlugin(
        options={'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
            'explicit': False,
        }}
    )
    assert formatter.enabled, True

# Generated at 2022-06-21 14:17:29.318550
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json = JSONFormatter(explicit_json=False,
                         format_options={'json': {'format': True,
                                                  'sort_keys': False,
                                                  'indent': 4},
                                          'colors': {'format': True,
                                                     'request': {'method': 'yellow',
                                                                 'url': 'blue',
                                                                 'headers': 'green'},
                                                     'response': {'headers': 'green',
                                                                  'status': 'bold,magenta'}}},
                         theme={'colors': {'blue': 'blue',
                                           'bold,magenta': 'bold,magenta',
                                           'green': 'green',
                                           'yellow': 'yellow'}})
    assert json.explicit_json == False
    assert json

# Generated at 2022-06-21 14:17:43.850601
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        formatter_plugin = JSONFormatter()
        assert formatter_plugin.format_options['json']['format']
    except:
        print("test failed")


# Generated at 2022-06-21 14:17:52.093235
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # given
    jsonFormatter = JSONFormatter(**{
        'format_options': {
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4
            }
        },
        'explicit_json': True
    })

    # when

    # then
    assert jsonFormatter.enabled == True
    assert jsonFormatter.format_options['json']['sort_keys'] == True
    assert jsonFormatter.format_options['json']['indent'] == 4
    assert jsonFormatter.kwargs['explicit_json'] == True


# Generated at 2022-06-21 14:17:54.013017
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        JSONFormatter()
    except Exception as e:
        assert False, "Unexpected Exception: " + str(e)


# Generated at 2022-06-21 14:17:56.497944
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatterobj = JSONFormatter(format_options = {'json': {'format': False, 'indent': 0, 'sort_keys': True}})
    assert formatterobj.enabled == False

# Generated at 2022-06-21 14:18:00.020856
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    This method is used to test the format_body method of the class JSONFormatter.
    """
    obj = JSONFormatter()
    body = 'data'
    mime = 'data'
    assert obj.format_body(body,mime) == 'data'

# Generated at 2022-06-21 14:18:01.997855
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.name == 'JSONFormatter'
    assert jsonFormatter.enabled


# Generated at 2022-06-21 14:18:05.971485
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    instance = JSONFormatter(
        format_options={'json': {
            'indent': 4,
            'sort_keys': True,
            'format': True,
        }}
    )
    assert type(instance) == JSONFormatter


# Generated at 2022-06-21 14:18:16.099662
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-21 14:18:27.803827
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from datetime import datetime
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from fixtures import EXIT, JSON_OUTPUT

    now = datetime.now().isoformat()
    json_content_type = 'application/json'
    headers = {'Content-Type': json_content_type}
    json_obj = [{'date': now}]
    body = str(json_obj)

    env = {'COLUMNS': '70'}
    r = http('--json', 'GET', 'http://localhost:9080/', headers=headers,
             env=env)
    assert HTTP_OK in r
    assert r.json == json_obj
    assert r.exit_status == ExitStatus.OK


# Generated at 2022-06-21 14:18:39.048289
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test for default values
    json_formatter = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': None
        }
    })
    assert json_formatter.enabled == True
    assert json_formatter.kwargs['explicit_json'] == False
    assert json_formatter.format_options['json']['format'] == True
    assert json_formatter.format_options['json']['sort_keys'] == False
    assert json_formatter.format_options['json']['indent'] == None

    # Test for custom values