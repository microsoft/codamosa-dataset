

# Generated at 2022-06-21 14:13:38.466255
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{"foo": "bar"}', 'application/json') == '{\n    "foo": "bar"\n}'
    assert JSONFormatter().format_body('{"foo": "bar"}', 'text/javascript') == '{\n    "foo": "bar"\n}'
    assert JSONFormatter().format_body('{"foo": "bar"}', 'text/plain') == '{\n    "foo": "bar"\n}'
    assert JSONFormatter().format_body('{"foo": "bar"}', 'text/html') == '{"foo": "bar"}'
    assert JSONFormatter().format_body(b'{"foo": "bar"}', 'application/json') == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-21 14:13:47.726098
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def check(body, mime, result):
        formatter = JSONFormatter(format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        }, explicit_json=False)
        assert result == formatter.format_body(body, mime)

    check('{"a": "b"}', 'application/json', '{\n    "a": "b"\n}')  # Valid JSON
    check('a: "b"', 'application/json', 'a: "b"')  # Invalid JSON
    check('{"a": "b"}', 'text/plain', '{\n    "a": "b"\n}')  # Mime type is not application/json, but is valid JSON

# Generated at 2022-06-21 14:13:54.368237
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonf = JSONFormatter()
    body = jsonf.format_body('{"a": 1, "b": 2}', 'json')
    assert body == '{\n    "a": 1,\n    "b": 2\n}'
    body = jsonf.format_body('{"a": 1, "b": 2}', 'text')
    assert body == '{\n    "a": 1,\n    "b": 2\n}'
    body = jsonf.format_body('{"a": 1, "b": 2}', 'application/json')
    assert body == '{\n    "a": 1,\n    "b": 2\n}'
    body = jsonf.format_body('<html></html>', 'html')
    assert body == '<html></html>'

# Generated at 2022-06-21 14:13:56.633869
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.format_options == False



# Generated at 2022-06-21 14:14:02.912040
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from . import httpie

    body = '[{"username": "user2", "active": false}]'
    assert httpie.JSONFormatter(format_options=dict(json=dict(format=True, indent=2, sort_keys=True))).format_body(body, 'application/json') == '''[
  {
    "active": false,
    "username": "user2"
  }
]'''

# Generated at 2022-06-21 14:14:05.339222
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()

    assert json_formatter.explicit_json
    assert json_formatter.explicit_form
    assert json_formatter.format_options['json']['format']
    assert not json_formatter.format_options['json']['sort_keys']
    assert json_formatter.format_options['json']['indent'] == 2


# Generated at 2022-06-21 14:14:16.261318
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class JSONFormatter(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = True


    formatter = JSONFormatter()

    # Test JSON
    json_str = '''{
        "id": 0,
        "title": "string",
        "completed": true
    }'''
    json_str2 = '''{
        "id": 0,
        "title": "string",
        "completed": true
    }'''
    assert json_str == formatter.format_body(json_str2, 'json')

    # Test JSON with explicit_json option
    json_str = '''{
        "id": 0,
        "title": "string",
        "completed": true
    }'''


# Generated at 2022-06-21 14:14:26.829439
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Body that is already formatted as JSON
    jf1 = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    })
    assert jf1.format_body(
        "{\"a\": 1, \"b\": 2}",
        "application/json") == "{\"a\": 1, \"b\": 2}"

    # Body that is not formatted as JSON
    jf2 = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    })

# Generated at 2022-06-21 14:14:28.793085
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        formatter = JSONFormatter()
        assert formatter.enabled == True
    except:
        assert False


# Generated at 2022-06-21 14:14:32.373979
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(options={'json': {'format': True, 'ensure_ascii': False, 'indent': 2, 'sort_keys': True}}, kwargs={})

# Generated at 2022-06-21 14:14:44.845238
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = { "json": { "format": False, "indent": 4, "sort_keys": False } }
    formatter = JSONFormatter(format_options=format_options)
    assert formatter.enabled == False
    assert formatter.format_options["json"]["format"] == False
    assert formatter.format_options["json"]["indent"] == 4
    assert formatter.format_options["json"]["sort_keys"] == False


# Generated at 2022-06-21 14:14:52.227876
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-21 14:15:02.345186
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(json.dumps({
        'id': 0,
        'name': 'Name',
        'url': 'https://www.example.com/'
    }), 'application/json') == """{
    "id": 0,
    "name": "Name",
    "url": "https://www.example.com/"
}"""
    assert formatter.format_body(json.dumps({
        'id': 0,
        'name': 'Name',
        'url': 'https://www.example.com/'
    }), 'application/javascript') == """{
    "id": 0,
    "name": "Name",
    "url": "https://www.example.com/"
}"""

# Generated at 2022-06-21 14:15:10.323207
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.BuiltinPlugins import BuiltinPlugins
    from settings import Settings
    
    settings = Settings()
    builtin_plugins = BuiltinPlugins(settings)
    
    json_formatter = JSONFormatter(settings.__dict__['format_options'])
    
    body = '{"hello": "world"}'
    mime = 'json'
    expected_body = '{\n    "hello": "world"\n}'
    
    # Run normal method
    result = json_formatter.format_body(body, mime)
    assert result == expected_body, result
    
    # Run patched method
    builtin_plugins.patch_json_formatter(json_formatter)
    result = json_formatter.format_body(body, mime)
    assert result == expected_body

# Generated at 2022-06-21 14:15:16.355318
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.core import parser

    p = parser.create_parser()
    args = p.parse_args(['--json', '--json-sort-keys'])
    formatter = JSONFormatter(args)
    assert formatter.enabled == True
    assert formatter.kwargs['explicit_json'] == False
    assert formatter.kwargs['json_sort_keys'] == True
    assert formatter.kwargs['json_indent'] == 4



# Generated at 2022-06-21 14:15:17.849635
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()
    assert formatter_plugin is not None

# Generated at 2022-06-21 14:15:22.653652
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    p = JSONFormatter()
    body = '{"key1": "value1", "key2": "value2"}'
    test_body = p.format_body(body, 'text')
    assert test_body == '{\n    "key1": "value1",\n    "key2": "value2"\n}'

# Generated at 2022-06-21 14:15:27.180726
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test a correct initialization of the class by mocking an argument
    # passed in the constructor
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            }
        }
    )
    assert formatter.enabled is True



# Generated at 2022-06-21 14:15:29.652633
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(b'{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-21 14:15:35.684205
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Set up the assert_equals function
    at = __import__('pyassert').assert_that
    # Set up the JSONFormatter class
    JSONFormatter = __import__('httpie_json_format').JSONFormatter

    # Create the JSONFormatter object
    jf = JSONFormatter()

    # Test the format_body method
    # Test 1, Explicit JSON
    at(jf.format_body(
        json.dumps({'a': '1', 'b': '2', 'c': '3'}), 'application/json')). \
        is_equal_to("""{
    "a": "1",
    "b": "2",
    "c": "3"
}""")

    # Test 2, JSON implied by MIME

# Generated at 2022-06-21 14:15:51.557604
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    foo = JSONFormatter(
        format_options={
            'json': {
                'format': False,
                'sort_keys': False,
                'indent': 2
            }
        }
    )
    assert foo.format_options['json']['format'] == False



# Generated at 2022-06-21 14:15:57.488197
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(format_options={
        'json': {'format': True, 'sort_keys': True, 'indent': 4}
    }).format_body('{"hi": 5}', 'application/json') == \
        '''{
    "hi": 5
}'''
    assert JSONFormatter(format_options={
        'json': {'format': True, 'sort_keys': True, 'indent': 4}
    }).format_body('<html><body>hi</body></html>', 'text/html') == \
        '<html><body>hi</body></html>'

# Generated at 2022-06-21 14:16:09.058580
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Unit test for method format_body of class JSONFormatter"""

    def func_test(obj, kwargs):
        """function to test method format_body"""
        obj.kwargs.update(kwargs)
        body = '{"a": 1, "b": "c"}'
        if 'content_type' in kwargs:
            content_type = 'Content-Type: ' + kwargs['content_type']
        else:
            content_type = 'Content-Type: application/json'
        assert obj.format_body(
            body=body,
            mime=content_type
        ) == json.dumps(
            obj=json.loads(body),
            indent=obj.format_options['json']['indent']
        )

    # test_case 1:

# Generated at 2022-06-21 14:16:17.091244
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import mock
    body = '[1, 2, 3, 4]'
    # mime_type = 'application/json'
    mime_type = 'text/html'
    plugin = JSONFormatter(format_options = {})
    with mock.patch.object(plugin, 'kwargs', {'explicit_json': False}):
        assert plugin.format_body(body, mime_type) == body
    with mock.patch.object(plugin, 'kwargs', {'explicit_json': True}):
        assert plugin.format_body(body, mime_type) == '\n[\n    1,\n    2,\n    3,\n    4\n]\n'

# Generated at 2022-06-21 14:16:27.288476
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fmter = JSONFormatter({'json': {'format': True}})
    # Valid JSON
    body = '{"a": 1, "b": 2}'
    assert fmter.format_body(body, 'application/json') == '{\n    "a": 1,\n    "b": 2\n}'
    # Invalid JSON
    body = '{"a": 1, "b": 2'
    assert fmter.format_body(body, 'application/json') == body
    # Valid JSON with JavaScript
    body = '{"a": 1, "b": 2}'
    assert fmter.format_body(body, 'text/javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    # Valid JSON with plain text

# Generated at 2022-06-21 14:16:30.221337
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = JSONFormatter(format_options={'json':{'format':True, 'sort_keys':False, 'indent':3}})
    assert(fp.format_options == {'json':{'format':True, 'sort_keys':False, 'indent':3}})
    assert(fp.enabled == True)



# Generated at 2022-06-21 14:16:41.010536
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    def test_JSONFormatter_init_default():
        fp = JSONFormatter()
        assert fp.format_options['json']['format'] == True
        assert fp.format_options['json']['indent'] == None
        assert fp.format_options['json']['sort_keys'] == False

    def test_JSONFormatter_init_indent():
        fp = JSONFormatter(format_options={'json': {'indent': 4}})
        assert fp.format_options['json']['indent'] == 4

    def test_JSONFormatter_init_sort_keys():
        fp = JSONFormatter(format_options={'json': {'sort_keys': True}})
        assert fp.format_options['json']['sort_keys'] == True


# Generated at 2022-06-21 14:16:42.799730
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={"json":{"format":False}})
    assert json_formatter.format_options == {"json":{"format":False}}


# Generated at 2022-06-21 14:16:50.544772
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    def test_json_formatter(body, mime):
        formatter = JSONFormatter()
        formatter.kwargs = {
            'explicit_json': False
        }
        formatter.format_options = {
            'json': {
                'indent': 2,
                'sort_keys': False,
                'format': True
            }
        }
        formatted_body = formatter.format_body(body, mime)
        return formatted_body

    def test_json_formatter_explicit_json(body, mime):
        formatter = JSONFormatter()
        formatter.kwargs = {
            'explicit_json': True
        }

# Generated at 2022-06-21 14:16:55.730938
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from base64 import b64encode
    from httpie.client import JSON_ACCEPT
    kwargs = {'explicit_json': True}
    json_formatter = JSONFormatter(kwargs)
    cases = [
        # Test invalid JSON is not formatted
        ({'body': 'hello, world', 'mime': 'json'}, 'hello, world'),
        # Test valid JSON is formatted
         ({'body': '{"a":1}', 'mime': 'json'}, '{\n    "a": 1\n}'),
         ({'body': '{"a": "c"}', 'mime': 'javascript'}, '{\n    "a": "c"\n}'),
    ]
    for case in cases:
        assert json_formatter.format_body(**case[0]) == case[1]




# Generated at 2022-06-21 14:17:14.229099
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Test that method format_body of class FormatterPlugin works as expected."""
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    body = '{"key": "value"}'
    json_indent = '2'
    args = [
        '--print=B',
        '--json',
        '--json-indent={}'.format(json_indent),
    ]
    env = {'HTTP_TEST_STRICT': 'yes'}
    r = http(
        'GET',
        HTTP_OK,
        '/',
        body,
        env=env,
        args=args,
    )
    assert r.exit_status == ExitStatus.OK
    assert r.stderr == ''
    assert r.json == json.loads(body)

# Generated at 2022-06-21 14:17:16.635276
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
     assert JSONFormatter().format_options == {'json': {'format': False, 'indent': 0, 'sort_keys': False}}

# Unit Test for format_body() method of class JSONFormatter

# Generated at 2022-06-21 14:17:19.749505
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    response_body = '{"key": "value", "list": ["value1", "value2"], "dict": {"key2": "value2"}}'
    mime = 'application/json'

    assert formatter.format_body(response_body, mime) == response_body

# Generated at 2022-06-21 14:17:31.404501
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.input import ParseResult
    from httpie.plugins import FormatterPlugin

    class _JSONFormatter(JSONFormatter, FormatterPlugin):
        pass

    obj = {
        "c": 3,
        "a": 1,
        "b": 2,
    }
    sorted_obj = {
        "a": 1,
        "b": 2,
        "c": 3,
    }
    body = json.dumps(obj=obj)
    expected_body_no_sort_keys = body
    expected_body_sort_keys = json.dumps(obj=sorted_obj)

    # Tests
    formatter = _JSONFormatter()

    # Bad JSON
    print("Test for bad JSON")
    body = None
    format_options = {'json': {}}

# Generated at 2022-06-21 14:17:37.582228
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    # Test with JSON data
    body = '{"id": 123, "name": "Amit", "email": "amit@example.com"}'
    formatter = JSONFormatter()
    formatted_body = formatter.format_body(body,'application/json')
    assert json.loads(body) == json.loads(formatted_body)
    
    # Test with non JSON data (ignore)
    body = '"id" 123, "name": "Amit", "email": "amit@example.com"}'
    formatter = JSONFormatter()
    formatted_body = formatter.format_body(body,'application/json')
    assert body == formatted_body

# Generated at 2022-06-21 14:17:41.058530
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_json = JSONFormatter(
        json={
            'sort_keys': False,
            'indent': 4,
            'format': True
        }
    )
    assert formatter_json


# Generated at 2022-06-21 14:17:48.039546
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
	j = JSONFormatter()
	assert j.format_body('{"a":1}', 'json') != '{"a": 1}'  # Check that JSONFormatter doesn't change anything (because sort_keys and indent aren't set) when the input is already JSON
	assert j.format_body('{"a":1}', 'json') == j.format_body('{"a": 1}', 'json')  # Check that JSONFormatter doesn't change anything (because sort_keys and indent aren't set) when the input is already JSON
	j.format_options['json']['sort_keys'] = True
	j.format_options['json']['indent'] = 2
	assert j.format_body('{"a":1}', 'json') == '{\n  "a": 1\n}'  # Check that JSONFormatter can prettify

# Generated at 2022-06-21 14:17:57.137633
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = {
        'json': {'format': True, 'indent': 3, 'sort_keys': False},
        'colors': {'format': True, 'request': {
            'method': 'blue', 'headers': 'green', 'body': 'white'
        }, 'response': {
            'status': {'code': 'cyan', 'line': 'white'},
            'headers': 'green', 'body': 'white'
        }, 'error': {
            'line': 'red'
        }},
    }

    kwargs = {
        'format_options': options,
        'explicit_json': False,
        'colors': True,
        'style': 'DEFAULT',
        'stream': False
    }

    response = JSONFormatter(**kwargs)


# Generated at 2022-06-21 14:18:05.594172
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import TestEnvironment, http

    env = TestEnvironment()
    if env.is_windows and env.is_appveyor:  # TODO
        return
    env.start_server()

    # Test for explicit json format
    foo_json = """
        {
            "foo": "lorem ipsum",
            "bar": "foo"
        }
    """
    r = http(env.base_url, 'POST', '--json', foo_json)
    assert r.record['status'] == ExitStatus.OK
    assert r.record['response']['body'] == foo_json

    env.shutdown_server()

# Generated at 2022-06-21 14:18:10.295971
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    expected = '[1,2,3]'
    actual = JSONFormatter.format_body(body='[1,2,3]', mime='text')
    assert expected == actual


# REST API From Dr. Quan Z. Sheng
# Implements some features

# Generated at 2022-06-21 14:18:31.339006
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {'format': True, 'sort_keys': True, 'indent': 4}
    }, kwargs={'explicit_json': True})

    body = \
        '{"z":3, "a":2, "j":1}'
    mime = 'application/json'
    actual = formatter.format_body(body, mime)
    expected = \
        '{\n' \
        '    "z": 3,\n' \
        '    "a": 2,\n' \
        '    "j": 1\n' \
        '}'

    assert actual == expected

# Generated at 2022-06-21 14:18:36.155620
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    """Unit test for constructor of class JSONFormatter"""

    formatter = JSONFormatter()

    assert formatter.format_options == {'json': {'format': True,
                                                 'indent': 2,
                                                 'sort_keys': True}}


# Generated at 2022-06-21 14:18:47.062859
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs = {'explicit_json': False}

    # invalid json
    body = '{"notvalidjson'
    mime = 'json'
    out = formatter.format_body(body, mime)
    assert out == body

    # valid json, no explicit json
    body = '{"a": "b"}'
    mime = 'json'
    out = formatter.format_body(body, mime)
    assert out == body

    # valid json, explicit json
    formatter.kwargs['explicit_json'] = True
    out = formatter.format_body(body, mime)
    assert out == '{\n    "a": "b"\n}'

    # valid json, but not json mime

# Generated at 2022-06-21 14:18:49.114766
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert True


# Generated at 2022-06-21 14:18:54.571850
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs['explicit_json'] = True
    formatter.format_options['json']['format'] = True
    body = '{"a" : true,"b" : 1,"c" : "My test"}'
    assert formatter.format_body(body, None) == '{\n    "a": true,\n    "b": 1,\n    "c": "My test"\n}'

# Generated at 2022-06-21 14:18:58.123382
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    testFormatter = JSONFormatter()
    assert testFormatter.format_body("{'test': 'true'}", 'json') == '{\n    "test": "true"\n}'
    assert testFormatter.format_body("{'test': 'true'}", 'javascript') == '{\n    "test": "true"\n}'
    assert testFormatter.format_body("{'test': 'true'}", 'text') == '{\n    "test": "true"\n}'
    assert testFormatter.format_body("{'test': 'true'}", 'not json') == "{'test': 'true'}"


# Generated at 2022-06-21 14:18:58.747263
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-21 14:18:59.361931
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass

# Generated at 2022-06-21 14:19:08.888109
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class Dummy:
        pass

    args = Dummy()
    args.explicit_json = False
    args.colors = False
    args.style = None
    args.format = ['json']

    plugin = JSONFormatter(args)

    assert plugin.format_options['json']['format']
    assert not plugin.format_options['json']['indent']
    assert not plugin.format_options['json']['sort_keys']

    assert plugin.format_body('"foo"', 'application/json') == '"foo"'

    args.explicit_json = True
    args.format = []
    plugin = JSONFormatter(args)
    assert plugin.format_body('"foo"', 'text/html') == '"foo"'


# Generated at 2022-06-21 14:19:13.719638
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
  formatter = JSONFormatter(
      format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}},
      explicit_json=False,
  )
  assert formatter.format_body('{"a": "b"}', 'application/json') == '{\n  "a": "b"\n}'
  assert formatter.format_body('{"a": "b"}', 'text/html') == '{"a": "b"}'

# Generated at 2022-06-21 14:19:27.624740
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    _json_formatter = JSONFormatter(
        fmt=None,
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': False
            }
        },
        config=None,
        explicit_json=False
    )

    body = '{"hi": "hello", "foo": "world"}'
    json_body = _json_formatter.format_body(body, 'text/json')
    assert json_body == '{\n    "hi": "hello",\n    "foo": "world"\n}'

# Generated at 2022-06-21 14:19:31.380852
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    a = JSONFormatter(format_options={"json": {"format": True, "indent": 2, "sort_keys": True}, "headers": {"style": "upper"}})
    assert a.format_options["json"] == {"format": True, "indent": 2, "sort_keys": True}
    assert a.format_options.get("headers") == {"style": "upper"}
    assert a.enabled == True


# Generated at 2022-06-21 14:19:33.934128
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Inputs
    formatter = JSONFormatter()
    body = '{"number":4,"string":"Hello"}'
    mime = 'application/json'

    # Compute output
    out = formatter.format_body(body, mime)

    # Assert output
    assert out == '{\n    "number": 4,\n    "string": "Hello"\n}'

# Generated at 2022-06-21 14:19:37.951844
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Initialize JSONFormatter class object
    formatter = JSONFormatter()

    # Test the default values of format_options
    assert formatter.format_options == {'json': {'format': True, 'indent': 2,
                                                 'sort_keys': True}}

    # Test the default value of enabled
    assert formatter.enabled == True


# Generated at 2022-06-21 14:19:49.122847
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import JSON_SORT_KEYS, JSON_SORT_KEYS_DEFAULT

# Generated at 2022-06-21 14:19:50.273904
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()
    assert formatter_plugin.enabled == True

# Generated at 2022-06-21 14:20:01.173470
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={
            "json": {
                "format": True,
                "sort_keys": True,
                "indent": 4
            }
        },
        explicit_json=False
    )
    body = '{"greeting":"Hello, World!"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "greeting": "Hello, World!"\n}'

    body = '{"greeting":"Hello, World!"}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "greeting": "Hello, World!"\n}'

    body = '{"greeting":"Hello, World!"}'
    mime = 'text'

# Generated at 2022-06-21 14:20:08.502249
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    plugin_manager = json.dumps({'plugins': {'managers': {}}})
    formatter_options = json.dumps({'json': {'indent': 2, 'sort_keys': True, 'format': False}})
    def get_config_dir(config_dir):
        return ''

    try:
        formatter = JSONFormatter(
            plugin_manager=plugin_manager,
            formatter_options=formatter_options,
            get_config_dir=get_config_dir
        )
        assert formatter.format_options['json']['sort_keys'] == True
    except:
        assert False


# Generated at 2022-06-21 14:20:14.213199
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import FormatterPluginTest
    from httpie.context import Environment
    env = Environment(formatter='json')
    kwargs = FormatterPlugin.kwargs_from_env(env)
    formatter = JSONFormatter(**kwargs)

    for test in FormatterPluginTest.test_cases:
        actual = formatter.format_body(test.body, test.mimetype)
        assert actual == test.expected



# Generated at 2022-06-21 14:20:18.072227
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = FormatterPlugin()
    j = JSONFormatter(format_options = f.format_options, kwargs = {'explicit_json': False})
    assert j.enabled == True


# Generated at 2022-06-21 14:20:31.692301
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter
    assert formatter


# Generated at 2022-06-21 14:20:34.166114
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.enabled == True
    assert isinstance(formatter, JSONFormatter)


# Generated at 2022-06-21 14:20:37.129757
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
    format_options = {
        'json': {'format': True, 'indent': 4, 'sort_keys': True}
    })

    assert json_formatter.enabled == True


# Generated at 2022-06-21 14:20:48.931657
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter_obj = JSONFormatter()
    assert jsonformatter_obj.enabled == False
    jsonformatter_obj.format_options['json']['format'] = False
    jsonformatter_obj.format_options['json']['sort_keys'] = True
    jsonformatter_obj.format_options['json']['indent'] = False
    jsonformatter_obj_with_kwargs = JSONFormatter(**{'explicit_json': False})
    assert jsonformatter_obj_with_kwargs.enabled == False
    jsonformatter_obj_with_kwargs.format_options['json']['format'] = False
    jsonformatter_obj_with_kwargs.format_options['json']['sort_keys'] = True

# Generated at 2022-06-21 14:20:50.456441
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    JSONFormatter.format_body("JSON=JSON", "json")

# Generated at 2022-06-21 14:20:56.826530
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test empty string
    text = JSONFormatter.format_body('', 'json')
    assert text == '""'
    # Test bad input format
    text = JSONFormatter.format_body('{"a": 1}', 'html')
    assert text == '{"a": 1}'
    # Test wrong json format
    text = JSONFormatter.format_body('{"a": 1', 'json')
    assert text == '{"a": 1'
    # Test succesful conversion
    text = JSONFormatter.format_body('{"a": 1}', 'json')
    assert text == '{\n    "a": 1\n}'
    # Test succesful conversion with unicode
    text = JSONFormatter.format_body('{"a": "✓"}', 'json')

# Generated at 2022-06-21 14:21:07.435102
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-21 14:21:08.976593
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    tmpFormatter = JSONFormatter()
    assert tmpFormatter.kwargs == {}


# Generated at 2022-06-21 14:21:12.455154
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    foo = JSONFormatter(format_options={
        'json': {
            'format': 'True',
            'indent': 2,
            'sort_keys': 'False'
        }
    })
    assert foo.format_options['json']['format'] == True
    assert foo.format_options['json']['indent'] == 2
    assert foo.format_options['json']['sort_keys'] == False


# Generated at 2022-06-21 14:21:22.129901
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class JSONFormatterForTest:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.format_options = {
                'json': {
                    'format': True,
                    'sort_keys': True,
                    'indent': 4
                }
            }
    input = '''{"args": {}, "headers": {"Accept": "*/*", "Accept-Encoding": "gzip, deflate", "Host": "httpbin.org", "User-Agent": "HTTPie/0.9.8"}, "origin": "180.149.240.203", "url": "https://httpbin.org/get"}'''

# Generated at 2022-06-21 14:21:57.018520
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-21 14:22:06.542200
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test method format_body of class JSONFormatter
    """
    jf = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        },
        explicit_json=False,
    )
    body = "{'id': 0, 'name': 'John'}"
    assert jf.format_body(body, mime='application/ala-bamba') == \
           '{\n    "id": 0,\n    "name": "John"\n}'
    assert jf.format_body(body, mime='application/json') == \
           '{\n    "id": 0,\n    "name": "John"\n}'

# Generated at 2022-06-21 14:22:11.604142
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    response = b'{"name": "John", "surname": "Smith"}'
    mime = 'application/json'
    formatter = JSONFormatter(format_options={
      'json': {
        'format': True,
        'indent': 4,
        'sort_keys': True,
      },
    })
    assert formatter.format_body(response.decode('utf-8'), mime) == '{\n    "name": "John",\n    "surname": "Smith"\n}'


# Generated at 2022-06-21 14:22:12.362359
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter


# Generated at 2022-06-21 14:22:16.513356
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"some": "json"}'
    mime = 'json'
    res = formatter.format_body(body, mime)
    assert res == '{\n    "some": "json"\n}'

# Generated at 2022-06-21 14:22:21.072201
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(explicit_json=False, format_options={'json': {'indent': 2, 'sort_keys': True, 'format': True}})
    assert jf.format_body('{"foo": 1}', 'text') == '{\n  "foo": 1\n}'

# Generated at 2022-06-21 14:22:26.223673
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4,
        }
    }).format_body(
        body='{"x": "y", "a": "b"}',
        mime='json'
    ) == '''{\n    "a": "b",\n    "x": "y"\n}'''

# Generated at 2022-06-21 14:22:35.553321
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '''[
        {
            "author": "fjb",
            "title": "Nice post"
        },
        {
            "author": "nl",
            "title": "Bad post"
        }
    ]'''
    formatter = JSONFormatter()
    mime = 'text/json'
    res = formatter.format_body(body=body, mime=mime)
    assert res == '''[
    {
        "author": "fjb",
        "title": "Nice post"
    },
    {
        "author": "nl",
        "title": "Bad post"
    }
]'''
    res = formatter.format_body(body='wtf', mime=mime)
    assert res == 'wtf'
    res = formatter.format_

# Generated at 2022-06-21 14:22:46.955882
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(**{'explicit_json': True,
                                 'format_options': {
                                     'json': {
                                         'format': True,
                                         'indent': 4,
                                         'sort_keys': True
                                     }
                                 }})
    assert formatter.format_body("""
{
    "key": "value"
}
""", "json") == """{
    "key": "value"
}
"""
    assert formatter.format_body("""
{
    "key": "value"
}
""", "javascript") == """{
    "key": "value"
}
"""

# Generated at 2022-06-21 14:22:55.309138
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body(
        "test_body",
        'application/json'
    ) == "test_body"

    assert JSONFormatter().format_body(
        "{\"body\":\"test_body\"}",
        'application/json'
    ) == '{\n    "body": "test_body"\n}'

    assert JSONFormatter().format_body(
        "{\"body\":\"test_body\"}",
        'application'
    ) == "{\"body\":\"test_body\"}"

    assert JSONFormatter(explicit_json=True).format_body(
        "{\"body\":\"test_body\"}",
        'application'
    ) == '{\n    "body": "test_body"\n}'