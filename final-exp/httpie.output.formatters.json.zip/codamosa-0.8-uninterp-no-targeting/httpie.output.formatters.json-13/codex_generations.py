

# Generated at 2022-06-21 14:13:34.143965
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert(JSONFormatter({'json': {'format': True}}).enabled)
    assert(not JSONFormatter({'json': {'format': False}}).enabled)



# Generated at 2022-06-21 14:13:45.043959
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Given
    formatter = JSONFormatter()
    formatter.kwargs = {'explicit_json': True}
    formatter.format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        },
        'colors': {
            'format': False,
        },
    }

    # When
    actual = formatter.format_body(
        '{"a": "b", "c": "d"}',
        'application/json',
    )
    # And
    actual_explicit = formatter.format_body(
        '{"a": "b", "c": "d"}',
        'text/plain',
    )

    # Then

# Generated at 2022-06-21 14:13:54.655156
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import registry
    registry.clear()

    f = JSONFormatter(format_options={'json': {'indent': 4, 'sort_keys': True, 'format': False}})
    assert f.format_body('{"a":1}', "application/json") == '{"a":1}'
    assert f.format_body('{"a":1}', "text/javascript") == '{"a":1}'
    assert f.format_body('{"a":1}', "text") == '{"a":1}'
    assert f.format_body('{"a":1}', "text/plain") == '{"a":1}'

# Generated at 2022-06-21 14:13:58.487037
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 3, 'sort_keys': True}}, explicit_json=False)
    assert json_formatter.enabled == True

test_JSONFormatter()


# Generated at 2022-06-21 14:14:07.094355
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(**{
        "format_options": {
            "json": {
                "sort_keys": True,
                "indent": 2,
                "format": True
            },
            "colors": True
        },
        "explicit_json": True
    }) == JSONFormatter(
        format_options={
            "json": {
                "sort_keys": True,
                "indent": 2,
                "format": True
            },
            "colors": True
        },
        explicit_json=True
    )


# Unit tests for format_body() of class JSONFormatter

# Generated at 2022-06-21 14:14:12.427301
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {'format': True, 'sort_keys': True, 'indent': 4}
    }, stdout_isatty=False)
    body = formatter.format_body('{"a": 1}', 'json')
    assert body == '{\n    "a": 1\n}\n'

# Generated at 2022-06-21 14:14:23.964384
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False)
    assert formatter.format_body(
        '{"teste":"ok"}',
        'json'
    ) == '{\n    "teste": "ok"\n}'
    assert formatter.format_body(
        '{"teste":"ok"}',
        'text'
    ) == '{\n    "teste": "ok"\n}'
    assert formatter.format_body(
        '{"teste":"ok"}',
        'javascript'
    ) == '{\n    "teste": "ok"\n}'
    assert formatter.format_body(
        '{"teste":"ok"}',
        'anything_else'
    ) == '{"teste":"ok"}'

# Generated at 2022-06-21 14:14:27.029296
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Unit test for format_body method of class JSONFormatter"""
    jsonFormatter = JSONFormatter()
    string = '{ "a": 2 }'
    response = jsonFormatter.format_body(string, 'json')
    assert response == string



# Generated at 2022-06-21 14:14:31.838555
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}},
        explicit_json=False,
    )
    assert formatter.enabled == True
    assert formatter.kwargs['explicit_json'] == False


# Generated at 2022-06-21 14:14:37.960215
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options = {
            'json' : {
                'format' : False,
                'indent' : 4,
                'sort_keys' : False
            }
        },
        explicit_json = False
    )
    assert json_formatter.enabled == False
    assert json_formatter.kwargs == {'explicit_json' : False}


# Generated at 2022-06-21 14:14:49.568422
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Create a JSONFormatter object
    json_formatter = JSONFormatter()

    # The format_options of the object should be the one used by the class
    assert json_formatter.format_options == json_formatter.FORMAT_OPTIONS

    # The enabled variable should be true if format is set to True in format_options
    json_formatter.format_options['json']['format'] = True # set format to True
    assert json_formatter.enabled

    # Queue is empty because we haven't added any information
    assert json_formatter.kwargs == {}

    # Add a key-value pair
    json_formatter.kwargs['explicit_json'] = True

    # Queue should not be empty because we have added a key-value pair
    assert json_formatter.kwargs

    # The key should be

# Generated at 2022-06-21 14:15:00.391805
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar", "baz": "qux"}', 'json') == '''{
    "baz": "qux",
    "foo": "bar"
}'''
    assert formatter.format_body('{"foo": "bar"}', 'json') == '''{
    "foo": "bar"
}'''
    assert formatter.format_body('{"foo": "bar"}', 'json') == '''{
    "foo": "bar"
}'''
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{"foo": "bar"}'

# Generated at 2022-06-21 14:15:03.678667
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options == {'json': {'format': True, 'indent': 4, 'sort_keys': True}}


# Generated at 2022-06-21 14:15:07.909084
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    obj = JSONFormatter(format_options={'json': {'format': None}})
    assert obj.enabled == None
    obj = JSONFormatter(format_options={'json': {'format': True}})
    assert obj.enabled == True
    obj = JSONFormatter(format_options={'json': {'format': False}})
    assert obj.enabled == False


# Generated at 2022-06-21 14:15:10.335417
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(format_options = True, kwargs = True)
    _ = f.format_body("null", "json")

# Run unit test for constructor of class JSONFormatter
test_JSONFormatter()


# Generated at 2022-06-21 14:15:14.786851
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    plugin = JSONFormatter({
        'json': {
            'sort_keys': False,
            'indent': 2,
            'format': True,
        }
    })
    data = {'foo': 1, 'bar': 2}
    body = json.dumps(data)
    assert body == plugin.format_body(body, 'json')

# Generated at 2022-06-21 14:15:19.333722
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    global JF
    JF = JSONFormatter(format_options={'json':{'format' : False}}, explicit_json=False)
    assert JF.format_options == {'json': {'format': False}}
    assert JF.explicit_json == False


# Unit tests for method format_body of class JSONFormatter

# Generated at 2022-06-21 14:15:29.289113
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test that the method doesn't change valid JSON.
    assert(JSONFormatter().format_body('{"foo": "bar"}', '') == '{"foo": "bar"}')
    # Test that the method doesn't change invalid JSON (unless
    # explicitly asked).
    assert(JSONFormatter().format_body('{foo: bar}', '') == '{foo: bar}')
    assert(JSONFormatter(explicit_json=False).format_body('{foo: bar}', '') == '{foo: bar}')
    assert(JSONFormatter(explicit_json=True).format_body('{foo: bar}', '') == '{foo: bar}')
    # Test that the method does change JSON, if it is explicitly asked.

# Generated at 2022-06-21 14:15:31.971817
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.formatter import JSONFormatter
    json_formatter = JSONFormatter(explicit_json=False)
    body = '''{"a": 1}'''
    json_formatter.format_body(body,'application/json')

# Generated at 2022-06-21 14:15:34.320343
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"k": "v"}'
    assert body == formatter.format_body(body, 'json')



# Generated at 2022-06-21 14:15:47.680705
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def test(body: str, is_json: bool, expected: str, json_options: dict,
             explicit_json: bool = False) -> None:
        f = JSONFormatter(format_options={'json': json_options},
                          explicit_json=explicit_json)
        actual = f.format_body(body=body, mime='application/json')
        assert actual == expected

    test('{"foo": 1}', True, '{\n    "foo": 1\n}', {'sort_keys': False, 'indent': 4})
    test('{"foo": 1}', True, '{\n    "foo": 1\n}', {'sort_keys': True, 'indent': 4})

# Generated at 2022-06-21 14:15:56.344490
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert json.dumps({
        'data': [
            {
                'id': 1,
                'message': 'I love HTTPie',
            },
            {
                'id': 2,
                'message': 'HTTPie is awesome',
            }
        ],
    }) == JSONFormatter(format_options=dict(), kwargs=dict()).format_body(
      '''{
           "data": [
               {
                   "id": 1,
                   "message": "I love HTTPie"
               },
               {
                   "id": 2,
                   "message": "HTTPie is awesome"
               }
           ]
       }'''
        , 'json'
    )


# Generated at 2022-06-21 14:15:58.359602
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    JSONFormatter().format_body('{ "key": "value" }', 'application/json')

# Generated at 2022-06-21 14:15:59.341207
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert "a" == "a"

# Generated at 2022-06-21 14:16:01.948499
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert str(formatter.enabled) == 'False'
    assert formatter.kwargs == {}

# Generated at 2022-06-21 14:16:09.953864
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_input = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    test_obj = JSONFormatter(format_options=test_input, explicit_json=True,
                             colors=256, style='solarized')
    assert test_obj.enabled == True
    assert test_obj.kwargs['explicit_json'] == True
    assert test_obj.kwargs['colors'] == 256
    assert test_obj.kwargs['style'] == 'solarized'


# Generated at 2022-06-21 14:16:12.016900
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled is False


# Generated at 2022-06-21 14:16:19.071695
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.plugins
    from httpie.plugins.json import JSONFormatterPlugin
    from httpie.plugins.json import JSONFormatter

    class JSONFormatterPluginTest(JSONFormatterPlugin):
        JSONFormatter = JSONFormatter

    httpie.plugins.json.JSONFormatterPlugin = JSONFormatterPluginTest

    arguments = {'json': {'format': True, 'sort_keys': False, 'indent': 2}}
    plugin = JSONFormatterPlugin(**arguments)

    body = '{"example": "test"}'
    assert plugin.format_body(body, 'json') == '{\n  "example": "test"\n}'
    assert plugin.format_body(body, 'javascript') == '{\n  "example": "test"\n}'

# Generated at 2022-06-21 14:16:26.207075
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert(JSONFormatter.format_body('{"key": "value"}') == '{\n  "key": "value"\n}')
    assert(JSONFormatter.format_body('{}') == '{}')
    assert(JSONFormatter.format_body('{"key": "value"') == '{"key": "value"')
    assert(JSONFormatter.format_body('{"key": "value') == '{"key": "value')


JSONFormatter.__test_class__ = test_JSONFormatter_format_body

# Generated at 2022-06-21 14:16:28.282287
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Instantiation of class JSONFormatter
    json_formatter = JSONFormatter()

    assert json_formatter.enabled is False