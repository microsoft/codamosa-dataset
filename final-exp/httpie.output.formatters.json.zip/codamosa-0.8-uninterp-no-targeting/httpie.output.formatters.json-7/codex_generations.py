

# Generated at 2022-06-21 14:13:31.365806
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass


# Generated at 2022-06-21 14:13:39.263988
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json = JSONFormatter(
        format_options = {
            "json": {
                "format": True,
                "indent": 4,
                "sort_keys": True
            }
        },
        explicit_json = True
    )

    assert json is not None
    assert json.kwargs['explicit_json'] == True
    assert json.format_options['json']['sort_keys'] == True

#  Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-21 14:13:48.275955
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {
        'format': True,
        'indent': 2,
        'sort_keys': True
    }}, explicit_json=True)

    input_data = '{"John": "doe", "John doe": "John"}'
    output_data = '{\n  "John": "doe",\n  "John doe": "John"\n}'.encode('utf8')
    assert formatter.format_body(input_data, "json") == output_data

    input_data = '{"John": "doe", "John doe": "John"}'
    output_data = '{"John": "doe", "John doe": "John"}'.encode('utf8')

# Generated at 2022-06-21 14:13:54.156093
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    kwargs = {
        'format_options': {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        }
    }
    JF = JSONFormatter(**kwargs)
    assert JF.format_options == kwargs['format_options']
    assert JF.enabled


# Generated at 2022-06-21 14:13:56.393846
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter(**{'format_options': {}, 'explicit_json': False})
    assert formatter_plugin is not None

# Generated at 2022-06-21 14:13:58.991513
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    my_formatter = JSONFormatter()
    assert my_formatter.enabled == my_formatter.format_options['json']['format']


# Generated at 2022-06-21 14:14:10.249275
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
  config = {
      'json': {
          'indent': 2,
          'sort_keys': True,
          'format': True
      }
  }
  formatter = JSONFormatter(format_options = config, kwargs = {'explicit_json': True})
  body = '{"ID": 12, "name": "test"}'
  mime = 'json'
  assert formatter.format_body(body, mime) == '{\n  "ID": 12,\n  "name": "test"\n}'
  config = {
      'json': {
          'indent': 2,
          'sort_keys': False,
          'format': True
      }
  }
  formatter = JSONFormatter(format_options = config, kwargs = {'explicit_json': True})


# Generated at 2022-06-21 14:14:19.036816
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = FormatterPlugin(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        }
    )
    jf = JSONFormatter(**fp.kwargs)
    assert jf.enabled
    assert jf.kwargs['explicit_json']
    assert jf.format_options['json']['format']
    assert jf.format_options['json']['indent'] == 4
    assert jf.format_options['json']['sort_keys']


# Generated at 2022-06-21 14:14:28.311616
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    # Valid JSON(array) as input
    body = '[1, 2, 3]'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '[1, 2, 3]'
    # Valid JSON(object) as input
    body = '{"name": "example", "age": 20}'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{"name": "example", "age": 20}'
    # Invalid JSON as input
    body = '{ "name": "example", "age": 20 }'
    mime = 'application/json'

# Generated at 2022-06-21 14:14:39.622217
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # define variables
    test_plugin = JSONFormatter(format_options={'json': {'indent': 4, 'sort_keys': True, 'format': True}}, explicit_json=False)  # type: JSONFormatter

    # define expected results
    expected_result_1 = json.dumps({"reponame": "GithubExplorer", "owner": "AlaaAttya"}, sort_keys=True, ensure_ascii=False, indent=4)
    expected_result_2 = json.dumps({"reponame": "GithubExplorer", "owner": "AlaaAttya"}, sort_keys=True, ensure_ascii=False, indent=4)

    # define test data

# Generated at 2022-06-21 14:14:44.419400
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    res = JSONFormatter(output_options={'json': {'format': True}})
    assert res.enabled == True


# Generated at 2022-06-21 14:14:52.007471
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False,
        config_dir=None
    )
    unmarshalled_json_body = {
        "array": [1, 2, 3],
        "boolean": True,
        "null": None,
        "number": 123,
        "object": {
            "a": "b",
            "c": "d",
            "e": "f"
        },
        "string": "Hello World"
    }
    json_body = json.dumps(obj=unmarshalled_json_body)

# Generated at 2022-06-21 14:14:56.300452
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import plugin_manager
    assert plugin_manager._formatter_plugins['.json']().format_options['json']['format']
    assert not plugin_manager._formatter_plugins['.json']({'explicit_json': True})().format_options['json']['format']

# Generated at 2022-06-21 14:15:00.960567
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test valid constructor
    json_fmt = JSONFormatter(format_options={'json': {'format': False}})
    assert not json_fmt.enabled
    json_fmt = JSONFormatter(format_options={'json': {'format': True}})
    assert json_fmt.enabled


# Generated at 2022-06-21 14:15:09.280839
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Test with non-JSON body
    body = "non json"
    mime = "json"
    assert JSONFormatter().format_body(body, mime) == body

    # Test with invalid JSON
    body = "invalid json"
    mime = "json"
    assert JSONFormatter().format_body(body, mime) == body

    # Test with valid JSON and mime type json
    body = '{"firstName": "John", "lastName": "Smith"}'
    mime = "json"
    assert JSONFormatter().format_body(body, mime) == body

    # Test with valid JSON and mime type javascript
    body = '{"firstName": "John", "lastName": "Smith"}'
    mime = "javascript"

# Generated at 2022-06-21 14:15:12.864635
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }
    plugin = JSONFormatter(options)
    assert plugin.kwargs == options


# Generated at 2022-06-21 14:15:16.446901
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '[1, 2, 3]'
    ret = formatter.format_body(body, 'application/json')
    assert ret == '[1, 2, 3]'



# Generated at 2022-06-21 14:15:26.405071
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fmt = JSONFormatter()
    # set JSON
    fmt.format_options['json']['format'] = True
    # set indent
    fmt.format_options['json']['indent'] = 2
    # set sort keys
    fmt.format_options['json']['sort_keys'] = True
    # set explicit JSON
    fmt.kwargs['explicit_json'] = True

    # test format body
    assert fmt.format_body('{"foo":"bar"}', "json") == \
           '{\n  "foo": "bar"\n}'
    assert fmt.format_body('{"foo":"bar"}', "javascript") == \
           '{\n  "foo": "bar"\n}'

# Generated at 2022-06-21 14:15:31.237079
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter({
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        },
    }, explicit_json=True)

    assert type(json_formatter) == JSONFormatter
    assert json_formatter.enabled is True
    assert json_formatter.kwargs['explicit_json'] is True


# Generated at 2022-06-21 14:15:33.317443
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_plugin = JSONFormatter(info=None, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}, kwargs={'explicit_json': False})
    assert test_plugin.enabled

# Generated at 2022-06-21 14:15:49.002113
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test explict_json FormatterPlugin
    json_formatter_explict = JSONFormatter(
        explicit_json=True,
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': False,
            },
            'colors': {
                'httpie': False,
                'requests': False,
            },
        }
    )
    assert json_formatter_explict.format_body("Hello World!", 'text/html') == "Hello World!"
    assert json_formatter_explict.format_body("{}", 'json') == "{}"
    assert json_formatter_explict.format_body("{}", 'javascript') == "{}"

# Generated at 2022-06-21 14:15:55.097121
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_formatter = JSONFormatter(**JSONFormatter.DEFAULT_FORMAT_OPTIONS)
    assert body_formatter.format_body("{\"key\":\"value\"}", "application/json") == "{\n    \"key\": \"value\"\n}"
    assert body_formatter.format_body("[1,2,3]", "application/json") == "[\n    1,\n    2,\n    3\n]"
    assert body_formatter.format_body("true", "application/json") == "true"

# Generated at 2022-06-21 14:16:06.465539
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    GIVEN JSONFormatter method format_body
    WHEN the method is called with a body that is not a valid json
    THEN the method returns the body unchanged
    """
    body = "Not a valid json"
    mime = "text/html"
    formatter = JSONFormatter(explicit_json=True)
    assert body == formatter.format_body(body, mime)

    """
    GIVEN JSONFormatter method format_body
    WHEN the method is called with a body that is not a valid json
    BUT the mime is "json"
    THEN the method returns the body unchanged
    """
    body = "Not a valid json"
    mime = "application/json"
    formatter = JSONFormatter(explicit_json=False)

# Generated at 2022-06-21 14:16:16.319121
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    plugin = JSONFormatter({'json': {'indent': 0}})
    body = '[{"foo": 123}]'
    content_type = 'application/json'
    result = plugin.format_body(body, content_type)
    assert result == '[{"foo": 123}]'
    content_type = 'application/javascript'
    result = plugin.format_body(body, content_type)
    assert result == '[{"foo": 123}]'
    content_type = 'text/javascript'
    result = plugin.format_body(body, content_type)
    assert result == '[{"foo": 123}]'
    content_type = 'text/plain'
    result = plugin.format_body(body, content_type)
    assert result == '[{"foo": 123}]'
    body = '{}'

# Generated at 2022-06-21 14:16:19.082772
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={
        'json': {
            'format': 'True',
            'indent': 4,
            'sort_keys': 'False'
        }
    })

# Generated at 2022-06-21 14:16:27.715475
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.cli.formatters import JSONFormatter
    import json
    import os
    obj = json.load(file('./test/data/test.json'))
    sorted_keys = json.dumps(obj, sort_keys=True, indent=4)
    not_sorted = json.dumps(obj, sort_keys=False, indent=4)
    jf = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}},
                       explicit_json=True)
    assert jf.format_body(body=not_sorted, mime=None) == sorted_keys

# Generated at 2022-06-21 14:16:36.361459
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{'explicit_json': False,
                                      'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}})
    body = '{"a": 1, "b": 2}'
    body = json_formatter.format_body(body=body, mime='application/json')
    assert body == '{\n    "a": 1,\n    "b": 2\n}'

    body = '{"a": 1, "b": "c"}'
    body = json_formatter.format_body(body=body, mime='application/json')
    assert body == '{\n    "a": 1,\n    "b": "c"\n}'

# Generated at 2022-06-21 14:16:44.846743
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    request_body = '''{
        "username":"John Doe",
        "password":"123",
        "updatetime": "2018-10-01 10:00:00"
    }'''
    formatter = JSONFormatter(**{'explicit_json': False, 'format_options':{'json':{'sort_keys': True, 'indent': 4, 'format': True}}})

    assert '''{
    "password": "123",
    "updatetime": "2018-10-01 10:00:00",
    "username": "John Doe"
}''' == formatter.format_body(request_body,'application/json')


# Generated at 2022-06-21 14:16:50.548602
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body(body='{"h":"w"}', mime='json') == '{\n  "h": "w"\n}'
    assert JSONFormatter().format_body(body='{"h":"w"}', mime='text') == '{\n  "h": "w"\n}'
    assert JSONFormatter().format_body(body='{"h":"w"}', mime='javascript') == '{\n  "h": "w"\n}'
    assert JSONFormatter().format_body(body='{"h":"w"}', mime='xml') == '{"h":"w"}'

# Generated at 2022-06-21 14:16:51.586616
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter()
    assert j.enabled