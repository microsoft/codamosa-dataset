

# Generated at 2022-06-21 14:13:26.733830
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    assert(f.enabled)

# Generated at 2022-06-21 14:13:32.783947
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert (
        JSONFormatter(explicit_json=False,
                      format_options=
                      {'json': {'sort_keys': False, 'indent': None, 'format': True}})
        .format_body('{}', 'text/json')
    ) == '{}'

    assert (
        JSONFormatter(explicit_json=False,
                      format_options={'json': {'sort_keys': False, 'indent': None, 'format': True}})
        .format_body('{"a": 123}', 'text/json')
    ) == '{"a": 123}'


# Generated at 2022-06-21 14:13:37.946340
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    x = JSONFormatter()
    assert x.enabled == False
    assert x.kwargs['explicit_json'] == False
    opts = x.format_options['json']
    assert opts['format'] == False
    assert opts['indent'] == 3
    assert opts['sort_keys'] == True

# Generated at 2022-06-21 14:13:47.381939
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.format_options['json']['format'] = True
    json_formatter.format_options['json']['indent'] = 4
    json_formatter.format_options['json']['sort_keys'] = False

    json = json_formatter.format_body('{"b": 2, "a": 1}', 'json')
    assert json == '{\n    "b": 2,\n    "a": 1\n}'

    json = json_formatter.format_body('{"a": 1, "b": 2}', 'json')
    assert json == '{\n    "a": 1,\n    "b": 2\n}'

    json_formatter.format_options['json']['sort_keys'] = True

# Generated at 2022-06-21 14:13:49.197086
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    assert f.format_body(body='{ "foo": 1 }', mime='application/json') == '{\n    "foo": 1\n}'

# Generated at 2022-06-21 14:13:59.998502
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import JSONFormatter
    from httpie.config import JSONOptions
    from httpie.context import Environment
    from httpie.plugins import EnvironmentPlugin

    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdout=None,
        stdout_isatty=False,
        stderr=None,
        stderr_isatty=False,
        should_stream=False,
        config=JSONOptions(),
        color=0,
    )

    ep = EnvironmentPlugin(env)
    format_options = ep.get_format_options(key=None)
    jf = JSONFormatter(format_options=format_options)
    assert jf.env.color == 0
    assert jf.enabled == format_options['json']['format']


# Generated at 2022-06-21 14:14:08.717557
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    body = 'hello'
    assert formatter.format_body(body=body, mime='text') == 'hello'

    body = '"hello"'
    assert formatter.format_body(body=body, mime='text') == '\"hello\"'

    body = '"hello'
    assert formatter.format_body(body=body, mime='text') == '"hello'

    body = '{"hello":"world"}'
    assert formatter.format_body(body=body, mime='json') == '{\n    "hello": "world"\n}'

# Generated at 2022-06-21 14:14:20.183446
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    '''
    Test format_body method of class JSONFormatter.
    '''
    class __JSONFormatter(JSONFormatter):
        def __init__(self):
            super().__init__(
                format_options={'json': {
                    'format': True,
                    'indent': 2,
                    'sort_keys': False,
                }}
            )

    test_input = '{"foo":{"bar":1}}'

    result = __JSONFormatter().format_body(test_input, 'application/json')
    assert result == test_input

    test_input = '<html><body>{"foo":{"bar":1}}</body></html>'

    result = __JSONFormatter().format_body(test_input, 'text/html')
    assert result == test_input


# Generated at 2022-06-21 14:14:25.141418
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(sort_keys=True, indent=2)
    assert jf.format_options['json']['format'] == 'on'
    assert jf.format_options['json']['sort_keys'] == True
    assert jf.format_options['json']['indent'] == 2


# Generated at 2022-06-21 14:14:28.967132
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonfmt = JSONFormatter(**{'format_options': {'json': {'format': True, 'indent': 2, 'sort_keys': True}}})
    assert jsonfmt.enabled
    assert jsonfmt.format_options['json']['indent'] == 2

# Generated at 2022-06-21 14:14:43.289172
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Set up the initial object of class JSONFormatter
    jsonFormatter = JSONFormatter()
    # Test case 1: a valid json
    jsonFormatter.format_options['json']['indent'] = 4
    jsonFormatter.format_options['json']['format'] = True
    jsonFormatter.format_options['json']['sort_keys'] = True
    jsonFormatter.kwargs['explicit_json'] = True
    assert jsonFormatter.format_body('{"key":"value"}', 'application/json') == \
           '{\n    "key": "value"\n}'

    # Test case 2: a valid json and an invalid mime type
    assert jsonFormatter.format_body('{"key":"value"}', 'application/turtle') == \
           '{"key":"value"}'

    # Test

# Generated at 2022-06-21 14:14:51.443071
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        output_options={
            'format': 'json',
            'options': {'json': {
                'indent': 2,
                'sort_keys': True,
            }}
        },
        explicit_json=False,
        implicit_json=False
    )

# Generated at 2022-06-21 14:15:01.715231
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test: method format_body in JSONFormatter should return the original
    # body because the MIME type does not contain any of the tokens contained
    # in maybe_json.
    json_formatter = JSONFormatter(format_options=
        {'json': {'format': True, 'indent': 4, 'sort_keys': True}},
        explicit_json=False)
    body = 'some text'
    mime = 'text/html'
    assert json_formatter.format_body(body, mime) == body
    # Test: method format_body in JSONFormatter should return the original
    # body because body cannot be parsed as a JSON object.

# Generated at 2022-06-21 14:15:09.837048
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = {
        'output_options': {'format': 'human'},
        'format_options': {
            'json': {'format': 'pretty', 'sort_keys': False, 
                     'indent': 4, 'compact': False, 'align': False}
        }
    }
    jsonformatter = JSONFormatter(**options)
    assert jsonformatter.enabled == True
    assert jsonformatter.format_options['json']['format'] == 'pretty' 
    assert jsonformatter.format_options['json']['sort_keys'] == False
    assert jsonformatter.format_options['json']['indent'] == 4
    assert jsonformatter.format_options['json']['compact'] == False
    assert jsonformatter.format_options['json']['align'] == False



# Generated at 2022-06-21 14:15:11.821932
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert jsonFormatter.__init__ == (jsonFormatter.__init__.__defaults__ or (
        False, None, False, False, False, False, True, None, None))


# Generated at 2022-06-21 14:15:22.530805
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonf = JSONFormatter(format_options={
        "json": {
            "sort_keys": True,
            "indent": 2,
            "format": True
        }
    })

    body = '{"hello": "world", "number": 42}'
    assert jsonf.format_body(body, "json") == (
        '{\n'
        '  "hello": "world",\n'
        '  "number": 42\n'
        '}'
    )

    # JSON should always be formatted regardless of the explicity flag
    jsonf = JSONFormatter(format_options={
        "json": {
            "sort_keys": True,
            "indent": 2,
            "format": True
        }
    }, explicit_json=False)

# Generated at 2022-06-21 14:15:23.828880
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_var = JSONFormatter()
    assert test_var


# Generated at 2022-06-21 14:15:32.647637
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs['explicit_json'] = False
    formatter.format_options['json']['format'] = True
    formatter.format_options['json']['indent'] = 2
    formatter.format_options['json']['sort_keys'] = True
    body = '[{"name":"test"}]'
    assert formatter.format_body(body, 'json') == '''[
  {
    "name": "test"
  }
]'''
    assert formatter.format_body(body, 'application/json') == '''[
  {
    "name": "test"
  }
]'''

# Generated at 2022-06-21 14:15:40.509218
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formater = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': False
            }
        }
    )
    assert isinstance(json_formater, FormatterPlugin)
    assert json_formater.enabled is True
    assert json_formater.kwargs == {
        'format_options': {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': False
            }
        }
    }


# Generated at 2022-06-21 14:15:50.860928
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    assert f.format_body("this is a json string", 'json') == "\"this is a json string\""
    assert f.format_body("this is a json string", 'text') == "\"this is a json string\""
    assert f.format_body("this is a json string", 'javascript') == "\"this is a json string\""
    assert f.format_body("this is a json string", 'html') == "this is a json string"
    assert f.format_body('{"name":"tom","sex":"male"}', 'json') == "{\"name\": \"tom\", \"sex\": \"male\"}"
    assert f.format_body('{"name":"tom","sex":"male"}', 'javascript') == "{\"name\": \"tom\", \"sex\": \"male\"}"
    assert f.format_body

# Generated at 2022-06-21 14:15:54.126479
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter()
    assert test

# Generated at 2022-06-21 14:15:56.368829
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter({'json': {
        'format': True,
        'indent': 1,
        'sort_keys': True
    }
    })

# Generated at 2022-06-21 14:16:08.268818
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    json_mime = 'application/json'
    javascript_mime = 'application/javascript'
    text_mime = 'text/plain'
    json_body = '{"a": 1, "c": 3, "b": 2}'
    non_json_body = 'not json'

    # Normal operation
    assert formatter.format_body(json_body, json_mime) == json.dumps(
        {"a": 1, "c": 3, "b": 2},
        sort_keys=True,
        ensure_ascii=False,
        indent=2)

    # Non json
    assert formatter.format_body(non_json_body, json_mime) == non_json_body

# Generated at 2022-06-21 14:16:14.794622
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    expected = """{
  "a": "123",
  "b": "12.34",
  "c": "example",
  "d": "true"
}"""

    json_formatter = JSONFormatter(vars(kwargs))
    formated_body = json_formatter.format_body("""{
    "a":"123",
    "b":"12.34",
    "c":"example",
    "d":true
}""", 'application/json')
    assert formated_body == expected

# Generated at 2022-06-21 14:16:25.454672
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def test(json_format_indent, json_format_sort_keys, body, mime,
             expected_body, expected_formatted):
        formatter = JSONFormatter(
            format_options={
                'json': {
                    'format': True,
                    'indent': json_format_indent,
                    'sort_keys': json_format_sort_keys,
                }
            }
        )
        formatted_body = formatter.format_body(body, mime)
        assert formatted_body == expected_body
        assert formatter.enabled == expected_formatted

    # Should format valid JSON.
    test(2, True, '{"a": 1}', 'json', '{\n  "a": 1\n}\n', True)

    # Shouldn't format invalid JSON.

# Generated at 2022-06-21 14:16:27.589584
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json':{'format': False}})
    assert not json_formatte

# Generated at 2022-06-21 14:16:35.003220
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    #
    # Test case 1:
    #   Input: json body, json mime
    #   Output: formatted
    #
    # Create test instance
    formatter = JSONFormatter(vertical_output=False, format_options={
            'json': {'format': True, 'indent': 4, 'sort_keys': True}
        }, explicit_json=True)
    # Set test parameters
    body = '{ "a": [ { "b": 1 }, { "b": 2 }, { "b": 3 } ] }'
    mime = 'application/json'
    # Perform the test
    output = formatter.format_body(body, mime)
    # Verify the results

# Generated at 2022-06-21 14:16:36.818935
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = dict())
    assert formatter.kwargs['explicit_json'] == False

# Generated at 2022-06-21 14:16:42.879141
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(None, "", "", "", "", "")
    test_str = "{\"id\": 1, \"name\": \"A green door\"}"
    json_formatter.format_body(test_str, "json")
    assert test_str == json.dumps(
        obj=json.loads(test_str),
        sort_keys=False,
        ensure_ascii=False,
        indent=None
    )

# Generated at 2022-06-21 14:16:47.361882
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 2
        }
    }

    class MockSettings():
        def __init__(self):
            self.__dict__['format_options'] = options

    formatter = JSONFormatter(MockSettings())

    assert formatter.enabled is True
    assert formatter.format_options == options

# Generated at 2022-06-21 14:16:53.150510
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JS

# Generated at 2022-06-21 14:16:56.367593
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    '''
    Constructor of class JSONFormatter.
    '''
    import pdb
    pdb.set_trace()

    json_formatter = JSONFormatter(json={'format': False})
    assert json_formatter.enabled is False


# Generated at 2022-06-21 14:16:59.515075
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    tester = JSONFormatter(body='{\n  "x": "y"\n}', mime='json',
                           format_options={'json': {'sort_keys': True}})
    assert tester.format_body(tester.body, tester.mime) == '{\n  "x": "y"\n}'

# Generated at 2022-06-21 14:17:03.051934
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    JF = JSONFormatter()

    assert JF.format_body('{"a": 1}', 'application/json') == '{\n  "a": 1\n}'
    assert JF.format_body('{"a": 1}', 'application/javascript') == '{\n  "a": 1\n}'
    assert JF.format_body('{"a": 1}', 'text/javascript') == '{\n  "a": 1\n}'
    assert JF.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-21 14:17:04.303597
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import json
    JSONFormatter()


# Generated at 2022-06-21 14:17:05.670431
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter(format_options={'json': {'format': True}})

# Generated at 2022-06-21 14:17:11.613044
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Just ensure that this data is formatted as JSON (and indented)
    """
    simple_data = '{"first_name": "Bill", "last_name": "Gates"}'
    # Expected output
    expected = '{\n  "first_name": "Bill",\n  "last_name": "Gates"\n}'

    assert expected == JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}}).format_body(simple_data, 'application/json')

# Generated at 2022-06-21 14:17:20.040537
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    class JSONFormatter():

        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.kwargs['explicit_json'] = False
            self.format_options = {
                "json": {
                    "format": True,
                    "indent": 2,
                    "sort_keys": True
                }
            }

        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                    or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass  # Invalid JSON, ignore.

# Generated at 2022-06-21 14:17:31.721263
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Example 1: mime is json, body is a JSON string
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"key_1": "value1", "key_2": "value2"}'
    mime = 'json'
    assert '{\n    "key_1": "value1",\n    "key_2": "value2"\n}' == formatter.format_body(body, mime)
    # Example 2: mime is not json, body is a JSON string
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})

# Generated at 2022-06-21 14:17:33.821209
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formats = {'json': {'format': True, 'sort_keys': False, 'indent': 4}}
    JSONFormatter(format_options=formats, explicit_json=False)

# Generated at 2022-06-21 14:17:53.213648
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with invalid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}},
                                   explicit_json=False)
    assert json_formatter.format_body('{"error": "test', "application/json") == '{"error": "test'

    # Test with valid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}},
                                   explicit_json=True)
    assert json_formatter.format_body('{"error": "test"}', "application/json") == """{
    "error": "test"
}"""

# Generated at 2022-06-21 14:18:01.527329
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    class Foo:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.format_options = {'json': {'format': 'True', 'indent': '4', 'sort_keys': 'True'}}

    class Bar:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    # Test correct initialisation
    json = JSONFormatter(**Foo(**{'explicit_json': True}))
    assert json.enabled == 'True'
    assert json.kwargs == {'explicit_json': True}

    # Test initialisation with incorrect arguments
    try:
        json = JSONFormatter(**Bar(**{'explicit_json': True}))
        assert False
    except:
        assert True

# Unit test

# Generated at 2022-06-21 14:18:07.366074
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()

    # Check that the constructor does not throw an exception
    # if the profile contains a valid dictionary for the
    # 'json' key.
    assert formatter.enabled is False
    assert formatter.format_options == {
        'json': {
            'format': False,
            'indent': None,
            'sort_keys': False
        }
    }


# Generated at 2022-06-21 14:18:11.028990
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    actual = JSONFormatter.format_body('{"a": "b"}'.encode(), 'json')
    expected = '{"a": "b"}'.encode()
    assert actual == expected


# Generated at 2022-06-21 14:18:17.972745
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '''
        {
            "foo": "bar",
            "baz": {
                "a": "b"
            },
            "list": [1, 2, 3]
        }
    '''
    mime = 'json'
    assert json_formatter.format_body(body=body, mime=mime) == '''{
    "baz": {
        "a": "b"
    },
    "foo": "bar",
    "list": [
        1,
        2,
        3
    ]
}'''
    mime = 'text'
    assert json_formatter.format_body(body=body, mime=mime) == body

# Generated at 2022-06-21 14:18:18.992819
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert isinstance(JSONFormatter(), JSONFormatter)

# Generated at 2022-06-21 14:18:20.049748
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  assert(isinstance(JSONFormatter(), JSONFormatter))

# Generated at 2022-06-21 14:18:30.358564
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})

    assert formatter.format_body('{"name":"John"}', 'json') == '{\n  "name": "John"\n}'
    assert formatter.format_body('{"name":"John"}', 'text') == '{\n  "name": "John"\n}'
    assert formatter.format_body('{"name":"John"}', 'javascript') == '{\n  "name": "John"\n}'

    assert formatter.format_body('{"name":"John"}', 'image/jpeg') == '{"name":"John"}'


# Generated at 2022-06-21 14:18:41.867334
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Validate that json is indented, sorted and without unicode escapes.
    class Dummy:
        def __init__(self, **kwargs):
            self.json = {
                'sort_keys': True,
                'indent': 2,
            }
            self.explicit_json = False
            self.kwargs = kwargs
    formatter = JSONFormatter(
        format_options={'json': {'format': True}},
        **Dummy().kwargs,
        explicit_json=Dummy().explicit_json
    )
    valid_json = '{"bar": "baz", "foo": {"key": "value"}}'
    body = '{"foo": {"key": "value"}, "bar": "baz"}'
    mime = 'json'
    formatted_body = formatter.format_

# Generated at 2022-06-21 14:18:53.292370
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie import CONF
    from httpie.utils import grouped_items
    from httpie.utils import get_values_as_dict
    from httpie.config import DEFAULTS
    from httpie.utils import get_grouped_values_as_dict
    import json
    import io
    import sys
    # create object
    json_format = JSONFormatter()
    # check super class
    assert isinstance(json_format, FormatterPlugin)

    # check variables of object
    # enabled
    assert json_format.enabled == CONF.json.format
    # kwargs
    assert json_format.kwargs == get_values_as_dict(CONF)
    assert json_format.kwargs == json_format.kwargs



# Generated at 2022-06-21 14:19:17.402219
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}, kwargs = {'explicit_json': False})
    assert formatter.format_body('{"key": "value"}', 'json') == '''{
    "key": "value"
}
'''
    assert formatter.format_body('{"key": "value"}', 'javascript') == '''{
    "key": "value"
}
'''
    assert formatter.format_body('{"key": "value"}', 'text') == '''{
    "key": "value"
}
'''
    assert formatter.format_body('{"key": "value"}', 'x-www-form-urlencoded') == '''{"key": "value"}'''

# Generated at 2022-06-21 14:19:19.115817
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    assert f.enabled == False
    f.enabled = True
    assert f.enabled == True


# Generated at 2022-06-21 14:19:20.764713
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	f = JSONFormatter()

# Generated at 2022-06-21 14:19:22.358690
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()

    assert json_formatter.enabled == False

# Generated at 2022-06-21 14:19:25.936873
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.kwargs == {'format_options': {}}
    assert formatter.format_options == {}
    assert formatter.format_options['json'] == {}
    assert formatter.enabled is False


# Generated at 2022-06-21 14:19:30.388427
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 2,
        }
    })

    assert formatter.format_body(
        """
{
    "a": "b",
    "c": 4
}
""", 'json') == '''
    {
        "a": "b",
        "c": 4
    }
    '''

# Generated at 2022-06-21 14:19:38.891223
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    plugin = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}},
                           explicit_json=False,
                           pretty=False)

    # Empty string
    assert plugin.format_body(body='', mime='') == ''

    # Non-JSON string
    assert plugin.format_body(body='not json', mime='text/plain') == 'not json'

    # JSON string
    body = '{"key": "value"}'
    formatted_body = '{\n  "key": "value"\n}'
    assert plugin.format_body(body=body, mime='application/json') == formatted_body
    assert plugin.format_body(body=body, mime='text/json') == formatted_body
    assert plugin.format_

# Generated at 2022-06-21 14:19:40.780728
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter is not None


# Generated at 2022-06-21 14:19:43.562247
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter({'sort_keys': 'sort_keys',
                       'indent': 'indent'})
    assert f is not None

# Generated at 2022-06-21 14:19:50.203414
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    formatter = JSONFormatter(**{
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            }
        },
        'explicit_json': True
    })

    result = formatter.format_body('''{
        "a": 1,
        "c": 3,
        "b": 2
    }''', 'json')

    assert result == '''{
  "a": 1,
  "b": 2,
  "c": 3
}'''