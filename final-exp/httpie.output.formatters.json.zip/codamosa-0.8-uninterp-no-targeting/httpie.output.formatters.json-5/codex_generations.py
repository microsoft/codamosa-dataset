

# Generated at 2022-06-21 14:13:32.696957
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonFormatter_instance = JSONFormatter()
    string = '{"foo": "bar"}'

    assert jsonFormatter_instance.format_body(string,'text') == string
    assert jsonFormatter_instance.format_body(string,'javascript') == string
    assert jsonFormatter_instance.format_body(string,'json') == string

    assert jsonFormatter_instance.format_body(string,'text') != '{"foo": "bar"}\n'
    assert jsonFormatter_instance.format_body(string,'javascript') != '{"foo": "bar"}\n'
    assert jsonFormatter_instance.format_body(string,'json') != '{"foo": "bar"}\n'

    assert jsonFormatter_instance.format_body(string,'plain') == string

# Generated at 2022-06-21 14:13:40.722916
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter({
        'json': {
            'format': 'on',
            'indent': 2,
            'sort_keys': 'on'
        }
    })
    assert formatter.enabled == 'on'
    assert formatter.kwargs == {
        'format_options': {
            'json': {
                'format': 'on',
                'indent': 2,
                'sort_keys': 'on'
            }
        },
        'explicit_json': False
    }



# Generated at 2022-06-21 14:13:43.350472
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }
    JSONFormatter(format_options)


# Generated at 2022-06-21 14:13:47.127901
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    options = {
        "json": {
            "format": True,
            "indent": 4,
            "sort_keys": False,
        }
    }
    formatter = JSONFormatter(options)
    assert formatter.enabled == True


# Generated at 2022-06-21 14:13:53.291607
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    input = {'indent': None, 'sort_keys': False, 'format': True}
    json = JSONFormatter(explicit_json=False, format_options={'json': input})
    try:
        assert json.format_options['json'] == input and json.enabled
    except AssertionError:
        return False
    else:
        return True


# Generated at 2022-06-21 14:14:01.492763
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(options={'json': {'format': True,
                                                'indent': 2,
                                                'sort_keys': True}})
    assert formatter.enabled is True
    assert formatter.kwargs == {'options': {'json': {'format': True,
                                                      'indent': 2,
                                                      'sort_keys': True}}}
    assert formatter.format_options == {'json': {'format': True,
                                                 'indent': 2,
                                                 'sort_keys': True}}

# Generated at 2022-06-21 14:14:08.312299
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'application/json'
    body = '{"firstName": "John", "lastName": "Smith", "age": 25}'  # valid
    assert JSONFormatter.format_body(body, mime) == body
    body = '{"firstName:" "John", "lastName": "Smith", "age": 25}'  # invalid
    assert JSONFormatter.format_body(body, mime) != body


if __name__ == '__main__':
    test_JSONFormatter_format_body()

# Generated at 2022-06-21 14:14:15.861227
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class TestJSONFormatter(JSONFormatter):
        def __init__(self):
            self.kwargs = {'explicit_json': False}
            self.format_options = {
                'json': {
                    'format': True,
                    'sort_keys': True,
                    'indent': 4
                }
            }
    formatter = TestJSONFormatter()
    assert formatter.format_body('{"ab": 1}', 'json') == '{\n    "ab": 1\n}'



# Generated at 2022-06-21 14:14:22.231180
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format':True, 'sort_keys':True, 'indent':4}})
    body = '{"testKey":"testValue"}'
    body_formatted = formatter.format_body(body, 'application/json')
    assert body_formatted == '{\n    "testKey": "testValue"\n}'

# Generated at 2022-06-21 14:14:24.388651
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter(**{'explicit_json':False, 'format_options':{'json':{'format':True, 'indent':8, 'sort_keys':True}}})
    assert jsonFormatter.get_format() == 'text'


# Generated at 2022-06-21 14:14:37.183251
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid and invalid JSON object
    j = JSONFormatter(**{'explicit_json': True})
    assert j.format_body('{"a":"a"}', 'json') == '{\n    "a": "a"\n}'
    assert j.format_body('{"a":"a"}', 'javascript') == '{\n    "a": "a"\n}'
    assert j.format_body('{"a":"a"}', 'text') == '{\n    "a": "a"\n}'
    assert j.format_body('{"a":"a"}', 'html') == '{"a":"a"}'
    # Test with invalid JSON object
    assert j.format_body('{"a":"a"', 'json') == '{"a":"a"'

# Generated at 2022-06-21 14:14:41.052367
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert jf.kwargs['explicit_json'] == False
    assert jf.enabled == True

# Generated at 2022-06-21 14:14:46.057248
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    func = JSONFormatter(format_options = {'json': 
        {'format': False, 'indent': 1, 'sort_keys': True}})
    assert func.enabled == False
    assert func.format_options == {'json': {'format': False, 'indent': 1, 
                                    'sort_keys': True}}


# Generated at 2022-06-21 14:14:52.854995
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-21 14:14:57.088922
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_body = '{"foo":"bar"}'
    formatter = JSONFormatter({}, {})
    expected_output = '{\n    "foo": "bar"\n}'
    actual_output = formatter.format_body(test_body, "json")
    assert actual_output == expected_output

# Generated at 2022-06-21 14:15:01.050710
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"foo": "bar"}'
    formatted_body = formatter.format_body(body=body, mime='text/plain')
    assert formatted_body == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-21 14:15:06.539023
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert json_formatter.enabled == True
    assert json_formatter.format_options == {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }


# Generated at 2022-06-21 14:15:11.146278
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(
        format_options = {
            'json' : {
                'format' : True,
                'indent' : 2,
                'sort_keys' : False
            }
        },
        explicit_json = False
    )

    assert jf.format_body("{}", "application/json") == json.dumps(
        obj = {},
        indent = 2,
        ensure_ascii = False,
        sort_keys = False
    )

# Generated at 2022-06-21 14:15:13.317510
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(format_options={'json': {}})
    assert f.format_options['json']['format'] == True


# Generated at 2022-06-21 14:15:21.820448
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(**{
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            }
        },
    })
    assert formatter.enabled is True
    assert formatter.kwargs['explicit_json'] is False
    assert formatter.format_options['json']['format'] is True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] is True