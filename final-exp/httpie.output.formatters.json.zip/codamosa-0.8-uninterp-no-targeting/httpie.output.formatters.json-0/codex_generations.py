

# Generated at 2022-06-21 14:13:36.337988
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = b'{"test_1": 1, "test_2": 2}'
    assert formatter.format_body(body, "json") == body
    body = b'{"test_1": 1, "test_2": 2}'
    assert not formatter.format_body(body, "xml") == body



# Generated at 2022-06-21 14:13:46.252494
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def do_test_JSONFormatter_format_body(body: str, mime: str, expected: str):
        fp = JSONFormatter(format_options={}, kwargs={})
        fp.enabled = True
        result = fp.format_body(body=body, mime=mime)
        print(result)
        assert expected == result

    do_test_JSONFormatter_format_body(
        body='{}', mime='json', expected='{\n    \n}'
    )
    do_test_JSONFormatter_format_body(
        body='{}', mime='javascript', expected='{\n    \n}'
    )

# Generated at 2022-06-21 14:13:48.681500
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter is not None


# Generated at 2022-06-21 14:13:59.429598
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': False, 'indent': '    '}})
    formatter.kwargs['explicit_json'] = False

    # Test valid JSON but without json in its mime type
    body = '{"name": "John", "surname": "Smith"}'
    mime = 'application/octet-stream'
    formatted_body = formatter.format_body(body, mime)
    assert body == formatted_body

    # Test valid JSON but with text in its mime type
    body = '{"name": "John", "surname": "Smith"}'
    mime = 'text/plain'
    formatted_body = formatter.format_body(body, mime)
    assert body == formatted_body

    # Test

# Generated at 2022-06-21 14:14:02.912200
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True,
                                                  'indent': 2,
                                                  'sort_keys': True}})


# Generated at 2022-06-21 14:14:07.450191
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    kwargs = {'--json': None}
    kwargs['json_value'] = False
    # Test json_value=False
    try:
        r = http('--form', 'POST', 'http://httpbin.org/post', 'hello=world',
                 **kwargs)
        assert HTTP_OK in r
    except SystemExit as e:
        assert e.code == ExitStatus.OK
    # Test json_value=True
    try:
        r = http('--json', 'POST', 'http://httpbin.org/post', 'hello=world')
        assert HTTP_OK in r
    except SystemExit as e:
        assert e.code == ExitStatus.OK
    # Test json_value=True, non-JSON Response
   

# Generated at 2022-06-21 14:14:16.115316
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert type(JSONFormatter(format_options={'json': {'format': True}})) == JSONFormatter
    assert JSONFormatter(format_options={'json': {'format': True}}).enabled == True
    assert JSONFormatter(format_options={'json': {'format': False}}).enabled == False
    assert JSONFormatter(format_options={'json': {'format': True}}, explicit_json=True).kwargs['explicit_json'] == True
    assert JSONFormatter(format_options={'json': {'format': True}}).kwargs['explicit_json'] == False



# Generated at 2022-06-21 14:14:24.571265
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert "1" == json_formatter.format_body("1", "json")
    assert "1" == json_formatter.format_body("1", "javascript")
    assert "1" == json_formatter.format_body("1", "text")
    assert '{"key":"value"}' == json_formatter.format_body('{"key":"value"}', "json")
    assert {} == json_formatter.format_body({}, "json")
    assert [] == json_formatter.format_body([], "json")

# Generated at 2022-06-21 14:14:31.791263
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter(
        format_options={'json': {'format': True, 'indent': 3, 'sort_keys': False}},
        explicit_json=False
    )

    call1 = jsonFormatter.format_body('{"A1": "A.1", "A2": "A.2"}', 'json')

    assert call1 == '{\n   "A1": "A.1",\n   "A2": "A.2"\n}'


# Generated at 2022-06-21 14:14:35.537822
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.format_options = {'json': {'format': True}}
    body = '{"b": 1}'
    assert formatter.format_body(body, 'json') == body  # noqa:E501

# Generated at 2022-06-21 14:14:44.033559
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter is not None


# Generated at 2022-06-21 14:14:48.542164
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter()
    assert test.enabled == True
    assert test.kwargs == {}
    assert test.format_options == {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        },
        'headers': {
            'sort': False,
        },
    }



# Generated at 2022-06-21 14:15:00.301331
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.streams import UnsupportedOutputStream
    import json
    import unittest
    from unittest.mock import Mock
    unittest.mock.patch('httpie.output.streams.UnsupportedOutputStream')
    Mock.format_options = {'json':{'format':True,'sort_keys':False,'indent':None}}
    Mock.kwargs = {'explicit_json':False}

    #Test 1: Valid JSON given body and mime
    #Test case
    Mock.body = '{ "name":"John", "age":30, "city":"New York"}'
    Mock.mime = 'text/json'
    #Expected output
    output = json.loads(Mock.body)

# Generated at 2022-06-21 14:15:02.388609
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = FormatterPlugin({'json': {'format': False}})
    assert formatter_plugin.format_options['json']['format'] == False


# Generated at 2022-06-21 14:15:10.353631
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case with invalid JSON
    json_formatter = JSONFormatter()
    body = '{"foo": "bar", "baz":}'

    assert json_formatter.format_body(body, 'application/json') == body

    # Test case with valid JSON as string
    json_formatter = JSONFormatter()
    body = '{"foo": "bar", "baz": "qux"}'

    assert json_formatter.format_body(body, 'application/json') == body

    # Test case with valid JSON as dict
    json_formatter = JSONFormatter()
    body = '''
    {
        "foo": "bar",
        "baz": "qux"
    }
    '''

# Generated at 2022-06-21 14:15:12.722739
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(explicit_json=True).format_body('{"test": "json"}', 'not-json') == '{\n    "test": "json"\n}'



# Generated at 2022-06-21 14:15:20.566027
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from fixtures import FILE_PATH
    with open(FILE_PATH, 'rb') as file:
        env = http(
            '--json',
            '--print=B',
            'POST', HTTP_OK,
            'Content-Type:application/json',
            '@' + FILE_PATH,
        )
        assert env.exit_status == ExitStatus.OK
        assert env.json == json.loads(file.read())



# Generated at 2022-06-21 14:15:26.269227
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = JSONFormatter(explicit_json=True, format_options={
        'json':{
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    })

    assert(fp.explicit_json == True)
    assert(fp.format_options == {
        'json':{
            'format': True,
            'indent': 4,
            'sort_keys': False
        }
    })


# Generated at 2022-06-21 14:15:34.245856
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(kwargs={'explicit_json': False})
    body_json = '{"key": "value"}'
    body_text = 'text'
    assert formatter.format_body(body_json, 'json') == body_json
    assert formatter.format_body(body_text, 'json') == body_text
    assert formatter.format_body(body_json, 'javascript') == body_json
    assert formatter.format_body(body_text, 'javascript') == body_text
    assert formatter.format_body(body_json, 'text') == body_json
    assert formatter.format_body(body_text, 'text') == body_text
    assert formatter.format_body(body_json, 'csv') == body_json

# Generated at 2022-06-21 14:15:38.719332
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': False}}
    formatter = JSONFormatter(format_options, explicit_json=False)
    assert formatter.format_options == format_options
    assert formatter.enabled == True
    assert formatter.kwargs['explicit_json'] == False


# Generated at 2022-06-21 14:15:58.653081
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(kwargs={'explicit_json': True}, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}).format_body(body='{"key": "value"}', mime='application/json') == '{\n    "key": "value"\n}'
    assert JSONFormatter(kwargs={'explicit_json': True}, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}).format_body(body='{"key": "value"}', mime='application/javascript') == '{\n    "key": "value"\n}'

# Generated at 2022-06-21 14:16:00.073099
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled

# Generated at 2022-06-21 14:16:11.932951
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.input import ParseResult
    from httpie.cli import parser
    from httpie.plugins import builtin

    args = parser.parse_args(args=[])
    args.explicit_json = True
    args.pretty = True
    args.json = "indent=4,sort_keys=1"
    args.output_options = ParseResult(args=args)

    body = { "a": [{"c": 1}], "b":2 }
    body_str = json.dumps(obj=body)

    formatter = JSONFormatter(args=args, kwargs=args)
    assert formatter.enabled == args.json

# Generated at 2022-06-21 14:16:15.408575
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert json == json
    assert json.dumps == json.dumps
    assert json.loads == json.loads
    assert obj == obj
    assert sort_keys == sort_keys
    assert ensure_ascii == ensure_ascii
    assert indent == indent


# Generated at 2022-06-21 14:16:26.206893
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # The method format_body should not make any changes if the format
    # option is set to False.
    assert formatter.format_body('{"test": [1, 2]}',
                                 'application/json') == '{"test": [1, 2]}'
    formatter.format_options['json']['format'] = True
    # Should also do nothing if the mime type does not contain 'json'.
    assert formatter.format_body('{"test": [1, 2]}',
                                 'application/petstore+json') == '{"test": [1, 2]}'
    # Should also do nothing if the mime type is not in the list.

# Generated at 2022-06-21 14:16:34.263832
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Initialize an object of class JSONFormatter
    jf = JSONFormatter(
            json = {
                'format': True,
                'indent': 2,
                'sort_keys': True
            },
            explicit_json = False,
            pretty = True,
            colors = {
                'header': 'blue',
                'match': 'red',
                'request_method': 'yellow',
                'request_scheme': 'cyan',
                'request_body': 'magenta_bold',
                'request_headers': 'blue',
                'request_querystring': 'white',
                'response_body': 'green',
                'response_headers': 'cyan',
                'response_timing': 'white'
            }
        )
    # Check the format option
    assert jf.enabled == True
    #

# Generated at 2022-06-21 14:16:44.426889
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    }, **{'explicit_json': True})
    assert f.enabled is True

    f = JSONFormatter(format_options={
        'json': {
            'format': False,
            'sort_keys': True,
            'indent': 4
        }
    }, **{'explicit_json': True})
    assert f.enabled is True

    f = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    }, **{'explicit_json': False})
    assert f.enabled is False

    f = JSON

# Generated at 2022-06-21 14:16:51.742836
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test behavior for default options
    default_json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': False, 'indent': 0}})

    assert default_json_formatter.format_options['json']['format'] == True
    assert default_json_formatter.format_options['json']['sort_keys'] == False
    assert default_json_formatter.format_options['json']['indent'] == 0

    # Test behavior for custom options
    custom_json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})

    assert custom_json_formatter.format_options['json']['format'] == True
    assert custom_json_formatter.format_options

# Generated at 2022-06-21 14:16:57.403563
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test that format_body() of JSONFormatter returns JSON
    """
    dummy_plugin = JSONFormatter(explicit_json=True,
                                 format_options={'json':
                                                 {'format': True,
                                                  'indent': 2,
                                                  'sort_keys': False}})
    assert dummy_plugin.format_body('{"test": "body"}', "application/json") == '{\n  "test": "body"\n}'

# Generated at 2022-06-21 14:17:03.069813
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.core import ExitStatus
    from httpie.core import main
    from httpie.context import Environment
    import os.path
    import tempfile
    import unittest

    class TestJSONFormatter(unittest.TestCase):

        def setUp(self):
            fd, self.path = tempfile.mkstemp()

        def tearDown(self):
            os.remove(self.path)

        def test_format_body_with_no_args_and_no_stdin_on_explicit_json(self):
            env = Environment()
            args = []
            exit_status, _, _ = main(args=args, env=env)
            self.assertEqual(exit_status, ExitStatus.ERROR)


# Generated at 2022-06-21 14:17:18.545704
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Create instance of JSONFormatter
    JSONFormatter().format_body('{"hello": "world"}', 'json')
    # Expect '{"hello": "world"}'
    #print(result)


# Generated at 2022-06-21 14:17:26.999553
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{\"adType\": \"banner\", \"adBannerData\": {\"type\": \"native\"}}"
    jf = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    assert(jf.format_body(body, 'json')) == '{\n  "adBannerData": {\n    "type": "native"\n  },\n  "adType": "banner"\n}'

# Generated at 2022-06-21 14:17:29.708165
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Testing if object is created or not
    try:
        formatter = JSONFormatter()
    # If object is not created we got an error
    except:
        assert False

    assert True


# Generated at 2022-06-21 14:17:37.428620
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from requests import Response
    from httpie import InputResponseWrapper

    fmt = JSONFormatter()
    assert fmt.enabled is True
    assert fmt.format_options['json'] == {
        'sort_keys': True,
        'indent': 4,
        'format': True
    }
    assert fmt.kwargs == {
        'pretty': True,
        'style': None,
        'stream': False,
        'download': False,
        'colors': None,
        'verbose': 0
    }

    data = {'this': 'is', 'some': 'json', 'data': {'with': ['nested', 'data']}}
    r = Response()

# Generated at 2022-06-21 14:17:46.184618
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json=False,
                                   format_options={'json': {'format': False,
                                                            'indent': 4,
                                                            'sort_keys': False}})
    assert json_formatter.format_body("""{ "key": "value", "empty_array": [] }""", "json") == """{
    "empty_array": [],
    "key": "value"
}"""
    assert json_formatter.format_body("""{ "key": "value", "empty_array": [] }""", "html") == """{ "key": "value", "empty_array": [] }"""

# Generated at 2022-06-21 14:17:51.650573
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(
        stdout=True,
        format='json',
        explicit_json=True,
        indent=None,
        sort_keys=False
    )
    assert jf.enabled == True
    assert jf.kwargs['explicit_json'] == True
    assert jf.kwargs['stdout'] == True


# Generated at 2022-06-21 14:17:59.186680
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json' : {'sort_keys': False,
                                                'indent': '    ',
                                                'format': True}},
                            app_struct={'app': {'version': '1.2.3',
                                                'name': 'httpie'}},
                            explicit_json=False,
                            colors=False,
                            verbose=False)
    
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['sort_keys'] == False
    assert json_formatter.format_options['json']['indent'] == '    '
    assert json_formatter.format_options['json']['format'] == True

# Generated at 2022-06-21 14:18:10.125023
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test if method format_body of class JSONFormatter
    """
    json_f = JSONFormatter()
    # case 1: invalid JSON
    result = json_f.format_body(body='{"key":"value"}""', mime='json')
    assert result == '{"key":"value"}""'
    # case 2: valid JSON
    result = json_f.format_body(body='{"key":"value"}', mime='json')
    assert result == '{\n    "key": "value"\n}'
    # case 3: valid JSON and sort_keys is False
    json_f.format_options['json']['sort_keys'] = False
    result = json_f.format_body(body='{"key":"value"}', mime='json')

# Generated at 2022-06-21 14:18:17.997721
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from .api_mock import TestJSONFormatter
    # Test in case 1:
    # input:
    #   formatter = TestJSONFormatter(explicit_json=True,
    #   format_options=TestJSONFormatter.var.FORMAT_OPTIONS)
    #   formatter.kwargs['explicit_json'] = True
    #   mime = 'json'
    #   body = '{"key":"hello"}'
    # expected:
    #   result = '{\n    "key": "hello"\n}'
    formatter = TestJSONFormatter(explicit_json=False, backend='test')
    formatter.kwargs['explicit_json'] = True
    mime = 'json'
    body = '{"key":"hello"}'

# Generated at 2022-06-21 14:18:19.040329
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert 1 == 1

# Generated at 2022-06-21 14:18:55.193286
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        explicit_json=False,
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 3
            }
        }
    )
    # Empty body
    assert formatter.format_body(body='', mime='json') == ''
    # Valid JSON
    assert formatter.format_body(
        body='{"a":"1","b":"2"}',
        mime='application/json'
    ) == '{\n   "a": "1",\n   "b": "2"\n}'
    # Invalid JSON

# Generated at 2022-06-21 14:18:58.089188
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
  # Arrange
  json_format = True
  indent = 4
  sort_keys = True
  format_options = {
    "json": {
      "format": json_format,
      "indent": indent,
      "sort_keys": sort_keys
    }
  }
  # Act
  formatter_plugin = JSONFormatter(format_options=format_options)
  # Assert
  assert formatter_plugin.enabled == json_format
  assert formatter_plugin.format_options == format_options


# Generated at 2022-06-21 14:19:05.276821
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        }
    )
    body = "{\"key1\": \"val1\", \"key2\": \"val2\"}"
    body = json_formatter.format_body(body=body, mime="application/json")
    print(body)
    test_body = """{
    "key1": "val1",
    "key2": "val2"
}"""
    assert body == test_body



# Generated at 2022-06-21 14:19:06.704780
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    var = JSONFormatter()

# Generated at 2022-06-21 14:19:11.587933
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pj = JSONFormatter(format_options={'json': {'format': False, 'sort_keys': None, 'indent': None}})
    assert pj.enabled == False
    pj = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': False, 'indent': 2}})
    assert pj.enabled == True

# Unit tests for function format_body of class JSONFormatter

# Generated at 2022-06-21 14:19:15.411029
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options = {'json': {'format': True, 'sort_keys': False, 'indent': 0}})

    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['sort_keys'] == False
    assert json_formatter.format_options['json']['indent'] == 0

# Unit tests for format_body method of class JSONFormatter

# Generated at 2022-06-21 14:19:25.515668
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py3
    from httpie.output.formatters import JSONFormatter
    from httpie.output.streams import StdoutBytesStream
    from httpie.plugins import FormatterPlugin

    # init a jsonformatter
    jsonformatter = JSONFormatter()

    # test 1: format a dict
    body = b'{"key": "value"}'
    mime = 'json'
    jsonformatter.kwargs['explicit_json'] = True
    stdoutstream = StdoutBytesStream()
    jsonformatter.f_stream = stdoutstream
    assert(jsonformatter.format_body(body, mime) == body if is_py3 else body + b'\r\n')

    # test 2: format a dict with explicit content type

# Generated at 2022-06-21 14:19:26.574330
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    print("jsonFormatter.enabled:", jsonFormatter.enabled)


# Generated at 2022-06-21 14:19:30.623755
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter(**{'explicit_json': False, 'format_options': {'json': {'format': True, 'indent': None, 'sort_keys': True}}})
    assert jsonformatter.enabled == True
    assert jsonformatter.explicit_json == False
    assert jsonformatter.format_options == {'json': {'format': True, 'indent': None, 'sort_keys': True}}


# Generated at 2022-06-21 14:19:31.248203
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert False, "Test not implemented."


# Generated at 2022-06-21 14:19:49.216399
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fopt = {'json': {'format': True}}
    jf = JSONFormatter(format_options=fopt, explicit_json=False, colors=None)
    assert jf.enabled == True


# Generated at 2022-06-21 14:19:59.152220
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(format_options={'json':{'sort_keys':True, 'indent':4}})
    unformatted_body = '''{
        "key1":"val1",
        "key2":"val2",
        "key3":"val3",
        "key4":"val4",
        "key5":"val5"
    }'''
    formatted_body = jf.format_body(unformatted_body, 'json')
    expected_formatted_body = '''{
    "key1": "val1",
    "key2": "val2",
    "key3": "val3",
    "key4": "val4",
    "key5": "val5"
}'''
    assert formatted_body == expected_formatted_body

# Generated at 2022-06-21 14:20:04.147234
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin = JSONFormatter()
    # Test for JSONFormatter class for the given body and mime
    body = '{"k":"v"}'
    mime = 'json'
    assert(formatter_plugin.format_body(body, mime) == body)


# Generated at 2022-06-21 14:20:10.021670
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin = JSONFormatter(format_options={'json': {"format" :True, "sort_keys":True, "indent":2}})
    assert formatter_plugin.format_body("{\"a\": 1, \"b\": 2}", "") == '{\n  "a": 1, \n  "b": 2\n}'
    assert formatter_plugin.format_body("{\"a\": 1, \"b\": 2}", "json") == '{\n  "a": 1, \n  "b": 2\n}'
    assert formatter_plugin.format_body("{\"a\": 1, \"b\": 2}", "javascript") == '{\n  "a": 1, \n  "b": 2\n}'

# Generated at 2022-06-21 14:20:17.259773
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test for valid kwargs
    JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        color_options={
            'colors': {
                'body': {
                    'json': ['green', 'reset']
                }
            }
        }
    )

    # Test for invalid kwargs

# Generated at 2022-06-21 14:20:26.131023
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }
    })
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-21 14:20:34.758035
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    import json
    import httpie
    from httpie.plugins import FormatterPlugin

    class JSONFormatter2(FormatterPlugin):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['json']['format']

        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                    or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass  # Invalid JSON, ignore.

# Generated at 2022-06-21 14:20:42.496014
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # FormatterPlugin class does not have attribute format_options
    # so create an instance and use it to test formatter (JSONFormatter)
    plugin = FormatterPlugin()
    json_formatter = JSONFormatter(format_options = plugin.format_options)
    body = '{ "name": "Jackson", "age": "26" }'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "age": "26",\n    "name": "Jackson"\n}'

# Generated at 2022-06-21 14:20:49.715732
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    kwargs = {
        'json_indent': 4,
        'json_sort_keys': True,
        'json_explicit_end': True,
        'json_explicit_start': True,
        'json_explicit_start': True,
        'json_format': True,
    }
    json_formatter = JSONFormatter(**kwargs)
    assert json_formatter.kwargs == kwargs
    assert json_formatter.enabled == True


# Generated at 2022-06-21 14:20:56.553972
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.cli.argtypes import JSON_SETTINGS
    kwargs = JSON_SETTINGS
    jf = JSONFormatter(json=kwargs)
    assert jf.format_body('{"test": "ok"}', '') == '{\n    "test": "ok"\n}'
    assert jf.format_body('{"test": "ok"}', '') == '{\n    "test": "ok"\n}'
    assert jf.format_body('{"test": "ok"}', 'application/json') == '{\n    "test": "ok"\n}'
    assert jf.format_body('{"test": "ok"}', 'application/javascript') == '{\n    "test": "ok"\n}'

# Generated at 2022-06-21 14:21:26.073821
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-21 14:21:36.794394
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin

    # Call JSONFormatter.format_body() with some text
    format_options = {"json": {"format": False, "indent": 2, "sort_keys": False}}
    formatter_plugin = FormatterPlugin(kwargs={}, format_options=format_options)
    body, mime = '{"test": "text"}', 'application/json'
    output = formatter_plugin.format_body(body=body, mime=mime)
    assert output == '{"test": "text"}'

    # Call JSONFormatter.format_body() with some text
    format_options = {"json": {"format": True, "indent": 2, "sort_keys": False}}
    formatter_plugin = FormatterPlugin(kwargs={}, format_options=format_options)
    body

# Generated at 2022-06-21 14:21:45.709290
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # test if json is formatted correctly
    json_formatter = JSONFormatter()
    formatter_output = json_formatter.format_body('{"Key":"Value"}', 'application/json')
    expected_output = '{\n    "Key": "Value"\n}'
    assert formatter_output == expected_output

    # test if unicode is formatted correctly
    formatter_output = json_formatter.format_body('{"Key":"Значение"}', 'application/json')
    expected_output = '{\n    "Key": "Значение"\n}'
    assert formatter_output == expected_output

    # test if invalid json is formatted correctly

# Generated at 2022-06-21 14:21:52.666696
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    data = '''
    {
      "2": 3,
      "1": "2"
    }
    '''
    expected = '''
    {
      "1": "2",
      "2": 3
    }
    '''
    formatter = JSONFormatter()
    formatter.format_options['json']['indent'] = 2
    formatter.format_options['json']['sort_keys'] = True
    actual = formatter.format_body(data, 'application/json')
    assert actual == expected

# Generated at 2022-06-21 14:21:53.624876
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert isinstance(JSONFormatter(format_options={"json": {"a": "b"}}), JSONFormatter)

# Generated at 2022-06-21 14:21:54.994923
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter()
    assert jf.format_body('{}', 'json') == '{}', 'Bad JSON string'


# Generated at 2022-06-21 14:22:02.878790
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_fmt = JSONFormatter()
    assert json_fmt.format_body('{"a": 1, "b": 2}', 'json') == \
        '{\n    "a": 1,\n    "b": 2\n}'
    assert json_fmt.format_body('{"a": 1, "b": 2}', 'text') == \
        '{\n    "a": 1,\n    "b": 2\n}'
    assert json_fmt.format_body('{"a": 1, "b": 2}', 'html') == \
        '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-21 14:22:05.682174
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatting = JSONFormatter(**{'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatting.enabled
    assert formatting.format_options['json']['format']

# Generated at 2022-06-21 14:22:08.243198
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.format_options == {'json': {'format': True, 'indent': 4, 'sort_keys': True}}



# Generated at 2022-06-21 14:22:14.359625
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test the setting of indent = 2 and sort_keys = False of format_options
    #  where JSON body is valid, is_json is False, and mime is 'json'
    class Dummy_JSONFormatter_format_body:
        """ Dummy object for unit test."""
        format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': False}}
        explicit_json = False
        kwargs = {'explicit_json': False}
        def __init__(self, **kwargs):
            pass

    # Test case where JSON body is valid and is_json is False and mime is 'json'
    body = '{"a": 1, "b": 2, "c": 3}'
    mime = 'json'

# Generated at 2022-06-21 14:23:13.537165
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass

# Generated at 2022-06-21 14:23:16.054279
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    #(disable_colors = True)
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format']
    assert formatter.kwargs['explicit_json']

# Generated at 2022-06-21 14:23:17.910507
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from . import httpie  # noqa
    print(httpie.JSONFormatter.format_body({"a": "b"}, "text"))

# Generated at 2022-06-21 14:23:20.115177
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={"json": {"format": True}})
    assert formatter.enabled
    assert formatter.kwargs == {}



# Generated at 2022-06-21 14:23:21.086049
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert 1


# Generated at 2022-06-21 14:23:26.222134
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    json_format = JSONFormatter()
    body = '{"id": 5, "name": "foo"}'
    mime = 'json'

    assert json_format.format_body(body, mime) == '{\n    "id": 5,\n    "name": "foo"\n}'