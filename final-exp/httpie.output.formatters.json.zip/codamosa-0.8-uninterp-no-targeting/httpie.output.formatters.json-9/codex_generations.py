

# Generated at 2022-06-21 14:13:40.992342
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    #test_body_json - returns the body in json format
    body_json = '{"test_dict": "test_value"}'
    test_JSONFormatter = JSONFormatter(body=body_json, explicit_json=False)
    expected_result = '{\n    "test_dict": "test_value"\n}'
    assert expected_result == test_JSONFormatter.format_body(body_json, 'json')

    # test_body_json_explicit - calls json.dumps and returns the
    # JSON formatted body
    body_json = '{"test_dict": "test_value"}'
    test_JSONFormatter = JSONFormatter(body=body_json, explicit_json=True)
    expected_result = '{\n    "test_dict": "test_value"\n}'

# Generated at 2022-06-21 14:13:41.953876
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass



# Generated at 2022-06-21 14:13:48.275892
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': False, 'indent': 0}})
    assert jsonformatter.enabled == True
    assert jsonformatter.kwargs['explicit_json'] == False
    assert jsonformatter.format_options['json']['format'] == True
    assert jsonformatter.format_options['json']['sort_keys'] == False
    assert jsonformatter.format_options['json']['indent'] == 0


# Generated at 2022-06-21 14:13:49.659863
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    assert f is not None


# Generated at 2022-06-21 14:13:56.320093
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    headers = {
        'content-type': 'application/json',
        'content-length': '19'
    }
    json_data = {
        'test': '123'
    }
    body = '{"test": "123"}'
    json_formatter = JSONFormatter(headers=headers, body=body, json_data=json_data, explicit_json=True)
    assert json_formatter.headers == headers
    assert json_formatter.body == body
    assert json_formatter.kwargs == {'headers': headers, 'body': body, 'json_data': json_data, 'explicit_json': True}
    assert json_formatter.format_options == {'json': {'format': True, 'sort_keys': True, 'indent': 2}}


# Generated at 2022-06-21 14:14:07.300986
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Scenario 1: body is json formatted
    body = '{"test": 123}'
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    result = formatter.format_body(body, 'application/json')
    assert result == '{\n    "test": 123\n}'

    # Scenario 2: body is not formatted
    body = '{"test": 123}'
    formatter = JSONFormatter(format_options={'json': {'format': False, 'indent': 4, 'sort_keys': True}})
    result = formatter.format_body(body, 'application/json')
    assert result == '{"test": 123}'

    # Scenario 3: body is not json object

# Generated at 2022-06-21 14:14:08.996826
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter is not None

# Generated at 2022-06-21 14:14:20.425177
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import os
    import tempfile
    import json
    import shutil
    from httpie.config import Config
    from httpie.plugins import FormatterPlugin

    temp_folder = tempfile.mkdtemp()
    config_file = os.path.join(temp_folder, 'config.json')
    json_string = '{"format": {"json": {"sort_keys": true, "indent": 4}}}'
    config_json = json.loads(json_string)
    with open(config_file, "w") as output:
        json.dump(config_json, output)
    config = Config(config_dir=temp_folder)
    formatter = JSONFormatter(format_options=config.format_options, explicit_json=True)
    assert formatter.enabled
    assert formatter.kwargs["explicit_json"]

# Generated at 2022-06-21 14:14:26.293366
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.context import Environment
    from httpie.plugins import PluginManager
    env = Environment('./plugins.json')
    plugin_manager = PluginManager(env)
    formatter = JSONFormatter(format_options=env.config,
                              plugin_manager=plugin_manager)
    assert formatter.enabled == True
    assert formatter.format_options == env.config
    assert formatter.plugin_manager == plugin_manager


# Generated at 2022-06-21 14:14:36.720115
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    body = '[{"a": "123"}]'
    mime = 'application/json'
    print_body = True
    indent = 2
    sort_keys = False
    explicit_json = True
    _format_plugin_options = {'json': {'format': True, 'indent': indent, 'sort_keys': sort_keys}}
    formatter = JSONFormatter(_format_plugin_options)
    formatter.kwargs = {'explicit_json': explicit_json}
    expected = '[\n  {\n    "a": "123"\n  }\n]'

    # Act
    result = formatter.format_body(body, mime)

    # Assert
    assert result == expected

# Generated at 2022-06-21 14:14:45.621100
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
        from httpie.context import Environment
        from httpie.plugins import PluginManager
        import httpie.plugins.builtin

        environment = Environment(plugins=PluginManager())
        plugin = httpie.plugins.builtin.JSONFormatter(environment)
        result = plugin.format_body(
            body='{"foo": "bar"}',
            mime='application/json'
        )
        assert result == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-21 14:14:46.150544
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass


# Generated at 2022-06-21 14:14:49.636284
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.kwargs == {}
    assert formatter.color_options == {}
    assert formatter.format_options == {'json': {'format': False, 'indent': None, 'sort_keys': False}}
    assert formatter.enabled == False


# Generated at 2022-06-21 14:15:00.395103
# Unit test for constructor of class JSONFormatter

# Generated at 2022-06-21 14:15:08.869687
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    FormatterPlugin.__plugins__ = {}
    from httpie.plugins import registry
    registry.register(JSONFormatter)
    
    def test_format_body(self, body: str, mime: str) -> str:
        maybe_json = [
            'json',
            'javascript',
            'text',
        ]
        if (self.kwargs['explicit_json']
                or any(token in mime for token in maybe_json)):
            try:
                obj = json.loads(body)
            except ValueError:
                pass  # Invalid JSON, ignore.

# Generated at 2022-06-21 14:15:11.049832
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=True)
    assert formatter.format_body('{''"name" : "Trevor"''}', 'json') == '{\n    "name": "Trevor"\n}\n'

# Generated at 2022-06-21 14:15:15.887842
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 
                                            'sort_keys': False, 
                                            'indent': 2}})
    body = "Hello world"
    mime = "javascript"
    result = formatter.format_body(body, mime)
    assert result == "Hello world"

# Generated at 2022-06-21 14:15:16.448827
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-21 14:15:18.204446
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == True

# Generated at 2022-06-21 14:15:28.120535
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Given
    json_formater = JSONFormatter(formatters={}, format_options={}, colors={},
                                  explicit_json=False)
    json_formater.format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': True}}
    # When
    # Formatting body
    body_formated = json_formater.format_body("""{
        "id": 1,
        "name": "A green door",
        "price": 12.50,
        "tags": ["home", "green"]
    }""", 'application/json')
    # Then

# Generated at 2022-06-21 14:15:44.138197
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Initialize an instance of JSONFormatter
    # with format_options as follows:
    #  - json (dictionary):
    #     - sort_keys (boolean): False
    #     - indent (integer): 4
    #          - format (boolean): False
    json_formatter = JSONFormatter(format_options={'json': {'sort_keys': False, 'indent': 4, 'format': False}})
    # JSONFormatter.format_body is False
    assert json_formatter.enabled == False
    
    # Call method format_body with body=
    # '{"key": "value"}'
    # and mime='application/json'
    # Assert method format_body returns the string
    # '{"key": "value"}'

# Generated at 2022-06-21 14:15:48.575408
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_json_formatter = JSONFormatter('',
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        }
    )
    assert test_json_formatter.enabled == True


# Generated at 2022-06-21 14:15:54.768971
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a":1}'
    response = formatter.format_body(body=body, mime='json')
    assert response == (
        '{\n'
        '    "a": 1\n'
        '}'
    )
    body = '"string", 1, true'
    response = formatter.format_body(body=body, mime='json')
    assert response == (
        '"string",\n'
        '1,\n'
        'true'
    )

# Generated at 2022-06-21 14:15:59.755179
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"name":"httpie"}'
    mime = 'application/json'
    assert JSONFormatter(**{'explicit_json': False, 'format_options': {'json':{'format': True, 'indent': 4, 'sort_keys': True}}}).format_body(body, mime) == '{\n    "name": "httpie"\n}'

# Generated at 2022-06-21 14:16:11.693614
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    obj = {
        "foo": {"bar": "baz"},
        "qux": "qux"
    }
    body = json.dumps(obj)
    formatted_body = formatter.format_body(body, "application/json")
    obj_formatted = json.loads(formatted_body)
    assert obj_formatted == obj
    assert len(formatted_body.splitlines()) == 4

    formatted_body = formatter.format_body(body, "text/javascript")
    obj_formatted = json.loads(formatted_body)
    assert obj_formatted == obj
    assert len(formatted_body.splitlines()) == 4

    formatted_body = formatter.format_body(body, "text/plain")
    obj_formatted = json.loads

# Generated at 2022-06-21 14:16:14.537829
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'options': {'json': {'format': True}}})
    assert JSONFormatter(format_options={'options': {'json': {'format': True}}}, kwargs={})

# Generated at 2022-06-21 14:16:17.032145
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(json = {'format': True, 'sort_keys': True, 'indent': 2})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2


# Generated at 2022-06-21 14:16:27.187350
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert test_formatter.enabled == True
    assert test_formatter.__dict__ == {'enabled': True, 'format_options': {'json': {'format': True}}, 'kwargs': {}}
    test_formatter.__init__(format_options={'json': {'format': False}})
    assert test_formatter.enabled == False
    assert test_formatter.__dict__ == {'enabled': False, 'format_options': {'json': {'format': False}}, 'kwargs': {}}
    test_formatter.__init__(format_options={'json': {'sort_keys': False, 'indent': None, 'format': True}})

# Generated at 2022-06-21 14:16:29.334678
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(**{'format_options': {'json': {'format': True, 'sort_keys': True, 'indent': 4}}}).format_body('{ "key": 3 }', 'text') == '{\n    "key": 3\n}'

# Generated at 2022-06-21 14:16:34.624769
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fmt = JSONFormatter()
    assert fmt.format_body('[{"a": 1}]', 'json') == '[\n    {\n        "a": 1\n    }\n]'
    assert fmt.format_body('{"a": "1"}', 'json') == '{\n    "a": "1"\n}'
    assert fmt.format_body('[{"a": 1}, {"b": 2}]', 'json') == '[\n    {\n        "a": 1\n    },\n    {\n        "b": 2\n    }\n]'