

# Generated at 2022-06-21 14:13:32.401020
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    instance = JSONFormatter()
    assert instance.format_body() == ''
    assert not instance.format_body('{}', 'json') == ''
    assert not instance.format_body('{"a": "b"}', 'json') == ''
    assert not instance.format_body('{"a": "b"}', 'javascript') == ''
    assert not instance.format_body('{"a": "b"}', 'text') == ''
    assert not instance.format_body('{"a": "b"}', 'application/json') == ''



# Generated at 2022-06-21 14:13:44.141779
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # create a JSONFormatter object to test its format_body method
    jsonFormatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4
            },
            'colors': {
                'header': False
            }
        }
    )

    # Test case 1:
    # Body with valid json data
    # Test if the body is correctly formatted
    jsonData = jsonFormatter.format_body(
        body='{"age": 100, "name": "John Doe", "occupation": "gardener"}',
        mime='json'
    )

# Generated at 2022-06-21 14:13:49.462929
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}},
        explicit_json=False
    )
    assert json_formatter.enabled == True
    assert json_formatter.kwargs['explicit_json'] == False


# Generated at 2022-06-21 14:13:51.041679
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True}})

# Generated at 2022-06-21 14:14:01.178664
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(**{'verbose': False, 'headers': True, 'body': True, 'style': 'colors', 'stream': False, 'hint': False, 'json_formatter': None, 'explicit_json': False})
    assert json_formatter.format_options['json']['format'] == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == False
    assert json_formatter.enabled == True
    assert json_formatter.kwargs['explicit_json'] == False

# Unit tests for format_body method of class JSONFormatter

# Generated at 2022-06-21 14:14:11.633900
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    # test formatting
    assert f.format_body('{"a": 10, "b": 2}', 'json') == '{\n    "a": 10,\n    "b": 2\n}'
    # test sort
    assert f.format_body('{"b": 2, "a": 10}', 'json') == '{\n    "a": 10,\n    "b": 2\n}'
    # test non-json
    assert f.format_body('{fake: json}', 'json') == '{fake: json}'
    # test unicode
    assert f.format_body('{"a": "❤️"}', 'json') == '{\n    "a": "❤️"\n}'

# Generated at 2022-06-21 14:14:13.909315
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()    # If this does not give an exception, constructor is fine


# Generated at 2022-06-21 14:14:17.309515
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()
    assert formatter_plugin.enabled


if __name__ == '__main__':
    formatter_plugin = JSONFormatter()
    assert formatter_plugin.enabled

# Generated at 2022-06-21 14:14:24.397759
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_ = JSONFormatter(format_options={'json': {'indent': 2, 'sort_keys': True}})
    with open("httpie/plugins/json/test_data.json", "r", encoding='utf-8') as json_file:
        data = json_file.read()
    assert json_.format_body(data, "json") == json.dumps(json.loads(data), sort_keys=True, indent=2, ensure_ascii=False)

# Generated at 2022-06-21 14:14:33.320169
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    d = {
        "json": {
            "format": True,
            "indent": 0,
            "sort_keys": False
        }
    }
    k = {}
    k["format_options"] = d
    k["explicit_json"] = True
    t = JSONFormatter(**k)
    assert t.enabled == True
    assert t.explicit_json == True
    assert t.format_options["json"]["format"] == True
    assert t.format_options["json"]["sort_keys"] == False
    assert t.format_options["json"]["indent"] == 0


# Generated at 2022-06-21 14:14:42.726892
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    testJSONFormatter = JSONFormatter()
    assert testJSONFormatter.enabled == False
    assert testJSONFormatter.kwargs == {}
    assert testJSONFormatter.format_options['json']['format'] == False


# Generated at 2022-06-21 14:14:46.229561
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options == {'json': {'indent': 4,
                                                 'sort_keys': True,
                                                 'format': True}}
    assert formatter.enabled

# Generated at 2022-06-21 14:14:48.225332
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == True


# Generated at 2022-06-21 14:14:59.730460
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for a json with indent = 2
    # (see httpie/plugins/builtin.py:JSONFormatter)
    json_formatter = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            },
            'colors': False,
            'stream': True,
        },
        explicit_json = False,
    )
    body = '{"key":"value"}'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{\n  "key": "value"\n}'

    # Test for valid json with indent = 5
    body = '{"key":"value"}'
    mime = 'application/json'
    json_formatter

# Generated at 2022-06-21 14:15:03.291285
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin = JSONFormatter()
    actual_output = formatter_plugin.format_body("{'username': 'demo'}", 'json')
    expected_output = '{"username": "demo"}'
    assert actual_output == expected_output


# Generated at 2022-06-21 14:15:10.731529
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter(kwargs={}, format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert j.format_options == {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    j = JSONFormatter(kwargs={'explicit_json': True}, format_options={'json': {'format': True, 'sort_keys': False, 'indent': 2}})
    assert j.kwargs == {'explicit_json': True}
    assert j.format_options == {'json': {'format': True, 'sort_keys': False, 'indent': 2}}
    assert j.enabled

# test for the format_body method of the class JSONFormatter

# Generated at 2022-06-21 14:15:12.532246
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert json_formatter is not None

# Generated at 2022-06-21 14:15:23.334827
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py2
    if is_py2:
        from httpie.compat import str
    u_str = str if is_py2 else lambda v: v
    class FakeFormatterPlugin:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.enabled = True
            self.format_options = {
                'json': {
                    'format': True,
                    'indent': 4,
                    'sort_keys': True,
                },
            }
    pl = FakeFormatterPlugin()
    json_formatter = JSONFormatter(**pl.kwargs)
    # test raw json data
    raw_str = u_str('{"a":1,"b":2}')

# Generated at 2022-06-21 14:15:30.133932
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Initialize class
    formater = JSONFormatter(format_options={
        'json': {
            'format': False
        }
    })
    # Test if the constructor works when no param is passed
    assert formater.format_options['json']['format'] == False
    # Test if the constructor works when the param is passed
    assert JSONFormatter(format_options={
        'json': {
            'format': True
        }
    }).format_options['json']['format'] == True

# Test for method format_body of class JSONFormatter

# Generated at 2022-06-21 14:15:32.154100
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(
        {'json': {'format': True, 'indent': 2, 'sort_keys': True}},
        {'explicit_json': False}
    )

# Generated at 2022-06-21 14:15:54.269675
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Create a JSONFormatter object
    json_formatter = JSONFormatter({'json': {'format': True, 'indent': 2, 'sort_keys': True}})

    # Test with JSON string that is already pretty-printed
    test_body = '''
    {
        "items": [
            {
                "id": 1,
                "name": "Test object 1"
            },
            {
                "id": 2,
                "name": "Test object 2"
            }
        ],
        "next_page": "http://localhost:5000/test/objects/?page=2",
        "prev_page": null
    }
    '''
    assert json_formatter.format_body(test_body, 'json') == test_body

    # Test with JSON string that is not pretty-printed
    test_body

# Generated at 2022-06-21 14:16:03.296138
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	formatter = JSONFormatter(format_options={'json': {'format': 'json', 'sort_keys': 'sort_keys', 'indent': 'indent'}}, kwargs={})
	assert formatter.format_options['json']['format'] == 'json', 'json formatter constructor failure'
	assert formatter.format_options['json']['indent'] == 'indent', 'json formatter constructor failure'
	assert formatter.format_options['json']['sort_keys'] == 'sort_keys', 'json formatter constructor failure'
	assert formatter.kwargs.keys() == {}, 'json formatter constructor failure'


# Generated at 2022-06-21 14:16:08.861977
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(
        format_options={
            'json':{
                'format': True,
                'sort_keys': True,
                'indent': 4
            }
        },
        explicit_json=True,
        body='{"a":1}',
        mime='application/json')


# Generated at 2022-06-21 14:16:16.940384
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"aaa" : "bbb"}', 'application/json') == '{\n' \
                                                                           '    "aaa": ' \
                                                                           '"bbb"\n' \
                                                                           '}'

    assert formatter.format_body('{"aaa" : "bbb"}', 'text') == '{\n' \
                                                               '    "aaa": ' \
                                                               '"bbb"\n' \
                                                               '}'

    assert formatter.format_body('{"aaa" : "bbb"}', 'bbb') == '{"aaa" : "bbb"}'

# Generated at 2022-06-21 14:16:27.042158
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Unit test_JSONFormatter_format_body

    # Test content
    content = {"name": "paul", "age": 19}
    json_content = json.dumps(content)
    text_content = json.dumps(content).replace("\"", "'")

    # Test parameters
    mime = "application/json"
    explicit_json = False
    format_options = {
        'json': {
            'format': True,
            'sort_keys': False,
            'indent': 4,
        }
    }
    kwargs = {
        'explicit_json': explicit_json,
        'format_options': format_options
    }

    # Test
    json_formatter = JSONFormatter(**kwargs)

# Generated at 2022-06-21 14:16:30.372800
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins.builtin import plugin_manager
    from httpie.plugins.builtin import JSONFormatter
    plugin_manager.register(JSONFormatter)
    assert isinstance(plugin_manager.get('JSONFormatter'), JSONFormatter)


# Generated at 2022-06-21 14:16:34.018445
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test_JSONFormatter = JSONFormatter()
    answer = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    assert test_JSONFormatter.__dict__ == answer


# Generated at 2022-06-21 14:16:43.787703
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.core import parser_args
    from httpie.core import main as httpie
    
    args = parser_args(['--output-format=json', '--json=format'])
    assert JSONFormatter(**vars(args)).enabled == True
    
    args = parser_args(['--output-format=json', '--json=none'])
    assert JSONFormatter(**vars(args)).enabled == False
    
    assert JSONFormatter(**vars(args)).format_options == args.json
    
    args = parser_args(['--output-format=json', '--json={"format":true, "indent":0, "sort_keys":true}'])
    assert JSONFormatter(**vars(args)).enabled == True
    assert JSONFormatter(**vars(args)).format_

# Generated at 2022-06-21 14:16:51.211445
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options = {
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': None,
            }
        },
        explicit_json = False,
    )

    # Try to format JSON
    # body = '{ "a": 1, "b": 2, "c": 3, "d": 4, "e": 5 }'
    body = '{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}'
    mime = 'json'

# Generated at 2022-06-21 14:16:55.558312
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    frm = JSONFormatter()
    assert frm.kwargs == {'explicit_json': False}
    assert frm.format_options == {'json': {'format': True,
                                           'indent': 4,
                                           'sort_keys': False}}
    assert frm.enabled == True
