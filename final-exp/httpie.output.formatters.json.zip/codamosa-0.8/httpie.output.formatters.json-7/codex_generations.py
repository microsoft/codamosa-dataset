

# Generated at 2022-06-11 23:48:16.084583
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with a valid json
    body = '{"a": 2, "b": "ok"}'
    assert JSONFormatter().format_body(body=body, mime='json') == body

    # Test with two valid jsons
    body = '{"a": 2, "b": "ok"}{"a": 2, "b": "ok"}'
    assert JSONFormatter().format_body(body=body, mime='json') == body

    # Test with an invalid json
    body = '{a: 2, "b": "ok"}'
    assert JSONFormatter().format_body(body=body, mime='json') == body

    # Test with a json and an invalid json
    body = '{"a": 2, "b": "ok"}{a: 2, "b": "ok"}'
    assert JSONFormatter().format

# Generated at 2022-06-11 23:48:25.225167
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.core import main
    from httpie.downloads import Downloader
    import pytest
    downloader = Downloader()
    #first test, when format_options['json']['format'] = True, and test the json-indent-level is 2, should be failed
    downloader.format_options['json']['format'] = True
    downloader.format_options['json']['indent'] = 2
    args = [
        '--json-pretty=all',
        'http://httpbin.org/get'
    ]
    env = dict()
    r = main(args=args, env=env, downloader=downloader)
    assert r.exit_status == 0
    assert r.format == 'json'
    assert r.output_file.write.call_count == 1

# Generated at 2022-06-11 23:48:31.960586
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert(json_formatter.format_body('"foo": "bar"', "json") == '"foo": "bar"')
    assert(json_formatter.format_body('{"foo": "bar", "baz": "quux"}',
                                   "json") == '{\n    "baz": "quux",\n    "foo": "bar"\n}')
    assert(json_formatter.format_body('{"foo": "bar"}', "text") == '{\n    "foo": "bar"\n}')

# Generated at 2022-06-11 23:48:41.479865
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

# Generated at 2022-06-11 23:48:46.245687
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    plugin = JSONFormatter(format_options={
        'json': {
            'indent': 1,
            'sort_keys': False,
            'format': True
        }
    }, explicit_json=True)
    body = """{\"a\": {\"b\": {\"c\": 1}}}"""
    expected = """{\n "a": {\n  "b": {\n   "c": 1\n  }\n }\n}"""
    assert plugin.format_body(body, 'application/json') == expected

# Generated at 2022-06-11 23:48:55.777999
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    # use JSON object as body, format it.
    body = '{"key": "value"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # use JSON object as body, format it by mime 'json'.
    body = '{"key": "value"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # use JSON object as body, format it without indent.
    body = '{"key": "value"}'
    mime = 'json'
    json_formatter.format_options['json']['indent'] = None
   

# Generated at 2022-06-11 23:49:04.386722
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py2, is_py3
    from httpie.formatter import get_valid_json
    
    json_formatter = JSONFormatter()
    body = '{"a":"value_a"}'
    mime = 'json'
    expected_result = get_valid_json(body)
    result = json_formatter.format_body(body, mime)
    assert result == expected_result
    if is_py2:
        assert isinstance(result, unicode)
    elif is_py3:
        assert isinstance(result, str)

# Generated at 2022-06-11 23:49:13.154450
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json':
                                       {'indent' : 2,
                                        'format' : True,
                                        'ensure_ascii' : False,
                                        'sort_keys' : False}
                                       })
    # Test 1
    #   Input
    body = '{ "foo": "bar" }'
    mime = 'application/json'
    #   Expected output
    expected_body = '{\n' \
                    '  "foo": "bar"\n' \
                    '}'
    #   Unit test
    assert formatter.format_body(body, mime) == expected_body
    # Test 2
    #   Input
    body = '{ "foo": "bar" }'
    mime = 'application/javascript'
    #   Ex

# Generated at 2022-06-11 23:49:18.342326
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    data = '''{
    "sort_keys": true,
    "indent": 2
}'''
    fp = JSONFormatter(format_options={'json': json.loads(data)})
    assert fp.format_body(data, 'json') == '''{
  "indent": 2,
  "sort_keys": true
}'''


# Generated at 2022-06-11 23:49:28.171697
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(None, explicit_json=False, json={'format': True, 'indent': 0, 'sort_keys': False})
    assert json_formatter.format_body("""{
    "foo": "bar"
}""",
        'application/json') == """{
    "foo": "bar"
}"""
    assert json_formatter.format_body("""{"foo": "bar"}""",
        'application/json') == """{
  "foo": "bar"
}"""
    assert json_formatter.format_body("""{"foo": "bar"}""",
        'application/javascript') == """{
  "foo": "bar"
}"""

# Generated at 2022-06-11 23:49:41.004782
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fake_kwargs = {
        'indent': 2,
        'sort_keys': True,
        'explicit_json': False,
        'format': True
    }

    fake_mime = 'json'
    fake_body = '''{"a": 1, "b": 2}'''
    expected_body = '''{
  "a": 1,
  "b": 2
}'''
    tf = JSONFormatter(format_options=fake_kwargs)
    assert tf.format_body(fake_body, fake_mime) == expected_body

# Generated at 2022-06-11 23:49:45.465810
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={"json": {"format": True, "indent": 2, "sort_keys": True}})
    expected = '{\n  "test": "test"\n}'
    result = json_formatter.format_body(body='{"test": "test"}', mime='json')
    assert result == expected

# Generated at 2022-06-11 23:49:54.968043
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:50:05.333135
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:50:14.548615
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fp = JSONFormatter()
    assert fp.format_body('{"foo": "bar"}', 'text/json') == '{\n    "foo": "bar"\n}'
    assert fp.format_body('{"foo": "bar"}', 'text/javascript') == '{\n    "foo": "bar"\n}'
    assert fp.format_body('{"foo": "bar"}', 'text/plain') == '{\n    "foo": "bar"\n}'
    assert fp.format_body('{"foo": "bar"}', 'text/html') == '{"foo": "bar"}'
    assert fp.format_body('{"foo": "bar"}', 'non/json') == '{"foo": "bar"}'

# Generated at 2022-06-11 23:50:25.001236
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import PluginManager
    pm = PluginManager()
    plugin = pm.instantiate_plugin('json', JSONFormatter)
    assert plugin.format_body('{"foo": "bar"}', mime='application/json') == '{\n    "foo": "bar"\n}'
    assert plugin.format_body('{"foo": "bar"}', mime='application/foo; bar=baz') == '{\n    "foo": "bar"\n}'
    assert plugin.format_body('{"foo": "bar"}', mime='application/json; foo=bar') == '{\n    "foo": "bar"\n}'
    assert plugin.format_body('{"foo": "bar"}', mime='javascript') == '{\n    "foo": "bar"\n}'
    assert plugin.format

# Generated at 2022-06-11 23:50:29.037712
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter(format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert jsonFormatter.enabled
    assert jsonFormatter.kwargs == {'explicit_json': False}


# Generated at 2022-06-11 23:50:32.021536
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSO
    # assert f.name == 'JSONFormatter'
    # assert f.enabled == False
    # assert f.kwargs == {}
    # assert f.fmt_options == {}
    # assert f.try_format is False

# Generated at 2022-06-11 23:50:37.077766
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"foo": 1}', 'application/text') == '{"foo": 1}'
    assert json_formatter.format_body('{"foo": 1}', 'json') == '{\n    "foo": 1\n}'

# Generated at 2022-06-11 23:50:38.379435
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert(JSONFormatter() is not None)

# Generated at 2022-06-11 23:50:51.936060
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest
    from httpie.output.formatters import JSONFormatter
    with pytest.raises(TypeError):
        JSONFormatter.format_body(body = 'Test text')

# Generated at 2022-06-11 23:50:54.051593
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a":1,"b":2}'
    formatter = JSONFormatter()

    result = json.loads(formatter.format_body(body, '123'))
    assert result.get('a') == 1
    assert result.get('b') == 2

# Generated at 2022-06-11 23:50:56.124556
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(
        '{"a": 1}',
        'application/json'
    ) == '{\n    "a": 1\n}'

# Generated at 2022-06-11 23:51:05.218216
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    '''
    if the response is a json format, pretty print it.
    '''
    json_dict = {
        'foo': 'bar',
        'baz': 'buzz'
    }
    json_str = json.dumps(json_dict)
    json_obj = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 2,
        }
    }
    json_fmtr = JSONFormatter(format_options=json_obj, explicit_json=False)
    assert json_fmtr.format_body(json_str, 'json/text') == '''\
{
  "baz": "buzz",
  "foo": "bar"
}'''

# Generated at 2022-06-11 23:51:16.322259
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import JSONOptions
    from httpie.compat import unicode
    from httpie.compat import is_py2

    t = JSONFormatter(format_options=JSONOptions(indent=2, sort_keys=True, format=True))
    mime_json = 'application/json'
    mime_text_json = 'text/json'
    mime_text_html = 'text/html'
    body_json = unicode('{"a": 1, "b": 2}')
    body_text = unicode('{"a": 1, "b": 2}')

    #Explicit JSON
    assert t.format_body(body_json, mime_text_html) == body_json
    assert t.format_body(body_text, mime_text_html) == body_text
   

# Generated at 2022-06-11 23:51:26.274234
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Create an instance of JsonFormatterPlugin
    json_formatter = JSONFormatter()

    # First test: body is not a valid json string
    invalid_json_body = '{"test": 123'
    invalid_json_mime = 'json'
    assert json_formatter.enabled is False
    assert json_formatter.format_body(invalid_json_body, invalid_json_mime) == invalid_json_body

    # Second test: body is a valid json string and no indentation
    valid_json_body = '{"test": 123}'
    valid_json_mime = 'json'
    json_formatter.format_options['json']['format'] = True
    assert json_formatter.enabled is True

# Generated at 2022-06-11 23:51:36.190329
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.format.json import JSONFormatter
    from json import dumps
    from collections import OrderedDict
    from io import open

    class FakeJSONFormatter(JSONFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.kwargs = {
                'explicit_json': True
            }

    fjson = FakeJSONFormatter(
        stdin=None,
        stdout=None,
        stderr=None,
        output_options=None,
        format_options=None,
        conf=None,
    )

    # Case 1: expected status code: 200, expected result: a string

# Generated at 2022-06-11 23:51:41.258171
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    JSONFormatter_ = JSONFormatter()
    body = '{"element1": "valueA", "element2": "valueB"}'
    body_formatted = '{\n  "element1": "valueA",\n  "element2": "valueB"\n}'
    assert JSONFormatter_.format_body(body=body, mime='application/json') == body_formatted

# Generated at 2022-06-11 23:51:43.624308
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(b'{"key": "value"}', "application/json") == '{\n    "key": "value"\n}'


# Generated at 2022-06-11 23:51:52.373851
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    #Test for valid json
    test_json = JSONFormatter(explicit_json=False, format_options={"json": {"format": False, "indent": 2, "sort_keys": True}})
    assert '{' not in test_json.format_body('{}', 'json')
    #Test for random text
    assert 'hello' == test_json.format_body('hello', 'json')
    #Test for invalid json
    test_json_1 = JSONFormatter(explicit_json=True, format_options={"json": {"format": False, "indent": 2, "sort_keys": True}})
    assert '{' not in test_json.format_body('{"}', 'json')
    #Test for invalid json with explicit_json set to True
    assert '{' not in test_json_1

# Generated at 2022-06-11 23:52:12.399618
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }, explicit_json=False)

    # Test
    json_str = '{"foo": "bar", "test": 1}'
    assert(json_formatter.format_body(json_str, 'json') == '{\n    "foo": "bar",\n    "test": 1\n}')
    assert(json_formatter.format_body(json_str, 'javascript') == '{\n    "foo": "bar",\n    "test": 1\n}')


# Generated at 2022-06-11 23:52:13.806200
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == True, 'test_JSONFormatter failed'

# Generated at 2022-06-11 23:52:23.901747
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(**{'explicit_json': False,
                         'format_options': {'json': {'format': True,
                                                     'indent': 2,
                                                     'sort_keys': True}}})
    # test when body is JSON
    body = '{"key": "value"}'  # type: str
    mime = 'json'  # type: str
    expected = '{\n  "key": "value"\n}'  # type: str
    assert f.format_body(body, mime) == expected
    mime = 'text'  # type: str
    assert f.format_body(body, mime) == expected
    # test when body is not JSON
    body = 'not json'  # type: str
    mime = 'json'  # type: str
   

# Generated at 2022-06-11 23:52:29.488965
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(**{'explicit_json': True})
    assert formatter.format_body('{"key": "value"}', "json") == \
        '{\n    "key": "value"\n}'
    assert formatter.format_body('[1, 2, 3]', "json") == \
        '[\n    1,\n    2,\n    3\n]'

# Generated at 2022-06-11 23:52:38.989247
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.format_body("{\"a\": 1, \"b\":2}", "application/json") == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonFormatter.format_body("{\"a\": 1, \"b\":2}", "application/javascript") == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonFormatter.format_body("{\"a\": 1, \"b\":2}", "text/plain") == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:52:47.327985
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import BuiltinPluginManager
    from httpie.plugins import JSONFormatter
    from requests.structures import CaseInsensitiveDict
    import types
    import json

    #### mock arguments
    # mock response object
    class MockResponse:
        def __init__(self, headers, body):
            self.body = body
            self.headers = headers

        def get_body(self):
            return self.body

        def get_headers(self, as_objects=False, lowercase_names=False):
            if as_objects:
                items = [
                    (k, [v]) for k, v in self.headers.items()
                ]
                return CaseInsensitiveDict

# Generated at 2022-06-11 23:52:52.923275
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Test with json formatting
    json_formatter = JSONFormatter(
        format_options={'json': {'format': True}})
    assert json_formatter.enabled is True

    # Test without json formatting
    json_formatter = JSONFormatter(
        format_options={'json': {'format': False}})
    assert json_formatter.enabled is False



# Generated at 2022-06-11 23:52:58.058457
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_body = '{"foo":1,"bar":"some string"}'
    assert JSONFormatter(format_options={
        'json': {'format': True, 'indent': 4, 'sort_keys': True}
    }).format_body(json_body, 'json') == (
        '{\n    "bar": "some string",\n    "foo": 1\n}'
    )

# Generated at 2022-06-11 23:53:03.836716
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    This test checks the fuctionality of `format_body` method of 
    `JSONFormatter` class
    """
    jf = JSONFormatter()
    body = "[{'a':1,'b':2},{'a':3,'b':4}]"
    print(jf.format_body(body=body, mime='json'))

# Generated at 2022-06-11 23:53:11.118484
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    assert (formatter.format_body(
        '{"a": 1, "b": 2}',
        'json') == '{\n    "a": 1,\n    "b": 2\n}')
    assert (formatter.format_body(
        '{"a": 1, "b": 2}',
        'application/json') == '{\n    "a": 1,\n    "b": 2\n}')
    assert (formatter.format_body(
        '{"a": 1, "b": 2}',
        'text/javascript') == '{\n    "a": 1,\n    "b": 2\n}')