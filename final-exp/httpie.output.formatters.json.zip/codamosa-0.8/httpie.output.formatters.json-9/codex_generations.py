

# Generated at 2022-06-11 23:48:08.720869
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass

# Generated at 2022-06-11 23:48:13.811906
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(explicit_json=True, format_options={'json': {
        'indent': 0,
        'sort_keys': False,
        'format': True
    }})

    assert jf.format_body('{"a":"b"}', 'json') == '{\n"a": "b"\n}'



# Generated at 2022-06-11 23:48:16.886692
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter().enabled
    assert not JSONFormatter(format_options={'json': {'sort_keys': True, 'indent': 2, 'format': True}}).enabled

# Generated at 2022-06-11 23:48:23.778780
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    FORMATTED_JSON_STRING = '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    mock_body = '{"a": 1, "b": 2, "c": 3}'
    mock_mime = 'application/json'

    json_formatter = JSONFormatter(**{'json': {'format': True}})
    assert json_formatter.format_body(body=mock_body, mime=mock_mime) == FORMATTED_JSON_STRING

# Generated at 2022-06-11 23:48:26.046489
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body({'test': 'test'}, 'json') == '{\n  "test": "test"\n}'

# Generated at 2022-06-11 23:48:28.581834
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    h = JSONFormatter(format_options={'json': {'format': True}})
    assert h.enabled == True


# Generated at 2022-06-11 23:48:34.093871
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    def check(in_obj, out_obj):
        assert formatter.format_body(in_obj, mime="json") == out_obj

    check('true', 'true')
    check('null', 'null')
    check('1', '1')
    check('1.0', '1.0')
    check('"foo"', '"foo"')
    check('[]', '[]')
    check('{}', '{}')
    check('{"bar": [1, 2, "baz"]}', '{\n    "bar": [\n        1,\n        2,\n        "baz"\n    ]\n}')

# Generated at 2022-06-11 23:48:40.182421
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    kwargs = {
        'format_options': {
            'json': {
                'format': True,
                'indent': True,
                'sort_keys': False
            }
        },
        'explicit_json': False
    }

    try:
        formatter = JSONFormatter(**kwargs)
        assert(formatter.enabled is True)
        assert(formatter.kwargs == kwargs)

    except Exception as e:
        assert(False)



# Generated at 2022-06-11 23:48:46.885128
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(**{'explicit_json': True,
                                 'format_options': {
                                     'json': {
                                         'format': True,
                                         'indent': 4,
                                         'sort_keys': True
                                     }
                                 }})

    assert formatter.kwargs['explicit_json'] is True
    assert formatter.format_options == {
                                         'json': {
                                             'format': True,
                                             'indent': 4,
                                             'sort_keys': True
                                         }
                                     }



# Generated at 2022-06-11 23:48:52.415103
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Case: no errors occur
    data = '{"name":"John"}'
    formatter_plugin = JSONFormatter()
    assert data == formatter_plugin.format_body(data, 'plain')

    # Case: error occurs
    data = '{"name":"John"'
    formatter_plugin = JSONFormatter()
    assert data == formatter_plugin.format_body(data, 'plain')