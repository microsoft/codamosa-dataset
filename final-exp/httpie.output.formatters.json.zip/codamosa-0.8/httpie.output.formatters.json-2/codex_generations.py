

# Generated at 2022-06-11 23:48:10.240564
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body("{'test': 'JSON'}", 'json') == '{\n    "test": "JSON"\n}'

# Generated at 2022-06-11 23:48:20.177033
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    maybe_json = [
            'json',
            'javascript',
            'text',
    ]
    fmt = JSONFormatter(
        #TODO: what args need to be passed
        format_options={'json': {
            'format': True,
            'indent': None,
            'sort_keys': True
        }},
        explicit_json=True
    )
    body = '{"k1": "v1"}'
    mime = 'json'
    assert fmt.format_body(body, mime) == body
    mime = 'application/json'
    assert fmt.format_body(body, mime) == body
    mime = 'text/javascript'
    assert fmt.format_body(body, mime) == body
    body = '{invalid}'
    assert fmt.format_

# Generated at 2022-06-11 23:48:30.726249
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:48:34.178276
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    assert isinstance(formatter, JSONFormatter)
    assert isinstance(json_str, str)

    # Unit test JSONFormatter.format_body
    assert json_str == formatter.format_body(json_str, 'application/json')



# Generated at 2022-06-11 23:48:44.009161
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body("{'a': 'b'}", 'text/json') == '''{
    "a": "b"
}'''
    assert formatter.format_body("{'a': 'b'}", 'text') == '''{
    "a": "b"
}'''
    assert formatter.format_body("{'a': 'b'}", 'javascript') == '''{
    "a": "b"
}'''
    assert formatter.format_body("{'a': 'b'}", 'html') == "{\'a\': \'b\'}"
    assert formatter.format_body("{'a': 'b'}", 'text/html') == "{\'a\': \'b\'}"
    assert formatter.format

# Generated at 2022-06-11 23:48:54.187623
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Create a temporary file with a JSON example
    # Indent, sort keys by name, and avoid
    # unicode escapes to improve readability.
    json_example = {
        "GLAccountTypeId": 0,
        "Name": "string",
        "Code": "string",
        "Valid": True,
        "Id": "string",
        "Version": 0,
        "Active": True,
        "CreatedOn": "2020-03-18T22:28:21.388Z",
        "CreatedBy": "string",
        "ModifiedOn": "2020-03-18T22:28:21.388Z",
        "ModifiedBy": "string",
        "Deleted": True
    }

# Generated at 2022-06-11 23:49:00.380189
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs['explicit_json'] = True
    json_formatter.format_options['json'] = {'format': True, 'sort_keys': True, 'indent': 4}
    result = json_formatter.format_body('{"a":1, "b":2}', 'json')
    assert result == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:49:06.583548
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    body = '{"hello":"world"}'
    mime = 'application/json'
    kwargs = {
        'explicit_json': True
    }
    # Act
    json_formatter = JSONFormatter(**kwargs)
    # Assert
    assert json_formatter.format_body(body=body, mime=mime) == '{\n    "hello": "world"\n}\n'

# Generated at 2022-06-11 23:49:14.649640
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import PluginManager
    from json import dumps
    from httpie.plugins import Plugin
    import requests
    import requests_mock

    def create_plugin(**plugin_kwargs):
        class TestPlugin(Plugin):
            name = 'Test'

            def __init__(self):
                self.__version__ = '0.0.1'
                self.format_options = {
                    'json': {
                        'sort_keys': True,
                        'indent': 2,
                        'format': True
                    }
                }

            def get_options(self):
                return self.format_options

            def update_settings(self, session):
                pass


# Generated at 2022-06-11 23:49:22.965730
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:49:36.592773
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    formatter = JSONFormatter(format_options={'json': {
        'format': True,
        'indent': 2,
        'sort_keys': True
    }})
    formatted = formatter.format_body(
        mime="application/json",
        body=r'{"name": "larry", "age": 60}'
    )
    assert isinstance(formatted, str)
    assert formatted == r'{\n  "age": 60,\n  "name": "larry"\n}'
    formatted = formatter.format_body(
        mime="application/javascript",
        body=r'{"name": "larry", "age": 60}'
    )

# Generated at 2022-06-11 23:49:43.689023
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(json={'format': True, 'sort_keys': False, 'indent': 2})
    
    maybe_json = [
        'json',
        'javascript',
    ]
    mime = 'json'
    assert any(token in mime for token in maybe_json)
    
    body = '{"name":"John", "age":30}'
    
    
    
    assert json.loads(body) == {"name":"John", "age":30}
    
    obj = json.loads(body)
    assert json.dumps(
                    obj=obj,
                    sort_keys=False,
                    ensure_ascii=False,
                    indent=2
                ) == '{\n  "name": "John",\n  "age": 30\n}'

# Generated at 2022-06-11 23:49:50.709679
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4
            }
        }
    ).format_body(
        '{"foo": "bar", "spam": "abc", "abc": 123}',
        'application/json'
    ) == '''{
    "abc": 123,
    "foo": "bar",
    "spam": "abc"
}'''

# Generated at 2022-06-11 23:49:51.592184
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass


# Generated at 2022-06-11 23:50:01.930186
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:50:09.469042
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(format_options = {"json": {"format": True, "sort_keys": True, "indent": 4}})
    data = '{"a":"b"}'
    data_ = jf.format_body(body=data, mime='')
    assert data_ == '{\n    "a": "b"\n}'
    data = '{"fname":"John","lname":"Doe","hobbies":["music","skiing","photography"],"age":32}'
    data_ = jf.format_body(body=data, mime='')

# Generated at 2022-06-11 23:50:14.340990
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    instance = JSONFormatter(**{
        'format_options': {
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        'explicit_json': True
    })
    assert instance.enabled == True
    assert instance.kwargs['explicit_json'] == True

# Generated at 2022-06-11 23:50:24.768267
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{'explicit_json': False,
                                      'format_options': {'json': {
                                          'format': True,
                                          'indent': 2,
                                          'sort_keys': True
                                      }
                                      }})
    assert json_formatter.format_body(body=json.dumps({'a': 1, 'b': 2}),
                                      mime='json') == json.dumps({'a': 1,
                                                                  'b': 2},
                                                                 sort_keys=True,
                                                                 indent=2,
                                                                 ensure_ascii=False)

# Generated at 2022-06-11 23:50:30.422827
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test validation of json.loads
    json_formatter = JSONFormatter()
    original_body = '[1, 2, 3]'
    body = json_formatter.format_body(body=original_body, mime='json')
    assert body == '[1, 2, 3]'

    # Test validation of json.loads
    json_formatter = JSONFormatter()
    original_body = '{{ "json": "test" }}'
    body = json_formatter.format_body(body=original_body, mime='json')
    assert body == '{{ "json": "test" }}'

    # Test standard calling with valid JSON
    json_formatter = JSONFormatter(**{'explicit_json': False})
    original_body = '{"json": "test"}'
    body = json_formatter.format_body

# Generated at 2022-06-11 23:50:41.646143
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4,
        }
    }
    json_formatter = JSONFormatter(format_options=format_options)
    data = {
        'd': {
            'a': 1,
            'b': [4],
            'c': {
                'c0': "hello",
                'c1': True,
                'c2': None,
            }
        },
        'a': [
            {},
            {
                'a1': True
            },
            {}
        ]
    }
    body = json.dumps(data, sort_keys=True, ensure_ascii=False, indent=4)