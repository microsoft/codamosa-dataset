

# Generated at 2022-06-11 23:48:15.985014
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_input = '{"string": "a string", "boolean": false, "number": 123}'
    test_mime = 'application/json'
    expected = '{\n    "boolean": false,\n    "number": 123,\n    "string": "a string"\n}'

    return_value = JSONFormatter()
    assert return_value.format_body(test_input, test_mime) == expected

# Generated at 2022-06-11 23:48:16.562072
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert True

# Generated at 2022-06-11 23:48:24.174978
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
	import unittest
	from unittest import mock
	from httpie.plugins import FormatterPlugin
	from httpie.plugins.builtin import JSONFormatter
	JSON_DATA = {
		'foo': 1,
		'bar': 'baz'
	}
	formatter_plugin = JSONFormatter()
	payload = json.dumps(JSON_DATA)
	mime = 'application/json'
	expected_output = json.dumps(JSON_DATA, sort_keys=False, ensure_ascii=False, indent=None)
	assert formatter_plugin.format_body(payload, mime) == expected_output

# Generated at 2022-06-11 23:48:31.502574
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = FormatterPlugin(**{'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    data = {
        'status_code': 200,
        'headers': {'Content-Type': 'application/json'},
        'body': '{"text": "hello world"}'
    }
    json_formatter = JSONFormatter(data)
    json_formatter.format_body(data['body'], data['headers']['Content-Type'])
    assert json.loads(json_formatter.body) == {'text': 'hello world'}

# Generated at 2022-06-11 23:48:37.598179
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    json_formatter = JSONFormatter(explicit_json=False,
                                        format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}},
                                        no_color=True)
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'


# Generated at 2022-06-11 23:48:46.653460
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Array json
    json_dict = '{"a":"b","c":[1,2,3],"d":4}'
    json_dict = json.loads(json_dict)
    json_dict = json.dumps(
        obj=json_dict,
        sort_keys=True,
        ensure_ascii=False,
        indent=4
    )
    assert JSONFormatter(format_options={"json" : {"format": True, "indent" : 4, "sort_keys": True}}).format_body(
        body=json_dict, mime="json") == json_dict

    # Object json
    json_dict = '{"a":"b","c":3,"d":[1,2,3]}'
    json_dict = json.loads(json_dict)

# Generated at 2022-06-11 23:48:53.310882
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {
        'format': True,
        'indent': 4,
        'sort_keys': True,
    }})
    assert formatter.format_body(
        '[{"a": 1, "b": 2, "c": 3}]',
        'application/json'
    ) == '[\n    {\n        "a": 1,\n        "b": 2,\n        "c": 3\n    }\n]'

# Generated at 2022-06-11 23:49:03.870507
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_obj = {
        'since': 1,
        'client_id': 'CLIENT_ID',
        'client_secret': 'CLIENT_SECRET',
        'redirect_uri': 'http://example.com',
    }
    body = json.dumps(
        obj=json_obj,
        sort_keys=True,
        ensure_ascii=False,
        indent=4
    )
    # Setting kwargs['explicit_json'] to True for test purposes.
    # Usually this is set by __init__() using options from the .ini file.
    json_formatter = JSONFormatter(kwargs={'explicit_json': True})
    response = json_formatter.format_body(json.dumps(json_obj), 'json')
    assert response == body

# Generated at 2022-06-11 23:49:12.829071
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test an invalid JSON
    message = b'foo"bar"baz'
    mime = 'json'
    json_formatter = JSONFormatter(explicit_json=True, format_options={"json":{"format":"True", "sort_keys": "True", "indent": "4"}})
    formatted_message = json_formatter.format_body(message, mime)
    assert formatted_message == message.decode()


    # Test a valid JSON
    message = b'{"foo":"bar","baz":"frotz"}'
    mime = 'json'
    json_formatter = JSONFormatter(explicit_json=True, format_options={"json":{"format":"True", "sort_keys": "True", "indent": "4"}})
    formatted_message = json_formatter.format_

# Generated at 2022-06-11 23:49:14.459892
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter

# Generated at 2022-06-11 23:49:22.765821
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"b": 2, "a": 1}'
    mime = 'application/json'
    assert body != JSONFormatter(
        format_options={
            'json': {
                'sort_keys': True,
                'indent': 4,
                'format': True,
            }
        }
    ).format_body(body, mime)

# Generated at 2022-06-11 23:49:23.351869
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert(False)

# Generated at 2022-06-11 23:49:24.885290
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter()
    assert(j.enabled)

# Generated at 2022-06-11 23:49:25.860187
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass


# Generated at 2022-06-11 23:49:36.593104
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # Successful construction
    fmt = JSONFormatter(format_options={
            "json": {
                "format": False,
                "indent": 4,
                "sort_keys": True
            }
        },
        explicit_json=False,
        color=False
    )
    assert isinstance(fmt, JSONFormatter)
    # Unsuccessful construction, when format_options is null
    try:
        JSONFormatter(format_options=None, explicit_json=False, color=False)
        assert False  # Shouldn't be here
    except TypeError:
        assert True
    # Unsuccessful construction, when format_options is empty

# Generated at 2022-06-11 23:49:43.688552
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    mime = 'application/json'
    json_body = '{"a": 1, "b": 2}'

    json_formatter.kwargs['explicit_json'] = False

    # Explicit_json is false here, so we expect the json_body to be returned
    # unchanged
    assert json_formatter.format_body(
        body=json_body,
        mime=mime
    ) == json_body
    assert json_formatter.format_body(
        body=json_body,
        mime='text/html'  # Should not trigger json formatting
    ) == json_body

    json_formatter.kwargs['explicit_json'] = True

    # Explicit_json is True here, so we expect the json_body to be formatted
    # with two spaces

# Generated at 2022-06-11 23:49:48.024226
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    })
    assert formatter.enabled is True


# Generated at 2022-06-11 23:49:50.191682
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{"id": "abc"}', '') == '{\n    "id": "abc"\n}'

# Generated at 2022-06-11 23:49:55.239299
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
            }
        }
    f = JSONFormatter(format_options=format_options)
    assert f.format_body('[]', 'json') == '[]'
    assert f.format_body('{}', 'json') == '{}'
    assert f.format_body('{"key": "value"}', 'json') == '{\n  "key": "value"\n}'

# Generated at 2022-06-11 23:50:01.111091
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter()
    assert jsonformatter.enabled == True
    assert jsonformatter.kwargs['explicit_json'] == False
    assert jsonformatter.format_options['json']['format'] == True
    assert jsonformatter.format_options['json']['indent'] == 2
    assert jsonformatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-11 23:50:12.674873
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fake = "test1"
    fake_option = {'json': {'format': True,
                            'indent': 2,
                            'sort_keys': True}}
    formatter = JSONFormatter(format_options=fake_option, explicit_json=fake)
    assert formatter.enabled == True
    assert formatter.kwargs == {'explicit_json': 'test1'}

# Generated at 2022-06-11 23:50:22.875147
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
                                   # log_dir=logdir,
                                   # log_file=logfile,
                                   # debug=False,
                                   format_options={},
                                   implicit_content_type='application/json',
                                   explicit_content_type='application/json',
                                   explicit_json=True,
                                   explicit_pretty=True,
                                   stdout_isatty=False,
                                   )
    body = '{"a": 2, "b": 3}'
    mime = 'application/json'
    body_expected = '{\n    "a": 2,\n    "b": 3\n}'
    body_json_formatted = json_formatter.format_body(body=body, mime=mime)
    assert body_json_formatted == body

# Generated at 2022-06-11 23:50:31.931591
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Test case for format_body method of class JSONFormatter.
    """
    # Init a JSONFormatter(like in httpie)
    json_formatter = JSONFormatter(explicit_json=True, 
                        format_options={
                            'json': {
                                'format': True,
                                'indent': 2,
                                'sort_keys': True
                            }
                        })
    # Strings input to format_body method
    json_string = '{"k1": "v1", "k2": "v2"}'
    text_string = 'this is a text string'
    javascript_string = 'var x = 1; console.log(x);'
    
    # Run format_body on a JSON string

# Generated at 2022-06-11 23:50:32.547496
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    JSONFormatter()

# Generated at 2022-06-11 23:50:38.239135
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(
        format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}}
    ).format_body('{"a": 1, "b": 2}', 'application/json') == \
        '{\n    "a": 1,\n    "b": 2\n}'



# Generated at 2022-06-11 23:50:47.694579
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    opt = {
      'headers': {
        'h': False,
        'H': True,
        'headers': True,
      },
      'body': {
        'b': False,
        'B': True,
        'body': True,
      },
      'verbose': {
        'v': True,
        'verbose': True,
      },
      'stream': {
        's': True,
        'stream': True,
      },
      'all': {
        'a': True,
        'all': True,
      },
      'json': {
        'json': True,
        'explicit_json': True,
        'format': True,
      },
    }

    formatter = JSONFormatter(format_options = opt)
    assert formatter.enabled

# Generated at 2022-06-11 23:50:55.738483
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
  # Test 1
  body = '{"success": true, "payload": {"user": "myusername", "password": "mypassword"}'
  mime = 'json'
  assert json.dumps(obj={"success": True, "payload": {"user": "myusername", "password": "mypassword"}}, sort_keys=True, ensure_ascii=False, indent=4) == JSONFormatter().format_body(body,mime)
  # Test 2
  body = '{"success": true, "payload": {"user": "myusername", "password": "mypassword"}'
  mime = 'javascript'

# Generated at 2022-06-11 23:51:02.145734
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonFormatter = JSONFormatter()
    # Test 1
    body = jsonFormatter.format_body('{"name": "Tom"}', "application/json")
    assert body == '{\n    "name": "Tom"\n}'

    # Test 2
    body = jsonFormatter.format_body('{"name": "Tom", "age": 25}', "application/json")
    assert body == '{\n    "age": 25,\n    "name": "Tom"\n}'


# Generated at 2022-06-11 23:51:04.925524
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    p = JSONFormatter(format_options={})
    assert p.kwargs == {'explicit_json': True}
    assert p.format_options == {}
    assert p.enabled is True


# Generated at 2022-06-11 23:51:08.240182
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # #unit-test direct call of method format_body of class JSONFormatter
    print('#unit-test direct call of method format_body of class JSONFormatter')
    print('No unit test available')

# Generated at 2022-06-11 23:51:29.502079
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.formatters.json import JSONFormatter
    body = '{"foo": "bar"}'
    mime = 'application/json'
    formatter = JSONFormatter(
        format_options={'json': {'indent': 2, 'sort_keys': True}},
    )
    body = formatter.format_body(body=body, mime=mime)
    assert body == '{\n  "foo": "bar"\n}'

    body = '{"foo": "bar"}'
    mime = 'application/javascript'
    formatter = JSONFormatter(
        format_options={'json': {'indent': 2, 'sort_keys': True}},
    )

# Generated at 2022-06-11 23:51:40.718429
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    f = JSONFormatter()

    assert(f.format_body('{"a": 0, "b": 1}', "text/javascript") == '{"a": 0, "b": 1}')
    assert(f.format_body('{"a": 0, "b": 1}', "application/javascript") == '{\n    "a": 0,\n    "b": 1\n}')

    f = JSONFormatter(explicit_json=True)

    assert(f.format_body('{"a": 0, "b": 1}', "text/plain") == '{\n    "a": 0,\n    "b": 1\n}')

# Generated at 2022-06-11 23:51:50.153620
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter({'json': {'format': True}, 'explicit_json': False}).format_body('{"a":1,"b":2}', 'text/plain') == '{\n    "a": 1,\n    "b": 2\n}\n'
    assert JSONFormatter({'json': {'format': True}, 'explicit_json': True}).format_body('{"a":1,"b":2}', 'text/plain') == '{\n    "a": 1,\n    "b": 2\n}\n'
    assert JSONFormatter({'json': {'format': True}, 'explicit_json': False}).format_body('{"a":1,"b":2}', 'application/json') == '{\n    "a": 1,\n    "b": 2\n}\n'
   

# Generated at 2022-06-11 23:51:58.150698
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options=dict())
    formatter.kwargs = dict()
    body_json = '{"k1": "v1", "k2": "v2"}'
    body_text = 'just some text'
    body_json_sorted = '{\n    "k1": "v1",\n    "k2": "v2"\n}'
    body_json_indented = '{\n    "k1": "v1",\n    "k2": "v2"\n}'

    assert(formatter.format_body(body=body_json, mime='json') == body_json)
    assert(formatter.format_body(body=body_json, mime='text') == body_json)

# Generated at 2022-06-11 23:52:08.108627
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fp = JSONFormatter(explicit_json=True)
    assert fp.enabled
    # Test JSON
    assert fp.format_body(body='{"key":"value"}', mime='application/json') == '{\n    "key": "value"\n}'
    assert fp.format_body(body='{"key":"value"}', mime='json') == '{\n    "key": "value"\n}'
    assert fp.format_body(body='{"key":"value"}', mime='application/not-json') == '{"key":"value"}'
    assert fp.format_body(body='INVALID_JSON', mime='json') == 'INVALID_JSON'
    # Test Text

# Generated at 2022-06-11 23:52:15.209262
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Formatter can format a JSON object in JSON body if the format option is enabled
    f = JSONFormatter(format_options={'json': {'format': True}})
    formatted = f.format_body('{"hello": "world"}', '')
    assert formatted.strip() == '{\n    "hello": "world"\n}'

    # Formatter does not format a JSON object in JSON body if the format option is disabled
    f = JSONFormatter(format_options={'json': {'format': False}})
    formatted = f.format_body('{"hello": "world"}', '')
    assert formatted == '{"hello": "world"}'
    # Does not format a body that isn't a JSON object
    f = JSONFormatter(format_options={'json': {'format': False}})
    formatted = f.format_

# Generated at 2022-06-11 23:52:24.775407
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from .httpie_mock import httpie_mock
    from .format_mock import format_mock

    json_formatter = JSONFormatter(httpie_mock, format_mock)

    assert json_formatter.format_body('{"foo": "bar"}', mime='json') == \
        '''{
    "foo": "bar"
}'''

    assert json_formatter.format_body('{"foo": "bar"}', mime='text') == \
        '''{
    "foo": "bar"
}'''

    assert json_formatter.format_body('{"foo": "bar"}', mime='image/png') == \
        '{"foo": "bar"}'

# Generated at 2022-06-11 23:52:35.569965
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # given
    maybe_json = [
        'json',
        'javascript',
        'text',
    ]
    json_formatter = JSONFormatter(**{'format_options': {'json': {'format': True, 'indent': 2, 'sort_keys': False}}})
    # when
    # body contains valid JSON
    body = '{"foo": ["bar", "baz"]}'
    mime = 'json'
    formatted_body_valid_JSON = json_formatter.format_body(body,mime)
    # body contains invalid JSON
    body = '{"foo": ["bar", "baz"]'
    mime = 'json'
    formatted_body_invalid_JSON = json_formatter.format_body(body,mime)
    # body does not contain JSON

# Generated at 2022-06-11 23:52:40.906062
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from .helpers import http, HTTP_OK
    assert JSONFormatter().format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert JSONFormatter().format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert JSONFormatter().format_body('{"a": "b"}', 'text') == '{"a": "b"}'
    assert JSONFormatter().format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'

# Generated at 2022-06-11 23:52:45.907328
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON content
    content = '{"name": "httpbin_plugin"}'
    output = JSONFormatter.format_body(content, "json")

    assert(content == output)
    assert(output == u'{\n    "name": "httpbin_plugin"\n}')

    # Test with invalid JSON
    content = "abc"
    output = JSONFormatter.format_body(content, "json")

    assert(content == output)

# Generated at 2022-06-11 23:53:07.224890
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"foo": "bar", "baz": 5}'
    formatter = JSONFormatter()

    # When the mime type is set to json
    assert formatter.format_body(body, 'application/json') == body

    # When the mime type is set to application/json, not "json"
    assert formatter.format_body(body, 'application/json') == body

    # When the mime type is set to javascript, not "json"
    assert formatter.format_body(body, 'application/javascript') == body

    # When the mime type is set to text, not "json"
    assert formatter.format_body(body, 'text/plain') == body

    # When the mime type is set to text, not "json"

# Generated at 2022-06-11 23:53:12.700944
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': False}}
    plugin = JSONFormatter(format_options=format_options, explicit_json=True)
    assert plugin.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert plugin.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert plugin.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert plugin.format_body('{a: "b"}', 'json') == '{a: "b"}'

# Generated at 2022-06-11 23:53:22.140281
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(**{ 'format_options': {'json': {'format': True, 'sort_keys': True, 'indent': 3}}, 'explicit_json': False}).format_body('{"a": 1}', 'json') == '{\n   "a": 1\n}'
    assert JSONFormatter(**{ 'format_options': {'json': {'format': True, 'sort_keys': True, 'indent': 3}}, 'explicit_json': False}).format_body('{"b": 1}', 'json') == '{\n   "b": 1\n}'

# Generated at 2022-06-11 23:53:30.590629
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    #No json
    assert  JSONFormatter(explicit_json=False,
    format_options={'json': {'format': True, 'indent': None, 'sort_keys': False}}).format_body('asdf','') == 'asdf'
    #json
    assert  JSONFormatter(explicit_json=False,
    format_options={'json': {'format': True, 'indent': None, 'sort_keys': False}}).format_body('{"asdf":1}','') == '{"asdf": 1}'
    #sort keys

# Generated at 2022-06-11 23:53:38.551164
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter_form_options = {
        'json': {
            'format': False,
            'indent': None,
            'sort_keys': False
        }
    }
    json_formatter = JSONFormatter(format_options = json_formatter_form_options,
                                    explicit_json = False)
    assert json_formatter.format_body('{"foo": "bar"}', 'application/json') == '{\n    "foo": "bar"\n}'
    assert json_formatter.format_body('{"foo": "bar"}', 'application/javascript') == '{\n    "foo": "bar"\n}'
    assert json_formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert json_

# Generated at 2022-06-11 23:53:43.072377
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"example": 1}'
    mime = 'application/json'
    formatted = formatter.format_body(body, mime)
    assert isinstance(formatted, type(body))
    assert formatted == body



# Generated at 2022-06-11 23:53:49.961646
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert JSONFormatter().format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert JSONFormatter().format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert JSONFormatter().format_body('{"foo": "bar"}', 'unknown') == '{"foo": "bar"}'

# Generated at 2022-06-11 23:53:59.137952
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
 
    def __init__(self, **kwargs):
        return FormatterPlugin.__init__(self, **kwargs)

    json_dict = {"id": "123", "label": "abc"}
    json_str = json.dumps(json_dict)

    # test if the exception is raised and handled properly
    print("Exceptions:")
    print("    Invalid JSON, ignore.")
    json_str = "invalid json string"
    assert(json_str == JSONFormatter().format_body(json_str, "application/json"))

    # single newline test cases

# Generated at 2022-06-11 23:54:07.692480
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body(body='{}', mime='json') == '{}'
    assert json_formatter.format_body(body='[]', mime='json') == '[]'
    assert json_formatter.format_body(body='{"foo": "bar"}', mime='json') == '{"foo": "bar"}'
    assert json_formatter.format_body(body='', mime='json') == ''
    assert json_formatter.format_body(body='{not json', mime='json') == '{not json'
    assert json_formatter.format_body(body='not json}', mime='json') == 'not json}'

# Generated at 2022-06-11 23:54:09.842946
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    assert f.format_body('{"a":1,"b":2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'



# Generated at 2022-06-11 23:54:21.829326
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert json.loads(
        JSONFormatter(explicit_json=True, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}}).format_body(
            '{"a": 1}', 'text')
    ) == {"a": 1}
    assert json.loads(
        JSONFormatter(explicit_json=True, format_options={'json': {'format': True,'indent': 2, 'sort_keys': True}}).format_body(
            r'{"a": 1}', 'application/json')
    ) == {"a": 1}

# Generated at 2022-06-11 23:54:29.247598
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs['explicit_json'] = True
    json_formatter.format_options['json']['indent'] = 8
    json_formatter.format_options['json']['sort_keys'] = True
    json_formatter.format_options['json']['format'] = True

    body = '{"hello": "world"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n        "hello": "world"\n}'

# Generated at 2022-06-11 23:54:36.499120
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter()
    body_json_unformatted = '{"key": "value"}'
    body_json_formatted = '{\n    "key": "value"\n}'
    body_text_unformatted = 'abcdef'
    assert jf.format_body(body_json_unformatted, 'json') == body_json_formatted
    assert jf.format_body(body_text_unformatted, 'text') == body_text_unformatted

# Generated at 2022-06-11 23:54:43.336921
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # Test for method format_body
    # Case 1
    body = 'https://www.google.com/'
    mime = 'text'
    actual = formatter.format_body(body, mime)
    assert actual == body
    # Case 2
    body = '{ "a": 1, "b": 2 }'
    mime = 'json'
    actual = formatter.format_body(body, mime)
    assert actual == '{\n\t"a": 1,\n\t"b": 2\n}'

# Generated at 2022-06-11 23:54:51.879621
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}, kwargs={'explicit_json': False})
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}\n'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{\n    "a": 1\n}\n'
    assert formatter.format_body('{"a": 1}', 'application/pdf') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'application/pdf; charset=utf-8') == '{"a": 1}'


# Generated at 2022-06-11 23:54:56.699182
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(explicit_json=True,
                       format_options={'json': {'format': True,
                                                'indent': 1,
                                                'sort_keys': True}})
    json_str = '{"msg": "Hello World", "n": 1}'
    assert jf.format_body(json_str, 'JSON') == '{\n "msg": "Hello World",\n "n": 1\n}'
    assert jf.format_body(json_str, 'TEXT') == '{\n "msg": "Hello World",\n "n": 1\n}'
    assert jf.format_body(json_str, 'HTML') == json_str



# Generated at 2022-06-11 23:54:58.739670
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonFormatter = JSONFormatter()
    body = jsonFormatter.format_body(body="{},", mime='json')
    assert body == '{\n}\n'

# Generated at 2022-06-11 23:55:06.747123
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False)
    body = '{"test": "test_value", "test_2": "test_value_2"}'
    body_json = json.loads(body)
    assert body == formatter.format_body(body, 'application/json')
    assert body_json == json.loads(
        formatter.format_body(body, 'text/javascript')
    )
    assert body_json == json.loads(
        formatter.format_body(body, 'text/plain')
    )
    assert body_json == json.loads(
        formatter.format_body(body, 'application/octet-stream')
    )
    # Invalid JSON, ignore.
    body = '{"test": "test_value", "test_2": "test_value_2"'


# Generated at 2022-06-11 23:55:15.894050
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
	options = {'json': {'format': True, 'indent': '2', 'sort_keys': True}}
	formatter = JSONFormatter(format_options=options)
	body = {"a": 1, "b": 2}
	body = json.dumps(body)
	formatted_body = formatter.format_body(body, 'json')
	expected = {"a": 1, "b": 2}
	expected = json.dumps(expected, sort_keys=True, ensure_ascii=False, indent=2)
	assert formatted_body == expected

	options = {'json': {'format': True, 'indent': '2', 'sort_keys': True}}
	formatter = JSONFormatter(format_options=options)
	body = {"a": 1, "b": 2}
	body = json

# Generated at 2022-06-11 23:55:24.081701
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.enabled = True
    assert json_formatter.enabled == True
    json_formatter.kwargs = {'explicit_json': False}
    assert json_formatter.kwargs['explicit_json'] == False
    json_formatter.kwargs = {'explicit_json': True}
    assert json_formatter.kwargs['explicit_json'] == True
    json_formatter.format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    }