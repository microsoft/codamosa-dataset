

# Generated at 2022-06-11 23:48:20.178727
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Given
    formatter = JSONFormatter(format_options={}, streams=None)
    input_body_json = '{"name": "John Doe", "height": 1.80, "age": 42}'
    input_body_not_json = 'foo bar'
    input_body_json_invalid = '{"foo": "bar",}'
    input_body_json_with_slash = '{"name": "John Doe", "height": 1.80, "age": 42}/'
    output_body_json = '{\n    "name": "John Doe",\n    "height": 1.8,\n    "age": 42\n}'
    # When
    output_body = formatter.format_body(input_body_json, 'application/json')
    output_body_not_json = formatter

# Generated at 2022-06-11 23:48:28.038716
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    data = {"foo": "bar", "fizz": "buzz"}
    from httpie.plugins import FormatterPlugin

    jf = JSONFormatter(explicit_json=False, format_options={
        "json": {
            "format": True,
            "indent": 2,
            "sort_keys": True
        }
    })
    assert jf.format_body(json.dumps(data), 'json') == json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False)

# Generated at 2022-06-11 23:48:31.057866
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={
            'json': {'format': True, 'indent': 2, 'sort_keys': True}
        },
        kwargs={'explicit_json': True}
    ) # Constructor of class JSONFormatter

    assert json_formatter.enabled



# Generated at 2022-06-11 23:48:36.489006
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter(**{
        'format_options': {
            'json': {
                'sort_keys': True,
                'indent': 4,
                'format': False,
            },
        },
    })
    assert f.format_options == {
        'json': {
            'sort_keys': True,
            'indent': 4,
            'format': False,
        },
    }
    assert not f.enabled

# Generated at 2022-06-11 23:48:45.860310
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    json_data = {
        "key1": "value1",
        "key2": "value2"
    }
    json_string = json.dumps(obj=json_data)
    assert json_formatter.format_body(json_string, 'text/json') == json_string

    json_data['key2'] = 'value2_changed'
    json_string_changed = json.dumps(obj=json_data)
    assert json_formatter.format_body(json_string_changed, 'text/json') == json_string_changed

    non_json_string = '{"key1":"value1", "key2":"value2"}'
    assert json_formatter.format_body(non_json_string, 'text/json') == non_json_string

# Generated at 2022-06-11 23:48:55.618532
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json=True)
    python_dict = {
        'a': 1,
        'b': [2, 3],
        'c': "4"
    }
    python_list = [1, 2, 3, 4]
    json_string = '{"a": 1, "b": [2, 3], "c": "4"}'
    assert json_formatter.format_body(json_string, "json") == json_string
    assert json_formatter.format_body(json.dumps(python_dict), "json") == json_string
    assert json_formatter.format_body(json.dumps(python_list), "json") == str(python_list)

# Generated at 2022-06-11 23:49:00.030700
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        print_body=True,
        format_options={
            'json':
            {
                'format': True,
                'indent': 4,
                'sort_keys': False
            }
        }
    )
    assert formatter.enabled == True


# Generated at 2022-06-11 23:49:04.729267
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 0, 'sort_keys': False}})
    data = formatter.format_body('{"test":"test"}', 'application/json')
    assert(data == '{"test":"test"}')



# Generated at 2022-06-11 23:49:11.021713
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter(format_options={'json': {
        'format': True,
        'indent': 0,
        'sort_keys': True,
    }}, explicit_json=True)
    assert test.kwargs['explicit_json']
    assert test.format_options['json']['format']
    assert test.format_options['json']['indent'] == 0
    assert test.format_options['json']['sort_keys']
    assert test.format_options['pretty'] == False



# Generated at 2022-06-11 23:49:16.648332
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={'json': {'format': True, 'indent': 4,
                                 'sort_keys': True, 'ensure_ascii': True}})
    assert formatter.format_body(
        '{"a": 1, "b": 2}', 'application/json') == '{\n    "a": 1,\n    "b": 2\n}'



# Generated at 2022-06-11 23:49:28.573805
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup of test
    test_JSONFormatter = JSONFormatter()
    test_JSONFormatter.format_options['json']['format'] = True
    test_JSONFormatter.kwargs['explicit_json'] = True
    test_JSONFormatter.format_options['json']['indent'] = 4
    test_JSONFormatter.format_options['json']['sort_keys'] = True

    # Test function
    assert test_JSONFormatter.format_body('{ "a": "test" }', 'JSON') == '{\n    "a": "test"\n}'

# Generated at 2022-06-11 23:49:39.224661
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    })
    assert json_formatter.format_body(
        body='{"A": "e", "B": "c", "C": "b", "D": "d", "E": "a"}',
        mime='application/json'
    ) == '{\n  "A": "e",\n  "B": "c",\n  "C": "b",\n  "D": "d",\n  "E": "a"\n}'


# Generated at 2022-06-11 23:49:42.848216
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_input = '{"key": "value"}'
    json_output = '{\n    "key": "value"\n}'
    formatter_plugin = JSONFormatter()
    assert(formatter_plugin.format_body(json_input, 'json') == json_output)
    

# Generated at 2022-06-11 23:49:53.070936
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Input values:
    # body = '{"k1": "string", "k2": [1, 2, 3]}'
    # mime = 'some_mime'
    # object = {}
    # object["indent"] = 4
    # object["sort_keys"] = True
    # object["enabled"] = True
    # plugin = JSONFormatter(object)
    # Expected result:
    # '{\n    "k1": "string",\n    "k2": [\n        1,\n        2,\n        3\n    ]\n}'
    body = '{"k1": "string", "k2": [1, 2, 3]}'
    mime = 'some_mime'
    object = {}
    object["indent"] = 4
    object["sort_keys"] = True

# Generated at 2022-06-11 23:50:03.090675
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.utils import strip_blank_lines
    mime = 'foo/json'
    body_json = '{"a": [1,2,3]}'
    body_string = 'not json'
    formatter = JSONFormatter(explicit_json=False)

    # JSON body
    actual_json = formatter.format_body(body_json, mime)
    expected_json = '{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}'
    assert actual_json == expected_json

    # Not JSON body
    actual_string = formatter.format_body(body_string, mime)
    assert actual_string == body_string



# Generated at 2022-06-11 23:50:10.877544
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    maybe_json = ['json', 'javascript', 'text']

    # body = "abc"
    fj = JSONFormatter(**{'explicit_json': True, 'format_options': {'json': {'format': True, 'sort_keys': False, 'indent': None}}})
    assert fj.format_body("abc", "text/plain") == "abc"

    # body = '{"a": 1}'
    fj = JSONFormatter(**{'explicit_json': True, 'format_options': {'json': {'format': True, 'sort_keys': False, 'indent': None}}})
    assert fj.format_body('{"a": 1}', "text/plain") == '{"a": 1}'

    # Invalid JSON

# Generated at 2022-06-11 23:50:17.095221
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.context import Environment
    http_env = Environment()
    jf = JSONFormatter(None, http_env)
    assert jf.format_body('{"foo": "bar", "no": 1}', 'json') == '{\n    "foo": "bar", \n    "no": 1\n}'
    assert jf.format_body('{"foo": "bar", "no": 1}', '') == '{\n    "foo": "bar", \n    "no": 1\n}'
    # no modifications made as not json
    assert jf.format_body('foo', '') == 'foo'


# Generated at 2022-06-11 23:50:23.564776
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Prepare mocked values before creating JSONFormatter object
    kwargs = {'explicit_json': True, 'format_options': {'json': {'format': True, 'sort_keys': True, 'indent': 1}}}

    # Create JSONFormatter object and call method format_body
    formatter = JSONFormatter(**kwargs)
    body = formatter.format_body("{'key': 1}", "json")

    # Verify result
    assert body == "{'key': 1}"

# Generated at 2022-06-11 23:50:27.868529
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(None, None, None, {
        'json': {
            'format': True,
            'indent': None,
            'sort_keys': False,
        }
    })
    formatted = formatter.format_body(
        '{"foo": 1, "bar": "baz"}', 'application/json'
    )
    assert formatted == '{\n    "bar": "baz",\n    "foo": 1\n}'

# Generated at 2022-06-11 23:50:37.917281
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    mime = 'application/json'
    # test 1
    body = '{"license": "This is a license"}'
    res = formatter.format_body(body, mime)
    assert res == '{\n  "license": "This is a license"\n}'
    # test 2
    body = '{"license":"This is a license"}'
    res = formatter.format_body(body, mime)
    assert res == '{\n  "license": "This is a license"\n}'
    # test 3
    body = '{"license": "This is a license"}'
    formatter.format_options['json']['indent'] = None
    res = formatter.format_body(body, mime)