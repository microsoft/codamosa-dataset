

# Generated at 2022-06-11 23:48:18.192743
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }
    })
    s = '{"key_1": "value_1", "key_2": "value_2"}'
    assert jf.format_body(s, 'json') == '{\n  "key_1": "value_1",\n  "key_2": "value_2"\n}'
    s = '{"key_1": "value_1", "key_2": "value_2"}'
    assert jf.format_body(s, 'javascript') == '{\n  "key_1": "value_1",\n  "key_2": "value_2"\n}'

# Generated at 2022-06-11 23:48:24.173016
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        formatter = JSONFormatter(format_options={'json': {'format': True,
                                                           'indent': 4,
                                                           'sort_keys': True}},
                                  explicit_json=False,
                                  colors=8)
    except NameError:
        raise AssertionError("JSONFormatter class constructor doesn't work properly")


# Generated at 2022-06-11 23:48:30.397453
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(defaults={'json': {'format': True, 'indent': 0, 'sort_keys': False}})
    assert json_formatter.enabled
    assert json_formatter.kwargs == {'explicit_json': False}
    assert json_formatter.format_options == {'json': {'format': True, 'indent': 0, 'sort_keys': False}}
# end of test_JSONFormatter


# Generated at 2022-06-11 23:48:39.822845
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1: valid json with application mime-type
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        },
        'colors': {
            '-': False,
            '+': False,
            'Boolean': False,
            'Number': False,
            'Null': False,
            'String': False
        },
        'headers': {
            'show': True,
            'separator': ':'
        },
        'pretty': True,
        'verbose': False
    })
    # Body is hard-coded by default

# Generated at 2022-06-11 23:48:47.926126
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(**{'explicit_json': True, 'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}})
    assert formatter.format_body(body="{\"status\":\"ok\"}", mime='json') == "{\n    \"status\": \"ok\"\n}"
    assert formatter.format_body(body="{\"status\":\"ok\"}", mime='text') == "{\"status\":\"ok\"}"
    assert formatter.format_body(body="a", mime='json') == "a"
    assert formatter.format_body(body="a", mime='text') == "a"
    assert formatter.format_body(body="a", mime='html') == "a"
    assert formatter.format_

# Generated at 2022-06-11 23:48:56.487553
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_string = '''
    {
        "status": "ok",
        "message": "HTTP Request Successful"
    }
    '''

    json_object = json.loads(json_string)

    expect_string = json.dumps(
        obj=json_object,
        sort_keys=True,
        ensure_ascii=False,
        indent=4,
    )

    class MockOption:
        def __init__(self, data):
            self.format = data
            self.sort_keys = data
            self.indent = data

    json_option = {"json": MockOption(True)}
    test_json = JSONFormatter(**json_option)
    result_string = test_json.format_body(json_string, 'json')

    # Test the result
    assert result_string

# Generated at 2022-06-11 23:49:02.398455
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-11 23:49:09.029086
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    options = {
        'json': {
            'format': True,
            'indent': 3,
            'sort_keys': False
        }
    }
    formatter = JSONFormatter(format_options=options)
    resp = formatter.format_body(body="{'key': 1}", mime='json')
    assert resp == '{\n   "key": 1\n}'
    resp = formatter.format_body(body="hola", mime='json')
    assert resp == 'hola'

# Generated at 2022-06-11 23:49:16.550957
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    expected_output = '{"a": 1, "b": 2}'
    formatter = JSONFormatter.__new__(JSONFormatter)
    formatter.kwargs = {'explicit_json': False}
    formatter.format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    input_data = '{"b": 2, "a": 1}'
    assert formatter.format_body(input_data, "") == expected_output

# Generated at 2022-06-11 23:49:26.864588
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    expected = '"hello"'
    output = formatter.format_body('"hello"', 'application/json')
    assert output == expected

    output = formatter.format_body('true', 'application/json')
    expected = 'true'
    assert output == expected

    output = formatter.format_body('true', 'text')
    expected = 'true'
    assert output == expected

    output = formatter.format_body('{"hello": "world"}', 'text')
    expected = '{\n    "hello": "world"\n}'
    assert output == expected

    expected = '"hello"'
    output = formatter.format_body('"hello"', 'application/json')
    assert output == expected

    output = formatter.format_body('true', 'application/json')