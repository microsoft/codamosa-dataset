

# Generated at 2022-06-11 23:48:17.360494
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False,
        }
    })

    # Test JSON object
    body = '{"a": 1, "z": 26, "c": 3, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "z": 26,\n    "c": 3,\n    "b": 2\n}\n'

    # Test JSON array
    body = '[1, 2, 3]'
    mime = 'application/json'

# Generated at 2022-06-11 23:48:22.826403
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
	json_formatter = JSONFormatter()
	body = '{"name":"hello","age":20}'
	mime = 'application/json'
	new_body = json_formatter.format_body(body, mime)
	sql_body = '{"age": 20, "name": "hello"}'
	assert new_body == sql_body

# Generated at 2022-06-11 23:48:32.109409
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py26
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    formatter = JSONFormatter()
    assert(type(formatter) == JSONFormatter)
    formatter.kwargs = {'explicit_json': False}
    formatter.format_options = {
        'json': {'sort_keys': True, 'indent': 4, 'format': True}
    }
    formatter.output_options = {'stream': None}
    # Invalid JSON
    body = '{"a": 3}'
    assert(formatter.format_body(body, 'json') == body)
    assert(formatter.format_body(body, 'text') == body)
    assert(formatter.format_body(body, 'javascript') == body)


# Generated at 2022-06-11 23:48:41.639132
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class DummyJSONFormatter:
        pass
    dummy = DummyJSONFormatter()

    # Test: when body is not str type
    dummy.kwargs = {} 
    body = 0
    mime = ""
    res = JSONFormatter.format_body(dummy, body, mime)
    assert res == str(body)

    # Test: when passed an empty body 
    body = ""
    mime = ""
    res = JSONFormatter.format_body(dummy, body, mime)
    assert res == body 

    # Test: when passed a None body
    body = None
    mime = None
    res = JSONFormatter.format_body(dummy, body, mime)
    assert res == str(body)

    # Test: when passed a valid json body

# Generated at 2022-06-11 23:48:50.561063
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter()

    # Test that only 1 valid JSON body is formatted
    test_cases = [
        # Valid JSON body
        {'body': '{"test": "body"}', 'expected': '{\n    "test": "body"\n}'},
        # Invalid JSON body
        {'body': '{"test": body"}', 'expected': '{"test": body"}'},
        # No JSON bodies
        {'body': '{test: "body"}', 'expected': '{test: "body"}'},
        {
            'body': '{"test": "body", "test2": "body2"}',
            'expected': '{\n    "test": "body", \n    "test2": "body2"\n}'
        },
    ]


# Generated at 2022-06-11 23:48:57.555054
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    # Must leave unmodified invalid JSON data
    assert not json_formatter.format_body('Not {} valid json', 'json')

    # Must leave unmodified invalid JSON data
    # (even if the mime type is json)
    assert not json_formatter.format_body('Not {} valid json', 'application/json')

    assert json_formatter.format_body('{ "a": 1 }', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{ "a": 1 }', 'application/json') == '{\n    "a": 1\n}'

    assert json_formatter.format_body('{ "a": 1 }', 'text') == '{\n    "a": 1\n}'
    assert json_

# Generated at 2022-06-11 23:49:01.117565
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"id":1,"name":"Test"}'
    mime = 'json'
    assert JSONFormatter().format_body(body, mime) == body
    assert JSONFormatter().format_body(body + ' ', mime) == body

# Generated at 2022-06-11 23:49:10.941993
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body("abc", "abc") == "abc"
    assert json_formatter.format_body(r'"abc"', "json") == '"abc"'
    assert json_formatter.format_body(r'"abc"', "text") == '"abc"'
    assert json_formatter.format_body(r'"abc"', "text/json") == '"abc"'
    assert json_formatter.format_body(r'{"c": "b"}', "json") == r'''{
    "c": "b"
}'''
    assert json_formatter.format_body(r'{"c": "b"}', "text") == r'''{
    "c": "b"
}'''
    assert json_formatter.format

# Generated at 2022-06-11 23:49:19.526278
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    }, explicit_json = True )
    a_json_str = r'''
    {
        "number": 123,
        "array": [
            {"name": "Alice"},
            {"name": "Bob"}
        ]
    }
    '''
    a_str = formatter.format_body(a_json_str , 'text/plain')
    print(a_str)

if __name__ == '__main__':
    test_JSONFormatter_format_body()

# Generated at 2022-06-11 23:49:29.028255
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Testing the method format_body of class JSONFormatter.
    """
    # JSONFormatter(debug=True, json_indent=2, pretty=True, save_cookies=True, sort_keys=False, session=<requests.sessions.Session object at 0x03E6B8B0>, style=<httpie.style.colors.DEFAULT object at 0x03E68750>)
    format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': False}}
    form = JSONFormatter(format_options=format_options)
    body = '{"a": "b"}'
    mime = 'json'
    assert form.format_body(body, mime) == '{\n  "a": "b"\n}'

# Generated at 2022-06-11 23:49:49.532265
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False,
        }
    }

    plugin = JSONFormatter(format_options=format_options)
    text = '{"key": "value"}'
    mime = 'application/json'
    assert plugin.format_body(text, mime) == '{\n  "key": "value"\n}'

    mime = 'text'
    assert plugin.format_body(text, mime) == '{\n  "key": "value"\n}'

    mime = 'not json'
    assert plugin.format_body(text, mime) == '{"key": "value"}'

# Generated at 2022-06-11 23:49:56.457148
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # No JSON
    body = "Not JSON"
    mime = "x-www-form-urlencoded"
    formatter = JSONFormatter()
    assert formatter.format_body(body, mime) == "Not JSON"

    # Valid JSON, not explicit
    body = '{"a": 1, "b": "text", "c": "t\\xe9st"}'
    mime = "application/json"
    formatter = JSONFormatter()
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": "text",\n    "c": "t\\xe9st"\n}'

    # Valid JSON, explicit
    body = '{"a": 1, "b": "text", "c": "t\\xe9st"}'
    m

# Generated at 2022-06-11 23:50:06.226548
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    args = {'explicit_json': False,
            'format_options': {'json': {'format': True,
                                        'indent': 4,
                                        'sort_keys': True}},
            'prettify': False}
    obj = dict(a=1, b=2, c=3)
    body = '{"a": 1, "b": 2, "c": 3}'
    assert JSONFormatter(**args).format_body(body, 'json') == json.dumps(
        obj=obj, sort_keys=True, ensure_ascii=False, indent=4)
    # Ensure that we also format text/* mime types.

# Generated at 2022-06-11 23:50:15.245448
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httplib2
    #test with valid json
    resp, content =  httplib2.Http("http://localhost:8001/api/v1/status").request("/api/v1/status")
    formatter = JSONFormatter(explicit_json=True)
    result = formatter.format_body(content,resp['content-type'])
    assert result == content
    #test with invalid json
    result = formatter.format_body("abc",resp['content-type'])
    assert result == "abc"
    #test with valid json without explicit json
    resp, content =  httplib2.Http("http://localhost:8001/api/v1/status").request("/api/v1/status")
    formatter = JSONFormatter()

# Generated at 2022-06-11 23:50:25.490511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    # Case 1: application/json
    body = '{"age": 20, "name": "John Smith"}'
    mime = "application/json"
    assert json_formatter.format_body(body, mime) == '{\n    "age": 20,\n    "name": "John Smith"\n}'

    # Case 2: text/javascript
    body = '{"age": 20, "name": "John Smith"}'
    mime = "text/javascript"
    assert json_formatter.format_body(body, mime) == '{\n    "age": 20,\n    "name": "John Smith"\n}'

    # Case 3: text/plain
    body = '{"age": 20, "name": "John Smith"}'

# Generated at 2022-06-11 23:50:33.357482
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange.
    formatter = JSONFormatter(
        format_options=dict(
            json=dict(
                format=True,
                indent=2,
                sort_keys=True,
            ),
        ),
        explicit_json=True,
    )
    body = '{"name": "jeff", "age": 30, "spouse": {"name": "anne", "age": 32}}'
    mime = 'json'

    # Act.
    actual = formatter.format_body(body, mime)

    # Assert.
    expected = '''{
  "age": 30,
  "name": "jeff",
  "spouse": {
    "age": 32,
    "name": "anne"
  }
}'''
    assert actual == expected

# Generated at 2022-06-11 23:50:44.220001
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    content = """{"name": "toto"}"""
    assert JSONFormatter(explicit_json=False).format_body(content, mime='json') == """{
    "name": "toto"
}"""
    assert JSONFormatter(explicit_json=True).format_body(content, mime='json') == """{
    "name": "toto"
}"""
    assert JSONFormatter(explicit_json=False).format_body(content, mime='text') == """{
    "name": "toto"
}"""
    assert JSONFormatter(explicit_json=True).format_body(content, mime='text') == """{
    "name": "toto"
}"""

# Generated at 2022-06-11 23:50:52.979040
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import str as compat_str
    from . import TestEnvironment

    formatter = JSONFormatter()


# Generated at 2022-06-11 23:51:00.746329
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(format_options={'json':{'format':True, 'sort_keys':True, 'indent':2}}).format_body('{"key":"value"}', 'text') == '{\n  "key": "value"\n}'
    assert JSONFormatter(format_options={'json':{'format':True, 'sort_keys':False, 'indent':0}}).format_body('{"key":"value"}', 'text') == '{"key":"value"}'
    assert JSONFormatter(format_options={'json':{'format':True, 'sort_keys':False, 'indent':4}}).format_body('{"key":"value"}', 'text') == '{\n    "key": "value"\n}'

# Generated at 2022-06-11 23:51:06.247323
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    txt = '{"a": 1, "b": "2", "c": 3}'
    f = FormatterPlugin(format_options={'json': {'sort_keys': False, 'indent': 1, 'format': True}})
    assert f.format_body(body=txt, mime='application/json') == '{\n "a": 1,\n "b": "2",\n "c": 3\n}'

# Generated at 2022-06-11 23:51:19.290636
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body(
        body='{ "a": 1 }',
        mime='application/json'
    ) == '{\n    "a": 1\n}'
    assert json_formatter.format_body(
        body='{ "a": 1 }',
        mime='application/javascript'
    ) == '{\n    "a": 1\n}'
    assert json_formatter.format_body(
        body='{ "a": 1 }',
        mime='text/plain'
    ) == '{\n    "a": 1\n}'
    assert json_formatter.format_body(
        body='{ "a": 1',
        mime='text/plain'
    ) == '{ "a": 1'

# Generated at 2022-06-11 23:51:25.412349
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False,
        }
    })
    body = '{"data": ["one", "two"]}'
    result = formatter.format_body(body, '')
    expected = """{
    "data": [
        "one",
        "two"
    ]
}"""
    assert result == expected

# Generated at 2022-06-11 23:51:27.820443
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter({}, format_options=dict(json=dict(format=True)))
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:51:30.233020
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(sort_keys = True, explicit_json = True, indent = None)
    assert formatter.format_body(body = '{"abc" : "def"}', mime = 'json') == '{"abc": "def"}'

# Generated at 2022-06-11 23:51:41.458585
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{ "a" : 12 }'
    mime = 'json'
    assert(JSONFormatter().format_body(body, mime) == '{ "a" : 12 }')
    assert(JSONFormatter(explicit_json=True).format_body(body, mime) == '{\n    "a": 12\n}')
    assert(JSONFormatter(explicit_json=True, format_options={'json': {'indent': 2}}).format_body(body, mime) == '{\n  "a": 12\n}')
    assert(JSONFormatter(explicit_json=True, format_options={'json': {'sort_keys': False}}).format_body(body, mime) == '{\n    "a": 12\n}')

# Generated at 2022-06-11 23:51:50.780085
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(kwargs=None, format_options=None)
    assert json_formatter.format_body('{"valid":"json"}', 'application/json') == '{\n    "valid": "json"\n}'
    assert json_formatter.format_body('{"invalid":"json"', 'text/plain') == '{"invalid":"json"'
    assert json_formatter.format_body('{"valid":"json"}', 'text/plain') == '{\n    "valid": "json"\n}'
    assert json_formatter.format_body('{"valid":"json"}', 'text/javascript') == '{\n    "valid": "json"\n}'
    assert json_formatter.format_body('{"invalid":"json"', 'text/javascript') == '{"invalid":"json"'

# Generated at 2022-06-11 23:51:58.176907
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1: json body with mime of json
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False,
        },
        'colors': {
            'format': True,
            'request_headers': 'cyan',
            'response_headers': 'green',
            'request_body': 'white',
            'response_body': 'white',
        },
        'stream': {
            'format': True,
            'requests': True,
            'responses': True,
        },
    })
    json_body = '{"key": "value"}'
    mime = 'application/json'
    result = json_formatter.format_body(json_body, mime)


# Generated at 2022-06-11 23:52:06.171060
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"key":"value"}', 'json') == '{\n    "key": "value"\n}'
    assert json_formatter.format_body('{"key":"value"}', 'javascript') == '{\n    "key": "value"\n}'
    assert json_formatter.format_body('{"key":"value"}', 'text') == '{\n    "key": "value"\n}'
    assert json_formatter.format_body('{"key":"value"}', 'html') == '{"key":"value"}'

# Generated at 2022-06-11 23:52:10.730693
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}})
    body = b'{"i am json"}'
    mime = 'application/json'
    assert formatter.format_body(body=body, mime=mime) == '{\n    "i am json"\n}'


# Generated at 2022-06-11 23:52:16.358067
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.compat import is_windows