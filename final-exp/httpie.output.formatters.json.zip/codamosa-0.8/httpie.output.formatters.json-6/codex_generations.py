

# Generated at 2022-06-11 23:48:16.513725
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def call_format_body(body, mime):
        return JSONFormatter(explicit_json=False, format_options = {'json':{'format': True, 'sort_keys': False, 'indent': 0}}).format_body(body=body, mime=mime)

    # Test on different types of MIME
    def test_JSONFormatter_format_body_json(test_case, expected):
        assert call_format_body(body=test_case,mime='json') == expected
    test_JSONFormatter_format_body_json(test_case='[1,2,3,4]',expected='[\n1,\n2,\n3,\n4\n]')

# Generated at 2022-06-11 23:48:19.928130
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(format_options={ 'json': { 'format': True } })
    body = '{"foo": "bar"}'
    mime = 'application/json'
    print(f.format_body(body, mime))
    print(f.format_body(body, 'text'))

# Generated at 2022-06-11 23:48:29.708248
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from requests import Response
    from pytest import fixture
    from httpie_formatter_apim import JSONFormatter
    r = Response()
    r.headers['Content-Type'] = 'application/json'
    r._content = b'[{"a": 1, "b": 2}, {"a": 3, "b": 4}]'
    r.encoding = 'utf-8'
    formatter = JSONFormatter()
    assert formatter.format_body(r.text, r.headers['Content-Type']) == '[\n  {\n    "a": 1,\n    "b": 2\n  },\n  {\n    "a": 3,\n    "b": 4\n  }\n]'

# Generated at 2022-06-11 23:48:30.240849
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert True == True

# Generated at 2022-06-11 23:48:31.464862
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie
    print(httpie.__version__)

# Generated at 2022-06-11 23:48:32.742402
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter.name == 'json'


# Generated at 2022-06-11 23:48:40.020180
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonformatter = JSONFormatter()
    # test if JSONFormatter.format_body() can format a valid JSON
    assert jsonformatter.format_body("""{"username":"leo","password":"leo"}""", "application/json") == """{
    "password": "leo",
    "username": "leo"
}"""

    # test if JSONFormatter.format_body() do not format a invalid JSON
    assert jsonformatter.format_body("""{"username":"leo", "password":"leo"}""", "application/json") == """{"username":"leo", "password":"leo"}"""

# Generated at 2022-06-11 23:48:41.024227
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    import httpie

    httpie.main()

# Generated at 2022-06-11 23:48:49.384191
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from collections import OrderedDict
    from httpie.plugins.formatter import JSONFormatter

    test_json_format = OrderedDict([
        ('format', True),
        ('indent', 2),
        ('sort_keys', True),
    ])

# Generated at 2022-06-11 23:48:57.118667
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    # 1. Accepts input when the destination is json
    # Also tests 1st "if" statement
    assert formatter.format_body('{"name": "httpie"}', 'json') == '{\n    "name": "httpie"\n}'

    # 2. Accepts input when the destination is text
    # Also tests 2nd "if" statement
    assert formatter.format_body('{"name": "httpie"}', 'text') == '{\n    "name": "httpie"\n}'

    # 3. Accepts input when the destination is javascript
    # Also tests 3rd "if" statement
    assert formatter.format_body('{"name": "httpie"}', 'javascript') == '{\n    "name": "httpie"\n}'

    # 4. Accepts input

# Generated at 2022-06-11 23:49:07.102654
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{
                    'format_options': {'json': {
                        'format': True,
                        'indent': 2,
                        'sort_keys': True,
                                          }},
                    'explicit_json': False
                })
    mime = "application/json"
    body = '{"msg": "Hello world!"}'
    assert json_formatter.format_body(body, mime) == \
           '{\n  "msg": "Hello world!"\n}'

# Generated at 2022-06-11 23:49:14.965184
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    assert f.format_options['json']['format']
    # Mime type is JSON, should format
    assert f.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    # Explicit JSON, should format
    assert f.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    # JSON body not formatted since mime is "text"
    assert f.format_body('{"a": 1}', 'text') != '"{\n    \"a\": 1\n}"'
    # Invalid JSON, should not format
    assert f.format_body('{"a": 1', 'text') != '{\n    "a": 1\n}'
    # Explicit JSON, should format

# Generated at 2022-06-11 23:49:20.462298
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{"
    body += '"key1":"value1",'
    body += '"key2":"value2"'
    body += "}"
    json_formatter = JSONFormatter()
    body_json = json_formatter.format_body(body, "json")
    assert body_json == '{\n    "key1": "value1",\n    "key2": "value2"\n}'

# Generated at 2022-06-11 23:49:24.470138
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{\"id\": \"123\"}"
    mime = "json"
    print(JSONFormatter(explicit_json=True, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}}).format_body(body, mime))

# Generated at 2022-06-11 23:49:27.258940
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.format_options['json']['format'] == True
    assert jf.kwargs['explicit_json'] == False


# Generated at 2022-06-11 23:49:28.399847
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == True

# Generated at 2022-06-11 23:49:32.091335
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import str
    print("test format_body")
    jf = JSONFormatter()
    r = jf.format_body('{"key": "value"}', 'application/json')
    assert(r == '{\n    "key": "value"\n}')

# Generated at 2022-06-11 23:49:40.633215
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    import json

    format_options = {'json': {'format': False}}
    kwargs = {'verbose': False}
    json_enabled = True
    formatter_plugin = FormatterPlugin(format_options, **kwargs)
    json_formatter = JSONFormatter(format_options, **kwargs)
    assert isinstance(formatter_plugin, FormatterPlugin)
    assert isinstance(json_formatter, JSONFormatter)
    assert isinstance(json_formatter, FormatterPlugin)
    assert json_formatter.enabled==json_enabled


# Generated at 2022-06-11 23:49:48.946784
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert (jsonFormatter.kwargs['color'] == False)
    assert (jsonFormatter.kwargs['colors'] == {})
    assert (jsonFormatter.kwargs['explicit_json'] == False)
    assert (jsonFormatter.format_options['json']['format'] == True)
    assert (jsonFormatter.format_options['json']['indent'] == 4)
    assert (jsonFormatter.format_options['json']['sort_keys'] == True)
    assert (jsonFormatter.enabled == True)


# Generated at 2022-06-11 23:49:56.199375
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    options = {'json':{'format': False, 'sort_keys': False, 'indent': 0}}
    json_formatter = JSONFormatter(format_options=options)
    file_path = 'mock.txt'
    with open(file_path, 'r') as f:
        body = f.read()
    body_formatted = json_formatter.format_body(body=body, mime='json')
    assert body == body_formatted, 'Test with json format: False'
    options['json']['format'] = True
    json_formatter = JSONFormatter(format_options=options)
    body_formatted = json_formatter.format_body(body=body, mime='text')
    assert body != body_formatted, 'Test with json format: True'
    assert body_form