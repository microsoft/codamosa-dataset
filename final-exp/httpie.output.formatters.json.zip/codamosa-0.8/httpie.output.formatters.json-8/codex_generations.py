

# Generated at 2022-06-11 23:48:16.132490
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
  # Test JSON formatter plugin
  json_formatter = JSONFormatter(
      format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}},
      explicit_json=False)
  assert json_formatter.format_body(
      '{"name": "httpie", "desc": "HTTPie is a CLI, cURL-like tool for humans"}', 'json') == (
          '{\n    "desc": "HTTPie is a CLI, cURL-like tool for humans", \n    "name": "httpie"\n}')

  # Test that formatter does not format an invalid JSON

# Generated at 2022-06-11 23:48:18.995521
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False,
        }
    }, explicit_json=False)
    assert formatter.format_body('{"foo": "bar"}', 'application/json') == '{\n  "foo": "bar"\n}'

# Generated at 2022-06-11 23:48:30.512449
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.formatters.colors import get_lexer

    JSONFormatter.lexer = get_lexer('JSON')
    f = JSONFormatter()

    # Valid JSON
    body = '{"hello": "world"}'
    assert f.format_body(body, '') == body

    # Invalid JSON
    body = '{"hello": "world"}abc'
    assert f.format_body(body, '') == body

    # Valid JSON with possible false-positive
    body = '{"hello": "world"}'
    assert f.format_body(body, 'text/plain') == body

    # Valid JSON with possible false-positive
    body = '{"hello": "world"}'
    assert f.format_body(body, 'text/plain') == body

    # Valid JSON with possible false-positive
    body

# Generated at 2022-06-11 23:48:34.402829
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    '''
    base on HTTPie/test/plugins/test_JSONFormatter.py
    '''
    jf = JSONFormatter(explicit_json=False)
    show = jf.format_body('{"a": 1}', 'text')
    assert show == '{\n    "a": 1\n}'

# Generated at 2022-06-11 23:48:44.210103
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"test": "pass"}'
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body(body, 'json') == body
    assert formatter.format_body(body, 'application/json') == body
    assert formatter.format_body(body, 'javascript') == body
    assert formatter.format_body(body, 'text') == body
    assert formatter.format_body('{"test-pass"}', 'json') == '"{\\"test-pass\\"}"'
    assert formatter.format_body('{"test-pass"}', 'application/json') == '"{\\"test-pass\\"}"'

# Generated at 2022-06-11 23:48:50.341289
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test = '{test_key: "test_value"}'
    format = 'application/json'
    res_test = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}).format_body(
        test, format)
    res_assert = '{\n    "test_key": "test_value"\n}'
    assert res_test == res_assert

# Generated at 2022-06-11 23:48:51.368480
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
        test = JSONFormatter()
        assert test

# Generated at 2022-06-11 23:48:57.807773
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # When JSON is valid
    formatter_options_1 = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False
        }
    }
    kwargs_1 = {'explicit_json': False}
    body = b'{ "a": "b" }'
    expected_body = '{ "a": "b" }'
    formatter = JSONFormatter(format_options=formatter_options_1, **kwargs_1)
    assert formatter.format_body(body, 'text') == expected_body

    # When JSON is invalid
    formatter_options_2 = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': False
        }
    }
    k

# Generated at 2022-06-11 23:49:04.924342
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '''
    {'foo': [1, 2, 3]}
    '''
    expected = r"""{
    "foo": [
        1, 
        2, 
        3
    ]
}""" 
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys':False}}, explicit_json=False)
    assert formatter.format_body(body=body, mime='application/json') == expected

# Generated at 2022-06-11 23:49:13.540125
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 0}', 'application/json') == '{"a": 0}'
    assert json_formatter.format_body('{"a": 0}', 'application/javascript') == '{\n    "a": 0\n}'
    assert json_formatter.format_body('{"a": 0}', 'text/json') == '{\n    "a": 0\n}'
    assert json_formatter.format_body('{"a": 0}', 'text/javascript') == '{\n    "a": 0\n}'
    assert json_formatter.format_body('{"a": 0}', 'text/plain') == '{\n    "a": 0\n}'

# Generated at 2022-06-11 23:49:19.970305
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-11 23:49:28.182524
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    # Test with invalid JSON
    body = "invalid JSON"
    mime = "json"
    assert(f.format_body(body, mime) == "invalid JSON")
    # Test with valid JSON
    body = '{"a": 1}'
    mime = "json"
    assert(f.format_body(body, mime) == '{\n  "a": 1\n}')
    # Test with valid JSON, but with an invalid mime type
    body = '{"a": 1}'
    mime = "invalid"
    assert(f.format_body(body, mime) == body)

# Generated at 2022-06-11 23:49:35.507929
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_text = '{"a":1, "b": "a"}'
    # test the explicit json
    json_formatter = JSONFormatter()
    v = json_formatter.format_body(json_text, 'application/json')
    assert v == json_text
    # not the explicit_json
    json_formatter = JSONFormatter(explicit_json=False)
    v = json_formatter.format_body(json_text, 'text/plain')
    assert v == json_text



# Generated at 2022-06-11 23:49:36.153723
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert 1 == 1

# Generated at 2022-06-11 23:49:43.500598
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Testing function format_body of class JSONFormatter
    # When the content type is json, then the json will be pretty printed
    fake_kwargs = {'explicit_json': False}
    fake_instance = JSONFormatter(**fake_kwargs)
    fake_instance.format_options = {
                                    'json': {
                                        'format': True,
                                        'indent': 4,
                                        'sort_keys': True
                                    }
                                }
    assert fake_instance.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'

    # When the content type is not json, then the json will not be pretty printed
    fake_instance = JSONFormatter(**fake_kwargs)

# Generated at 2022-06-11 23:49:50.191332
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

    assert json_formatter.format_body(
        '{"a": "b"}',
        'json'
    ) == '{' \
        '\n    "a": "b"' \
        '\n}'

    assert json_formatter.format_body(
        '{"a": "b"}',
        'notjson'
    ) == '{"a": "b"}'



# Generated at 2022-06-11 23:49:52.102450
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonformatter = JSONFormatter()
    print(jsonformatter.format_options)
    assert jsonformatter.enabled == False

# Generated at 2022-06-11 23:50:02.615057
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1, \n    "b": 2\n}', 'Error in format_body'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1, \n    "b": 2\n}', 'Error in format_body'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1, \n    "b": 2\n}', 'Error in format_body'

# Generated at 2022-06-11 23:50:09.191203
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_text = '{"foo": {"a": "A", "b": "B"}}'
    body_json = '{    "foo": {\n        "a": "A",\n        "b": "B"\n    }\n}'
    body_text_formatted = JSONFormatter(format_options={"json": {"indent": 4}}).format_body(body_text, '')
    assert body_text_formatted == body_json
    body_json_formatted = JSONFormatter(format_options={"json": {"indent": 4}}).format_body(body_json, '')
    assert body_json_formatted == body_json



# Generated at 2022-06-11 23:50:17.230533
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pretty_json_formatter = JSONFormatter(format_options=json.dumps({
      "json": {
        "format": True,
        "sort_keys": True,
        "indent": 4
      }
    }))
    
    mime = 'application/json'
    assert pretty_json_formatter.format_body('{"key2": "v2", "key": "v"}', mime) == '''{
    "key": "v",
    "key2": "v2"
}'''

    assert pretty_json_formatter.format_body('{"key": "v"}', mime) == '''{
    "key": "v"
}'''

    assert pretty_json_formatter.format_body('{"key": "v", "key2": "v2"}', mime)

# Generated at 2022-06-11 23:50:31.679167
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jf = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': None,
            'sort_keys': False,
        },
        'colors': False,
    },
    explicit_json=False)

    assert jf.format_body(body='{}', mime='json') == '{}'
    assert jf.format_body(body='{}', mime='text') == '{}'
    assert jf.format_body(body='{}', mime='javascript') == '{}'
    assert jf.format_body(body='{}', mime='json') == '{}'
    assert jf.format_body(body='', mime='json') == ''

# Generated at 2022-06-11 23:50:42.671036
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    kwargs = {
        'explicit_json': False
    }
    # Valid JSON, specified as JSON
    body_test = formatter.format_body('{"test": "value", "test2": "value2"}',
                                      'application/json', kwargs)
    assert body_test == '{\n    "test": "value", \n    "test2": "value2"\n}'
    # Valid JSON, specified as text
    body_test = formatter.format_body('{"test": "value", "test2": "value2"}',
                                      'text/plain', kwargs)
    assert body_test == '{\n    "test": "value", \n    "test2": "value2"\n}'
    # Valid JSON, specified as text with

# Generated at 2022-06-11 23:50:51.781127
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonFormatter = JSONFormatter()
    test_result = jsonFormatter.format_body("{\"test\": 0}", "json")
    assert test_result == '{\n  "test": 0\n}'
    test_result = jsonFormatter.format_body("{\"test\": 0}", "javascript")
    assert test_result == '{\n  "test": 0\n}'
    test_result = jsonFormatter.format_body("{\"test\": 0}", "text")
    assert test_result == '{\n  "test": 0\n}'
    test_result = jsonFormatter.format_body("{\"test\": 0}", "text/plain")
    assert test_result == '{\n  "test": 0\n}'

# Generated at 2022-06-11 23:50:56.649011
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    })
    body = formatter.format_body(
        '{"key":"value", "arr":[1,2,3]}', 'application/json')
    assert body == '''{
    "arr": [
        1,
        2,
        3
    ],
    "key": "value"
}'''


__all__ = ('JSONFormatter',)

# Generated at 2022-06-11 23:51:03.257113
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest

    body = '[{"mail": "email@gmail.com"}]'
    expected_body = '[\n' \
            '  {\n' \
            '    "mail": "email@gmail.com"\n' \
            '  }\n' \
            ']'

    formatter_plugin = JSONFormatter()
    result_body = formatter_plugin.format_body(body, "json")

    assert result_body == expected_body

# Generated at 2022-06-11 23:51:13.360606
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()

# Generated at 2022-06-11 23:51:16.090744
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from settings import DEFAULT
    from httpie.input import KeyValue
    JSONFormatter(KeyValue(
        DEFAULT.items(),
        '--json'
    ))

# Generated at 2022-06-11 23:51:19.095227
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(headers={})
    assert formatter._format_body(b'{"foo": "bar"}', 'application/json') == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 23:51:21.602844
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"test": "json"}'
    assert JSONFormatter().format_body(body,'json') == '{\n    "test": "json"\n}'



# Generated at 2022-06-11 23:51:26.315331
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    dummy_kwargs = {'explicit_json': True}
    formatter = JSONFormatter(dummy_kwargs)
    assert formatter.format_body('{}', '') == '{}'
    assert formatter.format_body('{"a": 1, "b": 2}', '') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:51:42.778907
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    json_formatter = JSONFormatter()
    body = '[{"name": "jill", "age": 53}]'

    # Act
    response = json_formatter.format_body(body, 'application/json')

    # Assert
    assert response == '[\n  {\n    "age": 53,\n    "name": "jill"\n  }\n]'

# Generated at 2022-06-11 23:51:47.511039
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 123}'
    mime = 'application/json'
    kwargs = {'explicit_json': False}
    json_formatter = JSONFormatter(**kwargs)
    assert json_formatter.format_body(body, mime) == '{\n    "a": 123\n}'

# Generated at 2022-06-11 23:51:48.709787
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
   assert JSONFormatter(**kwargs) is not None

# Generated at 2022-06-11 23:51:57.071631
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.formatter import BaseFormatter

    class JSONFormatter(FormatterPlugin):

        def __init__(self, **kwargs):
            kwargs['type'] = 'JSONFormatter'
            super().__init__(**kwargs)
            self.enabled = True

    options = dict(indent=2, sort_keys=True)
    # kwargs with format options
    json_formatter = JSONFormatter(indent=2, sort_keys=True)
    # kwargs without format options
    json_formatter_without_format_options = JSONFormatter(url='https://example.com')
    assert json_formatter.format_options['json'] == options
    assert json_formatter_without_format_options.format_options['json'] == dict

# Generated at 2022-06-11 23:51:59.820831
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{ "a": 1, "b": 2}', 'json') == '{\n  "a": 1, \n  "b": 2\n}'

# Generated at 2022-06-11 23:52:09.867717
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # JSON input
    body = formatter.format_body('{"a": 1}', 'json')
    assert body == '{\n    "a": 1\n}'
    # Invalid JSON input
    body = formatter.format_body('a', None)
    assert body == 'a'
    # JavaScript input
    body = formatter.format_body('{"a": 1}', 'javascript')
    assert body == '{\n    "a": 1\n}'
    # HTML input
    body = formatter.format_body('{"a": 1}', 'html')
    assert body == '{"a": 1}'
    # Unknown input
    body = formatter.format_body('{"a": 1}', None)
    assert body == '{"a": 1}'

# Generated at 2022-06-11 23:52:12.540298
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        response = """{ "name" : "My name" }"""
        inst = JSONFormatter(response)
    except:
        raise AssertionError('Failed to create JSONFormatter object')
    else:
        assert inst != None

# Generated at 2022-06-11 23:52:22.141264
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Formatted JSON"""
    # Test some of the examples from
    # http://hn.algolia.com/api
    json_formatter = JSONFormatter(format_options={},
                                   config_dir=None,
                                   stdin_isatty=False,
                                   stdout_isatty=False,
                                   format='',
                                   output_options=None,
                                   insecure=False,
                                   verify=False,
                                   proxies=None,
                                   user_agent=None,
                                   follow_redirects=False,
                                   kwargs={'explicit_json': True})
    assert json_formatter.format_body(None, None) is None
    assert json_formatter.format_body('', None) == ''

# Generated at 2022-06-11 23:52:26.769647
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format' : 'yes'}})
    try:
        JSONFormatter(format_options={'json': {'format' : 'no'}})
        assert False
    except:
        assert True

# Test JSONFormatter.format_body

# Generated at 2022-06-11 23:52:33.698458
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Given
    formatter = JSONFormatter()
    json_str = '{"a": 1, "b": "text", "c": [1, 2, 3]}'
    mime = 'application/json'

    # When
    body = formatter.format_body(json_str, mime)

    # Then
    assert body == '''{
    "a": 1,
    "b": "text",
    "c": [
        1,
        2,
        3
    ]
}'''

# Generated at 2022-06-11 23:52:57.422905
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'sort_keys': True}})

# Generated at 2022-06-11 23:53:07.683756
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a":1,"b":2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"b":2,"a":1}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "b": 2,\n    "a": 1\n}'
    body = '{"a":1,"b":2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:53:14.275505
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # create JSONFormatter object
    json_formatter = JSONFormatter()
    # test valid json string
    # this string is valid json
    string = '{"a": "b"}'
    # if format json is valid, method should not change input string
    assert json_formatter.format_body(string, '') == string
    # test invalid json string
    # this string is invalid json
    string = '{"a: "b"}'
    # if format json is invalid, method should not change input string
    assert json_formatter.format_body(string, '') == string

# Generated at 2022-06-11 23:53:15.981295
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=True)
    assert formatter.kwargs['explicit_json']


# Generated at 2022-06-11 23:53:26.930416
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    body = """
        ["foo", {
            "bar": ["baz", null, 1.0, 2, JSON],
            "qux": "quux"
        }]
    """
    mime = "application/json"
    expected_body = '\n'.join([
        "[",
        "    \"foo\",",
        "    {",
        "        \"bar\": [",
        "            \"baz\",",
        "            null,",
        "            1.0,",
        "            2,",
        "            \"JSON\"",
        "        ],",
        "        \"qux\": \"quux\"",
        "    }",
        "]"
    ])
    formatter = JSONFormatter()

# Generated at 2022-06-11 23:53:35.885937
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"foo": "bar"}'
    assert formatter.format_body(body, mime='application/json') == body
    assert "baz" in formatter.format_body('{"foo": "bar", "baz": 42}', mime='application/json')
    assert "baz" in formatter.format_body('{"foo": "bar", "baz": 42}', mime='application/javascript')
    assert "baz" in formatter.format_body('{"foo": "bar", "baz": 42}', mime='text/javascript')
    assert "baz" not in formatter.format_body('{"foo": "bar", "baz": 42}', mime='text/html')

# Generated at 2022-06-11 23:53:43.352883
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.plugins
    plugins = [p for p in httpie.plugins.__all__ if p.startswith('JSON')]
    for plugin_name in plugins:
        plugin = list(filter(lambda x: x.__name__.startswith(plugin_name),
                             httpie.plugins.get_all()))[0]()
        plugin.format_options['json']['format'] = True
        assert '\n' in plugin.format_body('{"foo": "bar"}', 'application/json')

# Generated at 2022-06-11 23:53:44.771445
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    inst = JSONFormatter()
    assert inst.enabled == True

# Generated at 2022-06-11 23:53:53.016715
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    JSON_FORMAT_OPTIONS = {
        # Note: sort_keys is set to True, i.e., it is sorted
        'sort_keys': True,
        'indent': None
    }

    json_formatter = JSONFormatter(format_options={'json': JSON_FORMAT_OPTIONS})

    json_string = '{"1":1,"2":2}'
    json_string_sorted = '{\n    "1": 1,\n    "2": 2\n}'
    json_string_sorted_indent = '{\n    "1": 1,\n    "2": 2\n}'

    json_dict = {'1':1, '2':2}

# Generated at 2022-06-11 23:53:54.269761
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter()
    assert jf.enabled

# Generated at 2022-06-11 23:54:40.955230
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin = JSONFormatter()
    assert formatter_plugin is not None

# Generated at 2022-06-11 23:54:48.494449
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with and without json token in mime
    obj = {'key': 'value'}
    body = json.dumps(obj, indent=True)
    mime_with_json = 'application/json'
    mime_without_json = 'application/vnd.api+json'
    Plugin = JSONFormatter()
    assert Plugin.format_body(body, mime_with_json) == body
    assert Plugin.format_body(body, mime_without_json) == body

    # Test with non-json body
    body = 'foo bar'
    assert Plugin.format_body(body, mime_with_json) == body

# Generated at 2022-06-11 23:54:57.529452
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False,
            format_options={'json': {
                'format': True,
                'sort_keys': False,
                'indent': 2,
            }})
    assert formatter.format_body('"hello"', 'json') == '"hello"'
    assert formatter.format_body('"hello"', 'json') == '"hello"'
    assert formatter.format_body('{}', 'json') == '{}'
    assert formatter.format_body('[]', 'json') == '[]'
    assert formatter.format_body('null', 'text') == 'null'
    assert formatter.format_body('true', 'text') == 'true'
    assert formatter.format_body('1', 'json') == '1'
    assert formatter

# Generated at 2022-06-11 23:55:05.572677
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Test data
    headers = {}
    url = 'https://example.com'
    method = 'POST'
    json_kwargs = {}
    explicit_json = False
    formatter_kwargs = {
        'include_headers': False,
        'include_bodies': True,
        'explicit_json': explicit_json,
    }
    body = ('{"foo": "bar", "an_array": [1, 2, 3, 4], "a_nested_dict":'
            ' {"nested_foo": "bar", "nested_an_array": [4, 3, 2, 1],'
            ' "nested_nested_foo": "bar"}}')

    # Check that the formatter returns an expected result
    formatter = JSONFormatter(**formatter_kwargs)
    result = form

# Generated at 2022-06-11 23:55:14.759980
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs = {'explicit_json': False}
    formatter.format_options = {
        'json': {
            'format': False,
            'sort_keys': True,
            'indent': 4
        }
    }

    assert formatter.format_body(
        '{"a": "b", "c": "d"}',
        'application/json'
    ) == '''{
    "a": "b",
    "c": "d"
}'''

    assert formatter.format_body(
        '{"a": "b", "c": "d"}',
        'mime/json'
    ) == '''{
    "a": "b",
    "c": "d"
}'''

    assert formatter.format_

# Generated at 2022-06-11 23:55:20.670348
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Create an instance of the class JSONFormatter
    jf = JSONFormatter()
    # Tests for method with type text
    # Create a json body
    body = '{\n  "key1": "value1", \n  "key2": "value2"\n}'
    # Set the content-type
    mime = 'text'
    # Call the method
    formatted_body = jf.format_body(body=body, mime=mime)
    # Check the results.
    assert body == formatted_body

# Generated at 2022-06-11 23:55:23.130495
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    assert formatter.format_body("""{
            "key": "value",
            "key2": "value2"

}""", 'json') == """{
    "key": "value",
    "key2": "value2"
}
""".strip()

# Generated at 2022-06-11 23:55:24.922055
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    result = formatter.format_body('{}', 'json')
    assert result == '{\n    \n}'

# Generated at 2022-06-11 23:55:35.258347
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_string = '{"a": 3, "b": [9, {"c": 6}, 1]}'
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': True,
                'indent': 4,
            }
        },
        explicit_json=True,
    )
    json_formatted_string = json_formatter.format_body(
        body=json_string,
        mime='json',
    )
    assert json_formatted_string != json_string

# Generated at 2022-06-11 23:55:44.558718
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with JSON as body, with and without sort_keys
    args = {
        'format_options': {
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 4
            }
        },
        'explicit_json': False
    }
    json_formatter = JSONFormatter(**args)
    json_body = '{"a":1,"b":2,"c":"three"}'
    assert json_formatter.format_body(json_body, 'application/json') == (
        '{\n' +
        '    "a": 1,\n' +
        '    "b": 2,\n' +
        '    "c": "three"\n' +
        '}'
    )