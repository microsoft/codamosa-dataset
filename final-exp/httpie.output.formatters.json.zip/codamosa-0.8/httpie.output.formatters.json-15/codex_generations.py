

# Generated at 2022-06-11 23:48:19.148545
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options = {'json': {'indent': 4, 'sort_keys': False, 'format': True}}).format_options['json']['indent'] == 4 
    # Tester med explisitt json
    assert JSONFormatter(format_options = {'json': {'indent': 4, 'sort_keys': False, 'format': True}}, kwargs={'explicit_json': True}).kwargs['explicit_json'] == True
    assert JSONFormatter(format_options = {'json': {'indent': 4, 'sort_keys': False, 'format': True}}, kwargs={'explicit_json': False}).kwargs['explicit_json'] == False

# Generated at 2022-06-11 23:48:30.586861
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from plugins import JSONFormatter
    from utils import CaseInsensitiveDict
    headers = CaseInsensitiveDict()

    # Test valid JSON
    headers['content-type'] = 'application/json'
    body = '{"test": "valid json"}'
    # Test if body is correctly formatted
    formatted_body = JSONFormatter().format_body(body, headers['content-type'])
    assert formatted_body == '{\n    "test": "valid json"\n}'

    # Test invalid JSON
    headers['content-type'] = 'application/json'
    body = '{"test": "invalid json'
    # Test if body remains unchanged
    formatted_body = JSONFormatter().format_body(body, headers['content-type'])
    assert formatted_body == '{"test": "invalid json'

    # Test

# Generated at 2022-06-11 23:48:33.678512
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin = JSONFormatter()
    body = '{"name": "value"}'
    mime = 'json'
    assert formatter_plugin.format_body(body, mime) == '{\n    "name": "value"\n}'

# Generated at 2022-06-11 23:48:35.066089
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    j = JSONFormatter()
    assert(j.enabled == False)

# Generated at 2022-06-11 23:48:44.791007
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.formatter import JSONFormatter

    format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 2}}
    kwargs = {'explicit_json': True}
    json_formatter = JSONFormatter(format_options=format_options, **kwargs)


# Generated at 2022-06-11 23:48:54.886235
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body1 = '{ "x": "1" }'
    body2 = '{ "x": "2" }'
    mime = 'text/json'
    formatter = JSONFormatter(json=None)
    assert formatter.format_body(body1, mime) == '{\n    "x": "1"\n}\n'
    assert formatter.format_body(body2, mime) == '{\n    "x": "2"\n}\n'
    # If body is not JSON, then return original body
    body3 = 'invalid JSON'
    assert formatter.format_body(body3, mime) == 'invalid JSON'
    # If body is None, then return an empty string
    body4 = None
    assert formatter.format_body(body4, mime) == ''

# Generated at 2022-06-11 23:49:05.647450
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.plugins

    httpie.plugins.__enabled_output_formatters__ = [
        'json',
    ]
    httpie.plugins.__output_formatters__ = {
        'json': JSONFormatter,
    }
    json_formatter = httpie.plugins.__output_formatters__['json']
    body = """{"tags": ["python", "json"]}"""
    assert json_formatter.format_body(
        body=body,
        mime='application/json',
    ) == body
    body = """["python", "json"]"""
    assert json_formatter.format_body(
        body=body,
        mime='application/json',
    ) == body
    body = """{"tags": ["python", "json"]}"""

# Generated at 2022-06-11 23:49:14.059956
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"foo": "bar"}'
    json_obj = json.loads(body)
    assert formatter.format_body(body, "application/json") == json.dumps(
        json_obj,
        sort_keys=False,
        ensure_ascii=False,
        indent=2
    )
    assert formatter.format_body(body, "text/javascript") == json.dumps(
        json_obj,
        sort_keys=False,
        ensure_ascii=False,
        indent=2
    )
    assert formatter.format_body(body, "text/plain") == json.dumps(
        json_obj,
        sort_keys=False,
        ensure_ascii=False,
        indent=2
    )
   

# Generated at 2022-06-11 23:49:24.511606
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_frmtr = JSONFormatter()
    chunk_of_body = "W00t!"
    mime_type = "application/json"
    formatted_body = json_frmtr.format_body(chunk_of_body, mime_type)
    assert formatted_body == "W00t!"

    # Formatter plugin should change this JSON request
    chunk_of_body = '''
        {
            "foo": "bar"
        }
    '''
    mime_type = "application/json"

# Generated at 2022-06-11 23:49:29.335013
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"hello": "world"}', 'application/json') == '{\n    "hello": "world"\n}'
    assert formatter.format_body("{ 'hello': 'world' }", 'text') == "{ 'hello': 'world' }"
    assert formatter.format_body("{ 'hello': 'world' }", 'javascript') == "{ 'hello': 'world' }"

# Generated at 2022-06-11 23:49:43.330246
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body1 = '"bar"'
    body2 = '{"baz": "qux"}'
    body3 = '{"foo": "bar", "baz": "qux"}'
    body4 = '["foo", "bar", "baz"]'

    # JSON formatter doesn't apply to non-json content type

    format_options = {
        'json': {
            'indent': 4,
            'sort_keys': False,
            'format': True,
        }
    }
    formatter = JSONFormatter(
        format_options=format_options,
        explicit_json=False,
    )

    fmt_body1 = formatter.format_body(body1, mime='application/json')
    assert fmt_body1 == body1


# Generated at 2022-06-11 23:49:52.648253
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class JSONFormatterX(JSONFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = True
            self.kwargs = {'explicit_json': True, 'headers':False}
            self.format_options = {
                'json' : {
                    'format': True,
                    'indent': 4,
                    'sort_keys': True
                }
            }
    body = '{"a": "b", "c": "d", "e": "f"}'
    assert JSONFormatterX().format_body(body, 'json') == json.dumps(json.loads(body), indent=4, sort_keys=True)

# Generated at 2022-06-11 23:50:03.296510
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    import json
    import os

    fmt = FormatterPlugin()
    json_formatter = JSONFormatter(fmt, None,
         format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            }
         }
    )


# Generated at 2022-06-11 23:50:07.963463
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.kwargs['explicit_json'] == False
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-11 23:50:16.516598
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': False
            }
        },
        explicit_json=False
    )
    mime = 'application/json'

# Generated at 2022-06-11 23:50:26.603928
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    format_options = {
        'json': {
            'format': False,
            'indent': 1,
            'sort_keys': True,
        }
    }
    # Testing valid JSON
    json_formatter = JSONFormatter(format_options=format_options, explicit_json=False)
    obj = '{"a": 1, "b": 2}'
    assert json_formatter.format_body(obj, 'json') == '{"a": 1, "b": 2}'
    assert json_formatter.format_body(obj, 'javascript') == '{"a": 1, "b": 2}'
    assert json_formatter.format_body(obj, 'text') == '{"a": 1, "b": 2}'
    format_options['json']['format'] = True
    json_formatter

# Generated at 2022-06-11 23:50:33.931850
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    
    # FormatterPlugin.__init__(self, **kwargs)
    # self.enabled = self.format_options['json']['format']
    # self.kwargs['explicit_json'] or any(token in mime for token in maybe_json)
    
    print('\n-----------------Unit Test: JSONFormatter > test_JSONFormatter_format_body -----------------')
    print('*Testing inputs*')
    # body
    print('\nbody = \'{ "foo": "bar", "baz": [1, 2, 3], "qux": true }\'')
    body = '{ "foo": "bar", "baz": [1, 2, 3], "qux": true }'
    # mime
    print('\nmime = \'json\'')
    mime = 'json'


# Generated at 2022-06-11 23:50:43.052677
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = """
{
        "num": "123",
        "str": "abc",
        "nul": null,
        "tru": true
}
    """
    expected = """
{
    "nul": null,
    "num": "123",
    "str": "abc",
    "tru": true
}
    """
    mime = 'json'
    # Instance of class JSONFormatter
    inst = JSONFormatter(format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    actual = inst.format_body(body=body, mime=mime)
    assert actual == expected


# Generated at 2022-06-11 23:50:46.690548
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": 1, "bar": [2, 3]}', 'json') == '{\n    "bar": [\n        2,\n        3\n    ],\n    "foo": 1\n}'

# Generated at 2022-06-11 23:50:53.809515
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
  json_test_formatter_plugin = JSONFormatter()
  body_for_test = "{\n 'key1' : 1,\n 'key2' : 'value2',\n 'key3' : ['a', 'b', 'c',\n 1, 2, 3]\n}"
  mime_for_test = 'json'
  assert json_test_formatter_plugin.format_body(body_for_test, mime_for_test) == body_for_test
  print("Unit test for method format_body of class JSONFormatter: good job, it works correctly.")

if __name__ == '__main__':
  test_JSONFormatter_format_body()

# Generated at 2022-06-11 23:51:10.698479
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(formatter_options={"json": {"format": True}})
    result_body = formatter.format_body('{"a": "b"}', 'json')
    assert result_body == '{\n    "a": "b"\n}'

# Generated at 2022-06-11 23:51:20.789741
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Mock object
    kwargs = {'explicit_json':False}
    # Instance of class JSONFormatter
    formatter = JSONFormatter(**kwargs)
    # Assertions
    # Case JSON
    assert formatter.format_body('{ "name" : "foo" }', 'application/json') == '{\n    "name": "foo"\n}'
    # Case Javascript
    assert formatter.format_body('{ "name" : "foo" }', 'application/javascript') == '{\n    "name": "foo"\n}'
    # Case Text
    assert formatter.format_body('{ "name" : "foo" }', 'text/plain') == '{\n    "name": "foo"\n}'
    # Case Not JSON

# Generated at 2022-06-11 23:51:21.790831
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass



# Generated at 2022-06-11 23:51:30.291009
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})

    assert json_formatter.format_body('{"zzz": 0, "aaa": 1, "bbb": 2}', 'application/json') == '{\n  "aaa": 1,\n  "bbb": 2,\n  "zzz": 0\n}'
    assert json_formatter.format_body('{"zzz": 0, "aaa": 1, "bbb": 2}', 'application/javascript') == '{\n  "aaa": 1,\n  "bbb": 2,\n  "zzz": 0\n}'

# Generated at 2022-06-11 23:51:32.805098
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter is not None


# Generated at 2022-06-11 23:51:43.233381
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}})
    assert formatter.format_body('[]', 'json') == '[]'
    assert formatter.format_body('{"a": 1}', 'json') == '{\n  "a": 1\n}'
    assert formatter.format_body('{"b": 2}', 'json') == '{\n  "b": 2\n}'
    assert formatter.format_body('[]', 'javascript') == '[]'
    formatter = JSONFormatter(explicit_json=True, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}})

# Generated at 2022-06-11 23:51:52.134471
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # <-- Setup --> #
    # Initialize JSONFormatter object with format_options
    format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }
    formatter_json = JSONFormatter(format_options=format_options, explicit_json=False)
    # Initialize JSONFormatter object with empty format_options
    formatter_empty_json = JSONFormatter(format_options={}, explicit_json=False)
    # Initialize JSONFormatter object with json key in format_options
    formatter_json_in_format_opts = JSONFormatter(format_options={'json': {}}, explicit_json=False)

    # <-- Testing --> #
    # Simple valid JSON - indent 4, sort keys, avoid unicode


# Generated at 2022-06-11 23:51:58.598681
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    obj = {
        'key1': 'value1',
        'key2': [0, 1, 2, 3],
        'key3': {'subkey1': 'subvalue1'}
    }
    body = json.dumps(obj=obj, sort_keys=True, ensure_ascii=False)
    mime = 'application/json'

    assert json.loads(body) == json.loads(formatter.format_body(body, mime))

    body = json.dumps(obj=obj, sort_keys=False, ensure_ascii=False)
    mime = 'application/json'

    assert json.loads(body) == json.loads(formatter.format_body(body, mime))


# Generated at 2022-06-11 23:52:08.653135
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    ENCODING_WINDOWS = 'windows-1251'
    ENCODING_UNICODE = 'utf-8'
    SORT_KEYS = True
    INDENT = 4

# Generated at 2022-06-11 23:52:15.493086
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Unit test for method format_body of class JSONFormatter.

    Method tested:
        - JSONFormatter.format_body
    """

    # Prepare the formatter plugin
    plugin = JSONFormatter(**{'format': True, 'explicit_json': False, 'sort_keys': False, 'indent': None})

    # Test json.
    assert plugin.format_body('{"data": 42}', 'application/json') == '{"data": 42}'

    # Test javascript.
    assert plugin.format_body('{"data": 42}', 'application/javascript') == '{"data": 42}'

    # Test text.
    assert plugin.format_body('{"data": 42}', 'text/plain') == '{"data": 42}'

    # Test invalid json.

# Generated at 2022-06-11 23:52:37.882637
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for the case of valid json
    valid_json = '{"message": "Hello World!"}'
    valid_mime = 'json'
    desired_result = json.dumps(
        obj=json.loads(valid_json),
        sort_keys=True,
        ensure_ascii=False,
        indent=4
    )
    actual_result = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False
    ).format_body(body=valid_json, mime=valid_mime)
    assert actual_result == desired_result
    # Test for the case of valid json with explicit_json as True

# Generated at 2022-06-11 23:52:46.333876
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import JSONFormatter
    from httpie.compat import is_windows
    from httpie.plugins.builtin import JSONPlugin

    # Given
    format = JSONPlugin()  # Using JSONPlugin as a mock
    formatter = JSONFormatter(format_options=format.options, raw_fallback=None)
    formatter.enabled = True

    # When
    valid_json_body = '[{"key": "value"}]'
    valid_formatted_json_body = '[\n    {\n        "key": "value"\n    }\n]'
    invalid_json_body = '[{key: value}]'
    invalid_json_body_escaped = '[{key: value}]' if is_windows else '[{key: value}]' # noqa: E501

# Generated at 2022-06-11 23:52:56.853374
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 1, 'sort_keys': True}}) \
        .format_body(body='{"a":1, "b":2}', mime='json') == '{\n "a": 1,\n "b": 2\n}'
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}}) \
        .format_body(body='{"b":2, "a":1}', mime='json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 1, 'sort_keys': True}}) \
        .format_

# Generated at 2022-06-11 23:53:07.110699
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # A method from JSONFormatter class
    # returns a string after formatting with json

    # Test 1
    json_body = '{   "name": "haris",   "lastname": "fatykhov" }'
    mime = 'json'
    json_formatter = JSONFormatter()
    assert (json_formatter.format_body(json_body, mime)) == '{ "name": "haris", "lastname": "fatykhov" }'

    # Test 2
    json_body = '{   "name": "haris",   "lastname": "fatykhov" }'
    mime = 'text'
    json_formatter = JSONFormatter()

# Generated at 2022-06-11 23:53:12.663378
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()

    # Case 1: JSON format, json keyword
    body = '[{"name": "john", "age": 21}, {"name": "jane", "age": 24}]'
    mime = 'json'
    expected = '''[
    {
        "age": 21,
        "name": "john"
    },
    {
        "age": 24,
        "name": "jane"
    }
]'''
    assert formatter.format_body(body, mime) == expected

    # Case 2: JSON format, javascript keyword
    body = '[{"name": "john", "age": 21}, {"name": "jane", "age": 24}]'
    mime = 'javascript'

# Generated at 2022-06-11 23:53:22.097354
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for an empty body
    b = JSONFormatter()
    assert(b.format_body("", "application/json") == "")
    # Test for a body that doesn't need to be formatted
    assert(b.format_body("{}", "application/json") == "{}")
    # Test for a body that needs to be formatted
    assert(b.format_body("{}", "javascript") == "{\n}")
    # Test for a body that needs to be formatted with sort_keys
    assert(b.format_body("{\"c\":3,\"a\":1,\"b\":2}", "text") == "{\n    \"a\": 1,\n    \"b\": 2,\n    \"c\": 3\n}")
    # Test for a body that should not be formatted

# Generated at 2022-06-11 23:53:30.540129
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    assert f.format_body(body='{"a": "b"}', mime='json') == '{\n    "a": "b"\n}'
    assert f.format_body(body='{"a": "b"}', mime='javascript') == '{\n    "a": "b"\n}'
    assert f.format_body(body='{"a": "b"}', mime='text') == '{\n    "a": "b"\n}'
    assert f.format_body(body='{"a": "b"}', mime='text/html') == '{"a": "b"}'
    assert f.format_body(body='{"a": "b"}', mime='application/unknown') == '{"a": "b"}'

# Generated at 2022-06-11 23:53:38.505484
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    BOOLEAN = False
    input_format_option = {
        'json': {
            'format': BOOLEAN,
            'indent': 2,
            'sort_keys': BOOLEAN,
        },
    }
    formatter = JSONFormatter(format_options=input_format_option)

    # Test invalid json
    input_body = 'abc'
    expected_result = 'abc'
    output_body = formatter.format_body(body=input_body, mime='json')
    assert output_body == expected_result

    input_body = '{"key":"value"}'
    expected_result = input_body
    output_body = formatter.format_body(body=input_body, mime='json')
    assert output_body == expected_result


# Generated at 2022-06-11 23:53:48.776761
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin_kwargs = {'no_color': True, 'explicit_json': False}
    content_type = 'text'
    json_body = '{"x": "y"}'
    non_json_body = 'no-json'

    # Json body data
    json_formatter = JSONFormatter()
    json_formatted = json_formatter.format_body(json_body, content_type)
    assert json.loads(json_formatted) == json.loads(json_body)

    # Non json body data
    non_json_formatter = JSONFormatter()
    non_json_formatted = non_json_formatter.format_body(non_json_body, content_type)
    assert non_json_formatted == non_json_body

# Generated at 2022-06-11 23:53:57.987515
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    from httpie.plugins import FormatterPlugin

    class JSONFormatter(FormatterPlugin):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['json']['format']

        def format_body(self, body: str, mime: str) -> str:
            maybe_json = [
                'json',
                'javascript',
                'text',
            ]
            if (self.kwargs['explicit_json']
                    or any(token in mime for token in maybe_json)):
                try:
                    obj = json.loads(body)
                except ValueError:
                    pass  # Invalid JSON, ignore.

# Generated at 2022-06-11 23:54:21.532669
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert False

# Generated at 2022-06-11 23:54:26.475891
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(indent=2, sort_keys=False, explicit_json=False)
    body = '{"a": "b", "c": "d"}'
    mime = 'json'
    assert formatter.format_body(body=body, mime=mime) == '{\n  "a": "b",\n  "c": "d"\n}'

# Generated at 2022-06-11 23:54:31.963913
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    valid_json = {
        "key": "value",
        "key2": "value2",
        "key3": "value3",
        "key4": "value4",
        "key5": "value5"
    }
    invalid_json = "foo"
    f = JSONFormatter()
    assert [valid_json, valid_json] == [json.loads(f.format_body(json.dumps(valid_json), 'json'))]
    assert [invalid_json, invalid_json] == [f.format_body(invalid_json, 'json')]

# Generated at 2022-06-11 23:54:35.303010
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
	formatter = JSONFormatter()
	assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'

# Generated at 2022-06-11 23:54:39.714513
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = """
{"a": "b", "c": "d"}
    """
    mime = 'json'
    formatter = JSONFormatter(format_options={'json': {'format': 1, 'sort_keys': 1, 'indent': 4}})
    body_formatted = formatter.format_body(body, mime)
    assert body != body_formatted

# Generated at 2022-06-11 23:54:42.441040
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    content_type = 'json'
    body = '{"key": "value"}'
    formatter = JSONFormatter()
    assert formatter.format_body(body, content_type) == body

# Generated at 2022-06-11 23:54:47.261903
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    formatter = JSONFormatter()
    formatter.enabled = True
    body = '{"param1":"value1","param2":"value2"}'
    mime = 'application/json'
    expected_result = body
    # Act
    result = formatter.format_body(body, mime)
    # Assert
    assert result == expected_result



# Generated at 2022-06-11 23:54:52.727024
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # Test that invalid JSON is not formatted
    assert ['null', 2] == json.loads(formatter.format_body('["null", 2]', 'json'))

    # Test that body is formatted with indent=4 and sort_keys=true
    assert '{\n    "a": 1,\n    "b": 2\n}' == formatter.format_body('{"b": 2, "a": 1}', 'json')
    
    # Test that body is not formatted if indent=0 and sort_keys=false
    assert '{"b": 2, "a": 1}' == formatter.format_body('{"a": 1, "b": 2}', 'json')

# Generated at 2022-06-11 23:54:54.730989
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"foo": 42}', 'application/json')

# Generated at 2022-06-11 23:55:03.238511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, json={'format': True})

    # Test JSON format
    body = '{"test": "tests"}'
    mime = 'application/json'
    body = formatter.format_body(body, mime)
    assert body == '{\n    "test": "tests"\n}'

    # Test that non-JSON responses are not modified
    body = 'blah blah'
    mime = 'text/plain'
    body = formatter.format_body(body, mime)
    assert body == 'blah blah'

    # Test that invalid JSON responses are not modified
    body = '{"test": "tests'
    mime = 'application/json'
    body = formatter.format_body(body, mime)

# Generated at 2022-06-11 23:55:55.838140
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # if body is json, format_body should return the body itself
    assert formatter.format_body('{}', 'application/json') == '{}'
    # if the body is not json, format_body should return
    # the body itself
    assert formatter.format_body('{', 'text') == '{'

# Generated at 2022-06-11 23:56:04.604092
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    input_body = ('{"asd":"das", "dsa": true, "number": 3.14}')
    expected_body = ('{\n'
                     '    "dsa": true,\n'
                     '    "asd": "das",\n'
                     '    "number": 3.14\n'
                     '}')
    mock_kwargs = {'explicit_json': False}
    mock_format_options = {'json': {'format': True,
                                    'indent': 4,
                                    'sort_keys': True}}
    instance = JSONFormatter(**mock_kwargs)
    instance.format_options = mock_format_options
    instance.enabled = True
    actual_body = instance.format_body(input_body, 'json')
    assert expected_body == actual_

# Generated at 2022-06-11 23:56:09.745134
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Case: Object with 3 properties, one is array of three elements.
    test_input_OK_1 = '''
    {
        "list": [
            1,
            2,
            3
        ],
        "stringProperty": "string value",
        "boolProperty": true
    }
    '''

    expected_output_OK_1 = '''
    {
        "boolProperty": true,
        "list": [
            1,
            2,
            3
        ],
        "stringProperty": "string value"
    }
    '''

    # Case: JSON object, with non-ASCII characters and '," in substr

# Generated at 2022-06-11 23:56:13.646155
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    httpie = JSONFormatter(format_options={"json": {"format": False, "sort_keys": True, "indent": 2}},
                           explicit_json=False,
                           headers=None)
    httpie.format_body("{\"a\":1}", "json") == '{"a": 1}'

# Generated at 2022-06-11 23:56:21.822492
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Setup
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import JSONFormatter
    from httpie.core import main
    import json
    import sys

    no_ansi_colors = is_windows() or (not sys.stdout.isatty())
    plugin_manager.register(JSONFormatter)
    # Set args
    args = ['-f', 'json', '--body=raw']
    # Set env
    env = {}
    # Set stdout and stderr
    stdout = io.StringIO()
    stderr = io.StringIO()
    # Set input
    input_ = io.StringIO()


# Generated at 2022-06-11 23:56:30.468442
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:56:34.935338
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'application/json'
    body = '{"foo": "bar", "baz": 42}'

    res = JSONFormatter(color=False, explicit_json=False, ignore_stdin=True).format_body(body, mime)

    expected = '{\n    "baz": 42, \n    "foo": "bar"\n}'
    assert res == expected

# Generated at 2022-06-11 23:56:37.567215
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    fp = JSONFormatter(explicit_json=False)
    assert fp.format_body(b'{"hello": "world"}', 'application/json') == '{"hello": "world"}'
# end Unit test

# Generated at 2022-06-11 23:56:45.648704
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Test if invalid JSON is not formatted
    test_json = '{"key": "value}'
    assert(test_json == JSONFormatter(format_options={'json': {'format' : True}}).format_body(test_json, 'application/json'))

    # Test if invalid JSON is not formatted, even if the format is explicity set
    test_json = '{"key": "value}'
    assert(test_json == JSONFormatter(format_options={'json': {'format' : True}}, explicit_json=True).format_body(test_json, 'application/json'))

    # Test if valid JSON is not formatted if the JSON format option is set to False
    test_json = '{"key": "value"}'

# Generated at 2022-06-11 23:56:48.520089
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('abc', 'json') == '"abc"'
    assert JSONFormatter(explicit_json=True).format_body('abc', 'text') == '"abc"'


Plugin = JSONFormatter