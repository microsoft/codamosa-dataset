

# Generated at 2022-06-11 23:48:12.407674
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    fp = JSONFormatter(**{
        'format_options': dict(
            json=dict(
                format=True,
                sort_keys=True,
                indent=4,
            ),
        ),
        'explicit_json': False,
    })
    assert isinstance(fp, JSONFormatter)

# Generated at 2022-06-11 23:48:21.453685
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(kwargs={'explicit_json': False})
    body = '{"a": 1}'
    assert formatter.format_body(body=body, mime='json') == '{\n    "a": 1\n}'
    assert formatter.format_body(body=body, mime='javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body(body=body, mime='text') == '{\n    "a": 1\n}'
    assert formatter.format_body(body='invalid json', mime='text') == 'invalid json'
    assert formatter.format_body(body='invalid json', mime='json') == 'invalid json'


# Generated at 2022-06-11 23:48:22.509548
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
	assert JSONFormatter is not None

# Generated at 2022-06-11 23:48:24.264674
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    a = JSONFormatter()
    assert a.format_body('a', '') == 'a'


# Generated at 2022-06-11 23:48:32.883074
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '[{"text": "i don\'t like", "id": "1"}, {"text": "very much", "id": "2"}]'
    mime = 'json'

    obj = json.loads(body)
    sort_keys = False
    ensure_ascii = False
    indent = False
    expected = json.dumps(
        obj=obj,
        sort_keys=sort_keys,
        ensure_ascii=ensure_ascii,
        indent=indent
    )

    formatter = JSONFormatter(explicit_json=True, format_options={'json': {'format': True, 'sort_keys': sort_keys, 'indent': indent}})

    assert formatter.format_body(body, mime) == expected

    body = '<xml>'

# Generated at 2022-06-11 23:48:38.187109
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jsonFormatter = JSONFormatter(format_options={
        'json':
            {
                'format': False,
                'indent': 2,
                'sort_keys': True
            }
    })

    assert not jsonFormatter.enabled
    assert jsonFormatter.format_options['json']['indent'] == 2
    assert jsonFormatter.format_options['json']['sort_keys'] is True



# Generated at 2022-06-11 23:48:42.780321
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.input import ParseError
    from httpie.plugins import FormatterPluginManager
    from httpie.plugins.builtin import FormatterPlugin
    from pygments import highlight
    from pygments.formatters import TerminalTrueColorFormatter
    from pygments.lexers import HttpLexer
    from pygments.style import Style
    from tests.constants import BIN_FILE_PATH
    from tests.conftest import isatty

    class TestStyle(Style):
        styles = {}

    FormatterPlugin.__init__ = lambda self: None
    FormatterPluginManager.__init__ = lambda self: None
    JSONFormatter.__init__ = lambda self: None
    JSONFormatter.format_body = lambda self, body, mime: body
    highlight = lambda data, lexer, formatter: data

# Generated at 2022-06-11 23:48:49.215685
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from httpie.plugins import JSONFormatter
    format_options = {
        "json": {
            "format": True,
            "indent": 2,
            "sort_keys": False
        }
    }
    json_formatter = JSONFormatter(format_options)

    body = ''
    mime = ''
    assert json_formatter.format_body(body, mime) == ''

    body = '"foo": "bar"'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '"foo": "bar"'

    body = '"foo": "bar"'
    mime = 'application/javascript'
    assert json_formatter.format_body(body, mime) == '"foo": "bar"'

   

# Generated at 2022-06-11 23:48:53.043670
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from . import FormatterPluginTestCase
    class TestJSONFormatter(FormatterPluginTestCase):
        plugin_name = 'JSONFormatter'
        plugin_class = JSONFormatter
    TestJSONFormatter().run()

# Generated at 2022-06-11 23:49:01.572235
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(kwargs={'explicit_json': False}, format_options={'json': {'sort_keys': False, 'indent': None}})
    assert(formatter.format_body('{"foo": "bar"}', 'application/json') == '{"foo": "bar"}')
    assert(formatter.format_body('{"foo": "bar"}', 'application/javascript') == '{"foo": "bar"}')
    assert(formatter.format_body('{"foo": "bar"}', 'text/plain') == '{"foo": "bar"}')
    assert(formatter.format_body('invalid', 'text/plain') == 'invalid')

# Generated at 2022-06-11 23:49:08.695340
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from testing.plugins import JSONPluginTest

    for test in JSONPluginTest.TESTS:
        json_formatter = JSONFormatter(
            format_options={'json': test['options']},
            **test['kwargs']
        )
        assert json_formatter.format_body(test['input'], 'application/json') == test['expected']

# Generated at 2022-06-11 23:49:15.858230
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, body: str, mime: str) -> str:
            return body

    # Test simple text
    text = 'simple text'
    formatter_plugin = TestFormatterPlugin(
        format_options={},
        **{'explicit_json': False})
    assert text == formatter_plugin.format_body(text, mime='text/plain')

    # Test simple JSON
    json_text = '{"name": "Baptiste", "age": 25}'
    formatter_plugin = TestFormatterPlugin(
        format_options={},
        **{'explicit_json': False})
    assert json_text == formatter_plugin.format_body(json_text, mime='application/json')

    # Test simple JSON
    json_

# Generated at 2022-06-11 23:49:26.235035
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test formatter JSONFormatter method format_body
    # Test with default parameters
    # Test with enabled option
    options = {'verify': True, 'allow-redirects': True, 'json': {'sort_keys': False, 'indent': 4, 'format': True}, 'timeout': None, 'output': 'stdout', 'print_headers': True, 'style': 'solarized', 'colors': True, 'headers': {}, 'stream': True, 'download': False, 'output-__file__': None, 'download-__file__': None, 'output-to': None, 'output-dir': None, 'download-dir': None, 'output-ascii': None}
    kwargs = {'explicit_json': True, 'headers': {}}

# Generated at 2022-06-11 23:49:29.201475
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_string = """{"b": [2, 3], "a": 1}"""
    formatter = JSONFormatter(format_options={})
    assert formatter.format_body(body=json_string, mime='json') == json_string


# Generated at 2022-06-11 23:49:32.920508
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = json_formatter.format_body('{"foo": "bar"}', 'json')
    assert body == '{\n    "foo": "bar"\n}'


# Generated at 2022-06-11 23:49:42.004813
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(format_options={"json": {"format": True, "sort_keys": True, "indent": 2}})
    # invalid json
    assert 'foo' == f.format_body('foo', 'json')
    assert 'foo' == f.format_body('foo', 'javascript')
    assert 'foo' == f.format_body('foo', 'text')
    # no json, but requested
    assert 'foo' == f.format_body('foo', 'html')
    assert '{"foo": bar}' == f.format_body('{"foo": "bar"}', 'json')
    assert '{"foo": bar}' == f.format_body('{"foo": "bar"}', 'javascript')
    assert '{"foo": bar}' == f.format_body('{"foo": "bar"}', 'text')

# Generated at 2022-06-11 23:49:52.436546
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.core import build_request
    from httpie.plugins import FormatterPluginManager, builtin_formatter_plugins
    from httpie.client import CLIClient, CLIClientRequest
    from httpie.input import ParseError
    from httpie.context import Environment
    from httpie.exitstatus import ExitStatus, ExitStatusError
    from httpie import __main__
    formatter_plugin_manager = FormatterPluginManager(
        classes=builtin_formatter_plugins()
    )
    # test_option = __main__.HTTPiePlugin(
    #     plugin_manager=formatter_plugin_manager
    # )

# Generated at 2022-06-11 23:49:58.893277
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.formatters import JSONFormatter
    formatter = JSONFormatter(None, None)
    assert formatter.format_body('{ "a": 0, "b": 1 }', 'application/json') == '{ "a": 0, "b": 1 }'
    assert formatter.format_body('{"a":0,"b":1}', 'text/javascript') == '{\n  "a": 0,\n  "b": 1\n}'

# Generated at 2022-06-11 23:50:07.800283
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.core import main
    from httpie.cli import get_res_body

    # Given a request with a response body like
    # {"test": [1,2,3]}
    args = [
        '--json-format=json',
        '--json-sort-keys',
        '--json-indent=0',
        'GET',
        'https://api.github.com/users/octocat/orgs'
    ]
    expected = '{"test":[1,2,3]}'


    # When formatter is a JSONFormatter instance
    # And when body is formatted
    class FakeStream(object):
        def write(self, txt):
            pass

        def flush(self):
            pass


# Generated at 2022-06-11 23:50:16.407006
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from pluginmanager import PluginManager
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    import pytest
    import os
    import tempfile
    # Since we are using a temporary file, we need to make
    # sure that it is removed when it goes out of scope.
    @pytest.fixture(autouse=True)
    def setup(request):
        with tempfile.NamedTemporaryFile("w+") as conf:
            conf.write("""
            json:
                format: True
                indent: 4
                sort_keys: True
            """)
            conf.flush()  # Make sure the configuration is written to file
            manager = PluginManager(conf.name)
            manager.add_plugin_class(FormatterPlugin)
            manager.add_

# Generated at 2022-06-11 23:50:28.809005
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{'format_options':{'json':{'format':True,'indent':4,'sort_keys':False}}})
    raw_body = '{"a": 1, "b": 2, "invalid": true}'
    formatted_body = json_formatter.format_body(raw_body, 'json')
    assert formatted_body == '{\n    "a": 1,\n    "b": 2,\n    "invalid": true\n}'
    raw_body = '{"a": 1, "b": 2, "invalid": true}'
    formatted_body = json_formatter.format_body(raw_body, 'javascript')

# Generated at 2022-06-11 23:50:39.563162
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    },
        explicit_json=False)
    mime = 'application/json'
    body = b'{"a": ["b", 1]}'
    assert formatter.format_body(body, mime) == '{\n  "a": [\n    "b",\n    1\n  ]\n}'
    body = b'{"a": ["b"]'
    assert formatter.format_body(body, mime) == '{"a": ["b"]'
    mime = 'application/javascript'

# Generated at 2022-06-11 23:50:43.269380
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Create an instance of class JSONFormatter
    json_formatter = JSONFormatter(kwargs={'explicit_json': False})

    # The first object is a valid json body, the second is not
    json_body = '{"key": "value"}'
    text_body = "Hello World!"

    # The first object should be formatted, the second not
    assert json_formatter.format_body(json_body, 'application/json') == '{\n    "key": "value"\n}'
    assert json_formatter.format_body(text_body, 'text/plain') == 'Hello World!'

# Generated at 2022-06-11 23:50:52.336398
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.formatter import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from collections import namedtuple
    json_formatter = JSONFormatter(
        stdout=None,
        stdin=None,
        format_options = {'json': {'indent': 2}},
        format='json',
        explicit_json=False,
        colors=True,
        style_default=True,
        style=None,
        styles=None,
        download_dir=None,
        output_file=None,
        output_dir=None,
        output_options=None,
        download_filename=None,
        debug=False,
        output_stream_factory=None
    )
    body_for_test = '{"first": 1, "second": 2}'
    response = namedtuple

# Generated at 2022-06-11 23:50:54.458780
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    ff = JSONFormatter()
    assert (ff.format_body(
        body='{"test": "test_body"}',
        mime='application/json'
    ) == '{\n    "test": "test_body"\n}')



# Generated at 2022-06-11 23:50:59.258141
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    bar = b'bar'
    foo = b'''
        {
            "foo":
                {
                    "bar": "baz"
                }
        }
    '''
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': False, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body(foo, 'application/json') == foo.decode()
    assert formatter.format_body(bar, 'application/json') == bar.decode()
    formatter = JSONFormatter(explicit_json=True, format_options={'json': {'format': False, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body(foo, 'application/json') == foo.decode()

# Generated at 2022-06-11 23:51:08.348034
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    # test with binary
    body_string = '{"metadata": {"name": "foo", "labels": {"tier": "frontend"}}}'
    mime = 'json'
    result = json_formatter.format_body(body=body_string, mime=mime)
    expected = '{\n    "metadata": {\n        "labels": {\n            "tier": ' \
               '"frontend"\n        },\n        "name": "foo"\n    }\n}'
    assert result == expected
    # test without binary
    body_string = '{"metadata": {"name": "foo", "labels": {"tier": "frontend"}}}'
    mime = 'application/yaml'

# Generated at 2022-06-11 23:51:14.686164
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Input
    body = '{"test": "value"}'
    mime = 'application/json'

    # Output
    s = '{\n    "test": "value"\n}'

    # Unit test.
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body(body, mime) == s

# Generated at 2022-06-11 23:51:24.823110
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from pytest import raises
    fp = JSONFormatter(kwargs={'explicit_json':True})

    # JSON object
    assert fp.format_body('{"a":1}', 'json') == '{\n    "a": 1\n}'

    # JSON array
    assert fp.format_body('["a",1]', 'json') == '[\n    "a",\n    1\n]'

    # JSON object as Javascript
    assert fp.format_body('{"a":1}', 'javascript') == '{\n    "a": 1\n}'

    # This one is invalid JSON
    with raises(ValueError):
        fp.format_body('{"1:1}', 'json')

    # This one is invalid JSON as JavaScript
    with raises(ValueError):
        fp.format

# Generated at 2022-06-11 23:51:27.309435
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body('{"test":"test"}', 'test') == 'test'
    assert JSONFormatter.format_body('{"test":"test"}', 'test') == 'test'
    assert JSONFormatter.format_body('{"test":"test"}', 'test') == 'test'

# Generated at 2022-06-11 23:51:39.658105
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body('not json', 'json') == 'not json'
    assert JSONFormatter.format_body('{"key": "value"}', 'json') == '{\n    "key": "value"\n}'
    assert JSONFormatter.format_body('{"key": "value"}', 'text') == '{\n    "key": "value"\n}'
    assert JSONFormatter.format_body('{"key": "value"}', 'javascript') == '{\n    "key": "value"\n}'

# Generated at 2022-06-11 23:51:46.475907
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": "abc", "b": "bcd"}'
    mime = 'application/json'
    explicit_json = False
    format_options = {
        'json': {
            'format': False,
            'sort_keys': False,
            'indent': 4
        },
        'styles': {
            'colors': True,
            'kv': {
                'key': True,
                'key_bg': None,
                'key_fg': None,
                'value': True,
                'value_bg': None,
                'value_fg': None
            }
        },
        'prettify': False
    }
    expected = '{"a": "abc", "b": "bcd"}'

# Generated at 2022-06-11 23:51:54.283379
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    formatter = JSONFormatter()

    # json
    json_content = {
        "http": "HTTP/2.0",
        "url": "http://httpie.org",
        "headers": {
            "content-type": "application/json"
        },
        "body": {
            "github": "https://github.com/jakubroztocil/httpie"
        }
    }
    formatter.format_body(json.dumps(json_content), "application/json")

    # javascript

# Generated at 2022-06-11 23:51:56.105155
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass


plugin_class = JSONFormatter

if __name__ == '__main__':
    test_JSONFormatter_format_body()

# Generated at 2022-06-11 23:52:05.907742
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from io import BytesIO
    from httpie.plugins import FormatterPlugin
    import json
    import httpie.output.formatters.json

    # Define an instance of class JSONFormatter.
    json_formatter: FormatterPlugin = httpie.output.formatters.json.JSONFormatter()

    # Try to format '{"valid": "json"}'
    # as JSON.
    body: str = '{"valid": "json"}'
    mime: str = 'httpie.output.formatters.json.JSONFormatter.test_JSONFormatter_format_body.mime'
    assert json_formatter.format_body(
        body=body,
        mime=mime
    ) == '''{
    "valid": "json"
}'''

    # Try to format '{"valid": "json"}'

# Generated at 2022-06-11 23:52:08.068159
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"foo":"bar"}'
    mime = 'content-type'
    assert formatter.format_body(body, mime) == body

# Generated at 2022-06-11 23:52:12.505353
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=True, format=True)
    test_string = '{"json": true}'
    assert formatter.format_body(test_string, 'json') == test_string
    assert formatter.format_body(test_string, 'text') == test_string
    assert formatter.format_body(test_string, 'javascript') == test_string


# Generated at 2022-06-11 23:52:22.098861
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs = {'explicit_json': True}
    json_formatter.format_options = {'json': {
        'format': True, 'indent': 2, 'sort_keys': True}}
    json_formatter.default_options = {'json': {
        'format': True, 'indent': 2, 'sort_keys': True}}
    json_formatter.enabled = True

    # Test without indentation
    json_formatter.format_options = {'json': {
        'format': True, 'indent': None, 'sort_keys': True}}
    body = '[{"a": "b"}, {"a": "c"}]'
    expected_body = '[{"a": "b"}, {"a": "c"}]'
    assert json_formatter

# Generated at 2022-06-11 23:52:24.822950
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(None, None).format_body('{"test": "json"}', 'json') == '{\n    "test": "json"\n}'

# Generated at 2022-06-11 23:52:35.611288
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json = False, format_options = {'json': {'format': True}})
    mime = "application/json"
    body = """
    {
        "firstname": "John",
        "lastname": "Doe",
        "age": 30,
        "address": {
            "street": "Main Street",
            "city": "New York",
            "state": "NY",
            "zip": 10021
        },
        "phoneNumbers": [
            {
                "type": "home",
                "number": "212 555-1234"
            },
            {
                "type": "mobile",
                "number": "646 555-4567"
            }
        ],
        "children": null
    }
"""

# Generated at 2022-06-11 23:52:54.972295
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test if the method formats a valid JSON string
    test_JSON1 = '{ "test": 10 }'

    assert(JSONFormatter(format_options={"json":{"format": True,"indent": 2,"sort_keys": True}}).format_body(test_JSON1, "json") == '{\n  "test": 10\n}')


    # Test if the method formats a valid JSON string with a different mime type than "json"
    test_JSON2 = '{ "test": 10 }'

    assert(JSONFormatter(format_options={"json":{"format": True,"indent": 2,"sort_keys": True}}).format_body(test_JSON2, "javascript") == '{\n  "test": 10\n}')

    # Test if the method formats a valid JSON string with a different mime type than "json"


# Generated at 2022-06-11 23:53:05.350725
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"3": "value", "2": "value", "1": "value"}'
    mime = 'text/json'
    kwargs = {'explicit_json':False}
    options = {
        "json": {
            "format": True,
            "indent": 2,
            "sort_keys": True
        }
    }
    assert JSONFormatter(kwargs=kwargs, format_options=options).format_body(body=body, mime=mime) == '{\n  "1": "value", \n  "2": "value", \n  "3": "value"\n}'
    assert body != '{\n  "1": "value", \n  "2": "value", \n  "3": "value"\n}'

# Generated at 2022-06-11 23:53:06.804180
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('', '') == ''
    # insert assert
    # insert assert

# Generated at 2022-06-11 23:53:09.992297
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter(**{'explicit_json': True, 'format_options':
                            {'json': {'format': True, 'indent': 2,
                                      'sort_keys': True}}}).format_body(
        '{"a": 1}', 'text/javascript'
    ) == '{\n  "a": 1\n}'

# Generated at 2022-06-11 23:53:14.563907
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_string = '{"id":1, "name": "John"}'

    formatter = JSONFormatter(
        indent=4,
        sort_keys=True,
        format=True
    )

    assert formatter.format_body(body=json_string, mime='json') == \
           '{\n' \
           '"id": 1,\n' \
           '"name": "John"\n' \
           '}'

# Generated at 2022-06-11 23:53:18.906979
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    p = JSONFormatter()
    example_json = json.dumps(obj={'key': 'value'})
    example_text = 'bla'
    assert p.format_body(example_json, 'json') == example_json
    assert p.format_body(example_text, 'text') == example_text
    assert p.format_body(example_json, 'other') == example_json

# Generated at 2022-06-11 23:53:27.455475
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Create formatter
    formatter = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 2,
        }
    })

    # Test if body is formatted correctly
    assert formatter.format_body(
        body='{"c": 3, "a": 1, "b": 2}',
        mime='none'
    ) == '{\n  "a": 1,\n  "b": 2,\n  "c": 3\n}'

# Generated at 2022-06-11 23:53:36.515657
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    def _json_formatter(body: str, mime: str) -> str:
        return JSONFormatter().format_body(body, mime)

    assert _json_formatter('{}', 'json') == '{}'
    assert _json_formatter('{"foo": "bar"}', 'json') == '{\n' \
                                                        '    "foo": "bar"\n' \
                                                        '}'
    assert _json_formatter('{"foo": "bar"}', 'text/json') == '{\n' \
                                                             '    "foo": "bar"\n' \
                                                             '}'
    assert _json_formatter('{"foo": "bar"}', 'text/javascript') == '{\n' \
                                                                   '    "foo": "bar"\n'

# Generated at 2022-06-11 23:53:47.280646
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    kwargs = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': False
        },
        'explicit_json': True
    }
    json_formatter = JSONFormatter(**kwargs)
    obj = "{'a':1,'b':2}"
    assert json_formatter.format_body(body=obj, mime="json") == \
        '''{\n    "a": 1,\n    "b": 2\n}'''
    assert json_formatter.format_body(body=obj, mime="text") == \
        '''{\n    "a": 1,\n    "b": 2\n}'''
    assert json_formatter.format_body(body="a", mime="text") == "a"

# Generated at 2022-06-11 23:53:56.495778
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.input import ParseError

    class JSONFormatter1(JSONFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.kwargs = kwargs

    jsonFormatter = JSONFormatter1(
        format_options={
            'json': {
                'format': True,
                'indent': None,
                'sort_keys': False
            }
        }
    )

    tests = [
        # invalid json
        ('invalidjson', 'invalidjson'),
        # valid json
        ('{"key": "value"}', '{\n    "key": "value"\n}'),
    ]

    for test in tests:
        res = jsonFormatter.format_body(test[0], None)