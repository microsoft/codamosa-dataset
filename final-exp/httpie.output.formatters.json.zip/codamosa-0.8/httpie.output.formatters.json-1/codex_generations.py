

# Generated at 2022-06-11 23:48:17.900569
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:48:24.089877
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:48:32.165321
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = json_formatter.format_body('{"a": "b"}', 'json')
    assert body == '{\n    "a": "b"\n}'
    body = json_formatter.format_body('{"a": "b"}', 'javascript')
    assert body == '{\n    "a": "b"\n}'
    body = json_formatter.format_body('{"a": "b"}', 'text')
    assert body == '{\n    "a": "b"\n}'
    body = json_formatter.format_body('{"a": "b"}', 'html')
    assert body == '{"a": "b"}'

# Generated at 2022-06-11 23:48:35.872569
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == False
    assert formatter.format_options['json']['indent'] == None
    assert formatter.format_options['json']['sort_keys'] == False


# Generated at 2022-06-11 23:48:45.401001
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import __version__ as httpie_version
    from httpie.plugins import __version_info__ as httpie_version_info
    from httpie import __version__ as httpie_parent_version
    from httpie import __version_info__ as httpie_parent_version_info
    fmt = JSONFormatter(httpie_version=httpie_version, httpie_version_info=httpie_version_info, httpie_parent_version=httpie_parent_version, httpie_parent_version_info=httpie_parent_version_info)
    assert type(fmt) == JSONFormatter
    assert fmt.__class__.__name__ == "JSONFormatter"

# Generated at 2022-06-11 23:48:48.008864
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.FMT_MIME == None
    assert formatter.FMT_KWARGS == None

# Generated at 2022-06-11 23:48:56.538959
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs = {
        'explicit_json': True
    }
    assert formatter.format_body('{"hello": "world"}', 'json') == '{\n    "hello": "world"\n}'
    assert formatter.format_body('<html><body><p>Hello World!</p></body></html>', 'json') == '<html><body><p>Hello World!</p></body></html>'
    assert formatter.format_body('<html><body><p>Hello World!</p></body></html>', 'text') == '<html><body><p>Hello World!</p></body></html>'
    assert formatter.format_body('{"hello": "world"}', 'html') == '{"hello": "world"}'
    assert form

# Generated at 2022-06-11 23:49:07.554492
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    test_class = JSONFormatter(format_options=dict(json=dict(format=True, sort_keys=True, indent=2)), kwargs=dict(explicit_json=False))
    assert test_class.format_body("""{"test": "123"}""", 'application/json') == """{\n  "test": "123"\n}"""
    assert test_class.format_body("""{"test": "123"}""", 'text/json') == """{\n  "test": "123"\n}"""
    assert test_class.format_body("""{"test": "123"}""", 'text/javascript') == """{\n  "test": "123"\n}"""

# Generated at 2022-06-11 23:49:16.550083
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # test loading JSON format object
    ff = JSONFormatter(request_format_options={'json':
                                               {'format': True,
                                                'indent': 2,
                                                'sort_keys': True}},
                       explicit_json=False)
    # test invalid JSON
    assert ff.format_body("invalid json", "") == "invalid json"
    # test no JSON in the content
    assert ff.format_body("simple string", "") == "simple string"
    # test JSON in the content
    assert ff.format_body('{"key": "value"}', "") == '{\n  "key": "value"\n}'

# Generated at 2022-06-11 23:49:26.864835
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    formatter = JSONFormatter(explicit_json=False,
        format_options={
            "json": {
                "format": True,
                "indent": 2,
                "sort_keys": True
            },
            "colors": {
                "method": "blue",
                "scheme": "blue",
                "host": "blue",
                "path": "blue"
            },
            "pretty": True
        }
    )

    body_str = '{ "foo": 1 }'
    mime = 'json'
    expected_str = '{\n  "foo": 1\n}'

    # Action
    actual_str = formatter.format_body(body_str, mime)

    # Assert
    assert actual_str == expected_str

# Generated at 2022-06-11 23:49:42.032524
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    print('>>> Test for method format_body of class JSONFormatter')
    print('>>> You should call constructor with argument format_options={{}}')
    print('>>> contain format=True.')
    print('>>> Create JSONFormatter')
    json_formatter = JSONFormatter(format_options = {'json': {'format': True}})
    print('>>> Check result with mime \'json\'')
    print(json_formatter.format_body('{}', 'json'))
    print('>>> Check result with mime \'javascript\'')
    print(json_formatter.format_body('{}', 'javascript'))
    print('>>> Check result with mime \'text\'')
    print(json_formatter.format_body('{}', 'text'))

# Generated at 2022-06-11 23:49:52.435495
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Initialize instance of class JSONFormatter with parameters
    # kwargs = {'explicit_json': False, 'format_options': {'json': {'indent': 4, 'sort_keys': False}}}
    # assert body and mime
    body = '{"key1": "value1", "key2": "value2"}'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'indent': 4, 'sort_keys': False}})
    # Expected output is a string of json-formatted body
    expected = '{\n    "key1": "value1",\n    "key2": "value2"\n}'
    # Call method format_body of class JSONFormatter

# Generated at 2022-06-11 23:50:03.049171
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK

    json_input = u'''\
{
    "args": {},
    "data": "",
    "files": {},
    "form": {
        "key": "value"
    },
    "headers": {
        "Accept": "text/plain",
        "Content-Length": "8",
        "Content-Type": "application/x-www-form-urlencoded"
    },
    "json": null,
    "origin": "87.127.245.102",
    "url": "http://httpbin.org/post"
}'''

    # Test when `indent` is `None`.

# Generated at 2022-06-11 23:50:10.821516
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Provides unit tests for method format_body of class JSONFormatter
    """
    fmt = JSONFormatter(explicit_json=False, format_options={"json": {"sort_keys": True, "indent": 4}})
    assert (fmt.format_body('{"a": 5}', "json") == ('{\n'
                                                    '    "a": 5\n'
                                                    '}'))  # Valid json, json format
    assert (fmt.format_body('{"a": 5}', "text") == '{"a": 5}')  # Valid json, text format
    assert (fmt.format_body('{"a": 5', "text") == '{"a": 5')  # Invalid json, text format

# Generated at 2022-06-11 23:50:15.749026
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    })
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-11 23:50:16.566201
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json = JSONFormatter()
    assert json != None

# Generated at 2022-06-11 23:50:26.604511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }},
        explicit_json=False)
    body_in = '{\"another\": \"object\", \"an\": \"object\"}'
    body_out = '{\n  "an": "object",\n  "another": "object"\n}'
    assert formatter.format_body(body=body_in, mime='json') == body_out
    assert formatter.format_body(body=body_in, mime='text') == body_out
    assert formatter.format_body(body=body_in, mime='javascript') == body_out

# Generated at 2022-06-11 23:50:33.931197
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(stdout=None,
                              format_options={'json': {'format': True,
                                                       'sort_keys': True,
                                                       'indent': 1}},
                              explicit_json=False)
    assert '{\n "a": {\n  "b": "c"\n },\n "d": "e"\n}' == formatter.format_body(
        '{"d": "e", "a": {"b": "c"}}', 'json')
    assert '{\n "d": "e",\n "a": {\n  "b": "c"\n }\n}' == formatter.format_body(
        '{"d": "e", "a": {"b": "c"}}', 'json')


# Generated at 2022-06-11 23:50:44.271399
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    mime = 'application/json'
    json_str = '{"a": 1, "b": 2, "c": [3, 4, 5], "d": {"e": 6, "f": 7}}'
    expected_str = """{
    "a": 1,
    "b": 2,
    "c": [
        3,
        4,
        5
    ],
    "d": {
        "e": 6,
        "f": 7
    }
}"""
    options = {
        'explicit_json': False,
        'format_options': {
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        }
    }
    formatter_plugin = JSONFormatter(**options)
    assert formatter_plugin

# Generated at 2022-06-11 23:50:44.852224
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    pass

# Generated at 2022-06-11 23:50:54.680075
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter.format_body(JSONFormatter(), '{"foo": "foo"}', 'application/json') == '{\n  "foo": "foo"\n}'
    assert JSONFormatter.format_body(JSONFormatter(), '{"foo": "foo"}', 'text/html') == '{"foo": "foo"}'

# Generated at 2022-06-11 23:50:56.867555
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    instance = JSONFormatter(**{})
    ret = instance.format_body('{"a":1,"b":2}', 'json')
    assert ret == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:50:58.499883
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    JSONFormatter.format_body(self, body, mime)
    """
    assert False


# Generated at 2022-06-11 23:51:07.799663
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:51:15.322270
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    }, explicit_json=False)
    body = '{"a": "a", "z": "z"}'
    mime = 'application/json'
    expected_body = '{\n   "a": "a",\n   "z": "z"\n}'

    assert formatter.format_body(body, mime) == expected_body

# Generated at 2022-06-11 23:51:25.369573
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with empty list
    formatted_list = []
    formatter_list = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': '  ', 'sort_keys': False}})
    for body, mime in formatted_list:
        assert body == formatter_list.format_body(body, mime)

    # Test with non-empty list
    formatted_list = [
        ('{"n":5}', 'json'),
        ('{"n":5}', 'javascript'),
        ('{"n":5}', 'text'),
        ("json   n   5", 'text'),
        ("json   n   5", 'plain'),
        ("json   n   5", 'xml'),
    ]

# Generated at 2022-06-11 23:51:30.862055
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import urlopen
    from httpie.plugins import plugin_manager
    json_formatter = JSONFormatter()
    plugin_manager.register(json_formatter)

    with urlopen('https://httpbin.org/get') as response:
        body = response.read().decode('utf-8')

        assert json_formatter.format_body('{"a": 2}', 'json') == '{\n    "a": 2\n}'

        assert json_formatter.format_body('{"a": 2}', '') == '{"a": 2}'

# Generated at 2022-06-11 23:51:42.466140
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.response import Response

    class JSONFormatterMock(JSONFormatter):
        def __init__(self):
            self.kwargs = {'explicit_json': False}
            self.format_options = {
                'json': {'format': True,
                         'sort_keys': False,
                         'indent': 4}
            }

    jf = JSONFormatterMock()
    body = jf.format_body('{"foo":"bar","a":2}', 'json')
    assert body == '{\n    "foo": "bar",\n    "a": 2\n}'

    body = jf.format_body('{"foo":"bar","a":2}', 'text')
    assert body == '{\n    "foo": "bar",\n    "a": 2\n}'

   

# Generated at 2022-06-11 23:51:51.378439
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter_plugin_object = JSONFormatter()
    assert formatter_plugin_object.format_body("False", "json") == 'false'
    assert formatter_plugin_object.format_body("{'a': 1, 'b': 2}", "json") == '{\n    "a": 1, \n    "b": 2\n}'
    assert formatter_plugin_object.format_body("{'a': 1, 'b': 2}", "javascript") == '{\n    "a": 1, \n    "b": 2\n}'
    assert formatter_plugin_object.format_body("{'a': 1, 'b': 2}", "text") == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-11 23:51:58.224551
# Unit test for method format_body of class JSONFormatter