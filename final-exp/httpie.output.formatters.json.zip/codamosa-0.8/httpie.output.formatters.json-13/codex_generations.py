

# Generated at 2022-06-11 23:48:17.778375
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest
    from httpie.plugins import FormatterPlugin, get_plugin_manager

    plugin = JSONFormatter()
    plugin_manager = get_plugin_manager()
    plugin_manager.formatters.append(plugin)

    assert plugin_manager.find_plugin(FormatterPlugin) == plugin

    body = plugin_manager.find_plugin(FormatterPlugin).format_body("""{"a": "b"}""", 'json')
    assert body == json.dumps(obj=json.loads("""{"a": "b"}"""),
        sort_keys=plugin.format_options['json']['sort_keys'],
        ensure_ascii=False,
        indent=plugin.format_options['json']['indent']
    )


# Generated at 2022-06-11 23:48:19.222429
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.kwargs == {}
    assert not formatter.enabled

# Generated at 2022-06-11 23:48:30.586195
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json

# Generated at 2022-06-11 23:48:39.940394
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"message":"Hello World"}'
    formatter = JSONFormatter()  # Enabled by default
    assert formatter.format_body(body, 'json') == '{\n    "message": "Hello World"\n}'
    assert formatter.format_body(body, 'application/json') == '{\n    "message": "Hello World"\n}'
    assert formatter.format_body(body, 'text/html') == body
    formatter.kwargs = {'explicit_json': True}  # Ignore mime...
    assert formatter.format_body(body, 'text/html') == '{\n    "message": "Hello World"\n}'
    formatter.enabled = False  # ...and the flag
    assert formatter.format_body(body, 'json') == body
    formatter

# Generated at 2022-06-11 23:48:48.007737
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(explicit_json = False,
                                   format_options = {'json': {'format': True,
                                                              'indent': 4,
                                                              'sort_keys': True}})
    input_json_content = json.dumps(obj = {
        "success": "true",
        "version": "1.0",
        "response": {
            "code": 200,
            "codeDetail": "Request succeeded",
            "status": "ok",
            "message": "OK"
        }
    })

# Generated at 2022-06-11 23:48:54.609017
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    plugin = JSONFormatter()
    assert plugin.format_body('body', 'application/json') == 'body'

    # Test 2
    plugin = JSONFormatter()
    assert plugin.format_body('{"name":"Alper"}', 'json') == '''{
    "name": "Alper"
}'''

    # Test 3
    plugin = JSONFormatter()
    assert plugin.format_body('{"name":"\u0130"}', 'json') == '''{
    "name": "İ"
}'''

# Generated at 2022-06-11 23:49:04.582296
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True}})
    assert formatter.format_body('{"key":"value"}', 'json') == """\
{
    "key": "value"
}"""
    assert formatter.format_body('{"key":"value"}', 'javascript') == """\
{
    "key": "value"
}"""
    assert formatter.format_body('{"key":"value"}', 'none') == '{"key":"value"}'
    assert formatter.format_body(
        '{"key":"value"}', 'text') == '{"key":"value"}'
    assert formatter.format_body('{"key":"value"', 'json') == '{"key":"value"'

# Generated at 2022-06-11 23:49:13.009684
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1: JSON body
    json_dict = {'1':1}
    j = JSONFormatter()
    body = j.format_body(json.dumps(json_dict), 'json')
    assert json.loads(body) == json_dict

    # Test 2: JSON body with valid JSON but invalid JSON object
    json_dict = "{'1':1}"
    j = JSONFormatter()
    body = j.format_body(json_dict, 'json')
    assert json.loads(body) == json_dict

    # Test 3: non-JSON body
    json_dict = "Some random string"
    j = JSONFormatter()
    body = j.format_body(json_dict, 'json')
    assert json.loads(body) == json_dict

# Generated at 2022-06-11 23:49:15.484685
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == True


# Generated at 2022-06-11 23:49:22.965179
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    instance = JSONFormatter(
        format_options={
            'json':{
                'format': True,
                'sort_keys': True,
                'indent': 2
            }
        },
        explicit_json=False
    )
    obj = json.loads(instance.format_body(
        body='{"b": 1, "a": 2, "c": [3, 1, 4]}',
        mime='application/json'
    ))
    assert obj == {'b': 1, 'a': 2, 'c': [3, 1, 4]}



# Generated at 2022-06-11 23:49:36.593658
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jp = JSONFormatter(format_options=dict(
        json=dict(format=True, sort_keys=False, indent=2)
    ))
    # It should format the body
    body = '{"username": "admin", "name": "Administrator"}'
    assert jp.format_body(body, mime='application/json') == '{\n  "name": "Administrator",\n  "username": "admin"\n}'

    # It should not format the body as invalid json
    body = '{"username": "admin", "name" "Administrator"}'
    assert jp.format_body(body, mime='application/json') == '{"username": "admin", "name" "Administrator"}'

    # It should not format the body as invalid json

# Generated at 2022-06-11 23:49:43.688900
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': 1,
                'indent': 4,
                'sort_keys': False,
            },
        },
        kwargs={'explicit_json': False}
    )

    input_data_1 = (
        '{"aaa": "bbb", "ccc": "ddd"}',
        'json'
    )
    assert json_formatter.format_body(*input_data_1) == \
        '{\n    "aaa": "bbb",\n    "ccc": "ddd"\n}'

    input_data_2 = (
        '{"aaa": "bbb", "ccc": "ddd"}',
        'text'
    )
    assert json_formatter.format_

# Generated at 2022-06-11 23:49:47.627317
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import os
    import sys
    sys.path.insert(0, os.path.dirname(__file__))
    import tests
    import httpie
    JSONFormatter().get_tests(tests, httpie)

# Generated at 2022-06-11 23:49:52.507121
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json = True, format_options = {"json":{"format": True}})
    body = '{"foo": 42, "bar": "a"}'
    mime = 'text/json'
    assert formatter.format_body(body, mime) == '{\n    "bar": "a",\n    "foo": 42\n}'


# Generated at 2022-06-11 23:49:53.303170
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    f = JSONFormatter()
    assert not f.enabled

# Generated at 2022-06-11 23:49:54.128310
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter

# Generated at 2022-06-11 23:50:04.490078
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"test1":"value", "test2":"value2"}'

    test_object = {'test1': 'value', 'test2': 'value2'}
    assert(json.loads(body) == test_object)

    explicit_json = False
    mime = 'json'
    sort_keys = False
    indent = 0
    formatter = JSONFormatter(explicit_json=explicit_json,
                              mime=mime,
                              sort_keys=sort_keys,
                              indent=indent)
    body = formatter.format_body(body=body, mime=mime)

    assert(body == json.dumps(test_object, ensure_ascii=False, indent=indent, sort_keys=sort_keys))

# Generated at 2022-06-11 23:50:10.946127
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}})
    assert f.format_body('{"a": 1, "b": [2, 3], "c": {"d": 4}, "e": "1\\"2"}', 'json') \
           == '{\n    "a": 1,\n    "b": [\n        2,\n        3\n    ],\n    "c": {\n        "d": 4\n    },\n    "e": "1\\"2"\n}'

# Generated at 2022-06-11 23:50:13.580056
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert(JSONFormatter().format_body('{"object": "value"}', 'text') == '"{\n    \\"object\\": \\"value\\"\n}"')

# Generated at 2022-06-11 23:50:24.148819
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from pytest import raises
    json_formatter = JSONFormatter(**dict(explicit_json=False, format_options=dict(json=dict(format=True, indent=True, sort_keys=False))))
    assert json_formatter.format_body(body='{"a": 1}', mime='application/json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body(body='{"a": 1}', mime='javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body(body='{"a": 1}', mime='text/javascript') == '{\n    "a": 1\n}'

# Generated at 2022-06-11 23:50:35.763818
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.__class__.__name__ == 'JSONFormatter'
    assert hasattr(formatter, 'format')
    assert hasattr(formatter, 'format_body')
    assert formatter.__class__.__name__ == 'JSONFormatter'


# Generated at 2022-06-11 23:50:45.835399
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Test input
    body = '[{"b": "c", "a": "b"}]'
    body_explicit = '[{"b": "c", "a": "b"}]'
    body_explicit_sort = '[{"a": "b", "b": "c"}]'
    body_explicit_sort_indent = '''[
  {
    "a": "b",
    "b": "c"
  }
]'''
    mime_json = 'json'
    mime_javascript = 'javascript'
    mime_text = 'text'
    mime_none = 'none'

    # Test plain text

# Generated at 2022-06-11 23:50:54.362682
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():

    # Initialize a JSONFormatter object.
    json_formatter = JSONFormatter(
        kwargs={
            'explicit_json': True,  # This value doesn't matter.
            'formatted': False,
        },
        format_options={
            # These values don't matter.
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 4,
            },
            'colors': {
                'format': True,
            },
            'unicode': {
                'format': True,
            },
        })

    # Test the method format_body with some invalid JSON input.
    body = "This isn't a json object"
    assert json_formatter.format_body(body, 'javascript') == body

    # Test the method format_body with a valid

# Generated at 2022-06-11 23:50:58.886872
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter_plugin_params = {
        'json': {
            'format': False, 'indent': 4, 'sort_keys': True
        }
    }
    json_formatter = JSONFormatter(**formatter_plugin_params)
    assert not json_formatter.enabled
    assert json_formatter.format_options['json']['format'] == False
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys'] == True
    assert isinstance(json_formatter, FormatterPlugin)


# Generated at 2022-06-11 23:51:08.073974
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from json import dumps
    from os import path
    from unittest import mock

    from httpie.plugins.builtin import JSONFormatter

    _file = path.join(path.dirname(__file__), 'fixtures/test_JSONFormatter_format_body.json')
    with open(_file) as fd:
        data = fd.read()
    json_obj = json.loads(data)
    with mock.patch(
            FormatterPlugin.__module__ + '.' + FormatterPlugin.__qualname__ + '.get_default_format_options',
            return_value={
                'json': {
                    'indent': 4,
                    'sort_keys': False,
                    'format': True
                }
            }
    ):
        _formatter = JSON

# Generated at 2022-06-11 23:51:17.446305
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from pprint import pprint
    test_format_options = dict(
        json=dict(
            format=True,
            sort_keys=False,
            indent=4
        ),
        colors=dict(
            match=dict(
                scheme=None,
                host=None,
                port=None,
                path=None,
                query=['green', 'bold'],
                fragment=None,
            )
        )
    )
    jf = JSONFormatter(
        format_options=test_format_options,
        explicit_json=False)
    assert jf.format_options == test_format_options
    pprint(jf.kwargs)
    print(jf.__dict__)

# Generated at 2022-06-11 23:51:27.152917
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test sort_keys and indent configuration
    f = JSONFormatter(format_options={'json': {'sort_keys': True, 'indent': 4}})
    assert f.format_body('{"z":1,"a":2,"y":3,"b":4}', 'application/json') == '{\n    "a": 2,\n    "b": 4,\n    "y": 3,\n    "z": 1\n}'

    # Test json
    f = JSONFormatter()
    assert f.format_body('{"z":1,"a":2,"y":3,"b":4}', 'application/json') == '{"z":1,"a":2,"y":3,"b":4}'

    # Test javascript
    f = JSONFormatter()

# Generated at 2022-06-11 23:51:30.979897
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import pytest
    from httpie.plugins import JSONFormatter
    from httpie.plugins.formatter.__json import JSONFormatter

    formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'application/json'

    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'


# Generated at 2022-06-11 23:51:42.510628
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """Format '{"key1": "val1", "key2": "val2"}'"""
    from httpie.output.formatters.JSONFormatter import JSONFormatter
    from httpie.core import main
    from httpie.compat import str
    # test string
    test_string = '{"key1": "val1", "key2": "val2"}'

    # Create kwargs base

# Generated at 2022-06-11 23:51:50.647949
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import str
    assert JSONFormatter().format_body('{"a": 0}', 'json') == '{"a": 0}'
    assert JSONFormatter().format_body('{"a": 0}', 'javascript') == '{"a": 0}'
    assert JSONFormatter().format_body('{"a": 0}', 'text') == '{"a": 0}'
    mime = 'application/xml'
    body = '<a>0</a>'
    assert JSONFormatter().format_body(body, mime) == body
    assert isinstance(
        JSONFormatter().format_body('{"a": 0}', 'json'),
        str
    )

# Generated at 2022-06-11 23:52:12.295362
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.input
    import httpie.cli

    args = httpie.cli.parser.parse_args(args=[])
    args.json = True
    args.sort_keys = True
    args.indent = 4
    http = httpie.input.HTTPie(args)

    data = {
        'name': 'a',
        'age': 3
    }

    assert JSONFormatter(kwargs=vars(http)).format_body(
        body=json.dumps(data),
        mime='json'
    ) == '''{
    "age": 3,
    "name": "a"
}'''


# Generated at 2022-06-11 23:52:21.895162
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }, explicit_json=False)
    # Test invalid input
    assert formatter.format_body('invalid', 'json') == 'invalid'
    # Test mime different than json
    assert formatter.format_body('{"a": 2, "b": 1}', 'text') == '{"a": 2, "b": 1}'
    # Test valid input with mime different than json
    assert formatter.format_body('{"b": 1, "a": 2}', 'text') == '{\n    "b": 1,\n    "a": 2\n}'
    # Test valid input with mime different than json and explicit_json

# Generated at 2022-06-11 23:52:32.035883
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    my_formatter = JSONFormatter()
    # test for indent and sort
    assert my_formatter.format_body('{"firstName": "John", "lastName": "Smith"}', 'application/json') == '{\n    "firstName": "John",\n    "lastName": "Smith"\n}'
    # test for unicode
    assert my_formatter.format_body('{"firstName": "Jóhn", "lastName": "Smíth"}', 'application/json') == '{\n    "firstName": "Jóhn",\n    "lastName": "Smíth"\n}'
    # test for invalid JSON

# Generated at 2022-06-11 23:52:36.024005
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(**{'explicit_json': False, 'format_options': {'json': {'format': True, 'indent': None, 'sort_keys': False}}})
    result = formatter.forma

# Generated at 2022-06-11 23:52:39.724599
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert test.format_body(body='{"a": 1, "b": 2}', mime='application/json') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:52:48.197298
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body_string = '{"name":"Antoine","age":23}'
    json_formatter = JSONFormatter()
    json_formatter.format_options['json']['format'] = True
    json_formatter.format_options['json']['sort_keys'] = False
    json_formatter.format_options['json']['indent'] = 2
    json_formatter.kwargs['explicit_json'] = False
    json_formatter.format_body(body_string, 'text')

    body_string = '{"name":"Antoine","age":23}'
    json_formatter = JSONFormatter()
    json_formatter.format_options['json']['format'] = True
    json_formatter.format_options['json']['sort_keys'] = True

# Generated at 2022-06-11 23:52:58.689599
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.input import ParseError
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        argv=['http', '--json', 'www.baidu.com'],
        config_dir=None,
        use_colors=True,
        default_options=None,
        session=None
    )

    # add plugin
    plugin_manager.get_all = lambda: [JSONFormatter]
    plugin_manager.load_installed()

    # get formatter

# Generated at 2022-06-11 23:53:03.497404
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{\"msg\": \"Hello\"}"
    assert body == JSONFormatter(json = {
        'format': True,
        'indent': 2,
        'sort_keys': True
        }).format_body(body, "application/json")


# Generated at 2022-06-11 23:53:10.965873
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs['explicit_json'] = False
    formatter.format_options['json']['sort_keys'] = False
    formatter.format_options['json']['indent'] = 4

    body = '{"a": "b", "c": "d"}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == \
        '{\n    "a": "b",\n    "c": "d"\n}'

    body = '"a": "b"'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == body

    mime = 'text/plain'
    assert formatter.format_body(body, mime) == body

# Generated at 2022-06-11 23:53:15.857613
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(kwargs={'explicit_json': True,
                                      'format_options': {
                                          'json': {
                                              'indent': 4,
                                              'format': True,
                                              'sort_keys': False
                                          }}
                                      }
                              )
    assert formatter.format_body('{"hello": "world"}', 'json') == \
        '{\n    "hello": "world"\n}'