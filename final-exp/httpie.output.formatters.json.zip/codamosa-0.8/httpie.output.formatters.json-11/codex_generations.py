

# Generated at 2022-06-11 23:48:17.654397
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.builtin import csv, form, json
    from httpie.plugins.builtin import pretty, stream
    from httpie.plugins.builtin import syntax_highlight
    from httpie.plugins.builtin import BrowserCompatibilityFormatter
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import CSVFormatter
    from httpie.plugins.builtin import FormFormatter
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import SyntaxHighlightFormatter
    # If response body is a valid JSON and the format option is set to JSON,
    # this method converts the response body to JSON and indents it.
    # Otherwise, it stays the same.
    body = '{"response": "body"}'

# Generated at 2022-06-11 23:48:28.886607
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    class MockJSONFormatter(JSONFormatter):
        def __init__(self):
            self.kwargs = {
                'explicit_json': False
            }
            self.format_options = {
                'json' : {
                    'format' : True,
                    'indent' : None,
                    'sort_keys' : False,
                }
            }

    formatter = MockJSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 23:48:32.232172
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsonFormatter = JSONFormatter()
    assert jsonFormatter.format_body('{"key": "value"}', 'application/json') == '{\n    "key": "value"\n}'
    assert jsonFormatter.format_body('{"key": "value"}', 'test/test') == '{"key": "value"}'

# Generated at 2022-06-11 23:48:41.754006
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_body = '{"name": "moto", "type": "motorbike"}'
    csv_body = 'name,type\nmoto,motorbike'
    formatter = JSONFormatter(explicit_json=False)
    assert formatter.format_body(json_body, 'application/json') == '{\n    "name": "moto",\n    "type": "motorbike"\n}'
    assert formatter.format_body(json_body, 'text/javascript') == '{\n    "name": "moto",\n    "type": "motorbike"\n}'
    assert formatter.format_body(json_body, 'text/plain') == '{\n    "name": "moto",\n    "type": "motorbike"\n}'
    assert form

# Generated at 2022-06-11 23:48:50.767514
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    func = JSONFormatter(format_options={"json":{"format":1, "indent":None, "sort_keys":True}}).format_body
    string = "It works!"
    assert '"'+string+'"' == func(string, True)
    assert func(string, False)==None, "Should handle no-json requests."
    assert func(json.dumps({"a":1}), True) == "{\n    \"a\": 1\n}", \
           "Should handle json requests."
    assert func(json.dumps({"a":1}), "application/json") == "{\n    \"a\": 1\n}", \
           "Should handle json requests."

# Generated at 2022-06-11 23:48:55.808693
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }},
        explicit_json=True,
        colors=True,
        preferences={},
        theme={},
        stdout_isatty=True
    )
    assert formatter.enabled is True
    assert formatter.kwargs['explicit_json'] is True


# Generated at 2022-06-11 23:49:03.483846
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Arrange
    json_data = b'{"a":1,"b":2}'
    json_data_as_string = json_data.decode("utf-8")
    # Act
    json_data_out = JSONFormatter(**{'explicit_json': True, 'json': {'format': True, 'indent': None, 'sort_keys': False}}).format_body(json_data_as_string, 'json')
    # Assert
    assert json_data_out==json_data_as_string

# Generated at 2022-06-11 23:49:03.961695
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    _test = JSONFormatter()

# Generated at 2022-06-11 23:49:12.901074
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert JSONFormatter().format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert JSONFormatter().format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert JSONFormatter().format_body('{"a": 1}', 'text/plain') == '{"a": 1}'
    assert JSONFormatter().format_body('', 'text') == ''
    assert JSONFormatter().format_body('', 'text/plain') == ''
    assert JSONFormatter().format_body('a', 'json') == '"a"'
    #assert JSONFormatter().format_body('a',

# Generated at 2022-06-11 23:49:19.034489
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {}}).enabled is False
    assert JSONFormatter(format_options={'json': {'format': True}}).enabled is True
    assert JSONFormatter(format_options={'json': {'format': False}}).enabled is False
    assert JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True}}).enabled is True


# Generated at 2022-06-11 23:49:30.541225
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_plugin = JSONFormatter()
    assert json_plugin.format_body('{"a" : [1, 2, 3]}', 'application/json') == '{\n    "a": [\n        1, \n        2, \n        3\n    ]\n}'
    assert json_plugin.format_body('{"a" : [1, 2, 3]}', 'application/notjson') == '{"a" : [1, 2, 3]}'
    assert json_plugin.format_body('Invalid JSON', 'application/json') == 'Invalid JSON'

# Generated at 2022-06-11 23:49:37.838072
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    test_object = JSONFormatter()
    body = '{"id":208,"name":"SuperCaliFragilisticExpialiDoosious"}'
    actual_output = test_object.format_body(body=body, mime='application/json')
    expected_output = '{\n    "id": 208,\n    "name": "SuperCaliFragilisticExpialiDoosious"\n}'
    assert actual_output==expected_output


# Generated at 2022-06-11 23:49:46.901205
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import get_plugin_manager
    from httpie.output.streams import build_output_stream

    pm = get_plugin_manager()
    formatter = pm.instantiate(
        klass=JSONFormatter,
        format_options=dict(),
        output_options=dict(),
        streams=[build_output_stream(None, 'stdout', dict())],
        color_scheme_options=dict(),
        kwargs=dict()
    )
    mime = 'text'
    body = '[{ "a": 1 }, { "b": 2 }]'
    assert formatter.format_body(body, mime) == '[{\n    "a": 1\n}, {\n    "b": 2\n}]'

# Generated at 2022-06-11 23:49:55.156182
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:50:04.980219
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import JSONFormatter
    assert JSONFormatter().format_body('this is not json, ok?', 'text/plain') == 'this is not json, ok?'
    assert JSONFormatter().format_body('{"a": 1, "b": "c"}', 'json') == '{\n    "a": 1,\n    "b": "c"\n}'
    assert JSONFormatter().format_body('{"a": 1, "b": "c"}', 'javascript') == '{\n    "a": 1,\n    "b": "c"\n}'
    assert JSONFormatter().format_body('{"a": 1, "b": "c"}', 'text') == '{\n    "a": 1,\n    "b": "c"\n}'

# Generated at 2022-06-11 23:50:11.172701
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    kwargs = {
        'explicit_json': True,
        'format': 'colors',
    }
    formatter = JSONFormatter(**kwargs)
    body = (
        '{\n'
        '    "data": {\n'
        '        "name": "Guillaume",\n'
        '        "age": 20\n'
        '    }\n'
        '}'
    )
    mime = 'json'
    result = formatter.format_body(body=body, mime=mime)
    expected = (
        '{\n'
        '    "data": {\n'
        '        "name": "Guillaume",\n'
        '        "age": 20\n'
        '    }\n'
        '}'
    )

# Generated at 2022-06-11 23:50:11.788788
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():

    pass

# Generated at 2022-06-11 23:50:17.888631
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert(json_formatter.format_body('{"test":"jaja"}', 'application/json') == '{\n    "test": "jaja"\n}')
    assert(json_formatter.format_body('{"test":"jaja"}', 'text') == '{\n    "test": "jaja"\n}')
    assert(json_formatter.format_body('{"test":"jaja"}', 'text/html') == '{"test":"jaja"}')
    assert(json_formatter.format_body('this is not JSON', 'text') == 'this is not JSON')
    assert(json_formatter.format_body('this is not JSON', 'application/json') == 'this is not JSON')

# Generated at 2022-06-11 23:50:22.733253
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins.builtin import JSONFormatter
    json_formatter = JSONFormatter({'format_options': {'json': {'format': True, 'indent': 2, 'sort_keys': True}}})
    print(json_formatter.format_body('{"a": 1}', 'json'))



# Generated at 2022-06-11 23:50:29.005624
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    JSONFormatter_class = JSONFormatter(kwargs = {
        'explicit_json': True,
        'format_options':{
            'json':{
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        }
    })

    json_input = '{"foo":1, "bar": "baz"}'
    json_input_mime = 'application/json'

    json_expected = json.dumps(json.loads(json_input), sort_keys=True, indent=2, ensure_ascii=False)
    
    json_output = JSONFormatter_class.format_body(json_input, json_input_mime)

    assert json_expected == json_output