

# Generated at 2022-06-11 23:48:09.228039
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    pass

# Generated at 2022-06-11 23:48:19.488390
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    class FakeJSONFormatter(JSONFormatter):

        def __init__(self, **kwargs):
            JSONFormatter.__init__(self, **kwargs)
            self.print_result = [
                self.enabled,
                self.kwargs['explicit_json'],
                self.format_options['json']['format'],
                self.format_options['json']['indent'],
                self.format_options['json']['sort_keys'],
            ]

        def format_body(self, body: str, mime: str) -> str:
            return None


# Generated at 2022-06-11 23:48:30.623824
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:48:38.512848
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        },
        'colors': {
            'red': True,
            'green': True,
            'blue': True,
        },
        'styles': False,
        'stream': False,
    }, explicit_json=True, **{'app_dir': '/app_directory', 'config_dir': '/config_directory'})

    assert formatter.format_options.get('json').get('format')
    assert not formatter.format_options.get('colors').get('red')

# Generated at 2022-06-11 23:48:47.156592
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.formatters import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.utils import response_json
    from httpie.status import ExitStatus
    from pygments import highlight
    from pygments.lexers import HttpLexer
    from pygments.formatters import TerminalTrueColorFormatter
    from httpie.input import ParseError
    import json

    import json
    json_formatter = JSONFormatter()
    json_data = [{'age': '34', 'name': 'Jim'},
                 {'age': '23', 'name': 'Alice'},
                 {'age': '32', 'name': 'Bob'}]
    json_obj = json.dumps(json_data)
    assert json_formatter.format_body(json_obj, 'json') == json.d

# Generated at 2022-06-11 23:48:49.431337
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body("{}", "application/json") == '{}'

# Generated at 2022-06-11 23:48:52.507080
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    _ = JSONFormatter(format_options={'json': {
        'format': True,
        'indent': None,
        'sort_keys': False,
    }},
    explicit_json=True)

# Generated at 2022-06-11 23:49:02.927436
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    data = {
        'test' : [1, 2, 3]
    }
    data_str = json.dumps(obj=data)
    formatter = JSONFormatter(explicit_json=True)
    assert formatter.enabled
    assert formatter.format_body(data_str, 'application/json') == data_str
    formatter = JSONFormatter(explicit_json=False)
    assert not formatter.enabled
    assert formatter.format_body(data_str, 'application/json') == data_str
    formatter = JSONFormatter(explicit_json=False)
    assert formatter.format_body(data_str, 'text/plain') == data_str
    assert formatter.format_body(data_str, 'text/javascript') == data_str
    assert formatter.format_body

# Generated at 2022-06-11 23:49:06.825355
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options = {'json':{'format':True, 'indent':2, 'sort_keys':True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2


# Generated at 2022-06-11 23:49:12.338691
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.kwargs['explicit_json'] = False
    formatter.format_options['json']['format'] = True
    formatter.format_options['json']['sort_keys'] = False
    formatter.format_options['json']['indent'] = 1
    body = '{"key1": "value1", "key2": "value2"}'
    print(formatter.format_body(body, 'json'))

# Generated at 2022-06-11 23:49:25.671331
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test simple JSON text
    j = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': True, 'indent': True}})
    j.format_body('{"key": "value"}', 'json') == '{\n    "key": "value"\n}'
    # Test non-JSON text
    j.format_body('Just some text', 'json') == 'Just some text'
    j.format_body('{"key": "value"}', 'text') == '{"key": "value"}'
    j.format_body('{"key": "value"}', 'javascript') == '{"key": "value"}'
    # Test invalid JSON
    j.format_body('{"key": "value"', 'json') == '{"key": "value"'
    j

# Generated at 2022-06-11 23:49:36.548028
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    """
    Unit test JSONFormatter format_body method
    """
    import httpie.input
    import httpie.plugins
    import json
    import pytest

    # Set up

    # Pretty-print a JSON body
    # Instantiate JSONFormatter with explicit_json=True
    formatter_dict = {'json': {'format': True, 'indent': 2, 'sort_keys': True}}
    formatter = httpie.plugins.JSONFormatter(
        input_=httpie.input.FileUpload(), **formatter_dict)

    # Dummy body, headers and mime type
    body = {'a': 1, 'b': 'two', 'c': [{'d': 3}, 4, [5, 'six']]}
    json_body = json.dumps(body)

# Generated at 2022-06-11 23:49:39.456748
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    jsf = JSONFormatter()
    result = jsf.format_body('{"hello":"world"}', 'application/json')
    assert(result == '{\n    "hello": "world"\n}')



# Generated at 2022-06-11 23:49:49.580549
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    response = '{"message": "Hello, World!"}'
    media_type = 'json'
    formatter_options = {'json': {'format': True, 'indent': 2}}

    assert JSONFormatter(formatter_options).format_body(response, media_type) == """{
  "message": "Hello, World!"
}"""

    media_type = 'application/json'
    assert JSONFormatter(formatter_options).format_body(response, media_type) == """{
  "message": "Hello, World!"
}"""

    media_type = 'application/x-www-form-urlencoded'
    assert JSONFormatter(formatter_options).format_body(response, media_type) == '{"message": "Hello, World!"}'

# Generated at 2022-06-11 23:49:56.480077
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = "{\"msg\": \"Hello\"}"
    formatter = JSONFormatter(**{'explicit_json': False})
    assert body == formatter.format_body(body=body, mime='json')

    formatter = JSONFormatter(**{'explicit_json': False})
    assert body == formatter.format_body(body=body, mime='text')
    assert body == formatter.format_body(body=body, mime='javascript')
    assert body != formatter.format_body(body=body, mime='yaml')

    body = '{"msg": "Hello"}'
    formatter = JSONFormatter(**{'explicit_json': False})
    assert body == formatter.format_body(body=body, mime='json')


# Generated at 2022-06-11 23:50:06.262460
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:50:13.281933
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPlugin
    from utils import FakePlugin

    obj = FakePlugin(format_options={
        'json': {
            'format': False,
            'sort_keys': True,
            'indent': 4,
        }
    })

    formatter = JSONFormatter(**obj.get_kwargs())

    # Unit test for method format_body
    def test_format_body():
        body = '{"foo": "bar"}'
        mime = 'json'

        formatter.format_body(body, mime)

# Generated at 2022-06-11 23:50:15.333851
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    test = JSONFormatter(format_options = {'json': {'format': True}})
    assert test.enabled

test_JSONFormatter()

# Generated at 2022-06-11 23:50:25.575514
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        explicit_json=True,
        format_options={
            "json": {
                "format": True,
                "indent": 4,
                "sort_keys": True
            }
        }
    )

    result = formatter.format_body(
        '{ "foo": ["bar", "baz"] }',
        'application/json'
    )
    assert result == '{\n    "foo": [\n        "bar",\n        "baz"\n    ]\n}'

    result = formatter.format_body(
        '{ "foo": ["bar", "baz"] }',
        'text/json'
    )

# Generated at 2022-06-11 23:50:33.403061
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import builtin
    from httpie.parsers import JSONParser
    from httpie.formatters import JSONFormatter
    from httpie.context import Environment

    parser = JSONParser()
    formatter = JSONFormatter(format_options={"json": {"format": True}})
    env = Environment(parser, formatter, [builtin.colors])

    # Test for correct indenting
    text = '\n{\n  "test": true\n}\n'
    assert formatter.format_body(text, mime="application/json") == text

    # Test for no indenting when no newlines are present
    text = '{"test":true}'
    assert formatter.format_body(text, mime="application/json") == text

    # Test for nested objects

# Generated at 2022-06-11 23:50:48.740063
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie import __version__


# Generated at 2022-06-11 23:50:50.679437
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    try:
        json_formatter = JSONFormatter()
    except Exception as e:
        assert(False)

# Test format_body

# Generated at 2022-06-11 23:50:52.166581
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled


# Generated at 2022-06-11 23:50:55.896537
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from json import loads
    options = {
        'json': {
            'indent': 0,
            'sort_keys': False,
        }
    }
    formatter = FormatterPlugin(format_options=options)
    body = '{"id": 1, "name": "Zeppo"}'
    actual = formatter.format_body(body=body, mime='application/json')
    expected = '{"id": 1, "name": "Zeppo"}'
    assert actual == expected

# Generated at 2022-06-11 23:51:05.539191
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.core import main
    from httpie.plugins import core
    from httpie.context import Environment, Term

    args = main.parser.parse_args([
        'http', '--json',
        '-b', '{}',
        'httpbin.org/post'
    ])
    assert args.json
    assert not args.explicit_json


# Generated at 2022-06-11 23:51:16.820296
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie import ExitStatus
    from utils import http

    exit_status, output = http(
        '--print=bH', 'GET', 'https://httpbin.org/json'
    )
    assert exit_status == ExitStatus.OK
    assert output.startswith('{')
    assert output.rstrip().endswith('}')
    assert '  ' in output  # Indented.

    # `--json=` enables the `indent` and `sort` options.
    exit_status, output = http(
        'GET', 'https://httpbin.org/json', '--json='
    )
    assert exit_status == ExitStatus.OK
    assert output.startswith('{')
    assert output.rstrip().endswith('}')
    assert '  ' in output  # Indented.

# Generated at 2022-06-11 23:51:21.037423
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"some": "body"}', 'json')
    assert formatter.format_body('{"some": "body"}', 'text')
    assert formatter.format_body('{"some": "body"}', 'javascript')

# Generated at 2022-06-11 23:51:22.093455
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter() != None

# Generated at 2022-06-11 23:51:30.456153
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"hex": "0x60046080", "binary": "0b11000000000001000110010000000000", "decimal": 24578, "octal": "0o141016", "char": "h"}'
    body_formatted = '{\n    "binary": "0b11000000000001000110010000000000",\n    "decimal": 24578,\n    "char": "h",\n    "hex": "0x60046080",\n    "octal": "0o141016"\n}'

# Generated at 2022-06-11 23:51:42.103535
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Indent and sort keys on the fly
    assert (JSONFormatter(explicit_json=False, format_options={
        'json': {
            'indent': 2,
            'sort_keys': True,
            'format': True
        }
    }).format_body('{"aaa":"bbb","ccc":"ddd"}', 'application/json')
        == '{\n  "aaa": "bbb",\n  "ccc": "ddd"\n}')

    # Test of explicit JSON flag

# Generated at 2022-06-11 23:51:58.679493
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = """
{
    "age": 19,
    "name": "test",
    "foo": "bar"
}
"""
    modified_body = """{
    "age": 19,
    "foo": "bar",
    "name": "test"
}"""  # Version with keys sorted alphabetically
    mime = 'json'
    json_formatter = JSONFormatter(kwargs={'explicit_json': False})
    assert json_formatter.format_body(body, mime) == modified_body

# Generated at 2022-06-11 23:52:03.564409
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    # GIVEN
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    
    # THEN
    assert formatter.enabled


# Generated at 2022-06-11 23:52:12.180228
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json = JSONFormatter()

    body = """
        {
            "a": 1,
            "b": 2
        }
    """
    expected_body = """
        {
            "a": 1,
            "b": 2
        }
    """
    actual_body = json.format_body(body=body, mime="json")
    assert actual_body == expected_body

    body = """
        {
            "b": 2,
            "a": 1
        }
    """
    expected_body = """
        {
            "a": 1,
            "b": 2
        }
    """
    actual_body = json.format_body(body=body, mime="json")
    assert actual_body == expected_body


# Generated at 2022-06-11 23:52:21.753866
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('1', '') == '1'
    assert formatter.format_body('{}', 'json') == '{}'
    # the following tests are made after the JSON is modified
    assert formatter.format_body('{}', 'text') == '{}'
    assert formatter.format_body('{}', 'javascript') == '{}'
    assert formatter.format_body('{}', 'json') == '{\n}'
    assert formatter.format_body('{"test": "test"}', 'json') == '{\n    "test": "test"\n}'
    assert formatter.format_body('{"test": "test"}', 'json') == '{\n    "test": "test"\n}'
    assert formatter

# Generated at 2022-06-11 23:52:31.900405
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Init
    formatter = JSONFormatter(explicit_json=False,
                              format_options={'json': {'format': True,
                                                       'indent': 4,
                                                       'sort_keys': False}})

    # Test
    assert isinstance(formatter, JSONFormatter)
    assert formatter.kwargs == {'explicit_json': False,
                                'format_options': {'json': {'format': True,
                                                            'indent': 4,
                                                            'sort_keys': False}}}
    assert formatter.format_body('{"key": "value1"}', 'json') == \
           '{\n    "key": "value1"\n}'

# Generated at 2022-06-11 23:52:40.718319
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    
    import json

    json_formatter = JSONFormatter(explicit_json=False)
    
    # Valid JSON
    json_str = '{"id":1,"user":"foo"}'
    check_json_str = '{\n    "id": 1,\n    "user": "foo"\n}'
    assert json_formatter.format_body(json_str, "application/json") == check_json_str
    
    # Valid JSON
    json_str = '{"id":1,"user":"foo"}'
    check_json_str = '{"id":1,"user":"foo"}'
    assert json_formatter.format_body(json_str, "text/html") == check_json_str
    
    # Not JSON

# Generated at 2022-06-11 23:52:43.601213
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(kwargs={}, format_options={'json': {}})
    assert formatter.format_body('{"foo": "bar"}', '') == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 23:52:46.564461
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    body = '{"a": 1, "b": 2}'
    assert JSONFormatter(**{}).format_body(body, 'json') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:52:57.076848
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-11 23:53:06.417343
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Define the instance of class JSONFormatter
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,  # enable to format
            'indent': 4,
            'sort_keys': True
        }
    },
        explicit_json=False,
    )
    
    # Make a copy of the body data
    body = '{"foo":1}'
    
    # Define the mime format of body
    mime = 'json'
    
    # Format the body
    body = formatter.format_body(body, mime)
    
    # Assert the result of format_body
    assert body == '{\n    "foo": 1\n}'

# Generated at 2022-06-11 23:53:37.702742
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    formatter.format_options['json']['format'] = True

    # Test with valid JSON
    body = formatter.format_body('{"a":"b"}', '')
    assert body == '{\n    "a": "b"\n}'

    # Test with invalid JSON
    body = formatter.format_body('{\n"a": "b"', '')
    assert body == '{\n"a": "b"'

    # Test without specified mime
    body = formatter.format_body('{"a":"b"}', 'unknown/mime')
    assert body == '{"a":"b"}'

    # Test with correct mime
    body = formatter.format_body('{"a":"b"}', 'application/json')

# Generated at 2022-06-11 23:53:45.356927
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter({}, 'json')
    assert formatter.format_body('{}', 'text/plain') == '{}'
    assert formatter.format_body('{}', 'application/json') == '{}'
    assert formatter.format_body('{}', 'text/x-json') == '{}'
    assert formatter.format_body('{}', 'text/javascript') == '{}'
    assert formatter.format_body('{}', 'application/javascript') == '{}'

# Generated at 2022-06-11 23:53:49.572801
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.output.formatters import JSONFormatter

    jf = JSONFormatter(json={'format': True})
    body = '{"test": 42}'
    body_formatted = jf.format_body(body, 'json')
    assert body_formatted == '{\n    "test": 42\n}'

# Generated at 2022-06-11 23:53:52.142326
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(format_options={'json': {'indent': 4}})
    assert jf.format_options['json']['indent'] == 4



# Generated at 2022-06-11 23:54:01.275708
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    """Unit test for constructor of class JSONFormatter"""

    formatter = JSONFormatter(
        session=None,
        format_options=None,
        colors=None,
        stdin=None,
        stdout=None,
        stderr=None,
        _stdout_bytes=None,
        _is_terminal=None,
        _is_windows=None,
        _is_colors_supported=None,
        _is_emoji_supported=None,
        config=None,
        args=None,
        kwargs={},
    )
    assert formatter.enabled == None
    assert formatter.kwargs == {}
    assert formatter.format_options == None
    assert formatter.session == None
    assert formatter.colors == None
    assert formatter.stdin == None
   

# Generated at 2022-06-11 23:54:10.113719
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONPlugin
    settings = {
        # Options
        '--pretty': 'all',
        # Formatters
        '--format': 'json', '--json.format': 'on',
        '--json.indent': None, '--json.sort_keys': 'on',
        '--json.compact': 'off',
        # Output options
        '--stream': 'off',
        '--print': 'HBhb',
        '--print-headers': 'on',
        '--follow': 'off',
        '--download': 'off',
        '--output': None,
        '--verify': 'on'
    }

# Generated at 2022-06-11 23:54:15.899023
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter()
    # f.format_body(body, mime) is called when mime is
    # valid.
    assert not f.format_body(
        body='{}',
        mime='application/json',
    ) == '{}'
    # f.format_body(body, mime) is called when mime is
    # invalid.
    assert f.format_body(
        body='{}',
        mime='json',
    ) == '{}'

# Generated at 2022-06-11 23:54:24.670707
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body(
        b'{"field": "value"}', 'json'
    ) == '{\n    "field": "value"\n}'

    assert JSONFormatter().format_body(
        b'{"field": "value"}', 'javascript'
    ) == '{\n    "field": "value"\n}'

    assert JSONFormatter().format_body(
        b'{"field": "value"}', 'text'
    ) == '{\n    "field": "value"\n}'

    assert JSONFormatter().format_body(
        b'{"field": "value"}', 'xml'
    ) == b'{"field": "value"}'


# Generated at 2022-06-11 23:54:27.941179
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    from httpie.plugins import FormatterPluginRegistry
    formatter = FormatterPluginRegistry().find_plugin('json')
    assert formatter.kwargs == formatter.format_options


# Generated at 2022-06-11 23:54:37.282673
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    f = JSONFormatter(**{'explicit_json': False,
                         'format_options': {'json': {'format': True,
                                                     'indent': 2,
                                                     'sort_keys': True}}})
    body = '{"key":"value"}'
    assert f.format_body(body, 'application/json') == '{\n  "key": "value"\n}\n' # noqa

    f = JSONFormatter(**{'explicit_json': False,
                         'format_options': {'json': {'format': False,
                                                     'indent': 2,
                                                     'sort_keys': True}}})
    body = '{"key":"value"}'
    assert f.format_body(body, 'application/json') == body