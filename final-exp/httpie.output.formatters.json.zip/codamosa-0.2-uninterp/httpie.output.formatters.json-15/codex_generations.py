

# Generated at 2022-06-17 20:35:21.967559
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter

    # Test for valid JSON
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        },
        explicit_json=False,
    )
    assert json_formatter.format_body(
        body='{"key": "value"}',
        mime='application/json'
    ) == '{\n    "key": "value"\n}'

    # Test for invalid JSON

# Generated at 2022-06-17 20:35:32.844632
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'application/javascript') == '{\n    "a": 1\n}'

# Generated at 2022-06-17 20:35:40.583289
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"key": "value"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    body = '{"key": "value"}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    body = '{"key": "value"}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    body = '{"key": "value"}'
   

# Generated at 2022-06-17 20:35:49.604510
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin

# Generated at 2022-06-17 20:36:00.542409
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:36:11.114222
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyOptions
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamOptions
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolkitOptions
    from httpie.plugins.json import JSONToolkitPlugin
    from httpie.plugins.json import JSONToolkitPrettyOptions
    from httpie.plugins.json import JSONToolkitPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamOptions
    from httpie.plugins.json import JSONToolkitStreamPlugin
    from httpie.plugins.json import JSONTool

# Generated at 2022-06-17 20:36:22.966509
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/html') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:36:25.861555
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == False


# Generated at 2022-06-17 20:36:37.426130
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:36:48.098918
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body

# Generated at 2022-06-17 20:36:57.419023
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1}', 'json') == '{\n  "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n  "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n  "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:37:04.016168
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:37:06.366379
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.kwargs == {}
    assert formatter.format_options == {}


# Generated at 2022-06-17 20:37:11.185725
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"b": 2, "a": 1}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:37:18.314225
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    assert json_formatter.enabled == True
    assert json_formatter.kwargs['explicit_json'] == False
    assert json_formatter.format_options['json']['format'] == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:37:25.735216
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:37:32.116483
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }
    }
    json_formatter.kwargs = {
        'explicit_json': False
    }
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:37:42.821355
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(body='{"a": 1}', mime='json') == '{\n    "a": 1\n}'
    assert formatter.format_body(body='{"a": 1}', mime='text') == '{\n    "a": 1\n}'
    assert formatter.format_body(body='{"a": 1}', mime='javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body(body='{"a": 1}', mime='html') == '{"a": 1}'
    assert formatter.format_body(body='{"a": 1}', mime='xml') == '{"a": 1}'

# Generated at 2022-06-17 20:37:48.794679
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:37:59.882604
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyFormatter
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamFormatter
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolFormatter
    from httpie.plugins.json import JSONToolPlugin
    from httpie.plugins.json import JSONToolPrettyFormatter
    from httpie.plugins.json import JSONToolPrettyPlugin
    from httpie.plugins.json import JSONToolStreamFormatter
    from httpie.plugins.json import JSONToolStreamPlugin
    from httpie.plugins.json import JSONToolUnicodeFormatter

# Generated at 2022-06-17 20:38:08.883025
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"key":"value"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

# Generated at 2022-06-17 20:38:20.251784
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    json_formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test with invalid JSON
    body = '{"key": "value"'
    assert json_formatter.format_body(body, mime) == body

    # Test with valid JSON and mime type not json
    mime = 'text'
    assert json_formatter.format_body(body, mime) == body

    # Test with valid JSON and mime type not json
    mime = 'javascript'
    assert json_formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

# Generated at 2022-06-17 20:38:31.117085
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'

# Generated at 2022-06-17 20:38:35.927050
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": "b"}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": "b"\n}'

# Generated at 2022-06-17 20:38:39.761832
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:38:50.004877
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(
        '{"a": 1, "b": 2}',
        'application/json'
    ) == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(
        '{"a": 1, "b": 2}',
        'application/javascript'
    ) == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(
        '{"a": 1, "b": 2}',
        'text/plain'
    ) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:38:56.277908
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1: JSON body
    json_body = '{"a": 1, "b": 2}'
    json_formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body(json_body, 'json') == '{\n  "a": 1,\n  "b": 2\n}'

    # Test 2: Non-JSON body
    non_json_body = '<html><body>Hello, world!</body></html>'
    json_formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_

# Generated at 2022-06-17 20:39:05.041219
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.format_options['json']['format'] = True
    json_formatter.format_options['json']['indent'] = 4
    json_formatter.format_options['json']['sort_keys'] = True
    json_formatter.kwargs['explicit_json'] = False

    body = '{"a": 1, "b": 2}'
    mime = 'json'
    expected = '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body(body, mime) == expected

    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:39:14.821651
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for valid JSON
    assert JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}}).format_body('{"key": "value"}', 'json') == '{\n    "key": "value"\n}'
    # Test for invalid JSON
    assert JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}}).format_body('{"key": "value"', 'json') == '{"key": "value"'
    # Test for valid JSON with explicit_json

# Generated at 2022-06-17 20:39:23.494427
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:39:45.839226
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyOptions
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamOptions
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolkitOptions
    from httpie.plugins.json import JSONToolkitPlugin
    from httpie.plugins.json import JSONToolkitPrettyOptions
    from httpie.plugins.json import JSONToolkitPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamOptions
    from httpie.plugins.json import JSONToolkitStreamPlugin
    from httpie.plugins.json import JSONTool

# Generated at 2022-06-17 20:39:56.850018
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:40:07.574383
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/html') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:40:09.326744
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})

# Generated at 2022-06-17 20:40:15.448232
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a":1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a":1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a":1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a":1}', 'html') == '{"a":1}'
    assert formatter.format_body('{"a":1}', 'xml') == '{"a":1}'
    assert formatter.format_body('{"a":1}', 'text/html') == '{"a":1}'

# Generated at 2022-06-17 20:40:20.935991
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:40:30.589669
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:40:32.559203
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:40:39.552752
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:40:44.278609
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    })
    body = '{"foo": "bar"}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:41:25.430574
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{\n    "a": 1\n}'
    assert formatter.format

# Generated at 2022-06-17 20:41:30.200463
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'plain') == '{"a": 1}'

# Generated at 2022-06-17 20:41:39.691308
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'csv') == '{"a": 1}'

# Generated at 2022-06-17 20:41:47.168900
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    }, explicit_json=False)
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:41:59.121492
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'html') == '{"foo": "bar"}'
    assert formatter.format_body('{"foo": "bar"}', 'xml') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:42:07.671935
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body(
        '{"a": "b"}',
        'json'
    ) == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        '{"a": "b"}',
        'text'
    ) == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        '{"a": "b"}',
        'javascript'
    ) == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        '{"a": "b"}',
        'html'
    ) == '{"a": "b"}'

# Generated at 2022-06-17 20:42:18.956270
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:42:24.970941
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:42:35.196361
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:42:39.124520
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:43:39.813548
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:43:48.952637
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:44:00.980199
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1:
    #   - body: '{"a": 1, "b": 2}'
    #   - mime: 'json'
    #   - format_options: {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    #   - explicit_json: False
    #   - expected: '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    explicit_json = False
    expected = '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:44:06.270820
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:44:14.193486
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'

# Generated at 2022-06-17 20:44:20.639323
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import PrettyJSONFormatter
    from httpie.plugins import PrettyOptionsPlugin
    from httpie.plugins import PrettyOptions
    from httpie.plugins import PrettyOptionsPlugin
    from httpie.plugins import PrettyOptions
    from httpie.plugins import PrettyOptionsPlugin
    from httpie.plugins import PrettyOptions
    from httpie.plugins import PrettyOptionsPlugin
    from httpie.plugins import PrettyOptions
    from httpie.plugins import PrettyOptionsPlugin
    from httpie.plugins import PrettyOptions
    from httpie.plugins import PrettyOptionsPlugin
    from httpie.plugins import PrettyOptions
    from httpie.plugins import PrettyOptionsPlugin
    from httpie.plugins import PrettyOptions
    from httpie.plugins import PrettyOptionsPlugin

# Generated at 2022-06-17 20:44:30.299740
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:44:37.000856
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows

# Generated at 2022-06-17 20:44:47.069846
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    # Input:
    #   body = '{"a": 1, "b": 2}'
    #   mime = 'json'
    #   kwargs = {'explicit_json': False}
    #   format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    # Expected output:
    #   body = '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    kwargs = {'explicit_json': False}
    format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}

# Generated at 2022-06-17 20:44:59.780229
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'plain') == '{"a": 1}'