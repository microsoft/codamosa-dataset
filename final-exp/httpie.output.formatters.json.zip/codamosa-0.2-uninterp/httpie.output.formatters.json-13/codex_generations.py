

# Generated at 2022-06-17 20:35:21.183366
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'

# Generated at 2022-06-17 20:35:31.319208
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

    # Test 2
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

    # Test 3
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:35:39.943145
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:35:48.961277
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:35:55.343699
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:36:03.524035
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'
    assert json_formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'

# Generated at 2022-06-17 20:36:12.162783
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    #   Input:
    #       body: '{"a": 1, "b": 2}'
    #       mime: 'application/json'
    #   Expected output:
    #       '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}).format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

    # Test case 2:
    #   Input:
    #       body: '{"a": 1, "b": 2}'
    #      

# Generated at 2022-06-17 20:36:23.204116
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.plugins.builtin.formatter

    # Create a JSONFormatter object
    json_formatter = httpie.plugins.builtin.formatter.JSONFormatter()

    # Create a JSON object

# Generated at 2022-06-17 20:36:34.465476
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:36:37.155375
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})


# Generated at 2022-06-17 20:36:51.018012
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:36:54.117727
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:36:59.123945
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    body = '{"key": "value"}'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body(body, mime) == '{\n  "key": "value"\n}'

    # Test with invalid JSON
    body = '{"key": "value"}'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body(body, mime) == '{\n  "key": "value"\n}'

# Generated at 2022-06-17 20:37:08.961333
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body(
        '{"a": "b"}',
        'application/json'
    ) == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        '{"a": "b"}',
        'text/javascript'
    ) == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        '{"a": "b"}',
        'text/plain'
    ) == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        '{"a": "b"}',
        'text/html'
    ) == '{"a": "b"}'
    assert json_formatter

# Generated at 2022-06-17 20:37:16.830522
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'

# Generated at 2022-06-17 20:37:21.858690
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:37:32.269094
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:37:42.345319
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{"a": 1, "b": 2}'

# Generated at 2022-06-17 20:37:48.561666
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:37:59.812159
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'

# Generated at 2022-06-17 20:38:21.807280
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import PrettyJSONFormatter
    from httpie.plugins import RawJSONFormatter
    from httpie.plugins import StreamJSONFormatter
    from httpie.plugins import JSONStreamFormatter
    from httpie.plugins import JSONLinesFormatter
    from httpie.plugins import JSONLinesStreamFormatter
    from httpie.plugins import JSONLinesPrettyFormatter
    from httpie.plugins import JSONLinesRawFormatter
    from httpie.plugins import JSONLinesStreamPrettyFormatter
    from httpie.plugins import JSONLinesStreamRawFormatter
    from httpie.plugins import JSONLinesStreamStreamFormatter
    from httpie.plugins import JSONLinesStreamStreamPrettyFormatter
    from httpie.plugins import JSONLinesStreamStreamRaw

# Generated at 2022-06-17 20:38:32.342849
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:38:37.785670
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:38:49.259452
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:38:54.710482
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    json_formatter = JSONFormatter()
    body = '{"a": "b"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

    # Test 2
    json_formatter = JSONFormatter()
    body = '{"a": "b"}'
    mime = 'javascript'
    assert json_formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

    # Test 3
    json_formatter = JSONFormatter()
    body = '{"a": "b"}'
    mime = 'text'

# Generated at 2022-06-17 20:38:59.614725
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:39:08.167340
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    #   Input:
    #       body = '{"a": "b"}'
    #       mime = 'json'
    #       kwargs = {'explicit_json': False}
    #       format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    #   Expected output:
    #       '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'json'
    kwargs = {'explicit_json': False}
    format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    formatter = JSONFormatter(kwargs=kwargs, format_options=format_options)
   

# Generated at 2022-06-17 20:39:17.463926
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": "b"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'html'

# Generated at 2022-06-17 20:39:24.819318
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    import json
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolkitPlugin
    from httpie.plugins.json import JSONToolkitPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamPlugin
    from httpie.plugins.json import JSONToolkitStreamPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamPrettyPlugin

# Generated at 2022-06-17 20:39:31.497319
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:39:54.708631
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:40:05.440487
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:40:13.019489
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body

# Generated at 2022-06-17 20:40:24.185973
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with invalid JSON
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"foo": "bar", "baz": "qux"}', 'json') == '{\n    "baz": "qux",\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar", "baz": "qux"}', 'javascript') == '{\n    "baz": "qux",\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:40:28.572354
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:40:29.202866
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter()

# Generated at 2022-06-17 20:40:37.225226
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'

# Generated at 2022-06-17 20:40:46.335473
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    body = '{"a": "b"}'
    mime = 'json'
    expected_result = '{\n    "a": "b"\n}'
    formatter = JSONFormatter()
    assert formatter.format_body(body, mime) == expected_result

    # Test case 2
    body = '{"a": "b"}'
    mime = 'javascript'
    expected_result = '{\n    "a": "b"\n}'
    formatter = JSONFormatter()
    assert formatter.format_body(body, mime) == expected_result

    # Test case 3
    body = '{"a": "b"}'
    mime = 'text'
    expected_result = '{\n    "a": "b"\n}'
    formatter = JSON

# Generated at 2022-06-17 20:40:59.023719
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyFormatter
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamFormatter
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolkitFormatter
    from httpie.plugins.json import JSONToolkitPlugin
    from httpie.plugins.json import JSONToolkitPrettyFormatter
    from httpie.plugins.json import JSONToolkitPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamFormatter
    from httpie.plugins.json import JSONToolkitStreamPlugin
    from httpie.plugins.json import JSONToolkitStreamPrettyFormatter
   

# Generated at 2022-06-17 20:41:05.862611
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            }
        },
        explicit_json=False,
    )
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:41:39.158699
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxHighlightFormatter
    from httpie.plugins.builtin import SyntaxHighlightOptions
    from httpie.plugins.builtin import UnicodeOutput
    from httpie.plugins.builtin import UnicodeOutputOptions
    from httpie.plugins.builtin import VerboseFormatter
    from httpie.plugins.builtin import VerboseOptions
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_response_stream


# Generated at 2022-06-17 20:41:49.100406
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body

# Generated at 2022-06-17 20:41:59.906179
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:42:06.359376
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'

# Generated at 2022-06-17 20:42:17.744936
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:42:23.900327
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:42:27.418384
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:42:35.863269
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/plain') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'application/javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'application/xml') == '{"a": 1}'

# Generated at 2022-06-17 20:42:42.969930
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    json_formatter.kwargs = {'explicit_json': False}
    body = '{"a": "b"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

    # Test 2
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    json_formatter.kwargs = {'explicit_json': False}
    body = '{"a": "b"}'
    mime = 'javascript'
    assert json

# Generated at 2022-06-17 20:42:47.153288
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = json_formatter.format_body('{"a": 1, "b": 2}', 'application/json')
    assert body == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:43:36.781700
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.kwargs == {}
    assert formatter.format_options == {}


# Generated at 2022-06-17 20:43:46.244275
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for valid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'

    # Test for invalid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2', 'json') == '{"a": 1, "b": 2'

    # Test for valid JSON with explicit_json

# Generated at 2022-06-17 20:43:56.438701
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        },
        explicit_json=False,
    )
    assert formatter.format_body(
        '{"a": 1, "b": 2}',
        'application/json'
    ) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:44:00.954531
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:44:11.376686
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:44:15.063517
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:44:21.235545
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import HTTPBody
    from httpie.plugins.builtin import HTTPTraceback
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import HTTPStats
    from httpie.plugins.builtin import HTTPPretty
    from httpie.plugins.builtin import HTTPInfo
    from httpie.plugins.builtin import HTTPBinary
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import HTTPTr

# Generated at 2022-06-17 20:44:30.802882
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:44:37.334506
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:44:42.182071
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True
