

# Generated at 2022-06-17 20:35:21.557142
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'plain') == '{"a": 1}'

# Generated at 2022-06-17 20:35:31.604767
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:35:40.162427
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:35:49.171947
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{\n    "a": 1\n}'
    assert formatter.format

# Generated at 2022-06-17 20:36:00.078395
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyOptions
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamOptions
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolbarOptions
    from httpie.plugins.json import JSONToolbarPlugin
    from httpie.plugins.json import JSONToolbarPrettyOptions
    from httpie.plugins.json import JSONToolbarPrettyPlugin
    from httpie.plugins.json import JSONToolbarStreamOptions
    from httpie.plugins.json import JSONToolbarStreamPlugin
    from httpie.plugins.json import JSONTool

# Generated at 2022-06-17 20:36:04.197419
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/plain') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:36:06.612955
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:36:07.814112
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False

# Generated at 2022-06-17 20:36:09.666436
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})


# Generated at 2022-06-17 20:36:16.217268
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:36:27.848764
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid json
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": "b"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n  "a": "b"\n}'

    # Test with invalid json
    body = '{"a": "b"'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{"a": "b"'

    # Test with valid json and explicit_json

# Generated at 2022-06-17 20:36:39.033835
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin

# Generated at 2022-06-17 20:36:48.687946
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'application/javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:36:59.980467
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'application/json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'application/javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/plain') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/html') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:37:09.489418
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text/plain'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text/html'

# Generated at 2022-06-17 20:37:17.871243
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import JSONOptions
    from httpie.plugins import Plugin
    from httpie.plugins import PluginManager
    from httpie.plugins import Options
    from httpie.plugins import FormatterOptions
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import JSONOptions
    from httpie.plugins import Plugin
    from httpie.plugins import PluginManager
    from httpie.plugins import Options
    from httpie.plugins import FormatterOptions
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import JSONOptions
    from httpie.plugins import Plugin
    from httpie.plugins import PluginManager

# Generated at 2022-06-17 20:37:22.630051
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:37:24.681439
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'

# Generated at 2022-06-17 20:37:34.283967
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:37:41.220571
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        }
    )
    assert formatter.enabled == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:37:59.385985
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:38:06.725010
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'html') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:38:12.393261
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:38:22.319239
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:38:27.334429
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body(body='{"a": 1, "b": 2}', mime='json') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:38:31.568283
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"foo": "bar"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:38:38.457336
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyOptions
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamOptions
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolbarOptions
    from httpie.plugins.json import JSONToolbarPlugin
    from httpie.plugins.json import JSONToolbarPrettyOptions
    from httpie.plugins.json import JSONToolbarPrettyPlugin
    from httpie.plugins.json import JSONToolbarStreamOptions
    from httpie.plugins.json import JSONToolbarStreamPlugin
    from httpie.plugins.json import JSONTool

# Generated at 2022-06-17 20:38:49.358173
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:38:59.680879
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for valid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": "b"}', 'json') == '{\n  "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'javascript') == '{\n  "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'text') == '{\n  "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'text/html') == '{"a": "b"}'

    # Test for invalid JSON
    assert json

# Generated at 2022-06-17 20:39:05.407870
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:39:24.547236
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": "b"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:39:26.001553
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"a": "b"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:39:31.295614
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:39:41.213758
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(
        '{"a": "b"}',
        'application/json'
    ) == '{\n    "a": "b"\n}'
    assert formatter.format_body(
        '{"a": "b"}',
        'application/javascript'
    ) == '{\n    "a": "b"\n}'
    assert formatter.format_body(
        '{"a": "b"}',
        'text/plain'
    ) == '{\n    "a": "b"\n}'
    assert formatter.format_body(
        '{"a": "b"}',
        'text/html'
    ) == '{"a": "b"}'

# Generated at 2022-06-17 20:39:49.670598
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:39:55.078850
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:40:05.868181
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body(body='{"a": 1, "b": 2}', mime='json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body(body='{"a": 1, "b": 2}', mime='text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body(body='{"a": 1, "b": 2}', mime='javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format

# Generated at 2022-06-17 20:40:13.312269
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:40:16.345964
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.format_options['json']['format'] == True
    assert formatter.kwargs['explicit_json'] == False


# Generated at 2022-06-17 20:40:17.669636
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-17 20:40:43.121225
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == False
    assert json_formatter.kwargs == {}
    assert json_formatter.format_options == {}


# Generated at 2022-06-17 20:40:50.232040
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for valid JSON
    body = '{"key": "value"}'
    mime = 'application/json'
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}).format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test for invalid JSON
    body = '{"key": "value"'
    mime = 'application/json'
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}).format_body(body, mime) == body

    # Test for valid JSON with explicit_json
    body = '{"key": "value"}'
    mime = 'application/json'

# Generated at 2022-06-17 20:40:56.667731
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"key1": "value1", "key2": "value2"}'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{\n  "key1": "value1",\n  "key2": "value2"\n}'

    # Test 2
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"key1": "value1", "key2": "value2"}'
    mime = 'application/javascript'
    assert json_

# Generated at 2022-06-17 20:41:05.468366
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/html') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:41:10.843783
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:41:11.946417
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True

# Generated at 2022-06-17 20:41:17.936564
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    assert formatter.format_body(
        '{"a": "b"}',
        'application/json'
    ) == '{\n  "a": "b"\n}'
    assert formatter.format_body(
        '{"a": "b"}',
        'application/javascript'
    ) == '{\n  "a": "b"\n}'
    assert formatter.format_body(
        '{"a": "b"}',
        'text/plain'
    ) == '{\n  "a": "b"\n}'
    assert formatter

# Generated at 2022-06-17 20:41:25.468848
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:41:30.244105
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'

# Generated at 2022-06-17 20:41:39.717811
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:42:28.239905
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:42:37.800983
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin

    # Test case 1
    # Input:
    #   body = '{"key": "value"}'
    #   mime = 'json'
    #   format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': True}}
    #   kwargs = {'explicit_json': False}
    # Expected output:
    #   '{\n  "key": "value"\n}'
    body = '{"key": "value"}'
    mime = 'json'

# Generated at 2022-06-17 20:42:41.811943
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-17 20:42:49.881640
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:43:00.014826
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test JSONFormatter.format_body() with valid JSON
    json_formatter = JSONFormatter()
    json_formatter.format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    }
    json_formatter.kwargs = {
        'explicit_json': False
    }
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

    # Test JSONFormatter.format_body() with invalid JSON
    json_formatter = JSONFormatter()

# Generated at 2022-06-17 20:43:11.213125
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    body = '{"key1": "value1", "key2": "value2"}'
    mime = 'application/json'
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    assert formatter.format_body(body, mime) == '{\n  "key1": "value1",\n  "key2": "value2"\n}'

    # Test with invalid JSON
    body = '{"key1": "value1", "key2": "value2"'
    mime = 'application/json'

# Generated at 2022-06-17 20:43:21.147594
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    })
    assert formatter.format_body('{"a": 1}', 'json') == '{\n  "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n  "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n  "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'


# Generated at 2022-06-17 20:43:31.018071
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    formatter

# Generated at 2022-06-17 20:43:40.589329
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import json
    import os
    import sys
    import tempfile

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    # Create the temporary file
    with os.fdopen(fd, 'w') as temp:
        temp.write('{"key1": "value1", "key2": "value2"}')

    # Read the temporary file
    with open(temp_path, 'r') as temp:
        body = temp.read()

    # Create a JSONFormatter object
    json_formatter = JSONFormatter()

    # Test the method

# Generated at 2022-06-17 20:43:45.361671
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True
