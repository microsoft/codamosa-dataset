

# Generated at 2022-06-17 20:35:23.724740
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import JSONOptions
    from httpie.plugins import Plugin
    from httpie.plugins import PluginManager
    from httpie.plugins import PluginRegistry
    from httpie.plugins import Options
    from httpie.plugins import FormatterOptions
    from httpie.plugins import PluginOptions
    from httpie.plugins import get_config_dict
    from httpie.plugins import merge_config_dict
    from httpie.plugins import merge_config_dicts
    from httpie.plugins import merge_dicts
    from httpie.plugins import merge_options
    from httpie.plugins import merge_user_config
    from httpie.plugins import merge_user_config_with_config_dict
    from httpie.plugins import merge_user_options

# Generated at 2022-06-17 20:35:33.149919
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentOptions
    from httpie.plugins.builtin import JSONPPSortKeysIndentFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentExplicitOptions
    from httpie.plugins.builtin import JSONPPSortKeysIndentExplicitFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentExplicitFormatOptions

# Generated at 2022-06-17 20:35:36.447192
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:35:47.309157
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONOptionsPlugin
    from httpie.plugins.builtin import HTTPOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import OAuth1Plugin
    from httpie.plugins.builtin import OAuth2Plugin
    from httpie.plugins.builtin import OAuth2Plugin
    from httpie.plugins.builtin import OAuth2Plugin
    from httpie.plugins.builtin import OAuth2Plugin

# Generated at 2022-06-17 20:35:54.954537
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    jf = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert jf.enabled == True
    assert jf.format_options['json']['indent'] == 2
    assert jf.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:36:02.432782
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    body = '{"a": "b", "c": "d"}'
    assert json_formatter.format_body(body, 'json') == '{\n  "a": "b",\n  "c": "d"\n}'

    # Test with invalid JSON
    body = '{"a": "b", "c": "d"}'
    assert json_formatter.format_body(body, 'text') == body

# Generated at 2022-06-17 20:36:11.643693
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={"json": {"format": True, "indent": 4, "sort_keys": True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:36:14.754098
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})

# Generated at 2022-06-17 20:36:25.603346
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs['explicit_json'] = True
    json_formatter.format_options['json']['format'] = True
    json_formatter.format_options['json']['indent'] = 2
    json_formatter.format_options['json']['sort_keys'] = True
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:36:30.086245
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:36:41.415356
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/plain') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'application/javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'application/xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'application/xhtml+xml') == '{"a": 1}'
    assert form

# Generated at 2022-06-17 20:36:49.899892
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False)
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'application/javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/plain') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/xml') == '{"a": 1}'

# Generated at 2022-06-17 20:37:00.418724
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    json_formatter = JSONFormatter()
    json_formatter.kwargs = {'explicit_json': False}
    json_formatter.format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    }
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

    # Test case 2
    json_formatter.kwargs = {'explicit_json': True}

# Generated at 2022-06-17 20:37:05.968492
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:37:10.496107
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-17 20:37:19.442933
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:37:27.237664
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.manager import plugin_manager_class
    from httpie.plugins.manager import plugin_manager_kwargs
    from httpie.plugins.manager import plugin_manager_singleton
    from httpie.plugins.manager import plugin_manager_singleton_class
    from httpie.plugins.manager import plugin_manager_singleton_kwargs
    from httpie.plugins.manager import plugin_manager_singleton_obj
    from httpie.plugins.manager import plugin_manager_singleton_obj_class
    from httpie.plugins.manager import plugin_manager_

# Generated at 2022-06-17 20:37:37.082132
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:37:42.306449
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 2


# Generated at 2022-06-17 20:37:46.075528
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    })
    body = '{"a": "b"}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:37:58.358315
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'

# Generated at 2022-06-17 20:38:03.815501
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:38:10.351173
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONOptionsPlugin
    from httpie.plugins.builtin import HTTPOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import UnixSocketPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin


# Generated at 2022-06-17 20:38:21.431977
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    # Test with valid JSON
    # Expected result: JSON is formatted
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

    # Test 2
    # Test with invalid JSON
    # Expected result: JSON is not formatted

# Generated at 2022-06-17 20:38:32.341990
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:38:37.785874
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:38:49.256364
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    assert formatter.format_body(body, 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(body, 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(body, 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(body, 'html') == body
    assert formatter.format_body(body, 'xml') == body
    assert formatter.format_body(body, 'csv') == body
    assert formatter.format_body(body, 'yaml')

# Generated at 2022-06-17 20:38:54.710511
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:39:03.861616
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True
            }
        },
        explicit_json=False
    )
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:39:13.405633
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text/plain'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text/html'

# Generated at 2022-06-17 20:39:28.051535
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"a": "b"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:39:38.776539
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:39:44.628362
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:39:48.064716
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:39:59.179036
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    mime = 'html'
    assert formatter.format_body(body, mime) == '{"a": 1, "b": 2}'

# Generated at 2022-06-17 20:40:09.518264
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:40:20.081051
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentOptions
    from httpie.plugins.builtin import JSONPPSortKeysIndentFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentExplicitOptions
    from httpie.plugins.builtin import JSONPPSortKeysIndentExplicitFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentExplicitFormatOptions

# Generated at 2022-06-17 20:40:29.899166
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:40:37.785488
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/html') == '{"foo": "bar"}'
    assert formatter.format_body('{"foo": "bar"}', 'text/html; charset=utf-8') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:40:46.765890
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.format_options = {
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }
    }
    json_formatter.kwargs = {
        'explicit_json': False
    }
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    mime = 'text'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    mime = 'javascript'

# Generated at 2022-06-17 20:41:18.277503
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:41:21.754744
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:41:33.391140
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert JSONFormatter(format_options={'json': {'format': False, 'indent': 2, 'sort_keys': True}})
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': False}})
    assert JSONFormatter(format_options={'json': {'format': False, 'indent': 2, 'sort_keys': False}})
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})

# Generated at 2022-06-17 20:41:37.287318
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:41:44.245002
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 4
        }
    })
    body = '{"foo": "bar"}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:41:50.546444
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:41:52.472755
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-17 20:41:58.197347
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:42:02.759113
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:42:08.659900
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:43:11.102710
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    # Input:
    #   body = '{"key": "value"}'
    #   mime = 'json'
    #   kwargs = {'explicit_json': True}
    #   format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    # Expected output:
    #   '{\n    "key": "value"\n}'
    body = '{"key": "value"}'
    mime = 'json'
    kwargs = {'explicit_json': True}
    format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    formatter = JSONFormatter(kwargs=kwargs, format_options=format_options)
    assert form

# Generated at 2022-06-17 20:43:20.684946
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'


# Generated at 2022-06-17 20:43:30.639766
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:43:36.406739
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:43:46.205414
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:44:00.215551
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:44:10.711924
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == body

    # Test 2
    formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'text'
    assert formatter.format_body(body, mime) == body

    # Test 3
    formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == body

    # Test 4
    formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'html'

# Generated at 2022-06-17 20:44:14.726064
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:44:25.481818
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxHighlightPlugin
    from httpie.plugins.builtin import UnicodeDisplayPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.manager import plugin_manager_class
    from httpie.plugins.manager import plugin_manager_help
    from httpie.plugins.manager import plugin_manager_load
    from httpie.plugins.manager import plugin_manager_load_builtin
    from httpie.plugins.manager import plugin_manager_load_external
    from httpie.plugins.manager import plugin_

# Generated at 2022-06-17 20:44:30.692628
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True
