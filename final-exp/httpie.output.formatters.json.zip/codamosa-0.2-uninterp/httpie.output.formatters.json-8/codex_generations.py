

# Generated at 2022-06-17 20:35:19.493910
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.kwargs == {}
    assert formatter.format_options == {}


# Generated at 2022-06-17 20:35:25.919756
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # Test 1
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    # Test 2
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    # Test 3
    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:35:30.058733
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:35:38.780085
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    # Input:
    #   body = '{"key": "value"}'
    #   mime = 'application/json'
    #   kwargs = {'explicit_json': False}
    #   format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 2}}
    # Expected output:
    #   '{\n  "key": "value"\n}'
    body = '{"key": "value"}'
    mime = 'application/json'
    kwargs = {'explicit_json': False}
    format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 2}}
    json_formatter = JSONFormatter(kwargs, format_options)
    assert json_form

# Generated at 2022-06-17 20:35:43.200471
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-17 20:35:52.006291
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    body = '{"a": 1, "b": 2}'
    mime = 'text/plain'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    body = '{"a": 1, "b": 2}'
    mime = 'text/html'

# Generated at 2022-06-17 20:36:00.042812
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:36:11.078050
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:36:22.965375
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONOptionsPlugin
    from httpie.plugins.builtin import HTTPOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPAuthOptionsPlugin
    from httpie.plugins.builtin import SessionPlugin

# Generated at 2022-06-17 20:36:25.499245
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:36:39.218579
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/plain') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'application/javascript') == '{\n    "a": 1\n}'

# Generated at 2022-06-17 20:36:44.695672
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:36:48.098265
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:36:50.901537
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"foo": "bar"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:37:00.739619
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": "b", "c": "d"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n  "a": "b",\n  "c": "d"\n}'

    # Test with invalid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": "b", "c": "d"}'
    mime = 'text'
    assert json_formatter.format_body(body, mime)

# Generated at 2022-06-17 20:37:10.564845
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    })
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/plain') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/javascript') == '{\n    "a": 1\n}'

# Generated at 2022-06-17 20:37:19.444136
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    #   Input:
    #       body: '{"a": 1, "b": 2}'
    #       mime: 'json'
    #       kwargs:
    #           explicit_json: False
    #           format_options:
    #               json:
    #                   format: True
    #                   sort_keys: True
    #                   indent: 4
    #   Expected output:
    #       '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'json'

# Generated at 2022-06-17 20:37:22.715474
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"a": "b"}'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:37:32.873267
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True,
        }
    })
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:37:43.535612
# Unit test for method format_body of class JSONFormatter

# Generated at 2022-06-17 20:37:54.230121
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import JSONPPOptions
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import StreamOptions
    from httpie.plugins.builtin import SyntaxOptions
    from httpie.plugins.builtin import SyntaxFormatter
    from httpie.plugins.builtin import UnicodeOptions
    from httpie.plugins.builtin import UnicodeFormatter
    from httpie.plugins.builtin import format_options

# Generated at 2022-06-17 20:38:04.595756
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    # Input:
    #   body = '{"a": 1, "b": 2}'
    #   mime = 'json'
    #   kwargs = {'explicit_json': True, 'format_options': {'json': {'format': True, 'indent': 2, 'sort_keys': True}}}
    # Expected output:
    #   '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    kwargs = {'explicit_json': True, 'format_options': {'json': {'format': True, 'indent': 2, 'sort_keys': True}}}
    json_formatter = JSONFormatter(**kwargs)

# Generated at 2022-06-17 20:38:16.215264
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:38:25.056746
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/html') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:38:33.958222
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import JSONOptions
    from httpie.plugins import Options
    from httpie.plugins import Plugin
    from httpie.plugins import PluginManager
    from httpie.plugins import PluginRegistry
    from httpie.plugins import PluginRegistryError
    from httpie.plugins import PluginRegistryValueError
    from httpie.plugins import PluginRegistryWarning
    from httpie.plugins import PluginRegistryWarning
    from httpie.plugins import PluginRegistryWarning
    from httpie.plugins import PluginRegistryWarning
    from httpie.plugins import PluginRegistryWarning
    from httpie.plugins import PluginRegistryWarning
    from httpie.plugins import PluginRegistryWarning
    from httpie.plugins import PluginRegistryWarning

# Generated at 2022-06-17 20:38:41.263722
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    # Test for valid JSON
    body = '{"key": "value"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == body
    # Test for invalid JSON
    body = '{"key": "value"'
    mime = 'json'
    assert formatter.format_body(body, mime) == body
    # Test for valid JSON with explicit_json
    body = '{"key": "value"}'
    mime = 'text'
    assert formatter.format_body(body, mime) == body
    # Test for invalid JSON with explicit_json
    body = '{"key": "value"'
    mime = 'text'
    assert formatter.format_body(body, mime) == body

# Generated at 2022-06-17 20:38:51.091131
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import JSONPPOptions
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import StreamOptions
    from httpie.plugins.builtin import SyntaxOptions
    from httpie.plugins.builtin import SyntaxFormatter
    from httpie.plugins.builtin import UnicodeOptions
    from httpie.plugins.builtin import UnicodeFormatter
    from httpie.plugins.builtin import format_options

# Generated at 2022-06-17 20:38:56.818682
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert json_formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:39:05.689000
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    #   - Input:
    #       + body = '{"a": 1, "b": 2}'
    #       + mime = 'json'
    #       + kwargs = {'explicit_json': False}
    #       + format_options = {
    #           'json': {
    #               'format': True,
    #               'indent': 4,
    #               'sort_keys': True
    #           }
    #       }
    #   - Expected output:
    #       + '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    kwargs = {'explicit_json': False}

# Generated at 2022-06-17 20:39:11.877655
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'