

# Generated at 2022-06-17 20:35:27.940567
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:35:35.245700
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:35:40.624312
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentOptions
    from httpie.plugins.builtin import JSONPPSortKeysIndentFormatter

    # Test JSONFormatter
    json_formatter = JSONFormatter(format_options={'json': JSONOptions()})
    assert json_formatter.format_body('{"a": 1}', 'json') == '{"a": 1}'

# Generated at 2022-06-17 20:35:46.334643
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:35:58.999193
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.context import Environment
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_HELP
    from httpie.output.streams import Error
    from httpie.compat import str
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py34
    from httpie.compat import is_py35

# Generated at 2022-06-17 20:36:11.016362
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import PrettyOptionsPlugin
    from httpie.plugins import JSONOptionsPlugin
    from httpie.plugins import HTTPOptionsPlugin
    from httpie.plugins import AuthPlugin
    from httpie.plugins import AutoJSONPlugin
    from httpie.plugins import HTTPBasicAuth
    from httpie.plugins import DigestAuth
    from httpie.plugins import OAuth1Auth
    from httpie.plugins import OAuth2Auth
    from httpie.plugins import OAuth2Plugin
    from httpie.plugins import AuthPlugin
    from httpie.plugins import AuthCredentials
    from httpie.plugins import AuthCredentialsPlugin
    from httpie.plugins import AuthPlugin
    from httpie.plugins import AuthCredentials
    from httpie.plugins import AuthC

# Generated at 2022-06-17 20:36:22.569384
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'yaml') == '{"a": 1}'

# Generated at 2022-06-17 20:36:24.324591
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})


# Generated at 2022-06-17 20:36:35.240867
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:36:42.101157
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyOptions
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamOptions
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolkitOptions
    from httpie.plugins.json import JSONToolkitPlugin
    from httpie.plugins.json import JSONToolkitPrettyOptions
    from httpie.plugins.json import JSONToolkitPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamOptions
    from httpie.plugins.json import JSONToolkitStreamPlugin
    from httpie.plugins.json import JSONTool

# Generated at 2022-06-17 20:36:52.434657
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'

# Generated at 2022-06-17 20:37:01.170563
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    # Input:
    #   body = '{"a": 1, "b": 2}'
    #   mime = 'json'
    #   self.kwargs['explicit_json'] = False
    #   self.format_options['json']['sort_keys'] = False
    #   self.format_options['json']['indent'] = 4
    # Expected output:
    #   '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, json={'format': True, 'sort_keys': False, 'indent': 4})

# Generated at 2022-06-17 20:37:08.274335
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:37:17.776378
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import JSONOptions
    from httpie.plugins import Plugin
    from httpie.plugins import PluginManager
    from httpie.plugins import PluginRegistry
    from httpie.plugins import PluginSettings
    from httpie.plugins import PluginType
    from httpie.plugins import get_plugin_manager
    from httpie.plugins import get_plugin_registry
    from httpie.plugins import get_plugin_settings
    from httpie.plugins import get_plugin_type
    from httpie.plugins import get_plugins
    from httpie.plugins import load_plugins
    from httpie.plugins import merge_settings
    from httpie.plugins import merge_user_settings
    from httpie.plugins import merge_user_settings_from_file
   

# Generated at 2022-06-17 20:37:26.143028
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyOptions
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamOptions
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolkitOptions
    from httpie.plugins.json import JSONToolkitPlugin
    from httpie.plugins.json import JSONToolkitPrettyOptions
    from httpie.plugins.json import JSONToolkitPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamOptions
    from httpie.plugins.json import JSONToolkitStreamPlugin
    from httpie.plugins.json import JSONTool

# Generated at 2022-06-17 20:37:30.384798
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:37:35.774846
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:37:45.061143
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1:
    #   - body: '{"a": 1, "b": 2}'
    #   - mime: 'json'
    #   - kwargs: {'explicit_json': False}
    #   - format_options: {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    #   - expected: '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    kwargs = {'explicit_json': False}
    format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}

# Generated at 2022-06-17 20:37:54.984801
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:38:05.321045
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert json_formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:38:16.472143
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:38:25.208465
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:38:29.376107
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:38:37.512973
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'application/javascript'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text/plain'

# Generated at 2022-06-17 20:38:41.099402
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.kwargs == {}
    assert formatter.format_options == {}


# Generated at 2022-06-17 20:38:51.087797
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONOptionsPlugin
    from httpie.plugins.builtin import HTTPOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import OAuth1AuthPlugin
    from httpie.plugins.builtin import OAuth2AuthPlugin
    from httpie.plugins.builtin import OAuth2AuthPlugin
    from httpie.plugins.builtin import OAuth2AuthPlugin

# Generated at 2022-06-17 20:38:52.641763
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})


# Generated at 2022-06-17 20:39:02.488341
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'


# Generated at 2022-06-17 20:39:11.267108
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a":1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'html') == '{"a":1}'
    assert json_formatter.format_body('{"a":1}', 'xml') == '{"a":1}'
    assert json_formatter.format_body('{"a":1}', 'csv') == '{"a":1}'

# Generated at 2022-06-17 20:39:19.164971
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    body = '{"a":1,"b":2,"c":3}'
    mime = 'json'
    formatter = JSONFormatter()
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

    # Test with invalid JSON
    body = '{"a":1,"b":2,"c":3'
    mime = 'json'
    formatter = JSONFormatter()
    assert formatter.format_body(body, mime) == body

    # Test with valid JSON but not JSON mime
    body = '{"a":1,"b":2,"c":3}'
    mime = 'text'
    formatter = JSONFormatter()

# Generated at 2022-06-17 20:39:36.935260
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:39:46.559152
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:39:50.961667
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-17 20:39:56.337625
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:40:07.064343
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    # Input:
    #   body = '{"name": "httpie"}'
    #   mime = 'json'
    #   kwargs = {'explicit_json': False}
    #   format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    # Expected output:
    #   '{\n    "name": "httpie"\n}'
    body = '{"name": "httpie"}'
    mime = 'json'
    kwargs = {'explicit_json': False}
    format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    json_formatter = JSONFormatter(**kwargs)
    json_formatter.format_options

# Generated at 2022-06-17 20:40:10.902711
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 2


# Generated at 2022-06-17 20:40:21.762710
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysFormatter
    from httpie.plugins.builtin import JSONSortKeysFormatter
    from httpie.plugins.builtin import JSONSortKeysOptions
    from httpie.plugins.builtin import JSONIndentFormatter
    from httpie.plugins.builtin import JSONIndentOptions
    from httpie.plugins.builtin import JSONPPSortKeysIndentFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentOptions

# Generated at 2022-06-17 20:40:28.840024
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:40:36.993707
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body(body='{"a": 1, "b": 2}', mime='json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(body='{"a": 1, "b": 2}', mime='text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(body='{"a": 1, "b": 2}', mime='javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:40:39.807848
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})


# Generated at 2022-06-17 20:41:13.491187
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    body = '{"foo": "bar"}'
    mime = 'application/json'
    assert JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}}).format_body(body, mime) == '{\n  "foo": "bar"\n}'
    # Test case 2
    body = '{"foo": "bar"}'
    mime = 'application/json'
    assert JSONFormatter(format_options={'json': {'format': False, 'sort_keys': True, 'indent': 2}}).format_body(body, mime) == '{"foo": "bar"}'
    # Test case 3
    body = '{"foo": "bar"}'
    mime = 'application/json'
    assert JSONFormatter

# Generated at 2022-06-17 20:41:18.921128
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for valid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:41:25.852945
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:41:37.359150
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:41:47.988300
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1:
    # Input:
    #   body = '{"key": "value"}'
    #   mime = 'json'
    #   kwargs = {'explicit_json': False}
    #   format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    # Expected output:
    #   '{\n    "key": "value"\n}'
    body = '{"key": "value"}'
    mime = 'json'
    kwargs = {'explicit_json': False}
    format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    json_formatter = JSONFormatter(kwargs=kwargs, format_options=format_options)

# Generated at 2022-06-17 20:41:59.472094
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:42:07.881641
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    #   - body: '{"a": 1, "b": 2}'
    #   - mime: 'application/json'
    #   - kwargs['explicit_json']: False
    #   - format_options['json']['format']: True
    #   - format_options['json']['sort_keys']: True
    #   - format_options['json']['indent']: 4
    #   - expected: '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    kwargs = {'explicit_json': False}

# Generated at 2022-06-17 20:42:16.903289
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'html') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:42:23.011781
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager

# Generated at 2022-06-17 20:42:32.805494
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": "b"}', 'application/json') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text/plain') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text/html') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text/xml') == '{\n  "a": "b"\n}'

# Generated at 2022-06-17 20:43:32.345461
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:43:41.017095
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.compat import is_py26
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    # Test case 1
    # Input:
    #   body = '{"name": "John", "age": 30, "car": null}'
    #   mime = 'json'
    #   kwargs = {'explicit_json': False}
    #   format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    # Expected output:
    #   body = '{\n    "age": 30,\n    "car": null,\n    "name": "John"\n}'

# Generated at 2022-06-17 20:43:47.218243
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(
        '{"a": 1, "b": 2}',
        'application/json'
    ) == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(
        '{"a": 1, "b": 2}',
        'application/javascript'
    ) == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(
        '{"a": 1, "b": 2}',
        'text/plain'
    ) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:44:00.372886
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:44:07.117813
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:44:09.608713
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True


# Generated at 2022-06-17 20:44:14.619779
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for method format_body of class JSONFormatter
    # Arrange
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": "b"}'
    mime = 'json'
    expected = '{\n  "a": "b"\n}'

    # Act
    actual = formatter.format_body(body, mime)

    # Assert
    assert actual == expected

# Generated at 2022-06-17 20:44:17.130383
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})


# Generated at 2022-06-17 20:44:22.823597
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    #   Input:
    #       body = '{"key": "value"}'
    #       mime = 'json'
    #   Expected output:
    #       body = '{\n    "key": "value"\n}'
    body = '{"key": "value"}'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}})
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test case 2:
    #   Input:
    #       body = '{"key": "value"}'
    #       mime = 'text'
    #   Ex

# Generated at 2022-06-17 20:44:29.471594
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'