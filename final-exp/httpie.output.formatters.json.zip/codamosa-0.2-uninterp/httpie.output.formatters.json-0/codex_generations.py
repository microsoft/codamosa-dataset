

# Generated at 2022-06-17 20:35:22.341739
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'

# Generated at 2022-06-17 20:35:28.189198
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": "b"}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:35:35.307040
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import PrettyJSONFormatter
    from httpie.plugins import PrettyOptionsPlugin
    from httpie.plugins import RawJSONFormatter
    from httpie.plugins import RawOptionsPlugin
    from httpie.plugins import StreamFormatter
    from httpie.plugins import StreamOptionsPlugin
    from httpie.plugins import SyntaxPlugin
    from httpie.plugins import SyntaxOptionsPlugin
    from httpie.plugins import UnicodePlugin
    from httpie.plugins import UnicodeOptionsPlugin
    from httpie.plugins import get_plugin_manager
    from httpie.plugins import get_plugins
    from httpie.plugins import get_plugin_class
    from httpie.plugins import get_plugin_classes
    from httpie.plugins import get_plugin_instances
   

# Generated at 2022-06-17 20:35:39.131531
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:35:48.155061
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:35:52.850235
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:36:03.053801
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:36:11.926045
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import JSONFormatter
   

# Generated at 2022-06-17 20:36:23.203954
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{'explicit_json': False, 'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}})
    assert json_formatter.format_body('{"a":1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'text/html') == '{"a":1}'

# Generated at 2022-06-17 20:36:34.465709
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    formatter = JSONFormatter