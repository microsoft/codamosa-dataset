

# Generated at 2022-06-17 20:35:21.740158
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:35:32.509392
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:35:34.436995
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})


# Generated at 2022-06-17 20:35:38.852111
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 2
        }
    })
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:35:41.469715
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

# Generated at 2022-06-17 20:35:47.193077
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:35:54.886500
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:35:56.208247
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:36:04.187319
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=True)
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'
    assert formatter.format

# Generated at 2022-06-17 20:36:12.507798
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body

# Generated at 2022-06-17 20:36:26.031052
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs['explicit_json'] = True
    json_formatter.format_options['json']['format'] = True
    json_formatter.format_options['json']['sort_keys'] = True
    json_formatter.format_options['json']['indent'] = 4

    # Test 1: Valid JSON
    body = '{"key1": "value1", "key2": "value2"}'
    mime = 'json'
    expected_body = '{\n    "key1": "value1",\n    "key2": "value2"\n}'
    assert json_formatter.format_body(body, mime) == expected_body

    # Test 2: Invalid JSON

# Generated at 2022-06-17 20:36:37.575711
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": "b"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'
    body = '{"a": "b"}'
    mime = 'html'

# Generated at 2022-06-17 20:36:45.716363
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:36:59.151096
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyOptions
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamOptions
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolkitOptions
    from httpie.plugins.json import JSONToolkitPlugin
    from httpie.plugins.json import JSONToolkitPrettyOptions
    from httpie.plugins.json import JSONToolkitPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamOptions
    from httpie.plugins.json import JSONToolkitStreamPlugin
    from httpie.plugins.json import JSONTool

# Generated at 2022-06-17 20:37:08.965444
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'html') == '{"a": 1, "b": 2}'

# Generated at 2022-06-17 20:37:17.818961
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUP

# Generated at 2022-06-17 20:37:26.175010
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/html') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:37:32.231379
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:37:42.935474
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n  "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text/html') == '{"a": "b"}'

# Generated at 2022-06-17 20:37:48.846280
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:37:57.507882
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a":1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a":1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a":1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a":1}', 'html') == '{"a":1}'

# Generated at 2022-06-17 20:38:07.458281
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:38:18.018584
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:38:26.131414
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:38:34.835762
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'html') == '{"foo": "bar"}'
    assert formatter.format_body('{"foo": "bar"}', 'xml') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:38:39.030908
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:38:49.543975
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:38:55.291336
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    # Test 2
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:39:04.492962
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    #   - body: {"a": 1, "b": 2}
    #   - mime: application/json
    #   - expected: {"a": 1, "b": 2}
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    expected = '{\n    "a": 1,\n    "b": 2\n}'
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}}).format_body(body, mime) == expected

    # Test case 2:
    #   - body: {"a": 1, "b": 2}
    #   - mime: text/html
    #   - expected: {"a": 1, "b": 2}


# Generated at 2022-06-17 20:39:14.161627
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a":1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'html') == '{"a":1}'
    assert json_formatter.format_body('{"a":1}', 'xml') == '{"a":1}'

# Generated at 2022-06-17 20:39:27.920021
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    body = '{"key": "value"}'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test with invalid JSON
    body = '{"key": "value"'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.format_body(body, mime) == '{"key": "value"'

    # Test with valid JSON and

# Generated at 2022-06-17 20:39:38.608319
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    # Input:
    #   body = '{"foo": "bar"}'
    #   mime = 'json'
    #   kwargs = {'explicit_json': True}
    #   format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    # Expected output:
    #   body = '{\n    "foo": "bar"\n}'
    body = '{"foo": "bar"}'
    mime = 'json'
    kwargs = {'explicit_json': True}
    format_options = {'json': {'format': True, 'sort_keys': True, 'indent': 4}}
    json_formatter = JSONFormatter(kwargs=kwargs, format_options=format_options)


# Generated at 2022-06-17 20:39:48.027930
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n  "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n  "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n  "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:39:59.176552
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for valid JSON
    body = '{"a": "b"}'
    mime = 'application/json'
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}}).format_body(body, mime) == '{\n  "a": "b"\n}'
    # Test for invalid JSON
    body = '{"a": "b"'
    mime = 'application/json'
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}}).format_body(body, mime) == '{"a": "b"'
    # Test for valid JSON but not application/json
    body = '{"a": "b"}'
    mime = 'text/plain'

# Generated at 2022-06-17 20:40:09.517040
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert json_formatter.format_body(
        body='{"a": "b"}',
        mime='application/json'
    ) == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        body='{"a": "b"}',
        mime='application/javascript'
    ) == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        body='{"a": "b"}',
        mime='text/plain'
    ) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:40:20.081290
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    #   - body: '{"a": 1, "b": 2}'
    #   - mime: 'application/json'
    #   - kwargs: {'explicit_json': False}
    #   - format_options: {'json': {'format': True, 'indent': 2, 'sort_keys': True}}
    #   - expected: '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    kwargs = {'explicit_json': False}
    format_options = {'json': {'format': True, 'indent': 2, 'sort_keys': True}}

# Generated at 2022-06-17 20:40:29.897906
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body(
        '{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        '{"a": "b"}', 'application/javascript') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        '{"a": "b"}', 'text/javascript') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body(
        '{"a": "b"}', 'text/plain') == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:40:34.412464
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:40:40.393685
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'

# Generated at 2022-06-17 20:40:47.937944
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'application/javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/plain') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/css') == '{"a": 1}'
   

# Generated at 2022-06-17 20:41:05.820367
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    mime = 'text/html'
    assert formatter.format_body(body, mime) == '{"a": 1, "b": 2}'
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
   

# Generated at 2022-06-17 20:41:13.527538
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"foo": "bar"}', 'application/json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/plain') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/html') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'application/xml') == '{"foo": "bar"}'
    assert formatter.format_body('{"foo": "bar"}', 'application/javascript')

# Generated at 2022-06-17 20:41:22.822860
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    assert JSONFormatter().format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert JSONFormatter().format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert JSONFormatter().format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert JSONFormatter().format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert JSONFormatter().format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:41:30.267498
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:41:39.743368
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text/html') == '{"a": 1, "b": 2}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'application/javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:41:48.913510
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body(
        '{"foo": "bar"}',
        'application/json'
    ) == '{\n    "foo": "bar"\n}'
    assert formatter.format_body(
        '{"foo": "bar"}',
        'application/javascript'
    ) == '{\n    "foo": "bar"\n}'
    assert formatter.format_body(
        '{"foo": "bar"}',
        'text/plain'
    ) == '{\n    "foo": "bar"\n}'
    assert formatter.format_body(
        '{"foo": "bar"}',
        'text/html'
    ) == '{"foo": "bar"}'

# Generated at 2022-06-17 20:41:58.093908
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:42:04.621479
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:42:09.286493
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.format_options = {
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    }
    json_formatter.kwargs = {
        'explicit_json': False,
    }
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:42:19.247754
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.manager import plugin_manager_class
    from httpie.plugins.manager import plugin_manager_instance
    from httpie.plugins.manager import plugin_manager_kwargs
    from httpie.plugins.manager import plugin_manager_kwargs_class
    from httpie.plugins.manager import plugin_manager_kwargs_instance
    from httpie.plugins.manager import plugin_manager_kwargs_type
    from httpie.plugins.manager import plugin_manager_type
    from httpie.plugins.manager import plugin_manager_type_class

# Generated at 2022-06-17 20:42:49.719279
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'

# Generated at 2022-06-17 20:43:00.504466
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for valid JSON
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}}).format_body(
        '{"a": "b"}', 'application/json') == '{\n  "a": "b"\n}'

    # Test for invalid JSON
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}}).format_body(
        '{"a": "b"', 'application/json') == '{"a": "b"'

    # Test for valid JSON with explicit_json

# Generated at 2022-06-17 20:43:11.651799
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:43:21.084237
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(
        format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}},
        explicit_json=False
    )
    assert json_formatter.format_body(
        '{"a": "b", "c": "d"}',
        'application/json'
    ) == '{\n    "a": "b",\n    "c": "d"\n}'
    assert json_formatter.format_body(
        '{"a": "b", "c": "d"}',
        'text/html'
    ) == '{"a": "b", "c": "d"}'

# Generated at 2022-06-17 20:43:30.964155
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.compat import is_py26

    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSONFormatter.format_body
    # Test for JSON

# Generated at 2022-06-17 20:43:40.590408
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    body = '{"a": 1, "b": 2}'
    mime = 'text/plain'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    body = '{"a": 1, "b": 2}'
    mime = 'text/html'

# Generated at 2022-06-17 20:43:47.085417
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.manager import PluginManager

# Generated at 2022-06-17 20:44:00.372645
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:44:10.900433
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1:
    #   input:
    #       body = '{"a": 1, "b": 2}'
    #       mime = 'application/json'
    #       kwargs = {'explicit_json': False}
    #       format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    #   expected:
    #       body = '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    kwargs = {'explicit_json': False}
    format_options = {'json': {'format': True, 'indent': 4, 'sort_keys': True}}
    formatter = JSONForm

# Generated at 2022-06-17 20:44:20.581050
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'html') == '{"a": 1, "b": 2}'

# Generated at 2022-06-17 20:45:10.943819
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs['explicit_json'] = True
    json_formatter.format_options['json']['format'] = True
    json_formatter.format_options['json']['sort_keys'] = True
    json_formatter.format_options['json']['indent'] = 4
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:45:20.630868
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1:
    #   - body: '{"a": 1}'
    #   - mime: 'json'
    #   - format_options['json']['format']: True
    #   - format_options['json']['sort_keys']: True
    #   - format_options['json']['indent']: 2
    #   - kwargs['explicit_json']: False
    #   - expected: '{\n  "a": 1\n}'
    body = '{"a": 1}'
    mime = 'json'
    format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 2
        }
    }
    kwargs = {
        'explicit_json': False
    }