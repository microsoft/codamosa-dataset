

# Generated at 2022-06-17 20:35:22.662025
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import HTTPBody
    from httpie.plugins.builtin import HTTPTraceback
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import HTTPStats
    from httpie.plugins.builtin import HTTPPretty
    from httpie.plugins.builtin import HTTPInfo
    from httpie.plugins.builtin import HTTPBinary
    from httpie.plugins.builtin import HTTPCookie
    from httpie.plugins.builtin import HTTPFile
    from httpie.plugins.builtin import HTTPVerbose
    from httpie.plugins.builtin import HT

# Generated at 2022-06-17 20:35:32.898978
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body

# Generated at 2022-06-17 20:35:41.660676
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body(
        body='{"a": "b"}',
        mime='application/json'
    ) == '{\n    "a": "b"\n}'

    assert json_formatter.format_body(
        body='{"a": "b"}',
        mime='application/javascript'
    ) == '{\n    "a": "b"\n}'

    assert json_formatter.format_body(
        body='{"a": "b"}',
        mime='text/plain'
    ) == '{\n    "a": "b"\n}'


# Generated at 2022-06-17 20:35:50.710180
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:36:01.608616
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a":1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a":1}', 'html') == '{"a":1}'
    assert json_formatter.format_body('{"a":1}', 'xml') == '{"a":1}'
    assert json_formatter.format_body('{"a":1}', 'csv') == '{"a":1}'

# Generated at 2022-06-17 20:36:07.654453
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    })
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

    # Test 2
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    })
    body = '{"b": 2, "a": 1}'

# Generated at 2022-06-17 20:36:17.883404
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test case 1
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 2
            }
        },
        explicit_json=False
    )
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    expected = '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body(body, mime) == expected

    # Test case 2
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'sort_keys': False,
                'indent': 2
            }
        },
        explicit_json=False
    )
    body

# Generated at 2022-06-17 20:36:23.484195
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['format'] == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:36:34.799946
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for valid JSON
    body = '{"foo": "bar"}'
    mime = 'application/json'
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': False, 'indent': 4}})
    assert formatter.format_body(body, mime) == '{\n    "foo": "bar"\n}'

    # Test for invalid JSON
    body = '{"foo": "bar"'
    mime = 'application/json'
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': False, 'indent': 4}})
    assert formatter.format_body(body, mime) == '{"foo": "bar"'

    # Test for valid JSON with indentation

# Generated at 2022-06-17 20:36:40.584217
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'html') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:36:51.457336
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:36:53.605180
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"foo": "bar"}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:36:57.598687
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:37:08.551825
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'application/javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text/javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:37:17.799889
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test 2
    formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test 3
    formatter = JSONFormatter()
    body = '{"key": "value"}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test 4
    form

# Generated at 2022-06-17 20:37:23.635506
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONOptionsPlugin
    from httpie.plugins.builtin import HTTPOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import OAuth1Plugin
    from httpie.plugins.builtin import OAuth2Plugin
    from httpie.plugins.builtin import DigestAuth
    from httpie.plugins.builtin import WSAuthPlugin
    from httpie.plugins.builtin import WSAuthPlugin
    from httpie.plugins.builtin import WSAuthPlugin
    from httpie.plugins.builtin import WSAuthPlugin

# Generated at 2022-06-17 20:37:33.105758
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": "b"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

    # Test 2
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": "b"}'
    mime = 'javascript'
    assert formatter.format_body(body, mime) == '{\n    "a": "b"\n}'

    # Test 3

# Generated at 2022-06-17 20:37:36.720430
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True


# Generated at 2022-06-17 20:37:45.720865
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 2}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'

# Generated at 2022-06-17 20:37:58.800198
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.output.streams import StdoutStream
    from httpie.output.streams import StderrStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import RawJSONFormatter
    from httpie.output.formatters import ColoredJSONFormatter
    from httpie.output.formatters import HeadersFormatter
    from httpie.output.formatters import StreamHeadersFormatter
    from httpie.output.formatters import StreamJSONFormatter
    from httpie.output.formatters import StreamRawJSONFormatter
    from httpie.output.formatters import StreamColoredJSONFormatter
    from httpie.output.formatters import StreamFormatter

# Generated at 2022-06-17 20:38:10.574642
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:38:21.469775
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyOptions
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamFormatter
    from httpie.plugins.json import JSONStreamOptions
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolkit
    from httpie.plugins.json import JSONToolkitOptions
    from httpie.plugins.json import JSONToolkitPlugin
    from httpie.plugins.json import JSONToolkitPrettyOptions
    from httpie.plugins.json import JSONToolkitPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamOptions

# Generated at 2022-06-17 20:38:32.342089
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for invalid json
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"key": "value"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == body

    # Test for valid json
    body = '{"key": "value"}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test for valid json with explicit_json
    formatter = JSONFormatter(format_options={'json': {'format': False, 'indent': 4, 'sort_keys': True}}, explicit_json=True)

# Generated at 2022-06-17 20:38:41.323823
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'csv') == '{"a": 1}'

# Generated at 2022-06-17 20:38:51.087415
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:38:57.672165
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:39:02.407695
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:39:06.743043
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:39:16.337929
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    # Test with invalid JSON
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == body

    # Test with valid

# Generated at 2022-06-17 20:39:24.144823
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:39:44.667799
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:39:50.334729
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:39:55.481960
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:40:06.213258
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    assert formatter.format_body(body, 'application/json') == body
    assert formatter.format_body(body, 'application/javascript') == body
    assert formatter.format_body(body, 'text/javascript') == body
    assert formatter.format_body(body, 'text/plain') == body
    assert formatter.format_body(body, 'text/html') == body
    assert formatter.format_body(body, 'text/xml') == body
    assert formatter.format_body(body, 'application/xml') == body
    assert formatter.format_body(body, 'application/xhtml+xml') == body

# Generated at 2022-06-17 20:40:13.530768
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    body = '{"foo": "bar"}'
    mime = 'application/json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body(body, mime) == '{\n  "foo": "bar"\n}'

    # Test with invalid JSON
    body = '{"foo": "bar"'
    mime = 'application/json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body(body, mime) == '{"foo": "bar"'

    # Test

# Generated at 2022-06-17 20:40:24.311239
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    body = '{"key": "value"}'
    mime = 'application/json'
    formatter = JSONFormatter()
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test with invalid JSON
    body = '{"key": "value"'
    mime = 'application/json'
    formatter = JSONFormatter()
    assert formatter.format_body(body, mime) == body

    # Test with valid JSON and explicit_json=True
    body = '{"key": "value"}'
    mime = 'application/json'
    formatter = JSONFormatter(explicit_json=True)

# Generated at 2022-06-17 20:40:31.150164
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'

# Generated at 2022-06-17 20:40:34.411546
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True,
            }
        }
    )
    assert formatter.enabled is True


# Generated at 2022-06-17 20:40:35.859859
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter()
    assert json_formatter.enabled == True


# Generated at 2022-06-17 20:40:45.298253
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:41:10.503421
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:41:14.410970
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:41:24.293750
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert json_formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:41:25.361983
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-17 20:41:30.109463
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'csv') == '{"a": 1}'

# Generated at 2022-06-17 20:41:36.082718
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:41:42.183405
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    mime = 'text'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    mime = 'javascript'
    assert json_formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'
    mime = 'html'

# Generated at 2022-06-17 20:41:45.520065
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:41:51.473242
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import JSONPPOptions
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import StreamOptions
    from httpie.plugins.builtin import SyntaxOptions
    from httpie.plugins.builtin import SyntaxFormatter
    from httpie.plugins.builtin import UnicodeOptions
    from httpie.plugins.builtin import UnicodeFormatter
    from httpie.plugins.builtin import format_options

# Generated at 2022-06-17 20:41:57.954775
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:42:49.206444
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(**{'explicit_json': False, 'format_options': {'json': {'format': True, 'indent': 4, 'sort_keys': True}}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format

# Generated at 2022-06-17 20:42:50.086106
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-17 20:42:55.958451
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:43:06.022013
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert json_formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'

# Generated at 2022-06-17 20:43:16.605852
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:43:21.391273
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 2
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:43:28.073126
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['indent'] == 4
    assert json_formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:43:39.257488
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    json_formatter.kwargs = {'explicit_json': False}
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    m

# Generated at 2022-06-17 20:43:43.645400
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['sort_keys'] == True
    assert json_formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-17 20:43:51.391730
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'css') == '{"a": 1}'