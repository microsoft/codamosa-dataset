

# Generated at 2022-06-17 20:35:20.089124
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False
    assert formatter.kwargs == {}
    assert formatter.format_options == {}


# Generated at 2022-06-17 20:35:30.026409
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:35:38.744136
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'css') == '{"a": "b"}'

# Generated at 2022-06-17 20:35:43.190793
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:35:50.709921
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:36:01.573537
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'html') == '{"foo": "bar"}'
    assert formatter.format_body('{"foo": "bar"}', 'xml') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:36:07.634747
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text/html') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:36:09.542670
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True,
        }
    })
    assert formatter.format_body(
        body='{"a": 1, "b": 2}',
        mime='json'
    ) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:36:10.333625
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter()
    assert formatter.enabled == False

# Generated at 2022-06-17 20:36:17.478537
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:36:34.852004
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'pdf') == '{"a": 1}'

# Generated at 2022-06-17 20:36:41.944122
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:36:47.168780
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:36:56.060705
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['sort_keys'] == True
    assert formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-17 20:37:04.295815
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'

# Generated at 2022-06-17 20:37:12.989750
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 2,
                'sort_keys': True
            }
        }
    )
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"b": 2, "a": 1}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'

# Generated at 2022-06-17 20:37:17.641845
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.kwargs == {}
    assert formatter.format_options == {'json': {'format': True, 'indent': 2, 'sort_keys': True}}


# Generated at 2022-06-17 20:37:20.428509
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True


# Generated at 2022-06-17 20:37:25.424492
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    body = '{"a": 1, "b": 2}'
    assert formatter.format_body(body, 'json') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:37:27.308586
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    assert JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})


# Generated at 2022-06-17 20:37:45.190633
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:37:50.684457
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:38:00.268529
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert json_formatter.format_body('{"a": "b"}', 'json') == '{\n  "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'text') == '{\n  "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'javascript') == '{\n  "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'

# Generated at 2022-06-17 20:38:05.618833
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['format'] == True
    assert formatter.format_options['json']['indent'] == 2
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:38:11.223943
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'

# Generated at 2022-06-17 20:38:21.193027
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert json_formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'
    assert json_formatter.format_body('{"a": "b"}', 'xml') == '{"a": "b"}'

# Generated at 2022-06-17 20:38:32.302156
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:38:41.081021
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    body = '{"a": 1, "b": 2}'
    assert formatter.format_body(body, 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(body, 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(body, 'text') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body(body, 'html') == '{"a": 1, "b": 2}'
    assert formatter.format_body(body, 'xml') == '{"a": 1, "b": 2}'

# Generated at 2022-06-17 20:38:49.094429
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body("{'a': 1}", "json") == '{\n    "a": 1\n}'
    assert json_formatter.format_body("{'a': 1}", "text") == '{\n    "a": 1\n}'
    assert json_formatter.format_body("{'a': 1}", "javascript") == '{\n    "a": 1\n}'
    assert json_formatter.format_body("{'a': 1}", "html") == "{'a': 1}"

# Generated at 2022-06-17 20:38:55.798311
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'

# Generated at 2022-06-17 20:39:17.232557
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'html') == '{"foo": "bar"}'
    assert formatter.format_body('{"foo": "bar"}', 'xml') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:39:24.657785
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={
        'json': {
            'format': True,
            'indent': 2,
            'sort_keys': True
        }
    })
    assert json_formatter.format_body(
        '{"a": 1, "b": 2}',
        'application/json'
    ) == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body(
        '{"a": 1, "b": 2}',
        'text/plain'
    ) == '{\n  "a": 1,\n  "b": 2\n}'
    assert json_formatter.format_body(
        '{"a": 1, "b": 2}',
        'text/html'
    )

# Generated at 2022-06-17 20:39:26.891183
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert json_formatter.enabled == True
    assert json_formatter.format_options['json']['sort_keys'] == True
    assert json_formatter.format_options['json']['indent'] == 4


# Generated at 2022-06-17 20:39:33.048846
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'

# Generated at 2022-06-17 20:39:38.605797
# Unit test for constructor of class JSONFormatter
def test_JSONFormatter():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.enabled == True
    assert formatter.format_options['json']['indent'] == 4
    assert formatter.format_options['json']['sort_keys'] == True


# Generated at 2022-06-17 20:39:48.029451
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:39:59.176741
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'

# Generated at 2022-06-17 20:40:09.517147
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for invalid JSON
    body = '{"key": "value"}'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test for valid JSON
    body = '{"key": "value"}'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=True, format_options={
        'json': {
            'format': True,
            'indent': 4,
            'sort_keys': True
        }
    })

# Generated at 2022-06-17 20:40:20.081025
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"}', 'application/json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'application/javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/javascript') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/plain') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'text/html') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:40:29.897688
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysOptions

# Generated at 2022-06-17 20:41:14.288846
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:41:24.209022
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert json_formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'
    assert json_formatter.format_body('{"foo": "bar"}', 'text') == '{\n    "foo": "bar"\n}'
    assert json_formatter.format_body('{"foo": "bar"}', 'html') == '{"foo": "bar"}'
    assert json_formatter.format_body('{"foo": "bar"}', 'xml') == '{"foo": "bar"}'

# Generated at 2022-06-17 20:41:35.521129
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text/plain') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'text/html; charset=utf-8') == '{"a": 1}'


# Generated at 2022-06-17 20:41:41.955237
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with invalid JSON
    formatter = JSONFormatter()
    assert formatter.format_body('{"foo": "bar"', 'json') == '{"foo": "bar"'
    assert formatter.format_body('{"foo": "bar"', 'javascript') == '{"foo": "bar"'
    assert formatter.format_body('{"foo": "bar"', 'text') == '{"foo": "bar"'

    # Test with valid JSON
    assert formatter.format_body('{"foo": "bar"}', 'json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'javascript') == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:41:50.061764
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test 1
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}},
                              explicit_json=False)
    body = '{"a": 1, "b": 2}'
    mime = 'json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

    # Test 2
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': False}},
                              explicit_json=False)
    body = '{"a": 1, "b": 2}'
    mime = 'javascript'

# Generated at 2022-06-17 20:41:55.444451
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(
        format_options={
            'json': {
                'format': True,
                'indent': 4,
                'sort_keys': True,
            }
        },
        explicit_json=False,
    )
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:42:04.356296
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a":1,"b":2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a":1,"b":2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a":1,"b":2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:42:09.324844
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.json import JSONFormatter
    from httpie.plugins.json import JSONOptions
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json import JSONPrettyOptions
    from httpie.plugins.json import JSONPrettyPlugin
    from httpie.plugins.json import JSONStreamOptions
    from httpie.plugins.json import JSONStreamPlugin
    from httpie.plugins.json import JSONToolkitOptions
    from httpie.plugins.json import JSONToolkitPlugin
    from httpie.plugins.json import JSONToolkitPrettyOptions
    from httpie.plugins.json import JSONToolkitPrettyPlugin
    from httpie.plugins.json import JSONToolkitStreamOptions
    from httpie.plugins.json import JSONToolkitStreamPlugin
    from httpie.plugins.json import JSONTool

# Generated at 2022-06-17 20:42:19.277608
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import JSONPPSortKeysOptions
    from httpie.plugins.builtin import JSONPPSortKeysFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentOptions
    from httpie.plugins.builtin import JSONPPSortKeysIndentFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentExplicitOptions
    from httpie.plugins.builtin import JSONPPSortKeysIndentExplicitFormatter
    from httpie.plugins.builtin import JSONPPSortKeysIndentExplicitFormatOptions

# Generated at 2022-06-17 20:42:29.267398
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter(format_options={'json': {'format': True, 'sort_keys': True, 'indent': 4}})
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'application/javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert json_formatter.format_body('{"a": 1, "b": 2}', 'text/plain') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:43:30.387936
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n    "a": 1,\n    "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:43:40.314449
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-17 20:43:49.337285
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test for method format_body of class JSONFormatter
    # Input:
    #   body: '{"a":1,"b":2}'
    #   mime: 'json'
    #   self.kwargs['explicit_json']: False
    #   self.format_options['json']['sort_keys']: True
    #   self.format_options['json']['indent']: 4
    # Expected output:
    #   '{\n    "a": 1,\n    "b": 2\n}'
    body = '{"a":1,"b":2}'
    mime = 'json'
    kwargs = {'explicit_json': False}
    format_options = {'json': {'sort_keys': True, 'indent': 4}}
    formatter = JSON

# Generated at 2022-06-17 20:44:01.096544
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text/plain'
    assert formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'
    body = '{"a": 1, "b": 2}'
    mime = 'text/html'

# Generated at 2022-06-17 20:44:11.371319
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'
    assert formatter.format_body('{"a": 1}', 'unknown') == '{"a": 1}'

# Generated at 2022-06-17 20:44:18.313692
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    json_formatter.kwargs = {'explicit_json': False}
    json_formatter.format_options = {
        'json': {
            'format': True,
            'sort_keys': True,
            'indent': 2
        }
    }

    # Test with valid JSON
    body = '{"a": 1, "b": 2}'
    mime = 'application/json'
    assert json_formatter.format_body(body, mime) == '{\n  "a": 1,\n  "b": 2\n}'

    # Test with invalid JSON
    body = '{"a": 1, "b": 2'
    mime = 'application/json'

# Generated at 2022-06-17 20:44:28.594230
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    # Test with valid JSON
    body = '{"key": "value"}'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body(body, mime) == '{\n    "key": "value"\n}'

    # Test with invalid JSON
    body = '{"key": "value"'
    mime = 'json'
    formatter = JSONFormatter(explicit_json=False, format_options={'json': {'format': True, 'indent': 4, 'sort_keys': True}})
    assert formatter.format_body(body, mime) == '{"key": "value"'

    # Test with valid JSON and

# Generated at 2022-06-17 20:44:34.128159
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter()
    assert formatter.format_body('{"a": "b"}', 'json') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'text') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'javascript') == '{\n    "a": "b"\n}'
    assert formatter.format_body('{"a": "b"}', 'html') == '{"a": "b"}'

# Generated at 2022-06-17 20:44:45.086636
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    json_formatter = JSONFormatter()
    assert json_formatter.format_body('{"a": 1}', 'json') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'javascript') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'text') == '{\n    "a": 1\n}'
    assert json_formatter.format_body('{"a": 1}', 'html') == '{"a": 1}'
    assert json_formatter.format_body('{"a": 1}', 'xml') == '{"a": 1}'

# Generated at 2022-06-17 20:44:51.475077
# Unit test for method format_body of class JSONFormatter
def test_JSONFormatter_format_body():
    formatter = JSONFormatter(format_options={'json': {'format': True, 'indent': 2, 'sort_keys': True}})
    assert formatter.format_body('{"a": 1, "b": 2}', 'json') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'javascript') == '{\n  "a": 1,\n  "b": 2\n}'
    assert formatter.format_body('{"a": 1, "b": 2}', 'text') == '{\n  "a": 1,\n  "b": 2\n}'