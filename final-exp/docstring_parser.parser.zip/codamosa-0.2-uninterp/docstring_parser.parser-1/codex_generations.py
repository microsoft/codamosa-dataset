

# Generated at 2022-06-17 18:16:36.361465
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        returns=None,
        raises=None,
        meta={},
        style=Style.numpy,
    )

# Generated at 2022-06-17 18:16:41.809693
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises['keyError'] == "raises an exception"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:16:53.360514
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: this is a test parameter
    :type a: int
    :returns: this is a test return
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'this is a test parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.returns.description == 'this is a test return'
    assert docstring.returns.type == 'str'
    assert docstring.meta == {'param', 'type', 'returns', 'rtype'}
    assert docstring.style == Style.numpy

# Generated at 2022-06-17 18:16:59.133370
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.returns.description == 'something'
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['b'].description == 'another parameter'


# Generated at 2022-06-17 18:17:04.278252
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params['arg1'].description == "the first argument"
    assert doc.params['arg2'].description == "the second argument"
    assert doc.returns.description == "the return value"
    assert doc.raises == {}
    assert doc.meta == {}
    assert doc.style == Style.numpy


# Generated at 2022-06-17 18:17:12.092373
# Unit test for function parse
def test_parse():
    """Test function parse"""
    from docstring_parser.styles import GoogleStyle
    text = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring, GoogleStyle)
    assert docstring.short_description == "This is a test function."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert doc

# Generated at 2022-06-17 18:17:21.588308
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    assert parse(text).short_description == "This is a test docstring."
    assert parse(text).long_description == ""
    assert parse(text).meta == {}
    assert parse(text).returns == None
    assert parse(text).raises == None
    assert parse(text).yields == None
    assert parse(text).warns == None
    assert parse(text).warnings == None
    assert parse(text).other == []
    assert parse(text).examples == []
    assert parse(text).see_also == []
    assert parse(text).attributes == []
    assert parse(text).methods == []
    assert parse(text).notes == []
    assert parse(text).references == []

# Generated at 2022-06-17 18:17:32.119126
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    assert parse(docstring).summary == 'This is a docstring.'
    assert parse(docstring).params['a'].desc == 'a parameter'
    assert parse(docstring).params['b'].desc == 'another parameter'
    assert parse(docstring).returns.desc == 'something'
    assert parse(docstring).examples == []
    assert parse(docstring).raises == []
    assert parse(docstring).see_also == []
    assert parse(docstring).meta == {}
    assert parse(docstring).notes == []
    assert parse(docstring).references == []
    assert parse(docstring).attributes == []

# Generated at 2022-06-17 18:17:43.118016
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type to be raised.
    """
    d = parse(text)
    assert d.short_description == "This is a test docstring."
    assert d.long_description == ""
    assert d.params[0].arg_name == "arg1"
    assert d.params[0].description == "The first argument."
    assert d.params[1].arg_name == "arg2"
    assert d.params[1].description == "The second argument."
    assert d.returns.description == "The return value."
    assert d.raises[0].type_name == "keyError"
   

# Generated at 2022-06-17 18:17:54.703812
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    """
    assert parse(docstring) == Docstring(summary='This is a test docstring.')

    docstring = """
    This is a test docstring.
    :param name: name of the person
    :type name: str
    :param age: age of the person
    :type age: int
    :returns: person object
    :rtype: object
    """
    assert parse(docstring) == Docstring(summary='This is a test docstring.',
                                         params=[('name', 'name of the person', 'str'),
                                                 ('age', 'age of the person', 'int')],
                                         returns=('person object', 'object'))


# Generated at 2022-06-17 18:18:07.319360
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.returns == None
    assert docstring.raises == []
    assert docstring.yields == None
    assert docstring.warns == []
    assert docstring.other == []
    assert docstring.params == []
    assert docstring.attributes == []
    assert docstring.decorators == []
    assert docstring.examples == []
    assert docstring.see_also == []
    assert docstring.notes == []
    assert docstring.references == []
    assert docstring.todo == []

# Generated at 2022-06-17 18:18:18.704390
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].description == 'another parameter'
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == 'something'
    assert len(docstring.raises) == 0
    assert len

# Generated at 2022-06-17 18:18:25.566182
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x value
    :param y: y value
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["x"] == "x value"
    assert docstring.params["y"] == "y value"
    assert docstring.returns == "x + y"
    assert docstring.meta == {}


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:18:34.791798
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'
    assert docstring.params[1].description == 'The second argument.'
    assert docstring.returns.description == 'Description of return value.'

# Generated at 2022-06-17 18:18:44.347586
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: Description of return value.
    :rtype: bool
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.return_type == 'bool'
    assert docstring.return_annotation == 'Description of return value.'
    assert docstring.meta['arg1']['type'] == 'int'
    assert docstring.meta['arg1']['annotation'] == 'The first argument.'

# Generated at 2022-06-17 18:18:52.879928
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param str name: The name of the person.
    :param int age: The age of the person.
    :returns: The person's name and age.
    :raises ValueError: If the age is negative.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['name']['type'] == 'str'
    assert docstring.meta['param']['name']['description'] == 'The name of the person.'
    assert docstring.meta['param']['age']['type'] == 'int'

# Generated at 2022-06-17 18:19:04.092482
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param int a: This is a parameter
    :param str b: This is a parameter
    :returns: This is a return
    :raises ValueError: This is a exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "This is a parameter"
    assert docstring.params['b'].description == "This is a parameter"
    assert docstring.returns.description == "This is a return"
    assert docstring.raises['ValueError'].description == "This is a exception"

# Generated at 2022-06-17 18:19:14.240318
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :rtype: Person
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.returns.type_name == "Person"
    assert docstring.returns.description == "a person"
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "name of the person"
    assert docstring.params[1].arg_name

# Generated at 2022-06-17 18:19:20.879311
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    '''
    assert parse(docstring).short_description == 'This is a docstring.'
    assert parse(docstring).long_description == ''
    assert parse(docstring).returns.description == 'None'
    assert parse(docstring).params['arg1'].description == 'The first argument.'
    assert parse(docstring).params['arg2'].description == 'The second argument.'


# Generated at 2022-06-17 18:19:28.381271
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    :raises Exception: if something goes wrong
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == "something"
    assert len

# Generated at 2022-06-17 18:19:37.554440
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print 'hello' or 'goodbye'.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].description == "The name to use."
    assert docstring.params[0].type_name == "str."
    assert docstring.params[1].arg_name == "state"

# Generated at 2022-06-17 18:19:47.752731
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("name", "name of the person"),
        ("age", "age of the person"),
    ]
    assert docstring.returns == "a person"
    assert docstring.raises == [("ValueError", "if age is negative")]

# Generated at 2022-06-17 18:19:57.888433
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:20:05.176338
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.meta == {}
    assert docstring.style == Style.numpy
    assert docstring.lines == ['This is a docstring.']
    assert docstring.errors == []


# Generated at 2022-06-17 18:20:13.605707
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: None
    :raises ValueError: If `foo` is empty.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['foo'].arg_type == 'str'
    assert docstring.params['foo'].description == 'This is a parameter.'
    assert docstring.params['bar'].arg_type == 'int'
    assert docstring.params['bar'].description == 'This is another parameter.'


# Generated at 2022-06-17 18:20:23.277926
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {'name': 'arg1', 'type': None, 'description': 'The first argument.'},
        {'name': 'arg2', 'type': None, 'description': 'The second argument.'},
    ]
    assert docstring.returns == {'type': None, 'description': 'Description of return value.'}

# Generated at 2022-06-17 18:20:30.637803
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    d = parse(text)
    assert d.short_description == 'This is a test function.'
    assert d.long_description == ''
    assert d.meta['a'] == 'a parameter'
    assert d.meta['b'] == 'another parameter'
    assert d.meta['returns'] == 'a return value'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:20:38.143415
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a formatted string
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {"name": "name", "type": "str", "description": "name of the person"},
        {"name": "age", "type": "int", "description": "age of the person"},
    ]
    assert docstring.returns == {"type": "", "description": "a formatted string"}
    assert docstring.meta == {}
    assert docstring.examples == []
    assert docstring.see_also == []

# Generated at 2022-06-17 18:20:46.147946
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print name or not.
    :type state: bool.
    :returns: str -- the formatted name
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'The name to use.'
    assert docstring.params['name'].type_name == 'str.'
    assert docstring.params['state'].description == 'Whether to print name or not.'
    assert docstring.params['state'].type_name == 'bool.'
    assert docstring.returns.description == 'the formatted name'
   

# Generated at 2022-06-17 18:20:54.581983
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param int a: parameter a
    :param str b: parameter b
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "parameter a"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"
    assert docstring.params[1].description == "parameter b"
    assert docstring.returns.type_name == ""

# Generated at 2022-06-17 18:21:07.898144
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: first argument
    :param arg2: second argument
    :returns: something
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'arg1': 'first argument', 'arg2': 'second argument'}
    assert docstring.returns == 'something'
    assert docstring.raises == {'keyError': 'raises an exception'}

# Generated at 2022-06-17 18:21:18.217581
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[0].type_name == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type_name == 'int'

# Generated at 2022-06-17 18:21:29.016801
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test_param: test parameter
    :type test_param: str
    :returns: test return
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "test_param"
    assert docstring.params[0].description == "test parameter"
    assert docstring.params[0].type_name == "str"
    assert docstring.returns.description == "test return"
    assert docstring.returns.type_name == "int"

# Generated at 2022-06-17 18:21:40.543806
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: The foo parameter.
    :type foo: int
    :param bar: The bar parameter.
    :type bar: str
    :returns: The return value.
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params["foo"].arg_type == "int"
    assert docstring.params["bar"].arg_type == "str"
    assert docstring.returns.arg_type == "bool"
    assert docstring.returns.description == "The return value."
    assert len(docstring.meta) == 4

# Unit

# Generated at 2022-06-17 18:21:45.254503
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring"


# Generated at 2022-06-17 18:21:55.347125
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :rtype: Person
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["name"].description == "name of the person"
    assert docstring.params["age"].description == "age of the person"
    assert docstring.returns.description == "a person"
    assert docstring.returns.type_name == "Person"


# Generated at 2022-06-17 18:22:05.257427
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: parameter a
    :param int b: parameter b
    :returns: a + b
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'parameter a'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'parameter b'
    assert docstring.params['b'].type_name == 'int'
    assert docstring.returns.description == 'a + b'
    assert docstring.returns.type_name == ''

# Generated at 2022-06-17 18:22:11.596418
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.
    :param a: a
    :param b: b
    :returns: c
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a'
    assert docstring.params['b'].description == 'b'
    assert docstring.returns.description == 'c'


# Generated at 2022-06-17 18:22:22.326429
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: return value
    :rtype: float
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'return value'

# Generated at 2022-06-17 18:22:30.443802
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {"x": "x"}
    assert docstring.returns == "x"
    assert docstring.meta == {"param x": "int", "returns": "int"}


# Generated at 2022-06-17 18:22:44.939759
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {'a': {'type': 'int', 'description': 'a parameter'}}
    assert docstring.returns == {'type': 'str', 'description': 'a return value'}
    assert docstring.meta == {'param a': {'type': 'int', 'description': 'a parameter'},
                              'returns': {'type': 'str', 'description': 'a return value'}}


# Generated at 2022-06-17 18:22:57.171695
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
    assert len(docstring.meta) == 3

# Generated at 2022-06-17 18:23:05.368644
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    doc = parse(text)
    assert doc.short_description == 'This is a function.'
    assert doc.long_description == ''
    assert doc.params == [{'name': 'x', 'type': 'int', 'description': 'x'}]
    assert doc.returns == {'type': 'int', 'description': 'x'}
    assert doc.meta == {'param x': 'int', 'returns': 'int'}


# Generated at 2022-06-17 18:23:15.744250
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}

# Generated at 2022-06-17 18:23:22.690125
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param foo: this is a foo
    :param bar: this is a bar
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.meta["param"]["foo"] == "this is a foo"
    assert doc.meta["param"]["bar"] == "this is a bar"

# Generated at 2022-06-17 18:23:30.054571
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print 'hello' or 'goodbye'.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'The name to use.'
    assert docstring.params['name'].type == 'str.'
    assert docstring.params['state'].description == 'Whether to print ' \
                                                    "'hello' or 'goodbye'."

# Generated at 2022-06-17 18:23:37.921223
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
    assert len

# Generated at 2022-06-17 18:23:48.308164
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: a parameter
    :type foo: str
    :param bar: another parameter
    :type bar: int
    :returns: a return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "foo": "a parameter",
        "bar": "another parameter"
    }
    assert docstring.returns == "a return value"
    assert docstring.meta == {
        "foo": "str",
        "bar": "int",
        "returns": "float"
    }


# Generated at 2022-06-17 18:23:57.776934
# Unit test for function parse
def test_parse():
    text = """
    This is a function docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == 'first parameter'
    assert docstring.params['b'] == 'second parameter'
    assert docstring.returns == 'return value'
    assert docstring.meta == {'param': {'a': 'first parameter', 'b': 'second parameter'}, 'returns': 'return value'}

# Generated at 2022-06-17 18:24:02.810850
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: this is a parameter
    :type foo: str
    :param bar: this is another parameter
    :type bar: int
    :returns: description of return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["foo"].description == "this is a parameter"
    assert docstring.params["foo"].annotation == "str"
    assert docstring.params["bar"].description == "this is another parameter"
    assert docstring.params["bar"].annotation == "int"
    assert docstring.returns.description == "description of return value"
    assert docstring

# Generated at 2022-06-17 18:24:12.513038
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {'x': 'x', 'y': 'y'}
    assert docstring.returns == "x + y"
    assert docstring.meta == {'param': ['x', 'y'], 'returns': ['x + y']}

# Generated at 2022-06-17 18:24:17.785483
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    assert parse(text).returns.type == "int"

# Generated at 2022-06-17 18:24:27.739250
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[0].annotation == 'int'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].description == 'another parameter'

# Generated at 2022-06-17 18:24:38.341677
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param name: name of the person
    :type name: str
    :param age: age of the person
    :type age: int
    :returns: a person
    :rtype: Person
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == [
        {'name': 'name', 'type': 'str', 'description': 'name of the person'},
        {'name': 'age', 'type': 'int', 'description': 'age of the person'}
    ]
    assert docstring.returns == {'type': 'Person', 'description': 'a person'}

# Generated at 2022-06-17 18:24:49.641318
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :returns: None
    :raises ValueError: If `bar` is not valid.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params["foo"].description == "This is a parameter."
    assert docstring.params["foo"].annotation == "str"
    assert docstring.params["bar"].description == "This is another parameter."
    assert docstring.params["bar"].annotation is None
    assert docstring.returns.description == "None"
    assert docstring.returns.annotation

# Generated at 2022-06-17 18:25:01.796674
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    """
    assert parse(text).short_description == "This is a test function."
    assert parse(text).long_description == ""
    assert parse(text).params == [
        {
            "name": "x",
            "type": "int",
            "description": "x",
            "annotation": "int",
            "default": None,
        },
        {
            "name": "y",
            "type": "float",
            "description": "y",
            "annotation": "float",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:25:10.451619
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a + b
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "a + b"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
        "returns": "int",
    }


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:25:18.315546
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:25:26.275858
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "a parameter"
    assert docstring.params['b'] == "another parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'something'}


# Generated at 2022-06-17 18:25:36.573843
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: this is a parameter
    :type foo: str
    :param bar: this is another parameter
    :type bar: int
    :returns: description of return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['foo'].description == "this is a parameter"
    assert docstring.params['foo'].type == "str"
    assert docstring.params['bar'].description == "this is another parameter"
    assert docstring.params['bar'].type == "int"
    assert docstring.returns.description == "description of return value"

# Generated at 2022-06-17 18:25:48.698754
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param int a: first parameter
    :param str b: second parameter
    :returns: the sum of a and b
    :raises ValueError: if a or b are not numbers
    """
    parsed = parse(docstring)
    assert parsed.short_description == 'This is a test docstring.'
    assert parsed.long_description == ''
    assert parsed.params['a'].name == 'a'
    assert parsed.params['a'].type == 'int'
    assert parsed.params['a'].description == 'first parameter'
    assert parsed.params['b'].name == 'b'
    assert parsed.params['b'].type == 'str'
    assert parsed.params['b'].description == 'second parameter'
    assert parsed.returns.type

# Generated at 2022-06-17 18:25:56.946449
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a
    :param b: b
    :returns: c
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "a", "b": "b"}
    assert docstring.returns == "c"
    assert docstring.meta == {"param": {"a": "a", "b": "b"}, "returns": "c"}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:26:07.660859
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: None
    :raises ValueError: if a is negative
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.returns.description == ''
    assert docstring.returns.annotation == 'None'
    assert docstring.raises['ValueError'].description == 'if a is negative'
    assert docstring.raises['ValueError'].annotation == ''


# Generated at 2022-06-17 18:26:16.774876
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].annotation == 'str'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.annotation == 'float'

# Generated at 2022-06-17 18:26:26.788823
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :raises ValueError: if something bad happens
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == [
        ('a', 'a parameter', 'int'),
        ('b', 'another parameter', 'str')
    ]
    assert docstring.returns == ('a string', None)
    assert docstring.raises == [('ValueError', 'if something bad happens')]

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:26:35.320919
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "The return value."