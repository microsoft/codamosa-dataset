

# Generated at 2022-06-17 18:16:45.974610
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :raises ValueError: if age is negative
    """
    doc = parse(docstring)
    assert doc.short_description == 'This is a test docstring.'
    assert doc.long_description == ''
    assert doc.meta['param'][0].arg_name == 'name'
    assert doc.meta['param'][0].type_name == 'str'
    assert doc.meta['param'][0].description == 'name of the person'
    assert doc.meta['param'][1].arg_name == 'age'
    assert doc.meta['param'][1].type_name == 'int'

# Generated at 2022-06-17 18:16:54.216127
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    :raises Exception: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "something"
    assert docstring.raises == {"Exception": "if something bad happens"}

# Generated at 2022-06-17 18:17:02.007283
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.returns.description == 'Description of return value.'
    assert docstring.raises[0].description == 'raises an exception'
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'

# Generated at 2022-06-17 18:17:09.470206
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == 'This is a docstring.'
    assert parsed.long_description == ''
    assert parsed.params['arg1'] == 'The first argument.'
    assert parsed.params['arg2'] == 'The second argument.'
    assert parsed.returns == 'Description of return value.'
    assert parsed.raises['keyError'] == 'raises an exception'


# Generated at 2022-06-17 18:17:20.614735
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: The foo parameter.
    :type foo: int
    :param bar: The bar parameter.
    :type bar: str
    :returns: The return value.
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("foo", "The foo parameter.", "int"),
        ("bar", "The bar parameter.", "str"),
    ]
    assert docstring.returns == ("The return value.", "bool")
    assert docstring.meta == {}
    assert docstring.examples == []
    assert docstring.see_also == []
    assert docstring.notes == []

# Generated at 2022-06-17 18:17:31.854850
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a
    :type a: int
    :param b: b
    :type b: str
    :returns: a + b
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "a"
    assert docstring.params['a'].type == "int"
    assert docstring.params['b'].description == "b"
    assert docstring.params['b'].type == "str"
    assert docstring.returns.description == "a + b"
    assert docstring.returns.type == "int"


# Generated at 2022-06-17 18:17:42.896950
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    """
    parsed = parse(docstring)
    assert parsed.short_description == 'This is a test docstring.'
    assert parsed.long_description == ''
    assert parsed.meta == {}
    assert parsed.returns == None
    assert parsed.raises == None
    assert parsed.yields == None
    assert parsed.warns == None
    assert parsed.warnings == None
    assert parsed.attributes == None
    assert parsed.methods == None
    assert parsed.parameters == None
    assert parsed.arguments == None
    assert parsed.variables == None
    assert parsed.fields == None
    assert parsed.examples == None
    assert parsed.seealso == None
    assert parsed.note == None
    assert parsed.notes == None
    assert parsed

# Generated at 2022-06-17 18:17:54.632404
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a + b
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type == 'str'
    assert docstring.returns.description == 'a + b'
    assert docstring.returns.type == 'int'

# Generated at 2022-06-17 18:17:58.605851
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    d = parse(text)
    assert d.short_description == "This is a test docstring."
    assert d.long_description == ""
    assert d.params == [
        ("a", "a parameter"),
        ("b", "another parameter"),
    ]
    assert d.returns == "a return value"
    assert d.meta == {}
    assert d.raises == []
    assert d.warnings == []
    assert d.notes == []
    assert d.todos == []
    assert d.attributes == []
    assert d.references == []
    assert d.examples == []
    assert d.seealso == []

# Generated at 2022-06-17 18:18:05.968372
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: None
    '''
    assert parse(text) == Docstring(
        summary='This is a docstring.',
        description='',
        returns=Docstring.Return('None', ''),
        params=[
            Docstring.Param('arg1', 'the first argument'),
            Docstring.Param('arg2', 'the second argument')
        ],
        meta={},
        style=Style.numpy,
    )

# Generated at 2022-06-17 18:18:20.912704
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is a parameter
    :type foo: str
    :param bar: this is another parameter
    :type bar: int
    :returns: description of return value
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "foo"
    assert docstring.params[0].description == "this is a parameter"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[1].arg_name == "bar"

# Generated at 2022-06-17 18:18:27.989436
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    result = parse(text)
    assert result.short_description == "This is a test docstring."
    assert result.long_description == ""
    assert result.params[0].arg_name == "arg1"
    assert result.params[0].description == "The first argument."
    assert result.params[1].arg_name == "arg2"
    assert result.params[1].description == "The second argument."
    assert result.returns.description == "None"

# Generated at 2022-06-17 18:18:35.728624
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    This is the second line.
    """
    assert parse(docstring).short_description == 'This is a test docstring.'
    assert parse(docstring).long_description == 'This is the second line.'
    assert parse(docstring).meta == {}
    assert parse(docstring).style == Style.numpy
    assert parse(docstring, style=Style.numpy).style == Style.numpy
    assert parse(docstring, style=Style.google).style == Style.google
    assert parse(docstring, style=Style.auto).style == Style.numpy
    assert parse(docstring, style=Style.auto).style == Style.numpy


# Generated at 2022-06-17 18:18:45.204401
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test docstring."
    assert parsed.long_description == ""
    assert parsed.returns.description == "Description of return value."
    assert parsed.raises.exceptions[0].description == "raises an exception"
    assert parsed.params[0].arg_name == "arg1"
    assert parsed.params[0].description == "The first argument."
    assert parsed.params[1].arg_name == "arg2"

# Generated at 2022-06-17 18:18:53.168908
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a description of what is returned'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}

# Generated at 2022-06-17 18:19:05.428644
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: This is a test parameter.
    :param int b: This is another test parameter.
    :returns: This is a test return.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'This is a test parameter.'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].type_name == 'int'

# Generated at 2022-06-17 18:19:15.427288
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :returns: None
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {'a': 'parameter a', 'b': 'parameter b'}
    assert docstring.returns == 'None'
    assert docstring.return_type == 'None'
    assert docstring.meta == {'param a': 'int', 'param b': 'str'}
    assert docstring.errors == []

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:19:23.021690
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['a']
    assert docstring.meta[0].annotation == 'int'
    assert docstring.meta[1].args == ['returns']
    assert docstring.meta[1].annotation == 'str'

# Generated at 2022-06-17 18:19:34.360201
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("x", "x", "int"),
        ("y", "y", "float"),
    ]
    assert docstring.returns == ("x + y", "float")

# Generated at 2022-06-17 18:19:46.182635
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: why you get a key error
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a description of what is returned'
    assert docstring.raises['keyError'] == 'why you get a key error'

if __name__ == '__main__':
    test

# Generated at 2022-06-17 18:20:00.155348
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a value
    :rtype: float
    """
    doc = parse(text)
    assert doc.short_description == 'This is a test docstring.'
    assert doc.long_description == ''
    assert doc.params['a'].description == 'a parameter'
    assert doc.params['a'].type_name == 'int'
    assert doc.params['b'].description == 'another parameter'
    assert doc.params['b'].type_name == 'str'
    assert doc.returns.description == 'a value'
    assert doc.returns.type_name == 'float'
    assert doc.meta == {}

# Generated at 2022-06-17 18:20:11.337742
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    :raises Exception: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params["a"].description == "a parameter"
    assert docstring.params["b"].description == "another parameter"
    assert docstring.returns.description == "something"
    assert len(docstring.raises) == 1
    assert docstring.raises["Exception"].description == "if something bad happens"


# Generated at 2022-06-17 18:20:20.006213
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: Name of the person
    :param int age: Age of the person
    :return: Person's name and age
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'name'
    assert docstring.params[0].type_name == 'str'
    assert docstring.params[0].description == 'Name of the person'
    assert docstring.params[1].arg_name == 'age'
    assert docstring.params[1].type_name == 'int'

# Generated at 2022-06-17 18:20:25.322410
# Unit test for function parse
def test_parse():
    text = """
    This is a function to do something.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function to do something."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"

# Generated at 2022-06-17 18:20:36.309710
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'

# Generated at 2022-06-17 18:20:44.861619
# Unit test for function parse
def test_parse():
    text = """
    This is a summary.

    This is a description.

    :param arg1: this is arg1
    :param arg2: this is arg2
    :returns: description of return value
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.summary == "This is a summary."
    assert docstring.description == "This is a description."
    assert docstring.returns == "description of return value"
    assert docstring.raises == "raises an exception"
    assert docstring.params == {
        "arg1": "this is arg1",
        "arg2": "this is arg2"
    }

# Generated at 2022-06-17 18:20:53.474575
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'None'
    assert docstring.meta == {}

    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    :raises keyError: raises an exception
    '''

# Generated at 2022-06-17 18:21:04.681640
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: this is a parameter
    :type a: int
    :returns: this is a return
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['a']['type'] == 'int'
    assert docstring.meta['a']['desc'] == 'this is a parameter'
    assert docstring.returns['type'] == 'int'
    assert docstring.returns['desc'] == 'this is a return'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:21:13.537180
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param a: a is a parameter.
    :type a: str
    :returns: a + 1
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.meta['a']['type'] == 'str'
    assert docstring.meta['a']['description'] == 'a is a parameter.'
    assert docstring.returns['type'] == 'int'
    assert docstring.returns['description'] == 'a + 1'


# Generated at 2022-06-17 18:21:25.589943
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("Hello, world!") == Docstring(summary="Hello, world!", description="", meta={})
    assert parse("Hello, world!\n\nThis is a test.") == Docstring(summary="Hello, world!", description="This is a test.", meta={})
    assert parse("Hello, world!\n\nThis is a test.\n\n:param test: test param\n:type test: str\n:returns: test return\n:rtype: int") == Docstring(summary="Hello, world!", description="This is a test.", meta={'param': [{'name': 'test', 'type': 'str', 'description': ''}], 'returns': {'type': 'int', 'description': ''}})

# Generated at 2022-06-17 18:21:38.952000
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "a parameter"
    assert docstring.params['b'] == "another parameter"
    assert docstring.returns == "a return value"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:21:46.861079
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: The first parameter.
    :param y: The second parameter.
    :returns: The return value.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].description == "The first parameter."
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].description == "The second parameter."
    assert docstring.returns.description == "The return value."
    assert docstring.raises == []
    assert docstring.meta == {}



# Generated at 2022-06-17 18:21:56.677610
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."

# Generated at 2022-06-17 18:22:02.829684
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "the first argument"
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "the second argument"
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == "the return value"

# Generated at 2022-06-17 18:22:12.535453
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a + b
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params["a"].description == "a parameter"
    assert docstring.params["a"].type_name == "int"
    assert docstring.params["b"].description == "another parameter"
    assert docstring.params["b"].type_name == "str"
    assert docstring.returns.description == "a + b"

# Generated at 2022-06-17 18:22:21.327365
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring.
    '''
    assert parse(docstring) == Docstring(
        summary='This is a docstring.',
        description='',
        meta={},
        examples=[],
        returns=None,
        raises=None,
        attributes=None,
        methods=None,
        see_also=None,
        notes=None,
        references=None,
        warnings=None,
        todos=None,
        deprecated=None,
        metadata=None,
        extended_summary=None,
        extended_description=None,
    )


# Generated at 2022-06-17 18:22:32.087411
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: person's name and age
    :raises ValueError: when age is negative
    """
    doc = parse(docstring)
    assert doc.short_description == 'This is a test docstring.'
    assert doc.long_description == ''
    assert doc.params[0].arg_name == 'name'
    assert doc.params[0].type_name == 'str'
    assert doc.params[0].description == 'name of the person'
    assert doc.params[1].arg_name == 'age'
    assert doc.params[1].type_name == 'int'
    assert doc.params[1].description == 'age of the person'

# Generated at 2022-06-17 18:22:43.814654
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1'] == 'The first argument.'
    assert docstring.meta['arg2'] == 'The second argument.'
    assert docstring.meta['returns'] == 'Description of return value.'
    assert docstring.meta['return'] == 'Description of return value.'
    assert docstring.meta['returns'] == docstring.meta['return']
    assert docstring.meta['returns'] == docstring.returns

# Generated at 2022-06-17 18:22:56.627876
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: first parameter
    :param str b: second parameter
    :returns: the result
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "a",
            "type": "int",
            "description": "first parameter",
            "default": None,
        },
        {
            "name": "b",
            "type": "str",
            "description": "second parameter",
            "default": None,
        },
    ]
    assert docstring.returns == {"type": None, "description": "the result"}
    assert docstring.raises == []
   

# Generated at 2022-06-17 18:23:03.896419
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    assert parse(docstring) == Docstring(
        content='This is a docstring.',
        returns=['Description of return value.'],
        raises=['keyError: raises an exception'],
        args=['arg1: The first argument.', 'arg2: The second argument.']
    )

# Generated at 2022-06-17 18:23:18.370022
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x parameter
    :param y: y parameter
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].description == "x parameter"
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].description == "y parameter"
    assert docstring.returns.description == "x + y"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:23:28.106394
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: The name of the person.
    :param int age: The age of the person.
    :returns: True if the person is allowed in the bar, False otherwise.
    :raises ValueError: If the age is negative.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'name'
    assert docstring.params[0].description == 'The name of the person.'
    assert docstring.params[1].arg_name == 'age'
    assert docstring.params[1].description == 'The age of the person.'
    assert doc

# Generated at 2022-06-17 18:23:37.338990
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param str arg1: The first argument.
    :param int arg2: The second argument.
    :returns: The return value.
    :raises ValueError: If something goes wrong.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].type_name == "int"


# Generated at 2022-06-17 18:23:43.021053
# Unit test for function parse
def test_parse():
    text = """
    This is a test.

    :param a: a
    :param b: b
    :returns: c
    """
    assert parse(text) == Docstring(
        content='This is a test.',
        returns=('c', None),
        params=[('a', None), ('b', None)],
        meta={},
    )


# Generated at 2022-06-17 18:23:53.242917
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "something"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
        "returns": "float",
    }

# Generated at 2022-06-17 18:23:56.290059
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."

# Generated at 2022-06-17 18:24:07.152586
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print 'hello' or 'goodbye'.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == [
        {'name': 'name', 'type': 'str.', 'description': 'The name to use.', 'default': None},
        {'name': 'state', 'type': 'bool.', 'description': 'Whether to print \'hello\' or \'goodbye\'.', 'default': None}
    ]

# Generated at 2022-06-17 18:24:11.180975
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        returns=None,
        raises=None,
        meta={},
    )


# Generated at 2022-06-17 18:24:17.220227
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: Foo parameter
    :type foo: str
    :param bar: Bar parameter
    :type bar: int
    :returns: None
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'foo'
    assert docstring.params[0].description == 'Foo parameter'
    assert docstring.params[0].annotation == 'str'
    assert docstring.params[1].arg_name == 'bar'
    assert docstring.params[1].description == 'Bar parameter'
    assert docstring

# Generated at 2022-06-17 18:24:25.192658
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
   

# Generated at 2022-06-17 18:24:38.890271
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type to be raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].arg_name == 'arg2'
    assert docstring.params['arg2'].description == 'The second argument.'
    assert docstring.returns

# Generated at 2022-06-17 18:24:50.178945
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == "None"
    assert docstring

# Generated at 2022-06-17 18:25:02.670061
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: baz
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'foo'
    assert docstring.params['foo'].type_name == 'str'
    assert docstring.params['bar'].description == 'bar'
    assert docstring.params['bar'].type_name == 'int'
    assert docstring.returns.description == 'baz'
    assert docstring.returns.type_name == 'float'

# Generated at 2022-06-17 18:25:09.496555
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == 'a return value'
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'a return value'}

# Generated at 2022-06-17 18:25:18.356833
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "a parameter", "b": "another parameter"}
    assert docstring.returns == "a return value"
    assert docstring.meta == {"param a": "a parameter", "param b": "another parameter", "returns": "a return value"}
    assert docstring.style == Style.numpy

# Generated at 2022-06-17 18:25:27.306768
# Unit test for function parse
def test_parse():
    text = """This is a function.
    :param a: this is a
    :type a: int
    :param b: this is b
    :type b: str
    :returns: this is return
    :rtype: float
    """
    doc = parse(text)
    assert doc.short_description == "This is a function."
    assert doc.long_description == ""
    assert doc.params[0].arg_name == "a"
    assert doc.params[0].description == "this is a"
    assert doc.params[0].type_name == "int"
    assert doc.params[1].arg_name == "b"
    assert doc.params[1].description == "this is b"
    assert doc.params[1].type_name == "str"

# Generated at 2022-06-17 18:25:36.457592
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'

# Generated at 2022-06-17 18:25:45.769734
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "Description of return value."
    assert docstring.raises == {"keyError": "raises an exception"}

# Generated at 2022-06-17 18:25:55.330747
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'None'
    assert docstring.meta == {}

# Generated at 2022-06-17 18:26:06.623818
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'param1': 'this is a first param',
                                'param2': 'this is a second param'}
    assert docstring.returns == 'this is a description of what is returned'
    assert docstring.raises == {'keyError': 'raises an exception'}

# Generated at 2022-06-17 18:26:16.861936
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["arg1"] == "The first argument."
    assert docstring.meta["param"]["arg2"] == "The second argument."
    assert docstring.meta["returns"] == "None"
    assert docstring.meta["raises"]["keyError"] == "raises an exception"

# Generated at 2022-06-17 18:26:26.829490
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.meta) == 3
    assert docstring.meta['arg1'].arg_name == 'arg1'
    assert docstring.meta['arg1'].type_name == ''
    assert docstring.meta['arg1'].description == 'the first argument'
    assert docstring.meta['arg2'].arg_name == 'arg2'
    assert docstring.meta['arg2'].type_name == ''

# Generated at 2022-06-17 18:26:33.282142
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == [("a", "a parameter", "int")]
    assert docstring.returns == ("a return value", "str")
    assert docstring.meta == {}
