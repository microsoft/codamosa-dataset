

# Generated at 2022-06-17 18:16:41.563726
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: This is a test parameter.
    :type a: str
    :param b: This is another test parameter.
    :type b: int
    :returns: This is a test return.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "This is a test parameter."
    assert docstring.params[0].type_name == "str"
    assert docstring.params[1].arg_name == "b"

# Generated at 2022-06-17 18:16:47.485810
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:16:57.033447
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: Name of the person
    :param int age: Age of the person
    :returns: Person's name and age
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "Name of the person"
    assert docstring.params[1].arg_name == "age"
    assert docstring.params[1].type_name == "int"
    assert docstring.params

# Generated at 2022-06-17 18:17:06.559882
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type to be raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["arg1"] == "The first argument."
    assert docstring.meta["param"]["arg2"] == "The second argument."
    assert docstring.meta["returns"] == "The return value."
    assert docstring.meta["raises"]["keyError"] == "The exception type to be raised."


# Generated at 2022-06-17 18:17:18.470455
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    assert docstring.returns[0].arg_type == 'None'
    assert docstring.raises[0].arg_type == 'keyError'
    assert docstring.raises[0].description == 'raises an exception'


# Generated at 2022-06-17 18:17:22.643402
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:17:28.984402
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: foo
    :param bar: bar
    :returns: returns
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["foo"] == "foo"
    assert docstring.meta["param"]["bar"] == "bar"
    assert docstring.meta["returns"] == "returns"

# Generated at 2022-06-17 18:17:39.378437
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: a + b
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test docstring."
    assert parsed.long_description == ""
    assert parsed.params == {'a': 'first parameter', 'b': 'second parameter'}
    assert parsed.returns == "a + b"
    assert parsed.meta == {'param': {'a': 'first parameter', 'b': 'second parameter'}, 'returns': 'a + b'}

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:17:45.396019
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a test function.'
    assert doc.long_description == ''
    assert doc.meta['param']['a'] == 'a parameter'
    assert doc.meta['param']['b'] == 'another parameter'
    assert doc.meta['return'] == 'a return value'

# Generated at 2022-06-17 18:17:54.201964
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :param b: parameter b
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "parameter a", "b": "parameter b"}
    assert docstring.returns == "return value"
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:18:05.311428
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'None'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:18:15.911906
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises Exception: Because I said so.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1'] == 'The first argument.'
    assert docstring.meta['arg2'] == 'The second argument.'
    assert docstring.meta['returns'] == 'Description of return value.'
    assert docstring.meta['raises'] == 'Because I said so.'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:18:22.857239
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param int x: x value
    :param int y: y value
    :returns: x + y
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['x'].description == 'x value'
    assert docstring.params['y'].description == 'y value'
    assert docstring.returns.description == 'x + y'


# Generated at 2022-06-17 18:18:30.240634
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.returns.type_name == "int"
    assert docstring.returns.description == "x + y"
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "x"
    assert docstring.params[1].arg_name == "y"

# Generated at 2022-06-17 18:18:37.986347
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {}



# Generated at 2022-06-17 18:18:46.253337
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == {'x': 'x', 'y': 'y'}
    assert docstring.returns == 'x + y'
    assert docstring.return_type == 'int'
    assert docstring.meta == {'param_types': {'x': 'int', 'y': 'int'}}

# Generated at 2022-06-17 18:18:54.141250
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
    assert docstring.raises[0].type_name

# Generated at 2022-06-17 18:18:57.208231
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1'] == 'the first argument'
    assert docstring.meta['arg2'] == 'the second argument'
    assert docstring.meta['returns'] == 'None'

# Generated at 2022-06-17 18:19:08.611348
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a return"
    assert docstring.raises['keyError'] == "raises an exception"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:19:17.646812
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument."
    }
    assert docstring.returns == "The return value."
    assert docstring.raises == {
        "keyError": "The exception type raised."
    }

# Generated at 2022-06-17 18:19:33.115571
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: This is a test parameter.
    :type a: int
    :returns: This is a test return.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "This is a test parameter."
    assert docstring.params[0].type_name == "int"
    assert docstring.returns.description == "This is a test return."
    assert docstring.returns.type_name == "str"

# Generated at 2022-06-17 18:19:38.073425
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params["a"].description == "a parameter"
    assert docstring.params["a"].type == "int"
    assert docstring.returns.description == "a return value"
    assert docstring.returns.type == "str"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:19:46.688283
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.meta['parameters']['x']['description'] == 'x'
    assert docstring.meta['parameters']['x']['annotation'] == 'int'
    assert docstring.meta['return']['description'] == 'x'
    assert docstring.meta['return']['annotation'] == 'int'

# Generated at 2022-06-17 18:19:57.188696
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test: test parameter
    :type test: str
    :returns: test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "test"
    assert docstring.params[0].description == "test parameter"
    assert docstring.params[0].type_name == "str"
    assert docstring.returns.description == "test return"
    assert docstring.returns.type_name == "str"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:20:09.445425
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "Description of return value."
    assert docstring.returns.type_name == "int"
    assert docstring.args[0].arg_name == "arg1"
    assert docstring.args[0].type_name == "int"
    assert docstring.args[0].description == "The first argument."
   

# Generated at 2022-06-17 18:20:19.304245
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: the result
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].type_name == 'str'
    assert doc

# Generated at 2022-06-17 18:20:25.238244
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    assert parse(text) == Docstring(
        summary='This is a docstring.',
        description='',
        returns='Description of return value.',
        raises='keyError: raises an exception',
        meta={
            'arg1': 'The first argument.',
            'arg2': 'The second argument.'
        }
    )

# Generated at 2022-06-17 18:20:34.130583
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int, optional
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: None
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "None"
    assert docstring.returns.type_annotation == "None"
    assert docstring.meta["arg1"].description == "The first argument."
    assert docstring.meta["arg1"].type_annotation == "int, optional"

# Generated at 2022-06-17 18:20:41.320649
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """

# Generated at 2022-06-17 18:20:55.323666
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["name"].arg_type == "str"
    assert docstring.meta["param"]["name"].description == "name of the person"
    assert docstring.meta["param"]["age"].arg_type == "int"
    assert docstring.meta["param"]["age"].description == "age of the person"
    assert docstring.meta["returns"].arg_type

# Generated at 2022-06-17 18:21:06.398233
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == {"x": "x", "y": "y"}
    assert docstring.returns == "x + y"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:21:14.379018
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["arg1"] == "The first argument."
    assert docstring.params["arg2"] == "The second argument."
    assert docstring.returns == "None"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:21:25.899805
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int x: x coordinate
    :param int y: y coordinate
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.meta['x']['type'] == 'int'
    assert docstring.meta['x']['description'] == 'x coordinate'
    assert docstring.meta['y']['type'] == 'int'
    assert docstring.meta['y']['description'] == 'y coordinate'
    assert docstring.returns['type'] == ''
    assert docstring.returns['description'] == 'x + y'


# Generated at 2022-06-17 18:21:38.614395
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {"name": "arg1", "type": None, "desc": "The first argument."},
        {"name": "arg2", "type": None, "desc": "The second argument."},
    ]
    assert docstring.returns == {"type": None, "desc": "Description of return value."}

# Generated at 2022-06-17 18:21:45.800235
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'first parameter'
    assert docstring.params['b'] == 'second parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {'param': {'a': 'first parameter', 'b': 'second parameter'}, 'returns': 'something'}
    assert docstring.style == Style.numpy

# Generated at 2022-06-17 18:21:52.886203
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    text = '''
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    assert parse(text) == GoogleStyle(text)

# Generated at 2022-06-17 18:22:04.109689
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param int a: first parameter
    :param str b: second parameter
    :returns: something
    :raises ValueError: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "first parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"

# Generated at 2022-06-17 18:22:12.255754
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1'] == 'The first argument.'
    assert docstring.meta['arg2'] == 'The second argument.'
    assert docstring.meta['returns'] == 'Description of return value.'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:22:22.888317
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a return'
    assert docstring.raises['keyError'] == 'raises an exception'

# Generated at 2022-06-17 18:22:33.759836
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a is a parameter
    :type a: int
    :param b: b is a parameter
    :type b: int
    :returns: a + b
    :rtype: int
    '''
    assert parse(text).short_description == 'This is a test function.'
    assert parse(text).long_description == ''
    assert parse(text).returns.type_name == 'int'
    assert parse(text).returns.description == 'a + b'
    assert parse(text).params[0].name == 'a'
    assert parse(text).params[0].type_name == 'int'
    assert parse(text).params[0].description == 'a is a parameter'

# Generated at 2022-06-17 18:22:44.688175
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    assert parse(text).summary == 'This is a test docstring.'
    assert parse(text).meta['param']['a'] == 'a parameter'
    assert parse(text).meta['param']['b'] == 'another parameter'
    assert parse(text).meta['returns'] == 'a return value'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:22:57.103413
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    d = parse(text)
    assert d.short_description == "This is a function."
    assert d.long_description == ""
    assert d.params[0].arg_name == "x"
    assert d.params[0].description == "x"
    assert d.params[0].annotation == "int"
    assert d.params[1].arg_name == "y"
    assert d.params[1].description == "y"
    assert d.params[1].annotation == "int"
    assert d.returns.description == "x + y"

# Generated at 2022-06-17 18:23:07.039740
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    """
    doc = parse(text)
    assert doc.short_description == "This is a function."
    assert doc.long_description == ""
    assert doc.params == [
        {
            "name": "x",
            "type": "int",
            "description": "x",
            "default": None,
        },
        {
            "name": "y",
            "type": "float",
            "description": "y",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:23:17.774461
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: person's name and age
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'name of the person'
    assert docstring.params['age'].description == 'age of the person'
    assert docstring.returns.description == "person's name and age"
    assert docstring.returns.type_name == 'str'
    assert docstring.raises is None
    assert docstring.meta is None
    assert docstring.extras == []

# Unit

# Generated at 2022-06-17 18:23:27.722709
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {"name": "a", "type": "int", "description": "a parameter"},
        {"name": "b", "type": "str", "description": "another parameter"},
    ]
    assert docstring.returns == {"type": "str", "description": "a string"}

# Generated at 2022-06-17 18:23:37.180256
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param str name: Name of the person.
    :param int age: Age of the person.
    :returns: Person's name and age.
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'Name of the person.'
    assert docstring.params['age'].description == 'Age of the person.'
    assert docstring.returns.description == "Person's name and age."
    assert docstring.returns.type_name == 'str'
    assert docstring.raises is None
    assert docstring.meta == {}
    assert docstring.style == Style.n

# Generated at 2022-06-17 18:23:47.923968
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: this is a foo
    :param bar: this is a bar
    :returns: this is a return
    """
    doc = parse(text)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == "foo"
    assert doc.params[0].description == "this is a foo"
    assert doc.params[1].arg_name == "bar"
    assert doc.params[1].description == "this is a bar"
    assert len(doc.returns) == 1
    assert doc.returns[0].description == "this is a return"
    assert doc.returns[0].type

# Generated at 2022-06-17 18:23:54.439656
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert docstring.returns == "Description of return value."
    assert docstring.raises == [("keyError", "raises an exception")]

# Generated at 2022-06-17 18:23:57.173089
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['x'] == 'x'
    assert docstring.meta['param']['y'] == 'y'
    assert docstring.meta['returns'] == 'x + y'

# Generated at 2022-06-17 18:24:08.047011
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'arg1': 'The first argument.',
                                'arg2': 'The second argument.'}
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises == {'keyError': 'raises an exception'}

# Generated at 2022-06-17 18:24:21.534106
# Unit test for function parse
def test_parse():
    text = '''
    This is a test.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test.'
    assert docstring.long_description == ''
    assert docstring.meta == {}
    assert docstring.params == []
    assert docstring.returns == None
    assert docstring.raises == []
    assert docstring.yields == None
    assert docstring.warnings == []
    assert docstring.notes == []
    assert docstring.references == []
    assert docstring.examples == []
    assert docstring.see_also == []
    assert docstring.todo == []
    assert docstring.attributes == []
    assert docstring.methods == []
    assert docstring.class_variables == []

# Generated at 2022-06-17 18:24:27.640399
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: float
    """
    assert parse(text) == Docstring(
        summary="This is a function.",
        description="",
        params=[("a", "a parameter", "int")],
        returns=("a return value", "float"),
        style=Style.numpy,
    )


# Generated at 2022-06-17 18:24:36.071750
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: the first parameter
    :param str b: the second parameter
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("a", "the first parameter", "int"),
        ("b", "the second parameter", "str"),
    ]
    assert docstring.returns == ("the return value", None)
    assert docstring.meta == {}


# Generated at 2022-06-17 18:24:43.792128
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    :raises Exception: if something bad happens
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == ""
    assert doc.params == {'a': 'first parameter', 'b': 'second parameter'}
    assert doc.returns == "something"
    assert doc.raises == {'Exception': 'if something bad happens'}
    assert doc.meta == {'param': ['a', 'b'], 'returns': ['something'], 'raises': ['Exception']}
    assert doc.style == Style.numpy


# Generated at 2022-06-17 18:24:54.963059
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""

# Generated at 2022-06-17 18:24:58.980553
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a
    :param b: b
    :return: c
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {'a': 'a', 'b': 'b'}
    assert docstring.returns == 'c'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:25:08.969576
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: this is a parameter
    :type foo: str
    :param bar: this is another parameter
    :type bar: int
    :returns: None
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "foo",
            "type": "str",
            "description": "this is a parameter",
            "default": None,
        },
        {
            "name": "bar",
            "type": "int",
            "description": "this is another parameter",
            "default": None,
        },
    ]
    assert docstring

# Generated at 2022-06-17 18:25:18.152083
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 3
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].description == 'another parameter'
    assert doc

# Generated at 2022-06-17 18:25:26.718070
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    text = '''
    This is a test docstring.
    '''
    style = Style.auto
    if style != Style.auto:
        return STYLES[style](text)
    rets = []
    for parse_ in STYLES.values():
        try:
            rets.append(parse_(text))
        except ParseError as e:
            exc = e
    if not rets:
        raise exc
    return sorted(rets, key=lambda d: len(d.meta), reverse=True)[0]
    assert text == rets[0].short_description


# Generated at 2022-06-17 18:25:35.672067
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a test parameter
    :param b: another test parameter
    :returns: a test return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a test parameter'
    assert docstring.params['b'] == 'another test parameter'
    assert docstring.returns == 'a test return value'
    assert docstring.meta == {'param': ['a', 'b'], 'returns': []}


# Generated at 2022-06-17 18:25:47.849812
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        returns=Docstring.Return(
            description='None',
            type=None,
        ),
        params=[
            Docstring.Param(
                name='arg1',
                description='The first argument.',
                type=None,
            ),
            Docstring.Param(
                name='arg2',
                description='The second argument.',
                type=None,
            ),
        ],
        meta={},
    )

# Generated at 2022-06-17 18:25:52.650867
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param str a: this is a test parameter
    :returns: this is a test return
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'this is a test parameter'
    assert docstring.returns.description == 'this is a test return'


# Generated at 2022-06-17 18:26:02.140690
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params[0].arg_name == 'x'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'x'
    assert docstring.params[1].arg_name == 'y'
    assert docstring.params[1].type_name == 'int'
    assert docstring.params[1].description == 'y'

# Generated at 2022-06-17 18:26:12.725659
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: person's name and age
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {'name': 'name', 'type': 'str', 'description': 'name of the person'},
        {'name': 'age', 'type': 'int', 'description': 'age of the person'}
    ]
    assert docstring.returns == {'type': '', 'description': "person's name and age"}

# Generated at 2022-06-17 18:26:22.909101
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:26:26.041557
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.
    '''
    assert parse(text) == Docstring(
        content='This is a docstring.',
        meta={},
        style=Style.pep257,
    )


# Generated at 2022-06-17 18:26:28.064852
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring
    """
    assert parse(text).short_description == "This is a test docstring"
