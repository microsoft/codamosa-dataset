

# Generated at 2022-06-17 18:16:42.134713
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a formatted string
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "name of the person"
    assert docstring.params[1].arg_name == "age"
    assert docstring.params[1].type_name == "int"
    assert docstring.params[1].description == "age of the person"
    assert docstring.returns.type_name

# Generated at 2022-06-17 18:16:53.379589
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta == {}
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.yields == None
    assert docstring.warns == None
    assert docstring.attributes == None
    assert docstring.methods == None
    assert docstring.see_also == None
    assert docstring.notes == None
    assert docstring.references == None
    assert docstring.examples == None
    assert docstring.index == None
    assert docstring.deprecated == None
    assert docstring.todo == None
    assert doc

# Generated at 2022-06-17 18:17:01.391919
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "Description of return value."
    assert docstring.raises == {"keyError": "raises an exception"}

# Generated at 2022-06-17 18:17:09.549961
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.
    '''
    assert parse(text) == Docstring(
        summary='This is a docstring.',
        description='',
        meta={},
        returns=None,
        raises=None,
        attributes=None,
        parameters=None,
        examples=None,
        see_also=None,
        notes=None,
        references=None,
        warnings=None,
        todos=None,
        warnings=None,
        deprecated=None,
        tags=None,
        meta_yaml=None,
        meta_json=None,
        meta_toml=None,
        meta_other=None,
        meta_other_name=None,
    )

# Generated at 2022-06-17 18:17:20.409651
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:17:31.672691
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.returns.description == 'a return value'

    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)

# Generated at 2022-06-17 18:17:42.032505
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert docstring.returns == "Description of return value."
    assert docstring.raises == [("keyError", "raises an exception")]
    assert docstring.meta == {}


# Generated at 2022-06-17 18:17:46.901171
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    """
    assert parse(docstring) == Docstring(
        content='This is a test docstring.',
        meta={},
        style=Style.google,
    )


# Generated at 2022-06-17 18:17:56.477869
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: x parameter
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"x": "x parameter"}
    assert docstring.returns == "x"
    assert docstring.meta == {"type": {"x": "int"}, "rtype": "int"}


# Generated at 2022-06-17 18:18:06.174086
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {"arg1": "The first argument."},
        {"arg2": "The second argument."},
    ]
    assert docstring.returns == "The return value."
    assert docstring.raises == [{"keyError": "The exception type raised."}]
    assert docstring.meta == {}
    assert docstring.style == Style.numpy

# Generated at 2022-06-17 18:18:20.981709
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a
    :type a: int
    :param b: b
    :type b: str
    :returns: a + b
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].arg_type == 'int'
    assert docstring.params['a'].description == 'a'
    assert docstring.params['b'].arg_type == 'str'
    assert docstring.params['b'].description == 'b'
    assert docstring.returns.arg_type == 'int'
    assert docstring.returns.description == 'a + b'


# Generated at 2022-06-17 18:18:28.023907
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "first parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "second parameter"
    assert docstring.returns.description == "something"


# Generated at 2022-06-17 18:18:31.467264
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'


# Generated at 2022-06-17 18:18:41.172372
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['parameters']['a'].arg_type == 'int'
    assert docstring.meta['parameters']['a'].description == 'a parameter'
    assert docstring.meta['returns'].arg_type == 'str'
    assert docstring.meta['returns'].description == 'a return value'


# Generated at 2022-06-17 18:18:50.000933
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:18:56.113765
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param str name: Name of the person
    :param int age: Age of the person
    :return: Person's name and age
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.meta['name']['type'] == 'str'
    assert docstring.meta['name']['desc'] == 'Name of the person'
    assert docstring.meta['age']['type'] == 'int'
    assert docstring.meta['age']['desc'] == 'Age of the person'
    assert docstring.returns['type'] == 'str'

# Generated at 2022-06-17 18:19:06.618800
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: this is a
    :param b: this is b
    :returns: this is return
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "this is a"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "this is b"
    assert docstring.returns.description == "this is return"


# Generated at 2022-06-17 18:19:16.399760
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'something'
    assert docstring.returns.type_name == 'float'

#

# Generated at 2022-06-17 18:19:24.097727
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: This is a parameter.
    :type a: int
    :returns: This is a return.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].description == 'This is a parameter.'
    assert docstring.params[0].type_name == 'int'
    assert docstring.returns.description == 'This is a return.'
    assert docstring.returns.type_name == 'int'


# Generated at 2022-06-17 18:19:33.200673
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "a parameter"
    assert docstring.params['b'] == "another parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {}
    assert docstring.style == Style.numpy
    assert docstring.raw == text


# Generated at 2022-06-17 18:19:47.622382
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['x'].arg_type == 'int'
    assert docstring.params['y'].arg_type == 'float'
    assert docstring.returns.arg_type == 'float'
    assert docstring.returns.description == 'x + y'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:19:50.412266
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring
    """
    assert parse(docstring).short_description == "This is a docstring"



# Generated at 2022-06-17 18:19:59.903774
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == ""
    assert doc.params == [
        {
            "name": "arg1",
            "type": None,
            "description": "The first argument.",
            "default": None,
        },
        {
            "name": "arg2",
            "type": None,
            "description": "The second argument.",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:20:11.156930
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print name or not.
    :type state: bool.
    :returns: None
    :raises keyError: Raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == [
        {'name': 'name', 'type': 'str.', 'description': 'The name to use.'},
        {'name': 'state', 'type': 'bool.', 'description': 'Whether to print name or not.'}
    ]

# Generated at 2022-06-17 18:20:19.869516
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    from docstring_parser.styles import GoogleStyle
    from docstring_parser.common import Docstring

    text = """
    This is a docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.returns.type_name == "bool"
    assert docstring.returns.description == "The return value. True for success, False otherwise."
    assert len(docstring.arguments) == 2
    assert doc

# Generated at 2022-06-17 18:20:27.862325
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param int a: This is a.
    :param str b: This is b.
    :returns: This is return.
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a function.'
    assert doc.long_description == ''
    assert doc.params['a'].arg_type == 'int'
    assert doc.params['a'].description == 'This is a.'
    assert doc.params['b'].arg_type == 'str'
    assert doc.params['b'].description == 'This is b.'
    assert doc.returns.arg_type == ''
    assert doc.returns.description == 'This is return.'
    assert doc.meta == {}

# Generated at 2022-06-17 18:20:34.992786
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"


# Generated at 2022-06-17 18:20:41.929297
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "arg1",
            "type": None,
            "desc": "The first argument.",
            "default": None,
        },
        {
            "name": "arg2",
            "type": None,
            "desc": "The second argument.",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:20:55.015125
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is a foo
    :type foo: int
    :param bar: this is a bar
    :type bar: str
    :returns: this is a return
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'this is a foo'
    assert docstring.params['foo'].type_name == 'int'
    assert docstring.params['bar'].description == 'this is a bar'
    assert docstring.params['bar'].type_name == 'str'
    assert docstring.returns.description == 'this is a return'
    assert docstring

# Generated at 2022-06-17 18:21:02.274737
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."

# Generated at 2022-06-17 18:21:17.003059
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: why you get a key error
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a description of what is returned'
    assert docstring.raises['keyError'] == 'why you get a key error'


# Generated at 2022-06-17 18:21:28.144934
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: this is a test parameter
    :type a: int
    :returns: this is a test return
    :rtype: str
    """
    doc = parse(text)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == ""
    assert doc.params == [
        {
            "name": "a",
            "type": "int",
            "desc": "this is a test parameter",
            "meta": {
                "type": "param",
                "name": "a",
                "type_name": "int",
                "description": "this is a test parameter"
            }
        }
    ]

# Generated at 2022-06-17 18:21:40.140276
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    doc = parse(text)
    assert doc.short_description == "This is a function."
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert len(doc.returns) == 1
    assert len(doc.raises) == 0
    assert len(doc.meta) == 0
    assert doc.params[0].arg_name == "x"
    assert doc.params[0].arg_type == ""
    assert doc.params[0].description == "x"
    assert doc.params[1].arg_name == "y"
    assert doc.params[1].arg_type == ""

# Generated at 2022-06-17 18:21:54.114527
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: param a
    :type a: int
    :param b: param b
    :type b: str
    :returns: something
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'param a'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'param b'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'something'
    assert docstring.returns.type_name == 'int'

# Generated at 2022-06-17 18:22:05.256779
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: Description of return value.
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.return_type == "bool"
    assert docstring.return_description == "Description of return value."
    assert docstring.meta["arg1"]["type"] == "int"
    assert docstring.meta["arg1"]["description"] == "The first argument."
    assert docstring.meta["arg2"]["type"] == "str"


# Generated at 2022-06-17 18:22:13.372266
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: This is a test parameter.
    :type a: int
    :returns: This is a test return.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "This is a test parameter."
    assert docstring.params['a'].type == "int"
    assert docstring.returns.description == "This is a test return."
    assert docstring.returns.type == "str"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:22:22.749709
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises Exception: An exception.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'The return value.'
    assert docstring.raises['Exception'] == 'An exception.'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:22:33.612947
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'name'
    assert docstring.params[0].type_name == 'str'
    assert docstring.params[0].description == 'name of the person'
    assert docstring.params[1].arg_name == 'age'
    assert docstring.params[1].type_name == 'int'
    assert docstring.params

# Generated at 2022-06-17 18:22:45.096667
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    assert parse(docstring) == parse(docstring, style=Style.google)

    docstring = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    assert parse(docstring) == parse(docstring, style=Style.numpy)


# Generated at 2022-06-17 18:22:57.239116
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'The first parameter.'
    assert docstring.params['param2'] == 'The second parameter.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:23:07.987728
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 3
    assert len(docstring.other) == 0


# Generated at 2022-06-17 18:23:18.438288
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param int a: the first parameter
    :param str b: the second parameter
    :returns: the return value
    :raises ValueError: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "the first parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"
    assert docstring.params

# Generated at 2022-06-17 18:23:26.417543
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.returns.description == 'Description of return value.'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].description == 'The second argument.'


# Generated at 2022-06-17 18:23:34.237633
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: baz
    :rtype: float
    """
    assert parse(docstring) == Docstring(
        summary="This is a docstring.",
        description="",
        params=[
            ("foo", "foo", "str"),
            ("bar", "bar", "int")
        ],
        returns=("baz", "float")
    )

# Generated at 2022-06-17 18:23:45.244429
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    doc = parse(text)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params[0].arg_name == "arg1"
    assert doc.params[0].description == "The first argument."
    assert doc.params[1].arg_name == "arg2"
    assert doc.params[1].description == "The second argument."
    assert doc.returns.description == "Description of return value."
    assert doc.raises[0].exc_name == "keyError"
    assert doc

# Generated at 2022-06-17 18:23:54.632864
# Unit test for function parse
def test_parse():
    text = """
        This is a docstring.

        :param int a: parameter a
        :param int b: parameter b
        :returns: sum of a and b
        """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "parameter a"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "int"
    assert docstring.params[1].description == "parameter b"
    assert len

# Generated at 2022-06-17 18:24:05.897618
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "", "", "")
    assert parse("\n") == Docstring("", "", "", "")
    assert parse("\n\n") == Docstring("", "", "", "")
    assert parse("\n\n\n") == Docstring("", "", "", "")
    assert parse("\n\n\n\n") == Docstring("", "", "", "")
    assert parse("\n\n\n\n\n") == Docstring("", "", "", "")
    assert parse("\n\n\n\n\n\n") == Docstring("", "", "", "")
    assert parse("\n\n\n\n\n\n\n") == Docstring("", "", "", "")

# Generated at 2022-06-17 18:24:09.797401
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "a parameter"}
    assert docstring.returns == "a return value"
    assert docstring.meta == {"a": "int", "returns": "str"}


# Generated at 2022-06-17 18:24:14.380730
# Unit test for function parse
def test_parse():
    text = '''
    This is a test.
    '''

# Generated at 2022-06-17 18:24:22.750707
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {'param a': 'a parameter', 'param b': 'another parameter', 'returns': 'something'}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:24:35.121531
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a string
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['name'].arg_type == 'str'
    assert docstring.meta['param']['name'].description == 'name of the person'
    assert docstring.meta['param']['age'].arg_type == 'int'
    assert docstring.meta['param']['age'].description == 'age of the person'
    assert docstring.meta['returns'].arg_type == 'a string'

# Generated at 2022-06-17 18:24:43.113626
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {"x": "x"}
    assert docstring.returns == "x"
    assert docstring.meta == {"x": "int"}
    assert docstring.raises == {}
    assert docstring.warns == {}
    assert docstring.see_also == {}
    assert docstring.notes == {}
    assert docstring.references == {}
    assert docstring.examples == ""
    assert docstring.attributes == {}
    assert doc

# Generated at 2022-06-17 18:24:54.777344
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a test function.'
    assert doc.long_description == ''
    assert doc.params[0].arg_name == 'x'
    assert doc.params[0].type_name == 'int'
    assert doc.params[0].description == 'x'
    assert doc.params[1].arg_name == 'y'
    assert doc.params[1].type_name == 'int'
    assert doc.params[1].description == 'y'

# Generated at 2022-06-17 18:25:00.501354
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :returns: return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["a"].description == "parameter a"
    assert docstring.params["a"].annotation == "int"
    assert docstring.params["b"].description == "parameter b"
    assert docstring.params["b"].annotation == "str"
    assert docstring.returns.description == "return value"
    assert docstring.returns.annotation == "float"

# Generated at 2022-06-17 18:25:03.828741
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.
    """
    assert parse(docstring).short_description == "This is a docstring."


# Generated at 2022-06-17 18:25:14.546438
# Unit test for function parse

# Generated at 2022-06-17 18:25:23.954054
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a return"
    assert docstring.raises['keyError'] == "raises an exception"


# Generated at 2022-06-17 18:25:34.820414
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params == [
        ('arg1', 'The first argument.'),
        ('arg2', 'The second argument.'),
    ]
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises == [('keyError', 'raises an exception')]
    assert docstring.meta == {}

# Generated at 2022-06-17 18:25:43.174261
# Unit test for function parse
def test_parse():
    text = '''\
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == {'arg1': 'The first argument.',
                                'arg2': 'The second argument.'}
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises == {'keyError': 'raises an exception'}


# Generated at 2022-06-17 18:25:47.627909
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("a", "first parameter"),
        ("b", "second parameter"),
    ]
    assert docstring.returns == "something"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:25:55.593945
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        returns=None,
        raises=None,
        meta={}
    )


# Generated at 2022-06-17 18:26:05.748034
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type == 'str'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:26:12.767991
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "a parameter"
    assert docstring.params['b'] == "another parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:26:22.946724
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a
    :type a: int
    :param b: b
    :type b: str
    :returns: a + b
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.params['b'].description == 'b'
    assert docstring.params['b'].annotation == 'str'
    assert docstring.returns.description == 'a + b'
    assert docstring.returns.annotation == 'int'

# Generated at 2022-06-17 18:26:30.986990
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["x"]["type"] == "int"
    assert docstring.meta["y"]["type"] == "int"
    assert docstring.returns["type"] == "int"
