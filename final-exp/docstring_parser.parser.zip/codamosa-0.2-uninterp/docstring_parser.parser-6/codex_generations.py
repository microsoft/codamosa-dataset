

# Generated at 2022-06-17 18:16:40.096518
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "None"
    assert docstring.params['arg1'].description == "the first argument"
    assert docstring.params['arg2'].description == "the second argument"


# Generated at 2022-06-17 18:16:52.776924
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].arg_name == 'arg2'
    assert docstring.params['arg2'].description == 'The second argument.'

# Generated at 2022-06-17 18:16:59.575396
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: first parameter
    :param str b: second parameter
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("a", "first parameter", "int"),
        ("b", "second parameter", "str"),
    ]
    assert docstring.returns == ("return value", None)
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:17:08.904320
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring"
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises['keyError'] == "raises an exception"

# Generated at 2022-06-17 18:17:18.382927
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    from docstring_parser.styles import GoogleStyle
    assert parse("""
    This is a test.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """) == GoogleStyle("""
    This is a test.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """)


# Generated at 2022-06-17 18:17:22.643431
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    assert parse(text) == Docstring(
        content='This is a test docstring.',
        meta={},
        style=Style.google
    )

# Generated at 2022-06-17 18:17:31.623557
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "something"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
        "returns": "float",
    }

# Generated at 2022-06-17 18:17:42.658634
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    doc = parse(text)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params[0].arg_name == "a"
    assert doc.params[0].description == "a parameter"
    assert doc.params[0].annotation == "int"
    assert doc.params[0].default == ""
    assert doc.params[1].arg_name == "b"
    assert doc.params[1].description == "another parameter"

# Generated at 2022-06-17 18:17:54.525539
# Unit test for function parse
def test_parse():
    text = """\
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: description of return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params["foo"].description == "This is a parameter."
    assert docstring.params["foo"].type_name == "str"
    assert docstring.params["bar"].description == "This is another parameter."
    assert docstring.params["bar"].type_name == "int"
    assert docstring.returns.description == "description of return value"
   

# Generated at 2022-06-17 18:18:04.404331
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: why you get a key error
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises['keyError'] == "why you get a key error"


# Generated at 2022-06-17 18:18:11.352285
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """
    doc = parse(text)
    assert doc.short_description == "This is a docstring."


# Generated at 2022-06-17 18:18:14.814314
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """
    assert parse(text).short_description == "This is a docstring."


# Generated at 2022-06-17 18:18:24.245182
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1'] == 'the first argument'
    assert docstring.meta['arg2'] == 'the second argument'
    assert docstring.meta['returns'] == 'the return value'
    assert docstring.meta['return'] == 'the return value'
    assert docstring.meta['returns'] == 'the return value'
    assert docstring.meta['return value'] == 'the return value'

# Generated at 2022-06-17 18:18:29.184581
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param int a: This is a test parameter.
    :returns: This is a test return.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'This is a test parameter.'
    assert docstring.returns.description == 'This is a test return.'


# Generated at 2022-06-17 18:18:39.155344
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:18:48.052127
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta == {}
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.yields == None
    assert docstring.warnings == None
    assert docstring.attributes == None
    assert docstring.methods == None
    assert docstring.see_also == None
    assert docstring.notes == None
    assert docstring.references == None
    assert docstring.examples == None
    assert docstring.index == None
    assert docstring.deprecated == None
    assert docstring.todo == None
    assert doc

# Generated at 2022-06-17 18:18:55.133350
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'parameter a'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'parameter b'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'None'

# Generated at 2022-06-17 18:19:06.476849
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter"
    }
    assert docstring.returns == "a return value"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
        "returns": "float"
    }


# Generated at 2022-06-17 18:19:14.998811
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"

# Generated at 2022-06-17 18:19:21.931801
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["arg1"] == "the first argument"
    assert docstring.meta["param"]["arg2"] == "the second argument"
    assert docstring.meta["returns"] == "the return value"

# Generated at 2022-06-17 18:19:36.414738
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print 'hello' or 'goodbye'.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'The name to use.'
    assert docstring.params['name'].type == 'str.'
    assert docstring.params['state'].description == 'Whether to print ' \
                                                    "'hello' or 'goodbye'."

# Generated at 2022-06-17 18:19:47.418203
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param int a: first parameter
    :param int b: second parameter
    :returns: sum of a and b
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['a'].arg_type == 'int'
    assert docstring.meta['param']['a'].description == 'first parameter'
    assert docstring.meta['param']['b'].arg_type == 'int'
    assert docstring.meta['param']['b'].description == 'second parameter'
    assert docstring.meta['returns'].arg_type == ''

# Generated at 2022-06-17 18:19:54.461365
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Nothing.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['arg1'] == 'The first argument.'
    assert docstring.meta['param']['arg2'] == 'The second argument.'
    assert docstring.meta['return'] == 'Nothing.'

# Generated at 2022-06-17 18:20:00.522332
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param a: a
    :param b: b
    :returns: c
    '''
    assert parse(text).short_description == 'This is a function.'
    assert parse(text).long_description == ''
    assert parse(text).returns.type_name == 'c'
    assert parse(text).params['a'].type_name == 'a'
    assert parse(text).params['b'].type_name == 'b'

# Generated at 2022-06-17 18:20:06.063032
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a
    :type a: int
    :param b: b
    :type b: float
    :returns: a + b
    :rtype: float
    """
    assert parse(text).short_description == 'This is a test docstring.'
    assert parse(text).long_description == ''
    assert parse(text).params[0].name == 'a'
    assert parse(text).params[0].type == 'int'
    assert parse(text).params[0].description == 'a'
    assert parse(text).params[1].name == 'b'
    assert parse(text).params[1].type == 'float'
    assert parse(text).params[1].description == 'b'

# Generated at 2022-06-17 18:20:13.544525
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a description of what is returned'
    assert docstring.raises['keyError'] == 'raises an exception'

# Generated at 2022-06-17 18:20:22.511821
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:20:31.191484
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "a parameter"
    assert docstring.params['b'] == "another parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'something'}


# Generated at 2022-06-17 18:20:38.597022
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: description of return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['foo'].arg_name == 'foo'
    assert docstring.params['foo'].description == 'This is a parameter.'
    assert docstring.params['foo'].annotation == 'str'
    assert docstring.params['bar'].arg_name == 'bar'

# Generated at 2022-06-17 18:20:44.962339
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'a return value'
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:20:57.489649
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: Name of the person
    :param int age: Age of the person
    :returns: Person's name and age
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].description == "Name of the person"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[1].arg_name == "age"
    assert docstring.params[1].description == "Age of the person"
    assert docstring.params[1].type_name == "int"


# Generated at 2022-06-17 18:21:07.494111
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :returns: return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "parameter a",
        "b": "parameter b",
    }
    assert docstring.returns == "return value"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
        "returns": "float",
    }

# Generated at 2022-06-17 18:21:16.741613
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param test: test parameter
    :type test: str
    :returns: test return
    :rtype: str
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test docstring."
    assert parsed.long_description == ""
    assert parsed.meta["parameters"]["test"]["description"] == "test parameter"
    assert parsed.meta["parameters"]["test"]["type"] == "str"
    assert parsed.meta["returns"]["description"] == "test return"
    assert parsed.meta["returns"]["type"] == "str"


# Generated at 2022-06-17 18:21:27.237784
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: This is a test parameter
    :type a: int
    :returns: This is a test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "This is a test parameter"
    assert docstring.params[0].type_name == "int"
    assert docstring.returns.description == "This is a test return"
    assert docstring.returns.type_name == "str"

# Generated at 2022-06-17 18:21:39.289920
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['x'].description == 'x'
    assert docstring.params['x'].annotation == 'int'
    assert docstring.params['y'].description == 'y'
    assert docstring.params['y'].annotation == 'int'
    assert docstring.returns.description == 'x + y'

# Generated at 2022-06-17 18:21:47.233246
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["arg1"] == "the first argument"
    assert docstring.meta["arg2"] == "the second argument"
    assert docstring.meta["returns"] == "the return value"
    assert docstring.style == Style.numpy
    assert docstring.returns is None
    assert docstring.raises is None
    assert docstring.yields is None
    assert docstring.warns is None
    assert docstring.warns_is_error

# Generated at 2022-06-17 18:21:53.727055
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[0].type_name == "int"
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params

# Generated at 2022-06-17 18:22:04.856059
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."

# Generated at 2022-06-17 18:22:13.986479
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"

# Generated at 2022-06-17 18:22:23.570799
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether or not to say hello.
    :type state: bool.
    :returns: None.
    :raises ValueError: If `name` is empty.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params[0].arg_name == 'name'
    assert docstring.params[0].description == 'The name to use.'
    assert docstring.params[0].type_name == 'str.'
    assert docstring.params[1].arg_name == 'state'

# Generated at 2022-06-17 18:22:35.463030
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.meta == {}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:22:43.428207
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'name of the person'
    assert docstring.params['age'].description == 'age of the person'
    assert docstring.returns.description == 'a person'
    assert docstring.raises['ValueError'].description == 'if age is negative'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:22:49.730592
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("Hello") == Docstring(summary="Hello", description="", meta={})
    assert parse("Hello\nWorld") == Docstring(summary="Hello", description="World", meta={})
    assert parse("Hello\n\nWorld") == Docstring(summary="Hello", description="World", meta={})
    assert parse("Hello\n\nWorld\n\n") == Docstring(summary="Hello", description="World", meta={})
    assert parse("Hello\n\nWorld\n\n\n") == Docstring(summary="Hello", description="World", meta={})
    assert parse("Hello\n\nWorld\n\n\n\n") == Docstring(summary="Hello", description="World", meta={})

# Generated at 2022-06-17 18:22:53.764265
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:23:04.505696
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str a: This is a parameter.
    :param int b: This is another parameter.
    :returns: This is a return value.
    :raises ValueError: This is a raised exception.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'This is a parameter.'
    assert docstring.params['b'].description == 'This is another parameter.'
    assert docstring.returns.description == 'This is a return value.'
    assert docstring.raises['ValueError'].description == 'This is a raised exception.'


# Generated at 2022-06-17 18:23:14.681008
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    assert len(docstring.meta) == 4


# Generated at 2022-06-17 18:23:25.921413
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param x: x value
    :type x: int
    :param y: y value
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['x'].description == 'x value'
    assert docstring.params['x'].type_name == 'int'
    assert docstring.params['y'].description == 'y value'
    assert docstring.params['y'].type_name == 'int'
    assert docstring.returns.description == 'x + y'

# Generated at 2022-06-17 18:23:36.541466
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:23:47.009870
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: name of the person
    :type name: str
    :param age: age of the person
    :type age: int
    :returns: person's name and age
    :rtype: str
    '''
    docstring = parse(text, style=Style.numpy)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['name'].arg_type == 'str'
    assert docstring.params['name'].description == 'name of the person'
    assert docstring.params['age'].arg_type == 'int'

# Generated at 2022-06-17 18:23:53.971036
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
   

# Generated at 2022-06-17 18:24:06.366521
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].arg_type == 'int'
    assert docstring.returns.arg_type == 'str'


# Generated at 2022-06-17 18:24:14.698163
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == 'a return value'
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'a return value'}
    assert docstring.style == Style.google

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:24:17.483218
# Unit test for function parse
def test_parse():
    text = '''
    This is a summary
    '''
    doc = parse(text)
    assert doc.summary == 'This is a summary'

# Generated at 2022-06-17 18:24:27.154354
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.
    """
    assert parse(docstring).short_description == "This is a docstring."
    assert parse(docstring).long_description == ""
    assert parse(docstring).meta == {}
    assert parse(docstring).returns == None
    assert parse(docstring).raises == None
    assert parse(docstring).yields == None
    assert parse(docstring).warns == None
    assert parse(docstring).attributes == None
    assert parse(docstring).see_also == None
    assert parse(docstring).notes == None
    assert parse(docstring).references == None
    assert parse(docstring).examples == None
    assert parse(docstring).index == None
    assert parse(docstring).deprecated == None

# Generated at 2022-06-17 18:24:35.692236
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "param1": "this is a first param",
        "param2": "this is a second param",
    }
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises == {"keyError": "raises an exception"}

# Generated at 2022-06-17 18:24:43.496966
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    This is a function.

    :param name: The name to use.
    :type name: str.
    :param state: Current state to be in.
    :type state: bool.
    :returns: int -- the return code.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""

# Generated at 2022-06-17 18:24:54.885508
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: this is a foo
    :type foo: int
    :param bar: this is a bar
    :type bar: str
    :returns: this is a return
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'this is a foo'
    assert docstring.params['foo'].type_name == 'int'
    assert docstring.params['bar'].description == 'this is a bar'
    assert docstring.params['bar'].type_name == 'str'
    assert docstring.returns.description == 'this is a return'

# Generated at 2022-06-17 18:24:57.767926
# Unit test for function parse
def test_parse():
    text = """
    This is a function
    """
    assert parse(text) == Docstring(
        summary="This is a function",
        description="",
        returns=None,
        raises=None,
        meta={},
    )


# Generated at 2022-06-17 18:25:06.312058
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    text = """
    This is a docstring.

    :param a: a
    :param b: b
    :returns: c
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["a"].description == "a"
    assert docstring.meta["param"]["b"].description == "b"
    assert docstring.meta["return"]["returns"].description == "c"


# Generated at 2022-06-17 18:25:13.631904
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'None'
    assert docstring.raises['keyError'] == 'raises an exception'

# Generated at 2022-06-17 18:25:26.377995
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: This is a parameter
    :type a: int
    :returns: This is a return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "This is a parameter"
    assert docstring.params['a'].type == "int"
    assert docstring.returns.description == "This is a return"
    assert docstring.returns.type == "str"


# Generated at 2022-06-17 18:25:33.581632
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: a parameter
    :type foo: str
    :returns: a return value
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].arg_type == 'str'
    assert docstring.returns.arg_type == 'int'


# Generated at 2022-06-17 18:25:41.406596
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param foo: Foo
    :param bar: Bar
    :returns: Return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params["foo"] == "Foo"
    assert docstring.params["bar"] == "Bar"
    assert docstring.returns == "Return value"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:25:53.199621
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "None"
    assert docstring.meta == {}

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:26:02.589839
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'first parameter'
    assert docstring.params['b'] == 'second parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {}
    assert docstring.style == Style.numpy

    text = '''
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    :raises KeyError: when a key error
    '''
    doc

# Generated at 2022-06-17 18:26:09.297320
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["x"]["type"] == "int"
    assert docstring.meta["returns"]["type"] == "int"


# Generated at 2022-06-17 18:26:17.762093
# Unit test for function parse
def test_parse():
    docstring = """
    This is a function.

    :param str arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises ValueError: If something bad happens.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a function."
    assert doc.long_description == ""

# Generated at 2022-06-17 18:26:26.080484
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == 'This is a docstring.'
    assert parsed.long_description == ''
    assert parsed.params['arg1'] == 'The first argument.'
    assert parsed.params['arg2'] == 'The second argument.'
    assert parsed.returns == 'Description of return value.'
    assert parsed.raises['keyError'] == 'raises an exception'


# Generated at 2022-06-17 18:26:34.778653
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "", "", "", "")
    assert parse("Hello world") == Docstring("", "Hello world", "", "", "")
    assert parse("Hello world\n") == Docstring("", "Hello world", "", "", "")
    assert parse("Hello world\n\n") == Docstring("", "Hello world", "", "", "")
    assert parse("Hello world\n\n\n") == Docstring("", "Hello world", "", "", "")
    assert parse("Hello world\n\n\n\n") == Docstring("", "Hello world", "", "", "")
    assert parse("Hello world\n\n\n\n\n") == Docstring("", "Hello world", "", "", "")