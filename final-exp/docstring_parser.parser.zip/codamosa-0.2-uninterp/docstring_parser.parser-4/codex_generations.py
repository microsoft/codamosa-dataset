

# Generated at 2022-06-17 18:16:56.444731
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: first parameter
    :param b: second parameter
    :returns: return value
    """
    doc = parse(text)
    assert doc.short_description == "This is a function."
    assert doc.long_description == ""
    assert doc.params == [
        ("a", "first parameter"),
        ("b", "second parameter"),
    ]
    assert doc.returns == "return value"
    assert doc.meta == {}



# Generated at 2022-06-17 18:17:05.977223
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :returns: something
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["parameters"]["a"]["description"] == "parameter a"
    assert docstring.meta["parameters"]["a"]["type"] == "int"
    assert docstring.meta["parameters"]["b"]["description"] == "parameter b"
    assert docstring.meta["parameters"]["b"]["type"] == "str"

# Generated at 2022-06-17 18:17:13.692461
# Unit test for function parse
def test_parse():
    text = """
    This is a test function
    :param a: test parameter
    :returns: test return
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'test parameter'
    assert docstring.returns == 'test return'


# Generated at 2022-06-17 18:17:22.502434
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text, style=Style.numpy)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.returns.description == 'Description of return value.'
    assert docstring.raises[0].description == 'raises an exception'
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'
    assert docstring.params

# Generated at 2022-06-17 18:17:30.691681
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type_name == 'int'

# Generated at 2022-06-17 18:17:41.863780
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a formatted string
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "name",
            "type": "str",
            "description": "name of the person",
            "default": None,
        },
        {
            "name": "age",
            "type": "int",
            "description": "age of the person",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:17:54.202070
# Unit test for function parse
def test_parse():
    docstring = parse("""
    This is a docstring.
    """)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.style == Style.google

    docstring = parse("""
    This is a docstring.

    This is a long description.
    """)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == "This is a long description."
    assert docstring.meta == {}
    assert docstring.style == Style.google


# Generated at 2022-06-17 18:18:04.188024
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: why you get a key error
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a description of what is returned'
    assert docstring.raises['keyError'] == 'why you get a key error'

# Generated at 2022-06-17 18:18:10.688290
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.
    :param a: This is a test parameter.
    :type a: int
    :returns: This is a test return.
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'This is a test parameter.'
    assert docstring.params['a'].type == 'int'
    assert docstring.returns.description == 'This is a test return.'
    assert docstring.returns.type == 'str'

# Generated at 2022-06-17 18:18:21.153087
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is a foo
    :type foo: str
    :param bar: this is a bar
    :type bar: int
    :returns: this is a return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta["foo"][0].arg_name == "foo"
    assert docstring.meta["foo"][0].arg_type == "str"
    assert docstring.meta["foo"][0].description == "this is a foo"
    assert docstring.meta["bar"][0].arg_name == "bar"
    assert docstring.meta["bar"][0].arg_

# Generated at 2022-06-17 18:18:33.622372
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a dict of name and age
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "name of the person"
    assert docstring.params[1].arg_name == "age"
    assert docstring.params[1].type_name == "int"


# Generated at 2022-06-17 18:18:42.489957
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a formatted string
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params["name"].description == "name of the person"
    assert docstring.params["age"].description == "age of the person"
    assert docstring.returns.description == "a formatted string"
    assert docstring.raises["ValueError"].description == "if age is negative"

# Generated at 2022-06-17 18:18:51.191146
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:19:02.389720
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type_name == 'str'

# Generated at 2022-06-17 18:19:12.968728
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a
    :type a: int
    :param b: b
    :type b: str
    :returns: a + b
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "a",
            "type": "int",
            "description": "a",
            "annotation": "a",
        },
        {
            "name": "b",
            "type": "str",
            "description": "b",
            "annotation": "b",
        },
    ]

# Generated at 2022-06-17 18:19:15.829368
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:19:24.039972
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.returns[0].description == 'a return value'
    assert docstring.meta == {'a': 'a parameter', 'b': 'another parameter', 'returns': 'a return value'}

# Generated at 2022-06-17 18:19:32.801711
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.returns.description == 'a return value'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:19:38.419159
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: baz
    :rtype: float
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'foo'
    assert docstring.params['foo'].annotation == 'str'
    assert docstring.params['bar'].description == 'bar'
    assert docstring.params['bar'].annotation == 'int'
    assert docstring.returns.description == 'baz'
    assert docstring.returns.annotation == 'float'


# Generated at 2022-06-17 18:19:48.173479
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "The return value."
    assert docstring.returns.type_name == ""


# Generated at 2022-06-17 18:20:00.431192
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:20:11.514620
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: This is what is returned.
    :rtype: bool
    """

# Generated at 2022-06-17 18:20:20.129161
# Unit test for function parse
def test_parse():
    text = '''
    This is a test.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test.'
    assert docstring.long_description == ''
    assert docstring.meta == {}
    assert docstring.params == []
    assert docstring.returns == None
    assert docstring.raises == []
    assert docstring.examples == []
    assert docstring.see_also == []
    assert docstring.notes == []
    assert docstring.references == []
    assert docstring.attributes == []
    assert docstring.methods == []
    assert docstring.deprecated == None
    assert docstring.todo == []
    assert docstring.yields == None
    assert docstring.yields_desc == None
    assert docstring

# Generated at 2022-06-17 18:20:30.386332
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:20:39.810303
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: Raises an exception.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "The return value."
    assert docstring.meta == {"raises": {"keyError": "Raises an exception."}}
    assert docstring.style == Style.numpy

# Generated at 2022-06-17 18:20:41.877011
# Unit test for function parse
def test_parse():
    text = """
    This is a test
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test'


# Generated at 2022-06-17 18:20:54.976420
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"

# Generated at 2022-06-17 18:21:02.191503
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'

# Generated at 2022-06-17 18:21:12.295627
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a
    :type a: int
    :param b: b
    :type b: str
    :returns: c
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.params['b'].description == 'b'
    assert docstring.params['b'].annotation == 'str'
    assert docstring.returns.description == 'c'
    assert docstring.returns.annotation == 'float'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:21:24.588020
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param name: The name to use.
    :type name: str.
    :param state: Current state to be in.
    :type state: bool.
    :returns: int -- the return code.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'name'
    assert docstring.params[0].description == 'The name to use.'
    assert docstring.params[0].type_name == 'str.'
    assert docstring.params[1].arg_name == 'state'
    assert docstring

# Generated at 2022-06-17 18:21:39.801513
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a + b
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.returns.description == 'a + b'
    assert docstring.returns.type_annotation == 'int'
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_annotation == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type_

# Generated at 2022-06-17 18:21:47.625149
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: nothing
    :rtype: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].annotation == 'str'
    assert docstring.returns.description == 'nothing'
    assert docstring.returns.annotation == 'None'

# Generated at 2022-06-17 18:21:53.845736
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises Exception: An exception.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'The return value.'
    assert docstring.raises['Exception'] == 'An exception.'
    assert docstring.meta == {}

# Generated at 2022-06-17 18:22:04.968811
# Unit test for function parse
def test_parse():
    text = """
    This is a test
    """

# Generated at 2022-06-17 18:22:14.075682
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    assert parse(text) == Docstring(
        summary="This is a test docstring.",
        description="",
        returns=None,
        raises=None,
        meta={},
    )

    text = """
    This is a test docstring.

    :param name: name
    :type name: str
    :returns: None
    :rtype: None
    """
    assert parse(text) == Docstring(
        summary="This is a test docstring.",
        description="",
        returns=None,
        raises=None,
        meta={
            "name": {
                "type": "str",
                "description": "name",
                "default": None,
            }
        },
    )


# Generated at 2022-06-17 18:22:21.441288
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {}



# Generated at 2022-06-17 18:22:32.173190
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "The return value."

# Generated at 2022-06-17 18:22:43.952266
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    from docstring_parser.parser import parse
    text = '''
    This is a function.

    :param a: a
    :type a: int
    :param b: b
    :type b: str
    :returns: a + b
    :rtype: int
    '''
    assert parse(text) == Docstring(
        content='This is a function.',
        returns=('a + b', 'int'),
        params=[('a', 'int'), ('b', 'str')],
        meta={},
    )

# Generated at 2022-06-17 18:22:53.805921
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    doc = parse(text)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params == [
        ("a", "first parameter"),
        ("b", "second parameter"),
    ]
    assert doc.returns == "something"
    assert doc.meta == {}

# Generated at 2022-06-17 18:23:04.897176
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    This is a test docstring.

    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: The return value.
    :raises keyError: The exception type to be raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "param1": "The first parameter.",
        "param2": "The second parameter."
    }
    assert docstring.returns == "The return value."
    assert docstring.raises == {"keyError": "The exception type to be raised."}

# Generated at 2022-06-17 18:23:17.291199
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"

# Generated at 2022-06-17 18:23:25.112329
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :param b: parameter b
    :return: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "parameter a"
    assert docstring.params['b'] == "parameter b"
    assert docstring.returns == "return value"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:23:36.437725
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument.")
    ]
    assert docstring.returns == "Description of return value."
    assert docstring.raises == [("keyError", "raises an exception")]
    assert docstring.meta == {}


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:23:44.820975
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    d = parse(text)
    assert d.short_description == "This is a test docstring."
    assert d.long_description == ""
    assert d.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert d.returns == "None"
    assert d.returns_description == ""
    assert d.meta == {}

# Generated at 2022-06-17 18:23:54.498462
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    docstring = """
    This is a test docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    doc = parse(docstring)
    assert isinstance(doc, Docstring)
    assert isinstance(doc, GoogleStyle)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].arg_type == "str"
    assert doc.meta[0].description == "The first argument."
    assert doc.meta

# Generated at 2022-06-17 18:23:58.076947
# Unit test for function parse
def test_parse():
    text = """
    This is a test for function parse.
    """
    assert parse(text) == Docstring(summary='This is a test for function parse.', description='', meta={})


# Generated at 2022-06-17 18:24:03.590890
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param x: x
    :param y: y
    :returns: x + y
    """
    assert parse(text) == Docstring(
        content='This is a test docstring.',
        params=[('x', 'x'), ('y', 'y')],
        returns='x + y',
        meta={},
    )


# Generated at 2022-06-17 18:24:13.443026
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises['keyError'] == "raises an exception"

# Generated at 2022-06-17 18:24:23.379250
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param int a: first parameter
    :param int b: second parameter
    :returns: sum of a and b
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "first parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "int"
    assert docstring.params[1].description == "second parameter"

# Generated at 2022-06-17 18:24:30.246727
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "a parameter"
    assert docstring.params['b'] == "another parameter"
    assert docstring.returns == "the return value"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:24:40.095360
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("Hello world") == Docstring(summary="Hello world", description="", meta={})
    assert parse("Hello world\n\nThis is a description") == Docstring(summary="Hello world", description="This is a description", meta={})
    assert parse("Hello world\n\nThis is a description\n\n:param x: this is a parameter") == Docstring(summary="Hello world", description="This is a description", meta={"param": [{"name": "x", "type": None, "desc": "this is a parameter"}]})

# Generated at 2022-06-17 18:24:43.244695
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."

# Generated at 2022-06-17 18:24:52.383495
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    assert parse(text) == Docstring(
        summary="This is a test docstring.",
        description="",
        returns=Docstring.Returns(
            description="x + y",
            type="int",
        ),
        params=[
            Docstring.Param(
                name="x",
                description="x",
                type="int",
            ),
            Docstring.Param(
                name="y",
                description="y",
                type="int",
            ),
        ],
        meta={},
    )

# Generated at 2022-06-17 18:25:03.823060
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param str arg1: The first argument.
    :param int arg2: The second argument.
    :returns: The return value.
    :raises ValueError: If something goes wrong.
    """
    doc = parse(docstring)
    assert doc.short_description == 'This is a test docstring.'
    assert doc.long_description == ''
    assert doc.params[0].arg_name == 'arg1'
    assert doc.params[0].type_name == 'str'
    assert doc.params[0].description == 'The first argument.'
    assert doc.params[1].arg_name == 'arg2'
    assert doc.params[1].type_name == 'int'
    assert doc.params[1].description == 'The second argument.'


# Generated at 2022-06-17 18:25:14.305473
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a test function.'
    assert doc.long_description == ''
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == 'a'
    assert doc.params[0].description == 'a parameter'
    assert doc.params[1].arg_name == 'b'
    assert doc.params[1].description == 'another parameter'
    assert len(doc.returns) == 1
    assert doc.returns[0].description == 'a return value'
    assert doc.raises == []
    assert doc.warns == []

# Generated at 2022-06-17 18:25:24.082692
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str a: This is a test parameter.
    :param str b: This is another test parameter.
    :returns: This is the return value.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "This is a test parameter."
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "This is another test parameter."
    assert docstring.returns.description == "This is the return value."

# Generated at 2022-06-17 18:25:33.548641
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'None'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:25:39.771255
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x
    :param y: y
    :returns: x + y
    """
    assert parse(text).summary == "This is a test docstring."
    assert parse(text).params["x"].description == "x"
    assert parse(text).params["y"].description == "y"
    assert parse(text).returns.description == "x + y"

# Generated at 2022-06-17 18:25:49.038012
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'a return value'
    assert docstring.meta == {'param': ['a', 'b'], 'returns': None}
    assert docstring.style == 'google'
    assert docstring.summary == 'This is a test docstring.'
    assert docstring.extended_summary == ''


# Generated at 2022-06-17 18:25:58.649522
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['x'].description == 'x'
    assert docstring.params['x'].type_name == 'int'
    assert docstring.params['y'].description == 'y'
    assert docstring.params['y'].type_name == 'int'
    assert docstring.returns.description == 'x + y'

# Generated at 2022-06-17 18:26:11.810508
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: name of the person
    :type name: str
    :param age: age of the person
    :type age: int
    :returns: person's name and age
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'name of the person'
    assert docstring.params['name'].type_name == 'str'
    assert docstring.params['age'].description == 'age of the person'
    assert docstring.params['age'].type_name == 'int'

# Generated at 2022-06-17 18:26:22.402672
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'a return value'
    assert docstring.meta == {}
    assert docstring.raises == {}
    assert docstring.warnings == {}
    assert docstring.attributes == {}
    assert docstring.see_also == {}
    assert docstring.notes == {}
    assert docstring.references == {}
    assert docstring.ex

# Generated at 2022-06-17 18:26:29.461893
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param int a: this is a
    :param str b: this is b
    :returns: this is a return
    :raises ValueError: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.returns.type_name == "this is a return"
    assert docstring.raises[0].type_name == "ValueError"
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "this is a"
    assert docstring.params[1].arg_name == "b"


# Generated at 2022-06-17 18:26:36.529051
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "Description of return value."
    assert docstring.params["arg1"].description == "The first argument."
    assert docstring.params["arg2"].description == "The second argument."
    assert docstring.raises["keyError"].description == "raises an exception"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:26:44.585519
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'something'}

# Generated at 2022-06-17 18:26:48.302556
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
