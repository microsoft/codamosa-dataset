

# Generated at 2022-06-17 18:16:41.000838
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: baz
    :rtype: float
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'foo': {'type': 'str', 'description': 'foo'},
                                'bar': {'type': 'int', 'description': 'bar'}}
    assert docstring.returns == {'type': 'float', 'description': 'baz'}

# Generated at 2022-06-17 18:16:46.277635
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'


# Generated at 2022-06-17 18:16:54.268071
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x value
    :param y: y value
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['x'] == 'x value'
    assert docstring.params['y'] == 'y value'
    assert docstring.returns == 'x + y'
    assert docstring.meta == {'param x': 'x value', 'param y': 'y value', 'returns': 'x + y'}
    assert docstring.style == Style.numpy

# Generated at 2022-06-17 18:17:02.064963
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str arg1: The first argument.
    :param int arg2: The second argument.
    :returns: The return value.
    :raises ValueError: If something goes wrong.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].type_name == "int"
    assert docstring.params[1].description

# Generated at 2022-06-17 18:17:08.276086
# Unit test for function parse
def test_parse():
    text = '''
    This is a function for testing.

    :param a: the first parameter
    :param b: the second parameter
    :returns: the result
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a function for testing.'
    assert doc.long_description == ''
    assert doc.params['a'] == 'the first parameter'
    assert doc.params['b'] == 'the second parameter'
    assert doc.returns == 'the result'
    assert doc.meta == {}

# Generated at 2022-06-17 18:17:17.924455
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta["a"].arg_type == "int"
    assert docstring.meta["a"].description == "a parameter"
    assert docstring.returns.arg_type == "str"
    assert docstring.returns.description == "a return value"

# Generated at 2022-06-17 18:17:27.880980
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "a parameter", "b": "another parameter"}
    assert docstring.returns == "a return value"
    assert docstring.meta == {"param a": "a parameter", "param b": "another parameter", "returns": "a return value"}
    assert docstring.style == Style.numpy
    assert docstring.raw == text


# Generated at 2022-06-17 18:17:39.572241
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str a: This is a test parameter.
    :param int b: This is another test parameter.
    :returns: This is a test return.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "This is a test parameter."
    assert docstring.params[0].annotation == "str"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "This is another test parameter."
    assert docstring.params[1].annotation == "int"
    assert docstring

# Generated at 2022-06-17 18:17:47.524759
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a + b
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'a + b'

# Generated at 2022-06-17 18:17:59.209739
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring"
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.style == Style.google
    assert docstring.params == []
    assert docstring.returns == []
    assert docstring.raises == []
    assert docstring.yields == []
    assert docstring.warns == []
    assert docstring.warnings == []
    assert docstring.see_also == []
    assert docstring.notes == []
    assert docstring.references == []
    assert docstring.examples == []
    assert docstring.attributes == []
    assert docstring.methods == []

# Generated at 2022-06-17 18:18:10.160812
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'

# Generated at 2022-06-17 18:18:20.696300
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"
    assert docstring.meta == {}
    assert docstring.style == Style.numpy

# Generated at 2022-06-17 18:18:27.807906
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == 'a string'
    assert docstring.meta == {'a': 'int', 'b': 'str', 'returns': 'str'}

# Generated at 2022-06-17 18:18:36.339976
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == [('x', 'x', 'int'), ('y', 'y', 'int')]
    assert docstring.returns == ('x + y', 'int')
    assert docstring.meta == {'param': [('x', 'x', 'int'), ('y', 'y', 'int')], 'returns': ('x + y', 'int')}
    assert docstring.style == Style.n

# Generated at 2022-06-17 18:18:45.683733
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: the result
    :rtype: float
    '''
    d = parse(text)
    assert d.short_description == 'This is a test function.'
    assert d.long_description == ''
    assert d.params == [
        ('a', 'a parameter', 'int'),
        ('b', 'another parameter', 'str')
    ]
    assert d.returns == ('the result', 'float')

# Generated at 2022-06-17 18:18:53.754827
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x value
    :type x: int
    :param y: y value
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['x'].description == 'x value'
    assert docstring.params['x'].type_name == 'int'
    assert docstring.params['y'].description == 'y value'
    assert docstring.params['y'].type_name == 'int'
    assert docstring.returns.description == 'x + y'

# Generated at 2022-06-17 18:19:04.645638
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a + b
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['a']['type'] == 'int'
    assert docstring.meta['param']['b']['type'] == 'str'
    assert docstring.meta['returns']['type'] == 'int'


# Generated at 2022-06-17 18:19:14.376323
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "None"
    assert docstring.rtype == ""
    assert docstring.meta == {"raises": "keyError: raises an exception"}

# Generated at 2022-06-17 18:19:23.151278
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a string
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'name'
    assert docstring.params[0].type_name == 'str'
    assert docstring.params[0].description == 'name of the person'
    assert docstring.params[1].arg_name == 'age'
    assert docstring.params[1].type_name == 'int'

# Generated at 2022-06-17 18:19:34.359060
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "The return value."

# Generated at 2022-06-17 18:19:48.282510
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: float
    :returns: a + b
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"
    assert docstring.params

# Generated at 2022-06-17 18:19:57.692017
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :return: x + y
    :rtype: int
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a function.'
    assert doc.long_description == ''
    assert doc.meta['param']['x']['type'] == 'int'
    assert doc.meta['param']['y']['type'] == 'int'
    assert doc.meta['return']['type'] == 'int'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:20:09.239423
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "something"
    assert docstring.meta == {
        "param a": "a parameter",
        "param b": "another parameter",
        "returns": "something",
    }

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:20:19.264641
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises Exception: Because I said so.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    assert len(docstring.meta) == 4
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'The first argument.'

# Generated at 2022-06-17 18:20:26.646122
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: This is a test parameter.
    :type a: int
    :returns: This is a test return.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].name == "a"
    assert docstring.params[0].description == "This is a test parameter."
    assert docstring.params[0].type == "int"
    assert docstring.returns.description == "This is a test return."
    assert docstring.returns.type == "str"

# Generated at 2022-06-17 18:20:37.609652
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].annotation == 'str'
    assert docstring.returns.description == 'something'
    assert docstring.returns.annotation == 'float'

# Generated at 2022-06-17 18:20:44.543054
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: parameter a
    :param b: parameter b
    :returns: return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['a'] == 'parameter a'
    assert docstring.meta['param']['b'] == 'parameter b'
    assert docstring.meta['returns'] == 'return value'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:20:53.413396
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "The return value."

# Generated at 2022-06-17 18:21:05.482542
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == 'This is a test function.'
    assert parsed.long_description == ''
    assert parsed.params == {'arg1': 'The first argument.', 'arg2': 'The second argument.'}
    assert parsed.returns == 'Description of return value.'
    assert parsed.raises == {'keyError': 'raises an exception'}

# Generated at 2022-06-17 18:21:14.495054
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    doc = parse(text)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == ""
    assert doc.params == {
        "a": "a parameter",
        "b": "another parameter"
    }
    assert doc.returns == "a string"
    assert doc.meta == {
        "a": "int",
        "b": "str",
        "returns": "str"
    }

# Generated at 2022-06-17 18:21:27.673113
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["arg1"] == "The first argument."
    assert docstring.meta["param"]["arg2"] == "The second argument."
    assert docstring.meta["returns"] == "None"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:21:36.313893
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param int a: this is a test parameter
    :param str b: this is another test parameter
    :return: this is a test return
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["a"].description == "this is a test parameter"
    assert docstring.params["b"].description == "this is another test parameter"
    assert docstring.returns.description == "this is a test return"

# Generated at 2022-06-17 18:21:44.685449
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether or not to say hello.
    :type state: bool.
    :returns: None.
    :raises ValueError: If `name` is empty.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test docstring."
    assert parsed.long_description == ""

# Generated at 2022-06-17 18:21:53.888256
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: a+b
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "first parameter"
    assert docstring.params['b'].description == "second parameter"
    assert docstring.returns.description == "a+b"


# Generated at 2022-06-17 18:22:04.109747
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'first parameter'
    assert docstring.params['b'] == 'second parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {}
    assert docstring.style == Style.numpy
    assert docstring.errors == []

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:22:13.650073
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.yields == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring

# Generated at 2022-06-17 18:22:20.761939
# Unit test for function parse
def test_parse():
    text = """
    This is a test function
    :param arg1: the first argument
    :param arg2: the second argument
    :returns: a value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function"
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "the first argument"
    assert docstring.params['arg2'] == "the second argument"
    assert docstring.returns == "a value"

# Generated at 2022-06-17 18:22:26.758976
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.
    :param x: the x parameter
    :param y: the y parameter
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == {
        "x": "the x parameter",
        "y": "the y parameter"
    }
    assert docstring.returns == "the return value"
    assert docstring.meta == {
        "param": {
            "x": "the x parameter",
            "y": "the y parameter"
        },
        "returns": "the return value"
    }
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:22:35.322294
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a description of what is returned'
    assert docstring.raises['keyError'] == 'raises an exception'

# Generated at 2022-06-17 18:22:43.426738
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: this is a foo
    :param bar: this is a bar
    :returns: this is a return
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 3
    assert docstring.params[0].arg_name == "foo"
    assert docstring.params[0].description == "this is a foo"
    assert docstring.params[1].arg_name == "bar"

# Generated at 2022-06-17 18:22:57.789456
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a return'
    assert docstring.raises['keyError'] == 'raises an exception'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:23:06.998494
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type == 'int'
    assert docstring.meta == {'a': 'int'}
    assert docstring.raises == {}


# Generated at 2022-06-17 18:23:15.576561
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "a parameter"
    assert docstring.params['a'].type == "int"
    assert docstring.returns.description == "a return value"
    assert docstring.returns.type == "str"

# Generated at 2022-06-17 18:23:25.783256
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {"x": {"type": "int", "desc": "x"}}
    assert docstring.returns == {"type": "int", "desc": "x"}
    assert docstring.meta == {"param x": {"type": "int", "desc": "x"}, "returns": {"type": "int", "desc": "x"}}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:23:35.960134
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test: test parameter
    :type test: str
    :returns: test return value
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "test"
    assert docstring.params[0].description == "test parameter"
    assert docstring.params[0].type_name == "str"
    assert docstring.returns.description == "test return value"
    assert docstring.returns.type_name == "int"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:23:47.626949
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: a parameter
    :type foo: str
    :param bar: another parameter
    :type bar: int
    :returns: a return value
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params[0].arg_name == 'foo'
    assert docstring.params[0].type_name == 'str'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[1].arg_name == 'bar'
    assert docstring.params[1].type_name == 'int'

# Generated at 2022-06-17 18:23:52.940098
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'first parameter'
    assert docstring.params['b'] == 'second parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:24:03.928926
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a return value
    :rtype: float
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type == 'str'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type == 'float'


# Generated at 2022-06-17 18:24:13.421495
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a return value
    :rtype: float
    '''
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        meta={
            'param': [
                {'name': 'a', 'type': 'int', 'description': 'a parameter'},
                {'name': 'b', 'type': 'str', 'description': 'another parameter'}
            ],
            'returns': {'type': 'float', 'description': 'a return value'}
        }
    )

# Generated at 2022-06-17 18:24:23.379072
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: x value
    :type x: int
    :param y: y value
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "x value"
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].type_name == "int"
    assert docstring

# Generated at 2022-06-17 18:24:35.658703
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert docstring.returns == "The return value."
    assert docstring.raises == [("keyError", "The exception type raised.")]
    assert docstring.meta == {}
    assert docstring.style == Style.numpy
    assert docstring.to_

# Generated at 2022-06-17 18:24:43.474427
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("Hello") == Docstring(summary="Hello", description="", meta={})
    assert parse("Hello\nWorld") == Docstring(summary="Hello", description="World", meta={})
    assert parse("Hello\nWorld\n\n") == Docstring(summary="Hello", description="World", meta={})
    assert parse("Hello\nWorld\n\n\n") == Docstring(summary="Hello", description="World", meta={})
    assert parse("Hello\nWorld\n\n\n\n") == Docstring(summary="Hello", description="World", meta={})
    assert parse("Hello\nWorld\n\n\n\n\n") == Docstring(summary="Hello", description="World", meta={})

# Generated at 2022-06-17 18:24:52.582826
# Unit test for function parse
def test_parse():
    text = """
    Summary line.

    Extended description.

    :param arg1: Description of arg1
    :param arg2: Description of arg2
    :returns: Description of return value
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."
    assert docstring.return_type == "Description of return value"
    assert docstring.raises == [("keyError", "raises an exception")]
    assert docstring.params == [
        ("arg1", "Description of arg1"),
        ("arg2", "Description of arg2"),
    ]

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:24:55.943336
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is foo
    :param bar: this is bar
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params['foo'] == "this is foo"
    assert docstring.params['bar'] == "this is bar"
    assert docstring.returns == ""
    assert docstring.raises == {}
    assert docstring.meta == {}



# Generated at 2022-06-17 18:25:04.170034
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type == 'int'

# Generated at 2022-06-17 18:25:10.548724
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: return value
    :rtype: float
    """

    doc = parse(text)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == ""
    assert doc.meta["a"] == "a parameter"
    assert doc.meta["b"] == "another parameter"
    assert doc.meta["returns"] == "return value"
    assert doc.meta["rtype"] == "float"

# Generated at 2022-06-17 18:25:18.080533
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: foo
    :param bar: bar
    :returns: baz
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['foo'] == "foo"
    assert docstring.params['bar'] == "bar"
    assert docstring.returns == "baz"
    assert docstring.meta == {'param': {'foo': 'foo', 'bar': 'bar'}, 'returns': 'baz'}

# Generated at 2022-06-17 18:25:27.157473
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: None
    :raises ValueError: If `foo` is equal to `bar`.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params['foo'].arg_type == 'param'
    assert docstring.params['foo'].name == 'foo'
    assert docstring.params['foo'].description == 'This is a parameter.'
    assert docstring.params['foo'].type_name == 'str'


# Generated at 2022-06-17 18:25:35.036206
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.style == Style.numpy
    assert docstring.params == []
    assert docstring.returns == []
    assert docstring.raises == []
    assert docstring.yields == []
    assert docstring.other == []

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:25:42.951554
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test: test parameter
    :returns: test return
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["test"].arg_name == "test"
    assert docstring.meta["param"]["test"].description == "test parameter"
    assert docstring.meta["return"]["returns"].arg_name == "returns"
    assert docstring.meta["return"]["returns"].description == "test return"


# Generated at 2022-06-17 18:25:56.446879
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    assert parse(docstring) == Docstring(
        summary="This is a test docstring.",
        description="",
        meta={
            "param": [
                {"name": "a", "type": "int", "description": "a parameter"},
                {"name": "b", "type": "str", "description": "another parameter"},
            ],
            "returns": {"type": "float", "description": "something"},
        },
    )


# Generated at 2022-06-17 18:26:07.320943
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: Name of the person
    :param int age: Age of the person
    :returns: Person's name and age
    :raises ValueError: If age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "name",
            "type": "str",
            "description": "Name of the person",
            "default": None,
        },
        {
            "name": "age",
            "type": "int",
            "description": "Age of the person",
            "default": None,
        },
    ]
    assert docstring.returns

# Generated at 2022-06-17 18:26:16.677666
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    """
    assert parse(docstring).short_description == "This is a test docstring."
    assert parse(docstring).long_description == ""
    assert parse(docstring).meta == {}
    assert parse(docstring).returns == None
    assert parse(docstring).raises == None
    assert parse(docstring).yields == None
    assert parse(docstring).warns == None
    assert parse(docstring).see_also == None
    assert parse(docstring).notes == None
    assert parse(docstring).references == None
    assert parse(docstring).examples == None
    assert parse(docstring).attributes == None
    assert parse(docstring).methods == None
    assert parse(docstring).class_variables == None

# Generated at 2022-06-17 18:26:26.713181
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "Description of return value."
    assert docstring.raises.description == "raises an exception"
    assert docstring.params["arg1"].description == "The first argument."
    assert docstring.params["arg2"].description == "The second argument."
    assert docstring.params["arg1"].annotation == ""