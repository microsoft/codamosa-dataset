

# Generated at 2022-06-17 18:16:46.114525
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    from docstring_parser.common import Docstring
    text = """
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring, GoogleStyle)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 0

# Generated at 2022-06-17 18:16:55.928300
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"
    assert docstring.params[1].description == "another parameter"


# Generated at 2022-06-17 18:17:05.810390
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: float
    :returns: a + b
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""

# Generated at 2022-06-17 18:17:18.729959
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x value
    :type x: int
    :param y: y value
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 4
    assert docstring.params[0].arg_name == 'x'
    assert docstring.params[0].type_name == 'int'

# Generated at 2022-06-17 18:17:28.383465
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params == [('x', 'x', 'int')]
    assert docstring.returns == ('x', 'int')
    assert docstring.meta == {'param x': 'x', 'type x': 'int',
                              'returns': 'x', 'rtype': 'int'}


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:17:40.152482
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: person's name and age
    :rtype: str
    """
    assert parse(text).short_description == 'This is a test function.'
    assert parse(text).long_description == ''
    assert parse(text).params[0].arg_name == 'name'
    assert parse(text).params[0].type_name == 'str'
    assert parse(text).params[0].description == 'name of the person'
    assert parse(text).params[1].arg_name == 'age'
    assert parse(text).params[1].type_name == 'int'
    assert parse(text).params[1].description == 'age of the person'
    assert parse

# Generated at 2022-06-17 18:17:49.692603
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        meta={'param': [('a', 'a parameter'), ('b', 'another parameter')],
              'returns': 'a return value'})


# Generated at 2022-06-17 18:17:54.161349
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:18:02.541401
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: A test parameter.
    :type foo: str
    :returns: A test return value.
    :rtype: int
    """
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        meta={
            'param': [
                {
                    'name': 'foo',
                    'type': 'str',
                    'description': 'A test parameter.'
                }
            ],
            'return': {
                'type': 'int',
                'description': 'A test return value.'
            }
        }
    )

# Generated at 2022-06-17 18:18:10.631938
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'param1': 'this is a first param',
                                'param2': 'this is a second param'}
    assert docstring.returns == 'this is a return'
    assert docstring.raises == {'keyError': 'raises an exception'}

# Generated at 2022-06-17 18:18:22.175042
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a test docstring.

    :param str a: This is a test parameter.
    :param str b: This is another test parameter.
    :returns: This is a test return value.
    '''
    assert parse(docstring) == Docstring(
        content='This is a test docstring.',
        meta={
            'parameters': [
                {'name': 'a', 'type': 'str', 'description': 'This is a test parameter.'},
                {'name': 'b', 'type': 'str', 'description': 'This is another test parameter.'}
            ],
            'returns': {'type': '', 'description': 'This is a test return value.'}
        }
    )

# Generated at 2022-06-17 18:18:29.877704
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: nothing
    :rtype: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'nothing'

# Generated at 2022-06-17 18:18:40.542564
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    :raises Exception: when something bad happens
    """
    d = parse(text)
    assert d.short_description == "This is a docstring."
    assert d.long_description == ""
    assert len(d.params) == 2
    assert len(d.returns) == 1
    assert len(d.raises) == 1
    assert d.params[0].arg_name == "a"
    assert d.params[0].description == "first parameter"
    assert d.params[1].arg_name == "b"
    assert d.params[1].description == "second parameter"
    assert d.returns[0].description == "something"
    assert d

# Generated at 2022-06-17 18:18:53.807547
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: this is a test parameter
    :type a: int
    :returns: this is a test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "this is a test parameter"
    assert docstring.params[0].type_name == "int"
    assert docstring.returns.description == "this is a test return"
    assert docstring.returns.type_name == "str"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:19:05.852388
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:19:15.793509
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: returns
    :rtype: int
    """
    assert parse(docstring) == Docstring(
        summary='This is a test docstring.',
        description='',
        meta={
            'param': [
                {
                    'name': 'foo',
                    'type': 'str',
                    'description': 'foo',
                },
                {
                    'name': 'bar',
                    'type': 'int',
                    'description': 'bar',
                },
            ],
            'returns': {
                'type': 'int',
                'description': 'returns',
            },
        },
    )

# Generated at 2022-06-17 18:19:24.012287
# Unit test for function parse
def test_parse():
    text = """
        This is a docstring.

        :param param1: this is a first param
        :param param2: this is a second param
        :returns: this is a return
        :raises keyError: raises an exception
        """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a return'
    assert docstring.raises['keyError'] == 'raises an exception'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:19:27.524987
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:19:31.221024
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        returns=None,
        raises=None,
        meta={},
    )

# Generated at 2022-06-17 18:19:36.516021
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "a return value"
    assert docstring.return_type == "float"

# Generated at 2022-06-17 18:19:50.538853
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    d = parse(text)
    assert d.short_description == 'This is a function.'
    assert d.long_description == ''
    assert d.params == [('a', 'a parameter', 'int')]
    assert d.returns == ('a return value', 'str')
    assert d.meta == {}


# Generated at 2022-06-17 18:20:00.004035
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a
    :type a: int
    :param b: b
    :type b: str
    :returns: a + b
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["parameters"]["a"]["description"] == "a"
    assert docstring.meta["parameters"]["a"]["type"] == "int"
    assert docstring.meta["parameters"]["b"]["description"] == "b"
    assert docstring.meta["parameters"]["b"]["type"] == "str"

# Generated at 2022-06-17 18:20:11.228857
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: baz
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "foo"
    assert docstring.params[0].description == "foo"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[1].arg_name == "bar"
    assert docstring.params[1].description == "bar"
    assert docstring.params[1].type_name == "int"
    assert doc

# Generated at 2022-06-17 18:20:13.817132
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."


# Generated at 2022-06-17 18:20:23.421218
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring.
    '''
    result = parse(docstring)
    assert result.short_description == 'This is a docstring.'
    assert result.long_description == ''
    assert result.meta == {}
    assert result.style == Style.numpy
    assert result.returns == None
    assert result.raises == None
    assert result.yields == None
    assert result.warns == None
    assert result.warns == None
    assert result.warns == None
    assert result.warns == None
    assert result.warns == None
    assert result.warns == None
    assert result.warns == None
    assert result.warns == None
    assert result.warns == None
    assert result.warns == None
    assert result.warns == None

# Generated at 2022-06-17 18:20:32.983813
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a function.'
    assert doc.long_description == ''
    assert doc.returns.description == 'x + y'
    assert doc.returns.type_name == 'int'
    assert doc.params['x'].description == 'x'
    assert doc.params['x'].type_name == 'int'
    assert doc.params['y'].description == 'y'
    assert doc.params['y'].type_name == 'int'

# Generated at 2022-06-17 18:20:42.130449
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[0].type_name == "int"
    assert docstring.params[1].arg_name == "arg2"
    assert docstring

# Generated at 2022-06-17 18:20:55.096029
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a is a parameter.
    :type a: int
    :param b: b is a parameter.
    :type b: str
    :returns: a+b
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a is a parameter.'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'b is a parameter.'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'a+b'
    assert docstring

# Generated at 2022-06-17 18:20:57.921508
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'


# Generated at 2022-06-17 18:21:07.730137
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    doc = parse(text)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == ""
    assert doc.params == [
        {"name": "x", "type": "int", "description": "x"},
        {"name": "y", "type": "int", "description": "y"},
    ]
    assert doc.returns == {"type": "int", "description": "x + y"}
    assert doc.meta == {}


# Generated at 2022-06-17 18:21:20.258530
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises Exception: An exception.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'arg1': 'The first argument.',
                                'arg2': 'The second argument.'}
    assert docstring.returns == 'The return value.'
    assert docstring.raises == {'Exception': 'An exception.'}

# Generated at 2022-06-17 18:21:29.986275
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :type arg1: int, optional
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int

    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta["arg1"]["type"] == "int, optional"
    assert docstring.meta["arg1"]["description"] == "The first argument."
    assert docstring.meta["arg2"]["type"] == "str, optional"
    assert docstring.meta["arg2"]["description"] == "The second argument."

# Generated at 2022-06-17 18:21:41.083682
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['x'].description == 'x'
    assert docstring.params['x'].annotation == 'int'
    assert docstring.params['y'].description == 'y'
    assert docstring.params['y'].annotation == 'int'
    assert docstring.returns.description == 'x + y'
    assert docstring.returns.annotation == 'int'

# Generated at 2022-06-17 18:21:54.584139
# Unit test for function parse
def test_parse():
    text = """
    This is a module docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a module docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'x': 'x', 'y': 'y'}
    assert docstring.returns == 'x + y'
    assert docstring.meta == {'x': 'int', 'y': 'int', 'returns': 'int'}
    assert docstring.errors == []
    assert docstring.warnings == []

if __name__ == '__main__':
    test_parse

# Generated at 2022-06-17 18:22:05.395238
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test docstring."
    assert parsed.long_description == ""
    assert parsed.params == {'arg1': 'The first argument.', 'arg2': 'The second argument.'}
    assert parsed.returns == "Description of return value."
    assert parsed.raises == {'keyError': 'raises an exception'}

# Generated at 2022-06-17 18:22:14.258323
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 3
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'
    assert docstring.params

# Generated at 2022-06-17 18:22:23.725173
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises Exception: Because I said so.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'

# Generated at 2022-06-17 18:22:33.299092
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: first parameter
    :param b: second parameter
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "first parameter", "b": "second parameter"}
    assert docstring.returns == "return value"
    assert docstring.meta == {"param": {"a": "first parameter", "b": "second parameter"}, "returns": "return value"}

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:22:41.745920
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['x'] == 'x'
    assert docstring.params['y'] == 'y'
    assert docstring.returns == 'x + y'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:22:55.242842
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    from docstring_parser.common import Docstring
    docstring = Docstring()
    docstring.short_description = "This is a short description"
    docstring.long_description = "This is a long description"
    docstring.meta = {'param': [{'name': 'param1', 'type': 'int', 'description': 'This is a param'}], 'return': [{'type': 'int', 'description': 'This is a return'}]}
    assert parse("This is a short description\n\nThis is a long description\n\nArgs:\n    param1 (int): This is a param\n\nReturns:\n    int: This is a return", style=GoogleStyle) == docstring


# Generated at 2022-06-17 18:23:07.617460
# Unit test for function parse
def test_parse():
    text = '''
    :param name: The name to use.
    :param state: Whether to activate the account.
    :returns: User account object.
    :raises ValueError: If the name is too short.
    '''
    doc = parse(text)
    assert doc.short_description == ''
    assert doc.long_description == ''
    assert doc.returns.description == 'User account object.'
    assert doc.params['name'].description == 'The name to use.'
    assert doc.params['state'].description == 'Whether to activate the account.'
    assert doc.raises['ValueError'].description == 'If the name is too short.'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:23:18.224005
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: a foo
    :type foo: str
    :param bar: a bar
    :type bar: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'a foo'
    assert docstring.params['foo'].type_name == 'str'
    assert docstring.params['bar'].description == 'a bar'
    assert docstring.params['bar'].type_name == 'int'
    assert docstring.returns.description == 'a return value'

# Generated at 2022-06-17 18:23:27.473458
# Unit test for function parse
def test_parse():
    text = """
    This is a summary.

    This is a description.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a summary.'
    assert docstring.long_description == 'This is a description.'
    assert docstring.params == {'arg1': 'The first argument.', 'arg2': 'The second argument.'}
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises == {'keyError': 'raises an exception'}


# Generated at 2022-06-17 18:23:37.324589
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("hello world") == Docstring(summary="hello world", description="", meta={})
    assert parse("hello world\n\nlonger description") == Docstring(summary="hello world", description="longer description", meta={})
    assert parse("hello world\n\nlonger description\n\n:param x: parameter x") == Docstring(summary="hello world", description="longer description", meta={"param": [{"name": "x", "type": None, "description": None}]})

# Generated at 2022-06-17 18:23:40.635083
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'


# Generated at 2022-06-17 18:23:51.678323
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    text = """
    This is a test function.

    :param a: test parameter a
    :param b: test parameter b
    :returns: test return
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'test parameter a'
    assert docstring.params['b'] == 'test parameter b'
    assert docstring.returns == 'test return'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:24:00.453342
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a
    :param b: b
    :returns: a + b
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "a", "b": "b"}
    assert docstring.returns == "a + b"
    assert docstring.meta == {
        "param": {"a": "a", "b": "b"},
        "returns": "a + b",
    }


# Generated at 2022-06-17 18:24:11.055907
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test: test parameter
    :returns: test return
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"test": "test parameter"}
    assert docstring.returns == "test return"
    assert docstring.raises == {}
    assert docstring.meta == {}
    assert docstring.style == Style.numpy
    assert docstring.summary == "This is a test docstring."
    assert docstring.extended_summary == ""
    assert docstring.body == ""
    assert docstring.examples == ""
    assert docstring.seealso == ""
    assert docstring.notes == ""

# Generated at 2022-06-17 18:24:21.117524
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "a parameter"
    assert docstring.params['a'].type_name == "int"
    assert docstring.params['b'].description == "another parameter"
    assert docstring.params['b'].type_name == "str"
    assert docstring.returns.description == "return value"
    assert docstring.returns.type_name == "float"


# Generated at 2022-06-17 18:24:30.097013
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: nothing
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == 'nothing'
    assert docstring.return_type == 'None'
    assert docstring.meta == {'param_types': {'a': 'int', 'b': 'str'}}

# Generated at 2022-06-17 18:24:40.740405
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test: test parameter
    :type test: str
    :returns: test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "test"
    assert docstring.params[0].description == "test parameter"
    assert docstring.params[0].type_name == "str"
    assert docstring.returns.description == "test return"
    assert docstring.returns.type_name == "str"
    assert docstring.meta == {}

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:24:53.320537
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param test: test parameter
    :type test: str
    :returns: test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [("test", "test parameter", "str")]
    assert docstring.returns == ("test return", "str")
    assert docstring.meta == {"param": [("test", "test parameter", "str")], "returns": ("test return", "str")}

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:25:00.814592
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param x: x
    :param y: y
    :returns: x + y
    """
    assert parse(docstring).summary == "This is a test docstring."
    assert parse(docstring).params['x'].description == "x"
    assert parse(docstring).params['y'].description == "y"
    assert parse(docstring).returns.description == "x + y"

# Generated at 2022-06-17 18:25:09.077809
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """This is a docstring.
    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params["a"] == "first parameter"
    assert docstring.params["b"] == "second parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {
        "param a": "first parameter",
        "param b": "second parameter",
        "returns": "something",
    }

# Generated at 2022-06-17 18:25:18.248004
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.returns.description == "Description of return value."
    assert docstring.raises.description == "raises an exception"
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"

# Generated at 2022-06-17 18:25:25.662326
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a test docstring.'
    assert doc.long_description == ''
    assert doc.meta['param']['a'] == 'a parameter'
    assert doc.meta['param']['b'] == 'another parameter'
    assert doc.meta['returns'] == 'something'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:25:34.731921
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises Exception: Because I said so.
    """
    assert parse(text).short_description == 'This is a test docstring.'
    assert parse(text).long_description == ''
    assert parse(text).params == {'arg1': 'The first argument.', 'arg2': 'The second argument.'}
    assert parse(text).returns == 'Description of return value.'
    assert parse(text).raises == {'Exception': 'Because I said so.'}

# Generated at 2022-06-17 18:25:44.060995
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type.
    """
    d = parse(text)
    assert d.short_description == "This is a test function."
    assert d.long_description == ""
    assert len(d.params) == 2
    assert d.params[0].arg_name == "arg1"
    assert d.params[0].description == "The first argument."
    assert d.params[1].arg_name == "arg2"
    assert d.params[1].description == "The second argument."
    assert d.returns.description == "The return value."
    assert len(d.raises) == 1
   

# Generated at 2022-06-17 18:25:50.589974
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: This is a test parameter.
    :type a: int
    :returns: This is a test return.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("a", "This is a test parameter.", "int")
    ]
    assert docstring.returns == ("This is a test return.", "str")
    assert docstring.meta == {}

# Generated at 2022-06-17 18:25:57.143002
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param a: a
    :param b: b
    :returns: a + b
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a'
    assert docstring.params['b'].description == 'b'
    assert docstring.returns.description == 'a + b'

# Generated at 2022-06-17 18:26:11.085986
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises Exception: Because you shouldn't have done that.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "Description of return value."
    assert docstring.raises == {"Exception": "Because you shouldn't have done that."}
    assert docstring.meta == {}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:26:21.886801
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].arg_type == "int"
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].arg_name == "arg2"
    assert docstring

# Generated at 2022-06-17 18:26:30.754720
# Unit test for function parse
def test_parse():
    """Test the function parse"""
    text = """
    This is a function.

    :param x: This is x.
    :type x: int
    :param y: This is y.
    :type y: float
    :returns: This is the return.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].description == "This is x."
    assert docstring.params[0].type_name == "int"
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].description == "This is y."
    assert doc

# Generated at 2022-06-17 18:26:36.478416
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'a return value'
    assert docstring.meta == {'a': 'a parameter', 'b': 'another parameter', 'returns': 'a return value'}