

# Generated at 2022-06-17 18:16:43.516936
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """
    assert parse(text).short_description == "This is a docstring."


# Generated at 2022-06-17 18:16:53.647309
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'
    assert docstring.params[1].description == 'The second argument.'
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == 'None'

#

# Generated at 2022-06-17 18:17:01.610142
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: a foo
    :type foo: str
    :param bar: a bar
    :type bar: int
    :returns: a baz
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params['foo'].description == "a foo"
    assert docstring.params['foo'].annotation == "str"
    assert docstring.params['bar'].description == "a bar"
    assert docstring.params['bar'].annotation == "int"
    assert docstring.returns.description == "a baz"
    assert docstring.returns.annotation == "float"



# Generated at 2022-06-17 18:17:10.020587
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: foo parameter
    :type foo: str
    :param bar: bar parameter
    :type bar: int
    :returns: return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "foo": "foo parameter",
        "bar": "bar parameter",
    }
    assert docstring.returns == "return value"
    assert docstring.meta == {
        "foo": "str",
        "bar": "int",
        "returns": "str",
    }


# Generated at 2022-06-17 18:17:20.267395
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: This is a test parameter.
    :type x: int
    :returns: This is a test return.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].description == "This is a test parameter."
    assert docstring.params[0].annotation == "int"
    assert docstring.returns.description == "This is a test return."
    assert docstring.returns.annotation == "str"


# Generated at 2022-06-17 18:17:31.474546
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: baz
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "foo": "foo",
        "bar": "bar",
    }
    assert docstring.returns == "baz"
    assert docstring.return_type == "float"
    assert docstring.meta == {
        "foo": "str",
        "bar": "int",
    }

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:17:42.534432
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param int x: x coordinate
    :param int y: y coordinate
    :returns: x + y
    """

# Generated at 2022-06-17 18:17:53.207354
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params == [('x', 'x', 'int')]
    assert docstring.returns == ('x', 'int')
    assert docstring.meta == {'param x': 'x', 'type x': 'int', 'returns': 'x', 'rtype': 'int'}


# Generated at 2022-06-17 18:18:03.853724
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: test parameter a
    :type a: int
    :param b: test parameter b
    :type b: str
    :returns: test return value
    :rtype: float
    """
    doc = parse(text)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == "a"
    assert doc.params[0].type_name == "int"
    assert doc.params[0].description == "test parameter a"
    assert doc.params[1].arg_name == "b"
    assert doc.params[1].type_name == "str"

# Generated at 2022-06-17 18:18:11.312495
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is foo
    :type foo: str
    :param bar: this is bar
    :type bar: int
    :returns: this is return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params["foo"].description == "this is foo"
    assert docstring.params["foo"].type == "str"
    assert docstring.params["bar"].description == "this is bar"
    assert docstring.params["bar"].type == "int"
    assert docstring.returns.description == "this is return"
    assert docstring.returns.type == "str"


# Generated at 2022-06-17 18:18:24.209070
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises['keyError'] == "raises an exception"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:18:32.552462
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type == 'str'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:18:43.133008
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 3
    assert docstring.meta["param"]["x"].description == "x"
    assert docstring.meta["param"]["y"].description == "y"
    assert docstring.meta["return"]["returns"].description == "x + y"



# Generated at 2022-06-17 18:18:50.277675
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.annotation == 'int'


# Generated at 2022-06-17 18:19:01.222649
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test: test parameter
    :type test: str
    :returns: test return
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["parameters"]["test"]["description"] == "test parameter"
    assert docstring.meta["parameters"]["test"]["type"] == "str"
    assert docstring.meta["returns"]["description"] == "test return"
    assert docstring.meta["returns"]["type"] == "int"
    assert docstring.meta["returns"]["annotation"] == "int"


# Generated at 2022-06-17 18:19:10.978951
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param test: test parameter
    :type test: str
    :returns: test return
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['test'].description == 'test parameter'
    assert docstring.params['test'].type == 'str'
    assert docstring.returns.description == 'test return'
    assert docstring.returns.type == 'str'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:19:19.057296
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: this is a foo
    :type foo: str
    :param bar: this is a bar
    :type bar: int
    :returns: this is a return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "foo"
    assert docstring.params[0].description == "this is a foo"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[1].arg_name == "bar"
    assert docstring.params[1].description == "this is a bar"
    assert docstring.params

# Generated at 2022-06-17 18:19:29.980129
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={}, returns=None)
    assert parse("hello") == Docstring(summary="hello", description="", meta={}, returns=None)
    assert parse("hello\nworld") == Docstring(summary="hello", description="world", meta={}, returns=None)
    assert parse("hello\nworld\n") == Docstring(summary="hello", description="world", meta={}, returns=None)
    assert parse("hello\nworld\n\n") == Docstring(summary="hello", description="world", meta={}, returns=None)
    assert parse("hello\nworld\n\n\n") == Docstring(summary="hello", description="world", meta={}, returns=None)

# Generated at 2022-06-17 18:19:37.106892
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: A foo parameter.
    :type foo: str
    :param bar: A bar parameter.
    :type bar: int
    :returns: A return value.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['foo'].description == "A foo parameter."
    assert docstring.params['foo'].type == "str"
    assert docstring.params['bar'].description == "A bar parameter."
    assert docstring.params['bar'].type == "int"
    assert docstring.returns.description == "A return value."
    assert docstring.returns.type

# Generated at 2022-06-17 18:19:44.853259
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["a"] == "a parameter"
    assert docstring.params["b"] == "another parameter"
    assert docstring.returns == "a return value"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:19:58.664294
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:20:10.529889
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param a: this is a
    :type a: str
    :param b: this is b
    :type b: int
    :returns: this is return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'this is a'
    assert docstring.params['a'].type_name == 'str'
    assert docstring.params['b'].description == 'this is b'
    assert docstring.params['b'].type_name == 'int'
    assert docstring.returns.description == 'this is return'

# Generated at 2022-06-17 18:20:16.896990
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 3


# Generated at 2022-06-17 18:20:25.273311
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x value
    :type x: int
    :param y: y value
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'x'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'x value'
    assert docstring.params[1].arg_name == 'y'
    assert docstring.params[1].type_name == 'int'

# Generated at 2022-06-17 18:20:32.463305
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test: This is a test param
    :type test: str
    :returns: This is a test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [("test", "This is a test param", "str")]
    assert docstring.returns == ("This is a test return", "str")
    assert docstring.meta == {}


# Generated at 2022-06-17 18:20:41.654066
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: None
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("foo", "foo", "str"),
        ("bar", "bar", "int"),
    ]
    assert docstring.returns == ("None", "None")

# Generated at 2022-06-17 18:20:55.323293
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    text = """\
        This is a test.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.
        """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring, GoogleStyle)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "The first argument."
   

# Generated at 2022-06-17 18:21:04.625635
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == 'a value'
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'a value'}


# Generated at 2022-06-17 18:21:13.496807
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'a return value'
    assert docstring.meta == {'a': 'a parameter', 'b': 'another parameter', 'returns': 'a return value'}


# Generated at 2022-06-17 18:21:24.738965
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:21:31.380966
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """
    assert parse(text).short_description == "This is a docstring."


# Generated at 2022-06-17 18:21:42.190276
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print name value.
    :type state: bool.
    :returns:  str -- the result.
    '''
    assert parse(text, style=Style.google).summary == 'This is a test docstring.'
    assert parse(text, style=Style.google).params[0].name == 'name'
    assert parse(text, style=Style.google).params[0].type == 'str.'
    assert parse(text, style=Style.google).params[1].name == 'state'
    assert parse(text, style=Style.google).params[1].type == 'bool.'

# Generated at 2022-06-17 18:21:52.768483
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    from docstring_parser.common import Docstring
    text = """
    This is a test docstring.
    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    assert parse(text) == Docstring(
        content='This is a test docstring.',
        params=[('a', 'a parameter', 'int')],
        returns=('a return value', 'str'),
        style=GoogleStyle
    )

# Generated at 2022-06-17 18:22:03.993653
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    :raises Exception: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == "something"

# Generated at 2022-06-17 18:22:13.548037
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    from docstring_parser.parser import parse
    text = """
    This is a test function
    :param a: first parameter
    :param b: second parameter
    :returns: return value
    """
    style = Style.auto
    parse(text, style)
    text = """
    This is a test function
    :param a: first parameter
    :param b: second parameter
    :returns: return value
    """
    style = Style.auto
    parse(text, style)
    text = """
    This is a test function
    :param a: first parameter
    :param b: second parameter
    :returns: return value
    """
    style = Style.auto

# Generated at 2022-06-17 18:22:19.246598
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x
    :param y: y
    :returns: x + y
    """
    assert parse(text).summary == "This is a test docstring."
    assert parse(text).params['x'].description == "x"
    assert parse(text).params['y'].description == "y"
    assert parse(text).returns.description == "x + y"

# Generated at 2022-06-17 18:22:26.047572
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether or not to say hello.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['name'] == 'The name to use.'
    assert docstring.params['state'] == 'Whether or not to say hello.'
    assert docstring.returns == 'None.'
    assert docstring.raises == 'AttributeError, KeyError'

# Generated at 2022-06-17 18:22:34.952173
# Unit test for function parse
def test_parse():
    text = """
    This is a sample docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a sample docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert docstring.returns == "Description of return value."
    assert docstring.raises == [("keyError", "raises an exception")]

# Generated at 2022-06-17 18:22:43.071858
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "something"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:22:56.292207
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == "something"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:23:08.976748
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].arg_type == ""
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].arg_name == "arg2"
    assert docstring.meta[1].arg_type == ""
    assert docstring.meta[1].description == "The second argument."
    assert doc

# Generated at 2022-06-17 18:23:18.909040
# Unit test for function parse
def test_parse():
    text = """
    This is a test.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :returns: This is a description of what is returned.
    :raises keyError: This is a description of the exception.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'This is the first argument.'
    assert docstring.params['arg2'] == 'This is the second argument.'
    assert docstring.returns == 'This is a description of what is returned.'
    assert docstring.raises['keyError'] == 'This is a description of the exception.'


# Generated at 2022-06-17 18:23:28.275901
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param foo: The foo parameter
    :type foo: int
    :param bar: The bar parameter
    :type bar: str
    :returns: The return value
    :rtype: bool
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'The foo parameter'
    assert docstring.params['foo'].annotation == 'int'
    assert docstring.params['bar'].description == 'The bar parameter'
    assert docstring.params['bar'].annotation == 'str'
    assert docstring.returns.description == 'The return value'

# Generated at 2022-06-17 18:23:33.688739
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """
    assert parse(text) == Docstring(
        summary='This is a docstring.',
        description='',
        returns=None,
        raises=None,
        meta={},
        style=Style.numpy,
    )


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:23:40.499491
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: bar
    :type foo: str
    :returns: baz
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"foo": "bar"}
    assert docstring.returns == "baz"
    assert docstring.return_type == "int"
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:23:53.025653
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    assert docstring.meta['arg1']['type'] == 'param'
    assert docstring.meta['arg1']['arg_name'] == 'arg1'
    assert docstring.meta['arg1']['description'] == 'The first argument.'

# Generated at 2022-06-17 18:24:04.029659
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'a string'

# Generated at 2022-06-17 18:24:11.012275
# Unit test for function parse
def test_parse():
    text = """
    This is a function.
    :param x: x
    :param y: y
    :returns: x+y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["x"] == "x"
    assert docstring.meta["param"]["y"] == "y"
    assert docstring.meta["returns"] == "x+y"

# Generated at 2022-06-17 18:24:20.732300
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:24:30.506850
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is a parameter
    :type foo: str
    :param bar: this is another parameter
    :type bar: int
    :returns: description of return value
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params['foo'].description == "this is a parameter"
    assert docstring.params['foo'].annotation == "str"
    assert docstring.params['bar'].description == "this is another parameter"
    assert docstring.params['bar'].annotation == "int"
    assert docstring.returns.description == "description of return value"

# Generated at 2022-06-17 18:24:41.547108
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: None
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"
    assert docstring.params[1].annotation == "str"

# Generated at 2022-06-17 18:24:54.214898
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "first parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "second parameter"
    assert docstring.returns.description == "something"
    assert docstring.raises is None
    assert docstring.meta == {}

# Generated at 2022-06-17 18:25:03.317463
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: description of return value
    :rtype: str
    """
    assert parse(text) == Docstring(
        summary='This is a docstring.',
        description='',
        meta={
            'foo': 'This is a parameter.',
            'bar': 'This is another parameter.',
            'returns': 'description of return value',
            'rtype': 'str',
        },
    )


# Generated at 2022-06-17 18:25:11.622967
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    doc = parse(text)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == ""
    assert doc.params == [
        {
            "name": "a",
            "type": "int",
            "description": "a parameter",
            "annotation": "",
            "default": "",
        },
        {
            "name": "b",
            "type": "str",
            "description": "another parameter",
            "annotation": "",
            "default": "",
        },
    ]
   

# Generated at 2022-06-17 18:25:13.590674
# Unit test for function parse
def test_parse():
    text = """
    This is a test
    """
    assert parse(text) == Docstring(text, '', '', '', '', '', '')

# Generated at 2022-06-17 18:25:23.312274
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "something"
    assert docstring.return_type == "float"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
    }

# Generated at 2022-06-17 18:25:34.116673
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    """
    assert parse(docstring).short_description == "This is a test docstring."
    assert parse(docstring).long_description == ""
    assert parse(docstring).returns.description == "the return value"
    assert parse(docstring).params[0].arg_name == "arg1"
    assert parse(docstring).params[0].description == "the first argument"
    assert parse(docstring).params[1].arg_name == "arg2"
    assert parse(docstring).params[1].description == "the second argument"

# Generated at 2022-06-17 18:25:42.485461
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a return value
    :rtype: float
    """
    assert parse(text) == Docstring(
        summary='This is a test function.',
        description='',
        meta={
            'a': 'a parameter',
            'b': 'another parameter',
            'returns': 'a return value',
            'rtype': 'float'
        }
    )

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:25:50.467221
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a formatted string
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params['name'].description == "name of the person"
    assert docstring.params['age'].description == "age of the person"
    assert docstring.returns.description == "a formatted string"
    assert docstring.raises['ValueError'].description == "if age is negative"


# Generated at 2022-06-17 18:26:00.209414
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'param1'
    assert docstring.params[0].description == 'this is a first param'
    assert docstring.params[1].arg_name == 'param2'
    assert docstring.params[1].description == 'this is a second param'

# Generated at 2022-06-17 18:26:13.829698
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:26:23.207670
# Unit test for function parse
def test_parse():
    text = """
    This is a function that does something.

    :param x: The first parameter.
    :type x: int
    :param y: The second parameter.
    :type y: int
    :returns: The return value.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function that does something."
    assert docstring.long_description == ""
    assert docstring.params['x'].description == "The first parameter."
    assert docstring.params['x'].type == "int"
    assert docstring.params['y'].description == "The second parameter."
    assert docstring.params['y'].type == "int"
    assert docstring.returns.description == "The return value."
    assert docstring.returns

# Generated at 2022-06-17 18:26:30.732005
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'a return value'
    assert docstring.meta == {}



# Generated at 2022-06-17 18:26:36.853948
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: x parameter
    :param y: y parameter
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['x'] == 'x parameter'
    assert docstring.params['y'] == 'y parameter'
    assert docstring.returns == 'return value'
    assert docstring.meta == {}
    assert docstring.style == Style.google
    assert docstring.to_str() == text

if __name__ == '__main__':
    test_parse()