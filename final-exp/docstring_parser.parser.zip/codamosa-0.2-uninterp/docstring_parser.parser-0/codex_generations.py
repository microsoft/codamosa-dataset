

# Generated at 2022-06-17 18:16:46.067859
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str arg1: The first argument.
    :param int arg2: The second argument.
    :returns: The return value.
    :raises ValueError: If something goes wrong.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'].arg_type == 'str'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].arg_type == 'int'
    assert docstring.params['arg2'].description == 'The second argument.'
    assert docstring.returns.arg_type == 'None'
    assert docstring.returns

# Generated at 2022-06-17 18:16:55.843255
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params["x"].description == "x"
    assert docstring.params["x"].type == "int"
    assert docstring.params["y"].description == "y"
    assert docstring.params["y"].type == "int"
    assert docstring.returns.description == "x + y"
    assert docstring.returns.type == "int"

# Generated at 2022-06-17 18:17:04.046195
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.returns.description == 'None'
    assert docstring.returns.annotation == ''

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:17:08.943215
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("Hello world") == Docstring(summary="Hello world", description="", meta={})
    assert parse("Hello world\n") == Docstring(summary="Hello world", description="", meta={})
    assert parse("Hello world\n\n") == Docstring(summary="Hello world", description="", meta={})
    assert parse("Hello world\n\nDescription") == Docstring(summary="Hello world", description="Description", meta={})
    assert parse("Hello world\n\nDescription\n") == Docstring(summary="Hello world", description="Description", meta={})
    assert parse("Hello world\n\nDescription\n\n") == Docstring(summary="Hello world", description="Description", meta={})

# Generated at 2022-06-17 18:17:19.372000
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'name of the person'
    assert docstring.params['age'].description == 'age of the person'
    assert docstring.returns.description == 'a person'
    assert docstring.raises['ValueError'].description == 'if age is negative'

# Generated at 2022-06-17 18:17:27.025672
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param a: parameter a
    :param b: parameter b
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'parameter a'
    assert docstring.params['b'] == 'parameter b'
    assert docstring.returns == 'return value'

# Generated at 2022-06-17 18:17:38.500060
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta == {}
    assert docstring.params == []
    assert docstring.returns == None
    assert docstring.raises == []
    assert docstring.other == []
    assert docstring.examples == []
    assert docstring.see_also == []
    assert docstring.notes == []
    assert docstring.references == []
    assert docstring.attributes == []
    assert docstring.methods == []
    assert docstring.deprecated == None
    assert docstring.todo == []
    assert docstring.warning == None
    assert docstring.bug

# Generated at 2022-06-17 18:17:42.002810
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {}
    assert docstring.style == Style.google

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:17:51.629823
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {"param": ["x", "y"], "returns": ["x + y"]}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:18:02.541813
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "x"
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].type_name == "float"
    assert docstring.params[1].description == "y"

# Generated at 2022-06-17 18:18:12.748160
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    doc = parse(text)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.meta == {}
    assert doc.sections == []
    assert doc.style == Style.numpy


# Generated at 2022-06-17 18:18:22.206884
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:18:29.881038
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].arg_name == 'arg2'
    assert docstring.params['arg2'].description == 'The second argument.'

# Generated at 2022-06-17 18:18:40.196131
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a description of what is returned'
    assert docstring.raises['keyError'] == 'raises an exception'


# Generated at 2022-06-17 18:18:52.460043
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params['x'] == "x"
    assert docstring.params['y'] == "y"
    assert docstring.returns == "x + y"
    assert docstring.meta == {'param': {'x': 'x', 'y': 'y'}, 'returns': 'x + y'}


# Generated at 2022-06-17 18:19:01.222530
# Unit test for function parse
def test_parse():
    text = """
    This is a test.
    :param a: a is a
    :param b: b is b
    :returns: a + b
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a is a'
    assert docstring.params['b'] == 'b is b'
    assert docstring.returns == 'a + b'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:19:12.628961
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param name: The name to use.
    :type name: str.
    :param state: Current state to be in.
    :type state: bool.
    :returns: int -- the return code.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params['name'].arg_type == 'str.'
    assert docstring.params['state'].arg_type == 'bool.'
    assert docstring.returns.arg_type == 'int'
    assert docstring.returns.description == 'the return code.'

# Generated at 2022-06-17 18:19:17.863414
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param x: x
    :param y: y
    :returns: x + y
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['x'] == 'x'
    assert docstring.params['y'] == 'y'
    assert docstring.returns == 'x + y'


# Generated at 2022-06-17 18:19:25.181884
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {"name": "arg1", "type": None, "description": "The first argument."},
        {"name": "arg2", "type": None, "description": "The second argument."},
    ]
    assert docstring.returns == {"type": None, "description": "Description of return value."}

# Generated at 2022-06-17 18:19:34.923308
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == {
        'arg1': 'The first argument.',
        'arg2': 'The second argument.'
    }
    assert docstring.returns == 'None'
    assert docstring.raises == {
        'keyError': 'raises an exception'
    }
    assert docstring.meta == {}


# Generated at 2022-06-17 18:19:53.500273
# Unit test for function parse
def test_parse():
    text = """
    This is a module docstring.

    This is the second paragraph of the module docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :param arg3: The third argument.
    :type arg1: int, optional
    :type arg2: str, optional
    :type arg3: list, optional
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a module docstring.'
    assert docstring.long_description == 'This is the second paragraph of the module docstring.'
    assert docstring.params['arg1'].arg_type == 'int, optional'
    assert docstring.params['arg1'].description == 'The first argument.'

# Generated at 2022-06-17 18:19:57.322996
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:20:07.933244
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.meta["a"]["type"] == "int"
    assert docstring.meta["b"]["type"] == "str"
    assert docstring.returns["type"] == "str"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:20:17.456463
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: None
    :raises ValueError: If `foo` is empty.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'This is a parameter.'
    assert docstring.params['foo'].type_name == 'str'
    assert docstring.params['bar'].description == 'This is another parameter.'
    assert docstring.params['bar'].type_name == 'int'
    assert docstring.returns.description == 'None'


# Generated at 2022-06-17 18:20:25.987213
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises Exception: An exception.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "The return value."
    assert docstring.raises == {"Exception": "An exception."}

# Generated at 2022-06-17 18:20:34.480684
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a + b
    :rtype: int
    """
    doc = parse(text)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == ""
    assert doc.params == [
        {"name": "a", "type": "int", "description": "a parameter"},
        {"name": "b", "type": "str", "description": "another parameter"},
    ]
    assert doc.returns == {"type": "int", "description": "a + b"}
    assert doc.meta == {}


# Generated at 2022-06-17 18:20:43.417103
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['x'].description == 'x'
    assert docstring.params['x'].type_name == 'int'
    assert docstring.params['y'].description == 'y'
    assert docstring.params['y'].type_name == 'float'
    assert docstring.returns.description == 'x + y'
    assert docstring.returns.type_name == 'float'
    assert docstring

# Generated at 2022-06-17 18:20:49.233990
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:20:57.304534
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param int a: This is a test parameter.
    :param str b: This is another test parameter.
    :returns: This is a test return.
    :raises ValueError: This is a test exception.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'This is a test parameter.'
    assert docstring.params['b'].description == 'This is another test parameter.'
    assert docstring.returns.description == 'This is a test return.'
    assert docstring.exceptions['ValueError'].description == 'This is a test exception.'


# Generated at 2022-06-17 18:21:01.162839
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring.
    '''
    assert parse(docstring).short_description == 'This is a docstring.'


# Generated at 2022-06-17 18:21:15.666445
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].arg_name == 'arg2'
    assert docstring.params['arg2'].description == 'The second argument.'

# Generated at 2022-06-17 18:21:27.324502
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print name or not.
    :type state: bool.
    :returns: str -- the formatted name.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['name'].arg_type == 'str.'
    assert docstring.params['state'].arg_type == 'bool.'
    assert docstring.returns.arg_type == 'str -- the formatted name.'
    assert len(docstring.raises) == 2
   

# Generated at 2022-06-17 18:21:38.657120
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: None
    """
    assert parse(text) == Docstring(
        summary="This is a test docstring.",
        description="",
        returns=Docstring.Return(
            type="None",
            description="",
        ),
        params=[
            Docstring.Param(
                name="arg1",
                type="",
                description="the first argument",
                default="",
            ),
            Docstring.Param(
                name="arg2",
                type="",
                description="the second argument",
                default="",
            ),
        ],
        meta={},
    )

# Generated at 2022-06-17 18:21:46.617916
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :rtype: Person
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['name'].description == "name of the person"
    assert docstring.params['age'].description == "age of the person"
    assert docstring.returns.description == "a person"
    assert docstring.returns.type_name == "Person"
    assert docstring.meta == {'param': {'name': 'str', 'age': 'int'}, 'returns': 'Person'}


# Generated at 2022-06-17 18:21:54.940254
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    """
    doc = parse(text)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params == [
        ("arg1", "the first argument"),
        ("arg2", "the second argument")
    ]
    assert doc.returns == "the return value"
    assert doc.meta == {}



# Generated at 2022-06-17 18:22:05.483414
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == "something"
    assert docstring.raises == []
    assert docstring.warn

# Generated at 2022-06-17 18:22:14.539592
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.utils import dedent
    text = dedent("""
    This is a short summary.

    This is a long description.

    This is a third paragraph in the long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """)
    docstring = parse(text)
    assert isinstance(docstring, Docstring)

# Generated at 2022-06-17 18:22:23.392618
# Unit test for function parse
def test_parse():
    text = """
    This is a module docstring.

    This is the first paragraph of the module docstring.

    This is the second paragraph of the module docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a module docstring.'
    assert docstring.long_description == 'This is the first paragraph of the module docstring.\n\nThis is the second paragraph of the module docstring.'
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
   

# Generated at 2022-06-17 18:22:34.195656
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "param1": "this is a first param",
        "param2": "this is a second param",
    }
    assert docstring.returns == "this is a return"
    assert docstring.raises == {"keyError": "raises an exception"}

# Generated at 2022-06-17 18:22:45.498025
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is a parameter
    :type foo: str
    :param bar: this is another parameter
    :type bar: int
    :returns: description of return value
    :rtype: str
    """

# Generated at 2022-06-17 18:22:58.825352
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    text = """
    This is a docstring.

    :param foo: first parameter
    :param bar: second parameter
    :returns: something
    :raises Exception: if something goes wrong
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"foo": "first parameter", "bar": "second parameter"}
    assert docstring.returns == "something"
    assert docstring.raises == {"Exception": "if something goes wrong"}
    assert docstring.meta == {}


# Generated at 2022-06-17 18:23:06.445556
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:23:11.520737
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "a parameter"}
    assert docstring.returns == "a return value"
    assert docstring.meta == {"a": "int", "returns": "int"}


# Generated at 2022-06-17 18:23:21.260822
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: Foo parameter
    :type foo: str
    :param bar: Bar parameter
    :type bar: int
    :returns: Docstring
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "foo": "Foo parameter",
        "bar": "Bar parameter",
    }
    assert docstring.returns == "Docstring"
    assert docstring.return_type == "str"
    assert docstring.meta == {}
    assert docstring.style == Style.numpy
    assert docstring.raw == text


# Generated at 2022-06-17 18:23:24.522060
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].type_name == "int"
    assert docstring.returns.description == "x"
    assert docstring.returns.type_name == "int"

# Generated at 2022-06-17 18:23:33.582545
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: this is a test param
    :type a: int
    :returns: this is a test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "this is a test param"
    assert docstring.params[0].type_name == "int"
    assert docstring.returns.description == "this is a test return"
    assert docstring.returns.type_name == "str"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:23:42.989094
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: foo
    :type foo: str
    :returns: bar
    :rtype: int
    """
    assert parse(text).short_description == "This is a docstring."
    assert parse(text).long_description == ""
    assert parse(text).returns.description == "bar"
    assert parse(text).returns.type_annotation == "int"
    assert parse(text).params[0].name == "foo"
    assert parse(text).params[0].description == "foo"
    assert parse(text).params[0].type_annotation == "str"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:23:46.627505
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: A parameter.
    :type a: int
    :param b: Another parameter.
    :type b: str
    :returns: A value.
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "A parameter."
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "Another parameter."
    assert docstring.params

# Generated at 2022-06-17 18:23:58.281551
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["a"] == "a parameter"
    assert docstring.params["b"] == "another parameter"
    assert docstring.returns == "a return value"
    assert docstring.meta["a"] == "int"
    assert docstring.meta["b"] == "str"
    assert docstring.meta["returns"] == "float"


# Generated at 2022-06-17 18:24:09.057375
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "Description of return value."
    assert docstring.raises == {"keyError": "raises an exception"}
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:24:23.411227
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: None
    :raises ValueError: If `foo` is not a string.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["foo"].description == "This is a parameter."
    assert docstring.params["foo"].annotation == "str"
    assert docstring.params["bar"].description == "This is another parameter."
    assert docstring.params["bar"].annotation == "int"

# Generated at 2022-06-17 18:24:30.247000
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param a: parameter a
    :param b: parameter b
    :returns: return value
    """
    assert parse(docstring) == Docstring(
        summary="This is a test docstring.",
        description="",
        meta={
            "param a": "parameter a",
            "param b": "parameter b",
            "returns": "return value",
        },
    )

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:24:39.857484
# Unit test for function parse
def test_parse():
    """Test function parse."""
    from docstring_parser.styles import GoogleStyle
    text = """
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring, GoogleStyle)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name == "int"

# Generated at 2022-06-17 18:24:46.815363
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.
    :param x: test param
    :returns: test return
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a test function.'
    assert doc.long_description == ''
    assert doc.params[0].arg_name == 'x'
    assert doc.params[0].description == 'test param'
    assert doc.returns.description == 'test return'

# Generated at 2022-06-17 18:24:54.517359
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.returns.description == 'Description of return value.'
    assert docstring.raises[0].description == 'raises an exception'
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'

# Generated at 2022-06-17 18:24:58.527387
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:25:08.675805
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print hello.
    :type state: bool.
    :returns: None.
    :raises keyError: Raises an exception.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == [
        {'name': 'name', 'type': 'str.', 'description': 'The name to use.'},
        {'name': 'state', 'type': 'bool.', 'description': 'Whether to print hello.'}
    ]

# Generated at 2022-06-17 18:25:17.905457
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :return: person's name and age
    :rtype: tuple
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['name'].arg_type == 'str'
    assert docstring.meta['param']['name'].description == 'name of the person'
    assert docstring.meta['param']['age'].arg_type == 'int'
    assert docstring.meta['param']['age'].description == 'age of the person'

# Generated at 2022-06-17 18:25:26.513834
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "a return value"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
        "returns": "str",
    }

# Generated at 2022-06-17 18:25:29.720666
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:25:38.337668
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    """
    assert parse(docstring) == Docstring(summary='This is a test docstring.')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:25:47.990234
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is a parameter
    :type foo: str
    :param bar: this is a parameter
    :type bar: int
    :returns: None
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['foo'].arg_type == 'str'
    assert docstring.params['foo'].description == 'this is a parameter'
    assert docstring.params['bar'].arg_type == 'int'
    assert docstring.params['bar'].description == 'this is a parameter'

# Generated at 2022-06-17 18:25:52.722948
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta=[])
    assert parse("Hello, world!") == Docstring(summary="Hello, world!", description="", meta=[])
    assert parse("Hello, world!\n\nThis is a test.") == Docstring(summary="Hello, world!", description="This is a test.", meta=[])
    assert parse("Hello, world!\n\nThis is a test.\n\n:param name: The name to say hello to.\n:type name: str\n:returns: A greeting for `name`.") == Docstring(summary="Hello, world!", description="This is a test.", meta=[("param", "name", "The name to say hello to.", "str"), ("returns", "", "A greeting for `name`.", "")])

# Generated at 2022-06-17 18:26:02.228867
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["param1"] == "this is a first param"
    assert docstring.params["param2"] == "this is a second param"
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises["keyError"] == "raises an exception"
    assert docstring.meta == {}
    assert docstring.style == Style.google

# Generated at 2022-06-17 18:26:12.825563
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print 'hello' or 'goodbye'.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {
        'name': {'type': 'str.', 'description': 'The name to use.'},
        'state': {'type': 'bool.', 'description': 'Whether to print '
                                                  "'hello' or 'goodbye'."},
    }

# Generated at 2022-06-17 18:26:20.644888
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['a'] == 'a parameter'
    assert docstring.meta['param']['b'] == 'another parameter'
    assert docstring.meta['returns'] == 'a return value'


# Generated at 2022-06-17 18:26:28.977680
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: Name of the person.
    :param int age: Age of the person.
    :returns: Person's name and age.
    :raises ValueError: If age is negative.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "Name of the person."
    assert docstring.params[1].arg_name == "age"
    assert docstring.params[1].type_name == "int"

# Generated at 2022-06-17 18:26:33.184566
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        returns=None,
        raises=None,
        meta={},
    )

if __name__ == '__main__':
    test_parse()