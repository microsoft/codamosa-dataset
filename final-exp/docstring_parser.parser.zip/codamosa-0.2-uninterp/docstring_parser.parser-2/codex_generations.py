

# Generated at 2022-06-17 18:16:46.202019
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises Exception: An exception.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument."
    }
    assert docstring.returns == "The return value."
    assert docstring.raises == {"Exception": "An exception."}

# Generated at 2022-06-17 18:16:53.131984
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.returns.description == 'the return value'

# Generated at 2022-06-17 18:17:01.295550
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type == 'int'

# Generated at 2022-06-17 18:17:10.130454
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
   

# Generated at 2022-06-17 18:17:20.868393
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    text = '''
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring, GoogleStyle)
    assert docstring.short_description == 'This is a test function.'
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 0

# Generated at 2022-06-17 18:17:32.033095
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.returns.description == 'a string'
    assert docstring.returns.type_name == 'str'
    assert docstring.meta['param']['a'].description == 'a parameter'
    assert docstring.meta['param']['a'].type_name == 'int'
    assert docstring.meta['param']['b'].description == 'another parameter'

# Generated at 2022-06-17 18:17:42.073914
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a string
    :raises ValueError: if age is negative
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'name of the person'
    assert docstring.params['age'].description == 'age of the person'
    assert docstring.returns.description == 'a string'
    assert docstring.raises['ValueError'].description == 'if age is negative'

# Generated at 2022-06-17 18:17:51.704575
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"x": "x", "y": "y"}
    assert docstring.returns == "x + y"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:18:02.639489
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str arg1: The first argument.
    :param int arg2: The second argument.
    :returns: The return value.
    :raises ValueError: If something goes wrong.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"

# Generated at 2022-06-17 18:18:09.651728
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == 'a string'
    assert docstring.meta == {'a': 'int', 'b': 'str', 'returns': 'str'}

# Generated at 2022-06-17 18:18:22.528796
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "x": "x",
        "y": "y"
    }
    assert docstring.returns == "x + y"
    assert docstring.return_type == "int"
    assert docstring.meta == {
        "param_types": {
            "x": "int",
            "y": "int"
        }
    }


# Generated at 2022-06-17 18:18:30.036389
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['x'].description == 'x'
    assert docstring.params['x'].type == 'int'
    assert docstring.params['y'].description == 'y'
    assert docstring.params['y'].type == 'int'
    assert docstring.returns.description == 'x + y'
    assert docstring.returns.type == 'int'

# Generated at 2022-06-17 18:18:40.712226
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"

# Generated at 2022-06-17 18:18:53.832794
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: nothing
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "name",
            "type": "str",
            "description": "name of the person",
            "default": None,
        },
        {
            "name": "age",
            "type": "int",
            "description": "age of the person",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:19:05.904138
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param a: this is a
    :type a: int
    :param b: this is b
    :type b: str
    :returns: None
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'this is a'
    assert docstring.params['a'].type == 'int'
    assert docstring.params['b'].description == 'this is b'
    assert docstring.params['b'].type == 'str'
    assert docstring.returns.description == 'None'

# Generated at 2022-06-17 18:19:11.352985
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param x: x
    :param y: y
    :returns: x + y
    '''
    assert parse(text) == Docstring(
        content='This is a function.',
        params=[
            ('x', 'x'),
            ('y', 'y')
        ],
        returns='x + y'
    )


# Generated at 2022-06-17 18:19:17.417757
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param x: x value
    :param y: y value
    :returns: x + y
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['x'].description == 'x value'
    assert docstring.params['y'].description == 'y value'
    assert docstring.returns.description == 'x + y'

# Generated at 2022-06-17 18:19:24.984598
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param int a: This is a parameter
    :param str b: This is a parameter
    :returns: This is a return
    :raises ValueError: This is a exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "This is a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"
    assert docstring.params[1].description == "This is a parameter"


# Generated at 2022-06-17 18:19:35.366728
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: description of return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params['foo'].description == "This is a parameter."
    assert docstring.params['foo'].type_name == "str"
    assert docstring.params['bar'].description == "This is another parameter."
    assert docstring.params['bar'].type_name == "int"
    assert docstring.returns.description == "description of return value"

# Generated at 2022-06-17 18:19:46.612812
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: parameter x
    :type x: int
    :param y: parameter y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    doc = parse(text)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params[0].arg_name == "x"
    assert doc.params[0].type_name == "int"
    assert doc.params[0].description == "parameter x"
    assert doc.params[1].arg_name == "y"
    assert doc.params[1].type_name == "int"
    assert doc.params[1].description == "parameter y"

# Generated at 2022-06-17 18:19:58.700267
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: foo
    :param bar: bar
    :returns: returns
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"foo": "foo", "bar": "bar"}
    assert docstring.returns == "returns"
    assert docstring.meta == {"param": ["foo", "bar"], "returns": ["returns"]}

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:20:10.526426
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    text = """
    This is a test docstring.

    :param str param1: This is a first parameter.
    :param int param2: This is a second parameter.
    :returns: This is a return value.
    :raises ValueError: This is a exception.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "param1"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "This is a first parameter."

# Generated at 2022-06-17 18:20:19.448694
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type == 'int'
    assert docstring.meta == {'param a': 'a parameter', 'type a': 'int',
                              'returns': 'a return value', 'rtype': 'int'}


# Generated at 2022-06-17 18:20:26.153244
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param arg1: The first argument.
    :type arg1: int, optional
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """
    assert parse(docstring) == Docstring(
        content='This is a docstring.',
        returns=('Description of return value.', 'int'),
        args=[('arg1', 'The first argument.', 'int, optional'),
              ('arg2', 'The second argument.', 'str, optional')])


# Generated at 2022-06-17 18:20:34.831663
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"

# Generated at 2022-06-17 18:20:43.629131
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert docstring.returns == "Description of return value."
    assert docstring.raises == [("keyError", "raises an exception")]
    assert docstring.meta == {}


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:20:53.257237
# Unit test for function parse
def test_parse():
    text = """\
    This is a docstring.

    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: baz
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "foo"
    assert docstring.params[0].description == "foo"
    assert docstring.params[0].annotation == "str"
    assert docstring.params[1].arg_name == "bar"
    assert docstring.params[1].description == "bar"
    assert docstring.params[1].annotation == "int"

# Generated at 2022-06-17 18:21:03.076070
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "first parameter"
    assert docstring.params['b'] == "second parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {}
    assert docstring.style == Style.numpy
    assert docstring.raw == text


# Generated at 2022-06-17 18:21:09.610710
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param int a: The first parameter
    :param int b: The second parameter
    :returns: The sum of the two parameters
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'The first parameter'
    assert docstring.params['b'].description == 'The second parameter'
    assert docstring.returns.description == 'The sum of the two parameters'

# Generated at 2022-06-17 18:21:19.873779
# Unit test for function parse
def test_parse():
    text = """
    This is a test.
    """

# Generated at 2022-06-17 18:21:35.689443
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: description of return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "foo"
    assert docstring.params[0].description == "This is a parameter."
    assert docstring.params[0].type_name == "str"
    assert docstring.params[1].arg_name == "bar"
    assert docstring.params[1].description == "This is another parameter."
    assert docstring.params

# Generated at 2022-06-17 18:21:40.486814
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    from docstring_parser.parser import parse
    text = """
    This is a test docstring.
    """
    style = Style.auto
    try:
        parse(text, style)
    except ParseError as e:
        exc = e
    assert exc.args[0] == "Could not parse docstring."

# Generated at 2022-06-17 18:21:52.486464
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["a"] == "a parameter"
    assert docstring.meta["param"]["b"] == "another parameter"
    assert docstring.meta["returns"] == "a return value"


# Generated at 2022-06-17 18:22:03.643276
# Unit test for function parse
def test_parse():
    """Test parse function."""
    text = """
    This is a test function.

    :param x: x value
    :type x: int
    :param y: y value
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['x'].description == 'x value'
    assert docstring.params['x'].type_name == 'int'
    assert docstring.params['y'].description == 'y value'
    assert docstring.params['y'].type_name == 'int'
    assert docstring.returns.description == 'x + y'

# Generated at 2022-06-17 18:22:10.454250
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    assert parse(docstring) == Docstring(
        summary='This is a test docstring.',
        description='',
        meta={
            'param': {
                'a': 'a parameter',
                'b': 'another parameter'
            },
            'returns': 'something'
        }
    )


# Generated at 2022-06-17 18:22:21.591166
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises Exception: Because you shouldn't have done that.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "Description of return value."
    assert docstring.raises == {"Exception": "Because you shouldn't have done that."}

# Generated at 2022-06-17 18:22:32.257625
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param int a: first parameter
    :param str b: second parameter
    :returns: return value
    :raises ValueError: if something goes wrong
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "first parameter"
    assert docstring.params[1].arg_name == "b"


# Generated at 2022-06-17 18:22:44.039138
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: first param
    :param b: second param
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "first param"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "second param"
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == "something"
    assert len(docstring.raises) == 0
    assert len

# Generated at 2022-06-17 18:22:48.778924
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:22:57.845262
# Unit test for function parse
def test_parse():
    text = """
    This is a test.

    :param a: a
    :param b: b
    :returns: c
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "b"
    assert docstring.returns.description == "c"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:23:10.382401
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param foo: foo is a string
    :type foo: str
    :param bar: bar is an int
    :type bar: int
    :returns: None
    :rtype: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert docstring.params[0].arg_name == 'foo'
    assert docstring.params[0].arg_type == 'str'
    assert docstring.params[0].description == 'foo is a string'

# Generated at 2022-06-17 18:23:20.118784
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    """
    assert parse(text) == Docstring(
        summary="This is a test docstring.",
        description="",
        returns=Docstring.Return(
            description="x + y",
            type="float",
        ),
        params=[
            Docstring.Param(
                name="x",
                description="x",
                type="int",
            ),
            Docstring.Param(
                name="y",
                description="y",
                type="float",
            ),
        ],
        meta={},
    )

# Generated at 2022-06-17 18:23:28.884659
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: first parameter
    :param b: second parameter
    :returns: a + b
    """
    assert parse(text).short_description == "This is a test function."
    assert parse(text).long_description == ""
    assert parse(text).returns.type_name == "int"
    assert parse(text).returns.description == "a + b"
    assert parse(text).params[0].arg_name == "a"
    assert parse(text).params[0].type_name == "int"
    assert parse(text).params[0].description == "first parameter"
    assert parse(text).params[1].arg_name == "b"
    assert parse(text).params[1].type_name == "int"

# Generated at 2022-06-17 18:23:35.279490
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :returns: This is a return value.
    :rtype: int
    '''
    assert parse(docstring) == Docstring(
        content='This is a docstring.',
        returns=('This is a return value.', 'int'),
        params=[('foo', 'This is a parameter.', 'str')],
        meta={},
    )

# Generated at 2022-06-17 18:23:38.090652
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring"


# Generated at 2022-06-17 18:23:48.712055
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Hello, world!") == Docstring(content="Hello, world!")
    assert parse("Hello, world!\n") == Docstring(content="Hello, world!")
    assert parse("Hello, world!\n\n") == Docstring(content="Hello, world!")
    assert parse("Hello, world!\n\n\n") == Docstring(content="Hello, world!")
    assert parse("Hello, world!\n\n\n\n") == Docstring(content="Hello, world!")
    assert parse("Hello, world!\n\n\n\n\n") == Docstring(content="Hello, world!")
    assert parse("Hello, world!\n\n\n\n\n\n") == Docstring(content="Hello, world!")


# Generated at 2022-06-17 18:24:00.250241
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: this is a foo
    :type foo: int
    :param bar: this is a bar
    :type bar: str
    :returns: this is a return
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['foo'].description == "this is a foo"
    assert docstring.params['foo'].type == "int"
    assert docstring.params['bar'].description == "this is a bar"
    assert docstring.params['bar'].type == "str"
    assert docstring.returns.description == "this is a return"

# Generated at 2022-06-17 18:24:07.401575
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a
    :param b: b
    :returns: c
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['a'] == 'a'
    assert docstring.meta['param']['b'] == 'b'
    assert docstring.meta['returns'] == 'c'

# Generated at 2022-06-17 18:24:14.751307
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "the return value"
    assert docstring.meta == {
        "param": ["a", "b"],
        "returns": ["returns"],
    }

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:24:22.167086
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "first parameter", "b": "second parameter"}
    assert docstring.returns == "something"
    assert docstring.meta == {"param": {"a": "first parameter", "b": "second parameter"}, "returns": "something"}


# Generated at 2022-06-17 18:24:35.362638
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "a parameter"
    assert docstring.params['a'].annotation == "int"
    assert docstring.params['b'].description == "another parameter"
    assert docstring.params['b'].annotation == "str"
    assert docstring.returns.description == "a string"
    assert docstring.returns.annotation == "str"

# Generated at 2022-06-17 18:24:43.286520
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].arg_name == 'arg2'
    assert docstring.params['arg2'].description == 'The second argument.'
    assert len(docstring.returns)

# Generated at 2022-06-17 18:24:52.718656
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "param1": "this is a first param",
        "param2": "this is a second param",
    }
    assert docstring.returns == "this is a return"
    assert docstring.raises == {"keyError": "raises an exception"}

# Generated at 2022-06-17 18:25:03.868806
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param foo: foo parameter
    :type foo: str
    :param bar: bar parameter
    :type bar: int
    :returns: return value
    :rtype: str
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params == [
        {
            "name": "foo",
            "type": "str",
            "description": "foo parameter",
            "default": None,
        },
        {
            "name": "bar",
            "type": "int",
            "description": "bar parameter",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:25:10.674798
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: str
    :returns: nothing
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("a", "first parameter", "int"),
        ("b", "second parameter", "str"),
    ]
    assert docstring.returns == ("nothing", "None")
    assert docstring.meta == {}


# Generated at 2022-06-17 18:25:18.681591
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["x"] == "x"
    assert docstring.params["y"] == "y"
    assert docstring.returns == "x + y"
    assert docstring.meta == {"param x": "x", "param y": "y", "returns": "x + y"}
    assert docstring.style == Style.numpy
    assert docstring.to_str() == text

# Generated at 2022-06-17 18:25:27.501807
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print name or not.
    :type state: bool.
    :returns: None.
    :raises keyError: Raises an exception.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'The name to use.'
    assert docstring.params['name'].type_name == 'str.'
    assert docstring.params['state'].description == 'Whether to print name or not.'
    assert docstring.params['state'].type_name == 'bool.'

# Generated at 2022-06-17 18:25:37.791154
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    assert parse(text).short_description == 'This is a test function.'
    assert parse(text).long_description == ''
    assert parse(text).params['a'].description == 'a parameter'
    assert parse(text).params['b'].description == 'another parameter'
    assert parse(text).returns.description == 'a return value'
    assert parse(text).returns.type_name == ''
    assert parse(text).raises['Exception'].description == ''
    assert parse(text).raises['Exception'].type_name == 'Exception'
    assert parse(text).other['keywords'].description == ''

# Generated at 2022-06-17 18:25:44.558151
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: a foo
    :param bar: a bar
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'] == 'a foo'
    assert docstring.params['bar'] == 'a bar'
    assert docstring.returns == 'a return value'
    assert docstring.meta == {}

# Generated at 2022-06-17 18:25:55.989695
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == 'a return value'
    assert docstring.return_type == 'float'
    assert docstring.meta == {'a': 'int', 'b': 'str'}


# Generated at 2022-06-17 18:26:07.151363
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :returns: a value
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == {'a': 'a parameter'}
    assert docstring.returns == "a value"
    assert docstring.meta == {'a': 'int'}


# Generated at 2022-06-17 18:26:16.609823
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: parameter a
    :param int b: parameter b
    :returns: sum of a and b
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.meta['parameters']['a'].arg_type == 'int'
    assert docstring.meta['parameters']['a'].description == 'parameter a'
    assert docstring.meta['parameters']['b'].arg_type == 'int'
    assert docstring.meta['parameters']['b'].description == 'parameter b'
    assert docstring.meta['returns'].arg_type == ''

# Generated at 2022-06-17 18:26:26.631506
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: This is a parameter.
    :type foo: int
    :param bar: This is another parameter.
    :type bar: str
    :returns: None
    :raises ValueError: If `value` is not valid.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['foo'].arg_type == 'int'
    assert docstring.params['foo'].description == 'This is a parameter.'
    assert docstring.params['bar'].arg_type == 'str'
    assert docstring.params['bar'].description == 'This is another parameter.'

# Generated at 2022-06-17 18:26:35.209954
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test: test parameter
    :type test: str
    :returns: test return
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "test",
            "type": "str",
            "description": "test parameter",
            "default": None,
        }
    ]
    assert docstring.returns == {
        "type": "int",
        "description": "test return",
    }