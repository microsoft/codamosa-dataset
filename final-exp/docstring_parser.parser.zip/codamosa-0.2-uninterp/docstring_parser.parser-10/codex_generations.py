

# Generated at 2022-06-17 18:16:46.679186
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: None
    :raises ValueError: If `foo` is empty.

    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params['foo'].arg_name == 'foo'
    assert docstring.params['foo'].description == 'This is a parameter.'
    assert docstring.params['foo'].annotation == 'str'
    assert docstring.params['foo'].default == None
    assert docstring.params

# Generated at 2022-06-17 18:16:56.802145
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
    assert docstring.raises[0].exc_name

# Generated at 2022-06-17 18:17:04.184762
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 0
    assert len(docstring.other) == 0


# Generated at 2022-06-17 18:17:12.030901
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "Description of return value."
    assert docstring.raises[0].description == "raises an exception"
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"

# Generated at 2022-06-17 18:17:21.556524
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == []
    assert docstring.returns == None
    assert docstring.yields == None
    assert docstring.raises == None
    assert docstring.warns == None
    assert docstring.other == []
    assert docstring.style == Style.numpy

# Generated at 2022-06-17 18:17:28.891751
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: nothing
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params['a'].arg_type == 'int'
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['b'].arg_type == 'str'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.returns.arg_type == 'None'
    assert docstring

# Generated at 2022-06-17 18:17:38.802175
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'

# Generated at 2022-06-17 18:17:47.106036
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].type_name == 'str'
    assert docstring

# Generated at 2022-06-17 18:17:58.864712
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: str
    :param arg2: The second argument.
    :type arg2: int
    :returns: Description of return value.
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1']['type'] == 'str'
    assert docstring.meta['arg1']['description'] == 'The first argument.'
    assert docstring.meta['arg2']['type'] == 'int'
    assert docstring.meta['arg2']['description'] == 'The second argument.'

# Generated at 2022-06-17 18:18:07.506554
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'


# Generated at 2022-06-17 18:18:20.622407
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: nothing
    :rtype: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.returns.description == 'nothing'
    assert docstring.returns.type_name == 'None'


# Generated at 2022-06-17 18:18:28.533864
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "None"
    assert docstring.raises == []
    assert docstring.meta == {}

# Generated at 2022-06-17 18:18:35.551138
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.meta['parameters']['x']['description'] == 'x'
    assert docstring.meta['parameters']['x']['type'] == 'int'
    assert docstring.meta['returns']['description'] == 'x'
    assert docstring.meta['returns']['type'] == 'int'

# Generated at 2022-06-17 18:18:44.271602
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:18:52.811091
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: None
    :rtype: None
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == "foo"
    assert doc.params[0].description == "This is a parameter."
    assert doc.params[0].type_name == "str"
    assert doc.params[1].arg_name == "bar"
    assert doc.params[1].description == "This is another parameter."

# Generated at 2022-06-17 18:19:04.043687
# Unit test for function parse
def test_parse():
    text = """
    This is a function to test the parse function
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function to test the parse function"
    assert docstring.long_description == ""
    assert docstring.params == [{'name': 'text', 'type': None, 'desc': 'docstring text to parse'},
                                {'name': 'style', 'type': None, 'desc': 'docstring style'}]
    assert docstring.returns == {'type': None, 'desc': 'parsed docstring representation'}

# Generated at 2022-06-17 18:19:14.195515
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "first parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"
    assert docstring.params[1].description == "second parameter"

# Generated at 2022-06-17 18:19:23.119529
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x parameter
    :type x: int
    :param y: y parameter
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {'x': 'x parameter', 'y': 'y parameter'}
    assert docstring.returns == "x + y"
    assert docstring.return_type == "int"
    assert docstring.meta == {'x': 'int', 'y': 'int'}
    assert docstring.errors == []
    assert docstring.warnings == []
    assert docstring.style

# Generated at 2022-06-17 18:19:33.711869
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param foo: This is a parameter.
    :type foo: str
    :returns: This is a return.
    :rtype: int
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params[0].arg_name == "foo"
    assert doc.params[0].description == "This is a parameter."
    assert doc.params[0].type_name == "str"
    assert doc.returns.description == "This is a return."
    assert doc.returns.type_name == "int"
    assert doc.meta == {}

# Generated at 2022-06-17 18:19:38.151225
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {"x": "x", "y": "y"}
    assert docstring.returns == "x + y"
    assert docstring.meta == {"x": "int", "y": "int", "returns": "int"}

# Generated at 2022-06-17 18:19:54.185876
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param int a: parameter a
    :param str b: parameter b
    :returns: return value
    """
    doc = parse(text)
    assert doc.short_description == "This is a function."
    assert doc.long_description == ""
    assert doc.params[0].arg_name == "a"
    assert doc.params[0].type_name == "int"
    assert doc.params[0].description == "parameter a"
    assert doc.params[1].arg_name == "b"
    assert doc.params[1].type_name == "str"
    assert doc.params[1].description == "parameter b"
    assert doc.returns.type_name == ""
    assert doc.returns.description == "return value"

# Generated at 2022-06-17 18:20:02.384759
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    d = parse(text)
    assert d.short_description == "This is a test docstring."
    assert d.long_description == ""
    assert d.params == [
        {"name": "a", "type": "int", "description": "a parameter"},
        {"name": "b", "type": "str", "description": "another parameter"},
    ]
    assert d.returns == {"type": "str", "description": "a string"}

# Generated at 2022-06-17 18:20:11.302081
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: the return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == 'the return value'
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'the return value'}


# Generated at 2022-06-17 18:20:20.004655
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :returns: return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "parameter a"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"

# Generated at 2022-06-17 18:20:27.693567
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: str
    :returns: the result
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "first parameter",
        "b": "second parameter",
    }
    assert docstring.returns == "the result"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
        "returns": "float",
    }

# Generated at 2022-06-17 18:20:29.900044
# Unit test for function parse
def test_parse():
    text = '''
    This is a test.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test.'


# Generated at 2022-06-17 18:20:40.415962
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: description
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'This is a parameter.'
    assert docstring.params['foo'].type_name == 'str'
    assert docstring.params['bar'].description == 'This is another parameter.'
    assert docstring.params['bar'].type_name == 'int'
    assert docstring.returns.description == 'description'

# Generated at 2022-06-17 18:20:54.501217
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: Foo parameter
    :param bar: Bar parameter
    :returns: Return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "foo": "Foo parameter",
        "bar": "Bar parameter",
    }
    assert docstring.returns == "Return value"
    assert docstring.meta == {
        "param": {
            "foo": "Foo parameter",
            "bar": "Bar parameter",
        },
        "returns": "Return value",
    }
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:21:06.132653
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.meta['x']['type'] == 'int'
    assert docstring.meta['x']['desc'] == 'x'
    assert docstring.meta['y']['type'] == 'int'
    assert docstring.meta['y']['desc'] == 'y'
    assert docstring.returns['desc'] == 'x + y'
    assert docstring.returns['type'] == 'int'


# Generated at 2022-06-17 18:21:17.002202
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.meta == {}
    assert docstring.style == Style.google

    text = '''
    This is a docstring.

    This is a long description.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.meta == {}
    assert docstring.style == Style.google


# Generated at 2022-06-17 18:21:27.594000
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.meta['x']['type'] == 'int'
    assert docstring.meta['x']['desc'] == 'x'
    assert docstring.returns['type'] == 'int'
    assert docstring.returns['desc'] == 'x'

# Generated at 2022-06-17 18:21:37.629976
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: Foo param
    :param bar: Bar param
    :returns: Return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"foo": "Foo param", "bar": "Bar param"}
    assert docstring.returns == "Return value"
    assert docstring.meta == {"param": ["foo", "bar"], "returns": []}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:21:45.336709
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["x"] == "x"
    assert docstring.meta["y"] == "y"
    assert docstring.meta["returns"] == "x + y"
    assert docstring.meta["rtype"] == "int"
    assert docstring.meta["type"] == {"x": "int", "y": "int"}

# Generated at 2022-06-17 18:21:49.473334
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring
    """
    doc = parse(text)
    assert doc.short_description == "This is a test docstring"


# Generated at 2022-06-17 18:21:55.744841
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is a foo
    :type foo: str
    :param bar: this is a bar
    :type bar: int
    :returns: this is a return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['foo']['type'] == 'str'
    assert docstring.meta['foo']['desc'] == 'this is a foo'
    assert docstring.meta['bar']['type'] == 'int'
    assert docstring.meta['bar']['desc'] == 'this is a bar'
    assert docstring.returns['desc'] == 'this is a return'

# Generated at 2022-06-17 18:22:00.980122
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a formatted string
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params['name'].description == "name of the person"
    assert docstring.params['age'].description == "age of the person"
    assert docstring.returns.description == "a formatted string"
    assert docstring.raises['ValueError'].description == "if age is negative"

# Generated at 2022-06-17 18:22:07.505493
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param a: a
    :param b: b
    :returns: c
    """
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        meta={
            'param': [
                {
                    'name': 'a',
                    'type': None,
                    'description': 'a'
                },
                {
                    'name': 'b',
                    'type': None,
                    'description': 'b'
                }
            ],
            'returns': {
                'type': None,
                'description': 'c'
            }
        }
    )

# Generated at 2022-06-17 18:22:11.474882
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        returns=None,
        raises=None,
        meta={}
    )

# Generated at 2022-06-17 18:22:22.219055
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type to be raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.returns == "The return value."
    assert docstring.return_type == ""
    assert docstring.raises == "The exception type to be raised."
    assert docstring.yields == ""
    assert docstring.meta["arg1"] == "The first argument."
    assert docstring.meta["arg2"] == "The second argument."
    assert docstring.meta["keyError"]

# Generated at 2022-06-17 18:22:33.055323
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a function.'
    assert doc.long_description == ''
    assert doc.meta['x']['type'] == 'int'
    assert doc.meta['x']['desc'] == 'x'
    assert doc.meta['y']['type'] == 'int'
    assert doc.meta['y']['desc'] == 'y'
    assert doc.returns['desc'] == 'x + y'
    assert doc.returns['type'] == 'int'


# Generated at 2022-06-17 18:22:46.447904
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {'arg1': 'The first argument.'},
        {'arg2': 'The second argument.'}
    ]
    assert docstring.returns == [{'returns': 'Description of return value.'}]
    assert docstring.raises == [{'keyError': 'raises an exception'}]

# Generated at 2022-06-17 18:22:57.706627
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param test: test parameter
    :type test: int
    :returns: test return
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['test'].description == 'test parameter'
    assert docstring.params['test'].type == 'int'
    assert docstring.returns.description == 'test return'
    assert docstring.returns.type == 'str'
    assert docstring.meta == {'param': {'test': {'description': 'test parameter', 'type': 'int'}}, 'returns': {'description': 'test return', 'type': 'str'}}

# Generated at 2022-06-17 18:23:04.551684
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    :raises Exception: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1

# Generated at 2022-06-17 18:23:16.465212
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.
    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].arg_name == 'arg2'
    assert docstring.params['arg2'].description == 'The second argument.'
    assert docstring.returns.description == 'None'

# Generated at 2022-06-17 18:23:26.954092
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :returns: return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "parameter a"
    assert docstring.params['a'].annotation == "int"
    assert docstring.params['b'].description == "parameter b"
    assert docstring.params['b'].annotation == "str"
    assert docstring.returns.description == "return value"
    assert docstring.returns.annotation == "float"

# Generated at 2022-06-17 18:23:36.353676
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :rtype: Person
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "name",
            "type": "str",
            "description": "name of the person",
            "default": None,
        },
        {
            "name": "age",
            "type": "int",
            "description": "age of the person",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:23:43.851609
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a test parameter
    :type a: int
    :returns: a test return value
    :rtype: int
    """
    d = parse(text)
    assert d.short_description == "This is a test function."
    assert d.long_description == ""
    assert d.params == [("a", "a test parameter", "int")]
    assert d.returns == ("a test return value", "int")
    assert d.meta == {}


# Generated at 2022-06-17 18:23:54.170468
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :returns: a + b
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "parameter a",
        "b": "parameter b"
    }
    assert docstring.returns == "a + b"
    assert docstring.return_type == "str"
    assert docstring.meta == {
        "param a": "int",
        "param b": "str",
        "returns": "str"
    }


# Generated at 2022-06-17 18:24:03.441653
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "The return value."
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:24:12.779691
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: str
    :returns: something
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "first parameter",
        "b": "second parameter",
    }
    assert docstring.returns == "something"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
        "returns": "int",
    }


# Generated at 2022-06-17 18:24:23.748713
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].description == 'another parameter'
    assert docstring.returns.description == 'a return value'


# Generated at 2022-06-17 18:24:32.268804
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["arg1"] == "The first argument."
    assert docstring.meta["arg2"] == "The second argument."
    assert docstring.meta["returns"] == "Description of return value."
    assert docstring.meta["raises"] == "raises an exception"

# Generated at 2022-06-17 18:24:41.131964
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "Description of return value."
    assert docstring.raises == {"keyError": "raises an exception"}
    assert docstring.meta == {}

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:24:51.589765
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param name: The name to use.
    :type name: str.
    :param state: Current state to be in.
    :type state: bool.
    :returns: int -- the return code.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {
        "name": "The name to use.",
        "state": "Current state to be in.",
    }
    assert docstring.returns == "the return code."
    assert docstring.return_type == "int"

# Generated at 2022-06-17 18:25:03.601481
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: The x parameter.
    :type x: int
    :param y: The y parameter.
    :type y: int
    :returns: The return value.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].description == "The x parameter."
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].description == "The y parameter."

# Generated at 2022-06-17 18:25:09.077298
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    '''
    assert parse(text) == Docstring(
        content='This is a test docstring.',
        returns=Docstring.Return('None'),
        args=[
            Docstring.Arg('arg1', 'The first argument.'),
            Docstring.Arg('arg2', 'The second argument.')
        ]
    )

# Generated at 2022-06-17 18:25:18.247802
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: person's name and age
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].description == "name of the person"
    assert docstring.params[0].annotation == "str"
    assert docstring.params[0].default == None
    assert docstring.params[1].arg_name == "age"

# Generated at 2022-06-17 18:25:25.955360
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param x: x
    :param y: y
    :returns: x + y
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == {'x': 'x', 'y': 'y'}
    assert docstring.returns == 'x + y'
    assert docstring.meta == {'param': {'x': 'x', 'y': 'y'}, 'returns': 'x + y'}


# Generated at 2022-06-17 18:25:35.671714
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:25:45.363297
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is a parameter
    :type foo: str
    :param bar: this is another parameter
    :type bar: int
    :returns: description of return value
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'this is a parameter'
    assert docstring.params['foo'].type_name == 'str'
    assert docstring.params['bar'].description == 'this is another parameter'
    assert docstring.params['bar'].type_name == 'int'
    assert docstring.returns.description == 'description of return value'
    assert docstring

# Generated at 2022-06-17 18:25:57.556196
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: This is foo.
    :type foo: int
    :param bar: This is bar.
    :type bar: str
    :returns: This is the return value.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params["foo"].description == "This is foo."
    assert docstring.params["foo"].type_name == "int"
    assert docstring.params["bar"].description == "This is bar."
    assert docstring.params["bar"].type_name == "str"
    assert docstring.returns.description == "This is the return value."
    assert doc

# Generated at 2022-06-17 18:26:08.052642
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a is a parameter
    :type a: int
    :param b: b is a parameter
    :type b: str
    :returns: a + b
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a is a parameter'
    assert docstring.params['b'] == 'b is a parameter'
    assert docstring.returns == 'a + b'
    assert docstring.rtype == 'int'
    assert docstring.meta == {'a': 'int', 'b': 'str'}

if __name__ == '__main__':
    test

# Generated at 2022-06-17 18:26:14.803638
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [("x", "x", "int")]
    assert docstring.returns == ("x", "int")
    assert docstring.meta == {}


# Generated at 2022-06-17 18:26:25.764651
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params["a"].description == "a parameter"
    assert docstring.params["a"].type_name == "int"
    assert docstring.params["b"].description == "another parameter"
    assert docstring.params["b"].type_name == "str"
    assert docstring.returns.description == "something"
    assert docstring.returns.type_name == "float"
    assert docstring

# Generated at 2022-06-17 18:26:34.525637
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: Description of return value.
    :rtype: bool
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].arg_type == 'int'
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[1].arg_name == 'arg2'
    assert docstring