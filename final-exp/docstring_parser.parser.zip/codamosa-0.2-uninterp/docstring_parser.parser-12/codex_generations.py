

# Generated at 2022-06-17 18:16:40.379786
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param int x: x
    :param int y: y
    :returns: x + y
    """
    doc = parse(text)
    assert doc.short_description == "This is a function."
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == "x"
    assert doc.params[0].type_name == "int"
    assert doc.params[0].description == "x"
    assert doc.params[1].arg_name == "y"
    assert doc.params[1].type_name == "int"
    assert doc.params[1].description == "y"
    assert doc.returns.type_name == ""

# Generated at 2022-06-17 18:16:50.689183
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    It has a few lines.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a test docstring."
    assert parsed.long_description == "It has a few lines."
    assert parsed.meta == {}
    assert parsed.style == Style.numpy
    assert parsed.lines == [
        "This is a test docstring.",
        "It has a few lines.",
    ]


# Generated at 2022-06-17 18:16:58.750550
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["arg1"] == "The first argument."
    assert docstring.meta["param"]["arg2"] == "The second argument."
    assert docstring.meta["returns"] == "Description of return value."
    assert docstring.meta["raises"]["keyError"] == "raises an exception"


# Generated at 2022-06-17 18:17:07.965769
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
    assert len

# Generated at 2022-06-17 18:17:13.253848
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["x"].description == "x"
    assert docstring.meta["param"]["y"].description == "y"
    assert docstring.meta["return"].description == "x + y"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:17:20.157629
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["arg1"] == "the first argument"
    assert docstring.meta["arg2"] == "the second argument"
    assert docstring.meta["returns"] == "None"

# Generated at 2022-06-17 18:17:31.375314
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert docstring.returns == "Description of return value."
    assert docstring.raises == [("keyError", "raises an exception")]

# Generated at 2022-06-17 18:17:42.451290
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param name: name of the person
    :type name: str
    :param age: age of the person
    :type age: int
    :returns: a person
    :rtype: Person
    """
    doc = parse(text)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == "name"
    assert doc.params[0].description == "name of the person"
    assert doc.params[0].type_name == "str"
    assert doc.params[1].arg_name == "age"
    assert doc.params[1].description == "age of the person"

# Generated at 2022-06-17 18:17:54.438881
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta == {}
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.yields == None
    assert docstring.warnings == None
    assert docstring.attributes == None
    assert docstring.methods == None
    assert docstring.see_also == None
    assert docstring.notes == None
    assert docstring.references == None
    assert docstring.examples == None
    assert docstring.index == None
    assert docstring.deprecated == None
    assert docstring.todo == None
    assert doc

# Generated at 2022-06-17 18:18:04.737984
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: str
    :returns: return value
    :rtype: float
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'first parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'second parameter'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'return value'
    assert docstring.returns.type_name == 'float'


# Generated at 2022-06-17 18:18:19.722154
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(
        summary="",
        description="",
        returns=None,
        raises=None,
        meta={},
        examples=[],
    )
    assert parse("Summary.") == Docstring(
        summary="Summary.",
        description="",
        returns=None,
        raises=None,
        meta={},
        examples=[],
    )
    assert parse("Summary.\n\nDescription.") == Docstring(
        summary="Summary.",
        description="Description.",
        returns=None,
        raises=None,
        meta={},
        examples=[],
    )

# Generated at 2022-06-17 18:18:28.161433
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: first parameter
    :param str b: second parameter
    :returns: something
    :raises ValueError: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'first parameter'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].type_name == 'str'

# Generated at 2022-06-17 18:18:34.756262
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    assert parse(docstring) == Docstring(
        content='This is a test docstring.',
        returns='Description of return value.',
        args=['arg1: The first argument.', 'arg2: The second argument.'],
        raises=['keyError: raises an exception'],
        meta={},
    )

# Generated at 2022-06-17 18:18:44.348722
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    text = """
    This is a summary.

    This is a description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = parse(text)
    assert docstring.summary == 'This is a summary.'
    assert docstring.description == 'This is a description.'
    assert docstring.returns.type_name == 'bool'
    assert docstring.returns.description == 'The return value. True for success, False otherwise.'
    assert docstring.params['arg1'].type_name == 'int'
    assert docstring.params['arg1'].description == 'The first argument.'

# Generated at 2022-06-17 18:18:52.879585
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: int
    """
    d = parse(text)
    assert d.short_description == "This is a test function."
    assert d.long_description == ""
    assert len(d.params) == 2
    assert d.params[0].arg_name == "a"
    assert d.params[0].description == "a parameter"
    assert d.params[0].annotation == "int"
    assert d.params[1].arg_name == "b"
    assert d.params[1].description == "another parameter"
    assert d.params[1].annotation == "str"

# Generated at 2022-06-17 18:19:04.092221
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: first parameter
    :param str b: second parameter
    :return: return value
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {"name": "a", "type": "int", "desc": "first parameter"},
        {"name": "b", "type": "str", "desc": "second parameter"},
    ]
    assert docstring.returns == {"type": "int", "desc": "return value"}
    assert docstring.meta == {}


# Generated at 2022-06-17 18:19:10.267937
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {"x": "x", "y": "y"}
    assert docstring.returns == "x + y"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:19:17.486159
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param x: test parameter
    :type x: int
    :returns: test return
    :rtype: int
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a test function.'
    assert doc.long_description == ''
    assert doc.params[0].arg_name == 'x'
    assert doc.params[0].type_name == 'int'
    assert doc.params[0].description == 'test parameter'
    assert doc.returns.type_name == 'int'
    assert doc.returns.description == 'test return'

# Generated at 2022-06-17 18:19:25.030253
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == [('x', 'x', 'int'), ('y', 'y', 'float')]
    assert docstring.returns == ('x + y', 'float')
    assert docstring.meta == {'param x': 'x', 'type x': 'int', 'param y': 'y', 'type y': 'float', 'returns': 'x + y', 'rtype': 'float'}

# Generated at 2022-06-17 18:19:35.366999
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param str a: This is a test parameter.
    :param int b: This is another test parameter.
    :returns: This is a test return.
    :raises ValueError: This is a test exception.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'This is a test parameter.'
    assert docstring.params['b'].description == 'This is another test parameter.'
    assert docstring.returns.description == 'This is a test return.'
    assert docstring.exceptions['ValueError'].description == 'This is a test exception.'


# Generated at 2022-06-17 18:19:53.618458
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: The x value
    :type x: int
    :param y: The y value
    :type y: int
    :returns: The sum of x and y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "x": "The x value",
        "y": "The y value",
    }
    assert docstring.returns == "The sum of x and y"
    assert docstring.return_type == "int"
    assert docstring.meta == {
        "x": "int",
        "y": "int",
    }

# Unit

# Generated at 2022-06-17 18:20:02.083181
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x value
    :type x: int
    :param y: y value
    :type y: int
    :returns: sum of x and y
    :rtype: int
    """

    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "x value"
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].type_name == "int"
    assert docstring

# Generated at 2022-06-17 18:20:12.158517
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str param1: The first parameter.
    :param int param2: The second parameter.
    :returns: The return value.
    :raises ValueError: If `param2` is equal to `param1`.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'param1'
    assert docstring.params[0].type_name == 'str'
    assert docstring.params[0].description == 'The first parameter.'
    assert docstring.params[1].arg_name == 'param2'

# Generated at 2022-06-17 18:20:21.519554
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: this is a foo
    :type foo: str
    :param bar: this is a bar
    :type bar: int
    :returns: this is a return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "foo": "this is a foo",
        "bar": "this is a bar"
    }
    assert docstring.returns == "this is a return"
    assert docstring.return_type == "str"

# Generated at 2022-06-17 18:20:29.391909
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param foo: foo bar
    :param bar: bar foo
    :returns: foobar
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'] == 'foo bar'
    assert docstring.params['bar'] == 'bar foo'
    assert docstring.returns == 'foobar'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:20:39.970724
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a return"
    assert docstring.raises['keyError'] == "raises an exception"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:20:47.222712
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    assert docstring.meta['arg1']['type'] == 'param'
    assert docstring.meta['arg1']['arg_name'] == 'arg1'
    assert docstring.meta['arg1']['description'] == 'The first argument.'

# Generated at 2022-06-17 18:20:54.555088
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print name or not.
    :type state: bool.
    :returns: str -- the result.
    '''
    assert parse(text) == Docstring(
        content='This is a test docstring.',
        returns=('str', 'the result.'),
        params=[
            ('name', 'The name to use.', 'str.'),
            ('state', 'Whether to print name or not.', 'bool.')
        ]
    )


# Generated at 2022-06-17 18:21:06.177102
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"
    assert docstring.params

# Generated at 2022-06-17 18:21:17.051818
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "None"
    assert docstring.returns.type_name == ""
    assert docstring.raises[0].type_name == ""
   

# Generated at 2022-06-17 18:21:28.701731
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: parameter a
    :param b: parameter b
    :returns: return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params == {'a': 'parameter a', 'b': 'parameter b'}
    assert docstring.returns == 'return value'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:21:36.799168
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["a"] == "a parameter"
    assert docstring.meta["param"]["b"] == "another parameter"
    assert docstring.meta["returns"] == "a return value"

# Generated at 2022-06-17 18:21:44.544405
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:21:54.388144
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param a: a
    :param b: b
    :returns: c
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['a'] == 'a'
    assert docstring.meta['param']['b'] == 'b'
    assert docstring.meta['returns'] == 'c'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:21:57.661703
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:22:07.032807
# Unit test for function parse
def test_parse():
    text = """
    This is a test
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test"
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.yields == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None

# Generated at 2022-06-17 18:22:14.907042
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    assert parse(docstring) == Docstring(
        summary='This is a test docstring.',
        description='',
        params=[
            ('a', 'a parameter'),
            ('b', 'another parameter'),
        ],
        returns='something',
        meta={},
    )

    docstring = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """

# Generated at 2022-06-17 18:22:23.766012
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """
    assert parse(text) == Docstring(
        summary="This is a function.",
        description="",
        returns=Docstring.Return(
            description="Description of return value.",
            type="int"
        ),
        params=[
            Docstring.Param(
                name="arg1",
                description="The first argument.",
                type="int"
            ),
            Docstring.Param(
                name="arg2",
                description="The second argument.",
                type="str, optional"
            )
        ]
    )

# Generated at 2022-06-17 18:22:33.339558
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "Description of return value."
    assert docstring.params['arg1'].description == "The first argument."
    assert docstring.params['arg2'].description == "The second argument."

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:22:44.978927
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'
    assert docstring.params[1].description == 'The second argument.'
    assert docstring.returns.description == 'Description of return value.'
    assert len

# Generated at 2022-06-17 18:22:58.689176
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """

# Generated at 2022-06-17 18:23:07.077247
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: Foo
    :param bar: Bar
    :returns: Baz
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {'foo': 'Foo', 'bar': 'Bar'}
    assert docstring.returns == 'Baz'
    assert docstring.returns_description == ''
    assert docstring.meta == {'param': ['foo', 'bar'], 'returns': ['returns']}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:23:17.813788
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].arg_name == 'arg2'
    assert docstring.params['arg2'].description == 'The second argument.'

# Generated at 2022-06-17 18:23:27.756985
# Unit test for function parse

# Generated at 2022-06-17 18:23:37.179057
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'a string'

# Generated at 2022-06-17 18:23:47.925015
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    text = '''
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    '''
    docstring = parse(text)
    assert isinstance(docstring, GoogleStyle)
    assert docstring.summary == 'This is a test function.'
    assert docstring.args == [('arg1', 'int', 'The first argument.'), ('arg2', 'str', 'The second argument.')]
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.meta == {}
    assert docstring.description == ''
    assert docstring.extended_summary == ''
    assert docstring.extended_description == ''
    assert docstring.examples == ''

# Generated at 2022-06-17 18:23:52.428771
# Unit test for function parse
def test_parse():
    text = """
    This is a test.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    assert parse(text) == Docstring(
        content='This is a test.',
        meta={
            'x': {
                'type': 'int',
                'desc': 'x',
            },
            'returns': {
                'type': 'int',
                'desc': 'x',
            },
        },
    )

# Generated at 2022-06-17 18:24:03.445946
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "Description of return value."
    assert docstring.raises == {"keyError": "raises an exception"}

# Generated at 2022-06-17 18:24:13.338800
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
    assert len

# Generated at 2022-06-17 18:24:23.378768
# Unit test for function parse

# Generated at 2022-06-17 18:24:37.202668
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == "a return value"
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'a return value'}


# Generated at 2022-06-17 18:24:44.197834
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: x value
    :type x: int
    :param y: y value
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].description == "x value"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].description == "y value"
    assert docstring.params

# Generated at 2022-06-17 18:24:55.067818
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: Description of return value.
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.returns.description == 'Description of return value.'
    assert docstring.returns.type_name == 'bool'
    assert docstring.args[0].arg_name == 'arg1'
    assert docstring.args[0].type_name == 'int'
    assert docstring.args[0].description == 'The first argument.'
    assert doc

# Generated at 2022-06-17 18:25:00.940280
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: float
    :returns: sum of a and b
    :rtype: float
    """
    parsed = parse(text)
    assert parsed.short_description == "This is a test function."
    assert parsed.long_description == ""
    assert parsed.returns.description == "sum of a and b"
    assert parsed.returns.type_name == "float"
    assert parsed.params["a"].description == "first parameter"
    assert parsed.params["a"].type_name == "int"
    assert parsed.params["b"].description == "second parameter"
    assert parsed.params["b"].type_name == "float"
    assert parsed

# Generated at 2022-06-17 18:25:10.288441
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a test parameter
    :type a: int
    :param b: another test parameter
    :type b: str
    :returns: a test return value
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "a test parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"

# Generated at 2022-06-17 18:25:18.846921
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text, style=Style.google)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "x + y"
    assert docstring.returns.type_name == "int"
    assert docstring.params["x"].description == "x"
    assert docstring.params["x"].type_name == "int"
    assert docstring.params["y"].description == "y"
    assert docstring.params["y"].type_

# Generated at 2022-06-17 18:25:27.528169
# Unit test for function parse
def test_parse():
    """Test function parse"""
    from docstring_parser.styles import GoogleStyle
    from docstring_parser.common import Docstring
    text = """
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description

# Generated at 2022-06-17 18:25:37.789141
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import Style
    text = '''
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    '''
    docstring = parse(text, style=Style.numpy)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'first parameter'
    assert docstring.params['b'] == 'second parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {}
    assert docstring.examples == []
    assert docstring.raises == {}
    assert docstring.yields == {}
    assert docstring.warns

# Generated at 2022-06-17 18:25:43.938455
# Unit test for function parse
def test_parse():
    text = """
    :param name: The name to use.
    :param state: Whether to use state.
    """
    docstring = parse(text)
    assert docstring.params[0].arg_name == 'name'
    assert docstring.params[0].description == 'The name to use.'
    assert docstring.params[1].arg_name == 'state'
    assert docstring.params[1].description == 'Whether to use state.'


# Generated at 2022-06-17 18:25:56.220057
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: first parameter
    :param str b: second parameter
    :return: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "first parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"
    assert docstring.params[1].description == "second parameter"

# Generated at 2022-06-17 18:26:06.777035
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param test: test parameter
    :returns: test return
    """
    assert parse(text).short_description == "This is a test function."
    assert parse(text).long_description == ""
    assert parse(text).returns.description == "test return"
    assert parse(text).params["test"].description == "test parameter"
    assert parse(text).meta == {}


# Generated at 2022-06-17 18:26:15.206092
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: A parameter
    :type a: int
    :returns: A return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [("a", "A parameter", "int")]
    assert docstring.returns == ("A return value", "str")
    assert docstring.meta == {"param a": "A parameter", "type a": "int", "returns": "A return value", "rtype": "str"}


# Generated at 2022-06-17 18:26:25.460268
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: this is a test parameter
    :param b: this is another test parameter
    :returns: this is a test return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'this is a test parameter'
    assert docstring.params['b'] == 'this is another test parameter'
    assert docstring.returns == 'this is a test return value'
    assert docstring.raises == {}
    assert docstring.meta == {}
    assert docstring.style == Style.google


# Generated at 2022-06-17 18:26:34.300415
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 3
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"