

# Generated at 2022-06-17 18:16:52.897898
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a string
    :raises ValueError: if age is negative
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params == [
        {
            "name": "name",
            "type": "str",
            "description": "name of the person",
            "default": None,
        },
        {
            "name": "age",
            "type": "int",
            "description": "age of the person",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:16:59.430435
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert doc.returns == "None"
    assert doc.raises == []
    assert doc.meta == {}

# Generated at 2022-06-17 18:17:05.278653
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether or not to say hello.
    :type state: bool.
    :returns: None.
    :raises ValueError: If `name` is empty.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["parameters"]["name"]["description"] == "The name to use."
    assert docstring.meta["parameters"]["name"]["type"] == "str."
    assert docstring.meta["parameters"]["state"]["description"] == "Whether or not to say hello."
    assert docstring

# Generated at 2022-06-17 18:17:12.760240
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"

# Generated at 2022-06-17 18:17:21.989093
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Hello world") == Docstring(content="Hello world")
    assert parse("Hello world", style=Style.numpy) == Docstring(content="Hello world")
    assert parse("Hello world", style=Style.google) == Docstring(content="Hello world")
    assert parse("Hello world", style=Style.sphinx) == Docstring(content="Hello world")
    assert parse("Hello world", style=Style.sphinx) == Docstring(content="Hello world")
    assert parse("Hello world", style=Style.sphinx) == Docstring(content="Hello world")
    assert parse("Hello world", style=Style.sphinx) == Docstring(content="Hello world")
    assert parse("Hello world", style=Style.sphinx) == Docstring(content="Hello world")


# Generated at 2022-06-17 18:17:28.663137
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"
    assert docstring.returns.description == "something"
    assert docstring.raises == []
    assert docstring.meta == {}

# Generated at 2022-06-17 18:17:40.200919
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: Description of return value.
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].arg_type == "int"
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].arg_name == "arg2"
    assert docstring.meta

# Generated at 2022-06-17 18:17:53.963023
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.style == Style.google
    assert docstring.returns is None
    assert docstring.return_type is None
    assert docstring.yields is None
    assert docstring.yield_type is None
    assert docstring.raises is None
    assert docstring.warns is None
    assert docstring.warn_type is None
    assert docstring.others == []
    assert docstring.params == []
    assert docstring.attributes == []
    assert docstring.variables == []
    assert docstring.examples == []


# Generated at 2022-06-17 18:18:03.908543
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:18:14.367698
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: description of return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "foo"
    assert docstring.params[0].description == "This is a parameter."
    assert docstring.params[0].type_name == "str"
    assert docstring.params[1].arg_name == "bar"
    assert docstring.params[1].description == "This is another parameter."

# Generated at 2022-06-17 18:18:27.918111
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: This is a test parameter.
    :param int b: This is another test parameter.
    :returns: This is a test return.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "This is a test parameter."
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "int"
    assert docstring.params[1].description == "This is another test parameter."

# Generated at 2022-06-17 18:18:37.120612
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert docstring.returns == "Description of return value."
    assert docstring.raises == [("keyError", "raises an exception")]
    assert docstring.meta == {}



# Generated at 2022-06-17 18:18:43.877400
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param a: parameter a
    :param b: parameter b
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "parameter a"
    assert docstring.params['b'] == "parameter b"
    assert docstring.returns == "return value"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:18:50.079765
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param int a: the first parameter
    :param str b: the second parameter
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'the first parameter'
    assert docstring.params['b'].description == 'the second parameter'
    assert docstring.returns.description == 'the return value'

# Generated at 2022-06-17 18:18:54.200683
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "name": "name of the person",
        "age": "age of the person",
    }
    assert docstring.returns == "a person"
    assert docstring.raises == {"ValueError": "if age is negative"}

# Generated at 2022-06-17 18:19:02.785807
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a
    :param b: b
    :returns: returns
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["a"] == "a"
    assert docstring.meta["param"]["b"] == "b"
    assert docstring.meta["returns"] == "returns"


# Generated at 2022-06-17 18:19:10.404749
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: foo
    :param bar: bar
    :returns: baz
    """
    assert parse(text) == Docstring(
        summary="This is a docstring.",
        description="",
        meta={
            "param": [
                {"name": "foo", "type": None, "desc": "foo"},
                {"name": "bar", "type": None, "desc": "bar"},
            ],
            "returns": [{"type": None, "desc": "baz"}],
        },
    )

# Generated at 2022-06-17 18:19:18.732665
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: This is a parameter
    :type a: int
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "This is a parameter"
    assert docstring.params[0].type_name == "int"
    assert docstring.returns.description == "None"
    assert docstring.returns.type_name == ""
    assert docstring.raises[0].type_name == "keyError"

# Generated at 2022-06-17 18:19:24.605614
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    assert parse(text).short_description == "This is a test docstring."
    assert parse(text).long_description == ""
    assert parse(text).params == {
        "a": "first parameter",
        "b": "second parameter"
    }
    assert parse(text).returns == "something"
    assert parse(text).raises == {}
    assert parse(text).meta == {}
    assert parse(text).style == Style.numpy


# Generated at 2022-06-17 18:19:27.694966
# Unit test for function parse
def test_parse():
    text = '''
    This is a test.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test.'


# Generated at 2022-06-17 18:19:38.222311
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print 'hello' or 'goodbye'.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['name'].arg_type == 'str.'
    assert docstring.params['state'].arg_type == 'bool.'
    assert docstring.returns.arg_type == 'None.'
    assert len(docstring.raises) == 2
    assert doc

# Generated at 2022-06-17 18:19:46.541628
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.returns.description == 'a return value'

# Generated at 2022-06-17 18:19:57.496928
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: first parameter
    :param bar: second parameter
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"foo": "first parameter", "bar": "second parameter"}
    assert docstring.returns == "return value"
    assert docstring.meta == {"param": ["foo", "bar"], "returns": ["return value"]}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:20:08.182158
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :type b: str
    :returns: return value
    :rtype: float
    """
    doc = parse(text)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params == [
        ("a", "parameter a", "int"),
        ("b", "parameter b", "str"),
    ]
    assert doc.returns == ("return value", "float")
    assert doc.meta == {}


# Generated at 2022-06-17 18:20:17.810461
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises['keyError'] == "raises an exception"

# Generated at 2022-06-17 18:20:24.345703
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :param b: parameter b
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "parameter a"
    assert docstring.params['b'] == "parameter b"
    assert docstring.returns == "return value"
    assert docstring.meta == {}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:20:32.309031
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'something'}


# Generated at 2022-06-17 18:20:39.463751
# Unit test for function parse
def test_parse():
    text = """
    This is a test.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.yields == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None

# Generated at 2022-06-17 18:20:46.846383
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.meta == {}
    assert doc.returns == None
    assert doc.raises == None
    assert doc.yields == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
    assert doc.warns == None
   

# Generated at 2022-06-17 18:20:55.035820
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1'] == 'the first argument'
    assert docstring.meta['arg2'] == 'the second argument'
    assert docstring.meta['returns'] == 'None'

# Generated at 2022-06-17 18:21:08.935763
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type == 'str'
    assert docstring.returns.description == 'something'
    assert docstring.returns.type == 'float'



# Generated at 2022-06-17 18:21:19.045411
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.style == Style.numpy
    assert docstring.returns == None
    assert docstring.return_type == None
    assert docstring.yields == None
    assert docstring.yield_type == None
    assert docstring.raises == None
    assert docstring.warns == None
    assert docstring.warn_type == None
    assert docstring.other == None
    assert docstring.params == None
    assert docstring.attributes == None
    assert docstring.examples == None
    assert docstring.seealso == None
   

# Generated at 2022-06-17 18:21:29.516423
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: this is a
    :type a: int
    :param b: this is b
    :type b: str
    :returns: this is return
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {'name': 'a', 'type': 'int', 'description': 'this is a'},
        {'name': 'b', 'type': 'str', 'description': 'this is b'},
    ]
    assert docstring.returns == {'type': 'float', 'description': 'this is return'}

# Generated at 2022-06-17 18:21:40.839234
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: foo
    :type foo: str
    :param bar: bar
    :type bar: int
    :returns: baz
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("foo", "foo", "str"),
        ("bar", "bar", "int"),
    ]
    assert docstring.returns == ("baz", "float")
    assert docstring.meta == {
        "foo": "foo",
        "bar": "bar",
        "returns": "baz",
        "rtype": "float",
    }



# Generated at 2022-06-17 18:21:52.688215
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "None"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:22:03.876849
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "The return value."

# Generated at 2022-06-17 18:22:13.444048
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a dict containing the name and age
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "name",
            "type": "str",
            "description": "name of the person",
            "default": None,
        },
        {
            "name": "age",
            "type": "int",
            "description": "age of the person",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:22:23.267715
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.style == Style.google

    text = """
    This is a test docstring.

    This is a long description.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is a long description."
    assert docstring.meta == {}
    assert docstring.style == Style.google


# Generated at 2022-06-17 18:22:34.075951
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params['x'].arg_type == "int"
    assert docstring.params['x'].description == "x"
    assert docstring.params['y'].arg_type == "int"
    assert docstring.params['y'].description == "y"
    assert docstring.returns.arg_type == "int"
    assert docstring.returns.description == "x + y"

#

# Generated at 2022-06-17 18:22:40.418591
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params == {'arg1': 'The first argument.', 'arg2': 'The second argument.'}
    assert doc.returns == 'None'
    assert doc.meta == {'param': {'arg1': 'The first argument.', 'arg2': 'The second argument.'}, 'returns': 'None'}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:22:55.656837
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:23:06.084819
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.yields == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring.warns == None
    assert docstring

# Generated at 2022-06-17 18:23:15.080552
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "the first argument"
    assert docstring.params['arg2'] == "the second argument"
    assert docstring.returns == "the return value"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:23:25.493365
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param int a: This is a parameter.
    :param str b: This is a parameter.
    :returns: This is a return value.
    :raises ValueError: This is a raised exception.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'This is a parameter.'
    assert docstring.params['b'].description == 'This is a parameter.'
    assert docstring.returns.description == 'This is a return value.'
    assert docstring.raises['ValueError'].description == 'This is a raised exception.'

# Generated at 2022-06-17 18:23:30.576918
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1'] == 'The first argument.'
    assert docstring.meta['arg2'] == 'The second argument.'
    assert docstring.meta['returns'] == 'Description of return value.'
    assert docstring.meta['raises'] == 'raises an exception'

# Generated at 2022-06-17 18:23:39.358410
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:23:48.353289
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'a': 'a parameter', 'b': 'another parameter'}
    assert docstring.returns == 'something'
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'something'}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:23:50.275565
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'

# Generated at 2022-06-17 18:23:59.648096
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: This is a parameter.
    :type a: int
    :returns: This is a return.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'This is a parameter.'
    assert docstring.params['a'].type == 'int'
    assert docstring.returns.description == 'This is a return.'
    assert docstring.returns.type == 'str'

# Generated at 2022-06-17 18:24:06.267591
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    """
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        meta={
            'arg1': 'the first argument',
            'arg2': 'the second argument',
            'returns': 'the return value'
        }
    )

# Generated at 2022-06-17 18:24:16.003901
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.

    :param foo: Foo
    :param bar: Bar
    :returns: Baz
    """
    assert parse(docstring) == Docstring(
        content='This is a docstring.',
        returns='Baz',
        params=[
            ('foo', 'Foo'),
            ('bar', 'Bar'),
        ],
        meta={},
    )

# Generated at 2022-06-17 18:24:24.104281
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: test parameter
    :type a: int
    :returns: test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {'a': {'type': 'int', 'description': 'test parameter'}}
    assert docstring.returns == {'type': 'str', 'description': 'test return'}
    assert docstring.meta == {'param a': {'type': 'int', 'description': 'test parameter'},
                              'returns': {'type': 'str', 'description': 'test return'}}

# Generated at 2022-06-17 18:24:30.872675
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "a parameter"
    assert docstring.params['b'] == "another parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:24:37.638826
# Unit test for function parse
def test_parse():
    text = """
    This is a function.
    :param a: a
    :param b: b
    :returns: c
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a'
    assert docstring.params['b'] == 'b'
    assert docstring.returns == 'c'
    assert docstring.meta == {}

# Generated at 2022-06-17 18:24:44.421697
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "param1": "this is a first param",
        "param2": "this is a second param",
    }
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises == {"keyError": "raises an exception"}
    assert docstring.meta == {}
    assert docstring.style == Style.google

# Generated at 2022-06-17 18:24:53.693687
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: first param
    :param b: second param
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "something"
    assert docstring.params["a"].description == "first param"
    assert docstring.params["b"].description == "second param"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:25:04.498432
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params[0].arg_name == 'x'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'x'
    assert docstring.params[1].arg_name == 'y'
    assert docstring.params[1].type_name == 'int'
    assert docstring.params[1].description == 'y'

# Generated at 2022-06-17 18:25:12.514384
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['a'] == 'a parameter'
    assert docstring.meta['param']['b'] == 'another parameter'
    assert docstring.meta['returns'] == 'a return value'


# Generated at 2022-06-17 18:25:18.563295
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a
    :param b: b
    :returns: c
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [("a", "a"), ("b", "b")]
    assert docstring.returns == "c"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:25:27.420028
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print 'hello' or 'goodbye'.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a test docstring.'
    assert doc.long_description == ''
    assert doc.params == [
        {'name': 'name', 'type': 'str.', 'description': 'The name to use.'},
        {'name': 'state', 'type': 'bool.', 'description': 'Whether to print '
                                                         "'hello' or 'goodbye'."},
    ]

# Generated at 2022-06-17 18:25:41.674164
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: str
    :param arg2: The second argument.
    :type arg2: int, optional
    :returns: Description of return value.
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["arg1"]["type"] == "str"
    assert docstring.meta["arg1"]["desc"] == "The first argument."
    assert docstring.meta["arg2"]["type"] == "int, optional"
    assert docstring.meta["arg2"]["desc"] == "The second argument."
    assert docstring

# Generated at 2022-06-17 18:25:54.524841
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: This is a test parameter.
    :type a: int
    :returns: This is a test return.
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'This is a test parameter.'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.returns.description == 'This is a test return.'
    assert docstring.returns.type_name == 'str'


# Generated at 2022-06-17 18:26:06.505077
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param int a: first parameter
    :param str b: second parameter
    :returns: something
    :raises ValueError: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'first parameter'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].type_name == 'str'

# Generated at 2022-06-17 18:26:09.721814
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:26:16.803235
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param x: x
    :param y: y
    :returns: x + y
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params['x'] == 'x'
    assert docstring.params['y'] == 'y'
    assert docstring.returns == 'x + y'
    assert docstring.meta == {'param': {'x': 'x', 'y': 'y'}, 'returns': 'x + y'}


# Generated at 2022-06-17 18:26:25.556586
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Hello world") == Docstring(content="Hello world")
    assert parse("Hello world", style=Style.google) == Docstring(
        content="Hello world"
    )
    assert parse("Hello world", style=Style.numpy) == Docstring(
        content="Hello world"
    )
    assert parse("Hello world", style=Style.reST) == Docstring(
        content="Hello world"
    )
    assert parse("Hello world", style=Style.sphinx) == Docstring(
        content="Hello world"
    )
    assert parse("Hello world", style=Style.sphinx_napoleon) == Docstring(
        content="Hello world"
    )

# Generated at 2022-06-17 18:26:33.324131
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: This is a parameter.
    :type foo: int
    :returns: This is a return value.
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {'foo': 'This is a parameter.'}
    assert docstring.returns == 'This is a return value.'
    assert docstring.return_type == 'str'
    assert docstring.meta == {'param_types': {'foo': 'int'}}

# Generated at 2022-06-17 18:26:38.280062
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param test: test parameter
    :type test: str
    :returns: test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"test": "test parameter"}
    assert docstring.returns == "test return"
    assert docstring.meta == {"param_types": {"test": "str"}, "return_type": "str"}