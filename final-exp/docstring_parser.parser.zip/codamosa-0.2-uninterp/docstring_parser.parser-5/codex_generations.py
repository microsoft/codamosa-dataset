

# Generated at 2022-06-17 18:16:40.069921
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'


# Generated at 2022-06-17 18:16:52.778162
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["a"].description == "a parameter"
    assert docstring.params["a"].annotation == "int"
    assert docstring.returns.description == "a return value"
    assert docstring.returns.annotation == "str"

# Generated at 2022-06-17 18:16:54.712336
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.
    '''
    assert parse(text).short_description == 'This is a test docstring.'

# Generated at 2022-06-17 18:17:02.373436
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a + b
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"
    assert docstring

# Generated at 2022-06-17 18:17:10.870074
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param foo: This is a parameter.
    :type foo: str
    :param bar: This is another parameter.
    :type bar: int
    :returns: None
    :rtype: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['foo'].arg_type == 'str'
    assert docstring.params['foo'].description == 'This is a parameter.'
    assert docstring.params['bar'].arg_type == 'int'
    assert docstring.params['bar'].description == 'This is another parameter.'

# Generated at 2022-06-17 18:17:21.374917
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: person's name and age
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "name",
            "type": "str",
            "description": "name of the person",
            "default": None,
        },
        {
            "name": "age",
            "type": "int",
            "description": "age of the person",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:17:32.075746
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"

# Generated at 2022-06-17 18:17:42.778440
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: why you get a keyError
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['param1'] == "this is a first param"
    assert docstring.params['param2'] == "this is a second param"
    assert docstring.returns == "this is a description of what is returned"
    assert docstring.raises['keyError'] == "why you get a keyError"

# Generated at 2022-06-17 18:17:54.581535
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a string
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "a parameter"
    assert docstring.params['a'].annotation == "int"
    assert docstring.params['b'].description == "another parameter"
    assert docstring.params['b'].annotation == "str"
    assert docstring.returns.description == "a string"
    assert docstring.returns.annotation == "str"
   

# Generated at 2022-06-17 18:17:57.876902
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: foo
    :param bar: bar
    :returns: baz
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'foo': 'foo', 'bar': 'bar'}
    assert docstring.returns == 'baz'
    assert docstring.meta == {'param': {'foo': 'foo', 'bar': 'bar'}, 'returns': 'baz'}

# Generated at 2022-06-17 18:18:10.542534
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a return
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "param1": "this is a first param",
        "param2": "this is a second param",
    }
    assert docstring.returns == "this is a return"
    assert docstring.raises == {"keyError": "raises an exception"}

# Generated at 2022-06-17 18:18:21.054167
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person object
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {"name": "name", "type": "str", "desc": "name of the person"},
        {"name": "age", "type": "int", "desc": "age of the person"},
    ]
    assert docstring.returns == {"type": "", "desc": "a person object"}

# Generated at 2022-06-17 18:18:29.125183
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].arg_name == 'arg2'
    assert docstring.params['arg2'].description == 'The second argument.'

# Generated at 2022-06-17 18:18:38.236393
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.meta['parameters']['x']['description'] == 'x'
    assert docstring.meta['parameters']['x']['annotation'] == 'int'
    assert docstring.meta['returns']['description'] == 'x'
    assert docstring.meta['returns']['annotation'] == 'int'

# Generated at 2022-06-17 18:18:47.155167
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].description == 'another parameter'
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == 'a return value'
    assert len(docstring.raises) == 0

# Generated at 2022-06-17 18:18:53.401782
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.style == Style.google
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.yields == None


# Generated at 2022-06-17 18:19:02.985690
# Unit test for function parse
def test_parse():
    text = """
    This is a test.
    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test.'
    assert docstring.long_description == ''
    assert docstring.params['x'] == 'x'
    assert docstring.params['y'] == 'y'
    assert docstring.returns == 'x + y'
    assert docstring.meta == {'param': ['x', 'y'], 'returns': ['x + y']}

# Generated at 2022-06-17 18:19:10.269044
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "a parameter"
    assert docstring.params['b'] == "another parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:19:18.477045
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "a parameter"
    assert docstring.params['b'] == "another parameter"
    assert docstring.returns == "a return value"
    assert docstring.meta == {'a': 'a parameter', 'b': 'another parameter', 'returns': 'a return value'}
    assert docstring.style == Style.numpy
    assert docstring.to_str() == text


# Generated at 2022-06-17 18:19:24.531111
# Unit test for function parse
def test_parse():
    """
    Test function parse
    """
    text = '''
    This is a test function.

    :param int a: a is an integer
    :param str b: b is a string
    :returns: return a + b
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a is an integer'
    assert docstring.params['b'].description == 'b is a string'
    assert docstring.returns.description == 'return a + b'


# Generated at 2022-06-17 18:19:37.319397
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: the person's name and age
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.meta["parameters"]["name"].arg_type == "str"
    assert docstring.meta["parameters"]["name"].description == "name of the person"
    assert docstring.meta["parameters"]["age"].arg_type == "int"
    assert docstring.meta["parameters"]["age"].description == "age of the person"
    assert docstring.meta

# Generated at 2022-06-17 18:19:46.256164
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :rtype: Person
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['name'].description == 'name of the person'
    assert docstring.params['age'].description == 'age of the person'
    assert docstring.returns.description == 'a person'
    assert docstring.returns.type_name == 'Person'

# Generated at 2022-06-17 18:19:57.454722
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "The return value."
   

# Generated at 2022-06-17 18:20:09.715313
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: this is a
    :param b: this is b
    :returns: this is return
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "this is a"
    assert docstring.params['b'] == "this is b"
    assert docstring.returns == "this is return"
    assert docstring.meta == {}
    assert docstring.examples == []
    assert docstring.notes == []
    assert docstring.references == []
    assert docstring.see_also == []
    assert docstring.warnings == []
    assert docstring.warnings == []
    assert docstring.t

# Generated at 2022-06-17 18:20:18.642589
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param test: test parameter
    :type test: str
    :returns: test return
    :rtype: str
    '''
    d = parse(text)
    assert d.short_description == 'This is a test function.'
    assert d.long_description == ''
    assert d.meta['param'][0].arg_name == 'test'
    assert d.meta['param'][0].type_name == 'str'
    assert d.meta['param'][0].description == 'test parameter'
    assert d.meta['return'][0].type_name == 'str'
    assert d.meta['return'][0].description == 'test return'


# Generated at 2022-06-17 18:20:27.272057
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {'arg1': 'The first argument.'},
        {'arg2': 'The second argument.'}
    ]
    assert docstring.returns == [{'returns': 'Description of return value.'}]
    assert docstring.raises == [{'keyError': 'raises an exception'}]

# Generated at 2022-06-17 18:20:33.726354
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {"x": "x", "y": "y"}
    assert docstring.returns == "x + y"
    assert docstring.meta == {"param": {"x": "x", "y": "y"}, "returns": "x + y"}


# Generated at 2022-06-17 18:20:40.962769
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].type_name == 'int'
    assert docstring.params['b'].description == 'another parameter'
    assert docstring.params['b'].type_name == 'str'
    assert docstring.returns.description == 'something'
    assert docstring.returns.type_name == 'float'


# Generated at 2022-06-17 18:20:54.817919
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x value
    :param y: y value
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "x",
            "type": None,
            "description": "x value",
            "default": None,
        },
        {
            "name": "y",
            "type": None,
            "description": "y value",
            "default": None,
        },
    ]
    assert docstring.returns == {
        "type": None,
        "description": "x + y",
    }
    assert doc

# Generated at 2022-06-17 18:21:04.075206
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param foo: Foo
    :param bar: Bar
    :returns: Baz
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"foo": "Foo", "bar": "Bar"}
    assert docstring.returns == "Baz"
    assert docstring.meta == {"param": {"foo": "Foo", "bar": "Bar"}, "returns": "Baz"}


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:21:18.697352
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["arg1"]["type"] == "int"
    assert docstring.meta["arg1"]["description"] == "The first argument."
    assert docstring.meta["arg2"]["type"] == "str, optional"
    assert docstring.meta["arg2"]["description"] == "The second argument."
    assert docstring

# Generated at 2022-06-17 18:21:29.303382
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: the x value
    :type x: int
    :param y: the y value
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].description == "the x value"
    assert docstring.params[0].annotation == "int"
    assert docstring.params[0].default == ""
    assert docstring.params[1].arg_name == "y"

# Generated at 2022-06-17 18:21:40.711733
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].type_name == "str"
    assert doc

# Generated at 2022-06-17 18:21:52.276909
# Unit test for function parse
def test_parse():
    text = """
    This is a test.
    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["x"].description == "x"
    assert docstring.meta["param"]["y"].description == "y"
    assert docstring.meta["returns"].description == "x + y"


# Generated at 2022-06-17 18:22:02.457792
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'x': 'x', 'y': 'y'}
    assert docstring.returns == 'x + y'
    assert docstring.meta == {'x': 'int', 'y': 'int', 'returns': 'int'}


# Generated at 2022-06-17 18:22:12.140778
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: This is a test parameter
    :param str b: This is another test parameter
    :returns: This is the return value
    :raises ValueError: This is a raised exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "This is a test parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"

# Generated at 2022-06-17 18:22:22.784899
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.returns == None
    assert docstring.raises == None
    assert docstring.yields == None
    assert docstring.warns == None
    assert docstring.see_also == None
    assert docstring.notes == None
    assert docstring.references == None
    assert docstring.examples == None
    assert docstring.attributes == None
    assert docstring.methods == None
    assert docstring.deprecated == None
    assert docstring.todo == None
    assert docstring.versionadded == None
    assert docstring

# Generated at 2022-06-17 18:22:33.649677
# Unit test for function parse
def test_parse():
    assert parse("""\
        This is a docstring.

        :param foo: foo
        :type foo: str
        :param bar: bar
        :type bar: int
        :returns: baz
        :rtype: float
        """) == Docstring(
            summary="This is a docstring.",
            description="",
            meta={
                "param": [
                    ("foo", "foo", "str"),
                    ("bar", "bar", "int"),
                ],
                "returns": [
                    ("baz", "float"),
                ],
            },
        )


# Generated at 2022-06-17 18:22:44.818387
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: this is a test parameter
    :type a: int
    :returns: this is a test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "this is a test parameter"
    assert docstring.params[0].type_name == "int"
    assert docstring.returns.description == "this is a test return"
    assert docstring.returns.type_name == "str"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:22:57.172337
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :raises ValueError: if age is negative
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {
            "name": "name",
            "type": "str",
            "description": "name of the person",
            "default": None,
        },
        {
            "name": "age",
            "type": "int",
            "description": "age of the person",
            "default": None,
        },
    ]

# Generated at 2022-06-17 18:23:09.084121
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "first parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "second parameter"
    assert docstring.returns.description == "something"


# Generated at 2022-06-17 18:23:17.813559
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: this is a test parameter
    :type a: int
    :returns: this is a test return
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'this is a test parameter'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.returns.description == 'this is a test return'
    assert docstring.returns.annotation == 'str'

# Generated at 2022-06-17 18:23:26.257605
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str a: This is a test parameter.
    :param str b: This is another test parameter.
    :returns: This is a test return.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "This is a test parameter."
    assert docstring.params['b'].description == "This is another test parameter."
    assert docstring.returns.description == "This is a test return."


# Generated at 2022-06-17 18:23:34.776897
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["arg1"] == "The first argument."
    assert docstring.meta["arg2"] == "The second argument."
    assert docstring.meta["returns"] == "None"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:23:45.877937
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: this is a test parameter
    :type a: int
    :returns: this is a test return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": {
            "description": "this is a test parameter",
            "type": "int"
        }
    }
    assert docstring.returns == {
        "description": "this is a test return",
        "type": "str"
    }

# Generated at 2022-06-17 18:23:53.378089
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'
    assert docstring.params[1].description == 'The second argument.'
    assert docstring.returns.description == 'Description of return value.'
   

# Generated at 2022-06-17 18:24:04.233213
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring
    from docstring_parser.common import Docstring
    text = """
    This is a function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'The first argument.'
   

# Generated at 2022-06-17 18:24:13.843580
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params == {'x': 'x', 'y': 'y'}
    assert docstring.returns == "x + y"
    assert docstring.return_type == "int"
    assert docstring.meta == {'param_types': {'x': 'int', 'y': 'int'}}


# Generated at 2022-06-17 18:24:23.411550
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param str name: Name of the person
    :param int age: Age of the person
    :returns: True if the person is allowed to drink alcohol
    :raises ValueError: If the person is under 18
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["parameters"]["name"]["type"] == "str"
    assert docstring.meta["parameters"]["name"]["description"] == "Name of the person"
    assert docstring.meta["parameters"]["age"]["type"] == "int"
    assert docstring.meta["parameters"]["age"]["description"] == "Age of the person"

# Generated at 2022-06-17 18:24:30.247971
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "first parameter"
    assert docstring.params['b'] == "second parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:24:41.865019
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type to be raised.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        ("arg1", "The first argument."),
        ("arg2", "The second argument."),
    ]
    assert docstring.returns == "The return value."
    assert docstring.raises == [("keyError", "The exception type to be raised.")]
    assert docstring.meta == {}


# Generated at 2022-06-17 18:24:54.606539
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    :raises Exception: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "something"
    assert docstring.raises == {"Exception": "if something bad happens"}
    assert docstring.meta == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:24:59.359250
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x
    :type x: int
    :returns: x
    :rtype: int
    """
    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:25:08.713013
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: something
    :rtype: float
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params == {
        "a": "a parameter",
        "b": "another parameter",
    }
    assert docstring.returns == "something"
    assert docstring.meta == {
        "a": "int",
        "b": "str",
        "returns": "float",
    }


# Generated at 2022-06-17 18:25:17.093442
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""
    assert doc.params[0].arg_name == "arg1"
    assert doc.params[0].description == "The first argument."
    assert doc.params[1].arg_name == "arg2"
    assert doc.params[1].description == "The second argument."
    assert doc.returns.description == "The return value."


# Generated at 2022-06-17 18:25:26.378256
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises Exception: An exception.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {
        "arg1": "The first argument.",
        "arg2": "The second argument.",
    }
    assert docstring.returns == "The return value."
    assert docstring.raises == {"Exception": "An exception."}

# Generated at 2022-06-17 18:25:35.335246
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a test function.'
    assert doc.long_description == ''
    assert doc.meta['parameters']['a'].description == 'a parameter'
    assert doc.meta['parameters']['a'].type_name == 'int'
    assert doc.meta['returns'].description == 'a return value'
    assert doc.meta['returns'].type_name == 'int'


# Generated at 2022-06-17 18:25:42.344880
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {'a': 'a parameter', 'b': 'another parameter'}


# Generated at 2022-06-17 18:25:55.575398
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: nothing
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "first parameter"
    assert docstring.params['b'] == "second parameter"
    assert docstring.returns == "nothing"
    assert docstring.meta == {}

    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: nothing
    :raises keyError: This is an exception
    """
    docstring = parse(text)

# Generated at 2022-06-17 18:26:06.739515
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param name: name of the person
    :type name: str
    :param age: age of the person
    :type age: int
    :returns: person's name and age
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "name of the person"
    assert docstring.params[1].arg_name == "age"
    assert docstring.params[1].type_name == "int"

# Generated at 2022-06-17 18:26:17.904375
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: float
    :returns: x + y
    :rtype: float
    """
    d = parse(text)
    assert d.short_description == "This is a function."
    assert d.long_description == ""
    assert d.params == {"x": "x", "y": "y"}
    assert d.returns == "x + y"
    assert d.return_type == "float"
    assert d.meta == {"x": "int", "y": "float"}
    assert d.style == Style.numpy

# Generated at 2022-06-17 18:26:26.598438
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: parameter a
    :param b: parameter b
    :returns: returns something
    '''
    assert parse(text).short_description == 'This is a test docstring.'
    assert parse(text).long_description == ''
    assert parse(text).params['a'] == 'parameter a'
    assert parse(text).params['b'] == 'parameter b'
    assert parse(text).returns == 'returns something'
    assert parse(text).meta == {'a': 'parameter a', 'b': 'parameter b'}
    assert parse(text).return_meta == {'returns': 'returns something'}
    assert parse(text).examples == []
    assert parse(text).raises == []

# Generated at 2022-06-17 18:26:35.180053
# Unit test for function parse
def test_parse():
    """Test function parse."""
    docstring = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :rtype: Person
    """
    assert parse(docstring) == Docstring(
        summary='This is a test docstring.',
        description='',
        meta=[
            ('param', 'str name', 'name of the person'),
            ('param', 'int age', 'age of the person'),
            ('returns', '', 'a person'),
            ('rtype', 'Person', ''),
        ],
        examples=[],
    )