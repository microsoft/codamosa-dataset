

# Generated at 2022-06-17 18:16:46.587541
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    docstring = """
    This is a function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    assert parse(docstring) == GoogleStyle(docstring)
    assert parse(docstring, style=Style.google) == GoogleStyle(docstring)
    assert parse(docstring, style=Style.numpy) == GoogleStyle(docstring)
    assert parse(docstring, style=Style.sphinx) == GoogleStyle(docstring)
    assert parse(docstring, style=Style.pep257) == GoogleStyle(docstring)
    assert parse(docstring, style=Style.auto) == GoogleStyle(docstring)


# Generated at 2022-06-17 18:16:54.353568
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta["arg1"] == "the first argument"
    assert docstring.meta["arg2"] == "the second argument"
    assert docstring.meta["returns"] == "None"


# Generated at 2022-06-17 18:17:02.124577
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."
   

# Generated at 2022-06-17 18:17:08.945359
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == {"a": "a parameter", "b": "another parameter"}
    assert docstring.returns == "return value"
    assert docstring.meta == {"param a": "a parameter", "param b": "another parameter", "returns": "return value"}


# Generated at 2022-06-17 18:17:20.268352
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param int a: first parameter
    :param str b: second parameter
    :returns: something
    :raises ValueError: if something bad happens
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "first parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].type_name == "str"

# Generated at 2022-06-17 18:17:30.693189
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'] == 'The first argument.'
    assert docstring.params['arg2'] == 'The second argument.'
    assert docstring.returns == 'Description of return value.'
    assert docstring.raises['keyError'] == 'raises an exception'
    assert docstring.meta == {}


# Generated at 2022-06-17 18:17:34.982721
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 3


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:17:45.079879
# Unit test for function parse
def test_parse():
    text = """\
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "Description of return value."

# Generated at 2022-06-17 18:17:55.365308
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: The first parameter.
    :type a: int
    :param b: The second parameter.
    :type b: str
    :returns: None
    :raises keyError: raises an exception
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['a'].arg_type == 'int'
    assert docstring.params['b'].arg_type == 'str'
    assert docstring.returns.arg_type == 'None'
    assert len(docstring.raises) == 1
    assert docstring.raises['keyError'].arg

# Generated at 2022-06-17 18:17:57.858818
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: A parameter
    :type a: int
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == {'a': 'A parameter'}
    assert docstring.returns == 'None'
    assert docstring.meta == {'a': 'int'}

# Generated at 2022-06-17 18:18:10.572725
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("Hello, world!") == Docstring(summary="Hello, world!", description="", meta={})
    assert parse("Hello, world!\n\nThis is a test.") == Docstring(summary="Hello, world!", description="This is a test.", meta={})

# Generated at 2022-06-17 18:18:19.354652
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    assert len(docstring.meta) == 4


# Generated at 2022-06-17 18:18:27.845060
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[0].description == "x"
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].type_name == "int"
    assert docstring.params[1].description == "y"

# Generated at 2022-06-17 18:18:35.727710
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: str
    :returns: a + b
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'].arg_type == 'int'
    assert docstring.params['b'].arg_type == 'str'
    assert docstring.returns.arg_type == 'str'


# Generated at 2022-06-17 18:18:44.075856
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.meta["arg1"] == "The first argument."
    assert docstring.meta["arg2"] == "The second argument."
    assert docstring.meta["returns"] == "Description of return value."
    assert docstring.meta["raises"] == "raises an exception"


# Generated at 2022-06-17 18:18:52.358529
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type raised.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['arg1'] == 'The first argument.'
    assert docstring.meta['param']['arg2'] == 'The second argument.'
    assert docstring.meta['returns'] == 'The return value.'
    assert docstring.meta['raises']['keyError'] == 'The exception type raised.'

# Generated at 2022-06-17 18:19:05.155465
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :param b: parameter b
    :returns: return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [
        {"name": "a", "type": None, "desc": "parameter a"},
        {"name": "b", "type": None, "desc": "parameter b"},
    ]
    assert docstring.returns == {"type": None, "desc": "return value"}
    assert docstring.meta == {
        "param a": "parameter a",
        "param b": "parameter b",
        "returns": "return value",
    }




# Generated at 2022-06-17 18:19:15.217063
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.
    """
    assert parse(docstring) == Docstring(
        summary='This is a docstring.',
        description='',
        meta={},
        returns=None,
        raises=None,
        examples=None,
        see_also=None,
    )

    docstring = """
    This is a docstring.

    This is a description.
    """
    assert parse(docstring) == Docstring(
        summary='This is a docstring.',
        description='This is a description.',
        meta={},
        returns=None,
        raises=None,
        examples=None,
        see_also=None,
    )


# Generated at 2022-06-17 18:19:19.423505
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring.
    """
    assert parse(docstring) == Docstring(
        summary='This is a docstring.',
        description='',
        meta={},
        returns=None,
        raises=None,
        examples=None,
        see_also=None,
    )

# Generated at 2022-06-17 18:19:26.893190
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("Summary") == Docstring(summary="Summary", description="", meta={})
    assert parse("Summary\n\nDescription") == Docstring(summary="Summary", description="Description", meta={})
    assert parse("Summary\n\nDescription\n\n:param a: param a") == Docstring(summary="Summary", description="Description", meta={"param a": ""})
    assert parse("Summary\n\nDescription\n\n:param a: param a\n:param b: param b") == Docstring(summary="Summary", description="Description", meta={"param a": "", "param b": ""})

# Generated at 2022-06-17 18:19:37.554115
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Hello, world!") == Docstring(short_description="Hello, world!")
    assert parse("Hello, world!\n\nThis is a test.") == Docstring(short_description="Hello, world!",
                                                                   long_description="This is a test.")

# Generated at 2022-06-17 18:19:47.753422
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: None
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1']['type'] == 'int'
    assert docstring.meta['arg2']['type'] == 'str'
    assert docstring.meta['returns']['type'] == 'None'
    assert docstring.meta['keyError']['type'] == 'exception'



# Generated at 2022-06-17 18:19:56.873456
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.
    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """
    assert parse(docstring) == Docstring(
        summary='This is a test docstring.',
        description='',
        params=[
            ('param1', 'this is a first param'),
            ('param2', 'this is a second param')
        ],
        returns='this is a description of what is returned',
        raises=[('keyError', 'raises an exception')]
    )


# Generated at 2022-06-17 18:20:06.900421
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param foo: a parameter
    :type foo: str
    :returns: a return value
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['foo'].description == 'a parameter'
    assert docstring.params['foo'].type_name == 'str'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.type_name == 'int'

# Generated at 2022-06-17 18:20:13.116245
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'].description == 'a parameter'
    assert docstring.params['a'].annotation == 'int'
    assert docstring.returns.description == 'a return value'
    assert docstring.returns.annotation == 'str'

# Generated at 2022-06-17 18:20:18.954469
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 0


# Generated at 2022-06-17 18:20:24.234806
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: str
    :returns: something
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params['a'].description == "first parameter"
    assert docstring.params['b'].description == "second parameter"
    assert docstring.returns.description == "something"
    assert docstring.raises == {}
    assert docstring.meta == {}
    assert docstring.extras == {}
    assert docstring.style == Style.numpy


# Generated at 2022-06-17 18:20:33.658334
# Unit test for function parse
def test_parse():
    """
    >>> parse("""

# Generated at 2022-06-17 18:20:42.698789
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param int a: first parameter
    :param int b: second parameter
    :returns: sum of a and b
    """
    doc = parse(text)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == ""
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].arg_type == "int"
    assert doc.meta[0].description == "first parameter"
    assert doc.meta[1].arg_name == "b"
    assert doc.meta[1].arg_type == "int"
    assert doc.meta[1].description == "second parameter"

# Generated at 2022-06-17 18:20:49.061285
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.params == []
    assert docstring.returns == None
    assert docstring.raises == []
    assert docstring.yields == None
    assert docstring.other == []

    text = """
    This is a test docstring.

    This is a long description.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is a long description."
    assert docstring.meta == {}
    assert docstring.params == []

# Generated at 2022-06-17 18:21:03.588686
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    :raises Exception: if something goes wrong
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert docstring.params["a"] == "first parameter"
    assert docstring.params["b"] == "second parameter"
    assert docstring.returns == "something"
    assert docstring.raises["Exception"] == "if something goes wrong"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:21:09.887089
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['arg1'] == "The first argument."
    assert docstring.params['arg2'] == "The second argument."
    assert docstring.returns == "Description of return value."
    assert docstring.raises['keyError'] == "raises an exception"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:21:20.004627
# Unit test for function parse
def test_parse():
    text = """
    This is a function docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'a'
    assert docstring.params[0].description == 'a parameter'
    assert docstring.params[1].arg_name == 'b'
    assert docstring.params[1].description == 'another parameter'
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == 'a return value'
    assert docstring.meta == {}



# Generated at 2022-06-17 18:21:29.929773
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: a person
    :rtype: Person
    """

# Generated at 2022-06-17 18:21:41.053882
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.meta) == 3
    assert docstring.params[0].arg_name == "a"
    assert docstring.params[0].description == "a parameter"
    assert docstring.params[1].arg_name == "b"
    assert docstring.params[1].description == "another parameter"
    assert docstring.returns[0].arg_name == "something"

# Generated at 2022-06-17 18:21:49.716855
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: nothing
    """
    assert parse(text) == Docstring(
        summary='This is a test docstring.',
        description='',
        meta={'param': [('a', 'a parameter'), ('b', 'another parameter')],
              'returns': ['nothing']})

# Generated at 2022-06-17 18:21:55.717227
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param x: x coordinate
    :param y: y coordinate
    :returns: distance
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params == [
        {'name': 'x', 'type': None, 'desc': 'x coordinate'},
        {'name': 'y', 'type': None, 'desc': 'y coordinate'},
    ]
    assert docstring.returns == {'type': None, 'desc': 'distance'}
    assert docstring.raises == []
    assert docstring.meta == {'param': ['x', 'y'], 'returns': []}

# Generated at 2022-06-17 18:22:04.893471
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params["a"].description == "a parameter"
    assert docstring.params["a"].type == "int"
    assert docstring.returns.description == "a return value"
    assert docstring.returns.type == "str"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-17 18:22:13.982455
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = """
    This is a test function.

    :param a: test parameter a
    :param b: test parameter b
    :returns: test return value
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params == {'a': 'test parameter a', 'b': 'test parameter b'}
    assert docstring.returns == 'test return value'
    assert docstring.meta == {}
    assert docstring.examples == []
    assert docstring.notes == []
    assert docstring.references == []
    assert docstring.see_also == []
    assert docstring.warnings == []
    assert docstring.warnings == []
    assert doc

# Generated at 2022-06-17 18:22:23.557568
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises keyError: The exception type.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].description == "The second argument."
    assert docstring.returns.description == "The return value."

# Generated at 2022-06-17 18:22:34.813397
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.returns.description == 'None'
    assert docstring.params['arg1'].description == 'The first argument.'
    assert docstring.params['arg2'].description == 'The second argument.'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:22:45.885637
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param str name: name of the person
    :param int age: age of the person
    :returns: the person's name and age
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "name"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "name of the person"
    assert docstring.params[1].arg_name == "age"
    assert docstring.params[1].type_name == "int"

# Generated at 2022-06-17 18:22:56.993599
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param test: This is a test param
    :type test: str
    :returns: This is a test return
    :rtype: str
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['test'].description == 'This is a test param'
    assert docstring.params['test'].type == 'str'
    assert docstring.returns.description == 'This is a test return'
    assert docstring.returns.type == 'str'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:23:06.917365
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['a'] == "first parameter"
    assert docstring.params['b'] == "second parameter"
    assert docstring.returns == "something"
    assert docstring.meta == {}
    assert docstring.style == Style.numpy

    text = """
    This is a test docstring.

    :param a: first parameter
    :param b: second parameter
    :returns: something
    :raises keyError: oops
    """
    docstring = parse(text)

# Generated at 2022-06-17 18:23:14.813946
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param a: a parameter
    :param b: another parameter
    :returns: something
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'something'
    assert docstring.meta == {}



# Generated at 2022-06-17 18:23:18.591160
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."


# Generated at 2022-06-17 18:23:28.227049
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.meta == {}
    assert docstring.style == Style.google
    assert docstring.params == []
    assert docstring.returns == []
    assert docstring.raises == []
    assert docstring.yields == []
    assert docstring.other == []
    assert docstring.warns == []
    assert docstring.warns == []
    assert docstring.warns == []
    assert docstring.warns == []
    assert docstring.warns == []
    assert docstring.warns == []
    assert docstring.warns == []

# Generated at 2022-06-17 18:23:37.388246
# Unit test for function parse
def test_parse():
    text = """
    This is a module docstring.

    This is the first line of the first paragraph.

    This is the second line of the first paragraph.

    This is the first line of the second paragraph.

    This is the second line of the second paragraph.

    :param arg1: The first argument.
    :type arg1: str
    :param arg2: The second argument.
    :type arg2: int, optional
    :returns: Description of return value.
    :rtype: bool
    :raises keyError: We never get here...
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a module docstring.'

# Generated at 2022-06-17 18:23:45.408198
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert docstring.meta['param']['arg1'] == 'the first argument'
    assert docstring.meta['param']['arg2'] == 'the second argument'
    assert docstring.meta['return'] == 'the return value'

# Generated at 2022-06-17 18:23:53.080693
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param foo: this is a foo
    :type foo: str
    :param bar: this is a bar
    :type bar: int
    :returns: this is a return
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params['foo'].arg_type == 'str'
    assert docstring.params['foo'].description == 'this is a foo'
    assert docstring.params['bar'].arg_type == 'int'
    assert docstring.params['bar'].description == 'this is a bar'
    assert docstring.returns.arg_type == 'str'
    assert doc

# Generated at 2022-06-17 18:24:00.695017
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.returns.type_name == "None"
    assert docstring.returns.description == ""
    assert docstring.params['arg1'].type_name == ""
    assert docstring.params['arg1'].description == "the first argument"
    assert docstring.params['arg2'].type_name == ""
    assert docstring.params['arg2'].description == "the second argument"
    assert docstring.meta == {}

# Generated at 2022-06-17 18:24:11.265411
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param x: x value
    :type x: int
    :param y: y value
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[0].description == "x value"
    assert docstring.params[0].type_name == "int"
    assert docstring.params[1].arg_name == "y"
    assert docstring.params[1].description == "y value"
    assert docstring.params[1].type_name == "int"


# Generated at 2022-06-17 18:24:21.400164
# Unit test for function parse
def test_parse():
    docstring = """
    This is a function docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a function docstring."
    assert parsed.long_description == ""
    assert parsed.returns.description == "None"
    assert parsed.raises[0].type == "keyError"
    assert parsed.raises[0].description == "raises an exception"
    assert parsed.params[0].arg_name == "arg1"
    assert parsed.params[0].description == "The first argument."
    assert parsed.params[1].arg_name == "arg2"

# Generated at 2022-06-17 18:24:30.465403
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    doc = parse(text)
    assert doc.short_description == 'This is a function.'
    assert doc.long_description == ''
    assert doc.params == {'x': 'x', 'y': 'y'}
    assert doc.returns == 'x + y'
    assert doc.meta == {'x': 'int', 'y': 'int', 'returns': 'int'}
    assert doc.style == Style.numpy

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:24:37.881858
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: parameter a
    :param b: parameter b
    :returns: a + b
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['parameters']['a'] == 'parameter a'
    assert docstring.meta['parameters']['b'] == 'parameter b'
    assert docstring.meta['returns'] == 'a + b'

# Generated at 2022-06-17 18:24:44.561857
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether or not to say hello.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    """
    doc = parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == ""

# Generated at 2022-06-17 18:24:54.864256
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: str
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.params == [("a", "a parameter", "int")]
    assert docstring.returns == ("a return value", "str")
    assert docstring.meta == {"param a": "a parameter", "type a": "int", "returns": "a return value", "rtype": "str"}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:25:00.381385
# Unit test for function parse
def test_parse():
    text = """
    This is a function.

    :param x: x
    :type x: int
    :param y: y
    :type y: int
    :returns: x + y
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert docstring.params == {'x': 'x', 'y': 'y'}
    assert docstring.returns == 'x + y'
    assert docstring.meta == {'x': 'int', 'y': 'int', 'returns': 'int'}
    assert docstring.style == Style.numpy

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:25:09.881894
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param int a: This is a parameter.
    :param str b: This is a parameter.
    :returns: This is a return value.
    :raises ValueError: This is a raised exception.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['a'].arg_type == 'int'
    assert docstring.params['a'].description == 'This is a parameter.'
    assert docstring.params['b'].arg_type == 'str'
    assert docstring.params['b'].description == 'This is a parameter.'

# Generated at 2022-06-17 18:25:18.193196
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :type a: int
    :returns: a return value
    :rtype: int
    '''
    d = parse(text)
    assert d.short_description == 'This is a test docstring.'
    assert d.long_description == ''
    assert len(d.meta) == 2
    assert d.meta[0].args == ['a']
    assert d.meta[0].description == 'a parameter'
    assert d.meta[0].annotation == 'int'
    assert d.meta[1].args == ['returns']
    assert d.meta[1].description == 'a return value'
    assert d.meta[1].annotation == 'int'

# Generated at 2022-06-17 18:25:34.022669
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param a: a parameter
    :param b: another parameter
    :returns: a return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.params['a'] == 'a parameter'
    assert docstring.params['b'] == 'another parameter'
    assert docstring.returns == 'a return value'
    assert docstring.meta == {'param': {'a': 'a parameter', 'b': 'another parameter'}, 'returns': 'a return value'}
    assert docstring.style == Style.numpy

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-17 18:25:36.982120
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring
    '''
    assert parse(text) == Docstring(text)

# Generated at 2022-06-17 18:25:43.286489
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['arg1'] == 'The first argument.'
    assert docstring.meta['arg2'] == 'The second argument.'
    assert docstring.meta['returns'] == 'Description of return value.'


# Generated at 2022-06-17 18:25:55.960467
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to print 'hello' or 'goodbye'.
    :type state: bool.
    :returns: None.
    :raises: AttributeError, KeyError
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test docstring.'
    assert docstring.long_description == ''
    assert docstring.meta['parameters']['name']['description'] == 'The name to use.'
    assert docstring.meta['parameters']['name']['type'] == 'str.'

# Generated at 2022-06-17 18:26:05.060915
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    :param x: x
    :param y: y
    :returns: x + y
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params['x'].description == "x"
    assert docstring.params['y'].description == "y"
    assert docstring.returns.description == "x + y"
    assert docstring.meta == {}


# Generated at 2022-06-17 18:26:15.026934
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function.

    :param str name: The name of the person.
    :param int age: The age of the person.
    :returns: True if the person is allowed to drink.
    :raises ValueError: If the age is less than 0.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'name'
    assert docstring.params[0].type_name == 'str'
    assert docstring.params[0].description == 'The name of the person.'
    assert docstring.params[1].arg_name == 'age'

# Generated at 2022-06-17 18:26:26.109862
# Unit test for function parse
def test_parse():
    text = """
    This is a test function.

    :param str arg1: The first argument.
    :param int arg2: The second argument.
    :returns: The return value.
    :raises ValueError: If something goes wrong.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "The first argument."
    assert docstring.params[1].arg_name == "arg2"
    assert docstring.params[1].type_name == "int"


# Generated at 2022-06-17 18:26:33.496200
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: None
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert docstring.returns.description == "None"
    assert docstring.params['arg1'].description == "The first argument."
    assert docstring.params['arg2'].description == "The second argument."

if __name__ == "__main__":
    test_parse()