

# Generated at 2022-06-11 21:26:21.769869
# Unit test for function parse
def test_parse():
    text = """
        This is a docstring.

        :param str name: Name of person.
        :param str address: Address of person.
        """

    parsed = parse(text)
    expected = Docstring(
        summary="This is a docstring.",
        body="",
        meta={"param": [
            {"name": "name", "type": "str", "desc": "Name of person."},
            {"name": "address", "type": "str", "desc": "Address of person."},
        ]},
    )
    assert parsed == expected



# Generated at 2022-06-11 21:26:33.093065
# Unit test for function parse
def test_parse():
    # pylint: disable=import-error
    # pylint: disable=no-name-in-module
    import pytest

    with pytest.raises(ParseError):
        parse("")

    with pytest.raises(ParseError):
        parse("""Doesn't have a short description.""")

    with pytest.raises(ParseError):
        parse("""Does have a short description.

        Doesn't have a long description.""")

    with pytest.raises(ParseError):
        parse("""Does have a short description.

        Does have a long description.""", style=Style.numpy)

    with pytest.raises(ParseError):
        parse("""Does have a short description.

        Does have a long description.""", style=Style.sphinx)


# Generated at 2022-06-11 21:26:44.677188
# Unit test for function parse
def test_parse():
    doc = """Автор: Сергей Миронов
    Цель: Пример документации на русском языке
    Параметры:
        name - Имя пользователя
        age - Возраст пользователя
        height - Рост пользователя

    """
    ret = parse(doc)
    print(ret.__dict__)

test_parse()

# Generated at 2022-06-11 21:26:46.218106
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:26:54.256662
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import google, numpy, sphinx
    text = '''
    Summary line.

    Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value.
    '''
    s = Style.auto
    assert parse(text, s) == parse(text, google)
    assert parse(text, s) == parse(text, numpy)
    assert parse(text, s) == parse(text, sphinx)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:27:06.300640
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError

    def compose(b, *a):
        text = ""
        for i in range(len(a)):
            text += b[i] + a[i] + "\n"
        text += b[-1]
        return text

    args_list = ["a: int, (optional)\n    a is an int",
                 "b: str, (optional)\n    b is a str"]
    args_dic = {"a": "int, (optional)\n    a is an int",
                "b": "str, (optional)\n    b is a str"}
    ret = "str\n    return a string"
    yiel = "str\n    yield a string"

    # parse with Style.auto

# Generated at 2022-06-11 21:27:11.130454
# Unit test for function parse
def test_parse():
    parsed = parse("""
        Hello world.

        :param a:
            first parameter
        :return:
            returns nothing
    """)
    assert parsed.short_description == "Hello world."
    assert parsed.long_description == ''
    assert parsed.meta['param'][0].args == ['a']
    assert parsed.meta['param'][0].description == "first parameter"
    assert parsed.meta['return'][0].description == "returns nothing"

# Generated at 2022-06-11 21:27:18.280339
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring('', '', [], [], [], [])
    assert parse(" ", "google") == Docstring('', '', [], [], [], [])
    assert parse("test") == Docstring('test', '', [], [], [], [])
    assert parse("test\ntest2") == Docstring('test', 'test2', [], [], [], [])


# Generated at 2022-06-11 21:27:22.779696
# Unit test for function parse
def test_parse():
	text = "title\n\ntest\n\n"
	print(parse(text))


if __name__ == "__main__":
	text = "title\n\ntest\n\n"
	print(parse(text))

# Generated at 2022-06-11 21:27:31.934852
# Unit test for function parse
def test_parse():
    """Test for function parse."""

    text = """
    One-line description.

    Additional description.
    """

    docstring = parse(text)
    assert docstring.summary == "One-line description."
    assert docstring.description == "Additional description."
    assert docstring.extended_summary == ""
    assert len(docstring.params) == 0
    assert len(docstring.returns) == 0
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 0
    assert docstring.style == Style.numpy
    assert str(docstring) == text


# Generated at 2022-06-11 21:27:44.594209
# Unit test for function parse
def test_parse():
    d = parse(text)
    assert d.short_description == "This is an example script."
    assert d.long_description == "This is the long description.  It should contain all the information that"
    assert d.returns.type_name == "int"
    assert d.returns.description == "The return code."
    assert d.params["argv"].type_name == "list"
    assert d.params["argv"].description == "Command-line arguments."
    d = parse(text2)
    assert d.short_description == "  This is an example script."
    assert d.long_description == "  This is the long description.  It should contain all the information that"
    assert d.returns.type_name == "  int"
    assert d.returns.description == "  The return code."

# Generated at 2022-06-11 21:27:54.171317
# Unit test for function parse
def test_parse():
    # Test for Google Style
    text = """A one-line summary that does not use variable names or the function name.
    <BLANKLINE>
    Extended description that can contain multiple paragraphs.
    <BLANKLINE>
    Args:
        text: docstring text to parse
        style: docstring style
    <BLANKLINE>
    Returns:
        parsed docstring representation
    """

# Generated at 2022-06-11 21:28:04.441817
# Unit test for function parse
def test_parse():

    s = """\
Args:
    none

Attributes:
    ``len`` (``str``): Length of the string.
    ``str`` (``str``): The string itself.

Returns:
    (``str``): the string in reverse
"""
    styles = [Style.numpy, Style.google, Style.pep257, Style.reST, Style.sphinx]
    for style in styles:
        parsed = parse(s, style)
        print(f"{parsed.args}")
        print(f"{parsed.retval}")
        print(f"{parsed.returns}")
        print(f"{parsed.attributes}")
        print(f"{parsed.examples}")
        print(f"{parsed.meta}")
       

# Generated at 2022-06-11 21:28:06.270853
# Unit test for function parse
def test_parse():
    text = "a b c"
    p = parse(text)
    assert repr(p.content) == repr(text)


# Generated at 2022-06-11 21:28:11.929616
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    simple = u"""This is the first line"""
    complex = u"""This is the first line
    This is the second line
    This is the third line
    """
    assert parse(simple).short_description == u'This is the first line'
    assert parse(complex).short_description == u'This is the first line'
    print('Test parse: success')


# Generated at 2022-06-11 21:28:18.258167
# Unit test for function parse
def test_parse():
    '''test function parse'''
    docstring = """This is a docstring.
                 djffkgbkjdfbkjdbfkjbfjkgjbfbfkbfb
                 jhjhjhjhjhjhjhjjhjhjhjhjhjhjhjhjh
                 """
    assert parse(docstring) == parse(docstring)

# Generated at 2022-06-11 21:28:22.035372
# Unit test for function parse
def test_parse():
    text = """This project is licensed under the MIT license, see `LICENSE`_ for more
information.

.. _LICENSE: https://github.com/hugovk/docstring_parser/blob/master/LICENSE
"""
    print(parse(text))

test_parse()

# Generated at 2022-06-11 21:28:32.476251
# Unit test for function parse
def test_parse():
    text = """
    A function or method

    :param a: A
    :param b: B
    :returns: The c
    """
    ds = parse(text)
    print(ds)
    assert ds._name == 'parse'
    assert ds.short_description == 'A function or method'
    assert ds.long_description == ''
    assert ds.returns.type_name == 'The c'
    assert ds.returns.description == ''
    assert ds.params['a'].type_name == 'A'
    assert ds.params['b'].type_name == 'B'


# Generated at 2022-06-11 21:28:40.876609
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    

# Generated at 2022-06-11 21:28:50.789176
# Unit test for function parse
def test_parse():
    """
        Testing function parse in parsing
    """
    a = Docstring(
        short_description='Hello',
        long_description='\n    Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n    Duis bibendum nibh et enim sodales, convallis\n    ',
        returns=None,
        raises=None,
        meta={
            'yields': [
                {
                    'type_name': 'int',
                    'description': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis bibendum nibh et enim sodales, convallis'
                }
            ]
        },
        extras={}
    )

# Generated at 2022-06-11 21:29:02.241765
# Unit test for function parse
def test_parse():
    docstring = """
    Tests the parse function

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation

    """
    result = parse(docstring)
    assert result.summary == 'Tests the parse function'
    assert result.params == {'text': 'docstring text to parse','style': 'docstring style'}
    assert result.returns == 'parsed docstring representation'
    assert result.meta == {'param': ['text', 'style', 'returns']}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:12.523622
# Unit test for function parse
def test_parse():
    docstring = """This function prints the provided string.
    :param s: the string to be printed
    :param reps: the number of times to repeat the string
    """
    doc = parse(docstring)
    assert (doc.short_description == 'This function prints the provided string.')
    assert (doc.long_description == None)
    assert (doc.tags == [{'name': 'param', 'type': None, 'desc': 'the string to be printed', 'value': None, 'options': [], 'optional': False, 'name_raw': None, 'name_type': None},
                          {'name': 'param', 'type': None, 'desc': 'the number of times to repeat the string', 'value': None, 'options': [], 'optional': False, 'name_raw': None, 'name_type': None}])


# Generated at 2022-06-11 21:29:16.590896
# Unit test for function parse
def test_parse():
    text = '''Hi Yuki
    nvm test
    '''
    assert parse(text)

# Generated at 2022-06-11 21:29:28.702044
# Unit test for function parse

# Generated at 2022-06-11 21:29:33.375949
# Unit test for function parse
def test_parse():
    text = '''
    Ищет в строке целое число, действительное, строку. 
    '''
    assert parse(text) == text

# Generated at 2022-06-11 21:29:41.632582
# Unit test for function parse
def test_parse():
    from .samples.decorators import sample_decorators
    from .samples.google import sample_google
    from .samples.google_missing import sample_google_missing
    from .samples.google_nested import sample_google_nested
    from .samples.google_nodef import sample_google_nodef
    from .samples.google_noargs import sample_google_noargs
    from .samples.google_noreturns import sample_google_noreturns
    from .samples.google_noreturns_void import sample_google_noreturns_void
    from .samples.google_args_split import sample_google_args_split
    from .samples.google_args_with_defaults import sample_google_args_with_defaults

# Generated at 2022-06-11 21:29:48.155205
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    docstring = '''Summary line.

Extended description.
'''

    doc = parse(docstring)

    assert doc.short_description == 'Summary line.\n'
    assert doc.long_description == 'Extended description.\n'

    assert not doc.params
    assert not doc.returns



# Generated at 2022-06-11 21:29:56.238213
# Unit test for function parse
def test_parse():
    text_numpy = '''
    Args:
        num_iter (int): Number of iterations.
        temp_file (str): Temporary file name.
        verbose(bool): Verbosity flag.

    Returns:
        None

    Raises:
        IOError: If file can not be opened.
        ValueError: If x is out of bounds.
    '''
    text_google = '''
        Args:
            num_iter (int): Number of iterations.
            temp_file (str): Temporary file name.
            verbose(bool): Verbosity flag.

        Returns:
            None

        Raises:
            IOError: If file can not be opened.
            ValueError: If x is out of bounds.
    '''

    result = parse(text_google, Style.google)

# Generated at 2022-06-11 21:30:07.452032
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    docstring = parse(
    """
    This is a docstring.

    This is a section.
    """)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == '<BLANKLINE>\nThis is a section.\n'
    assert docstring.sections == []
    assert repr(docstring) == (
        'Docstring(short_description=\'This is a docstring.\', '
        'long_description=\'<BLANKLINE>\\nThis is a section.\\n\', sections=[])'
    )

    docstring = parse(
    """
    This is a docstring.

    This is a first section.

    This is a second section.
    """,
    style=Style.rst)


# Generated at 2022-06-11 21:30:11.904192
# Unit test for function parse
def test_parse():
    examples = open("examples.txt", "r")
    for line in examples:
        print(parse(line))
        print()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:25.701912
# Unit test for function parse
def test_parse():
    # parse with no style provided (auto)
    text = '''This is a test string.'''
    expected = """This is a test string."""
    actual = str(parse(text))
    try:
        assert actual == expected
    except AssertionError:
        print("Failed: expected {}, got {}".format(expected, actual))

    # parse with Google style
    text = '''
    This is a test string.

    Args:
        msg (str): This is a test.
    '''
    expected = """
This is a test string.

Args:
    msg (str): This is a test.
"""
    actual = str(parse(text, style=Style.google))

# Generated at 2022-06-11 21:30:31.562765
# Unit test for function parse
def test_parse():
    my_text = "This is my sentence!"
    my_parse = parse(my_text)
    assert my_parse.summary == my_text
    assert my_parse.description == ""
    assert my_parse.returns == ""
    assert my_parse.raises == ""
    assert my_parse.meta == {}
    assert my_parse.style == Style.numpy
    print("* Passed test_parse")


# Generated at 2022-06-11 21:30:42.266312
# Unit test for function parse
def test_parse():
    """
    Indirect unit test for function parse
    """

    style = "numpy"
    text = '''
        A basic example of epydoc-style docstrings is:

        .. automethod:: __init__(width, height, code, color)

        :Parameters:
          width : int
              The width of the panel.
          height : int
              The height of the panel.
          code : str
              The hardware code of the panel.
          color : str
              The color of the panel.
    '''
    doc = parse(text, style=Style[style.upper()])

    # print(doc.args)
    # print(doc.returns)
    # print(doc.raises)
    # print(doc.summary)
    # print(doc.description)

# Generated at 2022-06-11 21:30:45.957050
# Unit test for function parse
def test_parse():
    """Tests whether docstring is properly parsed"""
    text = """This is a simple test"""
    docstring = parse(text)
    assert(docstring.short_description == "This is a simple test")

# Generated at 2022-06-11 21:30:57.603603
# Unit test for function parse
def test_parse():
    from textwrap import dedent

# Generated at 2022-06-11 21:31:07.333326
# Unit test for function parse
def test_parse():
    parse_string = '''
    """Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    '''
    result = parse(parse_string)
    assert 'parse' in result.short_description, "The short description should be 'parse'"
    assert 'Parse the docstring into its components.' in result.long_description, "The long description should be 'Parse the docstring into its components.'"
    assert result.long_description[-35:] == "parsed docstring representation", "The long description should be 'Parse the docstring into its components.'"
    assert 'text' in result.params, "The parameter 'text' should in the dictionary 'params'"

# Generated at 2022-06-11 21:31:19.117105
# Unit test for function parse
def test_parse():
    docstring1 = '''Sample function with types documented in the docstring.
    This function does nothing.
    Args:
    	param1 (int): The first parameter.
    	param2 (str): The second parameter.
    	param3 (Optional[List[int]]): The third parameter. Defaults to None.
    Returns:
    	bool: The return value. True for success, False otherwise.
    '''

    docstring2 = '''This function does nothing.
    Args:
    	param1 (int): The first parameter.
    	param2 (str): The second parameter.
    	param3 (Optional[List[int]]): The third parameter. Defaults to None.
    '''


# Generated at 2022-06-11 21:31:20.943559
# Unit test for function parse
def test_parse():
    assert parse('Foobar\n') == parse('Foobar\n', Style.google)

# Generated at 2022-06-11 21:31:32.542312
# Unit test for function parse
def test_parse():
    from pprint import pprint
    docstring_text = """
    This is a module docstring

    This is the second paragraph of the module docstring.
    """
    parsed_docstring = parse(docstring_text, style=Style.numpy)
    pprint(parsed_docstring.to_dict())
    # Result:
    # {'args': [],
    #  'attributes': [],
    #  'examples': [],
    #  'kwargs': [],
    #  'meta': [],
    #  'notes': [],
    #  'params': [],
    #  'references': [],
    #  'raises': [],
    #  'returns': [],
    #  'seealso': [],
    #  'summary': 'This is a module

# Generated at 2022-06-11 21:31:41.025399
# Unit test for function parse
def test_parse():
    """Test parse function
    """
    text = """This is a docstring.
:param key1: value1
:param key2: value2
:returns: Return value.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.meta['param']['key1'] == 'value1'
    assert docstring.meta['param']['key2'] == 'value2'
    assert docstring.meta['returns'] == 'Return value.'
    print(docstring)

# Generated at 2022-06-11 21:31:50.544315
# Unit test for function parse

# Generated at 2022-06-11 21:31:55.025856
# Unit test for function parse
def test_parse():
    d = parse('Returns:')
    print(d.title)
    print(d.body)
    print(d.meta)
    print(d.returns)
    d = parse('Returns: None')
    print(d.title)
    print(d.body)
    print(d.meta)
    print(d.returns)



# Generated at 2022-06-11 21:32:06.511361
# Unit test for function parse
def test_parse():

    # Test function parse(text, style)
    assert parse('') == Docstring(doc='', meta='')
    assert parse('hello world') == Docstring(doc='hello world', meta='')
    assert parse('hello world\n\n') == Docstring(doc='hello world', meta='')
    assert parse('hello world\n\n   ') == Docstring(doc='hello world', meta='')
    assert parse('\nhello world\n') == Docstring(doc='hello world', meta='')
    assert parse('   hello world\n') == Docstring(doc='hello world', meta='')
    assert parse('   hello world\n') == Docstring(doc='hello world', meta='')

# Generated at 2022-06-11 21:32:08.487026
# Unit test for function parse
def test_parse():
    text = '''
    
    
    
    
    
    
    Arguments:
        arg1 {str} -- the first argument
        arg2 {str} -- the second argument
    '''
    assert parse(text,Style.google)

# Generated at 2022-06-11 21:32:11.163112
# Unit test for function parse
def test_parse():
    assert type(parse("line1\nline2\n")) == Docstring


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:32:17.247830
# Unit test for function parse
def test_parse():
    def f():
        """
        Summary line.
        Description of my function.

        Parameters
        ----------
        arg1 : int
            Description of arg1

        Returns
        -------
        int
            Description of return value

        Raises
        ------
        AttributeError
            Description of exception
        """

    for i in parse(f.__doc__).as_dict().items():
        print(i)



# Generated at 2022-06-11 21:32:27.786887
# Unit test for function parse
def test_parse():
    test_string = '''
    This is a test

    Args:
        param1: Description 1
             Description 1.1
        param2: Description 2
    '''
    expected_string = """This is a test

Args:
    param1: Description 1
             Description 1.1
    param2: Description 2
"""
    assert parse(test_string).summary == 'This is a test'
    assert parse(test_string).params == {'param1': "Description 1\n             Description 1.1", 'param2': 'Description 2'}
    assert parse(test_string).value == expected_string
    assert parse(test_string).meta == {'Args': {'param1': "Description 1\n             Description 1.1", 'param2': 'Description 2'}}

# Generated at 2022-06-11 21:32:29.967908
# Unit test for function parse
def test_parse():
    y = parse('function test', Style.numpy)
    assert y.short_description == 'function test'

# Generated at 2022-06-11 21:32:39.129572
# Unit test for function parse
def test_parse():
    # parse()
    assert parse('test') == parse('test', style=Style.numpy)
    assert parse('test', style=Style.numpy) == parse('test', style=Style.sphinx)

    # parse(style=)
    assert parse('test', style=Style.auto) == parse('test')

    # parse(style=Style.numpy)
    assert parse(text='test', style=Style.numpy).summary == 'test'

    # parse(style=Style.sphinx)
    assert parse(text='test', style=Style.sphinx).short_description == 'test'

    # parse(style=Style.google)
    assert parse(text='test', style=Style.google).description == 'test'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:32:48.503144
# Unit test for function parse
def test_parse():
    docstring = """
        Description.

        :param arg0: first arg
        :param arg1: second arg
        :returns: nothing
        :raises keyError: raises an exception
    """
    doc = parse(docstring)
    assert doc.short_description == "Description."
    assert doc.long_description == ''
    assert doc.params == {
        "arg0": "first arg",
        "arg1": "second arg",
    }
    assert doc.returns == 'nothing'
    assert doc.raises == {"keyError" : 'raises an exception'}

# Generated at 2022-06-11 21:33:01.621075
# Unit test for function parse
def test_parse():

    # Test for invalid style
    try:
        mystring = parse("This is a test", style="random")
    except ParseError:
        pass

    # Test for different types of input
    mystring = parse("This is a test")
    assert(mystring.short_description == "This is a test")

    mystring = parse("This is a test\n\nThis is a second line")
    assert(mystring.short_description == "This is a test")
    assert(mystring.long_description == "This is a second line")

    mystring = parse("This is a test\n    :param hello: this is a param\n    :param world: this is anotjher param")
    assert(mystring.short_description == "This is a test")

# Generated at 2022-06-11 21:33:04.044108
# Unit test for function parse
def test_parse():
    if __name__ == "__main__":
        import doctest
        doctest.testmod()

test_parse()

# Generated at 2022-06-11 21:33:06.920160
# Unit test for function parse
def test_parse():
    text = """Parsing a docstring."""
    assert parse(text, style = Style.google).body == text


# Generated at 2022-06-11 21:33:11.259048
# Unit test for function parse
def test_parse():
    import unittest

    class TestParse(unittest.TestCase):
        def test_parse(self):
            self.assertEqual(parse('Function to solve quadratic equation and return the roots.'),
                Docstring('Function to solve quadratic equation and return the roots.'))

    unittest.main()

# Comment
# This is a test
# End comment

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:33:15.152844
# Unit test for function parse
def test_parse():
    doc = parse("""Parse the docstring into its components.""")
    assert doc.short_description == 'Parse the docstring into its components.'
    assert doc.long_description == ''
    assert doc.returns == None
    assert doc.meta == ''
    assert doc.params == []


# Generated at 2022-06-11 21:33:19.167888
# Unit test for function parse
def test_parse():
    assert parse("text")
    assert parse("text", 1)
    assert parse("text", style = 1)
    assert parse("text", style = None)
    assert parse("text", style = "")

# Generated at 2022-06-11 21:33:22.820379
# Unit test for function parse
def test_parse():
    """
    >>> parse('Hello\\nWorld\\n')
    'Hello\\nWorld\\n'
    >>> parse(Hello\\nWorld\\n)
    'Hello\\nWorld\\n'
    """

# Generated at 2022-06-11 21:33:33.518502
# Unit test for function parse
def test_parse():
    docstring = '/**\n' \
                ' * @arg A the first arg.\n' \
                ' * @arg B the second arg.\n' \
                ' * @returns the return value.\n' \
                ' */'
    d = parse(docstring)
    assert d.summary == 'the return value.'
    assert d.description == 'the return value.'
    assert d.arguments == {
        'A': {'descr': 'the first arg.'},
        'B': {'descr': 'the second arg.'},
    }
    assert d.returns == {'descr': 'the return value.'}

    docstring = '/**\n' \
                ' * @arg A the first arg.\n' \
                ' * @arg B the second arg.\n' \
               

# Generated at 2022-06-11 21:33:40.608853
# Unit test for function parse
def test_parse():
    text = '''\
    hello this is a test

    :param: str a
    :param: str b

    '''
    result = parse(text)
    assert result.short_description == 'hello this is a test'
    assert result.params['a'].type_name == 'str'
    assert result.returns_type.type_name == 'None'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:33:48.393245
# Unit test for function parse
def test_parse():
    docstring = """:param param1: the first parameter
    :param param2: the second parameter
    :returns: description of return value
    :raises keyError: raises an exception
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == ''
    assert parsed_docstring.long_description == ''
    assert str(parsed_docstring) == (
        ":param param1: the first parameter\n"
        "    :param param2: the second parameter\n"
        "    :returns: description of return value\n"
        "    :raises keyError: raises an exception\n")
    assert parsed_docstring.params[0].arg_name == 'param1'
    assert parsed_docstring.params[0].description == 'the first parameter'


# Generated at 2022-06-11 21:34:01.258718
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    print('test 1')
    print(parse('''\
    Hello
    '''))
    print('test 2')
    print(parse('''\
    Hello
    :param y:
    '''))
    print('test 3')
    print(parse('''\
    Hello
    :param x:
    :returns:
    '''))
    print('test 4')
    print(parse('''\
    Hello
    :param x:
    :returns:
    :raises:
    '''))
    print('test 5')
    print(parse('''\
    Hello
    :param x:
    :returns:
    :raises:
    :rtype:
    '''))

# Generated at 2022-06-11 21:34:05.665807
# Unit test for function parse
def test_parse():
    def test_function():
        '''A function which returns 1, 2
        or 3.
        '''
        return 0

    docstring = test_function.__doc__
    assert parse(docstring).summary == 'A function which returns 1, 2 or 3.'


# Generated at 2022-06-11 21:34:14.571122
# Unit test for function parse
def test_parse():
    # Test for Parameter style
    text = """  """
    test_ret = parse(text, style=Style.numpy)
    assert test_ret.meta == []
    assert test_ret.long_description == ""
    assert test_ret.short_description == ""
    assert test_ret.returns == None
    assert test_ret.yields == None
    assert test_ret.raises == []
    assert test_ret.warns == []
    assert test_ret.attributes == {}

    text = """This is a function to do something.

    Parameters
    ----------
    p1 : {'a', 'b'}
        Parameter 1.
    p2 : int, optional
        Parameter 2.

    Returns
    -------
    result : int
        Result of the function."""

# Generated at 2022-06-11 21:34:16.878103
# Unit test for function parse
def test_parse():
    s = '''Hello
This is a test.
    '''
    ret = parse(s)
    assert str(ret) == s

# Generated at 2022-06-11 21:34:25.069285
# Unit test for function parse
def test_parse():
    import os
    os.chdir('../')
    text = """\
        Return a list of the strings in the sequence sorted in case-insensitive
        ascending order.

        Check that all strings in a sequence is titlecase.

        :param sequence: sequence of strings
        :type  sequence: :py:class:`collections.abc.Sequence`
        :returns: case-insensitive ascending sorted sequence
        :rtype: list
        :raises TypeError: if all strings in *sequence* are not in titlecase
        """
    result = parse(text)
    assert result.short_description == 'Return a list of the strings in the sequence sorted in case-insensitive ascending order.'
    assert result.long_description == 'Check that all strings in a sequence is titlecase.'
    assert len(result.meta) == 3

# Generated at 2022-06-11 21:34:34.601383
# Unit test for function parse
def test_parse():
    # Test with a few styles
    docstring = parse("""
This is a description.

Args:
    param1: description
    param2: description

Returns:
    description
""")
    assert docstring.short_description == "This is a description."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.raises) == 0
    assert len(docstring.returns) == 1
    # Test with a few different kinds of styles
    docstring = parse("""
This is a description.

.. note::
    Long description

Args:
    param1: description
    param2: description

Returns:
    description
""")
    assert docstring.short_description == "This is a description."

# Generated at 2022-06-11 21:34:46.173486
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.google import GoogleDocstring
    from docstring_parser.styles.sphinx import SphinxDocstring
    from docstring_parser.styles.numpy import NumpyDocstring

    assert Docstring() == parse('')
    assert Docstring() == parse(' ')
    assert Docstring('', 'a') == parse('a')
    assert Docstring('', 'a') == parse('a ')
    assert Docstring('', 'a') == parse(' a')
    assert Docstring('') == parse('\n\n')
    assert Docstring('') == parse(' \n\n')
    assert Docstring('', 'a') == parse('a\n\n')
    assert Docstring('', 'a') == parse('a \n\n')
    assert Docstring('', 'a') == parse

# Generated at 2022-06-11 21:34:51.478881
# Unit test for function parse
def test_parse():
    text = """
    Parameters
    ----------
    a : int
    b : str
    """
    assert parse(text).params == [
        {'name': 'a', 'type': 'int', 'desc': ''},
        {'name': 'b', 'type': 'str', 'desc': ''},
    ]


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:35:01.446750
# Unit test for function parse
def test_parse():
    text = '''\
    The quick brown fox jumps over the lazy dog.
    
    Args:
        param1: The first parameter.
        param2: The second parameter.
    
    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    style = Style.google
    docstring = parse(text, style=style)
    print("description:", docstring.description)
    print("short_description:", docstring.short_description)
    print("long_description:", docstring.long_description)
    print("params:", docstring.params)
    print("returns:", docstring.returns)
    print("return:", docstring.returns)
    print("raises:", docstring.raises)
    print("meta:", docstring.meta)
   

# Generated at 2022-06-11 21:35:07.060830
# Unit test for function parse
def test_parse():
    docstring_1 = """Summary line.
    Extended description.
    Args:
        arg1: Description of arg1
        arg2: Description of arg2
    Returns:
        Description of return value
    """
    result_1 = parse(docstring_1)
    print(result_1)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:35:21.195608
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    from docstring_parser.styles import Style
    from pprint import pprint


# Generated at 2022-06-11 21:35:25.205778
# Unit test for function parse
def test_parse():
    def increment(self):
        """ Increase the value of the number by one.
        """
        self.number += 1

    docstring = parse(increment.__doc__)
    assert docstring.short_description == "Increase the value of the number by one."

# Generated at 2022-06-11 21:35:28.919268
# Unit test for function parse
def test_parse():
    text = """Single line docstring.

:param foo: parameter foo is bar
:param bar: parameter bar is foo
:returns: dict
"""
    assert parse(text)


# Generated at 2022-06-11 21:35:32.726080
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == 'Parse the docstring into its components.\n\n    :param text: docstring text to parse\n    :param style: docstring style\n    :returns: parsed docstring representation\n    '

# Generated at 2022-06-11 21:35:38.861284
# Unit test for function parse
def test_parse():
    # print(STYLES['google'])
    text = """\
Module summary line.

This is a multi-line docstring.

Parameters
----------
arg1 : int
    The first value.
arg2 : str
    The second value.
    Continued here.

Returns
-------
bool
    True if successful, False otherwise."""
    print(parse(text, Style.google))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:49.755305
# Unit test for function parse
def test_parse():
    doc = parse("""Summary line.

Description

Args:
    param1: The first parameter.
    param2: The second parameter.

Keyword Args:
    kwarg1: The first keyword param.
    kwarg2: The second keyword param.

Returns:
    bool: The return value. True for success, False otherwise.

Raises:
    AttributeError, KeyError

""")
    assert doc.short_description == "Summary line."
    assert doc.short_description == doc.summary
    assert doc.description == "Description"
    assert doc.meta["args"][0].arg_name == "param1"
    assert doc.meta["args"][0].description == "The first parameter."
    assert doc.meta["args"][1].arg_name == "param2"
    assert doc

# Generated at 2022-06-11 21:36:00.719489
# Unit test for function parse
def test_parse():
    pass

# Test for passing args
    test_s = """
Tensorflow version of densenet
"""
    parsed = parse(test_s)
    print(parsed)
    assert parsed.short_description == "Tensorflow version of densenet"

# Test for passing kwargs
    test_s = """
This method implements bbox reverse fine-tuning. It computes the
ground-truth regression values for a  collection of anchors, prunes the
collection by removing all anchors that have an IoU with any target box
above a specified threshold, and adds ground-truth regression values
to the remaining set of anchors.
"""
    parsed = parse(test_s, style=Style.auto)
    print(parsed)

# Generated at 2022-06-11 21:36:06.857880
# Unit test for function parse
def test_parse():
    assert parse("hello") == Docstring("hello", [])
    assert parse("hello world") == Docstring("hello world", [])
    assert parse("hello", Style.structured) == Docstring("hello", [])
    assert parse("hello world", Style.structured) == Docstring("hello world", [])
    assert parse("summary\n\nhello\n") == Docstring("summary", ["hello"])
    assert parse("summary\n\nhello\n", Style.structured) == Docstring("summary", ["hello"])
    assert parse("hello\n\nworld") == Docstring("hello", ["world"])
    assert parse("hello\n\nworld", Style.structured) == Docstring("hello", ["world"])