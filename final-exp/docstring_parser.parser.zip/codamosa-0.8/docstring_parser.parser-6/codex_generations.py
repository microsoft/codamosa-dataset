

# Generated at 2022-06-11 21:26:13.820147
# Unit test for function parse
def test_parse():
    assert parse("")

if __name__ == "__main__":
     main()

# Generated at 2022-06-11 21:26:23.889123
# Unit test for function parse
def test_parse():
    # Test with multi-line docstring
    ml_doc = """\
This is the first line of the docstring.

This is the second line of the docstring.

This is the third line of the docstring."""    
    style = Style.google
    doc = parse(ml_doc,style)
    assert doc.short_description == "This is the first line of the docstring."
    assert doc.long_description == "This is the second line of the docstring.\n\nThis is the third line of the docstring."

    # Test with single-line docstring
    sl_doc = "This is the first line of the docstring."
    doc = parse(sl_doc,style)
    assert doc.short_description == "This is the first line of the docstring."
    assert doc.long_description == None

# Generated at 2022-06-11 21:26:26.682919
# Unit test for function parse
def test_parse():
    print(parse("""
        test function
        """))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:26:33.896531
# Unit test for function parse
def test_parse():
    test_doc = """some description
    :param int var_name: description of the first variable
    :param str var_name: description of the second variable
    """
    test_expect = Docstring(  
        description = "some description",
        style = Style.default,
        meta = [
            ("param", "int var_name", "description of the first variable"),
            ("param", "str var_name", "description of the second variable")
        ]
    )
    test_return = parse(test_doc, test_expect.style)
    assert test_return == test_expect

# Generated at 2022-06-11 21:26:45.188265
# Unit test for function parse
def test_parse():
    text = '''
    Summary line.

    Extended description.

    :param str dir: the directory name to consider. Optional.
    :param int level: the level to use.  Defaults to 1.

    :returns: the directory name.
    :rtype: str
    '''
    data = parse(text)
    assert data.summary == 'Summary line.'
    assert data.description == 'Extended description.'
    assert data.extended_description == 'Extended description.'

# Generated at 2022-06-11 21:26:56.730863
# Unit test for function parse
def test_parse():
    assert parse('').summary == ''
    assert parse('Nothing').summary == 'Nothing'
    assert parse('A simple sentence.').summary == 'A simple sentence.'
    assert parse('A simple sentence.\n').summary == 'A simple sentence.'
    assert parse('A simple sentence with a newline.\n').summary == 'A simple sentence with a newline.'
    assert parse('A simple sentence with a newline.\n\n').summary == 'A simple sentence with a newline.'
    assert parse('A simple sentence with a newline.\n\n').description == ''
    assert parse('A simple sentence.\n\nA description.').description == 'A description.'
    assert parse('A simple sentence.\nA description.\n').description == 'A description.'


# Generated at 2022-06-11 21:27:02.781690
# Unit test for function parse
def test_parse():
    from .test_parsers import common_test_cases
    for style, case in common_test_cases:
        try:
            docstring = parse(case.text, style)
            assert docstring.summary == case.summary
            assert docstring.meta == case.meta_dict
        except Exception as e:
            print(case.text)
            print(e)

# Generated at 2022-06-11 21:27:08.000861
# Unit test for function parse
def test_parse():
    # Test parse routine for each possible docstring style
    for style in STYLES.keys():
        text = 'This is a test docstring'
        docstring = parse(text, style)
        assert docstring.text == text

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:27:11.071469
# Unit test for function parse
def test_parse():
    assert str(parse("A docstring.")) == 'Docstring(summary: "A docstring.", style: None)'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:27:21.911758
# Unit test for function parse
def test_parse():
    test_docstring = \
"""Basic example.

:param arg1: first argument
:type arg1: int
:param arg2: second argument
:type arg2: str
:returns: arg1 + arg2
:rtype: str
"""
    test_docstring_2 = \
"""Basic example.

:param arg1: first argument
:param arg2: second argument
:returns: arg1 + arg2
:rtype: str
"""

    parsed_docstring = parse(test_docstring)
    parsed_docstring2 = parse(test_docstring_2)

    def test_parsed_docstring(parsed_docstring):
        assert parsed_docstring.short_description == 'Basic example.'
        assert parsed_docstring.long_description == ''

# Generated at 2022-06-11 21:27:27.023589
# Unit test for function parse

# Generated at 2022-06-11 21:27:32.405550
# Unit test for function parse
def test_parse():
    assert parse("""\
        Module summary line.

        This is a multi-line summary description.
        """, Style.pep257) == Docstring(
            summary='Module summary line.',
            body='This is a multi-line summary description.',
            meta={})

    assert parse("""\
        Module summary line.

        This is a multi-line summary description.
        """, Style.google) == Docstring(
            summary='Module summary line.',
            body='This is a multi-line summary description.',
            meta={})

# Generated at 2022-06-11 21:27:42.507963
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyleDocstring
    from docstring_parser.styles import NumpyStyleDocstring
    from docstring_parser.styles import NumpyExampleDocstring
    from docstring_parser.styles import GoogleExampleDocstring

    test = "/**\n *\n */"
    assert isinstance(parse(test, style=Style.google), GoogleStyleDocstring)
    assert isinstance(parse(test, style=Style.numpy), NumpyStyleDocstring)
    assert isinstance(parse(test, style=Style.numpy_example), NumpyExampleDocstring)
    assert isinstance(parse(test, style=Style.google_example), GoogleExampleDocstring)

    test = """/****************************************************************
     *   '__init__' cannot be private
     ****************************************************************/"""

# Generated at 2022-06-11 21:27:47.476057
# Unit test for function parse
def test_parse():
    docstring = '''
    Author: Jason Yang
    file: test_parse.py
    Purpose: a unit test for function parse in main.py
    '''

    print(parse(docstring, style=Style.restructured))
    print("If there is no error output, that means this test has passed!")

# Generated at 2022-06-11 21:27:55.727363
# Unit test for function parse
def test_parse():
    docstring = '''First line.

    second paragraph

    :param name: foo
    :type name: str
    :param age: bar
    :type age: int
    :returns: foobar
    :rtype: str
    '''
    result = parse(docstring, Style.numpy)
    assert result.short_description == 'First line.'
    assert result.long_description == 'second paragraph'
    assert result.returns.description == 'foobar'
    assert result.returns.type_annotation == 'str'
    assert result.meta['name'].description == 'foo'
    assert result.meta['name'].type_annotation == 'str'
    assert result.meta['age'].description == 'bar'
    assert result.meta['age'].type_annotation == 'int'

#

# Generated at 2022-06-11 21:28:03.266367
# Unit test for function parse
def test_parse():
    def f():
        """Hellow world

        This is a test.

        (:param a: aa)
        (:param b: bb)

        (:returns: 10)
        """
        pass

    docstring = parse(f.__doc__)

    assert docstring.summary == "Hellow world"
    assert len(docstring.content) == 2
    assert docstring.content[0] == "This is a test."
    assert docstring.params == {"a": "aa", "b": "bb"}
    assert docstring.returns == "10"



# Generated at 2022-06-11 21:28:09.962210
# Unit test for function parse
def test_parse():
    txt = """\
        This is the first line.
        
        This is another line.
        
        :type: type
        :rtype: int
        :param str arg0: This is a short argument.
        :param arg1: This is a short argument.
        """
    doc = parse(txt)
    assert doc.short_desc == "This is the first line."
    assert doc.long_desc == "This is another line."
    assert doc.meta["type"] == "type"
    assert doc.meta["rtype"] == "int"
    assert doc.params[0].arg_name == "arg0"
    assert doc.params[1].arg_name == "arg1"


# Generated at 2022-06-11 21:28:20.838389
# Unit test for function parse
def test_parse():
    assert parse('""")') == {
        'meta': {},
        'short_description': '',
        'long_description': '',
        'extended_sections': [],
    }
    assert parse('"""\n"""') == {
        'meta': {},
        'short_description': '',
        'long_description': '',
        'extended_sections': [],
    }
    assert parse('"""hello world\n""') == {
        'meta': {},
        'short_description': 'hello world',
        'long_description': '',
        'extended_sections': [],
    }

# Generated at 2022-06-11 21:28:26.355209
# Unit test for function parse
def test_parse():
    docstring = """
    Name:
        parse
    Description:
        The main parsing routine.
    Returns:
        parsed docstring representation
    """
    parsed = parse(docstring)
    assert parsed.name == "parse"
    assert parsed.description == (
        "The main parsing routine."
    )

# Generated at 2022-06-11 21:28:37.542709
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Description, Params, Returns, Example
    from docstring_parser.docstring import NumpyDocstring
    from docstring_parser.styles import NumpyStyle
    docstring = parse('''
    Parameters
    ----------
    string : str
        String to be converted to integer.  The optional base
        defines the base if string is a number.
    base : int, optional
        Base of the number in string.''', style=NumpyStyle)
    assert isinstance(docstring, NumpyDocstring)
    assert docstring.meta['Parameters'][0].name == 'string'
    assert docstring.meta['Parameters'][0].type == 'str'

# Generated at 2022-06-11 21:28:43.487001
# Unit test for function parse
def test_parse():
    docstring = '''
    Line 1
    Line 2
    '''
    assert parse(docstring).summary == '''
    Line 1
    Line 2
    '''.strip()

# Generated at 2022-06-11 21:28:49.363970
# Unit test for function parse
def test_parse():
    def func(a):
        """
        docstring for function
        """
        return a

    doc = parse(func.__doc__)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.returns)
    print(doc.parameters)
    print(doc.raises)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:28:59.242877
# Unit test for function parse
def test_parse():
    test_docstring_string = ("The main parsing routine.\n"
                             "\n"
                             ":param text: docstring text to parse\n"
                             ":param style: docstring style\n"
                             ":returns: parsed docstring representation\n")
    assert isinstance(parse(test_docstring_string), Docstring)
    assert isinstance(parse(test_docstring_string, Style.numpy), Docstring)
    assert isinstance(parse(test_docstring_string, Style.google), Docstring)
    assert isinstance(parse(test_docstring_string, Style.sphinx), Docstring)
    assert isinstance(parse(test_docstring_string, Style.auto), Docstring)

# Generated at 2022-06-11 21:29:03.452102
# Unit test for function parse
def test_parse():
    import pprint
    text = """
    This is a summary paragraph

    This is a description paragraph
    """
    result = parse(text)
    pprint.pprint (result.__dict__)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:06.992565
# Unit test for function parse
def test_parse():
    docstring_parser.parse("""\
        Summary line here.

        Extended description here.

        Args:
          arg1 (int): Description of arg1
          arg2 (str): Description of arg2

        Returns:
          bool: Description of return value

        Raises:
          AttributeError: The ``Raises`` section is a list of all exceptions
          that are relevant to the interface.
          ValueError: If `param2` is equal to `param1`.
        """)

# Generated at 2022-06-11 21:29:16.012503
# Unit test for function parse
def test_parse():
    text = """
    Extracts all **key**, **value** pairs from a given **source** object.

    :param source: object from which to extract ``**key**, **value**`` pairs
    :param items: optional dictionary containing items to override

    :returns: dictionary of ``**key**, **value**`` pairs
    """
    result = parse(text)
    # result.short_description, result.long_description, result.sections
    assert result.short_description == "Extracts all **key**, **value** pairs from a given **source** object."
    assert result.long_description is None
    assert len(result.sections) == 3
    assert len(result.sections[0].params) == 1
    assert len(result.sections[1].params) == 1
    assert len(result.sections[2].params)

# Generated at 2022-06-11 21:29:18.198973
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:23.301417
# Unit test for function parse
def test_parse():
    text1 = """
    This is a function to find the maximum of two numbers
    :param a: first number
    :param b: second number(should be integer)
    :returns: maximum of the two numbers
    """
    print(parse(text1, style=Style.numpy))

# Generated at 2022-06-11 21:29:25.600190
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:31.761014
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()
    parse("""\
    Summary line.

    Extended description.

    :param arg1: Description of arg1
    :param arg2: Description of arg2
    :type arg1: str
    :type arg2: List[str]
    :returns: Description of return value
    :rtype: int
    :raises keyError: Independence of raising exceptions
    :raises TypeError: Dependence on arg1
    :raises AttributeError: Dependence on arg2
    """)



# Generated at 2022-06-11 21:29:44.651014
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Return
    contents =parse("""Return1: Returns a string that is the given or default string, or None.
Return2: This is a string.
Return3: This is a string too.
Arguments:
    value: a string
    default: a string
    """
    )
    returns = Return(description="Returns a string that is the given or default string, or None.")
    assert contents.returns == [returns]
    assert contents.meta["Arguments"][0] == " value: a string default: a string"
    assert contents.returns[0].description == "Returns a string that is the given or default string, or None."

# Generated at 2022-06-11 21:29:55.003273
# Unit test for function parse
def test_parse():
    name = "parse"
    msg = "parse should be a function that takes a str and a Style"
    assert callable(parse), msg
    msg = "parse should take exactly two arguments"
    assert len(inspect.signature(parse).parameters) == 2, msg
    s = "parse should take a docstring (str) argument"
    assert inspect.signature(parse).parameters["text"].annotation == str, s
    s = "parse should take a docstring style (Style) argument"
    assert inspect.signature(parse).parameters["style"].annotation == Style, s
    x = validate.validator(name)

# Generated at 2022-06-11 21:30:05.273474
# Unit test for function parse
def test_parse():
    test_docstring = '''Sum things up.

Parameters
----------
a : int
    The first number.
b : int
    The second number.

Returns
-------
int
    The sum.
'''
    # test getting style from docstring
    test_d = parse(test_docstring, style=Style.google)
    print(test_d.short_description)
    assert str(test_d.short_description) == 'Sum things up.'
    assert str(test_d.long_description) == ''
    assert str(test_d.rtype) == 'int'
    print(test_d.rst_fields)
    assert test_d.rst_fields == {'Parameters': '', 'Returns': ''}

# Generated at 2022-06-11 21:30:16.549657
# Unit test for function parse
def test_parse():
    assert parse.__name__ == 'parse'
    test_data = """
   Parameters:
       learning_rate (float): learning rate
       decay_rate (float): coefficient of exponential decay

   Returns:
       The output tensor.
    """

# Generated at 2022-06-11 21:30:26.278473
# Unit test for function parse
def test_parse():
    # auto detect
    text = """This is a `Sphinx`_ documentation of a `Python`_ library.
    """
    doc = parse(text)
    assert doc.short_description == 'This is a `Sphinx`_ documentation of a `Python`_ library.'
    assert doc.long_description == ''
    assert doc.meta == {}

    # numpy
    text = """This is a `Sphinx`_ documentation of a `Python`_ library.

    Parameters
    ----------
    key : value

    Returns
    -------
       return type is int
    """
    doc = parse(text, style=Style.numpy)
    assert doc.short_description == 'This is a `Sphinx`_ documentation of a `Python`_ library.'
    assert doc.long_description == ''

# Generated at 2022-06-11 21:30:35.436545
# Unit test for function parse
def test_parse():
  #checks for the return value, that includes the parameters
  #parse()
  assert parse("test") == 'test'
  assert parse("test2") == 'test2'

  #parse(text: str)
  assert parse("3") == '3'
  assert parse("aa") == 'aa'

  #parse(text: str, style: Style = Style.auto)
  assert parse("test", "Style.auto") == 'test'
  assert parse("test2", "Style.auto") == 'test2'
  assert parse("test", "Style") == 'test'
  assert parse("test2", "Style") == 'test2'


  #parse(text: str, style: Style = Style.auto) -> Docstring
  assert parse("3", "Style.auto") == '3'

# Generated at 2022-06-11 21:30:38.058514
# Unit test for function parse
def test_parse():
    assert parse("This is a docstring", Style.google)
    assert parse("This is a docstring", Style.sphinx)
    assert parse("This is a docstring", Style.numpy)
    assert not parse("This is a docstring")
    assert parse("This is a docstring", Style.pep257)

# Generated at 2022-06-11 21:30:49.817810
# Unit test for function parse
def test_parse():
    assert(parse("Function that returns 0.") == Docstring(params=[], returns=None, raises=[], other=[], summary="Function that returns 0", meta={}))
    # assert(parse("Function that returns 0.\n\nArgs:\n    a (int): Input parameter 1.\n\nReturns:\n    int: The computed value.") == Docstring(params=[{"name": "a", "type": "int", "desc": "Input parameter 1."}], returns={"type": "int", "desc": "The computed value"}, raises=[], other=[], summary="Function that returns 0", meta={}))
    # assert(parse("Function that returns 0.\n\nParameters\n----------\n    a (int): Input parameter 1.\n\nReturns\n-------\n    int: The computed value.") == Docstring(params=[{"name": "

# Generated at 2022-06-11 21:30:59.788366
# Unit test for function parse
def test_parse():
    text = """\
Usage Examples
-------------

This class is used for parsing the :py:mod:`docstring` in python modules.

.. code:: pycon

    >>> from docstring_parser import parse
    >>> docstring = parse(__doc__)
    >>> docstring.short_description
    'Usage Examples'
    >>> docstring.long_description
    'This class is used for parsing the docstring in python modules.'
    >>> docstring.params['text']
    'docstring text to parse'
    >>> docstring.returns
    'parsed docstring representation'
    >>> docstring.raises['ParseError']
    'if there is incorrect indentation in the docstring'
    >>> docstring.meta['author']
    'Oleksandr Kovalchuk <okovalchuk@fastmail.fm>'
    """

# Generated at 2022-06-11 21:31:07.366942
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, Meta, Params

    text = '''
    Args:
        arg1 (str): description for arg1
        arg2 (Optional[str]): description for arg2

    Returns:
        str: description for return value

    '''
    doc = Docstring(
        summary='',
        description='',
        meta=Meta(
            params=[
                Params(
                    name='arg1',
                    type=['str'],
                    desc='description for arg1')
            ],
            returns=Params(
                name='',
                type=['str'],
                desc='description for return value')
        )
    )
    assert parse(text) == doc

# Generated at 2022-06-11 21:31:12.354499
# Unit test for function parse
def test_parse():
    assert parse("""This is a docstring""") == parse("""This is a docstring""")


# Generated at 2022-06-11 21:31:24.531303
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring
    """
    assert(parse(text).description == text.strip())

    # Test style
    text = """
    :param arg1: this is arg1
    :param arg2: this is arg2
    :returns: description
    """
    assert(parse(text, Style.sphinx).params[0] == ("arg1", "this is arg1"))
    assert(parse(text, Style.sphinx).returns[0] == "description")

    # Test Style.auto
    text = """
    :param arg1: this is arg1
    :param arg2: this is arg2
    :returns: description
    """
    assert(parse(text).params[0] == ("arg1", "this is arg1"))

# Generated at 2022-06-11 21:31:25.580872
# Unit test for function parse

# Generated at 2022-06-11 21:31:35.425733
# Unit test for function parse

# Generated at 2022-06-11 21:31:46.451546
# Unit test for function parse
def test_parse():
    doc = parse(
        """
    Title

    Parameters
    ----------
    first : type
        the first parameter

    Other Parameters
    ----------------
    second :
        the second parameter
    """
    )
    assert doc.title == "Title"
    assert doc.description == ""
    assert doc.params["first"].type_name == "type"
    assert doc.params["second"].description == "the second parameter"
    assert doc.params["second"].name == "second"
    assert doc.params["second"].type_name == ""
    assert doc.params["second"].optional is False
    assert doc.params["second"].no_type is False
    assert doc.returns is None
    assert doc.yields is None
    assert doc.raises is None
    assert doc.warns is None
   

# Generated at 2022-06-11 21:31:56.274203
# Unit test for function parse
def test_parse():
    docstring = parse(
        """Summary line.

    Extended description.

    Args:
      arg1 (int): Description of arg1
      arg2 (str): Description of arg2
    Returns:
      int: Description of return value
    """
    )

    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."
    assert str(docstring) == (
        """Summary line.\n\nExtended description.\n\nArgs:\n  arg1 (int): Description of arg1\n  arg2 (str): Description of arg2\nReturns:\n  int: Description of return value\n"""
    )


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:07.608399
# Unit test for function parse
def test_parse():
    a = parse("""
        :param request: a http request
        :param another_param: another param
        :return: a http response
        :raises ServerError: a server error
    """)
    assert a.returns is not None
    assert a.raises is not None
    assert a.params is not None

    b = parse("""
        :param request: a http request
        :param another_param: another param
        :return: a http response
        :raises ServerError: a server error
    """, Style.numpy)
    assert b.returns is not None
    assert b.raises is not None
    assert b.params is not None


# Generated at 2022-06-11 21:32:19.003866
# Unit test for function parse
def test_parse():
    assert(parse("""\
    Counting up
    ===========
    This function simply returns a number increased by 1.

    Args:
        x (int): number to increase

    Returns:
        int: increased number

    Examples:
        >>> count_up(1)
        2
    """))
    assert(parse("""\
    Counting up
    ===========
    This function simply returns a number increased by 1.

    Args:
        x (int): number to increase
    """))
    assert(parse("""\
    Counting up
    ===========
    This function simply returns a number increased by 1."""))

# Generated at 2022-06-11 21:32:30.779276
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    assert parse("") == Docstring(short_description="", long_description="")
    assert (
        parse("This is a short description.\n\nThis is a long description.\n")
        == Docstring(
            short_description="This is a short description.",
            long_description="This is a long description.",
        )
    )
    assert (
        parse('This is a short description.\n\nThis is a long description.\n\n:param t: test')
        == Docstring(
            short_description="This is a short description.",
            long_description="This is a long description.",
            meta=[
                dict(name="param", arg="t", content="test", optional_type=None)
            ],
        )
    )

# Generated at 2022-06-11 21:32:36.475911
# Unit test for function parse
def test_parse():
    docstring = """One line summary.

    Extended description.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.

    """
    one = parse(docstring)
    print(one.short_description)
    print(one.long_description)
    print(one.params)
    print(one.returns)
    print(one.meta)

test_parse()

# Generated at 2022-06-11 21:32:46.846616
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

Extended description.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`

Returns
-------
bool
    Description of return value
"""
    d = parse(docstring)
    print(d)
    """

    'Summary line.\n\nExtended description.'
    'Parameters\n----------\narg1 : int\n    Description of `arg1`\narg2 : str\n    Description of `arg2`\n\nReturns\n-------\nbool\n    Description of return value'

"""

# Generated at 2022-06-11 21:32:57.813289
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    docstring = """Parses a docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    doc = parse(docstring)
    assert doc.short_description == 'Parses a docstring into its components.'
    assert doc.long_description == ''
    assert len(doc.params) == 2
    assert doc.params['text'].description == 'docstring text to parse'
    assert doc.params['style'].description == 'docstring style'
    assert len(doc.returns) == 1
    assert doc.returns['returns'].description == 'parsed docstring representation'


# Generated at 2022-06-11 21:33:02.703615
# Unit test for function parse
def test_parse():
    text = """
    Summary line.

    Extended description of function.
    """
    ret = parse(text)
    assert len(ret.meta) == 2
    assert ret.meta["summary"] == "Summary line."
    assert ret.meta["extended"] == "Extended description of function."

# Generated at 2022-06-11 21:33:07.417746
# Unit test for function parse
def test_parse():
    from docstring_parser.version import __version__ as docstring_version
    docstring = parse("""\
    This is a short summary.
    This is the extended summary which can go on for a number of lines.

    This is the extended description.

    Args:
        arg1: The first arg.
        arg2 (int): The second arg.

    Returns:
        A returned value.

    Raises:
        ValueError: For invalid input.

    Yields:
        A yielded value.
    """)
    assert docstring.short_description == 'This is a short summary.'
    assert docstring.long_description.startswith('This is the extended summary')
    assert docstring.unformatted == 'This is the extended description.'
    assert len(docstring.args) == 2

# Generated at 2022-06-11 21:33:17.296565
# Unit test for function parse
def test_parse():
    docstr='''Python 3.4.3 (v3.4.3:9b73f1c3e601, Feb 23 2015, 02:52:03) 
    [GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin
    Type "help", "copyright", "credits" or "license" for more information.
    >>> print(1)
    1
    '''
    res = parse(docstr)
    assert(res.short_description == "Python 3.4.3 (v3.4.3:9b73f1c3e601, Feb 23 2015, 02:52:03) \n    [GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin")

# Generated at 2022-06-11 21:33:21.226454
# Unit test for function parse
def test_parse():
    x = """
Summary line.

    Extended description.
"""
    assert type(parse(x)) == Docstring
    assert parse(x).summary == "Summary line."

# Generated at 2022-06-11 21:33:32.076849
# Unit test for function parse

# Generated at 2022-06-11 21:33:41.173084
# Unit test for function parse
def test_parse():
    doc = parse('This is summary.\n\nEmpty line\n\nThis is description.', Style.rst)
    assert(doc.short_desc == 'This is summary.')
    assert(doc.long_desc == 'Empty line\n\nThis is description.')

    doc = parse('This is summary.\n\nEmpty line\n\nThis is description.', Style.numpy)
    assert(doc.short_desc == 'This is summary.')
    assert(doc.long_desc == 'This is description.')

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:33:46.978082
# Unit test for function parse
def test_parse():
	print("Parsing:")
	text = """
	Parses a Docstring into its components.
	:param text: docstring text to parse
	:param style: docstring style.
	"""
	docstring = parse(text)
	print("Docstring:")
	print(docstring)
	print("\nDescription:")
	print(docstring.description)
	print("\nParamaters:")
	print(docstring.params)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:33:51.438226
# Unit test for function parse
def test_parse():
	text = """The ``parse`` function.

	:param doc: docstring text to parse
	:param style: docstring style
	:returns: parsed docstring representation
	"""
	print(parse(text))

if __name__ == '__main__':
	test_parse()

# Generated at 2022-06-11 21:33:58.563036
# Unit test for function parse
def test_parse():
    """Test function parse."""
    assert parse('Hello _world_!', Style.rest) == Docstring('Hello _world_!', [], [], [], [], [], [], {}, '')
    assert parse('Hello _world_!', Style.sphinx) == Docstring('', [], [], [], [], [], [], {}, 'Hello _world_!')

# Generated at 2022-06-11 21:34:04.872421
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

# Generated at 2022-06-11 21:34:06.362644
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:34:10.321538
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", body="", returns=None, meta={})
    assert parse("Summary.") == Docstring(summary="Summary.", body="", returns=None, meta={})
    
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:34:17.933608
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = "Just a test"
    docstring = parse(text, style=Style.auto)
    assert docstring.meta is None
    assert docstring.short_desc == ''
    assert docstring.long_desc == ''
    assert docstring.returns is None
    assert docstring.raises is None
    assert docstring.yields is None
    assert docstring.extra_args is None
    assert docstring.extra_kwargs is None


# Generated at 2022-06-11 21:34:21.306732
# Unit test for function parse
def test_parse():
    text1 = """The main parsing routine."""
    docstring = parse(text1, style=Style.numpy)
    assert(docstring.short_description == 'The main parsing routine.')


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:34:22.956683
# Unit test for function parse
def test_parse():
    result = parse("""text""")
    assert result.text == "text"


# Generated at 2022-06-11 21:34:29.640029
# Unit test for function parse
def test_parse():
    docstring = """
   Parameters
   ----------
   x : int
       The meaning of life.
   y : str
       And everything else.
"""
    assert parse(docstring).params[0].name == 'x'
    docstring = """
.. index::
   single: foo
   single: bar

Foo, bar, baz
"""
    assert parse(docstring).indexes[0].value == ['foo', 'bar']

# Generated at 2022-06-11 21:34:36.715737
# Unit test for function parse

# Generated at 2022-06-11 21:34:47.160737
# Unit test for function parse

# Generated at 2022-06-11 21:34:52.111867
# Unit test for function parse
def test_parse():
    text = "Summary line.\n\nModule description\n\n"
    doc = parse(text)
    assert doc.summary == "Summary line."
    assert doc.description == "Module description"

# Generated at 2022-06-11 21:34:58.719549
# Unit test for function parse
def test_parse():
    ds = parse(text='''
    Hello world.

    Description about hello world.
    Multi-line and so on.
    ''')
    print(ds.params)
    print(ds.meta)
    print(ds.summary)
    print(ds.extended_summary)
    print(ds.returns)
    print(ds.raises)
    print(ds.yields)
    print(ds.decorators)

# Generated at 2022-06-11 21:35:10.676839
# Unit test for function parse
def test_parse():
    from textwrap import dedent
    template = dedent('''\
        :Example:
        :Author: Michael Foord
        :Version: 1.0
        :Date: 2009-08-20
        :Copyright: 2009 by Michael Foord
        :Licence: BSD
        :Abstract: A template for new Python modules.
        :Requires: Python 2.6 or better
        :Keywords: module template, Python, foord
        :Rationale: How to structure a new module.
        :Notes: This is a template for new Python modules.

        This module is an example of how to structure your
        Python code.

        It is not intended to be used directly.
        ''')

# Generated at 2022-06-11 21:35:13.533735
# Unit test for function parse
def test_parse():

    test_text = """This is a test.
    """
    assert parse(test_text).short_description == "This is a test."

# Generated at 2022-06-11 21:35:22.324833
# Unit test for function parse
def test_parse():
    args = str(parse.__code__)
    assert 'docstring_parser.styles' in args, 'did you import the right package?'
    assert 'style' in args, 'does your function have an argument named `style`?'
    assert 'return' in args, 'does your function have a `return` statement?'
    assert 'parse_' in args, 'did you properly iterate over the styles?'
    assert 'STYLES' in args, 'did you access the right dictionary?'
    assert args.count('return') == 1, 'do you have more than one `return` statement?'
    assert 'len(d.meta)' in args, 'did you properly use the `len` function?'
    assert 'reverse=True' in args, 'did you sort your list in reverse?'

# Generated at 2022-06-11 21:35:27.967818
# Unit test for function parse
def test_parse():
    print(parse("This is a test."))
    print(parse("This is a test.","google"))
    print(parse("This is a test.","numpy"))
    print(parse("This is a test.","sphinx"))
    print(parse("This is a test.","github"))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:32.136369
# Unit test for function parse
def test_parse():
    docstring = '''
    The main parsing routine.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    parse(docstring)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:35:34.790335
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:35:41.092947
# Unit test for function parse
def test_parse():
    text = """
    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.
    param3 : list
        The third parameter.
    """
    res = parse(text)
    assert res.params == {
        'param1': {'type': 'int', 'desc': 'The first parameter.'},
        'param2': {'type': 'str', 'desc': 'The second parameter.'},
        'param3': {'type': 'list', 'desc': 'The third parameter.'}
    }
    assert res.meta == {}
    assert res.content == ''


# Generated at 2022-06-11 21:35:44.861928
# Unit test for function parse
def test_parse():
    text = '''
    Args:
        x : int
            The x coord.
    '''
    d = parse(text)
    print(d)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:35:57.717274
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    docstring = """Some docstring.

:param string name: the name to say hello to
:param int repeat: the number of times to say hello
:returns: None
"""
    parsed_docstring = parse(docstring)

    assert parsed_docstring.short_description == 'Some docstring.'
    assert parsed_docstring.long_description == ''
    assert parsed_docstring.params[0].name == 'name'
    assert parsed_docstring.params[0].type_name == 'str'
    assert parsed_docstring.params[0].description == 'the name to say hello to'
    assert parsed_docstring.params[1].name == 'repeat'
    assert parsed_docstring.params[1].type_name == 'int'

# Generated at 2022-06-11 21:36:04.989380
# Unit test for function parse
def test_parse():
    from docstring_parser.utils import get_docstring
    result = parse(get_docstring(test_parse.__doc__))
    assert result.short_description == 'Unit test for function parse'
    assert result.full_description == result.short_description
    # Check each attribute is parsed correctly
    assert result.meta == {'returns': [{
        'type': None,
        'description': 'Unit test for function parse'
    }]}


# Generated at 2022-06-11 21:36:15.256227
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.google import GoogleDocstring

    docstring = parse("""\
Sums two numbers.

:param a: first number
:param b: second number
:returns: sum of numbers
""")
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "Sums two numbers."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0
    assert len(docstring.others) == 0

    # No docstring given.
    assert parse("").short_description == ""

    # Auto-detect style.