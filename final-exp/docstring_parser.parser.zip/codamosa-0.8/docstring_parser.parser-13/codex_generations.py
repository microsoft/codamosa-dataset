

# Generated at 2022-06-11 21:26:23.353602
# Unit test for function parse
def test_parse():
    examples = ['hello', 'this is a test', 'yet another one']
    print('\nTesting function parse')
    print('input: ' + examples[0])
    print('output: ' + parse.__doc__)
    print('\nTesting function parse')
    print('input: ' + examples[1])
    print('output: ' + parse.__doc__)
    print('\nTesting function parse')
    print('input: ' + examples[2])
    print('output: ' + parse.__doc__)

# The code below is for testing the function parse
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:26:32.845638
# Unit test for function parse
def test_parse():
    # test docstring that is empty
    assert parse('').summary == ''

    # test docstring with one line
    assert parse('parse') == Docstring(
        summary='parse',
        description='',
        content='',
        meta={},
        exceptions=[],
        returns=None,
        attributes=[],
        methods=[],
        fields=[],
        others=[],
        see_also=[],
        module=None,
        keywords=[],
        variables=[],
        authors=[],
        notes=[],
        references=[],
        classes=[],
        raw=''
    )

    # test docstring with more than one line

# Generated at 2022-06-11 21:26:35.863089
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Style
    from docstring_parser.parser import parse
    from docstring_parser.parsers import GoogleDocstring

    assert parse('hello world', style=Style.auto) == GoogleDocstring('hello world')
    assert parse('hello world', style=Style.google) == GoogleDocstring('hello world')

# Generated at 2022-06-11 21:26:46.183220
# Unit test for function parse

# Generated at 2022-06-11 21:26:53.963376
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    text = '''
        Parse the docstring into its components.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        '''
    p = parse(text, style=Style.google)
    assert p.short_description == 'Parse the docstring into its components.'
    assert p.long_description == ''
    assert p.returns.name == 'returns'
    assert p.params[0].type == 'str'
    assert p.params[1].type == 'Style'

# Generated at 2022-06-11 21:26:57.916304
# Unit test for function parse
def test_parse():
    print(parse('hello'))
    print(parse('hello\ngoodbye'))
    print(parse(':param a:b\n\n'))
    print(parse('hello\n\n'))
    print(parse('hello\n\n\n'))
    print(parse('hello\n\n\n\n'))
    print(parse('hello\n\n\n\n\n'))

# Generated at 2022-06-11 21:27:09.492065
# Unit test for function parse

# Generated at 2022-06-11 21:27:21.388443
# Unit test for function parse
def test_parse():
    """Unit test for parse."""
    docstring = parse("""
        :param int a:
        :param int b:
        :returns:
        :rtype: int
        :raises ValueError:
    """)
    # print(docstring.params)
    # print(docstring.returns)
    # print(docstring.errors)
    assert None is not docstring.params
    assert None is not docstring.returns
    assert None is not docstring.errors
    # print(docstring.params)
    # print(docstring.returns)
    # print(docstring.errors)
    assert docstring.params.get("a")
    assert docstring.params.get("b")
    assert docstring.returns.get("returns")
    assert docstring.errors.get("ValueError")

# Generated at 2022-06-11 21:27:24.314936
# Unit test for function parse
def test_parse():
	text='''This is a sample docstring of a function.
	It assumes that the first argument is the input and the
	second is the output.'''
	parse(text)

# Generated at 2022-06-11 21:27:28.208674
# Unit test for function parse
def test_parse():
    text = """
    :param x: A parameter
    :returns: But this is a return
    """
    assert parse(text).sections[0].args[0].name == "x"
    assert parse(text).sections[1].args[0].name == "returns"

# Generated at 2022-06-11 21:27:37.714978
# Unit test for function parse
def test_parse():
    docstring = '''
    :param a: 
    :type a: int
    :param b: 
    :type b: int
    :return: 
    :rtype: int
    :returns:
    '''
    #print(parse(docstring))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:27:45.622226
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse(" ") == Docstring()
    assert parse("    ") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()

    assert parse("Hello world.") == Docstring(summary="Hello world.")
    assert parse("Hello world.\n") == Docstring(summary="Hello world.")
    assert parse("Hello world.\n\n") == Docstring(summary="Hello world.")
    assert parse("Hello world.\n\n\n") == Docstring(summary="Hello world.")


# Generated at 2022-06-11 21:27:52.256514
# Unit test for function parse
def test_parse():
    text=parse("""

    This is a hello world!
    \x0c

    :param int count: the number of hello worlds
    :returns: the hello world string
    :rtype: str

    """)
    assert text.meta['count']['type']=='int'
    assert text.meta['count']['desc']=='the number of hello worlds'
    assert text.returns['type']=='str'
    assert text.returns['desc']=='the hello world string'

# Generated at 2022-06-11 21:27:57.609179
# Unit test for function parse
def test_parse():
	assert parse("This is a test docstring.") == Docstring(summary="This is a test docstring.")
	assert parse("This is a test docstring.\n\nWith more lines.") == Docstring(summary="This is a test docstring.",
																				description=['With more lines.'])

# Generated at 2022-06-11 21:28:06.884199
# Unit test for function parse
def test_parse():
    text = '''
    fubar(foo, bar=None):
        '''
    docstring = parse(text, style=Style.google)
    assert docstring.short_description == ''
    assert docstring.long_description == ''
    assert docstring.tags == []

    text = '''
    fubar(foo, bar=None):
        Foo bar.
        '''
    docstring = parse(text, style=Style.google)
    assert docstring.short_description == 'Foo bar.'
    assert docstring.long_description == ''
    assert docstring.tags == []
    
    text = '''
    fubar(foo, bar=None):
        Foo bar.
        Foo bar too.
        '''
    docstring = parse(text, style=Style.google)
    assert docstring

# Generated at 2022-06-11 21:28:18.016477
# Unit test for function parse
def test_parse():
    d="""One line summary.

    Extended description.

    :param arg1: Description of arg1
    :type arg1: str
    :param arg2: Description of arg2
    :type arg2: int, optional
    :returns: Description of return value
    :rtype: int

    """
    assert parse(d, style=Style.numpy).sections[0].lines == ['Extended description.']
    assert parse(d, style=Style.numpy).sections[1].lines == ['', '    :param arg1: Description of arg1', '    :type arg1: str', '    :param arg2: Description of arg2', '    :type arg2: int, optional', '    :returns: Description of return value', '    :rtype: int', '']

# Generated at 2022-06-11 21:28:26.058180
# Unit test for function parse
def test_parse():
    docstr = '''
daemonize
    get the input, send it to the other side.
    if the other side is not there, store it in the
    queue and try to send it again later.
'''
    docstring = parse(docstr)
    assert docstring.short_description == 'daemonize'
    assert docstring.long_description == 'get the input, send it to the other side. if the other side is not there, store it in the queue and try to send it again later.'
    assert docstring.params == []
    assert docstring.returns == []

    docstr = '''
This is a very short description.

:param name: The name to use.
:type name: str.
:param state: Current state to be in.

:returns:  text
'''
    docstring = parse

# Generated at 2022-06-11 21:28:37.361185
# Unit test for function parse
def test_parse():
    func = lambda x: x
    func.__doc__ = """one-liner"""
    assert parse(func.__doc__).summary == "one-liner"

    func.__doc__ = """one-liner

multiline

- with
- bullet

- point

Some more
text
"""
    assert parse(func.__doc__).summary == "one-liner"
    assert parse(func.__doc__).description == "multiline\n\n- with\n- bullet\n\n- point\n\nSome more\ntext\n"
    assert parse(func.__doc__).metadata.keys() == set()
    assert parse(func.__doc__).signature == None
    assert parse(func.__doc__).return_annotation == None
    assert parse(func.__doc__).ex

# Generated at 2022-06-11 21:28:45.341098
# Unit test for function parse
def test_parse():
    text = """
    Single line description

    Parameters:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value

    Raises:
        TypeError: Description of exception
    """
    docstring = parse(text)
    assert docstring.short_description == "Single line description"
    assert docstring.long_description == ""
    assert len(docstring.meta) == 3
    assert len(docstring.sections) == 3
    assert len(docstring.returns) == 1
    return [docstring]

if __name__ == "__main__":
    print(test_parse())

# Generated at 2022-06-11 21:28:53.795413
# Unit test for function parse
def test_parse():
    # Should return an object with 25 entries and no exceptions
    test_string = """
    Function to get the full name of an NRL player, given the game they played in, their team and their surname.

    :param game: instance of the game class that the player played in.
    :param team: team that the player played for (e.g. 'Storm').
    :param surname: surname of the player.
    :returns: firstname and surname if player is found, otherwise 'not found'.
    """
    ts = parse(test_string)
    assert len(ts.fields) == 25


# Generated at 2022-06-11 21:29:09.448934
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""


# Generated at 2022-06-11 21:29:14.827426
# Unit test for function parse
def test_parse():
    text = '''
    :param type1 param1:
    :param type2 param2:
    :returns: type3
    '''
    docstring = parse(text, Style.numpy)
    assert docstring.params[0].name == 'param1'
    assert docstring.retvals[0].name == None
    assert docstring.params[0].type_name == 'type1'
    assert docstring.retvals[0].type_name == 'type3'

# Generated at 2022-06-11 21:29:20.631891
# Unit test for function parse
def test_parse():
    text = """This is a short summary.

    This is a longer description.  This can
    be as long as necessary.

    Args:
        a (int): The first parameter.
        b (str): The second parameter.
    """
    print(parse(text, style=Style.auto))

# Generated at 2022-06-11 21:29:30.279291
# Unit test for function parse
def test_parse():
	input = """This is example."""
	output = ['This is example.', '', []]
	assert parse(input, style=Style.Numpy).__dict__ == {'_summary': output[0], '_extended_summary': output[1], '_fields': output[2]}
	assert parse(input, style=Style.Google).__dict__ == {'_summary': output[0], '_extended_summary': output[1], '_fields': output[2]}
	input = """This is example.\n\nThis is extended summary."""
	output = ['This is example.', 'This is extended summary.', []]
	assert parse(input, style=Style.Numpy).__dict__ == {'_summary': output[0], '_extended_summary': output[1], '_fields': output[2]}


# Generated at 2022-06-11 21:29:40.127057
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle
    from docstring_parser.common import ReturnItem
    from unittest.mock import Mock

    result = Mock()
    result.args = ['a', 'b']
    result.return_desc = 'returns a value'
    result.other = 'some other text'
    result.meta = {'some', 'meta', 'data'}
    result.returns = [ReturnItem(type_='integer', desc='account id')]


# Generated at 2022-06-11 21:29:52.218219
# Unit test for function parse
def test_parse():
    text = """
        This is an example function.

        :param arg1: The first parameter.
        :type arg1: int

        :return: None
        :rtype: None
    """
    text_numpy = """
        This is an example function.

        Parameters
        ----------
        arg1 : int
            The first parameter.

        Returns
        -------
        None
    """
    text_sphinx = """
        This is an example function.

        :param arg1: The first parameter.
        :type arg1: int

        :returns: None
        :rtype: None
    """
    text_google = """
        This is an example function.

        Args:
            arg1 (int): The first parameter.

        Returns:
            None
    """

# Generated at 2022-06-11 21:30:00.766985
# Unit test for function parse
def test_parse():
    d = parse ("""\
        This is a short summary.

        This is a longer description.

        Args:

            this is the first parameter

            another one

        Returns:
            None
    """)
    assert d.short_description == "This is a short summary."
    assert d.long_description == "This is a longer description."
    a = d.params[0]
    assert a.arg_name == "this is the first parameter"
    a = d.params[1]
    assert a.arg_name == "another one"


# Generated at 2022-06-11 21:30:08.662847
# Unit test for function parse
def test_parse():
    text = """
    Keyword arguments:
    arg1 -- the first argument
    arg2 -- the second argument
    Returns:
    This is a description of what is returned.
    This can span multiple lines.
    Raises:
    An error
    Another error
    """
    ret = parse(text, style='numpy')
    print(ret)
    print(ret.fields)
    print(ret.short_description)
    print(ret.long_description)
    for field in ret.fields:
        print(field.type_name)
        print(field.arg_name)
        print(field.description)
    
    

# Generated at 2022-06-11 21:30:14.133637
# Unit test for function parse
def test_parse():
    text = parse('Summary\n    This is a very awesome function.\n    No, really.\n')
    assert(text.summary == 'Summary')
    assert(text.meta == 'This is a very awesome function.\nNo, really.')
    assert(text.description == '')


# Generated at 2022-06-11 21:30:16.706743
# Unit test for function parse
def test_parse():
    docstring = parse('Hello world')
    docstring.short_description.source == 'Hello world'


# Generated at 2022-06-11 21:30:31.975879
# Unit test for function parse
def test_parse():
    from .testdata.cstyle import C_STYLE
    from .testdata.googley import GOOGLEY_STYLE
    from .testdata.numpydoc import NUMPY_STYLE
    from .testdata.reST import RST_STYLE
    from .testdata.sphinx import SPHINX_STYLE
    # pylint: disable=line-too-long
    str1 = "This function does nothing."

# Generated at 2022-06-11 21:30:42.146469
# Unit test for function parse
def test_parse():
    text = '''
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    doc_str = parse(text, Style.google)
    assert doc_str.short_description == 'Parse the docstring into its components.'
    assert doc_str.long_description == ''
    assert doc_str.returns.type_name == ''
    assert doc_str.returns.description == 'parsed docstring representation'
    assert doc_str.returns.type_name == ''
    assert doc_str.params.type_name == ''
    assert doc_str.params.description == 'docstring text to parse'

# Generated at 2022-06-11 21:30:46.208540
# Unit test for function parse
def test_parse():
    text = """
    Unit test for the docstring parser

    Args:
        the: the first argument
        a (int): the second argument

    Returns:
        a tuple of two elements

    """
    parse(text, style = Style.auto)

# Generated at 2022-06-11 21:30:57.495439
# Unit test for function parse
def test_parse():
    doc = """
    This function is a  function

    Args:
        arg1: the first argument
        arg2: the second argument

    Returns:
        return a value

    Raises:
        ValueError, KeyError

    """
    ex = parse(doc)
    assert ex.short_description == "This function is a  function"
    assert ex.long_description == ""
    assert ex.returns == "return a value"
    assert ex.returns_description == ""
    assert ex.raises == [("ValueError", ""), ("KeyError", "")]
    assert ex.parameters == [("arg1", "the first argument"), ("arg2", "the second argument")]

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:31:06.122045
# Unit test for function parse
def test_parse():
	text1 = '''Samples random actions from the input policy for the given environment for a given number of steps.'''
	doc1 = parse(text1)
	assert doc1.short_description == text1
	assert doc1.long_description == None
	assert doc1.meta == []
	assert doc1.params == []
	assert doc1.returns == None

	text2 = """Policy for computing actions given observations."""
	doc2 = parse(text2)
	assert doc2.short_description == text2
	assert doc2.long_description == None
	assert doc2.meta == []
	assert doc2.params == []
	assert doc2.returns == None

# Generated at 2022-06-11 21:31:17.702102
# Unit test for function parse
def test_parse():
    text = '''
        Module description here.

        Parameters
        ----------
        param1 : int
            The first parameter.
        param2 : str
            The second parameter.

        Returns
        -------
        bool
            True if successful, False otherwise.
        '''

    doc = parse(text)

    assert isinstance(doc, Docstring)
    assert doc.short_description == 'Module description here.'
    assert doc.long_description == 'Module description here.'
    assert doc.params['param1'].description == 'The first parameter.'
    assert doc.params['param2'].description == 'The second parameter.'
    assert doc.returns.description == 'True if successful, False otherwise.'

# Test for numpy docstring

# Generated at 2022-06-11 21:31:24.514697
# Unit test for function parse
def test_parse():
    docstring = """
Some description

:param a: Parameter a
:type a: int
:raises ValueError: If a is even
    """
    expected = Docstring(summary="Some description\n",body=["",":param a: Parameter a", ":type a: int", ":raises ValueError: If a is even"], meta={'a': None, 'raises': 'ValueError'},returns=None, style="numpy")
    assert expected == parse(docstring)

# Generated at 2022-06-11 21:31:34.684668
# Unit test for function parse
def test_parse():
    # Define test data
    text = '''This function does something
        Something else
        And another thing
        Parameters
        ----------
        a : int
            First parameter
            Multiline
            Description
        b : str
            Second parameter
        Returns
        -------
        int
            Return value
        '''

    # Define expected output

# Generated at 2022-06-11 21:31:38.173897
# Unit test for function parse
def test_parse():
    assert parse('foo')
    assert parse('foo', Style.google)
    assert parse('foo', Style.numpy)
    assert parse('foo', Style.auto)

# Generated at 2022-06-11 21:31:47.679794
# Unit test for function parse
def test_parse():
    text = """
        Description of the function
        :param str arg1: Description of arg1
        :param bool arg2: Description of arg2
        :returns: Description of the output
        """
    doc = parse(text)
    assert doc[0] == 'Description of the function'
    assert doc[1][0][0] == 'arg1'
    assert doc[1][0][1] == 'str'
    assert doc[1][0][2] == 'Description of arg1'
    assert doc[1][1][0] == 'arg2'
    assert doc[1][1][1] == 'bool'
    assert doc[1][1][2] == 'Description of arg2'
    assert doc[2] == 'Description of the output'
    assert not doc[3]
    assert not doc[4]




# Generated at 2022-06-11 21:32:01.623234
# Unit test for function parse
def test_parse():
    text = """A module to calculate the averages of a given list of numbers.
    This module contains four functions: one_average(), two_average(), three_average(), and 
    n_average(). n_average() can handle an arbitrary number of inputs."""

    try:
        result = parse(text)
    except ParseError as e:
        print(e)
        return

    assert result.short_description == "A module to calculate the averages of a given list of numbers."
    assert result.long_description == 'This module contains four functions: one_average(), two_average(), three_average(), and \nn_average(). n_average() can handle an arbitrary number of inputs.'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:12.105450
# Unit test for function parse
def test_parse():
    """Test the main parsing routine"""
    # Same comment in different styles
    docstring = """Unit test for function parse
    
    :param path: path of the file
    :type path: str
    :returns: file content
    :rtype: str
    """
    parsed = parse(docstring, style=Style.numpy)
    assert parsed.short_description == "Unit test for function parse"
    assert parsed.long_description == ""
    assert parsed.params == {"path": "path of the file"}
    assert parsed.returns == {"returns": "file content"}
    assert parsed.meta == {"type": {"path": "str"}, "rtype": "str"}
    parsed = parse(docstring, style=Style.google)
    assert parsed.short_description == "Unit test for function parse"

# Generated at 2022-06-11 21:32:22.197822
# Unit test for function parse
def test_parse():
    ds = parse("""
    This is a summary.
    This is a description.
    :param foo: param 1
    :param bar: param 2
    :returns: this function returns
    :raises: IOError, OSError
    :key key1: value 1
    :key key2: value 2
    """)
    assert ds.short_description == "This is a summary."
    assert ds.long_description == "This is a description."
    assert ds.params == [
        ("foo", "param 1"),
        ("bar", "param 2"),
    ]
    assert ds.returns == "this function returns"
    assert ds.raises == "IOError, OSError"

# Generated at 2022-06-11 21:32:25.318926
# Unit test for function parse
def test_parse():
    assert parse("""\
Example
-------
Content
""") == Docstring(
        content=["Content"],
        meta=dict(Example="")
    )

# Generated at 2022-06-11 21:32:30.287858
# Unit test for function parse
def test_parse():
    print("Test parse().")

    # Use result of test ParseInterleaveDict
    assert {'foo': 'bar'} == parse("""baz
    :foo: bar
    """).meta

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-11 21:32:39.507708
# Unit test for function parse
def test_parse():
    print("Testing docstring_parser.core.parse...", end="")

    # Try parsing our own code
    from docstring_parser.core import parse
    ds = parse(parse.__doc__, style=Style.google)
    assert ds.short_description == "Parse the docstring into its components."
    assert ds.long_description.startswith("\nParse the docstring into its ")
    assert len(ds.meta) == 2
    assert len(ds.params) == 2
    assert ds.params["text"].description == "docstring text to parse"
    assert ds.params["style"].default == Style.google
    assert ds.returns.description.startswith("parsed docstring representation")
    assert ds.returns.types == "Docstring"

    # Test

# Generated at 2022-06-11 21:32:47.872529
# Unit test for function parse
def test_parse():
    docstring = """Type-hinting functions.
    
    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: str
    :return: return value
    :rtype: float
    """
    d = parse(docstring, style=Style.function)
    assert d.short_description == "Type-hinting functions."
    assert d.parameters == [
        {"name": "a", "type": "int", "text": "first parameter"},
        {"name": "b", "type": "str", "text": "second parameter"},
    ]
    assert d.returns == {"type": "float", "text": "return value"}

# Generated at 2022-06-11 21:32:58.498669
# Unit test for function parse
def test_parse():
    parser = parse(
        """
        Args:
            first (str): The first name.
            last (str): The last name.

        Returns:
            str: The full name.
        """
    )
    assert len(parser.meta) == 2
    assert parser.meta[0].argname == "first"
    assert parser.meta[0].type_name == "str"
    assert parser.meta[0].docstring == "The first name."
    assert parser.meta[1].argname == "last"
    assert parser.meta[1].type_name == "str"
    assert parser.meta[1].docstring == "The last name."
    assert parser.returns.type_name == "str"
    assert parser.returns.docstring == "The full name."

# Generated at 2022-06-11 21:33:04.483157
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    import pytest
    print(parse('a', style=Style.google))
    assert parse('a', style=Style.google).__dict__ == GoogleStyle('a').__dict__
    with pytest.raises(ParseError):
        parse('a', style=Style.numpydoc)

# Generated at 2022-06-11 21:33:11.896955
# Unit test for function parse
def test_parse():
	docstr = """
		Args:
			text(str): docstring text to parse
			style(Style): docstring style
		Returns:
			Docstring: parsed docstring representation
	"""
	assert (parse(docstr).short_description == '')
	assert (parse(docstr).long_description == None)
	assert (len(parse(docstr).meta) == 3)
	assert (parse(docstr).meta[1].name == 'style')
	assert (parse(docstr).meta[2].name == 'Returns')

# Generated at 2022-06-11 21:33:16.238620
# Unit test for function parse
def test_parse():
    text = """
    Unit test for function parse
    """
    style = Style.auto
    parse(text,style)

# Generated at 2022-06-11 21:33:17.295664
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()


# Generated at 2022-06-11 21:33:29.341597
# Unit test for function parse
def test_parse():
    from .styles.numpy import parse as numpy_parse
    from .styles.google import parse as google_parse
    from .styles.recommonmark import parse as recommonmark_parse
    def test(text, style):
        doc = parse(text, style = style)
        assert doc.short_description == 'First line.\n'
        assert len(doc.long_description.split('\n')) == 11

# Generated at 2022-06-11 21:33:32.952497
# Unit test for function parse
def test_parse():
    text = "This is a simple test."
    
    result = parse(text)
    print(result)

    assert(isinstance(result, Docstring))
    return True

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:33:43.872455
# Unit test for function parse
def test_parse():
    test_docstring = '''\
    My Title
    ================

    Summary line.

    Description:
    ================
    Description goes here.

    Return:
    ================
    None

    Raises:
    ================
    ZeroDivisionError: This is when the number is 0
    '''

    docstring = parse(test_docstring)
    assert docstring.title == 'My Title'
    assert docstring.summary == 'Summary line.'
    assert docstring.description == 'Description goes here.'
    assert docstring.returns == 'None'
    assert docstring.raises[0].name == 'ZeroDivisionError'
    assert docstring.raises[0].description == 'This is when the number is 0'


test_parse()

# Generated at 2022-06-11 21:33:54.809374
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import GoogleDocstring

    text = """One line summary.

    Extended description.

    Args:
        arg1 (int): Description of `arg1`.
        arg2 (str): Description of `arg2`.

    Returns:
        bool: Description of return value.

    """

# Generated at 2022-06-11 21:33:55.801342
# Unit test for function parse
def test_parse():
    assert parse("One line").short_description == "One line"


# Generated at 2022-06-11 21:34:03.445577
# Unit test for function parse

# Generated at 2022-06-11 21:34:13.420504
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GOOGLESTYLE, NUMPYSTYLE

    parse_ = parse
    ds = """
    """
    assert parse_(ds) is None

    # GOOGLESTYLE
    ds = """
    Args:
        name (str): name of the person.
        age (int): age of the person.
    Returns:
        Person: the person instance created.
    """

# Generated at 2022-06-11 21:34:20.192903
# Unit test for function parse
def test_parse():
    text = '''Algorithm for computing the "best worst" point in a set of points.

    The algorithm compute the point that is the closes from all other points.
    '''
    d = parse(text)
    assert d.summary == "Algorithm for computing the \"best worst\" point in a set of points."
    assert d.description == \
            "The algorithm compute the point that is the closes from all other points."

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:34:32.022273
# Unit test for function parse
def test_parse():
    import pytest
    from docstring_parser import parse
    text = '''
    :param par1: The first parameter.
    :type par1: str

    :param par2: The second parameter.
    :type par2: str

    :returns: description of return value
    :rtype: int

    :raises Exception1: if exception one occurs
    :raises Excpetion2: if exception two occurs
    '''
    # test that parse() raises an exception before Style.Google
    with pytest.raises(ParseError):
        parse(text, style=Style.Google)

    # test that parse() parses to the proper style
    assert parse(text, style=Style.Sphinx).style == Style.Sphinx


# Generated at 2022-06-11 21:34:33.822239
# Unit test for function parse
def test_parse():
    parse([0, 1, 2])

if __name__ == '__main__':
    parse([0, 1, 2])

# Generated at 2022-06-11 21:34:45.472762
# Unit test for function parse

# Generated at 2022-06-11 21:34:49.276260
# Unit test for function parse
def test_parse():
    docstring = parse(
        """
        Test docstring,
        simple
        """,
    )
    assert 'Test docstring' in docstring.short_description
    assert 'simple' in docstring.body
    assert len(docstring.meta) == 0

test_parse()

# Generated at 2022-06-11 21:34:59.961000
# Unit test for function parse
def test_parse():
    text = """
    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned\n
        this is a description of what is returned\n
        this is a description of what is returned
    :raises keyError: raises an exception
    """

# Generated at 2022-06-11 21:35:12.394316
# Unit test for function parse
def test_parse():
    assert parse('').summary == ''
    assert parse('').description == ''
    assert parse('').meta == {}
    assert parse('header\n==========\ndescription\n').summary == 'header'
    assert parse('header\n==========\ndescription\n').description == 'description'
    assert parse('header\n==========\ndescription\n').meta == {}
    assert parse("""Summary line.

Description of parameters.
:param x: param one
:param y: param two
:returns: nothing.
:raises MyException: when something goes wrong.
:var v: a variable
:ivar mvar: another variable
""", Style.numpy).description == 'Description of parameters.'

# Generated at 2022-06-11 21:35:21.834737
# Unit test for function parse
def test_parse():
    text1 = """
    Double check the version.
    """

    text2 = """
    This is a very long description that spans many lines.
    """

    text3 = """
    """

    text4 = """
    Short description.

    Long description.

    :param message: 
    :param optional: 
    """

    text5 = """
    Short description.

    Long description.

    :param message: 
    :param optional: 
    """

    text6 = """
    This shows example of Google style docstring.

    Args:
      param1: The first parameter.
      param2: The second parameter.

    Returns:
      This is a description of what is returned.

    Raises:
      KeyError: Raises an exception.
    """


# Generated at 2022-06-11 21:35:32.976347
# Unit test for function parse
def test_parse():
    assert (parse('"""Basic"""').description == 'Basic')
    assert (parse('    """Basic"""').description == 'Basic')
    assert (parse('"""\nBasic\n"""').description == 'Basic')
    assert (parse('"""\nBasic\n"""').description == 'Basic')
    assert (parse('"""\nBasic\n\n"""').description == 'Basic')
    assert (parse('"""\nBasic\n\n"""').description == 'Basic')
    assert (parse('"""\nBasic\n\n\n"""').description == 'Basic')
    assert (parse('"""\nBasic\n\n\n"""').description == 'Basic')
    assert (parse('"""Basic\n\n"""').description == 'Basic')
    assert (parse('"""Basic\n\n"""').description == 'Basic')

# Generated at 2022-06-11 21:35:42.882717
# Unit test for function parse
def test_parse():
    doc = """This is a summary sentence.
    
    This is an extended description.
    It is indented, so a paragraph break is needed.
    
    Keyword arguments:
        - param_1 -- this is a long param and is equals to "param long"
        - param_2 -- this is a short param
    
    Returns:
        this is a return value
    """

    d = parse(doc, style=Style.google)
    assert d.summary == "This is a summary sentence."
    assert d.description == "This is an extended description.\nIt is indented, so a paragraph break is needed."
    assert d.params['param_1'] == "this is a long param and is equals to \"param long\""
    assert d.params['param_2'] == "this is a short param"
    assert d.returns

# Generated at 2022-06-11 21:35:54.777381
# Unit test for function parse
def test_parse():
    def test_func():
        """
          This is a test function with no arguments.
          :returns: nothing
          :rtype: None

          .. versionadded:: 0.3.0
          .. versionchanged:: 0.5.0
            Now supports Python 3.5.

          **Logging example**

          .. code-block:: python
            :linenos:

            if __debug__:
                logger.debug("Debugging something.")

        """
        return
    parsed = parse(test_func.__doc__)
    assert(parsed.short_description == "This is a test function with no arguments.")

# Generated at 2022-06-11 21:35:58.034512
# Unit test for function parse
def test_parse():
    """Test Parsse Function"""
    string = "Test Docstring"
    docstring = parse(string)
    assert docstring.short_description == string
    assert docstring.returns == None

# Generated at 2022-06-11 21:36:09.123751
# Unit test for function parse
def test_parse():
    assert parse(" ")
    assert parse(" \n")
    assert parse(" \n\n")
    assert parse("")
    assert parse(" ")
    assert parse(" \n")
    assert parse(" \n \n")
    assert parse("\n", style=Style.rst)
    assert parse("a\n")
    assert parse("a\n", style=Style.rst)
    assert parse("a\n\n")
    assert parse("a\n\n", style=Style.rst)
    assert parse("a\nb\n", style=Style.rst)
    assert parse("a\nb\n\n")
    assert parse("a\nb\n\n", style=Style.rst)
    assert parse("a\nb\n \n\n")