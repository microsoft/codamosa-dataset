

# Generated at 2022-06-11 21:26:19.221126
# Unit test for function parse
def test_parse():
    assert parse("""
    Spam.

    :param eggs: an evil plan
    :type eggs: str
    :raises Exception: if the plan fails
    """).as_google() == """Spam.

Args:
    eggs (str): an evil plan

Raises:
    Exception: if the plan fails"""



# Generated at 2022-06-11 21:26:26.240944
# Unit test for function parse
def test_parse():
    assert parse('hello') == parse('hello', style=Style.numpy)
    assert parse('hello') == parse('hello', style=Style.google)
    assert parse('hello') == parse('hello', style=Style.sphinx)
    assert parse('hello') == parse('hello', style=Style.auto)
    assert parse('hello', style=Style.numpy) != parse('hello', style=Style.google)
    assert parse('hello', style=Style.sphinx) != parse('hello', style=Style.google)


##########################################################################
# END OF CODE
##########################################################################

##########################################################################
# MODE VARIABLES
##########################################################################

__all__ = [
    "parse",
    "Style",
    "Docstring",
    "ParseError",
]

__docformat__

# Generated at 2022-06-11 21:26:33.394273
# Unit test for function parse
def test_parse():
    text = """
    Parses the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    assert parse(text) == Docstring(
        summary="Parses the docstring into its components.",
        description="",
        long_description="",
        returns=("parsed docstring representation", ""),
        parameters=[("text", "docstring text to parse", ""), ("style", "docstring style", "")],
        annotations=[],
    )
test_parse()

# Generated at 2022-06-11 21:26:45.188292
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Param, Return, ReturnTuple
    from docstring_parser.styles import Google

    # Test with a docstring in Google format
    docstring = parse("""\
        Args:
            param1: The first parameter.
            param2: The second parameter.
        Returns:
            bool: The return value. True for success, False otherwise.
        """, style=Google)

    assert docstring.short_description == ""
    assert docstring.long_description == ""
    assert docstring.returns == Return(
        description='The return value. True for success, False otherwise.',
        type='bool'
    )

# Generated at 2022-06-11 21:26:53.224469
# Unit test for function parse
def test_parse():
    text = '''
    This is a
    normal docstring.
    '''
    Docstring = parse(text)
    assert Docstring.summary == 'This is a\nnormal docstring.'
    assert Docstring.description == None
    assert Docstring.meta == {}
    assert Docstring.returns == None
    assert Docstring.raises == None
    assert Docstring.yields == None
    assert Docstring.extended_summary == None

# Generated at 2022-06-11 21:26:55.323361
# Unit test for function parse
def test_parse():
    txt = """
    Some text
    """
    d = parse(txt)
    assert d.short_description == "Some text"
    assert d.meta == {}


# Generated at 2022-06-11 21:27:07.559739
# Unit test for function parse
def test_parse():
    """Tests the parsing of the docstring."""

    text = """\
This is a short summary.

This is a long description. It can include multiple paragraphs.

:param name1: description of name1
:type name1: str
:param name2: description of name2
:type name2: int
:returns: description of the return value
:rtype: int
:Example:
    example code
:Example:
    example docstring
"""
    ret = parse(text)
    assert ret.short_description == "This is a short summary."
    assert ret.long_description == "\nThis is a long description. It can include multiple paragraphs."
    assert ret.params[
        'name1'] == "description of name1"
    assert ret.params['name2'] == "description of name2"

# Generated at 2022-06-11 21:27:19.658691
# Unit test for function parse

# Generated at 2022-06-11 21:27:25.977928
# Unit test for function parse
def test_parse():
    doc = '''Single-line docstring.
    Extra indent.
    '''
    docstring = parse(doc)
    assert docstring.short_description == 'Single-line docstring.'
    assert len(docstring.long_description) == 1
    assert docstring.long_description[0] == 'Extra indent.'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:27:38.186319
# Unit test for function parse
def test_parse():
    assert parse('Hello') == Docstring(summary='Hello')
    assert parse('Hello\nWorld') == Docstring(summary='Hello\nWorld')
    assert parse('Hello\n\nWorld') == Docstring(summary='Hello', remainder='World')
    assert parse('Hello\nWorld\nHow are you') == Docstring(summary='Hello\nWorld', remainder='How are you')
    assert parse('Hello\nWorld\n\nHow are you') == Docstring(summary='Hello\nWorld', remainder='How are you')
    assert parse('Hello\nWorld\n\nHow are you\nGood morning') == Docstring(summary='Hello\nWorld', remainder='How are you\nGood morning')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:27:53.285707
# Unit test for function parse
def test_parse():
    text = " \n \n this is a docstring."
    docstring = parse(text)
    assert docstring.short_description == "this is a docstring."

    text = "this is a docstring.\n\nthis is more docstring."
    docstring = parse(text)
    assert docstring.short_description == "this is a docstring."
    assert docstring.long_description == "this is more docstring."

    text = "this is a docstring.\n\nthis is more docstring."
    docstring = parse(text, style=Style.google)
    assert docstring.short_description == "this is a docstring."
    assert docstring.long_description == "this is more docstring."


# Generated at 2022-06-11 21:27:57.870512
# Unit test for function parse
def test_parse():
    assert "hi\n" == parse("hi\n").short_description
    assert "hi\n" == parse("hi\n", Style.google).short_description
    assert "hi\n" == parse("hi\n", Style.numpy).short_description
    return True

# Generated at 2022-06-11 21:27:59.150694
# Unit test for function parse
def test_parse():
    assert isinstance(parse(''), Docstring)


# Generated at 2022-06-11 21:28:02.865998
# Unit test for function parse
def test_parse():
    text = """\
function parse(text: str, style: Style) -> Docstring:
    
    parse the docstring into its components
    
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    
    assert parse(text) is not None

# Generated at 2022-06-11 21:28:12.666270
# Unit test for function parse
def test_parse():
    ds = parse("""\
Parses the docstring into its components.

:param text: docstring text to parse
:param style: docstring style

:returns: parsed docstring representation
:rtype: :py:class:`Docstring`
""")
    assert ds.short_description == 'Parses the docstring into its components.'
    assert len(ds.long_description) == 2
    assert len(ds.params) == 2
    assert len(ds.params['text'].descriptions) == 1
    assert ds.params['text'].descriptions[0] == 'docstring text to parse'

    assert len(ds.returns) == 1
    assert ds.returns[0].descriptions[0] == 'parsed docstring representation'
    assert ds.returns

# Generated at 2022-06-11 21:28:15.044609
# Unit test for function parse
def test_parse():
    text = "This is my Docstring"
    doc = parse(text)
    assert doc.summary == text


# Generated at 2022-06-11 21:28:21.629970
# Unit test for function parse
def test_parse():
    text = """\
    Top level description.

    This function does something.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        Description of return value.
    """
    parsed = parse(text)
    assert parsed.short_description == 'Top level description.'
    assert len(parsed.long_description) == 2
    assert parsed.returns.arg_type is None
    assert parsed.returns.description == 'Description of return value.'
    return parsed

# Generated at 2022-06-11 21:28:33.890128
# Unit test for function parse
def test_parse():
    text = """
        Short summary.

        Long summary.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.

        Keyword Args:
            kwarg1 (int): The first keyword argument.
            kwarg2 (str): The second keyword argument.

        Returns:
            bool: The return value.

        Raises:
            AttributeError: The raises.
    """
    docstring = parse(text)
    assert docstring.short_description == 'Short summary.'
    assert docstring.long_description == 'Long summary.'
    assert docstring.returns.type_name == 'bool'
    assert docstring.returns.description == 'The return value.'
    assert docstring.raises.type_name == 'AttributeError'
    assert docstring.raises

# Generated at 2022-06-11 21:28:44.747332
# Unit test for function parse
def test_parse():
    text = """\
    """
    doc = parse(text)
    assert doc.short_description == None
    assert doc.long_description == ''
    assert doc.meta == {}

    text = """\
    This is the short description only.
    """
    doc = parse(text)
    assert doc.short_description == 'This is the short description only.'
    assert doc.long_description == ''
    assert doc.meta == {}

    text = """\
    This is the short description.

    This is the long description.

    And there are even meta-fields:
    :keyword: value
    """
    doc = parse(text)
    assert doc.short_description == 'This is the short description.'

# Generated at 2022-06-11 21:28:53.092768
# Unit test for function parse
def test_parse():
    doc = """
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    first = parse(doc, 'rst')
    second = parse(doc, 'numpy')
    third = parse(doc, 'google')
    print(first)
    print(second)
    print(third)

# Generated at 2022-06-11 21:29:04.557465
# Unit test for function parse
def test_parse():
    docStringObject = parse("""
    :param i: an integer
    :param y: a float
    :returns: sum of i and y
    :raises: an exception
    """)
    assert docStringObject.params == [("i", "an integer"), ("y","a float")]
    assert docStringObject.returns == "sum of i and y"
    assert docStringObject.raises == "an exception"

# Generated at 2022-06-11 21:29:05.286627
# Unit test for function parse
def test_parse():
    assert parse('This is a random test') == Docstring(content='This is a random test')

# Generated at 2022-06-11 21:29:06.013388
# Unit test for function parse
def test_parse():
    assert parse("foo") is not None

# Generated at 2022-06-11 21:29:10.493573
# Unit test for function parse
def test_parse():
    def foo():
        """Foo function.

        :param arg: arg.
        :returns: returns.
        """
        pass

    foo_docstring = """:param arg: arg.
:returns: returns.
"""

    doc = parse(foo_docstring)
    print(doc.keywords)

# Generated at 2022-06-11 21:29:15.200748
# Unit test for function parse
def test_parse():
    from docstring_parser.utils import parse_docstring
    from docstring_parser.parsers.numpy import NumpyParser
    docstring = parse_docstring(parse.__doc__)
    assert isinstance(docstring, Docstring)
    # assert isinstance(docstring, NumpyParser)

if __name__ == "__main__":
    docstring = parse(parse.__doc__)
    print(docstring)

# Generated at 2022-06-11 21:29:28.035596
# Unit test for function parse
def test_parse():
    d = parse("""
    This is a docstring

    :param name: blurb
    :type name: str

    :returns: None
    :rtype: None
    """)

    assert d.short_description == "This is a docstring"
    assert d.long_description == ""
    assert len(d.meta) == 2
    assert d.meta[0].arg_name == "name"
    assert d.meta[0].arg_type is None
    assert d.meta[0].arg_desc == "blurb"
    assert d.meta[0].arg_type_desc == "str"
    assert d.meta[1].arg_name == "None"
    assert d.meta[1].arg_type == "None"
    assert d.meta[1].arg_desc == None

# Generated at 2022-06-11 21:29:38.578516
# Unit test for function parse
def test_parse():
    #expected
    expected_text = '''\
        The main parsing routine.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        '''
    expected_summary = 'The main parsing routine.'
    expected_params = [
        {'name': 'text', 'type': None, 'desc': 'docstring text to parse'},
        {'name': 'style', 'type': None, 'desc': 'docstring style'}
    ]
    expected_returns = {'type': None, 'desc': 'parsed docstring representation'}
    expected_style = 2

    # test
    docstring = parse(expected_text, style=expected_style)
    assert docstring.text == expected_text
    assert docstring.summary == expected_summary


# Generated at 2022-06-11 21:29:50.989274
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, Tag

    text = '''\
    Parameters:
        p1 (type1): description1
        p2 (type2): description2

    Returns:
        type3: description3

    Raises:
        Exception1: description4
        Exception2: description5
    '''
    ds = Docstring(
        params=[
            Tag(name='p1', type='type1', description='description1'),
            Tag(name='p2', type='type2', description='description2'),
        ],
        returns=Tag(type='type3', description='description3'),
        raises=[
            Tag(name='Exception1', description='description4'),
            Tag(name='Exception2', description='description5'),
        ],
    )
    assert parse(text) == ds

# Generated at 2022-06-11 21:30:01.900730
# Unit test for function parse
def test_parse():

    from docstring_parser.styles.sphinx_default import SphinxDefaultStyle
    print('\ntesting parse() function')

    # Testing code that should be parsed
    doc = parse(r'''example of Sphinx text
        :param p1: description of p1
        :type p1: p1 type
        :param p2: description of p2
        :type p2: p2 type
        :returns: description of the return value
        :rtype: rtype''')

    print('done. ' + str(doc.__dict__))

    # Testing code that should be parsed

# Generated at 2022-06-11 21:30:10.334233
# Unit test for function parse
def test_parse(): 
    text = """
    Routine short_summary

    DETAILED DESCRIPTION

    Advanced description.

    Args:
       param1 (type): description of `param1`

    *Returns*:
        description of return value
    """
    doc = parse(text)
    assert doc.summary == "Routine short_summary"
    assert doc.extended == "Advanced description."
    assert doc.params[0]['name'] == 'param1'
    assert doc.params[0]['type'] == 'type'
    assert doc.params[0]['desc'] == 'description of `param1`'
    assert doc.returns[0]['type'] == 'None'
    assert doc.returns[0]['desc'] == 'description of return value'


# Generated at 2022-06-11 21:30:25.293240
# Unit test for function parse
def test_parse():
    """
    Test the parse function
    :return:
    """

    doc_string = """
    This function runs a function f with arguments args and kwargs and returns it's result. If the
    function f throws an exception, it will be caught and re-thrown after the hook is called.

    :param hook: hook to be called if the function fails
    :param f: the function to execute
    :param args: positional arguments for the function
    :param kwargs: keyword arguments for the function
    :return: what ever the function f returns
    """

    doc = parse(doc_string)
    assert doc.short_description == 'This function runs a function f with arguments args and kwargs and returns it\'s result.'
    assert len(doc.long_description) == 1

# Generated at 2022-06-11 21:30:29.990677
# Unit test for function parse
def test_parse():
    """Test for the function parse
    """
    text = """This is the first line of the docstring.
    It is not an abstract.
    This has the next open paragraph."""

    result = parse(text)

    assert result.abstract == "This is the first line of the docstring."
    assert result.description == text

test_parse()

# Generated at 2022-06-11 21:30:38.316406
# Unit test for function parse
def test_parse():
    ds = parse("""
        :param request:
        :type request:
        :param include_all:
        :type include_all:
        :param include_none:
        :type include_none:
        :param exclude_only:
        :type exclude_only:
        :returns:
        :rtype:
        """)
    assert ds.params['request'] == None
    assert ds.params['include_all'] == None
    assert ds.params['include_none'] == None
    assert ds.params['exclude_only'] == None
    assert ds.returns == None

# Generated at 2022-06-11 21:30:43.404993
# Unit test for function parse
def test_parse():
    text = """Atributos:
        
        x : tipo de x
        y : tipo de y
        
        """
    doc = parse(text, style=Style.google)
    assert str(doc) == text
    
    

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:55.833404
# Unit test for function parse
def test_parse():
    text = """
        :param str name: person name
        :param int age: persion age
        :param list(str) children: children names
        :rtype: None
        :return: no return
        """
    expected = {
        'parameters': [
            {'type': 'str', 'name': 'name', 'description': 'person name'},
            {'type': 'int', 'name': 'age', 'description': 'persion age'},
            {'type': 'list(str)', 'name': 'children', 'description': 'children names'},
        ], 'returns': [
            {'type': 'None', 'description': 'no return'},
        ]}
    assert expected == parse(text).meta
    assert expected == parse(text, Style.google).meta

# Generated at 2022-06-11 21:31:06.318240
# Unit test for function parse
def test_parse():

    import unittest
    class Test(unittest.TestCase):
        def test(self):
            self.assertEqual(parse("this is a test"), Docstring(
                '', 'this is a test', [], [], [], []
            ))
            self.assertEqual(parse("this is a test\n", Style.auto), Docstring(
                '', 'this is a test', [], [], [], []
            ))
            self.assertEqual(parse("this is a test\n", Style.numpy), Docstring(
                '', 'this is a test', [], [], [], []
            ))
            self.assertEqual(parse("this is a test\n", Style.google), Docstring(
                '', 'this is a test', [], [], [], []
            ))
    unitt

# Generated at 2022-06-11 21:31:18.389296
# Unit test for function parse
def test_parse():
    style = Style.numpy
    text = '''
    This module has the following features:

     * A
     * B
     * C

    Parameters
    ----------
    * A       : param A
    * B       : param B
    * C       : param C
    * D       : param D

    Raises
    ------
    * e1: Test exception 1
    * e2: Test exception 2
    * e3: Test exception 3

    Returns
    -------
    * A
    * B
    * C

    Examples
    --------
    * Example 1
    * Example 2

    Notes
    -----
    * Note 1
    * Note 2
    * Note 3
    '''

    rst = parse(text, style)
    assert(rst.short_description == 'This module has the following features:')

   

# Generated at 2022-06-11 21:31:29.988561
# Unit test for function parse
def test_parse():
	text = '''
		Parsing function is used to extract information from raw docstring.
		
		:param text: Docstring to parse
		:param style: Style to parse the docstring in
		:returns: returns parsed information about the docstring and its
							contents.
		:raises ParseError: if any errors are encountered
	'''

	test_docstring = parse(text, Style.auto)
	print(test_docstring.short_description)
	print(test_docstring.long_description)
	print(test_docstring.params)
	print(test_docstring.meta)
	print(test_docstring.returns)

# Unit test call
# test_parse()

# Generated at 2022-06-11 21:31:37.662571
# Unit test for function parse
def test_parse():
    """Unit test for function parse.

    :returns: 0 if parse parses a docstring properly
    """

    doc1 = """\
        This function is pretty cool.
        
        It really is.
        
        Args:
        arg1 (str): This is the first argument.
        arg2 (str): This is the second argument.
            It has a multi-line description.
        
        Returns:
        str: This is the return value.
        """


# Generated at 2022-06-11 21:31:39.893066
# Unit test for function parse
def test_parse():
    text = """This is a docstring"""
    style = Style.auto
    assert parse(text, style) == Docstring()
    

# Generated at 2022-06-11 21:31:51.719574
# Unit test for function parse
def test_parse():
    raw = '''  Summary line here.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of arg1

    arg2 : str
        Description of arg2

    Returns
    -------
    int
        Description of return value
    '''

    # parse(raw)

    print(parse(raw))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:03.266374
# Unit test for function parse
def test_parse():
    text = '''This function solves the differential equation
    $``\int_a^b f(x) dx``$ by the midpoint rule, with
    $``N``$ subintervals of length $``(b - a)/N``$.
    '''
    parsed = parse(text, style=Style.numpy)
    assert parsed.short_description == 'This function solves the differential equation'
    assert parsed.long_description == '$``\int_a^b f(x) dx``$ by the midpoint rule, with\n$``N``$ subintervals of length $``(b - a)/N``$.'
    assert parsed.returns == None
    assert parsed.yields == None
    assert parsed.raises == None

# Generated at 2022-06-11 21:32:11.333398
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    text = '''This is a docstring.
    It can span multiple lines.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.
    Returns:
        str: The return value.
    '''
    print(parse(text, Style.numpy))
    print(parse(text, Style.google))
    print(parse(text, Style.auto))
    print(parse('def func(x, y):'))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:21.684073
# Unit test for function parse
def test_parse():
    from pprint import pprint
    from docstring_parser.styles import AUTO
    from docstring_parser import parse

    d = parse('''
    Returns the value x raised to the power y.

    Args:
        x (float): The number to raise.
        y (float): The power to raise x to.

    Returns:
        float: ``x`` raised to the power ``y``.

    Raises:
        TypeError: If the inputs are not numbers.
        ValueError: If the input is negative.

    Examples:
        >>> pow(2, 3)
        8
        >>> pow(3, 2)
        9
        >>> pow(-2, 3)
        -8
        >>> pow(2.1, 3.7)
        10.0444
    ''')

    pprint(d.asdict())

# Generated at 2022-06-11 21:32:31.126149
# Unit test for function parse
def test_parse():
    doc = parse("""
    This is a docstring

    :param foo: a foo parameter
    :type foo: int
    :param baz: a baz parameter
    :type baz: bool
    :returns: The run result.
    :rtype: bool
    :raises: Exception
    """)
    assert doc.short_description == "This is a docstring"
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert len(doc.returns) == 1
    assert len(doc.raises) == 1

# Generated at 2022-06-11 21:32:40.323211
# Unit test for function parse
def test_parse():
    d = parse("""
    Function description.

    :param int param1: The first parameter.
    :param str param2: The second parameter.
    :returns: None.
    :raises ValueError: If `param2` is equal to `param1`.
    """, style=Style.google)
    assert isinstance(d.metavar_descriptions, dict)
    assert isinstance(d.param_descriptions, dict)
    assert d.short_description == 'Function description.'
    assert d.long_description == 'Function description.'
    assert d.param_descriptions['param1'] == 'The first parameter.'
    assert d.param_descriptions['param2'] == 'The second parameter.'
    assert d.returns_annotation == 'None'

# Generated at 2022-06-11 21:32:47.646671
# Unit test for function parse
def test_parse():
    print("Testing function test_parse()...")
    test_sig = 'test_sig'
    test_meta = 'test_meta'
    test_description = 'test_description'
    test_body = '''test_body

test_body2'''
    test_text = f'''{test_sig}
{test_meta}
{test_description}
{test_body}'''
    result = parse(test_text)
    assert result.sig == test_sig
    assert result.meta == test_meta
    assert result.description == test_description
    assert result.body == test_body

# Generated at 2022-06-11 21:32:58.351457
# Unit test for function parse
def test_parse():
    from docstring_parser.doctest import Docstring, Doctest
    from docstring_parser.styles import Style
    docstring = Docstring(
        short_description='short description',
        long_description='long description',
        meta=Doctest(
            code='def factorial(n):\n    return 0 if n == 0 else n * factorial(n - 1)',
            output='0',
        ),
    )
    assert parse('short description\n\nlong description\n\n>>> def factorial(n):\n...     return 0 if n == 0 else n * factorial(n - 1)\n>>> factorial(3)\n6', style=Style.google) == docstring

# Generated at 2022-06-11 21:33:09.937044
# Unit test for function parse
def test_parse():
    text = '''\
Hello, world.

General synopsis
----------------

This is the synopsis.

Description
-----------

This is the description.

Arguments
---------

- argument1: description of argument 1
- argument2: description of argument 2

Return value
------------

This is the return value.

'''
    assert parse(text) == {
        'title': 'Hello, world.',
        'summary': 'General synopsis',
        'body': 'This is the synopsis.\n\nDescription\n-----------\n\nThis is the description.\n',
        'args': ['argument1: description of argument 1', 'argument2: description of argument 2'],
        'return': 'This is the return value.',
        'raw': text,
    }

# Generated at 2022-06-11 21:33:18.334836
# Unit test for function parse
def test_parse():
    text = """
This is the docstring for the function.
Args:
    param1: description 1
    param2: description 2
Returns:
    description 1
    description 2
Kwargs:
    x: value of x
"""
    doc = parse(text)
    assert doc.short_description == 'This is the docstring for the function.'
    assert doc.long_description == 'This is the docstring for the function.'
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == 'param1'
    assert doc.params[0].description == 'description 1'
    assert doc.params[1].arg_name == 'param2'
    assert doc.params[1].description == 'description 2'
    assert len(doc.returns) == 2

# Generated at 2022-06-11 21:33:25.177332
# Unit test for function parse
def test_parse():
    print("test_parse()...")
    import doctest
    doctest.testmod()



# Generated at 2022-06-11 21:33:35.295167
# Unit test for function parse
def test_parse():
    """Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation

    """
    ds = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
#    print(parse(ds))
#    print(parse(ds).params)
#    print(parse(ds).returns)

if __name__ == "__main__":
    print("This is the docstring parser.")
    print("Running unit test...")
    test_parse()
    print("Unit test successful.")
#    print(parse(ds).params)
#    print(parse(ds).returns)

# Generated at 2022-06-11 21:33:45.810311
# Unit test for function parse
def test_parse():
    text = '''This is a module docstring for journal.
    """Explanation of how the code works.

    Parameters
    ----------
    the first argument
    second argument

    Returns
    -------
    a : int
        the answer
    """
    '''
    style = Style.numpy
    doc_string = parse(text, style)
    assert doc_string.short_description == "This is a module docstring for journal."
    assert doc_string.long_description == "Explanation of how the code works."
    assert doc_string.returns.name == "a"
    assert doc_string.returns.type_name == "int"
    assert doc_string.returns.description == "the answer"

# Generated at 2022-06-11 21:33:56.951144
# Unit test for function parse
def test_parse():
    from copy import copy
    from textwrap import dedent
    from functools import partial
    from docstring_parser.styles import parse_reST

    assert parse_reST('''
        :param bar: description
        ''').params['bar'] == 'description'

    assert len(parse('''
        :returns: description
        ''').returns) == 1

    assert len(parse_reST('''
        :returns: description
        ''').returns) == 1

    assert parse('''
        :returns: description
        :rtype: list
        ''').returns[0].type == 'list'

    assert parse_reST('''
        :rtype: list
        ''').returns[0].type == 'list'


# Generated at 2022-06-11 21:34:04.020452
# Unit test for function parse
def test_parse():
    assert(parse("hello") == Docstring(short_description='hello', long_description='', meta=[], returns=None))
    assert(parse("hello\nworld") == Docstring(short_description='hello', long_description='world', meta=[], returns=None))
    assert(parse("hello\nworld\n") == Docstring(short_description='hello', long_description='world', meta=[], returns=None))
    assert(parse("hello\n\nworld") == Docstring(short_description='hello', long_description='world', meta=[], returns=None))
    assert(parse("hello\n\nworld\n") == Docstring(short_description='hello', long_description='world', meta=[], returns=None))

# Generated at 2022-06-11 21:34:07.707713
# Unit test for function parse
def test_parse():
    assert parse('- class: Person\n  desc: |\n    Some desc.\n    Second line.', style=Style.numpy).get_sections() == []

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:34:11.025036
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a test docstring.
    '''
    actual = parse(docstring)
    expected = Docstring('''
    This is a test docstring.
    ''', None, None, None)

    assert actual == expected

# Generated at 2022-06-11 21:34:20.019347
# Unit test for function parse
def test_parse():
    text = '''\
    Short summary.

    Long summary.

    Long summary continued.

    :param name: description
    :type name: str
    :returns: description
    :rtype: int
    '''

    parse(text)
    parse(text, style=Style.numpy)

    # https://github.com/agronholm/docstring_parser/issues/73
    parse('''\
    """ 
        Function for testing purposes.
        Processing of the data can be done.
        
        :param - test: str
            This is for testing
        :return: str
            Return the test
    """''')

# Generated at 2022-06-11 21:34:24.441777
# Unit test for function parse
def test_parse():
    text = "New project to parse docstrings"
    style = "google"
    assert parse(text, style).short_description == "New project to parse docstrings"
    assert parse(text, style).long_description == ""
    assert parse(text, style).style == "google"
    assert parse(text, style).meta.__dict__ == {}

# Generated at 2022-06-11 21:34:31.307456
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    from docstring_parser import parse
    from .examples import PLAIN_DOCSTRING, PLAIN_PARSED, GOOGLE_DOCSTRING, GOOGLE_PARSED
    print("Testing function parse")
    assert(parse(PLAIN_DOCSTRING) == PLAIN_PARSED)
    assert(parse(GOOGLE_DOCSTRING, Style.google) == GOOGLE_PARSED)



# Generated at 2022-06-11 21:34:37.872351
# Unit test for function parse
def test_parse():
    assert parse('') is not None

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:34:47.916565
# Unit test for function parse

# Generated at 2022-06-11 21:34:56.266061
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Parameter, ReturnValue
    d = parse(
        """The main parsing routine.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
"""
    )
    assert d.summary == "The main parsing routine."
    assert d.extended_summary == ""
    assert d.params == [
        Parameter("text", "docstring text to parse"),
        Parameter("style", "docstring style"),
    ]
    assert d.returns == [ReturnValue("parsed docstring representation")]



# Generated at 2022-06-11 21:35:04.087944
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("a") == Docstring(content=["a"])
    assert parse("a\nb\nc") == Docstring(content=["a", "b", "c"])
    assert parse("a\nb\n") == Docstring(content=["a", "b"])
    assert parse("a\n\n") == Docstring(content=["a"])
    assert parse("\n") == Docstring()
    assert parse("\na\n") == Docstring(content=["a"])
    assert parse("a\n\nb", style=Style.numpy) == Docstring(content=["a", "b"])
    assert parse("a\n\nb") == Docstring(content=["a", "b"])
    assert parse("\na\n\nb") == Doc

# Generated at 2022-06-11 21:35:06.489273
# Unit test for function parse
def test_parse():
    test_string = "This is a test string"
    doc = parse(test_string)
    assert doc.short_description == test_string

# Generated at 2022-06-11 21:35:12.499576
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    from pprint import pprint
    text = '''
    This function does this and this.

    :param a: the first parameter

    :returns: the result
    '''
    for style in STYLES.keys():
        pprint(parse(text, style=style))

# Generated at 2022-06-11 21:35:21.893971
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse

# Generated at 2022-06-11 21:35:32.096484
# Unit test for function parse
def test_parse():
    text = """\
    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Keyword Args:
        kwarg1 (str): The first keyword argument.
        kwarg2 (str): The second keyword argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """
    doc = parse(text)
    assert len(doc.args) == 2
    assert len(doc.kwargs) == 2
    assert doc.returns
    assert doc.raises


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:40.179980
# Unit test for function parse
def test_parse():
    """
    Test function parse
    """
    text = """
    Function with Docstring

    :param name: string, name of the person
    :param lastname: string, last name of person
    :returns: string, full name
    """
    style = Style.sphinx
    
    result = parse(text, style)
    assert result.summary == 'Function with Docstring'
    assert result.description == ''
    assert result.long_description == ''
    #assert result.short_description == ''
    assert result.returns.annotation == 'string'
    assert result.returns.description == 'full name'


# Generated at 2022-06-11 21:35:41.740577
# Unit test for function parse
def test_parse():
    test = "My name is yeboong."
    parse(test)

# Generated at 2022-06-11 21:35:52.121279
# Unit test for function parse
def test_parse():
    text = """Arguments:
        a (int) -- A first argument.
        b (int) -- A second argument.
    """
    docstring = parse(text)
    assert docstring.short_description == ""
    assert docstring.long_description == ""
    assert docstring.params == {"a": "[int] A first argument.",
                                "b": "[int] A second argument."}


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:36:02.784873
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import epytext
    import pytest

    def test_parser(text, style, expected):
        result = parse(text, style)
        assert result.summary == expected[0], 'Wrong summary'
        assert result.docstring == expected[1], 'Wrong docstring'
        assert result.epilog == expected[2], 'Wrong epilog'
        assert result.meta == expected[3], 'Wrong meta'


# Generated at 2022-06-11 21:36:13.605079
# Unit test for function parse
def test_parse():
    """
    Test function parse()
    """
    # test for function parse()
    # test for a valid input string
    docstr = """
    This is a docstring for a function.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    int
        Description of return value
    """
    assert parse(docstr).params[0].name == 'arg1'
    # test for invalid input string
    docstr1 = """
    This is a docstring for a function.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2
    """
    ret = ""