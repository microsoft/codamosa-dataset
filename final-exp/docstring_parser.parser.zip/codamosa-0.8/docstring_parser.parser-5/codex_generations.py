

# Generated at 2022-06-11 21:26:20.613810
# Unit test for function parse
def test_parse():
    def foo():
        """Tests parse function.

        Args:
            x: first number
            y: second number

        Returns:
            Sum of numbers.
        """
        return

    assert(parse(foo.__doc__) == Docstring(
        summary='Tests parse function.',
        description='',
        args=[('x', 'first number'), ('y', 'second number')],
        returns='Sum of numbers.'))

# Generated at 2022-06-11 21:26:24.796262
# Unit test for function parse
def test_parse():

    assert parse('"""test"""') == Docstring(description=[''], content=['test'], meta={})
    assert parse("""test""") == Docstring(description=[''], content=['test'], meta={})

# Generated at 2022-06-11 21:26:27.801023
# Unit test for function parse
def test_parse():
    docstring = "This is a test docstring."
    assert parse(docstring).short_description == docstring


# Generated at 2022-06-11 21:26:31.634740
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = parse("""\
        # Do addition in Python.

        Args:
          a (int): an integer.
          b (int): another integer.

        Returns:
          int: a+b.
        """)
    assert docstring.short_description == "Do addition in Python."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    
test_parse()

# Generated at 2022-06-11 21:26:37.921236
# Unit test for function parse
def test_parse():
    from docstring_parser.tests.test_styles import docstrings
    for style in STYLES.values():
        text = docstrings[style.name]
        parsed = parse(text)
        assert parsed.meta['Description'] == docstrings[style.name]['meta']['Description']
        assert parsed.meta['Parameters'] == docstrings[style.name]['meta']['Parameters']
        assert parsed.meta['Return'][0] == docstrings[style.name]['meta']['Return'][0]
        assert parsed.meta['Raises'][0] == docstrings[style.name]['meta']['Raises'][0]
        assert parsed.meta['See Also'][0] == docstrings[style.name]['meta']['See Also'][0]
    print("Test passed!")

# Generated at 2022-06-11 21:26:43.709198
# Unit test for function parse
def test_parse():
    # style = Style.google
    style = Style.auto
    text = "Open the file :file in the chosen program.\n\n:file: path to some file\n\n:prg: the program to open the file with\n"
    ret = parse(text, style)
    print(ret)

# test_parse()

# if __name__ == '__main__':
#     main()

# Generated at 2022-06-11 21:26:55.835719
# Unit test for function parse

# Generated at 2022-06-11 21:27:08.128603
# Unit test for function parse
def test_parse():
    text = """compute the square numbers of x, element-wise."""
    d = parse(text)
    assert d.short_description == "compute the square numbers of x, element-wise."


# Generated at 2022-06-11 21:27:19.618924
# Unit test for function parse
def test_parse():
    print("Beging to test function parse")
    text = """A function to test function parse
    :param str key: A key
    :param int value: A value"""
    result = str(parse(text))
    #print("expect:", expect)
    #print("result:", result)
    #print("str(Docstring(expect)):", str(Docstring(expect)))
    #print("str(Docstring(result)):", str(Docstring(result)))
    assert result == 'A function to test function parse<br>\n:param str key: A key<br>\n:param int value: A value<br>\n', "should be true"
    print("Success to test function parse")

test_parse()

# Generated at 2022-06-11 21:27:30.402864
# Unit test for function parse
def test_parse():
    code = '''
#{
    "title": "This is title",
    "author": "jaewon.choi",
    "date": "2019-05-06",
    "version": "1.0.0"
}
"""
====================
TEST_DOCSTRING_PARSER
====================

**Section1**:

- arg1: lorem ipsum
- arg2: lorem ipsum

**Section2**:

- arg3: lorem ipsum
- arg4: lorem ipsum

"""
'''
    docstring = parse(code)
    print(docstring.meta)
    print(docstring.content)
    print(docstring.sections)
    print(docstring.args)
    print(docstring.returns)

# Generated at 2022-06-11 21:27:38.230385
# Unit test for function parse
def test_parse():
    text = """\
Simple add function

Args:
    a: first value
    b: second value
Returns:
    sum of a and b
"""
    style = Style.numpy
    rets = parse(text,style)

    assert rets.short_description == "Simple add function"

# Generated at 2022-06-11 21:27:45.860475
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    docstring = parse("""This is a function.
    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value
    :rtype: int
    """)
    assert(isinstance(docstring, Docstring))
    assert(docstring.summary == "This is a function.")
    assert(len(docstring.params) == 2)
    assert(docstring.returns.desc == "Description of return value")
    assert("optional" in docstring.params["arg2"].options)
    assert("int" in docstring.returns.annotation)
    assert("str" in docstring.params["arg2"].annotation)

# Generated at 2022-06-11 21:27:46.939691
# Unit test for function parse
def test_parse():
    text = """
    This is an example of functions.
    :param str para1: Parameter one
    """
    print(parse(text))

# Generated at 2022-06-11 21:27:48.821107
# Unit test for function parse
def test_parse():
    text = """The main parsing routine."""
    parse(text, style=Style.none)

# Generated at 2022-06-11 21:27:59.522100
# Unit test for function parse
def test_parse():
    test_string = '''class myClass:
    """
    myClass is a class that contains the data and functions associated with the
    learning of a neural network
    """
    """
    myClass is a class that contains the data and functions associated with the
    learning of a neural network
    """
    def __init__(self, x, y):
        """
        Initializes the parameters used for the class.
        """
        self.x = x
        self.y = y
        self.results = []

    def getResults(self):
        """
        Returns the results from the learning.

        :returns: the results from the learning.
        """
        return self.results
    '''
    myClass = parse(test_string)

# Generated at 2022-06-11 21:28:08.386481
# Unit test for function parse

# Generated at 2022-06-11 21:28:19.289625
# Unit test for function parse
def test_parse():

    def foo():
        """some docs

        :param a: int
        :param b: str
        :returns: None
        :raises ValueError: if a > 5
        """
        pass

    d = parse(foo.__doc__)

    assert d.content == ["some docs"]
    assert d.params == [("a", "int", None), ("b", "str", None)]
    assert d.returns == "None"
    assert d.raises == ["ValueError: if a > 5"]

    def foo():
        """some docs

        :a int:
        :b str:
        :returns: None
        :raises ValueError: if a > 5
        """
        pass

    d = parse(foo.__doc__)


# Generated at 2022-06-11 21:28:30.168394
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    input = """
    Returns the corresponding value
    and raises an exception
    """
    try:
        result = parse(input)
    except ParseError as e:
        print(e)
    expected = Docstring(summary='Returns the corresponding value and raises an exception', description='')
    assert result == expected

    input = """
    This docstring is in automatic mode
    """
    try:
        result = parse(input, Style.auto)
    except ParseError as e:
        print(e)
    expected = Docstring(summary='This docstring is in automatic mode', description='')
    assert result == expected

# Generated at 2022-06-11 21:28:36.475049
# Unit test for function parse
def test_parse():
    '''Unit test for function parse'''
    assert parse('''Routine to create a log of files
        :param name: routine name
        :type name: str
        :param logger: The name of the logger
        :type logger: str
        :returns: True''')
    assert None == parse('''Routine to create a log of files
        :param name: routine name
        :type name: str
        :param logger: The name of the logger
        :type logger: str
        :returns: True''')

# Generated at 2022-06-11 21:28:46.007526
# Unit test for function parse
def test_parse():
    doc = '''Short summary.

Longer description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        The return value. True for success, False otherwise.
    Raises:
        argparse.ArgumentTypeError
'''
    assert parse(doc).meta['summary'] == 'Short summary.'
    assert parse(doc).meta['description'] == 'Longer description.'
    assert parse(doc).meta['returns']['description'] == 'The return value. True for success, False otherwise.'
    assert parse(doc).meta['raises'][0]['description'] == 'argparse.ArgumentTypeError'
    assert parse(doc).meta['args'][1]['default'] is None

# Generated at 2022-06-11 21:28:51.136179
# Unit test for function parse
def test_parse():
    text = "This is a simple test of the docstring."
    assert text == parse(text).summary
    assert "\n" in parse(text + "\n\n This is a description.").summary

# Generated at 2022-06-11 21:29:00.866051
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, get_docstring_text, ParseError
    from docstring_parser.styles import STYLES, Style
    from docstring_parser import parser
    import io
    import textwrap
    # Test for function parse()

    # Test for function parse() when style is auto
    text = get_docstring_text()

    # Test for function parse() when style is Style.google

    # Test for function parse() when style is Style.numpy
    doc = parser.parse(text, style=Style.numpy)
    assert 'param' in doc.meta
    assert 'returns' in doc.meta
    assert doc.summary == 'Parse the docstring into its components.'
    assert doc.long_description == 'blah blah blah\nmulti-line blah\nblah.\n'


# Generated at 2022-06-11 21:29:06.946202
# Unit test for function parse
def test_parse():
    assert parse("", style=Style.numpy) == Docstring()
    assert parse(style=Style.numpy) == Docstring()
    with pytest.raises(KeyError):
        parse(style="invalid")

    docstring = Docstring()
    assert parse(docstring, style=Style.numpy) == docstring
    with pytest.raises(ParseError):
        parse(docstring)

# Generated at 2022-06-11 21:29:15.981942
# Unit test for function parse
def test_parse():
    text = """One-line summary.
    Extended description.
    
    Parameters
    ----------
    name : str
        Name of the person
    age : int
        Age of the person
    weight : float
        Weight of the person
    
    Returns
    -------
    str
        A formatted string of the person's details
    
    """
    docstring = parse(text)
    params = docstring.params
    assert params[0].name == 'name'
    assert params[0].type.name == 'str'
    assert params[0].desc.startswith('Name of')
    assert params[0].desc.endswith('person')
    assert params[2].name == 'weight'
    assert params[2].type.name == 'float'
    assert params[2].desc.startswith('Weight of')


# Generated at 2022-06-11 21:29:20.816846
# Unit test for function parse
def test_parse():
    """Test function parse"""
    func_name = 'def test():\n    """Test function.\n\n    Args: foo\n    """\n    pass'
    print(parse(func_name))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:29.580078
# Unit test for function parse
def test_parse():
    from pprint import pprint as pp
    import sys
    import os
    test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    for root, dirs, files in os.walk(test_data_dir):
        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                print('----------------')
                print(file_path)
                pp(parse(open(file_path, 'r').read()).__dict__)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:29:38.696934
# Unit test for function parse
def test_parse():
    text = """A short summary

    A long description.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    assert parse(text) == parse(text, Style.google)
    assert parse(text) == parse(text, Style.numpy)
    assert parse(text) == parse(text, Style.pep)
    assert parse(text) != parse(text, Style.sphinx)
    assert parse(text) != parse(text, Style.wiki)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:51.081750
# Unit test for function parse
def test_parse():
    import unittest
    import docstring_parser
    class TestParse(unittest.TestCase):
        def test_google(self):
            """
            Testing the docstring google parsing style
            """
            docstring = """
            This is the docstring
            """
            self.assertEqual(docstring_parser.parse(docstring).summary, 'This is the docstring')

        def test_numpy(self):
            """
            Testing the docstring numpy parsing style
            """
            docstring = """
            This is the docstring
            """
            self.assertEqual(docstring_parser.parse(docstring).summary, 'This is the docstring')

        def test_reST(self):
            """
            Testing the docstring reStructuredText parsing style
            """

# Generated at 2022-06-11 21:30:01.940364
# Unit test for function parse
def test_parse():
  text = """
        Build a 2-input XOR gate using 3 gates in a chain

        Args:
            a (int): A bit to be XORed.
            b (int): A bit to be XORed.
        Returns:
            int: Output of the XOR operation on ``a`` and ``b``.
        Raises:
            TypeError: If input is not a valid bit.
        """
  result = parse(text)
  assert result.short_description == "Build a 2-input XOR gate using 3 gates in a chain"
  assert len(result.long_description) == 2 
  assert result.long_description == '\n\t'.join([
        'Build a 2-input XOR gate using 3 gates in a chain',
        ""
    ])
  assert len(result.args) == 2

# Generated at 2022-06-11 21:30:10.620638
# Unit test for function parse
def test_parse():

    import unittest

    class TestParse(unittest.TestCase):

        def test_parse(self):

            # Empty docstring
            result = parse("")
            self.assertEqual(result.summary, "")
            self.assertEqual(result.parameters, [])

            # Docstring with markdown
            text = "\n\nExample of multi-line **markdown**\n\n"
            result = parse(text)
            self.assertEqual(result.summary, "Example of multi-line markdown")
            self.assertEqual(result.parameters, [])

            # Docstring with parameter list
            text = "\n\nThe first line\n\n:arg1: param1\n:arg2: param2"
            result = parse(text)

# Generated at 2022-06-11 21:30:16.027952
# Unit test for function parse
def test_parse():
    text = '''
            This is a sample docstring.
            :param x: a parameter
            :param y: another parameter
            '''
    print(text)
    print(parse(text))
    print(parse(text, Style.numpy))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:25.881468
# Unit test for function parse
def test_parse():
    res = parse("""\
    Checks the status of all servers.
    :param:
        param1: The first parameter.
        param2: The second parameter.
    :returns:
        This is a description of what is returned.
    :raises:
        KeyError: The RAISE exception.
    :rtype:
        dict
    """)
    assert res.summary == 'Checks the status of all servers.'
    assert res.params == {
        'param1': 'The first parameter.',
        'param2': 'The second parameter.',
    }
    assert res.returns == 'This is a description of what is returned.'
    assert res.raises == {'KeyError': 'The RAISE exception.'}
    assert res.rtype == 'dict'




# Generated at 2022-06-11 21:30:33.135383
# Unit test for function parse
def test_parse():
    text ="""
    The Fermi-LAT is a pair conversion telescope designed to cover the energy band from 20 MeV to greater than 300 GeV.
    It is the successor of the EGRET instrument on the Compton Gamma-Ray Observatory mission.
    """
    doc = parse(text)
    assert doc.short_description == '\nThe Fermi-LAT is a pair conversion telescope designed to cover the energy band from 20 MeV to greater than 300 GeV.\n'
    assert doc.long_description == 'It is the successor of the EGRET instrument on the Compton Gamma-Ray Observatory mission.\n'

# Generated at 2022-06-11 21:30:43.985162
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring_1 = '''Python is an easy to learn, powerful programming language.
    It has efficient high-level data structures and a simple but effective approach to object-oriented programming.
    Python’s elegant syntax and dynamic typing, together with its interpreted nature,
    make it an ideal language for scripting and rapid application development in many areas on most platforms.'''
    docstring_2 = '''This is a short description.

    This is a long description.
    It should be sufficient enough to be fully understandable.

    And this is the last paragraph of the long description.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises ExceptionName: Why and when the exception is raised.
    '''


# Generated at 2022-06-11 21:30:48.236990
# Unit test for function parse
def test_parse():
    parse_ = parse('hello world')
    assert isinstance(parse_, Docstring)
    assert parse_.short_description == 'hello world'
    assert parse_.long_description == ''
    assert parse_.style == Style.reST
    assert len(parse_.meta) == 0

# Generated at 2022-06-11 21:30:58.916119
# Unit test for function parse
def test_parse():
    text = """\
    A short summary line.

    A longer description of the module, with some ReST *formatting*
    _and inline :math:`math`_.

    Args:
        arg1 (type): Description of arg1
        arg2 (type):
            Description of arg2,
            with multiple lines

    Returns:
        type: Description of return value.

    Raises
        arg3 (type): Description of arg3

    .. math::

        E = mc^2

    .. note::

        Note

    .. seealso::

        Something to see

    .. warning::

        Warning

    .. deprecated::

        Use another function

    .. rubric:: Rubric

    .. contents:: Table of contents

    .. section-numbering::

    """
    ds = parse(text, style = Style.numpy)
    print

# Generated at 2022-06-11 21:31:00.783033
# Unit test for function parse
def test_parse():
    assert parse('dsf')
    assert not parse('')

# Generated at 2022-06-11 21:31:08.829004
# Unit test for function parse
def test_parse():
    text = '''
    Title: test_parse

    This is a test.
    '''
    ds = parse(text, style=Style.google)
    assert(ds.title == 'test_parse')
    assert(ds.long_desc == 'This is a test.')

    def test_args():
        text = '''
        Parameters
        ----------
        a : a
            Desc for a
        b : b
            Desc for b
        '''
        ds = parse(text, style=Style.numpy)
        assert(ds[0].arg_name == 'a')
        assert(ds[0].type_name == 'a')
        assert(ds[0].desc == 'Desc for a')
        assert(ds[1].arg_name == 'b')

# Generated at 2022-06-11 21:31:13.215341
# Unit test for function parse
def test_parse():
    assert parse("")
    assert parse('''
:param name: name of person
:raises ValueError: if name is empty
''')
    assert parse('''
:param name: name of person
:raises ValueError: if name is empty
''', style=Style.google)



# Generated at 2022-06-11 21:31:21.786289
# Unit test for function parse
def test_parse():
    docstring = """
    This is a sample docstring.

    :param name: this is the name param
    :type name: str
    :param address: this is the address param
    :type address: str
    :returns: None
    :raises keyError: raises an exception
    """

    assert parse(docstring)
    assert parse(docstring).short_description == "This is a sample docstring."
    assert parse(docstring).long_description == ""
    assert parse(docstring).params[0].arg_name == "name"
    assert parse(docstring).params[0].description == "this is the name param"
    assert parse(docstring).params[0].annotation == "str"
    assert parse(docstring).params[0].default == ""
    assert parse(docstring).params[1].arg_

# Generated at 2022-06-11 21:31:28.158786
# Unit test for function parse
def test_parse():
    text = """Summary line.
    
    Extended description.
    
    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`
    
    Returns
    -------
    int
        Description of return value
    """
    expected = """\
Summary line.

Extended description.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`

Returns
-------
int
    Description of return value
"""
    assert (parse(text).long_description == expected)



# Generated at 2022-06-11 21:31:39.649251
# Unit test for function parse
def test_parse():
    docstring = """\
    Parse the docstring into its components.

    :param text: docstring text to parse
    :type text: str
    :param style: docstring style
    :type style: Style, optional
    :returns: parsed docstring representation
    :rtype: Docstring
    """
    docstring_obj = parse(docstring)
    assert docstring_obj.short_description == "Parse the docstring into its components."
    assert docstring_obj.long_description == ""
    assert len(docstring_obj.params) == 2
    assert docstring_obj.params[0].arg_name == "text"
    assert docstring_obj.params[0].description == "docstring text to parse"
    assert docstring_obj.params[0].annotation == "str"
    assert docstring_

# Generated at 2022-06-11 21:31:48.450186
# Unit test for function parse
def test_parse():
    class DocClass:
        """DocString for the class.

        Description of the class

        :param arg1: a param
        :param arg2: another param
        """

        def __init__(self, arg1, arg2):
            """Docstring for the __init__ method.

            Description of the __init__ method

            :param arg1: a __init__ param
            :param arg2: another __init__ param
            """
            self.arg1 = arg1
            self.arg2 = arg2

        def method(self):
            """Docstring for the method.

            Description of the method
            """
            pass


# Generated at 2022-06-11 21:31:57.426220
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    docstring = parse("""This is the first line of the docstring.
        This is a second line.
        Arguments:
            x -- what a wonderous variable to have
            y -- another thing to be had
        Returns:
            Some stuff.
            More stuff.
            Even more.
        Raises:
            ValueError: if something goes wrong
        """, style=Style.multi_line)
    assert docstring.short_description == 'This is the first line of the docstring.'
    assert docstring.long_description[0] == 'This is the first line of the docstring.'
    assert docstring.long_description[1] == 'This is a second line.'
    assert docstring.arguments

# Generated at 2022-06-11 21:32:08.178254
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse
    from docstring_parser.parser import ParseError

    doc = """single line docstring."""
    assert parse(doc).short_description == 'single line docstring.'

    doc = """one line docstring.
    multiline docstring."""
    assert parse(doc).short_description == 'one line docstring.'
    assert parse(doc).long_description == 'multiline docstring.'

    doc = """Summary line.

    Extended description.
    """
    assert parse(doc).short_description == 'Summary line.'
    assert parse(doc).long_description == """Extended description.
    """


# Generated at 2022-06-11 21:32:11.870459
# Unit test for function parse

# Generated at 2022-06-11 21:32:16.299598
# Unit test for function parse
def test_parse():
    docstring = """
:param foo: first parameter
:param bar: second parameter
:param baz: third parameter
:returns: a return value
:param quux: last parameter
    """
    result = parse(docstring)
    assert result

import unittest


# Generated at 2022-06-11 21:32:23.950082
# Unit test for function parse
def test_parse():
    s = "Summary\n\nThis is extended description\n\nThis is the last section of description\n\nMore detailed description\n\n"""
    d = parse(s)
    assert str(d) == s
    assert d.summary.strip() == "Summary"
    assert d.description.strip() == "This is extended description\n\nThis is the last section of description\n\nMore detailed description"
    
    s = """Summary:
    Description of the summary

    Description:
    Description of the full summary in the next line
    """
    d = parse(s)
    assert str(d) == s
    assert d.summary.strip() == "Summary:"
    assert d.description.strip() == "Description of the summary\n\nDescription:"

# Generated at 2022-06-11 21:32:26.790048
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=False)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:32:34.279549
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring('', [], [])
    assert parse('Summary\n') == Docstring('Summary', [], [])
    assert parse('Summary\n        Arguments: none\n        Returns: none\n') == Docstring('Summary', [], [])


if __name__ == '__main__':

    ds = parse('''Summary
            Arguments: none
            Returns: none''')
    print(ds.summary)
    print(ds.extended_summary)
    print(ds.params)
    print(ds.returns)
    print(ds.raises)
    print(ds.yields)

# Generated at 2022-06-11 21:32:39.381181
# Unit test for function parse
def test_parse():
    import textwrap
    doc = """
    This is a multi-line docstring.

    This is the second line.
    """
    d = parse(doc)
    assert d.short_description == "This is a multi-line docstring."
    assert d.long_description == 'This is the second line.'



# Generated at 2022-06-11 21:32:47.603478
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Field, Function
    from docstring_parser.styles import DoxygenBasicStyle
    doxy_txt='''/**
 * @brief   Initialize function
 * @param   [in]   msg_info: message to be transferred.
 * @return  None.
 */'''
    test_docstring=parse(doxy_txt)
    assert isinstance(test_docstring, Function)
    assert isinstance(test_docstring.summary, str)
    assert isinstance(test_docstring.meta[0], Field)
    assert isinstance(parse(doxy_txt, style=Style.doxygen), DoxygenBasicStyle)

# Generated at 2022-06-11 21:32:58.314207
# Unit test for function parse

# Generated at 2022-06-11 21:33:06.222769
# Unit test for function parse
def test_parse():
    doc = """
    This is a title

    Parameters
    ----------
    arg1:
        This is argument 1.
    arg2:
        This is argument 2.

    Returns
    -------
    str
        This is a return value.
    """
    expected = doctest.DocTestParser().get_doctest(doc, {}, "", "", 0)
    assert parse(doc).__dict__ == expected.__dict__

# Generated at 2022-06-11 21:33:10.768602
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Meta, Parameter, Return, Exception
    from docstring_parser import parse
    from pprint import pprint

# Generated at 2022-06-11 21:33:14.199968
# Unit test for function parse
def test_parse():
    text = "This is a test docstring for docstring-parser.\n"
    docstring = parse(text,Style.google)
    assert docstring.short_description == "This is a test docstring for docstring-parser."

# Generated at 2022-06-11 21:33:26.145602
# Unit test for function parse
def test_parse():
    text = '''
This is a module

:param a: aaaa
:type a: int
:param b: bbbb
:rtype b: int
    '''
    e = '''This is a module

:param a: aaaa
:param b: bbbb
:type a: int
:rtype b: int
    '''
    ret = parse(text)
    assert (ret.summary == 'This is a module')
    assert (ret.body == '')
    assert (ret.meta['param'] == ['a: aaaa', 'b: bbbb'])
    assert (ret.meta['return'] == [])
    assert (ret.meta['type'] == ['a: int'])
    assert (ret.meta['rtype'] == ['b: int'])

# Generated at 2022-06-11 21:33:28.222275
# Unit test for function parse
def test_parse():
    """Test case for function parse"""
    text = """
    Foo
    """
    style = Style.numpy
    print(parse(text, style))


# Generated at 2022-06-11 21:33:34.962636
# Unit test for function parse
def test_parse():
    """Test the parse function independently."""
    text = '''\
    this is the first line
    \tand this is the second
    \tthis a third
    and a fourth'''

    style = Style.google

    assert parse(text, style).short_description == "this is the first line"
    assert parse(text, style).long_description == "and this is the second\nthis a third\nand a fourth"


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:33:45.740361
# Unit test for function parse
def test_parse():
    copy_parse = parse
    import pytest
    from docstring_parser.utils import trim

    def test_parse_docstring(text, expected):
        expected = trim(expected)
        result = parse(text)
        assert result.short_description == expected

    @pytest.mark.parametrize("text", [
        "",
        "\t",
        "\n",
        "Hello World!",
        ])
    def test_parse_text(text):
        # Empty docstrings are invalid.
        with pytest.raises(ParseError):
            parse(text)


# Generated at 2022-06-11 21:33:52.285494
# Unit test for function parse
def test_parse():
    text = """This is a nice function.
    Args:
    a: the first argument"""
    ret = parse(text)
    assert ret.short_description == "This is a nice function."
    assert ret.long_description == ""
    assert ret.meta['Args'] == [{'a': 'the first argument'}]
    

# Generated at 2022-06-11 21:33:57.991108
# Unit test for function parse
def test_parse():
    text = \
"""
param a: first param
param b: second param

:return: great stuff!

:rtype: int
:raises ValueError: if things break
"""
    parsed = parse(text)
    print('\n'.join(str(parsed).split('\n')[1:]))
    

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:34:08.040525
# Unit test for function parse
def test_parse():
    p = parse("""This is a function.
    :param arg1: first arg
    :param arg2: second arg
    :returns: None
    :raises keyError: raises an exception
    """)
    assert p.short_description == "This is a function."
    assert p.long_description == ""
    assert len(p.params) == 2
    assert len(p.returns) == 1
    assert len(p.raises) == 1
    assert p.returns[0].arg_name == ""
    assert p.returns[0].description == "None"
    assert p.raises[0].arg_name == "keyError"
    assert p.raises[0].description == "raises an exception"

# Generated at 2022-06-11 21:34:16.214158
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function to verify the function parse

    Parameters
    ----------
    a : int
        First parameter
    b : int
        Second parameter

    Returns
    -------
    int
        Sum of the input parameters

    Raises
    ------
    ValueError
        If parameters are not integers
    '''
    result = parse(text)
    assert result.meta['short_description'] == 'This is a test function to verify the function parse'
    assert result.meta['long_description'] == ''
    assert len(result.params) == 2
    assert result.returns == {'type': 'int', 'description': 'Sum of the input parameters'}
    assert len(result.raises) == 1
    assert result.tags == {}

# Generated at 2022-06-11 21:34:24.348620
# Unit test for function parse
def test_parse():
    # test parse function normal usage
    docstring = \
    """One line summary.

Describe the function one line at a time.

Parameters:

    param1 (int): Description of param1.
    param2 (str): Description of param2.

Returns:

    bool: Description of return value.
    """
    assert parse(docstring) is not None
    assert parse(docstring).short_description == "One line summary."
    assert parse(docstring).long_description == "Describe the function one line at a time."

    # test parse function empty docstring
    docstring = \
    """
    """
    assert parse(docstring) is not None
    assert parse(docstring).short_description == ""
    assert parse(docstring).long_description == ""

    # test parse function no docstring

# Generated at 2022-06-11 21:34:34.255988
# Unit test for function parse
def test_parse():
    assert parse("""
        """
    ) == Docstring(
        content='',
        summary=None,
        returns=None,
        raises=None,
        param_type=None,
        param_desc=None,
        author=None,
        version=None,
        deprecated=False,
        meta={},
    )
    assert parse("""
        """
    ).meta == {}
    assert parse("""
        """
    ).summary is None
    assert parse("""
        """
    ).returns is None
    assert parse("""
        """
    ).raises is None
    assert parse("""
        """
    ).param_type is None
    assert parse("""
        """
    ).param_desc is None
    assert parse("""
        """
    ).author is None

# Generated at 2022-06-11 21:34:41.452171
# Unit test for function parse
def test_parse():
    text = '''\
        # A description of the class
        :param param1: description of `param1`
        :param param2: description of `param2`
        :returns: descripion of return value
        :raises RuntimeError: if something wrong found
        '''

    assert parse(text) == parse(text, style=Style.google)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:34:47.305964
# Unit test for function parse
def test_parse():
    a = parse("""\
    The short summary.
    
    The long description.
    
    Args:
      arg1 (bool): the first arg
      arg2 (int): the second arg
    """)
    b = parse("""\
    The short summary.
    
    Args:
       arg1 (bool): the first arg
       arg2 (int): the second arg
    
    The long description.
    
    """)
    assert a == b



# Generated at 2022-06-11 21:34:55.574759
# Unit test for function parse
def test_parse():
    assert parse('hello world!') == Docstring(short_desc = 'hello', body = 'world!')
    assert parse('hello world!', style = 'google') == Docstring(short_desc = 'hello', body = 'world!')
    assert parse('hello world!', style = 'numpy') == Docstring(short_desc = 'hello', body = 'world!')
    assert parse('hello world!', style = 'numpy') != Docstring(short_desc = 'hello', body = 'a world!')
    print('Test passed.')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:00.032475
# Unit test for function parse
def test_parse():
    # type: () -> None
    '''Unit test for function parse'''

    assert str(parse("Test docstring")).strip() == "Test docstring"
    assert str(parse("Test docstring\nwith two lines")).strip() == "Test docstring with two lines"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:13.823960
# Unit test for function parse
def test_parse():
    text = """
    This is an example docstring
    """
    parsed = parse(text)
    assert parsed.short_description == "This is an example docstring"

    text = """
    This is an example docstring
    
    This is the long description. There are many like it but this one is mine.
    """
    parsed = parse(text)
    assert parsed.short_description == "This is an example docstring"
    assert parsed.long_description == "This is the long description. There are many like it but this one is mine."



# Generated at 2022-06-11 21:35:22.437297
# Unit test for function parse
def test_parse():
    text = """\
This is a test

:param foo: bar
:type foo: str
:returns: qux
"""


# Generated at 2022-06-11 21:35:28.465695
# Unit test for function parse
def test_parse():

    docstring = parse("""This is a docstring.
    Args:
        a: An integer.
        b: A string.
    """)

    assert docstring == Docstring(
        summary='This is a docstring.',
        description=None,
        meta=[
            ('Args', '', ['a: An integer.', 'b: A string.'])
        ]
    )

# Generated at 2022-06-11 21:35:39.199369
# Unit test for function parse
def test_parse():
    assert parse('').errors == []
    assert parse('\n').errors == []
    assert parse('\n\n').errors == []
    assert parse('brief description\n\nlong description').errors == []
    assert parse('brief description\n\nlong description').body == 'long description'
    assert parse('brief description\n\n:param').errors == []
    assert parse('brief description\n\n:param\n:param').errors == []
    assert parse('brief description\n\n:param first_param: first parameter\n:param second_param: second parameter').errors == []
    assert parse('brief description\n\n:param first_param: first parameter\n:param second_param: second parameter').params['first_param'].description == 'first parameter'

# Generated at 2022-06-11 21:35:46.571518
# Unit test for function parse
def test_parse():
    text = '''
    This is a function docstring.

    :param a: this is parameter a
    :param b: this is parameter b
    :param c: another parameter

    :returns: something
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a function docstring.'
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 3
    assert len(docstring.returns) == 1

# Generated at 2022-06-11 21:35:57.923338
# Unit test for function parse
def test_parse():
    """Parsed docstring"""
    text = """\
    This is a sample docstring for testing.

    :param param1: description of param1
    :type param1: type of param1
    :param param2: description of param2
    :type param2: type of param2
    :returns: what is returned
    :rtype: type of return value
    :raises exception1: when exception1 is raised
    :raises exception2: when exception2 is raised
    """
    docstring = parse(text, Style.google)
    assert docstring.short_description is None
    assert docstring.long_description is ''
    assert docstring.sections[0].heading == 'Parameters'
    assert docstring.sections[0].content.empty is False
    assert docstring.sections[0].content.params is not None


# Generated at 2022-06-11 21:36:09.027745
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("I am a summary.") == Docstring(summary="I am a summary.", description="", meta={})
    assert parse("I am a summary.  \nI am a description.") == Docstring(summary="I am a summary.", description="I am a description.", meta={})
    assert parse("I am a summary.  \nI am a description.  \n:arg a: arg") == Docstring(summary="I am a summary.", description="I am a description.", meta={"arg": "arg"})