

# Generated at 2022-06-11 21:26:23.888791
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import google
    
    text = """
        1. This does something.
        2. This does something else
        3. This does a third thing.
    """

    text2 = """
        This is a docstring. 
        It has a couple of lines.
    """

    text3 = """
        This has no blank lines in between.
    """
    
    text4 = """
        This is a really really really really really really really really really really really really really really really
        really really really really really really really really really really really really really really really really
        really really really really really really really really really really really really really really long docstring.
        and it has a couple of lines.
    """
    
    

# Generated at 2022-06-11 21:26:29.471999
# Unit test for function parse
def test_parse():
    docstring = """\
I am a docstring!
I don't contain any metadata.

"""
    result = parse(docstring)
    assert result.short_description == 'I am a docstring!'
    assert result.long_description == "I don't contain any metadata.\n"

# Generated at 2022-06-11 21:26:34.513985
# Unit test for function parse
def test_parse():
    import pdb
    pdb.set_trace()
    text = """
    This is an example docstring.
    
    :param p: 
    :type p: object
    """
    d = parse(text)
    assert len(d.meta) == 1
    print(d.meta)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:26:45.271961
# Unit test for function parse

# Generated at 2022-06-11 21:26:51.843059
# Unit test for function parse
def test_parse():
    assert set(parse('hello').content) == {'hello'}
    assert set(parse('hello\nworld').content) == {'hello', 'world'}
    assert set(parse('hello\nworld\n').content) == {'hello', 'world'}
    assert set(parse('hello\nworld\n\n').content) == {'hello', 'world'}

# Generated at 2022-06-11 21:26:56.931880
# Unit test for function parse
def test_parse():
    """Testing for string parse."""
    assert parse(text="""
    This is header line.
    It is next line
    And this is another line.
    """) == Docstring(summary='This is header line.\nIt is next line\n'+
    'And this is another line.',
    description='', tags=[])

#Test docstring parsing

# Generated at 2022-06-11 21:27:08.941931
# Unit test for function parse
def test_parse():
    text = """Simple Example
    - Test arg1: just a test arg1
    - Returns: what the method returns
    - Yields: what the method yields
    - Raises: what exceptions are raised
    - Warns: what warnings are shown
    - Attributes:
        - Test attr1: test attr
    This is an example of a simple python docstring.
    See Also: some other docs
    Notes:
        - this is a note
        - this is another
    References:
        [1] Ref1
        [2] Ref2
        [3] Ref3
    """
    ret = parse(text, Style.triple_quotes)
    assert ret.short_description == "Simple Example"
    assert ret.long_description == "This is an example of a simple python docstring."
    assert ret.extended_summary

# Generated at 2022-06-11 21:27:20.089545
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import STYLES, Style
    text = """\
    """
    if style != Style.auto:
        return STYLES[style](text)
    rets = []
    for parse_ in STYLES.values():
        try:
            rets.append(parse_(text))
        except ParseError as e:
            exc = e
    if not rets:
        raise exc
    return sorted(rets, key=lambda d: len(d.meta), reverse=True)[0]
    assert type(rets) == Docstring

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-11 21:27:31.622588
# Unit test for function parse
def test_parse():
    text = '''Return a list of selected tracks from a track list.

Args:
    tracks: list of source tracks
    select: function to select tracks

Returns:
    list of selected tracks
    '''
    #print(parse(text))
    assert len(parse(text).params) == 2
    #print(parse(text).params)
    #print(parse(text).params[0].name)
    assert parse(text).params[0].name == "tracks"
    #print(parse(text).params[0].type_name)
    assert parse(text).params[0].type_name == "list of source tracks"
    #print(parse(text).params[1].name)
    assert parse(text).params[1].name == "select"
    #print(parse(text).params[1].type_name

# Generated at 2022-06-11 21:27:42.332008
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", [])
    assert parse("abc") == Docstring("abc", [])
    assert parse("abc\n") == Docstring("abc", [])

    assert parse("a\n   b\n   c") == Docstring("a\n   b\n   c", [])
    assert parse("a\n  b\n    c") == Docstring("a\n  b\n    c", [])
    assert parse("a\n\tb\n\t\tc") == Docstring("a\n\tb\n\t\tc", [])
    assert parse("a\n b\n  c") == Docstring("a\n b\n  c", [])

# Generated at 2022-06-11 21:27:58.898092
# Unit test for function parse
def test_parse():
    """Testing function."""
    from docstring_parser.styles import GoogleDocstring
    assert isinstance(parse('Hello'), Docstring)
    google = GoogleDocstring
    assert isinstance(parse('Hello', style=google), Docstring)
    assert isinstance(parse('Hello', style=google), Docstring)

if __name__ == "__main__":
    test_parse()

# This code was used to test the module.
# To be deleted once testing is done.
# import pprint
# import docstring_parser.styles as st
# # import inspect
# import sys
# pprint.pprint(vars(sys.modules['docstring_parser.styles']))
# # print(inspect.getmembers(sys.modules['docstring_parser.styles'], inspect.isclass))
# pprint.pprint(vars

# Generated at 2022-06-11 21:28:01.121031
# Unit test for function parse
def test_parse():
    docstring = '''This is a test for multiline testing
    and this line is the second line
    '''
    assert parse(docstring)


# Generated at 2022-06-11 21:28:10.297342
# Unit test for function parse
def test_parse():
    text = """This is a sample docstring.
    @param callback (function) Called when the command response is received.
    @param command (str) The name of the command to execute.
    @param argv (list) A list of strings to be sent as arguments to the command.
    """
    sample = parse(text)
    assert(sample.short_description == "This is a sample docstring.")
    assert(sample.params[0].arg_name == "callback")
    assert(sample.params[0].description == "Called when the command response is received.")
    assert(sample.params[1].arg_name == "command")
    assert(sample.params[1].description == "The name of the command to execute.")
    assert(sample.params[2].arg_name == "argv")

# Generated at 2022-06-11 21:28:13.539387
# Unit test for function parse
def test_parse():
    text = '''Foo bar baz.
             Foo bar baz Foo bar baz
             Foo bar baz'''
    style = Style.google
    assert parse(text, style) == text

# Generated at 2022-06-11 21:28:17.245316
# Unit test for function parse
def test_parse():
    assert isinstance(parse(''), Docstring)
    assert parse('', Style.pep)
    assert parse('', Style.google)
    assert parse('', Style.numpy)
    assert parse('', Style.auto)

# Generated at 2022-06-11 21:28:25.649656
# Unit test for function parse
def test_parse():

    text = """
    Function parse test right now.

    :param test_1:
    :type test_1:

    :returns:
    :rtype:
    """


# Generated at 2022-06-11 21:28:37.125792
# Unit test for function parse
def test_parse():
    text = """One line summary.
    
    Extended description.
    
    Args:
        arg1: First argument
        arg2: Second argument
    Returns:
        None
    """
    docstring = parse(text)
    assert docstring.short_description == 'One line summary.'
    assert docstring.long_description == 'Extended description.'
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].description == 'First argument'
    assert docstring.meta[1].arg_name == 'arg2'
    assert docstring.meta[1].description == 'Second argument'
    assert docstring.meta[2].arg_name == None
    assert docstring.meta[2].description == 'None'



# Generated at 2022-06-11 21:28:39.240840
# Unit test for function parse
def test_parse():
    text = """ """
    assert parse(text)

test_parse()

# Generated at 2022-06-11 21:28:48.962069
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "", "", [])
    assert parse("Hello") == Docstring("", "", "Hello", [])
    assert parse("Hello\nWorld") == Docstring("", "", "Hello\nWorld", [])
    assert parse("Hello\n\nWorld") == Docstring("", "", "Hello\n\nWorld", [])
    assert parse("Hello\n\nWorld\n\n") == Docstring("", "", "Hello\n\nWorld", [])
    assert parse("Hello\n\nWorld\n\n\n") == Docstring("", "", "Hello\n\nWorld", [])
    assert parse("\nHello\n\nWorld\n\n") == Docstring("", "", "Hello\n\nWorld", [])

# Generated at 2022-06-11 21:28:59.534212
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Line
    ds = parse("""
            :param validator: callable used to check input
            :param bool as_object: if True, return a :class:`dict`
            :param bool validator: if True, return a :class:`dict`
            :param bool validator_2: if True, return a :class:`dict`
            :yield: the next item
            :rtype: number
            :raises AttributeError: when an attribute assignment fails.
            :raises ImportError: if unable to import.
            """)
    assert len(ds.params) == 3
    assert ds.yields
    assert ds.returns
    assert len(ds.raises) == 2
    assert ds.directive_sections == ['note', 'warning']

# Generated at 2022-06-11 21:29:13.151674
# Unit test for function parse
def test_parse():
    # input
    s = """
    Parameters
    ----------
    a : float
        First number.
    b : float
        Second number.

    Returns
    -------
    float
        Sum of a and b
    """
    # expected output

# Generated at 2022-06-11 21:29:25.602085
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import reST
    from docstring_parser.parsers import google
    from docstring_parser.docstring import FunctionDocstring

    parsed_google = parse("'Return True if x has the binary value '1'", style="google")
    parsed_reST = parse("Return True if x has the binary value '1'", style="reST")
    parsed_auto = parse("Return True if x has the binary value '1'", style="auto")
    assert isinstance(parsed_google, FunctionDocstring)
    assert isinstance(parsed_auto, FunctionDocstring)
    assert isinstance(parsed_reST, FunctionDocstring)

# Generated at 2022-06-11 21:29:26.865889
# Unit test for function parse
def test_parse():
    ds = parse("""
        """
    )
    assert len(ds.summary) == 0
    assert len(ds.description) == 0

# Generated at 2022-06-11 21:29:31.661098
# Unit test for function parse
def test_parse():
    text = """Title

:param a: param
:return: some return
    """
    doc = parse(text)
    assert doc.title == "Title"
    assert doc.parameters["a"].description == "param"
    assert doc.returns.description == "some return"


# Functions for command line interface

# Generated at 2022-06-11 21:29:36.528781
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """This is a docstring for parse function
    :param text: docstring text to parse
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring for parse function"
    assert docstring.params['text'].description == "docstring text to parse"

# Generated at 2022-06-11 21:29:40.914279
# Unit test for function parse
def test_parse():
    text = '''
    Description line 1
    Description line 2
    
    Args:
        argument_1 (type): Description of argument_1
        argument_2 (type): Description of argument_2
        
    Returns:
        Description of returns
        
    Raises:
        Exception1: Cause of exception 1
        Exception2: Cause of exception 2
    '''
    assert isinstance(parse(text), Docstring)


# Generated at 2022-06-11 21:29:52.640949
# Unit test for function parse

# Generated at 2022-06-11 21:30:03.251289
# Unit test for function parse
def test_parse():
    res = parse('""""""\nFoo bar\n""""""')
    assert res.short_description == 'Foo bar'
    assert res.long_description == ''
    assert res.meta == {}
    assert res.returns is None
    assert res.other == []
    assert repr(res) == (
        "Docstring(" +
        "short_description='Foo bar', " +
        "long_description='', " +
        "meta={}, " +
        "other=[], " +
        "returns=None" +
        ")"
    )

    res = parse("""
    Foo bar

    some long description
    line 1
    line 2

    :param arg1: an arg
    :param arg2: another arg
    :return:
    :rtype: int
    """)
   

# Generated at 2022-06-11 21:30:11.070144
# Unit test for function parse
def test_parse():
    ret = parse("""Summary line.
Description.

Args:
    arg1 (int): Description of arg1
    arg2 (str): Description of arg2

Returns:
    bool: Description of return value

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.
""")
    assert ret.description == "Summary line.\nDescription."
    assert ret.args == [
        ('arg1', 'int', 'Description of arg1'),
        ('arg2', 'str', 'Description of arg2')
    ]
    assert ret.return_type == 'bool'
    assert ret.return_desc == 'Description of return value'

# Generated at 2022-06-11 21:30:14.211537
# Unit test for function parse
def test_parse():
    """Unit Test"""
    text = """
    Test docstring.
    """
    print(parse(text).params)



# If this is the main module, perform the unit test

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:27.830457
# Unit test for function parse
def test_parse():
    text = """One line summary
    Extended description.

    :param foo: Foo parameter
    :param bar: Bar parameter

    :returns: None
    :raises keyError: raises an exception
    """
    result = parse(text)
    assert result.meta["parameters"]["foo"].description == "Foo parameter"
    assert result.meta["parameters"]["foo"].annotation == "object"
    assert result.meta["attributes"]["bar"].description == "Bar parameter"
    assert result.meta["attributes"]["bar"].annotation == "object"
    assert result.returns.description == "None"
    assert result.returns.annotation == "None"
    assert result.raises["KeyError"].description == "raises an exception"

# Generated at 2022-06-11 21:30:29.791208
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None


# Generated at 2022-06-11 21:30:31.664751
# Unit test for function parse
def test_parse():
    docstring = '''\
    This is a docstring
    with multiple lines.
    '''
    print(parse(docstring, style=Style.numpy))

# Generated at 2022-06-11 21:30:33.130403
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = 'This is a test'
    assert parse(text).summary == 'This is a test'


# Generated at 2022-06-11 21:30:43.984174
# Unit test for function parse
def test_parse():
    try:
        parse("asdfgh")
    except ParseError:
        pass
    else:
        assert False, "Expected exception"
    assert parse("( )") == Docstring.from_str("", "")
    assert parse("(asdfgh)") == Docstring.from_str("asdfgh", "")
    assert parse("(asdfgh)::") == Docstring.from_str("asdfgh", "")
    assert parse("(asdfgh)::jklm") == Docstring.from_str("asdfgh", "jklm")
    assert parse("(asdfgh)::jklm\n") == Docstring.from_str("asdfgh", "jklm")
    assert parse("(asdfgh)::jklm\nhjklm") == Docstring.from_str

# Generated at 2022-06-11 21:30:55.878477
# Unit test for function parse
def test_parse():
    doc = """Foo
    :param foo: the foo parameter
    :type foo: int
    :param bar: the bar parameter
    :type bar: float
    :returns: the return value"""

    d = parse(doc)
    assert d.raw_doc == doc
    assert d.short_description == 'Foo'
    assert d.long_description == ''
    assert len(d.meta) == 2
    assert d.meta[0].name == 'foo'
    assert d.meta[1].name == 'bar'
    assert d.meta[0].type_name == 'int'
    assert d.meta[1].type_name == 'float'
    assert d.returns.type_name == 'the return value'
    assert d.returns.description == ''

# Generated at 2022-06-11 21:31:02.052736
# Unit test for function parse
def test_parse():
    text='''
    """
    This is a test function
    :param number1: first number
    :type number1: int
    :param number2: second number
    :param number3: third number
    :type number3: int
    :returns: sum of the two numbers
    :raises: ValueError
    :return: returns sum of two numbers
    """'''
    docstring=parse(text)

    assert docstring.title==''
    assert docstring.short_description==''
    assert docstring.long_description=='This is a test function'
    assert len(docstring.attributes)==0
    assert len(docstring.params)==3
    assert docstring.params[0].name=='number1'
    assert docstring.params[0].arg_type=='int'

# Generated at 2022-06-11 21:31:09.787378
# Unit test for function parse
def test_parse():
    text = '''
    This is a summary.

    This is a description.

    :param param1: This is a parameter.
    :param param2: This is a parameter.
    :type param3: This is a parameter.
    :returns: This is a return value.
    :rtype: This is a return value.
    :raises error1: This is a raised error.
    :raises error2: This is a raised error.
    :key key1: This is a key.
    :key key2: This is a key.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a summary.'
    assert docstring.long_description == 'This is a description.'
    assert docstring.meta['params']['param1'] == 'This is a parameter.'


# Generated at 2022-06-11 21:31:17.318195
# Unit test for function parse
def test_parse():
    test_string='This is a \n multi line\n docstring'
    # print(repr(parse(test_string)))
    assert repr(parse(test_string)) == 'Docstring(description=None, content=[Content(body=\'This is a \', meta=None), Content(body=\'multi line\', meta=None), Content(body=\'docstring\', meta=None)], indentation=\'\')'



# Generated at 2022-06-11 21:31:20.646566
# Unit test for function parse
def test_parse():
    text="""
    This is the module docstring.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    style=Style.auto

    ret=parse(text,style)
    print(ret)

# Generated at 2022-06-11 21:31:34.926360
# Unit test for function parse
def test_parse():

    # Test for each style
    for style in STYLES:
        docstring = parse("fdfs",style)
        assert len(docstring.meta) == len(docstring.args) == len(docstring.returns) == len(docstring.raises) == len(docstring.warns) == len(docstring.warns) == len(docstring.todos) == 0
    # Test for auto style
    docstring = parse("dsf")
    assert len(docstring.meta) == len(docstring.args) == len(docstring.returns) == len(docstring.raises) == len(docstring.warns) == len(docstring.warns) == len(docstring.todos) == 0

# Generated at 2022-06-11 21:31:42.457193
# Unit test for function parse
def test_parse():
    
    text = """Function to generate random numbers.
    :param a: lower limit
    :type a: int
    :param b: upper limit
    :type b: int
    :param seed: random seed
    :type seed: float
    :returns: random numbers
    :rtype: int
    
    """
    assert isinstance(parse(text), Docstring)
    assert parse(text).__str__() == text

# Generated at 2022-06-11 21:31:54.038602
# Unit test for function parse
def test_parse():
    docstring = "This function does something\n" \
            "This is a test\n" \
            ":param x: param x description\n" \
            ":type x: type of x\n" \
            ":param y: param y description\n" \
            ":return: the function returns\n" \
            ":raises: error"
    my_docstring = parse(docstring, style=Style.sphinx)
    assert my_docstring.short_description == "This function does something"
    assert my_docstring.long_description == "This is a test"
    assert len(my_docstring.params) == 2
    assert len(my_docstring.returns) == 1
    assert len(my_docstring.raises) == 1



# Generated at 2022-06-11 21:32:05.829107
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a module of a package.

    Parameters
    ----------
    x : int
        x coordinate.
    
    y : int
        y coordinate.
    
    z : int
        z coordinate.
    
    Returns
    -------
    Dict
        Dictionary of x, y, z coordinates.
    
    Examples
    --------
    >>> from mypackage.mymodule import SomeClass
    >>> sc = SomeClass(1, 2, 3)
    >>> sc.x
    1

    >>> sc.y
    2

    >>> sc.z
    3
    '''


# Generated at 2022-06-11 21:32:12.781594
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    text = """A longer description that spans several lines.

    :param int x: a value to square
    :returns: The square of the given value
    """
    docstring = parse(text)
    assert len(docstring.short_description) > 0
    assert len(docstring.long_description) > 0
    assert len(docstring.meta) > 0
    assert len(docstring.meta[0].args) > 0
    assert len(docstring.meta[0].returns) > 0


# Generated at 2022-06-11 21:32:22.568517
# Unit test for function parse
def test_parse():
    txt = """
        Parameters:
            arg0 (str): description
            arg1 (int): description
        Returns:
            int: description
    """

    txt2 = """
        :param arg0: description
        :param arg1: description
        :returns: description
    """

    txt3 = """
        .. parameter:: arg0
            description

        .. parameter:: arg1
            description

        .. returns::
            description
    """

    txt = """
        Args:
            arg0 (str): description
            arg1 (int): description
        Returns:
            int: description
    """

    parsed = parse(txt)
    assert parsed.signature.arguments.pop("arg0").annotation == "str"
    assert parsed.signature.arguments.pop("arg1").annotation == "int"

# Generated at 2022-06-11 21:32:33.704484
# Unit test for function parse
def test_parse():
    def f():
        """A test function.

        This is the first line of the docstring.
        This is the second line of the docstring.
        This is the third.

        :param a: first parameter
        :param b: second parameter
        :returns: None
        """
        pass

    docstring = parse(f.__doc__)
    assert docstring.short_description == 'A test function.'
    assert docstring.long_description == 'This is the first line of the docstring.\nThis is the second line of the docstring.\nThis is the third.'

# Generated at 2022-06-11 21:32:40.667915
# Unit test for function parse
def test_parse():
    docstring = parse('''\
        This is a docstring.

        :param arg_1: First parameter
        :param arg_2: Second parameter
        :param arg_3: Third parameter
        :returns: Something
        ''')

    print(docstring.short_description)
    print()
    print(docstring.long_description)
    print()
    print(docstring.meta)

    # # This is a docstring.
    #
    # # arg_1: First parameter
    # # arg_2: Second parameter
    # # arg_3: Third parameter
    # # returns: Something

# Generated at 2022-06-11 21:32:49.320496
# Unit test for function parse
def test_parse():
    """Test that parse() parses docstrings"""
    text1 = '''
    Some text.
    
    Some more text over two lines.
    
    :param foo: Foo parameter.
    '''
    d1 = parse(text1)
    assert d1.short_description == 'Some text.'
    assert d1.long_description == 'Some more text over two lines.'
    assert d1.returns is None
    # Additional tests
    assert len(d1.meta) == 1
    assert d1.meta[0].args == ['foo']
    assert d1.meta[0].description == 'Foo parameter.'
    assert d1.meta[0].annotation is None
    

# Generated at 2022-06-11 21:32:59.489899
# Unit test for function parse
def test_parse():
    """To test function parse."""

    text = "Module description.\n\n"
    text += "Args:\n"
    text += "  arg1 (str): First argument.\n"
    text += "  arg2 (str): Second argument.\n"
    text += "    (default None)\n"
    text += "  arg3 (:obj:`int`, optional): Third argument.\n"
    text += "  arg4 :obj:`~foo.bar.Baz` (:obj:`list` of :obj:`~foo.bar.Baz`, optional): Fourth argument.\n"
    text += "  arg5 (:obj:`bool`): Fifth argument.\n"
    text += "  arg6 (:obj:`~.baz.Baz`): Sixth argument.\n"
   

# Generated at 2022-06-11 21:33:18.207217
# Unit test for function parse

# Generated at 2022-06-11 21:33:26.332546
# Unit test for function parse
def test_parse():
    text = """
    This module provides the main parsing routine.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    parse(text)


if __name__ == '__main__':
    text = """
    This module provides the main parsing routine.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    parse(text)
    print('Tested successfully!')

# Generated at 2022-06-11 21:33:31.950425
# Unit test for function parse
def test_parse():
    text = '''"""This is a test docstring.
    """
    '''
    text_list = [
        'def test(a, b):\n    """This is a test.\n    """\n    # test comment\n    return a + b',
        '"""This is a test docstring.\n    """',
        'def test(a, b):\n    """This is a test.\n    """\n    return a + b'
    ]
    assert type(parse(text)) == Docstring
    assert str(parse(text)) == text
    for example in text_list:
        assert type(parse(example)) == Docstring


# Generated at 2022-06-11 21:33:43.308981
# Unit test for function parse
def test_parse():
    text = """
    Example function with types documented in the docstring.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
"""
        {'type': None, 'variable': 'param1', 'description': ''}
        {'type': None, 'variable': 'param2', 'description': ''}
    """

# Generated at 2022-06-11 21:33:54.053259
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    docstr = """This is a module docstring.


    This is a class docstring.
    """
    assert parse(docstr)
    docstr = """
    This is a empty docstring"""
    assert parse(docstr)
    docstr = """
    This is a empty docstring"""
    assert parse(docstr)
    docstr = """

    This is a paragraph.

    - This is a bullet list.
    - This is another bullet list.
    """
    assert parse(docstr)
    docstr = """This is a module docstring.

    Note:
        Note in docstring

    This is a class docstring.
    """
    assert parse(docstr)

# Generated at 2022-06-11 21:34:00.515932
# Unit test for function parse
def test_parse():
    text = '''
    main_function
    -------------
    
    
    
    Parameters
    ----------
    arg1 : str
        The first string.
    arg2 : int
        The second string.

    Returns
    -------
    str
        The combined string.
    '''

    docstring = parse(text)

    assert docstring.meta['arg1'].description == 'The first string.'
    assert docstring.meta['arg2'].description == 'The second string.'

    assert docstring.returns.description == 'The combined string.'

# Generated at 2022-06-11 21:34:11.345941
# Unit test for function parse
def test_parse():
    def test_func(a, b):
        '''
        This is a test function.

        Args:
            a: arg a
            b: arg b

        Returns:
            This is a test return.
        '''
        pass

    docstring = parse(test_func.__doc__)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == ''
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args[0] == 'a'
    assert docstring.meta[0].args[1] == 'arg a'
    assert docstring.meta[1].args[0] == 'b'
    assert docstring.meta[1].args[1] == 'arg b'
    assert docstring.returns[0].args

# Generated at 2022-06-11 21:34:21.873517
# Unit test for function parse
def test_parse():
    """Test parsing the docstring"""
    text = """\
    The main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    d = parse(text)
    assert d.short_description == "The main parsing routine."
    assert len(d.params) == 2
    assert d.params[0].arg_name == "text"
    assert d.params[0].type_name == ""
    assert d.params[0].description == "docstring text to parse"
    assert d.params[1].arg_name == "style"
    assert d.params[1].type_name == ""
    assert d.params[1].description == "docstring style"

# Generated at 2022-06-11 21:34:29.890341
# Unit test for function parse
def test_parse():
    text = """This is the first line of the docstring. Subsequent lines
    are the optional description.

    :param param1: description of first parameter
    :type param1: something
    :param param2: description of second parameter
    :type param2: something else
    :returns: description of return value
    :rtype: another thing
    """

    print(parse(text))
    print(parse(text, Style.numpy))
    print(parse(text, Style.google))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:34:36.815306
# Unit test for function parse
def test_parse():
    # Test for Success
    test_docstring = """
    This is a Test Function
    Args:
        param1: Documented Param1
        param2: Documented Param2
    Returns:
        Docstring(summary='This is a Test Function',
                  description='',
                  args={'param1': 'Documented Param1',
                        'param2': 'Documented Param2'},
                  returns=[])
    """
    test_result = parse(test_docstring)
    assert(test_result.args == {'param1': 'Documented Param1', 'param2': 'Documented Param2'})
    #assert(test_result.args['param2'] == 'Documented Param2')


# Generated at 2022-06-11 21:34:57.982475
# Unit test for function parse
def test_parse():
    test_text = '''
    This function does something.
    
    :param arg1: the first argument
    :param arg2: the second argument
    :returns: None
    :raises keyError: raises an exception
    '''
    test_text_list = [line.rstrip() for line in test_text.splitlines()]
    test_text_list.pop(0)
    test_text_list.pop(0)
    test_text_list.pop(0)
    ret_list = []
    while test_text:
        doc_obj = Docstring(test_text)
        ret_list.append(doc_obj)
        test_text = str(test_text)[len(str(doc_obj)):]
    assert ret_list[0].meta[0][0] == 'param'

# Generated at 2022-06-11 21:35:08.899854
# Unit test for function parse
def test_parse():
    doctest = """This function does something.

    :param a: Input parameter
    :type a: int
    :return: Output
    :rtype: tuple

    """

    class Docstring(object):
        __slots__ = ()

        @property
        def summary(self):
            return 'This function does something.'

        @property
        def description(self):
            return '\n    '

        @property
        def params(self):
            return [{'name': 'a', 'type': 'int',
                     'description': 'Input parameter'}]

        @property
        def returns(self):
            return [{'type': 'tuple', 'description': 'Output'}]

    assert parse(doctest) == Docstring()



# Generated at 2022-06-11 21:35:19.955551
# Unit test for function parse
def test_parse():
    assert parse('''
    First sentence.
    ''').short_description == 'First sentence.'
    assert parse('''
    First sentence.
    Second sentence.

    This paragraph is not part of short description.
    ''').short_description == 'First sentence.'
    assert parse('''
    First sentence.

    Second sentence.
    This paragraph is not part of short description.
    ''').short_description == 'First sentence.'
    assert parse('''
    First sentence.
    Second sentence.

    This paragraph is not part of short description.
    ''').short_description == 'First sentence.\nSecond sentence.'
    assert parse('''
    First sentence.
    Second sentence.

    This paragraph is not part of short description.
    ''').short_description == 'First sentence.\nSecond sentence.'


# Generated at 2022-06-11 21:35:22.988273
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    assert isinstance(parse('text'), Docstring)
    assert isinstance(parse('text', Style.google), GoogleStyle)

# Generated at 2022-06-11 21:35:30.527527
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Style
    from docstring_parser import parse
    text = """\
    X : int
        The X coordinate.
    Y : int
        The Y coordinate.
    """
    style = Style.google

    docstring = Docstring(
        summary='',
        description='',
        meta={'X': 'int\n        The X coordinate.', 'Y': 'int\n        The Y coordinate.'},
        returns=None,
    )

    assert parse(text, style) == docstring



# Generated at 2022-06-11 21:35:31.717519
# Unit test for function parse
def test_parse():
    parse('test')

# Generated at 2022-06-11 21:35:42.032422
# Unit test for function parse
def test_parse():
    example_text = """Data extraction functions

    Parameters
    ----------
    filename : str
        Name of file to read.
    x : int, optional
        The number of points to read, default is 512.

    Returns
    -------
    ndarray
        Data read from file.

    Examples
    --------
    >>> from numpy import loadtxt
    >>> loadtxt('data.txt')
    array([[ 0.,  0.,  1.],
           [ 1.,  0.,  0.]])
    """
    result = parse(example_text)
    assert result.short_description == "Data extraction functions"
    assert result.long_description == "Data extraction functions"
    assert len(result.params) == 3
    assert result.params[0].arg_name == "filename"

# Generated at 2022-06-11 21:35:52.220095
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import DocstringParser

    text = '''testing
    testing
    :param foo: test foo
    :param bar: test bar
    :returns: test return'''
    docstring = DocstringParser().parse(text)
    assert docstring.short_description == "testing\ntesting"
    assert docstring.long_description == ''
    assert docstring.params == [{'name': 'foo', 'desc': 'test foo', 'type': ''},
                                {'name': 'bar', 'desc': 'test bar', 'type': ''}]
    assert docstring.returns == {'desc': 'test return', 'type': ''}
    assert docstring.metadata == {}



# Generated at 2022-06-11 21:36:02.882624
# Unit test for function parse
def test_parse():
    assert parse("23") == Docstring(summary='23')
    assert parse("23", style=Style.numpy) == Docstring(summary='23')
    assert parse("23\n\n") == Docstring(summary='23')
    assert parse("23\n\n", style=Style.google) == Docstring(summary='23')
    assert parse("23\n", style=Style.numpy) == Docstring(summary='23')
    assert parse("23\n\n") == Docstring(summary='23')
    assert parse("23\n\n", style=Style.numpy) == Docstring(summary='23')
    assert parse("23\n\n", style=Style.numpy).summary.startswith('23')

# Generated at 2022-06-11 21:36:05.260569
# Unit test for function parse
def test_parse():
    text= """
    def test_parse():
        """
    docstring=parse(text)
    assert docstring == "this is a test."