

# Generated at 2022-06-11 21:26:25.696653
# Unit test for function parse
def test_parse():
    text = """Returns the age. 
    
    :param name: The name of the person.
    :type name: str.
    
    :returns age: Person's age.
    :rtype age: int.
    """

    expected_docstring = """Returns the age. 
    
    :param name: The name of the person.
    :type name: str.
    
    :returns age: Person's age.
    :rtype age: int.
    
    
    """

    expected_summary = 'Returns the age.'
    expected_description = ''

# Generated at 2022-06-11 21:26:34.988177
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Example
    from docstring_parser.styles import GoogleStyle, NumpyStyle
    text = ' This function does something\nand there is a long description\n\n:param inta\n:param intb: the input b\n:returns: the result\n\n'
    text_google = 'This function does something\nand there is a long description\n\nArgs:\n    inta:\n    intb: the input b\n\nReturns:\n    the result\n'
    text_numpy = """This function does something
and there is a long description

Parameters
----------
inta
intb : the input b

Returns
-------
the result
"""

# Generated at 2022-06-11 21:26:40.905780
# Unit test for function parse
def test_parse():
    text = '''
    This function does something

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.


    Returns
    ----------
    bool
        True if successful, False otherwise.

    See Also
    --------
    other_func : Does something else.
    '''
    parse(text)

# Generated at 2022-06-11 21:26:45.989745
# Unit test for function parse
def test_parse():
    text = '''
    """ This is the description.

    Parameters
    ----------
    arg1 : str
        the first argument.
    arg2 : int
        the second argument.

    Returns
    -------
    str
        The return value.
    """
    '''
    style = Style.numpy
    doc = parse(text, style)
    print(doc)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:26:57.609914
# Unit test for function parse
def test_parse():
    # Picking up docstring from __init__.py
    from docstring_parser.__init__ import __doc__ as text
    # Picking up docstring for parse function
    from docstring_parser.parser import parse as text2
    # Using parse function to check docstring
    # print(parse(text, style=Style.google))
    # print(parse(text, style=Style.sphinx))
    # print(parse(text))
    print(parse(text2))
    # Testing constructors
    # Google

# Generated at 2022-06-11 21:27:02.628925
# Unit test for function parse
def test_parse():
    assert(parse.__doc__ == "Parse the docstring into its components.\n\n    :param text: docstring text to parse\n    :param style: docstring style\n    :returns: parsed docstring representation\n    ")

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:27:11.842352
# Unit test for function parse
def test_parse():
    """Test function parse."""
    text = """
    this is a function
    :param:
    :return: something
    """
    p = parse(text)
    assert p
    assert len(p.params) == 0
    assert len(p.returns) == 1

    text = """
    this is another function
    :param x:
    :param y:
    """
    p = parse(text)
    assert p
    assert len(p.params) == 2
    assert len(p.returns) == 0

    text = """
    set parameters of this model
    :param num_stages:
    :param num_lanes:
    """
    p = parse(text)
    assert p
    assert len(p.params) == 2
    
test_parse()

# Generated at 2022-06-11 21:27:22.374803
# Unit test for function parse
def test_parse():
    text = """\
    This is the first line of the docstring.

    This is the second.

    Parameters
    ----------
    arg1
        description of arg1
    arg2
        description of arg2

    Returns
    -------
    str
        description of return value
    """

    docstring = parse(text)


    #assert docstring.short_description == 'This is the first line of the docstring.'
    #assert docstring.long_description == 'This is the second.'
    assert docstring.summary == 'This is the first line of the docstring.'
    assert docstring.returns.dtype == 'str'
    assert docstring.returns.desc == 'description of return value'
    assert len(docstring.params) == 2
    assert docstring.params[0].name == 'arg1'
   

# Generated at 2022-06-11 21:27:26.434929
# Unit test for function parse
def test_parse():
    assert parse('>>> a=1\n    >>> a\n    1') == Docstring(
        description='',
        short_description='',
        examples=[
            ('>>> a=1\n    >>> a\n    1', [])
        ],
        attributes=[]
    )

# Generated at 2022-06-11 21:27:31.401669
# Unit test for function parse
def test_parse():
    text = """
    Constants used in the implementation of the various renderers.

    :param items: the items to be listed
    :type items: list
    :param level: the current indentation level
    :type level: int
    """

    style = Style.google

    assert parse(text, style) == Docstring(first_line=None, summary=None,
        description=['Constants used in the implementation of the various renderers.'],
        meta=[])

# Generated at 2022-06-11 21:27:44.464359
# Unit test for function parse
def test_parse():
    actual = parse("param x: a parameter")
    assert(actual, Docstring(short_description="", long_description="", content_type=None,
        returns=None, return_type=None, raises=None, meta={'params': [{'name': 'x', 'type': '', 'description': 'a parameter', 'default': ''}]}))
    actual = parse("return: ", style='google')
    assert(actual, Docstring(short_description="", long_description="", content_type=None,
        returns=None, return_type=None, raises=None, meta={'params': [{'name': '', 'type': '', 'description': '', 'default': ''}]}))
    actual = parse("return x: ", style='numpy')

# Generated at 2022-06-11 21:27:51.292041
# Unit test for function parse
def test_parse():
    """ test parse function"""
    print(parse(text = "docstring_parser.py"))
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-11 21:28:01.708816
# Unit test for function parse
def test_parse():
    text = """
    DocString Example

    :param name: name of the person
    :type name: str
    :param age: age of the person
    :type age: int
    :returns: dict of names and ages
    :rtype: dict
    :example:

        >>> ds = parse("""

# Generated at 2022-06-11 21:28:07.326439
# Unit test for function parse
def test_parse():
    text = '''
    :param name: the name of the person
    :type name: str.
    :returns: address of person.
    :rtype: str.
    '''
    doc = parse(text)
    assert type(doc) == Docstring
    assert doc.meta['name'].type == 'str.'
    assert doc.meta['name'].description == 'the name of the person'
    assert doc.returns == 'address of person.'
    assert doc.returns_type == 'str.'

# Generated at 2022-06-11 21:28:18.506395
# Unit test for function parse

# Generated at 2022-06-11 21:28:23.491948
# Unit test for function parse
def test_parse():
    s = parse('''
    Test the docstring in this method.

    :param foo: test param foo
    :type foo: str
    :param bar: test param bar
    :type bar: int
    :returns: None
    ''')

    print(s.summary)
    print(s.description)
    print(s.params)
    print(s.returns)

#test_parse()

# Generated at 2022-06-11 21:28:31.459999
# Unit test for function parse
def test_parse():
    docstring = parse('''
        """This is a test doc string.
        
        Args:
            test (str/int): Test argument.
        
        Returns:
            str: Test returned string.
        
        Raises:
            AttributeError: Test attribute error.
        """
        import sys
        import os
    ''')
    print(docstring)
    assert(docstring is not None)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:28:33.556528
# Unit test for function parse
def test_parse():
    txt = """
    This is the first line
    This is the second line
    """
    print(parse(txt))

# Generated at 2022-06-11 21:28:44.562121
# Unit test for function parse
def test_parse():
    '''
    >>> from docstring_parser import parse
    >>> docstring = parse('''

# Generated at 2022-06-11 21:28:53.930267
# Unit test for function parse
def test_parse():
    text = """
    Header

    This is the description.

    :param foo: first parameter
    :param bar: second parameter
    :return: description of the return value
    """
    actual = parse(text)
    expected = Docstring(
        header='Header',
        description='This is the description.',
        meta={
            'param': [
                'foo: first parameter',
                'bar: second parameter',
            ],
            'return': [
                'description of the return value'
            ],
        }
    )

    assert(expected == actual)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:09.260522
# Unit test for function parse
def test_parse():
    docstring = "This docstring will be parsed.\n" + \
                "\n" + \
                ":param param1: the first parameter\n" + \
                ":param param2: the second parameter\n" + \
                ":returns: description of return value\n" + \
                ":raises keyError: raises an exception\n" + \
                ":type param1: string"

# Generated at 2022-06-11 21:29:17.272516
# Unit test for function parse
def test_parse():
    text = """This function does something.

Args:
    arg1: The first argument.
    arg2: The second argument.

Returns:
    The return value. True for success, False otherwise.
"""
    docstring = parse(text, style=Style.google)
    assert docstring.short_description == "This function does something."
    assert docstring.long_description == ""
    assert len(docstring.args) == 2
    assert docstring.args[0].arg_name == "arg1"
    assert docstring.args[0].type_name == None
    assert docstring.args[0].description == "The first argument."
    assert docstring.args[1].arg_name == "arg2"
    assert docstring.args[1].type_name == None

# Generated at 2022-06-11 21:29:27.700921
# Unit test for function parse
def test_parse():
    d = parse('''

    This is an example docstring.

    :param name: What is your name
    :type name: str

    :returns: What is my return
    :rtype: str
    ''')
    assert d.short_description == 'This is an example docstring.'
    assert len(d.long_description) == 0
    assert d.params[0].arg_name == 'name'
    assert d.params[0].description == 'What is your name'
    assert d.returns.description == 'What is my return'


if __name__ == "__main__":
    # test_parse()
    pass

# Generated at 2022-06-11 21:29:38.414941
# Unit test for function parse
def test_parse():
    text = """This is the summary line.
    
    This is the description.
    
    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
    Returns:
        str: Description of return value
    Raises:
        Exception1: When something bad happens
        Exception2: When something worse happens
    """

    d = parse(text)
    print(d)
    assert(len(d.meta['args']) == 2)
    assert(len(d.meta['raises']) == 2)
    assert(len(d.meta['returns']) == 1)
    assert(d.meta['summary'] == 'This is the summary line.')
    assert(d.meta['description'] == 'This is the description.')

test_parse()

# Generated at 2022-06-11 21:29:50.788346
# Unit test for function parse
def test_parse():
    style = Style.google
    text1 = "This is a test docstring"
    text2 = "This is a test docstring\nAnd this is a second line"
    doc1 = parse(text1, style)
    doc2 = parse(text2, style)
    assert doc1.description == text1
    assert doc2.description == text2
    assert doc1.short_description == text1
    assert doc2.short_description == "This is a test docstring"
    assert not doc1.long_description
    assert doc2.long_description == "And this is a second line"
    assert doc1.params == []
    assert doc1.returns == None
    assert doc1.setup == None
    assert doc1.seealso == []
    assert doc1.yields == None
    assert doc1.notes

# Generated at 2022-06-11 21:30:01.900423
# Unit test for function parse
def test_parse():
    docstring = '''
    Args:
        a (int): The first argument.
        b (str): The second argument.

    Raises:
        ValueError: if a is True.
        RuntimeError: if b is False.

    Returns:
        int: The return value.
    '''

# Generated at 2022-06-11 21:30:05.852656
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    text = """This is a docstring.
    """
    d = parse(text)
    assert isinstance(d, Docstring)
    assert (d.short_description == 'This is a docstring.')

# Generated at 2022-06-11 21:30:17.103133
# Unit test for function parse
def test_parse():
    from docstring_parser import Docstring, ParseError, parse
    docstring = """One-line short summary.

One-line extended description.

Args:
    arg1 (int): Description of `arg1`
    arg2 (str): Description of `arg2`

Returns:
    bool: Description of return value

Raises:
    ValueError: When `arg2` is equal to `arg1`.

"""

# Generated at 2022-06-11 21:30:23.353956
# Unit test for function parse
def test_parse():
    test_text = textwrap.dedent(r"""


Test:
    Some example
    here
    go.

    It should find
    a test case.


"""
                                )

    # or use a multiline string within triple double quotes """
    doc = parse(test_text)
    print(doc.short_description) # or doc.long_description


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:34.157709
# Unit test for function parse

# Generated at 2022-06-11 21:30:49.307869
# Unit test for function parse
def test_parse():
    text = """
    This is a test sentence.
    This is a test sentence.
    This is a test sentence.

    Args:
        test_1 (int): The first test attribute.
        test_2 (int): The second test attribute.
    """
    expect = Docstring(summary="This is a test sentence.\nThis is a test sentence.\nThis is a test sentence.",
                       body="",
                       args=[
                           ("test_1", "int", "The first test attribute."),
                           ("test_2", "int", "The second test attribute.")
                       ])
    assert expect == parse(text)
    return True


if __name__ == "__main__":
    print("Unit test for function parse:", test_parse())

# Generated at 2022-06-11 21:30:57.989011
# Unit test for function parse
def test_parse():
    docstring = '''
    hello world.

    :param world: world
    :returns: hello world
    '''
    ret = parse(docstring)
    assert ret.summary == 'hello world.'
    assert ret.params['world'] == 'world'
    assert ret.returns == 'hello world'
    docstring = '''
    hello world.

    :param world: world
    :returns hello world
    '''
    ret = parse(docstring)
    assert ret.summary == 'hello world.'
    assert ret.params['world'] == 'world'
    assert ret.returns == 'hello world'

# Generated at 2022-06-11 21:31:03.930523
# Unit test for function parse
def test_parse():
    text = '''
    Inputs for this tool
    :param name:
    '''
    docstring = parse(text)
    assert docstring.returns.type_name == "None"
    assert docstring.params[0].name == "name"
    assert docstring.params[0].type_name == "None"
    assert docstring.params[0].description == ""


# Generated at 2022-06-11 21:31:17.626091
# Unit test for function parse
def test_parse():
    test_cases = [
        ("""
        Hello world.

        Args:
            test (str): test arg
        """, Style.numpy),
        ("""
        Args:
            test (str): test arg
        """, Style.sphinx)
    ]

    expected_value = [
        ('Hello world.', [('test', 'test arg')], '', '', '', ''),
        ('', [('test', 'test arg')], '', '', '', ''),
    ]

    for test_case, expected in zip(test_cases, expected_value):
        result = parse(*test_case)
        assert result.short_description == expected[0]
        assert result.args == expected[1]
        assert result.raises == expected[2]
        assert result.returns == expected[3]

# Generated at 2022-06-11 21:31:28.688742
# Unit test for function parse
def test_parse():
    text = """
    The parse docstring

    Parameters
    ----------
    text A docstring to be parsed.
    style The docstring style. Default is auto.

    Returns
    -------
    Parsed docstring representation.
    """
    doc = parse(text)
    assert doc.short_description == "The parse docstring"
    assert doc.long_description == "The parse docstring"
    assert doc.params[0].name == "text"
    assert doc.params[0].type == "A docstring to be parsed."
    assert doc.params[1].name == "style"
    assert doc.params[1].type == "The docstring style. Default is auto."
    assert doc.returns.type == "Parsed docstring representation."

# Generated at 2022-06-11 21:31:37.220560
# Unit test for function parse
def test_parse():
    # Create example docstring text
    docstring = """One line summary.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`.
    arg2 : str
        Description of `arg2`.

    Returns
    -------
    int
        Description of return value.

    """
    # Parse docstring
    result = parse(docstring)
    assert len(result.params) == 2
    assert len(result.returns) == 1


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:31:47.119557
# Unit test for function parse
def test_parse():
    """
    >>> docstring = ("This is a test documentation.\\n"
    ...              "\\n"
    ...              "This is a second line.\\n"
    ...              "\\n"
    ...              ":param test: this is a test\\n"
    ...              ":type test: int\\n"
    ...              ":returns: this is a return\\n"
    ...              ":rtype: str\\n")
    
    >>> parse(docstring)
    
    
    
    
    
    
    
    
    This is a test documentation.
    This is a second line.
    :param test: this is a test
    :type test: int
    :returns: this is a return
    :rtype: str
    :return: 
    """
    pass


# Generated at 2022-06-11 21:31:56.962440
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring for a function.
    It has several paragraphs.

    There are various places for a signature.

    :param foo: the foo parameter
    :type foo: str
    :returns: the return value
    :rtype: int
    """
    parsed_text = parse(text)
    assert(parsed_text.short_description == "This is a docstring for a function.")
    assert(parsed_text.long_description == '\nIt has several paragraphs.\n\nThere are various places for a signature.\n')
    assert(len(parsed_text.meta) == 2)
    assert(parsed_text.meta[0][0] == "foo")
    assert(parsed_text.meta[0][1] == "the foo parameter")
   

# Generated at 2022-06-11 21:31:58.698315
# Unit test for function parse

# Generated at 2022-06-11 21:32:08.432978
# Unit test for function parse

# Generated at 2022-06-11 21:32:22.488133
# Unit test for function parse

# Generated at 2022-06-11 21:32:33.674428
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    docstring = """Function for adding 2 numbers.

    Params:
        a: 1st number to be added
        b: 2nd number to be added

    Returns:
        sum of 2 numbers
    """

    assert parse(docstring) == {
        "description": "Function for adding 2 numbers.",
        "args": {"a": "1st number to be added", "b": "2nd number to be added"},
        "returns": "sum of 2 numbers",
        "yields": None,
        "raises": None,
        "warns": None,
        "others": [],
        "style": 3,
    }

# Generated at 2022-06-11 21:32:42.205927
# Unit test for function parse
def test_parse():
    assert parse('a,b') == Docstring(params=['a', 'b'])
    assert parse('a, b') == Docstring(params=['a', 'b'])
    assert parse('a, b') == Docstring(params=['a', 'b'])
    assert parse('a, b,', style=Style.reST) == Docstring(params=['a', 'b'])
    assert parse('a, b (foo)', style=Style.reST) == Docstring(params=['a', 'b (foo)'])
    assert parse('a, b (foo)') == Docstring(params=['a', 'b'], annotations={"b": "foo"})

# Generated at 2022-06-11 21:32:46.692218
# Unit test for function parse
def test_parse():
    doc_string = '''Some random text

    :param s: string
    :param d: description
    :returns: description
    :raises Exception: when error occurs
    '''
    parsed_doc_string = parse(doc_string)
    assert parsed_doc_string
    assert parsed_doc_string.short_description == 'Some random text'



# Generated at 2022-06-11 21:32:50.542375
# Unit test for function parse
def test_parse():
    from tests.fixtures import google as google_docstring
    from tests.fixtures import numpy as numpy_docstring

    assert parse(google_docstring)
    assert parse(numpy_docstring)
    try:
        parse("")
    except ParseError:
        assert True
    else:
        assert False

# Generated at 2022-06-11 21:32:57.289182
# Unit test for function parse
def test_parse():
    doc = "A sentence. And a sentence.\n\n" \
          ":param param1: first\n" \
          ":type param1: int"

    print( parse(doc) )

    d = Docstring(
        summary='A sentence. And a sentence.',
        description='',
        meta={'param1': {'type': 'int', 'desc': 'first'}},
        return_={},
        examples=[]
    )
    assert d.dump() == parse(doc).dump()

# Generated at 2022-06-11 21:32:59.666847
# Unit test for function parse

# Generated at 2022-06-11 21:33:07.599522
# Unit test for function parse
def test_parse():
    docstring = '''
    @param s: blah-blah
    '''
    res = parse(docstring)
    assert res.short_description == ''
    assert res.long_description == ''
    assert len(res.meta) == 1
    assert res.meta[0].arg_name == 's'
    assert res.meta[0].arg_type == None
    assert res.meta[0].description == 'blah-blah'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:33:15.128033
# Unit test for function parse
def test_parse():
    from docstring_parser.tests.test_data import numpy_docstring
    ds = parse(numpy_docstring)
    ds.args[0].default
    ds.meta['summary']
    ds.meta['extended_summary'].lines
    ds.args[0].name
    ds.args[0].annotation
    ds.args[0].description
    ds.raises[0].type
    ds.yields.annotation
    ds.yields.description
    ds.return_.annotation
    ds.return_.description
    ds.meta['see'].lines

# Generated at 2022-06-11 21:33:26.974851
# Unit test for function parse
def test_parse():
    ds = """Summary line.

Description:
  This paragraph describes
  the function.

Parameters:
  arg1 (int): The first argument.
  arg2 (str): The second argument.

Returns:
  bool: The return value. True for success, False otherwise.

  """

    docstring = parse(ds)
    assert hasattr(docstring, 'docstring')
    assert hasattr(docstring, 'meta')
    assert hasattr(docstring, 'summary')
    assert hasattr(docstring, 'extended_summary')
    assert hasattr(docstring, 'body')
    assert hasattr(docstring, '_parsed')

    assert docstring.docstring == ds.strip()

# Generated at 2022-06-11 21:33:34.540790
# Unit test for function parse
def test_parse():
  print("Testing running parse function...")
  doc = """Single-line docstring.
  Ignored, so expected to fail.
  """
  docstr = parse(doc)
  assert docstr.short_descr == "Single-line docstring."



# Generated at 2022-06-11 21:33:40.859010
# Unit test for function parse
def test_parse():
    dic = {
        'style': 'google',
        'summary': '     Test function parse()',
        'extended_summary': ''
    }
    assert parse(text=open('docstring_parser/__init__.py').read(), style='google')._asdict() == dic

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:33:48.515331
# Unit test for function parse
def test_parse():
    text = """A basic docstring.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    """


    # Test for parsing the docstring if default style is used
    docstring = parse(text)

    assert docstring.short_description == 'A basic docstring.'
    assert docstring.long_description == '\n    '
    assert docstring.params['param1'] == 'this is a first param'
    assert docstring.params['param2'] == 'this is a second param'
    assert docstring.returns == 'this is a description of what is returned'
    assert docstring.raises == {'keyError': 'raises an exception'}

    # Test for

# Generated at 2022-06-11 21:33:59.157553
# Unit test for function parse
def test_parse():
    import mock
    import pytest
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES
    from docstring_parser import parse
    # Test with one style
    test_style = list(STYLES.keys())[0]
    test_text = "Test text"
    with mock.patch.object(STYLES[test_style], "parse") as mock_style_parse:
        parse(test_text, test_style)
        mock_style_parse.assert_called_with(test_text)
    # Test with Style.auto
    test_text = "Test text"

# Generated at 2022-06-11 21:34:01.552726
# Unit test for function parse
def test_parse():
    test_doc = "This is a test doc string"
    result = parse(test_doc)
    assert result.short_descr == test_doc

# Generated at 2022-06-11 21:34:06.309722
# Unit test for function parse
def test_parse():
    s = """Hello, world
    This is a docstring.
    """
    assert parse(s) == Docstring(
        short_description='Hello, world',
        long_description='This is a docstring.',
        meta={},
        style=Style.pep257)



# Generated at 2022-06-11 21:34:11.584711
# Unit test for function parse
def test_parse():
    text = """
    This is a test.

    :param foo: bar
    :type foo: int
    :returns: 0
    """
    parser = parse(text)
    assert parser.short_description == "This is a test."
    assert parser.long_description == ""
    assert parser.returns.arg_type == "int"
    assert parser.returns.description == "0"

# Generated at 2022-06-11 21:34:16.751272
# Unit test for function parse
def test_parse():
    text = "Summary\n\nSome description\n\nparam: a\n:type a: int\n\nreturn: None\n:rtype: None\n"
    docstring = parse(text, Style.numpy)
    assert docstring.summary == "Summary"
    assert docstring.description == "Some description"

# Generated at 2022-06-11 21:34:20.149732
# Unit test for function parse
def test_parse():
    """Function to test function parse"""

    d = parse("""Parse the docstring into its components.""")
    assert d.content[0] == "Parse the docstring into its components."



# Generated at 2022-06-11 21:34:24.125584
# Unit test for function parse
def test_parse():
    from docstring_parser.parse import parse
    docstring = '''Summary line.

Extended description of function.

Parameters
----------
arg1 : int
    Description of arg1
arg2 : str
    Description of arg2

Returns
-------
str
    Description of return value
'''

# Generated at 2022-06-11 21:34:30.137142
# Unit test for function parse
def test_parse():
    a = str(parse.__doc__)
    assert(a == "Parse the docstring into its components.")

# Generated at 2022-06-11 21:34:33.843674
# Unit test for function parse
def test_parse():
    """define the unit test"""
    import pydocstring.parser as pp
    a=pp.parse("""This is the first line.
This is the second line.
This is the third line.""")
    assert a.short_description == "This is the first line."

# Generated at 2022-06-11 21:34:45.472599
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ReturnItem

    style_with_defaults = Style.numpy
    style = Style.google
    text = """Example function with types documented in the docstring.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    docstring = parse(text, style)
    assert docstring.short_description == "Example function with types documented in the docstring."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert isinstance(docstring.returns[0], ReturnItem)
    assert docstring.returns[0].name is None
   

# Generated at 2022-06-11 21:34:56.265737
# Unit test for function parse
def test_parse():
    docstring = """This is the module docstring.
This line is not indented.

This is the first paragraph.
It is followed by two blank lines.

This is the second paragraph.
It is followed by one blank line.

Summary line.
This is the summary paragraph.
"""
    d = parse(docstring, style=Style.numpy)
    assert d.description == 'This is the module docstring.\nThis line is not indented.'
    assert d.content == 'This is the first paragraph.\nIt is followed by two blank lines.\n\nThis is the second paragraph.\nIt is followed by one blank line.'
    assert d.short_description == 'Summary line.'
    assert d.long_description == 'This is the summary paragraph.'
    assert d.meta == {}



# Generated at 2022-06-11 21:35:03.877962
# Unit test for function parse
def test_parse():
    style = Style.numpy
    text = """This function does something.

    Parameters
    ----------
    param1 : array_like
        The first parameter.
    param2 :
        The second parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.

    """
    result = parse(text, style)
    print(result.summary)
    print(result.pos_args)
    print(result.pos_arg_names)
    print(result.kwargs[0].arg_name)
    print(result.kwargs[0].arg_type)
    print(result.kwargs[0].description)
    print(result.descriptions)
    print(result.returns)
    print(result.return_type)


# Generated at 2022-06-11 21:35:08.648076
# Unit test for function parse
def test_parse():
    text = """
    short summary
    :param str name: name of the person
    :param int age: age of the person
    """
    rets = parse(text)

    if rets.short_description != 'short summary':
        raise ImportError('parse failed')

# Generated at 2022-06-11 21:35:19.843991
# Unit test for function parse
def test_parse():
    str = """One line summary.

    Extended description.

    Args:
      arg1: Description of arg1
      arg2: Description of arg2
    Returns:
      Description of return val.
    """
    style = Style.google
    docstring = parse(text = str, style = style)
    assert(docstring.description == "One line summary.\n\nExtended description.")
    assert(docstring.short_description == "One line summary.")
    assert(docstring.long_description == "Extended description.")
    assert(docstring.raw == str)
    assert(docstring.meta['Args']['arg1'] == 'Description of arg1')
    assert(docstring.meta['Args']['arg2'] == 'Description of arg2')

# Generated at 2022-06-11 21:35:23.241532
# Unit test for function parse
def test_parse():
    assert parse("""title
    :param p1: p1
    :type p1: int
    :param p2: p2
    """).meta['p1'].type_name == 'int'

# Generated at 2022-06-11 21:35:24.270600
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    pass

# Generated at 2022-06-11 21:35:34.742595
# Unit test for function parse
def test_parse():
    """Unit tests for function parse"""

    from unittest import TestCase

    from docstring_parser.common import ReturnValue
    from docstring_parser.styles import Google, Numpy

    class Arguments(TestCase):

        def test_positionals(self):
            """Tests positional arguments"""
            text = """\
            Positional arguments:
            arg1 -- First argument
            arg2 -- Second argument
            """
            self.assertCountEqual(
                parse(text, style=Google).arguments,
                [
                    ("arg1", "First argument"),
                    ("arg2", "Second argument")
                ]
            )

        def test_keyword(self):
            """Tests keyword arguments"""
            text = """\
            Keyword arguments:
            kwarg1 -- First keyword argument
            """
            self.assertCount

# Generated at 2022-06-11 21:35:55.074893
# Unit test for function parse
def test_parse():
    text = """
    Parses the docstring into its components.

    Args:
        text (str): docstring text to parse.
        style (Style): docstring style.

    Returns:
        parsed docstring representation.

    Raises:
        ParseError: raise if can not parse the docstring.

    """
    result = parse(text)

# Generated at 2022-06-11 21:36:04.733551
# Unit test for function parse
def test_parse():
    text1 = "This is a docstring"
    text2 = ":param text: docstring text to parse"
    text3 = ":returns: parsed docstring representation"
    text4 = ":param style: docstring style"
    text5 = ":param style: docstring style\n :returns: parsed docstring representation"
    
    assert parse(text1, Style.google) == Docstring(summary='This is a docstring')
    assert parse(text2, Style.google) == Docstring(parameters=['text'])
    assert parse(text3, Style.google) == Docstring(returns='parsed docstring representation')
    assert parse(text4, Style.google) == Docstring(parameters=['style'])

# Generated at 2022-06-11 21:36:09.276192
# Unit test for function parse
def test_parse():
    docstring = """
    :param client: The client to associate with this object.
    :type client: :class:`~google.cloud.bigquery.client.Client`
    :param str dataset_id: The ID of the dataset.
    :param str name: (Optional) The name for the dataset.
    :raises ValueError: For invalid value types.
    """

# Generated at 2022-06-11 21:36:16.319846
# Unit test for function parse
def test_parse():
    docstring = '''\
One line summary.

Extended description.

:param foo: description of foo
:raises ValueError: if a problem occurred
'''
    doc = parse(docstring)
    # print("One line summary:", doc['summary'])
    # print("Extended description:", doc['description'])
    # print("foo:", doc['params']['foo'])
    # print("raises:", doc['raises']['ValueError'])

# if __name__ == "__main__":
#     test_parse()