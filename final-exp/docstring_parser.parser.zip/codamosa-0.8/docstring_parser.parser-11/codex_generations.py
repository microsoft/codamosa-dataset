

# Generated at 2022-06-11 21:26:23.289465
# Unit test for function parse
def test_parse():
    docstring_text = '''\
    """
    This is a summary.
    
    This is a description.

    :param foo: a parameter with a long description
    :param bar: a parameter without description

    :returns: The return value, which is also a long description.

    .. note::
        Some more information here.

    .. todo::
        Something that needs to be done.
    """
    '''
    ds = parse(docstring_text)
    assert(ds.summary == 'This is a summary.')
    assert(ds.description == '\nThis is a description.')

    # Params
    assert(len(ds.params) == 2)
    assert(ds.params[0].arg_name == 'foo')

# Generated at 2022-06-11 21:26:25.457380
# Unit test for function parse
def test_parse():
    text = ''
    style = Style.auto
    Docstring = parse(text,style)
    assert Docstring == Docstring

# Generated at 2022-06-11 21:26:34.057697
# Unit test for function parse
def test_parse():
    begin_doc = """
    Module:
        testDoc

    Add a link to the subsequent lines of a docstring when it's indented less
    than the first line.

    Args:
        text: the text of the docstring.

    Returns:
        The text with a link added to the last paragraph.

    Raises:
        AttributeError: If baz is not a valid option.
    """
    doc = parse(begin_doc)
    assert(doc.title == "testDoc")
    
    assert(len(doc.params) == 1)
    assert(len(doc.returns) == 1)
    assert(len(doc.raises) == 1)

# Generated at 2022-06-11 21:26:41.682480
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    parse_output = parse.__annotations__
    try:
        assert parse_output['text'] == "docstring text to parse"
        assert parse_output['style'] == "docstring style"
        assert parse_output['returns'] == "parsed docstring representation"
    except AssertionError:
        print('AssertionError: Please check the annotations for function parse')

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:26:53.825119
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    import numpy as np
    import math

# Generated at 2022-06-11 21:26:55.009395
# Unit test for function parse
def test_parse():
    d = parse("""
        This is a docstring.
        """)
    return d

# Generated at 2022-06-11 21:26:59.744252
# Unit test for function parse
def test_parse():
    s = """
        Palindrome checker.
        :param      text: input text
        :type       text: str
        :returns:          True if text is a palindrome, False otherwise
        :rtype:            bool
        :raises ValueError: if text contains non-alphanumeric characters
        """
    parse(s)

# Generated at 2022-06-11 21:27:10.657928
# Unit test for function parse
def test_parse():
    docstring = '''
    The ``match_tag()`` function

    :param tag: Tag to match
    :type tag: str
    :param attrs: Attributes to match
    :type attrs: dict[str, str]

    :return: True if the tag matches, False otherwise
    :rtype: bool
    :raises AttributeError: if tag is None, or attrs is not a dictionary.
    '''
    result = parse(docstring)

    assert result.short_description == "The ``match_tag()`` function"
    assert result.long_description == ""

# Generated at 2022-06-11 21:27:15.085913
# Unit test for function parse
def test_parse():
    assert parse('def abc():\n    """\n    Test\n    """') == Docstring(
        '\n    Test\n    ', '')
    assert parse('    Test') == Docstring('Test', '')

# Generated at 2022-06-11 21:27:18.385479
# Unit test for function parse
def test_parse():
    assert parse("Hello") is not None
    assert parse("Hello", stlye = Style.rst) is not None
    assert parse("Hello", style = Style.google) is not None

# Generated at 2022-06-11 21:27:27.355162
# Unit test for function parse
def test_parse():
    docstring = """This is a test docstring.
    :param one:first param
    :type one:int
    :param two: second param
    :type two: str
    :param three:third param
    :type three: float
    :returns: a string
    """

    assert isinstance(parse(docstring), Docstring)
    
    print("Testing of function: parse() successful.")

# Generated at 2022-06-11 21:27:40.726347
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    # Tests for use case 1 - Address what data is contained in each aspect of the Docstring.
    print("\n\n**** Test for use case 1 ****")

# Generated at 2022-06-11 21:27:51.950892
# Unit test for function parse

# Generated at 2022-06-11 21:28:02.151087
# Unit test for function parse
def test_parse():
    """
    Test case for function parse
    """
    docstring_1 = """
        Single line docstring.
        """
    docstring_2 = """
        Single line docstring.

        """
    docstring_3 = """
        Single line docstring.

        """
    docstring_4 = """
        Single line docstring.


        """
    docstring_5 = """
        Multiple
        line
        docstring.

        """
    docstring_6 = """
        Multiple
        line
        docstring.


        """
    docstring_7 = """
        Multiple
        line
        docstring.


        """
    docstring_8 = """
        Multiple
        line
        docstring.


        """

# Generated at 2022-06-11 21:28:03.539899
# Unit test for function parse
def test_parse():
    assert parse.__doc__

# Generated at 2022-06-11 21:28:06.193420
# Unit test for function parse
def test_parse():
    '''Test function parse'''
    text = '''
    @param a: bla
    :param b: a
    :return : bla
    '''
    print(text)
    print(parse(text))

# Generated at 2022-06-11 21:28:17.512810
# Unit test for function parse
def test_parse():
    test_cases = []

    # test_case 1
    ret_dictionary = {}
    ret_dictionary['text'] = "The main parsing routine."
    ret_dictionary['style'] = Style.num_style
    ret_dictionary['meta'] = {'param': [
        'text(str): docstring text to parse',
        'style: docstring style'],
        'returns': 'parsed docstring representation'}
    ret_dictionary['sections'] = []
    ret_dictionary['blank_before'] = None
    test_cases.append(ret_dictionary)

    # test_case 2
    ret_dictionary = {}
    ret_dictionary['text'] = "The main parsing routine."
    ret_dictionary['style'] = Style.num_style

# Generated at 2022-06-11 21:28:25.773562
# Unit test for function parse
def test_parse():
    assert parse("Summary.\n\n    Desc.\n") == parse("Summary.\nDesc.\n")
    assert parse("Summary.\n\n    Desc.\n", style=Style.google) == parse("Summary.\nDesc.\n", style=Style.google)
    assert parse("Summary.\n\n    Desc.\n", style=Style.numpy) == parse("Summary.\nDesc.\n", style=Style.numpy)
    assert parse("Summary.\n\n    Desc.\n", style=Style.pep257) == parse("Summary.\nDesc.\n", style=Style.pep257)

# Generated at 2022-06-11 21:28:37.192953
# Unit test for function parse
def test_parse():
    text = """
    Title line

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: All arguments concatenated.
    """
    d = parse(text)
    assert d.short_description == "Title line"
    assert d.long_description == ""
    assert d.returns.type_name == "All arguments concatenated."
    assert d.returns.description == ""
    assert d.params["arg2"].type_name == "The second argument."
    assert d.params["arg2"].description == ""
    assert d.raises is None



# Generated at 2022-06-11 21:28:44.448732
# Unit test for function parse
def test_parse():
    text = """\
    :Some meta:
        Description
        More Description
        Split Description
    a: int
        a Doc
    b: str
        b Doc
    throws: ValueError
        If a is not an integer
    """
    doc = parse(text)
    assert doc.meta['Some meta'] == 'Description\nMore Description\nSplit Description'
    assert doc.params['a'].description == 'a Doc'
    assert doc.params['b'].description == 'b Doc'
    assert doc.throws['ValueError'] == 'If a is not an integer'

# Generated at 2022-06-11 21:28:53.393282
# Unit test for function parse
def test_parse():
    import pprint
    from docstring_parser.tests.test_data import STYLE_DATA
    for style, data in STYLE_DATA.items():
        for text, expect in data:
            print(style, text)
            pprint.pprint(parse(text, style=style).to_dict())
            assert parse(text, style=style).to_dict() == expect


# Generated at 2022-06-11 21:29:02.009153
# Unit test for function parse
def test_parse():
    """Test function parse()."""
    source = """
    Function to calculate 2D Gaussian function.

    Parameters:
      x: Value at which the Gaussian function is calculated.
      y: Different to y.
      sigma: Standard deviation of Gaussian function.
    """
    output = parse(source)
    assert(len(output.params) == 3)
    assert(output.params[0].name == "x")
    assert(output.params[1].name == "y")
    assert(output.params[2].name == "sigma")
    assert(len(output.returns) == 0)
    assert(output.examples == [])
    assert(len(output.raises) == 0)
    assert(output.see_also == [] )
    assert(len(output.notes) == 0)

# Generated at 2022-06-11 21:29:07.404032
# Unit test for function parse
def test_parse():
    d3 = parse("""
    :param int dummy1: dummy1
    :param int dummy2: dummy2
    :return: dummy3
    :rtype: int
    """)
    print(d3.params)
    print(d3.meta)
    print(d3.returns)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:29:16.164687
# Unit test for function parse

# Generated at 2022-06-11 21:29:28.413182
# Unit test for function parse
def test_parse():
    text = """This is a general description and should be a single paragraph.
    This is a second paragraph.

    This is a third paragraph.

    Parameters
    ----------
    first : str, optional
        First params description
    second : int, optional
        Second param's description

    Returns
    -------
    str
        Return value description

    See Also
    --------
    :class:`test.test_test.Test`

    .. todo::
        * Add a todo item
        * Make this a list
        * Numbered lists work too

    """
    docstring = parse(text)
    assert len(docstring.sections['Parameters']) == 2
    first_param = docstring.sections['Parameters'][0]
    assert first_param.name == "first"
    assert first_param.type == "str"
    assert first

# Generated at 2022-06-11 21:29:37.894271
# Unit test for function parse
def test_parse():
    text = """
    hi

    :param str my_param: my first parameter
    :returns: something
    """

    ret = parse(text, Style.sphinx)

    assert ret.short_description == 'hi'
    assert ret.long_description == ''
    assert len(ret.params) == 1
    assert len(ret.returns) == 1
    assert (ret.returns.return_type, ret.returns.description) == ('', 'something')
    assert (ret.params['my_param'].arg_name,
            ret.params['my_param'].arg_type,
            ret.params['my_param'].description) == ('my_param', 'str', 'my first parameter')

# Generated at 2022-06-11 21:29:50.194363
# Unit test for function parse
def test_parse():
    docstring = parse("""
        Single line docstring

        :param request: The request object.
        :type request: :class:`rest_framework.request.Request`
        :returns: Response -- The response of the view.
        :raises: AttributeError, KeyError
        """)
    assert docstring.short_description == "Single line docstring"
    assert docstring.params['request'] == "The request object."
    assert docstring.returns == "Response -- The response of the view."
    assert docstring.raises == "AttributeError, KeyError"
    assert docstring.returns_type == "Response"
    assert docstring.returns_annotation == "Response"
    assert docstring.params_type == {'request': ":class:`rest_framework.request.Request`"}
    assert docstring

# Generated at 2022-06-11 21:29:53.429595
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a test for the parse function.
    '''

    ret = parse(docstring, style=Style.google)
    assert ret.short_description == ''
    assert ret.long_description == ['This is a test for the parse function.']

# Generated at 2022-06-11 21:30:04.464928
# Unit test for function parse
def test_parse():
    print("")
    print("Test function parse")
    print("")
    print("Test 1: Simple docstring")
    print("")

    docstring = parse("""This function does nothing.
    :param name: The name parameter.
    :type name: str.
    :param state: Current state to be in.
    :type state: bool.
    :returns:  str -- the result.
    :raises: AttributeError, KeyError
    """)

    print("Parsed docstring:")
    print(docstring)
    print("")
    print("========================================")
    print("")

    print("Test 2: Google style docstring")
    print("")


# Generated at 2022-06-11 21:30:09.607471
# Unit test for function parse
def test_parse():
    """Test parse."""
    style = Style.auto
    text = """Makes a great sandwich.

    Args:
        arg1: An argument
        arg2: Another argument
    Returns:
        a great sandwich
    """
    docstring = parse(text, style)
    print("test_parse")
    print("docstring: " + str(docstring))
    print("test_parse ends")
    assert docstring is not None


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:24.831216
# Unit test for function parse
def test_parse():
    text = '''
    This function does something.
    :param str name: The name to use.
    :param bool loud: Whether to yell.
    :returns: int -- The return code.
    :raises: TypeError -- The wrong type was given
    '''
    docstring = parse(text, Style.numpy)
    assert(docstring.long_description == 'This function does something.')
    assert(len(docstring.params) == 2)
    assert(docstring.params[0].type_name == 'str')
    assert(docstring.params[0].name == 'name')
    assert(docstring.params[0].description == 'The name to use.')
    assert(docstring.params[1].type_name == 'bool')

# Generated at 2022-06-11 21:30:29.788214
# Unit test for function parse
def test_parse():
    text = '''
    print(a)
    @param a:
    '''
    assert parse(text, style=Style.google) == '''
    print(a)
    @param a:
    '''
    assert parse(text, style=Style.numpy) == '''
    print(a)
    @param a:
    '''

# Generated at 2022-06-11 21:30:31.391528
# Unit test for function parse
def test_parse():
    func_docstring = """The main parsing routine."""
    assert parse(func_docstring) == parse(func_docstring)

# Generated at 2022-06-11 21:30:42.066020
# Unit test for function parse
def test_parse():
    # test parsing a plain docstring
    d = parse('Parses a docstring.')
    assert d.summary == 'Parses a docstring.'
    assert not d.args
    assert not d.kwargs
    assert not d.returns
    assert not d.yields
    assert not d.raises

    # test parsing a long docstring

# Generated at 2022-06-11 21:30:46.967372
# Unit test for function parse
def test_parse():
    text = """Summary line.

This is a longer description
that spans several lines.

Args:
    arg1 (int): The first parameter.
    arg2 (str): The second parameter.

Returns:
    bool: The return value. True for success, False otherwise.
"""
    assert parse(text=text)

# Generated at 2022-06-11 21:30:58.295142
# Unit test for function parse
def test_parse():
    assert parse('This is a one-line docstring.').short_description == 'This is a one-line docstring.'
    assert parse('Hello\n\nWorld').long_description == 'Hello\n\nWorld'
    assert parse('Hello\n  World').short_description == 'Hello\n  World'
    assert parse('Hello\n\nWorld',
                 style=Style.sphinx).long_description == 'Hello\n\nWorld'
    assert parse('Hello\n  World',
                 style=Style.sphinx).long_description == 'Hello\n  World'
    assert parse('Hello\n\nWorld',
                 style=Style.google).long_description == 'Hello\nWorld'
    assert parse('Hello\n  World',
                 style=Style.google).long_description == 'Hello\nWorld'

# Generated at 2022-06-11 21:31:01.909089
# Unit test for function parse
def test_parse():
    assert(parse('"""\nreturns the sum of a and b\n""")') == Docstring('returns the sum of a and b', (), (), (), (), (), (), (), ()))


# Generated at 2022-06-11 21:31:09.583857
# Unit test for function parse

# Generated at 2022-06-11 21:31:16.052285
# Unit test for function parse
def test_parse():
    docstring_parser_text = """\
    Short summary.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    int, str
        Description of return values
    """


# Generated at 2022-06-11 21:31:17.458771
# Unit test for function parse
def test_parse():
    assert parse("some text")
    assert parse("some text")

# Generated at 2022-06-11 21:31:24.664706
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse
    docstring = '''    This is a test for docstring parser.
    '''
    assert parse(docstring).short_description == 'This is a test for docstring parser.'

# Generated at 2022-06-11 21:31:34.788914
# Unit test for function parse
def test_parse():
    text = """This is my docstring.
    This is my second line

    Args:
        arg1 (int): First argument.
        arg2 (str): Second argument (default 'x').
        arg3 (float): Third argument (default 100.0).
    Kwargs:
        kkwarg1 (int): First key word argument (default 1).
        kwarg2 (str): Second key word argument (default 'y').
        kwarg3 (float): Third key word argument (default 200.0).
    """
    print(parse(text))
    print(parse(text, style='google'))
    print(parse(text, style='numpy'))
    print(parse(text, style='auto'))


# test and usage example
if __name__ == "__main__":

    test_parse()

# Generated at 2022-06-11 21:31:37.871128
# Unit test for function parse
def test_parse():
	text = 'This is a test docstring.'
	s = parse(text)
	assert(s.short_description == text)

# Generated at 2022-06-11 21:31:47.512229
# Unit test for function parse
def test_parse():
    """Test parse function."""
    text = '''Summary line.

Description of what it does, what parameters it expects, what it returns,
what errors it can raise, etc.

:param arg1: int
:param arg2: str
:returns: str
:raises keyError: raises an exception
'''
    result = parse(text, 'numpy')
    assert result.short_description == 'Summary line.\n'
    assert result.long_description == 'Description of what it does, what parameters it expects, what it returns,\nwhat errors it can raise, etc.\n'
    assert result.params == {'arg1': 'int', 'arg2': 'str'}
    assert result.returns == 'str'
    assert result.raises == {'keyError': 'raises an exception'}

# Generated at 2022-06-11 21:31:57.015676
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Parameter, Return, Variable
    from docstring_parser.styles import Style
    from .docstring_parser.__init__ import __version__
    docstring_parser_version = __version__
    text = '''
    :param a: Parameter A.
    :type a: int

    :param str b: Parameter B.
    :param int c: Parameter C.

    :returns: Return value.
    :rtype: int

    :raises ValueError: Raises ValueError.
    '''
    style = Style.google

# Generated at 2022-06-11 21:32:07.967303
# Unit test for function parse

# Generated at 2022-06-11 21:32:12.597485
# Unit test for function parse
def test_parse():
  text = '''\
  Header
  ------------------
  Params:
    name (str): Full name.
  Returns:
    bool: True if valid.
  Raises:
    TypeError: If `name` is not a string
  '''
  print(parse(text))

import doctest
doctest.testmod()

# Generated at 2022-06-11 21:32:21.528132
# Unit test for function parse
def test_parse():

    docstring = '''Hello, world.
This is a test.

:param x: some thing
:param y: somthing else
'''
    d = parse(docstring)
    assert d.full == docstring
    assert d.short == 'Hello, world.'
    assert d.long == 'This is a test.'
    assert d.meta[0].name == 'param'
    assert d.meta[0].args == 'x'
    assert d.meta[0].body == 'some thing'
    assert d.meta[1].name == 'param'
    assert d.meta[1].args == 'y'
    assert d.meta[1].body == 'somthing else'

# Generated at 2022-06-11 21:32:33.102884
# Unit test for function parse

# Generated at 2022-06-11 21:32:41.297804
# Unit test for function parse
def test_parse():
    with open("docstring_parser/test/test_file.py", "r") as f:
        text = f.read()
    parsed_dict = parse(text)
    assert parsed_dict.meta["author"] == "Randy Lai"
    assert parsed_dict.meta["date"] == "2018-09-23"
    assert len(parsed_dict.short_description) == 14
    assert len(parsed_dict.long_description) == 18
    assert parsed_dict.params["arg1"] == "str -- hello world"
    assert parsed_dict.raises["ValueError"] == "if arg1 is not a string"
    assert parsed_dict.returns == "True if success; else False"


# Generated at 2022-06-11 21:32:53.001652
# Unit test for function parse
def test_parse():
    print("Test func parse:")
    assert parse("foo\nbar") is not None
    assert parse("foo\nbar", style=Style.numpy) is not None
    assert parse("foo\nbar", style=Style.google) is not None
    assert parse("foo\nbar", style=Style.sphinx) is not None
    assert parse("foo\nbar", style=Style.auto) is not None
    assert parse("foo\nbar", style=None) is not None


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:33:01.485511
# Unit test for function parse
def test_parse():
    def d():
        """
        Return None

        :param yolo: haha
        :return: None
        """
        pass

    docstring = parse(d.__doc__)
    assert docstring.short_description == 'Return None'
    assert docstring.long_description == ''
    assert docstring.params[0].arg_name == 'yolo'
    assert docstring.params[0].description == 'haha'
    assert docstring.params[0].annotation == ''
    assert docstring.returns.arg_name == 'return'
    assert docstring.returns.description == 'None'
    assert docstring.returns.annotation == ''

    # Other tests are in test_styles.py and test_data.py

# Generated at 2022-06-11 21:33:03.742438
# Unit test for function parse
def test_parse():
    assert parse("This function does something.\n") == parse("This function does something.\n", style=Style.numpy)

# Generated at 2022-06-11 21:33:08.504969
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    assert parse("") == Docstring()
    assert parse("a", style=Style.numpy) == Docstring(content = "a")
    try:
        parse("a", style=Style.google)
    except ParseError:
        pass


# Generated at 2022-06-11 21:33:18.578027
# Unit test for function parse
def test_parse():
    """Unit tests for function parse"""
    test_parse_text = """This is a test docstring.
    :param param1: this is a one-line test parameter
    :param param2: this is a
                    multiline test parameter
    :returns: this is a test return
    :raises keyError: this is a test exception
    """
    assert parse(test_parse_text)
    test_parse_text2 = '''This is a test docstring.
    @param param1: this is a one-line test parameter
    @param param2: this is a
                    multiline test parameter
    @returns: this is a test return
    @raises keyError: this is a test exception
    '''
    assert parse(test_parse_text2)

# Generated at 2022-06-11 21:33:30.291958
# Unit test for function parse
def test_parse():
    text = """Function docstring.
    
    Parameters
    ----------
    arg1 : int
        the first argument
    arg2 : str
        the second argument
    Returns
    -------
    int, str
        The return value."""
    text += """\nYields
    ------
    int, str
        The yield value."""
    doc = parse(text)
    assert doc.summary == 'Function docstring.'
    assert len(doc.params) == 2
    assert doc.returns.desc == ['The return value.']
    assert doc.returns.type_name == ['int', 'str']
    assert len(doc.yields) == 1
    assert doc.yields[0].desc == ['The yield value.']

# Generated at 2022-06-11 21:33:35.893458
# Unit test for function parse
def test_parse():
    docstring = '''
        This is the first parameter.

        :param int x: the first parameter
        :param y: the second parameter
        :type y: float
        :returns: None
        :raises ValueError: when x is negative
        :raises TypeError: when x is not a int
    '''
    new_docstring = parse(docstring, style=Style.numpy)
    for item in new_docstring:
        print(item.to_dict())



# Generated at 2022-06-11 21:33:44.177554
# Unit test for function parse
def test_parse():
    doc = """
        Function variables
        :param x: first value
        :type x: int
        :param y: second value
        :type y: int
        :returns: sum of x and y
        :rtype: int
    """
    assert parse(doc)
    assert parse(doc).short_description == 'Function variables'
    assert parse(doc).long_description == ''
    assert parse(doc).meta['x'] == 'first value'
    assert parse(doc).meta['y'] == 'second value'
    assert parse(doc).meta['returns'] == 'sum of x and y'

# Generated at 2022-06-11 21:33:51.383841
# Unit test for function parse
def test_parse():
    """Simple unit test for function parse"""
    text = """This is function parse
    
    Parameters
    ----------
    text : str
        docstring text to parse
    style : Style
        docstring style
    """
    parsed = parse(text)
    assert parsed.summary == "This is function parse"
    assert parsed.meta["text"].type == "str"
    assert parsed.meta["style"].type == "Style"
    assert parsed.meta["style"].desc == "docstring style"

# Generated at 2022-06-11 21:34:00.083422
# Unit test for function parse
def test_parse():
    test_doc = """Summary line here.
    Extended description here.
    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
    Returns:
        str: Description of return value.
    """

    assert parse(test_doc) == Docstring(
        summary='Summary line here.',
        description='Extended description here.',
        meta={
            'args': [
                ['arg1', 'int', 'Description of arg1'],
                ['arg2', 'str', 'Description of arg2']
            ],
            'returns': ['str', 'Description of return value.']
        },
        sections=[]
    )
    return True
print(test_parse())

# Generated at 2022-06-11 21:34:11.782350
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import parse_pep257
    d = parse('', style=Style.pep257)
    assert d == parse_pep257('')
    d = parse('', style=Style.google)
    assert d == dict()
    d = parse('', style=Style.numpy)
    assert d == dict(index_parameter_name=[], return_type={})
    d = parse('', style=Style.sklearn)
    assert d == dict(index_parameter_name=[], index_return_type=[])
    d = parse('', style=Style.auto)
    assert d == dict()

# Generated at 2022-06-11 21:34:19.798919
# Unit test for function parse
def test_parse():
    text = """Returns a string which indicate the type of the input value.
    
    :param x: a number or string to be determined.
    :type x: a string.
    :return: a string which indicate the type of the input value
    :rtype: string
    """
    doc = parse(text)
    print('docstring text:', doc.text)
    print('meta:', doc.meta)
    print('params:', doc.params)
    print('returns:', doc.returns)
    
    
    

# Generated at 2022-06-11 21:34:30.463207
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse(" ") == Docstring()
    assert parse("hello") == Docstring(content="hello")
    assert parse("""
    hello,
    I am a
    
    docstring!
    """).content == """
    hello,
    I am a
    
    docstring!
    """
    assert parse("""
    :param p: a param 5
    """, Style.numpy).params["p"].desc == "a param 5"
    assert parse("""
    :param p: a param 5
    """, Style.google).params["p"].desc == "a param 5"
    assert parse("""
    :param p: a param 5
    """, Style.sphinx).params["p"].desc == "a param 5"

# Generated at 2022-06-11 21:34:41.067593
# Unit test for function parse
def test_parse():
    text = '''\
    This function does something.

    :param int foo: a foo
    :param: bar: a bar
    :param baz: a baz
    :raises ValueError: if the value is invalid

    :returns: the result
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This function does something.'
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 3
    assert docstring.params[0].arg_name == 'foo'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'a foo'
    assert docstring.params[1].arg_name == 'bar'

# Generated at 2022-06-11 21:34:46.133412
# Unit test for function parse
def test_parse():
    doc = """This is a test
    """

    assert parse(doc, style=Style.numpy).short_description == "This is a test"
    assert parse(doc, style=Style.numpy).sphinx == "This is a test"
    assert parse(doc, style=Style.sphinx).sphinx == "This is a test"

#test_parse()

# Generated at 2022-06-11 21:34:53.408930
# Unit test for function parse
def test_parse():
    assert parse("Parse the docstring into its components.") == Docstring(
        content="",
        returns=None,
        raises=None,
        meta={},
        examples=[],
        style=Style.numpy
    )

    # TODO: Docstring.summary should also pass
    assert parse("Parse the docstring into its components.", style=Style.go) == Docstring(
        content="Parse the docstring into its components.",
        returns=None,
        raises=None,
        meta={},
        examples=[],
        style=Style.go
    )

# Generated at 2022-06-11 21:35:02.692505
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Style, google

    docstr = google.parse('''
        A simple add function.

        Args:
            x: 1st value.
            y: 2nd value.

        Returns:
            Sum of x and y.
    ''')
    assert docstr.short_description == 'A simple add function.'
    assert len(docstr.long_description) == 0
    assert len(docstr.meta) == 2
    assert docstr.meta['Args'] == "x: 1st value.\ny: 2nd value."
    assert docstr.meta['Returns'] == "Sum of x and y."

    assert docstr.args == (
        ('x', '1st value.'),
        ('y', '2nd value.'),
    )

# Generated at 2022-06-11 21:35:15.456658
# Unit test for function parse
def test_parse():
    r = parse('paragraphe1\n\nparagraphe2')
    assert(str(r) == 'paragraphe1\n\nparagraphe2')
    
    r = parse('paragraphe1\n :key: value\nparagraphe2')
    assert(str(r.meta) == ' :key: value')
    assert(str(r) == 'paragraphe1\n\nparagraphe2')
    
    r = parse('paragraphe1\n :key: value inline\nparagraphe2')
    assert(str(r.meta) == ' :key: value inline')
    assert(str(r) == 'paragraphe1\n\nparagraphe2')
    

# Generated at 2022-06-11 21:35:22.436455
# Unit test for function parse
def test_parse():
    """Unit test for function parse
    """
    docstring = parse("""
    This method is for testing purpose

    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: Description of return value
    :raises keyError: raises an exception
    """)
    assert docstring.long_description == 'This method is for testing purpose'
    assert docstring.params['param1'].description == 'The first parameter.'
    assert docstring.params['param2'].description == 'The second parameter.'
    assert docstring.returns.description == 'Description of return value'
    assert docstring.raises['keyError'].description == 'raises an exception'

# Generated at 2022-06-11 21:35:33.267737
# Unit test for function parse
def test_parse():
    """Test parse function."""
    def fn():
        """This is the docstring.
        :param name: A name.
        :type name: str
        :param value: A value.
        :type value: int
        :rtype: dict
        """
        pass

    output = parse(fn.__doc__)
    print(output.meta)
    print(output.args)
    print(output.returns)
    assert output.meta == 'This is the docstring.'
    assert output.args == [('name', 'A name.'), ('value', 'A value.')]
    assert output.returns == 'dict'


# Generated at 2022-06-11 21:35:37.947384
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()
    print("test_docstring_parser.py is complete!")

# Generated at 2022-06-11 21:35:43.481985
# Unit test for function parse
def test_parse():
    docstring = """This is a very short description of a module.

A list of things that may be added to the docstring:

- A description of the project's history, including the rationale and
  factors that influenced its design.

- Technical notes and limitations.

- A glossary of terms that pertains to the module.

- Basic usage examples.
"""
    result = parse(docstring)
    assert str(result) == docstring
    assert result.short_description == "This is a very short description of a module."

# Generated at 2022-06-11 21:35:55.277802
# Unit test for function parse
def test_parse():
    text = '''
    A module-level docstring.
    
    :return: Nothing
    '''
    d = parse(text)
    assert d.short_description == 'A module-level docstring.'
    assert d.long_description is None
    assert d.returns.type_name == 'None'
    assert d.returns.description == 'Nothing'

    text = '''
    A module-level docstring.

    :param a: The first parameter.
    :param b: The second parameter.
    :return: Nothing
    '''
    d = parse(text)
    assert d.short_description == 'A module-level docstring.'
    assert d.long_description is None
    assert d.params['a'].type_name is None

# Generated at 2022-06-11 21:35:57.922955
# Unit test for function parse
def test_parse():
    text = """\
    """
    assert parse(text, style=Style.numpy).summary == ''


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:36:09.027856
# Unit test for function parse
def test_parse():
    # test a style that has compatibility issues with docstring_parser
    def test_case(text: str, result: str, style: Style = Style.auto):
        if style == Style.auto:
            ret = parse(text)
        else:
            ret = parse(text, style=style)
        assert repr(ret) == result

    test_case(
        text="",
        result="Docstring(summary='', body='', meta=(), sections=(), exceptions=(), returns=None, raises=(), \
calls=(), notes=(), warnings=(), attributes=(), properties=(), see_also=(), references=(), \
todo=(), examples=(), deprecated=(), extras=(), decorators=[])"
    )