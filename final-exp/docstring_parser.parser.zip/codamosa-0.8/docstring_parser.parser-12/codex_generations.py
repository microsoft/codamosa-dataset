

# Generated at 2022-06-11 21:26:19.525748
# Unit test for function parse

# Generated at 2022-06-11 21:26:23.915275
# Unit test for function parse
def test_parse():
    text = '''"""This is a test.

:param x: x-value
:returns: y-value
"""'''
    result = parse(text)
    assert result.short_description == 'This is a test.'
    assert len(result.long_description) == 0
    assert result.params['x'].type == 'x-value'
    assert result.returns.type == 'y-value'

# Run unit test for function parse
test_parse()

# Generated at 2022-06-11 21:26:30.087966
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    print('Test parse')
    docstring = """
    Test parse

    Parameters
    ----------
    text: str
        docstring text to parse
    style: Style = Style.auto
        docstring style
    :returns: parsed docstring representation
    """
    parse(docstring)
    return 


# Generated at 2022-06-11 21:26:36.599546
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

Extended description of function.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`
Returns
-------
str
    Description of return value
"""
    parsed_docstring = parse(docstring)
    assert isinstance(parsed_docstring, Docstring)
    assert parsed_docstring.summary
    assert parsed_docstring.description
    assert parsed_docstring.params
    assert parsed_docstring.returns
    assert parsed_docstring.returns.description == 'Description of return value'
    assert parsed_docstring.meta['arg2'].description == 'Description of `arg2`'



# Generated at 2022-06-11 21:26:40.781932
# Unit test for function parse
def test_parse():
    text = """
        Unit tests for function parse
        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """
    assert parse(text)

# Generated at 2022-06-11 21:26:51.950790
# Unit test for function parse
def test_parse():
    try:
        parse("")
        assert False, "Expected ParseError"
    except ParseError:
        assert True

    try:
        parse("Docstring with no title", style=Style.google)
        assert False, "Expected ParseError"
    except ParseError:
        assert True

    assert parse("Docstring with no title", style=Style.numpy)
    assert parse("Docstring with no title", style=Style.auto).summary == "Docstring with no title"
    assert parse("Docstring with no title", style=Style.all_) == [parse("Docstring with no title", style=st) for st in STYLES]


# Test file for module docstring_parser

# Generated at 2022-06-11 21:26:54.915569
# Unit test for function parse
def test_parse():
    expected = Docstring(summary="Test function parse",
                        description="The main parsing function")
    assert parse(expected.__repr__()) == expected

# Generated at 2022-06-11 21:27:07.058282
# Unit test for function parse
def test_parse():
    # Test 1
    text = """
    This is a short description
    
    
    This is a long description
    
    
    :param arg1: This is the first positional arg
    :param arg2: This is the second positional arg
    :param arg3: This is the first keyword arg
    :param arg4: This is the second keyword arg
    
    
    :returns: This is what is returned
    :returns: This is the second return
    :returns: This is the third return
    
    
    :raises (Exception), (Exception): This is the exception
    :raises Exception: This is another exception
    """
    d = parse(text)
    assert len(d.meta) == 7
    assert d.short_desc == 'This is a short description'

# Generated at 2022-06-11 21:27:08.214680
# Unit test for function parse
def test_parse():
    parse('parsing')

# Generated at 2022-06-11 21:27:09.065437
# Unit test for function parse

# Generated at 2022-06-11 21:27:22.737219
# Unit test for function parse
def test_parse():
    print("Testing parse")
    # 1
    text = '''
    """
    
    """
    '''
    assert repr(parse(text)) == control_repr
    # 2
    text = '''
    """
    
    
    
    
    
    
    
    
    
    
    
    
    
    """
    '''
    assert repr(parse(text)) == control_repr
    # 3
    text = '''
    """
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    """
    '''
    assert repr(parse(text)) == control_repr
    # 4

# Generated at 2022-06-11 21:27:31.904607
# Unit test for function parse

# Generated at 2022-06-11 21:27:36.887781
# Unit test for function parse
def test_parse():
    text = r"""    hello:
    hello:
    :param foo: hello
    :returns: hello
    """
    result = parse(text)
    assert result.body == r"""hello:"""
    assert len(result.meta) == 2


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:27:45.159154
# Unit test for function parse
def test_parse():
    text = """
        This is a test docstring.

        :param int a: parameter a
        :param str b: parameter b
        :returns: str -- my string
        :raises TypeError: generator raised the exception
    """
    ds = parse(text)
    assert ds.short_description == 'This is a test docstring.'
    assert ds.long_description == ''
    assert ds.meta['parameters']['a']['type'] == 'int'
    assert ds.meta['parameters']['b']['type'] == 'str'
    assert ds.meta['returns']['type'] == 'str'
    assert ds.meta['returns']['desc'] == 'my string'
    assert ds.meta['exceptions']['TypeError']['type']

# Generated at 2022-06-11 21:27:52.328491
# Unit test for function parse
def test_parse():
    assert isinstance(parse("""\
    This is a docstring.

    :param arg1: The arg1
    :param arg2: The arg2
    :returns: something
    :raises keyError: raises an exception
    """), Docstring)
    assert isinstance(parse("""\
    This is a docstring.
    """, style = Style.google), Docstring)
    assert isinstance(parse("""\
    This is a docstring.
    """, style = Style.numpy), Docstring)


# Generated at 2022-06-11 21:28:03.104690
# Unit test for function parse
def test_parse():
    # doctest: +NORMALIZE_WHITESPACE
    assert parse("It's a trap!") == Docstring(short_description="It's a trap!",
                                              long_description=None, meta={})

    assert parse("It's a trap!\n\nWith a long long description.") == Docstring(
        short_description="It's a trap!",
        long_description="With a long long description.", meta={})

    # doctest: +NORMALIZE_WHITESPACE

# Generated at 2022-06-11 21:28:11.003374
# Unit test for function parse
def test_parse():
    text = '''\
    Converts an array of samples to a waveform.

    :param data: array of samples
    :param width: number of bytes per sample
    :param nchannels: number of channels
    :param sampwidth: number of bytes per sample
    :param framerate: sampling frequency
    :param comptype: audio codec
    :param compname: audio codec
    :param frames: number of samples per channel
    '''

# Generated at 2022-06-11 21:28:14.043793
# Unit test for function parse
def test_parse():
    text = """
This is a multiline docstring.

This is the second line.
"""
    result = parse(text)
    assert(result)


# Generated at 2022-06-11 21:28:18.658498
# Unit test for function parse
def test_parse():
    text = """
    title: parse docstring
    author: A-team

    This is the content of the docstring.
    """
    assert parse(text, style=Style.google) is not None
    assert parse(text, style=Style.numpy) is not None


# Generated at 2022-06-11 21:28:29.172301
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import STYLES
    from docstring_parser.parser import parse
    text = \
        """
        This is a function.

        :param request:
        :param args:
        :param kwargs:
        :return:
        """
    # Parse the text with auto
    res = parse(text)
    assert type(res) == type(Docstring())
    # Parse the text with Numpy
    res = parse(text, 'numpy')
    assert type(res) == type(Docstring())
    # Parse the text with Numpy
    res = parse(text, 'google')
    assert type(res) == type(Docstring())

# Generated at 2022-06-11 21:28:43.830167
# Unit test for function parse
def test_parse():
    input = """Calculate z for Coefficients a,b,c.
    :param a: Coefficient a
    :type a: int
    :param b: Coefficient b
    :type b: int
    :param c: Coefficient c
    :type c: int
    :return: z
    :rtype: int
    :raises ValueError: if a is not positive
    """
    result = parse(input)
    assert result
    assert isinstance(result, Docstring)
    assert result.short_description == "Calculate z for Coefficients a,b,c."
    assert result.long_description == ""
    assert result.params[0].arg_name == "a"
    assert result.params[0].field_type == "int"
    assert result.params[0].description == "Coefficient a"

# Generated at 2022-06-11 21:28:55.393362
# Unit test for function parse
def test_parse():
    docstring = r'''One line summary.

    Extended summary.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    bool
        Description of return value
    '''

    assert parse(docstring).string == docstring
    assert parse(docstring).short_description == 'One line summary.'
    assert parse(docstring).long_description == '\nExtended summary.'
    assert parse(docstring).returns == ['bool', 'Description of return value']
    assert parse(docstring).sections['Parameters'] == [
        ['arg1', 'int', 'Description of `arg1`'],
        ['arg2', 'str', 'Description of `arg2`']
    ]

# Generated at 2022-06-11 21:29:02.517639
# Unit test for function parse
def test_parse():
    """
    Function to check if the parse function works.
    It checks for the parsed object with its name, description, etc.
    """
    doc = "Function to check if the parse function works. It checks for the parsed object with its name, description, etc."
    p = parse(doc)
    assert p.name == "test_parse"
    assert p.description == "Function to check if the parse function works.\nIt checks for the parsed object with its name, description, etc."
    assert p.params == []
    assert p.returns == {}

# Generated at 2022-06-11 21:29:12.631488
# Unit test for function parse
def test_parse():
    from docstring_parser.whitespace import parse_whitespace
    from docstring_parser.styles import STYLES, Style

    d = parse(text = "This is a test.", style = Style.whitespace)
    assert d.short_description == "This is a test."
    assert d.long_description == ""
    assert d.raw == "This is a test."
    assert d.params == []
    assert d.returns == None
    assert d.meta == []
    assert d.style == Style.whitespace

    d = parse(text = "This is a test.\nWith a second line.", style = Style.whitespace)
    assert d.short_description == "This is a test."
    assert d.long_description == "With a second line."

# Generated at 2022-06-11 21:29:27.224808
# Unit test for function parse
def test_parse():

    assert parse("") == Docstring()
    assert parse("\nfoo bar") == Docstring()

    assert parse("""\
one-line summary

one-line description

:param foo:
    foo parameter docs
""") == Docstring(
    summary = "one-line summary",
    description = "one-line description",
    params = {
        "foo": "foo parameter docs"
    }
)

    assert parse("""\
one-line summary

one-line description

:param foo: foo parameter docs
""") == Docstring(
    summary = "one-line summary",
    description = "one-line description",
    params = {
        "foo": "foo parameter docs"
    }
)


# Generated at 2022-06-11 21:29:33.630299
# Unit test for function parse
def test_parse():
    docstring = \
    """
    This is a docstring

    :param a: parameter a
    :param b: parameter b
    :returns: nothing

    """
    
    ds = parse(docstring)
    
    assert len(ds.params) == 2
    assert len(ds.returns) == 1
    assert len(ds.meta) == 2
    
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:29:41.751065
# Unit test for function parse
def test_parse():
    import os
    import sys
    import doctest
    path = os.path.dirname(__file__)
    path = os.path.join(path, 'style')
    sys.path.insert(0, path)
    from numpy import Docstring
    from numpy import Style
    from google import Docstring
    from google import Style
    from numpy import ParseError
    for style in Style:
        if style is Style.auto:
            continue
        docstring = parse("", style)
        assert(docstring.description == "")
        assert(docstring.meta == {})
        docstring = parse("test", style)
        assert(docstring.description == "test")
        assert(docstring.meta == {})
    for style in Style:
        if style is Style.auto:
            continue

# Generated at 2022-06-11 21:29:50.532877
# Unit test for function parse
def test_parse():
    doc = parse('''
    Return the absolute value of a number.  The argument may be an integer or a
    floating point number.  If the argument is a complex number, its magnitude
    is returned.
    ''')
    assert doc.short_description == 'Return the absolute value of a number.'
    assert doc.long_description == '''The argument may be an integer or a
    floating point number.  If the argument is a complex number, its magnitude
    is returned.'''

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:29:57.212996
# Unit test for function parse
def test_parse():
    """Test function parse(text, style)

    :returns: none
    """
    #test for style = auto
    docstring = """Description::
    This is a description.
    See more description.

Args:
    param1 (int): This is the first param.
    param2 (str): This is a second param.

Returns:
    bool: This is a description of the return value.
"""
    assert parse(docstring).description == "Description::\n    This is a description.\n    See more description.\n"
    assert parse(docstring).summary == "This is a description."
    assert parse(docstring).args == {'param1': 'This is the first param.', 'param2': 'This is a second param.'}

# Generated at 2022-06-11 21:30:08.270267
# Unit test for function parse
def test_parse():
  text = """parameters:
  name: str
  age: int
  address: str

  information:
  name: str
  age: int
  address: str

  """
  result = parse(text)
  assert result.short_description == ""
  assert result.long_description == ""
  assert result.meta.name == "parameters"
  assert result.meta.type == "Parameters"
  assert result.meta.parameters == [{"name":"name", "type":"str"},{"name":"age","type":"int"},{"name":"address","type":"str"}]
  assert result.meta.returns == {}
  assert result.meta.yields == {}
  assert result.meta.raises == []
  assert result.meta.attributes == []
  assert result.meta.decorator_list == []

# Generated at 2022-06-11 21:30:15.986541
# Unit test for function parse
def test_parse():
    text = '''
    this is description
    """
    :param model: The model
    :type model: class
    """
    '''
    assert(str(parse(text, style=Style.google)) == text.strip())

    text = '''
    this is description
    """
    @rtype: The return type
    @type: int
    """
    '''
    assert(str(parse(text, style=Style.numpy)) == text.strip())


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:25.845570
# Unit test for function parse
def test_parse():
    from pprint import pprint
    from docstring_parser.styles import GoogleStyleDocstring
    from docstring_parser.common import Docstring
    test_docstr = """This is a multiline docstring."""
    result = parse(test_docstr)
    assert result == Docstring.from_pep257(test_docstr)
    test_docstr = """
        This is a multiline docstring.

        :param x: A parameter
        :type x: int

        This is another line.
    """
    result = parse(test_docstr)
    assert result == GoogleStyleDocstring.from_pep257(test_docstr)

# Generated at 2022-06-11 21:30:33.094251
# Unit test for function parse
def test_parse():
    test_text = '''test text'''
    ret = parse(test_text, 'numpy')
    expected = Docstring(
        content=['test text'],
        summary='test text',
        returns=None,
        raises=None,
        attributes=None,
        variables=None,
        examples=None,
        see_also=None,
        notes=None,
        references=None,
        meta={'style': 'numpy'}
    )
    assert expected == ret
    return True

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:30:43.984726
# Unit test for function parse
def test_parse():
    string = '''
    Get shortest distance from a point for a line.

    Parameters
    ----------
    x,y : input array_like
        coordinates of input point
    a : array_like
        coordinates of end point 1 of line
    b : array_like
        coordinates of end point 2 of line

    Returns
    -------
    d : float
        shortest distance between the point and the line

    '''
    parsed = parse(string)
    assert parsed.short_description == 'Get shortest distance from a point for a line.'
    assert len(parsed.params) == 3
    assert parsed.params['x,y'].name == 'x,y'
    assert parsed.params['x,y'].type == 'input array_like'
    assert parsed.params['x,y'].description == 'coordinates of input point'


# Generated at 2022-06-11 21:30:55.427254
# Unit test for function parse
def test_parse():
    s = '''
        This is a test

        :param old: Old value
        :type old: int
        :param new: New value
        :type new: int
        :returns: New value
        :rtype: int
    '''
    d = parse(s)

    assert d.short_description == 'This is a test'
    assert d.long_description == ''
    d.params[0].arg_name == 'old'
    d.params[0].description == 'Old value'
    d.params[0].annotation == 'int'
    assert d.returns.description == 'New value'
    assert d.returns.annotation == 'int'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:31:01.507709
# Unit test for function parse
def test_parse():
    text = """Summary line.
    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    int
        Description of return value
    """

    rets = parse(text)
    # print(rets.arguments, rets.returns)
    assert len(rets.arguments) == 2, "parse() should have parsed two arguments"
    assert rets.arguments[0].name == "arg1", "parse() should have parsed arg1"
    assert rets.arguments[1].name == "arg2", "parse() should have parsed arg2"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:31:03.625019
# Unit test for function parse
def test_parse():
    import doctest, pytest
    results = doctest.testmod()
    assert results.failed == 0

test_parse()

# Generated at 2022-06-11 21:31:17.477439
# Unit test for function parse
def test_parse():
	d = """
    This is a docstring.

	:param a: The first param.
	:type a: int, required
	:param b: The second param.
	:type b: int, optional
	:raises e: An error
	:returns: nothing
	"""

	assert parse(d).summary == 'This is a docstring.'
	assert parse(d).description == ''
	assert parse(d).returns.description == 'nothing'
	assert parse(d).params[0].arg_name == 'a'
	assert parse(d).params[0].description == 'The first param.'
	assert parse(d).params[0].type_name == 'int'
	assert parse(d).params[0].is_required
	assert parse(d).raises[0].arg_name == 'e'
	

# Generated at 2022-06-11 21:31:22.668987
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function with some
    long docstring that should be correctly
    parsed.

    :param arg1: The first argument
    :param arg2: The second argument
    :param arg3: The third argument
    :returns: Something important
    '''
    assert parse(text).returns == "Something important"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:31:33.671561
# Unit test for function parse
def test_parse():
    text1 = """This is a function.

    It's a function docstring.

    :param arg1: This is the first argument.
    :param arg2: This is the second argument.
    :return: This is what is returned.
    """
    docstring = parse(text1)
    print('-'*50)
    print("Test 1 parse function: ")
    print("Summary:", docstring.summary)
    print("Description:", docstring.description)
    print("Parameters:")
    for param in docstring.params:
        print("\t", param.name, param.description)
    print("Returns:", docstring.returns.description)
    print('-'*50)
    print("Test 2 parse function: ")
    print("Summary:", docstring.summary)

# Generated at 2022-06-11 21:31:45.391339
# Unit test for function parse
def test_parse():
    # test for docstring parser
    from docstring_parser.styles import Style
    a = """\
        Computes the accuracy, a metric for multi-label classification of
        how many selected items are relevant.

        :param y_true: 2d numpy array.
                     Ground truth (correct) labels.
        :param y_pred: 2d numpy array.
                     Predicted labels, as returned by a classifier.
        :param k: Integer, number of top elements to consider as correct.
        """
    a = parse(a, Style.google)
    print(a)
    print(a.args)

# Generated at 2022-06-11 21:31:56.065230
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

# Generated at 2022-06-11 21:32:00.537614
# Unit test for function parse
def test_parse():
    print(parse(1))
    print(parse('a'))
    print(parse('b'))
    print(parse(style='a'))

test_parse()

# Generated at 2022-06-11 21:32:08.790499
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", body="", meta={})
    assert parse("hello world") == Docstring(summary="hello world", body="", meta={})
    assert parse("hello world\n\ngoodbye world") == Docstring(summary="hello world", body="goodbye world", meta={})

    assert parse("{} hello world {}", 'google') == Docstring(summary="hello world", body="", meta={})
    assert parse("hello world\n\n{}: goodbye world", 'google') == Docstring(summary="hello world", body="goodbye world", meta={"": "goodbye world"})
    assert parse("hello world\n\n:param foo: description", 'google') == Docstring(summary="hello world", body="", meta={"param": {"foo": "description"}})


# Generated at 2022-06-11 21:32:16.056424
# Unit test for function parse
def test_parse():
    assert parse('Simple one line docstring') == Docstring(
        summary='Simple one line docstring',
        description='',
        meta={},
        style=Style.google
    )
    assert parse('Simple one line docstring\n\nwith multiline description') == Docstring(
        summary='Simple one line docstring',
        description='with multiline description',
        meta={},
        style=Style.google
    )

# Generated at 2022-06-11 21:32:21.954402
# Unit test for function parse
def test_parse():
    """Test parse function."""
    from docstring_parser.tests.test_numpy import EXAMPLE_1
    from docstring_parser.tests.test_google import EXAMPLE_2
    from docstring_parser.tests.test_github import EXAMPLE_3
    from docstring_parser.tests.test_numpy import EXAMPLE_4
    #from docstring_parser.tests.test_sphinx import EXAMPLE_5
    #from docstring_parser.tests.test_sphinx import EXAMPLE_6
    #from docstring_parser.tests.test_numpy import EXAMPLE_7

    parsed = parse(EXAMPLE_1)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description.\n\nWith multiple paragraphs."

# Generated at 2022-06-11 21:32:29.591127
# Unit test for function parse
def test_parse():
    docstring = """
    One-line short summary.

    Extended description.

    :param x: Parameter x
    :type x: int
    :param y: Parameter y
    :type y: int
    :returns: Return value
    :rtype: int
    """
    print("d.short_description=",parse(docstring))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:38.918500
# Unit test for function parse

# Generated at 2022-06-11 21:32:48.400162
# Unit test for function parse
def test_parse():
    import docstring_parser.tests as tests
    def parse(text):
        return docstring_parser.parse(text)

    def check_parse(text, expect_meta=None, expect_short_desc=None, expect_long_desc=None, expect_extras=None):
        ret = parse(text)
        for k, v in (('meta', expect_meta), ('short_desc', expect_short_desc), ('long_desc', expect_long_desc), ('extras', expect_extras)):
            if v is not None:
                assert getattr(ret, k) == v, (k, v)
        return ret

    def check_exact_parse(text, expect):
        ret = parse(text)
        assert ret.meta == expect.meta
        assert ret.short_desc == expect.short_desc


# Generated at 2022-06-11 21:32:56.908645
# Unit test for function parse
def test_parse():
    docstring = """
    This is a sample function.

    :param arg1: The first argument.
    :param arg2: The second argument, it's an array.
    :returns: description of what is returned
    :raises keyError: raises an exception
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a sample function."
    assert parsed.long_description == ""
    assert parsed.meta["returns"] == "description of what is returned"
    assert parsed.meta["raises"][0] == "keyError: raises an exception"



# Generated at 2022-06-11 21:33:11.426368
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""


# Generated at 2022-06-11 21:33:24.380658
# Unit test for function parse
def test_parse():

    # Test a regular docstring
    text = '''\
    This module provides regular expression matching operations similar to
    those found in Perl.

    Both patterns and strings to be searched can be Unicode strings (str) as
    well as 8-bit strings (bytes).

    However, Unicode strings and 8-bit strings cannot be mixed: that is, you
    cannot match a Unicode string with a byte pattern or vice-versa; similarly,
    when asking for a substitution, the replacement string must be of the same
    type as both the pattern and the search string.
    '''

    docstring = parse(text)
    assert docstring.short_description == 'This module provides regular expression matching operations similar to\nthose found in Perl.'

# Generated at 2022-06-11 21:33:34.734865
# Unit test for function parse
def test_parse():
    from docstring_parser.models import Arg, Return
    doc = """one line summary

    more detailed summary

    Args:
        arg1 (int): the first arg
        arg2 (str): the second arg
        arg3 (str):
            the third arg

    Returns:
        bool: the return value

    """
    docstring = parse(doc)
    assert len(docstring.meta) == 2
    assert docstring.summary == 'one line summary'
    assert docstring.body == 'more detailed summary'
    assert docstring.args == Params([Arg(arg='arg1', type='int', desc='the first arg'),
                                     Arg(arg='arg2', type='str', desc='the second arg'),
                                     Arg(arg='arg3', type='str', desc='the third arg')])

# Generated at 2022-06-11 21:33:44.724667
# Unit test for function parse
def test_parse():
    text = '''\
:param int a: this is int a
'''
    docstring = parse(text, Style.numpy)
    assert docstring.meta['parameters']['a']['type'] == 'int'
    assert docstring.meta['parameters']['a']['description'] == 'this is int a'
    text = '''\
:param a: this is int a
'''
    docstring = parse(text, Style.numpy)
    assert docstring.meta['parameters']['a']['type'] == ''
    assert docstring.meta['parameters']['a']['description'] == 'this is int a'


# Generated at 2022-06-11 21:33:55.881206
# Unit test for function parse
def test_parse():
    text = """A Docstring Parser.

This module exports a single function, `parse`, which will parse a
docstring into its various parts.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation

"""
    test = """This is a long docstring with a lot of content.

It should parse all the available fields.

:param i: integer
:type  i: int
:returns: integer incremented by one
:rtype: int
"""
    try:
        parsed_test = parse(test)
    except ParseError as e:
        print("Exception occurred: ", e)
        return
    for key, value in parsed_test.items():
        print(key, ":", value)
    parsed_text = parse(text)

# Generated at 2022-06-11 21:33:58.722157
# Unit test for function parse
def test_parse():
    text = '''
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    parse(text)


# Generated at 2022-06-11 21:34:04.947595
# Unit test for function parse
def test_parse():
    docstring = '''\
    One-line short summary

    More detailed description (with some reStructuredText).

    :param str foo: Description of foo.
    :param dict bar: Description of bar.
    :type bar: dict
    :returns: Description of return value.
    :rtype: int
    :raises ValueError: Description of exception.
    '''
    ret = parse(docstring)
    assert ret.short_description == 'One-line short summary'
    assert ret.long_description == (
        'More detailed description (with some reStructuredText).')

# Generated at 2022-06-11 21:34:07.755130
# Unit test for function parse
def test_parse():
    text = """
Args:
    arg1: arg1 type
"""
    docstring = parse(text)
    assert docstring.args['arg1'] == 'arg1 type'


# Generated at 2022-06-11 21:34:16.845589
# Unit test for function parse
def test_parse():
    text = """Given the inputs, x, y and z, this function computes
    ... something.
    ...
    ... Args:
        x (int): first variable.
        y (str): second variable.
        z (bool): third variable.
    ...
    ... Returns:
        bool: Output of the function.
    ...
    ... Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    ...
    ... """
    doc = parse(text)
    assert doc.summary == 'Given the inputs, x, y and z, this function computes'
    assert doc.extended_summary == 'something.'
    assert len(doc.params) == 3

# Generated at 2022-06-11 21:34:25.070159
# Unit test for function parse
def test_parse():
    text = """One-line summary
    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    dict
        Description of return value
    """

# Generated at 2022-06-11 21:34:33.948449
# Unit test for function parse
def test_parse():
    text = '''
    Wraps a string in quotes

    :param str x: the string to be wrapped
    :returns: the wrapped string

    Example::
       >>> from parse import parse
       >>> parse('hello world')
       'hello world'
    '''

    ret = parse(text)
    print('parameters:', ret.parameters)
    print('returns:', ret.returns)
    print('raises:', ret.raises)
    print('yields:', ret.yields)
    print('meta:', ret.meta)

# Generated at 2022-06-11 21:34:36.199660
# Unit test for function parse
def test_parse():
    assert parse("Hello World") == parse("Hello World", style=Style.google)

# Generated at 2022-06-11 21:34:45.010892
# Unit test for function parse
def test_parse():
    test_text = '''\
This is a test docstring
=========================

This is a test docstring.

:Author:
    Name <email>
:Date:
    4/4/2020
:Input:
    * f1:
        variable.
    * f2:
        variable.
:Returns:
    * f1:
        variable.
    * f2:
        variable.
'''
    parsed_docstring = parse(test_text)
    assert parsed_docstring.summary == 'This is a test docstring'
    assert parsed_docstring.long_description == 'This is a test docstring.'


# Generated at 2022-06-11 21:34:47.429598
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError

    docstring = Docstring()
    assert type(parse(docstring)) is Docstring

# Generated at 2022-06-11 21:34:56.119560
# Unit test for function parse
def test_parse():
    text = '''\
    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat.
    '''
    docstring = parse(text)
    assert docstring.summary == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed'
    assert docstring.description == text
    assert docstring.meta == {}

# Generated at 2022-06-11 21:35:03.988242
# Unit test for function parse
def test_parse():

    text = """A one-line summary that does not use variable names or the function name.

Several sentences providing an extended description. Refer to
variables using back-ticks, e.g. `var`.

:param str filename: The filename to save the data to
:param int nrows: The number of rows to select
:param open file handle_: This can be an actual file handle or something like a network connection.
:param str *args: Variable length argument list.
:returns int: Count of the number of rows with the new data.
:raises: An error occurred accessing the bigtable.Table object.
"""

    docstring = parse(text, style=Style.numpy)
    assert docstring.short_description == 'A one-line summary that does not use variable names or the function name.'

# Generated at 2022-06-11 21:35:09.304047
# Unit test for function parse
def test_parse():
    if __name__ == "__main__":
        def foo(a, b):
            """Hey there.

            Args:
                a (int): foo
                b (str): bar

            Returns:
                int: baz
            """
            pass
        print(parse(foo.__doc__))


# Generated at 2022-06-11 21:35:20.181686
# Unit test for function parse

# Generated at 2022-06-11 21:35:26.380610
# Unit test for function parse
def test_parse():
    doctext = '''
This is an example for unit testing
:param str a: This is a parameter with name a
:param str b: This is a parameter with name b
:returns: int -- The return values of a and b
:raises KeyError: raises an exception
    '''
    print(parse(doctext))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:35:36.767022
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    docstring_with_meta = """Summary line.

Extended description.

:param arg1: Description of `arg1`
:param arg2: Description of `arg2`
:returns: Description of return value
:raises keyError: raises an exception
"""

    result = parse(docstring_with_meta)

    assert len(result.meta) == 4
    assert len(result.params) == 2
    assert len(result.returns) == 1
    assert result.returns[0].arg_name == "returns"
    assert result.returns[0].arg_type == None
    assert len(result.raises) == 1
    assert result.raises[0].arg_name == "raises"

# Generated at 2022-06-11 21:35:46.396800
# Unit test for function parse
def test_parse():
    text = """
        lorem ipsum

        :param int x: this is x
        :param int y: this is y

        :rtype: bool
        """
    docstring = parse(text)
    assert len(docstring.sections) == 2
    assert len(docstring.meta) == 2
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert docstring.sections[0].text == 'lorem ipsum'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:47.805972
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring(lines=[], meta={})



# Generated at 2022-06-11 21:35:49.603368
# Unit test for function parse
def test_parse():
    text = """bla bla bla"""
    d = parse(text)
    assert d.content == text

# Generated at 2022-06-11 21:35:57.425872
# Unit test for function parse
def test_parse():
    style = Style.numpy
    text = '''
    This is a test module
    '''
    style = Style.auto
    doc = parse(text, style)
    assert doc.short_description == 'This is a test module'
    assert doc.summary == 'This is a test module'
    doc.short_description = 'This is a short_description'
    assert doc.short_description != 'This is a test module'
    assert doc.short_description == 'This is a short_description'

# Generated at 2022-06-11 21:36:02.135376
# Unit test for function parse
def test_parse():
    actual = parse.__doc__
    expected = '''Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    assert actual == expected

# Generated at 2022-06-11 21:36:05.601490
# Unit test for function parse
def test_parse():
    from . import common
    import unittest

    class TestParse(unittest.TestCase):
        def test_parse(self):
            docstring = common.MULTI_LINE
            self.assertEqual(
                parse(docstring, Style.numpy),
                common.parse_numpy(docstring),
            )

    unittest.main()

# Generated at 2022-06-11 21:36:15.656201
# Unit test for function parse