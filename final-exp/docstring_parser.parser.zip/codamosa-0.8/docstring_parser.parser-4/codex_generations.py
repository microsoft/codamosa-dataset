

# Generated at 2022-06-11 21:26:25.571857
# Unit test for function parse
def test_parse():
    """Unit tests for function 'parse'."""
    #test standard docstring
    text = '''Single line summary
    Extended description

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    None
        Description of return value

    '''
    result = parse(text)

# Generated at 2022-06-11 21:26:29.819598
# Unit test for function parse
def test_parse():
    # assert parse(test_doc1) is not None
    assert parse(test_doc1) is not None

if __name__ == "__main__":
    # test_parse()
    pass

# Generated at 2022-06-11 21:26:32.725875
# Unit test for function parse
def test_parse():
    d = parse("""
    Arguments:
        param1 -- the first parameter
        param2 -- the second parameter
    """)
    assert isinstance(d, Docstring)
    assert d.short_description == ''

# Generated at 2022-06-11 21:26:35.478907
# Unit test for function parse
def test_parse():
    result = parse.__doc__
    #print(result)
    assert result == """Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation"""


# Generated at 2022-06-11 21:26:45.872629
# Unit test for function parse
def test_parse():
    test_docstring = """
    Summary line.

    Extended description of function.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: Raises an exception.
    """
    result = parse(test_docstring)
    expected_result = Docstring(
        'Summary line.',
        'Extended description of function.',
        [
            {'arg1': 'The first argument.', 'arg2': 'The second argument.'},
            {'returns': 'Description of return value.'},
            {'raises keyError': 'Raises an exception.'}
         ]
    )
    assert result == expected_result


# Unit test to check if function parse is raising a ParseError exception

# Generated at 2022-06-11 21:26:50.670016
# Unit test for function parse
def test_parse():
    text = """One line summary."""
    result = parse(text)
    assert result.short_description == 'One line summary.'


text = """
One line summary.

Extended description.

"""
result = parse(text)



# Generated at 2022-06-11 21:26:59.231430
# Unit test for function parse
def test_parse():
    # Test parsing of Google style docstring
    doc = parse("""This function does something.
                   It takes one argument, which is a number.""")
    assert doc.short_description == "This function does something."
    assert doc.long_description == "It takes one argument, which is a number."
    # Test parsing of Numpy style docstring
    doc = parse("""This function does something.

                   Parameters
                   ----------
                   arg : int
                       An integer.

                   Returns
                   -------
                   int
                       The same integer.""", style=Style.numpy)
    assert doc.short_description == "This function does something."
    assert doc.long_description == ""
    assert doc.meta["Parameters"][0].arg_name == "arg"
    assert doc.meta["Parameters"][0].type_name == "int"
    assert doc

# Generated at 2022-06-11 21:27:10.352385
# Unit test for function parse
def test_parse():
    text = '''This is an advanced sample docstring.

:param path: path to the file
:param mode: file open mode
:returns: file's content
:raises OSError: if file was not found
:raises ValueError: if open mode is unknown
'''
    docstring = parse(text)['meta']
    assert len(docstring) == 4
    assert docstring[0] == 'param path: path to the file'
    assert docstring[1] == 'param mode: file open mode'
    assert docstring[2] == "returns: file's content"
    assert docstring[3] == 'raises OSError: if file was not found'


# Generated at 2022-06-11 21:27:11.875339
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:27:22.375467
# Unit test for function parse

# Generated at 2022-06-11 21:27:30.252031
# Unit test for function parse
def test_parse():
    doc = """
    Some description.

    :param foo_bar: the foo bar
    :returns: the return value
    :raises ValueError: if foo
    """
    assert parse(doc).params == {'foo_bar': {'type': '', 'desc': 'the foo bar'}}


# Generated at 2022-06-11 21:27:32.512153
# Unit test for function parse
def test_parse():
    pass
    #assert parse("") == []

# Generated at 2022-06-11 21:27:42.543810
# Unit test for function parse
def test_parse():
    class Docstring:
        def __init__(self):
            self.short_description = "This is a docstring"
            self.long_description = "This is the long description"
            self.meta = {'a': 'b'}
            self.parameters = [{'name': 'arg1', 'description': 'arg1 desc', 'type': 'int'}, {'name': 'arg2', 'description': 'arg2 desc', 'type': 'float'}]

    def func_parse_test1(text: str, style: Style = Style.auto) -> Docstring:
        return Docstring()

    def func_parse_test2(text: str, style: Style = Style.auto) -> Docstring:
        return Docstring()

    parse_return = parse("This is a docstring")

# Generated at 2022-06-11 21:27:46.258527
# Unit test for function parse
def test_parse():
    text = """0.1a 1
0.1a 2


0.1a 3

0.1a 4"""
    print(parse(text=text, style=Style.numpy))


# Generated at 2022-06-11 21:27:50.119563
# Unit test for function parse
def test_parse():
    test_text = """This is a test docstring.
    And it has some tests to perform.
    """
    assert parse(test_text).body == "This is a test docstring.\nAnd it has some tests to perform.\n"

# Generated at 2022-06-11 21:28:00.278416
# Unit test for function parse
def test_parse():
    from .parser_numpy import parse as np_parse
    from .parser_google import parse as google_parse

    docstring = '''
    Section
    -------
        is here
    '''
    assert parse(docstring).sections[0].name == 'Section'
    assert parse(docstring).sections[0].content.splitlines()[0].strip() == 'is here'
    assert np_parse(docstring).sections[0].name == 'Section'
    assert np_parse(docstring).sections[0].content.splitlines()[0].strip() == 'is here'
    assert google_parse(docstring).sections[0].name == 'Section'
    assert google_parse(docstring).sections[0].content.splitlines()[0].strip() == 'is here'


# Generated at 2022-06-11 21:28:08.913952
# Unit test for function parse
def test_parse():
    """ Unit test for function parse """
    import textwrap
    text = textwrap.dedent("""
    This function does something.

    :param foo: The first parameter.
    :param bar: The second parameter.
    :returns: Nothing.
    :raises Exception: if something bad happens.

    """)
    ret = parse(text)
    assert ret == Docstring(
        content='This function does something.\n',
        short_description='This function does something.',
        long_description='',
        returns=None,
        raises=('Exception', 'if something bad happens.'),
        meta={
            'param': [
                ('foo', 'The first parameter.'),
                ('bar', 'The second parameter.')
            ]
        }
    )




# Generated at 2022-06-11 21:28:10.742578
# Unit test for function parse
def test_parse():
    text = "This is a test\n"
    style =  Style.auto
    parse(text, style)


# Generated at 2022-06-11 21:28:21.523548
# Unit test for function parse
def test_parse():
    d = parse('''
    Some function

    :param arg: arg
    :returns:
        desc: obj

    The long description.
    ''')
    assert str(d) == '''
    Some function

    :param arg: arg
    :returns:
        desc: obj

    The long description.
    '''
    d = parse('''
    Some function

    :arg arg: arg
    :returns obj: desc
    :raises TypeError: if bad things happen
    ''')
    assert str(d) == '''
    Some function

    :arg arg: arg
    :returns obj: desc
    :raises TypeError: if bad things happen
    '''

# Generated at 2022-06-11 21:28:29.916391
# Unit test for function parse
def test_parse():
    print("\nUnit test for function parse")
    from docstring_parser.common import Docstring
    from docstring_parser.styles import STYLES, Style
    docstring ="""
    This function is used to parse the docstring in the function
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    print("Input docstring: \n", docstring)
    print("Output docstring: \n", parse(docstring))

# test_parse()



# Generated at 2022-06-11 21:28:39.808273
# Unit test for function parse
def test_parse():
    text = """
"""
    docstring = parse(text)
    assert(docstring is None)

    text = """
Docstring Parser.

This is the docstring parsing module.
"""
    docstring = parse(text)
    assert(docstring is not None)


# Generated at 2022-06-11 21:28:42.907743
# Unit test for function parse
def test_parse():
    text = """
    This is a unit test for function parse.

    :returns: value 1
    """
    docstring = parse(text)
    assert docstring.summary == "This is a unit test for function parse."
    assert docstring.meta["returns"] == "value 1"

# Generated at 2022-06-11 21:28:53.930339
# Unit test for function parse
def test_parse():
    print ('Test parse function in parser.py')
    p = parse.__doc__    
    test_input    = "This is test input"
    test_style    = Style.pep257
    test_expect_style = "PEP257"
    test_style    = Style.google
    test_expect_style = "Google"
    test_style    = Style.numpy
    test_expect_style = "Numpydoc"
    test_style    = Style.auto
    test_expect_style = "PEP257"

    test_result_style = str(parse(test_input, test_style))
    print (str(test_result_style))
    if test_expect_style == str(test_result_style):
        print ('Test result - PASS')

# Generated at 2022-06-11 21:29:01.103831
# Unit test for function parse
def test_parse():
    text = '''
        This is a summary.

        Args:
            a: type a
            b: type b
        Return:
            return value
        '''
    p = parse(text)
    assert p.short_description == 'This is a summary.'
    assert p.long_description == ''
    assert len(p.fields) == 3
    assert p.fields[2].name == 'Return'
    assert p.fields[2].type == ''
    assert p.fields[2].description == 'return value'


if __name__ == '__main__':
    test_parse()
    print('Test passed!')

# Generated at 2022-06-11 21:29:11.512244
# Unit test for function parse
def test_parse():
    test_str = "A tested string"
    assert parse(test_str) == parse(test_str, Style.numpy)
    assert parse(test_str) == parse(test_str, Style.google)
    assert parse(test_str).description == test_str


if __name__ == "__main__":
    import os
    import sys
    import unittest

    sys.path.insert(0, os.path.abspath('..'))
    from docstring_parser import parse

    class TestParse(unittest.TestCase):
        def test_parse(self):
            test_str = "A tested string"
            self.assertEquals(parse(test_str), parse(test_str, Style.numpy))

# Generated at 2022-06-11 21:29:14.500163
# Unit test for function parse
def test_parse():
    docstring = '''function add
    # this is a function
    # add two numbers
    a: int
    b: int
    -> int
    '''
    parsed_docstring = parse(docstring)
    assert type(parsed_docstring) == Docstring

# Generated at 2022-06-11 21:29:27.823284
# Unit test for function parse
def test_parse():
    # Test for auto style
    text = '''
    :param param1: this is a short description
    :param param2: this is a longer
        multiline description
    :param param3: this is a short description
    '''
    d = parse(text)
    assert len(d.meta) == 3
    assert d.short_description == ''
    assert d.long_description == ''

    # Test for numpy style
    text = '''
    This is a multiline short description.
    This line is part of the same description.

    And this is a multiline long description.
    The short description consists of two paragraphs.
    The long description consists of two paragraphs.
    '''
    d = parse(text, Style.numpy)
    assert len(d.meta) == 0
    assert d.short_

# Generated at 2022-06-11 21:29:29.138380
# Unit test for function parse
def test_parse():
    assert type(parse('text')) == type(Docstring())

# Generated at 2022-06-11 21:29:38.288625
# Unit test for function parse
def test_parse():
    docstring = """This is a test.
    This is a test.

    :param test: test test
    :type test: str
    :returns: None
    :raises keyError: raises an exception
    """

    result = parse(docstring)
    assert(str(result.short_description) == "This is a test.\n    This is a test.")
    assert(str(result.long_description) == "")
    assert(str(result.meta.params['test']) == "test test")
    assert(str(result.meta.returns) == "None")
    assert(str(result.meta.raises['keyError']) == "raises an exception")

# Generated at 2022-06-11 21:29:50.638115
# Unit test for function parse
def test_parse():
    test_string1 = '''
    This is a test
    :first:
    :second: test2
    :third: test3
    '''
    test_string2 = '''
    This is a test
    :first:
    :second: test2
    :third: test3
    '''

    test_string2 = ">>> parse(test_string1)\n<docstring_parser.docstring.Docstring object at 0x000001DC1C8B7A20>"
    test_string3 = ">>> parse(test_string2)\n<docstring_parser.docstring.Docstring object at 0x000001DC1C8B7A20>"

    if test_string2 == test_string3:
        print("The two test strings are the same")

# Generated at 2022-06-11 21:29:57.679986
# Unit test for function parse
def test_parse():
    class_docstring = """A class docstring"""
    def_docstring = """A function docstring"""
    assert parse(class_docstring) == parse(class_docstring, Style.google)
    assert parse(def_docstring) == parse(def_docstring, Style.google)

# Generated at 2022-06-11 21:30:08.519720
# Unit test for function parse

# Generated at 2022-06-11 21:30:18.619578
# Unit test for function parse
def test_parse():
    text = '''Client library for the Capi API.

The required API key can be provided as an argument to the client
constructor.  Alternatively, it is recommended to set it as an
environment variable named CAPICLI_API_KEY.

The following examples are equivalent:

  $ export CAPICLI_API_KEY=12345
  $ python capicli.py ...

  from capicli import Client
  client = Client(api_key='12345')
'''

# Generated at 2022-06-11 21:30:25.701391
# Unit test for function parse
def test_parse():
    d= parse("""\
This method aborts the current operation.

:param str message: a message to display
:returns: None


.. versionchanged:: 1.1.0
    This is a breaking
    change.
""")
    print(d.short_description)
    print(d.long_description)
    print(d.meta)
    #print(d.meta.get('rtype', None))
    for key,value in d.meta.items():
        print(key,value)
    return


# Generated at 2022-06-11 21:30:26.820457
# Unit test for function parse
def test_parse():
    assert parse('something') == parse('something', Style.numpy)

# Generated at 2022-06-11 21:30:35.925402
# Unit test for function parse
def test_parse():
    """Tests the parse function which will take a docstring and return
    a Docstring instance
    """
    from os import path

    # Getting the example docstring
    filepath = path.join(path.dirname(__file__), "example.txt")
    with open(filepath, encoding="utf-8") as f:
        docstring = f.read()

    # Parsing the docstring
    parsed_docstring = parse(docstring)

    # Variable containing the expected output

# Generated at 2022-06-11 21:30:44.654802
# Unit test for function parse
def test_parse():
    text = """
    Multiline docstring.

    Short description.

    Long description.

    :param a:
        Parameter description.

    :return:
        Return description.
    :raises:
        ExceptionA
        ExceptionB
    """
    doc = parse(text, Style.google)
    assert doc.short_description == 'Short description.'
    assert doc.long_description == 'Long description.'
    assert doc.params[0].name == 'a'
    assert doc.params[0].type is None
    assert doc.params[0].desc == 'Parameter description.'
    assert doc.returns.type is None
    assert doc.returns.desc == 'Return description.'
    assert doc.exceptions[0].type == 'ExceptionA'
    assert doc.exceptions[0].desc == ''

# Generated at 2022-06-11 21:30:56.707889
# Unit test for function parse
def test_parse():
    """Test that parse works with both styles."""
    try:
        import numpy

        numpy.__doc__ is not None
        test_numpy = True
    except:
        test_numpy = False

    from .test_numpydoc import parse_numpy_docstring
    from .test_google import parse_google_docstring

    assert parse("""short description

long description

Args:
    foo: description

Returns:
    description
""", Style.numpy) == parse_numpy_docstring("""short description

long description

Args:
    foo: description

Returns:
    description
""")


# Generated at 2022-06-11 21:31:02.192192
# Unit test for function parse
def test_parse():
    text = """
     parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation 

    """
    print(parse(text))

#Code to test the function
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:31:09.860688
# Unit test for function parse
def test_parse():
    text = """
    lorem ipsum dolor
    :param x: the x parameter
    :type x: int
    :returns: None
    """
    parsed = parse(text)
    assert parsed.summary == "lorem ipsum dolor"
    assert parsed.params[0].name == "x"
    assert parsed.params[0].types == "int"
    assert parsed.returns == "None"
    
    text = """
    lorem ipsum dolor
    :parameter x: the x parameter
    :returns: None
    """
    parsed = parse(text, Style.epytext)
    assert parsed.summary == "lorem ipsum dolor"
    assert parsed.params[0].name == "x"
    assert parsed.params[0].types == None

# Generated at 2022-06-11 21:31:15.802231
# Unit test for function parse
def test_parse():
    from docstring_parser.tests.parse_tests import TEST_CASES

    for k, v in TEST_CASES.items():
        assert parse(k).__dict__ == v.__dict__


# Generated at 2022-06-11 21:31:26.540275
# Unit test for function parse
def test_parse():
    """Test for function parse"""

    from docstring_parser import parse
    docstring = parse("""
        A multi
        line docstring.

        :param arg1: the first value
        :param arg2: the first value
        :type arg1: int, str
        :type arg2: str
        :raises keyError: raises an exception
        :returns: None
        :rtype: int
        """)
    assert (docstring.short_description == 'A multi\nline docstring.')
    assert (docstring.long_description == None)
    param_keys = [p.arg_name for p in docstring.params]
    assert ('arg1' in param_keys)
    assert ('arg2' in param_keys)
    assert (docstring.returns.description == 'None')

# Generated at 2022-06-11 21:31:37.038238
# Unit test for function parse
def test_parse():
    doc = "Title\n\nThis is a summary.  And a second sentence."
    result = parse(doc, style=Style.google)
    assert result.title == 'Title'
    assert result.summary == 'This is a summary.'
    assert result.extended_summary == 'And a second sentence.'
    
    doc = '''
    A short summary.

    And an extended summary.

    Parameters
    ----------
    arg : int
        Description of `arg`.
    arg2 : str
        Description of `arg2`, which continues here.

    Returns
    -------
    str
        Description of return value.
    '''
    result = parse(doc, style=Style.numpy)
    assert len(result.params) == 2
    assert result.params['arg'].description == 'Description of `arg`.'

# Generated at 2022-06-11 21:31:46.994707
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    docstring = '''\
        One line summary.

        Extended description.

        Args:
            param1: Description of `param1`.
            param2: Description of `param2` on multiple lines.

                with indented text.

        Returns:
            Description of return value.
        '''
    doc = parse(docstring)
    assert doc.summary == 'One line summary.'
    assert doc.description == 'Extended description.'
    assert doc.params[0].name == 'param1'
    assert doc.params[1].name == 'param2'
    assert doc.returns.description == 'Description of return value.'
    assert doc.extras['Args']
    assert doc.extras['Returns']


# Generated at 2022-06-11 21:31:56.936964
# Unit test for function parse
def test_parse():
    key = 'parse'
    input_text = 'parse(text: str, style: Style = Style.auto) -> Docstring'
    input_style = 'style'
    output_style = 'style'
    output = 'docstring_parser.parse(text=input_text, style=Style.input_style)'

    assert key in globals(), f'Function {key} is not defined'
    assert callable(globals()[key]), f'Function {key} is not callable'

    # get the function from globals
    func = globals()[key]
    # prepare the input arguments
    args = [input_text, input_style]
    # use * operator to unpack the list
    assert func(*args) == output, f'Function {key} does not work properly'

    # Now add optiona args and test


# Generated at 2022-06-11 21:32:07.940942
# Unit test for function parse
def test_parse():
    doc_str = parse("""
        This is the main docstring.

        :param name: the name of the file, string
        :type name: str
        :param is_new: whether or not the file is new, boolean
        :type is_new: bool
        :param errors: errors to report, list
        :type errors: list
        :param warnings: warnings to report, list
        :type warnings: list
        :returns: a dict holding the file's name, file ID, number of errors,
                  number of warnings, and the boolean that specifies whether or
                  not the file is new
        :rtype: dict
        """)
    assert len(doc_str.params) == 4
    assert doc_str.returns
    assert len(doc_str.returns.params) == 5


# Generated at 2022-06-11 21:32:16.716509
# Unit test for function parse
def test_parse():
    assert parse.__doc__.count('\n') == 6
    docstring = \
    '''
    Main function

    Args:
        var1: Variable 1
        var2: Variable 2

    Returns:
        var1 + var2
    '''

# Generated at 2022-06-11 21:32:19.466630
# Unit test for function parse
def test_parse():
    assert parse("123456").full == "123456"
    assert parse("123456").short == "123456"
    assert parse("123456").long == "123456"
    assert parse("123456").signature == ""
    assert all([not parse("123456").meta[x] for x in ['params', 'returns', 'raises']])

# Generated at 2022-06-11 21:32:31.379017
# Unit test for function parse
def test_parse():
    test_doc = '''Example docstring.
    :param a: parameter a
    :param b: parameter b
    :returns: description of return value
    '''
    assert parse(test_doc) == Docstring.parse(test_doc)
    assert parse(test_doc, style=Style.numpy) == parse(test_doc, style=Style.numpy)
    assert parse(test_doc, style=Style.numpy) != parse(test_doc, style=Style.sphinx)
    assert parse(test_doc, style=Style.sphinx) != parse(test_doc, style=Style.google)
    assert parse(test_doc, style=Style.sphinx) == parse(test_doc, style=Style.sphinx)

# Generated at 2022-06-11 21:32:35.574571
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    text = """\
    test_parse
    ----------
    This is a test case
    """

    # parse docstring
    docstring = parse(text)
    # validate parsing
    assert docstring.short_description == 'test_parse'
    assert docstring.long_description == 'This is a test case'

# Generated at 2022-06-11 21:32:39.800102
# Unit test for function parse
def test_parse():
    assert parse('', 'auto') == None
    assert parse('', 'google') == None
    assert parse('', 'numpy') == None

# Generated at 2022-06-11 21:32:48.840641
# Unit test for function parse
def test_parse():
    doc = parse('''
    test documentation
    ''')
    assert doc.short_description == 'test documentation'

    doc = parse('''
    test documentation
    ''')
    assert doc.long_description == None

    doc = parse('''
    test documentation
    :param param: test param
    ''')
    assert doc.params['param'].description == 'test param'
    assert doc.short_description == 'test documentation'

    doc = parse('''
    test documentation
    :param param: test param
    :returns: this is a return
    ''')
    assert doc.params['param'].description == 'test param'
    assert doc.returns.description == 'this is a return'
    assert doc.short_description == 'test documentation'


# Generated at 2022-06-11 21:32:54.573123
# Unit test for function parse
def test_parse():
    text = """
    This is an example

    :param x: a parameter
    :param y: another parameter
    """
    result = parse(text, Style.google)
    assert result.description == "This is an example"
    assert result.params == {
            "x": "a parameter",
            "y": "another parameter"
        }


# Generated at 2022-06-11 21:32:56.601384
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 21:33:02.217346
# Unit test for function parse
def test_parse():
    test_docstring = """Hello world
    :param str test_param_1: test param 1
    :param str test_param_2: test param 2
    """
    doc = parse(test_docstring)
    assert doc.short_description == "Hello world"
    assert doc.params[0][0] == "test_param_1"
    assert doc.params[0][1] == "test param 1"
    assert doc.params[1][0] == "test_param_2"
    assert doc.params[1][1] == "test param 2"


# Generated at 2022-06-11 21:33:13.512596
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError, MultiSection
    from docstring_parser.styles.pep257 import PEP257
    from docstring_parser.styles.other import GOOGLE

    # PEP257 docstring
    text = """
        summary line

        extended description

        :param p: first parameter
        :type p: str
        :param q: second parameter
        :type q: bool
        :return: None
        :rtype: None
        :raises keyError: raises an exception
        :raises ImportError: if failed to import
        """
    parsed = PEP257(text)
    assert parsed == parse(text)
    assert parsed == parse(text, style=Style.pep257)

    # non-PEP257 docstring

# Generated at 2022-06-11 21:33:25.646595
# Unit test for function parse
def test_parse():
    text = '''
    :summary: This is the summary line.

    Kwargs:
        foo (str): This is foo.
        foo_bar (int): This is foo_bar.
        bar (Bar): This is bar.

    Returns:
        str: This is return value.
    '''

    # text = '''
    # :Summary[text/plain]: this is a 
    #     summary
    # :Args: 
    #     arg1 (str): this is arg1
    #     
    #     arg2 (int): this is arg2
    # :Returns:
    #     (int): the return value
    # '''

    docstring = parse(text)
    # print(docstring)
    assert docstring.summary == "This is the summary line."

# Generated at 2022-06-11 21:33:26.919828
# Unit test for function parse
def test_parse():
    assert parse('hello world') == Docstring('hello world', [], [])

# Generated at 2022-06-11 21:33:34.153929
# Unit test for function parse
def test_parse():
    docstring = """This is a test docstring.

:param param_one: The first parameter
:param param_two: The second parameter
:returns: None
"""
    ds = parse(docstring)
    assert ds.short_description == "This is a test docstring."
    assert ds.long_description == ""
    assert ds.params[0].arg_name == "param_one"
    assert ds.params[0].description == "The first parameter"
    assert ds.params[1].arg_name == "param_two"
    assert ds.params[1].description == "The second parameter"
    assert ds.returns.description == "None"
    # Test for Sphinx style function

# Generated at 2022-06-11 21:33:44.974487
# Unit test for function parse
def test_parse():
    """Basic test for parse"""

    result = parse(text = """
    Args:
      input_file: The path to the image file to be processed.
      out_dir: Optional path to the directory in which to place the output files.
    Returns:
      Write the created PNG files to the specified directory.
    """)
    assert result.summary == ""
    assert result.extended_summary == ""

    result = parse(text = """
    Args:
      input_file: The path to the image file to be processed.
      out_dir: Optional path to the directory in which to place the output files.
    Returns:
      Write the created PNG files to the specified directory.
    """)

    assert result.summary == ""
    assert result.extended_summary == ""

# Generated at 2022-06-11 21:33:57.488891
# Unit test for function parse
def test_parse():
    docstring = parse(
        'Test function for autogenerated docstring\n'
        '\n'
        'Args:\n'
        '    param1 (str): The first parameter.\n'
        '    param2 (str): The second parameter.\n'
    )
    assert docstring.summary == 'Test function for autogenerated docstring'
    assert docstring.description == None
    assert len(docstring.args) == 2
    assert docstring.args[0].arg_name == 'param1'
    assert docstring.args[0].type_name == 'str'
    assert docstring.args[0].description == 'The first parameter.'
    assert docstring.args[1].arg_name == 'param2'
    assert docstring.args[1].type_name == 'str'

# Generated at 2022-06-11 21:34:08.144814
# Unit test for function parse
def test_parse():
    assert parse("") == \
        Docstring(
            summary='',
            description='',
            return_annotation='',
            examples=None,
            yield_annotation='',
            raises=[],
            parameters=[],
            meta={},
            raises_exception=False,
            return_type=False,
            yield_type=False,
            is_class=False,
            is_function=False,
        )

# Generated at 2022-06-11 21:34:19.664710
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    # test parse() on a simple docstring
    text = """\
    A short summary

    This is a longer description.

    :param param1: Description of the first parameter
    :type param1: str
    :param param2: Description of the second parameter
    :type param2: int
    :returns: Description of the return value
    :rtype: str
    """

    doc = parse(text)

    assert doc.short_description == "A short summary"
    assert doc.long_description == """\
This is a longer description.
"""
    assert len(doc.params) == 2
    assert len(doc.returns) == 1

    assert doc.params['param1'].arg_name == 'param1'

# Generated at 2022-06-11 21:34:28.714596
# Unit test for function parse
def test_parse():
    text = """This is a summary
        This is a description.
        
        This is a description too.
        
        Here is the example:
        
        >>> print(hello)
        world
        
        Note:
        
        Also this is a note.
        
        And this is another one.
        
        Warning:
        
        Be careful!
        
        This is a warning.
        
        To do:
        
        Fix this!
        
        Also fix this.
        
        This is a to do."""

    if __name__ == '__main__':
        print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:34:36.323281
# Unit test for function parse
def test_parse():
    ds1 = parse('"""this is a docstring"""')
    ds2 = parse('\'\'\'this is a docstring\'\'\'')
    assert ds1 == ds2

    ds3 = parse('"""this is a docstring\nwith multi-lines.\n"""', Style.google)
    ds4 = parse('\'\'\'this is a docstring\nwith multi-lines.\n\'\'\'', Style.google)
    assert ds3 == ds4

    ds5 = parse('"""\nthis is a docstring\nwith multi-lines.\n\nArgs:\n  arg1: first argument\n\nReturns:\n  a string\n"""', Style.numpy)

# Generated at 2022-06-11 21:34:39.330184
# Unit test for function parse
def test_parse():
    doc = """
            This function returns the sum of two integers.

            Args:
                x (int): first number
                y (int): second number

            Returns:
                int: sum of two numbers

            Raises:
                ValueError: first number is negative
            """
    p = parse(doc)
    assert p.short_description == 'This function returns the sum of two integers.'
    assert len(p.long_description) == 0
    assert p.returns.type_name == 'int'
    assert p.returns.desc == 'sum of two numbers'
    assert len(p.exceptions) == 1
    assert len(p.params) == 2

# Generated at 2022-06-11 21:34:48.909603
# Unit test for function parse
def test_parse():
    assert parse("Single line docstring") == Docstring(
        content="Single line docstring",
        meta=[],
        sections=[],
    )

    assert parse("""\
        First line of the docstring.

        The rest of the docstring.
        """) == Docstring(
        content="""\
        First line of the docstring.

        The rest of the docstring.
        """,
        meta=[],
        sections=[],
    )


# Generated at 2022-06-11 21:34:50.223976
# Unit test for function parse
def test_parse():
    """Unit test for function: parse."""
    assert True

# Generated at 2022-06-11 21:34:56.111451
# Unit test for function parse
def test_parse():
    # First test
    text = """
    This is a test.
    
    Parameters:
        x (int): Which thing?
        y (str): Who knows?
    
    Returns:
        bool: The answer.
    """
    pydocstring = parse(text)
    assert pydocstring.short_description == "This is a test."
    assert pydocstring.long_description == ""
    assert pydocstring.returns.empty == False
    assert pydocstring.returns.type_name == "bool"
    assert pydocstring.returns.description == "The answer."
    assert pydocstring.returns.is_type_error == False
    params = pydocstring.params
    assert params[0].name == "x"

# Generated at 2022-06-11 21:35:03.988190
# Unit test for function parse
def test_parse():
    import pytest
    import os
    root_dir = os.path.dirname(os.path.dirname(__file__))
    examples_dir = os.path.join(root_dir, 'examples')
    google_file = os.path.join(examples_dir, 'google_module.py')
    numpy_file = os.path.join(examples_dir, 'numpy_module.py')
    this_file = os.path.join(root_dir, '__init__.py') # This file

    exists = os.path.exists(google_file) and os.path.exists(numpy_file) and os.path.exists(this_file)
    if not exists:
        raise AssertionError('test_parse(): Failed to find a test file.')


# Generated at 2022-06-11 21:35:17.796714
# Unit test for function parse
def test_parse():
    '''Test function parse by comparing with expected output'''
    class_text = """\
    A class.

    Attributes:
        attr1 (str): Description of `attr1`.
        attr2 (:obj:`int`, optional): Description of `attr2`.

    """
    function_text = """\
    A function.

    Args:
        arg1 (:obj:`int`): Description of `arg1`.
        arg2 (:obj:`list` of :obj:`str`): Description of `arg2`.

    Returns:
        :obj:`str`: Description of return value.

    """

# Generated at 2022-06-11 21:35:29.815099
# Unit test for function parse
def test_parse():
    import os

# Generated at 2022-06-11 21:35:32.481636
# Unit test for function parse
def test_parse():

    text = """
    This is a docstring.
    """
    doc = parse(text, style = 'google')

    assert(doc.short_description == 'This is a docstring.')

# Generated at 2022-06-11 21:35:41.865225
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    from docstring_parser.styles import GoogleStyle
    text = 'Summary\n    Long summary\n    \n    Args:\n        abcd (int): Test\n        \n        defg (bool): Test\n    \n    Returns:\n        str: Test'
    docstring = Docstring(summary='Summary', body='Long summary\n', returns=None,
                          raises=None, author='', args=[('abcd', 'Test', 'int'), ('defg', 'Test', 'bool')])
    assert parse(text) == docstring
    assert parse(text, GoogleStyle) == docstring

# Main function to test 
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:45.012522
# Unit test for function parse
def test_parse():
    assert parse("abcd efgh") == parse("abcd efgh", style = Style.auto)
    print("Test passed.")

# test_parse()

# Generated at 2022-06-11 21:35:56.748973
# Unit test for function parse
def test_parse():
    text = ("This is a function.\n"
            "This is a another line.\n"
            "\n"
            "Args:\n"
            "\tparam1: The first parameter.\n"
            "\tparam2: The second parameter.\n"
            "\t\tWith a description too.\n"
            "\n"
            "Returns:\n"
            "\tstr: The return value. True for success, False otherwise.\n")

    docstring = parse(text, style=Style.numpy)

    assert(docstring.short_description == "This is a function.")
    assert(docstring.long_description == "This is a another line.")
    assert(len(docstring.params) == 2)
    assert(docstring.params[0].arg_name == "param1")

# Generated at 2022-06-11 21:35:59.163562
# Unit test for function parse
def test_parse():
    parse("Hello")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:36:06.842388
# Unit test for function parse
def test_parse():
    text = '''"""
    This function parses a docstring into its components.

    Raises:
        ParseError: Thrown when the docstring is not in one of the recognized styles
    """

    '''
    doc = parse(text)
    assert doc.short_description == 'This function parses a docstring into its components.'
    assert doc.params[0].name == 'text'
    assert doc.raises[0].name == 'ParseError'
    assert len(doc.params) == 1
    assert len(doc.raises) == 1


# Generated at 2022-06-11 21:36:11.838822
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    text = """
    Returns:
        dict: A dictionary representing the parsed docstring.
    """

    parsed = parse(text, style=Style.google)
    assert isinstance(parsed, Docstring)
    
    