

# Generated at 2022-06-11 21:26:24.591276
# Unit test for function parse
def test_parse():
    text = '''
    Parameters
    ----------
    a : int
        An integer
    b : list
        A list
    Returns
    -------
    x : int
        A squared integer
    '''
    docstring = parse(text)
    assert docstring.summary == 'Parameters\n----------\na : int\n    An integer\nb : list\n    A list\nReturns\n-------\nx : int\n    A squared integer'
    assert str(docstring) == text
    assert docstring.meta['parameters']['a'].type == 'int'
    assert docstring.meta['parameters']['a'].description == 'An integer'
    assert docstring.meta['parameters']['b'].type == 'list'
    assert docstring.meta['parameters']['b'].description

# Generated at 2022-06-11 21:26:34.388254
# Unit test for function parse
def test_parse():
    print("Testing parse")
    docstring = """\
An example function that uses multiple lines of docstrings.

Example:
    This example will have 2 lines

Args:
    arg1: The first argument.
    arg2: The second argument.

Returns:
    Nothing.
"""
    d = parse(docstring)
    assert '\n'.join(d.short_description) == 'An example function that uses multiple lines of docstrings.'
    assert '\n'.join(d.long_description) == """\
Example:
    This example will have 2 lines"""
    assert len(d.meta) == 3
    assert d.meta['Args'].args == 'arg1, arg2'
    assert d.meta['Args'].meta == {'arg1': 'The first argument.', 'arg2': 'The second argument.'}

# Generated at 2022-06-11 21:26:45.233681
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse
    text = """Summary line.

Extended description.

Args:
    param1: Description of `param1`.
    param2: Description of `param2` on multiple
            lines.

Returns:
    str: Description of return value.
"""
    result = parse(text)
    assert result.short_description == "Summary line."
    assert result.long_description == "Extended description."
    assert result.params == [
        {'name': 'param1',
         'desc': 'Description of `param1`.',
         'type': None,
         'optional': False},
        {'name': 'param2',
         'desc': 'Description of `param2` on multiple lines.',
         'type': None,
         'optional': False},
    ]

# Generated at 2022-06-11 21:26:57.032230
# Unit test for function parse
def test_parse():
    text = '''
        """This is a test docstring.
        
        This is the second line.
        
        Args:
            arg1(int): argument 1
            arg2(str, optional): argument 2
            
        Attributes:
            attr1(str): attribute 1
            attr2(str): attribute 2
            
        Returns:
            bool: True if successful, False otherwise
        
        Examples:
            >>> 1+1
            2
            >>> 2+2
            4
            
        Raises:
            AttributeError: not found
        """
    '''
    docstring = parse(text)
    assert len(docstring.args) == 2
    assert len(docstring.attributes) == 2
    assert len(docstring.examples) == 2

# Generated at 2022-06-11 21:27:09.056083
# Unit test for function parse
def test_parse():
    text = '''An abstract class for representing a transformation on a dataset.
    Required inputs are the dataset to be transformed and the input schema.
    Optional inputs are the output schema, the name of the transformation,
    and the parameters of the transformation.

    Parameters:
        dataset (DataFrame):
            A Spark DataFrame to be transformed.
        input_col (str):
            The name of the input column.
        output_col (str):
            The name of the output column.
        params (dict):
            The parameters of the transformation.
    '''
    d = parse(text)
    install_requires = d.params['params'].type_name.split(',')
    install_requires = list(map(lambda x: x.strip(), install_requires))
    print(install_requires)
    assert 0

# Generated at 2022-06-11 21:27:20.793529
# Unit test for function parse
def test_parse():
    text = """\
    Some summary text.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Raises:
        AttributeError: The ``AttributeError`` exception.
        ValueError: The ``ValueError`` exception.
    """
    result = parse(text)
    assert result.short_description == "Some summary text."
    assert len(result.long_description) == 0
    assert len(result.params) == 2
    assert len(result.returns) == 0
    assert len(result.raises) == 2
    assert len(result.meta) == 3
    assert result.meta["Args"].type == "Args"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:27:25.642251
# Unit test for function parse

# Generated at 2022-06-11 21:27:37.994339
# Unit test for function parse
def test_parse():
    text = '''\
    Short description.

    More description with code and some math.

    .. math::
        c = \\sqrt{a^2 + b^2}

    :param a: the length of a
    :type a: int
    :returns: length of hypotenuse
    :rtype: float
    '''
    d = Docstring(
        summary='Short description.',
        description='More description with code and some math.\n',
        content='More description with code and some math.',
        returns=('length of hypotenuse', 'float'),
        returns_description='',
        params=[('a', 'the length of a', 'int')]
    )
    assert d == parse(text)


# Generated at 2022-06-11 21:27:45.748203
# Unit test for function parse
def test_parse():
    from docstring_parser import split
    from docstring_parser.styles import NUMPYDOC
    from docstring_parser.common import Meta

    text = """
    This is a short description
    and this is longer one
    and can span over multiple lines
    """
    docstring = NUMPYDOC(text)
    assert docstring.short_description == text.strip()
    assert docstring.long_description == split(text.strip())
    assert docstring.meta == Meta()

    text = """
    This is a short description
    and this is longer one
    and can span over multiple lines

    Parameters
    ----------
    arg1: int
         The first argument
    arg2: str
         The second argument
    """
    docstring = NUMPYDOC(text)
    assert docstring.short_description == text.strip

# Generated at 2022-06-11 21:27:49.446511
# Unit test for function parse
def test_parse():
    """Test parse """
    text = """This is a program
    to parse docstring"""
    assert parse(text) == text

if __name__ == "__main__":
    test_parse

# Generated at 2022-06-11 21:27:57.459282
# Unit test for function parse
def test_parse():
    assert parse(" random text")
    assert parse("\n some metadata\n random text")
    assert parse("\n some metadata\n random text")
    assert parse("Random text")
    assert parse("Random text\n")

# Generated at 2022-06-11 21:28:06.778823
# Unit test for function parse
def test_parse():
    """
    This test is to ensure the docstring parsing functions are working properly.
    """
    docstring = "This is a docstring"

    assert parse(docstring) == Docstring(
        content = docstring,
        summary = "This is a docstring",
        extended_summary = None,
        body = None
    )

    docstring = "This is a docstring\n\nThis is more of the docstring extended summary"

    assert parse(docstring) == Docstring(
        content = docstring,
        summary = "This is a docstring",
        extended_summary = "This is more of the docstring extended summary",
        body = None
    )


# Generated at 2022-06-11 21:28:09.807583
# Unit test for function parse
def test_parse():
    """Test parse function."""
    test_docstring = """
    """
    docstring = parse(test_docstring)
    assert isinstance(docstring, Docstring)


# Generated at 2022-06-11 21:28:11.443917
# Unit test for function parse
def test_parse():
    text = """This is description"""
    assert parse(text) == Docstring(description=text)


# Generated at 2022-06-11 21:28:22.085251
# Unit test for function parse
def test_parse():
    import json
    import os
    import sys
    import io
    import unittest

    class TestParse(unittest.TestCase):
        def test_parse_sphinx(self):
            script_path = os.path.realpath(__file__)
            script_dir = os.path.dirname(script_path)
            sample_dir = os.path.join(script_dir, 'samples/sphinx')
            files = [
                os.path.join(sample_dir, fname) for fname in os.listdir(sample_dir)
            ]
            for fname in files:
                with io.open(fname, encoding='utf-8') as f:
                    result = parse(f.read())
                print(fname)

# Generated at 2022-06-11 21:28:27.015726
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstr.
    :param param1: description 1
    :param param2: description 2
    :param param3: description 3
    :return: return description
    '''
    assert parse(text)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:28:29.518198
# Unit test for function parse
def test_parse():
    docstring= parse("""
    hello 
    """
)

    assert docstring.short_description == "hello"

# Generated at 2022-06-11 21:28:36.273196
# Unit test for function parse
def test_parse():

    def foo():
        '''This is a docstring.
        
        :param name: a name
        
        :returns: a string
        '''
        pass

    docstring = parse(foo.__doc__)
    print(docstring)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.params)
    print(docstring.returns)
    print(docstring.meta)

# Generated at 2022-06-11 21:28:45.836078
# Unit test for function parse
def test_parse():
    doctest = parse.__doc__
    style_auto = parse(doctest)
    assert isinstance(style_auto, Docstring)

    style_numpy = parse(doctest, style=Style.numpy)
    assert isinstance(style_numpy, Docstring)

    style_google = parse(doctest, style=Style.google)
    assert isinstance(style_google, Docstring)

    style_toorgle = parse(doctest, style=Style.toorgle)
    assert isinstance(style_toorgle, Docstring)

    style_restructuredtext = parse(doctest, style=Style.reStructuredText)
    assert isinstance(style_restructuredtext, Docstring)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:28:56.850140
# Unit test for function parse
def test_parse():
    doc = """Summary line.

Extended description of function.

:param arg1: Description of `arg1`
:param arg2: Description of `arg2`
:returns: Description of return value
:raises keyError: raises an exception
"""

    parsed = parse(doc)
    assert parsed.short_description == "Summary line."
    assert parsed.long_description == "Extended description of function."
    assert parsed.returns.description == "Description of return value"
    assert parsed.params['arg1'].name == "arg1"
    assert parsed.params['arg1'].description == "Description of `arg1`"
    assert parsed.raises['keyError'].description == "raises an exception"



# Generated at 2022-06-11 21:29:11.739129
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    doc_obj = parse(docstring)

    # test for style
    assert doc_obj.style == Style.numpydoc
    assert doc_obj.style_name == doc_obj.style.name

    # test for description
    description = list(doc_obj.description.strip().split('\n'))
    description[0] += '\n'
    description[1] = '\n' + description[1]
    description[2] = '\n' + description[2]
    description[3] = '\n' + description[3]

    assert doc_obj.description.strip() == ''.join(description)

    # test for parameters present
    assert 'text' in doc_obj.params.keys()
    assert 'style' in doc_obj.params.keys()

# Generated at 2022-06-11 21:29:16.480685
# Unit test for function parse
def test_parse():
    result = parse("""
        This is a docstring.

        :param name: The name to say hello to.
        :type name: str
        :returns: None
        :raises ValueError: If name is empty.
    """)
    assert result.short_description == "This is a docstring."
    assert result.long_description == None
    assert result.returns == "None"
    assert result.return_type == None
    assert result.raises == "ValueError"
    assert result.raises_description == "If name is empty."

# Generated at 2022-06-11 21:29:26.867278
# Unit test for function parse
def test_parse():
    assert len(parse('''
    This is my docstring

    :param param: Parameter
    ''').params) == 1
    try:
        parse('Invalid docstring')
    except ParseError:
        pass
    else:
        raise AssertionError('ParseError expected')

if __name__ == '__main__':
    import sys
    import unittest

    if '-t' in sys.argv:
        test_parse()
    elif '-tb' in sys.argv:
        doctest.testmod()
    else:
        unittest.main(argv=sys.argv[:1])

# Generated at 2022-06-11 21:29:28.968724
# Unit test for function parse
def test_parse():
    for parse_style in STYLES.values():
        try:
            assert parse_style('hello')
        except ParseError:
            pass

# Generated at 2022-06-11 21:29:39.353249
# Unit test for function parse
def test_parse():
    # Function parse
    # Given
    text1 = "This is a function"
    text2 = "This is a function"
    text3 = "This is a function"
    
    # when
    parse(text1, style=Style.auto)
    parse(text2, style=Style.Google)
    parse(text3, style=Style.Numpy)
    # Should return
    # Docstring(summary='This is a function',
    #           description=None,
    #           meta={}, sections=[Section(title='Parameters',
    #                                     content='None',
    #                                     kind='parameters'),
    #                             Section(title='Example',
    #                                     content='None',
    #                                     kind='example')])
    # Docstring(summary='This is a function',
    #           description=None,


# Generated at 2022-06-11 21:29:44.499380
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    test_string = """
    This is a test of Docstring Parsing.
    It should parse without error.

    :param str test: This is a test
    """
    test_docstring = parse(test_string)
    if test_docstring is None:
        assert 0
    else:
        assert 1

# Generated at 2022-06-11 21:29:48.052460
# Unit test for function parse
def test_parse():
    assert parse("test")
    assert parse("test", style=Style.google)
    assert parse("test", style=Style.numpy)


# Generated at 2022-06-11 21:29:55.525375
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import Style
    text = '''
    The main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    return_obj = Docstring(
        short_description='The main parsing routine.',
        long_description='',
        meta=[
            ('param', 'text', 'docstring text to parse'), 
            ('param', 'style', 'docstring style'), 
            ('returns', 'parsed docstring representation')
        ]
    )
    assert parse(text, Style.rst) == return_obj

# Generated at 2022-06-11 21:30:05.072284
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "")
    assert parse("Hello") == Docstring("Hello", "")
    assert parse("Hello\n world!") == Docstring("Hello world!", "")
    assert parse("Hello\n\n world!") == Docstring("Hello\nworld!", "")
    assert parse("\nHello\n\n world!") == Docstring("Hello\nworld!", "")
    assert parse("\nHello world!\n") == Docstring("Hello world!", "")
    assert parse("\nHello\n\n world!\n\nfoo") == Docstring("Hello\nworld!", "foo")
    assert parse("\nHello\n\n world!\n\nfoo\n") == Docstring("Hello\nworld!", "foo\n")

# Generated at 2022-06-11 21:30:13.199204
# Unit test for function parse
def test_parse():
    text = '''double check specification about parsing string'''
    style = 'google'
    a = parse(text, style)
    assert type(a) == Docstring
    assert a.short_description == 'double check specification about parsing string'
    assert a.long_description == ''
    assert a.returns == None
    assert a.yields == None
    assert a.raises == []
    assert a.meta == None

# Generated at 2022-06-11 21:30:24.705897
# Unit test for function parse
def test_parse():
    doc = parse('''\
Multi-line docstring.

:param a_str: this is a string

:returns: an integer
:rtype: int''')

    assert doc.short_description == 'Multi-line docstring.'
    assert doc.long_description == ''
    assert len(doc.params) == 1
    assert len(doc.returns) == 1
    assert len(doc.meta) == 2

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:30:34.526810
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

This is a longer description of the class, which offer a
few lines of explanation.

Extended description of class.

Param1:
    Description of `param1`

Param2:
    Description of `param2`

Returns:
    Description of return value.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.

"""

# Generated at 2022-06-11 21:30:44.240227
# Unit test for function parse
def test_parse():

    class A:
        """
        A is a class.
        :param a: a
        :param b: b
        :param c: c
        """

        def foo(self, a, b, c=1, *args):
            r"""
            A is a class.

            :param a: a
            :param b: b
            :param c: c
            :param \*args: args
            """

    class B:
        """
        B is a class.
        """

        def foo(self, a, b, c=1, *args):
            r"""
            B is a class.

            :param a: a
            :param b: b
            :param c: c
            :param \*args: args
            """

    class C:
        """
        C is a class.
        """



# Generated at 2022-06-11 21:30:46.568436
# Unit test for function parse
def test_parse():
    s='This is the class doc'
    assert parse(s)==Docstring(s)
    
    
# End of file

# Generated at 2022-06-11 21:30:55.830916
# Unit test for function parse
def test_parse():

    # Parse string into docstring object
    docstring = parse("""First line \
                    Second line \
                    Third line \
                    """)
    # Test object class
    assert isinstance(docstring, Docstring)

    # Test object values
    assert docstring.short_description == "First line"
    assert docstring.long_description == "Second line\nThird line"

    # Test object attributes
    assert docstring.params == []
    assert docstring.returns == []
    assert docstring.see_also == []
    assert docstring.version == []

# Generated at 2022-06-11 21:31:02.017866
# Unit test for function parse
def test_parse():
    """Unit test for function parse.
    """

    test1 = """This is the first test.
    :param x: The first param
    :type x: int
    :param y: The second param
    :type y: int
    :returns: The sum of x and y
    :rtype: int
    """
    test2 = """This is the second test
    :param a: The first param.
    :param b: The second param.
    :returns: The sum of a and b.
    """
    test3 = """This is the third test
    :ivar x: The first param
    :ivar y: The second param
    :ivar z: The third param
    :ivar op: The operation
    :returns: The operation applied to x, y and z.
    """

# Generated at 2022-06-11 21:31:09.751432
# Unit test for function parse
def test_parse():
    text = """This is a funtion to test the parser\n
    :param fileName: name of the file to open\n
    :type filename: string\n
    :param mode: the mode in which the file is opened\n
    :type mode: string\n
    :param bufsize: Not required\n
    :returns : string \n
    :raises : OpenFileError\n
    """
    d = parse(text, style=Style.numpy)
    assert d.summary == 'This is a funtion to test the parser'
    assert d.params['fileName'].desc == 'name of the file to open'
    assert d.params['fileName'].type == 'string'
    assert d.params['mode'].desc == 'the mode in which the file is opened'

# Generated at 2022-06-11 21:31:20.503962
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    doc = """
    Summary line.

    Extended description.

    :param arg1: Description of arg1
    :type arg1: int, str, dict
    :param arg2: Description of arg2
    :type arg2: str
    :returns: Description of return value
    :rtype: float, int
    :raises keyError: desc of exception
    """
    result = parse(doc)

    assert result.metadata['Summary line.'][0] == 'Summary line.'
    assert result.metadata['Extended description.'][0] == 'Extended description.'
    assert result.metadata[':param arg1: Description of arg1'][0] == ':param arg1: Description of arg1'

# Generated at 2022-06-11 21:31:28.785339
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.google import GoogleStyle as Style

    docstring = """Args:
        param1: The first parameter.
        param2: The second parameter.
    """

    params = parse(docstring, Style.auto)
    assert params.args[0].arg_name == 'param1'
    assert params.args[0].description == 'The first parameter.'
    assert params.args[1].arg_name == 'param2'
    assert params.args[1].description == 'The second parameter.'

# Generated at 2022-06-11 21:31:32.599285
# Unit test for function parse
def test_parse():
    """Unit test for function parse
    """
    import pytest
    docstring = parse.__doc__
    with pytest.raises(ParseError):
        parse(docstring, style=Style.auto)



# Generated at 2022-06-11 21:31:47.029574
# Unit test for function parse

# Generated at 2022-06-11 21:31:48.321277
# Unit test for function parse
def test_parse():
    assert parse('Test') is not None

# Generated at 2022-06-11 21:31:50.182603
# Unit test for function parse
def test_parse():
    assert isinstance(parse(''), Docstring)==True

# Generated at 2022-06-11 21:31:53.111253
# Unit test for function parse
def test_parse():
  assert ("""summary

Args:
    x: an integer
    y: a float
""") == parse("""summary

Args:
    x: an integer
    y: a float
""")


# Generated at 2022-06-11 21:32:04.910150
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    from docstring_parser.styles import STYLES, Style

    def parse(text: str, style: Style = Style.auto) -> Docstring:
        if style != Style.auto:
            return STYLES[style](text)
        rets = []
        for parse_ in STYLES.values():
            try:
                rets.append(parse_(text))
            except ParseError as e:
                exc = e
        if not rets:
            raise exc
        return sorted(rets, key=lambda d: len(d.meta), reverse=True)[0]


# Generated at 2022-06-11 21:32:06.860786
# Unit test for function parse
def test_parse():
    assert parse('1. ') == parse(' 1. ')

# Generated at 2022-06-11 21:32:13.125007
# Unit test for function parse
def test_parse():
    test_parse.__doc__  # doctest: +ELLIPSIS
    '''
    >>> d = parse(test_parse.__doc__)
    >>> d
    Docstring(summary='Unit test for function parse', meta={}, sections=[])
    >>> d.summary
    'Unit test for function parse'
    >>> d.meta
    {}
    >>> d.sections
    []
    '''


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:32:15.499131
# Unit test for function parse
def test_parse():
    text = ("hello")
    assert parse(text) == {'name': 'hello'}



# Generated at 2022-06-11 21:32:19.094698
# Unit test for function parse
def test_parse():
    docstring = r"""
    text
    """
    assert parse(docstring) == Docstring(short_description='', long_description='text\n    ', tags=[])

    docstring = r"""
    s
    l
    """
    assert parse(docstring) == Docstring(short_description='s', long_description='l\n    ', tags=[])


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:30.910599
# Unit test for function parse
def test_parse():
    '''
    phrase = "This function does something.\n\n:param int a: the first param\n:param str b: the second param\n\n:returns: describes the return value\n:rtype: str\n\n:raises ValueError: if b <= a\n\n"
    #phrase = "hello world"
    doc = parse(phrase, style = Style.numpy)
    print(doc)
    '''


# Generated at 2022-06-11 21:32:40.320396
# Unit test for function parse
def test_parse():
    text = """
    Summary line.

    Extended description.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    ans = parse(text)
    print(ans)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:43.947342
# Unit test for function parse
def test_parse():
    """
    >>> text = "Test Function"
    >>> style = Style.google
    >>> parse(text, style)
    Docstring(summary='Test Function', description=None, returns=None, raises=None, meta={})
    """


# Generated at 2022-06-11 21:32:50.903241
# Unit test for function parse
def test_parse():
    text = """This is a test docstring.
    :param test: test param
    :returns: test return
    :raises TypeError: if test fails"""
    docstring = parse(text, Style.numpy)
    assert docstring.params == [('test', 'test param', None)]
    assert docstring.returns == 'test return'
    assert docstring.raises == [('TypeError', 'if test fails')]

# Generated at 2022-06-11 21:32:53.203740
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    # Case 1: Docstring for function parse
    assert parse('a')
    # Case 2: Docstring for function parse
    try:
        parse('')
    except ParseError as e:
        assert type(e) == ParseError


# Generated at 2022-06-11 21:32:57.940771
# Unit test for function parse
def test_parse():
    from docstring_parser import DocstringParser
    from docstring_parser.styles import NUMPYDOC
    assert isinstance(parse('', style=NUMPYDOC), Docstring)
    assert isinstance(parse('from none'), Docstring)
    assert isinstance(DocstringParser(style=NUMPYDOC).parse('from none'), Docstring)

# Generated at 2022-06-11 21:33:05.480985
# Unit test for function parse
def test_parse():
    """main parser"""
    from docstring_parser.styles import NUMPYDOC
    docstring = """
    Parameters
    ----------
    arg1 : int
        The first parameter.
    arg2 : str
        The second parameter.

    Returns
    -------
    str
        The return value.

    """
    assert len(parse(docstring, style=NUMPYDOC).content) == 3


# Generated at 2022-06-11 21:33:15.117664
# Unit test for function parse
def test_parse():
    docstring = '''
    Parse the docstring into its components.

      :param text: docstring text to parse
      :param style: docstring style
      :return: parsed docstring representation
      '''
    doc = parse(docstring)
    print('docstring: ' + docstring)
    print('style: ' + 'Numpy')
    print('summary: ' + doc.summary)
    print('description: ' + doc.description)
    print('meta: ' + str(doc.meta))
    print('body: ' + str(doc.body))
    print()

    docstring = '''
    Parse the docstring into its components.
    '''
    doc = parse(docstring)
    print('docstring: ' + docstring)
    print('style: ' + doc.style.value)
    print

# Generated at 2022-06-11 21:33:23.824315
# Unit test for function parse
def test_parse():
    docstring_text = """
    A simple example docstring.

    :param foo: the foo parameter
    :param bar: the bar parameter
    :returns: returns the result
    """
    result = parse(docstring_text, style=Style.numpy)
    print(result)

    """
    A simple example docstring.

    :param foo: the foo parameter
    :param bar: the bar parameter
    :returns: returns the result
    """

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:33:27.874244
# Unit test for function parse

# Generated at 2022-06-11 21:33:36.288564
# Unit test for function parse

# Generated at 2022-06-11 21:33:47.234953
# Unit test for function parse
def test_parse():
    docstring = """This is a Google style docstring.

Args:
    arg1 (int): The first argument.
    arg2 (str): The second argument.
    arg3 (list of str): A list of strings.

Returns:
    bool: The return value. True for success, False otherwise.
    """
    assert isinstance(parse(docstring), Docstring)
    assert isinstance(parse(docstring, Style.google), Docstring)
    assert isinstance(parse(docstring, Style.numpy), Docstring)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:33:50.299335
# Unit test for function parse
def test_parse():
    text = r'''Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    parse(text)


if __name__ == '__main__':
    # test_parse()
    text = r'''Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    print(parse(text).__dict__)

# Generated at 2022-06-11 21:34:00.374350
# Unit test for function parse
def test_parse():
    """Test parsing of strings."""

    def test_string(string, expected):
        res = parse(string)
        assert expected == res

    def test_style(string, style, expected):
        res = parse(string, style)
        assert expected == res

    test_string(
        """Description.

        Args:
            a: a
            b: b
            c: c

        Returns:
            None

        """,
        Docstring(
            description="Description.",
            args=[
                "a",
                "b",
                "c",
            ],
            meta={"returns": "None"},
        ))


# Generated at 2022-06-11 21:34:11.227578
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import google

    docstr = """First line is brief explanation.

    The only line of the first paragraph ends here.
    The first paragraph is followed by a blank line.

    The second paragraph starts here. It continues here.
    And it ends here.
    """
    assert parse(docstr).meta['brief'] == 'First line is brief explanation.'

    docstr = """Parameters:
    arg1 (int): Description of `arg1`
    arg2 (str): Description of `arg2`

    Returns:
    bool: Description of return value
    """
    assert parse(docstr).meta['parameters']['arg1']['annotation'] == 'int'


# Generated at 2022-06-11 21:34:21.762253
# Unit test for function parse
def test_parse():
    text = '''
        Test docstring.
          Lines starting with '#' are ignored and stripped.
        #
        # This is ignored.
        #
        :param number: a number (int, float, etc.)
        :param name: a string
        :param keyword: a keyword
        :return: a number
    '''
    doc = parse(text)
    assert doc.short_description == 'Test docstring. Lines starting with \'#\' are ignored and stripped.'
    assert len(doc.long_description) == 1
    assert not doc.long_description[0]
    assert len(doc.meta) == 3
    assert doc.meta['param'] == ['number: a number (int, float, etc.)',
                                 'name: a string',
                                 'keyword: a keyword']
    assert doc.meta['return']

# Generated at 2022-06-11 21:34:32.344551
# Unit test for function parse
def test_parse():
    test_text = '''
    line one
    line two
    '''
    ds = parse(test_text)
    text = ds.text
    assert text

    test_text = """
    Parameters
    ----------
    x : int
        The meaning of life and everything
    """
    ds = parse(test_text)
    assert ds.params['x'].type == 'int'
    assert ds.params['x'].desc == 'The meaning of life and everything'

    test_text = """
    Check this out.

    Parameters
    ----------
    x : int
        The meaning of life and everything
    """
    ds = parse(test_text)
    assert ds.params['x'].type == 'int'

# Generated at 2022-06-11 21:34:43.484978
# Unit test for function parse
def test_parse():
    text = '''
    """Returns the sum of all numbers in the list
    :param collection: the collection to get a sum of
    :param n: the last number in the series
    :return: the sum of the numbers
    """
    '''
    parsed = parse(text)

    assert parsed.short_description == 'Returns the sum of all numbers in the list'
    assert parsed.long_description == ''
    assert parsed.returns.type_name == 'the sum of the numbers'
    assert parsed.params['collection'].type_name == 'the collection to get a sum of'
    assert parsed.params['n'].type_name == 'the last number in the series'
    assert len(parsed.meta) == 3


# Generated at 2022-06-11 21:34:45.849801
# Unit test for function parse
def test_parse():
    from .examples import NUMPY_DOCSTRING
    d = parse(NUMPY_DOCSTRING)
    print(d)

# Generated at 2022-06-11 21:34:52.701693
# Unit test for function parse
def test_parse():
    text = """Unit test for function parse
    :param text: docstring text to parse
    :param style: docstring style"""
    if (parse(text).raw != text):
        raise Exception('test_parse failed')
    return 0
test_parse()

# def parse_group_dict(text: str, style: Style = Style.auto,
#                      group_dict: Dict[str, Sequence[str]] = None) -> Docstring:
#     """Parse the docstring into its components.

#     :param text: docstring text to parse
#     :param style: docstring style
#     :param group_dict: Dictionary mapping sections in the docstring to names
#     :returns: parsed docstring representation
#     """
#     if style != Style.auto:
#         return STYLES[style](text, group_

# Generated at 2022-06-11 21:35:02.291620
# Unit test for function parse
def test_parse():
    text = """Summary line.

This is an extended description.

Args:
    arg1 (int): The first argument.
    arg2 (str): The second argument.
Returns:
    int: The return value. True for success, False otherwise.
"""
    docstring = parse(text)
    expected = Docstring(
        summary="Summary line.",
        description=["This is an extended description."],
        metadata=[
            ("Args", None, [("arg1", "int", None, "The first argument."),
                            ("arg2", "str", None, "The second argument.")]),
            ("Returns", "int", None, "The return value. \
            True for success, False otherwise.")
        ],
        style=Style.numpy,
        style_name="NumPy"
    )
    assert str(docstring)

# Generated at 2022-06-11 21:35:11.224571
# Unit test for function parse
def test_parse():
    docstring_text = """Routine:
:param
:returns:
:raises:"""
    assert parse(docstring_text).meta['returns'] == ''


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:18.733292
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.google import parse_google_docstring
    docstring = '''\
    Short summary.

    Longer description.

    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`
    '''
    parsed = parse(docstring)
    parsed_ = parse(docstring, style=Style.google)
    parsed__ = parse_google_docstring(docstring)
    assert parsed == parsed_ == parsed__

# Generated at 2022-06-11 21:35:21.014579
# Unit test for function parse
def test_parse():
    docstr = """\
Module summary line.

Module description.
"""
    myobj = parse(docstr)
    print(myobj.short_description)
    print(myobj.long_description)

# Generated at 2022-06-11 21:35:23.036525
# Unit test for function parse
def test_parse():
    result = parse("This is docstring")
    print(result)


# Generated at 2022-06-11 21:35:30.898775
# Unit test for function parse
def test_parse():
    assert parse("asdf") == parse("asdf", style=Style.numpy)
    assert parse("asdf") != parse("asdf", style=Style.google)

    assert parse("asdf", style=Style.numpy) == parse("asdf", style=Style.auto)
    assert parse("asdf", style=Style.google) == parse("asdf", style=Style.auto)
    assert parse("asdf", style=Style.auto) == parse("asdf", style=Style.auto)
    
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:35:34.897144
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    docstring_text = "the quick brown fox jumps over the lazy dog"
    assert parse(docstring_text).short_description == docstring_text

# Generated at 2022-06-11 21:35:39.588910
# Unit test for function parse
def test_parse():
    docstring_styles = [Style.pep, Style.google, Style.numpy]
    for style in docstring_styles:
        assert parse(parse(docstring_text, style=style), style=style) == parse(docstring_text, style=style), \
            "parse(parse(docstring_text, style=style), style=style) != parse(docstring_text, style=style)"


# Generated at 2022-06-11 21:35:47.049586
# Unit test for function parse
def test_parse():
	docstring = '''This function will do something.
	
	:params i: The parameter i
			   This is a multi-line description
	:params b: The parameter b
	:returns: What it will return
			   Also a multi-line description
	'''
	assert parse(docstring) == Docstring(params=[('i','\n			   This is a multi-line description'), ('b','None')], returns="What it will return\n			   Also a multi-line description")

# Generated at 2022-06-11 21:35:52.148707
# Unit test for function parse
def test_parse():
    """Test that the test_parse is working"""
    test = """
    This is a test docstring:
    :param test_param: this is a test parameter
    :returns: this is a return value
    """
    docstring = parse(test)
    assert docstring.short_description == "This is a test docstring:"
    assert len(docstring.long_description) == 0
    assert docstring.returns.description == "this is a return value"
    assert len(docstring.params) == 1
    assert docstring.params[0].arg_name == "test_param"
    assert docstring.params[0].description == "this is a test parameter"

# Generated at 2022-06-11 21:36:02.832821
# Unit test for function parse
def test_parse():
    expected_docstring = Docstring(
        summary='Prints Hello World',
        description='If you want to print Hello World, then call this function',
        meta={
            'parameters': {
                    'name': 'name'
                    },
            'returns': 'Hello World',
            'raises': {
                'name': 'exception',
                'description': 'Raises an exception'
            }
        }
    )
    example_docstring_str = '''\
    Prints Hello World

    If you want to print Hello World, then call this function

    :param name:
    :returns: Hello World
    :raises exception: Raises an exception'''
    assert parse(example_docstring_str) == expected_docstring

# Generated at 2022-06-11 21:36:16.659520
# Unit test for function parse
def test_parse():
    r = parse("""
    Hello"""
    )
    assert r.short_description == 'Hello'
    assert not r.long_description
    assert not r.meta

    r = parse("""Hello
    -----
    World
    """)
    assert r.short_description == 'Hello'
    assert r.long_description == 'World'
    assert not r.meta

    r = parse("""Hello
    Hello
    """)
    assert r.short_description == 'Hello\nHello'
    assert not r.long_description
    assert not r.meta

    r = parse("""Hello
    World
    -----
    Next
    """)
    assert r.short_description == 'Hello'
    assert r.long_description == 'World\nNext'
    assert not r.meta
