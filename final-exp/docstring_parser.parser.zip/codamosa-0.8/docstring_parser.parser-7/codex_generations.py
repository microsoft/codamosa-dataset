

# Generated at 2022-06-11 21:26:25.572593
# Unit test for function parse
def test_parse():
    assert parse("hello") == Docstring("hello", [], [])
    assert parse("hello\nworld\n") == Docstring("hello\nworld", [], [])
    assert parse("hello\nworld\n\n") == Docstring("hello\nworld", [], [])
    assert parse("hello\nworld\n\n\n") == \
           Docstring("hello\nworld", [], [])
    assert parse("hello\nworld\n\n\n\n") == \
           Docstring("hello\nworld", [], [])
    assert parse("hello\nworld\n\nSection\n-------\n\n\n") == \
           Docstring("hello\nworld", [], [])

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:26:32.668372
# Unit test for function parse
def test_parse():
    def f(x, y=1):
        """Test"""
        pass
    docstring = parse(f.__doc__)
    assert docstring.short_description == 'Test'
    assert docstring.args == [{'validator': None, 'name': 'x', 'type': None, 'default': None, 'description': ''}]
    assert docstring.returns == {'name': 'return', 'type': None, 'description': ''}
    assert docstring.long_description == ''

# Generated at 2022-06-11 21:26:34.673770
# Unit test for function parse
def test_parse():
    assert isinstance(parse(""), Docstring) is True

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:26:36.555965
# Unit test for function parse
def test_parse():
	text = """This is a test."""
	doc = parse(text)
	print(doc)

test_parse()

# Generated at 2022-06-11 21:26:43.036975
# Unit test for function parse
def test_parse():
    """Test case for function parse"""
    # Testing for parse function
    assert parse.__doc__ == ("Parse the docstring into its components.\n\n"
                             "    :param text: docstring text to parse\n"
                             "    :param style: docstring style\n"
                             "    :returns: parsed docstring representation\n")
    assert parse.__name__ == 'parse'
    assert callable(parse)

# Generated at 2022-06-11 21:26:48.357622
# Unit test for function parse
def test_parse():
    docstring_python = '''Single line docstring.'''

    assert parse(docstring_python) == 'Single line docstring.'

    docstring_numpy = '''Single line docstring.

    Extended description.
    '''

    assert parse(docstring_numpy) == 'Single line docstring. \n \n Extended description.'

    docstring_google = '''Single line docstring.

    Args:
        arg_one (str): The first argument.
        arg_two (:obj:`int`, optional): The second argument. Defaults to None.
            Second line of description should be indented.
        arg_three (:obj:`list` of :obj:`str`): List of strings.

    Returns:
        bool: The return value. True for success, False otherwise.

    '''

# Generated at 2022-06-11 21:26:58.813560
# Unit test for function parse
def test_parse():
    text = """
            Summary line.

            Extended description.

            Args:
                arg1 (int): Description of arg1
                arg2 (str): Description of arg2

            Returns:
                bool: Description of return value

            """
    docstring = parse(text)
    print(docstring)
    assert docstring.summary == 'Summary line.'
    assert docstring.description == 'Extended description.'
    assert docstring.meta.parameters == [
        {'name': 'arg1', 'type': 'int', 'description': 'Description of arg1'},
        {'name': 'arg2', 'type': 'str', 'description': 'Description of arg2'},
    ]
    assert docstring.meta.returns == {'type': 'bool', 'description': 'Description of return value'}


# Generated at 2022-06-11 21:27:02.178457
# Unit test for function parse
def test_parse():
    t = """
    This is a test.
    """
    print(parse(t))
    print()
    print(parse(t, 1))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:27:11.523495
# Unit test for function parse
def test_parse():
    s = """
    Dummy function.

    :param a: first parameter
    :param b: second parameter
    :return: return value
    :raises ValueError: when a > 10
    """
    d = parse(s)
    assert(d.short_description == "Dummy function.")
    assert(d.long_description == "")
    assert(len(d.params) == 2)
    assert(len(d.returns) == 1)
    assert(len(d.raises) == 1)
    assert(len(d.warns) == 0)
    assert(len(d.yields) == 0)
    assert(len(d.attributes) == 0)
    assert(len(d.meta) == 0)


# Generated at 2022-06-11 21:27:16.242358
# Unit test for function parse
def test_parse():
    style = Style.auto
    text = """

    :param id: Integer

    """
    parse(text, style)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:27:31.057989
# Unit test for function parse
def test_parse():
    text = """One line summary.

Longer, multi-line description. May contain Markdown, including [links](https://example.com) and lists:

1. One
2. Two
"""

    expected = """One line summary.

Longer, multi-line description. May contain Markdown, including [links](https://example.com) and lists:

1. One
2. Two
"""

    expected_doc = Docstring("One line summary.\n", "\nLonger, multi-line description. May contain Markdown, "
                                                 "including [links](https://example.com) and lists:\n\n"
                                                 "1. One\n"
                                                 "2. Two\n", "", "", [], [], None, None, [])


    parsed_doc = parse(text)

# Generated at 2022-06-11 21:27:42.151930
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import STYLES
    from docstring_parser.docstring import Docstring

    text = "this is a simple test"
    d = parse(text)
    assert isinstance(d, Docstring)

    text = '''\
    short summary
    short summary

    longer explanation

     - list
     - list

    :param arg:
    :keyword arg:
    :param list arg:
    :keyword list arg:
    :param str arg:
    :keyword str arg:
    :return:
    :rtype:
    '''
    d = parse(text, style=STYLES[Style.sphinx])
    assert isinstance(d, Docstring)
    assert d.short_description == 'short summary'

# Generated at 2022-06-11 21:27:52.672801
# Unit test for function parse
def test_parse():
    # import sys
    # sys.path.insert(0, "..")
    from docstring_parser.parser import parse
    
    # Check the auto feature
    text1 = """\
    """
    text2 = """\
    Hello, World!
    """
    text3 = """\
    :param s: str
    """
    text4 = """\
    :param s: str
        test
    """
    text5 = """\
    :returns: bool
    """
    text6 = """\
    :param x: int
        x coordinate
    :param y: int
        y coordinate
    :returns: point
        This is a point.\
    """

# Generated at 2022-06-11 21:28:03.451200
# Unit test for function parse
def test_parse():
    """Testing function parse"""
    from docstring_parser.styles import DEFAULT_STYLE
    from docstring_parser.common import ParseError
    from docstring_parser.parser import parse
    docstring = """
    Parse the docstring into a dictionary.

    :param docstring: the docstring to parse
    :param style: style, defaults to ``auto``
    :param cls: The class if available
    :return: dict
    :raises ParseError: if any errors are found
    """
    assert parse(docstring) == DEFAULT_STYLE(docstring)

# Generated at 2022-06-11 21:28:11.715378
# Unit test for function parse
def test_parse():
    expected_description = ('This is the sample.'
                            ' This is the second line.'
                            '    This is the third line.'
                            ' This is the fourth line.'
                            '\nThis is the fifth line.'
                            '\nAnd the sixth line.')
    expected_args = [{'name': 'arg1', 'type_name': 'str', 'description': 'This is the argument1.'},
                     {'name': 'arg2', 'type_name': 'str', 'description': 'This is the argument2.'}]
    expected_returns = {'type_name': 'str', 'description': 'The return value.'}
    expected_raises = [{'type_name': 'ValueError', 'description': 'If something bad happens.'}]

# Generated at 2022-06-11 21:28:15.466352
# Unit test for function parse
def test_parse():
    """Function to test parse function"""
    teststring = """Function to test parse function"""
    expected_dict = {}
    test_output = parse(teststring)
    assert test_output.__dict__ == expected_dict

# Generated at 2022-06-11 21:28:18.200834
# Unit test for function parse
def test_parse():
    text = parse(text="""test""" )
    print(text)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:28:22.718755
# Unit test for function parse
def test_parse():

    docstring = '''Description:
  "Test Description"

Args:
    arg1: arg1
    arg2: arg2

Return:
    return1: return1
    return2: return2
'''

    from pprint import pprint
    pprint(parse(docstring))




if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:28:34.753204
# Unit test for function parse
def test_parse():
    text = """
    This is the summary.

    :param foo: The foo parameter
    :type foo: int
    :param bar: The bar parameter
    :type bar: str
    :returns: str
    :raises ValueError: Something bad happened.
    """
    actual = parse(text)
    expected = Docstring(
        summary="This is the summary.",
        description=None,
        returns="str",
        params=[
            ("foo", "int", "The foo parameter"),
            ("bar", "str", "The bar parameter"),
        ],
        other=[("raises", "ValueError", "Something bad happened.")],
        meta={},
    )
    assert actual == expected

    text = " something random "
    actual = parse(text)

# Generated at 2022-06-11 21:28:36.844894
# Unit test for function parse
def test_parse():
    text = """The main parsing routine."""
    style = Style.google
    #assert parse(text) == 4

# Generated at 2022-06-11 21:28:50.988434
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, DArgument
    test_data = '''
    :param aaa: aaaa
    :param bbb: bbbb
    :param ccc: ccccc
    :rtype: dict
    :raises: ValueError
    '''
    ds = parse(test_data)
    assert len(ds.args) == 3
    assert ds.args == [DArgument('aaa', 'aaaa'), DArgument('bbb', 'bbbb'), DArgument('ccc', 'ccccc')]
    assert ds.ret_type == 'dict'
    assert ds.raises == ['ValueError']
    ds.append_arg('ddd', 'ddd')

# Generated at 2022-06-11 21:28:57.329587
# Unit test for function parse
def test_parse():
    text = \
"""Using the function
 
Parameters
----------
text_: string
 
Returns
-------
docstring: docstring_parser.docstring.Docstring
 
Raises
------
docstring_parser.exceptions.ParseError"""
    result = parse(text)
    print(result)
    assert 0

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:00.014744
# Unit test for function parse
def test_parse():
    """Parse a docstring"""
    assert parse.__doc__ == "Parses docstring into its components\n"

# Generated at 2022-06-11 21:29:06.429241
# Unit test for function parse
def test_parse():
    docstring = {'short_description': 'Lorem ipsum dolor sit amet.',
                 'long_description': '',
                 'meta': {},
                 'sections': [],
                 'newlines': 0}
    assert parse(' """Lorem ipsum dolor sit amet.\n"""') == docstring
    assert parse('''"""Lorem ipsum dolor sit amet.

\n"""''') == docstring

# Generated at 2022-06-11 21:29:10.702304
# Unit test for function parse
def test_parse():
    text = '''"""
    This function does something.
    And it does it good.

    :param a: first parameter
    :type a: int
    :param b: second parameter
    :type b: str
    :returns: str
    :raises ValueError: raises error
    """'''
    assert len(parse(text)) == 3
    return "test_parse() passed"

# Generated at 2022-06-11 21:29:16.038316
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError, Style
    text = "This is a test."
    style1 = Style.google
    style2 = Style.numpy
    style3 = Style.auto
    try:
        assert parse(text,style1) == parse(text,style2)
        assert parse(text,style1) != parse(text,style3)
    except ParseError as e:
        print(e)
    else:
        print("Passed!")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:29:24.002979
# Unit test for function parse
def test_parse():
    assert parse("""\
    This is sample documentation string
    test of parse.

    Args:
        arg1(int): Argument1
        arg2(str): Argument2
        arg3(float): Argument3
        arg4(bool): Argument4
    """).to_dict() == {
        'arg1': 'Argument1',
        'arg2': 'Argument2',
        'arg3': 'Argument3',
        'arg4': 'Argument4',
    }

# Generated at 2022-06-11 21:29:31.045450
# Unit test for function parse
def test_parse():
    text = """\
    A test function.

    Args:
        a: The first argument.
        b: The second argument.

    Returns:
        The return value.

    Raises:
        An exception.
    """
    docstring = parse(text)
    assert str(docstring) == text
    assert docstring.short_description == "A test function."
    assert docstring.long_description == ""
    assert docstring.summary == 'A test function.'
    assert docstring.meta["Args"] == 'a: The first argument.\nb: The second argument.'
    assert docstring.meta["Raises"] == "An exception."
    assert docstring.meta["Returns"] == "The return value."
    assert docstring.returns == "The return value."
    assert docstring.return_type == "return value"


# Generated at 2022-06-11 21:29:40.520351
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google
    from docstring_parser.common import Docstring, ParseError
    import pytest

    # Test for valid text
    text = """
    A small summary.

    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`

    Returns:
        str: Description of return value
    """

# Generated at 2022-06-11 21:29:52.418907
# Unit test for function parse
def test_parse():
    """Test_parse unit test for function parse."""

    text = "This is a test"
    style = "google"
    # if style != Style.auto:
    #     return STYLES[style](text)
    # rets = []
    rets = parse(text, style)
    # for parse_ in STYLES.values():
    #     try:
    #         rets.append(parse_(text))
    #     except ParseError as e:
    #         exc = e
    # if not rets:
    #     raise exc
    # return sorted(rets, key=lambda d: len(d.meta), reverse=True)[0]
    assert rets.short_description == "This is a test"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:58.908947
# Unit test for function parse
def test_parse():
    print(parse.__doc__)

# Test case for function parse
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:09.184248
# Unit test for function parse
def test_parse():
    ds = '''
    title
    ---------
    description

    Parameters
    ----------
    arg1 : int
        the first argument.

    arg2 : str
        the second argument.

    Returns
    -------
    dict
        information.
    '''
    output = parse(ds)
    expected = {'title': 'title', 'description': 'description', 'parameters': [
        {'name': 'arg1', 'type_name': 'int', 'description': 'the first argument.'},
        {'name': 'arg2', 'type_name': 'str', 'description': 'the second argument.'}],
        'returns': {'type_name': 'dict', 'description': 'information.'}}
    assert output.keywords == expected['keywords']
    assert output.description == expected['description']

# Generated at 2022-06-11 21:30:18.727021
# Unit test for function parse
def test_parse():
    """This is the test unit for function parse"""
    # Line-based styles.
    assert isinstance(parse("one\ntwo"), Docstring)
    assert isinstance(parse("one\ntwo", Style.rst), Docstring)
    assert isinstance(parse("one\ntwo", Style.google), Docstring)
    assert isinstance(parse("one\ntwo", Style.sphinx), Docstring)

    # Numpy styles.
    assert isinstance(parse("One.\n\nTwo."), Docstring)
    assert isinstance(parse("One.\n\nTwo.", Style.numpy), Docstring)

    # Numpy/Google styles.
    assert isinstance(parse("Args:\n  one: One.\n  two: Two."), Docstring)

# Generated at 2022-06-11 21:30:27.404826
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    text = '''
    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
    The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here',
    making it look like readable English.
    '''
    ret = parse(text)
    assert ret.short_description == 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'
    assert ret.long_description == 'The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\',\nmaking it look like readable English.\n'

# Generated at 2022-06-11 21:30:36.314321
# Unit test for function parse
def test_parse():
    text1 = '''\
    Single-line docstring.

    :param x: a parameter
    :param y: a parameter
    :returns: a return value
    '''
    ds = parse(text1)
    assert ds.short_description == 'Single-line docstring.'
    assert ds.long_description == ''
    assert ds.meta['parameters']['x'] == 'a parameter'
    assert ds.meta['parameters']['y'] == 'a parameter'
    assert ds.meta['returns'] == 'a return value'

    text2 = '''\
    Single-line docstring.

    And the multi-line long description...

    :param x: a parameter
    :param y: a parameter
    :returns: a return value
    '''

# Generated at 2022-06-11 21:30:44.900598
# Unit test for function parse
def test_parse():
    text = '''\
    This is the summary line.

    This is the extended description. It can span multiple paragraphs.

    This is a separate paragraph, preceded by a blank line.

    First paragraph.
    Second paragraph.

    Args:
        arg1: Type of arg1
        arg2: Type of arg2
        kwarg1: Type of kwarg1.
        kwarg2: Type of kwarg2.

    Returns:
        Description of return value

    Raises:
        TypeError: if any arguments are the wrong type
        ValueError: if any arguments are out of acceptable range
    '''

    docstring = parse(text)

    assert docstring.summary == 'This is the summary line.'

# Generated at 2022-06-11 21:30:56.906600
# Unit test for function parse

# Generated at 2022-06-11 21:31:00.146304
# Unit test for function parse
def test_parse():
    doc="""This is a doc string.

    This is not.
    """
    assert parse(doc).short_description == ""

# Generated at 2022-06-11 21:31:08.415310
# Unit test for function parse
def test_parse():
    docstring = """
    Summary line.

    Extended description.

    Returns:
        Description of return value.
    """

    parsed_docstring = parse(docstring)

    assert parsed_docstring.short_description == "Summary line."
    assert parsed_docstring.long_description == "Extended description."
    assert len(parsed_docstring.returns) == 1
    assert parsed_docstring.returns[0].description == "Description of return value."
    assert parsed_docstring.returns[0].type_name is None
    assert parsed_docstring.returns[0].name is None
    assert parsed_docstring.raises is None
    assert parsed_docstring.yields is None
    assert parsed_docstring.warns is None
    assert parsed_docstring.note is None
    assert parsed_

# Generated at 2022-06-11 21:31:18.141593
# Unit test for function parse
def test_parse():
    test = '''\
    Title
    ======

    Subtitle
    ---------

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: description of the return value.
    :raises error: explanation of error.

    '''
    docstrings = parse(test)
    assert docstrings.meta == {'arg1': 'The first argument.', 'arg2': 'The second argument.', 'returns': 'description of the return value.', 'raises': 'explanation of error.', 'title': 'Title', 'subtitle': 'Subtitle'}
    assert docstrings.content == ''

# Generated at 2022-06-11 21:31:25.631129
# Unit test for function parse
def test_parse():
    text = """
    Unit test for function parse
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:31:35.449692
# Unit test for function parse
def test_parse():
    test_val = ("Test function to test parse()\n"
                ":param x: integer 0 < x < 10\n"
                ":returns: x*10\n"
                ":raises KeyError: raises an exception")
    assert parse(test_val).summary == "Test function to test parse()"
    assert parse(test_val).params[0][0] == "x"
    assert parse(test_val).params[0][1] == "integer 0 < x < 10"
    assert parse(test_val).returns == "x*10"
    assert parse(test_val).exceptions[0][0] == "KeyError"
    assert parse(test_val).exceptions[0][1] == "raises an exception"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:31:42.507801
# Unit test for function parse
def test_parse():
    ds = """
    Unit test for function parse

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    d = parse(ds, Style.numpy)
    print(d.params)
    print(d.returns)
    return d

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:31:52.048043
# Unit test for function parse
def test_parse():
    txt = """
    This is a module docstring.

    :param path: The path to the file.
    :param mode: The mode to open the file with.
    :param buffering: The file's desired buffer size.
    """
    doc = parse(txt)
    assert doc.short_description == 'This is a module docstring.'
    assert len(doc.long_description) == 2
    assert len(doc.meta) == 3
    assert len(doc.content) == 0


if __name__ == '__main__':
    test_parse()
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:32:03.685750
# Unit test for function parse

# Generated at 2022-06-11 21:32:13.623471
# Unit test for function parse
def test_parse():
    """ Unit test for function parse
    """
    # Setup
    text = """one line summary

one line description

Args:
    name (str): name of the person
    age (int): age of the person
    location (str): location of the person

Returns:
    bool: true, if person was added, otherwise false.

Raises:
    PersonAlreadyExistsError: if a person with the same name and
        location already exists.
    """
    # Exercise
    docstring = parse(text)
    # Verify
    assert docstring.short_description == "one line summary"
    assert docstring.long_description == "one line description"
    assert docstring.args[0].arg_name == "name"
    assert docstring.args[0].arg_type == "str"

# Generated at 2022-06-11 21:32:22.076601
# Unit test for function parse
def test_parse():
    sample_docstring = '''
    :param name: The name to use.
    :param state: Whether to add state or not.
    :returns "Hello, Bob"
    :raises ImportError: When pyfiglet is not installed.
    '''
    docstring = parse(sample_docstring)
    assert docstring.params['name']['desc'] == 'The name to use.'
    assert docstring.params['state']['desc'] == 'Whether to add state or not.'
    assert docstring.returns['desc'] == '"Hello, Bob"'
    assert docstring.raises['ImportError']['desc'] == 'When pyfiglet is not installed.'

# Generated at 2022-06-11 21:32:33.549822
# Unit test for function parse
def test_parse():
    """
    Test function: parse
    """
    # Setup
    style = Style.rst
    text = """\
    Shape array to newshape.

    Parameters
    ----------
    x : array_like
    newshape : int or tuple of ints
        The new shape should be compatible with the original shape. If
        an integer, then the result will be a 1-D array of that length.
        One shape dimension can be -1. In this case, the value is
        inferred from the length of the array and remaining dimensions.

    Returns
    -------
    reshaped_array : ndarray
        This will be a new view object if possible; otherwise, it will
        be a copy. Note there is no guarantee of the *memory layout* (C- or
        Fortran- contiguous) of the returned array.
    """

    # Exercise
   

# Generated at 2022-06-11 21:32:42.116897
# Unit test for function parse
def test_parse():
    """Test parse() with different docstring styles.

    :returns: None
    """

    # Test parse().

# Generated at 2022-06-11 21:32:47.369197
# Unit test for function parse
def test_parse():
    text_google = """Summary line.
    Extended description. In some cases, this may be a multi-line
    description.
    Args:
        int_arg (int): Integer argument.
        str_arg (str): String argument.
    Returns:
        dict: Dictonary of stuff."""

    text_numpy = """Summary line.
    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    dict
        Description of return value

    """

    text_sphinx = """Summary line.
    Args:
        int_arg (int): Integer argument.
        str_arg (str): String argument.
    Returns:
        dict: Dictonary of stuff.
    """

    text

# Generated at 2022-06-11 21:32:53.106682
# Unit test for function parse
def test_parse():
    text = """Summarize the contents of a file with two
    lines (and ends with a newline)."""
    doc = Docstring()
    doc.summary = """Summarize the contents of a file
        with two lines"""
    doc.description = "(and ends with a newline)."
    assert parse(text) == doc

# Generated at 2022-06-11 21:33:00.818173
# Unit test for function parse
def test_parse():
    test_inputs = [
        ("""Test function with TypesFormater docstring.""", Style.pep257),
        ("""Test function with Google docstring.""", Style.google),
        ("""Test function with Numpy docstring.""", Style.numpy),
        ("""Test function with Default docstring.""", Style.default),
        ("""Test function with Sphinx docstring.""", Style.sphinx),
        ("""Test function with auto docstring.""", Style.auto)
    ]

    for text, style in test_inputs:
        print(parse(text, style))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:33:10.768181
# Unit test for function parse
def test_parse():
    docstring = """\
    This is one paragraph. This is another paragraph.

    :param arg1: Description of arg1.
    :param arg2: Description of arg2.
    :returns: Description of return value.
    :raises keyError: Raises an exception.
    """

    expected = Docstring(
        summary="This is one paragraph. This is another paragraph.",
        description="",
        returns="Description of return value.",
        args=[
            ("arg1", "Description of arg1."),
            ("arg2", "Description of arg2.")
        ],
        raises=[("keyError", "Raises an exception.")],
        examples=[],
    )
    assert parse(docstring) == expected

# Generated at 2022-06-11 21:33:18.844517
# Unit test for function parse
def test_parse():
    docstring = """
Parameter analyzer module
Use:
  import ParameterAnalyzer as PA
"""
    print(parse(docstring))
    docstring = """
Parameter analyzer module
Use:
  import ParameterAnalyzer as PA
  mig = PA.MOSFET(name="m1", W=100e-6, L=100e-6)
"""
    print(parse(docstring))
    docstring = """
Parameter analyzer module
Use:
  import ParameterAnalyzer as PA
  mig = PA.MOSFET(name="m1", W=100e-6, L=100e-6)
  mig.getGateInfo()
"""
    print(parse(docstring))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:33:19.958710
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-11 21:33:31.026034
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    docstring = '''
    Args:
        function (function): function for which to compute derivatives
    '''
    assert parse(docstring)[0]['type'] == 'param'
    assert parse(docstring)[0]['name'] == 'function'
    assert parse(docstring)[0]['description'] == 'function for which to compute derivatives'
    docstring = '''
    :param function: function for which to compute derivatives
    '''
    assert parse(docstring)[0]['type'] == 'param'
    assert parse(docstring)[0]['name'] == 'function'
    assert parse(docstring)[0]['description'] == 'function for which to compute derivatives'
    docstring = '''
    :param function:
        function for which to compute derivatives
    '''

# Generated at 2022-06-11 21:33:42.165563
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring

    s = GoogleDocstring(
        """This
        function atpH_G_DG only returns a positive value.

        Args:
            HA : the acid involved
            HX : the base involved (or proton acceptor)
            I : ionic strength (molar)
            zHA : the charge of the acid (-)
            zX : the charge of the base (or proton acceptor) (+)

        Returns:
            Free energy of binding of a proton in kJ/mol at the specified
            conditions
        """
    ) 
    assert s.short_description == 'This\nfunction atpH_G_DG only returns a positive value.'
    assert s.long_description == ''
    assert s.style == 'Google'
    assert s.returns.type

# Generated at 2022-06-11 21:33:53.203568
# Unit test for function parse
def test_parse():
    text = """
    A short summary of the method.

    Additional information.

    :param a: First param
    :param b: Second param
    :returns: Nothing of interest
    """
    docstring = parse(text)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta)
    print(docstring.params)
    print(docstring.returns)
    print(docstring.raises)
    print()

    text = """
    A short summary of the method.

    Additional information.

    :param a: First param
    :param b: Second param
    :returns: Nothing of interest
    :raises KeyError: raises an exception
    """
    docstring = parse(text)
    print(docstring.short_description)
   

# Generated at 2022-06-11 21:33:56.492135
# Unit test for function parse
def test_parse():
    test_docstring = '''
    This is a sample docstring
    This is the first line
    This is the second line
    '''
    print(parse(test_docstring))


# Generated at 2022-06-11 21:33:59.788224
# Unit test for function parse
def test_parse():
    assert parse(1) == 1
    assert parse(1, style=Style.google) == 1
    assert parse(1, style=Style.numpy) == 1


__all__ = (
    "Docstring",
    "ParseError",
    "parse",
)

# Generated at 2022-06-11 21:34:11.897989
# Unit test for function parse
def test_parse():
    text = '''\
    This is a
    multi-line docstring.

    :param request: A request object.
    :type request: :class:`~django.http.HttpRequest`
    :param username: The username for the user to lookup.
    :type username: str
    :returns: A :class:`~django.contrib.auth.models.User` object.
    :raises: :exc:`~django.contrib.auth.models.User.DoesNotExist`, if the
        user with that username doesn't exist.

    A space between the type and the description is mandatory.

    The first line is short.
    The second line is short too.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a multi-line docstring.'


# Generated at 2022-06-11 21:34:20.607860
# Unit test for function parse
def test_parse():
    """Test the function parse(text, style)
    """
    text = 'This is the docstring parser.\nIt consists of two parts:\n\n'\
           '1. A standalone module for parsing docstrings\n2. A Sphinx extension to integrate with Sphinx projects.'
    doc = parse(text)
    assert doc.short_description == 'This is the docstring parser.\nIt consists of two parts:'
    assert doc.long_description == '\n\n1. A standalone module for parsing docstrings\n2. A Sphinx extension to integrate with Sphinx projects.'
    assert len(doc.sections) == 0

# Generated at 2022-06-11 21:34:28.864325
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle, NumpyStyle
    test_text = \
    """
        Quick sort is a comparison sort, meaning that it can sort items of any type for which a "less-than" relation is defined.
    
        :param arr: list to be sorted
        :returns: sorted list
    """
    assert parse(test_text) == GoogleStyle(test_text)
    assert parse(test_text, Style.google) == GoogleStyle(test_text)
    assert parse(test_text, Style.numpy) == NumpyStyle(test_text)

# Generated at 2022-06-11 21:34:31.979350
# Unit test for function parse
def test_parse():
    text = "This is the example of docstring."
    res = parse(text, style = Style.numpy)
    if res == None:
        print("Parse test fail")
    else:
        print("Parse test success")

# Generated at 2022-06-11 21:34:38.169408
# Unit test for function parse
def test_parse():
    test_docstring = """
    This is a module docstring.

    This module does stuff.

    Keyword arguments:
    arg -- This is a positional argument.
    kwarg -- This is a keyword argument.

    """
    import docstring_parser
    parsed_docstring = docstring_parser.parse(test_docstring)
    print(parsed_docstring)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:34:40.418537
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:34:41.691089
# Unit test for function parse
def test_parse():
    assert parse("")
    assert parse("cs")
    assert parse("cs",style=2)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:34:50.236079
# Unit test for function parse
def test_parse():
    text1 = """
    This is a class named Add
    """
    text2 = """
    This is a class named Add
        :param alpha: the alpha value
        :param beta: the beta value
        :type alpha: int
        :type beta: int
    """
    text3 = """
    This is a class named Add
        :param alpha: the alpha value
        :type alpha: int

        :param beta: the beta value
        :type beta: int
    """
    text4 = """
    This is a class named Add
        :param alpha: the alpha value
        :param beta: the beta value
        :type alpha: int
        :type beta: int

        :returns: the result
        :rtype: int
    """

# Generated at 2022-06-11 21:34:54.330306
# Unit test for function parse
def test_parse():
  with open('/Users/rjsr/Documents/FACENS/5º SEMESTRE/TCC/ARQUIVOS/teste.txt', 'r') as myfile:
    data=myfile.readlines()
    text_teste = ''.join(data)
  parse_teste = parse(text_teste, style = Style.auto)
  print(parse_teste)
  #print(parse_teste.meta)
  #print(parse_teste.returns)
  
#test_parse()

# Generated at 2022-06-11 21:35:03.115875
# Unit test for function parse
def test_parse():
    style = Style.sphinx
    text_1 = '''
    Some text
    
    :param a: This is parameter a
    :type a: Integer or Float
    :returns: returns value
    '''
    assert parse(text_1, style).summary == 'Some text'
    assert parse(text_1, style).parameters == {'a': ('Integer or Float', 'This is parameter a', None, None)}
    assert parse(text_1, style).returns[0] == 'returns value'
    
    text_2 = '''
    Some text
    
    :param a: This is parameter a
    :type a: Integer or Float
    :returns: returns value
    :returns: returns another value
    '''
    assert parse(text_2, style).summary == 'Some text'


# Generated at 2022-06-11 21:35:17.189991
# Unit test for function parse
def test_parse():
    # Test auto style
    assign = parse("")
    assert assign.meta == {}
    assign = parse("""
    Item 1
    Item 2
    """)
    assert assign.meta == {}
    assign = parse("""
    :param x: The x coordinate
    :type x: int
    """)
    assert assign.meta == {'Parameters': ['x', 'int']}
    assign = parse("""
    @param x: The x coordinate
    @type x: int
    """)
    assert assign.meta == {'Parameters': ['x', 'int']}
    assign = parse("""
    Item 1
    Item 2
    
    @param x: The x coordinate
    @type x: int
    """)
    assert assign.meta == {'Parameters': ['x', 'int']}

# Generated at 2022-06-11 21:35:27.967074
# Unit test for function parse
def test_parse():
    text = """Examples
    ---------
    >>> a = True
    >>> if a:
    ...     print("a is True")
    a is True
    """
    docstring = parse(text, Style.numpydoc)
    assert docstring.examples == [
        '>>> a = True\n>>> if a:',
        '...     print("a is True")\na is True'
    ]
    text = """Parameters
    ----------
    filename : str
        The path of the file to write.
    """
    docstring = parse(text, Style.numpydoc)

# Generated at 2022-06-11 21:35:37.568632
# Unit test for function parse
def test_parse():
    content = '''
    brief:   A command line tool to simplify the creation of a
             new Python project.

    Usage:
    pyt new <project_name>
    pyt support <project_name>

    Options:
    -v, --version
        Show program's version number and exit
    -h, --help
        Show this help message and exit
    '''

    def test_parse_pos(content: str, pos: int):
        docstring = parse(content, pos)
        assert docstring.brief == 'A command line tool to simplify the creation of a\nnew Python project.'
        assert docstring.metadata['Usage'] == ['pyt new <project_name>', 'pyt support <project_name>']

# Generated at 2022-06-11 21:35:38.399990
# Unit test for function parse
def test_parse():
    """Unit tests for function parse."""
    pass

# Generated at 2022-06-11 21:35:43.962562
# Unit test for function parse
def test_parse():
    docstring = parse("""\
    The :class:`Series` class.

    Allows easy creation of ``Series`` objects.
    """)
    assert len(docstring.summary) == 2
    assert docstring.meta['class'] == 'Series'
    assert docstring.description == 'Allows easy creation of ``Series`` objects.'


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:35:55.725552
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    from docstring_parser.styles import STYLES
    from docstring_parser.styles import Style
    import pytest
    #print(parse(text, style))
    for style in STYLES.keys():
        with pytest.raises(ParseError):
            parse("", style)

    # Test auto style detection
    from textwrap import dedent
    docstring = dedent("""
    This is a
    single line
    docstring.
    """).lstrip()
    assert parse(docstring).short_description == docstring

    docstring = dedent("""
    This is a
    single line
    docstring.

    Parameters
    ----------
    foo : str
        foo bar
    """).lstrip()
    assert parse(docstring).short_description

# Generated at 2022-06-11 21:35:56.906786
# Unit test for function parse

# Generated at 2022-06-11 21:36:07.928307
# Unit test for function parse
def test_parse():
    text = """
    A short description.
    A second line of the description.

    :param arg: The first argument.
    :param arg2: The second argument.
    :param list arg3: A list argument.
    :param dict arg4: A dict argument.
    :param arg5: Another argument.
    :type arg5: bool
    :returns: Description of the return value.
    :rtype: str
    """
    print(parse(text))
    # Docstring(summary='A short description.\nA second line of the description.\n\n', body='', 
    # meta={'returns': ('Description of the return value.', 'str'), 
    #      'param': (('arg', 'The first argument.'), ('arg2', 'The second argument.'), ('list arg3', 'A list argument

# Generated at 2022-06-11 21:36:17.548396
# Unit test for function parse
def test_parse():
    '''docstring parsing test'''
    func_doc = '''Docstring: This is a test function
    :param name1: first parameter
    :param name2: second parameter
    :param name3: third parameter
    :return: the return value
    :rtype: float
    '''
    doc = parse(func_doc, style=Style.numpy)
    assert doc.short_description == 'Docstring: This is a test function'
    assert doc.long_description == 'Docstring: This is a test function'
    assert doc.meta['parameters']['name1'] == 'first parameter'
    assert doc.meta['parameters']['name2'] == 'second parameter'
    assert doc.meta['parameters']['name3'] == 'third parameter'