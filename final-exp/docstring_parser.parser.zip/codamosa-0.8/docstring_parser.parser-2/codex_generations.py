

# Generated at 2022-06-11 21:26:24.074470
# Unit test for function parse
def test_parse():
    docstring = """Short summary.

    Longer description.

    Args:
        arg1 (int): Description of `arg1`.
        arg2 (str): Description of `arg2` that
                    spans multiple lines.

    Returns:
        bool: Description of return value.
    """
    doc = parse(docstring,Style.numpy)
    assert doc.short_description == "Short summary."
    assert doc.long_description == "Longer description."
    assert doc.tags == [
        ("Args", {
            "arg1": "Description of `arg1`.",
            "arg2": "Description of `arg2` that spans multiple lines."
        }),
        ("Returns", {
            "return": "Description of return value."
        })
    ]

# Generated at 2022-06-11 21:26:33.755935
# Unit test for function parse
def test_parse():
    # test for parse() with python style
    docstring = parse("""
This function does something.

:param foo: A positional argument
:keyword bar: A keyword argument
:returns: Description of return value
:raises Exception: Because you shouldn't do that
""")
    assert docstring.short_description == "This function does something."
    assert [p.arg_name for p in docstring.params] == ['foo']
    assert [p.arg_name for p in docstring.keyword_args] == ['bar']
    assert docstring.returns == "Description of return value"
    assert docstring.raises[0].arg_name == "Exception"
    assert docstring.returns == "Description of return value"



# Style test for function parse

# Generated at 2022-06-11 21:26:41.989648
# Unit test for function parse
def test_parse():
    import docstring_parser
    docstring = """One line summary.

    Extended description.

    :param arg1: Description of arg1
    :type arg1: str
    :param arg2: Description of arg2
    :type arg2: int, optional
    :returns: Description of return value
    :rtype: bool
    :raises keyError: Description of exception
    """

    d = docstring_parser.parse(docstring)
    assert d.short_description == "One line summary."

# Generated at 2022-06-11 21:26:46.937603
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = '''\
    """
    test_parse

    Arguments:
        param1 (int): This is the first param.

    Returns:
        bool: This is a description of what is returned.

    """
    '''
    assert parse(text).summary == 'test_parse'
    assert parse(text,style=Style.rst).summary == 'test_parse'



# Generated at 2022-06-11 21:26:58.293466
# Unit test for function parse
def test_parse():
    """
    Simple Unit test for function parse

    ..warning: This unit tes is for function parse only.
    """
    class Test(Docstring):

        def __init__(self, meta=None, short_description=None, long_description=None,
                 extras=None):

            super().__init__(meta, short_description, long_description, extras)
            self.meta = meta
            self.short_description = short_description
            self.long_description = long_description
            self.extras = extras

        def __eq__(self, other):
            if not isinstance(other, Test):
                return False

# Generated at 2022-06-11 21:27:09.773223
# Unit test for function parse
def test_parse():
    text = ""
    basic = parse(text)
    assert basic.short_description == ''
    assert basic.long_description == ''
    assert basic.meta == {}

    text = "a simple function"
    basic = parse(text)
    assert basic.short_description == 'a simple function'
    assert basic.long_description == ''
    assert basic.meta == {}

    text = """a simple function
    with a long description
    spanning multiple lines
    """
    basic = parse(text)
    assert basic.short_description == 'a simple function'
    assert basic.long_description == 'with a long description\n' + \
        'spanning multiple lines'
    assert basic.meta == {}


# Generated at 2022-06-11 21:27:16.445891
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    assert parse.__doc__ == parse.__name__
    try:
        parse("")
    except ParseError:
        pass
    else:
        assert False


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:27:28.393591
# Unit test for function parse
def test_parse():
    text = """One line summary.
    Extended description.
    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value
    """
    d = parse(text, style=Style.numpy)
    assert d.short_description == "One line summary."
    assert d.long_description == "Extended description."
    assert d.returns.type_name == "bool"
    assert d.returns.description == "Description of return value"
    assert len(d.args) == 2
    assert d.args[0].name == "arg1"
    assert d.args[0].type_name == "int"
    assert d.args[0].description == "Description of arg1"

# Generated at 2022-06-11 21:27:35.670460
# Unit test for function parse
def test_parse():
    ds = parse("""a
b
c
""")
    assert ds.short_description == "a"
    assert ds.long_description == "b"
    assert ds.meta == {'c'}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:27:44.429982
# Unit test for function parse
def test_parse():
    print("Testing parse(text, style): ")
    docstring = """\
A text.
Paragraph
:param arg1: arg1 doc
:type arg1: str
:param arg2: arg2 doc
:type arg2: int
:returns: response
:rtype: str
:raises blabla: blabla
"""
    d = parse(docstring)

    assert d.short_description == "A text."
    assert d.long_description == "Paragraph\n"
    assert d.meta["args"] == [
        ("arg1", "str", "arg1 doc"),
        ("arg2", "int", "arg2 doc")
    ]
    assert d.meta["returns"] == ("response", "str")
    assert d.meta["rtype"] == "str"
    assert d.meta

# Generated at 2022-06-11 21:27:59.564249
# Unit test for function parse
def test_parse():
    """Test fuction parse"""
    a = parse('''
    This is a summary.
    ''')
    result = {'summary': 'This is a summary.', 'extended_summary': None, 'indented_wrapped_lines': [], 'empty_lines_after_summary': 0, 'yields': None, 'raises': None, 'returns': None}
    assert a.__dict__ == result

    a = parse('''
    This is a summary.
    This is an extended_summary.
    ''')

# Generated at 2022-06-11 21:28:08.430294
# Unit test for function parse
def test_parse():
    text = "This docstring has no style"
    assert parse(text) == Docstring(text = text, sections = [], meta = {})
    text = '''This docstring has google style

:param text: docstring text to parse
:returns: parsed docstring representation
'''
    assert parse(text) == Docstring(text = text, sections = [], meta = {'returns': 'parsed docstring representation', 'param': 'docstring text to parse'})
    text = '''This docstring has numpy style

Parameters
----------
text : str
    docstring text to parse

Returns
-------
Docstring
    parsed docstring representation
'''

# Generated at 2022-06-11 21:28:19.322409
# Unit test for function parse
def test_parse():
    print("test_parse")
    docstring = r"""Short description.

    Long description.

    :param arg1: Description of arg1
    :param arg2: Description of arg2
    :type arg1: int, float,...
    :type arg2: str
    :raises keyError: raises Error
    :returns: Description of return value
    :rtype: int, float

    """

    parsed_docstring = parse(docstring)

    print(parsed_docstring)
    print(parsed_docstring.short_description)
    print(parsed_docstring.long_description)
    print(parsed_docstring.params)
    print(parsed_docstring.returns)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:28:31.329905
# Unit test for function parse

# Generated at 2022-06-11 21:28:32.769520
# Unit test for function parse
def test_parse():
    assert parse('') is not None

# Generated at 2022-06-11 21:28:43.907387
# Unit test for function parse
def test_parse():
    assert (
        parse(
            """\
    One-line short summary.

    Extended description.

    :param name: The name to say a greeting to
    :type name: str
    :param quiet: Whether to print or not
    :type quiet: bool
    :returns: None
    :raises keyerror: raises an exception
    """
        ).short_description
        == "One-line short summary."
    )

# Generated at 2022-06-11 21:28:55.977005
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("")
    assert parse("\n") == Docstring("\n")
    assert parse("  \n") == Docstring("  \n")
    assert parse("\n\n") == Docstring("\n\n")

    assert parse("docs") == Docstring("docs\n")

    assert parse("docs\n") == Docstring("docs\n")
    assert parse("docs\n\n") == Docstring("docs\n")
    assert parse("docs\n\n\n") == Docstring("docs\n")

    assert parse("  docs\n") == Docstring("  docs\n")
    assert parse("  docs\n\n") == Docstring("  docs\n")
    assert parse("  docs\n\n\n") == Docstring("  docs\n")


# Generated at 2022-06-11 21:29:06.862687
# Unit test for function parse
def test_parse():
    docstring = '''
    First line.

    Parameters
    ----------
    x : int
        The first param.
    y : str
        The second param.

    Returns
    -------
    int
        Something.
    '''
    doc = parse(docstring, style=Style.numpy)
    assert doc.short_description == "First line."
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert len(doc.returns) == 1
    assert doc.returns[0].name == "Something."
    assert doc.returns[0].type_name == "int"
    assert doc.returns[0].desc == ""
    assert doc.returns[0].default is None
    assert doc.metadata['section_order'] == ['Parameters', 'Returns']

    docstring

# Generated at 2022-06-11 21:29:15.948531
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import STYLES

    assert parse('') == Docstring('', args=())
    assert parse('', style=Style.numpy).args == ()

    assert parse('''
short descr

long descr''') == Docstring('short descr', 'long descr', args=())

    assert parse('''
short descr

long descr''', style=Style.numpy).args == ()

    assert parse('''
short descr

long descr

Args:
    arg1: blah blah blah.
''') == Docstring('short descr', 'long descr', args=('arg1',))


# Generated at 2022-06-11 21:29:28.034246
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = '''    """blabla \n\nblablabla.

    :param df: bla bla
    :type df: pandas
    :returns: bla bla
    :raises keyError: raises an exception
    """
    '''
    docstring = parse(text)
    assert docstring.short_description == "blabla"
    assert docstring.long_description == "blablabla."
    assert docstring.returns == "bla bla"
    assert docstring.parameters == {"df": "bla bla"}
    assert docstring.return_type == {"returns": "pandas"}
    assert docstring.raises == {"keyError": "raises an exception"}

# Generated at 2022-06-11 21:29:33.730437
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:29:38.036923
# Unit test for function parse
def test_parse():
    """Unit test to test the parse function"""
    test_docstring = """Parse the docstring into its components.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """
    print(parse(test_docstring))

# Generated at 2022-06-11 21:29:50.246639
# Unit test for function parse
def test_parse():
    """
    Test function parse
    """
    import pytest

# Generated at 2022-06-11 21:29:56.073263
# Unit test for function parse
def test_parse():
    text = """Complex number field.
    
    Attributes:
        real (int): The real part of complex number.
        imag (int): The imaginary part of complex number.
    
    """
    print(parse(text, style=Style.numpy))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:30:07.262296
# Unit test for function parse
def test_parse():
    """
    Testing the parse method
    """
    assert parse(
        '''
        this is a short description
        '''
    ) == Docstring(
        short_description='this is a short description'
    )

    assert parse(
        '''
        this is a short description

        and this is a long description
        '''
    ) == Docstring(
        short_description='this is a short description',
        long_description='and this is a long description'
    )


# Generated at 2022-06-11 21:30:17.747388
# Unit test for function parse
def test_parse():
    docstring = '''A function that does nothing.

    :param int a: A number
    :return: Nothing
    :raise TypeError: when invalid type is provided'''

    assert parse(docstring).long_description == "A function that does nothing."
    assert parse(docstring).params[0].name == "a"
    assert parse(docstring).params[0].type_name == "int"
    assert parse(docstring).params[0].description == "A number"
    assert parse(docstring).returns.description == "Nothing"
    assert parse(docstring).exceptions[0].type_name == "TypeError"
    assert parse(docstring).exceptions[0].description == "when invalid type is provided"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:30:27.102771
# Unit test for function parse
def test_parse():
    docstring = parse(text = '''
    """Example module.
    
    This is a longer description. It can be several lines.
    
    Attributes:
        attr1 (int): Description of `attr1`.
        attr2 (str): Description of `attr2`.
    
    """
    ''')

    assert(docstring.short_description == "Example module.")
    assert(len(docstring.long_description) == 2)
    assert(docstring.long_description[0] == "This is a longer description. It can be several lines.")
    assert(docstring.long_description[1] == '')
    assert(len(docstring.meta) == 2)
    assert(docstring.meta[0].name == "attr1")
    assert(docstring.meta[0].type_name == "int")

# Generated at 2022-06-11 21:30:33.420082
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__

    assert docstring.short_description == "Parse the docstring into its components."
    assert len(docstring.long_description) == 3
    assert docstring.long_description[0] == ":param text: docstring text to parse"
    assert docstring.long_description[1] == ":param style: docstring style"
    assert docstring.long_description[2] == ":returns: parsed docstring representation"


# Generated at 2022-06-11 21:30:36.683489
# Unit test for function parse
def test_parse():
    import tempfile

# Generated at 2022-06-11 21:30:40.401291
# Unit test for function parse
def test_parse():
    text="""
    """
    assert(len(parse(text).meta) == 0)
    assert(len(parse(text).desc) == 0)
    assert(len(parse(text).sections) == 0)
    assert(parse(text).style == Style.google)

# Generated at 2022-06-11 21:30:57.059992
# Unit test for function parse
def test_parse():
    text1 = """\
        aaa
        bbb
        ccc
        """
    style1 = Style.google
    parsed_docstring = parse(text1, style1)
    assert parsed_docstring.short_description == 'aaa'
    assert parsed_docstring.long_description == 'bbb'
    assert parsed_docstring.meta['ccc'] == ''
    text2 = """\
        aaa
        bbb
        ccc
        """
    style2 = Style.numpy
    parsed_docstring = parse(text2, style2)
    assert parsed_docstring.short_description == 'aaa'
    assert parsed_docstring.long_description == 'bbb'
    assert parsed_docstring.meta['ccc'] == ''

# Generated at 2022-06-11 21:31:07.033254
# Unit test for function parse
def test_parse():
    res = parse(r'''Display a message on the screen and wait for the user to
    press a key.

    :param msg: message to be displayed
    :type msg: str
    :param wait: message to be displayed
    :type wait: bool
    :returns: pressed key
    :rtype: str
    ''')
    yield assertEqual, len(res.params), 2
    yield assertEqual, len(res.returns), 1
    res = parse(r'''Display a message on the screen and wait for the user to
    press a key.

    Parameters
    ----------
    msg : str
        message to be displayed
    wait : bool
        message to be displayed
    Returns
    -------
    str
        pressed key
    ''')
    yield assertEqual, len(res.params), 2
   

# Generated at 2022-06-11 21:31:07.780387
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-11 21:31:19.428574
# Unit test for function parse
def test_parse():
	assert parse("""This is a class.
	""" + """
	:param x: parameter x
	:return: the return value
	:raises Exception: raises exception
	""", Style.sphinx).returns == 'the return value'
	assert parse("""This is a class.
	""" + """
	:param x: parameter x
	:return: the return value
	:raises Exception: raises exception
	""", Style.google).returns == 'the return value'
	assert parse("""This is a class.
	""" + """
	:param x: parameter x
	:return: the return value
	:raises Exception: raises exception
	""", Style.numpy).returns == 'the return value'

# Generated at 2022-06-11 21:31:25.483268
# Unit test for function parse
def test_parse():
    text = '''\
    :param name: The name to use.
    :type name: str.
    :param state: Whether to use state.
    :type state: bool.
                                                                                                                                                                                                                                                                                                       '''
    result = parse(text)
    print(result.params)

test_parse()

# Generated at 2022-06-11 21:31:30.577270
# Unit test for function parse
def test_parse():
    doc = """
	def parse(text: str, style: Style = Style.auto) -> Docstring:
    """
    parsed_data = parse(doc)
    assert(parsed_data.summary == 'def parse(text: str, style: Style = Style.auto) -> Docstring:')

# Generated at 2022-06-11 21:31:32.385358
# Unit test for function parse
def test_parse():
    text_test = "This is my text"
    style_test = Style.auto
    assert parse(text_test, style_test) is None

# Generated at 2022-06-11 21:31:34.984483
# Unit test for function parse
def test_parse():
    # make sure function parse works
    assert parse('test') == parse('test', style='google')

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:31:46.172810
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary='', description='', meta={})
    # With one line summary
    assert parse("Summary.") == Docstring(summary='Summary.',
                                          description='',
                                          meta={})

    # With one line summary and description
    assert parse("Summary.Description.") == Docstring(summary='Summary.',
                                                      description='Description.',
                                                      meta={})

    # With one line summary, description, and metadata
    assert parse("Summary.Description.Author: Me.") == Docstring(
        summary='Summary.',
        description='Description.',
        meta={'author': 'Me.'}
    )
    # With one line summary, description, and multiple metadata

# Generated at 2022-06-11 21:31:55.073327
# Unit test for function parse
def test_parse():
    from .styles.google import parse as gp
    from .styles.numpy import parse as np
    assert parse('hello') == gp('hello')
    assert parse('hello') == np('hello')
    class TestParseError(ParseError): pass
    def t(s): raise TestParseError
    import docstring_parser.styles as ds
    ds.STYLES['test'] = t
    try:
        assert parse('hello', style='test') == gp('hello')
        assert parse('hello', style='test') == np('hello')
    finally:
        del ds.STYLES['test']

# Generated at 2022-06-11 21:32:08.549833
# Unit test for function parse
def test_parse():
    assert parse('\n') == Docstring(short_description=None, long_description=None, meta=None)
    assert parse('Hello\n') == Docstring(short_description='Hello', long_description=None, meta=None)
    assert parse('Hello\nthis is <b>bold</b>') == Docstring(short_description='Hello', long_description='this is <b>bold</b>', meta=None)
    assert parse('\n\tHello\n\tthis is <b>bold</b>') == Docstring(short_description='Hello', long_description='this is <b>bold</b>', meta=None)

# Generated at 2022-06-11 21:32:11.397929
# Unit test for function parse
def test_parse():
    text = """Takes two arguements.\n"""
    assert str(parse(text)) == text

# Generated at 2022-06-11 21:32:14.406937
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring
    '''
    docobj = parse(docstring)
    assert(docobj.short_description == 'This is a docstring')

# Generated at 2022-06-11 21:32:19.961068
# Unit test for function parse
def test_parse():
    doc = """The core functionality of this library is to parse docstrings.

:param arg1: The first argument
:type arg1: type
:param arg2: The second argument
:type arg2: type
:returns: What the function returns
:rtype: type
"""
    doc_parser = parse(doc)
    doc_parser.short_description

test_parse()

# Generated at 2022-06-11 21:32:21.617845
# Unit test for function parse
def test_parse():
    """Test parsing a docstring"""
    expected = parse(test_docstring)
    print(expected)



# Generated at 2022-06-11 21:32:30.690674
# Unit test for function parse
def test_parse():
    ds = parse("""
        This is a docstring
        with some paragraphs.

        Parameters
        ----------
        name : str
            name of the function
        age : int
            age of the function
        """)

    assert ds.short_description == "This is a docstring with some paragraphs."
    assert len(ds.long_description) == 1
    assert ds.meta["Parameters"][0].arg_name == "name"
    assert str(ds.meta["Parameters"][0].arg_type) == "<class 'str'>"

# Generated at 2022-06-11 21:32:40.118962
# Unit test for function parse
def test_parse():
    # Test: null
    text = ""
    try:
        Docstring(text)
    except ParseError as e:
        assert str(e) == "Failed to parse docstring."
    else:
        assert False, 'The expected exception did not occur.'
    # Test: single line
    text = "docstring_parser."
    with open("./test.txt", "w") as f:
        f.write(text)
    try:
        Docstring(text)
    except ParseError as e:
        assert str(e) == "Failed to parse docstring."
    else:
        assert False, 'The expected exception did not occur.'
    # Test: empty
    text = "\n"

# Generated at 2022-06-11 21:32:48.905187
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    docstring_test = """This function computes the sum of two numbers.

Args:
    x: first number
    y: second number

Returns:
    the sum of two numbers
"""
    docstring = parse(docstring_test)
    assert docstring.short_description == "This function computes the sum of two numbers."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[1].arg_name == "y"
    assert docstring.returns.description == "the sum of two numbers"


# Generated at 2022-06-11 21:32:58.948091
# Unit test for function parse
def test_parse():    
    from docstring_parser.styles import GoogleDocstring, NumpyDocstring
    import os
    # Check if the output matches for each style:
    for style in [Style.google, Style.numpy]:
        fname = os.path.join('tests', 'test_style_%s_output.txt' % style.name)
        with open(fname, 'r') as f:
            expected_output = f.read()
    
        if style == Style.google:
            actual_output = str(GoogleDocstring(expected_output))
        else:
            actual_output = str(NumpyDocstring(expected_output))
        
        assert expected_output == actual_output

if __name__ == '__main__':
    # Unit test
    test_parse()

# Generated at 2022-06-11 21:33:06.821193
# Unit test for function parse
def test_parse():
    """Function for testing parse"""
    try:
        parsed = parse("""
        This is a function which does something
        :param: x A number
        :param: y Another number
        :returns: The sum of x and y
        :raises: TypeError if the inputs are not numbers""")
        print(parsed)
    except Exception as e:
        print(str(e))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:33:24.429878
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google, Numpy, Multiqc
    assert parse("Test docstring") == Docstring("Test docstring")
    assert parse("Test docstring", style=Style.google) == Google("Test docstring")
    assert parse("Test docstring", style=Style.numpy) == Numpy("Test docstring")
    assert parse("Test docstring", style=Style.multiqc) == Multiqc("Test docstring")

# Generated at 2022-06-11 21:33:34.773335
# Unit test for function parse

# Generated at 2022-06-11 21:33:37.675592
# Unit test for function parse
def test_parse():
    from doctest import testmod
    testmod()


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:33:42.064861
# Unit test for function parse
def test_parse():

    def __test(text, style):
        parsed = parse(text, Style.auto)
        assert (parsed.__dict__ == style(text).__dict__)

    for text, style in PARSE_TEST_CASES:
        __test(text, style)

# String representation of function parse

# Generated at 2022-06-11 21:33:47.763238
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    text = """This function parses a text
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    rets = parse(text)
    if rets.style == 'google':
        print('pass!')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:33:57.595047
# Unit test for function parse
def test_parse():
    text = """
This is the module docstring.

This is the second line.

Args:
    param1 (int): The first parameter.
    param2 (str): The second parameter.
Returns:
    bool: The return value. True for success, False otherwise.
"""

    doc = parse(text)
    assert doc.short_description == 'This is the module docstring.'
    assert doc.long_description == 'This is the second line.'
    assert len(doc.meta) == 3
    assert len(doc.params) == 2
    assert len(doc.returns) == 1
    assert doc.returns[0].description == 'The return value. True for success, False otherwise.'

# Generated at 2022-06-11 21:34:08.297690
# Unit test for function parse
def test_parse():
    # Check possible valid inputs
    doc = """\
        This is a test module.

        This is a test function.
        :param str first_arg: first argument
        :param str second_arg: second argument
        :return: test value
        :rtype: bool
        """


# Generated at 2022-06-11 21:34:19.932142
# Unit test for function parse
def test_parse():
    docstring = """One line summary.
Extended description.

:param arg1: Description of arg1
:type arg1: str
:param arg2: Description of arg2
:type arg2: int, optional
:returns: Description of return value
:rtype: bool
"""
    d = parse(docstring)
    assert d.short_description == 'One line summary.'
    assert d.long_description == 'Extended description.'
    assert d.meta['arg1'].arg_type == 'str'
    assert d.meta['arg2'].arg_type == 'int, optional'
    assert d.meta['arg2'].description == 'Description of arg2'
    assert d.returns.arg_type == 'bool'
    assert d.returns.description == 'Description of return value'


# Generated at 2022-06-11 21:34:22.724094
# Unit test for function parse
def test_parse():
    docstring = """
        This is a docstring
        """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "This is a docstring"


# Generated at 2022-06-11 21:34:27.344687
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    from doctest import testmod
    from .__main__ import __doc__
    import sys
    module = sys.modules[__name__]
    result = testmod(module, verbose=True)
    assert result.failed == 0, result

# Generated at 2022-06-11 21:34:38.612963
# Unit test for function parse
def test_parse():
    text = '''
    :param arg_name: arg description
    :param arg2_name: arg2 description
    :returns: description of return value
    '''
    assert parse(text) == parse(text, style=Style.numpy)
    text = '''
    @param arg_name arg description
    @param arg2_name arg2 description
    @return description of return value
    '''
    assert parse(text) == parse(text, style=Style.google)

# Generated at 2022-06-11 21:34:41.668986
# Unit test for function parse
def test_parse():
    text = '''Blockquote format
    '''
    print(parse(text, Style.blockquote))
# Main function
if __name__=='__main__':
    test_parse()

# Generated at 2022-06-11 21:34:50.174113
# Unit test for function parse
def test_parse():
    text = """
    This function does something
    something else
    """
    doc = parse(text)
    assert doc.summary == "This function does something"
    assert doc.description == "something else"

    text = """
    This function does something.
    """
    doc = parse(text)
    assert doc.description == None

    text = """
    Brief description of my function.

    Longer description.
    """
    doc = parse(text)
    assert doc.summary == "Brief description of my function."
    assert doc.description == "Longer description."

    text = """
    Arguments:
        param1: The first parameter.
        param2: The second parameter.

    Returns:
        Something.
    """
    doc = parse(text)

# Generated at 2022-06-11 21:34:54.281929
# Unit test for function parse
def test_parse():
    # Function signature: parse(text: str, style: Style = Style.auto) -> Docstring
    text = """\
This is a docstring
  Args:
    arg1: arg1 description
    arg2: arg2 description
  Returns: None
"""
    # NOTE: bad indentation, no space after colon
    text = """\
This is a docstring
Args:
  arg1:arg1 description
  arg2:arg2 description
Returns:
  None
"""
    docstring = parse(text)


# Generated at 2022-06-11 21:35:03.116101
# Unit test for function parse
def test_parse():
    from textwrap import dedent

    # this is a sample docstring in Numpy format
    example_docstring = """
        One line summary.

        Extended description.

        Parameters
        ----------
        arg1 : int
            Description of `arg1`
        arg2 : str
            Description of `arg2`

        Returns
        -------
        bool
            Description of return value

        """

    expected_docstring = Docstring(
        content='One line summary.\n\nExtended description.',
        args=[
            ('arg1', 'int', 'Description of `arg1`'),
            ('arg2', 'str', 'Description of `arg2`')
        ],
        returns=('bool', 'Description of return value'),
        raise_exprs=[],
        others=[]
    )


# Generated at 2022-06-11 21:35:16.196144
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    docstring = '''
    A short summary.

    A longer description.

    :param int arg1: the first value
    :param str arg2: the second value
    :returns: description of return value
    :raises KeyError: raises an exception
    '''
    docstring_obj = parse(docstring, Style.google)
    print(docstring_obj)
    print(docstring_obj.short_description)
    print(docstring_obj.long_description)
    print(docstring_obj.params)
    print(docstring_obj.returns)
    print(docstring_obj.exceptions)
    print(docstring_obj.meta)

if __name__ == "__main__":
    import doctest
    doctest.testmod()
   

# Generated at 2022-06-11 21:35:18.465865
# Unit test for function parse
def test_parse():
    text = '''\
    Top line.
    Bottom line.'''

    assert parse(text) == Docstring(summary='Top line.', description='Bottom line.')

# Generated at 2022-06-11 21:35:29.997205
# Unit test for function parse
def test_parse():
    from docstring_parser.parse import parse
    test = "Takes the input and returns the output"
    docstring = parse(test)
    assert docstring.short_description == "Takes the input and returns the output"
    test = ":param int num1: The first number\n:param int num2: The second number.\n:param int num3: The third number."
    docstring = parse(test)
    assert docstring.params["num1"].description == "The first number"
    assert docstring.params["num2"].description == "The second number."
    assert docstring.params["num3"].description == "The third number."
    test = ":return: The return of the function."
    docstring = parse(test)
    assert docstring.returns.description == "The return of the function."


# Generated at 2022-06-11 21:35:35.291719
# Unit test for function parse
def test_parse():
    text = '''
    def test():
        \"\"\"
        This is a docstring.
        \"\"\"
    '''
    assert(parse(text)==Docstring('This is a docstring.', '', set(), {}))
    assert(parse('This is an other docstring.')==Docstring('This is an other docstring.', '', set(), {}))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:42.071130
# Unit test for function parse
def test_parse():
    text = """
    This function solves the system of linear scalar equations, with the LU \
decomposition without pivoting.

    Parameters
    ----------
    A : (M, M) array_like
        Square matrix.
    b : {(M,), (M, K)} array_like
        Right-hand side matrix in ``A x = b``.

    Returns
    -------
    x : {(M,), (M, K)} ndarray
        Solution to the system.
    x : {(M,), (M, K)} ndarray
        Solution to the system.
    True

    Raises
    ------
    ValueError
        If `A` is singular within machine precision.
    """
    print(parse(text))

# Generated at 2022-06-11 21:35:57.509116
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """
Parse the docstring into its components.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
"""
    obj = parse(text)
    assert obj.short_description == 'Parse the docstring into its components.'
    assert obj.short_description_markup is None
    assert len(obj.long_description) == 3
    assert obj.long_description[0] == ''
    assert obj.long_description[1] == ':param text: docstring text to parse'
    assert obj.long_description[2] == ':param style: docstring style'
    assert len(obj.meta) == 0


# Generated at 2022-06-11 21:36:01.199920
# Unit test for function parse
def test_parse():
    text = """
    Hello this is a docstring
    """
    doc = parse(text)
    assert doc.short_description == 'Hello this is a docstring'



# Generated at 2022-06-11 21:36:11.282886
# Unit test for function parse
def test_parse():
    text="""
This is a module docstring
and a epilog.

:param para1: Paragraph 1
:param pa2: Paragraph 2

:type para1: string
:type pa2: int, float
:return: None

:raises TypeError: If para1 is not string
:raises RuntimeError: If pa2 is not in 1..10
"""

    doc = parse(text)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.parameters)
    print(doc.returns)
    print(doc.epilog)
    print(doc.examples)
    print(doc.versionadded)
    print(doc.deprecated)
    print(doc.meta)
    print(doc.unknown_sections)