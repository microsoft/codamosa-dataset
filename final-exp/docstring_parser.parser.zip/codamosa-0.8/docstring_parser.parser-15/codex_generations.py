

# Generated at 2022-06-11 21:26:23.223318
# Unit test for function parse
def test_parse():
    """Test function parse."""

    assert parse('a_function', Style.sphinx).long_description == '(test_parse in module test_parser) a_function'
    assert parse('a_function', Style.numpy).long_description == '(test_parse in module test_parser) a_function'
    assert parse('a_function', Style.google).long_description == '(test_parse in module test_parser) a_function'

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_parse()

# Generated at 2022-06-11 21:26:33.895716
# Unit test for function parse
def test_parse():
    docstring = """Summary line.
Extended description.
Args:
    param1: The first parameter.
    param2: The second parameter.
Returns:
    bool: The return value. True for success, False otherwise.

"""
    p = parse(docstring)
    assert p.short_description == 'Summary line.'
    assert p.long_description == 'Extended description.'
    assert p.returns.type_name == 'bool'
    assert p.returns.description == 'The return value. True for success, False otherwise.'
    assert len(p.parameters) == 2
    assert p.parameters[0].arg_name == 'param1'
    assert p.parameters[0].description == 'The first parameter.'
    assert p.parameters[1].arg_name == 'param2'
    assert p.param

# Generated at 2022-06-11 21:26:45.187322
# Unit test for function parse
def test_parse():
    docstring_1 = """Summary line.

    Extended description.

    Args:
        arg1: Description of arg1
        arg2: Description of arg2

    Returns:
        Description of return value
    """
    docstring_2 = """Summary line.

    Extended description.

    param arg1: Description of arg1
    param arg2: Description of arg2

    return: Description of return value
    """
    docstring_3 = """Summary line.

    Extended description.

    :param arg1: Description of arg1
    :param arg2: Description of arg2

    :returns: Description of return value
    """
    docstring_4 = """Summary line.

    Extended description.

    @param arg1: Description of arg1
    @param arg2: Description of arg2

    @return: Description of return value
    """

# Generated at 2022-06-11 21:26:48.543551
# Unit test for function parse
def test_parse():
    text = """
this is the summary

this is the description
""".strip()

    docstring = parse(text)
    assert docstring.summary == "this is the summary"
    assert docstring.description == "this is the description"



# Generated at 2022-06-11 21:26:58.861675
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring(short_description='', long_description='',
                                  meta={})
    assert parse(' ') == Docstring(short_description='',
                                   long_description='', meta={})
    assert parse('\t') == Docstring(short_description='',
                                    long_description='', meta={})
    assert parse('foo') == Docstring(short_description='foo',
                                     long_description='', meta={})
    assert parse('\n') == Docstring(short_description='',
                                    long_description='\n', meta={})
    assert parse('\n\n') == Docstring(short_description='',
                                      long_description='\n\n', meta={})

# Generated at 2022-06-11 21:27:06.457995
# Unit test for function parse
def test_parse():
    text = """
    The Powerball module.
    :param size: Powerball size.
    :param max: Highest number.
    """
    doc = parse(text)
    assert(doc.short_description == 'The Powerball module.')
    assert(len(doc.params) == 2)
    assert(doc.params['size'].desc == 'Powerball size.')
    assert(doc.params['max'].desc == 'Highest number.')

# Generated at 2022-06-11 21:27:07.466805
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:27:18.235491
# Unit test for function parse
def test_parse():
    text = \
"""This is a sum function.

    :param a: first number
    :param b: second number
    :type a: int
    :type b: int
    :return: sum of a, b
    :rtype: float
"""
    d = parse(text)
    assert d.short_description == "This is a sum function."
    assert d.long_description == ""
    assert d.meta == {
            "param a": "first number",
            "param b": "second number",
            "type a": "int",
            "type b": "int",
            "return": "sum of a, b",
            "rtype": "float"}


# Generated at 2022-06-11 21:27:29.481167
# Unit test for function parse

# Generated at 2022-06-11 21:27:38.584235
# Unit test for function parse
def test_parse():
    text = """One line summary.
   
    Extended description.
   
    :param foo: description
    :type foo: :py:class:`int`
    :returns: description
    :rtype: :py:class:`str`
    :raises type: reason
    """
    docstring = parse(text, style=Style.numpy)
    assert docstring.extended_description == "Extended description."
    assert docstring.meta['params']['foo']['type'] == ':py:class:`int`'

# Generated at 2022-06-11 21:27:49.222855
# Unit test for function parse
def test_parse():
    """Unit test to demonstrate example use."""
    assert parse("""
    This is a docstring.

    :param p1: parameter 1
    :param p2: parameter 2
    :returns: the result
    """) == parse("""
    :param p1: parameter 1
    :param p2: parameter 2
    :returns: the result

    This is a docstring.
    """)

# Generated at 2022-06-11 21:27:59.726926
# Unit test for function parse
def test_parse():
    text = """
    :param x: this is a parameter
    :return: asdf
    """
    res = parse(text, Style.numpy)
    assert res.short_description == ""
    assert res.long_description == ""
    assert res.meta['param'] == ['x: this is a parameter']
    assert res.meta['return'] == ['asdf']

    text = """
    This is a short description.

    This is a long description.
    """

    res = parse(text, Style.google)
    assert res.short_description == "This is a short description."
    assert res.long_description == "This is a long description."
    assert res.meta == {}


# Generated at 2022-06-11 21:28:06.040010
# Unit test for function parse
def test_parse():
    test = parse("""Test.
    :param int x: first parameter.
    :param str y: second parameter.
    :returns: something.
    :rtype: int or str.
    """)

    if test.short_description != "Test.":
        raise ParseError("Error parsing")
    if len(test.params) < 2:
        raise ParseError("Error parsing")
    if test.params[0].annotation != "int":
        raise ParseError("Error parsing")

# Generated at 2022-06-11 21:28:07.181499
# Unit test for function parse
def test_parse():
    assert parse('Hello World!')


# Generated at 2022-06-11 21:28:18.355923
# Unit test for function parse

# Generated at 2022-06-11 21:28:25.237420
# Unit test for function parse
def test_parse():
    test_docstring = """
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    :param dir_path: directory path to be cleaned
    :type dir_path: str
    :returns: cleaned list of filepaths
    :rtype: list
    """

    test_d = parse(test_docstring)
    print(test_d)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:28:36.914189
# Unit test for function parse
def test_parse():
    # testing for None
    #assert parse(None) == None
    assert parse(None, Style.auto) == None
    assert parse(None, Style.pep257) == None

    # testing for string of empty
    #assert parse("") == None
    assert parse("", Style.auto) == None
    assert parse("", Style.pep257) == None

    # testing for string of ascii
    assert parse("This is a test", Style.pep257).summary == "This is a test"
    assert parse("This is a test", Style.numpy).summary == "This is a test"
    assert parse("This is a test", Style.sphinx).summary == "This is a test"
    assert parse("This is a test", Style.google).summary == "This is a test"

# Generated at 2022-06-11 21:28:46.333618
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    # Test empty string
    assert parse("") == Docstring()

    # Test basic docstring
    assert parse("""A basic docstring.""") == Docstring(
        summary="A basic docstring."
    )
    assert parse("""A basic docstring.

    More text.""") == Docstring(
        summary="A basic docstring.", description="More text."
    )

    # Test different style docstrings
    for style in Style:
        assert parse(":param a: this is a", style=style) == Docstring(
            parameters=[Docstring.Parameter('a', 'this is a')]
        )
        assert parse(":return: nothing", style=style) == Docstring(
            returns=Docstring.Returns('nothing')
        )

    # Test Google style

# Generated at 2022-06-11 21:28:48.775101
# Unit test for function parse
def test_parse():
    docstring = "Hello there. This is a function."
    parsed_docstring = parse(docstring)
    assert parsed_docstring == docstring

# Generated at 2022-06-11 21:28:56.943739
# Unit test for function parse
def test_parse():
    text = '''
    This is a test of the parse function.

    :param name=default: A test parameter.
    :param name2: Another test parameter.
    :returns: Test return value.
    '''

    style = Style.google

    style2 = Style.auto
    d = parse(text, style2)
    assert d.body == 'This is a test of the parse function.'
    assert d.meta['returns'] == 'Test return value.'
    assert d.meta['name'] == 'A test parameter.'


# Generated at 2022-06-11 21:29:11.041867
# Unit test for function parse
def test_parse():
    text = """
    Represents the result of the barcode scanning. Contains the fields:
      text - The raw text representation of the barcode
      format - The format of the barcode
      cancelled - Whether or not this scan was cancelled
    """

    param = parse(text)

    assert param.summary == 'Represents the result of the barcode scanning.'
    assert len(param.meta) == 3
    assert param.meta[0]['name'] == 'text'
    assert param.meta[0]['type'] == 'The raw text representation of the barcode'
    assert param.meta[1]['name'] == 'format'
    assert param.meta[1]['type'] == 'The format of the barcode'
    assert param.meta[2]['name'] == 'cancelled'
    assert param.meta[2]['type']

# Generated at 2022-06-11 21:29:17.873585
# Unit test for function parse
def test_parse():
  s = '''\
:param test1: test1
:type test1: test1
:param test2: test2
:type test2: test2
:param test3: test3
:type test3: test3
:param test4: test4
:type test4: test4
:param test5: test5
:type test5: test5
:returns: 
:rtype: 
:raises: 
:raises ValueError: 
:raises TypeError: 
:raises RuntimeError: 
:raises AttributeError: 
'''
  from docstring_parser.styles import NumpyStyle
  d = parse(s, style=NumpyStyle)
  assert len(d) == 13
  assert d[0] == ':param test1: test1'

# Generated at 2022-06-11 21:29:20.354463
# Unit test for function parse
def test_parse():
    text = '''This is a test for parse()'''
    docstring = parse(text)
    assert len(docstring.meta) == 0
    text = '''This is a test for parse()
    :param param: some parameter
    :returns: some return value
    '''
    docstring = parse(text)
    assert len(docstring.meta) == 2

# Generated at 2022-06-11 21:29:24.764504
# Unit test for function parse
def test_parse():
    text = '''Parameters
        ----------
        arg1 : int
            The first argument.
        arg2 : str
            The second argument.
    '''
    docstr = parse(text)
    assert docstr.__str__() == text

# Generated at 2022-06-11 21:29:29.837056
# Unit test for function parse
def test_parse():
    docstring = '''Section 1
    Section 2
    Section 3

Section 4

Section 5
    '''
    assert parse(docstring, style=Style.yapf).sections[0].text == 'Section 1'

    docstring = ':param word: word'
    assert parse(docstring, style=Style.numpy).params[0].arg_name == 'word'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:29:37.531210
# Unit test for function parse
def test_parse():
    doc = '''the quick brown fox
    :param x: a variable
    :returns: x squared
    '''
    d = parse(doc)
    assert d.short_description == 'the quick brown fox'
    assert d.parameters[0].arg_name == 'x'
    assert d.parameters[0].description == 'a variable'
    assert d.returns.description == 'x squared'

if __name__ == '__main__':
    print('Executing doctest.')
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:29:48.206208
# Unit test for function parse
def test_parse():
    ds = """Authors:
        Name <name@gmail.com>
        Name2 <name2@gmail.com>
        
    Args:
        x: This is the first parameter.
        y: This is the second parameter.
    
    Returns:
        This is the return value.
    """
    results = parse(ds)
    assert results.params['x'] == 'This is the first parameter.'
    assert results.params['y'] == 'This is the second parameter.'
    assert results.returns == 'This is the return value.'
    assert results.authors == ['Name <name@gmail.com>', 'Name2 <name2@gmail.com>']

# Generated at 2022-06-11 21:29:55.126711
# Unit test for function parse
def test_parse():
    text = """
    This is a meta summary.

    This ends the summary and starts the body.

    :param x: The x param.
    :param y: The y param.
    :returns: The x + y.
    """
    print(parse(text)) # Should return a Docstring object


if __name__ == '__main__':
    text = """
    This is a meta summary.

    This ends the summary and starts the body.

    :param x: The x param.
    :param y: The y param.
    :returns: The x + y.
    """
    print(parse(text)) # Should return a Docstring object

# Generated at 2022-06-11 21:30:01.898247
# Unit test for function parse
def test_parse():
	docstring = """Parses a docstring into its components.

Arguments:
    text (str): The docstring text to parse.
    style (:class:`Style`, optional): The docstring style. Defaults to
        :attr:`Style.AUTO`.

Returns:
    :class:`Docstring`: The parsed docstring representation.
"""
	assert parse(docstring)
	assert parse(docstring, style=Style.numpy)


# Generated at 2022-06-11 21:30:06.180933
# Unit test for function parse
def test_parse():
    docstring = """
    doc for test_parse
    Args:
        aay: aay
        bee: bee
    """
    ds = parse(docstring, Style.google)
    print(ds)

if __name__ == "__main__":
    test_parse()
    pass

# Generated at 2022-06-11 21:30:13.325721
# Unit test for function parse
def test_parse():
    text = '''\
    """The main parsing routine."""
    '''
    assert parse(text) == Docstring(summary='The main parsing routine.')


# Generated at 2022-06-11 21:30:24.872357
# Unit test for function parse
def test_parse():
    docstring = '''
    Example function with types in the docstring.
    :param int a: The first parameter.
    :param list b: The second parameter.
    :return: This is a description of what is returned.
    :rtype: dict
    :return: This is another description of what is returned.
    :rtype: list
    '''

    parser_obj = parse(docstring)
    assert parser_obj.short_description == 'Example function with types in the docstring.'
    assert parser_obj.long_description == []
    assert parser_obj.long_description_markup == []
    assert parser_obj.meta == {
        'a': {'typ': 'int', 'desc': 'The first parameter.'},
        'b': {'typ': 'list', 'desc': 'The second parameter.'}
    }

# Generated at 2022-06-11 21:30:34.528485
# Unit test for function parse
def test_parse():
    style_list = [
        Style.google,
        Style.numpy,
        Style.reST
    ]
    text_list = [
        "This is Google style.",
        "This is Numpy style.",
        "This is reST style."
    ]
    style_name_list = [
        "google",
        "numpy",
        "reST"
    ]
    des_list = [
        "This is Google style.",
        "This is Numpy style.",
        "This is reST style."
    ]
    ret_list = [
        Docstring(description=des_list[0], meta=[]),
        Docstring(description=des_list[1], meta=[]),
        Docstring(description=des_list[2], meta=[])
    ]

# Generated at 2022-06-11 21:30:44.240489
# Unit test for function parse
def test_parse():
    text = """
    This is the first line of a short summary.
  
    This is the first line of a long summary.
    It is separated from the short summary by a blank line
    and uses two sentences to describe the function.
  
    Args:
      arg1 (str): First argument.
  
      arg2 (str): Second argument.
  
    Returns:
      bool: True if the function succeeded.
  
    Raises:
      ValueError: Raised when a value is invalid.
  
      NotImplementedError: Raised when a subclass does not define a required
                           implementation.
    """

# Generated at 2022-06-11 21:30:56.368804
# Unit test for function parse
def test_parse():
    # Test for argparse style
    text = """Some function description.

Parameters
----------
x : float
    The x-coordinate
y : float
    The y-coordinate
z : float
    The z-coordinate
"""
    docstring = parse(text)
    assert docstring.short_description == "Some function description."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 3
    assert len(docstring.returns) == 0
    assert len(docstring.yields) == 0
    assert len(docstring.raises) == 0
    assert len(docstring.warns) == 0
    assert len(docstring.other) == 0
    assert docstring.meta["x"]["type"] == "float"

# Generated at 2022-06-11 21:31:06.648814
# Unit test for function parse
def test_parse():
  text = '''Parse the docstring into its components.
  Parameters
  ----------
  text: docstring text to parse
  style: docstring style
  '''
  result = parse(text)
  assert result.short_description == "Parse the docstring into its components.", "Not short description"
  assert result.long_description == "", "Not long description"
  assert result.params["text"].description == "docstring text to parse", "Not text description"
  assert result.params["text"].type == "str", "Not text type"
  assert result.params["text"].name == "text", "Not text name"
  assert result.params["style"].description == "docstring style", "Not style description"

# Generated at 2022-06-11 21:31:10.835746
# Unit test for function parse
def test_parse():
    text = """
        Parse the docstring into its components.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """
    print(parse(text))



# Generated at 2022-06-11 21:31:20.843699
# Unit test for function parse
def test_parse():
    doc = parse("""
    Some example.

    :param foo: this is foo
    :return: this is a return

    Some other description.
    """)
    assert doc.short_description == "Some example."
    assert doc.long_description == "Some other description."
    assert doc.meta["foo"][0].arg_name == "foo"
    assert doc.meta["foo"][0].type_name is None
    assert doc.meta["foo"][0].description == "this is foo"
    assert doc.meta["return"][0].arg_name is None
    assert doc.meta["return"][0].type_name is None
    assert doc.meta["return"][0].description == "this is a return"

# Generated at 2022-06-11 21:31:32.514334
# Unit test for function parse
def test_parse():
    ds = parse('''The ``decrypt`` function takes the key and ctext and
returns the text and metadata.

:param key: key used to encrypt the string
:param ctext: ciphertext needed to decrypt
:return: (success, message)
''')
    assert ds.summary == 'The ``decrypt`` function takes the key and ctext and returns the text and metadata.'
    assert ds.meta[0].name == 'key'
    assert ds.meta[0].type == None
    assert ds.meta[0].description == 'key used to encrypt the string'
    assert ds.meta[1].name == 'ctext'
    assert ds.meta[1].type == None
    assert ds.meta[1].description == 'ciphertext needed to decrypt'
    assert ds.returns.name

# Generated at 2022-06-11 21:31:44.263264
# Unit test for function parse
def test_parse():
    docstring = '''
        """
        Args:
            arg1
            arg2

        Returns:
            Return values.

        Raises:
            IOError: An error occurred.
        """
    '''
    docstring = parse(docstring)
    assert len(docstring.args) == 2
    assert docstring.args[0].arg_type == 'Args'
    assert docstring.args[0].arg_name == 'arg1'
    assert docstring.args[1].arg_type == 'Args'
    assert docstring.args[1].arg_name == 'arg2'
    assert len(docstring.returns) == 1
    assert docstring.returns[0].arg_type == 'Returns'
    assert docstring.returns[0].arg_name == 'Return values.'

# Generated at 2022-06-11 21:31:52.315529
# Unit test for function parse
def test_parse():
    print('Testing function parse')
    try:
        parse('""')
    except ParseError as err:
        print('ParseError:', err)
    else:
        print('No error')
    #print('Finished testing.')



# Generated at 2022-06-11 21:32:02.436453
# Unit test for function parse
def test_parse():
    text = """Summary line.

This is a module docstring.

This line is part of the same paragraph.

:param arg1: Description of arg1
:param arg2: Description of arg2

:returns: Description of return value
:raises Exception1: Because of this.
:raises Exception2: Because of that.
:raises Exception3: Because of everything.

Optional section 1.

Optional section 2.
"""
    assert str(parse(text)) == text
    assert parse(text) == parse(text)
    assert parse(text) != parse(text.replace("Optional", "Something else"))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:09.527031
# Unit test for function parse
def test_parse():
    text = """
    This is a module docstring.

    Arguments
    ---------
    a : int
        first argument
    b : float, default=2
        second argument (default: 2)
    """

    d = parse(text)

    assert d.short_desc == "This is a module docstring."
    assert d.long_desc == ""
    assert d.meta == {'Arguments\n+++++++': ['a : int\n    first argument', 'b : float, default=2\n    second argument (default: 2)']}


# Generated at 2022-06-11 21:32:13.082382
# Unit test for function parse
def test_parse():
    text = """\
    :param hello: blabla
    :returns: foo
    """
    style = Style.auto
    assert parse(text, style) == STYLES[Style.google](text)

# Generated at 2022-06-11 21:32:18.724158
# Unit test for function parse
def test_parse():
    docstring = """
  This is the short description.

  This is a more detailed description.

  :param param1: The first parameter.
  :param param2: The second parameter.
  :returns: Description of return value.

  """
    print(parse(docstring,style=Style.sphinx))

# test_parse()

# Generated at 2022-06-11 21:32:27.710725
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import PEP257Style
    text = """PEP 257 docstring checker.

:param str text: the docstring text to check
:param str name: the name of the object the docstring belongs to
:returns: the docstring checker instance
:rtype: :class:`PEP257Checker`
:raises ValueError: if the text argument is not provided
:raises IOError: if the name argument is not provided
"""
    assert parse(text) == PEP257Style(text)


if __name__ == "__main__":
	test_parse()

# Generated at 2022-06-11 21:32:30.287443
# Unit test for function parse
def test_parse():
    ds = '''
    this is a docstring
    '''
    assert parse(ds).body == 'this is a docstring'


# Generated at 2022-06-11 21:32:39.507668
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import parse
    d = parse('Hello, World!')
    assert d.short_description == 'Hello, World!'
    d = parse('Hello, World!\n\nThis is a test.\n')
    assert d.short_description == 'Hello, World!'
    assert d.long_description == 'This is a test.'
    assert d.params == {}
    d = parse('')
    assert d.short_description == ''
    assert d.long_description == ''
    assert d.params == {}
    d = parse('Hello, World!\n:param x: testing')
    assert d.short_description == 'Hello, World!'
    assert d.params['x'] == 'testing'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:43.867296
# Unit test for function parse
def test_parse():
    text = '''
    Compute the sum of a list of numbers.
        :param a: The first number.
        :rtype: The answer.
        :raises ValueError: If `a` is not a number.
    '''
    parse(text)
#---------------------------------------------------------------------------------------------

# Generated at 2022-06-11 21:32:45.838455
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""


# Generated at 2022-06-11 21:32:53.407667
# Unit test for function parse
def test_parse():
    doc_str = '''What's up, Doc?'''
    print(str(parse(doc_str)))

    doc_str = '''What's up, Doc?
    :param param1: The first parameter.
    :param param2: The second parameter.
    
    :raises KeyError: Raises an exception.
    '''
    print(str(parse(doc_str)))

# Generated at 2022-06-11 21:32:56.840498
# Unit test for function parse
def test_parse():
    text = '''
      Parse the docstring into its components.
      
      :param text: docstring text to parse
      :param style: docstring style
      :returns: parsed docstring representation
    '''
    ret = parse(text)
    assert ret.summary == "Parse the docstring into its components."
    assert ret.meta[0]["name"] == "text"
    assert ret.meta[1]["name"] == "style"
    assert ret.meta[2]["name"] == "returns"
    assert ret.content == ""

# Generated at 2022-06-11 21:33:09.590649
# Unit test for function parse
def test_parse():
    text = """Plots a ROC curve.

:parameters:
    fpr : array, shape = [>2]
        Increasing false positive rates such that element i is the false
        positive rate of predictions with score >= thresholds[i].
    tpr : array, shape = [>2]
        Increasing true positive rates such that element i is the true
        positive rate of predictions with score >= thresholds[i].
    roc_auc : float
    labels : list of str, optional
        List of line labels.
    ax : matplotlib axes, optional
        If provided, plot on this axis; otherwise, open a new figure.
    **kwargs : dict, optional
        matplotlib options for each line.
:returns:
    ax : matplotlib axes
        Returns the axes that the ROC plot is drawn on.
    """

# Generated at 2022-06-11 21:33:16.269033
# Unit test for function parse
def test_parse():
    d = parse('''\
This is a test docstring

With a second paragraph.

:param  a: this
:type   a: str
:param  b: that
:type   b: int
:returns: the other
:rtype:   float
''')
    assert d.short_description == 'This is a test docstring'
    assert d.long_description == 'With a second paragraph.'
    assert d.meta['a']['type'] == 'str'
    assert d.meta['b']['type'] == 'int'
    assert d.returns['type'] == 'float'

# Generated at 2022-06-11 21:33:18.904245
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('\n') == Docstring()
    assert parse('\n\n') == Docstring()
    assert parse('\n\n\n') == Docstring()



# Generated at 2022-06-11 21:33:30.445599
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    docstring = """This is the Docstring"""
    ret = parse(docstring)
    assert ret == Docstring(summary="This is the Docstring", meta={}, extended="")
    docstring = """This is the Summary.

This is the Extended part.

Args:
    arg1 (str): this is the first argument

Returns:
    str: this is the return value
"""
    ret = parse(docstring)
    assert ret == Docstring(summary="This is the Summary.", meta={"Args": [("arg1", "str", "this is the first argument")], "Returns": [("", "str", "this is the return value")]}, extended="This is the Extended part.")

# Generated at 2022-06-11 21:33:35.767387
# Unit test for function parse
def test_parse():
    text =  '''
    classify(X, Y)

    Classify instances with Y.

    Args:
        X (numpy.ndarray): instances data
        Y (numpy.ndarray): instances label
    '''
    parsed = parse(text)
    assert parsed.summary == 'Classify instances with Y.'
    assert parsed.extended_summary == ''
    assert parsed.params['X'] == 'instances data'
    assert parsed.params['Y'] == 'instances label'

# Generated at 2022-06-11 21:33:38.582470
# Unit test for function parse
def test_parse():
    ds = """
        This is a docstring
        with two lines
    """
    assert parse(ds).description.startswith(ds)

# Generated at 2022-06-11 21:33:47.371077
# Unit test for function parse
def test_parse():
    data = "Summary\n\n    :param name: this is the name param\n    :type name: str\n    :param state: None/True/False\n    :type state: bool\n    :returns:  int -- the return code. 0 for success, 1 for failure\n    :raises error: if error"
    parsed = parse(data)
    assert(parsed.short_description == "Summary")
    assert(parsed.long_description == "")
    assert(parsed.summary == "Summary")
    assert(parsed.meta["parameters"][0].name == "name")
    assert(parsed.meta["parameters"][0].description == "this is the name param")
    assert(parsed.meta["parameters"][0].annotation == "str")
   

# Generated at 2022-06-11 21:33:58.240133
# Unit test for function parse
def test_parse():
    meta, summary, body, examples, kwargs = parse(
        """\
    Parses docstrings into its components.

    :param text: Docstring text to parse
    :param style: Docstring style
    :returns parsed docstring representation as a dict
    :raises ParseError: when the parser fails to parse

    This is a description of my function. It does some awesome things.
    Some other things. Maybe.

    Here are some examples:

    >>> parse('hello, world!')
    ['hello', 'world']
    >>> parse('hello, world', style='google')
    (['hello', 'world'], {}, {})
    """
    )
    assert meta['param'][0]['name'] == 'text'
    assert meta['param'][0]['annotation'] == 'Docstring text to parse'
   

# Generated at 2022-06-11 21:34:10.944638
# Unit test for function parse
def test_parse():
    docstring_1 = parse("""
        first line
        second line
        """)
    assert len(docstring_1.summary) == 2
    assert docstring_1.summary[0] == "first line"
    assert docstring_1.summary[1] == "second line"

    docstring_2 = parse(r'''
        Summarize the function here.

        :param str name:
           The full name of the member.
           This is a second line of the description.
        ''', style=Style.numpy)
    assert len(docstring_2.params) == 1
    param = docstring_2.params[0]
    assert param.arg_name == 'name'
    assert param.arg_type == 'str'
    assert len(param.description) == 2
    assert param.description[0]

# Generated at 2022-06-11 21:34:21.574784
# Unit test for function parse
def test_parse():
    # test with string
    test_string = "Docstring"
    assert parse(test_string).short_description == "Docstring"
    # test with newlines
    test_string = "Docstring\n"
    assert parse(test_string).short_description == "Docstring"
    # test with list (pypi)

# Generated at 2022-06-11 21:34:28.664858
# Unit test for function parse
def test_parse():
    ''' Unit test for the function parse'''
    docstring = """
    This is a short description.
    This is a detailed description.
    :param data: The data to train the neural network on.
    :type data: File
    :param dataList: The list of data files to train the neural network on.
    :type dataList: list
    :returns: trained network
    :rtype: Network
    """
    print(parse(docstring))
    # Pass


# Generated at 2022-06-11 21:34:36.302349
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ReturnItem

    docstring_text = """Test parse.
Usage::
    >>> parse(text, style='google')
    >>> parse(text, style='numpy')
Args:
    text (String): String to parse.
    style (Optional[String]): Style of the string.
Returns:
    Docstring: Return the parsed docstring.
"""
    docstring = parse(docstring_text)
    assert docstring.short_description == "Test parse."
    assert docstring.content == "\nUsage::\n    >>> parse(text, style='google')\n    >>> parse(text, style='numpy')"
    assert docstring.params[1].arg_name == "style"
    assert docstring.returns == [ReturnItem("Docstring", return_desc="Return the parsed docstring.")]

# Generated at 2022-06-11 21:34:44.147565
# Unit test for function parse
def test_parse():
    text = '''
        Summary line.

        Extended description.

        Args:
            arg1: Description of arg1
            arg2: Description of arg2

        Returns:
            Description of return value
        '''
    docstring = parse(text)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == 'Extended description.'
    assert docstring.params['arg1'] == 'Description of arg1'
    assert docstring.params['arg2'] == 'Description of arg2'
    assert docstring.returns == 'Description of return value'

# Generated at 2022-06-11 21:34:47.845897
# Unit test for function parse
def test_parse():
    text = """https://google.com
    :param x: The x coordinate.
    :type x: int
    :param y: The y coordinate.
    :type y: int
    :returns: Point
    :rtype: Point
    """
    assert parse(text, Style.google)

# Generated at 2022-06-11 21:34:58.801260
# Unit test for function parse

# Generated at 2022-06-11 21:35:02.113642
# Unit test for function parse
def test_parse():
    text = """\
    Return a Foo object of the given `size`.
    """

    docstring = parse(text)
    assert docstring.short_description == "Return a Foo object of the given `size`."

# Generated at 2022-06-11 21:35:07.893139
# Unit test for function parse
def test_parse():
        docstring = """This function does something.
        :param name: The name to use.
        :type name: str.
        :param state: Current state to be in.
        :type state: bool.
        :returns:  int -- the return code.
        :raises: AttributeError, KeyError"""
        assert parse(docstring).short_description == "This function does something."

# Generated at 2022-06-11 21:35:11.428497
# Unit test for function parse
def test_parse():
    text = '''
    summary

    description
    '''

    ds = parse(text)
    assert ds.summary == 'summary'
    assert ds.description == 'description'



# Generated at 2022-06-11 21:35:17.301386
# Unit test for function parse
def test_parse():
    text = '''\
    :param str name: the name to say
    :raises ValueError: if name is empty
    :returns str: the greeted name
    :returns int: the number of letters in the name
    '''
    expected = Docstring(
        content='',
        meta=[
            ('param', 'str', 'name', 'the name to say'),
            ('raises', 'ValueError', '', 'if name is empty'),
            ('returns', 'str', '', 'the greeted name'),
            ('returns', 'int', '', 'the number of letters in the name'),
        ]
    )
    actual = parse(text)
    assert expected == actual

test_parse()

# Generated at 2022-06-11 21:35:23.716949
# Unit test for function parse
def test_parse():
    docstr = parse("""
    Test text. This is a test of the emergency parsing system.

    Parameters
    ----------
    foo : string
        foo bar baz
    bar : float
        bar bar bar
    """)
    assert docstr.style == Style.numpy
    assert docstr.short_desc == 'Test text.'
    assert docstr.long_desc == 'TThis is a test of the emergency parsing system.'

# Generated at 2022-06-11 21:35:34.258370
# Unit test for function parse
def test_parse():
    # Test for Doxygen style
    text = """\
This is a test for Doxygen style.

:param A: this is a parameter
:type A: str
:param B: this is a parameter
:type B: int
:return: this is a return
:rtype: float
"""

    rtn = parse(text)
    assert rtn.short_description == "This is a test for Doxygen style."
    assert len(rtn.returns) == 1
    assert rtn.returns[0].type_name == "float"
    assert rtn.returns[0].description == "this is a return"
    assert len(rtn.long_description) == 1
    assert len(rtn.meta) == 4
    assert len(rtn.meta[1].meta) == 2
    assert rtn

# Generated at 2022-06-11 21:35:44.008959
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""


# Generated at 2022-06-11 21:35:50.540203
# Unit test for function parse
def test_parse():
    try:
        parse("", Style.google)
    except:
        pass
    try:
        parse("", Style.numpy)
    except:
        pass
    try:
        parse("", Style.pep257)
    except:
        pass
    try:
        parse("", Style.sphinx)
    except:
        pass
    try:
        parse("", Style.auto)
    except:
        pass

# Generated at 2022-06-11 21:36:01.277136
# Unit test for function parse
def test_parse():
    text = (
        "Description\n"
        "\n"
        "    Indented line 1.\n"
        "    Indented line 2.\n"
        "\n"
        "Not indented line.\n"
        "\n"
        "    Indented line 3.\n"
        "    Indented line 4.\n"
        "\n"
        "    Not indented line.\n"
        "\n"
        "Returns\n"
        "\n"
        "    A string"
    )
    result = parse(text)

# Generated at 2022-06-11 21:36:11.361798
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    Returns:
        bool: The return value. True for success, False otherwise.
"""
    docstring = parse(text)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."
    assert docstring.returns.type_name == "bool"
    assert (
        docstring.returns.description
        == "The return value. True for success, False otherwise."
    )
    assert len