

# Generated at 2022-06-11 21:26:16.442812
# Unit test for function parse
def test_parse():
    text = '''
    :param x: scatterplot data
    :type x: [array-like or str]
    :param y: scatterplot data
    :type y: [array-like or str]
    '''
    doc = parse(text)
    print(doc.params)
    print(doc.returns)
    print(doc.errors)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:26:25.173126
# Unit test for function parse
def test_parse():
    text = parse(
        "Return a list of the first 100 prime numbers.\n"
        "Each prime number is represented as an Integer object.\n"
    )
    assert text.short_description == "Return a list of the first 100 prime numbers."
    assert text.long_description == "Each prime number is represented as an Integer object."
    assert text.returns is None
    assert text.returns_description is None
    assert text.meta == {}


# Generated at 2022-06-11 21:26:30.733405
# Unit test for function parse
def test_parse():
    txt = '''
On the first line we have one-liner.

On the second line we have a blank.

We also have some more
lines here as well.

And a section:

Args:
  arg1: Here is arg1.
  arg2: Here is arg2.
  arg3: Here is arg3.

Returns:
  This is the return value.
    '''
    result = parse(txt)
    results = result.sections
    assert(results[0][0]['name'] == 'Args')
    assert(results[0][0]['content'] == 'arg1: Here is arg1.\narg2: Here is arg2.\narg3: Here is arg3.')
    assert(results[0][1]['name'] == 'Returns')

# Generated at 2022-06-11 21:26:37.321014
# Unit test for function parse
def test_parse():
	'''
		docstring_parser.parse() generates a Docstring instance from a given docstring 
		text and returns it with all the meta data in it
		for some test cases
	'''
	assert parse('This is a test') == Docstring(description='This is a test')

	assert parse('This is a test\n\nArgs:\n    param1: description') == Docstring(description='This is a test\n\n',
																					params=[['param1', 'description']],
																					returns=[])


# Generated at 2022-06-11 21:26:42.212194
# Unit test for function parse
def test_parse():
    text='parse(text, style=Style.auto) -> Docstring\nParses the docstring into its components.\n\n:param text: docstring text to parse\n:param style: docstring style\n:returns: parsed docstring representation'
    assert(parse(text, Style.auto)=='')

# Generated at 2022-06-11 21:26:47.121798
# Unit test for function parse
def test_parse():
    text = '''
    Parameters
    ----------
    x : array_like
        Array (or array-like) of data.'''
    style = Style.numpy
    doc = parse(text, style)
    assert doc.meta['Parameters'][0]['x'] == 'array_like'
    assert doc.meta['Parameters'][0]['desc'] == 'Array (or array-like) of data.'
    assert doc.content == None

# Generated at 2022-06-11 21:26:56.525819
# Unit test for function parse
def test_parse():

    docstring = """
    This is a test docstring.
    It is a very nice one.
    There are many others like it,
    but this one is mine.
    """

    docstring_obj = parse(docstring, style=Style.numpy)
    assert docstring_obj.short_description == docstring.split('\n')[1].strip()
    assert docstring_obj.long_description == '\n'.join(docstring.split('\n')[2:])
    assert docstring_obj.meta == []

# Generated at 2022-06-11 21:27:07.958342
# Unit test for function parse
def test_parse():
    text = '''
        Parse the docstring into its components.

        :param text: to be parsed text
        :param style: docstring style
        :returns: parsed docstring representation'''

    docs = parse(text)
    assert (docs.short_description == 'Parse the docstring into its components.')
    assert (docs.long_description == '')
    assert (docs.meta == {
        'param': [{
            'name': 'text',
            'description': 'to be parsed text'
        }, {
            'name': 'style',
            'description': 'docstring style'
        }],
        'returns': [{
            'description': 'parsed docstring representation'
        }]
    })



# Generated at 2022-06-11 21:27:20.088124
# Unit test for function parse
def test_parse():
    text = """\
    This is the description.

    This is the second paragraph.

    :param x: This is the X parameter
    :type x: int
    :param y: This is the Y parameter
    :type y: int
    :param z: This is the Z parameter
    :type z: int
    :returns: This is the return description
    :raises RuntimeError: This is the RuntimeError description
    """
    doc = parse(text)
    assert doc.description == 'This is the description.\n\nThis is the second paragraph.\n'

    assert doc.params['x'] == 'This is the X parameter'
    assert doc.params['y'] == 'This is the Y parameter'
    assert doc.params['z'] == 'This is the Z parameter'

# Generated at 2022-06-11 21:27:24.050265
# Unit test for function parse
def test_parse():
    text = "Calculates the roots of a quadratic equation"
    style = Style.auto
    assert parse(text=text, style=style).summary == "Calculates the roots of a quadratic equation"

# Generated at 2022-06-11 21:27:41.517472
# Unit test for function parse
def test_parse():
    assert (Docstring(
        summary='Function to return a + b.',
        description='',
        params=[],
        returns=None,
        meta={}) ==
        parse(
            """Function to return a + b.
            :param a: first value
            :param b: first value
            :return: a + b value
            """))

    assert (Docstring(
        summary='func to return a + b',
        description='',
        params=['a: first value', 'b: second value'],
        returns=['a + b value'],
        meta={}) ==
        parse(
            """func to return a + b
            :param a: first value
            :param b: second value
            :return: a + b value
            """))


# Generated at 2022-06-11 21:27:44.371468
# Unit test for function parse
def test_parse():
    t = """This is what you should see"""
    assert parse(t) == Docstring(description=["This is what you should see"], meta={}, fields={}, tags=[])

# Generated at 2022-06-11 21:27:47.999278
# Unit test for function parse
def test_parse():
    print ("Testing parse()")
    docstring = """
    This is a docstring
    """
    print(parse(docstring).summary)
    print("--------------------------------------------------------------------------------")
    print (parse(docstring))

# Generated at 2022-06-11 21:27:59.108320
# Unit test for function parse
def test_parse():
    text = """\
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    ds = parse(text)
    assert ds.summary == ''
    assert ds.signature == ''
    assert ds.meta['param'][0].args == ['text']
    assert ds.meta['param'][0].description == 'docstring text to parse'
    assert ds.meta['param'][1].args == ['style']
    assert ds.meta['param'][1].description == 'docstring style'
    assert ds.meta['returns'][0].args == []
    assert ds.meta['returns'][0].description == 'parsed docstring representation'
    assert ds.description == ''
    assert ds

# Generated at 2022-06-11 21:28:07.032173
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    text = 'function to test'

    # Unit test for function parse
    def test_parse():
        from docstring_parser.common import Docstring, ParseError
        from docstring_parser.styles import STYLES, Style

        text = 'function to test'

        # assert parse(text, Style.auto) == 
        # assert parse(text, Style.google) == Docstring()
        # assert parse(text, Style.numpy) == Docstring()
        # assert parse(text, Style.rdoc) == Docstring()
        # assert parse(text, Style.sphinx) == Docstring()

# Generated at 2022-06-11 21:28:18.201401
# Unit test for function parse
def test_parse():
    import os
    import pickle as pkl
    import shutil
    import subprocess
    import sys
    import tempfile
    import zipfile

    def write_to_file(package, pkg_zip, file_name, file_content):
        pkg_name = package.split('.')[0]
        if pkg_name in pkg_zip.namelist():
            base = pkg_zip.extract(pkg_name, path=tempdir)
        else:
            base = os.path.join(tempdir, pkg_name)
            os.makedirs(base)
        with open(os.path.join(base, file_name), 'w') as f:
            f.write(file_content)


# Generated at 2022-06-11 21:28:29.322186
# Unit test for function parse
def test_parse():
    docstring = """
    short summary

    extended summary

    :param first_param: the first parameter
    :type first_param: str
    :param second_param: the second parameter
    :type second_param: int
    :returns: None
    :raises keyError: raises an exception
    """
    style = Style.numpy

    parsed_docstring = parse(docstring, style)

    assert parsed_docstring.short_description == "short summary"
    assert parsed_docstring.long_description == "extended summary"
    assert parsed_docstring.metadata["param"][0]["name"] == "first_param"
    assert parsed_docstring.metadata["param"][0]["type"] == "str"
    assert parsed_docstring.metadata["param"][1]["name"] == "second_param"

# Generated at 2022-06-11 21:28:38.762945
# Unit test for function parse
def test_parse():
    from re import sub
    from textwrap import dedent

    from docstring_parser.parser import parse

    docstring = """This is a module docstring."""
    assert parse(docstring).short_description == 'This is a module docstring.'

    docstring = """Example module.
    This module does stuff.
    """
    parsed = parse(docstring)
    short_description = """Example module."""
    long_description = """This module does stuff."""
    assert parsed.short_description == short_description
    assert parsed.long_description == long_description

    docstring = """Example module.
    This module does stuff.
    :param int foo: A foo parameter.
    """
    parsed = parse(docstring)
    short_description = """Example module."""
    long_description = """This module does stuff."""
   

# Generated at 2022-06-11 21:28:48.490020
# Unit test for function parse
def test_parse():
    docstring = """
            This is a short summary
            of the function or class.

            And a longer description
            than the summary.

            :param spam: the spam
            :type spam: str
            :param eggs: the eggs
            :type eggs: int
            :param foo: the foo
            :type foo: str
            :raises ValueError: when the arg is not valid
            :returns: True if the arg is valid
            :rtype: bool
            """

# Generated at 2022-06-11 21:28:52.178905
# Unit test for function parse
def test_parse():
    doc = """
    Short summary.

    Longer summary.

    Keyword arguments:
        arg1: arg1 type and description
        arg2: arg2 type and description
    """
    assert parse(doc) == parse.__doc__

# Generated at 2022-06-11 21:29:03.599719
# Unit test for function parse
def test_parse():
    class Test:
        """
        Test function.
        :param b: test parameter.
        :type b: int
        """
        def test(a, b):
            pass
    assert(parse(Test.__doc__).params == {'b': {'doc': 'test parameter.', 'type': 'int'}})


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:29:13.228282
# Unit test for function parse
def test_parse():
    actual = parse("")
    assert actual.meta == {}
    assert actual.summary == ""
    assert actual.body == ""
    assert actual.has_examples == False

    actual = parse("a\n")
    assert actual.meta == {}
    assert actual.summary == "a"
    assert actual.body == ""
    assert actual.has_examples == False

    actual = parse("a\nb")
    assert actual.meta == {}
    assert actual.summary == "a"
    assert actual.body == "b"
    assert actual.has_examples == False

    actual = parse("a\n\nb\n")
    assert actual.meta == {}
    assert actual.summary == "a"
    assert actual.body == "b"
    assert actual.has_examples == False


# Generated at 2022-06-11 21:29:27.323827
# Unit test for function parse
def test_parse():
    # Test Google docstring parsing.
    doc = parse(r"""
        Do something awesome.

        Keyword arguments:
        arg -- The first command line argument.
        """)
    assert len(doc.meta) == 1
    assert doc.meta[0].key == 'arg'
    assert doc.meta[0].value == 'The first command line argument.'
    assert doc.summary == 'Do something awesome.'

    # Test Numpy docstring parsing.
    doc = parse(r"""
        Do something awesome.

        Parameters
        ----------
        arg : int
            The first command line argument.
        """)
    assert len(doc.meta) == 1
    assert doc.meta[0].key == 'arg'
    assert doc.meta[0].value == 'int\n\tThe first command line argument.'
    assert doc.summary

# Generated at 2022-06-11 21:29:38.201188
# Unit test for function parse
def test_parse():
    text = ('This is a module docstring\n'
            '\n'
            'This module does some things\n'
            '\n'
            ':param some_param: Some value\n'
            '\n'
            ':returns: None\n'
            ':rtype: None\n'
            ':raises SomeException: If something goes wrong')
    docstring = parse(text)
    assert docstring.short_description == 'This is a module docstring'
    assert docstring.long_description == 'This module does some things'
    assert docstring.meta == {'param': [['some_param', 'Some value']],
                              'returns': [None],
                              'rtype': [None],
                              'raises': ['SomeException', 'If something goes wrong']}

# Generated at 2022-06-11 21:29:48.259225
# Unit test for function parse
def test_parse():
    test_docstring = ''' 
    This function does a very simple thing.

    :param x: :py:class:`~.Test`, this is optional.
    :param y: :py:class:`~.Test`
    :type y: :py:class:`~.Test`
    :return: :py:class:`~.Test`
    :rtype: :py:class:`~.Test`
    :raises ValueError: If x is :py:class:`~.Test`
    :Example: :ref:`example`
    '''
    assert parse(test_docstring) == parse.__doc__

# Generated at 2022-06-11 21:29:56.108509
# Unit test for function parse
def test_parse():
    text = """
        This is the title
        ===================

        This is the description.

        :param int a: description a
        :param int b: description b
        :return: None
    """
    doc = parse(text)
    assert doc.title == 'This is the title'
    assert doc.description == 'This is the description.'
    assert doc.args[0].name == 'a'
    assert doc.args[0].type == 'int'
    assert doc.args[0].description == 'description a'
    assert doc.args[1].name == 'b'
    assert doc.args[1].type == 'int'
    assert doc.args[1].description == 'description b'
    assert doc.returns == ('', 'None')

test_parse()

# Generated at 2022-06-11 21:30:07.299476
# Unit test for function parse
def test_parse():
    from .styles import Style
    assert parse('Hello world') == Docstring(summary='Hello world', style=Style.google)
    assert parse('Hello world', style=Style.google) == Docstring(summary='Hello world', style=Style.google)
    assert parse('Hello world', style=Style.numpy) == Docstring(summary='Hello world', style=Style.numpy)
    assert parse('Hello world', style=Style.numpy) == Docstring(summary='Hello world', style=Style.numpy)
    assert parse('Hello world', style=Style.napoleon) == Docstring(summary='Hello world', style=Style.napoleon)
    assert parse('Hello world', style=Style.rst) == Docstring(summary='Hello world', style=Style.rst)

# Generated at 2022-06-11 21:30:16.990403
# Unit test for function parse
def test_parse():
    if __name__ == '__main__':
        with open('test_docstring.py', 'r') as f:
            txt = f.read()
        doc = parse(txt)

    assert txt == doc.raw
    assert 'Docstring Parser' == doc.summary
    assert 'Test Paragraph' == doc.desc
    assert 'Paragraph2' == doc.extended
    assert tuple() == doc.raises

    a = doc.params[0]
    assert 'a' == a.arg_name
    assert 'int' == a.dtype
    assert 'First parameter' == a.desc

    r = doc.returns[0]
    assert 'int' == r.dtype
    assert 'The return value' == r.desc

# Generated at 2022-06-11 21:30:22.108750
# Unit test for function parse
def test_parse():
    text = '''
        Title
        
        Keyword arguments:
            param1: description
            param2: description
        '''
    expected = Docstring(
        "Title",
        ("param1", "description"),
        ("param2", "description"),
    )
    assert parse(text) == expected

test_parse()

# Generated at 2022-06-11 21:30:33.137992
# Unit test for function parse
def test_parse():
    d = parse('Hello, World!')
    assert d.summary == 'Hello, World!'
    assert d.params == []
    assert d.returns == None
    d = parse('Hello, World!\n:param x: First param\n:returns: Return value')
    assert d.summary == 'Hello, World!'
    assert d.params == [Docstring(meta={'param':'x', 'type':None, 'desc':'First param'})]
    assert d.returns == Docstring(meta={'returns':None, 'type':None, 'desc':'Return value'})


# Generated at 2022-06-11 21:30:43.696444
# Unit test for function parse
def test_parse():
    text = """
    Parses docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    ret = parse(text)
    assert ret.summary == "Parses docstring into its components."
    assert ret.meta['style'] == 'style: str'
    assert ret.meta['text'] == 'text: str'
    assert ret.meta['returns'][0] == 'returns: parsed docstring representation'



# Generated at 2022-06-11 21:30:55.926870
# Unit test for function parse
def test_parse():

    text = """Summary line.

    Extended description.
    """

    docstring = parse(text)
    assert(docstring.short_description == 'Summary line.')
    assert(docstring.long_description == 'Extended description.')
    assert(docstring.meta == [])

    text = """Summary line.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.


    Extended description.

    """

    docstring = parse(text)
    assert(docstring.short_description == 'Summary line.')
    assert(docstring.long_description == 'Extended description.')
    assert(len(docstring.meta) == 4)

# Generated at 2022-06-11 21:31:06.366783
# Unit test for function parse
def test_parse():
    docstring = """Example docstring.
    This is a

    multiline docstring."""

    assert parse(docstring).short_description == "Example docstring."

    docstring = """Example docstring.
    This is a
    multiline docstring.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int, str
        The return value."""

    assert parse(docstring).short_description == "Example docstring."

    docstring = """Example docstring.
    This is a
    multiline docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        int, str: The return value."""


# Generated at 2022-06-11 21:31:11.992598
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Params, ReturnItem, ExampleItem
    from docstring_parser.parser import parse
    text = '''
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    :Example:
        Hello world
    '''

    doc = parse(text)
    assert doc.short_description
    assert doc.params[0].name == 'text'
    assert doc.params[1].name == 'style'
    assert doc.returns[0].type_name == 'Docstring'
    assert doc.example[0].description == 'Hello world'

# Generated at 2022-06-11 21:31:23.814096
# Unit test for function parse
def test_parse():
    text = """
    Test function

    :param a: Test
    :type a: Test type
    :returns: Test return value
    :rtype: Test return type

    Extra text that should be ignored
    """

    ds = parse(text)
    assert ds.short_description == 'Test function'
    assert ds.long_description == 'Test function'
    assert ds.meta['a'].arg_name == 'a'
    assert ds.meta['a'].arg_type == 'Test type'
    assert ds.meta['a'].description == 'Test'
    assert ds.returns.description == 'Test return value'
    assert ds.returns.type_name == 'Test return type'
    assert ds.returns.annotation == None


# Generated at 2022-06-11 21:31:34.103128
# Unit test for function parse
def test_parse():
    from .common import Comment, Parameter
    from .styles import GoogleDocstring, NumpyDocstring, NumPyDocstring
    assert parse("hello world") == Docstring("hello world\n", [], [], [], [], [])
    assert parse("hello world\n\n") == Docstring("hello world\n", [], [], [], [], [])
    assert parse("hello world\n\n\n") == Docstring("hello world\n", [], [], [], [], [])
    assert parse("hello world\n\n222") == GoogleDocstring("hello world\n", [], [], [], [], [])
    assert parse("hello world\n\n222", style=Style.google) == GoogleDocstring("hello world\n", [], [], [], [], [])

# Generated at 2022-06-11 21:31:45.694860
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    docstring = parse("""
    Args:
        param1: The first parameter.
        param2: The second parameter.
    Returns:
        True if successful, False otherwise.
        """)
    assert isinstance(docstring, GoogleStyle)
    assert docstring.long_description == ''
    assert len(docstring.meta) == 3
    assert docstring.meta['Args'] == 'param1: The first parameter.\n        param2: The second parameter.'
    assert docstring.meta['Returns'] == 'True if successful, False otherwise.'
    assert docstring.short_description == '<no short description>'


# Generated at 2022-06-11 21:31:56.343138
# Unit test for function parse

# Generated at 2022-06-11 21:32:07.608794
# Unit test for function parse
def test_parse():
    assert parse('').short_description == ''
    assert parse('').long_description == ''
    assert parse('')._meta == []

    assert parse('Hello world.').short_description == 'Hello world.'
    assert parse('Hello world.').long_description == ''
    assert parse('Hello world.')._meta == []

    assert parse('Hello world.\n\nAnd goodbye.').short_description == 'Hello world.'
    assert parse('Hello world.\n\nAnd goodbye.').long_description == 'And goodbye.'
    assert parse('Hello world.\n\nAnd goodbye.')._meta == []

    assert parse('Hello world.\n\nAnd goodbye.\n\n:param int param1: a parameter.').short_description == 'Hello world.'

# Generated at 2022-06-11 21:32:13.124646
# Unit test for function parse
def test_parse():
    assert parse("""
:param p1: parameter 1
:returns: returns 1
""") == Docstring(
    text="""
:param p1: parameter 1
:returns: returns 1
""",
    meta={
        "param": [
            ("p1", None, None, None)
        ],
        "return": [
            (None, None, None, None)
        ]
    }
)

# Generated at 2022-06-11 21:32:26.930081
# Unit test for function parse
def test_parse():
    text = '''
        title: My Title
        author: Your Name
        date: today
        mainTitle: The main title
        subTitle: A sub title
        abstract:
            The abstract describes the purpose of this document.
            The abstract is typically a short paragraph.
        keywords:
            - a
            - list
            - of
            - keywords
        '''

    docstring = parse(text)

    assert docstring.meta['title'] == 'My Title'
    assert docstring.meta['author'] == 'Your Name'
    assert docstring.meta['date'] == 'today'
    assert docstring.meta['mainTitle'] == 'The main title'
    assert docstring.meta['subTitle'] == 'A sub title'

# Generated at 2022-06-11 21:32:34.305289
# Unit test for function parse
def test_parse():
    text = '''\
parse

Parse the docstring into its components.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation\
'''
    d = parse(text)
    assert d.short_description == 'parse'
    assert d.long_description == '''\
Parse the docstring into its components.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation'''
    assert d.params[0].arg_name == 'text'
    assert d.returns == d.params[-1]

# Generated at 2022-06-11 21:32:38.188335
# Unit test for function parse
def test_parse():
    ds = '''foo
    Args:
        foo: foo
    '''
    doc = parse(ds)
    assert doc.short_description == 'foo'
    assert "Args" in doc.long_description

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:32:47.985092
# Unit test for function parse
def test_parse():
    text = """
    Args:
    - a (str):
    """
    d = parse(text, Style.google)
    assert len(d.args) == 1
    assert len(d.params) == 1
    assert len(d.returns) == 0

    text = """
    Parameters
    ----------
    a : str
    """
    d = parse(text, Style.numpy)
    assert len(d.args) == 1
    assert len(d.params) == 1
    assert len(d.returns) == 0

    text = """
    :param a:
    """
    d = parse(text, Style.auto)
    assert len(d.args) == 1
    assert len(d.params) == 1
    assert len(d.returns) == 0



# Generated at 2022-06-11 21:32:51.132788
# Unit test for function parse
def test_parse():
    assert parse(docstring_example) == 'This is an example of parsed docstring.'
    assert parse(docstring_example) == 'This is an example of parsed docstring.'

# Generated at 2022-06-11 21:32:58.462465
# Unit test for function parse
def test_parse():
    assert parse("Description\n") == Docstring(description="Description")
    assert parse("Description\n\nArgs:\n  arg1") == Docstring(description="Description", args=[DocstringArgument(name="arg1")])
    assert parse("Description\n\nArgs:\n  arg1 (type)\n    Description\n  arg2 : type\n    Description") == Docstring(description="Description", args=[DocstringArgument(name="arg1", type="type", desc="Description"), DocstringArgument(name="arg2", type="type", desc="Description")])

# Generated at 2022-06-11 21:33:05.661340
# Unit test for function parse
def test_parse():
    text = """This is a test module for pydocstyle.

    :param: test: a test parameter
    :returns: a test return
    """
    result = parse(text=text)
    assert result.summary == "This is a test module for pydocstyle."
    assert result.description == ""
    assert result.params == {"test": "a test parameter"}
    assert result.returns == "a test return"

# Generated at 2022-06-11 21:33:07.690994
# Unit test for function parse
def test_parse():
    text = '''"""
    Test function unit testing.
    """'''
    assert parse(text) == Docstring()

# Generated at 2022-06-11 21:33:17.340205
# Unit test for function parse
def test_parse():
    # test case 1
    text = """
    This is a example for docstring

    :param name: The name to use in the greeting.
    :param: 
    :returns str:
    """

    result = parse(text, style=Style.google)
    assert result.short_description == "This is a example for docstring"
    assert result.long_description is None
    assert result.params['name']['description'] == "The name to use in the greeting."
    assert result.params['name']['type'] is None
    assert result.returns['type'] == "str"

    # test case 2
    text = """
    This is a example for docstring

    :param name: The name to use in the greeting.
    :param: 
    """


# Generated at 2022-06-11 21:33:20.804145
# Unit test for function parse
def test_parse():

    assert parse('Hello World').short_description == 'Hello World'
    print("test_parse passed")
 
test_parse()

# Generated at 2022-06-11 21:33:34.499135
# Unit test for function parse
def test_parse():
    a = parse('This is a function')
    assert a.short_description == 'This is a function'
    assert a.long_description == 'This is a function'
    assert a.returns == None
    assert a.returns_description == None
    assert a.params == []
    assert a.raises == []
    assert a.yields == None

    a = parse('This is a function\n@param arg1 arg1 description')
    assert a.short_description == 'This is a function'
    assert a.long_description == 'This is a function'
    assert a.returns == None
    assert a.returns_description == None
    assert a.params[0].arg_name == 'arg1'
    assert a.params[0].arg_type == None

# Generated at 2022-06-11 21:33:45.556148
# Unit test for function parse
def test_parse():
    """
    Test the parsing routine by parsing a google style docstring.
    """
    text = """
    This is a google style docstring
    It also has a description spanning multiple lines.

    Args:
        arg1: blah blah blah
        arg2: blah blah blah

    Returns:
        blah blah blah"""
    parsed = parse(text)

    assert parsed.short_description == 'This is a google style docstring'
    assert parsed.long_description == 'It also has a description spanning multiple lines.'
    assert parsed.returns == 'blah blah blah'
    assert len(parsed.args) == 2
    assert len(parsed.kwargs) == 0
    assert len(parsed.exceptions) == 0
    assert parsed.args[0] == ('arg1', 'blah blah blah')
    assert parsed

# Generated at 2022-06-11 21:33:55.576070
# Unit test for function parse
def test_parse():
    text = """One line summary.

Longer, multi-line summary, which may
span several lines.

Args:
  arg1 (:obj:`int`): description.
  arg2 (:obj:`str`): description.

Returns:
  int: return description.

Raises:
  :obj:`ValueError`: if something bad happens.


.. _Google Python Style Guide:
   http://google.github.io/styleguide/pyguide.html
"""

    d = parse(text)
    assert len(d.args) == 2
    assert len(d.raises) == 1


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:34:02.610262
# Unit test for function parse
def test_parse():
    assert parse("").summary == ""
    assert parse(" ").summary == " "

    # Test with the test_docstrings script.
    import os
    import sys
    import subprocess
    from distutils.core import run_script

    old_argv = sys.argv
    script_name = os.path.join(os.path.dirname(__file__), "test_docstrings")
    try:
        sys.argv = [script_name]
        run_script(script_name, True)
    finally:
        sys.argv = old_argv


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_parse()

# Generated at 2022-06-11 21:34:09.503401
# Unit test for function parse
def test_parse():
    docstring = """Module docstring"""

    # Check default style
    assert parse(
        docstring).__dict__ == Docstring(
        meta={}, content=[docstring]).__dict__

    # Check google
    assert parse(
        docstring,
        style=Style.google).__dict__ == Docstring(
            meta={}, content=[docstring]).__dict__

# test_parse()

if __name__ == "__main__":
    # test_parse()
    pass

# Generated at 2022-06-11 21:34:20.808953
# Unit test for function parse
def test_parse():
    text = """
    (1) The first sentence of the docstring.

    (2) The second sentence of the docstring.

    :param name1: The first parameter.
    :type name1: str
    :param name2: The second parameter.
    :type name2: bool, optional
    :returns: Description of return value.
    :rtype: int
    :raises keyError: raises an exception
    """
    doc = parse(text)
    assert len(doc) == 4
    assert doc.short_description == "The first sentence of the docstring."
    assert doc.long_description == "The second sentence of the docstring."

# Generated at 2022-06-11 21:34:25.938092
# Unit test for function parse
def test_parse():
    docstr = """one line summary
    more description if needed
    :param arg1: the first argument
    :param arg2: the second argument
    :raises keyError: depends on input
    """
    assert (parse(docstr)) == Docstring('one line summary', 'more description if needed', ['arg1', 'arg2'], 'keyError')

# Generated at 2022-06-11 21:34:32.539741
# Unit test for function parse
def test_parse():
    text = '''
        This function does something.

        :param param1: The first parameter.
        :param param2: The second parameter.
        :returns: Description of return value.
        :raises keyError: raises an exception
        '''
    assert parse(text)
    assert parse(text, style=Style.google)
    assert parse(text, style=Style.numpy)
    assert parse(text, style=Style.rest)
    assert parse(text, style=Style.rst)



# Generated at 2022-06-11 21:34:43.761837
# Unit test for function parse
def test_parse():
    # Test simple doc string with description
    assert parse("""\
        first line
        second line""") == Docstring(
            description='first line\nsecond line',
            body=''
    )
    # Test simple doc string with summary
    assert parse("""\
        first line
        second line
        """, style=Style.numpy) == Docstring(
        summary='first line',
        description='second line',
        body=''
    )
    # Test docstring with body section

# Generated at 2022-06-11 21:34:50.047786
# Unit test for function parse
def test_parse():
    """docstring_parser.parse(text, style=Style.auto) -> Docstring
    Parse the docstring into its components.
    """
    class Dummy:
        """
        Dummy class for testing

        :param str some_parameter: name of a parameter
        """

    d = parse(Dummy.__doc__)
    assert d.short_description == "Dummy class for testing"
    assert d.long_description == None
    assert d.meta == {
        "param": [{"name": "some_parameter", "type": "str", "description": "name of a parameter"}],
    }

# Generated at 2022-06-11 21:34:59.594395
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`
Returns
-------
bool
    Description of return value"""
    docstring = parse(text)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == '\nExtended description.\n'
    assert docstring.get_section('return') == 'bool\n    Description of return value'

# Generated at 2022-06-11 21:35:11.274336
# Unit test for function parse
def test_parse():
    text = ("This is a Sphinx formatted docstring test.\n"
            "\n"
            "This is the first paragraph.\n\n"
            "Features\n"
            "^^^^^^^^\n"
            "- This is a feature\n"
            "- This is another feature\n"
            "\n"
            "Usage\n"
            "^^^^^\n"
            ".. code-block:: python\n"
            "\n"
            "    def parse(text, style):\n"
            "        try:\n"
            "            # Try with style\n"
            "        except ParseError:\n"
            "            # try without style")
    print(parse(text))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:35:21.412501
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import AutoStyle, GoogleStyle, NumpyStyle, GithubStyle, NumPyStyle, EpytextStyle
    from docstring_parser.docstring import Docstring
    import unittest

    class TestParse(unittest.TestCase):

        def test_parse_GoogleStyle(self):
            text = '''
            Args:
                arg1 (str): This is a first argument.
                arg2 (str): This is a second argument.
            '''
            result = parse(text)
            expected = Docstring(text)
            expected.args = {
                'arg1': 'This is a first argument.',
                'arg2': 'This is a second argument.'
            }
            self.assertEqual(result, expected)


# Generated at 2022-06-11 21:35:32.673616
# Unit test for function parse
def test_parse():
    text = '''\
    This is a function.

    Args:
        a (int): The first param.

    Returns:
        str: The return value.

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function/class.
        >>> a = 1
        >>> b = 2
        >>> a + b
        3'''
    assert parse(text).short_description == "This is a function."
    assert parse(text).long_description == (
        "Examples should be written in doctest format, and should illustrate "
        "how to use the function/class.\n"
        ">>> a = 1\n"
        ">>> b = 2\n"
        ">>> a + b\n"
        "3"
    )

# Generated at 2022-06-11 21:35:38.564366
# Unit test for function parse
def test_parse():
    text = """This is an API level docstring with an API parameter and an API
        return type with a nice javadoc style"""
    docstring = parse(text, style=Style.javadoc)
    assert docstring.short_description == "This is an API level docstring with an API parameter and an API\n        return type with a nice javadoc style"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:43.757795
# Unit test for function parse
def test_parse():
    class Docstring(object):
        """Docstring class.

        :param lines: array of docstring lines
        :param meta: dictionary of metadata contained in lines
        """

        def __init__(self, lines, meta):
            self.lines = lines
            self.meta = meta

    assert parse('') == Docstring([], {})

test_parse()

# Generated at 2022-06-11 21:35:48.869934
# Unit test for function parse
def test_parse():
    """Test function parse."""

    text = '''
    This is a test.

    :param a: the param
    :type a: int

    :returns: the return
    :rtype: float
    '''
    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:35:50.044109
# Unit test for function parse
def test_parse():
    parse('"Simple docstring to test"')

# Generated at 2022-06-11 21:36:00.274689
# Unit test for function parse
def test_parse():
    """Test parse function."""

    text = """\
A long description with multiple lines.

    Parameters
    ----------
    foo
        First parameter
    bar
        Second parameter
    baz
        Third parameter

    Returns
    -------
    str
        Something back
    """

    docstring = parse(text)
    assert docstring.long_description == 'A long description with multiple lines.'
    assert len(docstring.params) == 3
    assert docstring.params[0].name == 'foo'
    assert docstring.returns.type_name == 'str'
    assert docstring.returns.description == 'Something back'
    assert docstring.style == 'numpy'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:36:10.912570
# Unit test for function parse
def test_parse():
    text = """This is first line.
    This is second line.
    This is third line.
    :param pA
    :param pB
    :return title
    :return desc
    :rtype return_type
    """
    doc = parse(text, style=Style.sphinx)
    assert doc.short_description == "This is first line.\nThis is second line.\nThis is third line.\n"
    assert doc.long_description == ""
    assert doc.params == {'pA': '', 'pB': ''}
    assert doc.returns == [('title', 'desc', 'return_type')]
    assert doc.meta == {}
    assert doc.notes == []
    assert doc.examples == []
    assert doc.style == Style.sphinx