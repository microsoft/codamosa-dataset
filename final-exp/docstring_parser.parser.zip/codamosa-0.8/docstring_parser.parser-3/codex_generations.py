

# Generated at 2022-06-11 21:26:23.830295
# Unit test for function parse
def test_parse():
    for style in STYLES:
        text = """

Description
-----------

Some sparce text that describes the function.

Parameters
----------
foo : :class:`str`
    Some dummy parameter.

Other Parameters
----------------
bar : :class:`int`
    Some other dummy parameter.

Returns
-------
:class:`tuple`
    Description of what is returned.

Raises
------
RuntimeError
    If things go wrong.

"""
        docstring = parse(text, style=style)
        print(docstring)
        print(docstring.short_description)
        print(docstring.long_description)
        print(docstring.meta['returns'])
        print(docstring.meta['raises'])
        print(docstring.meta['parameters'])

# Generated at 2022-06-11 21:26:34.026452
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    assert parse('Spam eggs') == Docstring(summary='Spam eggs', description='', returns='', params=[])
    assert parse('') == Docstring(summary='', description='', returns='', params=[])
    assert parse('Spam eggs\n\nDescription\n\nDescription line.') == Docstring(summary='Spam eggs', description='Description line.', returns='', params=[])
    assert parse('Spam eggs\n\tDescription\n\tDescription line.') == Docstring(summary='Spam eggs', description='Description line.', returns='', params=[])

# Generated at 2022-06-11 21:26:39.446531
# Unit test for function parse
def test_parse():
    text='''
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    assert type(parse(text))==docstring_parser.styles.NumpyDocstring

# Generated at 2022-06-11 21:26:46.597445
# Unit test for function parse
def test_parse():
    # Given
    text = """\
        :param data.DataFrame df: data frame with data to add

        return a DataFrame
        """

    # When
    d = parse(text)

    # Then
    assert d.short_description == ''
    assert d.long_description == ''
    assert d.meta['param'][0].args == ['data.DataFrame df']
    assert d.meta['param'][0].description == 'data frame with data to add'
    assert d.returns.args == ['DataFrame']
    assert d.returns.description == 'return a DataFrame'

# Generated at 2022-06-11 21:26:54.971628
# Unit test for function parse
def test_parse():
    expected = {
        'params': ['string'],
        'returns': True,
        'rtype': 'bool',
        'summary': "Check whether input string is a URL.",
        'description': "Check whether input string is a URL.\n",
        'meta': {
            'title': 'is_url',
            'author': 'Brian K. Jones',
            'author_email': 'bkjones@gmail.com',
            'copyright': 'Copyright (c) 2015, Brian K. Jones.',
            'license': 'MIT',
            'version': '0.1',
        }
    }
    result = parse(parse_str)
    assert expected == result


# Generated at 2022-06-11 21:27:07.108269
# Unit test for function parse
def test_parse():
    # test 1
    text = """\
    This is a test docstring.

    :param arg1: the first argument
    :param arg2: the second argument

    :type arg1: string
    :type arg2: int, optional

    :returns: description of return value
    :rtype: int

    :raises exception_name: explanation of why/when the exception is raised
    """

    style = Style.auto
    style = Style.numpy
    d1 = parse(text, style)
    assert d1.short_description == 'This is a test docstring.'
    assert d1.long_description == ''
    assert d1.returns.description == 'description of return value'
    assert d1.returns.type_annotation == 'int'
    assert len(d1.params) == 2

# Generated at 2022-06-11 21:27:19.499022
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse
    from docstring_parser import parse
    import docstring_parser
    docstring_parser.__version__
    parse.__doc__
    c = parse(r'''
    this is a dummy function
    ''')
    c.concat()
    c.summary
    c.body  # returns None
    assert c.style == 'numpy'

    c = parse(r'''
    dummy function

    Parameters
    ----------
    data1 : ndarray
        Array of data.
    data2 : ndarray
        Another array of data.
    ''')
    c.concat()
    c.summary
    c.body
    c.args
    assert c.style == 'numpy'

# Generated at 2022-06-11 21:27:30.329602
# Unit test for function parse
def test_parse():
    d = parse(u'')
    assert d == Docstring(short_description=u'',
                          long_description=u'', meta={})
    d = parse(u'TODO(dcramer): figure out how to make this work')
    assert d == Docstring(short_description=u'',
                          long_description=u'', meta={u'todo': u'figure out how to make this work'})
    d = parse(u' ::\n\\tThis is a test.\n\\tAnother line.\n    ')
    assert d == Docstring(short_description=u'',
                          long_description=u'This is a test.\nAnother line.', meta={})
    d = parse(u'This is a test.\n\nThis is another test.')
    assert d == Docstring

# Generated at 2022-06-11 21:27:41.879637
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    analyzed = parse('''
    Simple function.

    :param int: param x
    :param y: param y
    :returns: description of return
    :raises ValueError: if x is negative
    ''')
    assert analyzed.short_description == 'Simple function.'
    assert analyzed.long_description == ''
    assert analyzed.returns.type_name == 'returns'
    assert analyzed.returns.description == 'description of return'
    assert len(analyzed.params) == 2
    assert analyzed.params['int'].type_name == 'int'
    assert analyzed.params['int'].description == 'param x'
    assert analyzed.params['y'].type_name == ''
    assert analyzed.params['y'].description == 'param y'
   

# Generated at 2022-06-11 21:27:46.188945
# Unit test for function parse
def test_parse():
    text = '''
    One line summary.

    Several lines long description.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'One line summary.'
    assert docstring.long_description == 'Several lines long description.'



# Generated at 2022-06-11 21:28:00.835228
# Unit test for function parse
def test_parse():
    # happy path
    text = """This is a docstring.

:param param1: This is a first param.
:param param2: This is a second param.
:keyword kwarg1: This is a first keyword arg.
:keyword kwarg2: This is a second keyword arg.
:return: This is a return type.
:raises: IOError, ZeroDivisionError
"""
    doc = parse(text)
    assert doc is not None
    assert isinstance(doc, Docstring)
    validate_happy_path_docstring(doc)
    # test auto style

# Generated at 2022-06-11 21:28:05.686124
# Unit test for function parse
def test_parse():
    text = "test parse"
    s = Style.numpy
    d = parse(text,s)
    print(d)
    s = Style.google
    d = parse(text,s)
    print(d)
    d = parse(text)
    print(d)
    
#test_parse()
# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-11 21:28:06.982841
# Unit test for function parse
def test_parse():
    assert parse('hello world').summary == 'hello world'

# Generated at 2022-06-11 21:28:18.119091
# Unit test for function parse
def test_parse():
    result = parse(test_doc1, style=style1)
    assert result.short_description == 'Lorem ipsum.'
    assert result.long_description == '\nDolor sit amet.\n'
    assert result.long_description.strip() == 'Dolor sit amet.'
    assert result.meta['arguments'][0].arg_name == 'foo'
    assert result.meta['arguments'][0].type_name == int
    assert result.meta['arguments'][0].description == 'Baz.'
    assert result.meta['arguments'][1].arg_name == 'bar'
    assert result.meta['arguments'][1].type_name is None
    assert result.meta['arguments'][1].description == 'Baz.'
    assert result.meta['keywords'][0].arg

# Generated at 2022-06-11 21:28:21.824593
# Unit test for function parse
def test_parse():
    test_docstring = '''\
    Describe Clx file format here.

    :param arg1: the first value
    :param arg2: the first value
    :returns: None
    :raises keyError: raises an exception
    '''
    test_docstring = parse(test_docstring)

# Generated at 2022-06-11 21:28:34.011938
# Unit test for function parse
def test_parse():
    docstring = """\
One-line summary.

    Extended summary.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.
    param3 : List[int]
        The third parameter.

    Attributes:
    ----------
    attr1 : str
        Docstring for attribute `attr1`.
    attr2 : str
        Docstring for attribute `attr2`.
    attr3 : str
        Docstring for attribute `attr3`.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    parsed_docstring = parse(docstring)
    print(parsed_docstring)
   

# Generated at 2022-06-11 21:28:39.297591
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

Extended description.

Parameters
----------
arg1 : int
    Description of arg1
arg2 : str
    Description of arg2
Returns
-------
str
    Description of return value
"""

    d = parse(docstring)

# Generated at 2022-06-11 21:28:49.013695
# Unit test for function parse
def test_parse():
    """Tests the parse function of the parser module."""
    from docstring_parser.common import Docstring
    docstring = Docstring()
    docstring.short_description = 'Short description'
    docstring.long_description = '\n  Long description'
    docstring.params['arg'] = ['Test arg']
    docstring.params['optarg'] = ['Default arg with value `optval`']
    docstring.params['optarg2'] = ['Optional arg with no value']
    docstring.returns['ret'] = ['Test return value']
    docstring.meta['author'] = ['Test author']
    docstring.meta['note'] = ['Test note']

# Generated at 2022-06-11 21:28:59.569841
# Unit test for function parse
def test_parse():
    from pprint import pprint
    from .common import ParseError

    from . import google
    from . import numpy
    from . import sphinx
    from . import epytext

    def p(text, style=None):
        r = parse(text, style)
        pprint(r._asdict())

    def x(text, style=None):
        r = parse(text, style)
        pprint(r.short_description)
        pprint(r.long_description)

    # test case 1
    text = """
        Function to do x and y.

        This function does x and y.

        :param x: Parameter x
        :type x: int
        :param y: Parameter y
        :type y: int
        """

    x(text)

# Generated at 2022-06-11 21:29:09.776746
# Unit test for function parse
def test_parse():
    text = '''
    The quick brown fox jumps over the lazy dog.

    :param int this: this is a paragraph
    :param this: this is another paragraph

    :raises ValueError: This is the first sentence
                            of this paragraph.

                         This is the second sentence
                         of this paragraph.

    This is the first sentence of this paragraph.

    This is the second sentence of this paragraph.

    '''

    d = parse(text)
    assert(d.short_description == 'The quick brown fox jumps over the lazy dog.')
    assert(d.long_description == 'This is the first sentence of this paragraph.\n\nThis is the second sentence of this paragraph.')
    assert(len(d.meta) == 2)
    assert(d.meta[0].name == "this")

# Generated at 2022-06-11 21:29:27.644594
# Unit test for function parse
def test_parse():
    import docstring_parser
    docstring = docstring_parser.parse('''
    Args:
        input_data (pandas.DataFrame): input data
        input_name (str, optional): input name
        output_path (str): output path''')
    assert docstring.args[0].name == 'input_data'
    assert docstring.args[1].name == 'input_name'
    assert docstring.args[2].name == 'output_path'
    assert docstring.args[0].annotation == 'pandas.DataFrame'
    assert docstring.args[1].annotation == 'str'
    assert docstring.args[2].annotation == 'str'
    assert docstring.returns.name == 'str'
    assert docstring.returns.annotation == 'str'
   

# Generated at 2022-06-11 21:29:32.314233
# Unit test for function parse
def test_parse():
    # Unit test for parse
    text = """This is Function1
    :rtype: String
    """
    # test for text
    assert parse(text).short_description == "This is Function1"
    # test for return type
    assert parse(text).returns[0].type_name == "String"

# Generated at 2022-06-11 21:29:41.110378
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="",
                                  description="",
                                  operation="",
                                  arguments=dict(),
                                  operation_returns="",
                                  operation_raises="",
                                  operation_examples="",
                                  meta=dict(),
                                  operation_yields="")


# Generated at 2022-06-11 21:29:50.788283
# Unit test for function parse
def test_parse():
    """Test func parse"""
    text = '''Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    docstring = parse(text)
    assert docstring.short_description == 'Parse the docstring into its components.'
    assert docstring.long_description == ''
    assert docstring.params == {'text': 'docstring text to parse', 'style': 'docstring style'}
    assert docstring.returns == 'parsed docstring representation'


# Generated at 2022-06-11 21:29:53.646555
# Unit test for function parse
def test_parse():
    ds = parse("""
    This is a test
    """)
    assert ds.short_description == "This is a test"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:04.575292
# Unit test for function parse
def test_parse():
    doc = parse("""
    Convert input to a floating point number.

    :param x: Input.
    :type x: float or int.

    :return: The floating point number.
    :rtype: float.
    """)

    assert len(doc.sections) == 2

    assert doc.sections[0].title == "Parameters"
    assert len(doc.sections[0].content) == 2
    assert len(doc.sections[0].content[0]) == 2
    assert doc.sections[0].content[0][0] == "x"
    assert doc.sections[0].content[0][1] == "Input."
    assert len(doc.sections[0].content[1]) == 2
    assert doc.sections[0].content[1][0] == "x"

# Generated at 2022-06-11 21:30:06.749267
# Unit test for function parse
def test_parse():
    assert parse("")
    assert parse("a")
    assert parse("a\nb")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:15.420780
# Unit test for function parse
def test_parse():
    text = """\
    This is a module docstring.

    :param foobar: parameter
    :type foobar: int
    :returns: value
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a module docstring."
    assert docstring.long_description.lines == []
    assert docstring.params == {"foobar": "parameter"}
    assert docstring.returns == "value"
    assert str(docstring) == text


# Change file "test_docstring_parser.py"
test_parse()

# Generated at 2022-06-11 21:30:19.521658
# Unit test for function parse
def test_parse():
    docstring = """
        This function does something.

        :param str var: This is a string.
        :raises TypeError: if var is not a string
    
        :returns: None
    
        """
    assert parse(docstring).params['var'].arg_type == 'str'

# Generated at 2022-06-11 21:30:30.869246
# Unit test for function parse
def test_parse():
    text = '''\
    """
    This is a one-line summary.

    This is a longer description. You might want to break it into
    a paragraph.

    Parameters
    ----------
    arg1 : int, optional
        This is an argument.
    arg2 : str
        This is another argument.

    Returns
    -------
    int
        This is a return.
    """
    '''

    docstring = parse(text)

    # Basic assertions
    assert docstring.summary == 'This is a one-line summary.'
    assert 'paragraph.' in docstring.description

    # Section parsing
    assert 'arg1' in docstring.params
    assert 'arg2' in docstring.params
    assert docstring.params['arg1'] == 'This is an argument.'

# Generated at 2022-06-11 21:30:42.916704
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring

    :param param1: this is a first parameter
    :param param2: this is a second parameter
    :type param1: int
    :type param2: int
    :returns: this is a return string
    :rtype: int
    '''
    components = parse(text)
    assert components.meta['param1'] == 'this is a first parameter'
    assert components.meta['param2'] == 'this is a second parameter'
    assert components.meta['returns'] == 'this is a return string'
    assert components.summary == 'This is a test docstring'

# Generated at 2022-06-11 21:30:46.158560
# Unit test for function parse
def test_parse():
    text = '''This is a docstring.'''
    print(parse(text))
    return None

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:30:57.744729
# Unit test for function parse
def test_parse():
    assert parse('hello') == Docstring(summary='hello', description='')
    assert parse('''
Hello, `world`__.

.. __: http://google.com
''') == Docstring('Hello, `world`__.', description='', meta='''
.. __: http://google.com
''')
    assert parse('''
Hello, `world`__.


.. __: http://google.com
''') == Docstring('Hello, `world`__.', description='', meta='''
''')
    assert parse('''
Hello, `world`__.

__ http://google.com
''') == Docstring('Hello, `world`__.', description='', meta='''
__ http://google.com
''')

# Generated at 2022-06-11 21:31:03.714778
# Unit test for function parse
def test_parse():
    text = """
    Hello world!
    This is a doc string.

    :param str param1: the first param
    :param str param2: the second param
    :return: None
    """
    print('Parse test result:')
    print(parse(text, style = Style.sphinx))
    return

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:31:15.312819
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    assert parse(text='text', style='text')==Docstring('text', [])
    assert parse(text='', style='text')==Docstring('', [])
    assert parse(text='text', style='')==Docstring('text', [])
    assert parse(text='', style='')==Docstring('', [])
    assert parse(text='text')==Docstring('text', [])
    assert parse(text='')==Docstring('', [])
#test_parse()

# Generated at 2022-06-11 21:31:19.373793
# Unit test for function parse
def test_parse():
    docstring = """The main 
    parsing routine.
        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """
    p = parse(docstring, style=Style.numpy)
    print(p)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:31:31.364725
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    import unittest

    class TestParse(unittest.TestCase):
        """Test class for function parse"""

        def test_parse_rst(self):
            """Unit test for function parse: rst-style docstring"""
            func_name = 'parse'
            param_name = 'style'
            text = ':param ' + param_name + ': docstring style\n'
            text = text + ':returns: parsed docstring representation'
            result = parse(text)
            self.assertEqual(result.short_description, '')
            self.assertEqual(result.long_description, '')
            self.assertEqual(result.params[0].arg_name, param_name)

# Generated at 2022-06-11 21:31:39.599109
# Unit test for function parse
def test_parse():
    text = '''
    Summarized title
    ================
    
    Paragraph 1.
    
    Paragraph 2.
    '''
    docstring = parse(text)
    assert docstring.title == 'Summarized title'
    assert docstring.content == 'Paragraph 1.\n\nParagraph 2.\n'
    assert docstring.content_raw == '    Paragraph 1.\n    \n    Paragraph 2.\n'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:31:48.423923
# Unit test for function parse
def test_parse():
    """
        The function parse parses the docstring into its components.
    """
    from docstring_parser.docstring import FunctionDocstring, Parameter, ReturnValue
    from docstring_parser.parsers import GoogleParser
    import pytest

    def func():
        """Description of the function

        :type a: str
        :param a: Param a of type str

        :type b: str
        :param b: Param b of type str

        :rtype: str
        :returns: return value of type str
        """
        pass

    style = Style.google

# Generated at 2022-06-11 21:31:56.436010
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Returns a full API response object with API data, meta and metadata.

    This function is intended to be used in API calls that need to return a
    full API response object.

    **Example**::

        api_response = api.response({'data': data})

    :param data: API data
    :param meta: API meta data
    :param metadata: API metadata
    :returns: API response object
    """)
    assert len(docstring.meta['returns']) == 1
    assert len(docstring.meta['example']) == 1
    assert len(docstring.meta['param']) == 3



# Generated at 2022-06-11 21:32:11.080205
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    # Test 1:
    text="""
    docstring sample
    """
    d = parse(text)
    print("1.1: Should return []: {0}".format(d.meta))
    print("1.2: Should return []: {0}".format(d.content))

    # Test 2:
    text="""
    ```python
    def foo():
        pass
    ```
    """
    d = parse(text)
    print("2.1: Should return []: {0}".format(d.meta))
    print("2.2: Should return a list with 1 member: {0}".format(d.content))

    # Test 3:
    text="""
    :param name: name here
    :type name: str
    """

# Generated at 2022-06-11 21:32:13.658228
# Unit test for function parse
def test_parse():
    sample_docstring = '''Keyword arguments:
                arg1 -- blah blah
                arg2 -- blah blah'''
    assert parse(sample_docstring)


# Generated at 2022-06-11 21:32:18.388216
# Unit test for function parse
def test_parse():
    """Run unit test for function parse"""
    import doctest
    doctest.testmod(verbose=True)

# Run unit test for function parse if module is executed as a script
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-11 21:32:29.236825
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(meta=[])
    assert parse("Summary only.") == Docstring(summary="Summary only.")
    assert parse("Summary only", Style.pep257) == Docstring(summary="Summary only.")
    assert parse("Summary only", Style.google) == Docstring(summary="Summary only.")
    assert parse("Summary only", Style.numpy) == Docstring(summary="Summary only.")
    assert parse("Summary") == Docstring(summary="Summary")
    assert parse("Summary", Style.pep257) == Docstring(summary="Summary")
    assert parse("Summary", Style.google) == Docstring(summary="Summary")
    assert parse("Summary", Style.numpy) == Docstring(summary="Summary")



# Generated at 2022-06-11 21:32:34.377210
# Unit test for function parse
def test_parse():
    text='''
    Classify the data into given number of classes
    Parameters
    ----------
    data: 2D Numpy array
        Data to be classified
    n_classes: int
        Number of classes
    '''
    parsed=parse(text,Style.numpy)
    print(parsed.parameters)
    print(parsed.returns)
    
    
test_parse()

# =============================================================================
# 
# =============================================================================

# Generated at 2022-06-11 21:32:40.279983
# Unit test for function parse
def test_parse():
    text = '''This is a test example.
    :param a: the first parameter
    :param b: the second parameter
    :returns: the return value
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a test example.'
    assert doc.long_description == ''
    assert doc.returns.description == ['the return value']
    assert doc.params[0].name == 'a'
    assert doc.params[0].description == 'the first parameter'

# Generated at 2022-06-11 21:32:42.442362
# Unit test for function parse
def test_parse():

    text = r"""This is
a test function.

:param test: test first arg
"""

    docstring = parse(text)



# Generated at 2022-06-11 21:32:51.339349
# Unit test for function parse
def test_parse():
    text = """This is an example docstring.  Here's a list:
    
    - one
    - two
    
    And more text."""
    # parse
    docstring = parse(text)
    # test if results are correct
    assert docstring.short_description == "This is an example docstring."
    assert docstring.long_description == "Here's a list:\n\n- one\n- two\n\nAnd more text."
    assert len(docstring.meta) == 0

    # test if parse with default style works
    docstring = parse(text, style=Style.default)
    assert docstring.short_description == "This is an example docstring."
    assert docstring.long_description == "Here's a list:\n\n- one\n- two\n\nAnd more text."

# Generated at 2022-06-11 21:32:53.453928
# Unit test for function parse
def test_parse():
    text = """
    This is a Docstring
    """
    d = parse(text)
    assert isinstance(d, Docstring)



# Generated at 2022-06-11 21:32:56.431471
# Unit test for function parse
def test_parse():
    """Unit test for parse function."""
    import unittest
    import doctest
    tests = doctest.DocTestSuite(optionflags=doctest.ELLIPSIS)
    tests.layer = tests
    return tests

# Generated at 2022-06-11 21:33:04.043387
# Unit test for function parse
def test_parse():
    r = parse("""Hello
    world""")
    assert r.short_description == 'Hello'
    assert r.long_description == ['world']


# Generated at 2022-06-11 21:33:12.494512
# Unit test for function parse
def test_parse():
    """Test for parse function"""
    assert type(parse("this is the docstring\n")) == docstring_parser.parse_auto.ParseAuto
    assert type(parse("this is the docstring\n", docstring_parser.styles.Style.google)) == docstring_parser.parse_google.ParseGoogle
    assert type(parse("this is the docstring\n", docstring_parser.styles.Style.numpy)) == docstring_parser.parse_numpy.ParseNumpy
    assert type(parse("this is the docstring\n", docstring_parser.styles.Style.sphinx)) == docstring_parser.parse_sphinx.ParseSphinx


# Generated at 2022-06-11 21:33:20.083883
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google, NumPy, ReStructuredText
    
    text_1 = "This is a docstring in Google format."
    text_2 = "This is a docstring in NumPy format."
    text_3 = "This is a docstring in ReStructuredText format."
    
    assert parse(text_1, Style.google) == Google(text_1)
    assert parse(text_1, Style.numpy) == NumPy(text_1)
    assert parse(text_1, Style.restructuredtext) == ReStructuredText(text_1)
    assert parse(text_1) == Google(text_1)
    
    assert parse(text_2, Style.google) == Google(text_2)

# Generated at 2022-06-11 21:33:24.173405
# Unit test for function parse
def test_parse():
    """Sample docstring to test."""
    text = '''
    Args:
        test (int): this is a test.
        test2 (str): this is another test.
    '''

    style = parse(text)
    assert style == Style.google

# Generated at 2022-06-11 21:33:34.576976
# Unit test for function parse
def test_parse():
    text = """
        Args:
            arg1 (int): Description of `arg1`.
            arg2 (str): Description of `arg2`.

        Keyword Args:
            kwarg1 (str): Description of `kwarg1`.
            kwarg2: Description of `kwarg2`.

        Raises:
            ValueError: If `arg1` already exists.

        Returns:
            bool: Description of return value.

        Examples:
            Examples should be written in doctest format, and
            should illustrate how to use the function.

            >>> a = [1, 2, 3]
            >>> print([x + 3 for x in a])
            [4, 5, 6]

        """
    rets = parse(text)
    print(rets.args)
    print(rets.kwargs)

# Generated at 2022-06-11 21:33:44.640876
# Unit test for function parse
def test_parse():
    text = \
'''HOGE docstring

Args:
    arg1: arg1_type, arg1_description
    arg2: arg2_type, arg2_description

Returns:
    return_type, return_description
    
'''
    expected = Docstring(
        description=['HOGE docstring'],
        args=[
            ('arg1', 'arg1_type', 'arg1_description'),
            ('arg2', 'arg2_type', 'arg2_description'),
        ],
        returns=('return_type', 'return_description')
    )
    assert parse(text) == expected

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-11 21:33:53.556637
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    import pytest
    def test_parse():
        text = """
        :param foo: does something
        :param bar: does something else
        :return: None
        """
        d = parse(text, style=Style.sphinx)
        assert isinstance(d, Docstring)
        text = """
        :foo: does something
        :bar: does something else
        :return: None
        """
        with pytest.raises(ParseError):
            parse(text, style=Style.sphinx)

# Generated at 2022-06-11 21:34:02.049602
# Unit test for function parse
def test_parse():
    class A:
        """Parse the docstring into its components.
        
        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """

    class B:
        """Parse the docstring into its components.
        
        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """
    class C:
        """Parse the docstring into its components.
        
        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """    

# Generated at 2022-06-11 21:34:09.892912
# Unit test for function parse
def test_parse():
    text = '''"""This is the docstring.

It has multiple lines.

:param x: parameter x
:param y: parameter y

:raises ValueError: if x < y

:return: something useful
:rtype: int
:return: something else (optional)"""'''
    doc = parse(text)
    assert len(doc.summary)==1
    assert len(doc.meta)==4
    assert len(doc.desc)==2
    assert len(doc.returns)==2


# Generated at 2022-06-11 21:34:21.037972
# Unit test for function parse
def test_parse():
    """Check the correctness of function parse"""
    text = ["The main parsing routine. \n\n", "This is a description about the function.\n", "\n", "Parameters \n", "----------\n", "text: str\n", "\t", "docstring text to parse\n", "style: Style= Style.auto\n", "\t", "docstring style\n", "\n", "Returns\n", "-------\n", "parsed docstring representation\n"]
    text = "".join(text)
    #print(text)
    assert(parse(text).summary == 'The main parsing routine.')
    assert(parse(text).description == 'This is a description about the function.\n\n')
    assert(parse(text).meta['Parameters'][0].name == 'text')

# Generated at 2022-06-11 21:34:28.270113
# Unit test for function parse
def test_parse():
    """ Test the function parse with doctest example in the official source code """
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_parse()



# Generated at 2022-06-11 21:34:36.093390
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    text='''
    input: str
        Args:
            output (str): hello world 2
            func (str): qq
        Returns:
            str: hello world
        
        Raises:
            NotImplementedError: The input must not be empty.
    '''
    docstring = parse(text)
    google = GoogleStyle(text)
    print(docstring.summary)
    print(docstring.meta)
    print(docstring.extras)
    print(docstring.raw)
    
    print(GoogleStyle(text).meta)
    print(GoogleStyle(text).raw)
    print(GoogleStyle(text).extras)
    print(GoogleStyle(text).summary)

test_parse()

# Generated at 2022-06-11 21:34:46.675454
# Unit test for function parse
def test_parse():
    """Test the parse(text, style) function
    """
    text = """Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    style = Style.numpy
    test = parse(text, style)
    assert(test.short_description == "Parse the docstring into its components.")
    assert(len(test.params) == 2)
    assert(test.params[0].name == "text")
    assert(test.params[0].description == "docstring text to parse")
    assert(test.params[1].name == "style")
    assert(test.params[1].description == "docstring style")
    assert(len(test.returns) == 1)

# Generated at 2022-06-11 21:34:57.602890
# Unit test for function parse
def test_parse():
    import sys
    import os
    from docstring_parser.parser import parse
    from docstring_parser._parser import Parser

    class SampleParser(Parser):
        keys = {
            'author': (1, 'last'),
            'status': (1, 'last'),
            'version': (2, 'last'),
        }

        @staticmethod
        def parse(content):
            return Parser.parse(content, SampleParser.keys)

    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_parse.py'), 'r', encoding='utf-8') as f:
        try:
            docstring = f.read()
        except UnicodeDecodeError:
            print("UnicodeDecodeError: test_parse.py")

# Generated at 2022-06-11 21:35:08.900867
# Unit test for function parse
def test_parse():
    docstring = '''Example docstring.
Example multi-line docstring.
Parameters
----------
arg1 : int
    The first argument.
arg2 : str
    The second argument.
arg3 : list
    The third argument.
Raises
------
AttributeError
    The class attribute is read-only.
KeyError
    The dict key doesn't exist.
OtherError
    Something else went wrong.
Returns
-------
str
    The return value. True for success, False otherwise.'''
    docstring_object = parse(docstring)
    assert docstring_object.short_description == 'Example docstring.'
    assert docstring_object.long_description == 'Example multi-line docstring.'
    assert docstring_object.sections["Parameters"]["arg1"] == "The first argument."

# Generated at 2022-06-11 21:35:17.756487
# Unit test for function parse
def test_parse():
    # test simple example
    text = """Returns the lunar phase angle

    The lunar phase angle is the angle from the centre of the Moon to the
    centre of the Earth, as viewed from the centre of the Sun.

    This is a test for the description.

    Args:
        time (:obj:`datetime.datetime`, optional): input time,
            default=``datetime.utcnow()``

    Raises:
        ValueError: raised if ``time`` is invalid

    Returns:
        :obj:`float`: the lunar phase angle in degrees
    """
    print(parse(text))

# Generated at 2022-06-11 21:35:29.772305
# Unit test for function parse
def test_parse():
    def fn(x):
        """This is a test.

        >>> def f(a):
        ...     return a*a
        >>> f(4)
        16
        """
    text = fn.__doc__

    class Foo(object):
        """This is a class test.

        >>> def f(a):
        ...     return a*a
        >>> f(4)
        16
        """

    text = Foo.__doc__

    class Foo(object):
        """This is a class test.

        :param a: a
        :returns: a*a
        """

    text = Foo.__doc__
    assert parse(text).summary == "This is a class test."
    assert parse(text).description == ""
    assert len(parse(text).params) == 2

# Generated at 2022-06-11 21:35:39.057405
# Unit test for function parse
def test_parse():
  text = """One liner.
  :param str foo: Foo parameter.
  :param dict bar: Bar parameter.
  :raises ValueError: blah blah blah."""
  doc = parse(text)
  assert doc.summary == 'One liner.'
  assert len(doc.params) == 2
  assert len(doc.raises) == 1
  assert len(doc.examples) == 0
  assert len(doc.returns) == 0
  doc = parse(text, style="numpy")
  assert doc.summary == 'One liner.'
  assert len(doc.params) == 2
  assert len(doc.raises) == 1
  assert len(doc.examples) == 0
  assert len(doc.returns) == 0
  doc = parse(text, style="google")

# Generated at 2022-06-11 21:35:41.991470
# Unit test for function parse
def test_parse():
    assert parse('a')
    assert parse('')
    def fn():
        """
        yaml
        ---
        a:
          - b
        """
        pass
    assert parse(fn.__doc__)

# Generated at 2022-06-11 21:35:45.584377
# Unit test for function parse
def test_parse():
    """Function for testing the parse function.
    """
    ds = """
    test fucntion
    """
    print(parse(ds))
    print(parse(ds, Style.numpy))

# Generated at 2022-06-11 21:35:51.968797
# Unit test for function parse
def test_parse():
    """
    >>> text='This is a simple sentence and\\ncontinues in the next line.'
    >>> doc = parse(text)
    >>> doc.short_description
    'This is a simple sentence and'
    >>> doc.long_description
    'continues in the next line.'
    """

# Generated at 2022-06-11 21:36:02.640656
# Unit test for function parse
def test_parse():
    text = """Single line summary

    Single line extended description

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value

    Raises:
        ValueError: If `invalidate` is True.
    """
    doc = parse(text)
    assert(doc.summary == "Single line summary")
    assert(doc.extended_summary == "Single line extended description")
    assert(len(doc.params) == 2)
    assert(doc.params[0].type_name == "int")
    assert(doc.params[1].arg_name == "arg2")
    assert(len(doc.returns) == 1)
    assert(doc.returns[0].type_name == "bool")

# Generated at 2022-06-11 21:36:13.142229
# Unit test for function parse
def test_parse():
    text = '''
    This is a summary.

    This is the description
    '''
    assert parse(text).summary == 'This is a summary.'
    assert parse(text).description == 'This is the description'

    text = '''
    :param p1: param 1
    :type p1: int
    :param p2: param 2
    :type p2: float
    :returns: return value
    :rtype: int
    :raises AnError: when it happens
    '''
    assert parse(text).params['p1'] == "param 1"
    assert parse(text).params['p2'] == "param 2"
    assert parse(text).returns == "return value"
    assert parse(text).raises['AnError'] == "when it happens"
