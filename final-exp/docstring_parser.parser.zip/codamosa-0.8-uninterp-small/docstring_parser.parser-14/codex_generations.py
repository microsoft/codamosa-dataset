

# Generated at 2022-06-25 16:33:40.506385
# Unit test for function parse
def test_parse():
    # Basic test
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    # Test function
    str_1 = 'Test function'
    docstring_1 = parse(str_1)
    # Simple test
    str_2 = 'Simple test'
    docstring_2 = parse(str_2)
    # Test function with args
    str_3 = 'Test function with args'
    docstring_3 = parse(str_3)
    # Test function with meta
    str_4 = 'Test function with meta'
    docstring_4 = parse(str_4)
    # Test function with nested args
    str_5 = 'Test function with nested args'
    docstring_5 = parse(str_5)
    # Test function with nested meta

# Generated at 2022-06-25 16:33:51.357501
# Unit test for function parse
def test_parse():
    assert [1, 2, 3] == [1, 2, 3], "Should be true"

    assert True == True, "Should be true"

    assert 3.14 >= 3.14, "Should be true"

    assert 'abc' == 'abc', "Should be true"

    assert [1, 2, 'abc'] == [1, 2, 'abc'], "Should be true"

    assert [1, 2, 3] == [1, 2, 3], "Should be true"

    assert 3.14 >= 3.14, "Should be true"

    assert 'abc' == 'abc', "Should be true"

    assert [1, 2, 'abc'] == [1, 2, 'abc'], "Should be true"

    assert [1, 2, 3] == [1, 2, 3], "Should be true"

    assert 3.

# Generated at 2022-06-25 16:33:59.013667
# Unit test for function parse
def test_parse():
    assert parse('a\nb\nc') == parse('a\nb\nc')
    assert parse('\n') == parse('\n')
    assert parse('  ') == parse('  ')
    assert parse('ab') == parse('ab')
    assert parse('abcabcabc') == parse('abcabcabc')
    assert parse('test case 0') == parse('test case 0')
    assert parse('testcase0') == parse('testcase0')
    assert parse('TestCase0') == parse('TestCase0')
    assert parse('test\ncase\n0') == parse('test\ncase\n0')
    assert parse('test\r\ncase\r\n0') == parse('test\r\ncase\r\n0')

# Generated at 2022-06-25 16:34:05.172989
# Unit test for function parse
def test_parse():
    str_0 = parse("")
    assert str_0 == "", "{0}".format(str_0)

    str_0 = parse("a")
    assert str_0 == "a", "{0}".format(str_0)

# Generated at 2022-06-25 16:34:11.285200
# Unit test for function parse
def test_parse():
    str_0 = """foo
    """
    docstring_0 = parse(str_0)
    str_0_ds_0 = str(docstring_0)
    str_0_ds_1 = docstring_0.summary
    str_0_ds_2 = str(docstring_0.description)
    str_0_ds_3 = str(docstring_0.meta)
    test_result = docstring_0._style == 1
    str_0_ds_4 = docstring_0._raw
    str_0_ds_5 = docstring_0._linenos


# Generated at 2022-06-25 16:34:18.122952
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    class_0 = Style
    docstring_0 = parse(str_0, class_0.auto)
    docstring_1 = parse(str_0, class_0.google)
    docstring_2 = parse(str_0, class_0.pep)
    docstring_3 = parse(str_0, class_0.numpy)
    docstring_4 = parse(str_0, class_0.napoleon)
    str_1 = 'random.randint(low, high=None, size=None, dtype=int)'
    class_1 = Style
    class_2 = Docstring
    docstring_5 = parse(str_1, class_1.auto)
    assert docstring_5.short_description == ''
    assert docstring_5.long_

# Generated at 2022-06-25 16:34:20.464714
# Unit test for function parse
def test_parse():
    # Testcase.0: test_case_0
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert (docstring_0.summary == 'a') and (docstring_0.extended_summary == '') and (docstring_0.body == '') and (len(docstring_0.meta) == 0)



# Generated at 2022-06-25 16:34:21.740067
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:34:26.527899
# Unit test for function parse
def test_parse():
    # default style
    str_0 = 'aL'
    docstring_0 = parse(str_0)

    # Google style
    str_1 = 'aL'
    docstring_1 = parse(str_1, style=Style.google)


if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:34:27.641255
# Unit test for function parse
def test_parse():
    test_case_0()


# Main function call

# Generated at 2022-06-25 16:34:35.421176
# Unit test for function parse
def test_parse():

    # Setup
    str_0 = 'aL'

    # Invoke function
    docstring_0 = parse(str_0)

    # Test cases
    assert docstring_0 is None
# End of test case 0


# Generated at 2022-06-25 16:34:42.461497
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert docstring_0.description == ''
    assert docstring_0.params == {'a': 'L'}
    assert docstring_0.returns == ''
    assert docstring_0.meta == {'a': 'L'}
    assert docstring_0.extras == []
    str_1 = 'R'
    docstring_1 = parse(str_1)
    assert docstring_1.description == ''
    assert docstring_1.params == {}
    assert docstring_1.returns == 'R'
    assert docstring_1.meta == {'returns': 'R'}
    assert docstring_1.extras == []
    str_2 = 'Ra'
    docstring_2 = parse

# Generated at 2022-06-25 16:34:48.269609
# Unit test for function parse
def test_parse():
    str_1 = 'this is'
    docstring_1 = parse(str_1)
    # No error, so we passed
    print('Test passed')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:34:52.173888
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    import pytest
    pytest.main(['-q', '--tb=line', '-x', '--pdb', '-s', __file__])

# Generated at 2022-06-25 16:35:01.683270
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    expected_output = Docstring()
    expected_output.short_description = 'aL'
    expected_output.long_description = ''
    expected_output.returns = None
    expected_output.meta = {'L': None}
    expected_output.sphinx = ''
    expected_output.napoleon = ''
    assert parse(str_0) == expected_output
    str_1 = 'aL'
    expected_output = Docstring()
    expected_output.short_description = 'aL'
    expected_output.long_description = ''
    expected_output.returns = None
    expected_output.meta = {'bL': None}
    expected_output.sphinx = ''
    expected_output.napoleon = ''

# Generated at 2022-06-25 16:35:09.889926
# Unit test for function parse
def test_parse():
    # Arguments:
    str_0 = 'aL'

    # Return type:
    ret_type_1 = Docstring

    # Call the tested function:
    ret_val_1 = parse(str_0)

    # Verify the value returned by the function by calling
    # another function:
    assert type(ret_val_1) == ret_type_1


    # Verify each type in the returntype:
    # Verify that the value returned by the function is an instance of
    # the class it was declared as.
    assert isinstance(ret_val_1, Docstring)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:35:10.955047
# Unit test for function parse
def test_parse():
    assert 'L' == parse('aL', style='numpy')


# Generated at 2022-06-25 16:35:11.436412
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-25 16:35:18.506484
# Unit test for function parse
def test_parse():
    assert True == True


# Program: PARSER.py

##############
#  Plan:
#   - parser takes in a string
#   - parser returns a parsed string
#
#  Ideas:
#   - parser separates string into components (meta, descriptors, sections)
#   - parser separates string into lines
#       - parser detects if line is meta
#           - if ismeta
#           - if isdescriptor
#               - if issection
#               - if not issection
#           - if not isdescriptor
#               - if issection
#               - if not issection
#       - if not ismeta
#           - if isdescriptor
#               - if issection
#               - if not issection
#           - if not isdescriptor
#               - if issection
#               - if not issection

# Generated at 2022-06-25 16:35:29.404830
# Unit test for function parse
def test_parse():

    text = 'some documentation'
    ret = parse(text)
    assert ret.text == 'some documentation'
    assert ret.meta == {}

    text = 'some documentation\n    :param a: param a'
    ret = parse(text)
    assert ret.text == 'some documentation'
    assert ret.meta == {'param': [{'a': None}]}

    text = 'some documentation\n    :param a: param a\n    :param b: param b\n    :param c: param c'
    ret = parse(text)
    assert ret.text == 'some documentation'
    assert ret.meta == {'param': [{'a': None}, {'b': None}, {'c': None}]}


# Generated at 2022-06-25 16:35:34.736904
# Unit test for function parse
def test_parse():
    assert callable(parse)
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 16:35:36.880469
# Unit test for function parse
def test_parse():
    # Test case 0
    assert parse("test_case_0()") is not None, "test_parse: test case 0 failed"



# Generated at 2022-06-25 16:35:47.073198
# Unit test for function parse
def test_parse():
    str_0 = 'This is a docstring'
    docstring_0 = parse(str_0)
    assert docstring_0.description == str_0
    assert not docstring_0.meta
    assert str(docstring_0) == str_0

    str_1 = 'This is\na docstring'
    docstring_1 = parse(str_1)
    assert docstring_1.description == str_1
    assert not docstring_1.meta
    assert str(docstring_1) == str_1

    str_2 = 'This is\na docstring\n'
    docstring_2 = parse(str_2)
    assert docstring_2.description == str_2
    assert not docstring_2.meta
    assert str(docstring_2) == str_2


# Generated at 2022-06-25 16:35:50.218847
# Unit test for function parse
def test_parse():
    assert True



# Generated at 2022-06-25 16:35:51.706720
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except Exception:
        pass

# Generated at 2022-06-25 16:35:54.210240
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except AssertionError as e:
        print(e)
        raise AssertionError("unit test for function parse failed")



# Generated at 2022-06-25 16:36:00.475367
# Unit test for function parse
def test_parse():

    # Desired output:
    # DocstringField(name='return', description='parsed docstring representation')

    expected_output = [
        DocstringField(name='return', description='parsed docstring representation')
    ]

    output = parse.__annotations__['return']

    assert output == expected_output

# Generated at 2022-06-25 16:36:07.077544
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert [docstring_0.short_description, docstring_0.long_description, docstring_0.meta, docstring_0.style] == ['', '', OrderedDict(), 'numpy']
    assert docstring_0.returns == None
    assert docstring_0.return_type == None
    assert docstring_0.yields == None
    assert docstring_0.yield_type == None
    assert docstring_0.raises == None
    assert docstring_0.see_also == None
    str_1 = 'aL'
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:36:09.687856
# Unit test for function parse
def test_parse():
    assert parse('aL') == "aL"
    assert parse('L') == "L"


# Generated at 2022-06-25 16:36:16.684792
# Unit test for function parse
def test_parse():
    # Test str_0
    str_0 = 'aL'
    answer_0 = 'aL'
    docstring_0 = parse(str_0)
    assert answer_0 == docstring_0

    # Test str_1
    str_1 = 'L'
    answer_1 = 'L'
    docstring_1 = parse(str_1)
    assert answer_1 == docstring_1

    # Test str_2
    str_2 = 'a'
    answer_2 = 'a'
    docstring_2 = parse(str_2)
    assert answer_2 == docstring_2

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:36:25.200437
# Unit test for function parse
def test_parse():
    assert parse('aL') == Docstring(
        summary='aL',
        description=None,
        returns=None,
        raises=None,
        meta={},
        parsed={
            'summary': 'aL',
            'description': '',
            'returns': '',
            'yields': '',
            'raises': '',
            'other': [],
        }
    )



# Generated at 2022-06-25 16:36:27.616770
# Unit test for function parse
def test_parse():
    str_1 = 'aL'
    docstring_1 = parse(str_1)
    assert docstring_1.full == str_1


# Generated at 2022-06-25 16:36:37.412338
# Unit test for function parse
def test_parse():
    # test default case
    str_0 = 'abcdefg'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'abcdefg'

    # test the case where there is only one line
    str_1 = 'This is a one line string'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This is a one line string'

    # test the case where there are many lines
    str_2 = 'This is the first line.\nThis is the second line.'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'This is the first line.'
    assert docstring_2.long_description == 'This is the second line.'


# Generated at 2022-06-25 16:36:42.171422
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = 'aL'
    style_0 = 'numpydoc'
    docstring_0 = parse(str_0, style_0)


# Generated at 2022-06-25 16:36:52.056791
# Unit test for function parse
def test_parse():
    docstring_0 = parse("""\
                                This is an example.

                                Args:
                                    param1: The first parameter.
                                    param2: The second parameter.

                                Returns:
                                    True if successful, False otherwise.
                                """,
                         style=Style.google)
    assert docstring_0.short_description == "This is an example."
    assert len(docstring_0.long_description) == 0
    assert len(docstring_0.meta) == 2
    assert docstring_0.meta[0].name == "Args"
    assert docstring_0.meta[1].name == "Returns"
    assert len(docstring_0.meta[0].content) == 2
    assert docstring_0.meta[0].content[0].name == "param1"
    assert docstring

# Generated at 2022-06-25 16:36:53.800268
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Imports

from ctypes import *
import math
import random

# Structures


# Generated at 2022-06-25 16:36:56.242119
# Unit test for function parse
def test_parse():
    """Test for the function parse."""

    str_0 = 'AL'
    docstring_0 = parse(str_0)

    """Testing for the function parse"""



# Generated at 2022-06-25 16:37:06.171867
# Unit test for function parse
def test_parse():
    docstring_0 = parse("Returns a list containing ``len(xs)`` copies of the item ``ys``")
    docstring_1 = parse("Adds b and c, returns the result.")
    docstring_2 = parse("Returns the sum of all the elements in a list.")
    docstring_3 = parse("Takes two numbers as input and multiplies them.")
    docstring_4 = parse("Returns a list containing the result of multiplying all elements in a list by three.")
    docstring_5 = parse("Takes two inputs and returns the first input")
    docstring_6 = parse("Takes two inputs and returns the second input")
    docstring_7 = parse("Takes two inputs and returns the second input", style=Style.pep429)


if __name__ == '__main__':
    test_case_0()
    test_parse

# Generated at 2022-06-25 16:37:07.162844
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:37:10.957166
# Unit test for function parse
def test_parse():
    # Test the 0th test case.
    print("Testing the 0th test case.")
    test_case_0()

    print("Done with the testing.")

test_parse()

# Generated at 2022-06-25 16:37:20.987236
# Unit test for function parse
def test_parse():
    ###############################################################
    # Test for format google_style for single line docstring and multi line docstring
    ###############################################################
    str_1 = 'ssssssssss sssssssssssssssssss'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'ssssssssss'
    assert docstring_1.long_description == 'ssssssssssssssssssss'


# Generated at 2022-06-25 16:37:28.752320
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    from docstring_parser.styles import Style
    assert (isinstance(parse(""), Docstring))
    assert (isinstance(parse("", Style.google), Docstring))
    assert (isinstance(parse("", Style.numpy), Docstring))
    assert (isinstance(parse("", Style.sphinx), Docstring))
    assert (isinstance(parse("", Style.auto), Docstring))


# Function test_case_0

# Generated at 2022-06-25 16:37:37.024949
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'a'
    assert docstring_0.long_description == 'L'
    assert docstring_0.meta == {'summary': ''}
    assert docstring_0.style == 'numpy'
    assert str(docstring_0) == 'a\n\nL\n'
    assert docstring_0.params == {}
    assert docstring_0.raises == {}
    assert docstring_0.returns is None
    str_1 = 'a\nL'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'a'
    assert docstring_1.long_description == 'L'
    assert docstring_

# Generated at 2022-06-25 16:37:40.838167
# Unit test for function parse
def test_parse():
    import numpy as np
    sample_text = """\
    Test routine: Parse docstring.
    :param text: docstring text to parse
    :param style: docstring style
    :rtype: parsed docstring representation
    """
    assert isinstance(parse(sample_text), object)
    assert isinstance(parse(sample_text, Style.num_py), object)


# Generated at 2022-06-25 16:37:43.284574
# Unit test for function parse
def test_parse():
  print("testing function parse")
  test_case_0()

if __name__ == "__main__" :
  test_parse()

# Generated at 2022-06-25 16:37:52.595837
# Unit test for function parse
def test_parse():
    str_0 = r"""
    This is a very basic example of a docstring.

    :param app_id: Application id
    :param app_name: Application name
    :param app_type: Application type
    :returns: Application details
    """
    docstring_0 = parse(str_0)
    str_1 = r"""
    This is a very basic example of a docstring.

    :param app_id: Application id
    :param app_name: Application name
    :param app_type: Application type
    :returns: Application details
    """
    docstring_1 = parse(str_1)
    # str_0 = 'aL'
    # docstring_0 = parse(str_0)
    # docstring_0 = parse(str_0)
    # docstring_0 = parse(str

# Generated at 2022-06-25 16:37:55.688432
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Run test for the above function
test_parse()

# Test if the above code runs successfully
test_case_0()

# Parse the above string and check if successful
#print(parse(str_0))

# Generated at 2022-06-25 16:37:58.518800
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
#Test Case 0
    docstring_0 = parse(str_0)
    assert docstring_0.description.description == 'aL'
    assert docstring_0.description.short_description == 'aL'




# Generated at 2022-06-25 16:37:59.541919
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:38:01.004655
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:38:05.941438
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:38:10.933219
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    if(len(docstring_0.short_description)==1):
        print("Testcase passed!")
    else:
        print("Testcase failed!")
        print("Expected:",2)
        print("Actual:",len(docstring_0))


test_parse()

# Generated at 2022-06-25 16:38:12.820821
# Unit test for function parse
def test_parse():
    test_case_0()
    assert True

# Generated at 2022-06-25 16:38:14.133616
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:38:17.073625
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    print(docstring_0)
    str_1 = 'aR'
    docstring_1 = parse(str_1)
    print(docstring_1)



# Generated at 2022-06-25 16:38:29.026057
# Unit test for function parse
def test_parse():
    # Test a random function that does not exist
    # Call function parse with a function that does not exist
    try:
        assert parse(rFunc)
    except AssertionError:
        print("Function parse(rFunc) is not implemented")

    # Test a string that exists
    # Call function parse with a string
    try:
        assert parse("This is a string")
        print("Function parse('This is a string') is implemented")
    except AssertionError:
        print("Function parse('This is a string') is not implemented")

    # Test an integer
    # Call function parse with an integer
    try:
        assert parse(1)
        print("Function parse(1) is implemented")
    except AssertionError:
        print("Function parse(1) is not implemented")

    # Test a list of integers
    #

# Generated at 2022-06-25 16:38:41.284502
# Unit test for function parse
def test_parse():
    # docstring test 0
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    str_1 = 'aL'
    docstring_1 = docstring_0.full_text
    assert float('inf') == docstring_1
    str_1 = 'aL'
    docstring_1 = docstring_0.pre_meta
    assert float('inf') == docstring_1
    str_1 = 'aL'
    docstring_1 = docstring_0.post_meta
    assert float('inf') == docstring_1
    docstring_1 = docstring_0.meta
    assert [] == docstring_1
    docstring_1 = docstring_0.summary
    assert '' == docstring_1
    docstring_1 = docstring_0.extended_

# Generated at 2022-06-25 16:38:46.474777
# Unit test for function parse
def test_parse():
    # TODO: Update this with an example docstring and example parsing
    str_0 = ''
    str_1 = ''
    style_0 = Style.numpy
    style_1 = Style.google
    style_2 = Style.pep257
    style_3 = Style.auto
    style_4 = Style.google
    style_5 = Style.pep257
    style_6 = Style.numpy
    style_7 = Style.auto
    style_8 = Style.auto
    style_9 = Style.numpy
    style_10 = Style.numpy
    docstring_0 = parse(str_0, style_0)
    docstring_1 = parse(str_0, style_1)
    docstring_2 = parse(str_0, style_2)

# Generated at 2022-06-25 16:38:54.233766
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'aL'
    assert len(docstring_0.long_description) == 0
    assert len(docstring_0.params) == 0
    assert len(docstring_0.returns) == 0
    assert len(docstring_0.raises) == 0
    assert len(docstring_0.meta) == 0
    assert len(docstring_0.examples) == 0


# Generated at 2022-06-25 16:38:56.567532
# Unit test for function parse
def test_parse():
    test_case_0()
    # Replace this with other tests


# Generated at 2022-06-25 16:38:58.587596
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-25 16:39:00.902753
# Unit test for function parse
def test_parse():
    import pytest

    with pytest.raises(Exception):
        test_case_0()

# Generated at 2022-06-25 16:39:10.579834
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    str_0 = 'aL'
    assert str_0
    assert not callable(str_0)
    #assert not isinstance(str_0, Type)
    assert not isinstance(str_0, int)
    assert not issubclass(str_0, Style)
    assert not isinstance(str_0, Style)
    assert not isinstance(str_0, Docstring)
    assert not isinstance(str_0, ParseError)
    assert not isinstance(str_0, STYLES)

    docstring_0 = parse(str_0)
    assert docstring_0
    assert not callable(docstring_0)

# Generated at 2022-06-25 16:39:14.180992
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert docstring_0 == {'description': str_0, 'params': {}, 'returns': {}}


# Generated at 2022-06-25 16:39:18.054207
# Unit test for function parse
def test_parse():
    str_0 = \
'''
    '''

    str_1 = \
'''
    '''

    assert type(parse(str_0)) is Docstring
    assert parse(str_0).args == {}
    assert parse(str_1).return_type == None


# Generated at 2022-06-25 16:39:28.084328
# Unit test for function parse
def test_parse():
    str_0 = '''
    Title1

    :param foo: The first param.
    :param bar: The second param.
    :returns: Description of return value.
    :raises keyError: The exception to be raised.
    '''
    docstring_0 = parse(str_0)

    # Added in 0.7.0
    assert isinstance(docstring_0.content, list)
    assert isinstance(docstring_0.meta, dict)
    assert docstring_0.meta[0].args == ('foo',)
    assert docstring_0.meta[0].description == 'The first param.'
    assert docstring_0.meta[1].args == ('bar',)
    assert docstring_0.meta[1].description == 'The second param.'

# Generated at 2022-06-25 16:39:29.213571
# Unit test for function parse
def test_parse():
    assert(callable(parse))


# Generated at 2022-06-25 16:39:31.028378
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()
    print('Test successful')

# Generated at 2022-06-25 16:39:37.031074
# Unit test for function parse
def test_parse():
    _str_0 = 'aL'
    docstring_0 = parse(_str_0)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:39:46.345389
# Unit test for function parse
def test_parse():
    s = 'Here is a standard docstring.\n'\
        '\n'\
        ':param int arg: The argument.\n'\
        ':returns: None\n'\
        ':raises ValueError: if something bad happens\n'\
        '\n'\
        'Here is some additional text.'
    docstring = parse(s)
    assert docstring.short_description == 'Here is a standard docstring.'
    assert docstring.long_description == 'Here is some additional text.'
    assert len(docstring.params) == 1
    assert docstring.params[0].arg_name == 'arg'
    assert docstring.params[0].annotation == 'int'
    assert docstring.params[0].description == 'The argument.'

# Generated at 2022-06-25 16:39:56.673981
# Unit test for function parse
def test_parse():
    # This function tests the function parse by creating the different docstrings and then parsing it to check if the
    # docstring returned is equivalent to the original one

    assert parse("") == Docstring(content=[], meta={})
    assert parse("Hello world.") == Docstring(content=["Hello world."], meta={})
    assert parse("""Hello world.
    Yes.
    """) == Docstring(content=["Hello world.", "Yes."], meta={})
    assert parse("""Hello world.
    :param a: first parameter
    :type a: int
    :keyword b: second parameter
    :type b: int
    """) == Docstring(content=["Hello world."], meta={"param": {"a": {"type": "int"}}, "keyword": {"b": {"type": "int"}}})

# Generated at 2022-06-25 16:39:59.015025
# Unit test for function parse
def test_parse():
    # Tests for function parse that only require types
    return None

# print(test_parse())

# Generated at 2022-06-25 16:40:07.445748
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    # AssertionError: Docstring must not be empty
    # AssertionError: Docstring must not be empty
    # AssertionError: Docstring must not be empty
    # AssertionError: Docstring must not be empty
    str_1 = 'zb'
    docstring_1 = parse(str_1)
    str_2 = 'aL'
    docstring_2 = parse(str_2)
    str_3 = 'aL'
    docstring_3 = parse(str_3)
    str_4 = 'aL'
    docstring_4 = parse(str_4)
    # AssertionError: Docstring must not be empty
    str_5 = ''

# Generated at 2022-06-25 16:40:13.044463
# Unit test for function parse
def test_parse():
    # Setup
    arg_0 = 'aL'
    arg_1 = Style.auto
    
    # Testing
    # docstring_0 = parse(arg_0, arg_1)
    # print(docstring_0)

    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:40:19.185372
# Unit test for function parse
def test_parse():
    input = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque nibh enim, eget porta metus egestas vel."

    expected = Docstring(
        summary="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque nibh enim, eget porta metus egestas vel.",
    )

    assert parse(input) == expected

# Generated at 2022-06-25 16:40:21.051798
# Unit test for function parse
def test_parse():
    str_0 = '"""aL"""\n'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:40:25.394044
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:40:26.262489
# Unit test for function parse
def test_parse():
    print(parse)


# Generated at 2022-06-25 16:40:31.272669
# Unit test for function parse
def test_parse():
    # Test when the function parse is called and
    # the the string is empty
    try:
        parse("")
        assert False
    except ParseError as e:
        assert str(e) == "No docstring found"

    # Test when the function parse is called and
    # the the string does not contain ':'
    try:
        parse("Hello")
        assert False
    except ParseError as e:
        assert str(e) == "No docstring found"


if __name__ == '__main__':
    # test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:40.386247
# Unit test for function parse
def test_parse():
    assert callable(parse), "Function 'parse' is not defined"
    assert isinstance(parse(str_0), Docstring), "Return type of function 'parse' is not Docstring"
    assert parse(str_0).full_name == 'aL', "Function 'parse' does not return correct name"

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:40:48.295844
# Unit test for function parse
def test_parse():
    # Test function from python function parse
    # Input arguments:
    str_0 = 'aL'

    assert parse(str_0) == 'aL'

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:55.967500
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    if docstring_0.short_description != 'aL':
        print("Error in test case 0")

    str_1 = 'bL'
    docstring_1 = parse(str_1, Style.numpy)
    if docstring_1.short_description != 'bL':
        print("Error in test case 1")

    str_2 = 'aL'
    docstring_2 = parse(str_2, Style.numpy)
    if docstring_2.short_description != 'aL':
        print("Error in test case 2")

    str_3 = 'cL'
    docstring_3 = parse(str_3, Style.google)

# Generated at 2022-06-25 16:41:02.591842
# Unit test for function parse
def test_parse():
    def func0_or_func1(arg0):
        str_0 = 'aL'
        docstring_0 = parse(str_0)
        assert docstring_0 == 'f'

    def func2():
        str_1 = 'aL'
        docstring_1 = parse(str_1)
        assert docstring_1 == 'f'

    func2()
    test_case_0()
    func0_or_func1('aL')



# Generated at 2022-06-25 16:41:03.763474
# Unit test for function parse
def test_parse():
    docstring_0 = parse()
    assert isinstance(docstring_0, object)

# Generated at 2022-06-25 16:41:12.843332
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)

    # docstring_0.lines:
    assert len(docstring_0.lines) == 0
    assert docstring_0.lines == []

    # docstring_0.meta:
    assert len(docstring_0.meta) == 0
    assert docstring_0.meta == {}

    # docstring_0.returns:
    assert docstring_0.returns is None

    # docstring_0.raises:
    assert len(docstring_0.raises) == 0
    asser

# Generated at 2022-06-25 16:41:14.764241
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'aL'


# Generated at 2022-06-25 16:41:19.797579
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    style_0 = Style.NUMPY
    docstring_0 = parse(str_0, style_0)


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:41:27.325450
# Unit test for function parse
def test_parse():
    # arg1 -> text; arg2 -> style
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()

# Generated at 2022-06-25 16:41:36.804820
# Unit test for function parse
def test_parse():
    str_0 = "Returns a random 32-bit unsigned integer."
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Returns a random 32-bit unsigned integer."
    assert docstring_0.long_description is None
    assert len(docstring_0.returns) == 0
    assert len(docstring_0.meta) == 0
    
    str_1 = "Generates a random string of the specified length.\n\n    Args: int length: Length of the resulting string.\n    Returns:\n        str: A random string."
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Generates a random string of the specified length."

# Generated at 2022-06-25 16:41:39.685768
# Unit test for function parse
def test_parse():
	# example case:
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert docstring_0.meta['L'] == 'a'


print(test_parse())

# Generated at 2022-06-25 16:41:51.089355
# Unit test for function parse
def test_parse():
    print('Testing function parse.')
    str_0 = ("Objects of this class represent sets of natural numbers.\n"
             "The main purpose of this is to do math.\n"
             "In this example, we will compute the union of two sets.\n"
             ":\returns: a set that is set a union set b.\n")
    docstring_0 = parse(str_0)
    print(docstring_0)
    str_1 = ("This is a sample docstring.  It may span multiple lines.\n\n"
             "    And it has code!\n"
             "    :param str message: A message.\n\n"
             "    :param int thing: Another thing.\n")
    docstring_1 = parse(str_1, Style.google)

# Generated at 2022-06-25 16:41:57.361241
# Unit test for function parse
def test_parse():
    str0 = "Test"
    assert parse(str0) == 'Test'
    assert parse("Test").docstring == "Test"
    assert parse("Te\nst").docstring == "Te\nst"
    assert parse("Te\nst\n").docstring == "Te\nst\n"
    assert parse("Te\nst\n").summary == 'Te'
    assert parse("Te\nst").summary == 'Te'
    assert parse("Te\nst\n").description == 'st\n'
    assert parse("Te\nst\n").meta == {}
    assert parse("Te\nst\n").params == {}
    assert parse("Te\nst\n").returns == {}
    assert parse("Te\nst\n").raises == {}

# Generated at 2022-06-25 16:41:59.117960
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)

# Main function

# Generated at 2022-06-25 16:42:02.631396
# Unit test for function parse
def test_parse():
    param_0 = "aL"
    assert(parse(param_0) == 'aL')



# Generated at 2022-06-25 16:42:04.092410
# Unit test for function parse
def test_parse():
    test_case_0()

# Program unit tests

# Generated at 2022-06-25 16:42:16.119332
# Unit test for function parse
def test_parse():
    # AssertionError
    try:
        str_0 = None
        docstring_0 = parse(str_0)
        assert False
    except AssertionError:
        pass
    # AssertionError
    try:
        str_1 = 'aL'
        docstring_1 = parse(str_1)
        assert False
    except AssertionError:
        pass
    # AssertionError
    try:
        str_2 = None
        docstring_2 = parse(str_2)
        assert False
    except AssertionError:
        pass
    # AssertionError
    try:
        str_3 = None
        docstring_3 = parse(str_3)
        assert False
    except AssertionError:
        pass
    # AssertionError

# Generated at 2022-06-25 16:42:22.737911
# Unit test for function parse
def test_parse():
    str_0 = '''
    aL
    '''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert docstring_0.summary == ''
    assert docstring_0.meta == {
        'aL': []
    }
    assert docstring_0.returns == []
    assert docstring_0.yields == []
    assert docstring_0.raises == []
    assert docstring_0.see_also == []



# Generated at 2022-06-25 16:42:26.280698
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:42:35.755568
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    print(len(docstring_0.meta)) # <type 'int'>
    print(docstring_0.meta) # <type 'dict'>
    print(docstring_0.summary) # ''
    print(docstring_0.returns) # <type 'NoneType'>
    print(docstring_0.raises) # <type 'NoneType'>
    print(docstring_0.yields) # <type 'NoneType'>
    print(docstring_0.extended_summary) # ''
    print(docstring_0.extend_summary) # ''
    print(docstring_0.body) # ''
    print(docstring_0.params) # <type 'NoneType'>

# Generated at 2022-06-25 16:42:43.798331
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert len(docstring_0.meta) == 0
    assert docstring_0.content is None
    assert docstring_0.returns is None
    assert docstring_0.raises is None
    assert docstring_0.yields is None
    assert docstring_0.other == '\n'

    str_1 = 'gL'
    docstring_1 = parse(str_1)
    assert len(docstring_1.meta) == 0
    assert docstring_1.content is None
    assert docstring_1.returns is None
    assert docstring_1.raises is None
    assert docstring_1.yields is None
    assert docstring_1.other == '\n'

   

# Generated at 2022-06-25 16:42:51.875359
# Unit test for function parse
def test_parse():
    str_0 = ''
    str_1 = '\n'
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    assert(docstring_0.short == '')
    assert(docstring_1.short == '')

# Generated at 2022-06-25 16:42:53.381159
# Unit test for function parse
def test_parse():
    assert 'aL' in parse("aL")

test_parse()

# Generated at 2022-06-25 16:42:56.227015
# Unit test for function parse
def test_parse():
    text_0 = "aL"
    style_0 = Style.auto
    docstring_0 = parse(text_0, style_0)
    print(docstring_0)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:42:57.132275
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:58.130394
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:43:02.090091
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert str_0 == 'aL'
    print('Passed.')


test_parse()

# Generated at 2022-06-25 16:43:03.753517
# Unit test for function parse
def test_parse():
    with pytest.raises(SystemExit):
        assert test_case_0() == 0

# Generated at 2022-06-25 16:43:09.967936
# Unit test for function parse
def test_parse():
    func_name, docstring = parse.__name__, parse.__doc__
    try:
        parse()
    except TypeError as e:
        print('TypeError raised. Argument(s) missing!')
    except Exception as e:
        print('Test Failed!', e)
        return
    print('Test Passed!')
    return

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:43:14.040885
# Unit test for function parse
def test_parse():    
    str_0 = 'aL'
    docstring_0 = parse(str_0)
    assert type(docstring_0) == docstring_parser.common.Docstring
    assert docstring_0.short_description == 'aL'


# Generated at 2022-06-25 16:43:15.008489
# Unit test for function parse
def test_parse():
    assert False

# Compute code coverage

# Generated at 2022-06-25 16:43:34.111355
# Unit test for function parse
def test_parse():
    str_0 = 'aL'
    docstring_0 = parse(str_0, Style.google)
    assert docstring_0.short_description == 'aL'
    assert docstring_0.long_description == ''
    assert not docstring_0.meta.returns
    assert not docstring_0.meta.raises
    assert not docstring_0.meta.params
    assert not docstring_0.meta.attributes
    assert not docstring_0.meta.see_also
    assert not docstring_0.meta.example
    str_1 = 'aL'
    docstring_1 = parse(str_1, Style.numphy)
    assert docstring_1.short_description == 'aL'
    assert docstring_1.long_description == ''
    assert not docstring_1.meta