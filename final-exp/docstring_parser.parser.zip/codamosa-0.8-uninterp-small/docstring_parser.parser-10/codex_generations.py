

# Generated at 2022-06-25 16:33:39.430071
# Unit test for function parse
def test_parse():
    str_0 = 'Implementation of :func:`int` (``__int__``) special method\n\n    :param obj: Object to be converted to int\n    :param base: Base of conversion\n    :raises TypeError: If the object can not be converted to int\n    '
    docstring_0 = parse(str_0)
    str_1 = '  Implements :func:`int` (``__int__``) special method\n\n    :param obj: Object to be converted to int\n    :param base: Base of conversion\n    :raises TypeError: If the object can not be converted to int\n    '
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:33:40.200920
# Unit test for function parse
def test_parse():
    assert False, "Test if the function returns the correct value"

# Generated at 2022-06-25 16:33:50.307073
# Unit test for function parse
def test_parse():
    str_0 = ""
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    assert docstring_0.summary == ""
    assert docstring_0.description == ""
    assert docstring_0.returns == None
    assert docstring_0.returns_description == ""
    assert docstring_0.meta == {}
    str_1 = """
    Summary line.

    Extended description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    style_1 = Style.google
    docstring_1 = parse(str_1, style_1)
    assert docstring_1.summary == "Summary line."
   

# Generated at 2022-06-25 16:33:53.524384
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = Style.auto
    docstring_0 = parse(str_0)
    assert style_0 in STYLES.values()
    assert type(docstring_0) == type(Docstring())


# Generated at 2022-06-25 16:34:05.342883
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:34:12.961309
# Unit test for function parse
def test_parse():
    # Test for function parse

    str = 'This is a sample docstring'
    assert parse(str) == 'This is a sample docstring'
    assert parse(str, style='numpy') == 'This is a sample docstring'
    assert parse(str, style='google') == 'This is a sample docstring'
    assert parse(str, style='auto') == 'This is a sample docstring'
    assert parse(str, style='invalid') is None

# Generated at 2022-06-25 16:34:20.227689
# Unit test for function parse
def test_parse():
    str_0 = "Single line docstring"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Single line docstring"
    assert docstring_0.long_description == None
    assert docstring_0.meta == {}


# Generated at 2022-06-25 16:34:25.869745
# Unit test for function parse
def test_parse():
    # Arrange
    str_0 = "The main parsing routine."
    expected_docstring = Docstring(summary="The main parsing routine.",
        description="None",
        extended_summary="None",
        metadata={})

    # Act
    actual_docstring = parse(str_0)

    # Assert
    assert actual_docstring == expected_docstring


# Generated at 2022-06-25 16:34:28.275068
# Unit test for function parse
def test_parse():
    docstring_1 = parse("")
    assert docstring_1 is not None

    docstring_2 = parse("This is a test docstring for testing parse()")
    assert docstring_2 is not None

# Generated at 2022-06-25 16:34:30.132214
# Unit test for function parse
def test_parse():
    assert(parse.__name__ == 'parse')
    assert(len(parse.__doc__) > 0)

# Generated at 2022-06-25 16:34:43.207175
# Unit test for function parse
def test_parse():
	assert parse('  Summary.\n\n  Long summary.\n') == parse('  Summary.\n  Long summary.\n')
	assert parse('test_parse\n---------\n\nDocstring\n') == parse('test_parse\n---------\nDocstring\n')
	assert parse('test_parse\n---------\n\nDo\ncstring\n') == parse('test_parse\n---------\nDo\ncstring\n')
	assert parse('test_parse\n---------\n\nDocs\ntring\n') == parse('test_parse\n---------\nDocs\ntring\n')
	assert parse('test_parse\n---------\n\nDocst\nring\n') == parse('test_parse\n---------\nDocst\nring\n')

# Generated at 2022-06-25 16:34:53.901875
# Unit test for function parse
def test_parse():
    # Failure test case for function parse
    text_0 = ''
    style_0 = 'Style.auto'
    # Exception raised: 'docstring_parser.styles.auto.AutoStyle', 'failed to parse docstring'
    # Exception raised: 'docstring_parser.styles.one_line.OneLineStyle', 'failed to parse docstring'
    # Exception raised: 'docstring_parser.styles.rst.RstStyle', 'failed to parse docstring'
    # Exception raised: 'docstring_parser.styles.google_numpy.GoogleStyleNumpyStyle', 'failed to parse docstring'
    # Exception raised: 'docstring_parser.styles.google.GoogleStyle', 'failed to parse docstring'
    # Exception raised: 'docstring_parser.styles.numpy.NumpyStyle', 'failed to parse docstring'
    # Exception

# Generated at 2022-06-25 16:34:59.207324
# Unit test for function parse
def test_parse():
    str_0 = "  \t\n"
    styl_0 = parse(str_0)
    styl_1 = str_0
    assert styl_0 != styl_1
 
    str_0 = "Gets a list of all nonzero indices in this matrix."
    styl_0 = parse(str_0)
    styl_1 = "[index: (int, int), value] list"
    assert styl_0 == styl_1


# Generated at 2022-06-25 16:35:04.216609
# Unit test for function parse
def test_parse():
    str_0 = """\
        parameter_0
            Returns: docstring_parser.models.parameter.Parameter
            Return type: docstring_parser.models.parameter.Parameter
    """
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-25 16:35:14.394134
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = Style.auto        # default
    style_1 = Style.google
    style_2 = Style.numpy
    style_3 = Style.doctest

    # Verify return values
    docstring_0 = parse(str_0, style_0)
    docstring_1 = parse(str_0, style_1)
    docstring_2 = parse(str_0, style_2)
    docstring_3 = parse(str_0, style_3)
    assert docstring_0
    assert docstring_1
    assert docstring_2
    assert docstring_3

# Generated at 2022-06-25 16:35:17.449113
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-25 16:35:18.466768
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:35:19.980855
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:35:23.473498
# Unit test for function parse
def test_parse():
    assert parse('a') == None
    style = Style.auto
    assert parse(str, style) == None
    assert parse('a') == None

# Generated at 2022-06-25 16:35:32.428006
# Unit test for function parse
def test_parse():
    string = '''
        Keyword arguments:
            arg -- description

        Raises:
            AttributeError, KeyError
    '''

# Generated at 2022-06-25 16:35:41.311534
# Unit test for function parse
def test_parse():
    style_0 = Style.auto
    text_0 = None
    parse(text_0, style_0)
    style_1 = Style.auto
    text_1 = None
    parse(text_1, style_1)

# Generated at 2022-06-25 16:35:43.114281
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = None
    test_case_0(str_0, style_0)


# Generated at 2022-06-25 16:35:43.870010
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:35:52.446012
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = Style.numpy
    docstring_0 = parse(str_0, style_0)
    docstring_1 = parse(str_0)
    docstring_2 = parse(str_0, style_0)


if __name__ == '__main__':
    import sys
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger('test')

    # Run test with
    # $ python -m doctest -v test_parse.py

    # Run unit tests
    test_case_0()

    # Run performance test
    logger.info('Starting performance test...')
    test_parse()
    logger.info('Performance test done!')

# Generated at 2022-06-25 16:36:03.736741
# Unit test for function parse
def test_parse():
    # Setup
    text_0 = "/**\n * This is a test.\n */\n"
    text_1 = "\"\"\"\n This is a test.\n \"\"\"\n"
    text_2 = '\'\'\'\n This is a test.\n \'\'\'\n'
    text_3 = "/**\n * This is a test.\n */\n"
    text_4 = "/**\n * This is a test.\n */\n"

    # Invocation
    docstring_0 = parse(text_0)
    docstring_1 = parse(text_1)
    docstring_2 = parse(text_2)
    docstring_3 = parse(text_3, Style.google)
    docstring_4 = parse(text_4, Style.numpy)



# Generated at 2022-06-25 16:36:06.976713
# Unit test for function parse
def test_parse():
    assert parse('Function description.')

# Generated at 2022-06-25 16:36:16.505963
# Unit test for function parse
def test_parse():
    docstring_0 = "This is a docstring that fits into one line."
    docstring_1 = ""
    style_0 = Style.numpy
    style_1 = Style.auto
    style_2 = Style.sphinx
    out_0 = parse(docstring_0, style_0)
    out_1 = parse(docstring_1, style_1)
    out_2 = parse(docstring_0, style_2)
    out_3 = parse(docstring_1, style_2)
    out_4 = parse(docstring_0, style_1)
    out_5 = parse(docstring_1, style_0)
    docstring_2 = "This is a docstring that fits into one line."
    out_6 = parse(docstring_2)


# Generated at 2022-06-25 16:36:25.835089
# Unit test for function parse
def test_parse():

    docstring = parse("""
        :param arg0: first arg
        :param arg1: second arg
        :param arg2: third arg

        :return: the return value
    """)

    assert docstring.return_section.title == "return"
    assert docstring.return_section.content == "the return value"

    assert all(section.title == "param" for section in docstring.params.values())
    assert docstring.params["arg0"].content == "first arg"
    assert docstring.params["arg1"].content == "second arg"
    assert docstring.params["arg2"].content == "third arg"




# Generated at 2022-06-25 16:36:35.772676
# Unit test for function parse
def test_parse():
    str_0 = "This is a docstring"
    str_1 = None
    style_0 = Style.numpy
    docstring_0 = parse(str_0, Style.numpy)
    assert str(docstring_0) == "This is a docstring"
    docstring_0 = parse(str_1, Style.numpy)
    assert str(docstring_0) == "None"
    docstring_0 = parse(str_1, Style.google)
    assert str(docstring_0) == "None"
    docstring_0 = parse(str_0)
    assert str(docstring_0) == "This is a docstring"
    docstring_0 = parse(str_1)
    assert str(docstring_0) == "None"
    style_0 = Style.numpy
    doc

# Generated at 2022-06-25 16:36:42.973631
# Unit test for function parse
def test_parse():
    str_0 = None
    style_1 = Style.numpy
    docstring_1 = parse(str_0, style_1)
    str_2 = None
    style_3 = Style.google
    docstring_3 = parse(str_2, style_3)
    str_4 = None
    style_5 = Style.sphinx
    docstring_5 = parse(str_4, style_5)
    str_6 = None
    style_7 = Style.pep
    docstring_7 = parse(str_6, style_7)
    str_8 = None
    style_9 = Style.auto
    docstring_9 = parse(str_8, style_9)
    str_10 = None
    style_11 = Style.numpy

# Generated at 2022-06-25 16:36:53.136057
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    str_1 = 'se'
    docstring_1 = parse(str_1)
    str_2 = '@param dsdsd'
    docstring_2 = parse(str_2)
    str_3 = '@param dsdsd 10'
    docstring_3 = parse(str_3)
    str_4 = '@param dsdsd 10'
    docstring_4 = parse(str_4)
    str_5 = '@param dsdsd 10'
    docstring_5 = parse(str_5)
    str_6 = '@param dsdsd 10'
    docstring_6 = parse(str_6)
    str_7 = '@return dsdsd 10'
    docstring

# Generated at 2022-06-25 16:36:54.698123
# Unit test for function parse
def test_parse():
    test_parser(parse, "numpy", __file__)

# Generated at 2022-06-25 16:37:04.846927
# Unit test for function parse
def test_parse():
    import pytest
    from docstring_parser.common import Docstring
    from docstring_parser.styles import Style

    text = "This is a docstring"
    result = parse(text)
    assert isinstance(result, Docstring)

    text = "This is a docstring"
    style = Style.auto
    result = parse(text, style)
    assert isinstance(result, Docstring)

    text = "This is a docstring with a : in it."
    style = Style.auto
    result = parse(text, style)
    assert isinstance(result, Docstring)

    text = "This is a docstring with a : in it."
    style = Style.epytext
    result = parse(text, style)
    assert isinstance(result, Docstring)


# Generated at 2022-06-25 16:37:14.831336
# Unit test for function parse
def test_parse():
    # Test for hand-crafted examples
    r = parse('Hello, world!')
    assert r.short_description == 'Hello, world!'
    assert r.long_description == ''
    r = parse('Hello, world!\nThis is a longer description.')
    assert r.short_description == 'Hello, world!'
    assert r.long_description == 'This is a longer description.'
    r = parse('Hello, world!\n\nThis is a longer description.')
    assert r.short_description == 'Hello, world!'
    assert r.long_description == 'This is a longer description.'
    r = parse('Hello, world!\n\nThis is a longer description.\n\n.. meta::\n    :keywords: foo, bar\n    :author: Me')

# Generated at 2022-06-25 16:37:21.731305
# Unit test for function parse
def test_parse():
    text = 'hello'
    docstring = parse(text)
    assert str(docstring) == 'hello'



# Generated at 2022-06-25 16:37:23.706556
# Unit test for function parse
def test_parse():
    assert 1 == 1

test_case_0()

# Generated at 2022-06-25 16:37:24.976001
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:37:35.083614
# Unit test for function parse
def test_parse():
    # test if function parse can be successfully called with valid values of 
    # param text and style
    str_0 = """Summary line.

Extended description of function.

Parameters:
    arg1 (int): Description of `arg1`
    arg2 (str): Description of `arg2`

Returns:
    bool: Description of return value

"""
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    assert docstring_0.short_description == "Summary line."
    assert docstring_0.long_description == "Extended description of function."

# Generated at 2022-06-25 16:37:39.478005
# Unit test for function parse
def test_parse():
    str_0 = "Return random integers from low (inclusive) to high (exclusive)."
    docstring_0 = parse(str_0)


if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:37:40.820853
# Unit test for function parse
def test_parse():
    assert parse(None) == None

# Generated at 2022-06-25 16:37:55.488524
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    str_1 = 'Simple string for test'
    docstring_1 = parse(str_1, style=Style.google)
    str_2 = 'This is a test for Google style docstring\n\nArguments:\n    arg1: First argument\n    arg2: Second argument\n\nReturns:\n    str: String of arguments'
    docstring_2 = parse(str_2, style=Style.google)
    str_3 = 'This is a test for Numpy style docstring\n\nParameters\n----------\narg1 : str\n    First argument\narg2 : str\n    Second argument\n\nReturns\n-------\nstr\n    String of arguments'

# Generated at 2022-06-25 16:37:57.272567
# Unit test for function parse
def test_parse():
    assert callable(parse)

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:37:58.235550
# Unit test for function parse
def test_parse():
    assert callable(parse)

# tests for the exceptions in parse

# Generated at 2022-06-25 16:38:07.914554
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.meta == {}

    str_1 = "This is a docstring"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == str_1
    assert docstring_1.long_description == None
    assert docstring_1.meta == {}

    str_2 = "\nThis is a longer description\n"
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == None
    assert docstring_2.long_description == str_2
    assert docstring_2.meta == {}


# Generated at 2022-06-25 16:38:13.968819
# Unit test for function parse
def test_parse():
    a = parse('''
    Title is not important
    ''')

    assert a.description == 'Title is not important' and a.args == [] and a.returns == None
    assert a.raises == []


# Generated at 2022-06-25 16:38:20.481416
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0, None)
    str_1 = """
    Summary line.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    bool
        Description of return value

    """
    docstring_1 = parse(str_1, None)
    assert(docstring_1.short_description == 'Summary line.')
    assert(docstring_1.long_description == 'Extended description of function.')
    assert(docstring_1.returns.description == 'Description of return value')

# Generated at 2022-06-25 16:38:21.867174
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:38:24.188385
# Unit test for function parse
def test_parse():
    str_0 = None
    r0 = parse(str_0)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:38:32.086778
# Unit test for function parse
def test_parse(): 
    # Test 1: docstring with everything
    str1 = '''
    @param request: request is a HttpRequest object.
        It contains following attributes.
        - path
        - method
        - encoding
        - GET
        - POST
        - COOKIES
        - FILES
        - META
        - header
        - content_type
        - content_params
        - upload_handlers
    '''
    docstring_1 = parse(str1)
    assert docstring_1.params[0].arg_name == 'request'
    assert docstring_1.params[0].type_name == 'HttpRequest'
    assert docstring_1.params[0].description == 'request is a HttpRequest object.'
    assert docstring_1.params[0].attributes[0] == 'path'

# Generated at 2022-06-25 16:38:42.690938
# Unit test for function parse
def test_parse():

    # Finish test_case_0
    str_0 = '''This is a test docstring.
    This is the second line.
    '''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a test docstring.'
    assert docstring_0.long_description == 'This is the second line.\n    \n    '
    assert docstring_0.meta == {}
    assert len(docstring_0.params) == 0
    assert len(docstring_0.returns) == 0
    assert len(docstring_0.raises) == 0

    # Finish test_case_1

# Generated at 2022-06-25 16:38:56.169103
# Unit test for function parse
def test_parse():

    assert parse('') == Docstring()
    assert parse('\n') == Docstring()

    assert parse('test') == Docstring(content=['test'])
    assert parse('test\n') == Docstring(content=['test'])
    assert parse('test\n\n') == Docstring(content=['test'])
    assert parse('\ntest') == Docstring(content=['test'])
    assert parse('\n\ntest') == Docstring(content=['test'])

    assert parse('a\nb\n\nc') == Docstring(content=['a', 'b', 'c'])
    assert parse('a\nb\nc') == Docstring(content=['a', 'b', 'c'])

# Generated at 2022-06-25 16:39:06.503373
# Unit test for function parse
def test_parse():
    str0 = "This is a docstring.\nThis is a docstring.\n"
    str1 = "This is a docstring.\nThis is a docstring.\n\n"
    str2 = "This is a docstring.\nThis is a docstring.\n\nThis is a docstring.\nThis is a docstring.\n"
    str3 = "This is a docstring.\nThis is a docstring.\n\nThis is a docstring.\nThis is a docstring.\n\n"
    str4 = None
    value = parse(str0, style=Style.numpy)
    expected = 'This is a docstring.\nThis is a docstring.'
    assert value.short_description == expected
    value1 = parse(str1, style=Style.numpy)

# Generated at 2022-06-25 16:39:07.480593
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:39:14.391583
# Unit test for function parse
def test_parse():
    str_0 = r'''
    This is a docstring.

    :param name: (optional) first name

    :type name: str

    :returns: a greeting
    :rtype: str
    '''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a docstring.'
    assert docstring_0.long_description == '\n    '
    assert docstring_0.params['name'] == 'first name'
    assert docstring_0.params['type'] == 'str'
    assert docstring_0.returns == 'a greeting'
    assert docstring_0.return_type == 'str'

    str_1 = r'''Get a greeting.
    '''
    docstring_1 = parse(str_1)
    assert doc

# Generated at 2022-06-25 16:39:25.060836
# Unit test for function parse
def test_parse():
    assert parse("""Description of the method.
Parameters:
  - name (str): Description of the parameter
    with the continuation line.
  - version (int): Description of the parameter.
Raises:
  - TypeError: Description of the error.
  - ValueError: Description of the error.
""") == Docstring(
    content="Description of the method.",
    params={
        "name": "Description of the parameter\nwith the continuation line.",
        "version": "Description of the parameter.",
    },
    raises={
        "TypeError": "Description of the error.",
        "ValueError": "Description of the error.",
    },
)

# Generated at 2022-06-25 16:39:28.182772
# Unit test for function parse
def test_parse():
    # Setup
    text = "Test function."

    # Exercise
    docstring = parse(text)

    # Verify
    expected_summary = "Test function."
    expected_description = None
    assert docstring.summary == expected_summary
    assert docstring.description == expected_description


# Generated at 2022-06-25 16:39:30.026957
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:39:31.816693
# Unit test for function parse
def test_parse():
    assert (parse(None))

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])


# Generated at 2022-06-25 16:39:32.953048
# Unit test for function parse
def test_parse():
    docstring_0 = parse("  ")


# Generated at 2022-06-25 16:39:39.675983
# Unit test for function parse
def test_parse():
    str_0 = """This function does some stuff.

    Blablabla bli bla.

    :param foo: footype
    :type foo: int
    :rtype: str
    :return: Stuff
    """
    docstring_0 = parse(str_0)
    assert docstring_0.description == 'This function does some stuff.'
    assert docstring_0.params == {'foo': 'footype'}

    str_1 = """This function does some stuff.

    :param foo: footype
    :type foo: int
    """
    docstring_1 = parse(str_1)
    assert docstring_1.description == 'This function does some stuff.'
    assert docstring_1.params == {'foo': 'footype'}

    str_2 = """This function does some stuff.
    """

# Generated at 2022-06-25 16:39:49.305804
# Unit test for function parse
def test_parse():

    str_0 = '/**\n * Some text\n */\nfunction A() {}\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Some text'
    assert docstring_0.long_description.startswith('<pre><code>function A(')

    str_1 = '/**\n Some text\n with a newline\n*/\nfunction A() {}\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Some text with a newline'
    assert docstring_1.long_description.startswith('<pre><code>function A(')


# Generated at 2022-06-25 16:39:57.730663
# Unit test for function parse
def test_parse():
    str_0 = """A short description.

A longer description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value
"""
    docstring_0 = parse(str_0)
    print('docstring ', docstring_0)
    print(dir(docstring_0))
    ('arg1', 'arg2', 'description', 'description_long', 'returns')
    assert docstring_0.short_description == 'A short description.'
    assert docstring_0.long_description == 'A longer description.'
    assert docstring_0.args == [
        ('arg1', 'int', 'Description of arg1'),
        ('arg2', 'str', 'Description of arg2')
    ]
    assert docstring_

# Generated at 2022-06-25 16:40:06.715756
# Unit test for function parse
def test_parse():
    str_0 = """Generate prime numbers in given range.
    Parameters
    ----------
    start : int, optional
        lower bound of the range
    stop : int, optional
        upper bound of the range
    Returns
    -------
    result : list
        list of prime numbers in given range
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Generate prime numbers in given range."
    assert docstring_0.long_description == ""
    assert docstring_0.sections['Parameters'].fields[0].names == ["start"]
    assert docstring_0.sections['Parameters'].fields[0].description == "int, optional\n        lower bound of the range"
    assert docstring_0.sections['Parameters'].fields[1].names == ["stop"]
    assert doc

# Generated at 2022-06-25 16:40:16.282709
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    bool
        Description of return value

    """
    assert parse(docstring) == Docstring(
        summary='Summary line.',
        description='Extended description.',
        args=['arg1', 'arg2'],
        arg_descriptions=['Description of `arg1`', 'Description of `arg2`'],
        returns=['bool'],
        return_description='Description of return value',
    )

# Generated at 2022-06-25 16:40:17.116011
# Unit test for function parse
def test_parse():
    assert isinstance(parse(str_0), None)


# Generated at 2022-06-25 16:40:23.672799
# Unit test for function parse
def test_parse():
    print('test_parse...', end=' ')
    assert(parse('      the first line') == 
    parse('\nthe first line'))
    
    assert(parse('      the first line\n\n      the second line') == 
    parse('the first line\n\nthe second line'))
    assert(parse('      the first line\n\n      the second line') == 
    parse('the first line\n\n\n      the second line'))
    print('Passed!')

# -----------------
# Testing Script 
# -----------------

# test_case_0()
test_parse()

# Generated at 2022-06-25 16:40:30.714478
# Unit test for function parse

# Generated at 2022-06-25 16:40:42.657562
# Unit test for function parse
def test_parse():
    str_0 = """
    This is a simple demo
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "This is a simple demo"
    docstring_1 = parse(str_0)
    str_1 = """
    This is a simple demo

    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
    """
    docstring_2 = parse(str_1)
    assert docstring_2.long_description == "Lorem ipsum dolor sit amet, consectetur adipiscing elit."

# Generated at 2022-06-25 16:40:52.941135
# Unit test for function parse
def test_parse():
    class Foo():
        """A simple example class.

        :param foo: description of `foo` parameter
        :param bar: description of `bar` parameter
        :type foo: int
        :type bar: str
        :var baz: description of `baz` variable
        """

        def __init__(self, foo, bar):
            """Description of the `__init__` method.

            :param foo: description of `foo` parameter
            :param bar: description of `bar` parameter
            :type foo: int
            :type bar: str
            """

            self.baz = foo + bar


# Generated at 2022-06-25 16:40:57.069098
# Unit test for function parse
def test_parse():
    try:
        # it is a function without return statement
        assert parse('') is None
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:41:10.233957
# Unit test for function parse
def test_parse():
    assert docstring_0.__str__() == '<Docstring: <Summary: None> <Body: None> <Examples: None> <Returns: None> <Yields: None> <Raises: None> <Attributes: None> <Warns: None> <See Also: None> <Notes: None> <Warnings: None> <References: None> <Version Added: None> <Version Changed: None> <Deprecated: None> <Unknown: None> <Extended Summary: None> <Extended Body: None> <Extended Examples: None> <Extended Attributes: None>>'

test_case_0()

# Generated at 2022-06-25 16:41:15.350407
# Unit test for function parse
def test_parse():
    # AssertionError: ValueError: None is not a string
    test_case_0()


if __name__ == '__main__':
    import sys
    import traceback

    try:
        test_parse()
    except AssertionError as e:
        traceback.print_exc()
        raise
    except:
        traceback.print_exc()
        sys.exit(1)
    sys.exit(0)

# Generated at 2022-06-25 16:41:26.392022
# Unit test for function parse
def test_parse():
    str_0 = """The main parsing routine."""
    docstring_0 = parse(str_0)
    # Check simple equality
    assert docstring_0.short_description == "The main parsing routine."

    str_0 = """The main parsing routine.

"""
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "The main parsing routine."


    str_0 = """The main parsing routine.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
"""
    docstring_0 = parse(str_0)
    # Check simple equality
    assert docstring_0.short_description == "The main parsing routine."
    assert docstring_0.long_description == None

# Generated at 2022-06-25 16:41:31.102614
# Unit test for function parse
def test_parse():
    assert None == parse('')


# Generated at 2022-06-25 16:41:39.246714
# Unit test for function parse
def test_parse():
    str_0 = """This is a module to test parsing docstrings.

:type message: str
:var message: default message to print if no message provided
:param message: message to print
"""
    docstring = parse(str_0)
    assert(docstring.short_description == 'This is a module to test parsing docstrings.')
    assert(docstring.type_comments['message'] == 'str')
    assert(docstring.var_comments['message'] == 'default message to print if no message provided')
    assert(docstring.params['message'] == 'message to print')

# Test for a typical google style docstring

# Generated at 2022-06-25 16:41:49.293547
# Unit test for function parse
def test_parse():
    str_0 = None
    assert docstring_0 == docstring_parse(str_0)
    str_1 = 'test'
    assert docstring_1 == docstring_parse(str_1)
    str_2 = 'test'
    assert docstring_2 == docstring_parse(str_2)
    str_3 = 'test\n'
    assert docstring_3 == docstring_parse(str_3)
    str_4 = 'test\n'
    assert docstring_4 == docstring_parse(str_4)
    str_5 = 'test\n'
    assert docstring_5 == docstring_parse(str_5)
    str_6 = 'test\n'
    assert docstring_6 == docstring_parse(str_6)
    str_7 = 'test\n'


# Generated at 2022-06-25 16:41:53.341303
# Unit test for function parse
def test_parse():
    text_0 = "A string"
    style_0 = Style.auto
    ret_2 = parse(text_0, style_0)
    assert type(ret_2) == Docstring


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:41:56.752268
# Unit test for function parse
def test_parse():
    docstring_0 = None

    str_0 = "This is a test."
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "This is a test."

# Generated at 2022-06-25 16:42:03.802734
# Unit test for function parse
def test_parse():
    # try:
    #     assert(parse('string') == 'string')
    #     assert(parse('unknown string') == 'unknown string')
    # except Exception as e:
    #     raise Exception(e)
    # finally:
    #     print('Test successful')
    pass


if __name__ == '__main__':
    test_case_0()
    # test_parse()

# Generated at 2022-06-25 16:42:07.209223
# Unit test for function parse
def test_parse():
    input_string = None
    output_string = parse(input_string)
    assert output_string == None



# Generated at 2022-06-25 16:42:18.894158
# Unit test for function parse
def test_parse():
    str_0 = None
    _ = parse(str_0)
    return


if __name__ == '__main__':
    import sys
    import time

    start_time = time.time()
    for i in range(1000000):
        test_parse()
    end_time = time.time()

    print("Execution time: {}".format(end_time - start_time))

# Execution time: 6.912806749343872

# Generated at 2022-06-25 16:42:27.682313
# Unit test for function parse
def test_parse():
    str_0 = 'Returns: The result of the operation.'
    style_1 = Style.numpy
    docstring_0 = parse(str_0, style=style_1)
    assert docstring_0.summary == None, 'Summary must be None.'
    assert docstring_0.meta['returns'] == 'The result of the operation.', 'Meta returns must be "The result of the operation."'

    str_1 = 'Args: arg1(int): The first argument.'
    docstring_1 = parse(str_1, style=style_1)
    assert docstring_1.summary == None, 'Summary must be None.'
    assert docstring_1.meta['args'] == 'arg1(int): The first argument.', 'Meta args must be "arg1(int): The first argument."'


# Generated at 2022-06-25 16:42:38.017141
# Unit test for function parse
def test_parse():
    str_0 = """
        Args:
          a:
            - 1
            - 2
    """
    docstring_0 = parse(str_0)
    str_1 = """
        Parameters
        ----------
        a: int
          An integer.
    """
    docstring_1 = parse(str_1)
    str_2 = """
        Parameters
        ----------
        a: int
          An integer.

        b: str
          A string.

        Returns
        -------
        c: float
          A float.
    """
    docstring_2 = parse(str_2)
    str_3 = """
        Returns
        -------
        c: float
          A float.

        b: str
          A string.

        Parameters
        ----------
        a: int
          An integer.
    """


# Generated at 2022-06-25 16:42:41.241325
# Unit test for function parse
def test_parse():
    text_0 = "Hello"
    docstring_0 = parse(text_0)
    assert docstring_0 == ""
    style_0 = "numpy"
    docstring_1 = parse(text_0,style_0)
    assert docstring_1 == ""

# Generated at 2022-06-25 16:42:41.761912
# Unit test for function parse
def test_parse():
    assert True == True

# Generated at 2022-06-25 16:42:48.470054
# Unit test for function parse
def test_parse():
    _style = Style.numpy

# Generated at 2022-06-25 16:42:50.142430
# Unit test for function parse
def test_parse():
    assert callable(parse)
    assert isinstance(parse(' some text '),Docstring)

# Generated at 2022-06-25 16:42:59.632245
# Unit test for function parse
def test_parse():
    expected_return = """docstring_parser.common.Docstring(admonition=None, args=None, args_kwargs_only=False, attributes=None, exceptions=None, examples=None, kwargs=None, key=None, meta=docstring_parser.common.Meta(author=[], copyright=[], created=[], description=[], deprecated=[], keywords=[], license=[], note=[], notes=[], organization=[], parameters=[], see=[], todo=[], version=[], warning=[]), methods=None, name=None, note=None, rest=None, returns=None, sections=None, see_also=None, todo=None, warnings=None)"""
    str_0 = "The main parsing routine."
    assert str(parse(str_0)) == expected_return

# Generated at 2022-06-25 16:43:10.461632
# Unit test for function parse
def test_parse():
    str_1 = '''This function returns a string.
    :param a:
    :param b:
    :returns:
    '''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "This function returns a string."
    assert docstring_1.long_description == ""
    assert docstring_1.meta["param"]["a"]["type"] is None
    assert docstring_1.meta["param"]["b"]["type"] is None
    assert docstring_1.meta["param"]["a"]["desc"] == ""
    assert docstring_1.meta["param"]["b"]["desc"] == ""
    assert docstring_1.meta["return"]["type"] is None

# Generated at 2022-06-25 16:43:22.479152
# Unit test for function parse
def test_parse():
    text = """
        This is a summary.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.

        Raises:
            AttributeError: The ``AttributeError`` exception.
            ValueError: The ``ValueError`` exception.

        .. _Google Python Style Guide:
           http://google.github.io/styleguide/pyguide.html

        .. _YAPF:
           https://github.com/google/yapf
    """
    style = Style.google
    d = parse(text, style)

    assert d.summary == "This is a summary."
    assert len(d.meta) == 3
    assert d.meta[0].name == 'arg1'
    assert d