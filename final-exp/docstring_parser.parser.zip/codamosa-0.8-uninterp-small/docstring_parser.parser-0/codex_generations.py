

# Generated at 2022-06-25 16:33:41.593528
# Unit test for function parse
def test_parse():
    # Test case 1
    str_1 = 'Hello, world.'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Hello, world.'
    assert docstring_1.long_description == ''

    # Test case 2
    str_2 = 'Hello, world.\n\nGoodbye, world.'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'Hello, world.'
    assert docstring_2.long_description == 'Goodbye, world.'

    # Test case 3
    str_3 = ':short: Hello, world.\n\n:long: Goodbye, world.'
    docstring_3 = parse(str_3)
    assert docstring_3.short_description == 'Hello, world.'
    assert docstring

# Generated at 2022-06-25 16:33:49.554116
# Unit test for function parse
def test_parse():  # TODO: fully test parser
    str_0 = """This is a docstring.

:param name: The name
:type name: str
:returns: name
:rtype: str
"""
    docstring_0 = Docstring(
        content='This is a docstring.',
        params={'name': {'type': 'str', 'desc': 'The name'}},
        returns={'type': 'str', 'desc': 'name'},
        meta={}
    )
    assert parse(str_0) == docstring_0


# Generated at 2022-06-25 16:33:51.357961
# Unit test for function parse
def test_parse():
    with pytest.raises(ParseError):
        parse("")


# Generated at 2022-06-25 16:33:59.011765
# Unit test for function parse
def test_parse():
    str_0 = '_'
    assert not parse(str_0).summary
    assert not parse(str_0).description
    assert not parse(str_0).return_type
    assert not parse(str_0).returns

    # Zero Parameters
    str_1 = '.. py:function:: test_function_0(self)'
    assert 'test_function_0' == parse(str_1).name
    assert not parse(str_1).parameters
    assert not parse(str_1).return_type
    assert not parse(str_1).returns

    # Summary
    str_2 = '.. py:function:: test_function_1(self)' + '\n\n' + \
            '   Function summary.'
    assert 'Function summary.' == parse(str_2).summary

# Generated at 2022-06-25 16:34:00.965221
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-25 16:34:10.383809
# Unit test for function parse
def test_parse():
    str_0 = '_'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    import resource
    import timeit

    def run_time(func):
        t = timeit.Timer(lambda: func())
        print(t.timeit(1))


    resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
    run_time(test_case_0)

    resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    run_time(test_case_0)

    resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
    run_time(test_case_0)

# Generated at 2022-06-25 16:34:17.533881
# Unit test for function parse
def test_parse():
    str_0 = '_'
    docstring_0 = parse(str_0)
    str_1 = '__'
    docstring_1 = parse(str_1)
    str_2 = '___'
    docstring_2 = parse(str_2)
    str_3 = '____'
    docstring_3 = parse(str_3)
    str_4 = '_____'
    docstring_4 = parse(str_4)
    str_5 = '______'
    docstring_5 = parse(str_5)
    str_6 = '_______'
    docstring_6 = parse(str_6)
    str_7 = '________'
    docstring_7 = parse(str_7)
    str_8 = '_________'
    docstring_8 = parse(str_8)


# Generated at 2022-06-25 16:34:28.958870
# Unit test for function parse
def test_parse():
    assert docstring_0.meta["summary"] == ""
    assert docstring_0.meta["module"] == ""
    assert docstring_0.meta["author"] == ""
    assert docstring_0.meta["copyright"] == ""
    assert docstring_0.meta["credits"] == ""
    assert docstring_0.meta["license"] == ""
    assert docstring_0.meta["version"] == ""
    assert docstring_0.meta["email"] == ""
    assert docstring_0.meta["status"] == ""
    assert docstring_0.meta["todo"] == []
    assert docstring_0.meta["see"] == []
    assert docstring_0.meta["note"] == []
    assert docstring_0.meta["warning"] == []
    assert docstring_0.meta["bug"] == []


# Generated at 2022-06-25 16:34:31.448988
# Unit test for function parse
def test_parse():
    assert parse('_') == 0
    
    
test_parse()
test_case_0()

# Generated at 2022-06-25 16:34:38.767007
# Unit test for function parse
def test_parse():
    assert parse("") is not None
    assert parse("_") is not None
    assert parse("This is a test for function parse") is not None
    assert parse("_") == Docstring(summary='',
                                   description='',
                                   meta=set(),
                                   examples=[],
                                   raises=[],
                                   warnings=[],
                                   notes=[],
                                   references=[],
                                   returns=[])
    assert parse("_ _ _ _") == Docstring(summary='',
                                         description=' _ _ _',
                                         meta=set(),
                                         examples=[],
                                         raises=[],
                                         warnings=[],
                                         notes=[],
                                         references=[],
                                         returns=[])

# Generated at 2022-06-25 16:34:50.798985
# Unit test for function parse
def test_parse():
    text = 'foo'
    docstring = parse(text)
    assert docstring.style == Style.google
    assert docstring.summary == ''
    assert docstring.extended_summary == ''
    assert docstring.returns == None
    assert docstring.yields == None
    assert docstring.raises == []
    assert docstring.meta == None
    assert docstring.params == []
    assert docstring.other == []

# Generated at 2022-06-25 16:34:54.511120
# Unit test for function parse
def test_parse():
    str_0 = '_'
    docstring_0 = parse(str_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:34:55.330377
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:35:01.508228
# Unit test for function parse
def test_parse():
    str_0 = '_'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == '_'

# Test 1

# Generated at 2022-06-25 16:35:10.887086
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = '_'
    docstring_0 = parse(str_0)

    # Test case 1
    str_1 = '_'
    docstring_1 = parse(str_1)

    # Test case 2
    str_2 = '_'
    docstring_2 = parse(str_2)

    # Test case 3
    str_3 = '_'
    docstring_3 = parse(str_3)

    # Test case 4
    str_4 = '_'
    docstring_4 = parse(str_4)

    # Test case 5
    str_5 = '_'
    docstring_5 = parse(str_5)

    # Test case 6
    str_6 = '_'
    docstring_6 = parse(str_6)

    # Test

# Generated at 2022-06-25 16:35:18.213115
# Unit test for function parse
def test_parse():
    str_0 = "parse_regex(path, regex, group=.0, encoding=.cp437.)"
    str_1 = "parse_regex(path, regex, group=.regex_group., encoding=.cp437.)"
    str_2 = "parse_regex(path, regex, group=.regex_group., encoding=.cp437., \
filter_regex=.filter_regex.)"
    str_3 = "parse_regex(path, regex, group=.regex_group., encoding=.cp437.)"
    str_4 = 'parse_regex(path, regex, group=.regex_group., encoding=.cp437.)'
    str_5 = 'parse_regex(path, regex, group=.regex_group., encoding=.cp437.)'
    str_

# Generated at 2022-06-25 16:35:29.382013
# Unit test for function parse
def test_parse():
    str_0 = '''
    def a():

    return 1
    '''
    docstring_0 = parse(str_0)
    assert docstring_0
    assert docstring_0.params == {}

    str_1 = '''
    def a(a):

    return 1
    '''
    docstring_1 = parse(str_1)
    assert docstring_1
    assert docstring_1.params == {'a' : ''}

    str_2 = '''
    def a(a):

    return 1
    '''
    docstring_2 = parse(str_2)
    assert docstring_2
    assert docstring_2.params == {'a' : ''}

    str_3 = '''
    def a(a):

    return 1
    '''
    docstring_

# Generated at 2022-06-25 16:35:39.988763
# Unit test for function parse
def test_parse():
    # Test case 0:
    assert(parse("_") == Docstring(description="_",
                                   content=[],
                                   returns=[],
                                   meta={}))

    # Test case 1:
    assert(parse("_\n\nThis is a test\n") == Docstring(description="_\n\nThis is a test",
                                                       content=[],
                                                       returns=[],
                                                       meta={}))

    # Test case 2:
    assert(parse("_\n\nThis is a test\n\nThis is a description\n") == Docstring(description="_\n\nThis is a test",
                                                                                content=[],
                                                                                returns=[],
                                                                                meta={}))

    # Test case 3:

# Generated at 2022-06-25 16:35:41.436828
# Unit test for function parse
def test_parse():
    str_0 = '_'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:35:42.618640
# Unit test for function parse
def test_parse():
    test_case_0()

# Main function to run unit tests

# Generated at 2022-06-25 16:35:58.754163
# Unit test for function parse
def test_parse():
    # Test 1: With an example return
    ans = parse('parse(text: str, style: Style = Style.auto) -> Docstring\n')
    assert ans.short_description == 'parse(text: str, style: Style = Style.auto) -> Docstring'
    assert ans.long_description == ''
    assert ans.lines == []

    # Test 2: With an example return
    ans = parse('parse(text: str, style: Style = Style.auto) -> Docstring\n\nLong')
    assert ans.short_description == 'parse(text: str, style: Style = Style.auto) -> Docstring'
    assert ans.long_description == 'Long'
    assert ans.lines == []

    # Test 3: With an example return and single line

# Generated at 2022-06-25 16:36:03.540299
# Unit test for function parse

# Generated at 2022-06-25 16:36:15.911096
# Unit test for function parse
def test_parse():
    str_0 = '_'
    docstring_0 = parse(str_0)
    assert len(docstring_0.brief) == 0

    str_1 = 'blabla'
    docstring_1 = parse(str_1)
    assert docstring_1.brief == 'blabla'

    str_2 = 'blabla\n\nbla'
    docstring_2 = parse(str_2)
    assert len(docstring_2.params) == 0

    str_3 = 'blabla\n\nblabla blabla\nblabla\n'
    docstring_3 = parse(str_3)
    assert docstring_3.brief == 'blabla'


# Generated at 2022-06-25 16:36:26.795308
# Unit test for function parse
def test_parse():

    # Setup
    str_0 = '_'
    docstring_0 = parse(str_0)
    assert docstring_0._text == str_0

    str_1 = '_\n'
    docstring_1 = parse(str_1)
    assert docstring_1._text == str_1

    str_2 = '_\n\n'
    docstring_2 = parse(str_2)
    assert docstring_2._text == str_2

    str_3 = '_\n\n\n'
    docstring_3 = parse(str_3)
    assert docstring_3._text == str_3

    str_4 = '_\n\n\n\n'
    docstring_4 = parse(str_4)
    assert docstring_4._text == str_4



# Generated at 2022-06-25 16:36:36.734216
# Unit test for function parse
def test_parse():

    # Test case import
    from docstring_parser.common import ParseError

    # Test case 1
    str_1 = 'Test docstring.'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Test docstring.'
    assert docstring_1.long_description == ''

    # Test case 2
    str_2 = 'Test docstring.\n\nTest function.'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'Test docstring.'
    assert docstring_2.long_description == 'Test function.'

    # Test case 3
    str_3 = 'Test docstring.\n\nTest function.\n\n:var var1: variable 1'
    docstring_3 = parse(str_3)
   

# Generated at 2022-06-25 16:36:44.897507
# Unit test for function parse
def test_parse():
    # make sure that the docstring parses the text properly
    docstring = parse(__doc__)
    assert docstring.summary == (
        "The main parsing routine."
    )
    assert docstring.description == (
        "Parse the docstring into its components.\n\n"
        ":param text: docstring text to parse\n"
        ":param style: docstring style\n"
        ":returns: parsed docstring representation\n"
    )
    print("test_parse() - OK!")


# Generated at 2022-06-25 16:36:57.585293
# Unit test for function parse

# Generated at 2022-06-25 16:37:07.348862
# Unit test for function parse
def test_parse():
    # setup
    str_0 = '_'
    str_1 = '_\n'
    str_2 = '_\n\n'
    str_3 = '_\n\n\n'
    str_4 = '_\n\n\n\n'
    str_5 = '_\n\n\n\n\n'
    str_6 = '_\n\n\n\n\n\n'
    str_7 = '_\n\n\n\n\n\n\n'
    str_8 = '_\n\n\n\n\n\n\n\n'
    str_9 = '_\n\n\n\n\n\n\n\n\n'

# Generated at 2022-06-25 16:37:17.113394
# Unit test for function parse
def test_parse():
    arg_0 = '_'
    ret_0 = parse(arg_0)
    assert ret_0.body == ''
    assert ret_0.meta['_'][0].desc == ''
    assert ret_0.meta['_'][0].type == ''
    assert ret_0.summary == ''
    assert ret_0.returns.desc == ''
    assert ret_0.returns.type == ''
    assert ret_0.yields.desc == ''
    assert ret_0.yields.type == ''

    arg_1 = '_\n'
    ret_1 = parse(arg_1)
    assert ret_1.body == ''
    assert ret_1.meta['_'][0].desc == ''
    assert ret_1.meta['_'][0].type == ''
    assert ret

# Generated at 2022-06-25 16:37:28.494202
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = '_'
    docstring_0 = parse(str_0)

    # Test case 1
    str_1 = '_ '
    docstring_1 = parse(str_1)

    # Test case 2
    str_2 = ' _'
    docstring_2 = parse(str_2)

    # Test case 3
    str_3 = '_   '
    docstring_3 = parse(str_3)

    # Test case 4
    str_4 = '   _'
    docstring_4 = parse(str_4)

    # Test case 5
    str_5 = '_\t'
    docstring_5 = parse(str_5)

    # Test case 6
    str_6 = '\t_'

# Generated at 2022-06-25 16:37:45.648227
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    str_1 = '_'
    docstring_1 = parse(str_1)
    str_2 = '_\n'
    docstring_2 = parse(str_2)
    str_3 = '_\n\n'
    docstring_3 = parse(str_3)
    str_4 = '_\n\n\n'
    docstring_4 = parse(str_4)
    str_5 = '_\n\n\n\n'
    docstring_5 = parse(str_5)
    str_6 = '_\n\n\n\n\n'
    docstring_6 = parse(str_6)

# Generated at 2022-06-25 16:37:55.460205
# Unit test for function parse
def test_parse():
    text = '''Base class for all commands.  Provides generic parsing functionality
    that all commands can use.

    :param str command: the name of the command being executed.
    :param str doc: the full documentation string of the command class.
    :param str arg_string: the argument string extracted from the docstring
    :param str logfile: the filename of the logfile
    :param int verbosity: the verbosity level for the logger
    :param bool dryrun: whether or not to actually execute commands
    :param str workdir: the working directory to execute commands in
    :param int jobs: the number of parallel jobs to use
    :param dict umask: the umask to use when executing commands
    '''
    docstring = parse(text)
    print(docstring.arguments)
    print(docstring.description)

# Generated at 2022-06-25 16:38:08.423610
# Unit test for function parse
def test_parse():
    docstring_0 = parse("1")
    docstring_1 = parse("d")
    docstring_2 = parse("e")
    docstring_3 = parse("d")
    docstring_4 = parse("d")
    docstring_5 = parse("d")
    docstring_6 = parse("d")
    docstring_7 = parse("d")
    # noinspection PyCallingNonCallable
    docstring_8 = parse("d")
    # noinspection PyCallingNonCallable
    docstring_9 = parse("d")
    docstring_10 = parse("d")
    docstring_11 = parse("d")
    docstring_12 = parse("d")
    docstring_13 = parse("d")
    docstring_14 = parse("d")
    docstring_15 = parse("d")
   

# Generated at 2022-06-25 16:38:14.281430
# Unit test for function parse
def test_parse():
    assert callable(parse)
    assert len(parse.__args__) == 2
    assert parse.__args__[0] == 'text'
    assert parse.__args__[1] == 'style'
    assert parse.__kwdefaults__['style'] == 'auto'

# Generated at 2022-06-25 16:38:15.153117
# Unit test for function parse
def test_parse():
    assert callable(parse) == True



# Generated at 2022-06-25 16:38:21.543274
# Unit test for function parse
def test_parse():
    # Test 1
    str_1 = 'This is a description.\n\nThis is a\nlong description.\n\nAnd here is yet another line.'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "This is a description."
    assert docstring_1.long_description == "This is a long description.\nAnd here is yet another line."
    assert docstring_1.tags == []

    # Test 2
    str_2 = 'This is a description.\n\nThis is a\nlong description.\n\nAnd here is yet another line.\n\n:param foo: The first param.\n:param bar: The second param.'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:38:30.114215
# Unit test for function parse

# Generated at 2022-06-25 16:38:39.460121
# Unit test for function parse
def test_parse():
    str_1 = "VirtualChain is a cryptocurrency framework for the\
    inclusion of crypto logic in any app.\n\n It offers a high level APIs \
    for crypto functionality as well as low level access to standard crypto \
    primitives."
    docstring_1 = parse(str_1)
    str_2 = 'LSH (Locality Sensitive Hashing) functions.'
    docstring_2 = parse(str_2)
    str_3 = 'Replace the first match of pattern in string with repl, \
    returning the modified string.'
    docstring_3 = parse(str_3)


# Generated at 2022-06-25 16:38:42.909525
# Unit test for function parse
def test_parse():
    assert(parse('_') != parse('_'))



# Generated at 2022-06-25 16:38:44.123676
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:39:10.683226
# Unit test for function parse
def test_parse():
    # Testing for Dunder
    assert parse('''__all__ = ['parse', 'test_parse']''')

    # Testing for Function with arguments
    assert parse('''Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation''')
    # Testing for Function
    assert parse('''Create an image with the loaded image mask applied.''')

    # Testing for Class
    assert parse('''A rectangle with four sides of equal length is a square''')


# Unit Test for class Docstring

# Generated at 2022-06-25 16:39:13.217403
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-25 16:39:24.076910
# Unit test for function parse
def test_parse():
    str_0 = '_'
    docstring_0 = parse(str_0)
    assert docstring_0.title == ''
    assert docstring_0.description == ''
    assert docstring_0.args == []
    assert docstring_0.returns == None
    assert docstring_0.raises == []
    str_1 = '_\n    DOCSTRING_PARSER_V\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.title == ''
    assert docstring_1.description == 'DOCSTRING_PARSER_V'
    assert docstring_1.args == []
    assert docstring_1.returns == None
    assert docstring_1.raises == []

# Generated at 2022-06-25 16:39:26.215092
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-25 16:39:34.407624
# Unit test for function parse

# Generated at 2022-06-25 16:39:45.826438
# Unit test for function parse
def test_parse():
    str_0 = '    Docstring for a function or method.\n    \n    '
    str_1 = '    Docstring for a function or method.\n    \n    '
    str_2 = '    More elaborate description of function. Can contain several\n    paragraphs.\n    \n    '
    str_3 = '(a, b[, c]): Docstring for a function with parameters.'
    str_4 = '(a, b[, c]): Docstring for a function with parameters.'
    str_5 = '(a, b[, c]): Docstring for a function with parameters.'
    str_6 = '    :param a:\n    :type a:\n    :param b:\n    :type b:\n    :param c:\n    :type c:\n    '

# Generated at 2022-06-25 16:39:48.805238
# Unit test for function parse
def test_parse():
    str_0 = '_'
    docstring_0 = parse(str_0)
    assert True



# Generated at 2022-06-25 16:39:53.284870
# Unit test for function parse
def test_parse():
    print('--> test_parse() ', end='')

    text = """
    This is a module docstring.
    """

    docstring = parse(text)

    assert docstring.short_description == "This is a module docstring."
    assert docstring.long_description is None
    assert docstring.meta == {}

    print('OK')


# Generated at 2022-06-25 16:39:55.151200
# Unit test for function parse
def test_parse():
    test_case_0()


# Compiled implementation
parse_impl = parse

# Generated at 2022-06-25 16:40:04.894579
# Unit test for function parse
def test_parse():

    # Test 1:
    str_1 = '_'
    docstring_1 = parse(str_1)
    # print(docstring_1)
    assert docstring_1.__class__.__name__ == 'Docstring'
    assert docstring_1.summary == ''
    assert docstring_1.body == ''
    assert docstring_1.meta == {}
    assert docstring_1.get_tag('arg') == []
    assert docstring_1.get_tag('author') == []
    assert docstring_1.get_tag('arg_example') == []
    assert docstring_1.get_tag('arg_example_idx') == []
    assert docstring_1.get_tag('author') == []
    assert docstring_1.get_tag('caveats') == []
    assert doc

# Generated at 2022-06-25 16:40:31.797064
# Unit test for function parse
def test_parse():
    str_0 = '/**\r\n * Description of the class\r\n */'
    docstring_0 = parse(str_0)
    str_1 = '/**\r\n * Description of the class\r\n * @author\r\n * @version 1.0\r\n */'
    docstring_1 = parse(str_1)
    str_2 = '/**\r\n * Description of the class\r\n */\r\n/**\r\n * Description of the class\r\n * @author\r\n * @version 1.0\r\n */'
    docstring_2 = parse(str_2)
    str_3 = '/**\r\n * Description of the function\r\n */'
    docstring_3 = parse(str_3)
    str

# Generated at 2022-06-25 16:40:44.140150
# Unit test for function parse
def test_parse():
    docstring_0 = parse('_')
    assert docstring_0.title == '', 'Expected empty and got ' + str(docstring_0.title)
    assert docstring_0.description == '', 'Expected empty and got ' + str(docstring_0.description)
    assert docstring_0.type_tag == '_', 'Expected _ and got ' + str(docstring_0.type_tag)
    assert docstring_0.meta == {}, 'Expected empty and got ' + str(docstring_0.meta)
    assert docstring_0.params == [], 'Expected [] and got ' + str(docstring_0.params)
    assert docstring_0.returns == None, 'Expected None and got ' + str(docstring_0.returns)
    docstring_0 = parse

# Generated at 2022-06-25 16:40:45.511494
# Unit test for function parse
def test_parse():
    assert parse(None, None) == None



# Generated at 2022-06-25 16:40:50.198469
# Unit test for function parse
def test_parse():
    docstring_0 = parse(str_0)
    assert (docstring_0 == None)

# Generated at 2022-06-25 16:40:56.524870
# Unit test for function parse
def test_parse():
    try:
        str_0 = '_'
        docstring_0 = parse(str_0)
    except ParseError as e:
        assert(e.text == '_')
        assert(e.lineno == None)
        assert(e.colno == None)
        assert(e.style == Style.auto)
    try:
        str_1 = '_'
        docstring_1 = parse(str_1, Style.sphinx)
    except ParseError as e:
        assert(e.text == '_')
        assert(e.lineno == None)
        assert(e.colno == None)
        assert(e.style == Style.sphinx)

# Generated at 2022-06-25 16:40:59.298518
# Unit test for function parse
def test_parse():
    test_case_0()
    print("unit test passed")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:41:10.234094
# Unit test for function parse
def test_parse():
    str_0 = 'Module to parse docstrings.'
    docstring_0 = parse(str_0)
    str_1 = ""
    str_1 = docstring_0.short_description
    str_2 = "Docstring Styles"
    str_2 = docstring_0.long_description
    str_3 = "Parameters"
    str_3 = docstring_0.meta['Parameters'][0]
    str_4 = ":param text: docstring text to parse"
    str_4 = docstring_0.meta['Parameters'][1]
    str_5 = ":param style: docstring style"
    str_5 = docstring_0.meta['Parameters'][2]
    str_6 = ":returns: parsed docstring representation"
    str_6 = docstring_0.meta['Returns']
   

# Generated at 2022-06-25 16:41:20.728901
# Unit test for function parse
def test_parse():

    print(test_case_0.__name__)
    try:
        test_case_0()
    except:
        print("Test case 0 FAILED!")
        return
    print("Test case 0 PASSED!")




if __name__ == '__main__':
    import argparse as AP

    # Create an Argument Parser
    parser = AP.ArgumentParser()

    # Add a nargs='+' argument for accepting a list of integers
    parser.add_argument('--test', nargs='?', default=0, type=int)

    # Parse the command line arguments
    args = vars(parser.parse_args())

    if args['test'] == 0:
        # test_case_0()
        test_parse()

# Generated at 2022-06-25 16:41:21.698886
# Unit test for function parse
def test_parse():
    pass

test_parse()

# Generated at 2022-06-25 16:41:29.920967
# Unit test for function parse
def test_parse():
    str0 = '_'
    docstring0 = parse(str0)
    str1 = "\\"
    docstring1 = parse(str1)
    str2 = "\""
    docstring2 = parse(str2)
    str3 = "\'"
    docstring3 = parse(str3)
    str4 = "\\\'\""
    docstring4 = parse(str4)
    str5 = "\\\'\\\""
    docstring5 = parse(str5)
    str6 = "\\\"\\\'"
    docstring6 = parse(str6)
    str7 = "\'\\\"\""
    docstring7 = parse(str7)
    str8 = "\"\\\"\\\'"
    docstring8 = parse(str8)
    str9 = "\'\\\"\\\"\""
   

# Generated at 2022-06-25 16:41:52.213948
# Unit test for function parse
def test_parse():
    example_docstring = '''
    This is an example docstring.

    :param arg1: First argument.
    :type arg1: int
    :param arg2: Second argument.
    :type arg2: str
    :returns: arg1 + arg2
    :rtype: str
    '''
    parsed = parse(example_docstring)
    parsed.short_description
    parsed.long_description
    parsed.meta
    parsed.meta['arg1']


# Generated at 2022-06-25 16:42:02.387525
# Unit test for function parse
def test_parse():
    # Testing for the case 'str_0 : _'
    str_0 = '_'
    docstring_0 = parse(str_0)

    # Testing for the case 'str_1 : description\n'
    str_1 = 'description\n'
    docstring_1 = parse(str_1)

    # Testing for the case 'str_2 : :param x: param x'
    str_2 = ':param x: param x'
    docstring_2 = parse(str_2)

    # Testing for the case 'str_3 : :param x: first\n    param x'
    str_3 = ':param x: first\n    param x'
    docstring_3 = parse(str_3)

    # Testing for the case 'str_4 : :param x: param x\n\n:type

# Generated at 2022-06-25 16:42:03.210265
# Unit test for function parse
def test_parse():
    assert parse


# Generated at 2022-06-25 16:42:04.815360
# Unit test for function parse
def test_parse():
    assert callable(parse)


# vim: set filetype=python ts=4 sw=4 tw=79 et :

# Generated at 2022-06-25 16:42:17.002142
# Unit test for function parse
def test_parse():
    docstring_0 = parse("a")
    assert docstring_0.meta['a'] == ''
    docstring_1 = parse("a     b")
    assert docstring_1.meta['a'] == 'b'
    docstring_2 = parse("b")
    assert docstring_2.meta['b'] == ''
    docstring_3 = parse("b     c")
    assert docstring_3.meta['b'] == 'c'
    docstring_4 = parse("d")
    assert docstring_4.meta['d'] == ''
    docstring_5 = parse("d     e")
    assert docstring_5.meta['d'] == 'e'
    docstring_6 = parse("a     b     c     d     e")
    assert docstring_6.meta['a'] == 'b'

# Generated at 2022-06-25 16:42:21.197339
# Unit test for function parse
def test_parse():
    assert callable(parse)

exec(test_case_0.__name__ + '()')

# Generated at 2022-06-25 16:42:32.237245
# Unit test for function parse
def test_parse():
    # [docstring_parser.common.Docstring, str, docstring_parser.styles.Style]
    args = [(Docstring, "text", Style)]
    # [docstring_parser.common.Docstring, docstring_parser.common.Docstring, docstring_parser.common.Docstring]
    expected_res = [Docstring, Docstring, Docstring]
    # python3 doesn't specify the order of keyword arguments, so need to be
    # flexible here.
    for i in range(3):
        res = parse(*args[i])
        assert res == expected_res[i]



# Generated at 2022-06-25 16:42:38.855134
# Unit test for function parse
def test_parse():
    # docstring_parser.py:342: error: Test of function parse failed
    # docstring_parser.py:342: error:   stdout: None
    # docstring_parser.py:342: error:   stderr: None
    # docstring_parser.py:342: error:   return code: None
    # docstring_parser.py:342: error:   exception: None
    str_0 = '_'
    docstring_0 = parse(str_0)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:42:46.588998
# Unit test for function parse
def test_parse():
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
    assert True == True
   

# Generated at 2022-06-25 16:42:56.685200
# Unit test for function parse
def test_parse():
    docstring_0 = parse('_')
    assert docstring_0.short_description == '_'
    assert docstring_0.long_description == ''
    assert docstring_0.meta == {}
    assert docstring_0.style == Style.numpy
    docstring_1 = parse('_', style=Style.numpy)
    assert docstring_1.short_description == '_'
    assert docstring_1.long_description == ''
    assert docstring_1.meta == {}
    assert docstring_1.style == Style.numpy
    docstring_2 = parse('_', style='numpy')
    assert docstring_2.short_description == '_'
    assert docstring_2.long_description == ''
    assert docstring_2.meta == {}

# Generated at 2022-06-25 16:43:16.801290
# Unit test for function parse
def test_parse():
    str_0 = '_'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:43:21.528643
# Unit test for function parse
def test_parse():
    # print(parse('_'))
    assert str(parse('_')) == '<docstring_parser.docstring.Docstring object at 0x7f9838e9f908>'

# if __name__ == '__main__':
#     print(parse('_'))

# Generated at 2022-06-25 16:43:31.297481
# Unit test for function parse
def test_parse():
    text_0 = ''
    style_0 = Style.auto
    docstring_0 = parse(text_0, style_0)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert docstring_0.return_type == ''
    assert docstring_0.return_description == ''
    assert docstring_0.meta == {}
    assert docstring_0.errors == []
    assert docstring_0.args == []
    assert docstring_0.args_full == []

    text_1 = '.. module:: test'
    style_1 = Style.numpy
    docstring_1 = parse(text_1, style_1)
    assert docstring_1.short_description == ''