

# Generated at 2022-06-25 16:33:36.297150
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:33:42.398869
# Unit test for function parse
def test_parse():
    docstring_tests_0 = parse('Test function for `parse`.')
    docstring_tests_1 = parse('Test function for `parse`.')
    assert docstring_tests_0 == docstring_tests_1
    docstring_tests_2 = parse('Test function for `parse`.')
    assert docstring_tests_2 == docstring_tests_1
    return 'Test completed'


# Generated at 2022-06-25 16:33:43.381350
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:33:49.929318
# Unit test for function parse
def test_parse():
    src = """\
summary

description

:param param1: this is a param
:param param2: this is a param
:returns: this is what is returned
:raises keyError: raises an exception
"""
    docstring = parse(src)
    assert docstring.summary == 'summary'
    assert docstring.description == 'description'
    assert docstring.returns == 'this is what is returned'


# Generated at 2022-06-25 16:33:58.144259
# Unit test for function parse
def test_parse():
    # Setup
    style = Style.auto
    text = 'This is a sample docstring to test with'
    expected = Docstring(
        content='This is a sample docstring to test with',
        params=[],
        returns=None,
        raises=[],
        styles=[Style.google],
        title='',
        meta={})
    try:
        # Exercise
        actual = parse(text, style)
    except:
        # Verify
        assert False
    else:
        # Verify
        assert actual is not expected
        assert len(actual.params) == len(expected.params)
        assert len(actual.raises) == len(expected.raises)
        assert list(actual.params) == list(expected.params)
        assert list(actual.raises) == list(expected.raises)
        assert actual.content

# Generated at 2022-06-25 16:34:02.628679
# Unit test for function parse
def test_parse():
    # test code here.
    text = None
    style = None
    docstring_0 = parse(text, style)



# Generated at 2022-06-25 16:34:13.231885
# Unit test for function parse
def test_parse():
    # Example 1
    str_0 = '\n    @{\x0cIxUsa}pDfA{v+P]~\n'
    style_0 = Style.np
    docstring_0 = parse(str_0, style_0)
    args_0 = docstring_0.args
    kwargs_0 = docstring_0.kwargs
    meta_0 = docstring_0.meta
    exceptions_0 = docstring_0.exceptions
    returns_0 = docstring_0.returns
    content_0 = docstring_0.content
    if (len(args_0) != 0):
        print('AssertionError')
    if (len(kwargs_0) != 0):
        print('AssertionError')

# Generated at 2022-06-25 16:34:18.222167
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:34:20.585420
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Check that the output of the function match with the expected result

# Generated at 2022-06-25 16:34:23.145286
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:34:38.913170
# Unit test for function parse
def test_parse():
    text_0 = 'This is a nice docstring.\n\nIt is separated by two newlines into multiple parts.'
    text_1 = 'Some other docstring.\n\nIt too is also separated by two newlines into multiple parts.'
    text_2 = 'Another nice docstring.\n\nIt too is separated by two newlines into multiple parts.'
    style_0 = Style.sphinx
    style_1 = Style.google
    style_2 = Style.auto
    style_3 = Style.numpy
    style_4 = Style.google
    style_5 = Style.numpy
    style_6 = Style.sphinx
    style_7 = Style.google
    style_8 = Style.numpy
    style_9 = Style.auto
    style_10 = Style.google

# Generated at 2022-06-25 16:34:40.763870
# Unit test for function parse
def test_parse():
    test_case_0()


test_parse()

# Generated at 2022-06-25 16:34:44.716605
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    style = Style.auto
    docstring_0 = parse(str_0, style)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert docstring_0.meta == {'@{': ['{\x0cIxUsa', 'pDfA', 'v+P]~']}



# Generated at 2022-06-25 16:34:54.511632
# Unit test for function parse
def test_parse():
    str_0 = """
        @param arg: the first arg
    """
    docstring_0 = parse(str_0)
    assert docstring_0.meta['arg'][0].type_name is None
    assert docstring_0.meta['arg'][0].arg_name == 'arg'
    assert docstring_0.meta['arg'][0].description == 'the first arg'
    assert docstring_0.summary == ''
    assert docstring_0.body == ''
    assert docstring_0.returns is None

    str_1 = """
    @brief Brief summary

    Detailed description

    @param arg: the first arg
    """
    docstring_1 = parse(str_1)
    assert docstring_1.meta['arg'][0].type_name is None
    assert docstring_

# Generated at 2022-06-25 16:34:55.261565
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:34:57.903193
# Unit test for function parse
def test_parse():
    str_0 = 'P?o'
    style = Style.google

    assert parse(str_0, style) == 'P?o'

# Generated at 2022-06-25 16:35:01.925792
# Unit test for function parse
def test_parse():
    test_str = '@{IxUsa}pDfA{v+P]~'
    docstring = parse(test_str)
    assert isinstance(docstring, Docstring)

# Generated at 2022-06-25 16:35:11.241821
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)
    str_1 = '''
    @brief A test string.
    @param str_0 A test param.
    '''
    docstring_1 = parse(str_1)
    str_2 = '''
    @brief A test string.
    '''
    docstring_2 = parse(str_2)
    str_3 = '''
    @brief A test string.
    @param str_0 A test param.
    @param str_1 A test param.
    @param str_2 A test param.
    '''
    docstring_3 = parse(str_3)
    str_4 = 'A test string.'
   

# Generated at 2022-06-25 16:35:14.141039
# Unit test for function parse
def test_parse():
    docstring_0 = Docstring(description='', content=[], returns=None, meta={}, style='auto')
    assert parse() == docstring_0

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:35:20.343101
# Unit test for function parse
def test_parse():
    text = '''
Hello world!
========
Author: John Doe
Date: 1 February 2013
Description:
    This is a description of the program. It has multiple lines!
    It can even contain **markdown** formatting!
'''
    assert parse(text).short_description == "Hello world!"
    assert parse(text).long_description == '''This is a description of the program. It has multiple lines!
It can even contain **markdown** formatting!'''
    assert parse(text).sphinx_extras == {
        "author": "John Doe",
        "date": "1 February 2013",
        "description": "Hello world!",
    }

# Generated at 2022-06-25 16:35:33.971816
# Unit test for function parse
def test_parse():
    str_0 = 'P?o'
    expected_output_0 = Docstring(summary='P?o\n')
    assert parse(str_0, style='fb') == expected_output_0
    str_1 = 'P?o'
    expected_output_1 = Docstring(summary='P?o\n')
    assert parse(str_1, style='fb') == expected_output_1
    str_2 = 'P?o'
    expected_output_2 = Docstring(summary='P?o\n')
    assert parse(str_2, style='fb') == expected_output_2
    str_3 = 'P?o'
    expected_output_3 = Docstring(summary='P?o\n')
    assert parse(str_3, style='fb') == expected_output_3
    str_

# Generated at 2022-06-25 16:35:36.169321
# Unit test for function parse
def test_parse():

    str_0 = 'P?o'

    assert parse(str_0) == 'P?o'


# Generated at 2022-06-25 16:35:46.971535
# Unit test for function parse
def test_parse():
    try:
        str_1 = 'Section 1\nSection 2'
        result = parse(str_1)
    except BaseException as e:
        print(e)
        result = False
    assert result

# ----------------------------------------------------------------
# Outputs for testing

test_parse_0_output = None
test_parse_1_output = False
test_parse_2_output = False
test_parse_3_output = False
test_parse_4_output = None
test_parse_5_output = None
test_parse_6_output = None
test_parse_7_output = None
test_parse_8_output = None
test_parse_9_output = None
test_parse_10_output = False
test_parse_11_output = None
test_parse_12_output = False
test_parse_13_output

# Generated at 2022-06-25 16:35:54.502086
# Unit test for function parse
def test_parse():
    # Test for function parse
    assert func_return_0 == parse(param_0, param_1)

    # Test for function parse
    assert func_return_1 == parse(param_2, param_3)

    # Test for function parse
    assert func_return_2 == parse(param_4, param_5)

    # Test for function parse
    assert func_retur

# Generated at 2022-06-25 16:35:55.906521
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 16:35:58.116687
# Unit test for function parse
def test_parse():
    pass


# Main function

# Generated at 2022-06-25 16:36:02.315215
# Unit test for function parse
def test_parse():
    assert callable(parse)
    # Test 1
    str_0 = 'P?o'
    style = Style.auto
    ret_1 = parse(str_0, style)
    assert ret_1.__class__.__name__ == 'Docstring'


# Generated at 2022-06-25 16:36:07.833197
# Unit test for function parse
def test_parse():
    str_0 = "# Hello\nworld\n    \nhelloworld"
    docstring = parse(str_0)
    assert docstring.short_description == "Hello"
    assert docstring.long_description == "world\nhelloworld"
    assert docstring.meta == {}

    str_1 = """Hello world
    pok

    asdf

    Keyword arguments:
    :param str x: The X coordinate
    :param str y: The Y coordinate

    :return: Something
    :rtype: str
    """
    docstring = parse(str_1)
    assert docstring.short_description == "Hello world"
    assert docstring.long_description == "pok\nasdf"
    assert docstring.meta == {}


# Generated at 2022-06-25 16:36:10.285735
# Unit test for function parse
def test_parse():
    # Test 0
    try:
        test_case_0()
    except Exception as e:
        print(e)
    else:
        print('Success!')

test_parse()

# Generated at 2022-06-25 16:36:12.669182
# Unit test for function parse
def test_parse():
    test_case_0()

# main test script
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:25.122089
# Unit test for function parse
def test_parse():
    str_0 = 'T#c@{\x0cIxUsa}pDfA{v+P]~'
    result_0 = 'T#c@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)
    result_0 = docstring_0
    assert result_0 == 'T#c@{\x0cIxUsa}pDfA{v+P]~'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:36:25.954461
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:36:36.225813
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)
    assert docstring_0.long_description.startswith('@{')
    assert docstring_0.long_description.endswith('~')
    assert len(docstring_0.short_description) == 0
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta['IxUsa'] == 'pDfA{v+P]'
    str_1 = '*T'
    docstring_1 = parse(str_1)
    assert len(docstring_1.short_description) == 0
    assert len(docstring_1.long_description) == 0

# Generated at 2022-06-25 16:36:37.520179
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:39.126556
# Unit test for function parse
def test_parse():
    assert func_0(str_0) == docstring_0


# Generated at 2022-06-25 16:36:41.526759
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:36:48.416331
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'DfA{v+P]~'
    assert docstring_0.long_description == 'IxUsa'
    str_1 = '@{\x0cIxUsa}pDfA{v+P]~\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'DfA{v+P]~'
    assert docstring_1.long_description == 'IxUsa'
    str_2 = '\n@{\x0cIxUsa}pDfA{v+P]~'
    docstring

# Generated at 2022-06-25 16:36:55.778068
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0, Style.PEP257)
    assert docstring_0.short_description == '@{\x0cIxUsa}pDfA{v+P]~'
    assert docstring_0.long_description == ''
    assert docstring_0.tags == []

# Generated at 2022-06-25 16:36:57.473644
# Unit test for function parse
def test_parse():
    assert callable(parse)

test_case_0()


# Compiled Python file

# Generated at 2022-06-25 16:37:06.441074
# Unit test for function parse
def test_parse():
    try:
        parse('parse(')
        assert 0
    except ParseError:
        pass
    assert parse('') is None
    assert parse('Hello, world.').short_description == 'Hello, world.'
    assert parse('Hello, world.', Style.google).short_description == 'Hello, world.'
    assert parse('Hello, world.', Style.numpy).short_description == 'Hello, world.'
    assert parse('Hello, world.', Style.rst).short_description is None
    docstring_0 = Docstring(short_description='Hello, world.', long_description=None, extra_sections=[], meta={})
    assert parse('Hello, world.') == docstring_0


# Generated at 2022-06-25 16:37:18.427625
# Unit test for function parse
def test_parse():
    str_0 = '@@@'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert docstring_0.params == {}
    assert docstring_0.returns == None
    assert docstring_0.meta == {}

    str_0 = '@@@\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert docstring_0.params == {}
    assert docstring_0.returns == None
    assert docstring_0.meta == {}

    str_0 = '@'
    docstring_0 = parse(str_0)
    assert docstring_0.short_

# Generated at 2022-06-25 16:37:19.276551
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:37:26.226788
# Unit test for function parse
def test_parse():
    test_docstring_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    test_str_0 = parse(test_docstring_0)
    # @{\x0cIxUsa}pDfA{v+P]~


# Generated at 2022-06-25 16:37:28.751736
# Unit test for function parse
def test_parse():
    str_11 = 'docstring_parser.parse(text: str, style: Style = Style.auto) -> Docstring'
    docstring_11 = parse(str_11)


# Generated at 2022-06-25 16:37:29.988916
# Unit test for function parse
def test_parse():
    # Test func parse
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:37:37.743058
# Unit test for function parse
def test_parse():
    print('Test: function parse... ', end='')
    # test case 0
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)
    assert len(docstring_0.sections) == 4
    assert len(docstring_0.meta) == 4
    assert docstring_0.short_description == '@{\x0cIxUsa}'
    assert docstring_0.long_description == ''
    assert docstring_0.sections[0].heading == 'pDfA'
    assert docstring_0.sections[0].content == 'v+P]~'
    assert docstring_0.sections[1].heading == 'Example'
    assert docstring_0.sections[1].content == ''


# Generated at 2022-06-25 16:37:45.806707
# Unit test for function parse
def test_parse():

    str_0 = '{z:d^$b@/w/'
    str_1 = '}p@G{!n'
    str_2 = 'jC]B=2g'
    str_3 = ']Iz1g'
    str_4 = 'Uy%6$'
    str_5 = '=a[hGw('
    str_6 = '4Xe'
    str_7 = '&5S'
    str_8 = '+^'
    str_9 = '"+j'
    str_10 = '{'
    str_11 = '+7M'
    str_12 = '"hA'
    str_13 = 'a"p'
    str_14 = 'Z7v'
    str_15 = 'A8M'
    str_

# Generated at 2022-06-25 16:37:51.468913
# Unit test for function parse
def test_parse():
    text_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    style_0 = Style.auto
    docstring_0 = parse(text_0, style_0)

test_parse()

# Generated at 2022-06-25 16:37:56.862459
# Unit test for function parse
def test_parse():
    assert callable(parse), "Function 'parse' not defined." 
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == str_0, "Short description not equal to the parsed one." 
    assert docstring_0.long_description == str_0, "Long description not equal to the parsed one." 
    assert docstring_0.meta == str_0, "Metadata not equal to the parsed ones." 


# Generated at 2022-06-25 16:38:01.231181
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    style_0 = Style.reST
    docstring_0 = parse(str_0, style_0)


# Generated at 2022-06-25 16:38:15.849677
# Unit test for function parse
def test_parse():
    styles = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    metas_0 = [0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1]
    metas_1 = [0, 0, 0, 2, 0, 2, 1, 2, 3, 1, 0, 2, 1]
    metas_2 = [3, 0, 1, 1, 2, 1, 1, 0, 1, 1, 2, 0, 1]
    metas_3 = [1, 0, 1, 2, 0, 1, 1, 0, 1, 2, 0, 1, 1]

# Generated at 2022-06-25 16:38:17.212966
# Unit test for function parse
def test_parse():
    test_case_0()

# Main routine
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:38:29.025921
# Unit test for function parse
def test_parse():
    string_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(string_0)

    string_1 = '@{\x0cIxUsa}pDfA{v+P]~\x0c'
    docstring_1 = parse(string_1)

    string_2 = '@{\x0cIxUsa}pDfA{v+P]~\x0c'
    docstring_2 = parse(string_2)

    string_3 = '{\x0cIxUsa}pDfA{v+P]~\x0c'
    docstring_3 = parse(string_3)


# Generated at 2022-06-25 16:38:33.930329
# Unit test for function parse
def test_parse():
    str_0 = "docstring_parser.common, docstring_parser.styles, \
        docstring_parser.utils"
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:38:43.747384
# Unit test for function parse
def test_parse():
    str_1 = '@{\x0cIxUsa}pDfA{v+P]~\n'
    str_2 = '{\x0cIxUsa}pDfA{v+P]~@\n'
    str_3 = '{\x0cIxUsa}pDfA{v+P]~\n'
    str_4 = '@{\x0cIxUsa}pDfA{v+P]~@\n'
    str_5 = '@{\x0cIxUsa}pDfA{v+P]~@\n'
    str_6 = '@{\x0cIxUsa}pDfA{v+P]~@\n'

# Generated at 2022-06-25 16:38:49.762846
# Unit test for function parse
def test_parse():
    # Arguments:
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'

    # Return type:
    # Docstring:
    # Examples:
    assert parse(str_0) == None



# Generated at 2022-06-25 16:38:56.515452
# Unit test for function parse
def test_parse():
    input_str_0 = '    """Multiline docstring\n    for fun\n    """\n    '
    expected_str_0 = 'Multiline docstring\nfor fun\n'
    expected_str_0_summary = 'Multiline docstring\n'
    assert parse(input_str_0).summary == expected_str_0_summary
    assert parse(input_str_0).description == expected_str_0
    assert parse(input_str_0).return_type is None
    assert len(parse(input_str_0).params) == 0
    assert len(parse(input_str_0).raises) == 0
    assert len(parse(input_str_0).meta) == 0
    input_str_1 = '"""One line docstring"""\n'
    expected_str_1

# Generated at 2022-06-25 16:38:57.472410
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:39:02.117648
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    expected_0 = None
    docstring_0 = parse(str_0)
    assert(expected_0 == docstring_0)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:39:06.788788
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    # style: auto
    docstring_0 = parse(str_0)
    assert 'brief' not in docstring_0.meta
    assert 'name' not in docstring_0.meta

# Check that an empty docstring can be parsed

# Generated at 2022-06-25 16:39:13.452548
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:39:24.427848
# Unit test for function parse
def test_parse():
    """Test parse function."""
    # Make sure to test the following:
    # - invalid input
    # - expected output
    # - invalid style
    # - all styles
    # - empty docstring
    # - required=False fields, default values
    # - inheritance
    # - unicode
    # - ignore blank lines
    # - empty docstring

    # test cases

# Generated at 2022-06-25 16:39:31.068407
# Unit test for function parse
def test_parse():
    str_0 = '"pINT*y9"+HB)T}!c%VJYFZb[u<7'
    str_1 = '"C^`9XD'
    str_2 = '!t,s[QZ/Hvo<&:o*OB'
    assert len(parse(str_0)) == len(str_0)
    assert len(parse(str_1)) == len(str_1)
    assert len(parse(str_2)) == len(str_2)

# Generated at 2022-06-25 16:39:35.533184
# Unit test for function parse
def test_parse():
    assert callable(parse)

# unit tests for module
if __name__ == '__main__':
    import sys
    for func in dir(sys.modules[__name__]):
        if func[0:5] == "test_":
            print("Running unit test for function  %s" % func)
            globals()[func]()
            print("*****   Unit test for function %s OK   *****" % func)

# Generated at 2022-06-25 16:39:37.548751
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generate unit test files

# Generated at 2022-06-25 16:39:48.021448
# Unit test for function parse
def test_parse():
    d = """    :some_tag: value

    This is a long description.
    It should include all the necessary information about the function,
    like parameters, return value and exceptions.

    :returns: description of the return value
    :raises Exception: description of the exception

    """
    doc = parse(d)
    assert doc.short_description == ""
    assert doc.long_description == "This is a long description.\nIt should include all the necessary " \
                                   "information about the function,\nlike parameters, return value and " \
                                   "exceptions."
    assert len(doc.tags) == 2
    assert doc.tags[0].tag_name == "returns"
    assert doc.tags[0].tag_type == "returns"

# Generated at 2022-06-25 16:39:49.049627
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:39:50.209872
# Unit test for function parse
def test_parse():
    test_case_0()

# Compiled version of test_parse

# Generated at 2022-06-25 16:39:58.339977
# Unit test for function parse
def test_parse():
    # *****Test case 0*****
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'

    docstring_0 = parse(str_0)
    assert docstring_0.meta['\x0cIxUsa'] == 'pDfA{v+P]~'

    # *****Test case 1*****
    str_1 = '@\x0cVuZjt"W]`u{'

    docstring_1 = parse(str_1)
    assert docstring_1.meta['\x0cVuZjt"W]`u{'] == ''

    # *****Test case 2*****
    str_2 = '@\x0bw'

    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:40:03.481231
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == '@{\x0cIxUsa}pDfA{v+P]~'
    print('docstring_parser.parse Success')


# Generated at 2022-06-25 16:40:12.286284
# Unit test for function parse
def test_parse():
    str_0 = '<p>The main parsing routine.</p>'
    docstring_0 = parse(str_0)
    str_1 = '<p>The main parsing routine.</p>'
    docstring_1 = parse(str_1, Style.google)


# Generated at 2022-06-25 16:40:18.657153
# Unit test for function parse
def test_parse():
    str_0 = '\n        \n\n        @{\x0cIxUsa}pDfA{v+P]~\n      '
    docstring_0 = parse(str_0)
    str_1 = '  \n          \n\n            R$4P4<d@\n            \n\n          \n      '
    docstring_1 = parse(str_1)
    assert docstring_0 == docstring_1


# Generated at 2022-06-25 16:40:24.127930
# Unit test for function parse
def test_parse():
    text_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    style_0 = Style.auto
    docstring_0 = parse(text_0, style_0)


# Generated at 2022-06-25 16:40:26.350903
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    test_case_0()
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:40:28.218571
# Unit test for function parse
def test_parse():
    assert callable(parse)

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:28.936207
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:40:32.766487
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 16:40:42.728228
# Unit test for function parse
def test_parse():
    text_0 = '''
        """A docstring.

        A second paragraph.

        :param foo: this is foo
        :type foo: str
        :param bar: this is bar
        :type bar: str
        :rtype: str
        :raises Exception: raises an exception
        """'''
    docstring_0 = parse(text_0)

# Generated at 2022-06-25 16:40:44.616409
# Unit test for function parse
def test_parse():
  test_case_0()

if __name__ == '__main__':
  test_parse()

# Generated at 2022-06-25 16:40:55.722799
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    str_1 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_1 = parse(str_1)
    str_2 = 'WdV8BUv+P]~'
    docstring_2 = parse(str_2)
    str_3 = 'wCj%*JGA'
    docstring_3 = parse(str_3)
    str_4 = '+P]~'
    docstring_4 = parse(str_4)
    str_5 = 'jh>v+P]~'
    docstring_5 = parse(str_5)
    str_6 = 'y)x0}A{(]{'
    docstring_6 = parse

# Generated at 2022-06-25 16:41:10.485408
# Unit test for function parse
def test_parse():
    str_0 = '"""This is a short description.\n\nThis is a longer description.\n\nArgs:\n    arg1 (bool): This is arg1\n    arg2 (list of str): This is arg2\n\nReturns:\n    int: This is a return value.\n"""'
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    str_1 = '"""This is a short description.\n\nThis is a longer description.\n\n:param arg1: This is arg1\n:type arg1: bool\n:param arg2: This is arg2\n:type arg2: list of str\n:returns: This is a return value.\n:rtype: int\n"""'
    style_1 = Style.sph

# Generated at 2022-06-25 16:41:20.808029
# Unit test for function parse
def test_parse():

    # Initialize variables
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    str_1 = '4'
    str_2 = '"b@c+\\"\\\'d}'
    str_3 = 'C'
    str_4 = '\\\n'
    str_5 = '\'\\\n'
    str_6 = '"\\\n'
    str_7 = '\n<D>\n'
    str_8 = '{}\n'
    str_9 = 'F"M"y!\r'
    str_10 = '\rQ\r'
    str_11 = '\n\r'
    str_12 = '\r\n\r'

# Generated at 2022-06-25 16:41:27.665741
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)

    assert docstring_0.summary == '@{\x0cIxUsa}pDfA{v+P]~'
    assert docstring_0.parameters == ['@{\x0cIxUsa}pDfA{v+P]~']

#nose.tools.assert_equal(expected, parse(text, style))
    #assert expected == parse(text, style)

# Generated at 2022-06-25 16:41:33.374425
# Unit test for function parse
def test_parse():
    print('Testing function: parse')
    # Testing for Test Case #0
    test_case_0()

if __name__=='__main__':
    print('Executing Test Suite: docstring-parser.docstring-parser')
    test_parse()

# Generated at 2022-06-25 16:41:36.590662
# Unit test for function parse
def test_parse():
    # Test the result
    str_0 = 'This is a test'
    str_1 = 'This is another test'
    str_2 = 'This is the third test'
    # Test if the result satisfies certain criteria
    assert str_0 == str_0
    assert str_1 != str_2


# Generated at 2022-06-25 16:41:47.079936
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)
    str_1 = 'a'
    docstring_1 = parse(str_1)
    str_2 = 'Sd\t@\x1f'
    docstring_2 = parse(str_2)
    str_3 = '1\x0c_!D][{'
    docstring_3 = parse(str_3)
    str_4 = 'v'
    docstring_4 = parse(str_4)
    str_5 = 'ZhR+@'
    docstring_5 = parse(str_5)
    str_6 = 'VY*'
    docstring_6 = parse(str_6)
    str_

# Generated at 2022-06-25 16:41:48.226825
# Unit test for function parse
def test_parse():
    assert False == False, 'Expected True but got False'

test_case_0()

# Generated at 2022-06-25 16:41:56.634583
# Unit test for function parse
def test_parse():
    # str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    # docstring_0 = parse(str_0)
    assert callable(parse)

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:41:59.500276
# Unit test for function parse
def test_parse():
    # Positive test cases (examples) with interesting inputs
    # Negative test cases (counterexamples) with interesting inputs
    assert True # TODO: implement your test cases here


# Generated at 2022-06-25 16:42:08.044480
# Unit test for function parse
def test_parse():
    assert("\u0014" in parse("var = 1"))
    assert("\u0001" in parse("var = 1"))
    assert("\u0010" in parse("var = 1"))
    assert("\u0005" in parse("var = 1"))
    assert("\u0013" in parse("var = 1"))
    assert("\u0014" in parse("var = 1"))
    assert("\u0001" in parse("var = 1"))
    assert("\u0010" in parse("var = 1"))
    assert("\u0003" in parse("var = 1"))
    assert("\u0000" in parse("var = 1"))
    assert("\u0013" in parse("var = 1"))
    assert("\u000c" in parse("var = 1"))

# Generated at 2022-06-25 16:42:13.301026
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:14.471138
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:26.107376
# Unit test for function parse
def test_parse():
    print('TESTING FOR FUNCTION parse')
    
    # Testing if arg (type docstring_parser.common.Docstring) == ret
    
    # Testing 1
    assert parse('Hi, this is a test') == parse('Hi, this is a test'), 'Test 1 failed'
    print('Test 1 passed')
    
    # Testing if arg (type docstring_parser.styles.Style) == ret
    
    # Testing 2
    assert parse('Hi, this is a test', style=Style.reST) != parse('Hi, this is a test', style=Style.auto), 'Test 2 failed'
    print('Test 2 passed')
    
    # Testing if arg (type str) == ret
    
    # Testing 3

# Generated at 2022-06-25 16:42:32.851536
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)
    assert not hasattr(docstring_0.summary, '__len__')
    assert docstring_0.summary == 'This function does something useful.'
    assert 'Parameters' in docstring_0.meta


if __name__ == '__main__':
    for i in range(10000000):
        test_case_0()
    print('done')

# Generated at 2022-06-25 16:42:34.149701
# Unit test for function parse
def test_parse():
    test_case_0()

# Unit test case generator

# Generated at 2022-06-25 16:42:38.423494
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except ParseError:
        pass

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:42:39.393016
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:41.528736
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:42:48.335749
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)

    str_1 = '$'
    docstring_1 = parse(str_1)

    str_2 = '$'
    docstring_2 = parse(str_2)

    str_3 = 'kZg`}p'
    docstring_3 = parse(str_3)

    str_4 = '4e'
    docstring_4 = parse(str_4)

    str_5 = '$'
    docstring_5 = parse(str_5)

    str_6 = '%'
    docstring_6 = parse(str_6)

    str_7 = '%'

# Generated at 2022-06-25 16:42:49.809642
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:43:04.040621
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    # test_case_0
    assert parse('"@{\x0cIxUsa}pDfA{v+P]~"', Style.google) is parse(str_0, Style.google)
    # test_case_1
    assert parse('"@{\x0cIxUsa}pDfA{v+P]~"', Style.numpy) is parse(str_0, Style.numpy)
    # test_case_2
    assert parse('"@{\x0cIxUsa}pDfA{v+P]~"', Style.sphinx) is parse(str_0, Style.sphinx)

# Generated at 2022-06-25 16:43:04.897076
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:43:11.543785
# Unit test for function parse
def test_parse():
    str_0 = 'test string'
    style_0 = Style.numpy
    docstring_0 = parse(str_0, style_0)
    #assert docstring_0.summary == 'test string'
    str_1 = 'test string'
    style_1 = Style.sphinx
    docstring_1 = parse(str_1, style_1)
    #assert docstring_1.metadata == {'description': 'test string'}


# Generated at 2022-06-25 16:43:23.359380
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == '@{\x0cIxUsa}pDfA{v+P]~'
    assert docstring_0.long_description == None
    assert len(docstring_0.params) == 0
    assert len(docstring_0.returns) == 0
    assert len(docstring_0.exceptions) == 0
    assert docstring_0.yields == None
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta[0]['name'] == 'versionadded'
    assert docstring_0.meta[0]['value'] == '2.12'

# Generated at 2022-06-25 16:43:26.478615
# Unit test for function parse
def test_parse():
    str_0 = '@{\x0cIxUsa}pDfA{v+P]~'
    docstring_0 = parse(str_0)