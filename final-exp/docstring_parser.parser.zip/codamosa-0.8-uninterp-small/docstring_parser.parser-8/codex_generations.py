

# Generated at 2022-06-25 16:33:40.178130
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 16:33:40.959178
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:33:51.777634
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == 'Note'
    assert docstring_0.long_description == None
    assert docstring_0.tags == {}
    assert docstring_0.meta == {}
    assert len(docstring_0.tags) == 0
    assert len(docstring_0.meta) == 0
    str_1 = 'Note\n    '
    docstring_1 = parse(str_1)

    assert docstring_1.short_description == 'Note'
    assert docstring_1.long_description == None
    assert docstring_1.tags == {}
    assert docstring_1.meta == {}
    assert len(docstring_1.tags) == 0

# Generated at 2022-06-25 16:33:59.011952
# Unit test for function parse
def test_parse():
    text_0 = 'Example:\n\n  >>> hello()\n  42\n  >>> foo()\n'
    ret_0 = parse(text_0)

    text_1 = 'Example:\n\n  >>> hello()\n  42\n  >>> foo()\n'
    style_1 = Style.google
    ret_1 = parse(text_1, style_1)

    text_2 = 'Example:\n\n  >>> hello()\n  42\n  >>> foo()\n'
    style_2 = Style.numpy
    ret_2 = parse(text_2, style_2)

    return ret_0, ret_1, ret_2


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:34:01.938453
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    assert parse(str_0) != None

# Generated at 2022-06-25 16:34:07.901800
# Unit test for function parse
def test_parse():
    text = """This function does something.

It takes two arguments:
arg1: A string
arg2: A string

And it returns:
rtype: A string

And an optional return description

And it has a long description and an optional description

And it has a long description and an optional description. This is a test with a `backtick`"""
    print(parse(text))

# Generated at 2022-06-25 16:34:16.256316
# Unit test for function parse
def test_parse():
    str_0 = '检查效验码是否正确。'
    docstring_0 = parse(str_0)
    str_1 = str_0 + '\n\n：param bar: 效验码\n'
    docstring_1 = parse(str_1)
    print(docstring_1)
    str_2 = str_1 + '\n:returns: 结果\n'
    docstring_2 = parse(str_2)
    print(docstring_2)
    str_3 = str_2 + '\n:raises ValueError: 输入值小于0\n'
    docstring_3 = parse(str_3)

# Generated at 2022-06-25 16:34:17.235565
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:34:20.788983
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:34:22.931870
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None


# Generated at 2022-06-25 16:34:27.984393
# Unit test for function parse
def test_parse():
    assert callable(parse)
    test_case_0()

# Generated at 2022-06-25 16:34:30.601743
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main(['-q', __file__])

# Generated at 2022-06-25 16:34:40.815259
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    assert len(docstring_0.short_description) == 0
    assert docstring_0.long_description == ''
    assert docstring_0.style == 'numpy'
    assert docstring_0.meta == {}
    assert len(docstring_0.params) == 0
    assert docstring_0.returns is None
    assert len(docstring_0.raises) == 0
    assert len(docstring_0.see_also) == 0
    assert docstring_0.notes == str_0
    assert docstring_0.references == ''
    assert len(docstring_0.examples) == 0
    assert len(docstring_0.attributes) == 0

# Generated at 2022-06-25 16:34:41.656551
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:34:47.110213
# Unit test for function parse
def test_parse():
    input_str = '-- Unit test for function parse'
    text = parse(input_str)
    assert text.description == 'Unit test for function parse'
    print('test_parse passed!')


# Generated at 2022-06-25 16:34:48.195799
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:34:55.790132
# Unit test for function parse
def test_parse():

    # Test for style='Style.auto'
    str_0 = '"""This is a module docstring."""'
    docstring_0 = parse(str_0)
    docstring_1 = Docstring(
        content='This is a module docstring.\n',
        style=Style.google,
    )

    # Test for style='Style.google'
    str_1 = '"""This is a module docstring.\n"""\n'
    docstring_2 = parse(str_1, style=Style.google)
    docstring_3 = Docstring(
        content='This is a module docstring.\n',
        style=Style.google,
    )

    # Test for style='Style.google'
    str_2 = '"""This is a module docstring.\nwith extra lines.\n"""\n'

# Generated at 2022-06-25 16:35:07.583685
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle
    # default style is numpy
    assert parse('Note').__class__ == NumpyStyle
    # Available style
    assert parse('Note', Style.google).__class__ == NumpyStyle
    assert parse('Note', Style.numpy).__class__ == NumpyStyle
    assert parse('Note', Style.rtd).__class__ == NumpyStyle
    assert parse('Note', Style.auto).__class__ == NumpyStyle
    # Style not available
    try:
        parse('Note', Style.reStructuredText)
    except NotImplementedError:
        pass
    else:
        raise Exception('has no reStructuredText style')

# Generated at 2022-06-25 16:35:09.582447
# Unit test for function parse
def test_parse():
    parse_0 = parse()
    parse_1 = parse()
    assert parse_0 != parse_1


if __name__ == '__main__':
    test_case_0()
    test_parse()


__all__ = ['parse']

# Generated at 2022-06-25 16:35:17.146080
# Unit test for function parse

# Generated at 2022-06-25 16:35:33.971998
# Unit test for function parse
def test_parse():
    str_0 = ''
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)

    str_1 = ''
    style_1 = Style.numpy
    docstring_1 = parse(str_1, style_1)

    str_2 = ''
    style_2 = Style.restructuredtext
    docstring_2 = parse(str_2, style_2)

    str_3 = ''
    style_3 = Style.sphinx
    docstring_3 = parse(str_3, style_3)

    str_4 = ''
    style_4 = Style.auto
    docstring_4 = parse(str_4, style_4)


# Generated at 2022-06-25 16:35:39.321657
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    assert docstring_0.__eq__('')
    str_1 = 'Note'
    style_1 = Style.numpy
    docstring_1 = parse(str_1, style_1)
    assert docstring_1.__eq__('')


# Generated at 2022-06-25 16:35:47.900484
# Unit test for function parse
def test_parse():
    t_0 = 'Note'
    docstr_0 = parse(t_0)
    assert docstr_0.short_description == 'Note'

    t_1 = 'some short description\nsome longer description'
    docstr_1 = parse(t_1)
    assert docstr_1.short_description == 'some short description'
    assert docstr_1.long_description == 'some longer description'

    t_2 = 'some short description\nsome longer description\n\nsome param'
    docstr_2 = parse(t_2)
    assert docstr_2.short_description == 'some short description'
    assert docstr_2.long_description == 'some longer description'
    assert docstr_2.meta['some param'] == []


# Generated at 2022-06-25 16:35:59.195093
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstr_0 = parse(str_0)

    str_1 = '''
    Hi!
    '''
    docstr_1 = parse(str_1)

    str_2 = '''
    Hi!
        '''
    docstr_2 = parse(str_2)

    str_3 = '''
    Hi!
    '''
    docstr_3 = parse(str_3)

    str_4 = '''
    Hi!

    '''
    docstr_4 = parse(str_4)

    str_5 = '''
    Hi!
    '''
    docstr_5 = parse(str_5)

    str_6 = 'Hi!'
    docstr_6 = parse(str_6)


# Generated at 2022-06-25 16:36:03.065307
# Unit test for function parse
def test_parse():
    str_0 = 'Another example'
    str_1 = 'Another example'
    ret_2 = parse(str_0, Style.auto)
    docstring_2 = parse(str_1)
    ret_3 = str(docstring_2)
    assert ret_3 == str_0

# Generated at 2022-06-25 16:36:04.165791
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:15.986141
# Unit test for function parse
def test_parse():
    # test case 1
    text_1 = 'This module provides utilities for mapping strings to\ntypes.  The basic purpose is to provide a single point of\nentry for defining new-style string-based object\nspecifications.\n'

# Generated at 2022-06-25 16:36:26.947802
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)

    assert docstring_0.summary == 'Note'
    assert docstring_0.description == ''
    assert docstring_0.meta == {}
    assert docstring_0.returns == None
    assert docstring_0.return_type == None
    assert docstring_0.exceptions == []
    assert docstring_0.examples == []
    assert docstring_0.see_also == []
    assert docstring_0.yields == None
    assert docstring_0.yield_type == None
    assert docstring_0.yield_description == None
    assert docstring_0.todos == []

    str_1 = ''
    docstring_1 = parse(str_1)

    assert docstring_1

# Generated at 2022-06-25 16:36:28.706505
# Unit test for function parse
def test_parse():
    docstring_0 = parse('Note',1)

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:36:34.632747
# Unit test for function parse
def test_parse():
    strs = ['Note', 'Note\n', 'Note\n\n', 'Note\n\n    ']
    for str_ in strs:
        docstring = parse(str_)

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:36:47.954576
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    assert docstring_0 ==  Docstring(
                                                     summary='',
                                                     body='Note',
                                                     meta={}
                                                     )

# Generated at 2022-06-25 16:36:53.333697
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    assert parse(str_0) == Docstring(content={'Note': 'None'}, style='google', meta={})

    str_1 = '''Single line docstring'''
    assert parse(str_1) == Docstring(content={'Single line docstring': 'None'}, style='google', meta={})

    str_2 = '''
    This is a multiline docstring.
    '''
    assert parse(str_2) == Docstring(content={'This is a multiline docstring.': 'None'}, style='google', meta={})

    str_3 = '''
    This is a multiline docstring.

    Args:
      arg_0: The first argument.
    '''

# Generated at 2022-06-25 16:36:57.804853
# Unit test for function parse
def test_parse():
    # Do not touch this line. This is a test.
    assert test_case_0(), 'test_case_0'
    print('All tests passed!')
    
test_parse()

'''
if __name__ == '__main__':
    for line in sys.stdin:
        print(repr(parse(line.strip())))
'''

# Generated at 2022-06-25 16:37:07.470730
# Unit test for function parse
def test_parse():
    text_0 = '@custom.decorator'
    style_0 = Style.pep257
    docstring_0 = parse(text_0, style_0)
    assert docstring_0.meta == ['@custom.decorator']
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert docstring_0.return_annotation == ''
    assert docstring_0.param_types == {}
    assert docstring_0.raises == {}
    assert docstring_0.see_also == []

    text_1 = 'This is a short description.'
    style_1 = Style.pep257
    docstring_1 = parse(text_1, style_1)
    assert docstring_1.meta == []
    assert docstring_1.short_

# Generated at 2022-06-25 16:37:10.774322
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 16:37:18.570150
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    assert docstring_0.title == 'Note'
    str_1 = 'Note\n    Note'
    docstring_1 = parse(str_1)
    assert docstring_1.title == 'Note'
    assert docstring_1.summary == 'Note'
    str_2 = 'Note\n\nNote'
    docstring_2 = parse(str_2)
    assert docstring_2.title == 'Note'
    assert docstring_2.summary == 'Note'
    str_3 = 'Note\n\n\nNote'
    docstring_3 = parse(str_3)
    assert docstring_3.title == 'Note'

# Generated at 2022-06-25 16:37:23.472119
# Unit test for function parse

# Generated at 2022-06-25 16:37:33.834759
# Unit test for function parse
def test_parse():
    """
    Test parse function.
    """
    str_0 = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation

    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse the docstring into its components.'

    # Test for non-existent style
    style_1 = 'java'
    try:
        docstring_1 = parse(str_0, style_1)
    except ParseError as e:
        pass
    else:
        raise AssertionError("The input docstring style type should not exist")

    # Test for invalid docstring
    str_1 = ''
    style_0 = 'google'

# Generated at 2022-06-25 16:37:41.545395
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    str_1 = 'Name: Numpy_Docstring_Parser\nDescription: A Python docstring parser.\nVersion: 0.1.2\nSummary: a python docstring parser coded in Python.\nHome-page:\nhttps://github.com/numpy/numpy/blob/master/doc/source/reference/generated/numpy.docstring_parser.parse.rst.html\nAuthor: None\nAuthor-email: None\nLicense: BSD\nLocation: /usr/local/lib/python3.6/dist-packages\nRequires: numpy\nRequired-by: '
    docstring_1 = parse(str_1)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 16:37:51.865458
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    assert(docstring_0.style == Style.numpy)
    assert(docstring_0.summary == '')
    assert(docstring_0.extended_summary == '')
    assert(docstring_0.extended_summary_sections == ())
    assert(docstring_0.body == '')
    assert(docstring_0.body_sections == ())
    assert(docstring_0.meta == ())
    assert(docstring_0.returns == None)
    assert(docstring_0.returns_section == None)
    assert(docstring_0.yields == None)
    assert(docstring_0.yields_section == None)
    assert(docstring_0.raises == None)


# Generated at 2022-06-25 16:38:02.473001
# Unit test for function parse
def test_parse():
    str_0 = '''\
This is a test for the parse function.
'''
    assert parse(str_0) == None

# Test case for function parse

# Generated at 2022-06-25 16:38:15.063512
# Unit test for function parse
def test_parse():
    str_0 = 'Compute the cross product of two vectors.\n\nParameters\n----------\na : array_like\n    Input vector.\nb : array_like\n    Input vector.\nReturns\n-------\nc : ndarray\n    The cross product of the inputs.\nExamples\n--------\n>>> x = np.array([1, 2, 3])\n>>> y = np.array([4, 5, 6])\n>>> np.cross(x, y)\narray([-3,  6, -3])\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Compute the cross product of two vectors.'
    assert docstring_0.long_description == 'Compute the cross product of two vectors.\n\n'
    assert docstring_

# Generated at 2022-06-25 16:38:16.170497
# Unit test for function parse
def test_parse():
    text = '''
    Sample:
    '''
    assert parse(text)

# Generated at 2022-06-25 16:38:16.930147
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:38:28.989183
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.brief == ''
    assert docstring_0.long_description == ''
    assert docstring_0.meta == ''
    assert docstring_0.params == {}
    assert docstring_0.style == 'google'
    assert docstring_0.returns == None
    assert docstring_0.raises == {}
    
    str_1 = 'Memo:  The parameter *p* is a vector '
    docstring_1 = parse(str_1)
    assert docstring_1.brief == ''
    assert docstring_1.long_description == ''
    assert docstring_1.meta == ''
    assert docstring_1.params == {}
    assert docstring_1.style == 'google'


# Generated at 2022-06-25 16:38:34.287034
# Unit test for function parse
def test_parse():
    text_0 = 'This is a module-level docstring.'
    result = parse(text_0)
    assert result.full_docstring_text == text_0
    assert result.summary_text == 'This is a module-level docstring.'


# Generated at 2022-06-25 16:38:42.257908
# Unit test for function parse
def test_parse():
    text_0 = 'This function is a simple demo function'
    assert parse(text_0) == Docstring(text_0, None)
    text_1 = 'This function is a simple demo function\n\nArgs:\n  a: any type\n  b: any type'
    assert parse(text_1) == Docstring(text_1, [('a', None, None), ('b', None, None)])
    text_2 = 'This function is a simple demo function\n\nArgs:\n  a: any type\n  b: any type\n\nReturns: int'
    assert parse(text_2) == Docstring(text_2, [('a', None, None), ('b', None, None)], 'int')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:38:44.569702
# Unit test for function parse
def test_parse():
    assert parse('Note') == 'Note'



# Generated at 2022-06-25 16:38:55.131411
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the docstring into its components.'
    str_1 = '''Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    str_2 = '''Parse the docstring into its components.
    
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    str_3 = '''Parse the docstring into its components.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    str_4 = 'Note'

# Generated at 2022-06-25 16:38:56.410418
# Unit test for function parse
def test_parse():
    assert parse('Note')
    assert parse('Note:')

# Generated at 2022-06-25 16:39:04.705342
# Unit test for function parse
def test_parse():
    docstring_0 = parse("Note")
    docstring_1 = parse("Note")


# Generated at 2022-06-25 16:39:13.705921
# Unit test for function parse
def test_parse():
    assert parse("This is doc") == 'This is doc' 
    assert parse("This is ") == 'This is ' 
    assert parse("This is doc") == 'This is doc' 
    assert parse("This is ") == 'This is ' 
    assert parse("This is doc") == 'This is doc' 
    assert parse("This is ") == 'This is ' 
    assert parse("This is doc") == 'This is doc' 
    assert parse("This is ") == 'This is ' 
    assert parse("This is doc") == 'This is doc' 
    assert parse("This is ") == 'This is ' 
    assert parse("This is doc") == 'This is doc' 
    assert parse("This is ") == 'This is ' 

# Generated at 2022-06-25 16:39:22.619490
# Unit test for function parse
def test_parse():
    str1 = 'Hello World'
    docstring1 = parse(str1)
    assert docstring1.text == str1

    str2 = 'Hello World\n\n'
    docstring2 = parse(str2)
    assert docstring2.text == str2

    str3 = 'Hello World\n\n'
    docstring3 = parse(str3)
    assert docstring3.text == str3

    str4 = 'Hello World'
    docstring4 = parse(str4)
    assert docstring4.text == str4

    str5 = 'Hello World'
    docstring5 = parse(str5)
    assert docstring5.text == str5


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:39:32.202897
# Unit test for function parse
def test_parse():
    print("Testing parse...", end="")
    docstring_0 = parse("Note", Style.none)
    assert(docstring_0.short_description == None)
    assert(docstring_0.long_description == None)
    assert(docstring_0.meta == {})
    docstring_1 = parse("Note.", Style.none)
    assert(docstring_1.short_description == "Note.")
    assert(docstring_1.long_description == None)
    assert(docstring_1.meta == {})
    docstring_2 = parse("""
        Note.

        This is a long description.
        """, Style.none)
    assert(docstring_2.short_description == "Note.")
    assert(docstring_2.long_description == "This is a long description.")

# Generated at 2022-06-25 16:39:38.672980
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Note'
    assert docstring_0.long_description is None
    assert docstring_0.params == []
    assert docstring_0.returns is None
    assert docstring_0.yields is None
    assert docstring_0.raises is None
    assert docstring_0.meta == {}
    str_1 = 'Note\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Note'
    assert docstring_1.long_description is None
    assert docstring_1.params == []
    assert docstring_1.returns is None
    assert docstring_1.yields is None

# Generated at 2022-06-25 16:39:41.295879
# Unit test for function parse
def test_parse():
    # Assign the argument to a local variable:
    text = 'Note'

    style = Style.auto


    # Call the function:
    raise NotImplementedError()

    # Check the result:
    assert result == expected_result

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:39:51.261472
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    str_1 = ''
    docstring_1 = parse(str_1)
    str_2 = 'Note\n\nParameters\n----------\na : int\nb : int\n\nReturns\n-------\nc : int\nsum of a and b'
    docstring_2 = parse(str_2)
    str_3 = 'Note\n\nParameters\n----------\na : int\nb : int\n\nReturns\n-------\nc : int\nsum of a and b\n\n'
    docstring_3 = parse(str_3)

# Generated at 2022-06-25 16:39:52.628863
# Unit test for function parse
def test_parse():
    # assert parse(str_0) == docstring_0
    pass

# Generated at 2022-06-25 16:40:00.865768
# Unit test for function parse
def test_parse():
    # Code to test parse
    text = 'This is a docstring.'
    docstring = parse(text)
    assert (docstring) == text
    text = '''This is a docstring.
    This is a docstring.
    This is a docstring.
    This is a docstring.
    This is a docstring.
    This is a docstring.
    '''
    docstring = parse(text)
    assert (docstring) == text
    text = ''
    docstring = parse(text)
    assert (docstring) == text


# Generated at 2022-06-25 16:40:13.325021
# Unit test for function parse
def test_parse():
    str_0 = 'Note: This is a note.'
    docstring_0 = parse(str_0)
    assert docstring_0.note == 'This is a note.'
    str_1 = 'Note: This is a note.\n\nAuthor: John Smith\nDate: 1/1/2014\n'
    docstring_1 = parse(str_1)
    assert docstring_1.note == 'This is a note.'
    assert docstring_1.author == 'John Smith'
    assert docstring_1.date == '1/1/2014'
    str_2 = 'Note: This is a note.\n\nAuthor: John Smith\n\nDate: 1/1/2014\n'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:40:28.012942
# Unit test for function parse
def test_parse():
    try:
        str_list = list()
        str_list.append('Note')
        str_list.append('Page')
        str_list.append('Title')
        for str_ in str_list:
            docstring = parse(str_)
        print('Function parse success')
    except:
        print('Function parse fail')

if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:29.533131
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 'Note'

# Generated at 2022-06-25 16:40:33.448170
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:40:44.499744
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    str_1 = 'Note\n'
    docstring_1 = parse(str_1)
    str_2 = '"Note"\n'
    docstring_2 = parse(str_2)
    str_3 = """\"\"\"Note\"\"\"\n"""
    docstring_3 = parse(str_3)
    str_4 = """\'\'\'Note\'\'\'\n"""
    docstring_4 = parse(str_4)
    str_5 = """\'\'\'\nNote\'\'\'\n"""
    docstring_5 = parse(str_5)
    str_6 = """\'\'\'Note\n\'\'\'\n"""
    docstring_6 = parse(str_6)
    str_

# Generated at 2022-06-25 16:40:54.531488
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(description='', content='', meta='')
    
    assert parse(""""
    The first line should be a short, concise summary of the object's purpose.
    This line should begin with a capital letter and end with a period.

    Multiple paragraphs are supported.
    """) == Docstring(description='The first line should be a short, concise summary of the object\'s purpose. This line should begin with a capital letter and end with a period. Multiple paragraphs are supported.',
    content='\n',
    meta='')
    
    assert parse("""
    Parameters:
        param1 (int): The first parameter.
        param2 (str): The second parameter.
    """) == Docstring(description='',
    content='\n',
    meta='')
    

# Generated at 2022-06-25 16:41:04.723601
# Unit test for function parse
def test_parse():

    str_0 = 'Note'
    docstring_0 = parse(str_0)

    assert docstring_0.field('Note') == 'Note'


    str_1 = '''Note

Args:
    arg1: argument 1
    arg2: argument 2'''
    docstring_1 = parse(str_1)

    assert docstring_1.field('Note') == 'Note'
    assert docstring_1.field('arg1') == 'argument 1'
    assert docstring_1.field('arg2') == 'argument 2'


    str_2 = '''Note

:Param arg1: argument 1
:Param arg2: argument 2'''
    docstring_2 = parse(str_2)

    assert docstring_2.field('Note') == 'Note'
    assert docstring_2.field

# Generated at 2022-06-25 16:41:05.810667
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-25 16:41:08.624258
# Unit test for function parse
def test_parse():
    res = parse('Note')
    assert res.summary == 'Note'


# Generated at 2022-06-25 16:41:13.661602
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    docstring_0 = parse(str_0)

# Running module as script
if __name__ == "__main__":
    module_name = os.path.basename(__file__)
    module_base = os.path.splitext(module_name)[0]
    test_num = 0
    #test_case_0()
    test_case_0()
    test_parse()
    print('{0} passed all the tests...'.format(module_name))

# Generated at 2022-06-25 16:41:15.348816
# Unit test for function parse
def test_parse():
    print("Testing function parse ...")
    test_case_0()
    print("Passed!")

# Test all

# Generated at 2022-06-25 16:41:30.145202
# Unit test for function parse
def test_parse():
    text_0 = """
Return the absolute value of the argument.

When the argument is a complex number, its magnitude is returned.
When the argument is an array, a new NumPy array is returned with the absolute values.

The return value is a scalar if and only if *val* is a scalar.

The absolute value is also known as the modulus or magnitude.

Parameters
----------
val : scalar or array_like
    Input value.

Returns
-------
res : array_like
    Absolute value of `val`.
"""
    docstring_0 = parse(text_0)

# Generated at 2022-06-25 16:41:35.635683
# Unit test for function parse
def test_parse():
    text = '''\
    LightGBM is a fast, distributed, high performance gradient boosting
    framework based on decision tree algorithms.
    '''

    doc = parse(text)
    assert doc.short_description == 'LightGBM is a fast, distributed, high performance gradient boosting'
    assert doc.long_description == 'framework based on decision tree algorithms.'

# Generated at 2022-06-25 16:41:45.980614
# Unit test for function parse

# Generated at 2022-06-25 16:41:52.733233
# Unit test for function parse

# Generated at 2022-06-25 16:41:54.172227
# Unit test for function parse
def test_parse():
    assert not callable(parse)


# Generated at 2022-06-25 16:41:58.750115
# Unit test for function parse
def test_parse():
    style = Style.auto
    text = 'Usage: This is used for testing pyparser.\n\nAuthor:\n'
    result = parse(text, style)
    assert result.summary == 'Usage: This is used for testing pyparser.'
    assert result.meta['Author'] == ''

# Generated at 2022-06-25 16:42:07.858951
# Unit test for function parse

# Generated at 2022-06-25 16:42:14.720102
# Unit test for function parse
def test_parse():
    with open('docstring_parser/tests/docstring.txt') as f:
        docstring = f.read()
    parsed_string = parse(docstring)
    assert isinstance(parsed_string, Docstring)
    assert parsed_string.short_description == "This is a short description."
    assert parsed_string.long_description == ("This is a very long description. It can span across several lines"
                                              "and can occur after an empty line or not.")
    assert parsed_string.params[0]['type'] == 'str'
    assert parsed_string.params[0]['desc'] == 'This is the first parameter.'
    assert parsed_string.params[1]['type'] == 'int'
    assert parsed_string.params[1]['desc'] == 'This is the second parameter.'
    assert parsed_string

# Generated at 2022-06-25 16:42:23.779336
# Unit test for function parse
def test_parse():
    str_0 = '\n    Note'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert len(docstring_0.params) == 0
    assert len(docstring_0.returns) == 0
    assert len(docstring_0.author) == 0
    assert len(docstring_0.see_also) == 0
    assert len(docstring_0.raises) == 0
    assert len(docstring_0.todo) == 0
    assert len(docstring_0.note) == 1
    assert docstring_0.note[0] == 'Note'
    assert docstring_0.version == ''
    assert docstring_0.meta == {}

# Generated at 2022-06-25 16:42:34.651056
# Unit test for function parse
def test_parse():
    docstring_0 = parse("One line initial summary.")
    assert docstring_0.summary == "One line initial summary."
    assert docstring_0.description == ""
    assert docstring_0.returns == ""
    assert len(docstring_0.meta) == 0
    assert len(docstring_0.examples) == 0

    docstring_1 = parse("One line initial summary.\n\nA description.")
    assert docstring_1.summary == "One line initial summary."
    assert docstring_1.description == "A description."
    assert docstring_1.returns == ""
    assert len(docstring_1.meta) == 0
    assert len(docstring_1.examples) == 0


# Generated at 2022-06-25 16:42:47.909558
# Unit test for function parse
def test_parse():

    # Test 0:
    str_0 = 'Note'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.params == []
    assert docstring_0.returns is None
    assert docstring_0.yields is None
    assert docstring_0.raises is None
    assert docstring_0.warns is None
    assert docstring_0.examples == []
    assert docstring_0.references is None
    assert docstring_0.meta == ['Note']

    # Test 1:

# Generated at 2022-06-25 16:42:51.280769
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# main function

# Generated at 2022-06-25 16:42:59.629924
# Unit test for function parse
def test_parse():
    str_0 = '"""A test docstring"""\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ''
    str_1 = '"""A test docstring"""\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == ''
    str_2 = 'Test docstring\n\n'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'Test docstring'
    str_3 = 'Test docstring\n\n'
    docstring_3 = parse(str_3)
    assert docstring_3.short_description == 'Test docstring'
    str_4 = 'Test docstring\n\nTest docstring'
    docstring_4 = parse

# Generated at 2022-06-25 16:43:03.923845
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    style_0 = Style.Google
    style_1 = Style.Numpy
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_0, style=style_0)
    docstring_2 = parse(str_0, style=style_1)

# Generated at 2022-06-25 16:43:08.290017
# Unit test for function parse
def test_parse():
    str_0 = 'Note'
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)

    assert (docstring_0.style == Style.google)

test_parse()

# Generated at 2022-06-25 16:43:15.322013
# Unit test for function parse
def test_parse():
    # Create our test values
    str_0 = 'Note'
    str_1 = 'Note: This is a note.'
    str_2 = 'Note: This is a note. \nThis is a note.'
    str_3 = 'Note: \nThis is a note. \nThis is a note.'
    str_4 = 'Note: This is a note. \nThis is a note.\n'
    str_5 = 'Note: This is a note. \nThis is a note.\n\n'
    str_6 = 'Note: This is a note. \nThis is a note.\n\n \n'
    str_7 = 'Note: This is a note.\nThis is a note.'
    str_8 = 'This is a note.\nThis is a note.'

# Generated at 2022-06-25 16:43:25.141377
# Unit test for function parse
def test_parse():

    # Check if the parsed docstring equals the expected result
    str_0 = 'Note\n\nThis is a test.'
    expected_0 = ''
    assert docstrings_equal(parse(str_0), expected_0)

    str_1 = 'Parameters\n----------\narg1 : str\n    The first argument.\narg2 : int\n    The second argument.'
    expected_1 = ''
    assert docstrings_equal(parse(str_1), expected_1)

    str_2 = 'Returns\n-------\nbool\n    True if successful, False otherwise.'
    expected_2 = ''
    assert docstrings_equal(parse(str_2), expected_2)

    str_3 = 'Yields\n------\nint\n    The next number in the sequence.'
    expected_3 = ''
