

# Generated at 2022-06-25 16:33:40.721265
# Unit test for function parse
def test_parse():
    str_0 = 'DjVkCr[2O`Gv<ZW'
    docstring_0 = parse(str_0)
    str_1 = '?xP#HYq|#'
    docstring_1 = parse(str_1)
    str_2 = 'jwu;oG_e'
    docstring_2 = parse(str_2)
    str_3 = '8gv|zD]\x7f'
    docstring_3 = parse(str_3)
    assert (docstring_1.short_description == 'f2@Vc%Wg')
    assert (docstring_2.long_description == [])
    assert (docstring_3.meta == {})

# Generated at 2022-06-25 16:33:42.864285
# Unit test for function parse
def test_parse():
    str_0 = 'Hello, World!'
    docstring_0 = parse(str_0)
    assert docstring_0.full == str_0


# Generated at 2022-06-25 16:33:43.784777
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:33:54.012986
# Unit test for function parse
def test_parse():
    str_0 = '3lX*dh9`\pG{p*'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == '3lX*dh9`\pG{p*'
    str_1 = 'zQ~|7+X_NS{:V'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'zQ~|7+X_NS{:V'
    str_2 = 'xl|\^]c%@}9a8'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'xl|\^]c%@}9a8'
    str_3 = '`'

# Generated at 2022-06-25 16:33:59.125394
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    var_0 = parse(str_0)
    assert var_0.short != "4"


# Generated at 2022-06-25 16:34:06.865951
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)
    assert docstring_0.parameters[0].name == '--iterations'
    assert docstring_0.returns.type_name == 'int'
    assert docstring_0.raises[0].type_name == 'ValueError'
    assert docstring_0.content == '\n        This is the long description for the function\n        '
    str_1 = '}F{:i#\x7fO'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This is a short description'
    assert docstring_1.summary == 'This is a short description'

# Generated at 2022-06-25 16:34:08.485002
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:34:16.695906
# Unit test for function parse
def test_parse():
    text = '''\
    Keyword arguments:
    arg1 -- the first value
    arg2 -- the second value
    '''
    expected = Docstring(
        summary='',
        description='',
        returns='',
        args=[],
        kwargs=(
            ('arg1', 'the first value'),
            ('arg2', 'the second value')
        ),
        examples=[],
        meta=text
    )
    assert parse(text) == expected
    str_0 = '7xIxWXNvkHp}Nzq'
    docstring_0 = parse(str_0)
    #assert parse(str_0) == expected
    str_1 = 'ztW0|t7;B'
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:34:28.903100
# Unit test for function parse
def test_parse():
    test_case_0()
    str_0 = "This module contains tools for working with the Adafruit IO REST API."
    docstring_0 = parse(str_0)
    check_docstring(docstring_0, str_0)
    parse("a")
    parse("asdf")
    parse("asdf\n")
    parse("asdf\n asdf")
    parse(" asdf\n asdf")
    parse("asdf\n asdf\n")
    parse("\n")
    parse("asdf  ")
    parse("asdf\n  ")
    parse("\n\n\n")
    parse("\n\n\n\n")
    parse("\n\n\n\n\n")
    parse("\n\n\n\n\n\n")


# Generated at 2022-06-25 16:34:29.941337
# Unit test for function parse

# Generated at 2022-06-25 16:34:43.218409
# Unit test for function parse
def test_parse():
    str_0 = 'TlTn8hF*'
    style = Style.auto
    docstring_0 = parse(str_0, style)
    str_1 = '\\brU#Vc%s'
    style = Style.auto
    docstring_1 = parse(str_1, style)
    str_2 = 'ob$|w'
    style = Style.auto
    docstring_2 = parse(str_2, style)
    str_3 = 'ox~b<3'
    style = Style.auto
    docstring_3 = parse(str_3, style)
    str_4 = '3qB_O'
    style = Style.auto
    docstring_4 = parse(str_4, style)
    str_5 = '\\j1'
    style = Style.auto
   

# Generated at 2022-06-25 16:34:47.069882
# Unit test for function parse
def test_parse():
    test_case_0()
    print('All tests passed!')

# Print function for function parse

# Generated at 2022-06-25 16:34:52.240060
# Unit test for function parse
def test_parse():
    str_0 = '<2&=.X)c%qOX>'
    style_0 = '{m}g`5U6BHU'
    docstring_0 = parse(str_0, style_0)


if __name__ == '__main__':
    import timeit
    print(timeit.timeit(test_case_0, number=10))
    print(timeit.timeit(test_parse, number=10))

# Generated at 2022-06-25 16:35:00.885272
# Unit test for function parse
def test_parse():
    str_0 = 'The element at index @p{idx} in the @c{list}.'
    str_1 = 'The element at index @p{idx} in the @p{list}.'
    str_2 = 'The element at index @p{idx} in the @p{list}.'
    for str_ in [str_0, str_1, str_2]:
        docstring = parse(str_)
        assert docstring.short_description.text == 'The element at index {idx} in the {list}.'
        assert docstring.meta['idx'] == 'the index of the element to be returned.'
        assert docstring.meta['list'] == 'the list to be searched.'

# Generated at 2022-06-25 16:35:10.304620
# Unit test for function parse
def test_parse():
    str_0 = 'x,h*xZ'
    val_0 = parse(str_0)
    assert val_0.long_description == 'x,h*xZ' and val_0.short_description == 'x,h*xZ'

    # Test case 1
    str_1 = 'G\\kZ!{/P"+[9X'
    val_1 = parse(str_1)
    assert val_1.long_description == 'G\\kZ!{/P"+[9X' and val_1.short_description == 'G\\kZ!{/P"+[9X'

    str_2 = 'ugdd\\W8N\\P/'
    val_2 = parse(str_2)

# Generated at 2022-06-25 16:35:11.034810
# Unit test for function parse
def test_parse():
    assert api_version.status_code == 200

# Generated at 2022-06-25 16:35:18.308348
# Unit test for function parse
def test_parse():
    str_0 = 'kMjKQ`4m*4}hfZKX'
    style = Style.auto
    docstring_0 = parse(str_0, style)
    str_1 = 'V7`u*`2}r0e_P'
    style = Style.numpy
    docstring_1 = parse(str_1, style)
    str_2 = 'kv&a1y}JMi,V7l'
    style = Style.google
    docstring_2 = parse(str_2, style)
    str_3 = 'qBzNvJ?9Z'
    style = Style.sphinx
    docstring_3 = parse(str_3, style)
    str_4 = '*Xp}lO?cC_}1!}~*'
   

# Generated at 2022-06-25 16:35:18.825832
# Unit test for function parse
def test_parse():


    assert callable(parse)


# Generated at 2022-06-25 16:35:29.441031
# Unit test for function parse
def test_parse():
    str_0 = 'xzQvL-OJ|R?#P$W.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'xzQvL-OJ|R?#P$W.'
    str_1 = '-DzK#6+^u2F\\U6<'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == '-DzK#6+^u2F\\U6<'
    str_2 = '_>lNw(y~P?@0}Vu'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == '_>lNw(y~P?@0}Vu'

# Unit test

# Generated at 2022-06-25 16:35:36.665716
# Unit test for function parse
def test_parse():
    str_0 = 'DCz\\6`\\>6Jz%@\\^`6\\5'
    style_0 = Style.pep_257
    docstring_0 = parse(str_0, style_0)

if __name__ == '__main__':
    test_case_0()
    # test_parse()  # FIXME: add cases to test output
    # test_parse()
    # test_parse()
    print('Done')

# Generated at 2022-06-25 16:35:41.311057
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:35:48.988169
# Unit test for function parse
def test_parse():
    docstring_0 = parse(
        """This is the summary line.

The description of the function is here.

:param input_data: str to be processed
:returns: str processed
:raises: exception in case of error
"""
    )
    assert docstring_0.summary == "This is the summary line."
    assert docstring_0.description == "The description of the function is here."
    assert docstring_0.returns.description == "str processed"
    assert docstring_0.params[0].name == "input_data"
    assert docstring_0.params[
        0
    ].description == "str to be processed"
    assert [e.description for e in docstring_0.raises] == [
        "exception in case of error"
    ]



# Generated at 2022-06-25 16:35:51.821228
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:35:56.821530
# Unit test for function parse
def test_parse():
    text_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(text_0)

    assert docstring_0.summary == 'HLcX*dh9`\\pG{p*'.split('\n')[0]


test_parse()
test_case_0()

# Generated at 2022-06-25 16:36:01.254125
# Unit test for function parse
def test_parse():
    text = "Lorem ipsum."
    assert (parse(text) == Docstring(desc=text))


if __name__ == '__main__':
    globals()['test_case_0']()

# Generated at 2022-06-25 16:36:06.380723
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:36:12.395783
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)
    str_1 = 'Zr0{H>~jzGX9\nP#M`'
    docstring_1 = parse(str_1)
    str_2 = '7D`8\n}jAm4\\&tBe|\\ "B{sjh#dYm2'
    docstring_2 = parse(str_2)
    str_3 = 'T\n{K#<YdQZ:1&'
    docstring_3 = parse(str_3)
    str_4 = 't)aK7VuSNNFL'
    docstring_4 = parse(str_4)

# Generated at 2022-06-25 16:36:19.114604
# Unit test for function parse
def test_parse():
    # Strings
    str_1 = '''\
The main parsing routine.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation'''
    str_2 = """\
This is a multi-line docstring.

This is the second line.
"""
    str_3 = """\
This is a multi-line docstring.

This is the second line.

This is the third line.
"""
    str_4 = """\
This is a multi-line docstring.

This is the second line.

This is the third line.

This is the fourth line!
"""

# Generated at 2022-06-25 16:36:21.325066
# Unit test for function parse
def test_parse():
    assert True == True

# Test cases for function parse

# Generated at 2022-06-25 16:36:29.932363
# Unit test for function parse
def test_parse():

    # Test Case 0
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)

    # Test Case 1
    str_1 = '=M'
    docstring_1 = parse(str_1)

    # Test Case 2
    str_2 = '=M\n'
    docstring_2 = parse(str_2)

    # Test Case 3
    str_3 = '=M\n\n'
    docstring_3 = parse(str_3)

    # Test Case 4
    str_4 = '=M\n\n\n\n=M'
    docstring_4 = parse(str_4)

    # Test Case 5

# Generated at 2022-06-25 16:36:40.201333
# Unit test for function parse
def test_parse():
    from random import randint
    from random import choice
    from string import ascii_letters
    from string import digits
    style_to_int = {'numpy': '0', 'google': '1', 'sphinx': '2'}
    for i in range(100):
        str_0 = ''.join(choice(ascii_letters) for i in range(100))
        if randint(0, 1):
            docstring_0 = parse(str_0)
        else:
            docstring_0 = parse(str_0, choice(list(style_to_int.keys())))


if __name__ == '__main__':
    import sys
    import timeit
    if len(sys.argv) == 1:
        for i in range(100000):
            test_case_0()


# Generated at 2022-06-25 16:36:40.824881
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:36:45.076609
# Unit test for function parse
def test_parse():
    text = 'Hello, world!'
    parsed = parse(text)
    assert parsed.content.raw == text

if __name__ == "__main__":
    import time

    start_time = time.time()
    test_case_0()
    test_parse()
    print('{} seconds'.format(time.time() - start_time))

# Generated at 2022-06-25 16:36:57.585390
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert docstring_0.content == 'HLcX*dh9`\\pG{p*'
    assert docstring_0.context == ''
    assert docstring_0.return_annotation == ''
    assert docstring_0.returns_description == ''
    assert docstring_0.warns == ''
    assert docstring_0.raises == ''
    assert docstring_0.yield_annotation == ''
    assert docstring_0.yields_description == ''
    str_1 = '\t9@Fk=rYc<w"p'

# Generated at 2022-06-25 16:37:07.319087
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)
    str_1 = 'q3yWKf8aJ/"\t-C{PQwOdO8KtNHM'
    docstring_1 = parse(str_1)
    str_2 = 'HLcX*dh9`\\pG{p*'
    docstring_2 = parse(str_2)
    str_3 = 'HLcX*dh9`\\pG{p*'
    docstring_3 = parse(str_3)
    str_4 = 'my_module'
    docstring_4 = parse(str_4)
    str_5 = '<"^'
    docstring_5 = parse(str_5)
    str

# Generated at 2022-06-25 16:37:09.380983
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:37:17.821682
# Unit test for function parse
def test_parse():
    arr = list()
    arr.append(0)
    arr.append(0)
    arr.append(1)
    arr.append(1)
    arr.append(1)
    arr.append(1)
    arr.append(1)
    arr.append(0)
    arr.append(1)
    arr.append(1)
    arr.append(0)
    arr.append(1)
    arr.append(1)
    arr.append(1)
    arr.append(1)
    arr.append(0)
    arr.append(1)
    arr.append(1)
    arr.append(0)
    arr.append(1)
    arr.append(1)
    arr.append(1)
    arr.append(1)
    arr.append(1)
   

# Generated at 2022-06-25 16:37:31.264868
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)
    assert str_0 == docstring_0.summary.strip()
    str_1 = '    "4pj0{$wb4?-:W<B--od>jyio<@2|}IwVRa`lF'
    docstring_1 = parse(str_1)
    assert str_1 == docstring_1.meta.get('args')[0].description.strip()
    str_2 = 'v}m(]{+-iz1(;h!xJ_b\\+'
    docstring_2 = parse(str_2)
    assert str_2 == docstring_2.variables[0].name
    str_3 = '?'
    doc

# Generated at 2022-06-25 16:37:31.863590
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-25 16:37:32.907550
# Unit test for function parse
def test_parse():
    assert True

# Test case for function parse

# Generated at 2022-06-25 16:37:46.573704
# Unit test for function parse
def test_parse():
    str_0 = 'j'
    str_1 = 't'
    str_2 = 'Z'
    str_3 = 'm'
    str_4 = '='
    str_5 = '<'
    str_6 = 'N'
    str_7 = '>'
    str_8 = '!'
    str_9 = 'L'
    str_10 = ' '
    str_11 = '2'
    str_12 = 'K'
    str_13 = '/'
    str_14 = ':'
    str_15 = 'y'
    str_16 = '='
    str_17 = ','
    str_18 = 'w'
    str_19 = 'D'
    str_20 = 'Y'
    str_21 = '7'
    str_22 = '0'

# Generated at 2022-06-25 16:37:55.850280
# Unit test for function parse

# Generated at 2022-06-25 16:37:59.756896
# Unit test for function parse
def test_parse():
    try:
        func_0 = test_case_0
        func_0()
    except Exception as e:
        print('Exception: %s' % e)
        assert False


# Generated at 2022-06-25 16:38:08.572943
# Unit test for function parse

# Generated at 2022-06-25 16:38:18.870888
# Unit test for function parse
def test_parse():
    docstring_0 = parse('def foo(arg):\n    """\n    Returns x uniquely.\n    """\n    return x')
    assert len(docstring_0.args) == 1
    assert docstring_0.args[0].arg == 'arg'
    assert docstring_0.returns.content == 'x uniquely.'
    assert len(docstring_0.examples) == 0
    assert len(docstring_0.seealso) == 0
    docstring_1 = parse('def foo(arg):\n    """\n    Returns x uniquely.\n    """\n    return x', style=Style.google)
    assert len(docstring_1.args) == 1
    assert docstring_1.args[0].arg == 'arg'

# Generated at 2022-06-25 16:38:29.237921
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    assert parse(str_0) == None
    str_0 = 'W'
    assert parse(str_0) == None
    str_0 = 'Whz'
    assert parse(str_0) == None
    str_0 = '<'
    assert parse(str_0) == None
    str_0 = 'R'
    assert parse(str_0) == None
    assert parse() == None
    assert parse() == None
    assert parse() == None
    assert parse() == None
    assert parse() == None
    assert parse() == None
    assert parse() == None
    assert parse() == None
    assert parse() == None
    assert parse() == None

# vim: tabstop=2 shiftwidth=2 expandtab

# Generated at 2022-06-25 16:38:30.657359
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:38:42.149072
# Unit test for function parse
def test_parse():
    func = parse
    text_0 = ["hello"]

# Generated at 2022-06-25 16:38:52.703562
# Unit test for function parse
def test_parse():
    assert parse('Hello', style=Style.numpy) == Docstring(
        summary='Hello',
        description=[],
        returns=None,
        raises=None,
        attributes=None,
        methods=None
    )
    assert parse('Hello', style=Style.google) == Docstring(
        summary='Hello',
        description=[],
        returns=None,
        raises=None,
        attributes=None,
        methods=None
    )
    assert parse('Hello', style=Style.auto) == Docstring(
        summary='Hello',
        description=[],
        returns=None,
        raises=None,
        attributes=None,
        methods=None
    )

# Generated at 2022-06-25 16:39:04.249599
# Unit test for function parse
def test_parse():
    str_0 = '{0}{1}{2}'.format('https://github.com', '/styles/', 'whitespace')
    url_0 = '{0}{1}{2}'.format('https://raw.githubusercontent.com/readthedocs', '/sphinx-features/master/features/', 'docstrings/whitespace.string')
    buff = StringIO()
    urlopen(url_0, None, None, buff)
    str_1 = buff.getvalue()
    str_2 = str_1.strip()
    str_3 = str_2.replace('\r', '')
    load_string = str_3.replace('\n', ' ')
    str_4 = 'whitespace'
    style_0 = STYLES[str_4]

# Generated at 2022-06-25 16:39:08.339199
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:39:12.560826
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:39:13.956255
# Unit test for function parse
def test_parse():
    assert callable(parse)


import random


# Generated at 2022-06-25 16:39:19.898123
# Unit test for function parse
def test_parse():
    text_0 = 'Test one two three four five'
    style_0 = Style.numpy
    docstring_0 = parse(text_0, style_0)
    assert docstring_0.short_description == 'Test one two three four five'
    assert docstring_0.long_description == ''
    assert docstring_0.meta.get('param') == None
    assert docstring_0.meta.get('return') == None
    assert docstring_0.meta.get('raise') == None


# Generated at 2022-06-25 16:39:29.470665
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param int x: Description of x.
:param int y: Description of y.
"""
    style = Style.numpy
    # docstr = parse(text, style)
    # assert docstr == Docstring(summary='Summary line.', description='Extended description.', style=style, 
    #                            params={'x': 'Description of x.', 'y': 'Description of y.'})
    # docstr = parse(text)
    # assert docstr == Docstring(summary='Summary line.', description='Extended description.', style=style, 
    #                            params={'x': 'Description of x.', 'y': 'Description of y.'})


# Generated at 2022-06-25 16:39:36.754849
# Unit test for function parse
def test_parse():
    str_0 = 'this is a test string\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == str_0.strip()
    assert docstring_0.long_description == ''
    assert docstring_0.meta is None
    assert docstring_0.returns is None
    assert len(docstring_0.params) == 0
    assert len(docstring_0.errors) == 0
    assert len(docstring_0.raises) == 0
    assert len(docstring_0.yields) == 0
    assert len(docstring_0.warns) == 0
    assert len(docstring_0.examples) == 0


# Generated at 2022-06-25 16:39:39.709077
# Unit test for function parse
def test_parse():
    try:
        assert callable(parse)
    except AssertionError as e:
        print(e)
        raise(e)


# Generated at 2022-06-25 16:39:49.442556
# Unit test for function parse
def test_parse():
    comment = 'Parses xml docs.\n' \
        '\n' \
        ':param xml_doc: XML document string.\n' \
        ':param xpath: XPATH expression to evaluate.\n' \
        ':returns: Parsed xml doc.\n'
    assert parse(comment).short_description == 'Parses xml docs.'
    assert parse(comment).long_description == ''
    assert parse(comment.replace(':param ', ':parameter ')).parameters == [
        {
            'name': 'xml_doc',
            'type': None,
            'description': 'XML document string.'
        },
        {
            'name': 'xpath',
            'type': None,
            'description': 'XPATH expression to evaluate.'
        }
    ]

# Generated at 2022-06-25 16:39:51.494102
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    assert parse(str_0) == docstring_0

# Generated at 2022-06-25 16:40:03.627614
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)
    # expected docstring_0:
    # short_desc: None
    # long_desc: None
    # tags: None
    str_0 = '&%oJqX4Mht8o`2'
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    # expected docstring_0:
    # short_desc: None
    # long_desc: None
    # tags: None
    str_0 = 'j/^y25B>i-d?.h|'
    style_0 = Style.numpy
    docstring_0 = parse(str_0, style_0)
    # expected docstring_0

# Generated at 2022-06-25 16:40:09.993267
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Test if function parse wouldn't fail without any arguments

# Generated at 2022-06-25 16:40:13.576162
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except Exception as ex:
        print('Error in test_parse():{}'.format(ex))

test_parse()

# Generated at 2022-06-25 16:40:14.939326
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:40:23.497990
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ""
    assert docstring_0.long_description == ""
    str_1 = '\\n\\t@param value: Description of value\\n\\r'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == ""
    assert docstring_1.long_description == ""
    str_2 = '\\n\\t@param value: Description of value\\n\\r'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == ""
    assert docstring_2.long_description == ""

# Generated at 2022-06-25 16:40:30.574481
# Unit test for function parse
def test_parse():
    text = """
    This is a summary::

        the summary
    """
    docstring_0 = parse(text)
    text_1 = """
    This is a summary::

        the summary

    :param name:
    :type name:
    :return:
    :rtype:
    """
    docstring_1 = parse(text_1)
    text_2 = """
    This is a summary::

        the summary

    :param name:
    :type name:
    :return:
    :rtype:
    """
    docstring_2 = parse(text_2)
    text_3 = """
    This is a summary::

        the summary

    :param name:
    :type name:
    :return:
    :rtype:
    """

# Generated at 2022-06-25 16:40:42.657182
# Unit test for function parse
def test_parse():
    str_0 = "      Author: Lorem ipsum.\n      Email: lorem_ipsum@gmail.com\n    Docstring with\n    multiple paragraphs\n   \n      and empty lines.\n   \n        Even with\n        spaces.\n      And a final paragraph."
    docstring_0 = parse(str_0)
    assert docstring_0.meta['author'] == 'Lorem ipsum.'
    assert docstring_0.meta['email'] == 'lorem_ipsum@gmail.com'
    assert docstring_0.short_description == 'Docstring with multiple paragraphs and empty lines. Even with spaces.'
    assert docstring_0.long_description == 'And a final paragraph.'


# Generated at 2022-06-25 16:40:52.941827
# Unit test for function parse
def test_parse():
    text_0 = 'Single-line docstring'
    style_0 = Style.numpy
    docstring_0 = parse(text_0, style_0)
    assert docstring_0.short_description == 'Single-line docstring'
    assert docstring_0.long_description == ''
    assert docstring_0.returns is None
    assert docstring_0.return_type == ''
    assert docstring_0.params == []
    assert docstring_0.meta == {}
    text_1 = 'Single-line docstring'
    docstring_1 = parse(text_1)
    assert docstring_1.short_description == 'Single-line docstring'
    assert docstring_1.long_description == ''
    assert docstring_1.returns is None
    assert docstring_1.return_type

# Generated at 2022-06-25 16:40:54.737101
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:40:55.396067
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-25 16:40:56.662056
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:41:09.110356
# Unit test for function parse
def test_parse():
    str_0 = 'Example docstring'
    str_1 = '  Foo bar baz'
    str_2 = '  Foo bar baz'
    str_3 = '  Foo bar baz'

    answer_0 = parse(str_0)
    answer_1 = parse(str_1)
    answer_2 = parse(str_2)
    answer_3 = parse(str_3)

    answer_0_raw = 'Example docstring'
    answer_1_raw = '  Foo bar baz'
    answer_2_raw = '  Foo bar baz'
    answer_3_raw = '  Foo bar baz'
    assert answer_0 == answer_0_raw
    assert answer_1 == answer_1_raw
    assert answer_2 == answer_2_raw
    assert answer_3 == answer

# Generated at 2022-06-25 16:41:19.757588
# Unit test for function parse
def test_parse():
    str_0 = '-E;JF?6|>\\6#*`VhJ"B'
    docstring_0 = parse(str_0)
    str_1 = 'q3(c0>Ea=G|Cx5q5_D'
    docstring_1 = parse(str_1)
    assert((str_0 == docstring_0.short_description) and (str_1 == docstring_1.short_description))
    str_2 = 'thfRhDd+uWM2P^n.c%#'
    docstring_2 = parse(str_2)
    str_3 = 'Px`&H"+`^-*;p]D"MI'
    docstring_3 = parse(str_3)

# Generated at 2022-06-25 16:41:20.572795
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:41:29.230827
# Unit test for function parse
def test_parse():
    str_0 = '@pylife\n@author\n     John Smith\n@author\n     Adam Smith'
    docstring_0 = parse(str_0)
    str_1 = '@pylife\n@author\n     John Smith\n@author\n     Adam Smith'
    docstring_1 = parse(str_1)
    str_2 = '@pylife\n@author\n     John Smith\n@author\n     Adam Smith'
    docstring_2 = parse(str_2)
    str_3 = '@pylife\n@author\n     John Smith\n@author\n     Adam Smith'
    docstring_3 = parse(str_3)

# Generated at 2022-06-25 16:41:30.873375
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    test_case_0()

# Generated at 2022-06-25 16:41:40.971187
# Unit test for function parse
def test_parse():
    text_0 = 'Hello! This is a paragraph.'
    style_0 = Style.numpy
    docstring_0 = parse(text_0, style_0)
    assert docstring_0.short_description == 'Hello!'
    assert docstring_0.long_description == 'This is a paragraph.' and docstring_0.long_description_markup_type == None
    assert len(docstring_0.params) == 0
    assert len(docstring_0.returns) == 0
    assert len(docstring_0.raises) == 0
    assert docstring_0.example == None and docstring_0.example_markup_type == None
    assert len(docstring_0.meta) == 0
    assert docstring_0.style == style_0 and docstring_0.valid == True

    text_1

# Generated at 2022-06-25 16:41:47.035719
# Unit test for function parse
def test_parse():
    str1 = """
        Hello world!
        :param str a:
        :returns: int
    """
    docstring1 = parse(str1)
    assert docstring1.summary == 'Hello world!\n'
    assert docstring1.fields['param a'].type == 'str'
    assert docstring1.fields['returns'].type == 'int'



# Generated at 2022-06-25 16:41:49.141799
# Unit test for function parse
def test_parse():
    try:
        assert callable(parse)
    except:
        print('Function "parse" is not callable.')
        raise


test_case_0()

# Generated at 2022-06-25 16:41:52.517397
# Unit test for function parse
def test_parse():
    # Check that style argument is handled correctly
    # TODO: todo
    # Handle ParseError in auto mode
    # TODO: todo
    test_case_0()

# Generated at 2022-06-25 16:42:02.525907
# Unit test for function parse
def test_parse():
    str_0 = 'This is a short one-line docstring.'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 'This is a short one-line docstring.'
    assert docstring_0.summary_first_sentence == 'This is a short one-line docstring.'
    str_0 = 'This is also a short one-line docstring.'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 'This is also a short one-line docstring.'
    assert docstring_0.summary_first_sentence == 'This is also a short one-line docstring.'
    str_0 = 'This is not a short one-line docstring.'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:42:08.905109
# Unit test for function parse
def test_parse():
    # docstring_parser.parse(docstring)
    assert callable(parse)

# Generated at 2022-06-25 16:42:10.470804
# Unit test for function parse
def test_parse():
    # test cases
    test_case_0()


# Generated at 2022-06-25 16:42:11.616820
# Unit test for function parse
def test_parse():
    assert callable(parse), 'Function "parse" is not callable'


# Generated at 2022-06-25 16:42:13.818065
# Unit test for function parse
def test_parse():
    assert callable(parse)

# testing main trigger
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:42:15.972870
# Unit test for function parse
def test_parse():
    str_0 = 'The main parsing routine.'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:42:23.979512
# Unit test for function parse
def test_parse():
    str_0 = 'E}ZSz'
    str_1 = 'e'
    str_2 = 'd)'
    str_3 = 'T'
    str_4 = '>'
    str_5 = 'W'
    str_6 = '&'
    str_7 = 'V'
    str_8 = 'Wh'
    str_9 = '6U'
    str_10 = 'Cv'
    str_11 = '&'
    str_12 = 'f)'
    str_13 = '`'
    str_14 = '@S'
    str_15 = '|'
    str_16 = 'X'
    str_17 = 'u'
    str_18 = '#'
    str_19 = 'x$0'
    str_20 = '!&'


# Generated at 2022-06-25 16:42:34.686969
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    assert parse(str_0) == 'HLcX*dh9`\\pG{p*'
    str_1 = '9|1J:n>ufv"+/K!8'
    assert parse(str_1) == '9|1J:n>ufv"+/K!8'
    str_2 = 'E^tC4wH=1[0hcQ9X'
    assert parse(str_2) == 'E^tC4wH=1[0hcQ9X'
    str_3 = '_axm&nPq3@GO-T>T'
    assert parse(str_3) == '_axm&nPq3@GO-T>T'
    str_

# Generated at 2022-06-25 16:42:44.604000
# Unit test for function parse
def test_parse():
    input_0 = 'Zpzq3}t1w,F'
    expected_output_0 = 'Zpzq3}t1w,F'
    returned_value_0 = parse(input_0)
    test_0 = expected_output_0 == returned_value_0
    input_1 = 'y>u~6N'
    expected_output_1 = 'y>u~6N'
    returned_value_1 = parse(input_1)
    test_1 = expected_output_1 == returned_value_1
    input_2 = 'TgT<J'
    expected_output_2 = 'TgT<J'
    returned_value_2 = parse(input_2)
    test_2 = expected_output_2 == returned_value_2

# Generated at 2022-06-25 16:42:45.350026
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:54.496233
# Unit test for function parse
def test_parse():
    str_1 = '\n'
    str_2 = '\n'
    docstring_2 = parse(str_2)
    str_3 = 'q&pA\t*}(T<wHrk FQyp)c'
    docstring_3 = parse(str_3)
    str_4 = '\n'
    docstring_4 = parse(str_4)
    str_5 = '\n'
    str_6 = '\n'
    docstring_6 = parse(str_6)
    str_7 = '}%\t5\tL1\t0E0\tqJ\t{(Z9'
    docstring_7 = parse(str_7)

# Generated at 2022-06-25 16:43:01.594542
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        print('test_parse failed')


# Generated at 2022-06-25 16:43:02.716586
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:43:12.890204
# Unit test for function parse
def test_parse():
    str_0 = 'HLcX*dh9`\\pG{p*'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'HLcX*dh9`\\pG{p*'

    str_0 = 'j\\z>6{9U|Xd]>]'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'j\\z>6{9U|Xd]>]'

    str_0 = '1n7~d8Mzm9fY$S'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == '1n7~d8Mzm9fY$S'


# Generated at 2022-06-25 16:43:23.998646
# Unit test for function parse
def test_parse():
    text = """Summary line.

    Extended description.

    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`

    Returns:
        bool: Description of return value

    Raises:
        AttributeError: The text to explain the exception.
    """
    docstring_0 = parse(text)
    assert(docstring_0.short_description == 'Summary line.')
    assert(docstring_0.long_description == 'Extended description.')
    assert(len(docstring_0.params) == 2)
    assert(docstring_0.params['arg1'] == 'Description of `arg1`')
    assert(docstring_0.params['arg2'] == 'Description of `arg2`')

# Generated at 2022-06-25 16:43:31.687461
# Unit test for function parse
def test_parse():
    """
    Function with arguments
    :param x: int
    :param y: int
    :return: int
    """
    str_0 = """
    Function with arguments
    
    :param x: int
    :param y: int
    :return: int
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Function with arguments"
    assert docstring_0.long_description == ""
    assert docstring_0.args == []
    assert docstring_0.args_named == [("x", "int"), ("y", "int")]
    assert docstring_0.args_unnamed == []
    assert docstring_0.returns == ("int", "")
    assert docstring_0.return_type == "int"
    assert docstring_0