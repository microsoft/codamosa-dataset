

# Generated at 2022-06-25 16:33:39.064768
# Unit test for function parse
def test_parse():
    str_0 = 'Parses the docstring into its components.\n\n:param text: docstring text to parse\n:param style: docstring style\n:returns: parsed docstring representation'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:33:39.581862
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-25 16:33:40.368399
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:33:42.396927
# Unit test for function parse
def test_parse():
    text = "Hello World.\nThis is a test for parse.\n"
    style = Style.google
    parse(text, style)
    return 1


# Generated at 2022-06-25 16:33:52.612186
# Unit test for function parse
def test_parse():
    from docstring_parser.example_code import add
    # Test for return value
    assert isinstance(parse(add.__doc__), Docstring) == True

    # Test for TypeError
    try:
        parse(1)
    except TypeError:
        assert True
    else:
        assert False

    try:
        parse([1, 2])
    except TypeError:
        assert True
    else:
        assert False

    try:
        parse((1, 2))
    except TypeError:
        assert True
    else:
        assert False

    try:
        parse({"a": 1})
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-25 16:33:53.385702
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:34:00.674875
# Unit test for function parse
def test_parse():
    valid_inputs = test_case_0()
    outputs = parse(valid_inputs[0])
    if outputs != valid_inputs[1]:
        raise Exception("Expected =" + valid_inputs[1] + ", but got =" + outputs)

# main test run
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:34:02.321981
# Unit test for function parse
def test_parse():
    pass


# Generated at 2022-06-25 16:34:11.883250
# Unit test for function parse
def test_parse():
    str_0 = 'Returns the last element of the array.'
    ret_0 = parse(str_0)
    str_1 = 'Returns the last element of the array.'
    ret_1 = parse(str_1)
    str_2 = 'Returns the last element of the array.'
    ret_2 = parse(str_2)
    str_3 = 'Returns the last element of the array.'
    ret_3 = parse(str_3)
    str_4 = 'Returns the last element of the array.'
    ret_4 = parse(str_4)
    str_5 = 'Returns the last element of the array.'
    ret_5 = parse(str_5)
    str_6 = 'Returns the last element of the array.'
    ret_6 = parse(str_6)

# Generated at 2022-06-25 16:34:21.842469
# Unit test for function parse

# Generated at 2022-06-25 16:34:34.211806
# Unit test for function parse
def test_parse():
    str_0 = None
    str_1 = """\
This is a fake docstring.
It has two lines.
"""
    str_2 = """\
This is a fake docstring.
It has two lines.
"""
    str_3 = """\
This is a fake docstring.
It has two lines.
"""
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    docstring_2 = parse(str_2)
    docstring_3 = parse(str_3)


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:34:41.943524
# Unit test for function parse
def test_parse():
    docstring_0 = parse("The quick brown fox jumps over the lazy dog.\n\n")
    docstring_1 = parse(" The quick brown fox jumps over the lazy dog.\n\n")
    docstring_2 = parse("  The quick brown fox jumps over the lazy dog.\n\n")
    docstring_3 = parse("   The quick brown fox jumps over the lazy dog.\n\n")
    docstring_4 = parse("    The quick brown fox jumps over the lazy dog.\n\n")
    docstring_5 = parse("     The quick brown fox jumps over the lazy dog.\n\n")
    docstring_6 = parse("      The quick brown fox jumps over the lazy dog.\n\n")
    docstring_7 = parse("       The quick brown fox jumps over the lazy dog.\n\n")
   

# Generated at 2022-06-25 16:34:53.408043
# Unit test for function parse
def test_parse():
    assert parse('', Style.google) == Docstring(
        summary='',
        description='',
        args=[],
        returns=None,
        raises=[],
    )
    assert parse('  Foo bar baz.') == Docstring(
        summary='Foo bar baz.',
        description='',
        args=[],
        returns=None,
        raises=[],
    )
    assert parse('Some longer\ndescription.') == Docstring(
        summary='',
        description='Some longer\ndescription.',
        args=[],
        returns=None,
        raises=[],
    )

# Generated at 2022-06-25 16:34:56.573938
# Unit test for function parse
def test_parse():
    assert callable(parse)
    str_0 = None
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:35:08.937260
# Unit test for function parse
def test_parse():
    str_0 = "Update SSH known hosts for new IP address"
    docstring_0 = parse(str_0)
    str_1 = "Update SSH known hosts for new IP addresses\n"
    docstring_1 = parse(str_1)
    str_2 = "returns an int\n"
    docstring_2 = parse(str_2)
    str_3 = "Returns an int\n"
    docstring_3 = parse(str_3)
    str_4 = "returns a list\n"
    docstring_4 = parse(str_4)
    str_5 = "Returns a list\n"
    docstring_5 = parse(str_5)
    str_6 = "returns a dict\n"
    docstring_6 = parse(str_6)

# Generated at 2022-06-25 16:35:11.115379
# Unit test for function parse
def test_parse():
    str_0 = ''
    style_0 = Style.auto
    # Call function parse with argument str_0, style_0
    r = parse(str_0, style_0)

# Generated at 2022-06-25 16:35:18.354796
# Unit test for function parse
def test_parse():
    str_0 = 'string is null'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'string is null'
    assert docstring_0.long_description == 'string is null'
    assert list(docstring_0.returns) == []
    assert list(docstring_0.raises) == []
    assert list(docstring_0.parameters) == []
    assert list(docstring_0.examples) == []
    assert list(docstring_0.see_also) == []
    assert list(docstring_0.meta) == []
    assert list(docstring_0.notes) == []
    assert list(docstring_0.warnings) == []
    str_1 = ''
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:35:25.458326
# Unit test for function parse
def test_parse():
    import pytest
    import sys
    import io

    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    test_case_0()
    sys.stdout = sys.__stdout__

    assert ("Docstring not found in function main, return None.\n" in capturedOutput.getvalue()) is True

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:35:36.058877
# Unit test for function parse
def test_parse():
    # from docstring_parser.parser import parse
    # from docstring_parser.styles import AUTODOC
    # from docstring_parser import Docstring
    str_0 = None
    docstring_0 = parse(str_0)
    str_1 = "This is description"
    docstring_1 = parse(str_1)
    print(docstring_1)
    str_2 = "This is description\n :returns: \n\n"
    docstring_2 = parse(str_2)
    print(docstring_2)
    str_3 = "This is description\n\n:return: return_description\n\n"
    docstring_3 = parse(str_3)
    print(docstring_3)

# Generated at 2022-06-25 16:35:39.297014
# Unit test for function parse
def test_parse():
    test_case_0()

# Testing from here

# Generated at 2022-06-25 16:35:48.905316
# Unit test for function parse

# Generated at 2022-06-25 16:35:50.548268
# Unit test for function parse
def test_parse():
    assert 1 == 1

test_parse()

# Generated at 2022-06-25 16:35:51.625060
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:36:03.322300
# Unit test for function parse
def test_parse():
    assert_equal("", parse(""))
    assert_equal("", parse("\n"))
    assert_equal("\n", parse("\n\n"))
    assert_equal("\n", parse("\n\n\n"))
    assert_equal("\n\n", parse("\n\n\n\n"))
    assert_equal("\n\n\n", parse("\n\n\n\n\n"))
    assert_equal("a", parse("\na"))
    assert_equal("a\n", parse("\na\n"))
    assert_equal("a\n\n", parse("\na\n\n"))
    assert_equal("a\n\nb", parse("\na\n\nb"))

# Generated at 2022-06-25 16:36:16.076657
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    style_0 = Style.sphinx
    str_1 = None
    docstring_1 = parse(str_1, style_0)
    str_2 = """
    """
    docstring_2 = parse(str_2)
    style_1 = Style.sphinx
    str_3 = """
    """
    docstring_3 = parse(str_3, style_1)
    str_4 = """
    """
    docstring_4 = parse(str_4)
    style_2 = Style.sphinx
    str_5 = """
    """
    docstring_5 = parse(str_5, style_2)
    str_6 = """
    """
    docstring_6 = parse(str_6)

# Generated at 2022-06-25 16:36:19.802542
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    # test_parse()
    test_case_0()

# Generated at 2022-06-25 16:36:28.746556
# Unit test for function parse
def test_parse():
    str_0 = 'Summary\n'
    str_1 = 'Returns'
    str_2 = '    Summary\n'
    str_3 = 'Summary\n\n'
    str_4 = 'Summary\n\nReturns'
    str_5 = 'Summary\n\n    Returns'
    str_6 = 'Summary\n\n\nReturns'
    str_7 = 'Summary\n\n\nReturns\n\n\n'
    str_8 = 'Summary\n\nReturns\n\n\n'
    str_9 = 'Summary\n\nreturns'
    str_10 = 'Summary\n\nReturnss'
    str_11 = 'Summary\n\nReturn'
    str_12 = 'Summary\n\nRaises'

# Generated at 2022-06-25 16:36:32.302448
# Unit test for function parse
def test_parse():
    assert parse('') == None # AssertionError: assert None == None


# Generated at 2022-06-25 16:36:40.181107
# Unit test for function parse
def test_parse():
    str_1 = "Function docstring example"
    assert parse(str_1) == None
    str_2 = "Function docstring example\n"
    assert parse(str_2) == None
    str_3 = "Function docstring example\n\n"
    assert parse(str_3) == None
    str_4 = "Function docstring example\n\n:param str_1: parameter 1\n:returns: return value\n"
    assert parse(str_4) == None

    str_5 = "Function docstring example"
    assert parse(str_5) == None
    str_6 = "Function docstring example\n"
    assert parse(str_6) == None
    str_7 = "Function docstring example\n\n"
    assert parse(str_7) == None
    str_8

# Generated at 2022-06-25 16:36:42.087129
# Unit test for function parse
def test_parse():
    str_0 = 'None'
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    return docstring_0.short_description


# Generated at 2022-06-25 16:36:55.795228
# Unit test for function parse
def test_parse():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test_dir', type=str, required=True,
                        help='path to test cases')
    args = parser.parse_args()
    test_dir = args.test_dir

    test_cases = []

    for file_name in os.listdir(test_dir):
        if file_name.endswith('.py'):
            test_cases.append(file_name)

    for test_case in test_cases:
        # create output directory if not exists
        output_dir = os.path.join('tests/results', test_case)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        test_file = os.path.join(test_dir, test_case)


# Generated at 2022-06-25 16:37:00.918557
# Unit test for function parse
def test_parse():

    # Example 1.
    docstring_1 = """Summary line.

Description of the multiline
description.

Args:
  arg1: Description of arg1

      arg1 accepts a long description documented on multiple lines
      like this.

  arg2: Description of arg2

      arg2 accepts a long description documented on multiple lines
      like this.

Returns:
  Description of return value.

Raises:
  AnError: This error is raised if ...
  AnotherError: This error is raised if ...

"""
    assert parse(docstring_1).summary == 'Summary line.'
    assert parse(docstring_1).description == 'Description of the multiline\ndescription.'
    assert parse(docstring_1).params['arg1'].arg_name == 'arg1'

# Generated at 2022-06-25 16:37:08.674446
# Unit test for function parse
def test_parse():
    str_0 = 'param: int: The parameter to use.'
    style_0 = None
    docstring_0 = parse(str_0)
    try:
        assert (docstring_0.params[0].name == 'param')
        assert (docstring_0.params[0].type_name == 'int')
        assert (docstring_0.params[0].description == 'The parameter to use.')
    except:
        print('Expected:', docstring_0.params[0].name, 'int', 'The parameter to use.')
        print('Actual:', 'param', docstring_0.params[0].type_name, docstring_0.params[0].description)
    str_1 = 'a: int: testing\nb: int: second one\n'
    style_1 = None
    doc

# Generated at 2022-06-25 16:37:10.646193
# Unit test for function parse
def test_parse():
    assert parse('mytest') == None

test_parse()
test_case_0()

# Generated at 2022-06-25 16:37:18.512302
# Unit test for function parse
def test_parse():
    text_0 = """
    """
    style_0 = Style.NUMPY
    docstring_0 = parse(text_0, style_0)

    text_1 = """
    """
    style_1 = Style.NUMPY
    docstring_1 = parse(text_1, style_1)

    text_2 = """
    """
    style_2 = Style.NUMPY
    docstring_2 = parse(text_2, style_2)

    text_3 = """
    """
    style_3 = Style.NUMPY
    docstring_3 = parse(text_3, style_3)

    text_4 = """
    """
    style_4 = Style.NUMPY
    docstring_4 = parse(text_4, style_4)

    text_5 = """
    """

# Generated at 2022-06-25 16:37:19.588699
# Unit test for function parse
def test_parse():
    assert parse(str_0, style_0) == docstring_0

# Generated at 2022-06-25 16:37:31.329453
# Unit test for function parse
def test_parse():
    text_0 = """
    This is a module docstring!

    This is a multiline string.
    This is a multiline string.

    This is a multiline string.
    This is a multiline string.
    """
    style_0 = None
    docstring_0 = parse(text_0, style_0)
    # This is a module docstring!
    summary = docstring_0.summary
    # This is a multiline string.
    # This is a multiline string.

    # This is a multiline string.
    # This is a multiline string.
    description = docstring_0.description
    # This is a module docstring!
    summary_check = "This is a module docstring!"
    assert(summary == summary_check)
    # This is a multiline

# Generated at 2022-06-25 16:37:38.251959
# Unit test for function parse
def test_parse():
    import sys
    import inspect
    import json
    import traceback
    # Initialize the test case input data
    text_0 = None
    style_0 = docstring_parser.styles.Style.auto
    text_1 = """This is a sample docstring.
    It has two paragraphs. The second one
    is empty."""
    style_1 = docstring_parser.styles.Style.auto
    text_2 = """Exceptions raised as a result of invalid types or
            values passed to parameters of API methods will be
            converted to ``ValueError`` or one of its
            descendants. Note that this includes exceptions from
            underlying libraries, such as ``TensorFlow``."""
    style_2 = docstring_parser.styles.Style.auto
    arg_0 = text_0
    arg_1 = style_0

# Generated at 2022-06-25 16:37:39.545552
# Unit test for function parse
def test_parse():
    test_case_0()

# Run the unit tests
test_parse()

# Generated at 2022-06-25 16:37:50.193426
# Unit test for function parse
def test_parse():
    str_0 = """Summary line.

Extended description.

:param int a: Parameter a
:param int b: Parameter b
:returns: Return value
:raises ValueError: On invalid input
    """
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 'Summary line.'
    assert docstring_0.description == 'Extended description.'
    assert docstring_0.params['a'].description == 'Parameter a'
    assert docstring_0.params['a'].type_name == 'int'
    assert docstring_0.params['a'].optional == False
    assert docstring_0.params['b'].description == 'Parameter b'
    assert docstring_0.params['b'].type_name == 'int'
    assert docstring_0.params

# Generated at 2022-06-25 16:38:07.088060
# Unit test for function parse
def test_parse():
    assert callable(parse), "Function <parse> not defined"

    str_1 = "class Calculator(object):\n\tdef add(self, a, b):\n\t\t\"\"\"Adds two numbers\n\t\t\n\t\tArgs:\n\t\t\ta (int): first argument\n\t\t\tb (int): second argument\n\t\t\t\n\t\tReturns:\n\t\t\tint: The sum of the two numbers\n\t\t\"\"\"\n\t\treturn a + b\n\t"
    docstring_0 = parse(str_1)
    assert docstring_0.meta['summary'] == 'Adds two numbers', "Summary incorrect: {}".format(docstring_0.meta['summary'])

# Generated at 2022-06-25 16:38:18.676954
# Unit test for function parse
def test_parse():
    assert callable(parse)
    str_0 = """
    This is a docstring
    """
    docstring_0 = parse(str_0)
    str_1 = """
    This is a docstring
    """
    docstring_1 = parse(str_1, Style.numpy)
    assert [docstring_0, docstring_1] == parse(str_0, Style.numpy)
    assert [docstring_0, docstring_1] == parse(str_1)
    assert [docstring_0, docstring_1] == parse(str_1, Style.google)
    str_2 = """
    This is a docstring
    """
    docstring_2 = parse(str_2, Style.google)

# Generated at 2022-06-25 16:38:21.241639
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Unittest for function test_case_0

# Generated at 2022-06-25 16:38:30.059498
# Unit test for function parse
def test_parse():
    assert docstring_0.short_description == "Test case."
    assert docstring_0.long_description == ""
    assert docstring_0.returns == None
    assert len(docstring_0.params) == 0
    assert len(docstring_0.exceptions) == 0
    str_1 = "Test case."
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Test case."
    assert docstring_1.long_description == ""
    assert docstring_1.returns == None
    assert len(docstring_1.params) == 0
    assert len(docstring_1.exceptions) == 0
    str_2 = "Test case.\n    \n    More details."
    docstring_2 = parse(str_2)
    assert docstring

# Generated at 2022-06-25 16:38:41.874529
# Unit test for function parse
def test_parse():
    str_0 = "This is a sample string"
    style_0 = 0
    parse(str_0, style=style_0)
    str_1 = 'TODO'
    style_1 = 1
    parse(str_1, style=style_1)
    str_2 = 'TODO'
    style_2 = 2
    parse(str_2, style=style_2)
    str_3 = 'TODO'
    style_3 = 3
    parse(str_3, style=style_3)
    str_4 = 'TODO'
    style_4 = 4
    parse(str_4, style=style_4)
    str_5 = 'TODO'
    style_5 = 5
    parse(str_5, style=style_5)

# Generated at 2022-06-25 16:38:44.608275
# Unit test for function parse
def test_parse():
    style = Style.google
    text = None
    docstring = parse(text, style)



# Generated at 2022-06-25 16:38:55.122799
# Unit test for function parse
def test_parse():
    str_0 = "metavar1 : type1\nmetavar2 : type2\n:param metavar1:\n param_desc1\n:param metavar2:\n param_desc2\n:return:\n return_desc1\n return_desc2"
    str_1 = ":param metavar1:\n param_desc1\n:param metavar2:\n param_desc2\n:return:\n return_desc1\n return_desc2\nmetavar1 : type1\nmetavar2 : type2"
    str_2 = ":param metavar1:\n param_desc1"

# Generated at 2022-06-25 16:38:57.426673
# Unit test for function parse
def test_parse():
    assert callable(parse), "Function 'parse' not defined"

# Generated at 2022-06-25 16:39:07.286310
# Unit test for function parse
def test_parse():
    str_0 = 'A test case.\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'A test case.'
    str_1 = 'A test case.'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'A test case.'
    str_2 = "A test case.\n\nArgs:\narg1 (str): The first argument.\n\nReturns:\nNone"
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'A test case.'
    assert docstring_2.long_description == ''
    assert docstring_2.returns == 'None'
    assert len(docstring_2.args) == 1

# Generated at 2022-06-25 16:39:14.328175
# Unit test for function parse
def test_parse():
    # Check docstring_parser.parser.parse.
    str_0 = '          \n'
    docstring_0 = parse(str_0)
    str_1 = '\n'
    docstring_1 = parse(str_1)
    str_2 = '    """\n    Foo bar.\n    """\n'
    docstring_2 = parse(str_2)
    str_3 = '::\n\n\n  Foo bar.\n'
    docstring_3 = parse(str_3)
    str_4 = '.. [#] Test\nTest\n'
    docstring_4 = parse(str_4)
    str_5 = ' Test\n Test\n\n'
    docstring_5 = parse(str_5)


# Generated at 2022-06-25 16:39:22.709917
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    style_0 = Style.google

    with pytest.raises(Exception):
        parse(str_0, style_0)

# Generated at 2022-06-25 16:39:26.358788
# Unit test for function parse
def test_parse():
    assert 0 == 0


# Generated at 2022-06-25 16:39:30.091743
# Unit test for function parse
def test_parse():
    text = """bla bla bla,
        123 abc xyz
        """
    style = Style.google
    ds = parse(text, style)
    assert ds.short_description == "bla bla bla,"
    assert ds.long_description == "123 abc xyz"


# Generated at 2022-06-25 16:39:37.657171
# Unit test for function parse
def test_parse():
    # Function Setup
    str_0 = ""

    # Test Cases

    # Function Test 1
    assert docstring_0 == docstring_0
    assert docstring_0.short_description == ""
    assert docstring_0.long_description == ""
    assert docstring_0.meta == dict()
    assert docstring_0.params == dict()
    assert docstring_0.returns == None
    assert docstring_0.returns_annotation == None
    assert docstring_0.raises == dict()
    assert docstring_0.yields == None
    assert docstring_0.yields_annotation == None
    assert docstring_0.style == Style.auto

    # Function Test 2

# Generated at 2022-06-25 16:39:48.069151
# Unit test for function parse
def test_parse():
    str_0 = '''Create a new database in the file "my_db.sqlite"
    
    :param file: database file path
    :param journal_mode: Journal mode of the database
    :returns: Connection object or None if database was opened successfully
    '''
    docstring_0 = parse(str_0)
    assert docstring_0.title == 'Create a new database in the file "my_db.sqlite"'
    assert docstring_0.body == ''
    assert docstring_0.meta == {'param': ['file', 'database file path', 'journal_mode', 'Journal mode of the database'], 'returns': ['Connection object or None if database was opened successfully']}


# Generated at 2022-06-25 16:39:49.090065
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:39:52.209076
# Unit test for function parse
def test_parse():
    style = Style.google
    text = '''
    this is content
    '''
    foo = parse(text)

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:03.661528
# Unit test for function parse
def test_parse():
    str_0 = str('''
            Short summary. Longer description.

            Args:
                param1 (int): Description of `param1`
                param2 (:obj:`str`, optional): Description of `param2`

            Returns:
                bool: Description of return value

            ''')
    docstring_0 = parse(str_0)
    str_1 = str('''
            Short summary. Longer description.
            More.

            Args:
                param1 (int): Description of `param1`
                param2 (:obj:`str`, optional): Description of `param2`

            Returns:
                bool: Description of return value

            ''')
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:40:06.811046
# Unit test for function parse
def test_parse():
    try:
        test_case_0() 
    except Exception as E:
        print(E)
    print('test_parse done')

print('main.py started')
test_parse()
print('main.py done')

# Generated at 2022-06-25 16:40:14.800920
# Unit test for function parse
def test_parse():
    check_ast = False
    # Check lines below for a detailed AST of this part of the code
    if check_ast:
        import ast
        import inspect
        from pprint import pprint
        pprint(ast.dump(ast.parse(inspect.getsource(parse))))

    # Test function call with arguments
    str_0 = None
    docstring_0 = parse(str_0)


if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:20.471597
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:40:31.164649
# Unit test for function parse
def test_parse():
    str_0 = ""
    docstring_0 = parse(str_0)
    assert str_0 == docstring_0.short_description

    str_1 = """ class Test(object):
        """
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.returns == None
    assert docstring_1.params == None
    assert docstring_1.examples == None
    assert docstring_1.meta == None
    assert docstring_1.returns_desc == None

    str_2 = """class Test(object):
        """
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == None
    assert docstring_2.long_

# Generated at 2022-06-25 16:40:41.141720
# Unit test for function parse
def test_parse():
    docstring_1 = parse("Takes two numbers and returns their sum.\n"
                        "Arguments:\n"
                        "  x: A number\n"
                        "  y: Another number\n"
                        "Returns:\n"
                        "  The sum of the two numbers.")
    docstring_2 = parse("Takes two numbers and returns their sum.\n"
                        "Arguments:\n"
                        "  x: A number\n"
                        "  y: Another number\n"
                        "Returns:\n"
                        "  The sum of the two numbers.", style=Style.google)


# Generated at 2022-06-25 16:40:53.135477
# Unit test for function parse
def test_parse():
    # Input parameters
    text_0 = None
    style_0 = None
    docstring_0 = parse(text_0, style_0)
    assert docstring_0 == None
    # Output: Docstring(meta={}, summary=None, description=None, extras=[], returns=None)

    text_1 = None
    style_1 = None
    docstring_1 = parse(text_1, style_1)
    assert docstring_1 == None
    # Output: Docstring(meta={}, summary=None, description=None, extras=[], returns=None)

    text_2 = None
    style_2 = None
    docstring_2 = parse(text_2, style_2)
    assert docstring_2 == None
    # Output: Docstring(meta={}, summary=None, description=None, extras=[], returns

# Generated at 2022-06-25 16:40:54.579402
# Unit test for function parse
def test_parse():
    assert callable(parse)
    print("Test for function parse:pass!")

# Generated at 2022-06-25 16:41:04.757479
# Unit test for function parse
def test_parse():
    # Test cases
    str_0 = None
    docstring_0 = parse(str_0)
    str_1 = 'Docstring created with docstring_parser.parser.parse()'
    docstring_1 = parse(str_1)
    str_2 = 'Docstring created with docstring_parser.parser.parse(str, style)'
    docstring_2 = parse(str_2)
    str_3 = 'Docstring created with docstring_parser.parser.parse(str, style)'
    docstring_3 = parse(str_3)
    str_4 = 'Docstring created with docstring_parser.parser.parse(str, style)'
    docstring_4 = parse(str_4)
    str_5 = 'Docstring created with docstring_parser.parser.parse(str, style)'
    docstring_5

# Generated at 2022-06-25 16:41:08.782518
# Unit test for function parse
def test_parse():
    func_args = []
    res_expected = None
    res = parse(*func_args)

    assert res == res_expected

test_parse()

# Generated at 2022-06-25 16:41:19.640556
# Unit test for function parse
def test_parse():
  docstring_0 = parse('This is a module docstring')
  assert docstring_0 == Docstring(summary='This is a module docstring',
                                  description=None,
                                  returns=None,
                                  yield_=None,
                                  raises=None,
                                  see_also=None,
                                  examples=None,
                                  metadata={})

  str_0 = None
  docstring_0 = parse(str_0)
  assert docstring_0 == Docstring(summary=None,
                                  description=None,
                                  returns=None,
                                  yield_=None,
                                  raises=None,
                                  see_also=None,
                                  examples=None,
                                  metadata={})
  str_0 = 'This is a module docstring\n'

# Generated at 2022-06-25 16:41:20.767540
# Unit test for function parse
def test_parse():
    assert (parse('a, b') is not None)


# Generated at 2022-06-25 16:41:25.508944
# Unit test for function parse
def test_parse():
	# Test cases for parse
    test_case_0()
    # Test case for exceptions when method is not implemented
    try:
        class DummyClass:
            def method(self):
                pass
        dummy_instance = DummyClass()
        dummy_instance.method()
    except NotImplementedError as e:
        print(e)

# Generated at 2022-06-25 16:41:32.032998
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:41:36.180141
# Unit test for function parse
def test_parse():
  is_raises_exception = False
  try:
    call_0 = parse(str_0)
  except:
    is_raises_exception = True
  assert is_raises_exception

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:41:39.319048
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    if docstring_0 != None:
        print('Error at line 5: expected: {}, actual: {}'.format(None, docstring_0))

test_parse()

# Generated at 2022-06-25 16:41:49.368913
# Unit test for function parse
def test_parse():
    import sys
    import os
    import random
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    def parse(text: str, style: Style = Style.auto) -> Docstring:
        """Parse the docstring into its components.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """

        if style != Style.auto:
            return STYLES[style](text)
        rets = []
        for parse_ in STYLES.values():
            try:
                rets.append(parse_(text))
            except ParseError as e:
                exc = e
        if not rets:
            raise exc

# Generated at 2022-06-25 16:41:53.879865
# Unit test for function parse
def test_parse():
    docstring_0 = parse(None)
    assert docstring_0 == {'params': {'text': None}, 'returns': {}, 'summary': None}
    docstring_1 = parse('test')
    assert docstring_1 == {'params': {'text': 'test'}, 'returns': {}, 'summary': None}



# Generated at 2022-06-25 16:42:02.968459
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = Style.auto
    docstring_0 = parse(str_0, style_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert len(docstring_0.params) == 0
    assert len(docstring_0.returns) == 0
    assert len(docstring_0.exceptions) == 0
    assert len(docstring_0.meta) == 0
    str_1 = '\n'
    style_1 = Style.auto
    docstring_1 = parse(str_1, style_1)
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert len(docstring_1.params) == 0

# Generated at 2022-06-25 16:42:14.473350
# Unit test for function parse
def test_parse():
    str_1 = "This is a short description\n\nThis is a long description\n\n:param int b: This is a long description for parameter b\n:type b: int\n:param array_like c: This is a long description for parameter c\n:type c: array_like\n:raises ValueError: if b < 0\n:returns: a + b + c\n:rtype: int"

# Generated at 2022-06-25 16:42:26.109123
# Unit test for function parse
def test_parse():
    assert parse('foo\n---\nbar\n') == parse('foo\n========\nbar\n')
    assert parse('\nfoo\nbar\n') == parse('\nfoo\nbar\n')
    assert parse('\nfoo\nbar\n') == parse('\nfoo\nbar\n')
    assert parse('foo\n---\nbar\n') == parse('foo\n========\nbar\n')
    assert parse('\nfoo\nbar\n') == parse('\nfoo\nbar\n')
    assert parse('\nfoo\nbar\n') == parse('\nfoo\nbar\n')
    assert parse('foo\n---\nbar\n') == parse('foo\n========\nbar\n')

# Generated at 2022-06-25 16:42:35.675594
# Unit test for function parse

# Generated at 2022-06-25 16:42:43.761301
# Unit test for function parse
def test_parse():

    from docstring_parser.docstring import Docstring
    style_0 = Style.google
    text_0 = "Summary line.\n\nDescription\n    More detailed description.\n"
    parse_0 = parse(text_0, style_0)
    assert isinstance(parse_0, Docstring)
    assert parse_0.short_description == 'Summary line.'
    assert parse_0.long_description == 'Description\nMore detailed description.\n'
    style_1 = Style.google
    text_1 = "Summary line.\n\nDescription\n    More detailed description.\n\nArgs:\n    arg_1: Description of `arg_1`\n    arg_2: Description of `arg_2`\n"
    parse_1 = parse(text_1, style_1)

# Generated at 2022-06-25 16:42:49.927388
# Unit test for function parse
def test_parse():
    assert True

test_case_0()

# Generated at 2022-06-25 16:42:59.629830
# Unit test for function parse
def test_parse():
    print("START test_parse")

    docstring_0 = parse(None)

    assert docstring_0._text == ""
    assert docstring_0._summary == ""
    assert len(docstring_0._extended) == 0
    assert len(docstring_0._returns) == 0
    assert len(docstring_0._raises) == 0
    assert len(docstring_0._yields) == 0
    assert len(docstring_0._arguments) == 0

    str_0 = ""
    docstring_1 = parse(str_0)

    assert docstring_1._text == ""
    assert docstring_1._summary == ""
    assert len(docstring_1._extended) == 0
    assert len(docstring_1._returns) == 0

# Generated at 2022-06-25 16:43:00.384237
# Unit test for function parse
def test_parse():
    # Check if exception raises
    with raises(Exception):
        test_case_0()

# Generated at 2022-06-25 16:43:01.516384
# Unit test for function parse
def test_parse():
    assert callable(parse)
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:43:02.705802
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:43:12.857907
# Unit test for function parse
def test_parse():
    str_1 = """Hello World"""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Hello World"

    str_2 = """Hello World
    This is a long description
    You should write something here
    """
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == "Hello World"
    assert docstring_2.long_description == str_2

    str_3 = """Hello World
    :param arg1: This is a first argument
    :param arg2: This is a second argument
    :param arg3: This is a third argument
    """
    docstring_3 = parse(str_3)
    assert docstring_3.short_description == "Hello World"

# Generated at 2022-06-25 16:43:23.987360
# Unit test for function parse
def test_parse():
    str_0 = """\
        This is the first line
        and this the second line.

        :param x: A param with a type and a default value
        :type x: int, optional
        :param y: Optional param
        :type y: int, optional
        :param kwargs: Optional keyword args
        :type kwargs: dict, optional
        :returns: Some type
        :rtype: int
        :returns: Something else
        :rtype: int
        """
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:43:31.665630
# Unit test for function parse
def test_parse():
    assert parse('This is a simple function.') == parse('This is a simple function.')
    assert parse('This is a short sentence. This is another short sentence.') == parse('This is a short sentence. This is another short sentence.')
    assert parse('This is a short sentence. And this is a second short sentence.') == parse('This is a short sentence. And this is a second short sentence.')
    assert parse('This is a short sentence. And this is a second short sentence.') == parse('This is a short sentence. And this is a second short sentence.')
    assert parse('This is a short sentence. This is another short sentence.') == parse('This is a short sentence. This is another short sentence.')
    assert parse('This is a short sentence. This is another short sentence.') == parse('This is a short sentence. This is another short sentence.')