

# Generated at 2022-06-25 16:33:40.963726
# Unit test for function parse
def test_parse():
    str_0 = 'Test mail from mail sender'
    str_1 = (
        'encode data and create a new message.\n'
        '\n'
        '    :param data: input data\n'
        '    :type data: bytes\n'
        '    :returns: message instance\n'
        '    :rtype: :py:class:`email.message.Message`\n'
    )

# Generated at 2022-06-25 16:33:51.776844
# Unit test for function parse
def test_parse():
    # set up test cases
    test_cases = [
        # TODO add more test cases
        # (expected, input)
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
        (None, '|'),
    ]

    # run test cases
    tested = 0
    passed

# Generated at 2022-06-25 16:33:59.243073
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse

    # Sub Case 0
    str_0 = '|'
    docstring_0 = parse(str_0)
    assert docstring_0 is not None
    assert len(docstring_0.get_meta()) == 0

    # Sub Case 1
    str_1 = '| Hello, world! I am using | docstring_parser |.\n|'
    docstring_1 = parse(str_1)
    assert docstring_1 is not None
    assert len(docstring_1.get_meta()) == 0

    # Sub Case 2
    str_2 = '| Hello, world! I am using | docstring_parser |.\n|\n| Summary line\n|\n| Extended description\n|'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:34:02.132342
# Unit test for function parse
def test_parse():
    str_0 = '|'
    assert parse('|')

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:34:11.740268
# Unit test for function parse
def test_parse():
    # Setup
    str_0 = '| '
    str_1 = '|'
    str_2 = '| options: '
    str_3 = '|'
    str_4 = '| -h, --help show this help message and exit '
    str_5 = '| -c CONFIG, --config CONFIG '
    str_6 = '|              custom path to config file '
    str_7 = '|'
    # Expected result
    text_expected = '\n'.join([str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7])
    # Actual result
    actual = parse(text_expected)
    # Validation
    assert actual.get_text() == text_expected, 'Please check the implementation of function parse'

# Unit test

# Generated at 2022-06-25 16:34:14.371148
# Unit test for function parse
def test_parse():
    str_0 = '|'
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring)


# Generated at 2022-06-25 16:34:17.740448
# Unit test for function parse
def test_parse():
    assert callable(parse), 'Function "parse" is not callable'
    # Test cases
    test_case_0()

# Generated at 2022-06-25 16:34:20.825118
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:34:29.896442
# Unit test for function parse
def test_parse():
    str_0 = '|'
    docstring_0 = parse(str_0)
    assert (docstring_0.short_desc is None)
    assert (docstring_0.long_desc is None)
    assert (docstring_0.meta is None)
    assert (docstring_0.content is None)
    assert (docstring_0.sections == [])
    str_1 = '|\n'
    docstring_1 = parse(str_1)
    assert (docstring_1.short_desc is None)
    assert (docstring_1.long_desc is None)
    assert (docstring_1.meta is None)
    assert (docstring_1.content is None)
    assert (docstring_1.sections == [])
    str_2 = '|\r'
    docstring_

# Generated at 2022-06-25 16:34:31.625409
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:34:40.906835
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:34:47.953294
# Unit test for function parse
def test_parse():

    # Setup
    text = 'Function "parse" is not callable'
    style = Style.auto

    # Exercise
    ret = parse(text, style)

    # Verify
    assert ret == 'Function "parse" is not callable'
    assert ret != 'Function "parse" is callable'

    # Teardown
    pass

# Generated at 2022-06-25 16:34:49.533932
# Unit test for function parse
def test_parse():
    print("Test: function parse")
    test_case_0()


# Generated at 2022-06-25 16:34:56.444008
# Unit test for function parse
def test_parse():
    # TODO: Test docstrings with different style
    str_test_0 = '''This function parses the docstring.

    Args:
        text (str): docstring text to parse
        style (:obj:`Style`, optional): docstring style, defaults to
            :obj:`Style.auto`

    Returns:
        :obj:`Docstring`: parsed docstring representation
    '''
    result = parse(str_test_0)
    assert result.params == {"text": {"type": "str", "desc": "docstring text to parse"}, "style": {"type": "obj:`Style`", "desc": "docstring style, defaults to\n            :obj:`Style.auto`"}}
    assert result.summary == "This function parses the docstring."
    assert result.description == ""
    assert result.meta

# Generated at 2022-06-25 16:35:02.148449
# Unit test for function parse
def test_parse():
    db_0 = parse(str_0)

# Generated at 2022-06-25 16:35:11.426514
# Unit test for function parse
def test_parse():
    # assert(isinstance(parse('Function "parse" is not callable'), Docstring))
    assert(isinstance(parse('Function "parse" is not callable'), Docstring))
    assert(isinstance(parse('Function "parse" is not callable'), Docstring))
    assert(isinstance(parse('Function "parse" is not callable'), Docstring))
    assert(isinstance(parse('Function "parse" is not callable'), Docstring))
    assert(isinstance(parse('Function "parse" is not callable'), Docstring))
    assert(isinstance(parse('Function "parse" is not callable'), Docstring))
    assert(isinstance(parse('Function "parse" is not callable'), Docstring))
    assert(isinstance(parse('Function "parse" is not callable'), Docstring))

# Generated at 2022-06-25 16:35:14.250616
# Unit test for function parse
def test_parse():
    # docstring_parser.parse is implemented using builtin function len, but len is not callable here
    # assert docstring_parser.parse(str_0) == 'Function "parse" is not callable'
    print("test_parse ran")

# Generated at 2022-06-25 16:35:18.977259
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:35:29.550949
# Unit test for function parse
def test_parse():
    print("Test Case 0: ", end = '')
    str_0 = """Function "parse" is not callable"""
    print(parse(str_0) == "Function \"parse\" is not callable")

    print("Test Case 1: ", end = '')
    str_1 = """Function "parse" is not callable"""
    print(parse(str_1) == "Function \"parse\" is not callable")

    print("Test Case 2: ", end = '')
    str_2 = """Function "parse" is not callable"""
    print(parse(str_2) == "Function \"parse\" is not callable")

    print("Test Case 3: ", end = '')
    str_3 = """Function "parse" is not callable"""
    print(parse(str_3) == "Function \"parse\" is not callable")

# Generated at 2022-06-25 16:35:35.829461
# Unit test for function parse
def test_parse():
    # Test for case
    test_case_0()
    str_1 = 'Parse the docstring into its components.\n\n    :retur n s:\n        parsed docstring representation'

    # Test function
    doc2 = parse(str_1)
    print(doc2)
    return

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:35:43.300894
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except Exception as e:
        print("Catch Error: {}, in test_case_0".format(e))

# Main function for test
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:35:48.844277
# Unit test for function parse
def test_parse():
    try:
        parse(str_0)
    except ParseError as e:
        return "Exception raised successfully"



# Generated at 2022-06-25 16:35:51.389861
# Unit test for function parse
def test_parse():
    expected = 'Function "parse" is not callable'
    actual = parse()
    assert(actual != expected)

# Generated at 2022-06-25 16:35:51.901034
# Unit test for function parse
def test_parse():
    result = parse()

# Generated at 2022-06-25 16:35:53.215101
# Unit test for function parse
def test_parse():
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:35:54.761082
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-25 16:35:59.265860
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    str_0 = "Function parse is not callable!"
    assert parse(str_0) == ParseError(str_0)



# Generated at 2022-06-25 16:36:00.300056
# Unit test for function parse
def test_parse():
    print("Test Case 0 for parse")
    test_case_0()
    print("Test Case 0 passed")

# Generated at 2022-06-25 16:36:01.113641
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-25 16:36:02.734983
# Unit test for function parse
def test_parse():
    test_case_0()
    assert 1 == 1


# Generated at 2022-06-25 16:36:16.453259
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    from docstring_parser.parser import parse
    str_0 = '|'
    style_0 = Style.auto
    assert parse(str_0, style_0) == Docstring(description='', content=[])
    style_1 = Style.numpy
    assert parse(str_0, style_1) == Docstring(description='', content=[])
    style_2 = Style.google
    assert parse(str_0, style_2) == Docstring(description='', content=[])
    style_3 = Style.sphinx
    assert parse(str_0, style_3) == Docstring(description='', content=[])
    style_4 = Style.epytext

# Generated at 2022-06-25 16:36:23.885368
# Unit test for function parse
def test_parse():
    str_0 = '|'
    docstring_0 = parse(str_0)

    assert docstring_0.summary == None
    # assert docstring_0.extended_summary == None
    assert docstring_0.body == None
    # assert docstring_0.returns == None
    assert docstring_0.style == Style.reST
    assert docstring_0.errors == None


# Code fragment for testing docstring_parser.parse

# Generated at 2022-06-25 16:36:27.585064
# Unit test for function parse
def test_parse():
    # Assert an exception is raised for invalid docstring
    try:
        docstring_0 = parse(str_0)
    except ParseError:
        pass
    else:
        raise AssertionError


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 16:36:38.932375
# Unit test for function parse
def test_parse():
    assert parse("This is a module summary") == Docstring(summary="This is a module summary", parameters=[], returns=None, raises=[], warnings=[], notes=[], meta=[])
    assert parse("This is a module summary\n") == Docstring(summary="This is a module summary", parameters=[], returns=None, raises=[], warnings=[], notes=[], meta=[])
    assert parse("This is a module summary\n\n") == Docstring(summary="This is a module summary", parameters=[], returns=None, raises=[], warnings=[], notes=[], meta=[])
    assert parse("This is a module summary\n\nThis is a module description") == Docstring(summary="This is a module summary", description="This is a module description", parameters=[], returns=None, raises=[], warnings=[], notes=[], meta=[])

# Generated at 2022-06-25 16:36:47.175425
# Unit test for function parse
def test_parse():
    str_0 = """
    |
    """
    docstring_0 = parse(str_0)
    str_1 = '| Hello world!'
    docstring_1 = parse(str_1)
    str_2 = """
    |   
    | This is a test case for the `parse` function.
    |
    | **Keyword arguments:**
    |   str -- the string to be parsed
    |   
    | **Returns:**
    |     A parsed Document Object
    """
    docstring_2 = parse(str_2)
    print(docstring_2)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:36:53.085533
# Unit test for function parse
def test_parse():
    str_0 = 'name:   Sphinx Extensions API\ndesc: |\n    This package provides the core infrastructure for the Sphinx\n    extensions mechani'
    docstring_0 = parse(str_0)
    assert len(docstring_0.params) == 0
    str_1 = 'docs/source/conf.py\ndescription: |\n   This is the configuration file for Sphinx documentation.\n'
    docstring_1 = parse(str_1)
    assert docstring_1.params[0].name == 'docs/source/conf.py'
    assert docstring_1.params[0].type_name == 'file'
    assert docstring_1.params[0].desc == 'This is the configuration file for Sphinx documentation.'

# Generated at 2022-06-25 16:37:03.060024
# Unit test for function parse
def test_parse():
    str_0 = "A simple docstring"
    str_1 = "A simple docstring\nWith a second line"
    str_2 = "A simple docstring\r\nWith a second line"
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    docstring_2 = parse(str_2)

    return docstring_0.short_description == "A simple docstring" \
           and docstring_1.short_description == "A simple docstring" \
           and docstring_2.short_description == "A simple docstring"

if __name__ == '__main__':
    if not test_parse():
        print("test_parse failed")
        exit(1)
    print("All tests passed")

# Generated at 2022-06-25 16:37:13.489194
# Unit test for function parse
def test_parse():
    result_0 = parse('|')
    assert isinstance(result_0, Docstring)
    assert result_0.summary == ''
    assert result_0.returns == None
    assert result_0.params == {}
    assert result_0.examples == []
    assert result_0.meta == {}
    assert result_0.meta_formatted == ''

    result_1 = parse('\n')
    assert isinstance(result_1, Docstring)
    assert result_1.summary == ''
    assert result_1.returns == None
    assert result_1.params == {}
    assert result_1.examples == []
    assert result_1.meta == {}
    assert result_1.meta_formatted == ''

# Generated at 2022-06-25 16:37:15.215340
# Unit test for function parse
def test_parse():
    test_case_0()


# Main
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:37:28.469681
# Unit test for function parse
def test_parse():
    # Parse
    assert ( '|name|DESCRIPTION|'==Docstring.parse('|name|DESCRIPTION|') )
    assert ( '|name|DESCRIPTION|'==Docstring.parse('|name|DESCRIPTION|') )
    assert ( '|name|DESCRIPTION|'==Docstring.parse('|name|DESCRIPTION|') )
    assert ( '|name|DESCRIPTION|'==Docstring.parse('|name|DESCRIPTION|') )
    assert ( '|name|DESCRIPTION|'==Docstring.parse('|name|DESCRIPTION|') )
    assert ( '|name|DESCRIPTION|'==Docstring.parse('|name|DESCRIPTION|') )
    assert ( '|name|DESCRIPTION|'==Docstring.parse('|name|DESCRIPTION|') )

# Generated at 2022-06-25 16:37:33.820873
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-25 16:37:41.545569
# Unit test for function parse
def test_parse():
    assert str(parse('|')) == 'Docstring([Section(name=Summary, content=None, content_offset=0, params=None)])'
    assert str(parse('|This is a short summary')) == 'Docstring([Section(name=Summary, content=This is a short summary, content_offset=0, params=None)])'
    assert str(parse('|This is a short summary\n|that has two lines')) == 'Docstring([Section(name=Summary, content=This is a short summary\nthat has two lines, content_offset=0, params=None)])'

# Generated at 2022-06-25 16:37:44.590385
# Unit test for function parse
def test_parse():
    testcase_0()

# Compiled implementation
from docstring_parser.styles import STYLES, Style
_hax_parsing_result_0 = None

# Generated at 2022-06-25 16:37:54.497495
# Unit test for function parse
def test_parse():
    str_0 = '|'
    assert parse(str_0) == None
    str_1 = '|'
    assert parse(str_1) == None
    str_2 = '|'
    assert parse(str_2) == None
    str_3 = '|'
    assert parse(str_3) == None
    str_4 = '|'
    assert parse(str_4) == None
    str_5 = '|'
    assert parse(str_5) == None
    str_6 = '|'
    assert parse(str_6) == None
    

# Test case to verify that the module can be executed as a script
# from the command line

# Generated at 2022-06-25 16:38:01.230968
# Unit test for function parse
def test_parse():
    try:
        str_0 = '|'
        docstring_0 = parse(str_0)
        if docstring_0 == None:
            print("Pass")
        else:
            print("Fail")
    except:
        print("Fail")
test_parse()



# Generated at 2022-06-25 16:38:14.983732
# Unit test for function parse
def test_parse():

    # test case 0
    str_0 = '|'
    docstring_0 = parse(str_0)

    assert docstring_0.summary is None
    assert docstring_0.short_description is None
    assert docstring_0.long_description == ''
    assert docstring_0.meta == {'index': 0, 'lineno': 0, 'col_offset': 0}

    # test case 1
    str_1 = ':param int foo: Foo parameter'
    docstring_1 = parse(str_1)

    assert docstring_1.summary is None
    assert docstring_1.short_description is None
    assert docstring_1.long_description == ''
    assert docstring_1.meta == {'index': 0, 'lineno': 0, 'col_offset': 0}

    assert docstring_

# Generated at 2022-06-25 16:38:20.990563
# Unit test for function parse
def test_parse():
    str_0 = '|'
    docstring_0 = parse(str_0)
    assert docstring_0.to_str() == '|'
    str_1 = '|\n|\n|'
    docstring_1 = parse(str_1)
    assert docstring_1.to_str() == '|\n|\n|'
    str_2 = '|'
    docstring_2 = parse(str_2)
    assert docstring_2.to_str() == '|'
    str_3 = '|'
    docstring_3 = parse(str_3)
    assert docstring_3.to_str() == '|'
    str_4 = '|\n|'
    docstring_4 = parse(str_4)
    assert docstring_4.to_str

# Generated at 2022-06-25 16:38:21.792264
# Unit test for function parse
def test_parse():
    str_0 = '|'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:38:30.275848
# Unit test for function parse
def test_parse():
    # Example 1:
    str_1 = '''
        """
        Here goes a short description of the function.
        This is a docstring.
        In multiline.
        And spans
        several lines.
        """
        '''
    docstring_1 = parse(str_1)
    assert(isinstance(docstring_1, Docstring))
    assert(docstring_1.short_description == "Here goes a short description of the function.")
    assert(docstring_1.long_description == "This is a docstring.\nIn multiline.\nAnd spans\nseveral lines.")
    assert(docstring_1.style == Style.numpy)

    # Example 2:

# Generated at 2022-06-25 16:38:32.491074
# Unit test for function parse
def test_parse():
    test_case_0()

# Main function to run the unit tests

# Generated at 2022-06-25 16:38:39.887333
# Unit test for function parse
def test_parse():
    doc_parser = DocstringParser()
    doc_parser._params = 'test'
    assert doc_parser.get_params() == 'test'

# Generated at 2022-06-25 16:38:41.958252
# Unit test for function parse
def test_parse():
    assert 1==1

# Generated at 2022-06-25 16:38:50.711456
# Unit test for function parse
def test_parse():
    str_0 = '| This is a test'
    docstring_0 = parse(str_0)
    print(f'test_parse: docstring_0:{docstring_0}')
    str_1 = """| This is a test
    | with a multi-line test
    | with a multi-line test
    | with a multi-line test
    | with a multi-line test
    | with a multi-line test
    | with a multi-line test
    """
    docstring_1 = parse(str_1)
    print(f'test_parse: docstring_1:{docstring_1}')



# Generated at 2022-06-25 16:39:04.138200
# Unit test for function parse
def test_parse():
    str_0 = """\nThis is a docstring.\n"""
    docstring_0 = parse(str_0)

    str_1 = """\n   This is a docstring.\n"""
    docstring_1 = parse(str_1)

    str_2 = """\nThis is a docstring.\n\nArgs:\n  a: The first argument.\n  b: The second argument.\n\nReturns:\n  The return value.\n"""
    docstring_2 = parse(str_2)

    str_3 = """\nThis is a docstring.\n\nParameters\n----------\n  a : The first argument.\n  b : The second argument.\n\nReturns\n-------\n  The return value.\n"""

# Generated at 2022-06-25 16:39:11.192507
# Unit test for function parse
def test_parse():
    str_0 = '|'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    import sys
    import time

    if len(sys.argv) == 1:
        for i in dir():
            if 'test_' in i:
                print('running '+ i)
                globals()[i]()
                print('done\n')
    else:
        globals()[sys.argv[1]]()

# Generated at 2022-06-25 16:39:13.647164
# Unit test for function parse
def test_parse():
    assert parse(str_0) == docstring_0


# Generated at 2022-06-25 16:39:14.761613
# Unit test for function parse
def test_parse():
    test_case_0()
        

# Generated at 2022-06-25 16:39:25.353880
# Unit test for function parse
def test_parse():
    str_0 = """
    This is a docstring.
    """
    docstring_0 = parse(str_0)
    str_1 = """
    This is a docstring.
    """
    docstring_1 = parse(str_1)
    str_2 = """
    This is a docstring.
    """
    docstring_2 = parse(str_2)
    str_3 = """
    This is a docstring.
    """
    docstring_3 = parse(str_3)
    str_4 = """
    This is a docstring.
    """
    docstring_4 = parse(str_4)
    str_5 = """
    This is a docstring.
    """
    docstring_5 = parse(str_5)

# Generated at 2022-06-25 16:39:26.132757
# Unit test for function parse
def test_parse():
    test_case_0()



# Generated at 2022-06-25 16:39:34.344049
# Unit test for function parse
def test_parse():
    str_0 = '|'
    print(parse(str_0))
    str_1 = '|A|A|'
    print(parse(str_1))
    str_2 = '|A|A|\n|A|A|\n|A|A|\n'
    print(parse(str_2))
    str_3 = '|A|A|\n|A|A|\n|A|A|\n|A|A|\n|A|A|\n|A|A|\n|A|A|\n|A|A|\n'
    print(parse(str_3))

# Generated at 2022-06-25 16:39:48.735177
# Unit test for function parse
def test_parse():
    str_0 = '|'
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_0, style=Style.auto)
    docstring_2 = parse(str_0, style=Style.google)
    docstring_3 = parse(str_0, style=Style.numpy)

if __name__ == '__main__':
    test_case_0()
    test_parse()

# ----------------------------------------------------------------------------------------------------------------------
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |
# |

# Generated at 2022-06-25 16:39:57.324538
# Unit test for function parse
def test_parse():
    test_case_0()
    str_0 = '|'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ""
    assert docstring_0.long_description == ""
    assert docstring_0.extended_sections == []

# Generated at 2022-06-25 16:40:04.713047
# Unit test for function parse
def test_parse():

    # Set the style to reStructuredText
    style_0 = Style.reStructuredText
    # Call the function with arguments str_0 and style_0
    parse(str_0, style_0)

    # Set the style to Google
    style_1 = Style.Google
    # Call the function with arguments str_0 and style_1
    parse(str_0, style_1)

    # Set the style to NumPy
    style_2 = Style.NumPy
    # Call the function with arguments str_0 and style_2
    parse(str_0, style_2)

# Generated at 2022-06-25 16:40:15.706289
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = '|'
    docstring_0 = parse(str_0)
    docstring_str_0 = '|'

    # Test case 1
    str_1 = '*'
    docstring_1 = parse(str_1)
    docstring_str_1 = '*'

    # Test case 2
    str_2 = '+'
    docstring_2 = parse(str_2)
    docstring_str_2 = '+'

    # Test case 3
    str_3 = '-'
    docstring_3 = parse(str_3)
    docstring_str_3 = '-'


# ...
# Invalid docstring style 5
# ...
    # Test case 4
    str_4 = '!'
    docstring_4 = parse(str_4)


# Generated at 2022-06-25 16:40:17.726484
# Unit test for function parse
def test_parse():
    assert parse('|') == []


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:25.416263
# Unit test for function parse

# Generated at 2022-06-25 16:40:31.558802
# Unit test for function parse
def test_parse():
    docstring_0 = parse('|')
    docstring_1 = parse('   |')
    docstring_2 = parse('       ')
    docstring_3 = parse('|   ')
    docstring_4 = parse('|')
    docstring_5 = parse('|    ')
    docstring_6 = parse('|')
    docstring_7 = parse('|    ')
    docstring_8 = parse('|')
    docstring_9 = parse('|    ')
    docstring_10 = parse('|')
    docstring_11 = parse('|    ')
    docstring_12 = parse('|')
    docstring_13 = parse('|    ')

# Generated at 2022-06-25 16:40:44.138811
# Unit test for function parse
def test_parse():
    assert(parse("") == Docstring(None, "", "", "", "", "", []))
    assert(parse("hello") == Docstring(None, "", "", "hello", "", "", []))
    assert(parse("hello world") ==
           Docstring(None, "", "", "hello world", "", "", []))
    assert(parse("hello world\n") ==
           Docstring(None, "", "", "hello world\n", "", "", []))
    assert(parse("hello\nworld") ==
           Docstring(None, "", "", "hello\nworld", "", "", []))
    assert(parse("hello\nworld\n") ==
           Docstring(None, "", "", "hello\nworld\n", "", "", []))

# Generated at 2022-06-25 16:40:54.318427
# Unit test for function parse
def test_parse():
    with open('docstring.txt') as f:
        text = f.read()
    docstring = parse(text, style=Style.google)

    assert docstring.short_description == ''
    assert docstring.long_description == ''
    assert docstring.params['test_file'].description == 'Text file to parse into sentences'

    assert 'New line' in docstring.params['test_file'].annotation
    assert docstring.params['test_file'].default == 'None'
    assert docstring.params['test_file'].optional

    assert docstring.params['test_file_2'].description == 'Text file to parse into sentences'
    assert 'New line' in docstring.params['test_file_2'].annotation
    assert docstring.params['test_file_2'].default == 'None'

# Generated at 2022-06-25 16:41:03.124296
# Unit test for function parse
def test_parse():
    text = "test"
    style = Style.google
    docstring_parse = parse(text, style)
    assert(docstring_parse.summary == None)
    assert(docstring_parse.extended_summary == None)
    assert(docstring_parse.body == None)
    assert(docstring_parse.params == [])
    assert(docstring_parse.returns == None)
    assert(docstring_parse.raises == [])
    assert(docstring_parse.other == [])
    assert(docstring_parse.meta == {'title_initials': set(), 'author': set(), 'version': set(), 'see': set()})

# Generated at 2022-06-25 16:41:08.623928
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:41:15.532413
# Unit test for function parse
def test_parse():
    str_0 = '|'
    docstring_0 = parse(str_0)
    str_1 = '|'
    docstring_1 = parse(str_1, Style.marshmallow)
    str_2 = '|'
    docstring_2 = parse(str_2, Style.numpydoc)
    str_3 = '|'
    docstring_3 = parse(str_3, Style.google)
    str_4 = '|'
    docstring_4 = parse(str_4, Style.sphinx)
    str_5 = '|'
    docstring_5 = parse(str_5, Style.auto)
    str_6 = '|'
    docstring_6 = parse(str_6, Style.sphinx)

    # Test raise

# Generated at 2022-06-25 16:41:26.392076
# Unit test for function parse
def test_parse(): 
    assert callable(parse)
    # Test default function call
    str_0 = '|'
    docstring_0 = parse(str_0)
    assert type(docstring_0) == Docstring

    # Test default function call
    str_0 = '|'
    style_0 = Style.numpy
    docstring_0 = parse(str_0, style_0)
    assert type(docstring_0) == Docstring

    # Test default function call
    str_0 = '|'
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    assert type(docstring_0) == Docstring

    # Test default function call
    str_0 = '|'
    style_0 = Style.sphinx

# Generated at 2022-06-25 16:41:36.804556
# Unit test for function parse
def test_parse():
    import numpy
    str_0 = """
    | Parameter: input -- The input argument.
    """
    docstring_0 = parse(str_0)
    str_1 = """
    |
    | Algorithm: Recursive
    |
    | Complexity: O(2^n)
    """
    docstring_1 = parse(str_1)
    str_2 = """
    Args:
        param1: The first parameter.
        param2: The second parameter.

    Returns:
        True if successful, False otherwise.

    """
    docstring_2 = parse(str_2)
    str_3 = """
        :param param1: The first parameter.
        :param param2: The second parameter.
        :returns: True if successful, False otherwise.
    """

# Generated at 2022-06-25 16:41:47.271750
# Unit test for function parse
def test_parse():
    str_0 = '|'
    docstring_0 = parse(str_0)
    assert docstring_0.return_annotation == None
    assert docstring_0.yield_annotation == None
    assert docstring_0.long_summary == None
    assert docstring_0.short_summary == None
    assert docstring_0.body == '|'
    assert docstring_0.meta == {}
    assert docstring_0.parameters == []
    assert docstring_0.examples == []
    assert docstring_0.yields == []
    assert docstring_0.see_also == []
    assert docstring_0.notes == []
    assert docstring_0.warnings == []
    assert docstring_0.raises == []
    assert docstring_0.attributes == []
   

# Generated at 2022-06-25 16:41:53.322705
# Unit test for function parse
def test_parse():
    func_0 = '''
    """
    - 0, 1, 2
    - 3, 4
    """
    '''
    docstring_0 = parse(func_0)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == '- 0, 1, 2\n- 3, 4\n'
    assert docstring_0.params == OrderedDict([])
    assert docstring_0.returns == None
    assert docstring_0.meta == OrderedDict([])
    func_1 = '''
    """
    0, 1, 2
    3, 4
    """
    '''
    docstring_1 = parse(func_1)
    assert docstring_1.short_description == '0, 1, 2'

# Generated at 2022-06-25 16:41:54.536101
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:41:56.868944
# Unit test for function parse
def test_parse():
    print('Testing docstring_parser 0.1')
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:42:04.071033
# Unit test for function parse

# Generated at 2022-06-25 16:42:16.119167
# Unit test for function parse
def test_parse():
    docstring_0 = parse('')
    assert docstring_0.signature is None
    assert str(docstring_0.summary) == 'None'
    assert docstring_0.extended_summary == ''
    assert len(docstring_0.params) == 0
    assert len(docstring_0.returns) == 0
    assert len(docstring_0.raises) == 0
    docstring_1 = parse('\nHello World\n')
    assert docstring_1.signature is None
    assert str(docstring_1.summary) == 'None'
    assert docstring_1.extended_summary == 'Hello World'
    assert len(docstring_1.params) == 0
    assert len(docstring_1.returns) == 0
    assert len(docstring_1.raises)

# Generated at 2022-06-25 16:42:25.935163
# Unit test for function parse
def test_parse():
    str_0 = '| key: value\n'
    docstring_0 = parse(str_0)
    assert docstring_0.meta['key'] == 'value'

    str_1 = '| key: value\n| foo: bar\n'
    docstring_1 = parse(str_1)
    assert set(docstring_1.meta.keys()) == {'key', 'foo'}
    assert docstring_1.meta['key'] == 'value'

    str_2 = '| key: value\n| foo: bar\n|   a: b\n'
    docstring_2 = parse(str_2)
    assert docstring_2.meta['key'] == 'value'
    assert docstring_2.meta['foo']['a'] == 'b'


# Generated at 2022-06-25 16:42:27.153530
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:30.194819
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    test_case_0()


# ----
# main
# ----

if __name__ == "__main__":
    test_parse()
    print("Done.")

# Generated at 2022-06-25 16:42:39.681634
# Unit test for function parse
def test_parse():
    assert parse('hello world') == Docstring(first_line='', short_description='hello world', long_description='', docstring_type='')
    assert parse('hello world\n') == Docstring(first_line='', short_description='hello world', long_description='', docstring_type='')
    assert parse('\nhello world\n') == Docstring(first_line='', short_description='hello world', long_description='', docstring_type='')
    assert parse('hello world\n\n') == Docstring(first_line='', short_description='hello world', long_description='', docstring_type='')
    assert parse('hello world\n\n\n') == Docstring(first_line='', short_description='hello world', long_description='', docstring_type='')
    assert parse

# Generated at 2022-06-25 16:42:47.181946
# Unit test for function parse
def test_parse():
    text_0 = '|'
    style_0 = Style.auto
    ret_0 = parse(text_0, style_0)
    assert ret_0 == parse(text_0) == None

    text_1 = '|a|b|c|\n|---|---|---|\n|d|e|f|'
    style_1 = Style.auto
    ret_1 = parse(text_1, style_1)
    assert ret_1 == parse(text_1) == None

    text_2 = '|a|b|c|\n|---|---|---|\n|d|e|f|'
    style_2 = Style.auto
    ret_2 = parse(text_2, style_2)
    assert ret_2 == parse(text_2) == None

    text_3

# Generated at 2022-06-25 16:42:49.309596
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:59.559927
# Unit test for function parse
def test_parse():
    assert callable(parse)
    str_0 = ''
    docstring_0 = parse(str_0)
    str_1 = '\n'
    docstring_1 = parse(str_1)
    str_2 = 'simple\n'
    docstring_2 = parse(str_2)
    str_3 = 'simple'
    docstring_3 = parse(str_3)
    str_4 = '\n\n'
    docstring_4 = parse(str_4)
    str_5 = 'simple\n\n'
    docstring_5 = parse(str_5)
    str_6 = 'Args:\n    variable (float): The value of variable.\nReturns:\n    float: The value of variable.'
    docstring_6 = parse(str_6)

# Generated at 2022-06-25 16:43:10.308426
# Unit test for function parse
def test_parse():
    # Test the below examples.
    str_0 = '|'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == '|'
    assert docstring_0.long_description == ''
    assert docstring_0.returns == ''
    assert docstring_0.returns_description == ''
    assert docstring_0.meta == {}
    assert docstring_0.example == ''
    assert docstring_0.exceptions == []
    assert docstring_0.yields == []
    assert docstring_0.yields_description == []
    assert docstring_0.other == []
    str_1 = '|   ---|---\n|   1|  2\n|   3|  4\n'

# Generated at 2022-06-25 16:43:16.457491
# Unit test for function parse
def test_parse():
    # Returns an object of type 'Docstring'
    assert isinstance(parse(''), Docstring)
    assert isinstance(parse('|'), Docstring)
    assert isinstance(parse('foo\nbar'), Docstring)
    assert isinstance(parse('foo\n bar'), Docstring)
    assert isinstance(parse('foo\n\n bar'), Docstring)
    assert isinstance(parse(':param a: foo\nbar'), Docstring)
    assert isinstance(parse('a'), Docstring)
    assert isinstance(parse(':param str a: foo\nbar'), Docstring)
    assert isinstance(parse(':param a: foo\n:type a: str\nbar'), Docstring)
    assert isinstance(parse(':param str a: foo\n:type a: str\nbar'), Docstring)

# Generated at 2022-06-25 16:43:18.136156
# Unit test for function parse
def test_parse():
    assert parse

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:43:31.850121
# Unit test for function parse
def test_parse():
    # Tests a one line docstring
    str_0 = "Example module.\n"
    docstring_0 = parse(str_0)
    assert docstring_0.__str__() == "Example module."

    # Tests a multi line docstring
    str_1 = "Example module.\n" \
            "This module does stuff.\n"
    docstring_1 = parse(str_1)
    assert docstring_1.__str__() == "Example module.This module does stuff."

    # Tests a docstring with variants of parameters