

# Generated at 2022-06-25 16:33:40.747289
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.'
    assert docstring_0.long_description == '\n  f :returns: parsed docstring\n    '
    assert docstring_0.returns == None
    assert docstring_0.yields == None
    assert docstring_0.raises == None
    assert docstring_0.other == None

# Generated at 2022-06-25 16:33:51.590931
# Unit test for function parse
def test_parse():
    # Test 0
    case_0 = 'Parse.the Google-soyle docstring into its components.'
    expected_0 = ['Parse.the Google-soyle docstring into its components.']
    assert parse(case_0) == expected_0

    # Test 1
    case_1 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    expected_1 = ['Parse.the Google-soyle docstring into its components.',
                  'f',
                  ':returns: parsed docstring']
    assert parse(case_1) == expected_1

if __name__ == '__main__':
    test_parse()

 
# +
import re
from typing import List, Tuple
from typing import TYPE_CHECKING
#if

# Generated at 2022-06-25 16:33:54.122504
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except:
        import sys
        print(sys.exc_info()[1])
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 16:34:00.602151
# Unit test for function parse
def test_parse():
    # test_case_0
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 'Parse.the Google-soyle docstring into its components.'
    # test_case_1
    str_1 = '"""\nParse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    """'
    docstring_1 = parse(str_1)
    assert docstring_1.summary == 'Parse.the Google-soyle docstring into its components.'
    # test_case_2

# Generated at 2022-06-25 16:34:10.659462
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    # str_0 = 'Parse the docstring into its components.\n\n  :param text: docstring text to parse\n  :param style: docstring style\n  :returns: parsed docstring representation\n'
    str_1 = 'Parse the docstring into its components.\n\n  :param text: docstring text to parse\n  :param style: docstring style\n  :returns: parsed docstring representation\n'
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.'

# Generated at 2022-06-25 16:34:20.784634
# Unit test for function parse
def test_parse():
    # test case 0
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.'
    assert docstring_0.long_description == ''
    assert len(docstring_0.params) == 0
    assert docstring_0.returns.type_name == 'parsed docstring'
    assert docstring_0.returns.description == ''
    assert len(docstring_0.raises) == 0
    assert docstring_0.see_also == ''
    assert len(docstring_0.meta) == 1

    # test case 1
    str_1

# Generated at 2022-06-25 16:34:29.896395
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the docstring into its components\n'
    docstring_0 = parse(str_0)

    str_1 = 'Parse the docstring into its components\n'
    docstring_1 = parse(str_1)

    str_2 = '\nParse the docstring into its components\n'
    docstring_2 = parse(str_2)

    str_3 = 'Parse the docstring into its components\n  '
    docstring_3 = parse(str_3)

    str_4 = 'Parse the docstring into its components\n\n  f :returns: parsed docstring\n    '
    docstring_4 = parse(str_4)


# Generated at 2022-06-25 16:34:40.526616
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    str_1 = 'Parse.the GitHub-soyle docstring into its components.\n  f:returns: parsed docstring\n'
    str_2 = 'The main parsing routine. \n\nThe main :parameters: routine'

    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.'
    assert docstring_0.long_description == ''
    assert docstring_0.returns == [('parsed docstring', )]
    assert docstring_0.meta == {'f': []}

    assert docstring_1.short_description == 'Parse.the Google-soyle docstring into its components.'

# Generated at 2022-06-25 16:34:50.454990
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 'Parse.the Google-soyle docstring into its components.\n\n'
    assert docstring_0.description == ''
    assert docstring_0.returns.type_name == 'parsed docstring'
    assert docstring_0.returns.description == ''
    assert isinstance(docstring_0.returns, docstring_parser.common.Return)
    assert len(docstring_0.params) == 0
    assert len(docstring_0.exceptions) == 0


# Generated at 2022-06-25 16:34:52.687046
# Unit test for function parse
def test_parse():
    assert True


# Generated at 2022-06-25 16:35:08.118472
# Unit test for function parse
def test_parse():
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None
    assert parse("blah") == None

# Generated at 2022-06-25 16:35:09.316988
# Unit test for function parse
def test_parse():
    a = parse("This is a test")
    b = parse("")


# Generated at 2022-06-25 16:35:17.115004
# Unit test for function parse
def test_parse():
    # Case 1
    expected = {
        'summary': 'Parse the docstring into its components.',
        'meta': [],
        'extended_summary': 'The short summary ends with a period.\n\nAnd then we have a blank line followed by an extended summary.',
        'parts': {
            'Args': [
                'text (str): docstring text to parse',
                'style (Style, optional): docstring style',
            ],
            'Returns': 'parsed docstring representation'
        }
    }

# Generated at 2022-06-25 16:35:27.884416
# Unit test for function parse
def test_parse():
    # Test: no docstrings passed in
    assert parse("") == None

    # Test: It works

    str_1 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Parse.the Google-soyle docstring into its components.\n\n'
    assert docstring_1.long_description == '  f :returns: parsed docstring\n    '
    assert docstring_1.return_annotation == None
    assert docstring_1.meta['f'] == {'returns': 'parsed docstring'}
    assert docstring_1._style is 'google'

    # Test: No docstrin
    assert parse

# Generated at 2022-06-25 16:35:33.453677
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_0, style=Style.numpy)
    docstring_2 = parse(str_0, style=Style.google)
    assert len(docstring_0.short_description) == 32 and len(docstring_1.short_description) == 32 and len(docstring_2.short_description) == 32


# Generated at 2022-06-25 16:35:35.006748
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:35:43.847058
# Unit test for function parse
def test_parse():
    docstring_0 = parse('\nThis is a description.\n    Tne line above contains two spaces after the period.\n    This line contains a period.\n\nFirst argument.\n\nSecond argument.\n\nReturns something.', style = Style.google)
    docstring_0 = parse('\nThis is a description.\n    Tne line above contains two spaces after the period.\n    This line contains a period.\n\nFirst argument.\n\nSecond argument.\n\nReturns something.', style = Style.auto)

# Generated at 2022-06-25 16:35:52.810635
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 'Parse.the Google-soyle docstring into its components.'
    assert docstring_0.meta == dict({ 'f': dict() })
    assert docstring_0.returns == 'parsed docstring'
    str_1 = '\n    Parse.the Google-soyle docstring into its components.\n\n    f :returns: parsed docstring\n      '
    docstring_1 = parse(str_1)
    assert docstring_1.summary == 'Parse.the Google-soyle docstring into its components.'
    assert docstring_1.meta

# Generated at 2022-06-25 16:35:53.678099
# Unit test for function parse
def test_parse():
    assert 0 == 0


# Generated at 2022-06-25 16:36:00.912948
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.meta == {'returns': [{'type': None, 'name': None, 'desc': 'parsed docstring'}]}


# Performance test for function parse

# Generated at 2022-06-25 16:36:18.559632
# Unit test for function parse
def test_parse():
    str_2 = """Parse.the Google-soyle docstring into its components.

\t f :returns: parsed docstring\n"""
    assert parse(str_2) != None
    assert isinstance(parse(str_2), Docstring)
    assert parse(str_2).summary == "Parse.the Google-soyle docstring into its components."
    str_3 = 'Parse.the Google-soyle docstring into its components.\n\n\t f :returns: parsed docstring\n'
    assert parse(str_3) != None
    assert isinstance(parse(str_3), Docstring)
    assert parse(str_3).summary == "Parse.the Google-soyle docstring into its components."
    assert parse(str_3).meta['f'] == 'parsed docstring'


# Generated at 2022-06-25 16:36:20.029955
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:36:21.055392
# Unit test for function parse
def test_parse():
    test_case_0()



# Generated at 2022-06-25 16:36:29.695455
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.'
    assert docstring_0.long_description == ''
    assert docstring_0.get_param_type('f') is None
    assert docstring_0.get_param_description('f') is None
    assert docstring_0.get_param_default('f') is None
    assert docstring_0.returns.type_name is None
    assert docstring_0.returns.description == 'parsed docstring'
    assert docstring_0.returns.default is None

# Generated at 2022-06-25 16:36:39.428313
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    print("Test case 0")
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.'
    assert docstring_0.long_description == ''
    assert isinstance(docstring_0.meta, dict)
    assert len(docstring_0.meta) == 1
    assert docstring_0.meta['returns'] == ['parsed docstring']
    print("Test case 1")

# Generated at 2022-06-25 16:36:42.027543
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:36:51.935566
# Unit test for function parse
def test_parse():

    from docstring_parser.common import Line
    from docstring_parser.models import Section, Parameter
    from docstring_parser.styles import Style

    docstring_0 = parse("""
                          Parse the Google-style docstring into its components.

                          Parameters
                          ----------
                          param: str
                             Some param.
                          Returns
                          -------
                          parsed docstring
                          """)
    # Check if isinstance(docstring_0, Docstring)
    try:
        assert isinstance(docstring_0, Docstring)
    except:
        print(docstring_0)
        raise AssertionError
    # Check if len(docstring_0.description) == 2

# Generated at 2022-06-25 16:36:54.680458
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:37:04.845429
# Unit test for function parse
def test_parse():
    assert parse("Parsing Google style docstring\n    :param a: first parameter\n    :param b: second paramter\n    :return: nothing") == Docstring(summary='Parsing Google style docstring', description='', tags=[('param', 'a', 'first parameter'), ('param', 'b', 'second paramter'), ('return', '', 'nothing')])

# Generated at 2022-06-25 16:37:11.291291
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.description == 'Parse.the Google-soyle docstring into its components.' # Assertion
    assert docstring_0.returns.description == 'parsed docstring' # Assertion


# Generated at 2022-06-25 16:37:35.231680
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    str_1 = 'Parse.the auto-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    str_2 = 'Parse.the Numpy-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    str_3 = 'Parse.the epytext-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    str_4 = 'Parse.the rst-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0

# Generated at 2022-06-25 16:37:46.644697
# Unit test for function parse
def test_parse():
    str_0 = 'Use the bultin function print() to print the output.\n\n:raises NoError:\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.build() == 'Use the bultin function print() to print the output.\n\n:raises NoError:\n\n'
    str_1 = 'Do this.\n\n:param x:\n'
    docstring_1 = parse(str_1)
    assert docstring_1.build() == 'Do this.\n\n:param x:\n'
    str_2 = 'Do this.\n\n:type x:\n'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:37:55.874086
# Unit test for function parse
def test_parse():
    st0 = '''Parse.the Google-soyle docstring into its components.

      @author: author

      f :returns: parsed docstring
        '''
    doc_str0 = parse(st0)
    assert doc_str0.summary == 'Parse.the Google-soyle docstring into its components.'
    assert doc_str0.meta['author'] == 'author'
    assert doc_str0.params == []
    assert doc_str0.returns.type == 'returns'
    assert doc_str0.returns.description == 'parsed docstring'
    assert doc_str0.returns.name is None


# Generated at 2022-06-25 16:37:57.731189
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:38:10.176953
# Unit test for function parse
def test_parse():
    """ Parse test case """
    t = 'Parse the docstring into its components.\n\n    :parameters:\n        text: docstring text to parse\n        \n        style: docstring style\n\n    :returns: parsed docstring representation\n    '
    docstring_0 = parse(t)
    assert docstring_0.short_description == 'Parse the docstring into its components.'
    assert docstring_0.long_description == ''
    assert docstring_0.params == {'text': 'docstring text to parse', 'style': 'docstring style'}
    assert docstring_0.returns == 'parsed docstring representation'
    assert docstring_0.meta == {}


# Generated at 2022-06-25 16:38:16.218739
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    import sys
    import timeit

    print(timeit.timeit('test_parse()', setup='from __main__ import test_parse', number=1000))
    # if sys.flags.optimize < 2:
    # 	print( cProfile.run('test_parse()') )
    # else:
    # 	print( 'Docutils is too old' )
    #

# Generated at 2022-06-25 16:38:17.281171
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None


# Generated at 2022-06-25 16:38:29.035295
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the Google-style docstring into its components.\n\n:f:returns: parsed docstring\n'
    str_1 = 'Parse the Google-style docstring into its components.\n\n:f:return: parsed docstring\n'
    str_2 = 'Parse the Google-style docstring into its components.\n\n:f:returns: parsed docstring\n'
    str_3 = 'Parse the Google-style docstring into its components.\n  f:returns: parsed docstring\n'
    str_4 = 'Parse the Google-style docstring into its components.\n  f:returns: parsed docstring\n'

# Generated at 2022-06-25 16:38:41.284387
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.title == 'Parse'
    assert docstring_0.short_description == 'the Google-soyle docstring into its components.'
    assert docstring_0.long_description == ''
    assert docstring_0.return_type == 'parsed docstring'
    assert docstring_0.return_annotation == ''
    assert docstring_0.return_description == ''
    assert docstring_0.params == []
    assert docstring_0.meta == ['f :returns: parsed docstring']
    assert docstring_0.examples == []
    assert docstring_0.notes

# Generated at 2022-06-25 16:38:42.448785
# Unit test for function parse
def test_parse():
  test_case_0()
  test_case_1()


# Generated at 2022-06-25 16:38:51.077408
# Unit test for function parse
def test_parse():
    test_case_0()

# Saves the unit test's state information to the xml report file
# and closes it

# Generated at 2022-06-25 16:38:54.638492
# Unit test for function parse
def test_parse():
    # Dummy Test
    assert True

# Generated at 2022-06-25 16:39:01.970594
# Unit test for function parse
def test_parse():
    a = '''
        Parameters
        ----------
        arg : int
            Description of `arg`.
        arg2 : str
            Description of `arg2`

        Returns
        -------
        str
            Description of return value.
        '''
    b = parse(a)
    assert(len(b.params) == 2)
    assert(b.returns[0].description == 'Description of return value.')
    assert(b.returns[0].type_name == 'str')



# Generated at 2022-06-25 16:39:12.077671
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.'
    assert docstring_0.long_description == 'f'
    assert len(docstring_0.fields) == 1

# Generated at 2022-06-25 16:39:21.670416
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.'
    assert docstring_0.long_description == '\n    f :returns: parsed docstring\n      '
    str_1 = '\n    Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Parse.the Google-soyle docstring into its components.'

# Generated at 2022-06-25 16:39:23.934345
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:39:26.529328
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:39:34.659116
# Unit test for function parse
def test_parse():
    assert parse('Parse the docstring into its components\n\n:returns: parsed docstring\n:rtype: Docstring') == Docstring(short_description='Parse the docstring into its components', long_description=None, meta={'returns': 'parsed docstring', 'rtype': 'Docstring'}, params=None, returns=None, functions=None)
    assert parse('Parse the docstring into its components\n\n:returns parsed docstring\n:rtype Docstring') == Docstring(short_description='Parse the docstring into its components', long_description=None, meta=None, params=None, returns=None, functions=None)

# Generated at 2022-06-25 16:39:37.410071
# Unit test for function parse
def test_parse():
    test_case_0()


test_parse()

# Generated at 2022-06-25 16:39:43.487787
# Unit test for function parse
def test_parse():
    import sys
    import StringIO
    import io
    pass_flag = True
    output = io.BytesIO()
    saved_stdout = sys.stdout
    try:
        sys.stdout = output
        test_case_0()
    except:
        pass_flag = False
    sys.stdout = saved_stdout
    assert(pass_flag == True)

if __name__ == '__main__':
    test_parse()
    print('Test passed')

# Generated at 2022-06-25 16:39:56.981057
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = 'Parse the Google-style docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse the Google-style docstring into its components.'
    assert docstring_0.long_description == None
    assert docstring_0.meta == {'returns': 'parsed docstring'}
    # Test case 1
    str_1 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Parse.the Google-soyle docstring into its components.'

# Generated at 2022-06-25 16:40:01.155440
# Unit test for function parse
def test_parse():
    assert parse("foo\nbar") == Docstring(
        "foo\nbar",
        summary="foo",
        description="",
        returns=None,
        raises=None,
        attributes=None,
        examples=None,
        sections=[],
    )



# Generated at 2022-06-25 16:40:03.436851
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:40:14.710240
# Unit test for function parse
def test_parse():
    text = '''
        The module docstring is the first thing listed in a
        Python module, and is usually just a one-line summary
        of the module's purpose. The docstring for the builtins
        module is a good example of such a docstring.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
    '''
    d = parse(text)
    assert d.first_line == 'The module docstring is the first thing listed in a'
    assert d.body == 'Python module, and is usually just a one-line summary\nof the module\'s purpose. The docstring for the builtins\nmodule is a good example of such a docstring.'
    assert d.short_description == 'The module docstring is the first thing listed in a'
    assert d

# Generated at 2022-06-25 16:40:23.329424
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the Google-style docstring into its components.'
    assert 'Parses the Google-style docstring' in parse(str_0).short_description
    assert 'Parses the Google-style docstring into its components.' == parse(str_0).long_description
    assert [''] == parse(str_0).params
    assert [('returns', 'parsed docstring')] == parse(str_0).returns

    str_1 = 'Parse the numpy-style docstring into its components.'
    assert 'Parses the numpy-style docstring' in parse(str_1).short_description
    assert 'Parses the numpy-style docstring into its components.' == parse(str_1).long_description
    assert [''] == parse(str_1).params

# Generated at 2022-06-25 16:40:23.831313
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-25 16:40:26.044192
# Unit test for function parse
def test_parse():
    import pytest
    with pytest.raises(Exception):
        test_case_0()

if __name__ == '__main__':
    import pytest
    pytest.main(args=[__file__])

# Generated at 2022-06-25 16:40:29.165182
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except AssertionError as e:
        print('FAILED: test_parse')
        exit(1)
    print('SUCCESS: test_parse')
    exit(0)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:40:33.448904
# Unit test for function parse
def test_parse():
    assert callable(parse)


# main
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:40:34.735070
# Unit test for function parse
def test_parse():
    test_case_0()


test_parse()

# Generated at 2022-06-25 16:40:42.775566
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)

    return docstring_0

# Generated at 2022-06-25 16:40:53.055449
# Unit test for function parse
def test_parse():
    # Case 0
    str_0 = 'Parse.the docstring into its components.\n\n  g :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0._short_description == "Parse.the docstring into its components."
    assert docstring_0._long_description == ""
    assert docstring_0._returns.type == "parsed docstring"
    assert docstring_0._returns.description == ""
    assert docstring_0._attributes == list()
    assert docstring_0._raises == list()
    assert docstring_0._warnings == list()
    assert docstring_0._notes == list()
    assert docstring_0._references == list()
    assert docstring_0._seealso == list()

# Generated at 2022-06-25 16:40:57.841637
# Unit test for function parse
def test_parse():
  assert parse('This is a test string.')

# Generated at 2022-06-25 16:41:00.778166
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except Exception as e:
        print("raise exception...")
        raise e
    else:
        print("test case passed.")

test_parse()

# Generated at 2022-06-25 16:41:08.096622
# Unit test for function parse
def test_parse():
    # Check init
    assert parse.__doc__ is not None
    # Check instance and input/output
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.\n\n'
    assert docstring_0.description == 'f'
    assert docstring_0.params['f'].type_name == 'returns'
    assert docstring_0.params['f'].description == 'parsed docstring'



# Generated at 2022-06-25 16:41:15.378147
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0 is not None
    str_1 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_1 = parse(str_1, Style.google)
    assert docstring_1 is not None
    str_2 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_2 = parse(str_2, Style.numpy)
    assert docstring_2 is not None

# Generated at 2022-06-25 16:41:19.600864
# Unit test for function parse
def test_parse():
    assert parse.__doc__
    #assert docstring_0 == 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '

# Generated at 2022-06-25 16:41:25.977425
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.yields == None
    assert docstring_0.flags == []
    assert docstring_0.meta['returns'] == ['parsed docstring']
    assert docstring_0.description == 'Parse.the Google-soyle docstring into its components.'

# Generated at 2022-06-25 16:41:28.630574
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except Exception as e:
        assert False

# Program entry point

# Generated at 2022-06-25 16:41:36.845107
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse.the Google-soyle docstring into its components.\n\n'
    assert docstring_0.long_description is None
    assert docstring_0.returns.type_name == 'parsed docstring'
    assert docstring_0.returns.description is None
    assert len(docstring_0.params) == 1
    assert docstring_0.params[0].arg_name == 'f'
    assert docstring_0.params[0].type_name is None
    assert docstring_0.params[0].description is None

# Generated at 2022-06-25 16:41:48.706985
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except:
        assert False

# Main
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:42:02.018657
# Unit test for function parse
def test_parse():
    assert len(parse.__defaults__) == 1  # __defaults__ stores default arguments
    assert 'style' in parse.__annotations__
    assert parse.__annotations__['style'] == Style.auto  # __annotations__ stores type annotations
    assert parse.__doc__ is not None  # __doc__ stores docstring
    assert len(parse.__code__.co_varnames) == 2 # __code__ stores information like number of arguments
    assert len(parse.__code__.co_consts) == 8
    assert parse.__code__.co_consts[0] == '\nThe main parsing routine.\n\n'
    assert parse.__code__.co_consts[3] == None # co_consts stores string and numbers used in the bytecode
    assert parse.__code__.co_

# Generated at 2022-06-25 16:42:14.072381
# Unit test for function parse
def test_parse():
    assert callable(parse)
    # String, String -> String
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n   '
    str_1 = 'Parse the Google-style docstring into its components.'
    str_2 = 'Parse the Google-style docstring into its components.'
    str_3 = 'Parses a docstring into its components.\n\n    Args:\n        text (str): The docstring text to parse.\n        style (Style): The docstring style.\n\n    Returns:\n        Docstring: The parsed docstring representation.\n    '

# Generated at 2022-06-25 16:42:16.529480
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == '__main__':
    # Unit test for function parse
    test_parse()

# Generated at 2022-06-25 16:42:19.036998
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:26.303378
# Unit test for function parse
def test_parse():
    import sys
    import os
    import random

    def get_rand_string(len_):
        return ''.join(chr(random.randrange(32, 127, 1)) for i in range(len_))

    def test(str_):
        assert str_ == parse(str_).to_str()

    for i in range(10000):
        rand_str = get_rand_string(random.randint(0, 100))
        try:
            test(rand_str)
        except ParseError:
            test(rand_str)


#test_case_0()

# Generated at 2022-06-25 16:42:27.814869
# Unit test for function parse
def test_parse():
    test_case_0()
    print("Done!")

test_parse()

# Generated at 2022-06-25 16:42:38.115195
# Unit test for function parse
def test_parse():
    # Test for style auto:
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring'
    assert docstring_0.short_description == 'Parse.the Google-soyle', "Short description for the docstring not parsed correctly"
    assert docstring_0.long_description == "Parse.the Google-soyle docstring into its components.", "Long description for the docstring not parsed correctly"
    assert len(docstring_0.params) == 1, "Params for the docstring should be equal to 1"
    assert docstring_0.params[0].arg_name == "f", "Argument name for the docstring not parsed correctly"

# Generated at 2022-06-25 16:42:46.066567
# Unit test for function parse
def test_parse():
	str_0 = 'This is magic.\n\nArgs:\n  name (str): Name of the magician.\n  age (int): Age of the magician.\n\nReturns:\n  Magician: The magician namedtuple.\n\nRaises:\n  ImportError: If python-magic is not found.\n'
	docstring_0 = parse(str_0)
	assert docstring_0.short_description == "This is magic."
	assert docstring_0.long_description == ""
	assert len(docstring_0.params) == 2
	assert docstring_0.params[0].arg_name == "name"
	assert docstring_0.params[0].type_name == "str"
	assert docstring_0.params[0].description == "Name of the magician."
	assert docstring

# Generated at 2022-06-25 16:42:50.229278
# Unit test for function parse
def test_parse():
    str_0 = 'Parse.the Google-soyle docstring into its components.\n\n  f :returns: parsed docstring\n    '
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:43:11.210204
# Unit test for function parse
def test_parse():

    str_0 = 'Parse the Google-style docstring into its components.\n\n    f: returns: parsed docstring\n    '
    docstring_0 = parse(str_0, Style.google)
    assert docstring_0.summary == 'Parse the Google-style docstring into its components.'
    assert 'f' in docstring_0.meta
    assert docstring_0.meta['f'].details == 'parsed docstring'

    str_1 = 'Parse Google-style docstring into components.\n\n    f: parsed docstring\n    '
    docstring_1 = parse(str_1, Style.google)
    assert docstring_1.summary == 'Parse Google-style docstring into components.'
    assert 'f' in docstring_1.meta

# Generated at 2022-06-25 16:43:12.502886
# Unit test for function parse
def test_parse():
    assert False == True



# Generated at 2022-06-25 16:43:23.766286
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the Google-style docstring into its components.\n\n:param text: docstring text to parse\n\n:returns: parsed docstring representation\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Parse the Google-style docstring into its components.'
    assert docstring_0.long_description == ''
    assert docstring_0.params == {'text': 'docstring text to parse'}
    assert docstring_0.returns == 'parsed docstring representation'
    assert docstring_0.content == 'Parse the Google-style docstring into its components.'
    assert docstring_0.meta == {'text': 'docstring text to parse'}

# Generated at 2022-06-25 16:43:31.570185
# Unit test for function parse
def test_parse():
    str_0 = 'Parse the Google-style docstring into its components.\n   f :returns: parsed docstring'
    assert str_0 == parse(str_0).text
    str_0 = 'Parse the Google-style docstring into its components.\n   f :returns: parsed docstring'
    assert 'Parse the Google-style docstring into its components.' == parse(str_0).summary
    str_0 = 'Parse the Google-style docstring into its components.\n   f :returns: parsed docstring'
    assert 'parsed docstring' == parse(str_0).returns
    str_0 = 'Parse the Google-style docstring into its components.\n   f :returns: parsed docstring'
    assert [] == parse(str_0).notes