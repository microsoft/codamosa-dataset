

# Generated at 2022-06-25 16:33:40.457341
# Unit test for function parse
def test_parse():
    str_0 = 's@>`=&'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 's'
    assert docstring_0.long_description == '@>`=&'
    assert docstring_0.meta == {}

    str_1 = 'd\n\nq\nw'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'd'
    assert docstring_1.long_description == 'q\nw'
    assert docstring_1.meta == {}

    str_2 = 'n\n\n'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'n'
    assert docstring_2.long_description == ''
   

# Generated at 2022-06-25 16:33:42.215917
# Unit test for function parse
def test_parse():
    # Testing with 2 docstrings of different styles
    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-25 16:33:51.814309
# Unit test for function parse
def test_parse():
    str_ = 'Summary line.\n\n    Extended description.\n\n    Args:\n        arg1(int): Description of arg1.\n        arg2 (str): Description of arg2.\n\n    Returns:\n        bool: Description of return value.'
    docstring = parse(str_)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == 'Extended description.'
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].arg_type == 'int'
    assert docstring.params[0].description == 'Description of arg1.'


# Generated at 2022-06-25 16:33:54.767306
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    str_0 = 's@>`=&'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:33:59.173005
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 16:34:03.548359
# Unit test for function parse
def test_parse():
    str_0 = '**arg1**: bla bla\n\n  \t the first argument\n\n**arg2**: bli bli\n\n  \t the second argument'
    docstring_0 = parse(str_0)
    str_1 = '**arg1**: bla bla\n\n  \t the first argument\n\n**arg2**: bli bli\n\n  \t the second argument'
    docstring_1 = docstring_0.docstring
    assert docstring_0.meta['arg1'].name == 'arg1'
    assert docstring_0.meta['arg2'].name == 'arg2'
    assert docstring_0.docstring == str_1

# Generated at 2022-06-25 16:34:06.523149
# Unit test for function parse
def test_parse():
   str_0 = 's@>`=&'
   docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:34:07.541328
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:34:09.518774
# Unit test for function parse
def test_parse():
    str_0 = 's@>`=&'
    docstring_0 = parse(str_0)


test_case_0()
test_parse()

# Generated at 2022-06-25 16:34:16.972516
# Unit test for function parse
def test_parse():

    # Simple test using style numpy
    # This tests that both the parse function and style numpy work.
    text = '''
    One line summary.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`.

    arg2 : str
        Description of `arg2`.

    Returns
    -------
    bool
        Description of return value.
    '''

    docstring = parse(text, style=Style.numpy)

    assert docstring.summary == "One line summary."
    assert docstring.extended_description == "Extended description."
    assert docstring.returns.description == "Description of return value."
    assert docstring.meta["parameters"][0].argname == "arg1"

# Generated at 2022-06-25 16:34:29.801929
# Unit test for function parse
def test_parse():
    test_case_0()

# Make sure it works with Python 2 __metaclass__
# Make sure it works with Python 2 __metaclass__

if __name__ == '__main__':
    # Verify that the module parses itself
    docstring = parse(parse.__doc__)
    print(docstring)

    assert docstring.short_description == "The main parsing routine."
    assert docstring.long_description == "The main parsing routine."
    assert docstring.params["text"].description == "docstring text to parse"
    assert docstring.params["style"].description == "docstring style"
    assert docstring.returns.description == "parsed docstring representation"

    # Now make sure it works with a real example

    # Python 2 __metaclass__

# Generated at 2022-06-25 16:34:40.482873
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    doc = parse(str_0, style = Style.numpy)
    assert doc.lines == ['One line summary.', '']
    assert doc.meta['arg1'] == ['int', 'Description of `arg1`.']
    assert doc.meta['arg2'] == ['str', 'Description of `arg2`.']
    assert doc.meta['returns'] == ['bool', 'Description of return value.']
   

# Generated at 2022-06-25 16:34:43.257740
# Unit test for function parse
def test_parse():
    test_case_0_parse = parse(test_case_0())
    assert type(test_case_0_parse) == docstring_parser.common.Docstring

################################################################################
# AUTOGENERATED BY SPHINX
################################################################################


# Generated at 2022-06-25 16:34:44.795756
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:34:54.040466
# Unit test for function parse
def test_parse():
    docstring = Docstring(
        summary=Summary('One line summary.'),
        description=Description(['Extended description.']),
        metadata={
            'arg1': Parameter('arg1', 'int', 'Description of `arg1`.'),
            'arg2': Parameter('arg2', 'str', 'Description of `arg2`.'),
            'return': Return('bool', 'Description of return value.')
        },
        style=Style.numpy
    )
    assert parse(str_0) == docstring

    str_1 = '\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n    '

# Generated at 2022-06-25 16:34:59.412718
# Unit test for function parse
def test_parse():
    expected_value = str_0
    assert parse('\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    ') == expected_value
    assert parse('\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    ', Style.google)

# Generated at 2022-06-25 16:35:03.376807
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Style
    assert parse(str_0) == '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '

# Generated at 2022-06-25 16:35:04.672682
# Unit test for function parse
def test_parse():
    # Test with Full Example
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:35:10.326949
# Unit test for function parse
def test_parse():
    style = Style.auto
    parsed_str = parse(str_0, style)
    print(parsed_str)


test_case_0()
test_parse()

# Generated at 2022-06-25 16:35:17.788503
# Unit test for function parse

# Generated at 2022-06-25 16:35:31.590474
# Unit test for function parse
def test_parse():
    assert callable(parse)
    ds = parse(test_case_0())

    assert ds.short_description == "One line summary."
    assert ds. long_description == "Extended description.\n\nParameters\n----------\narg1 : int\n    Description of `arg1`.\narg2 : str\n    Description of `arg2`.\nReturns\n-------\nbool\n    Description of return value."

    el = dict(ds.meta)

    assert el["arg1"] == "int\n\tDescription of `arg1`."
    assert el["arg2"] == "str\n\tDescription of `arg2`."
    assert el["return"] == "bool\n\tDescription of return value."

    #print ds.meta
    #print ds.short_description
    #

# Generated at 2022-06-25 16:35:43.266689
# Unit test for function parse
def test_parse():
    docstring = parse(str_0)

    # Test for signature
    signature = docstring.signature
    assert signature == None

    # Test for summary
    summary = docstring.summary
    assert summary == 'One line summary.'

    # Test for description
    description = docstring.description
    assert description == 'Extended description.'

    # Test for parameters
    parameters = docstring.parameters
    parameter = parameters['arg1']
    assert parameter['name'] == 'arg1'
    assert parameter['type'] == 'int'
    assert parameter['descr'] == 'Description of `arg1`.'

    parameter = parameters['arg2']
    assert parameter['name'] == 'arg2'
    assert parameter['type'] == 'str'
    assert parameter['descr'] == 'Description of `arg2`.'

    # Test for returns


# Generated at 2022-06-25 16:35:52.808541
# Unit test for function parse
def test_parse():
    text = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    style = Style.numpy
    expected = Docstring(text, summary='One line summary.', description='Extended description.', params={'arg1': {'desc': 'Description of `arg1`.', 'type': 'int'}, 'arg2': {'desc': 'Description of `arg2`.', 'type': 'str'}}, returns= {'desc': 'Description of return value.', 'type': 'bool'})

# Generated at 2022-06-25 16:36:03.848956
# Unit test for function parse
def test_parse():
    str_0 = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    doc_0 = parse(str_0)
    assert doc_0.short_description == 'One line summary.'
    assert doc_0.long_description == '\nExtended description.'

# Generated at 2022-06-25 16:36:15.985713
# Unit test for function parse

# Generated at 2022-06-25 16:36:19.074942
# Unit test for function parse
def test_parse():
    assert parse(str_0)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:28.306448
# Unit test for function parse
def test_parse():
    assert len(parse(str_0).params) == 2
    assert len(parse(str_0).returns) == 1
    assert parse(str_0).returns[0].type_name == 'bool'
    assert parse(str_0).returns[0].description == 'Description of return value.'
    assert parse(str_0).params[0].name == 'arg1'
    assert parse(str_0).params[0].type_name == 'int'
    assert parse(str_0).params[0].description == 'Description of `arg1`.'
    assert parse(str_0).params[1].name == 'arg2'
    assert parse(str_0).params[1].type_name == 'str'
    assert parse(str_0).params[1].description == 'Description of `arg2`.'
   

# Generated at 2022-06-25 16:36:36.780848
# Unit test for function parse
def test_parse():
    assert parse(str_0) ==  Docstring(
    summary = "One line summary.",
    description = "Extended description.",
    params = {
      'arg1' :  "Description of `arg1`.",
      'arg2' :  "Description of `arg2`.",
    },
    returns = "Description of return value.",
)

# Test cases
if __name__ == '__main__':
    import pytest
    pytest.main(["--color=yes", __file__])

# Generated at 2022-06-25 16:36:44.147524
# Unit test for function parse
def test_parse():
    text = str_0
    style = 'sphinx'
    # Function parse must return the parsed docstring representation
    assert parse(text, style) == Docstring(
        summary='One line summary.',
        description='Extended description.',
        meta={'Parameters': [('arg1', 'int', 'Description of `arg1`.'), ('arg2', 'str', 'Description of `arg2`.')], \
                'Returns': [('', 'bool', 'Description of return value.')]}
    )

# Generated at 2022-06-25 16:36:49.184432
# Unit test for function parse
def test_parse():
    assert isinstance(parse(str_0), Docstring) == True

# Generated at 2022-06-25 16:36:54.988209
# Unit test for function parse
def test_parse():
    print(parse(str_0))
    assert 1 == 1

test_parse()

# Generated at 2022-06-25 16:36:59.732409
# Unit test for function parse
def test_parse():
    assert parse(str_0) == """One line summary.

Extended description.

Parameters
----------
arg1 : int
    Description of `arg1`.

arg2 : str
    Description of `arg2`.

Returns
-------
bool
    Description of return value.
    """, 'case 0 failed'


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:37:06.440690
# Unit test for function parse
def test_parse():

    # Evaluate/test function
    docstring = parse(str_in='\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    ', style='numpy')

    # Verify results
    assert str(docstring) == str_0

# Generated at 2022-06-25 16:37:16.387753
# Unit test for function parse
def test_parse():
    # Example from GitHub issue #18
    str_0 = '''
    One line summary.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`.

    arg2 : str
        Description of `arg2`.

    Returns
    -------
    bool
        Description of return value.
    '''
    func_0 = lambda str_0: parse(str_0, Style.numpy)
    res_0 = func_0(str_0)

# Generated at 2022-06-25 16:37:26.140515
# Unit test for function parse
def test_parse():
    docstring = parse(str_0)
    print(docstring)
    #assert docstring.body == '    Extended description.\n'
    #assert docstring.params['arg1'].description == ['Description of `arg1`.']
    #assert docstring.params['arg2'].description == ['Description of `arg2`.']
    #assert docstring.returns.description == ['Description of return value.']
    #assert docstring.summary == 'One line summary.'

# Execute test_parse
test_parse()

# Generated at 2022-06-25 16:37:36.011775
# Unit test for function parse
def test_parse():
    # Arguments
    text = str_0
    style = Style.numpy
    # Function call
    ds = parse(text, style)
    # Returns
    assert ds.summary == 'One line summary.'
    assert ds.description == 'Extended description.'
    assert ds.params == {'arg1': 'Description of `arg1`.', 'arg2': 'Description of `arg2`.'}
    assert ds.returns == 'Description of return value.'
    assert ds.metadata == {'style': 'numpy', 'name': 'parse'}

    # Arguments
    text = str_0
    style = Style.numpy
    # Function call
    ds = parse(text, style)
    # Returns
    assert ds.summary == 'One line summary.'

# Generated at 2022-06-25 16:37:45.644044
# Unit test for function parse
def test_parse():

    test_case_true = True

    str_0 = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    res_0 = parse(text=str_0)
    res_0.returns.dtype.__str__()

    test_case_true = True

    print('test_parse executed successfully.')


# Generated at 2022-06-25 16:37:47.008073
# Unit test for function parse
def test_parse():
    assert not parse(str_0)


# Generated at 2022-06-25 16:37:56.059677
# Unit test for function parse
def test_parse():
    str_0 = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    str_1 = 'One line summary.\n\n Extended description.\n\n Parameters\n ----------\n arg1 : int\n     Description of `arg1`.\n\n arg2 : str\n     Description of `arg2`.\n\n Returns\n -------\n bool\n     Description of return value.'

    assert(str(parse(str_0)) == str(parse(str_0)))

# Generated at 2022-06-25 16:38:08.996681
# Unit test for function parse
def test_parse():
    sample = parse
    str_0 = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '

# Generated at 2022-06-25 16:38:19.684636
# Unit test for function parse
def test_parse():
    docstring = parse(text=str_0, style=Style.numpy)
    assert docstring.meta['summary'] == 'One line summary.'
    assert docstring.meta['description'] == 'Extended description.'
    assert docstring.params['arg1'].name == 'arg1'
    assert docstring.params['arg1'].desc == 'Description of `arg1`.'
    assert docstring.params['arg2'].name == 'arg2'
    assert docstring.params['arg2'].desc == 'Description of `arg2`.'
    assert docstring.returns.desc == 'Description of return value.'

# Generated at 2022-06-25 16:38:22.979142
# Unit test for function parse
def test_parse():
    assert parse(str_0) != None
    print("test_parse: passed")

test_parse()

# End of test__docstring_parser.py

# Generated at 2022-06-25 16:38:30.883678
# Unit test for function parse
def test_parse():
    # test for string
    str_0 = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    ret_0 = parse(str_0, Style.google)

# Generated at 2022-06-25 16:38:36.475563
# Unit test for function parse
def test_parse():
    doc_str = parse(str_0)
    # print(doc_str.summary)
    # print(doc_str.extended)
    # print(doc_str.name)
    # print(doc_str.params)
    # print(doc_str.returns)
    # print(doc_str.section)
    # print(doc_str.meta)

# Generated at 2022-06-25 16:38:40.778053
# Unit test for function parse
def test_parse():
    arg1, arg2 = None, None
    # Call the function
    cls_ret = parse(str_0)
    assert(cls_ret == cls_exp)
    return cls_ret == cls_exp

# Generated at 2022-06-25 16:38:44.310184
# Unit test for function parse
def test_parse():
    text = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    style = Style.numpy
    result = parse(text, style)
    assert result.short_description is None


# Generated at 2022-06-25 16:38:55.009064
# Unit test for function parse
def test_parse():
    str_0 = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '

# Generated at 2022-06-25 16:39:05.670202
# Unit test for function parse
def test_parse():
    # Test 1
    str_0 = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    ret_0 = parse(str_0)
    assert str(ret_0) == '''\
One line summary.

    Extended description.

    * Parameters
        - **arg1** (*int*) -- Description of `arg1`.
        - **arg2** (*str*) -- Description of `arg2`.

    * Returns
        - (*bool*) -- Description of return value.'''


    # Test 2

# Generated at 2022-06-25 16:39:07.794485
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:39:15.300370
# Unit test for function parse
def test_parse():
    try:
        from docstring_parser import parse
    except:
        pass
    else:
        assert callable(parse)

    try:
        from docstring_parser import parse
    except:
        pass
    else:
        assert callable(parse)


# Generated at 2022-06-25 16:39:21.710679
# Unit test for function parse
def test_parse():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 16:39:31.591759
# Unit test for function parse
def test_parse():
    assert callable(parse)
    str_2 = 'One line summary.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    assert parse(str_0) == parse(str_2)
    str_9 = '\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '

# Generated at 2022-06-25 16:39:35.958774
# Unit test for function parse
def test_parse():
    docstring = parse(str_0)
    assert docstring.summary == 'One line summary.'
    assert docstring.description == '    Extended description.\n\n'
    assert docstring.params == [('arg1', 'int', 'Description of `arg1`.', '\n        '), ('arg2', 'str', 'Description of `arg2`.', '\n        ')]
    assert docstring.returns == ('bool', '    Description of return value.\n')

# Generated at 2022-06-25 16:39:37.458660
# Unit test for function parse
def test_parse():
    ds = parse(str_0)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:39:45.734894
# Unit test for function parse
def test_parse():
    # Test case 0
    str_0 = '\n    One line summary.\n\n    Extended description.\n\n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`.\n\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n    '
    try:
        assert(str(parse_parse(str_0)) == str_0)
    except AssertionError as e:
        print(str_0)
        print('expected:', str_0)
        print('actual  :', str(parse_parse(str_0)))

# Generated at 2022-06-25 16:39:48.199778
# Unit test for function parse
def test_parse():
    assert 1
    assert 2

# test_case_0

# Generated at 2022-06-25 16:39:50.108118
# Unit test for function parse
def test_parse():
    assert isinstance(parse(str_0, Style.numpy), Docstring)
    assert isinstance(parse(str_0, Style.google), Docstring)

# Generated at 2022-06-25 16:39:52.628316
# Unit test for function parse
def test_parse():
    print("Test parse function")
    print(parse(str_0))

if __name__ == '__main__':
    # test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:01.452685
# Unit test for function parse
def test_parse():
    text = str_0
    style = Style.numpy
    ret_val = {'description': 'One line summary.\n\nExtended description.', 
        'params': [{'arg': 'arg1', 'type': 'int', 'description': 'Description of `arg1`.'}, 
                    {'arg': 'arg2', 'type': 'str', 'description': 'Description of `arg2`.'}], 
        'returns': [{'return': 'return value', 'type': 'bool', 'description': 'Description of return value.'}]}
    assert parse(text, style) == ret_val


# Generated at 2022-06-25 16:40:13.326042
# Unit test for function parse
def test_parse():
    text_0 = str_0
    style_0 = Style.numpy
    parse(text_0,style_0)
    # text_1 = str_0
    # style_1 = Style.numpy
    # parse(text_1,style_1)
    # text_2 = str_2
    # style_2 = Style.numpydoc
    # parse(text_2,style_2)
    # text_3 = str_0
    # style_3 = Style.google
    # parse(text_3,style_3)
    # text_4 = str_1
    # style_4 = Style.numpy
    # parse(text_4,style_4)
    # text_5 = str_1
    # style_5 = Style.numpydoc
    # parse(text_5,

# Generated at 2022-06-25 16:40:23.853593
# Unit test for function parse
def test_parse():
    str_0 = 's@>`=&'
    docstring_0 = parse(str_0)

    assert docstring_0.summary == 's@>`=&'


# Generated at 2022-06-25 16:40:30.878212
# Unit test for function parse
def test_parse():
    str_0 = 'This is brief description.\n\nAnd this is description.'
    str_1 = ':type arg1: int\n:param arg2: description'
    str_2 = ':raises KeyError: if key not in mapping'
    str_3 = ':returns: None'
    str_4 = ':rtype: dict'
    str_5 = ':param arg1: this is arg1\n:type arg1: int\n:param arg2: this is arg2'
    str_6 = ':param arg1: this is arg1\n:param arg2: this is arg2\n:raises KeyError: if key not in mapping\n:return: None\n:rtype: dict'

# Generated at 2022-06-25 16:40:35.586870
# Unit test for function parse
def test_parse():
    pass


test_case_0()
test_parse()

# Generated at 2022-06-25 16:40:45.362400
# Unit test for function parse
def test_parse():

    str_0 = 's@>`=&'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == ''
    assert docstring_0.body == ''
    assert docstring_0.meta == {}
    assert docstring_0.style == Style.numpy

    str_1 = '@param x: this is x'
    docstring_1 = parse(str_1)
    assert docstring_1.summary == ''
    assert docstring_1.body == ''
    assert docstring_1.meta['param'][0].desc == 'this is x'

    str_2 = '@x x: this is x'
    docstring_2 = parse(str_2)
    assert docstring_2.summary == ''
    assert docstring_2.body == ''
    assert doc

# Generated at 2022-06-25 16:40:55.750740
# Unit test for function parse

# Generated at 2022-06-25 16:41:05.372981
# Unit test for function parse
def test_parse():
    str_1 = 'this is a docstring with simple style'
    docstring_1 = parse(str_1)
    assert (docstring_1.short_description == 'this is a docstring with simple style')
    str_2 = 'this is a docstring with simple style\nParagraphs are separated by blank lines.\n\nFirst Paragraph'\
        '\n\nParagraphs are separated by blank lines.'
    docstring_2 = parse(str_2)
    assert (docstring_2.short_description == 'this is a docstring with simple style')
    assert (docstring_2.long_description == 'Paragraphs are separated by blank lines.\n\nFirst Paragraph'\
        '\n\nParagraphs are separated by blank lines.')

# Generated at 2022-06-25 16:41:12.740206
# Unit test for function parse
def test_parse():

    # Case 1
    str_1 = 's@>`=&'
    docstring_1 = parse(str_1)
    assert docstring_1.summary == 's@>`=&'

    # Case 2
    str_2 = 's@>`=&\n'
    docstring_2 = parse(str_2)
    assert docstring_2.summary == 's@>`=&'

if __name__ == "__main__":
    test_parse()
    test_case_0()

# Generated at 2022-06-25 16:41:23.055799
# Unit test for function parse
def test_parse():
    str_0 = '\n        Args:@\n            name: The name of the author@\n            age: Author\'s age@\n        '
    str_1 = '\n        '
    str_2 = '\n        Args:@\n            name: The name of the author@\n            age: Author\'s age@\n        Raises:@\n            AttributeError: The ``name`` is set to a new value@\n        '
    str_3 = '\n        Args:@\n            name: The name of the author@\n            age: Author\'s age@\n        Returns:@\n            int. The return value is the age of the author@\n        '

# Generated at 2022-06-25 16:41:30.826072
# Unit test for function parse
def test_parse():
    str = 'Configures camera pin settings.\n\n        :param pin_config: Dictionary representing pin configuration.\n        :param pin_config: dict\n        :param pin_mode: Pin mode (0 for input and 1 for output).\n        :param pin_mode: int\n        :param pin_level: Pin level (0 for low and 1 for high).\n        :param pin_level: int\n        :param pin_number: Pin number.\n        :param pin_number: int\n        '
    docstring = parse(str)
    assert docstring.short_description == 'Configures camera pin settings.', 'Short description incorrect'
    assert docstring.long_description == '', 'Long description incorrect'
    assert len(docstring.params) == 5, 'Param count incorrect'

# Generated at 2022-06-25 16:41:40.976882
# Unit test for function parse
def test_parse():
    str_0 = "Returns the specified string with the first character capitalized if the specified string is not blank."
    str_1 = "Returns the specified string with the first character capitalized if the specified string is not blank.@param s@returns the specified string with the first character capitalized if the specified string is not blank."
    str_2 = "Returns the specified string with the first character capitalized if the specified string is not blank.@param s@returns the specified string with the first character capitalized if the specified string is not blank.@s@s"

# Generated at 2022-06-25 16:41:52.648522
# Unit test for function parse
def test_parse():
    str_0 = 's@>`=&'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 's'
    assert docstring_0.description == '@>`='
    assert docstring_0.meta == {}
    str_1 = "' <!+#!g>@,vw{B:W:}o5E;,I"
    docstring_1 = parse(str_1)
    assert docstring_1.summary == "' <!+#!g"
    assert docstring_1.description == '>@,vw{B:W:}o5E;,I'
    assert docstring_1.meta == {}
    str_2 = '})jJyw]4RB{F&h(>*'

# Generated at 2022-06-25 16:41:54.589093
# Unit test for function parse
def test_parse():
    test_case_0()

# Collect all test cases in this file

# Generated at 2022-06-25 16:42:03.230700
# Unit test for function parse
def test_parse():
    str_0 = 's@>`=&'
    style_0 = parse(str_0)
    assert style_0 == Style.google

    str_1 = 's;|~J'
    style_1 = parse(str_1)
    assert style_1 == Style.numpy

    str_2 = 's,oJ$'
    style_2 = parse(str_2)
    assert style_2 == Style.google

    str_3 = 'sXJ:y\x7f'
    style_3 = parse(str_3)
    assert style_3 == Style.numpy

    str_4 = 's>|\x7fJ'
    style_4 = parse(str_4)
    assert style_4 == Style.numpy

    str_5 = 's%j&'
   

# Generated at 2022-06-25 16:42:04.132731
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:42:16.156255
# Unit test for function parse

# Generated at 2022-06-25 16:42:21.400185
# Unit test for function parse
def test_parse():
    str_0 = 's@>`=&'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 's'
    assert docstring_0.extended_summary == '@>`='
    assert docstring_0.meta[0].name == '&'


# Generated at 2022-06-25 16:42:26.127694
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:42:32.838884
# Unit test for function parse
def test_parse():
    strs = [
        's@>`=&',
        's>@&`=',
        's=&`>@',
    ]
    for s in strs:
        docstring_0 = parse(s)
        assert docstring_0.short_description == 's'
        assert docstring_0.long_description == '@'
        assert docstring_0.meta == {
            '>': '`',
            '=': '&',
        }



# Generated at 2022-06-25 16:42:34.463867
# Unit test for function parse
def test_parse():
    res_0 = test_case_0()
    assert res_0 is not None

# Benchmark for function parse

# Generated at 2022-06-25 16:42:44.570190
# Unit test for function parse
def test_parse():
    func_0 = parse
    str_0 = """
    This function does something.
    """
    # docstring_0 = parse(str_0)
    docstring_0 = func_0(str_0)
    str_1 = 's@>`=&'
    docstring_1 = parse(str_1)
    str_2 = '"@"@$!%'
    docstring_2 = parse(str_2)
    str_3 = "TODO(me): implement"
    docstring_3 = parse(str_3)
    str_4 = """
    Describe what this function does.
    """
    docstring_4 = parse(str_4)
    str_5 = "Do a thing"
    docstring_5 = parse(str_5)

# Generated at 2022-06-25 16:43:04.413343
# Unit test for function parse

# Generated at 2022-06-25 16:43:07.395522
# Unit test for function parse
def test_parse():
    test_case_0()


# Test for additional functionality

# Test for the addition of a new style

# Generated at 2022-06-25 16:43:14.815793
# Unit test for function parse
def test_parse():
    str_0 = 'The main parsing routine.'
    docstring_0 = parse(str_0)
    assert docstring_0 == docstring_0
    str_1 = 's@>`=&'
    docstring_1 = parse(str_1)
    assert docstring_1 == docstring_1
    str_2 = 'Is there a way to do stepwise forward selection in sklearn?'
    docstring_2 = parse(str_2)
    assert docstring_2 == docstring_2
    str_3 = '((a+b))'
    docstring_3 = parse(str_3)
    assert docstring_3 == docstring_3
    str_4 = 'http://www.codingame.com/playgrounds/14213/exercice-de-python-les-dictionnaires/solutions'

# Generated at 2022-06-25 16:43:24.864667
# Unit test for function parse
def test_parse():
    str_0 = 's@>`=&'
    docstring_0 = parse(str_0)
    str_1 = 'Gn|K'
    docstring_1 = parse(str_1)
    str_2 = '_5R'
    docstring_2 = parse(str_2)
    str_3 = 'n>Zq'
    docstring_3 = parse(str_3)
    str_4 = 'zG)'
    docstring_4 = parse(str_4)
    str_5 = 'cC|Nv'
    docstring_5 = parse(str_5)
    str_6 = '8G'
    docstring_6 = parse(str_6)
    str_7 = 'jK;'
    docstring_7 = parse(str_7)
    str

# Generated at 2022-06-25 16:43:34.138543
# Unit test for function parse
def test_parse():
    # Test case 1
    str_1 = 's@>`=&'
    docstring_1 = parse(str_1)
    # Compare docstring_1 with expected value
    assert docstring_1 == Docstring(
        summary='',
        body='',
        rest='s@>`=&',
        meta='',
    )
    # Test case 2
    str_2 = ''
    docstring_2 = parse(str_2)
    # Compare docstring_2 with expected value
    assert docstring_2 == Docstring(
        summary='',
        body='',
        rest='',
        meta='',
    )
    # Test case 3
    str_3 = 'd$_0Yf'
    docstring_3 = parse(str_3)
    # Compare docstring_3 with expected value
