

# Generated at 2022-06-25 16:33:39.997642
# Unit test for function parse
def test_parse():
    str_0 = '{'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert docstring_0.return_annotation == ''
    assert not docstring_0.meta

    str_1 = '\n{}'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == ''
    assert docstring_1.long_description == ''
    assert docstring_1.return_annotation == ''
    assert not docstring_1.meta

    str_2 = '\n{} \n\n{'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == ''
    assert docstring_2.long_

# Generated at 2022-06-25 16:33:50.122114
# Unit test for function parse
def test_parse():
    str_0 = ';Zc+H^SLft\n*{'
    str_0_expected_parts = {
        'short_description': ';Zc+H^SLft\n*{',
        'long_description': '',
        'tags': {},
        'meta': {}
    }
    docstring_0 = parse(str_0) # expect ParseError
    str_1 = '<\x19|QC_<'
    str_1_expected_parts = {
        'short_description': '<\x19|QC_<',
        'long_description': '',
        'tags': {},
        'meta': {}
    }
    docstring_1 = parse(str_1, style=Style.google)
    docstring_1.short_description == str_1_

# Generated at 2022-06-25 16:33:58.173306
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 16:34:10.479440
# Unit test for function parse
def test_parse():
    from random import choice

    from docstring_parser.styles import STYLES

    # example values

# Generated at 2022-06-25 16:34:20.639204
# Unit test for function parse
def test_parse():
    str_0 = '=*2/\n`ZlT/n)@\n'
    style_0 = Style.google
    ret_0 = parse(str_0,style_0)
    assert ret_0 == None
    str_1 = 'D@V3XzY\nJ&dbZ,\n'
    style_1 = Style.auto
    ret_1 = parse(str_1,style_1)
    assert ret_1 == None
    str_2 = '{4&Fo6f\n+Xkc%\n\\HG}n\nE\n'
    style_2 = Style.numpy
    ret_2 = parse(str_2,style_2)
    assert ret_2 == None

# Generated at 2022-06-25 16:34:29.345346
# Unit test for function parse
def test_parse():
    str_0 = 'K-a"|";;z8T}\'\t'
    str_1 = 's;p$dP\t+A'
    str_2 = 'p\'y,#\tB*='
    str_3 = 'X,\\?\t>h0\n'
    str_4 = 'e\'LJ=<\nGtK'
    str_5 = '>a^q\n'
    str_6 = '20o(Ypt'
    str_7 = 'r|`$>c\th=\n'
    str_8 = '$^E\t2\t'
    str_9 = '\\C#\nsQ\\'
    str_10 = '\\Oy@Y\\"\n'

# Generated at 2022-06-25 16:34:32.587928
# Unit test for function parse
def test_parse():
    test_case_0()

    print("[OK] Function 'parse' is working properly")


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:34:38.796066
# Unit test for function parse
def test_parse():
    str_0 = '+}=PnY8E,.'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == '+}=PnY8E,.'
    str_1 = ''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == ''
    str_2 = '}B<U'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == '}B<U'
    str_3 = 'b-sM2!YJEv'
    docstring_3 = parse(str_3)
    str_4 = 'U>I+H-n_'
    docstring_4 = parse(str_4)

# Generated at 2022-06-25 16:34:50.073418
# Unit test for function parse
def test_parse():
    str_0 = '\n        This is the first line of the first paragraph\n            This is the second line of the first paragraph\n        This is the first line of the second paragraph\n            This is the second line of the second paragraph\n        '
    docstring_0 = parse(str_0)
    assert(docstring_0.short_description == 'This is the first line of the first paragraph')
    assert(len(docstring_0.long_description) == 2)
    assert(docstring_0.long_description[0] == 'This is the first line of the first paragraph\n            This is the second line of the first paragraph')
    assert(docstring_0.long_description[1] == 'This is the first line of the second paragraph\n            This is the second line of the second paragraph')

# Generated at 2022-06-25 16:34:55.071753
# Unit test for function parse
def test_parse():
    # Assertion error: assert 0 == 1
    str_0 = '\n'
    docstring_0 = parse(str_0)

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:35:08.457402
# Unit test for function parse
def test_parse():
    str_0 = '"""'
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)

    str_1 = 'google'
    style_1 = Style.google
    docstring_1 = parse(str_1, style_1)

    str_2 = 'google'
    style_2 = Style.google
    docstring_2 = parse(str_2, style_2)

    str_3 = 'google'
    style_3 = Style.google
    docstring_3 = parse(str_3, style_3)

    str_4 = 'google'
    style_4 = Style.google
    docstring_4 = parse(str_4, style_4)

    str_5 = 'google'
    style_5 = Style.google

# Generated at 2022-06-25 16:35:16.525659
# Unit test for function parse
def test_parse():
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)

    # None tests
    # Try to access forbidden attribute __weakref__ of docstring_0.meta
    try:
        vulnerable_0 = docstring_0.meta.__weakref__
    except Exception:
        vulnerable_0 = None
    assert vulnerable_0 is None

    # None tests
    # Try to access forbidden attribute __dict__ of docstring_0
    try:
        vulnerable_0 = docstring_0.__dict__
    except Exception:
        vulnerable_0 = None
    assert vulnerable_0 is None

    # None tests
    # Try to access forbidden attribute __dict__ of docstring_0.meta

# Generated at 2022-06-25 16:35:28.598573
# Unit test for function parse

# Generated at 2022-06-25 16:35:33.499894
# Unit test for function parse
def test_parse():
    assert callable(parse)
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)

if __name__ == "__main__":
    test_case_0()
    test_parse()
    print("Test passed")

# Generated at 2022-06-25 16:35:38.285577
# Unit test for function parse

# Generated at 2022-06-25 16:35:47.211242
# Unit test for function parse
def test_parse():
    text = '''
    A docstring example.

    :param arg1: first argument
    :type arg1: int
    :param arg2: second argument
    :type arg2: int
    :returns: sum of arguments
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.short_description == 'A docstring example.'
    assert len(docstring.long_description.lines) == 0
    assert len(docstring.params) == 2
    assert 'arg1' in docstring.params
    assert docstring.params['arg1'].arg_name == 'arg1'
    assert docstring.params['arg1'].description == 'first argument'
    assert docstring.params['arg1'].type_name == 'int'

# Generated at 2022-06-25 16:35:50.214920
# Unit test for function parse
def test_parse():
    assert 1



# Generated at 2022-06-25 16:35:51.340895
# Unit test for function parse
def test_parse():
    assert(parse('') == None)

# Generated at 2022-06-25 16:35:52.528441
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:35:56.612789
# Unit test for function parse
def test_parse():
    text = ':param int x: the x axis'
    docstring = parse(text)
    try:
        assert len(docstring.params) == 1
    except AssertionError:
        print('AssertionError raised!')

test_parse()
test_case_0()

# Generated at 2022-06-25 16:36:03.549337
# Unit test for function parse
def test_parse():
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)
    print(docstring_0)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:15.916191
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    str_0 = '{}\n{}\n{}\n{}\n{}\n{}\n{}'
    str_1 = '{}\n{}\n{}\n{}'
    str_2 = '{}'
    str_3 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.meta['short_description'] == str_1.format('', '', '', '')
    assert docstring_0.meta['long_description'] == str_2.format(str_0.format('', '', '', '', '', '', ''))
    assert docstring_0.parsed_content == str_3
    str_4 = '\n{}\n{}\n{}\n{}\n{}'
    str_5

# Generated at 2022-06-25 16:36:26.795227
# Unit test for function parse

# Generated at 2022-06-25 16:36:27.967530
# Unit test for function parse
def test_parse():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 16:36:39.129315
# Unit test for function parse
def test_parse():
    str_0 = '.8P|>wyDv"w5R0\n'
    str_1 = ';Zc+H^SLft\u0019'
    str_2 = ';Zc+H^SLft\n*{'
    str_3 = 'a8uA\u0013?A'
    str_4 = ';Zc+H^SLft\u0019'
    style_0 = Style.auto
    style_1 = Style.google
    style_2 = Style.numpy
    style_3 = Style.sphinx
    assert parse(str_3) == parse(str_2)
    assert parse(str_2) == parse(str_1)
    assert parse(str_1) == parse(str_0)

# Generated at 2022-06-25 16:36:42.863275
# Unit test for function parse
def test_parse():
    assert callable(parse)
    try:
        parse("Hello")
    except Exception:
        raise AssertionError("Unexpected exception raised")



# Generated at 2022-06-25 16:36:52.103854
# Unit test for function parse
def test_parse():

    # Test for function parse

    str_ = ';Zc+H^SLft\n*{'
    docstring_ = parse(str_)
    assert docstring_.summary == ';Zc+H^SLft'
    assert docstring_.description == '*{'
    assert docstring_.args == []
    assert docstring_.params == []
    assert docstring_.returns == None
    assert docstring_.raises == []

    str_ = 'returns for this\n\nthis is all for the returns'
    docstring_ = parse(str_)
    assert docstring_.summary == 'returns for this'
    assert docstring_.description == 'this is all for the returns'
    assert docstring_.args == []
    assert docstring_.params == []
    assert docstring_.returns == None
    assert docstring

# Generated at 2022-06-25 16:37:02.336952
# Unit test for function parse
def test_parse():
    str_0 = ';Zc+H^SLft\n*{'
    style_0 = Style.numpy
    docstring_0 = parse(str_0, style_0)
    assert docstring_0.meta == {'args': [], 'returns': []}
    str_1 = 'D8ef+g_?0'
    style_1 = Style.numpy
    docstring_1 = parse(str_1, style_1)
    assert docstring_1.meta == {'args': [], 'returns': []}
    str_2 = 'L>J^R'
    style_2 = Style.numpy
    docstring_2 = parse(str_2, style_2)
    assert docstring_2.meta == {'args': [], 'returns': []}
    str_

# Generated at 2022-06-25 16:37:10.648110
# Unit test for function parse
def test_parse():
    str_0 = ''
    style_0 = Style.default
    docstring_0 = parse(str_0, style_0)
    str_1 = ''
    style_1 = Style.numpy
    docstring_1 = parse(str_1, style_1)
    str_2 = ''
    style_2 = Style.google
    docstring_2 = parse(str_2, style_2)
    str_3 = ''
    style_3 = Style.sphinx
    docstring_3 = parse(str_3, style_3)
    str_4 = ''
    style_4 = Style.auto
    docstring_4 = parse(str_4, style_4)
    str_5 = ''
    style_5 = Style.reST

# Generated at 2022-06-25 16:37:18.511803
# Unit test for function parse
def test_parse():
    #from docstring_parser import parse
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)

    #from docstring_parser import parse
    str_1 = ';Zc+H^SLft\n*{'
    docstring_1 = parse(str_1)

    #from docstring_parser import parse
    str_2 = ';Zc+H^SLft\n*{'
    docstring_2 = parse(str_2)

    #from docstring_parser import parse
    str_3 = ';Zc+H^SLft\n*{'
    docstring_3 = parse(str_3)

    #from docstring_parser import parse

# Generated at 2022-06-25 16:37:32.654962
# Unit test for function parse
def test_parse():
    str_0 = '''
    Short summary.
    More summary.

    Params
    -----------
    a: int
        First param.
    b
        Second param

    Returns
    -------
    str
        Return value description.
    '''
    docstring_0 = parse(str_0)
    str_1 = '''
        Short summary.
        More summary.
    
        Params
        -----------
        a: int
            First param.
        b
            Second param
    
        Returns
        -------
        str
            Return value description.
        '''
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:37:35.822856
# Unit test for function parse
def test_parse():
    print("\n\n***Unit test for function parse***\n")
    print("Testing the first example.")
    test_case_0()
    print("Test passed!")



# Generated at 2022-06-25 16:37:47.020233
# Unit test for function parse
def test_parse():
    docstring = parse('', Style.google)
    assert docstring.full_summary == ''
    assert docstring.summary == ''
    assert docstring.description == ''
    assert len(docstring.params) == 0
    assert len(docstring.returns) == 0
    assert len(docstring.raises) == 0
    assert len(docstring.meta) == 0
    assert docstring.footer == ''

    docstring = parse('title\n----\n\nDescription\n', Style.google)
    assert docstring.full_summary == 'title'
    assert docstring.summary == 'title'
    assert docstring.description == 'Description'
    assert len(docstring.params) == 0
    assert len(docstring.returns) == 0
    assert len(docstring.raises) == 0

# Generated at 2022-06-25 16:37:56.060260
# Unit test for function parse
def test_parse():
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)
    assert docstring_0.args == []
    assert docstring_0.args_with_default == []
    assert docstring_0.args_with_annotation == []
    assert docstring_0.varargs == ''
    assert docstring_0.varkwargs == ''
    assert docstring_0.ret == ''
    assert docstring_0.ret_with_annotation == ''
    assert docstring_0.summary == ''
    assert docstring_0.meta == {}
    str_1 = ';Zc+H^SLft\n*{'
    docstring_1 = parse(str_1)
    assert docstring_1.args == []
    assert docstring_

# Generated at 2022-06-25 16:38:08.996686
# Unit test for function parse
def test_parse():
    # run_testcase_0
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == ';Zc+H^SLft*{'
    assert docstring_0.description == None
    assert docstring_0.extended_summary == None
    assert docstring_0.params == []
    assert docstring_0.returns == None
    assert docstring_0.return_type == None
    assert docstring_0.raises == []
    assert docstring_0.meta == []

    # run_testcase_1
    str_1 = 'F:=,\n+m~e'
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:38:13.460947
# Unit test for function parse
def test_parse():
    assert callable(parse)

if __name__ == '__main__':
    test_case_0()
    test_parse()
    print("All tests passed successfully")

# Generated at 2022-06-25 16:38:15.577018
# Unit test for function parse
def test_parse():
    # No errors
    try:
        test_case_0()
    except:
        assert False

    # Invalid input type
    test_case_1()



# Generated at 2022-06-25 16:38:20.962697
# Unit test for function parse
def test_parse():
    # SOMETHING
    # SOMETHING ELSE
    # SOMETHING
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)

    assert docstring_0.meta['title'] == 'SOMETHING'
    assert docstring_0.meta['description'] == ['SOMETHING ELSE', 'SOMETHING']

test_parse()



# str_0 = ';Zc+H^SLft\n*{'
# docstring_0 = parse(str_0)
# print(docstring_0.meta['title'])
# print(docstring_0.meta['description'])
# print(docstring_0.meta['description'])

# Generated at 2022-06-25 16:38:26.381282
# Unit test for function parse
def test_parse():
    assert callable(parse)


if __name__ == '__main__':
    import sys
    import timeit

    # Unit test for function parse
    test_parse()

    # Performance test for function parse
    print(timeit.timeit(stmt="test_case_0()", setup="from __main__ import test_case_0", number=100000))

    sys.exit(0)

# Generated at 2022-06-25 16:38:30.002052
# Unit test for function parse
def test_parse():
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:38:43.476707
# Unit test for function parse

# Generated at 2022-06-25 16:38:54.547672
# Unit test for function parse
def test_parse():
    str_0 = ''
    str_1 = '"\x1d}6U5rx6Sv'
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    assert (docstring_0.meta == {})
    assert (docstring_0.short_description == None)
    assert (docstring_0.long_description == None)
    assert (docstring_0.params == {})
    assert (docstring_0.returns == None)
    assert (docstring_0.examples == [])
    assert (docstring_1.meta == {})
    assert (docstring_1.short_description == None)
    assert (docstring_1.long_description == None)
    assert (docstring_1.params == {})

# Generated at 2022-06-25 16:39:04.865688
# Unit test for function parse
def test_parse():
    def test_case_0():
        str_0 = 'J&bX1xa4!4:)'
        docstring_0 = parse(str_0)
        assert (docstring_0.meta.summary == str_0)

    def test_case_1():
        str_0 = 'Wf_l<!l%cV7-T'
        docstring_0 = parse(str_0)
        assert (docstring_0.meta.summary == str_0)

    def test_case_2():
        str_0 = '1%:@l[0o`5;G&'
        docstring_0 = parse(str_0)
        assert (len(docstring_0.params) == 0)


# Generated at 2022-06-25 16:39:13.705593
# Unit test for function parse
def test_parse():
    str_0 = 'We are not what we should be!\nWe are not what we need to be.\nBut at least we are not what we used to be\n(Football Coach)'
    str_1 = 'We are not what we should be!\nWe are not what we need to be.\nBut at least we are not what we used to be\n(Football Coach)'
    str_2 = 'We are not what we should be!\nWe are not what we need to be.\nBut at least we are not what we used to be\n(Football Coach)'
    str_3 = 'We are not what we should be!\nWe are not what we need to be.\nBut at least we are not what we used to be\n(Football Coach)'

# Generated at 2022-06-25 16:39:16.388483
# Unit test for function parse
def test_parse():
    tool = parse
    assert tool('#%cB') == None
    assert tool('Jj@F^v') == None
    assert tool('t') == None
    assert tool('8') == None

# Generated at 2022-06-25 16:39:25.098897
# Unit test for function parse
def test_parse():
    # This function simulates the command line input and calls the function
    # 'parse' which is in src/docstring_parser/parser.py with given arguments
    # For example, parse(args.text, style=args.style)
    str_0 = ';Zc+H^SLft\n*{'
    style_0 = Style.auto
    docstring_0 = parse(str_0, style_0)

    assert docstring_0.full_docstring == ';Zc+H^SLft\n*{\n'
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:39:33.264376
# Unit test for function parse
def test_parse():
    # Input parameters:
    text = 'follow r2l from p1.x, p2.x to p3.x, p3.y'

    # `style`:
    style = Style.auto

    docstring = parse(text, style)
    # Test assertions:
    assert docstring.summary == 'follow r2l from p1.x, p2.x to p3.x, p3.y'
    assert docstring.extended_summary == None
    assert len(docstring.meta) == 0
    assert len(docstring.params) == 0
    assert len(docstring.params_full) == 0
    assert len(docstring.args) == 0
    assert len(docstring.returns) == 0
    assert len(docstring.yields) == 0

# Generated at 2022-06-25 16:39:44.270068
# Unit test for function parse
def test_parse():
    from random import choice, shuffle
    from docstring_parser.common import Parameter
    from docstring_parser.styles import STYLES, Style
    from copy import copy
    cases = []
    # str_0 = ':Zc+H^SLft\n*n'
    str_0 = ''
    cases.append((str_0, Style.google,
                 Docstring(short_description='', long_description='',
                           params=[], returns=None, raises=[], attributes=[],
                           params_short=[], returns_short=None, raises_short=[],
                           attributes_short=[], summary_short='')))
    # str_0 = '(-#1_E*\x1f"+=8Y;\nM\x1d'

# Generated at 2022-06-25 16:39:49.323862
# Unit test for function parse
def test_parse():
    print('Testing parse... ', end='')
    docstring = parse('''\
        """
        Short summary.

        Extended description.

        Parameters
        ----------
        arg1: int
            Description of `arg1`
        arg2: str
            Description of `arg2`

        Returns
        -------
        str
            Description of return value.
        """
    ''')
    assert docstring.short_description == 'Short summary.'
    assert str(docstring) == '''\
        Short summary.

        Extended description.


        Parameters
        ----------
        arg1: int
            Description of `arg1`
        arg2: str
            Description of `arg2`


        Returns
        -------
        str
            Description of return value.
    '''
    print('Passed.')


# Generated at 2022-06-25 16:39:57.801329
# Unit test for function parse
def test_parse():
    from docstring_parser.parse import parse
    from docstring_parser.styles import Style

    str_0 = '\n    Parse the docstring into its components.\n\n    :returns: parsed docstring representation\n    '
    docstring_0 = parse(str_0, style=Style.numpy)
    assert docstring_0.short_description == 'Parse the docstring into its components.'
    assert docstring_0.long_description.startswith('\n    Parse the docstring into its components.\n\n    ')
    assert len(docstring_0.returns) == 1
    assert docstring_0.returns[0].type_name == 'Docstring'
    assert docstring_0.returns[0].description == 'parsed docstring representation'


# Generated at 2022-06-25 16:40:13.335028
# Unit test for function parse
def test_parse():
    str_0 = 'g/@J/q\nIzHc%A?!\nMgf5q[aHG'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'IzHc%A?!\nMgf5q[aHG'
    assert docstring_0.long_description == 'g/@J/q'
    assert docstring_0.returns is None
    assert docstring_0.return_type is None
    assert len(docstring_0.raises) == 0
    assert len(docstring_0.yields) == 0
    assert len(docstring_0.meta) == 0

    str_1 = ''
    docstring_1 = parse(str_1)
    assert docstring_1.short_description

# Generated at 2022-06-25 16:40:14.709205
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:40:23.334770
# Unit test for function parse
def test_parse():
    param_0 = 'v'
    param_1 = 'd'
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)
    assert(len(docstring_0.meta) == 2)
    assert(len(docstring_0.short_description) == 1)
    assert(docstring_0.short_description[0] == str_0)
    assert(len(docstring_0.long_description) == 2)
    assert(docstring_0.long_description[0] == str_0)
    assert(len(docstring_0.params) == 1)
    assert(len(docstring_0.params[param_0]) == 2)

# Generated at 2022-06-25 16:40:30.455996
# Unit test for function parse
def test_parse():
    # Test for MatchError
    str_0 = '9!?R$k!zMv^\nM4Tw'
    docstring_0 = parse(str_0)
    str_1 = '^F'
    docstring_1 = parse(str_1)
    # Test for MatchError
    str_2 = 'T*pG=fk\n@K>:[g94'
    docstring_2 = parse(str_2)
    str_3 = 'B2'
    docstring_3 = parse(str_3)
    str_4 = '\'\nBtTb,(g-\nK\n'
    docstring_4 = parse(str_4)
    str_5 = '%cM\nmzK*ct\n-\nF&\n'
    docstring_

# Generated at 2022-06-25 16:40:39.106736
# Unit test for function parse
def test_parse():
    text = 'Pylint uses astroid to parse Python code into an AST ' \
       'and can optionally check it against coding standards.' \
       '\n\n :param text: docstring text to parse\n' \
       ' :param style: docstring style\n :returns: parsed docstring representation\n'
    res = parse(text)
    return res

if __name__ == '__main__':
    print(test_parse())

# Generated at 2022-06-25 16:40:46.775916
# Unit test for function parse
def test_parse():
    str_0 = 'Keyword arguments:\n    length -- length of the fibonacci series\n\n    Returns:returns the fibonacci series \n\n    '
    str_1 = 'This is my docstring.'
    str_2 = 'Keyword arguments:\n    length -- length of the fibonacci series\n\n    Returns:returns the fibonacci series \n\n    '
    str_3 = 'Keyword arguments:\n    length -- length of the fibonacci series\n\n    Returns:returns the fibonacci series \n\n    '
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    docstring_2 = parse(str_2)
    docstring_3 = parse(str_3)

# Generated at 2022-06-25 16:40:53.609581
# Unit test for function parse
def test_parse():
    # Arguments:
    text_0 = 'xxxxxxxx\nx'
    text_1 = 'xxxxxxxx\nx'
    text_2 = 'xxxxxxxx\nx'
    text_3 = 'xxxxxxxx\nx'
    text_4 = 'xxxxxxxx\nx'
    text_5 = 'xxxxxxxx\nx'
    text_6 = 'xxxxxxxx\nx'
    text_7 = 'xxxxxxxx\nx'
    text_8 = 'xxxxxxxx\nx'
    text_9 = 'xxxxxxxx\nx'
    text_10 = 'xxxxxxxx\nx'
    text_11 = 'xxxxxxxx\nx'
    text_12 = 'xxxxxxxx\nx'
    text_13 = 'xxxxxxxx\nx'
    text_14 = 'xxxxxxx\nx'
    text_15 = 'xxxxxxx\nx'

# Generated at 2022-06-25 16:41:04.215051
# Unit test for function parse
def test_parse():

    str_0 = """@param foo: The foo parameter.
@type foo: str
@param bar: The bar parameter.
@type bar: str
@returns: The return value.
@rtype: str
"""
    docstring_0 = parse(str_0)
    str_1 = """The foo parameter.
:type foo: str
:param bar: The bar parameter.
:type bar: str
:returns: The return value.
:rtype: str
"""
    docstring_1 = parse(str_1)

# ## Test Parse
# class TestParse(TestCase):
#
#     def test_parse(self):
#         self.parse_docstring("""@param foo: The foo parameter.
# @type foo: str
# @param bar: The bar parameter.
# @type bar: str

# Generated at 2022-06-25 16:41:06.150331
# Unit test for function parse
def test_parse():
    test_case_0()

# Main function

# Generated at 2022-06-25 16:41:15.090826
# Unit test for function parse
def test_parse():
    print("Test of function parse")

    # The following test cases correspond to the examples found in the pdf
    # that was shared on Piazza
    str_0 = '''ABSTRACT: The purpose of the class is to allow for a simple
            math operation to be performed on an array of values in some form
            of a vector. The operations include addition, subtraction,
            multiplication, division, and exponentiation. There is a special
            power method for performing exponentiation on a large array of
            numbers.
    '''
    docstring_0 = parse(str_0)
    print(docstring_0)

# Generated at 2022-06-25 16:41:22.589100
# Unit test for function parse
def test_parse():
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    import timeit
    print(timeit.timeit("test_parse()", setup="from __main__ import test_parse", number=10))

# Generated at 2022-06-25 16:41:28.363126
# Unit test for function parse
def test_parse():
    str_0 = '#X-jM;I"V|b.>y\n=@!w<+j7'
    docstring_0 = parse(str_0)
    assert docstring_0[0] == '#X-jM;I"V|b.>y\n=@!w<+j7'
    assert docstring_0[1] == ''
    assert docstring_0[2] == ''
    return 'unit_test_passed'


# Generated at 2022-06-25 16:41:32.943958
# Unit test for function parse
def test_parse():
    assert callable(parse)

if __name__ == '__main__':
    test_case_0()
    test_parse()
    print('All test cases passed.')

# Generated at 2022-06-25 16:41:34.713409
# Unit test for function parse
def test_parse():
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:41:35.710727
# Unit test for function parse
def test_parse():
    assert None


# Generated at 2022-06-25 16:41:39.777184
# Unit test for function parse
def test_parse():
    # Given
    str_0 = 'return a+b'
    style_0 = Style.numpy

    # When
    docstring_0 = parse(str_0, style_0)

    # Then
    assert docstring_0.meta['returns'] == [{'type': '', 'description': 'a+b'}]


# Generated at 2022-06-25 16:41:47.233071
# Unit test for function parse
def test_parse():
    import sys
    import random
    print('Testing function parse')
    print('# Calling function parse...')
    try:
        test_case_0()
        pass
    except BaseException as e:
        print('An exception was raised in test_case_0')
        print(f'Exception: {e}')
        print('Please check the log file for details')
        sys.exit(1)
    else:
        print('Test case 0 passed')
    print('# Function parse ran to completion.')


# Program entry point

# Generated at 2022-06-25 16:41:51.969224
# Unit test for function parse
def test_parse():
    assert callable(parse)
    docstring_0 = parse('')
    assert docstring_0 is not None
    assert docstring_0.meta is not None
    assert docstring_0.desc is not None
    assert docstring_0.params is not None
    assert docstring_0.returns is not None
    assert docstring_0.raises is not None
    assert docstring_0.examples is not None
    assert docstring_0.yields is not None
    assert docstring_0.see_also is not None

# Generated at 2022-06-25 16:41:52.702584
# Unit test for function parse
def test_parse():
    assert True



# Generated at 2022-06-25 16:42:02.580298
# Unit test for function parse
def test_parse():
    str_0 = ''
    style_0 = Style.reST
    style_1 = Style.numpy
    style_2 = Style.google
    style_3 = Style.yas
    style_4 = Style.auto
    assert style_0 != style_1 != style_2 != style_3 != style_4 != style_0
    assert len(set(STYLES.keys())) == 5
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_0, style = style_0)
    docstring_2 = parse(str_0, style = style_1)
    docstring_3 = parse(str_0, style = style_2)
    docstring_4 = parse(str_0, style = style_3)

# Generated at 2022-06-25 16:42:09.451126
# Unit test for function parse
def test_parse():
    test_case_0()
    test_parse.__doc__ = parse.__doc__

# Test suite for parse

# Generated at 2022-06-25 16:42:20.460746
# Unit test for function parse
def test_parse():
    str_0 = '8:}W5e'
    docstring_0 = parse(str_0)

    str_1 = 'MrdH]t:*R-Z#>0'
    str_2 = '8#?WX].'
    str_3 = 'L-4W8:5pBhPr?w#x>'
    str_4 = 'YHN<b1"g~[Rt(P'
    docstring_1 = parse(str_1)
    str_5 = '+L'
    str_6 = '_IH'
    str_7 = 'Jg(R'
    str_8 = 'UN<&U{'
    docstring_2 = parse(str_2)
    str_9 = 'p'
    str_10 = '{'
   

# Generated at 2022-06-25 16:42:26.069470
# Unit test for function parse
def test_parse():
    str_0 = 'This is a docstring.'
    str_1 = 'This is a docstring.\n'
    text_0 = 'class '
    text_1 = 'This is a docstring.'
    text_expect = 'This is a docstring.'
    docstring_0 = parse(text_1)
    r0 = docstring_0.description
    r1 = docstring_0.description_short
    assert r1 == text_expect and r0 == text_expect
    str_2 = 'This is a docstring.\n\nThis is a second paragraph.'
    docstring_1 = parse(str_2)
    r2 = docstring_1.description
    r3 = docstring_1.description_short
    assert r3 == text_expect and r2 == str_2

#

# Generated at 2022-06-25 16:42:35.665157
# Unit test for function parse
def test_parse():
    func_0 = parse
    str_0 = 'This is a docstring.'
    docstring_0 = func_0(str_0)
    value_0 = docstring_0.content
    value_1 = str_0
    assert (value_0 == value_1)
    str_1 = 'This is a docstring.\n\nThis is the second line.\n\n\nThis is the third line.'
    docstring_1 = func_0(str_1)
    value_2 = docstring_1.content
    value_3 = str_1
    assert (value_2 == value_3)
    str_2 = 'This is a docstring.\n\nArgs:\narg: argument'
    docstring_2 = func_0(str_2)
    value_4 = docstring_2

# Generated at 2022-06-25 16:42:44.422467
# Unit test for function parse
def test_parse():
    # print("\n\n=== Initialize test cases ===")
    str_0 = ';Zc+H^SLft\n*{'
    # print("\n--- Init docstring_0 ---")
    docstring_0 = parse(str_0)

    # print("\n=== Run test cases ===")
    # print("\n--- Run parse docstring_0 ---")
    docstring_0 = parse(str_0)
    # print("\n=== Pass test cases ===")
    # print("\n--- Pass parse docstring_0 ---")

if __name__ == '__main__':
    # print("\n=== Begin main function ===")
    test_case_0()
    # test_parse()
    # print("=== End main function ===")

# Generated at 2022-06-25 16:42:55.797932
# Unit test for function parse
def test_parse():
    str_0 = 'r>D*VCk-g|]j+Mvg%'
    result_0 = parse(str_0)
    assert result_0.docstring == str_0
    str_1 = ':|9fYOo&P"p;!cU(=F\n'
    result_1 = parse(str_1)
    assert result_1.docstring == str_1
    str_2 = 'wQ?VR+f\n`4^%Ks'
    result_2 = parse(str_2)
    assert result_2.docstring == str_2
    str_3 = '^!61/j0'
    result_3 = parse(str_3)
    assert result_3.docstring == str_3
    str_4 = '*f11\n'

# Generated at 2022-06-25 16:43:05.502821
# Unit test for function parse
def test_parse():
    # docstring case 0
    str_0 = ';Zc+H^SLft\n*{'
    docstring_0 = parse(str_0, style=Style.numpy)
    assert docstring_0.summary == ';Zc+H^SLft'
    assert docstring_0.body == '*{'
    assert docstring_0.meta == {}
    assert docstring_0.tags == []
    # docstring case 1
    str_1 = 'eO.O}>;\t$aX\n+?<\n\tD[~:Q]'
    docstring_1 = parse(str_1, style=Style.sphinx)
    assert docstring_1.summary == 'eO.O}>;\t$aX'

# Generated at 2022-06-25 16:43:06.779826
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:43:07.664551
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:43:10.385887
# Unit test for function parse
def test_parse():
    str_0 = '-\n  ```py\n  Description\n  ```\n  -\n  '
    docstring_0 = parse(str_0)
    return str_0


# Generated at 2022-06-25 16:43:24.400128
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    from collections import OrderedDict
    str_108 = '\n    Generate a new random number. The number is uniformly distributed between\n    0.0 and 1.0\n    \n    \n    :rtype: float\n    '
    docstring_108 = parse(str_108)
    assert docstring_108.short_description == 'Generate a new random number. The number is uniformly distributed between'
    assert docstring_108.long_description == '0.0 and 1.0'
    assert docstring_108.meta == OrderedDict([('rtype', 'float')])

# Generated at 2022-06-25 16:43:27.043270
# Unit test for function parse
def test_parse():
    a = '"%Y-%m-%d"'
    docstring = parse(a)
    assert docstring.summary == a


