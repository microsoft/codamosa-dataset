

# Generated at 2022-06-25 16:33:38.832782
# Unit test for function parse
def test_parse():
    str_0 = ':param a:b\ndf\n:type a:bl'
    docstring_0 = parse(str_0)
    assert docstring_0.params["a"].description == "b\ndf"
    assert docstring_0.params["a"].type == "bl"


# Generated at 2022-06-25 16:33:48.604958
# Unit test for function parse
def test_parse():
    text_0 = ':\x0ct4w0<Zts'
    style_0 = Style.googledoc
    assert parse(text_0, style_0) == ':\x0ct4w0<Zts'
    text_1 = '.ZbGJ|\x0b|'
    style_1 = Style.googledoc
    assert parse(text_1, style_1) == '.ZbGJ|\x0b|'
    text_2 = ''
    style_2 = Style.googledoc
    assert parse(text_2, style_2) == ''
    text_3 = '_6\nh6`g'
    style_3 = Style.googledoc
    assert parse(text_3, style_3) == '_6\nh6`g'
   

# Generated at 2022-06-25 16:33:51.318079
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:33:52.571202
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:33:59.593106
# Unit test for function parse
def test_parse():
    func_0 = 'k9\x0c(7<Wk'
    str_0 = 'Dd\x0c&0"zd'
    class_0 = 'Km\x0b8(%Ow'
    str_1 = '4l\x0b+5,Sk'
    class_1 = 'Kj\x0bQ4?1f'
    str_2 = '?|\x0bP;!Vd'
    class_2 = '!I\x0bw7#]d'
    str_3 = 'Yd\x0bq3/h0'
    class_3 = '=,\x0bv6#^l'
    str_4 = ' s\x0b~7&*z'

# Generated at 2022-06-25 16:34:07.156072
# Unit test for function parse
def test_parse():
    #assert  # TODO: implement your test here
    assert True # TODO: implement your test here

# Unit tests for class Docstring

# Unit tests for class Style

# Unit tests for class ParseError

# Unit tests for class Argument

# Unit tests for class Section

# Unit tests for class ExamplesSection

# Unit tests for class RaisesSection

# Unit tests for class YieldsSection

# Unit tests for class ReturnsSection

# Unit tests for class ParamSection

# Unit tests for class AttributeSection

# Unit tests for class KeywordSection

# Unit tests for class NoteSection

# Unit tests for class VariableSection

# Unit tests for class WarningSection

# Unit tests for class ExtendedSummarySection

# Unit tests for class ExtendedSection

# Unit tests for class Meta

# Unit tests for class MetaPair

# Generated at 2022-06-25 16:34:15.184016
# Unit test for function parse
def test_parse():
    str_0 = "foo bar baz"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "foo bar baz"
    assert docstring_0.long_description == ""
    assert docstring_0.meta == {}
    str_1 = "foo"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "foo"
    assert docstring_1.long_description == ""
    assert docstring_1.meta == {}
    str_2 = "foo\nbar\nbaz\n"
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == "foo"
    assert docstring_2.long_description == "bar\nbaz"
    assert docstring_2.meta

# Generated at 2022-06-25 16:34:17.121742
# Unit test for function parse
def test_parse():
    test_case_0()


# Generated at 2022-06-25 16:34:22.748484
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:34:25.837000
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)


if __name__ == "__main__":
    test_parse()
    test_case_0()

# Generated at 2022-06-25 16:34:32.065725
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:34:34.172453
# Unit test for function parse
def test_parse():
    str_0 = ''
    style_0 = Style.google

    docstring_0 = parse(str_0, style_0)

# Generated at 2022-06-25 16:34:41.927056
# Unit test for function parse
def test_parse():
    # Stubs
    str_0 = ':param x:f\n\n:returns: f\n'
    str_1 = ':param x:f\n\n:returns: f\n\n'
    str_2 = ':param x:f\n\n:returns: f\n\n:raises f: test\n'

    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    docstring_2 = parse(str_2)

    assert docstring_0.body == ''
    assert docstring_0.meta['params']['x'] == 'f'
    assert docstring_0.meta['returns'] == 'f'
    assert not docstring_0.meta['raises']


# Generated at 2022-06-25 16:34:53.406426
# Unit test for function parse
def test_parse():
    text = 'Title\n\nArgs:\n\tfoo: bar\n\t'
    assert parse(text).args == [('foo', 'bar')]

    text = "Title\n\narg1:\n\tblah\narg2:\n\tblah"
    assert parse(text).args == [('arg1', 'blah'), ('arg2', 'blah')]

    text = "Title\n\nArgs:\n\targ1 (foo):\n\t\tblah\n\targ2:\n\t\tblah"
    assert parse(text).args == [
        ('arg1', 'blah (foo)'), ('arg2', 'blah')
    ]


# Generated at 2022-06-25 16:34:54.753202
# Unit test for function parse
def test_parse():
    assert True == True


# Generated at 2022-06-25 16:35:03.116229
# Unit test for function parse
def test_parse():
    docstring_0 = parse('\x1d\x039N\xc2a\x19\x05\x7f\x16\x19g\x0e\x1d\xc3!r\x0b\x13\x14\x7fz\x0e')
    assert docstring_0.short_description == '\x1d\x039N\xc2a\x19\x05\x7f\x16\x19g\x0e\x1d\xc3!r\x0b\x13\x14\x7fz\x0e'
    assert docstring_0.long_description == ''
    assert not docstring_0.meta

# Generated at 2022-06-25 16:35:05.709504
# Unit test for function parse
def test_parse():
    assert (not (5 == 5))
    assert (5 != 5)
    assert (5 != 5)

test_parse()

# Generated at 2022-06-25 16:35:16.159848
# Unit test for function parse
def test_parse():
    expected_0 = ':\x0ct4w0<Zts'
    assert_equal(expected_0, parse(expected_0))
    assert_equal(expected_0, parse(expected_0, Style.one_liner))
    assert_equal(expected_0, parse(expected_0, Style.short))
    assert_equal(expected_0, parse(expected_0, Style.restructured))
    assert_equal(expected_0, parse(expected_0, Style.google))
    assert_equal(expected_0, parse(expected_0, Style.numpy))
    assert_equal(expected_0, parse(expected_0, Style.epytext))
    assert_equal(expected_0, parse(expected_0, Style.napoleon))

# Generated at 2022-06-25 16:35:17.728484
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:35:20.761878
# Unit test for function parse
def test_parse():
    text = 'doctest placeholder'
    style = 'doctest placeholder' # Placeholder
    assert 1==1 # Placeholder until implemented
    return

# Generated at 2022-06-25 16:35:26.341857
# Unit test for function parse
def test_parse():
    assert callable(parse)

# ======= end ======= #

# Generated at 2022-06-25 16:35:32.425101
# Unit test for function parse
def test_parse():
    assert parse(':\x0ct4w0<Zts') == parse(':\x0ct4w0<Zts')
    assert parse(':\x0ct4w0<Zts') == parse(':\x0ct4w0<Zts')
    assert parse(':\x0ct4w0<Zts') == parse(':\x0ct4w0<Zts')
    assert parse(':\x0ct4w0<Zts') == parse(':\x0ct4w0<Zts')
    assert parse(':\x0ct4w0<Zts') == parse(':\x0ct4w0<Zts')

# Generated at 2022-06-25 16:35:37.035820
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import SphinxStyle
    docstring = SphinxStyle.parse('')
    assert docstring.meta == ''
    assert docstring.body == ''
    assert docstring.returns == None

# Test string length

# Generated at 2022-06-25 16:35:38.821242
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:35:41.917938
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:35:43.942409
# Unit test for function parse
def test_parse():

    string = "Test docstring for testing purpose"
    docstring = parse(str_0)
    assert docstring.short_description == 'Test docstring for testing purpose'


# Generated at 2022-06-25 16:35:52.808338
# Unit test for function parse
def test_parse():

    str_2 = 'some text'
    docstring_2 = parse(str_2, Style.sphinx)
    assert docstring_2.short_description == 'some text'
    assert docstring_2.long_description == ''
    assert docstring_2.meta.keys() == ['param']
    assert docstring_2.meta[ 'param' ] == []

    str_3 = ' :param int plop: plop param'
    docstring_3 = parse(str_3, Style.sphinx)
    assert docstring_3.short_description == ''
    assert docstring_3.long_description == ''
    assert docstring_3.meta.keys() == ['param']
    assert docstring_3.meta[ 'param' ] == [('plop', 'int', 'plop param')]

    str

# Generated at 2022-06-25 16:36:03.849141
# Unit test for function parse

# Generated at 2022-06-25 16:36:07.912041
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:36:11.927517
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == ':\x0ct4w0<Zts'


# Generated at 2022-06-25 16:36:29.356214
# Unit test for function parse
def test_parse():
    str_0 = '[{{}}]{{}}'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:36:32.799912
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:36:35.235872
# Unit test for function parse
def test_parse():
    arg0 = ':\x0ct4w0<Zts'
    ret0 = parse(arg0)



# Generated at 2022-06-25 16:36:47.044344
# Unit test for function parse
def test_parse():
    # Test case 0
    x = ':\x0ct4w0<Zts'
    expected0 = parse(x)
    actual0 = Docstring(summary='',
                        body='',
                        meta={},
                        examples=[])
    assert expected0 == actual0

    # Test case 1
    x1 = '\x0b>\'\x0cB:\x0ce)y+\x0cM'
    expected1 = parse(x1)
    actual1 = Docstring(summary='',
                        body='',
                        meta={},
                        examples=[])
    assert expected1 == actual1

    # Test case 2
    x2 = '\x0b1\x0cv#\x0bB\x0c8\x0c=%\x0cI\x0cJ\x0c;'


# Generated at 2022-06-25 16:36:53.067019
# Unit test for function parse
def test_parse():
    # Test case 0
    assert parse(':\x0ct4w0<Zts') == Docstring(summary='', description='',
                                              meta={}, examples=(':\x0ct4w0<Zts',),
                                              returns=None,
                                              raises=None)
    # Test case 1
    assert parse('YnZ4^Cw-\x19\x1a"Ui') == Docstring(summary='', description='',
                                              meta={}, examples=('YnZ4^Cw-\x19\x1a"Ui',),
                                              returns=None,
                                              raises=None)
    # Test case 2

# Generated at 2022-06-25 16:36:54.949873
# Unit test for function parse
def test_parse():
    d = parse('Hello world.')
    assert d.short_description == 'Hello world.'


# Generated at 2022-06-25 16:36:56.775823
# Unit test for function parse
def test_parse():
    assert parse('::\n') == None

if __name__ == '__main__':
    test_parse()
    test_case_0()

# Generated at 2022-06-25 16:36:59.903812
# Unit test for function parse
def test_parse():
    assert inspect.isfunction(parse)
    assert parse("\n")
    assert parse("\n", Style.google)
    assert parse("\n", Style.numpy)
    assert parse("\n", Style.auto)


# Generated at 2022-06-25 16:37:02.895813
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:37:11.021329
# Unit test for function parse
def test_parse():
    # Sample inputs and expected outputs

    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)

    str_1 = '\x0b'
    docstring_1 = parse(str_1)

    str_2 = '\x06'
    docstring_2 = parse(str_2)

    str_3 = '\x16\x1b'
    docstring_3 = parse(str_3)

    str_4 = '\x1f'
    docstring_4 = parse(str_4)

    str_5 = '\x1c'
    docstring_5 = parse(str_5)

    str_6 = '\x0c'
    docstring_6 = parse(str_6)


# Generated at 2022-06-25 16:37:28.882868
# Unit test for function parse
def test_parse():
    str = 'Tests for docstring_parser package'
    docstring = parse(str)
    assert docstring.short_description == 'Tests for docstring_parser package'
    assert docstring.long_description == None
    assert isinstance(docstring.meta, list)
    assert isinstance(docstring.params, list)
    assert isinstance(docstring.returns, list)
    assert isinstance(docstring.raises, list)
    assert isinstance(docstring.yields, list)


# Generated at 2022-06-25 16:37:29.801666
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:37:37.625334
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)

    str_0 = 't9\x1d\x1e\x1f'
    docstring_0 = parse(str_0)
    
    str_0 = 'm\x12;&,\x0c'
    docstring_0 = parse(str_0)

    str_0 = 'l\x00,2\x00; '
    docstring_0 = parse(str_0)

    str_0 = 'j>\x0eC=\x1e\x1f'
    docstring_0 = parse(str_0)

    str_0 = 'z\x14\x0c\x11\x17\x1f'
    docstring_0 = parse(str_0)

    str_

# Generated at 2022-06-25 16:37:45.756031
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)
    str_1 = 'Y\\\x0b8W&!$Gjd4\x0e'
    docstring_1 = parse(str_1, Style.google)
    str_2 = '\x02p7h\x07\x01\x0e\x0eY'
    docstring_2 = parse(str_2, Style.google)
    str_3 = '&z\x0e\x0b\x06<\x0f\x0f.'
    docstring_3 = parse(str_3, Style.google)
    str_4 = '\x0fU\x03u\\\x07\x04\x04'
    docstring_

# Generated at 2022-06-25 16:37:46.645071
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:37:51.874611
# Unit test for function parse
def test_parse():
    style = Style.rst
    text = ':\x0ct4w0<Zts'
    docstring_0 = parse(text, style)
    assert docstring_0.short_description == ':\x0ct4w0<Zts'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:37:58.948534
# Unit test for function parse
def test_parse():
    # Parses the docstring into its components.

    str_0 = ""

	# Style: Google
    str_1 = 'Short summary.\n\nMore detailed description.\n\nArgs:\n  arg1: Description of `arg1`.\n  arg2: Description of `arg2`.\n\nReturns:\n  Description of return value.\n'
    docstring_1 = parse(str_1)
    is_instance_0(docstring_1, Docstring)


# Generated at 2022-06-25 16:38:00.490284
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:38:08.705753
# Unit test for function parse
def test_parse():
    str_0 = '_o4|4y-~7\u001a)5\x04@1}S'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == str_0, "Simple description"

    str_1 = '\x1d\x1a\x06\x0f\x0e\x17\x12 '
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == str_1, "Simple description"

    str_2 = '\x17F\u000e\x1dV\x0f\x1d@\x0c\x0c'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == str_2, "Simple description"

# Generated at 2022-06-25 16:38:09.549155
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:38:26.486392
# Unit test for function parse
def test_parse():
    str_0 = 'r\x0b\x0f\x0f'
    docstring_0 = parse(str_0)
    str_1 = ':\x0ct4w0<Zts'
    docstring_1 = parse(str_1)
    str_2 = '\x0c=\x0bd8WgA\x0c'
    docstring_2 = parse(str_2)
    str_3 = 'NR\x00'
    docstring_3 = parse(str_3)


# Generated at 2022-06-25 16:38:35.672917
# Unit test for function parse

# Generated at 2022-06-25 16:38:42.562937
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)
    str_1 = '\x06\x1b\x0c\x0b$+\x1d\x1c\x1f\x1b\x14\x05\x13\x14\x0b\x01/\x03\x1f\x1d\x0c\x0f\x06\x1d\x05\x0c\x06\x14\x14\x0e\x1a\x1f\x1c\x1d\x14\x0e:\x0c\x06\x1c\x0b\x01\x0c'
    docstring_1 = parse(str_1)
    str_

# Generated at 2022-06-25 16:38:49.601032
# Unit test for function parse
def test_parse():
    try:
        str_0 = ':\x0ct4w0<Zts'
        docstring_0 = parse(str_0)
    except AssertionError as e:
        print('Failed test:', e)
    print(docstring_0)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:38:51.404392
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:39:01.725928
# Unit test for function parse
def test_parse():
    assert callable(parse)
    str_0 = ""
    style_0 = Style.numpy
    docstring_0 = parse(str_0, style_0)
    str_1 = ":param int arg1: the first argument.\n:return: the sum.\n"
    style_1 = Style.google
    docstring_1 = parse(str_1, style_1)
    str_2 = "optional python summary\n"
    style_2 = Style.auto
    docstring_2 = parse(str_2, style_2)


# Generated at 2022-06-25 16:39:11.959365
# Unit test for function parse
def test_parse():
    str_0 = 'C\nE\x17m9'
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_0, Style.numpy)
    assert(str(docstring_0) == "Docstring([Summary(['C\\nE\\x17m9'])])")
    assert(str(docstring_1) == "Docstring([Summary(['C\\nE\\x17m9'])])")
    str_1 = '~k\x17f0G:\x0bu'
    docstring_2 = parse(str_1, Style.google)
    assert(str(docstring_2) == "Docstring([Summary(['~k\\x17f0G:\\x0bu'])])")

# Generated at 2022-06-25 16:39:21.587620
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)
    assert len(docstring_0) == 0
    str_1 = '4w0<Zts:\x0ct'
    docstring_1 = parse(str_1)
    assert len(docstring_1) == 0
    str_2 = ':\x0ct4w0<Zts'
    docstring_2 = parse(str_2)
    assert len(docstring_2) == 0
    str_3 = '<Zts:\x0c4w0t'
    docstring_3 = parse(str_3)
    assert len(docstring_3) == 0
    str_4 = ':\x0c4w0<Ztst'
    docstring_4 = parse

# Generated at 2022-06-25 16:39:31.480673
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    assert parse(str_0).short_description == 'Zts'
    assert parse(str_0).long_description == ''
    assert parse(str_0).style == 'google'
    assert parse(str_0).notes == []
    assert parse(str_0).raises == []
    assert parse(str_0).returns == []
    assert parse(str_0).yields == []

    str_1 = ':lQdzzGn\n$:lQdzzGn\nk7'
    assert parse(str_1).short_description == ''
    assert parse(str_1).long_description == 'k7'
    assert parse(str_1).style == 'google'

# Generated at 2022-06-25 16:39:36.733121
# Unit test for function parse
def test_parse():
    str = ':param str argname: The argument name.'
    docstring_0 = parse(str)
    assert docstrin

# Generated at 2022-06-25 16:39:51.009699
# Unit test for function parse
def test_parse():
    pass

if __name__ == '__main__':
    test_parse()
    test_case_0()

# Generated at 2022-06-25 16:39:53.658817
# Unit test for function parse
def test_parse():
    str_0 = 'This is a test'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'This is a test'


# Generated at 2022-06-25 16:40:03.794589
# Unit test for function parse
def test_parse():
    assert callable(parse)


if __name__ == '__main__':
    import sys
    import timeit

    repeat_inner = 2
    repeat_outer = 10

    t_setup_text = '''from __main__ import test_case_0'''
    t_text_0 = '''test_case_0()'''
    t_text_1 = '''parse(':\x0ct4w0<Zts', Style.auto)'''
    t_text_2 = '''parse(':\x0ct4w0<Zts', None)'''
    t_text_3 = '''parse(':\x0ct4w0<Zts', Style.auto)'''


# Generated at 2022-06-25 16:40:10.226430
# Unit test for function parse
def test_parse():
    # test_case_0
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)
# Test to see if the test cases were properly executed


# Generated at 2022-06-25 16:40:15.776207
# Unit test for function parse
def test_parse():
    style_0 = Style.google
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)
    print(docstring_0.full)


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:25.620095
# Unit test for function parse
def test_parse():
    assert parse(
        'This is a normal paragraph.\n\n    This is a code block.'
    ).short_description == 'This is a normal paragraph.'
    assert parse(
        'This is a normal paragraph.\n\n    This is a code block.'
    ).long_description == 'This is a code block.'
    assert parse(
        'This is a normal paragraph.\n\n    This is a code block.'
    ).return_annotation == ''
    assert parse(
        'This is a normal paragraph.\n\n    This is a code block.'
    ).params == []
    assert parse(
        'This is a normal paragraph.\n\n    This is a code block.'
    ).raises == []

# Generated at 2022-06-25 16:40:32.063985
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)
    assert docstring_0.summary == ''
    assert docstring_0.fields == []
    assert docstring_0.returns == ''
    assert docstring_0.raises == [('', '')]
    str_1 = '=+]\x0bO9\x0bL'
    docstring_1 = parse(str_1)
    assert docstring_1.summary == '=+]\x0bO9\x0bL'
    assert docstring_1.fields == []
    assert docstring_1.returns == ''
    assert docstring_1.raises == [('', '')]

# Generated at 2022-06-25 16:40:35.703079
# Unit test for function parse

# Generated at 2022-06-25 16:40:42.704629
# Unit test for function parse
def test_parse():
    assert " : Test".strip()

if __name__ == "__main__":
    test_parse()
    test_case_0()

# Generated at 2022-06-25 16:40:52.981901
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)
    str_1 = ';p#cN<9&4l=7]J'
    docstring_1 = parse(str_1)
    str_2 = '7>G!9P4ck^%=)'
    docstring_2 = parse(str_2)
    str_3 = '>0[z9T$\x0b^#E`'
    docstring_3 = parse(str_3)
    str_4 = 'N3\x0c:Nb>*M=Fg['
    docstring_4 = parse(str_4)
    str_5 = '2:m_m>dJ!\n=D^'
    docstring_5 = parse

# Generated at 2022-06-25 16:41:11.308001
# Unit test for function parse
def test_parse():
    str_0 = ''
    docstring_0 = parse(str_0)

    str_1 = '\x0cs]'
    docstring_1 = parse(str_1)

    str_2 = 'M2P'
    docstring_2 = parse(str_2)

    str_3 = '5.\x0bu)W8'
    docstring_3 = parse(str_3)

    str_4 = '}H&\x0c4T'
    docstring_4 = parse(str_4)

    str_5 = '\x0b%\x0c'
    docstring_5 = parse(str_5)

    str_6 = '\n\n'
    docstring_6 = parse(str_6)

    str_7 = ';e,'
    docstring_7

# Generated at 2022-06-25 16:41:19.874748
# Unit test for function parse
def test_parse():
    text = '''\
    :param path: The path to the file to load

    :raises FileNotFoundError: If ``path`` doesn't exist
    '''

    docstring = parse(text)

    assert docstring.args == []
    assert docstring.returns == None
    assert docstring.yields == None
    assert docstring.raises == [
        {'type': 'FileNotFoundError', 'description': "If ``path`` doesn't exist"}]
    assert docstring.meta == {'param': [{'name': 'path', 'description': 'The path to the file to load'}]}



# Generated at 2022-06-25 16:41:20.689945
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:41:24.741180
# Unit test for function parse
def test_parse():
    text = """\
The module.

:param int arg1: the arg1
:param arg2: the arg2
"""
    ds = parse(text)


if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:41:28.802249
# Unit test for function parse
def test_parse():
    # RUN FUNCTION: test_case_0
    str_0 = ':\x0ct4w0<Zts'
    parse(str_0)

# Generated at 2022-06-25 16:41:39.048693
# Unit test for function parse

# Generated at 2022-06-25 16:41:40.052719
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:41:49.880272
# Unit test for function parse
def test_parse():
    str_0 = 'a: xxx\ny: yyy'
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short_description == 'a: xxx'
    assert docstring_0.long_description == 'y: yyy'
    assert docstring_0.meta['a'] == 'xxx'
    assert docstring_0.meta['y'] == 'yyy'
    str_1 = 'a: xxx\n\ny: yyy'
    docstring_1 = parse(str_1)
    assert isinstance(docstring_1, Docstring)
    assert docstring_1.short_description == 'a: xxx'
    assert docstring_1.long_description == 'y: yyy'
    assert docstring

# Generated at 2022-06-25 16:41:53.577269
# Unit test for function parse
def test_parse():
    assert(parse() != None)
    return None


print(test_parse())
for i in range(0,10):
    test_case_0()
str_0 = ':\x0ct4w0<Zts'
docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:42:02.817026
# Unit test for function parse

# Generated at 2022-06-25 16:42:19.887263
# Unit test for function parse
def test_parse():
    'Tests for the parsing of docstrings.'
    from docstring_parser.common import Docstring
    from docstring_parser.styles import GoogleStyle
    from docstring_parser.styles import NumpyStyle
    # print('\n')

    # print('Testing parsing\n')
    str_0 = ':'
    docstring_0 = parse(str_0)
    # print(docstring_0.params)
    # print(docstring_0.returns)
    # print(docstring_0.raises)
    # print('\n\n')
    # print(docstring_0.short_description)
    assert docstring_0.short_description == ''
    assert docstring_0.result == ''
    assert docstring_0.params == []
    assert docstring_0.returns == []

# Generated at 2022-06-25 16:42:23.168406
# Unit test for function parse
def test_parse():
    text = 'Parses the docstring into its components.'
    style = Style.numpy
    docstring = parse(text, style)
    assert docstring.short_description == 'Parses the docstring into its components.'


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:42:34.587774
# Unit test for function parse
def test_parse():
    str_0 = '\u0006\x9f6z\x0c@"\u000c'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == '\u0006\x9f6z\x0c@"\u000c'
    assert docstring_0.long_description == ''
    assert docstring_0.params == []
    assert docstring_0.returns == None
    assert docstring_0.meta == {}

# Generated at 2022-06-25 16:42:40.617263
# Unit test for function parse
def test_parse():
    str_0 = ':param int _: some description'
    docstring_0 = parse(str_0)
    assert docstring_0.params[0].name == '_'
    assert docstring_0.params[0].type == 'int'
    assert docstring_0.params[0].description == 'some description'


# Subtest of test_parse

# Generated at 2022-06-25 16:42:47.780945
# Unit test for function parse
def test_parse():
    str_0 = 'to@z)e7`^o'
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    str_1 = 'm\x7fmO5"6U@X'
    style_1 = Style.google
    docstring_1 = parse(str_1, style_1)
    if docstring_0 == docstring_1:
        str_2 = '\xa0\x86\x17\t\n\vt\x9d\x15\x8a\x96\t\n'
        style_2 = Style.google
        docstring_2 = parse(str_2, style_2)
        str_3 = 'd2Q$&G\x80\x9d\x0e'

# Generated at 2022-06-25 16:42:49.755521
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:53.495245
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:43:04.246964
# Unit test for function parse
def test_parse():
    style = Style.auto
    # Example from https://github.com/nnseva/docstring-parser/issues/27

# Generated at 2022-06-25 16:43:08.576574
# Unit test for function parse
def test_parse():
    str_0 = ':\x0ct4w0<Zts'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:43:09.582072
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:43:18.085475
# Unit test for function parse
def test_parse():
    test_case_0()

if __name__ == "__main__":
    try:
        test_parse()
    except Exception as ex:
        print(str(ex))

# Generated at 2022-06-25 16:43:22.617722
# Unit test for function parse
def test_parse():
    str_0 = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:43:24.859853
# Unit test for function parse
def test_parse():
    print('Testing function parse')
    test_case_0()

# Generated at 2022-06-25 16:43:34.138667
# Unit test for function parse
def test_parse():
    str_0 = ''
    style_0 = Style.auto
    docstring_1 = parse(str_0, style_0)