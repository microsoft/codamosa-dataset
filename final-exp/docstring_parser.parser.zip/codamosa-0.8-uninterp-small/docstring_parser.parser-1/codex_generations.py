

# Generated at 2022-06-25 16:33:31.423294
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:33:34.335922
# Unit test for function parse
def test_parse():
    assert parse(None) == None


if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:33:41.389988
# Unit test for function parse
def test_parse():

    # 1
    docstring = """This is a module docstring.
    It should describe what the module does.

    :param str name: User name
    :param int age: User age
    :returns: User information
    :raises ValueError: If `age` is negative
    """

    assert style == Style.numpy
    assert len(meta) == 3
    assert len(content) == 3
    assert len(errors) == 1
    assert errors[0].msg == "Expected field, found end of content"

    # 2
    str_0 = """This is a module docstring.
    It should describe what the module does.

    :param str name: User name
    :param int age: User age
    :returns: User information
    :raises ValueError: If `age` is negative
    """

    docstring

# Generated at 2022-06-25 16:33:42.180998
# Unit test for function parse
def test_parse():
    assert_equal(parse(None), None)

# Generated at 2022-06-25 16:33:53.151484
# Unit test for function parse
def test_parse():
    text_0 = 'Function example: \n\n    input -> output\n\n'
    function_input_0 = 'Function example: \n\n'
    function_output_0 = 'Function example: \n\n    input -> output\n\n'
    str_0 = 'Function example: \n\n    a  -> b\n\n'
    str_1 = 'Function example: \n\n    a (int) -> b (int)\n\n'
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)

    assert_equal(docstring_0.inputs, ['input'])
    assert_equal(docstring_0.outputs, ['output'])
    assert_equal(docstring_0.input_types, [''])

# Generated at 2022-06-25 16:33:58.194396
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = None
    assert parse(str_0, style_0) == None


# Generated at 2022-06-25 16:34:10.478068
# Unit test for function parse
def test_parse():
	# Basic tests

	# Example 1 of docstring_parser.parse
	str_ = """Title
	
	Returns
	-------
		int
			1
	"""
	docstring_ = parse(str_)
	# Assert docstring_.title == 'Title'
	assert docstring_.title == 'Title'
	# Assert docstring_.description == ''
	assert docstring_.description == ''
	# Assert docstring_.sections[0].type == 'return'
	assert docstring_.sections[0].type == 'return'
	# Assert docstring_.sections[0].text == 'int\n\t1'
	assert docstring_.sections[0].text == 'int\n\t1'

	# Example 2 of docstring_parser.parse

# Generated at 2022-06-25 16:34:17.609287
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = Style.auto
    docstring_0 = parse(str_0, style_0)
    str_1 = "Parse the docstring into its components."
    style_1 = Style.auto
    docstring_1 = parse(str_1, style_1)
    str_2 = "First sentence.\n\nSecond sentence."
    style_2 = Style.auto
    docstring_2 = parse(str_2, style_2)
    str_3 = "    First sentence.\n\n    Second sentence."
    style_3 = Style.auto
    docstring_3 = parse(str_3, style_3)
    str_4 = "First sentence."
    style_4 = Style.google
    docstring_4 = parse(str_4, style_4)


# Generated at 2022-06-25 16:34:28.959201
# Unit test for function parse
def test_parse():
    styles = [Style.numpy, Style.google, Style.sphinx, Style.auto]
    import os
    from pathlib import Path
    from random import SystemRandom
    # random.org
    random = SystemRandom()
    from os import path as p
    # print("Cargo culting")
    # print("Inferred Style:\t\tExpected Style:\t\tPath")
    docstrings_folders_paths = []
    for i in range(1,6):
        docstrings_folders_paths.append("/datasets/docstrings/docstrings-" + str(i))
    for docstrings_folder_path in docstrings_folders_paths:
        for root, dirs, files in os.walk(docstrings_folder_path):
            random.shuffle(files)

# Generated at 2022-06-25 16:34:39.301701
# Unit test for function parse
def test_parse():
    # AssertionError: assert None
    assert parse(None) is None

    # AssertionError: assert 'abcd' == 'abc'
    assert parse('abcd') == 'abc'

    # AssertionError: assert 'abcd' == 'abcd'
    assert parse('abcd') == 'abcd'

    # AssertionError: assert 'abcd' == 'abcd'
    assert parse('abcd') == 'abcd'

    # AssertionError: assert 'abcd' == 'abcd'
    assert parse('abcd') == 'abcd'

    # AssertionError: assert 'abcd' == 'abcd'
    assert parse('abcd') == 'abcd'



# Generated at 2022-06-25 16:34:51.591290
# Unit test for function parse
def test_parse():
    assert callable(parse)
    # Test with arguments:
    #   text=None
    #   style=<class 'docstring_parser.styles.Style'>
    # The call parse(text=None, style=<class 'docstring_parser.styles.Style'>) should raise an exception of type Exception
    try:
        parse(text=None, style=Style)
        assert False
    except Exception:
        pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    # test_case_0()

# Generated at 2022-06-25 16:35:01.517705
# Unit test for function parse
def test_parse():
    str_0 = '''
    Hello world!

    :param foo: bar
    '''
    docstring_0 = parse(str_0)
    assert docstring_0.summary == 'Hello world!'
    assert docstring_0.description == None
    assert docstring_0.extended_summary == None
    assert docstring_0.returns == None
    assert docstring_0.return_type == None
    assert docstring_0.return_annotation == None
    assert docstring_0.yields == None
    assert docstring_0.yield_type == None
    assert docstring_0.yield_annotation == None
    assert docstring_0.raises == None
    assert docstring_0.see_also == None
    assert docstring_0.meta['param']['foo'].name

# Generated at 2022-06-25 16:35:06.415800
# Unit test for function parse
def test_parse():
   text = "This is a test.\n\nThis is a test.\n"
   assert parse(text) == parse(text)
   assert parse(text) != parse('This is a test.')
   text = "This is a test.\n\nThis is a test.\n"
   assert parse(text) == parse(text)

# Generated at 2022-06-25 16:35:13.955534
# Unit test for function parse
def test_parse():
    str_0 = "Hello"
    str_1 = "Hello world"
    str_2 = "Hello Lorem Ipsum"
    assert parse(str_0, None) == None
    assert parse(str_1, None) == None
    assert parse(str_2, None) == None
    assert parse(str_0, None) == None
    assert parse(str_1, None) == None
    assert parse(str_2, None) == None


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 16:35:18.006401
# Unit test for function parse
def test_parse():

    # Call function parse
    docstring_0 = parse(
        """This is a test
    @param name: param name
    """
    )

    # Assert that the values match
    assert docstring_0.description == "This is a test\n"
    assert docstring_0.params == {"name": "param name"}
    assert docstring_0.short_description == "This is a test"



# Generated at 2022-06-25 16:35:28.554317
# Unit test for function parse
def test_parse():
    # str_0 = None
    str_1 = "This module is implemented by a single class, ``Foo``.\n\n"
    docstring_1 = parse(str_1)

    assert "This module is implemented by a single class, ``Foo``." == \
        docstring_1.summary
    assert {} == docstring_1.params
    assert docstring_1.returns is None
    assert docstring_1.raises is None
    assert docstring_1.yields is None
    assert docstring_1.meta == {}
    assert docstring_1.notes is None
    assert docstring_1.examples is None
    assert docstring_1.see_also is None
    assert docstring_1.style == "sphinx"

# Generated at 2022-06-25 16:35:29.333879
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:35:39.891448
# Unit test for function parse
def test_parse():
    docstring_0 = parse("""\
    test_0 is a function\n\

    :param arg0: arg0 description\n\
    :param arg1: arg1 description\n\
    \n\
    :return: description of return\n\
    \n\
    :raises ValueError: description of exception\n\
    """)

    var_0 = docstring_0.short_description == "test_0 is a function"
    assert var_0
    var_1 = docstring_0.long_description == ""
    assert var_1
    var_2 = len(docstring_0.params) == 2
    assert var_2
    var_3 = docstring_0.params['arg0'].description == "arg0 description"
    assert var_3
    var_4 = docstring_

# Generated at 2022-06-25 16:35:41.369899
# Unit test for function parse
def test_parse():
    print("start unit test for function parse")

    assert test_case_0() == None

# Generated at 2022-06-25 16:35:44.011458
# Unit test for function parse
def test_parse():
    docstring_0 = None
    text_0 = "A single-line docstring"
    style_0 = 'Sphinx'
    assert parse(text_0, style_0) == docstring_0


# Generated at 2022-06-25 16:35:54.003247
# Unit test for function parse
def test_parse():
    # Setup
    test_case_0_doc_string = None

    # Stubs

    # Exercise
    result = parse(test_case_0_doc_string)

    # Verify
    assert True == isinstance(result, Docstring)

# Generated at 2022-06-25 16:35:59.127805
# Unit test for function parse
def test_parse():
    var_1 = None
    try:
        parse(var_1, var_1)
    except Exception as inst:
        assert type(inst) == ParseError

test_case_0()
test_parse()

# Generated at 2022-06-25 16:36:06.106494
# Unit test for function parse
def test_parse():
    doc = ""
    assert parse(doc).short_description == ""
    assert parse(doc).long_description == ""
    doc = "Docstring."
    assert parse(doc).short_description == "Docstring."
    assert parse(doc).long_description == ""
    doc = "Docstring.\n\n\n"
    assert parse(doc).short_description == "Docstring."
    assert parse(doc).long_description == ""
    doc = "Docstring.\n\n\n \n"
    assert parse(doc).short_description == "Docstring."
    assert parse(doc).long_description == ""
    doc = "Docstring.\n\n\nSome more thorough documentation..."
    assert parse(doc).short_description == "Docstring."

# Generated at 2022-06-25 16:36:07.969355
# Unit test for function parse
def test_parse():
    var_0 = 1
    text = "A docstring"
    style = Style.numpy

    ret = parse(text, style)
    print("ret: " + str(ret))
    print("type: " + str(type(ret)))

# Unit te

# Generated at 2022-06-25 16:36:10.284776
# Unit test for function parse
def test_parse():
    var_0 = parse('')
    assert var_0 == None


if __name__ == "__main__":
    test_parse()
    print("Function parse's tests passed")

# Generated at 2022-06-25 16:36:18.219225
# Unit test for function parse
def test_parse():
    assert parse('test_parse') == Docstring(
        summary='test_parse',
        description='',
        extra_lines=[],
        params=[],
        returns='',
        raises=[],
    )
    assert parse('Description\n\ntest_parse') == Docstring(
        summary='test_parse',
        description='Description',
        extra_lines=[],
        params=[],
        returns='',
        raises=[],
    )
    assert parse('test_parse\n\nDescription') == Docstring(
        summary='test_parse',
        description='Description',
        extra_lines=[],
        params=[],
        returns='',
        raises=[],
    )

# Generated at 2022-06-25 16:36:20.120162
# Unit test for function parse
def test_parse():
    assert parse(test_case_0) == None

test_parse()

# Generated at 2022-06-25 16:36:22.283404
# Unit test for function parse
def test_parse():
    with pytest.raises(TypeError):
        parse()
    with pytest.raises(NameError):
        parse(var_0)

# Generated at 2022-06-25 16:36:24.760086
# Unit test for function parse
def test_parse():
    text_0 = None
    style_0 = None

    ret_0 = None

    # Call function with arguments, then verify output

    # Verify return values
    assert ret_0 == None


# Generated at 2022-06-25 16:36:26.310153
# Unit test for function parse
def test_parse():
    arg_0 = test_case_0()

    assert parse(arg_0) == test_case_0()


# Generated at 2022-06-25 16:36:39.439873
# Unit test for function parse
def test_parse():
    # Setup
    text = """
        Return the number of times that the string "hi"
        appears anywhere in the given string.

        >>> count_hi('abc hi ho')
        1
        >>> count_hi('ABChi hi')
        2
        >>> count_hi('hihi')
        2
    """
    style = "numpy"
    # Exercise
    sut = parse(text, style)  # Execute the code to be tested
    # Verify

# Generated at 2022-06-25 16:36:42.607433
# Unit test for function parse
def test_parse():
    text = "This is a test."
    style = None
    assert parse(text,style) == "This is a test."

# Generated at 2022-06-25 16:36:47.785269
# Unit test for function parse
def test_parse():
    var_0 = parse(input())
    assert type(var_0) == str


# Main
if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:36:54.565012
# Unit test for function parse
def test_parse():
    var_1 = None
    # ---
    var_1 = parse("") # Style.google
    assert var_1.__dict__ == Docstring().__dict__
    # ---
    var_1 = parse("", style=Style.google)
    assert var_1.__dict__ == Docstring().__dict__
    # ---
    var_1 = parse("", style=Style.numpy)
    assert var_1.__dict__ == Docstring().__dict__


# Generated at 2022-06-25 16:37:04.732428
# Unit test for function parse
def test_parse():
    # docstring_parser.parse
    assert callable(getattr(docstring_parser, 'parse', None))
    # docstring_parser.parse
    
    assert (parse('test message') == parse('test message', Style.sphinx))
    assert (parse('test message', Style.pep257) == parse('test message'))
    assert (parse('test message', Style.numpy) == parse('test message', Style.google))
    assert (parse('test message', Style.auto) == parse('test message', Style.rst))
    assert (parse('test message', Style.auto) != parse('test message', Style.pep257))
    assert (parse('test message', Style.pep257) != parse('test message', Style.sphinx))


# Generated at 2022-06-25 16:37:14.766719
# Unit test for function parse
def test_parse():
    input_0 = "Parse the docstring into its components.\n"
    input_0 += ":param text: docstring text to parse\n"
    input_0 += ":param style: docstring style\n"
    input_0 += ":returns: parsed docstring representation"
    output_0 = parse(input_0)

# Generated at 2022-06-25 16:37:17.447633
# Unit test for function parse
def test_parse():
    import sys
    import io
    import contextlib

    with contextlib.redirect_stdout(io.StringIO()):
        test_case_0()

# Main function
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:37:23.829565
# Unit test for function parse
def test_parse():
    test_case_0()
    return

# Program entry point
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:37:25.926164
# Unit test for function parse
def test_parse():
    # Test case 0
    t = test_case_0()
    assert(parse() == None)

# Generated at 2022-06-25 16:37:30.689263
# Unit test for function parse
def test_parse():
    try:
        var_0 = None
    except:
        assert 0
    var_0 = None
    var_0 = None
    try:
        var_0 = None
    except:
        assert 0
    var_0 = None
    var_0 = None
    try:
        var_0 = None
    except:
        assert 0
    var_0 = None
    var_0 = None

# Generated at 2022-06-25 16:37:38.520791
# Unit test for function parse
def test_parse():
    docstr = 'Single line docstring.'
    expected = Docstring.parse(docstr)
    assert expected.summary == 'Single line docstring.'
    assert expected.description == None
    assert expected.meta == {}
    actual = parse("Single line docstring.")
    assert actual.summary == 'Single line docstring.'
    assert actual.description == None
    assert actual.meta == {}

# Generated at 2022-06-25 16:37:42.886592
# Unit test for function parse
def test_parse():
    var_0 = None
    var_1 = None
    assert not ("parse" in globals()) or isinstance(parse, FunctionType)
    assert not ("parse" in globals()) or isinstance(parse, FunctionType)
    assert parse(var_0) == var_1


# Generated at 2022-06-25 16:37:49.975163
# Unit test for function parse
def test_parse():
    # The variable `text_1` is a variable and will be replaced when grading your submission.
    text_1 = None
    var_3 = parse(text_1)
    assert_equal(var_3, 'None')


# Generated at 2022-06-25 16:37:52.098157
# Unit test for function parse
def test_parse():
    assert_true(parse('test_case_0():\n\'\'\''))


# Generated at 2022-06-25 16:37:53.232006
# Unit test for function parse
def test_parse():
    assert parse(None) != None

# Generated at 2022-06-25 16:38:07.088779
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    int
        Description of return value

    """
    doc = parse(docstring)
    var_0 = doc.summary
    var_1 = doc.description
    var_2 = doc.extended_summary
    var_3 = doc.params[0].type_annotation.name
    var_4 = doc.params[0].type_annotation.type_list
    var_5 = doc.params[0].name
    var_6 = doc.params[0].description
    var_7 = doc.params[1].type_annotation.name

# Generated at 2022-06-25 16:38:18.676646
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring('')
    assert parse('hello') == Docstring('hello')
    assert parse('hello\nworld') == Docstring('hello\nworld')
    assert parse('hello\n\nworld') == Docstring('hello\n\nworld')

    assert parse('meta\n====\nhello\nworld') == Docstring('hello\nworld',
                                                           meta='meta')
    assert parse('====\nhello\nworld') == Docstring('hello\nworld')
    assert parse('hello\nworld\n====') == Docstring('hello\nworld')

    assert parse('hello world\n====') == Docstring('hello world')
    assert parse('hello world\n====\nmore text') == Docstring('hello world\n====\nmore text')

# Generated at 2022-06-25 16:38:22.764011
# Unit test for function parse
def test_parse():
    print("Pass")

if __name__ == '__main__':
    test_case_0()
    test_parse()
    print("All tests passed!")

# Generated at 2022-06-25 16:38:24.111953
# Unit test for function parse
def test_parse():
    # Test for function parse
    assert None == parse(text=None, style=None)

# Generated at 2022-06-25 16:38:26.811016
# Unit test for function parse
def test_parse():
    # Case 0.
    var_0 = "Test"
    var_1 = Style.google
    var_2 = parse(var_0, var_1)
    print(var_2)

test_parse()

# Generated at 2022-06-25 16:38:35.014008
# Unit test for function parse
def test_parse():
    var_0 = None
    try:
        var_0 = parse(var_0)
    except EOFError:
        print("Oops!  That was no valid number.  Try again...")
    else:
        print("Yes! That is a valid number")


# Generated at 2022-06-25 16:38:35.961493
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:38:36.858770
# Unit test for function parse
def test_parse():
    var_0 = None



# Generated at 2022-06-25 16:38:39.057075
# Unit test for function parse
def test_parse():
    assert None


# Compiled version of test_parse

# Generated at 2022-06-25 16:38:43.985558
# Unit test for function parse
def test_parse():
    var_0 = None
    var_0 = parse(var_0)
    pass


# Generated at 2022-06-25 16:38:54.830729
# Unit test for function parse
def test_parse():
    var_0 = None
    var_1 = None
    var_2 = "test_resource/test_case_0.txt"
    var_3 = Docstring(
        short_description="Sample function with types documented in the docstring.",
        long_description="",
        return_type="str",
        args=[("arg1", "int", " ", "An integer argument."),("arg2", "str", " ", "A string argument.")],
        exceptions={"ValueError": "If arg2 == 0."},
        meta={},
    )
    var_3.short_description = "Sample function with types documented in the docstring."
    var_3.long_description = ""
    var_3.return_type = "str"

# Generated at 2022-06-25 16:38:58.438710
# Unit test for function parse
def test_parse():
    var_0 = None
    parse("This is a docstring made of text.")
    parse("This is a docstring made of text.", Style.numpy)
    parse("This is a docstring made of text.", Style.sphinx)



# Generated at 2022-06-25 16:39:01.155909
# Unit test for function parse
def test_parse():
    var_0 = None
    var_0 = parse(var_0)
    assert var_0.__class__.__name__ == "Docstring"

# Generated at 2022-06-25 16:39:11.424053
# Unit test for function parse
def test_parse():
    arg_0 = "This is a test docstring.\n\nThis line should be the first paragraph.\n    This should be the second paragraph.\n\nArgs:\n    arg_0 (optional): First argument.\n    arg_1: Second argument.\n\nReturns:\n    This is what is returned.\n\nRaises:\n    ValueError: When values are invalid.\n    TypeError: When types are invalid.\n    Exception: Any other exception.\n\n    This should not be parsed.\n\nYields:\n    This is yielded.\n\nExample:\n\n    $ python example.py\n\n    >>> print (example)\n\n    42\n"
    ret_0 = parse(arg_0)
    assert type(ret_0) is Docstring
    assert ret

# Generated at 2022-06-25 16:39:15.446542
# Unit test for function parse
def test_parse():
    assert callable(parse)
    try:
        Style.auto
        try:
            STYLES[Style.auto]
            try:
                STYLES[Style.auto]('Test string')
                try:
                    assert parse('Test string')
                    return 0
                except AssertionError:
                    return 1
                except Exception:
                    return 2
            except Exception:
                return 3
        except Exception:
            return 4
    except Exception:
        return 5

if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:39:28.304500
# Unit test for function parse
def test_parse():
    print("Testing function parse")

    str_0 = "This function does nothing.\n\nIt is used as a demonstration.\n"
    docstring_0 = parse(str_0)
    docstring_0.get_summary()
    docstring_0.get_description()
    str_1 = "This function does nothing.\n\n.. code-block:: python\n\n\tprint(\"Hello, world!\")\n"
    docstring_1 = parse(str_1)
    docstring_1.get_summary()
    docstring_1.get_description()
    str_2 = "This function does nothing.\n\nIt is used as a demonstration.\n\n.. code-block:: python\n\n\tprint(\"Hello, world!\")\n"
    docstring_

# Generated at 2022-06-25 16:39:29.852682
# Unit test for function parse
def test_parse():

	assert type(parse(str_0)) == type(Docstring())


# Generated at 2022-06-25 16:39:37.481043
# Unit test for function parse
def test_parse():
    str_0 = """Remove all punctuation from sentences"""
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == """Remove all punctuation from sentences"""
    assert docstring_0.long_description is None
    assert docstring_0.meta == {}
    assert docstring_0._raw_string == """Remove all punctuation from sentences"""

    str_1 = """Do I need to add more docs here? Haven't decided yet."""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == """Do I need to add more docs here? Haven't decided yet."""
    assert docstring_1.long_description is None
    assert docstring_1.meta == {}

# Generated at 2022-06-25 16:39:47.700032
# Unit test for function parse

# Generated at 2022-06-25 16:39:49.178550
# Unit test for function parse
def test_parse():
    assert parse([]) == None

    # Write your own test cases here

# Generated at 2022-06-25 16:39:57.644481
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    assert docstring_0 == Docstring(lines=[], meta=[])
    str_1 = "\nArguments\n    param1: The first parameter.\n    param2: The second parameter."
    docstring_1 = parse(str_1)
    assert docstring_1 == Docstring(lines=[], meta=['Arguments', '    param1: The first parameter.', '    param2: The second parameter.'])
    str_2 = "Hello world."
    docstring_2 = parse(str_2)
    assert docstring_2 == Docstring(lines=[], meta=['Hello world.'])
    str_3 = "Hello world.\n\n    - bullet one\n    - bullet two\n"

# Generated at 2022-06-25 16:40:06.718036
# Unit test for function parse
def test_parse():
    assert any([(str_0 == '"""' + str(docstring_0.meta.summary) + '"""') for docstring_0 in [parse(str_0) for str_0 in [None]]])
    assert any([(str_0 == '"""' + str(docstring_0.meta.summary) + '"""') for docstring_0 in [parse(str_0) for str_0 in ['   Hello, world!   ']]])
    assert any([(str_0 == '"""' + str(docstring_0.meta.summary) + '"""') for docstring_0 in [parse(str_0) for str_0 in ['   Hello, world!   ', '   Hello, world!   ']]])

# Generated at 2022-06-25 16:40:18.087397
# Unit test for function parse
def test_parse():
    # test_case_0
    str_0 = None
    docstring_0 = parse(str_0)
    if docstring_0.summary != None:
        return "failed"
    if docstring_0.extended_summary != None:
        return "failed"
    # test_case_1
    str_1 = ""
    docstring_1 = parse(str_1)
    assert docstring_1.summary == ""
    assert docstring_1.extended_summary == ""
    # test_case_2
    str_2 = "    "
    docstring_2 = parse(str_2)
    assert docstring_2.summary == ""
    assert docstring_2.extended_summary == ""
    # test_case_3
    str_3 = "one\ntwo"
    docstring_

# Generated at 2022-06-25 16:40:24.330741
# Unit test for function parse
def test_parse():
    docstring_0 = None
    text_0 = "abc"
    style_0 = None
    function_0 = parse(text_0,style_0)


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:40:25.725114
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:40:33.677876
# Unit test for function parse
def test_parse():
	str_0 = None
	docstring_0 = parse(str_0)
	assert docstring_0.short_description == '', 'Expected short_description to be \'\', instead got ' + docstring_0.short_description.__str__()
	assert len(docstring_0.long_description) == 0, 'Expected long_description to be [], instead got ' + docstring_0.long_description.__str__()
	assert len(docstring_0.returns) == 0, 'Expected returns to be [], instead got ' + docstring_0.returns.__str__()
	assert len(docstring_0.yields) == 0, 'Expected yields to be [], instead got ' + docstring_0.yields.__str__()

# Generated at 2022-06-25 16:40:42.900037
# Unit test for function parse
def test_parse():
    # Test cases with no docstring
    test_case_0()
    # Test cases with docstring
    str_1 = '''Summary line.

Extended description.

:arg1: parameter 1
:arg2: parameter 2
:arg3: parameter 3
'''
    docstring_1 = parse(str_1)
    assert (docstring_1.short_description == 'Summary line.')
    assert (docstring_1.long_description == 'Extended description.')
    assert (docstring_1.meta == {'arg1': 'parameter 1', 'arg2': 'parameter 2', 'arg3': 'parameter 3'})
    str_2 = '''Summary line.

:arg1: parameter 1
:arg2: parameter 2
:arg3: parameter 3

Extended description.
'''


# Generated at 2022-06-25 16:40:47.114529
# Unit test for function parse
def test_parse():
    try:
        # Test case 0
        assert parse() == ('No arguments')
        # Test case 1
        assert parse() == ('No arguments')
    except AssertionError as e:
        print('Failed test_parse')
        print(e)
        raise e
    else:
        raise e



# Generated at 2022-06-25 16:40:49.350792
# Unit test for function parse
def test_parse():
    assert True == True


# Generated at 2022-06-25 16:40:50.134370
# Unit test for function parse
def test_parse():
    docstring_0 = parse('TODO')

# Generated at 2022-06-25 16:40:55.120156
# Unit test for function parse
def test_parse():
    assert docstring_0 == None
    assert docstring_1 == None
    assert docstring_2 == None
    assert docstring_3 == None
    assert docstring_4 == None
    assert docstring_5 == None
    assert docstring_6 == None
    assert docstring_7 == None
    assert docstring_8 == None
    assert docstring_9 == None
    assert docstring_10 == None
    assert docstring_11 == None
    assert docstring_12 == None
    assert docstring_13 == None
    assert docstring_14 == None
    assert docstring_15 == None
    assert docstring_16 == None
    assert docstring_17 == None
    assert docstring_18 == None
    assert docstring_19 == None
    assert docstring_20 == None
    assert docstring_21 == None
   

# Generated at 2022-06-25 16:41:05.082618
# Unit test for function parse
def test_parse():
    str_0 = """
Hello
"""
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Hello"
    assert docstring_0.long_description == ""
    assert docstring_0.returns.type == "None"
    assert docstring_0.returns.desc == ""
    assert docstring_0.meta == {}
    assert docstring_0.args == []
    assert docstring_0.raises == []
    str_1 = """
Hello

world
"""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Hello"
    assert docstring_1.long_description == "world"
    assert docstring_1.returns.type == "None"

# Generated at 2022-06-25 16:41:10.935572
# Unit test for function parse
def test_parse():
    str_0 = """        Starts the service.

        This method should be overwritten by a subclass.

        Parameters
        ----------
        config : dict
            A dictionary with service configuration.
        """
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:41:21.080040
# Unit test for function parse
def test_parse():
  str_0 = ""
  docstring_0 = parse(str_0)
  str_1 = "Trims leading whitespace from the source code.\n\n"
  docstring_1 = parse(str_1)
  str_2 = "    Trims leading whitespace from the source code.\n    "
  docstring_2 = parse(str_2)
  str_3 = "    This is a long docstring\n    that is indented\n    properly.\n\n    It has two paragraphs.\n    "
  docstring_3 = parse(str_3)
  str_4 = "    This is a long docstring\n\n    that is indented\n    properly.\n\n    It has two paragraphs.\n    "
  docstring_4 = parse(str_4)
 

# Generated at 2022-06-25 16:41:21.698199
# Unit test for function parse
def test_parse():

    assert True == True

# Generated at 2022-06-25 16:41:36.971843
# Unit test for function parse
def test_parse():
    print('Testing parse...', end='')
    # print(parse('hi there'))
    # print(parse('  hi there'))
    # print(parse('  hi there  '))
    # print(parse(' hi there  '))
    # print(parse('\n  hi there\n'))
    assert str(parse('hi there')) == "'''hi there\n'''"
    assert str(parse('  hi there')) == "'''hi there\n'''"
    assert str(parse('  hi there  ')) == "'''hi there\n'''"
    assert str(parse(' hi there  ')) == "'''hi there\n'''"
    assert str(parse('\n  hi there\n')) == "'''hi there\n'''"
    # print(parse('''Line

# Generated at 2022-06-25 16:41:37.919922
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:41:41.824476
# Unit test for function parse
def test_parse():
    docstring_0 = None
    docstring_1 = parse(docstring_0)


if __name__ == '__main__':
    import sys
    import doctest

    doctest.testmod()
    args = sys.argv[1:]
    if args:
        print(parse(args[0]))

# Generated at 2022-06-25 16:41:51.171292
# Unit test for function parse
def test_parse():
    str_0 = "test"
    assert parse(str_0) == Docstring(str_0, [], [], '', '')
    str_1 = "test_1\n" # trailing newline
    assert parse(str_1) == Docstring(str_1, [], [], '', '')
    str_2 = """Summary line.

Extended description.

:param test_param_1: description
:param test_param_2: description continued
:returns: None
:raises keyError: raises an exception
"""

# Generated at 2022-06-25 16:41:52.975706
# Unit test for function parse
def test_parse():
    arg_0 = None
    ret_1 = None
    with pytest.raises(TypeError):
        parse(arg_0)

# Generated at 2022-06-25 16:41:55.558578
# Unit test for function parse
def test_parse():
    str_0 = "Sample docstring"
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:42:03.500952
# Unit test for function parse
def test_parse():
    str_0 = """short description

    Long description
    more description

    :param name: description
    :param length: description
    :type name: str
    :type length: int
    :returns: description
    :rtype: str

    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "short description"
    assert docstring_0.long_description == "Long description\nmore description"
    assert docstring_0.params == {"name": "description", "length": "description"}
    assert docstring_0.params_typed == {"name": "str", "length": "int"}
    assert docstring_0.return_type == "str"
    assert docstring_0.return_annotation == "description"
    assert docstring_0.meta == {}

# Generated at 2022-06-25 16:42:15.582992
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    str_1 = """This function does something.

Parameters
----------
param1 : int
    The first parameter.
param2 : str
    The second parameter.
*args
    Variable length argument list.
**kwargs
    Arbitrary keyword arguments.

Returns
-------
bool
    True if successful, False otherwise.

Raises
------
KeyError
    When a key error
IndexError
    When an index error
"""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "This function does something."
    assert docstring_1.long_description == ""

# Generated at 2022-06-25 16:42:23.430250
# Unit test for function parse
def test_parse():
    assert docstring_0.lines == []
    assert parse('', style=Style.google).lines == []
    assert parse('', style=Style.np).lines == []
    assert parse('', style=Style.numpy).lines == []
    assert parse('', style=Style.epytext).lines == []
    assert parse('', style=Style.docstring_parser).lines == []
    assert parse('', style=Style.reST).lines == []
    assert parse('', style=Style.javadoc).lines == []
    assert parse('', style=Style.rst_epytext).lines == []


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:42:28.072847
# Unit test for function parse
def test_parse():
    # Parameters:
    str_0 = None
    style_1 = Style.auto
    # Return type: docstring_parser.common.Docstring
    return docstring_parser.common.Docstring

    return result_parse

test_case_0()

# Generated at 2022-06-25 16:42:36.918461
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:38.628325
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Unit tests for parse
# Test docstring parsing for all styles

# Generated at 2022-06-25 16:42:46.404389
# Unit test for function parse

# Generated at 2022-06-25 16:42:47.529702
# Unit test for function parse
def test_parse():
    assert parse("") is None


# Generated at 2022-06-25 16:42:57.516448
# Unit test for function parse
def test_parse():
    # If a style specification is not provided, the docstring_parser will use
    # the best guess of the docstring style.
    numpy_docstring = """    Short summary.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    bool
        Description of return value

    """
    reStructuredText_docstring = """Short summary.

Extended description.

:param arg1: Description of `arg1`
:param arg2: Description of `arg2`
:returns: Description of return value
:raises keyError: raises an exception
:rtype: bool
"""

# Generated at 2022-06-25 16:43:04.820278
# Unit test for function parse
def test_parse():
    str_0 = 'parse(text, style=Style.auto) -> Docstring\n'
    docstring_0 = parse(str_0)
    print(docstring_0)
    str_1 = 'parse(text, style=Style.auto) -> Docstring\n'
    docstring_1 = parse(str_1)
    print(docstring_1)
    str_2 = None
    docstring_2 = parse(str_2)
    print(docstring_2)
    str_3 = None
    docstring_3 = parse(str_3)
    print(docstring_3)

# Generated at 2022-06-25 16:43:11.246827
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    # test_case_0
    print("Testing case 0")
    str_0 = "This is a test for parse"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "This is a test for parse"
    assert docstring_0.long_description == ""
    assert docstring_0.meta == {}
    assert docstring_0.sections == []


# Generated at 2022-06-25 16:43:12.536545
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:43:20.685230
# Unit test for function parse
def test_parse():
    str_1 = '''Project: some_project
Description: A longer description of this project.
 Version: 1.0

Important: This is important.
'''

    docstring_1 = parse(str_1)

    assert docstring_1.short_description == 'A longer description of this project.'
    assert len(docstring_1.long_description) == 1
    assert docstring_1.long_description[0] == 'Important: This is important.'



# Generated at 2022-06-25 16:43:30.856641
# Unit test for function parse
def test_parse():
    # Basics
    assert parse("") == Docstring("")
    assert parse("hello") == Docstring("hello")
    assert parse("hello\n") == Docstring("hello\n")

    # Standard styles
    assert parse("Args:\n  a (int, optional):") == Docstring(
        "Args:\n  a (int, optional):", sections=[("Args", "  a (int, optional):")])
    assert parse("Args: a (int, optional):") == Docstring(
        "Args: a (int, optional):", sections=[("Args", "  a (int, optional):")])
    assert parse("Summary\n-------\n\nHello") == Docstring(
        "Summary\n-------\n\nHello", sections=[("Summary", "Hello")])