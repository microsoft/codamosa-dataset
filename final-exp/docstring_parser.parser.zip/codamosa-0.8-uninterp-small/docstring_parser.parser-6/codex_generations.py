

# Generated at 2022-06-25 16:33:37.511699
# Unit test for function parse
def test_parse():
    str_0 = "Test only this line"
    doc_0 = parse(str_0, Style.default)
    assert doc_0.short_description == "Test only this line"
    str_0 = "Test only this line\n\nAnother line"
    doc_0 = parse(str_0, Style.default)
    assert doc_0.short_description == "Test only this line"
    assert doc_0.long_description == "Another line"


# Generated at 2022-06-25 16:33:39.468543
# Unit test for function parse
def test_parse():
    assert callable(parse)
    assert isinstance(parse(''), Docstring)

# Generated at 2022-06-25 16:33:49.553498
# Unit test for function parse
def test_parse():
    str_0 = "Adds two numbers together."
    docstring_0 = parse(str_0)
 
    str_1 = "Adds two numbers together.\n"
    docstring_1 = parse(str_1)

    str_2 = "Adds two numbers together.\n\n"
    docstring_2 = parse(str_2)
 
    str_3 = "Adds two numbers together.\n\n"
    docstring_3 = parse(str_3)

    str_4 = "Adds two numbers together.\n\n"
    docstring_4 = parse(str_4)

    str_5 = "Adds two numbers together.\n\n"
    docstring_5 = parse(str_5)

    str_6 = "Adds two numbers together.\n\n"
    docstring_6

# Generated at 2022-06-25 16:33:55.817293
# Unit test for function parse
def test_parse():
    # Test case for function parse
    str_0 = "A function that counts the number of words in a string.\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "A function that counts the number of words in a string."
    str_1 = "A function that counts the number of words in a string.\n\nArgs:\n    s (str): Input string.\n\nReturns:\n    int\n        The number of words in the string.\n\n"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "A function that counts the number of words in a string."
    assert docstring_1.long_description == "\n"

# Generated at 2022-06-25 16:34:05.924501
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    assert docstring_0.summary == None
    assert docstring_0.meta == {}
    assert docstring_0.content == {}
    assert docstring_0.extended_summary == None
    assert docstring_0.extended_summary == None
    assert docstring_0.params == {}
    assert docstring_0.returns == None
    assert docstring_0.returns == None
    assert docstring_0.yields == None
    assert docstring_0.yields == None
    assert docstring_0.raises == {}
    assert docstring_0.warns == {}
    assert docstring_0.warns == {}
    assert docstring_0.see_also == []
    assert docstring_0.see

# Generated at 2022-06-25 16:34:11.530173
# Unit test for function parse
def test_parse():
    text = """
    """
    style = Style.auto
    rets = parse(text, style)
    assert rets == Docstring(
        meta={},
        args=[],
        kwargs=[],
        returns=None,
        raises=[],
        other=[])



# Generated at 2022-06-25 16:34:12.961627
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:34:17.536092
# Unit test for function parse
def test_parse():
    str_0 = ' '
    assert parse(str_0) != None


# Generated at 2022-06-25 16:34:23.517603
# Unit test for function parse
def test_parse():
    with open("tests/data/docstring_examples/numpy") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            assert parse(line)

# Generated at 2022-06-25 16:34:26.879087
# Unit test for function parse
def test_parse():
    test_case_0()
    


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:34:38.766465
# Unit test for function parse
def test_parse():
    # Tested method.
    from docstring_parser.parser import parse

    # Setup test cases.
    # Each test case is a tuple.
    # The first value is the test description.
    # The second value is a dict of as follows:
    #     text: The docstring text
    #     style: The docstring style
    #     results: The expected results.
    #         For Docstring, the results is the return value of
    #         Docstring.get_parsed_tuple().
    #         For other values, the results is the value itself.

# Generated at 2022-06-25 16:34:41.149755
# Unit test for function parse
def test_parse():
    assert callable(parse), "Function <parse> not defined"


# Generated at 2022-06-25 16:34:42.153250
# Unit test for function parse
def test_parse():
    assert 1 == 1


# Generated at 2022-06-25 16:34:46.827230
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = Style.numpy
    assert parse(str_0, style_0) is None

# Generated at 2022-06-25 16:34:47.869661
# Unit test for function parse
def test_parse():
    test_case_0()

# Generated at 2022-06-25 16:34:50.040739
# Unit test for function parse
def test_parse():
    print("Testing function parse..."),

    # Test case 0
    test_case_0()

    print("Done.")

# Main
test_parse()

# Generated at 2022-06-25 16:34:56.890841
# Unit test for function parse
def test_parse(): 
    str_0 = 'This function does something.\n\nArgs:\n  arg1: arg1 value\n  arg2: arg2 value\n\nReturns:\n  arg1 + arg2\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0 == 'This function does something.'


# Generated at 2022-06-25 16:35:01.582879
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("") == Docstring()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:35:10.989031
# Unit test for function parse
def test_parse():
    str_0 = "This module provides a single point of entrance for all \
            functionalities.\n\nAll other submodules are available as \
            attriubutes of this one.\n\nOptions\n-------\n\n-  verbose: whether \
            to print process information on screen.\n\nExample\n-------\n\n    \
            import DF\n\n            \n    attr_list = ['_' in s for s in dir(DF)]\n\n            \n    print (len([s for s in attr_list if s is True]))"
    result = parse(str_0)

# Generated at 2022-06-25 16:35:17.418705
# Unit test for function parse
def test_parse():
    parsed = parse('''
    Test function.

    :param x: a number
    :param y: some text
    :returns: the sum of x and y
    :raises ValueError: if x is negative
    ''', Style.numpy)
    assert parsed.short_description == 'Test function.'
    assert parsed.long_description == ''
    assert parsed.params['x'].description == 'a number'
    assert parsed.returns.description == 'the sum of x and y'
    assert parsed.params['y'].description == 'some text'
    assert parsed.raises['ValueError'].description == 'if x is negative'


# Generated at 2022-06-25 16:35:25.494451
# Unit test for function parse
def test_parse():

    # str_0 = None
    # style_0 = Style.auto
    # docstring_0 = parse(str_0, style_0)
    # assert docstring_0 == ?

    pass

# Generated at 2022-06-25 16:35:26.270198
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:35:27.913920
# Unit test for function parse
def test_parse():
    # test for docstring_parser.parser.parse
    str_0 = None
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:35:30.078772
# Unit test for function parse
def test_parse():
    assert parse("Test.")
    assert parse("Test.\n\n")
    assert parse("Test.\n\nMore")
    assert parse("Test.\n  \nMore")


# Generated at 2022-06-25 16:35:36.087431
# Unit test for function parse
def test_parse():
    str_0 = "bla bla bla"
    assert(parse(str_0) == None)
    
    str_1 = "bla bla bla"
    assert(parse(str_1) == None)
    
    str_2 = "bla bla bla"
    assert(parse(str_2) == None)

# Generated at 2022-06-25 16:35:39.869617
# Unit test for function parse
def test_parse():
    assert callable(parse)

if __name__ == '__main__':
    test_case_0()

    test_parse()

# Generated at 2022-06-25 16:35:40.370016
# Unit test for function parse
def test_parse():
    assert True


# Generated at 2022-06-25 16:35:41.549064
# Unit test for function parse
def test_parse():
    assert parse('test') is not None
test_parse()


# Generated at 2022-06-25 16:35:49.131798
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = Style.auto
    assert parse(str_0, style_0) == None
    str_1 = 'This is a test of the docstring parser'
    style_1 = Style.google
    assert parse(str_1, style_1) == None
    str_2 = 'This is a test of the docstring parser'
    style_2 = Style.sphinx
    assert parse(str_2, style_2) == None
    str_3 = 'This is a test of the docstring parser'
    style_3 = Style.numpydoc
    assert parse(str_3, style_3) == None
    str_4 = 'This is a test of the docstring parser'
    style_4 = Style.auto
    assert parse(str_4, style_4) == None

# Generated at 2022-06-25 16:35:50.214133
# Unit test for function parse
def test_parse():
    assert True # implemented

# Generated at 2022-06-25 16:35:55.384928
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:36:05.256389
# Unit test for function parse
def test_parse():

    str_0 = '"Summary line.\\n\\nDescription:\\n    First line.\\n    Second line.\\n\\nArgs:\\n    arg1 (~int): Description of arg1\\n    arg2 (\\"str\\"): Description of arg2\\n\\nReturns:\\n    ~int: Description of return value\\n\\nRaises:\\n    AttributeError: When something is wrong\\n    AndError: Another exception\\n"\n'

# Generated at 2022-06-25 16:36:07.399341
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:36:16.651049
# Unit test for function parse
def test_parse():
    str_0 = \
        '''
    Sample docstring 2.

    Attributes:

        module (str): Module name.

        class_ (str): Class name.

        shortcut (str): Shortcut name.

        name_ (str): Name.
    '''

    docstring_0 = parse(str_0)
    assert(docstring_0.summary == 'Sample docstring 2.')
    assert(docstring_0.extended_summary == '')
    assert(docstring_0.meta == {
        "module": "str",
        "class_": "str",
        "shortcut": "str",
        "name_": "str"})
    assert(docstring_0.docstring == str_0)

    str_2 = None
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:36:19.633742
# Unit test for function parse
def test_parse():
    # Test case 0
    assert None == parse(None)


# Generated at 2022-06-25 16:36:22.159637
# Unit test for function parse
def test_parse():
    str_0 = "hello, world"

    # Call the function
    docstring_0 = parse(str_0)

    assert docstring_0.full_signature == ""

# Generated at 2022-06-25 16:36:30.425276
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = None
    assert parse(str_0) == docstring_0
    str_1 = '''Example of :func:`docstring_parser.parse` usage.

:param param1: The first parameter.
:param param2: The second parameter.
:returns: Description of return value.
:raises keyError: raises an exception
'''
    docstring_1 = Docstring(content=[('Example of ', []), (':func:`docstring_parser.parse` usage.', [])], params=[('param1', 'The first parameter.'), ('param2', 'The second parameter.')], returns='Description of return value.', exceptions=[('keyError', 'raises an exception')], meta={})
    assert parse(str_1) == docstring_1

# Generated at 2022-06-25 16:36:39.511607
# Unit test for function parse
def test_parse():
    # Test for Single Line
    str_0 = "This is a test string"
    docstring_0 = parse(str_0)
    assert(docstring_0.title == "This is a test string")
    assert(docstring_0.metadata == {})
    assert(docstring_0.short_description == "")
    assert(docstring_0.long_description == "")
    assert(docstring_0.returns == "")
    assert(docstring_0.raises == "")
    assert(docstring_0.yields == "")

    # Test for Multi-Line
    str_1 = """This is a test string
    This is a test string
    This is a test string"""
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:36:42.442891
# Unit test for function parse
def test_parse():
    assert parse(str_0) == docstring_0


# Generated at 2022-06-25 16:36:45.312015
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:36:51.409155
# Unit test for function parse
def test_parse():
    assert None == test_case_0()

# Compiled 2 tests for function parse

# Generated at 2022-06-25 16:36:52.353340
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:37:02.576104
# Unit test for function parse
def test_parse():
    import pytest
    import sys
    import doctest

    doctest.testmod()

    # Test with a string docstring
    res = parse('This is a docstring.')
    assert res.short_description == 'This is a docstring.'

    # Test with a multiline docstring
    res = parse('One\nTwo\nThree')
    assert res.short_description == 'One'
    assert res.long_description == 'Two\nThree'

    # Test with a docstring with a colon
    res = parse('Docstring with a colon: No problem.')
    assert res.short_description == 'Docstring with a colon: No problem.'

    # Test with a docstring with a signature
    res = parse('(param) -> object\n:param param: this is my param')

# Generated at 2022-06-25 16:37:10.786211
# Unit test for function parse
def test_parse():
    str_0 = None
    str_1 = ''
    str_2 = 'Summary line.\n\n    Description of longer description.\n'
    str_3 = 'Summary line.\n\n    Description of longer description.\n\n:param arg1: description arg1\n:type arg1: str'
    str_4 = 'Summary line.\n\n    Description of longer description.\n\n:param arg1: description arg1\n:type arg1: str\n:returns: None'
    str_5 = 'Summary line.\n\n    Description of longer description.\n\n:param arg1: description arg1\n:type arg1: str\n:returns: None\n:rtype: None'

# Generated at 2022-06-25 16:37:18.568160
# Unit test for function parse

# Generated at 2022-06-25 16:37:23.472345
# Unit test for function parse
def test_parse():
    # The docstring text to parse
    text_0 = ""
    # The docstring style
    style_0 = Style.rest
    # Parse the docstring into its components
    print(parse(text_0, style_0))
    
    text_1 = "This function parses a string and returns\n  the result\n  as a list."
    style_1 = Style.google
    # Parse the docstring into its components
    print(parse(text_1, style_1))
    
    text_2 = ""
    style_2 = Style.auto
    # Parse the docstring into its components
    print(parse(text_2, style_2))
    

# Generated at 2022-06-25 16:37:33.821808
# Unit test for function parse
def test_parse():
    str_0 = 'Intervals and fermions'
    str_1 = '  Intervals and fermions'
    str_2 = 'Intervals and fermions\n'
    str_3 = 'Intervals and fermions\nLonger version of the name'
    str_4 = 'Intervals and fermions\n\nLonger version of the name'
    case_0 = Docstring(short_description = 'Intervals and fermions')
    case_1 = Docstring(short_description = 'Intervals and fermions')
    case_2 = Docstring(short_description = 'Intervals and fermions\n')
    case_3 = Docstring(short_description = 'Intervals and fermions', long_description = 'Longer version of the name')

# Generated at 2022-06-25 16:37:37.600815
# Unit test for function parse
def test_parse():
    docstring = parse('Hello, world', style=Style.rst)
    assert docstring.short_description == "Hello, world"
    assert docstring.long_description == ""
    assert docstring.nesting_level == 0
    assert docstring.style_name == 'StyledRst'


# Generated at 2022-06-25 16:37:42.015074
# Unit test for function parse
def test_parse():
    assert callable(parse)
    test_case_0()
    try:
        parse()
        assert False
    except TypeError:
        assert True
    except AssertionError:
        print('expected function `parse` to raise an error')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:37:55.344266
# Unit test for function parse
def test_parse():
    # Tests for function parse

    import sys

    # Setup
    if sys.version_info < (3, 0):
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    text = """A simple function.

:param arg1: The first argument.
:param arg2: The second argument.
:returns: a value
:raises Exception: handle exception
"""
    expected_output = """A simple function.

:param arg1: The first argument.
:param arg2: The second argument.
:returns: a value
:raises: Exception: handle exception
"""


# Generated at 2022-06-25 16:38:00.998263
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:38:04.837814
# Unit test for function parse
def test_parse():
    string_0 = 'hello'
    string_1 = 'hello'
    obj_0 = parse(string_0)
    obj_1 = parse(string_0, string_1)

    assert obj_0 is not None
    assert obj_1 is not None


# Generated at 2022-06-25 16:38:06.813880
# Unit test for function parse
def test_parse():
    assert parse("") == None
    assert parse("This is an invalid docstring") == None
    assert parse("This function does nothing.\n    ") == None

test_parse()

# Generated at 2022-06-25 16:38:16.687430
# Unit test for function parse
def test_parse():
    str_0 = """This is a description.

    This is also a description.
    """
    docstring_0 = parse(str_0)
    assert hasattr(docstring_0, 'long_description')
    assert docstring_0.long_description == 'This is a description.  This is also a description.'
    assert docstring_0.short_description == 'This is a description.'
    # test_parse0_error
    try:
        str_0 = """This is a description.

        This is also a description.
        """
        docstring_0 = parse(str_0)
    except ParseError:
        pass
    # test_parse1_error

# Generated at 2022-06-25 16:38:20.701172
# Unit test for function parse
def test_parse():
    assert True # TODO: implement your test here

# Run the unit tests

# Generated at 2022-06-25 16:38:29.917897
# Unit test for function parse
def test_parse():
    str_0 = """
  This should be the long description

  Parameters
  ----------
  arg1
      The first argument
  arg2
      The second argument
  arg3
      The third argument
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "This should be the long description"
    assert docstring_0.long_description == ""
    assert len(docstring_0.parameters) == 3
    assert isinstance(docstring_0.parameters[0], docstring_parser.common.Parameter)
    assert docstring_0.parameters[0].name == "arg1"
    assert docstring_0.parameters[0].description == "The first argument"

# Generated at 2022-06-25 16:38:37.672999
# Unit test for function parse
def test_parse():
    # test args_0
    str_0 = None
    style_0 = Style.google
    try:
        docstring_0 = parse(str_0, style_0)
        assert False
    except ParseError:
        pass

    # test args_1
    str_1 = """
    This is a function.
    """
    style_1 = Style.google
    docstring_1 = parse(str_1, style_1)
    assert type(docstring_1) == Docstring


# Add more tests if you have time, please!

# Generated at 2022-06-25 16:38:44.269857
# Unit test for function parse
def test_parse():
    # AssertionError: AssertionError not raised
    # assert pytest.raises(AssertionError, test_case_0)
    pass

# Generated at 2022-06-25 16:38:54.226309
# Unit test for function parse
def test_parse():
    str_1 = """Arguments: x : int
            y : string
            z : list, optional
        """
    str_2 = "Parameters\n    ----------\n    x : int\n"
    str_3 = """Аргументы:x : int
            y : string
            z : list, optional
        """
    str_4 = """x : int
            y : string
            z : list, optional
        """

    print(parse(str_1).__dict__)
    print(parse(str_2).__dict__)
    print(parse(str_3).__dict__)
    print(parse(str_4).__dict__)


# Generated at 2022-06-25 16:39:04.745289
# Unit test for function parse
def test_parse():

    str_0 = None
    docstring_0 = parse(str_0)
    str_1 = '''\
    The full name of the person.

    :param str first_name: the person's first name
    :param str last_name: the person's last name
    :param str title: the person's title
    :returns: the person's full name
    '''
    docstring_1 = parse(str_1)
    str_2 = '''\
    Sanitize the text.

    :param str text: raw text to sanitize
    :param str replacement_text: text to replace bad words with
    :returns: sanitized text
    '''
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:39:12.969525
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:39:22.663797
# Unit test for function parse
def test_parse():
    str_0 = 'This is a module to be tested.'
    docstring_0 = parse(str_0, Style.auto)
    assert docstring_0.full == 'This is a module to be tested.'
    assert docstring_0.short == 'This is a module to be tested.'
    assert docstring_0.long == ''
    assert docstring_0.meta == ''
    assert len(docstring_0.sections) == 0

    str_1 = 'This is a module to be tested.\n\n'
    docstring_1 = parse(str_1, Style.auto)
    assert docstring_1.full == 'This is a module to be tested.\n\n'
    assert docstring_1.short == 'This is a module to be tested.'
    assert docstring_1.long == ''

# Generated at 2022-06-25 16:39:33.701164
# Unit test for function parse
def test_parse():
    str_0 = 'This is a docstring.'
    style_0 = Style.reST
    docstring_0 = parse(str_0, style_0)
    assert (str(docstring_0) == 'This is a docstring.')
    assert (docstring_0.summary == 'This is a docstring.')
    assert (docstring_0.body == '')
    assert (docstring_0.meta == {})
    style_1 = Style.auto
    docstring_1 = parse(str_0, style_1)
    assert (str(docstring_1) == 'This is a docstring.')
    assert (docstring_1.summary == 'This is a docstring.')
    assert (docstring_1.body == '')
    assert (docstring_1.meta == {})
    str_

# Generated at 2022-06-25 16:39:37.155865
# Unit test for function parse
def test_parse():
    parser = parse
    assert parser('test parse') == None
    assert parser('test parse') == None



# Generated at 2022-06-25 16:39:40.341399
# Unit test for function parse
def test_parse():
    assert len(parse("None", style=Style.numpy).params) == 0
    assert parse("None", style=Style.numpy).return_type == 'None'


# Generated at 2022-06-25 16:39:50.053249
# Unit test for function parse
def test_parse():
    # {
    #   'docstring': '', 
    #   'meta': {
    #     'summary': '', 
    #     'author': '', 
    #     'date': None, 
    #     'return': {
    #       'type': None, 
    #       'desc': None
    #     }, 
    #     'args': {}, 
    #     'raises': {}
    #   }
    # }
    assert_equals(parse(""), _parse_str(""))

    # {
    #   'docstring': '', 
    #   'meta': {
    #     'summary': '', 
    #     'author': '', 
    #     'date': None, 
    #     'return': {
    #       'type': None, 

# Generated at 2022-06-25 16:39:51.060834
# Unit test for function parse
def test_parse():
    assert 0


# Generated at 2022-06-25 16:39:57.223680
# Unit test for function parse
def test_parse():
    text = """
    Args:
        x:    The repeated argument.
        y(int):
            The singular argument.

    Returns:
        The return value(s).
    """
    docstring_1 = parse(text)
    assert docstring_1.args == ['x', 'y'], "Incorrect argument parsing."
    assert docstring_1.kwargs == {'y': 'int'}, "Incorrect keyword argument parsing."
    assert docstring_1.returns == ['The return value(s).'], "Incorrect return value parsing."


# Generated at 2022-06-25 16:40:06.661362
# Unit test for function parse
def test_parse():
    str_0 = """
    :param path: The path of the file to open (string)
    :param mode: The mode with which to open the file (string)
    :returns: A file object
    :raises: :class:`FileNotFoundError`
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ""
    assert not docstring_0.long_description
    assert not docstring_0.meta
    assert len(docstring_0.body) == 4
    assert docstring_0.body[0] == ('param', 'path', 'The path of the file to open (string)')
    assert docstring_0.body[1] == ('param', 'mode', 'The mode with which to open the file (string)')

# Generated at 2022-06-25 16:40:15.889857
# Unit test for function parse
def test_parse():
    str_0 = "This is a sample docstring."
    assert parse(str_0) == Docstring(
        summary="This is a sample docstring."
    )
    str_1 = "This is a sample docstring.\n\nThis is a summary."
    assert parse(str_1) == Docstring(
        summary="This is a summary."
    )
    str_2 = "This is a sample docstring.\n\nThis is a summary.\n\nThis is a description."
    assert parse(str_2) == Docstring(
        summary="This is a summary.",
        description="This is a description."
    )

# Generated at 2022-06-25 16:40:29.070296
# Unit test for function parse
def test_parse():
    parse("")

    docstring = parse("arg")
    assert docstring.short_description == "arg"

    docstring = parse("""
        """ + "a" * 50 + """

        """ + "b" * 50 + """

        """ + "c" * 50 + """

        """ + "d" * 50 + """
        """)
    assert docstring.short_description == "a" * 50
    assert docstring.long_description == "b" * 50 + "\n" + "c" * 50
    assert docstring.meta["d"] == "d" * 50


# Generated at 2022-06-25 16:40:33.881723
# Unit test for function parse
def test_parse():
    assert parse('returns\n    something') == Docstring(
        meta={'returns': 'something'},
        summary='',
        body='',
        params=[],
        raises=[],
        )
    assert parse('returns\nsomething') == Docstring(
        meta={'returns': ''},
        summary='returns',
        body='something',
        params=[],
        raises=[],
        )
    assert parse('something\nreturns\n    something else') == Docstring(
        meta={'returns': 'something else'},
        summary='something',
        body='',
        params=[],
        raises=[],
        )

# Generated at 2022-06-25 16:40:42.971151
# Unit test for function parse
def test_parse():
    str_0 = "testcase 0"
    style_0 = Style.numpy
    docstring_0 = parse(str_0, style_0)
    str_1 = "testcase 1"
    style_1 = Style.auto
    docstring_1 = parse(str_1, style_1)
    str_2 = "testcase 2"
    style_2 = Style.google
    docstring_2 = parse(str_2, style_2)
    str_3 = "testcase 3"
    style_3 = Style.numpydoc
    docstring_3 = parse(str_3, style_3)


# Parsing of the source file.
if __name__ == "__main__":
    with open("docstring_parser/main.py", "r") as f:
        source = f.read

# Generated at 2022-06-25 16:40:53.491352
# Unit test for function parse
def test_parse():
    str_0 = """This is a docstring"""
    assert parse(str_0, style=Style.numpy) == Docstring(summary=str_0,
                                                        meta=[],
                                                        body=[])

    str_1 = """This is a docstring\n"""
    assert parse(str_1, style=Style.numpy) == Docstring(summary=str_1[:-1],
                                                        meta=[],
                                                        body=[])

    str_2 = """This is a docstring\n\n"""
    assert parse(str_2, style=Style.numpy) == Docstring(summary=str_2[:-2],
                                                        meta=[],
                                                        body=[])

    str_3 = """This is a docstring\n\n\n"""

# Generated at 2022-06-25 16:40:59.297902
# Unit test for function parse
def test_parse():
    str_0 = """
    @brief: 
    @param: 
    """
    docstring_0 = parse(str_0)
    assert(docstring_0.short_description == '')
    assert(docstring_0.long_description == '')
    assert(docstring_0.tags == {'param'})


# Generated at 2022-06-25 16:41:10.233706
# Unit test for function parse
def test_parse():
    str_0 = '''docstring'''
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    assert docstring_0.summary == 'docstring'
    assert docstring_0.extended_summary == ''
    assert docstring_0.body == ''
    assert docstring_0.return_type == 'None'
    assert docstring_0.return_desc == ''
    assert len(docstring_0.meta) == 0
    str_1 = '''docstring'''
    style_1 = Style.epytext
    docstring_1 = parse(str_0, style_1)
    assert docstring_0.summary == 'docstring'
    assert docstring_0.extended_summary == ''
    assert docstring_0.body == ''
   

# Generated at 2022-06-25 16:41:11.432245
# Unit test for function parse
def test_parse():
    assert parse(str(None)) == None

# Generated at 2022-06-25 16:41:16.483427
# Unit test for function parse
def test_parse():
    str_0 = 'Arguments:\n\n\tx -- foo\n\ny -- bar\n\n'
    style_0 = Style.google
    docstring_0 = parse(str_0, style_0)
    docstring_0 = parse(str_0)
    assert (docstring_0.args == {'x', 'y'})


# Generated at 2022-06-25 16:41:20.104929
# Unit test for function parse
def test_parse():
    str_0 = 'Test string'
    style_0 = Style(str_0)
    obj_0 = parse(str_0, style_0)

    assert obj_0.summary == 'Test string'

# Unit tests for class Docstring

# Generated at 2022-06-25 16:41:28.892003
# Unit test for function parse
def test_parse():
    # Strings
    str_0 = None
    str_1 = ''
    str_2 = 'Hello'
    str_3 = 'Hello, this is a description'
    str_4 = 'Hello, this is a description\n    that is split across\n    multiple lines'
    str_5 = 'Hello, this is a description\n    that is split across\n    multiple lines\n\nArguments:\n    param1: First parameter\n    param2: Second parameter'
    str_6 = 'Hello, this is a description\n    that is split across\n    multiple lines\n\nArguments:\n    param1: First parameter\n    param2: Second parameter\n\nReturns:\n    Return value'

# Generated at 2022-06-25 16:41:31.762726
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-25 16:41:39.510826
# Unit test for function parse
def test_parse():
    # Mock data for parse
    str_0 = "Test string"

    # Invoke function
    docstring_0 = parse(str_0)

    for t in docstring_0.short_description:
        if t.data != 'Test string':
            print('Failed test_parse')
        assert t.data == 'Test string'
    if docstring_0.long_description != None:
        print('Failed test_parse')
        assert False
    for t in docstring_0.meta.keys():
        if t != None:
            print('Failed test_parse')
            assert False
    for t in docstring_0.meta.values():
        if t != None:
            print('Failed test_parse')
            assert False

# Generated at 2022-06-25 16:41:49.508218
# Unit test for function parse
def test_parse():
    str_0 = \
    """
    This is function docstring

    :param arg_0: arg_0 description
    :type arg_0: int, float
    :param arg_1: arg_1 description
    :type arg_1: str
    :returns: None
    :rtype: NoneType
    """
    docstring_0 = parse(str_0)
    str_1 = \
    """
    This is function docstring

    :param arg_0: arg_0 description
    :type arg_0: int, float
    :param arg_1: arg_1 description
    :type arg_1: str
    :returns: None
    :rtype: NoneType
    """
    docstring_1 = parse(str_1)
    assert docstring_0 == docstring_1

# Unit

# Generated at 2022-06-25 16:41:53.291257
# Unit test for function parse
def test_parse():
    assert parse("")
    assert [parse("")]


# Generated at 2022-06-25 16:41:56.752547
# Unit test for function parse
def test_parse():

    # Call function parse
    # Assert if the returned valuie is of type Docstring
    assert isinstance(parse(text), Docstring)



if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:42:07.411479
# Unit test for function parse
def test_parse():
    function_arg_0 = "Argument: s -- The string to parse."
    function_arg_1 = "Argument: style -- str, optional"
    function_arg_2 = "Return type: Docstring"
    function_arg_3 = "Return type: ParseError"
    function_arg_4 = "style != Style.auto"
    function_arg_5 = "style == Style.auto"
    function_arg_6 = "rets.append(parse_(text))"
    function_arg_7 = "rets = sorted(rets, key=lambda d: len(d.meta), reverse=True)"
    function_arg_8 = "return sorted(rets, key=lambda d: len(d.meta), reverse=True)[0]"
    function_return_0 = function_arg_1
    function_return_1 = function_

# Generated at 2022-06-25 16:42:08.944008
# Unit test for function parse
def test_parse():
    assert callable(parse), "Function parse not defined"

# Generated at 2022-06-25 16:42:18.985128
# Unit test for function parse
def test_parse():
    str_0 = """
    #test
    sum
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'sum'
    assert docstring_0.short_description == 'sum'
    str_1 = None
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == None


if __name__ == '__main__':
    o = open('code.txt', 'r')
    for line in o.readlines():
        if line.startswith('#'):
            continue
        if line.startswith('"""') or line.startswith('"'):
            print(parse(line))

# Generated at 2022-06-25 16:42:22.159695
# Unit test for function parse
def test_parse():
    str_test = None
    docstring_test = parse(str_test)


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:42:34.503958
# Unit test for function parse
def test_parse():
    print('Test function parse')
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 16:42:44.978215
# Unit test for function parse
def test_parse():
    str_0 = "test docstring"
    docstring_0 = parse(str_0)
    str_1 = "test docstring\n"
    docstring_1 = parse(str_1)
    str_2 = "test docstring\n\nmore test"
    docstring_2 = parse(str_2)
    str_3 = "test docstring\n\nmore test\n\n"
    docstring_3 = parse(str_3)
    str_4 = "test docstring\n\nmore test\n\n\n"
    docstring_4 = parse(str_4)
    str_5 = "test docstring\n\nmore test\n\nanother line"
    docstring_5 = parse(str_5)

# Generated at 2022-06-25 16:42:46.594702
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:42:56.142176
# Unit test for function parse
def test_parse():
    str_1 = """Summary line.

    Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value

    """
    docstring_1 = parse(str_1, Style.numpy)
    assert docstring_1.short_description == "Summary line."
    assert docstring_1.long_description == "Extended description."
    assert docstring_1.returns.type_name == "bool"
    assert docstring_1.returns.description == "Description of return value"
    assert docstring_1.meta["Args"][0].arg_name == "arg1"
    assert docstring_1.meta["Args"][0].type_name == "int"

# Generated at 2022-06-25 16:43:06.485347
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:43:11.836655
# Unit test for function parse
def test_parse():
    str_1 = """\
        Single-line docstring

        Nothing interesting here.
        """
    expected_1 = Docstring(
        summary="Single-line docstring", content="""\
        Single-line docstring

        Nothing interesting here.
    """,
        returns=None,
        parameters=[],
        meta={},
        examples=[]
    )

    assert parse(str_1) == expected_1
    str_2 = """\
        Single-line docstring with line breaks

        Some things written
        on multiple lines.
        """

# Generated at 2022-06-25 16:43:22.689160
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = 0
    parse_0 = parse(str_0, style_0)

if __name__ == '__main__':
    import sys
    import timeit

    if len(sys.argv) == 1:
        for i in range(1):
            print(timeit.timeit(stmt="test_case_0()", setup="from __main__ import test_case_0", number=1))
    elif len(sys.argv) == 2:
        if sys.argv[1] == "-t":
            print(timeit.timeit(stmt="test_parse()", setup="from __main__ import test_parse", number=10))