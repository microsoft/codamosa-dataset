

# Generated at 2022-06-25 16:33:36.645922
# Unit test for function parse
def test_parse():
    docstring = parse('''"""
    The module's docstring.
    """''')
    assert docstring.summary == "The module's docstring."


# Generated at 2022-06-25 16:33:39.430433
# Unit test for function parse
def test_parse():
    assert callable(parse)

# test_case_0()
test_parse()

# Generated at 2022-06-25 16:33:40.806722
# Unit test for function parse
def test_parse():
    test_case_0()

# main function
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:33:47.491608
# Unit test for function parse
def test_parse():
    text = '\n   Foo bar baz.\n\n   '
    style = Style.numpy
    ds = parse(text, style)
    assert ds.short_desc is None
    assert len(ds.long_desc) == 2
    assert ds.long_desc[0] == 'Foo bar baz.'
    assert ds.long_desc[1] == ''
    assert not ds.sections
    
test_case_0()
test_parse()

# Generated at 2022-06-25 16:33:57.992425
# Unit test for function parse
def test_parse():
	str_a = d = '''
		This is a test docstring.

		Args:
		    a: 1
		    b: 2

		Returns:
		    True
		'''
	docstring_a = parse(str_a)
	assert len(docstring_a.summary) == 1
	assert docstring_a.summary[0] == 'This is a test docstring.'
	assert len(docstring_a.body) == 0
	assert len(docstring_a.params) == 2
	assert len(docstring_a.returns) == 1
	assert len(docstring_a.meta) == 1
	assert docstring_a.meta[0] == 'Args:'
	assert len(docstring_a.raises) == 0

# Generated at 2022-06-25 16:34:10.417000
# Unit test for function parse
def test_parse():
    docstring_0 = parse("This is a docstring.")
    assert docstring_0.summary == "This is a docstring."
    docstring_1 = parse("This is a docstring.\n\nAnd now some more text.")
    assert docstring_1.summary == "This is a docstring."
    docstring_2 = parse("This is a docstring.\n\nOn two lines.")
    assert docstring_2.summary == "This is a docstring."
    docstring_3 = parse("This is a docstring.\n\nAdditional text\nand another line.")
    assert docstring_3.summary == "This is a docstring."
    docstring_4 = parse("This is a docstring.\n\nAdditional text on two\nlines.")

# Generated at 2022-06-25 16:34:11.245738
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:34:15.866397
# Unit test for function parse
def test_parse():
    # Automatically generated unit test for function parse
    # ********************************************************
    # TODO: This is not a complete unit test for this function
    # ********************************************************

    # Run function to obtain input and output of the function
    input_arguments, output_from_function = parse(str_0)
    # Create instance of the function being tested
    function_under_test = parse(str_0)

    assert function_under_test == output_from_function
    # ********************************************************

# Generated at 2022-06-25 16:34:23.646722
# Unit test for function parse
def test_parse():
    str_0 = """Docstring of the function.
    """
    docstring_0 = parse(str_0)
    assert docstring_0.meta['short_description'] == 'Docstring of the function.'
    str_1 = """Docstring of the function.
    """
    docstring_1 = parse(str_1)
    assert docstring_1.meta['short_description'] == 'Docstring of the function.'
    str_2 = """Docstring of the function."""
    docstring_2 = parse(str_2)
    assert docstring_2.meta['short_description'] == 'Docstring of the function.'
    str_3 = """Docstring of the function."""
    docstring_3 = parse(str_3)
    assert docstring_3.meta['short_description'] == 'Docstring of the function.'

# Generated at 2022-06-25 16:34:25.568587
# Unit test for function parse
def test_parse():
    docstring_0 = None
    str_0 = "Test text"
    assert parse(str_0) == docstring_0


# Generated at 2022-06-25 16:34:31.939736
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    test_case_0(str_0)

test_parse()

# Generated at 2022-06-25 16:34:34.350068
# Unit test for function parse
def test_parse():
    assert parse(str_0, style=Style.auto)


# Generated at 2022-06-25 16:34:39.338513
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    assert (parse(str_0, style=Style.numpy, **kwargs) == None)
    assert (parse(str_0) == None)

# Generated at 2022-06-25 16:34:43.318244
# Unit test for function parse
def test_parse():
    text = '\n   Foo bar baz.\n\n   '
    # Test if expected is equal to actual
    if parse(text) == Docstring(short_description='Foo bar baz.'):
        return True
    return False


if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:34:54.017714
# Unit test for function parse
def test_parse():
    text = """
       Python is a great programming language.
       Its syntax is simple and expressive.

       The library has many aspects that can help a programmer.
       Some of them are:
           - Powerful
           - Object-oriented
           - Dynamic

       This is a small example to get you started.

       >>> print("Hello World!")
       Hello World!
    """
    style = Style.numpy

    test_case_0()

    docstring = parse(text, style)
    assert(docstring.short_description == 'Python is a great programming language.')
    assert(docstring.long_description == 'Its syntax is simple and expressive.\nThe library has many aspects that can help a programmer. Some of them are:\n- Powerful\n- Object-oriented\n- Dynamic\n\nThis is a small example to get you started.')
   

# Generated at 2022-06-25 16:34:54.871954
# Unit test for function parse
def test_parse():
    # Test 0:
    test_case_0()

# Generated at 2022-06-25 16:35:03.196967
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    style = Style.google

    assert parse('', style) == Docstring('', '', '', '', '', '', '', '', '', '')
    assert parse(' ', style) == Docstring('', '', '', '', '', '', '', '', '', '')
    assert parse('    ', style) == Docstring('', '', '', '', '', '', '', '', '', '')

    # no description
    assert parse(' :param int param_0:', style) == Docstring('', '', '', 'param_0', 'int', '', '', '', '', '')

# Generated at 2022-06-25 16:35:12.027033
# Unit test for function parse
def test_parse():
    text = 'Title\n----\nSummary\n\nOptional\n'
    style = Style.numpy
    assert(parse(text, style).title.strip() == 'Title')
    assert(parse(text, style).summary.strip() == 'Summary')
    assert(parse(text, style).meta[0].strip() == 'Optional')

# Generated at 2022-06-25 16:35:18.568108
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    str_1 = '\n   Foo bar baz.\n\n   '
    str_2 = '\n   Foo bar baz.\n\n   '
    style_0 = Style.google
    style_1 = Style.numpy
    style_2 = Style.auto
    try:
        r = parse(str_0, style_0)
    except ParseError as e:
        assert(False)
    try:
        r = parse(str_1, style_1)
    except ParseError as e:
        assert(False)
    try:
        r = parse(str_2, style_2)
    except ParseError as e:
        assert(False)

# Generated at 2022-06-25 16:35:22.933957
# Unit test for function parse
def test_parse():
    # Test for match 1 :
    str_0 = '\n   Docstring for foo.\n  '
    style_0 = Style.google
    dict_0 = parse(str_0, style_0)
    dict_1 = {'Description': [], 'Section': OrderedDict()}
    dict_1['Section']['Parameters'] = [{'param_name': 'a', 'param_desc': 'Argument a', 'delimiter': None}]
    dict_1['Section']['Args'] = [{'param_name': 'a', 'param_desc': 'Argument a', 'delimiter': None}]
    dict_1['Section']['Arguments'] = [{'param_name': 'a', 'param_desc': 'Argument a', 'delimiter': None}]
    dict

# Generated at 2022-06-25 16:35:33.813594
# Unit test for function parse
def test_parse():
    # 1-1 test
    str_1 = '\n   Foo bar baz.'
    actual_1 = parse(str_1)
    assert actual_1.short_description.strip() == 'Foo bar baz.'

    # 1-2 test
    str_2 = '\n   Foo bar baz.\n\n   '
    actual_2 = parse(str_2)
    assert actual_2.short_description.strip() == 'Foo bar baz.'
    assert actual_2.long_description.strip() == ''

    # 1-3 test
    str_3 = '\n   Foo bar baz.\n   Foo bar baz.\n\n   1'
    actual_3 = parse(str_3)

# Generated at 2022-06-25 16:35:41.604004
# Unit test for function parse
def test_parse():
    func1=open('functions/func1.func')
    func2=open('functions/func2.func')
    func3=open('functions/func3.func')
    func4=open('functions/func4.func')
    func5=open('functions/func5.func')
    func6=open('functions/func6.func')
    func7=open('functions/func7.func')
    func8=open('functions/func8.func')
    func9=open('functions/func9.func')
    func10=open('functions/func10.func')

#add your test cases

#main program

# Generated at 2022-06-25 16:35:43.375399
# Unit test for function parse
def test_parse():
    assert callable(parse)

if __name__ == '__main__':
    test_parse()
    test_case_0()

# Generated at 2022-06-25 16:35:50.128240
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    text = """
    One line summary.

    Extended description.

    Args:
        arg1(int): Description of `arg1`
        arg2(str): Description of `arg2`

    Kwargs:
        kwarg1(int): Description of `kwarg1`
        kwarg2(str): Description of `kwarg2`

    Returns:
        int: Description of return value
    """

    # Test return value
    docstring = parse(text)
    assert docstring.short_description == 'One line summary.'
    assert docstring.long_description == 'Extended description.'
    assert docstring.params['arg1'] == 'Description of `arg1`'
    assert docstring.params['arg2'] == 'Description of `arg2`'
    assert docstring.params

# Generated at 2022-06-25 16:35:54.816260
# Unit test for function parse
def test_parse():
    try:
        assert callable(parse)
    except Exception:
        assert False
        print('Function \'parse\' is not callable.')
        return
    
    print('Function \'parse\' passed all tests.')


# Program entry point
if __name__ == '__main__':
    print('Testing...')
    test_parse()

# Generated at 2022-06-25 16:35:55.771409
# Unit test for function parse
def test_parse():
    test_case_0()
    return

# Generated at 2022-06-25 16:36:06.602690
# Unit test for function parse
def test_parse():
	docstring = '''
    Summarize the Blah class here.

    Longer description of the blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah
    blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah
    blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah

    :param x: Description of `x`.
    :type x: int
    :param y: Description of `y`.
    :type y: int
    :raises ValueError: If `x` or `y` are invalid.
    :rtype: int
    :return: Description of return value.
    :rtype: NoIdea
    '''

	doc = parse(docstring)

	print('Summary:', doc.summary)
	

# Generated at 2022-06-25 16:36:08.395895
# Unit test for function parse
def test_parse():
    input_data = "name\n"
    output_data = "name"
    output = parse(input_data)
    assert output == output_data

# Generated at 2022-06-25 16:36:14.860659
# Unit test for function parse
def test_parse():

    text_0 = '\n   Foo bar baz.\n\n   '
    style_0 = Style.auto
    res_0 = parse(text_0,style_0)
    res_0.text = 'Foo bar baz.'

    assert res_0.text == 'Foo bar baz.'

if __name__ == '__main__':
    import pytest
    pytest.main(['-s', '--tb=native', '--pyargs', 'docstring_parser.parse'])

# Generated at 2022-06-25 16:36:16.941253
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    parse(str_0, Style.google)
    assert True

# Generated at 2022-06-25 16:36:21.587825
# Unit test for function parse
def test_parse():
    print(parse(str_0))

# Generated at 2022-06-25 16:36:23.356781
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 16:36:31.216947
# Unit test for function parse
def test_parse():
    str_0 = '''
    The :class:`foo` class.

    This is a more detailed description.

    :param arg1: first argument
    :param arg2: second argument
    :returns: nothing
    :raises arg3: if something bad happens
    '''
    str_1 = '''
    The :class:`foo` class.

    This is a more detailed description.

    :param arg1: first argument
    :param arg2: second argument
    :raises arg3: if something bad happens
    :returns: nothing
    '''

# Generated at 2022-06-25 16:36:40.025182
# Unit test for function parse
def test_parse():
    assert parse('\n   Foo bar baz.\n\n   ') == parse('\n   Foo bar baz.\n\n   ', Style.auto)
    assert parse('\n   Foo bar baz.\n\n   ') == parse('\n   Foo bar baz.\n\n   ', Style.pep257)
    assert parse('\n   Foo bar baz.\n\n   ') == parse('\n   Foo bar baz.\n\n   ', Style.google)
    assert parse('\n   Foo bar baz.\n\n   ') == parse('\n   Foo bar baz.\n\n   ', Style.numpy)

# Generated at 2022-06-25 16:36:45.950814
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    str_1 = '\n        Foo bar baz.\n\n        '
    str_2 = '\nFoo bar baz.\n\n'
    str_3 = '\n        Foo bar baz.\n\n'
    str_4 = '\n   Foo bar baz.\n\n'
    str_5 = '\nFoo bar \n   baz.\n\n'
    str_6 = '\nFoo bar baz.\n'
    str_7 = '  Foo bar baz.  '
    str_8 = '\n   Foo bar \n   baz.\n\n'

# Generated at 2022-06-25 16:36:52.475221
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    res_0 = parse(str_0, Style.auto)
    res_1 = parse(str_0, Style.pep257)
    res_2 = parse(str_0, Style.numpy)

# Generated at 2022-06-25 16:37:02.698209
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    str_1 = '\n   Foo bar baz.\n\n   '
    str_2 = '\n   Foo bar baz.\n\n   '

    # Testing for int with style
    # AssertionError: Expected 1 to equal 2
    assert parse(str_0, 1) == parse(str_0, 2)

    # Testing for str with style
    # AssertionError: Expected '\n   Foo bar baz.\n\n   ' to equal '\n   Foo bar baz.\n\n   '

# Generated at 2022-06-25 16:37:10.922869
# Unit test for function parse
def test_parse():
    # Example 0:
    str_0 = '\n   Foo bar baz.\n\n   '
    try:
        str_1 = parse(str_0)
    except:
        succ_0 = False
    else:
        succ_0 = True
    assert succ_0

    # Example 1:
    str_0 = '\n   Foo bar baz.\n\n   '
    try:
        str_1 = parse(str_0, )
    except:
        succ_0 = False
    else:
        succ_0 = True
    assert succ_0

    # Example 2:
    str_0 = '\n   Foo bar baz.\n\n   '
    try:
        str_1 = parse(str_0, )
    except:
        succ_0 = False
   

# Generated at 2022-06-25 16:37:12.079951
# Unit test for function parse
def test_parse():

    test_case_0()
    #
    # 
    #

# Generated at 2022-06-25 16:37:19.379069
# Unit test for function parse
def test_parse():
    foo = '''  This is a short summary.
    Various newlines and tabs are being used here.
    
        Indented paragraphs and lists should be unindented to the
        level of the first non-whitespace character, and then
        reformatted to fit the line width.
          * This is the reformatted list item #1.
            Some other text.
          * This is the reformatted list item #2.
    
        Here is the second paragraph.
    Paragraphs should be separated by two newlines.
    
    * This is the new list item #1.
    * This is the new list item #2.
    
        More text in list item #2.
    '''
    result = parse(foo)
    print(result)
    print(repr(result))


# Generated at 2022-06-25 16:37:26.468929
# Unit test for function parse
def test_parse():
    with pytest.raises(TypeError):
        parse()
    with pytest.raises(TypeError):
        parse(text='')


# Generated at 2022-06-25 16:37:29.323778
# Unit test for function parse
def test_parse():
    text = '   Foo bar baz.\n\n'
    style = Style.reStructuredText
    assert parse(text, style) == Docstring('Foo bar baz.', [], [], [], '')

# Generated at 2022-06-25 16:37:37.350745
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    str_1 = '\n   Bar foo baz.\n\n   '
    str_2 = '\n   Baz foo bar.\n\n   '
    str_3 = '\n   Bar baz foo.\n\n   '
    str_4 = '\n   Foo baz bar.\n\n   '
    str_5 = '\n   Bar foo baz.\n\n   '
    str_6 = '\n   Baz foo bar.\n\n   '
    str_7 = '\n   Bar baz foo.\n\n   '
    str_8 = '\n   Foo baz bar.\n\n   '

# Generated at 2022-06-25 16:37:39.409910
# Unit test for function parse
def test_parse():
    # Test for cases where style = None
    assert 1 # TODO: implement your test here


# Generated at 2022-06-25 16:37:45.430592
# Unit test for function parse
def test_parse():
    text = '\n   Foo bar baz.\n\n   '
    style = Style.auto
    test_case_0(text, style)
    str_0 = '\n   Foo bar baz.\n\n   '
    text_1 = '\n   Foo bar baz.\n\n   '
    test_case_0(text_1, style)


# Generated at 2022-06-25 16:37:52.496394
# Unit test for function parse
def test_parse():
    import random, string
    LENGTH = 100

    # Test case 0
    # string_0 = '\n   Foo bar baz.\n\n   '
    # result_0 = parse(string_0)
    #
    # assert result_0 != None

    # Test case 1
    str_1 = ''.join(random.choice(string.ascii_letters) for i in range(LENGTH))
    result_1 = parse(str_1)
    assert result_1 != None


if __name__ == "__main__":
    # test_case_0()
    test_parse()

# Generated at 2022-06-25 16:37:59.101350
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    str_1 = '\n   '
    str_2 = '\n   \n   Foo bar baz.\n\n   '
    str_3 = '\n   Foo bar baz.\n\n   '
    str_4 = '\n   Foo bar baz.\n\n   \n   '
    str_5 = '\n   \n   Foo bar baz.\n\n   '
    str_6 = '\n   Foo bar baz.\n\n   '
    str_7 = '\n   Foo bar baz.\n\n   \n\n   '
    str_8 = '\n\n   Foo bar baz.\n\n   '
    str_9

# Generated at 2022-06-25 16:38:02.243498
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    #tests.assertEqual(parse(str_0), "")

# Generated at 2022-06-25 16:38:15.023407
# Unit test for function parse
def test_parse():
    str_0 = '\n   Foo bar baz.\n\n   '
    str_1 = '\n   Foo bar baz\n   '
    str_2 = '\n   Foo bar baz and more.\n\n   '
    str_3 = '\n   This is a longer foo bar baz with more text.\n   '
    str_4 = '\n   Foo bar baz and more.\n\n   '
    str_5 = '\n   Foo bar baz.\n\n   '
    str_6 = '\n   Foo bar baz and more.\n\n   '
    str_7 = '\n   This is a longer foo bar baz with more text.\n   '

# Generated at 2022-06-25 16:38:19.685015
# Unit test for function parse
def test_parse():

    # Run test for the following version:
    version = '0.1.0'

    text_0 = '\n   Foo bar baz.\n\n   '
    try:
        # Testing method parse against text_0
        assert parse(text_0), \
            "parse(text_0) returned unexpected value"

    except AssertionError as e:
        print(
            "AssertionError raised in TestCase: ",
            e.__class__.__name__)

    test_case_0()


# Generated at 2022-06-25 16:38:31.095973
# Unit test for function parse
def test_parse():
    # Hint: Use the following test cases to test your function:
    assert parse("") == Docstring()
    assert parse("hello world") == Docstring("hello world")
    assert parse("hello\nworld") == Docstring("hello\nworld")
    assert parse("hello\nworld\n") == Docstring("hello\nworld")
    assert parse("hello\nworld\n\n") == Docstring("hello\nworld")
    assert parse("hello\n\nworld") == Docstring("hello\n\nworld")
    assert parse("hello world\n") == Docstring("hello world")
    assert parse("hello world\n\n") == Docstring("hello world")
    assert parse("hello\nworld\n") == Docstring("hello\nworld")
    assert parse("hello\nworld\n\n") == Doc

# Generated at 2022-06-25 16:38:42.454646
# Unit test for function parse
def test_parse():
    # Test for case 0
    str_0 = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    assert parse(str_0) == Docstring(
        summary=['Parse the docstring into its components.'],
        body=[],
        returns=['parsed docstring representation'],
        examples=None,
        params=[Param('text', 'docstring text to parse'), Param('style', 'docstring style')],
        meta=None,
    )

    # Test for case 1

# Generated at 2022-06-25 16:38:53.986876
# Unit test for function parse
def test_parse():
    str_0 = """\
    This is a test of a function's docstring parsing.
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ''
    assert docstring_0.long_description == ''
    assert docstring_0.meta == {}
    assert docstring_0.returns == None
    assert docstring_0.params == []
    assert docstring_0.raises == []

    str_1 = """\
    This is another test.

    This is the long description of the docstring.
    """
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'This is another test.'
    assert docstring_1.long_description == 'This is the long description of the docstring.'
    assert docstring_

# Generated at 2022-06-25 16:39:04.591119
# Unit test for function parse
def test_parse():
    str_0 = '''\
        A short description.

        A longer description.

        Args:
            arg_0 (int): Description of arg_0.
            arg_1 (str): Description of arg_1.

        Returns:
            bool: Description of return value.

        Raises:
            ValueError: If `arg_0` is equal to `arg_1`.
        '''
    docstring_0 = parse(str_0)
    print(docstring_0.short_description)
    print(docstring_0.long_description)
    print(docstring_0.args)
    print(docstring_0.returns)
    print(docstring_0.raises)

# Generated at 2022-06-25 16:39:07.191473
# Unit test for function parse
def test_parse():
    assert callable(parse), "Function <parse> undefined"


# Generated at 2022-06-25 16:39:09.309681
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = Style.numpy
    docstring_0 = parse(str_0, style_0)

# Generated at 2022-06-25 16:39:21.342491
# Unit test for function parse
def test_parse():
  text_0 = "Adds a value to the group.."
  style_0 = Style.auto
  assert parse(text_0, style_0) == Docstring("Adds a value to the group..\n", description="Adds a value to the group.", meta={})
  assert parse(text_0, style_0) == Docstring("Adds a value to the group..\n", description="Adds a value to the group.", meta={})
  text_1 = None
  style_1 = Style.auto
  with pytest.raises(Exception) as excinfo:
    assert parse(text_1, style_1) == None
  assert str(excinfo.value) == 'None is not a valid docstring.'
  text_2 = ""
  style_2 = Style.auto
  assert parse(text_2, style_2) == Docstring

# Generated at 2022-06-25 16:39:31.293939
# Unit test for function parse
def test_parse():
    str_0 = "Hello World!"
    docstring_0 = parse(str_0)
    assert docstring_0.__repr__() == "Docstring(meta={'title': 'Hello World!', 'parameters': None, 'returns': None, 'raises': None, 'examples': None, 'yields': None, 'see_also': None, 'references': None}, desc=None, summary=None)"
    assert (docstring_0 == docstring_0) == True
    assert docstring_0.__str__() == "Hello World!\n"

    str_1 = "Hello\nWorld!"
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:39:33.945981
# Unit test for function parse
def test_parse():
    str_0 = 'Please enter your pin'
    style_0 = Style.auto
    docstring_0 = parse(str_0, style_0)
    assert docstring_0.brief == 'Please enter your pin'


# Generated at 2022-06-25 16:39:36.899408
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:39:41.391119
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:39:43.956088
# Unit test for function parse
def test_parse():
    text_0 = ""
    style_0 = Style.numpy
    docstring_0 = parse(text_0, style_0)
    assert docstring_0 == None


# Generated at 2022-06-25 16:39:46.619958
# Unit test for function parse
def test_parse():
    text = '''This is a function.

    bla bla bla bla
    '''
    docstring = parse(text)
    assert docstring.summary == 'This is a function.'
    assert docstring.description == 'bla bla bla bla'


# Generated at 2022-06-25 16:39:50.821298
# Unit test for function parse
def test_parse():
    a = 'The main parsing routine.'
    b = 'Routine for Parse.'
    docstring_0 = parse(a)
    docstring_1 = parse(b)
    assert docstring_0.short_description == b



# Generated at 2022-06-25 16:39:58.605302
# Unit test for function parse
def test_parse():
    str_0 = '@param x: Description of x.'
    style_0 = Style.auto
    docstring_0 = parse(str_0, style_0)
    assert docstring_0.summary == ''
    assert docstring_0.description == ''
    assert docstring_0.extended_summary == ''
    assert docstring_0.meta[0].args == ['x']
    assert docstring_0.meta[0].description == 'Description of x.'
    assert docstring_0.meta[0].meta_type == 'param'
    assert docstring_0.meta[0].name == 'x'
    assert docstring_0.meta[0].type_name == ''
    str_1 = '@param  x   \t: Description of x.'
    style_1 = Style.google
    docstring_1

# Generated at 2022-06-25 16:40:01.379241
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    str_1 = """\
            foo
            """
    docstring_2 = parse(str_1)


# Generated at 2022-06-25 16:40:13.322818
# Unit test for function parse
def test_parse():
    docstring_0 = parse('')
    docstring_1 = parse('\n')
    docstring_2 = parse('\n\n\n')
    docstring_3 = parse('arbitrary docstring')
    docstring_4 = parse('\n\n\narbitrary docstring\n\n\n')
    docstring_5 = parse('arbitrary docstring\n')
    docstring_6 = parse('\n\n\narbitrary docstring')
    docstring_7 = parse('\n\n\narbitrary docstring\n\n\n')
    docstring_8 = parse('\n\n\narbitrary docstring\n\n\n', style=Style.google)

# Generated at 2022-06-25 16:40:14.705807
# Unit test for function parse
def test_parse():
    assert parse("docstring") == None



# Generated at 2022-06-25 16:40:23.294748
# Unit test for function parse
def test_parse():
    from copy import deepcopy
    # Setup test values

    long_description_1 = """
#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
    short_description_1 = "Hello World"
    summary_1 = "Hello World"
    tags_1 = ["@author:author@example.com", "@deprecated:deprecated"]
    params_1 = {"param_1": "x", "param_2": "y"}
    returns_1 = {"return_1": "z"}
    examples_1 = {"example_1": "ex_1", "example_2": "ex_2"}
    warnings_1 = ["Warning 1", "Warning 2"]

# Generated at 2022-06-25 16:40:24.083946
# Unit test for function parse
def test_parse():
    assert docstring_0 is None


# Generated at 2022-06-25 16:40:28.429306
# Unit test for function parse
def test_parse():
    assert 0


# Generated at 2022-06-25 16:40:33.581668
# Unit test for function parse
def test_parse():
    docstring_0 = parse("Test docstring style: numpy\n\n    :param \n    :return: \n\n")
    assert docstring_0.content[0].startswith("Test docstring style")
    assert not docstring_0.content[0].endswith("numpy\n\n    :param \n    :return: \n\n")
    assert docstring_0.meta[0].startswith("param")
    assert docstring_0.meta[0].endswith(": \n\n")
    assert not docstring_0.meta[0].endswith("  :param \n    :return: \n\n")
    assert docstring_0.meta[1].startswith("return")

# Generated at 2022-06-25 16:40:41.445065
# Unit test for function parse
def test_parse():
    str_0 = "Docstring for the hello module."
    docstring_0 = parse(str_0)

    str_1 = """
    Hello world!

    :param int param_0: The 0th parameter.
    :param array param_1: The 1th parameter.
    :param some_class param_2: The 2th parameter.
    :return: something.
    :rtype int:
    :raise type_0: if something is wrong.
    :raise type_1: if something is wrong.
    """
    docstring_1 = parse(str_1)

test_parse()

# Generated at 2022-06-25 16:40:52.523721
# Unit test for function parse
def test_parse():
    text_0 = '''\
    Keyword arguments:
    arg1 -- description
    '''
    style_0 = Style.numpy
    docstring_0 = parse(text_0, style_0)
    assert (str(docstring_0) == text_0)

    style_1 = Style.google
    docstring_1 = parse(text_0, style_1)
    assert (str(docstring_1) == text_0)

    style_2 = Style.sphinx
    docstring_2 = parse(text_0, style_2)
    assert (str(docstring_2) == text_0)

    text_1 = '''\
    Args:
        arg1 (str): description
    '''
    style_3 = Style.numpy

# Generated at 2022-06-25 16:40:55.546332
# Unit test for function parse
def test_parse():
    assert parse("")


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:40:58.925020
# Unit test for function parse
def test_parse():
    str_0 = None
    style_0 = Style.auto
    docstring_0 = parse(str_0, style_0)
    assert docstring_0 is None


# Generated at 2022-06-25 16:41:10.004700
# Unit test for function parse
def test_parse():
    text_0 = 'This is a docstring'
    style_0 = 'google'
    docstring_0 = parse(text_0, style_0)
    assert docstring_0._text == 'This is a docstring\n'

    text_1 = 'This is a docstring'
    style_1 = 'numpy'
    docstring_1 = parse(text_1, style_1)  # Expecting exception ParseError
    assert docstring_1._text == 'This is a docstring\n'

    text_2 = 'This is a docstring'
    style_2 = 'auto'
    docstring_2 = parse(text_2, style_2)
    assert docstring_2._text == 'This is a docstring\n'

if __name__ == '__main__':
    test_case

# Generated at 2022-06-25 16:41:11.177095
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None

# Generated at 2022-06-25 16:41:12.080097
# Unit test for function parse
def test_parse():
    assert True

# Test case 0

# Generated at 2022-06-25 16:41:15.158488
# Unit test for function parse
def test_parse():
    # no style specified, leaves it at .auto
    assert parse('blah')
    # specifying a style
    for style in [Style.auto, Style.numpy, Style.google]:
        assert parse('blah', style)
    assert not parse('blah', Style.auto)


# Generated at 2022-06-25 16:41:19.640801
# Unit test for function parse
def test_parse():
    assert parse(None) == None


# Generated at 2022-06-25 16:41:28.526535
# Unit test for function parse

# Generated at 2022-06-25 16:41:39.022506
# Unit test for function parse
def test_parse():

    # Empty String
    docstring = parse("")
    assert docstring.meta == ""

    # Simple String
    docstring = parse("This is a description.")
    assert docstring.content == "This is a description."
    assert docstring.short_description == "This is a description."
    assert docstring.description == ""
    assert docstring.meta == ""

    # Fields
    docstring = parse(
        """
        This is a description.

        :param int id: id of the object
        :param int flag: flag of the object
        """
    )
    assert docstring.content == """This is a description.

:param int id: id of the object
:param int flag: flag of the object"""
    assert docstring.short_description == "This is a description."
    assert docstring.description == ""

# Generated at 2022-06-25 16:41:48.507424
# Unit test for function parse
def test_parse():
    str_1 = "This is an example docstring."
    docstring_1 = parse(str_1)
    str_2 = """This is a docstring.
        That contains multilines.

        And I am going to parse it."""
    docstring_2 = parse(str_2)
    str_3 = """This is a docstring.
        That contains multilines.

        And I am going to parse it."""
    style_3 = Style.google
    docstring_3 = parse(str_3, style_3)
    assert docstring_1 is not None
    assert docstring_2 is not None
    assert docstring_3 is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:42:02.018916
# Unit test for function parse
def test_parse():
    str_0 = "The main parsing routine."
    style_0 = "auto"
    str_1 = "The main parsing routine."
    style_1 = "numpy"
    str_2 = "The main parsing routine."
    style_2 = "google"
    str_3 = "The main parsing routine."
    style_3 = "pep257"
    str_4 = "The main parsing routine."
    style_4 = "sphinx"
    # Call function parse with arguments str_0, style_1
    docstring_0 = parse(str_1, style_1)
    # Call function parse with arguments str_0, style_0
    docstring_1 = parse(str_0, style_0)
    # Call function parse with arguments str_2, style_1

# Generated at 2022-06-25 16:42:03.471008
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:42:15.581148
# Unit test for function parse
def test_parse():
    str_0 = "    Line above\n    \n        Line in\n        \n    Line below\n    "
    expected_result_0 = Docstring(short_description="Line above",
                                  long_description=["Line in"],
                                  meta={})

    actual_result_0 = parse(str_0)
    assert (actual_result_0.short_description == expected_result_0.short_description)
    assert (actual_result_0.long_description == expected_result_0.long_description)
    assert (actual_result_0.meta == expected_result_0.meta)
    str_1 = "    Line above\n    \none-liner\n    \n    Line below\n    "

# Generated at 2022-06-25 16:42:18.817052
# Unit test for function parse
def test_parse():
    assert 1


# Generated at 2022-06-25 16:42:27.659601
# Unit test for function parse
def test_parse():
    text = '''This is a function definition.
 
    Args:
        param1 (str): The first parameter.
        param2 (int, optional): The second parameter. Defaults to 42.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.
 
    Returns:
        bool: The return value. True for success, False otherwise.
 
    '''
    doc = parse(text)
    print(doc.short_description)  # This is a function definition.
    print(doc.long_description)  # None
    print(doc.meta)
    print(doc.meta['Returns'])
    print(doc.meta['Args'])
    print(doc.meta['Args'][1])
    print(doc.meta['Args'][1]['description'])

# Generated at 2022-06-25 16:42:35.278844
# Unit test for function parse
def test_parse():

    # get the docstring at file level
    docstring_1 = parse.__doc__
    print(docstring_1)

    # get the docstring at class level
    class A:
        "parsing the docstring"

    print(parse(A.__doc__))

    # get the docstring at method level
    class B:
        "parsing the docstring"
        def f(self):
            """This is a method docstring."""

    print(parse(B.f.__doc__))


# Entry point for the program
if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:42:39.819592
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:42:43.793853
# Unit test for function parse
def test_parse():
    func_0 = parse('')
    assert isinstance(func_0, Docstring)
    assert func_0.summary is None
    assert func_0.description is None
    assert func_0.meta == {}
    assert func_0.params == {}
    assert func_0.raises == {}
    assert func_0.returns is None


# Generated at 2022-06-25 16:42:55.766218
# Unit test for function parse
def test_parse():
    str_0 = "Return a tuple containing the string and its length."
    docstring_0 = parse(str_0,Style.numpy)
    assert docstring_0.sections == [ 'Return a tuple containing the string and its length.' ]
    assert docstring_0.meta == {}


# Generated at 2022-06-25 16:43:05.123666
# Unit test for function parse
def test_parse():
    str_1 = ':param a: top of the stack\n'
    str_2 = ':param b: next on the stack\n'
    str_3 = ':param c: bottom of the stack\n'
    str_4 = ':return: the result of the function \n'
    str_5 = ':raises ValueError: if d is zero\n'
    str_6 = 'This is a function that adds numbers together.\n'
    str_7 = '\n'
    str_8 = 'This is the second paragraph of the documentation.\n'
    str_9 = '\n'
    str_10 = 'This is the third paragraph of the documentation.'
    str_11 = '\n'
    str_12 = ':param a: top of the stack\n'

# Generated at 2022-06-25 16:43:07.439127
# Unit test for function parse
def test_parse():
    # print(parse(parse(str_0)))
    test_case_0()


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:43:14.839591
# Unit test for function parse
def test_parse():
    str_0 = "\n"\
            "    This function is used to convert all text to upper case.\n"\
            "        Parameters\n"\
            "        ----------\n"\
            "        x : str\n"\
            "            First parameter\n"\
            "        y : int\n"\
            "            Second parameter\n"\
            "        Returns\n"\
            "        -------\n"\
            "        str\n"\
            "            uppercased string\n"\
            "    "
    docstring_0 = parse(str_0)
    # assert docstring_0.returns.type_name.startswith("str") == True
    # assert docstring_0.summary.startswith("This function is used to convert") == True
    # assert

# Generated at 2022-06-25 16:43:17.775714
# Unit test for function parse
def test_parse():
    str_0 = None
    docstring_0 = parse(str_0)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:43:19.694264
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:43:30.799785
# Unit test for function parse
def test_parse():
    assert parse('sphinx') == Docstring(
        summary='sphinx',
        description=None,
        params=None,
        returns=None,
        raises=None,
        meta=None,
        style=Style.numpy,
    )
    assert parse('numpy') == Docstring(
        summary='numpy',
        description=None,
        params=None,
        returns=None,
        raises=None,
        meta=None,
        style=Style.numpy,
    )
    assert parse('google') == Docstring(
        summary='google',
        description=None,
        params=None,
        returns=None,
        raises=None,
        meta=None,
        style=Style.google,
    )