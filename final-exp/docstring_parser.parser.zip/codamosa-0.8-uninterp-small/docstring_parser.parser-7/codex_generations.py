

# Generated at 2022-06-25 16:33:33.599217
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:33:36.744390
# Unit test for function parse
def test_parse():
    assert(callable(parse))

if __name__ == "__main__":
    docstring_0 = parse(str_0)
    print('all_good')

# Generated at 2022-06-25 16:33:48.073008
# Unit test for function parse
def test_parse():
    str_0 = "ZqnQr@"
    style_1 = Style.auto
    docstring_0 = parse(str_0, style_1)
    str_1 = "\\(\\\"!,&z5@5%c"
    style_2 = Style.numpy
    docstring_1 = parse(str_1, style_2)
    str_2 = "> ),T@i"
    style_3 = Style.google
    docstring_2 = parse(str_2, style_3)
    str_3 = "!vbl=^"
    style_4 = Style.sphinx
    docstring_3 = parse(str_3, style_4)
    str_4 = "Sf$}5IL"
    style_5 = Style.epytext
    docstring_4 = parse

# Generated at 2022-06-25 16:33:52.726788
# Unit test for function parse
def test_parse():

    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:33:59.752923
# Unit test for function parse
def test_parse():
    string = "Python is a very useful language"
    assert parse(string) == string

# Test the execution time
import timeit

print(timeit.timeit("test_case_0()", setup="from __main__ import test_case_0", number=6))

# Generated at 2022-06-25 16:34:00.530545
# Unit test for function parse
def test_parse():
    pass



# Generated at 2022-06-25 16:34:05.410164
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:34:15.984927
# Unit test for function parse
def test_parse():
    print('Test function parse')

    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.full == str_0

    str_1 = '''\
    Test function parse
    
    Parameters
    ----------
    str_0 : input string
    docstring_0 : output parsed docstring
    
    Returns
    -------
    docstring_0 : output parsed doxcstring
    
    Raises
    ------
    ParseError : Failed to parse input docstring
    '''


# Generated at 2022-06-25 16:34:19.517206
# Unit test for function parse
def test_parse():
    assert parse(None) is not None

# Size of the test case

# Generated at 2022-06-25 16:34:25.296610
# Unit test for function parse
def test_parse():
    str_0 = "Convolutional Neural Nets for NLP"
    docstring_0 = parse(str_0)
    if docstring_0.short_description == "Convolutional Neural Nets for NLP":
        assert (True)
        print('test_parse ok')
    else:
        assert (False)


# Generated at 2022-06-25 16:34:40.714221
# Unit test for function parse
def test_parse():
    # Test Basic
    str_0 = r"""
        This is a docstring.
        It has multiple lines.
    """
    str_1 = r"""This is a docstring.
        It has multiple lines."""
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    assert(docstring_0.description == str_0)
    assert(docstring_1.description == str_1)
    # Test Args
    str_2 = r"""
        This is a docstring.
        It has multiple lines.

        :param arg_0: Arg 0
        :type arg_0: str

        :param arg_1: Arg 1
        :type arg_1: int

        :param arg_2: Arg 2
        :type arg_2: long
    """
   

# Generated at 2022-06-25 16:34:50.517731
# Unit test for function parse
def test_parse():
    str_0 = "y#\\ztV.~tYK\\R:iT\\K,~7V0kIp'N0VuLMNy2D]Vz$0w0K/a@=:ZQXo5_]W<1C,{(6-k>6U"
    str_1 = "nP#U.XD<v[iKj]kR,1xkp1H]_j(i|Q'^)`%('`/5f2S0N8!<):0G{c[Uv/6W4;8h:$>=HZ6mvTHC<MZZ8Dm-kuzi]xz)B58FWb>;:@Qf.0e3-k9)&FX|G"

# Generated at 2022-06-25 16:35:01.392333
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM\nBybYt@,F.0z^a97vg\t1Z8@RwgDx*BjH=\n!d9qP_L-j2We(1=f:B"
    str_1 = "OLW'E+ud!!\\ESQQm6ZvM"
    str_2 = "BybYt@,F.0z^a97vg\t1Z8@RwgDx*BjH=\n!d9qP_L-j2We(1=f:B"
    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    docstring_2 = parse(str_2)
    assert docstring

# Generated at 2022-06-25 16:35:08.639611
# Unit test for function parse
def test_parse():
    import random
    # Create an array of random UTF-8 strings.
    strs = [random.choice(['一', '三', '完', '是', '无']) for _ in range(1000)]

    # Create a map of all child nodes of Style.
    style_map = {child.name: child for child in Style}

    # For each string, apply all parsing styles.
    for str in strs:
        for style in style_map.values():
            parse(str, style=style)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:35:15.308909
# Unit test for function parse
def test_parse():
    import docstring_parser
    ds = """
        Test function

        :param param_1: Parameter 1
        :type param_2: Parameter 2
        :returns: Description of return value
        """
    obj = docstring_parser.parse(ds)
    # Test parameter
    print(obj.returns)
    # Test return value
    print(obj.params_dict)
    assert obj.params_dict['param_2'] == 'Parameter 2'
    assert obj.returns == 'Description of return value'

if __name__ == "__main__":
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:35:17.712386
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Generated at 2022-06-25 16:35:28.704623
# Unit test for function parse
def test_parse():
    str_0 = """\
        go here:
        http://example.com to see the example
        """
    str_1 = """\
        go here:
        http://example.com to see the example
        """
    str_2 = """\
        go here:
        http://example.com to see the example
        """
    str_3 = """\
        go here:
        http://example.com to see the example
        """
    str_4 = """\
        go here:
        http://example.com to see the example
        """
    docstring_0 = parse(str_0, Style.default)
    docstring_1 = parse(str_1, Style.default)
    docstring_2 = parse(str_2, Style.default)

# Generated at 2022-06-25 16:35:39.709071
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    str_1 = "U5q5@/p%c.`Cd`/KjN\'"
    str_2 = "V52bK~=wDV{!W8!K4V7"
    str_3 = "nWm", "SzKd68#!/:K/[wF"
    str_4 = "OLW'E+ud!!\\ESQQm6ZvM"
    str_5 = "#yK<nH,,\"Y*d6!XgKDq"
    str_6 = "U5q5@/p%c.`Cd`/KjN\'"

# Generated at 2022-06-25 16:35:44.904406
# Unit test for function parse
def test_parse():
    text = """
    SHORT DESCRIPTION

    LONG DESCRIPTION

    PARAMETERS:
      *arg -- list of objects
      **kwargs -- optional arguments


    RETURNS: a list of objects
    """
    docstring = parse(text)
    assert docstring.short_description == 'SHORT DESCRIPTION'
    assert docstring.long_description == 'LONG DESCRIPTION'
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1


# Generated at 2022-06-25 16:35:50.570014
# Unit test for function parse
def test_parse():
    # Tests that it raises the right exception.
    str_0 = "fM'WW[IYa`UT<C9XD)S?"

    try:
        docstring_0 = parse(str_0)
        assert False
    except ParseError:
        assert True
    else:
        assert True


if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:36:05.309683
# Unit test for function parse
def test_parse():
    assert callable(parse)
    # No style specified
    #
    str_0 = "__author__ = 'edanishevsky'"
    docstring_0 = parse(str_0)
    str_1 = "__copyright__ = 'Copyright 2019'"
    docstring_1 = parse(str_1)
    str_2 = "__license__ = 'MIT'"
    docstring_2 = parse(str_2)
    # str_1 = "__version__ = '1.1'"
    # docstring_1 = parse(str_1)
    # str_2 = "__status__ = 'Production'"
    # docstring_2 = parse(str_2)

    str_3 = "__all__ = ["
    docstring_3 = parse(str_3)


# Generated at 2022-06-25 16:36:16.110041
# Unit test for function parse
def test_parse():
    # Check for style: Google
    for i in range(0,10):
        str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
        docstring_0 = parse(str_0, Style.google)
        str_1 = "OLW'E+ud!!\\ESQQm6ZvM"
        docstring_1 = docstring_0.short_description.rstrip('\r\n')
        assert str_1 == str_0
    # Check for style: NumPy
    for i in range(0,10):
        str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
        docstring_0 = parse(str_0, Style.numpy)

# Generated at 2022-06-25 16:36:17.011261
# Unit test for function parse
def test_parse():
    pass

# examples

# Generated at 2022-06-25 16:36:21.136085
# Unit test for function parse
def test_parse():
    print(parse("OLW'E+ud!!\\ESQQm6ZvM\nTest"))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:36:23.882901
# Unit test for function parse
def test_parse():
    str_0 = "jX}lN)-=dzj%iA\\W/h'!q;njf"
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:36:25.473945
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)

# Benchmark for function parse

# Generated at 2022-06-25 16:36:35.100755
# Unit test for function parse
def test_parse():
    str_0 = 'Test for parse function'
    test_case_0()
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Test for parse function'
    assert docstring_0.long_description == ''
    assert docstring_0.meta == {}
    assert docstring_0.returns == None
    assert docstring_0.examples == []
    str_1 = 'Test for parse function: test case one'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Test for parse function'
    assert docstring_1.long_description == 'test case one'
    assert docstring_1.meta == {}
    assert docstring_1.returns == None
    assert docstring_1.examples == []
   

# Generated at 2022-06-25 16:36:37.930146
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:36:47.552187
# Unit test for function parse
def test_parse():
    str1 = """\
OLW'E+ud!!\\ESQQm6ZvM"""

    str2 = """\
OLW'E+ud!!\\ESQQm6ZvM"""


# Generated at 2022-06-25 16:36:48.941592
# Unit test for function parse
def test_parse():
    assert func() == 0


# Generated at 2022-06-25 16:36:55.105121
# Unit test for function parse
def test_parse():
    assert(parse("This is cool") == "This is cool")
    assert(parse("This is cool") != "This is not so cool")


# Generated at 2022-06-25 16:36:57.887275
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)

if __name__ == '__main__':

    # Start validation
    test_parse()

# Generated at 2022-06-25 16:37:04.196685
# Unit test for function parse
def test_parse():
    str_0 = "Setup function: function will be executed before each test.\n"
    #case_0 = parse(str_0, Style.google)
    #print(case_0)
    case_1 = parse(str_0, Style.auto)
    print(case_1)
    #print(case_0 == case_1)

# test if the main function can call the parse function

# Generated at 2022-06-25 16:37:05.049329
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:37:15.032280
# Unit test for function parse
def test_parse():

    # Test that function parse returns the correct value.

    str_0 = "Hello, world!"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Hello, world!"
    assert docstring_0.long_description == ""
    assert docstring_0.first_line_ending == " "
    assert docstring_0.meta == []

    str_1 = "Hello, world!\nHello, universe!"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Hello, world!"
    assert docstring_1.long_description == "\nHello, universe!"
    assert docstring_1.first_line_ending == "\n"
    assert docstring_1.meta == []


# Generated at 2022-06-25 16:37:22.417149
# Unit test for function parse
def test_parse():
    # find all test docstrings
    for name in dir():
        if name.startswith("test_case_"):
            eval(name)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:37:25.389704
# Unit test for function parse
def test_parse():
    test_case_0()

# Function to parse docstring and check it's style
# Function: parse

# Generated at 2022-06-25 16:37:28.449845
# Unit test for function parse
def test_parse():
    func=(lambda str_0: parse(str_0))
    str_0="OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0=func(str_0)

# Generated at 2022-06-25 16:37:29.477945
# Unit test for function parse
def test_parse():
    assert parse('') != None


# Generated at 2022-06-25 16:37:30.280915
# Unit test for function parse
def test_parse():
    assert(callable(parse))

# Generated at 2022-06-25 16:37:43.369302
# Unit test for function parse
def test_parse():
    try:
        func = parse
        args = ("b\\X'7i", Style.google)
        rv = func(*args)
        str_value = "ab\\X'7i"
        assert (rv == str_value)
        print('\033[32m' + '✔ test_parse() passed successfully' + '\033[0m')
    except AssertionError as e:
        print('\033[31m' + '✘ test_parse() failed' + '\033[0m')

# Generated at 2022-06-25 16:37:49.767991
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == '__main__':
    import sys
    import timeit

    repeat = 1
    number = 1

    if (len(sys.argv) == 3):
        repeat = int(sys.argv[2])
        number = int(sys.argv[1])

    print(timeit.timeit("test_parse()",
                        setup="from __main__ import test_parse",
                        number=number,
                        repeat=repeat))

# Generated at 2022-06-25 16:37:58.194594
# Unit test for function parse
def test_parse():
    str_0 = "Zamowienie zostalo zrealizowane"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Zamowienie zostalo zrealizowane\n"
    assert docstring_0.long_description == ""

    str_1 = "Komunikat. Zamowienie nie zostalo zrealizowane."
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Komunikat. Zamowienie nie zostalo zrealizowane."
    assert docstring_1.long_description == ""

    str_2 = "Komunikat. Zamowienie nie zostalo zrealizowane."
    docstring_2 = parse

# Generated at 2022-06-25 16:38:07.914813
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)
    print(docstring_0)
    assert docstring_0 == "OLW'E+ud!!\\ESQQm6ZvM"
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)
    print(docstring_0)
    assert docstring_0 == "OLW'E+ud!!\\ESQQm6ZvM"
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)
    print(docstring_0)

# Generated at 2022-06-25 16:38:10.725320
# Unit test for function parse
def test_parse():
    string = """A reference counter.

:param int max_refs:
    Maximum number of references to allow.
:param str name:
    A name for this counter, for debugging purposes.
"""
    # Parse docstring
    docstring = parse(string, style=Style.google)

    assert docstring.short_description == "A reference counter."
    assert docstring.long_description == ''
    assert docstring.returns == None
    assert docstring.meta == ['max_refs', 'name']



# Generated at 2022-06-25 16:38:19.167307
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'OLW'
    assert len(docstring_0.long_description) == 1
    assert docstring_0.long_description[0] == "E+ud!!"
    assert docstring_0.meta['ESQQm6ZvM'] == None
    str_1 = "26_*3b}`'Hw<`ON,#]8e_"
    docstring_1 = parse(str_1)
    str_2 = "7wH/|5R`-k~1#`d)#r"
    docstring_2 = parse(str_2)
    str_3 = ""
    docstring

# Generated at 2022-06-25 16:38:20.017859
# Unit test for function parse
def test_parse():
    text = ''
    style = Style.numpy
    assert callable(parse)

# Generated at 2022-06-25 16:38:29.486179
# Unit test for function parse
def test_parse():
    text_0 = "    hello this is a docstring."
    style_0 = Style.google
    docstring_0 = parse(text_0, style_0)
    assert docstring_0.short_description == 'hello this is a docstring.'
    assert docstring_0.long_description == 'hello this is a docstring.'
    assert docstring_0.tags == ()
    assert docstring_0.meta == {}
    text_1 = "Hello world.\n\nHi."
    style_1 = Style.auto
    docstring_1 = parse(text_1, style_1)
    assert docstring_1.short_description == 'Hello world.'
    assert docstring_1.long_description == 'Hello world.\n\nHi.'
    assert docstring_1.tags == ()
    assert docstring_

# Generated at 2022-06-25 16:38:41.450667
# Unit test for function parse
def test_parse():
    from random import randint
    randint = randint
    text = '''
    Returns a tuple containing the request's parameters.
    
    :param string request: an HTTP request
    :return: a tuple containing all parameters in the request
    '''
    style = Style.numpy
    docstring_1 = parse(text, style)
    assert docstring_1.return_desc == "a tuple containing all parameters in the request"
    assert docstring_1.meta[0].type_ == "string"
    assert docstring_1.meta[0].name == "request"
    assert docstring_1.meta[0].desc == "an HTTP request"
    assert docstring_1.summary == "Returns a tuple containing the request's parameters."
    print("Test Case 0 of parse Passed!")
    

# Generated at 2022-06-25 16:38:43.382258
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:38:52.443351
# Unit test for function parse
def test_parse():
    str = "\n"
    docstring = parse(str)
    assert docstring._docstring_parts['summary'] == ''
    assert docstring._docstring_parts['extended_summary'] == ''
    assert docstring._docstring_parts['extended_summary_indent'] == 0
    assert docstring._docstring_parts['meta'] == {}


# Generated at 2022-06-25 16:38:54.104681
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-25 16:38:57.248625
# Unit test for function parse
def test_parse():
    # Please note that the following test is not complete
    # (i.e. you may need to add more tests)
    test_case_0()

test_parse()

# Generated at 2022-06-25 16:38:59.650481
# Unit test for function parse
def test_parse():
    assert parse('abc') is not None
    assert parse('abc',123) is not None


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:39:04.045791
# Unit test for function parse
def test_parse():
    testing_0 = open('testing.txt','r')
    docstring_0 = parse(testing_0)
    assert docstring_0.summary == 'Performs a deep learning model of the given dataset.'

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 16:39:13.570803
# Unit test for function parse
def test_parse():
    assert parse("This is the first line. This is the second line. This is the third line.") == Docstring(content=['This is the first line.', 'This is the second line.', 'This is the third line.'], meta={}, sections=())
    assert parse("This is the first line.\n\nThis is the second line.\n\nThis is the third line.") == Docstring(content=['This is the first line.', 'This is the second line.', 'This is the third line.'], meta={}, sections=())
    assert parse("This is the first line.\n This is the second line.\n This is the third line.") == Docstring(content=['This is the first line.', ' This is the second line.', ' This is the third line.'], meta={}, sections=())

# Generated at 2022-06-25 16:39:17.304398
# Unit test for function parse
def test_parse():

    # Case 0

    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)

    assert docstring_0 == "OLW'E+ud!!\\ESQQm6ZvM"

# Generated at 2022-06-25 16:39:27.376347
# Unit test for function parse
def test_parse():
    with open("test_files/test3.txt", "r") as f:
        data10 = f.read()
    docstring_0 = parse(data10)
    assert docstring_0.short_description == "This is a test file"
    assert docstring_0.long_description == "This is a test file This is a test file This is a test file"

# Generated at 2022-06-25 16:39:30.112568
# Unit test for function parse
def test_parse():
    assert parse("line1\nline2\nline3") == Docstring(
        description=["line1", "line2", "line3"],
        params={},
        returns="",
    )



# Generated at 2022-06-25 16:39:31.862896
# Unit test for function parse
def test_parse():
    text = "OLW'E+ud!!\\ESQQm6ZvM"

    assert(parse(text) is not None)

# Generated at 2022-06-25 16:39:42.792808
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)
    # AssertionError: b'%' followed by a non-special character
    # at pos 0 in OLW'E+ud!!\ESQQm6ZvM

if __name__ == '__main__':
    test_case_0()
    test_parse()

# Generated at 2022-06-25 16:39:44.895731
# Unit test for function parse
def test_parse():
    assert callable(parse)

# Test cases to cover all branches

# Generated at 2022-06-25 16:39:45.744187
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:39:55.230060
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)
    str_1 = "bX#\x92\xaf\x1b\x83\xc9\x11\x89:\xed\x1a\x80?\x8d\xec\xc3-\xd2\x14\xae\x06\xe9!\x9f\x0c\x01\xb1\xac\xc1\xab@\xfb\xca\x9b"
    docstring_1 = parse(str_1)
    assert docstring_1.args[0] == 'a'


# Generated at 2022-06-25 16:39:58.182604
# Unit test for function parse
def test_parse():
    try:
        test_case_0()
    except AssertionError as ae:
        print("Test 0 failed")
        print(ae)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:40:07.003384
# Unit test for function parse
def test_parse():
    style_0 = Style.numpy
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0, style_0)
    if len(docstring_0.summary) != 19:
        print("The summary of docstring_0 contains a wrong value")
        exit(1)
    expected_short_summary_0 = "OLW'E+ud!!"
    actual_short_summary_0 = docstring_0.short_summary.strip()
    if actual_short_summary_0 != expected_short_summary_0:
        print("short_summary of docstring_0 contains a wrong value")
        exit(1)
    expected_params_0 = []
    actual_params_0 = docstring_0.params

# Generated at 2022-06-25 16:40:08.096817
# Unit test for function parse
def test_parse():
    assert callable(parse)


# Generated at 2022-06-25 16:40:19.185368
# Unit test for function parse
def test_parse():
    """Test the function parse(text) with a given input
    """

    text = "This is the first line of the docstring." + \
                  "This is the second line of the docstring."
    docstring = parse(text)
    assert docstring.short_description == \
                                 'This is the first line of the docstring.'
    assert docstring.long_description == \
                              'This is the second line of the docstring.'
    assert docstring.tags == []
    text = "This is the first line of the docstring.\n" + \
                  "This is the second line of the docstring."
    docstring = parse(text)
    assert docstring.short_description == \
                                 'This is the first line of the docstring.'

# Generated at 2022-06-25 16:40:24.150898
# Unit test for function parse
def test_parse():
    # An empty docstring.
    d = parse('')
    assert d.content == []
    assert d.short_description == ''
    assert d.long_description == ''
    assert d.sections == []
    assert d.meta == {}



# Generated at 2022-06-25 16:40:31.119116
# Unit test for function parse
def test_parse():
    text = \
        """
        Hello, world

        :param name: The name to say hello to
        :type name: str
        :param loud: Whether to shout or not
        :type loud: bool
        :returns: Greeting as a string
        :rtype: str
        :raises ValueError: If `name` is empty
        """
    actual = parse(text)
    assert actual.short_description == "Hello, world"
    assert len(actual.long_description) == 0
    assert len(actual.meta) == 4
    meta_0 = actual.meta[0]
    assert meta_0.arg_name == "name"
    assert meta_0.arg_type == "str"
    assert meta_0.arg_desc == "The name to say hello to"
    meta_1 = actual.meta

# Generated at 2022-06-25 16:40:50.101281
# Unit test for function parse
def test_parse():
    # Test from an example
    str_0 = ""
    assert parse(str_0) == Docstring("")
    str_1 = "PyShEx.Validator\n================\n\n.. autoclass:: PyShEx.Validator\n    :members:\n\n    .. automethod:: __call__\n\n    .. automethod:: compact\n\n    .. automethod:: validate\n\n    .. automethod:: validate_stream\n"
    assert parse(str_1) == Docstring("PyShEx.Validator")
    str_2 = "1 2 3 4 5\n6 7 8 9 10\n11 12 13 14 15\n16 17 18 19 20\n21 22 23 24 25\n"
    assert parse(str_2) == Docstring("1 2 3 4 5")
    str

# Generated at 2022-06-25 16:40:56.493535
# Unit test for function parse
def test_parse():
    str_1 = "qVz@)pKZuV7Oc,6^&bXU"
    docstring_1 = parse(str_1)
    assert(str_1 == docstring_1.raw)
    str_2 = "5S_fS8p(W/Kvf^G59Jn)"
    docstring_2 = parse(str_2)
    assert(str_2 == docstring_2.raw)
    str_3 = "mS;Wh]5o]n$Z*1q3Wn;"
    docstring_3 = parse(str_3)
    assert(str_3 == docstring_3.raw)
    str_4 = "D$T=2&!L7]0i$8\\s(s,"

# Generated at 2022-06-25 16:40:59.298671
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:41:01.137898
# Unit test for function parse
def test_parse():
    docstring_0 = parse("Qo!x$O^Xyv%4SnLA4d`~^T")


# Generated at 2022-06-25 16:41:06.320800
# Unit test for function parse
def test_parse():
    # test case 0
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)

    assert docstring_0 == ""


# Unit tests for class Docstring

# Generated at 2022-06-25 16:41:15.136674
# Unit test for function parse
def test_parse():
    stdin_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    stdin_1 = "OLW'E+ud!!\\ESQQm6ZvM"
    stdin_2 = "OLW'E+ud!!\\ESQQm6ZvM"
    stdin_3 = "OLW'E+ud!!\\ESQQm6ZvM"
    stdin_4 = "OLW'E+ud!!\\ESQQm6ZvM"
    stdin_5 = "OLW'E+ud!!\\ESQQm6ZvM"
    assert parse(stdin_0) == "OLW'E+ud!!\\ESQQm6ZvM"

# Generated at 2022-06-25 16:41:26.243824
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)
    # Now we check the docs and parameters
    # for the docstring
    assert docstring_0.short_description == "OLW'E+ud!!\\ESQQm6ZvM"
    assert docstring_0.long_description == ''
    assert len(docstring_0.params) == 0
    assert docstring_0.params == {}
    assert len(docstring_0.returns) == 0
    assert len(docstring_0.raises) == 0
    assert docstring_0.meta == {}
    # Now we check the docs, parameters and returns
    # for the docstring

# Generated at 2022-06-25 16:41:32.664429
# Unit test for function parse
def test_parse():
    test_case_0()

# End unit test
    print("Passed all tests!!!")
    
test_parse()

# Generated at 2022-06-25 16:41:39.429973
# Unit test for function parse
def test_parse():
    case_1 = [
        "OLW'E+ud!!\\ESQQm6ZvM",
        Style.numpy,
        'OLW\'E+ud!!\\ESQQm6ZvM'
    ]
    assert parse(*case_1[:-1]) == case_1[-1]

    case_2 = [
        'I#S(^T6TJ8&[+_$EujQ!',
        Style.sphinx,
        'I#S(^T6TJ8&[+_$EujQ!'
    ]
    assert parse(*case_2[:-1]) == case_2[-1]

# main function test

# Generated at 2022-06-25 16:41:49.439161
# Unit test for function parse
def test_parse():
    # Example 0 (case 0)
    str_0 = "UL\\D&=,;HI#J.uV7s9x!\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.params == []
    assert docstring_0.returns == None
    assert docstring_0.raises == []
    assert docstring_0.meta == {}
    assert docstring_0.style == Style.rst
    assert docstring_0.examples == []
    assert docstring_0.notes == []
    # Example 1 (case 0)
    str_1 = "P*p.^[o/;'pK\n"

# Generated at 2022-06-25 16:42:03.231628
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)
    assert docstring_0.summary == "OLW'E+ud!!\\ESQQm6ZvM"

    str_1 = "a short summary\n\nAlso a description."
    docstring_1 = parse(str_1)
    assert docstring_1.summary == "a short summary"
    assert docstring_1.description == "Also a description."

    str_2 = "<param.h> - TrueSTUDIO C/C++ parameter definitions file"
    docstring_2 = parse(str_2)
    assert docstring_2.summary == "param.h - TrueSTUDIO C/C++ parameter definitions file"


# Generated at 2022-06-25 16:42:04.815168
# Unit test for function parse
def test_parse():
    test_case_0()


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-25 16:42:10.634295
# Unit test for function parse
def test_parse():
    """
    Unit tests for function parse
    """
    input_value = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(input_value)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-25 16:42:15.643365
# Unit test for function parse
def test_parse():
    text_0 = "some description"
    style_0 = Style.google
    result_0 = parse(text_0, style_0)
    print(result_0)
    # assert result_0.description == "some description"
    text_1 = "some description"
    style_1 = Style.numpy
    result_1 = parse(text_1, style_1)
    print(result_1)
    # assert result_1.description == "some description"
    text_2 = "some description"
    style_2 = Style.numpy
    result_2 = parse(text_2, style_2)
    print(result_2)
    # assert result_2.description == "some description"

# Unit tests for function parse

# Generated at 2022-06-25 16:42:18.815220
# Unit test for function parse
def test_parse():
    assert callable(parse)



# Generated at 2022-06-25 16:42:27.659677
# Unit test for function parse
def test_parse():
    str1 = "###"
    str2 = "### Summary\n\n" + \
            "The following function does some math.\n\n" + \
            "### Description\n\n" + \
            "The following function does addition, subtraction, and multiplication.\n\n" + \
            "### Args\n\n" + \
            "a {int|float} -- the first operand\n" + \
            "b {int|float} -- the second operand\n\n" + \
            "### Returns\n\n" + \
            "sum {int|float} -- sum of a and b\n" + \
            "diff {int|float} -- difference between a and b\n" + \
            "mul {int|float} -- product of a and b\n\n"

# Generated at 2022-06-25 16:42:28.674189
# Unit test for function parse
def test_parse():
    pass


# Generated at 2022-06-25 16:42:32.375426
# Unit test for function parse
def test_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()

test_parse()

# Generated at 2022-06-25 16:42:41.249275
# Unit test for function parse
def test_parse():
    # AssertionError: Metadata must be list-like for 'numpy' style
    # str_0 = "\\X=;RgNHB>\\P*A?\\H"
    str_0 = "'*fKy$/'1!Xg$"
    # AssertionError: Metadata must be list-like for 'numpy' style
    # str_1 = "B+uV:nFnZ"
    str_1 = "xroSO7AJ"
    # AssertionError: Metadata must be list-like for 'numpy' style
    # str_2 = "wf^v[+W7c8)9q/]c=QM}Ot^/fkN.gl&SWR\\{\\H#|>,'C[;D}9Kj&IY@\"

# Generated at 2022-06-25 16:42:48.174069
# Unit test for function parse
def test_parse():
    try:
        assert isinstance(parse('"""'), Docstring)
    except ParseError:
        pass

    try:
        assert isinstance(parse('"""\n"""\n"""\n'), Docstring)
    except ParseError:
        pass

    try:
        assert isinstance(parse('    """\n    """\n    """\n'), Docstring)
    except ParseError:
        pass

    try:
        assert isinstance(parse('"""\n::\n\n    """\n\n'), Docstring)
    except ParseError:
        pass

    try:
        assert isinstance(parse('"""\n\n    This is a\n    multiline description.\n\n"""\n'), Docstring)
    except ParseError:
        pass


# Generated at 2022-06-25 16:43:00.322204
# Unit test for function parse
def test_parse():
    str_0 = "OLW'E+ud!!\\ESQQm6ZvM"
    docstring_0 = parse(str_0)
    assert docstring_0.meta == {}
    assert docstring_0.summary == ''
    assert docstring_0.body == ''
    assert docstring_0.decorators == ['']
    assert docstring_0.returns == []
    assert docstring_0.yields == []
    assert docstring_0.raises == []
    str_1 = "dT?T_T6yh(g#C%@+j"
    docstring_1 = parse(str_1)
    assert docstring_1.meta == {}
    assert docstring_1.summary == ''
    assert docstring_1.body == ''
    assert docstring_1

# Generated at 2022-06-25 16:43:07.804597
# Unit test for function parse
def test_parse():
    func = Docstring(
        short_description="Parses a raw docstring into its components.",
        long_description=(
            ":param text: docstring text to parse\n"
            ":param style: docstring style\n"
            ":returns: parsed docstring representation"
        ),
        returns="Docstring",
        params=[
            (
                "text",
                "docstring text to parse",
                None,
                None,
            ),
            (
                "style",
                "docstring style",
                Style.auto,
                None,
            ),
        ],
        style=Style.numpy,
        meta={},
        indent='    ',
    )
    assert parse(func.dumps()) == func

# Generated at 2022-06-25 16:43:10.462082
# Unit test for function parse
def test_parse():
    str_0 = u"Dummy docstring."
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == u"Dummy docstring."



# Generated at 2022-06-25 16:43:22.488674
# Unit test for function parse
def test_parse():
    # Assert docstring parsed correctly for all styles
    string = 'Return the hypotenuse of a right-angled triangle.'
    for style in STYLES.values():
        docstring = parse(string, style=style)
        assert docstring.short_description == string

    # Assert docstring parsed correctly ignoring first blank line
    string = '\nReturn the hypotenuse of a right-angled triangle.'
    for style in STYLES.values():
        docstring = parse(string, style=style)
        assert docstring.short_description == string[1:]

    # Assert docstring parsed correctly with multiple blank lines
    string = '\n\n\nReturn the hypotenuse of a right-angled triangle.'
    for style in STYLES.values():
        docstring = parse(string, style=style)

# Generated at 2022-06-25 16:43:33.132221
# Unit test for function parse
def test_parse():
    str_0 = "KZn_$Z-L`f^'hW8z^&>K"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "KZn_$Z-L`f^'hW8z^&>K"
    assert docstring_0.long_description == "KZn_$Z-L`f^'hW8z^&>K"
    assert docstring_0.params == {}
    assert docstring_0.returns == None
    assert docstring_0.raises == {}
    assert docstring_0.yields == None

    str_1 = "P>jRSG9}`D^7YJ(]_'V7"
    docstring_1 = parse(str_1)