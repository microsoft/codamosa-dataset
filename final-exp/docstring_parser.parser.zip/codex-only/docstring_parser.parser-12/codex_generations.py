

# Generated at 2022-06-23 17:16:33.438423
# Unit test for function parse
def test_parse():
    s = '''
    A summary.

    :param foo: Paragraph 1.

        Paragraph 2.
    :param bar: Something else.
    '''
    assert parse(s, style=Style.numpy) == parse(s, style=Style.auto)

    s = '''
    A summary.

    :param foo: Paragraph 1.

        Paragraph 2.
    :param bar: Something else.
    '''

# Generated at 2022-06-23 17:16:40.413937
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring
    from docstring_parser.styles import NumpydocDocstring
    from docstring_parser.styles import GoogleDocstring
    from docstring_parser.styles import GoogleDocstring
    from docstring_parser.styles import GoogleDocstring
    from docstring_parser.styles import GoogleDocstring
    from docstring_parser.styles import GoogleDocstring
    #from docstring_parser.styles import GoogleDocstring
    #from docstring_parser.styles import GoogleDocstring
    #from docstring_parser.styles import GoogleDocstring
    #from docstring_parser.styles import GoogleDocstring
    #from docstring_parser.styles import GoogleDocstring
    #from docstring_parser.styles import GoogleDocstring
    #from docstring_parser.styles import GoogleDocstring
    #from docstring_parser

# Generated at 2022-06-23 17:16:47.246469
# Unit test for function parse
def test_parse():
    docstring = '''Parses the docstring into its components.

    Returns:
        Parsed docstring representation
    '''
    docstring_parser.common.Docstring = namedtuple('Docstring', 'short, long, meta')
    docstring_parser.styles.STYLES = {None: lambda text: docstring_parser.common.Docstring('Parses the docstring into its components.', 'Returns:\n  Parsed docstring representation\n', [])}
    assert parse(docstring) == docstring_parser.common.Docstring('Parses the docstring into its components.', 'Returns:\n  Parsed docstring representation\n', [])


# Generated at 2022-06-23 17:16:55.835725
# Unit test for function parse
def test_parse():
    text = '''\
    Update a document in the collection.

    :param document: document to be added
    :param key: key to identify the document
    '''
    docstring = parse(text)
    assert docstring.short_description == "Update a document in the collection."
    assert docstring.long_description == ""
    assert docstring.params[0].arg_name == "document"
    assert docstring.params[0].description == "document to be added"
    assert docstring.params[1].arg_name == "key"
    assert docstring.params[1].description == "key to identify the document"

# Generated at 2022-06-23 17:17:02.976714
# Unit test for function parse
def test_parse():
    text = '''\
summary
    extended_summary

Args:
    arg1 (int): Description of arg1
    arg2 (str): Description of arg2

Returns:
    bool: Description of return value
'''
    docstring = parse(text)

    print(docstring.summary)
    print(docstring.extended_summary)
    for arg in docstring.arguments:
        print(arg.name)
        print(arg.type_name)
        print(arg.description)
    print(docstring.returns.type_name)
    print(docstring.returns.description)

if __name__ == '__main__':
    test_parse()
 

#
#
#

# Generated at 2022-06-23 17:17:10.032851
# Unit test for function parse
def test_parse():
    text = """
    Arguments
    ---------
    a: int
        the first param
    b: str
        the second param

    Returns
    -------
    str
    """
    assert parse(text, style=Style.google) == Docstring(
        summary='',
        description='',
        params=[
            ('a', 'int', 'the first param'),
            ('b', 'str', 'the second param'),
        ],
        returns='str',
        raises=[],
        yields=[],
        rtype=None,
        meta={},
    )

# Generated at 2022-06-23 17:17:16.887220
# Unit test for function parse
def test_parse():
    # Test for style not set
    result = parse("this is a test")
    assert result.text == "this is a test"
    # Test for style set
    result = parse("this is a test", Style.google)
    assert result.text == "this is a test"
    # Test for style not in key
    try:
        result = parse("this is a test", "nct")
    except:
        result = False
    assert result == False

# Main method for running unit tests

# Generated at 2022-06-23 17:17:26.584659
# Unit test for function parse
def test_parse():
    doc = '''
Args:
    x (float): The first value.
    y (float): The second value.
'''
    result = parse(doc, style=Style.google)
    assert result.args == [{
        'arg': 'x',
        'annotation': 'float',
        'description': 'The first value.',
    }, {
        'arg': 'y',
        'annotation': 'float',
        'description': 'The second value.',
    }]
    assert result.kwargs == []
    assert result.returns == {
        'annotation': None,
        'description': None,
    }
    assert result.raises == []

# Generated at 2022-06-23 17:17:36.828687
# Unit test for function parse
def test_parse():

    docstring = """This is a module level docstring.
    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.
    Returns
    -------
    bool
        True if successful, False otherwise.
    """

    d = parse(docstring)

    assert d.short_description == 'This is a module level docstring.'
    assert d.long_description == ''
    assert len(d.params) == 2
    assert len(d.returns) == 1
    assert len(d.meta) == 2
    assert len(d.examples) == 0
    assert len(d.raises) == 0

    assert d.params[0].arg_name == 'param1'
    assert d.params[0].type_name == 'int'
    assert d.params

# Generated at 2022-06-23 17:17:47.066266
# Unit test for function parse
def test_parse():
    text = '''The main parsing routine.
    
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    docstring = parse(text)
    assert docstring.summary == "The main parsing routine."
    assert docstring.description == ""
    assert len(docstring.meta) == 3
    assert docstring.meta[2]['type'] == 'returns' # Return value
    assert docstring.meta[2]['name'] == None
    assert docstring.meta[2]['description'] == "parsed docstring representation"
    assert len(docstring.meta[2]) == 3
    assert docstring.meta[2]['type'] == 'returns'
    assert len(docstring.meta[2]['parameters']) == 0

# Generated at 2022-06-23 17:17:52.077572
# Unit test for function parse
def test_parse():
    a = parse("""This is a function.

    """
              """Parameters
    ----------
    a : This is a comment.
    b : This is another comment.

    Returns
    -------
    Z : This is a third comment.
    """)

    # Test function parse()
    assert(a.short_description == 'This is a function.')
    assert(a.long_description == '')
    assert(a.params['a'] == 'This is a comment.')
    assert(a.params['b'] == 'This is another comment.')
    assert(a.returns == 'This is a third comment.')

# Generated at 2022-06-23 17:17:59.862195
# Unit test for function parse
def test_parse():
    text = """
    This is the summary line.

    This is the rest of the docstring.

    :param arg1: Describes arg1
    :param arg2: Describes arg2
    :type arg1: The type for arg1
    :type arg2: The type for arg2
    :returns: Description of return value
    :rtype: The return type

    """
    docstring = parse(text)
    print(docstring.params)
    print(docstring.returns)
    print(docstring.summary)
    print(docstring.description)
    #assert docstring.params == [{'arg1', 'arg2'}]
    #assert docstring.returns == ['Description of return value']
    #assert docstring.summary == ['This is the summary line.']
    #assert docstring.description

# Generated at 2022-06-23 17:18:01.265289
# Unit test for function parse
def test_parse():
    text = "Hello world\n"
    _ = parse(text)



# Generated at 2022-06-23 17:18:03.667512
# Unit test for function parse
def test_parse():
	assert parse(text='') == Docstring(summary='', description='')

if __name__ == '__main__':
	test_parse()

# Generated at 2022-06-23 17:18:14.208739
# Unit test for function parse
def test_parse():
    s = """Summary line.
    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    str
        Description of return value"""
    doc = parse(s)
    assert doc.summary == "Summary line."
    assert 'Extended description.' in doc.description
    assert doc.params == {
        'arg1': {
            'type': 'int',
            'desc': 'Description of `arg1`'},
        'arg2': {
            'type': 'str',
            'desc': 'Description of `arg2`'}}
    assert doc.returns == {'type': 'str',
                           'desc': 'Description of return value'}

# Generated at 2022-06-23 17:18:15.712209
# Unit test for function parse
def test_parse():
    """Function that test if the parse function work well.
    """
    import doctest
    from docstring_parser import parsing
    doctest.testmod(parsing)


# Generated at 2022-06-23 17:18:21.176761
# Unit test for function parse
def test_parse():
    assert parse('foo') == Docstring('foo')
    assert parse('foo;bar') == Docstring('foo\nbar')
    text = 'foo;bar\n\n\n'
    assert parse(text) == Docstring(text)
    assert parse('rst') == Docstring('rst')
    assert parse('rst;bar') == Docstring('rst\nbar')
    text = 'rst;bar\n\n\n'
    assert parse(text) == Docstring(text)



# Generated at 2022-06-23 17:18:26.980324
# Unit test for function parse
def test_parse():
    a = parse('This is a test docstring')
    assert a.summary == 'This is a test docstring'
    b = parse('This is a test docstring', style=Style.google)
    assert b.summary == 'This is a test docstring'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:18:35.108245
# Unit test for function parse
def test_parse():
    """Test for function parse."""

    text = """\
This function does something.
:param arg1: The first argument.
"""
    args = parse(text)
    print(args.short_description)
    assert args.short_description == "This function does something."
    assert args.long_description.text == ""
    assert args.long_description.type == "text"
    assert args.meta[0].name == "arg1"
    assert args.meta[0].arg_type == "argument"
    assert args.meta[0].description.text == "The first argument."
    assert args.meta[0].description.type == "text"

# Generated at 2022-06-23 17:18:42.134930
# Unit test for function parse
def test_parse():
    text = """parse(text: str, style: Style = Style.auto) -> Docstring:
    """

    ret = parse(text)
    assert ret.__repr__() == 'Docstring(params=[Param(name=text, type=str, desc=None, default=None), Param(name=style, type=Style, desc=None, default=Style.auto)], type=Docstring, desc=None, returns=Docstring, meta=[])'

# Generated at 2022-06-23 17:18:45.303319
# Unit test for function parse
def test_parse():
    text = '''
    """
    This is a docstring.
    desc
    """"
    '''
    assert parse(text).desc == 'This is a docstring.\ndesc'
    return


# Generated at 2022-06-23 17:18:56.780063
# Unit test for function parse
def test_parse():

    text_0 = """

    A great way to manage your knowledge.

    Params:
        ...

    Returns:
        ...

    """

    text_1 = """

    A great way to manage your knowledge.

    :param ...:
        ...

    :returns:
        ...

    """

    text_2 = """
    A great way to manage your knowledge.

    Args:
        ...

    Returns:
        ...

    """

    text_3 = """

    A great way to manage your knowledge.

    Parameters
    ----------
    ...

    Returns
    -------
    ...

    """
    assert parse(text_0).summary == "A great way to manage your knowledge."
    assert parse(text_1).summary == "A great way to manage your knowledge."

# Generated at 2022-06-23 17:19:06.806933
# Unit test for function parse
def test_parse():
    ds = r"""\
        Parse the docstring into its components.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """
    d = parse(ds)
    assert isinstance(d, Docstring)
    assert d.summary == 'Parse the docstring into its components.'
    assert len(d.extended_summary) == 0
    assert len(d.params) == 2
    assert len(d.returns) == 1
    assert len(d.meta) == 2

    assert 'Parse the docstring into its components.' in str(d)


# Generated at 2022-06-23 17:19:08.294377
# Unit test for function parse
def test_parse():
    my_string = """This is a test string.
    
    This is a second line.
    
    This is a third line.
    
    """
    parsed = parse(my_string)
    print(parsed)
    
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:09.971176
# Unit test for function parse
def test_parse():
    s = parse('hello')
    assert s.summary == 'hello'

# Generated at 2022-06-23 17:19:17.642669
# Unit test for function parse
def test_parse():
    """docstring for test_parse"""
    
    docstring = """\
        This function does something.
        
        This sentence is a short description.
        It is meant to be a concise summary.
        
        Parameters
        ----------
        arg1 : int
            This is the first parameter description.
        arg2 : str
            This is a long parameter description that
            gets wrapped to the next line.
        
        Returns
        -------
        str
            This is the return value description.
        """
    docstring = parse(docstring)
    print("="*30)
    print("docstring = {}".format(docstring))
    print("="*30)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:27.997562
# Unit test for function parse
def test_parse():
    def test_parse_all_styles():
        import os.path
        import pkgutil
        import docstring_parser
        for loader, name, ispkg in pkgutil.walk_packages(path=docstring_parser.styles.__path__):
            path = loader.path
            module = loader.find_module(name).load_module(name)
            for name, _ in module.__dict__.items():
                if name.startswith('_'):
                    continue
                style = getattr(module, name)
                if not issubclass(style, Style):
                    continue
                filename = os.path.join(path, '%s.rst' % name.lower())
                with open(filename) as f:
                    text = f.read()
                doc = parse(text, style=style)
                yield style

# Generated at 2022-06-23 17:19:38.257413
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    assert len(parse('Tests parse.\n').full.split('\n')) == 3
    assert len(parse('Tests parse.\n').short.split('\n')) == 2
    assert parse('Tests parse.\n').short == 'Tests parse.'
    assert parse('Tests parse.\n').full == 'Tests parse.\n'
    assert str(parse('Tests parse.\n')) == 'Tests parse.'
    assert parse('Tests parse.\n').meta is None
    assert len(parse('Tests parse.\n:param a: input a\n\n').full.split('\n')) == 4

# Generated at 2022-06-23 17:19:40.576731
# Unit test for function parse
def test_parse():
    text = '''This is a module docstring.'''
    result = parse(text)
    assert result.short_description == 'This is a module docstring.'


# Generated at 2022-06-23 17:19:52.221252
# Unit test for function parse
def test_parse():
    docstring = """\
    One line description.

    Several lines description.

    Args:
        arg1 (int): The first parameter.
        arg2 (str): The second parameter. Defaults to "foo".
        arg3 (list): The third parameter.
        arg4 (str): The fourth parameter.

    Returns:
        int: The return value.

    Raises:
        AttributeError: The ``Raises`` section is a list, which may be empty.
        ValueError: If `param2` is equal to `param1`.

    """

# Generated at 2022-06-23 17:19:55.737305
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__

    if len(docstring) < 1:
        print("There is no docstring in function parse")
    else:
        print("Function parse has docstring with length " + str(len(docstring)))

test_parse()

# Generated at 2022-06-23 17:20:05.677103
# Unit test for function parse
def test_parse():
    """Docstring to test.

    Parameters
    ----------
    arg : str
        The argument.
    kwarg : str
        The keyword argument.

    Raises
    ------
    ValueError
        An exception.
    """

    docstring = parse(test_parse.__doc__)
    assert docstring.short_description == 'Docstring to test.'
    assert len(docstring.long_description.split('\n')) == 9
    assert len(docstring.params) == 2
    assert len(docstring.raises) == 1
    assert len(docstring.see_also) == 0
    assert len(docstring.returns) == 0

# Generated at 2022-06-23 17:20:07.640647
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring
    """
    style = Style.auto
    assert parse(text, style)


# Generated at 2022-06-23 17:20:11.459908
# Unit test for function parse
def test_parse():
    text = """
        This is a test.

        Args:
            param1 (int): This is param1.

        Kwargs:
            param2 (str): This is param2.
        """
    print(parse(text))


# Generated at 2022-06-23 17:20:13.062347
# Unit test for function parse
def test_parse():
    assert parse('some text')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:20:22.265344
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", [], [], None, None, None)
    assert parse("Objective: my objective\n\nA description") == \
           Docstring("Objective: my objective\n\nA description", [], [], 'Objective: my objective', "A description", None)
    assert parse("Objective: my objective\n\nA description\n\nReturns: a\n",
                                                                    style=Style.sphinx) == \
           Docstring("Objective: my objective\n\nA description\n\nReturns: a\n", ['a'], [], 'Objective: my objective', "A description", None)

# Generated at 2022-06-23 17:20:30.505370
# Unit test for function parse
def test_parse():
    text = '''
    """toto

    :param a:
        hello
    :param b:
        world
    """
    '''
    doc = parse(text, style=Style.sphinx)
    assert doc.short_description == "toto"
    assert doc.long_description == ""
    assert doc.params[0].arg_name == "a"
    assert doc.params[0].description == "hello"
    assert doc.params[1].arg_name == "b"
    assert doc.params[1].description == "world"

# Generated at 2022-06-23 17:20:39.546119
# Unit test for function parse
def test_parse():
    # docstring_parser.parse.test_parse()
    text = r"""
    Test function for docstring_parser.parse.parse
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    res = parse(text)
    print(res.summary)
    print(res.description)
    print(res.returns)
    print(res.return_type)
    print(res.meta)
    print(res.meta['param'])
    print(res.meta['returns'])
    # docstring_parser.parse.test_parse()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:20:41.537811
# Unit test for function parse
def test_parse():
    text = '''
    Hi guys
    I will talk about Python
    '''

    assert parse(text) == parse(text)

# Generated at 2022-06-23 17:20:53.488670
# Unit test for function parse
def test_parse():
    doc = """
    Unit test for function parse

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

# Generated at 2022-06-23 17:20:54.957705
# Unit test for function parse
def test_parse():
    print(parse('Hello, this is a docstring.'))


# Generated at 2022-06-23 17:20:59.348730
# Unit test for function parse
def test_parse():
    text = '''"""This is a docstring.
    
    Some details.
    """'''
    result = parse(text)
    print(result.summary)
    print(result.description)

if __name__ == "__main__":
    test_pa

# Generated at 2022-06-23 17:21:10.704017
# Unit test for function parse
def test_parse():
    """Testing function parse"""
    doc1 = """Calculate the volume of a sphere with a given radius

        r: radius of a sphere
        d: diameter of a sphere

        Returns
        -------

        volume of a sphere
        """
    parsed_doc1 = parse(doc1)
    assert parsed_doc1.short_description == "Calculate the volume of a sphere with a given radius"
    assert parsed_doc1.long_description == "\nvolume of a sphere"
    assert parsed_doc1.meta['r'] == ['radius of a sphere']
    assert parsed_doc1.meta['d'] == ['diameter of a sphere']


# Generated at 2022-06-23 17:21:12.148092
# Unit test for function parse
def test_parse():
    assert parse('Hello world!') is not None
    assert parse('Na', style=Style.auto) is not None

# Generated at 2022-06-23 17:21:20.380769
# Unit test for function parse
def test_parse():
    text = """
    This is the first paragraph of the docstring.
    
    This is the second paragraph of the docstring.
    
    :param foo: A required positional argument
    :param bar: An optional keyword argument
    :return: A string
    :raises ValueError: if `value` is negative
    """
    docstring = parse(text, style = Style.Numpy)
    
    assert docstring.short_description == 'This is the first paragraph of the docstring.'
    assert docstring.long_description == 'This is the second paragraph of the docstring.'
    assert docstring.params['foo'] == 'A required positional argument'
    assert docstring.params['bar'] == 'An optional keyword argument'
    assert docstring.returns == 'A string'

# Generated at 2022-06-23 17:21:28.386983
# Unit test for function parse

# Generated at 2022-06-23 17:21:39.904406
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle
    from textwrap import dedent
    doc = "This is a docstring."
    assert parse(doc).short_description == doc
    ds = '\n'.join(['This is a docstring.',
                    '',
                    'Args:',
                    '    a (int): Docstring for a.',
                    '    b (str): Docstring for b.',
                    '',
                    'Returns:',
                    '    int: Docstring for return value.'])
    assert parse(ds) == NumpyStyle().parse(ds)

# Generated at 2022-06-23 17:21:51.000608
# Unit test for function parse
def test_parse():
    text = """This is a function that performs some task.

Args:
    param1(int): This is the first parameter.
        It can contain multiple lines
        and be indented.
    param2(tuple): This is the second parameter.
    param3(float): This is the third parameter.

Returns:
    int: Some description of the return value.

Raises:
    ValueError: If something bad happens.
    RuntimeError: If something really bad happens.
"""

# Generated at 2022-06-23 17:21:59.151389
# Unit test for function parse

# Generated at 2022-06-23 17:22:08.504853
# Unit test for function parse
def test_parse():
    docstring_numpy = ''' One-line summary that does not use variable names or the function name.

    Extended summary that may include multiple paragraphs.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`
    Returns
    -------
    int
        Description of return value
        
    '''
    docstring_google = ''' One-line summary that does not use variable names or the function name.

    Extended summary that may include multiple paragraphs.

    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`
    Returns:
        int: Description of return value
        
    '''
    docstring_numpy_result = parse(docstring_numpy)
    docstring_google_result

# Generated at 2022-06-23 17:22:18.265131
# Unit test for function parse
def test_parse():
    text = """
        simple func
        :param int a: xxx
        :param int b: yyy
        :returns: xxx
        :raises ValueError: xxx
        :err RuntimeError: xxx
    """

    ret = parse(text)
    assert len(ret.params) == 2
    assert len(ret.returns) == 1
    assert len(ret.raises) == 2
    assert ret.summary == "simple func"
    assert ret.extended_summary is None
    assert ret.params[0].arg_name == "a"
    assert ret.params[0].type_name == "int"
    assert ret.params[0].description == "xxx"
    assert ret.params[1].arg_name == "b"
    assert ret.params[1].type_name == "int"

# Generated at 2022-06-23 17:22:25.351476
# Unit test for function parse
def test_parse():
    text = "This is my very own docstring"
    doc1 = parse(text)
    doc2 = parse(text, Style.google)
    assert doc1.short_description == "This is my very own docstring"
    assert doc1.short_description == "This is my very own docstring"
    assert doc1 == doc2

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:28.769389
# Unit test for function parse
def test_parse():
    """DocstringParser.parse"""
    assert parse("just a string").short_description == "just a string"

    with pytest.raises(ParseError):
        parse("a multiline\ndocstring without quotes")

# Generated at 2022-06-23 17:22:38.432538
# Unit test for function parse
def test_parse():
    text = """
        This is a method.

        Args:
            param1 (int): this is the first param
            param2 (str, optional): this is a second param
            param3 (list, optional): this is a third param

        Returns:
            bool: this is a description of what is returned

        Raises:
            KeyError: raises an exception
            ValueError: raises an exception
        """

    docstring = parse(text)
    assert docstring.short_description == "This is a method."
    assert len(docstring.long_description.splitlines()) == 6
    assert not docstring.meta.params

# Generated at 2022-06-23 17:22:40.599611
# Unit test for function parse
def test_parse():
    docstring = parse("This is a test docstring")
    assert docstring.short_description == "This is a test docstring"

# Generated at 2022-06-23 17:22:43.515362
# Unit test for function parse
def test_parse():
    text = """\
    Test Function

    :param int a: parameter A
    :param int b: parameter B
    :returns: a+b
    """
    parse(text)


# Generated at 2022-06-23 17:22:50.990145
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Parameter
    from docstring_parser.styles import GoogleDocstring, NumpydocDocstring
    parsed = parse("""
    Example function with types documented in the docstring.

    :param int age: Age of the person
    :param str lastname: Last name of the person
    :returns: Person's full name
    :rtype: str
    :raises ValueError: When age is negative
    """)

# Generated at 2022-06-23 17:22:51.585709
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:22:52.780293
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    assert True

# Generated at 2022-06-23 17:22:55.656843
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == """\
Parse the docstring into its components.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation"""

# Generated at 2022-06-23 17:23:07.229649
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    s = r"""
    The __init__ method of a class is a special method that is called when an instance
    of a class is created. It is called the constructor method and is named init by
    convention. We use the init method to initialize (e.g. establish a starting value)
    any data attributes of an object that we will need. Instance variables, which
    we will look at in the next section, are data attributes that are specific to
    each object.
    """
    parsed = parse(s, style=GoogleStyle)
    assert parsed.summary == 'The __init__ method of a class is a special method that is called when an instance of a class is created. It is called the constructor method and is named init by convention.' # noqa

# Generated at 2022-06-23 17:23:09.622528
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    text = '''
    My silly docstring.
    '''
    print(parse(text))


# Generated at 2022-06-23 17:23:19.162092
# Unit test for function parse

# Generated at 2022-06-23 17:23:22.157458
# Unit test for function parse
def test_parse():
    assert parse("description")
    assert parse("description\n")
    assert parse("description\nmore\nmore")

# Generated at 2022-06-23 17:23:32.468446
# Unit test for function parse
def test_parse():
    text = """
    Single line docstring.
    """
    parsed_docstring = parse(text, style='google')

    assert parsed_docstring.short_description == "Single line docstring."
    assert parsed_docstring.long_description == ""
    assert parsed_docstring.meta['summary'] == "Single line docstring."

    text = """
    Single line docstring.

    Args:
        arg_a (int): The first parameter.
        arg_b (str): The second parameter.
    """
    parsed_docstring = parse(text, style = 'google')

    assert parsed_docstring.short_description == "Single line docstring."
    assert parsed_docstring.long_description == ""
    assert parsed_docstring.meta['summary'] == "Single line docstring."

# Generated at 2022-06-23 17:23:35.730167
# Unit test for function parse
def test_parse():
    print(parse("""
    A thing that does a thing.

    Stuff goes here.
    """))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:23:40.581295
# Unit test for function parse
def test_parse():
    text = '''"""
    :param a: A
    :param b: B
    """'''
    docstring = parse(text)
    assert docstring.meta['param'][0]['name'] == 'a'
    assert docstring.meta['param'][1]['name'] == 'b'

# Generated at 2022-06-23 17:23:49.921687
# Unit test for function parse
def test_parse():
    docstring = """
        It is an absurd disciplinary apparatus, with absurd disciplinary goals.
        (Cf. Hacking, 1995; Zhang, 2010; Smith, 2018)

        :param ds: A Dataset object
        :param kwargs: Keyword arguments

        :returns: A Dataset object
        """
    parsed = parse(docstring)
    assert parsed.summary == "It is an absurd disciplinary apparatus, with absurd disciplinary goals."
    assert parsed.references == [
        "Hacking, 1995",
        "Zhang, 2010",
        "Smith, 2018",
    ]
    assert parsed.returns == {"returns": "A Dataset object"}
    assert parsed.params == {
        "ds": "A Dataset object",
        "kwargs": "Keyword arguments",
    }

# Generated at 2022-06-23 17:24:00.591090
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    from docstring_parser.styles import STYLES
    from docstring_parser.common import Docstring, Meta
    from docstring_parser.parser import parse

    # style format1, with one parameter
    docstr = '''
    """
    :param s: string to be reversed
    :return: reversed string
    """
    '''
    # parse
    parsed = parse(docstr, STYLES[Style.format1])
    # print(parsed)
    assert parsed == Docstring(
        meta = Meta(
            summary = None
            , parameters = {'s': None}
            , returns = None
            )
        , description = None
        )

    # style format1, with multiple parameters

# Generated at 2022-06-23 17:24:03.774903
# Unit test for function parse
def test_parse():
    text = '''
        text - This

        text - is

        text - a

        text - test
    '''

    # test parse as numpy style
    docstring = parse(text, style=Style.numpy)
    assert(docstring.summary == ['This', 'is', 'a', 'test'])
    assert(docstring.args == [])
    assert(docstring.kwargs == [])
    assert(docstring.retvals == [])

    # test parse as google style
    docstring = parse(text, style=Style.google)
    assert(docstring.summary == ['This', 'is', 'a', 'test'])
    assert(docstring.args == [])
    assert(docstring.kwargs == [])
    assert(docstring.retvals == [])

    # test parse as reST

# Generated at 2022-06-23 17:24:14.951140
# Unit test for function parse
def test_parse():
    text = """\
This is the module docstring.

This is the class docstring.

This is the method docstring.

This is the function docstring.

This is the __init__ docstring.
"""
    docstring = parse(text)
    assert docstring.short_description == "This is the module docstring."
    assert docstring.long_description == ""
    assert docstring.meta["author"] == ""
    assert docstring.meta["blurb"] == ""
    assert docstring.meta["copyright"] == ""
    assert docstring.meta["email"] == ""
    assert docstring.meta["license"] == ""
    assert docstring.meta["summary"] == ""
    assert docstring.meta["version"] == ""
    assert len(docstring.params) == 0

# Generated at 2022-06-23 17:24:26.985969
# Unit test for function parse
def test_parse():

    assert parse("")==Docstring(summary="",
                                description="",
                                params=None,
                                return_value=None,
                                meta={'author':[],
                                      'date':[],
                                      'see also':[],
                                      'note':[],
                                      'warning':[],
                                      'raise':[],
                                      'references':[],
                                      'todo':[],
                                      'bug':[],
                                      'example':[]},
                                return_type=None,
                                style=Style.google)

# Generated at 2022-06-23 17:24:35.216992
# Unit test for function parse
def test_parse():
    text = ('test\n'
            ':param param1: the first parameter\n'
            ':param param2: the second parameter\n'
            ':return: description of return value\n')

    ret = parse(text)
    assert ret.short_description == 'test'
    assert ret.long_description == ''

    params = ret.params
    assert params.get('param1') == 'the first parameter'
    assert params.get('param2') == 'the second parameter'

    assert ret.returns == 'description of return value'

# Generated at 2022-06-23 17:24:45.961941
# Unit test for function parse
def test_parse():
    """
    [Description]
    Test the function parse.
    """

# Generated at 2022-06-23 17:24:51.248746
# Unit test for function parse
def test_parse():
    text = '''
    My function for case 1

    :param param1: description
    :type param1: int
    '''
    obj = parse(text, style=Style.auto)
    print(obj.short_description)
    print(obj.long_description)
    print(obj.meta)


# Generated at 2022-06-23 17:25:00.063673
# Unit test for function parse
def test_parse():
    assert parse('').summary == ''
    assert parse('a').summary == 'a'
    assert parse('a\nb').summary == 'a'
    assert parse('a\nb\n\nC').description == 'b'
    assert parse('a\n\nC').description == ''
    assert parse('a\n\nC\nd').description == 'd'
    assert parse('a\n\n:C:\n\nd').description == 'd'
    assert not parse('a\n\n:C:\n\nd').meta
    assert parse('a\n\n:C:\n\nd', style=Style.google).meta['C'] == 'd'
    assert parse('a\n\n:C: d', style=Style.numpy).meta['C'] == 'd'

# Generated at 2022-06-23 17:25:12.114635
# Unit test for function parse
def test_parse():
    text = ''' 
    This is a function.
    Parameters:
        a: a
        b (int): b
        c: c
    Returns:
        return value
    '''
    doc = parse(text)
    print(doc)
    assert doc.summary == 'This is a function.'
    assert doc.params['a'].type == "type_or_var"
    assert doc.params['a'].varname == "a"
    assert doc.params['a'].description == ""
    assert doc.params['b'].type == "int"
    assert doc.params['b'].varname == "b"
    assert doc.params['b'].description == ""
    assert doc.params['c'].type == "type_or_var"
    assert doc.params['c'].varname

# Generated at 2022-06-23 17:25:20.739332
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None
    docstring = parse("""Function to test this docstring parser
    \n @author: Author name
    @param a: first parameter
    @param b: second parameter
    @returns c: something
    """)
    assert docstring.summary == 'Function to test this docstring parser'
    assert docstring.get_meta('author') == 'Author name'
    assert docstring.params['a'].name == 'a'
    assert docstring.returns.name == 'c'
    assert docstring.params['a'].required is False
    assert docstring.params['a'].default is None
    assert docstring.returns.name == 'c'
    assert docstring.returns.required is False
    assert docstring.returns.default is None

# Generated at 2022-06-23 17:25:28.280259
# Unit test for function parse
def test_parse():
    try:
        parse('hello wold!')
    except ParseError:
        pass
    else:
        assert False, "Docstring should contain at least one line"
    assert parse('hello world!\n').summary == 'hello world!'
    assert parse('hello world!\n').meta == []
    assert parse('hello world!\n').description == ''
    assert parse('hello world!\n').returns == None

# Generated at 2022-06-23 17:25:34.020024
# Unit test for function parse
def test_parse():
    text = '''
    Hello, World!

    Summary:
    This is a test. I want to see if my function works properly

    Arguments:
    arg1 -- the first argument
    arg2 -- the second argument

    Returns:
    Dictionary containing value of arg1 and arg2
    '''
    style = Style.numpy
    assert style != Style.auto
    style = parse(text)
    assert style == Style.numpy
    assert style.meta['summary'] == 'This is a test. I want to see if my function works properly'
    assert style.sections[0]['name'] == 'Arguments'

# Generated at 2022-06-23 17:25:34.934992
# Unit test for function parse
def test_parse():
    assert isinstance(parse(""), Docstring)

# Generated at 2022-06-23 17:25:38.563115
# Unit test for function parse
def test_parse():
    text = """
    This is a comment.
    """
    rets = parse(text)
    print(rets.short_desc)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:44.296389
# Unit test for function parse
def test_parse():
    text = """
        This is the first line of docstring
        This is the second line
        Hello.
        .Separated.
        Another Line.
        .Key: Value.
    """
    print("Result of parsing: ")
    print(parse(text, style=Style.google))

if __name__=="__main__":
    test_parse()

# Generated at 2022-06-23 17:25:54.976222
# Unit test for function parse
def test_parse():
    text = "Summary line.\n\n    Extended description.\n\n    Parameters:\n        arg1 (int): Description of arg1\n        arg2 (str): Description of arg2\n\n    Returns:\n        int: Description of return value\n"
    text_simple = "Summary line.\n\n    Extended description.\n\n    Args:\n        arg1 (int): Description of arg1\n        arg2 (str): Description of arg2\n\n    Returns:\n        Description of return value\n"

# Generated at 2022-06-23 17:26:06.352799
# Unit test for function parse
def test_parse():
    """."""
    text = """\
    Test function to see if the function works
    Params:None
    Return: None
    """
    assert(parse(text, style=Style.numpy)==Docstring(params=None,returns=None,summary='Test function to see if the function works'))

    text = """\
    Test function to see if the function works
    Args:None
    Returns: None
    """
    assert(parse(text, style=Style.google)==Docstring(args=None,returns=None,summary='Test function to see if the function works'))

    text = """\
    This function will test to see if the function works.
    :param None
    :return:None
    """

# Generated at 2022-06-23 17:26:15.817472
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.numpydoc import NUMPY_STYLE
    from docstring_parser.styles.google import GOOGLE_STYLE
    from docstring_parser.styles.sphinx import SPHINX_STYLE
    from docstring_parser.styles.sphinx_wiki import SPHINX_WIKI_STYLE


# Generated at 2022-06-23 17:26:18.475898
# Unit test for function parse
def test_parse():
    assert isinstance(parse('.. py:class:: MyClass'), Docstring)
    try:
        parse('.. py:method:: my_method(arg1)')
    except:
        assert False

# Generated at 2022-06-23 17:26:29.821612
# Unit test for function parse
def test_parse():
    """
    Test parse function
    """

# Test 1:
    text = """This function will get a string and return the number of vowels in it
    Parameters:
        text:string:The input string
    Return:
        int: The number of vowels
    """
    expected = parse(text)
    assert(expected.short_description == "This function will get a string and return the number of vowels in it")
    assert(expected.long_description == "")
    assert(expected.signature == "")
    assert(expected.returns.arg_type == "int")
    assert(expected.returns.description == "The number of vowels")
    assert(expected.examples == "")
    assert(expected.yields.arg_type == "")
    assert(expected.yields.description == "")
