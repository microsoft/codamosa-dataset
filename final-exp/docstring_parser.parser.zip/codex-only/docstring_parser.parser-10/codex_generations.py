

# Generated at 2022-06-23 17:16:26.662329
# Unit test for function parse
def test_parse():
    text = \
        """Unit test for function parse
        
        Parameters
        ----------
        text : str
            docstring text to parse
        style : str
            docstring style
            
        This is a content inside the description
        
        Returns
        -------
        str
            parsed docstring representation
        """

    doc = parse(text)
    assert(doc.short_description == "Unit test for function parse")
    assert(doc.long_description == "This is a content inside the description")
    assert(len(doc.params) == 2)
    assert(len(doc.returns) == 0)
    assert(len(doc.raises) == 0)
    assert(len(doc.yields) == 0)
    assert(len(doc.other_sections) == 0)

    ret = doc.params[0]

# Generated at 2022-06-23 17:16:36.676363
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    #raise ParseError('foo')
    docstring = parse('''
    :param x: parameter x
    :raises ValueError: raises ValueError
    :returns: returns number
    ''')
    assert docstring is not None
    assert docstring.params is not None
    assert docstring.raises is not None
    assert docstring.returns is not None
    assert docstring.summary is None

    docstring = parse('''
    :param x: parameter x
    :raises ValueError: raises ValueError
    :returns: returns number
    ''')
    assert docstring.params == {'x': 'parameter x'}

# Generated at 2022-06-23 17:16:45.793773
# Unit test for function parse
def test_parse():

    text = """Given a set of parameters, computes the device frequencies for
     Design and Detector.
    :param parameters: (cxcalib.Parameters) the parameters with relevant information
    :return: (tuple) device frequencies in Hz
    """

    result = parse(text)

    # Test functions
    assert isinstance(result, Docstring)
    assert isinstance(result.short_description, str)
    assert isinstance(result.long_description, str)
    assert isinstance(result.params, list)
    assert isinstance(result.returns, list)
    assert isinstance(result.meta, dict)
    assert isinstance(result.type_keys, list)

    # Test values
    assert len(result.params) == 2
    assert len(result.returns) == 2

# Generated at 2022-06-23 17:16:53.866962
# Unit test for function parse
def test_parse():

    docstring = parse("""
    This is a docstring.
    """)

    assert docstring.short_description == "This is a docstring."

    docstring = parse("""
    This is a docstring.
    This is a docstring.
    This is a docstring.
    This is a docstring.
    This is a docstring.
    """)

    assert docstring.short_description == "This is a docstring.\n    This is a docstring.\n    This is a docstring.\n    This is a docstring.\n    This is a docstring."

# Generated at 2022-06-23 17:17:03.396294
# Unit test for function parse
def test_parse():
    assert parse('miguel') == Docstring('miguel', [], [], '', '', '', '')
    assert parse('"""miguel"""') == Docstring('miguel', [], [], '', '', '', '')
    assert parse('"""miguel\n\n"""') == Docstring('miguel', [], [], '', '', '', '')
    assert parse('"""miguel\n\n"""', style='google') == Docstring('miguel', [], [], '', '', '', '')
    assert parse(' m\ni \ng \nu \ne \nl \n\n') == Docstring('miguel', [], [], '', '', '', '')

# Generated at 2022-06-23 17:17:13.026877
# Unit test for function parse
def test_parse():
    docstring = \
    """Summary line.

    Extended description.
    """
    assert(parse(docstring, style=Style.numpy).summary == \
    "Summary line.")
    assert(parse(docstring, style=Style.numpy).description == \
    "Extended description.")

    docstring = \
    """Summary line.

    :param foo: first parameter
    :type foo: str
    :param bar: second parameter
    :type bar: int
    :returns: return value
    :rtype: str
    """
    assert(parse(docstring, style=Style.numpy).params[0].arg_name == \
    "foo")
    assert(parse(docstring, style=Style.numpy).params[0].type_name == \
    "str")

# Generated at 2022-06-23 17:17:19.860466
# Unit test for function parse
def test_parse():
  text = """

  This is a test for the parse function in this module.

  Parameters:
    var1 - A string
    var2 - Another string
  """
  doc = parse(text)
  assert doc.short_description == "This is a test for the parse function in this module."
  assert doc.meta["Parameters"] == ["var1 - A string", "var2 - Another string"]

# Generated at 2022-06-23 17:17:31.269199
# Unit test for function parse

# Generated at 2022-06-23 17:17:39.130673
# Unit test for function parse
def test_parse():

    assert(parse('') == Docstring(''))
    assert(parse('a\nb\nc') == Docstring('a\nb\nc'))
    assert(parse('\n    a\n    b\n    c\n') == Docstring('a\nb\nc'))

    assert(parse('Summary line.\n\nDescription line.\n') == Docstring(
        summary='Summary line.',
        body=['Description line.'],
    ))

    assert(parse('Summary line.\n\nDescription line.') == Docstring(
        summary='Summary line.',
        body=['Description line.'],
    ))


# Generated at 2022-06-23 17:17:43.530164
# Unit test for function parse
def test_parse():
    from textwrap import dedent
    docstring_text = dedent("""\
    This is a test
    
    Arguments:
        a: First argument
        b: Second argument
    Returns:
        int.
    """)
    assert(parse(docstring_text, style=Style.numpydoc) == Docstring(arguments=['a: First argument','b: Second argument'], meta='int.', summary='This is a test', style=Style.numpydoc))
    docstring_text = dedent("""\
    This is a test
    
    Args:
        a: First argument
        b: Second argument
    Returns:
        int.
    """)

# Generated at 2022-06-23 17:17:48.337733
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = \
"""This function will do the division and returns quotient & remainder.

    :param dividend: The dividend
    :param divisor: The divisor
    :returns: quotient & remainder
    :raises ZeroDivisionError: if divisor is zero
"""
    assert parse(text).meta['param']['dividend'].description == 'The dividend'

test_parse()

# Generated at 2022-06-23 17:17:58.397688
# Unit test for function parse
def test_parse():
    print('test_parse')
    print(parse(''))
    print(parse('\n'))
    print(parse('\n\n'))
    print(parse('foo bar baz'))
    print(parse('foo bar'))
    print(parse('foo bar\n\n'))
    print(parse('   foo bar  \n\n'))
    print(parse('\n\n  foo bar  \n\n'))
    print(parse('\n\n  foo bar  \n  baz qux'))
    print(parse('\n\n  foo bar\n\n  baz qux'))
    print(parse('\n\n  foo bar\n\n  baz qux\n\n'))

# Generated at 2022-06-23 17:18:09.176048
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.
    
    Args:
        a (str): First argument.
        b (str, int): Second argument.
            Will be cast to int.
    
    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    \
    #Calling function parse for docsting style auto
    print(repr(parse(text)))
    print('\n')
    
    #Calling function parse for docsting style numpy
    print(repr(parse(text, style=Style.numpy)))
    print('\n')
    
    #Calling function parse for docsting style google
    print(repr(parse(text, style=Style.google)))
    print('\n')
    
    #Calling function parse for docsting style reStruct

# Generated at 2022-06-23 17:18:19.120796
# Unit test for function parse

# Generated at 2022-06-23 17:18:21.404810
# Unit test for function parse
def test_parse():
    text = """A test module."""
    py = parse(text)
    assert py.short_description == "A test module."


# Generated at 2022-06-23 17:18:26.499477
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    func = lambda x: x
    doc = parse(func.__doc__)
    assert doc.short_description == 'lambda x: x'
    assert doc.long_description.startswith('The main parsing routine.')


# Generated at 2022-06-23 17:18:34.149234
# Unit test for function parse
def test_parse():
    docstring = parse('''\
Assignment
--
Title: Short Title
Summary: An assignment, return true.
Author: Jinjie Xu
Contact: jinjiexu@cmu.edu
      ''')

    expected_docstring = Docstring(
        content = 'Assignment',
        short_description = "An assignment, return true.",
        long_description = "",
        author = "Jinjie Xu",
        contact = "jinjiexu@cmu.edu",
        notes = "",
        examples = "",
        see_also = "",
        attributes = [],
        parameters = [],
        return_label = None,
        returns = [],
        raises = [],
        yields = [],
        other_sections = [],
        meta = {}
    )

    assert docstring

# Generated at 2022-06-23 17:18:45.303264
# Unit test for function parse
def test_parse():
    # Good input test
    assert parse("This is an example docstring.")
    assert parse("This is an example docstring.", Style.google)
    assert parse("This is an example docstring.", Style.numpy)
    assert parse("This is an example docstring.", Style.sphinx)

    # Bad input test
    try:
        parse("")
    except ParseError:
        pass
    except Exception:
        raise AssertionError()
    try:
        parse("", Style.sphinx)
    except ParseError:
        pass
    except Exception:
        raise AssertionError()
    try:
        parse("", Style.auto)
    except ParseError:
        pass
    except Exception:
        raise AssertionError()

# Generated at 2022-06-23 17:18:49.626168
# Unit test for function parse
def test_parse():
    sample_docstring = \
    """This is a sample docstring
    This is a sample docstring
    This is a sample docstring
    This is a sample docstring"""
    assert parse(sample_docstring).summary == "This is a sample docstring"

# Generated at 2022-06-23 17:18:51.652389
# Unit test for function parse
def test_parse():
    """Test parsing with custom styles."""
    print(parse('Hello world, this is a test.\nFoo bar'))
#test_parse()

# Generated at 2022-06-23 17:18:58.728254
# Unit test for function parse
def test_parse():
    docstring = """\
    This is a short summary.

    This is the description.

    Parameters
    ----------
    a : int
        Description of a.
    b : float
        Description of b.

    Returns
    -------
    None
        Description of return value.
    """

    ds = parse(docstring)
    assert ds['summary'] == "This is a short summary."
    assert ds['description'] == "This is the description."
    assert len(ds['parameters']) == 2
    assert ds['parameters'][0]['name'] == 'a'
    assert ds['parameters'][0]['type'] == 'int'
    assert ds['parameters'][0]['description'] == 'Description of a.'
    assert len(ds['returns']) == 1
    assert d

# Generated at 2022-06-23 17:19:09.678651
# Unit test for function parse
def test_parse():
    text = '''Function to parse a docstring.

    :param text: docstring text
    :param style: docstring style
    :returns: docstring object
    '''
    result = parse(text)
    assert result.short_description == 'Function to parse a docstring.'
    assert result.long_description == ''
    assert result.style == 'numpy'
    assert [tag.arg_name for tag in result.parameters] == ['text', 'style']
    assert result.parameters[1].description == 'docstring style'
    assert result.parameters[0].description == 'docstring text'
    assert result.returns.description == 'docstring object'

# Generated at 2022-06-23 17:19:13.815964
# Unit test for function parse
def test_parse():
    """Test function parse()."""

    text = """
        Description
        -----------
        Description line 1
        Description line 2

        Parameters
        ----------
        param1 : type1
            param1 description
        param2 : type2
            param2 description

        Returns
        -------
        type
            return description
    """
    doc = parse(text)

    # test parameters
    assert len(doc.meta.params) == 2
    assert doc.meta.params["param1"].type == "type1"
    assert doc.meta.params["param2"].type == "type2"
    assert doc.meta.params["param1"].desc == "param1 description"
    assert doc.meta.params["param2"].desc == "param2 description"

    # test returns

# Generated at 2022-06-23 17:19:25.927727
# Unit test for function parse
def test_parse():
    pass  # NOTE: Test it via parse_module.py
    #
    # print(parse("\n"))
    # print(parse("\n\n"))
    # print(parse("\n\n\n"))
    # print(parse("\n\n\n\n"))
    # print("*" * 20)
    # print(parse("Hello"))
    # print(parse("Hello\n"))
    # print(parse("Hello\n\n"))
    # print(parse("Hello\n\n\n"))
    # print("*" * 20)
    # print(parse("Hello\nWorld\n"))
    # print(parse("Hello\nWorld\n\n"))
    # print(parse("Hello\nWorld\n\n\n"))
    # print("*" * 20)
    # print

# Generated at 2022-06-23 17:19:30.308982
# Unit test for function parse
def test_parse():
    test_parse1()
    test_parse2()
    test_parse3()
    test_parse4()
    test_parse5()
    test_parse6()
    # test_parse7()  # this test is optional for now
    test_parse8()


# Generated at 2022-06-23 17:19:38.807131
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Parameter
    docstring = """Short summary.

Long Summary

:param arg1: the first argument
:type arg1: int
:param arg2: the second argument
:type arg2: str
:returns: description of return value
:rtype: bool
"""
    doc = parse(docstring)

    assert doc.short_description == "Short summary."
    assert doc.long_description == "Long Summary"
    assert doc.params == [
        Parameter("arg1", "the first argument", "int", None),
        Parameter("arg2", "the second argument", "str", None),
    ]
    assert doc.returns == Parameter("", "description of return value", "bool", "")

    assert doc.get_header() == "Short summary."
    assert doc.get

# Generated at 2022-06-23 17:19:44.092095
# Unit test for function parse
def test_parse():
    from docstring_parser import parse, ParseError
    docstring = """\
    This is a very short docstring.

    Parameters
    ----------
    param1: description of the first parameter
    """
    print(parse(docstring))
    print(parse(docstring, style=Style.numpy))

    with pytest.raises(ParseError):
        parse('This is not a docstring.\n', style=Style.numpy)

# Generated at 2022-06-23 17:19:52.347211
# Unit test for function parse
def test_parse():
    text = """
    This function does some math.

    :param a: This is a parameter.
    :type a: int
    :returns: This is a return value.
    :rtype: int
    """
    ds = parse(text, style=Style.numpy)
    assert ds.short_description == "This function does some math."
    assert ds.long_description == ""
    assert len(ds.params) == 1
    assert len(ds.returns) == 1

# Generated at 2022-06-23 17:19:59.384073
# Unit test for function parse
def test_parse():
    docstring = """This is a docstring for a function.
    :param param1: this is a parameter
    :type param1: int
    :param param2: this is a parameter
    :type param2: str
    :returns: this is a return
    :rtype: dict
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a docstring for a function."
    assert parsed.long_description == ""
    assert parsed.params == [
        (
            "param1",
            "this is a parameter",
            "int",
        ),
        (
            "param2",
            "this is a parameter",
            "str",
        ),
    ]
    assert parsed.returns is not None
    assert parsed.returns.args == ("this is a return",)


# Generated at 2022-06-23 17:20:10.203737
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Description, DescriptionStyle
    from docstring_parser.styles import Style

    docstring = parse('Test')
    assert docstring.full == 'Test'
    assert docstring.short == 'Test'
    assert docstring.long ==  Description('', '', '', DescriptionStyle.blank)
    assert docstring.style == Style.other
    assert docstring.meta == []
    assert docstring.indent == 0

    docstring = parse('Test\n')
    assert docstring.full == 'Test\n'
    assert docstring.short == 'Test'
    assert docstring.long ==  Description('', '', '', DescriptionStyle.blank)
    assert docstring.style == Style.other
    assert docstring.meta == []
    assert docstring.indent == 0


# Generated at 2022-06-23 17:20:19.699155
# Unit test for function parse
def test_parse():
    text = '''
    :param foo: placeholder for foo
    :param bar: placehold for bar
    :raises ValueError: Placeholder for error
    :returns: Placeholder for returns
    :yields: Placeholder for yeilds
    :yield type: Type for yielded values
    :yield param list: List of parameters
    '''

    docstr = parse(text)

    assert docstr.params[0].arg_name == 'foo'
    assert docstr.params[0].description.startswith('placeholder')

    assert docstr.raises[0].type_name == 'ValueError'
    assert docstr.raises[0].description.startswith('Placeholder')

    assert docstr.returns.description.startswith('Placeholder')


# Generated at 2022-06-23 17:20:24.594145
# Unit test for function parse
def test_parse():
    """Test parse function."""
    docstring = r"""
      This is the first sentence
      of the docstring.
    
      This is the second sentence.
    
      Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`
    
      Returns:
        str: Description of return value
    """
    # assert len(parse(docstring)) == 4
    assert parse(docstring).short_description == 'This is the first sentence'
    assert len(parse(docstring).long_description) == 2
    assert len(parse(docstring).meta) == 2
    assert parse(docstring).meta[0].name == 'arg1'


# Generated at 2022-06-23 17:20:32.837114
# Unit test for function parse
def test_parse():
    text = """
Description of function

Parameters:
    param1: A dictionary that stores data.
    param2: A boolean variable.

Returns:
    None
    """
    d = parse(text)
    assert d.description == "Description of function"
    assert len(d.params) == 2
    assert len(d.returns) == 1
    assert d.params['param1']=="A dictionary that stores data."
    assert d.params['param2']=="A boolean variable."
    assert d.returns[0]==''

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:20:38.169626
# Unit test for function parse
def test_parse():
    assert parse('{a} {b}') == Docstring(meta={'a': None, 'b': None})
    assert parse('{a}\n{b}', style='numpy') == Docstring(meta={'a': None, 'b': None})
    assert parse('{a}: {b}', style='google') == Docstring(meta={'a': None, 'b': None})

# Generated at 2022-06-23 17:20:43.537479
# Unit test for function parse
def test_parse():
    print("┌────────────────────────────────────┐")
    text = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    docstring = parse(text)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.params[0].name)
    print(docstring.returns)
    print("└────────────────────────────────────┘")


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:20:51.446985
# Unit test for function parse
def test_parse():
    import sys
    sys.path.append('.')
    from docstring_parser.parser import parse
    from docstring_parser.parser import Docstring
    from markdown import markdown

    try:
        d = parse('''
        """This is a test"""
        ''')
    except Exception as e:
        print(f"Error in parse: {str(e)}")
        return False
    print(f"Test passed: parse")
    return True

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:21:00.608737
# Unit test for function parse
def test_parse():
    ds = parse("""\
        First line.

        :param length: The length of the object.
        :param width: The width of the object.
        :returns: What the object is made of.

        Final line.
        """)

    assert ds.short_description == "First line."
    assert ds.long_description == "\nFinal line.\n"
    assert ds.returns.description == "What the object is made of."
    assert ds.meta == {
        'length': 'The length of the object.',
        'width': 'The width of the object.',
    }


# Generated at 2022-06-23 17:21:12.589732
# Unit test for function parse
def test_parse():
    docstring1 = """One line description.
    
    More description here.
    
    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: Description of return value.
    :rtype: bool
    """

# Generated at 2022-06-23 17:21:20.656174
# Unit test for function parse
def test_parse():
	
	##TEST 1
	text = ''' """This function returns a*b
	
	this function is a test to multiply
	this is a demo to test the function
	
	
	""" '''
	
	parse_ = parse(text, style = Style.google)
	assert parse_.meta.summary == 'This function returns a*b' 
	assert parse_.meta.description == 'this function is a test to multiply\nthis is a demo to test the function'
	assert parse_.meta.args.a == 'a'
	assert parse_.meta.returns.return_meta == 'return a*b'
	
	
	##TEST 2
	text = ''' """This function returns a*b
	
	
	""" '''
	
	parse_ = parse(text, style = Style.numpy)
	

# Generated at 2022-06-23 17:21:22.043371
# Unit test for function parse
def test_parse():
    pass

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:21:24.654775
# Unit test for function parse
def test_parse():

    assert parse('name = "parser"\ndocstring = """Hello World"""') == Docstring(description='Hello World', meta=['name = "parser"\n', 'docstring = """Hello World"""'])

# Generated at 2022-06-23 17:21:35.344819
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = '''This module demonstrates documentation as specified by the
    `Google Python Style Guide`_.

    .. _Google Python Style Guide:
       http://google.github.io/styleguide/pyguide.html

    '''
    docstring = parse(text, style='sphinx')
    assert(docstring.short_description == 'This module demonstrates documentation as specified by the Google Python Style Guide.')
    assert(docstring.long_description == 'http://google.github.io/styleguide/pyguide.html')

    text = '''This module demonstrates documentation as specified by the
    `Google Python Style Guide`_.

    .. _Google Python Style Guide:
       http://google.github.io/styleguide/pyguide.html

    '''

# Generated at 2022-06-23 17:21:39.000114
# Unit test for function parse
def test_parse():
    import docstring_parser
    doc = '''
        Parameter:
        ----------
        name:          str
            Description
        value:         float
            Description
        '''

    print(docstring_parser.parse(doc))


# Generated at 2022-06-23 17:21:46.958308
# Unit test for function parse
def test_parse():
    assert parse(""""
    Function def for testing docstrings.

    :param x: input value
    :type x: int
    :returns: output value
    :rtype: int
    """) == Docstring(
        short_description='Function def for testing docstrings.',
        long_description=None,
        content_type='text/plain',
        returns=('output value', 'int', None),
        yield_=None,
        raises=None,
        meta={
            'param': [('x', 'input value', 'int', None)],
            'rtype': 'int'}
    )

# Generated at 2022-06-23 17:21:57.471139
# Unit test for function parse
def test_parse():
    from .common import Docstring
    from .parsers import GoogleParser
    text = '''\
Returns the square root of a number.

Args:
    number (int): The number to square.
    precision (int, optional): The desired precision. Defaults to 2.

Raises:
    ValueError: If `number` is negative.

Returns:
    int: The square root of `number`.
'''


# Generated at 2022-06-23 17:22:07.349165
# Unit test for function parse
def test_parse():
    """Test the function parse"""
    text_1 = """This is the example of numpydoc style."""
    text_2 = """This is the example of google style."""
    text_3 = """This is the example of epytext style."""
    text_4 = """This is the example of default style."""
    text_5 = """This is the example of all style."""
    assert parse(text_1, style = Style.numpydoc) == parse(text_1), "The function parse is not correct!"
    assert parse(text_2, style = Style.google) == parse(text_2), "The function parse is not correct!"
    assert parse(text_3, style = Style.epytext) == parse(text_3), "The function parse is not correct!"

# Generated at 2022-06-23 17:22:14.023451
# Unit test for function parse
def test_parse():
    parser = parse(text, style=Style.google)
    assert(parser.summary == 'Load data.')

if __name__ == "__main__":
    text = '''\
Load data.

This loads data into the system.

:param str name: Name of the data to load
:param int age: Age of the data
:returns: Loaded data
:raises ValueError: If the data cannot be loaded
'''
    test_parse()

# Generated at 2022-06-23 17:22:21.111516
# Unit test for function parse
def test_parse():
    # test parsing of standard Numpy docstring
    from inspect import cleandoc
    from docstring_parser.utils import unindent
    from docstring_parser.utils import parse_numpy_style_docstring

    s = '''
    Spherical harmonic normalization.

    norm : {'4pi', 'ortho', 'schmidt', 'unnorm'}, optional
        Normalization of the spherical harmonics. Defaults to '4pi',
        the fully normalized convention.
    '''
    s = '\n'.join(line.lstrip() for line in unindent(cleandoc(s)).split('\n'))
    docstring = parse_numpy_style_docstring(s)
    assert docstring.short_description == 'Spherical harmonic normalization.'
    assert docstring.long_description == ''
    assert docstring

# Generated at 2022-06-23 17:22:33.003618
# Unit test for function parse
def test_parse():
    s = ("This is a sample docstring.\n\n"
         "Another paragraph in the description.\n\n"
         ":param str name: The name to use\n"
         ":param int value: The value of the attribute\n"
         ":returns: int -- the return code\n"
         ":raises ValueError: if the value is invalid\n"
         ":other: Other info")
    doc = parse(s)
    assert doc.short_description == 'This is a sample docstring.'
    assert doc.long_description == "Another paragraph in the description."
    assert doc.meta['name']['description'] == 'The name to use'
    assert doc.meta['value']['description'] == 'The value of the attribute'

# Generated at 2022-06-23 17:22:37.466568
# Unit test for function parse
def test_parse():
    text = """
This is a short summary.

Args:
    arg1: The first argument.
    arg2: The second argument.

Returns:
    The return value. True for success, False otherwise.

Raises:
    KeyError: Raises an exception.
"""
    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:41.713635
# Unit test for function parse
def test_parse():
    #assert parse(None) == None
    assert parse("") == None
    assert parse("Hello") == None
    assert parse("Hello World!", style="github") != None
    assert parse("Hello World!", style="google") != None
    assert parse("Hello World!", style="numpydoc") != None

test_parse()

# Generated at 2022-06-23 17:22:48.185174
# Unit test for function parse
def test_parse():
    #print(parse("long: l\nshort:\n\tthe end"))
    doc = parse("long: l\nshort:\n\tthe end")
    assert doc.short_description == "the end"
    assert doc.long_description == "l"
    #print(doc.get_sections())
    assert doc.get_sections() == [
        {'name': None, 'content': 'the end', 'metadata': {'long': 'l'}}
    ]
    assert doc["long"] == "l"
    assert doc["short"] == "the end"

# Generated at 2022-06-23 17:22:58.055157
# Unit test for function parse
def test_parse():
	a = "hello world"
	b = parse(a)
	assert str(b) == a
	
	a = "hello \nworld"
	b = parse(a)
	assert str(b) == a
	
	a = "hello \t world"
	b = parse(a)
	assert str(b) == a
	
	a = "hello \t \n\n world"
	b = parse(a)
	assert str(b) == a
	
	a = "hello : world"
	b = parse(a)
	assert str(b) == a
	
	a = "hello :\n"
	b = parse(a)
	assert str(b) == a
	
	a = "hello : \n"
	b = parse(a)
	assert str(b)

# Generated at 2022-06-23 17:23:02.084681
# Unit test for function parse
def test_parse():
    text = '''
    """
    The main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    '''
    print(parse(text))

# Generated at 2022-06-23 17:23:04.256738
# Unit test for function parse
def test_parse():
	# Tests for parse function
	import doctest
	doctest.testmod()

if __name__ == "__main__":
	test_parse()

# Generated at 2022-06-23 17:23:12.559952
# Unit test for function parse
def test_parse():
    docstring = parse("""Short summary.
    Longer description.

    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`
    Returns:
        bool: Description of return value
    """)
    args = docstring.args
    assert args[0].arg_name == 'arg1'
    assert args[0].type_name == 'int'
    assert args[0].description == 'Description of `arg1`'
    assert args[1].arg_name == 'arg2'
    assert args[1].type_name == 'str'
    assert args[1].description == 'Description of `arg2`'

    returns = docstring.returns
    assert returns[0].type_name == 'bool'

# Generated at 2022-06-23 17:23:20.304050
# Unit test for function parse
def test_parse():
    text = """

All my arguments.

Args:
    arg1 (int): The first argument.
    arg2 (str): The 2nd argument.

Keyword Args:
    arg3 (bool): The 3rd argument.

Returns:
    Tuple[int, str, bool]: The return value.
    """
    assert Docstring(
        args=[
            Docstring.Argument(arg1='The first argument.', arg2='The 2nd argument.')
        ],
        meta={},
        arguments=[
            Docstring.Argument(arg3='The 3rd argument.')
        ],
        return_=[
            Docstring.Return(
                ('The return value.',)
            )
        ],
        summary='All my arguments.'
    ) == parse(text)

# Generated at 2022-06-23 17:23:22.323262
# Unit test for function parse
def test_parse():
    txt = 'Testing'
    assert type(parse(txt)) == Docstring

# Generated at 2022-06-23 17:23:23.184057
# Unit test for function parse
def test_parse():
    assert parse("test") is not None

# Generated at 2022-06-23 17:23:33.763401
# Unit test for function parse
def test_parse():
    """
    >>> test_parse()
    True
    """
    from docstring_parser.styles import NumpyDocstring, GoogleDocstring, reStructuredTextDocstring
    from docstring_parser.common import Docstring
    docstring1 = Docstring(
    "This function does something...\n\n"
    "Args:\n"
    "    arg1 (int): The first argument.\n"
    "    arg2 (str): The second argument.\n\n"
    "Returns:\n"
    "    bool: The return value. True for success, False otherwise.\n"
    )


# Generated at 2022-06-23 17:23:45.161393
# Unit test for function parse
def test_parse():
    text = '''
    Class comment here
    :param arg1: ...
    :type arg1: ...
    :param arg2: ...
    :type arg2: ...
    :ivar arg1: ...
    :ivar arg2: ...
    :vartype arg1: ...
    :vartype arg2: ...
    :raises ValueError: ...
    :return: ...
    :rtype: ...
    '''
    assert parse(text).summary == 'Class comment here'
    assert parse(text).meta['param']['arg1'] == '...'
    assert parse(text).meta['type']['arg1'] == '...'
    assert parse(text).meta['param']['arg2'] == '...'

# Generated at 2022-06-23 17:23:52.455261
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.parse import parse
    from docstring_parser.styles import Style
    docstring_object = parse('"""\n'
                             '    Test for parsing.\n'
                             '\n'
                             '    :param test: Test\n'
                             '    :type test: str\n'
                             '    :returns: Test\n'
                             '    :rtype: bool\n'
                             '"""')
    assert docstring_object == Docstring(summary='Test for parsing.',
                                         description=None,
                                         extended_summary=None,
                                         annotations=dict(params=dict(test=('Test', 'str')),
                                                          returns=('Test', 'bool')),
                                         returns=None)


# Generated at 2022-06-23 17:24:01.530583
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    import pytest

    # Test case 1
    text = """
    Test function for the function parser.

    :param str name: Name to test the function.
    :param type style: (style) Test method to test the function.
    :return:
      Returns the cartesian product of X and Y.
    :rtype: List[str]
    """

    if Style.auto != Style.numpydoc:
        def parse(text: str, style: Style = Style.auto) -> Docstring:
            if style != Style.auto:
                return STYLES[style](text)
            rets = []

# Generated at 2022-06-23 17:24:11.641888
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ReturnItem, MetaItem
    from docstring_parser.docstring import parse
    assert parse("Return type: dict") == Docstring(
        returns=(ReturnItem(
            returns='dict',
            description=None,
        ),)
    )

# Generated at 2022-06-23 17:24:19.972981
# Unit test for function parse
def test_parse():
    def parse_test(docstring, style=Style.google):
        if style != Style.auto:
            return STYLES[style](docstring)
        rets = []
        for parse_ in STYLES.values():
            try:
                rets.append(parse_(docstring))
            except ParseError as e:
                exc = e
        if not rets:
            raise exc
        return sorted(rets, key=lambda d: len(d.meta), reverse=True)[0]

    docstring = """Test
    Args:
        arg1 : str
            The first argument.
        arg2 : int
            The second argument.
    Returns:
        bool
            The return value. True for success, False otherwise.
    """
    d = parse_test(docstring, style=Style.google)


# Generated at 2022-06-23 17:24:24.115981
# Unit test for function parse
def test_parse():
    test_repr = "Paragraph [0]"
    test_text = "This is a test."
    parsed = parse(test_text)
    if isinstance(parsed, Docstring):
        assert(test_repr in str(parsed))

# Generated at 2022-06-23 17:24:30.798547
# Unit test for function parse
def test_parse():
    assert(parse("""This function does something.

:param lhs: Description
:param rhs: Description
:return: Description
""") == Docstring(summary="This function does something.",
                    description=None,
                    meta=[('param', 'lhs', 'Description'),
                          ('param', 'rhs', 'Description'),
                          ('return', None, 'Description')]))


# Generated at 2022-06-23 17:24:40.817533
# Unit test for function parse

# Generated at 2022-06-23 17:24:43.407127
# Unit test for function parse
def test_parse():
    docstring = "This is a docstring"
    assert parse(docstring).short_description == "This is a docstring"


# Generated at 2022-06-23 17:24:51.005900
# Unit test for function parse
def test_parse():
    test = """A short summary.

    A longer description.
    """
    result = parse(test)
    assert result.short_description == "A short summary."
    assert result.long_description == "A longer description."
    assert result.meta == {}

    test = """A short summary.

    A longer description.

    :param arg1: A string.
    :param arg2: An int.
    :returns: The string when arg2 is 0, else the int.
    :raises ValueError: if the value is out of range.
    """
    result = parse(test)
    assert result.short_description == "A short summary."
    assert result.long_description == "A longer description."

# Generated at 2022-06-23 17:24:52.754856
# Unit test for function parse
def test_parse():
    pass


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:57.606166
# Unit test for function parse
def test_parse():
    text = '''
    Args:
        comment_id (int): the comment id.
        user_id (int): the user id.
    '''
    doc = parse(text, style = Style.google)
    assert(doc.args == [('comment_id', '(int): the comment id.'), ('user_id', '(int): the user id.')])



# Generated at 2022-06-23 17:25:08.740087
# Unit test for function parse
def test_parse():
    style = Style.reST
    text = """One-line summary.

Description not limited to one line.

:param a: Parameter a
:type a: int
:param b: Parameter b
:type b: str
:returns: something
:rtype: str
"""
    doc = parse(text, style = style)
    assert doc.short_description == 'One-line summary.'
    assert doc.long_description == 'Description not limited to one line.'
    assert doc.returns == 'something'
    assert doc.return_type == 'str'
    parameters = doc.params
    assert parameters[0].arg_name == 'a'
    assert parameters[0].description == 'Parameter a'
    assert parameters[0].annotation == 'int'
    assert parameters[1].arg_name == 'b'
   

# Generated at 2022-06-23 17:25:14.418044
# Unit test for function parse
def test_parse():
    d = parse("""
    test
    """)
    d = parse("""
    test
    """, style=Style.numpy)
    assert d.short_description == "test"
    d = parse("""
    test
    """, style=Style.google)
    assert d.short_description == "test"


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:15.868200
# Unit test for function parse
def test_parse():
    pass

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:26.155609
# Unit test for function parse
def test_parse():
    text = '''
The first line is a brief and always on a single line description.

The only tag (`:param`) and its content.

The last paragraph containing anything.
'''
    ds = parse(text)
    meta = ds.meta
    assert len(meta) == 1
    assert meta[0].tag_name == 'param'
    assert meta[0].type_name == None
    assert meta[0].name == None
    assert meta[0].short_description.strip() == 'The only tag (`:param`) and its content.'
    assert ds.long_description.strip() == 'The last paragraph containing anything.'
    assert ds.content.strip() == text

# Generated at 2022-06-23 17:25:27.705315
# Unit test for function parse

# Generated at 2022-06-23 17:25:33.453505
# Unit test for function parse
def test_parse():
    text = """Test parse with overloaded parameters.
    :param x: the first param
    :param y: the second param

    :return: None
    """

    docstring = parse(text, style=Style.sphinx)
    assert docstring.params[0].arg_name == "x"
    assert docstring.params[1].arg_name == "y"

    # Test that the docstring parses without error without
    # specifying a style
    docstring = parse(text)
    assert docstring.params[0].arg_name == "x"

# Generated at 2022-06-23 17:25:38.528239
# Unit test for function parse
def test_parse():
    f = open('/Users/mightymermaid/Documents/docstring_parser/tests/data/simple.doctest', 'r')
    text = f.read()
    print(parse(text))

# Generated at 2022-06-23 17:25:39.461179
# Unit test for function parse
def test_parse():
    """Test function parse"""
    assert True


# Generated at 2022-06-23 17:25:44.267125
# Unit test for function parse
def test_parse():
    actual = parse('''
    A simple function.

    Parameters:
        x (str): The first thing.
        y (str): The second thing.

    Returns:
        str: the sum

    ''')
    expected = Docstring(
        summary='A simple function.',
        meta={'Parameters': [
            ['x (str)', 'The first thing.'],
            ['y (str)', 'The second thing.'],
        ]},
        description=None,
        returns=[('str', 'the sum')],
        raises=[],
        warnings=[])
    assert actual == expected

# Generated at 2022-06-23 17:25:54.977319
# Unit test for function parse
def test_parse():
    assert parse('hello') == Docstring('hello')
    assert parse('hello\nworld') == Docstring('hello\nworld')
    assert parse('hello\nworld', style='numpy') == Docstring('hello\nworld')
    assert parse('hello\nworld', style='google') == Docstring('hello\nworld')
    assert parse('hello\nworld', style='auto') == Docstring('hello\nworld')

# Generated at 2022-06-23 17:26:03.040648
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Field
    ds = parse('"""Test\n:param name: the name\n:type name: str\n"""')
    assert len(ds.meta) == 2
    assert ds.meta[0] == Field(name='param', type_='the name',
                               default='', desc='')
    assert ds.meta[1] == Field(name='type', type_='name',
                               default='str', desc='')


# Generated at 2022-06-23 17:26:11.823706
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import google, numpy

    ret = parse("""Summarize the Test class here.

Longer description here.

Attributes:
    attr1 (str): Description of `attr1`.
    attr2 (List[int]): Description of `attr2`.

Methods:
    method1(param1, param2)
        Description of `method1`.
""", style=google)
    assert ret.summary == "Summarize the Test class here."
    assert ret.description == "Longer description here."
    assert ret.meta['methods'] == ['method1(param1, param2)']
    assert ret.meta['attributes'] == ['attr1 (str)', 'attr2 (List[int])']


# Generated at 2022-06-23 17:26:17.556113
# Unit test for function parse
def test_parse():
    test_docstring = parse("""
    Here is my docstring.

    :param str line1: this is first line of the parameter
    :param int line2: this is second line of the parameter

    :returns: nothing
    :rtype int
    """)
    assert test_docstring.short_description == "Here is my docstring."
    assert test_docstring.long_description == ""
    assert test_docstring.params[0].arg_type == "str"
    assert test_docstring.returns.type_name == "int"


# Generated at 2022-06-23 17:26:29.126758
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('\n') == Docstring()
    assert parse('\n\n\n') == Docstring()

    assert parse('First line of summary\n') == Docstring(
        summary='First line of summary')
    assert parse('First line of summary\n\n') == Docstring(
        summary='First line of summary')
    assert parse('First line of summary\n\nSecond line of summary') == Docstring(
        summary='First line of summary\n\nSecond line of summary')

    assert parse('Summary\n\nDescription') == Docstring(
        summary='Summary', description='Description')
    assert parse('Summary\n\nDescription\n\nArgs:') == Docstring(
        summary='Summary', description='Description', params=())