

# Generated at 2022-06-23 17:16:34.399807
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a function.

    Parameters
    ----------
    arg1 : str
        The first argument.
    arg2 : int
    
    Returns
    -------
    arg1
    '''
    parsed = parse(docstring)
    param = parsed.params[0]
    assert param.arg_name == 'arg1'
    assert param.type_name == 'str'
    assert param.description == 'The first argument.'
    assert param.default is None
    assert param.is_optional is False

    param = parsed.params[1]
    assert param.arg_name == 'arg2'
    assert param.type_name == 'int'
    assert param.description == ''
    assert param.default is None
    assert param.is_optional is False

    param = parsed.returns
   

# Generated at 2022-06-23 17:16:37.063598
# Unit test for function parse
def test_parse():
    assert parse("Text") == Docstring(Style.restructuredtext, "Text", [], [], [], [], [], [], [], [])

# Generated at 2022-06-23 17:16:46.142230
# Unit test for function parse

# Generated at 2022-06-23 17:16:47.698329
# Unit test for function parse
def test_parse():
    assert parse('test')


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:16:51.912289
# Unit test for function parse
def test_parse():
    text = '''"""The main parsing routine."""\n'''
    assert parse(text).short_description == 'The main parsing routine.'
    return True

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:17:01.406446
# Unit test for function parse
def test_parse():
    docstring = \
"""Summary line.

Extended description of function.

Parameters
----------
arg1 : int
    Description of arg1
arg2 : str
    Description of arg2

Returns
-------
bool
    Description of return value

"""
    print (parse(docstring))
    print (parse(docstring,style=Style.numpy))
    print (parse(docstring,style=Style.google))
    print (parse(docstring,style=Style.pep257))
    print (parse(docstring,style=Style.rst))
    print (parse(docstring,style=Style.sphinx))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:07.995076
# Unit test for function parse
def test_parse():
    doc = """
    Args:
        x: first number
        y: second number
    """
    ds = parse(doc)
    assert(ds.args[0].name == 'x')
    assert(ds.args[1].name == 'y')
    assert(ds.args[0].desc == 'first number')
    assert(ds.args[1].desc == 'second number')
    assert(ds.ret.desc == None)

# Generated at 2022-06-23 17:17:13.138170
# Unit test for function parse
def test_parse():
    d = """\
    this is a test
    :param name: string
    :type name: str
    :param kwargs: keyword arguments
    :returns: a string
    :rtype: str
    """
    parsed = parse(d)
    assert parsed.params == {
        'name': 'string',
        'kwargs': 'keyword arguments',
    }
    assert parsed.returns == "a string"

# Generated at 2022-06-23 17:17:25.733102
# Unit test for function parse
def test_parse():
    """
    :returns: True if parse works, otherwise False
    """
    doc = parse("""
    :param param1: the first parameter
    :param param2: the second parameter
    :returns: description of what is returned
    :raises keyError: avoids any key errors
    """)
    assert str(doc) == """
:param param1: the first parameter
:param param2: the second parameter
:returns: description of what is returned
:raises keyError: avoids any key errors
    """.lstrip()
    assert doc.short_description == ""
    assert doc.long_description == ""
    assert doc.params[0].arg_name == "param1"
    assert doc.params[0].description == "the first parameter"
    assert doc.params[1].arg_name == "param2"
   

# Generated at 2022-06-23 17:17:36.103521
# Unit test for function parse
def test_parse():
    #1. test CodeStyle
    docstring = '''
    This is a simple program that creates a file.

    :param name: the name of the file to be created

    :returns: the name of the file'''
    ds = Docstring(docstring, style = Style.code)
    assert(ds.meta['name'] == 'the name of the file to be created')
    assert(ds.content == ['This is a simple program that creates a file.', '', ':param name: the name of the file to be created', '', ':returns: the name of the file'])

    #2. test NumPyStyle

# Generated at 2022-06-23 17:17:46.100713
# Unit test for function parse
def test_parse():
    # Test parse() with default auto style
    test_str1 = 'This is a test string'
    test_ret1 = parse(test_str1)
    assert test_ret1.short_description == test_str1

    # Test parse() with specified style
    test_str2 = '''
    This is a test string
    This is line 2 of
    the test string
    '''
    test_ret2 = parse(test_str2, style = Style.google)
    assert test_ret2.long_description == test_str2

    # Test parse() with unknown string
    test_str3 = 'Unable to parse this string'
    test_ret3 = parse(test_str3)
    assert test_ret3.short_description == test_str3

# Generated at 2022-06-23 17:17:51.798994
# Unit test for function parse
def test_parse():
    docstring = """The main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    docstring = parse(docstring)
    assert docstring is not None
    assert docstring.short_description == "The main parsing routine."
    assert docstring.long_description == ""
    assert docstring.params['text'] == 'docstring text to parse'
    assert docstring.params['style'] == 'docstring style'
    assert docstring.returns == 'parsed docstring representation'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:54.332930
# Unit test for function parse
def test_parse():
    # an example
    docstring = '''
    This is a docstring
    '''
    assert parse(docstring) == Docstring(
        'This is a docstring')

# Generated at 2022-06-23 17:18:05.789827
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring('')
    assert parse('') == Docstring('')
    assert parse('') == Docstring('')
    doc = Docstring('Text')
    assert parse('Text') == doc
    assert parse('') == Docstring('')
    doc = Docstring('Text\n')
    assert parse('Text') == doc
    doc = Docstring('Text')
    assert parse('Text\n') == doc
    assert parse('') == Docstring('')
    assert parse('\n') == Docstring('')
    assert parse('\n\n') == Docstring('')
    assert parse('\n\n') == Docstring('')
    assert parse('') == Docstring('')
    doc = Docstring('\nText\n')

# Generated at 2022-06-23 17:18:16.819873
# Unit test for function parse
def test_parse():
    '''Test for function parse.'''
    from docstring_parser.docstring import Docstring
    from docstring_parser.styles import NumpyStyle, GoogleStyle, PEP257Style

    docstring = \
        '''Short summary.
    
        Extended description.
    
        Parameters
        ----------
        arg1 : int
            Description of `arg1`
        arg2 : str
            Description of `arg2`
    
        Returns
        -------
        bool
            Description of return value
    
        '''
    assert parse(docstring) == Docstring(docstring)
    assert parse(docstring, style=NumpyStyle) == Docstring(docstring)
    assert parse(docstring, style=GoogleStyle) == Docstring(docstring)

# Generated at 2022-06-23 17:18:27.567464
# Unit test for function parse
def test_parse():
    text = """
    Example function with types documented in the docstring.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    result = parse(text, style=Style.google)
    assert len(result.meta) == 3
    assert result.meta[0].args == ['param1', 'param2']
    assert result.meta[0].annotation == 'int, str'
    assert result.meta[0].description == 'The first parameter.'
    assert result.returns.annotation == 'bool'
    assert result.returns.description == 'The return value. True for success, False otherwise.'
    result = parse(text, style=Style.numpy)

# Generated at 2022-06-23 17:18:32.817111
# Unit test for function parse
def test_parse():
    text = '''
    This is a list of all possible parameters,
    :param arg1: the first argument
    :param arg2: the second argument 
    :param arg3: the third argument
    :returns: returns a docstring
    '''
    style = Style.google
    assert parse(text, style).arguments == ['arg1', 'arg2', 'arg3']
    assert parse(text, style).returns == 'returns a docstring'


# Generated at 2022-06-23 17:18:39.469493
# Unit test for function parse
def test_parse():
    docstring = """
    Class for generating the Mapping with the number of occurrences of word as value.

    :param word: word to be classified
    :param word_dict: word dictionary used for classification
    :returns: Mapping with the number of occurrences of word as value.
    """
    docstring = parse(docstring)
    assert docstring.params['word'] == 'word to be classified'

# Generated at 2022-06-23 17:18:45.999513
# Unit test for function parse
def test_parse():
    # test parse with auto style
    s = '''
    :returns: parsed docstring representation
    '''
    d = parse(s)
    assert(d.content == '')
    assert(d.meta['returns'] == 'parsed docstring representation')

    # test parse with numpydoc style
    d = parse(s, style='numpy')
    assert(d.content == '')
    assert(d.meta['returns'] == 'parsed docstring representation')

# Generated at 2022-06-23 17:18:57.430185
# Unit test for function parse
def test_parse():
    docstring = """\
    Some summary line with a colon in it.

    :param str attr1: Description of `attr1`
    :type attr1: int
    :raises ValueError: if attr1 is invalid
    :returns: integer value of attr1
    :rtype: int
    :var str attr2: Description of `attr2`
    :vartype attr2: :class:`MyClass`
    :cvar int num1: Description of `num1`
    :ivar int num2: Description of `num2`
    :keyword str a: Description of `a`
    :kwarg str b: Description of `b`
    :example:
        Usage example::

            t = MyClass()
            t.attr1
            t.method1()
    """


# Generated at 2022-06-23 17:19:05.051930
# Unit test for function parse
def test_parse():
    """docstring for test_parse"""
    text = """
    :param path: path to the file to read
    :param mode: The mode in which to open the file.  Defaults to 'r'.
    """
    docstring = parse(text)
    assert docstring.params is not None
    assert docstring.params['path'].name == 'path'
    assert docstring.params['path'].desc == 'path to the file to read'


# Generated at 2022-06-23 17:19:11.972960
# Unit test for function parse
def test_parse():
    text = """This is a module docstring.
    This is the first paragraph of the docstring.

    This is the second.

    Args:
        arg1 (str): The first argument.
        arg2 (Optional[str]): The second argument. Defaults to None.

    Returns:
        bool: The return value. True for success, False otherwise.
        """
    if __name__ == "__main__":
        print(parse(text))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:15.528422
# Unit test for function parse
def test_parse():
    text = '''\
        This function does something
        very important.

        Args:
            arg1: the first argument
            arg2: the second argument

        Returns:
            None
        '''
    result = parse(text)
    print (result.long_description)

test_parse()


# Generated at 2022-06-23 17:19:17.853731
# Unit test for function parse
def test_parse():
    res=parse('this is a test ,''''''')
    assert res.params=='this is a test'

#Unit test for function parse with some error

# Generated at 2022-06-23 17:19:20.877799
# Unit test for function parse
def test_parse():
    assert parse("test_parse")  # No exception is success

if __name__ == "__main__":
    import pytest
    pytest.main()

# Generated at 2022-06-23 17:19:26.839968
# Unit test for function parse
def test_parse():
    doc = """     Summary line.
   
    Extended description.
    """
    docstring = parse(doc)
    assert docstring.short_description.raw == 'Summary line.'
    assert docstring.short_description.parsed == ['Summary line.']
    assert docstring.long_description.raw == 'Extended description.'
    assert docstring.long_description.parsed == ['Extended description.']

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:32.615093
# Unit test for function parse
def test_parse():
    text = '''
    This document describes how to parse docstring.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    assert parse(text, style='google').short_description == 'parse docstring'
    assert parse(text, style='reStructuredText').short_description == 'This document describes how to parse docstring.'

# Generated at 2022-06-23 17:19:37.985560
# Unit test for function parse
def test_parse():
    string = '''
    The method is used to parse the text input.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    assert(parse(string))
    assert(parse(' '))
    assert(parse('\n'))
    assert(parse('\n\n'))
    assert(parse(''))

# Generated at 2022-06-23 17:19:49.204282
# Unit test for function parse
def test_parse():
    text = '''\
    A docstring with a :param.
    
    :param param1: a parameter
    :param param2: another parameter
    
    :returns: a return value
    :raises Exception: always
    '''
    docstring = parse(text)
    assert docstring.text() == 'A docstring with a :param.'
    assert docstring.title() == 'A docstring with a :param.'
    assert docstring.short_description() == 'A docstring with a :param.'
    assert docstring.long_description() == ''
    assert docstring.parameters() == {
        'param1': 'a parameter',
        'param2': 'another parameter',
    }
    assert docstring.returns() == 'a return value'

# Generated at 2022-06-23 17:19:57.946321
# Unit test for function parse

# Generated at 2022-06-23 17:20:09.536238
# Unit test for function parse

# Generated at 2022-06-23 17:20:16.050572
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    from docstring_parser.styles import STYLES
    from docstrings import google_func, numpy_func, rest_func, doctest_func
    # import doctest
    # doctest.testmod()
    ds = parse(google_func)
    ds_style = ds.style
    print(ds)
    print(ds.meta.get('returns'))
    print(STYLES[ds_style].format(ds))
    assert True == True


# Generated at 2022-06-23 17:20:22.454184
# Unit test for function parse
def test_parse():
    assert parse("")
    assert parse("Summary")
    assert parse("Summary\n")
    assert parse("Summary\n\n\n")
    assert parse("Summary\n\n\nExtra\n")
    assert parse("Summary\nDescription.\n")
    assert parse("Summary\nDescription.\n\n")
    assert parse("Summary\n\nDescription.\n\n")
    assert parse("Summary\nDescription.\nExtra\n")
    assert parse("Summary\n\nDescription.\nExtra\n")
    assert parse("Summary\nDescription.\n\nExtra\n")

    try:
        assert parse("Summary\nDescription\nExtra")
    except Exception as e:
        print(e)
        pass

# Generated at 2022-06-23 17:20:34.030466
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Field, Parameter, ReturnValue
    from docstring_parser.styles import google

    docstring = parse("""
        :param name: 
        :param age: 
        :type name: str
        :type age: int
        :returns: str
        :rtype: str
        """)
    assert docstring.short_description == ""
    assert docstring.long_description == ""

# Generated at 2022-06-23 17:20:42.719855
# Unit test for function parse
def test_parse():
    text = """
    Features:
        1. Feature one
        2. Feature two
    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    """
    style = Style.numpy
    docstring = parse(text, style)
    assert docstring.summary == 'Features:\n\t1. Feature one\n\t2. Feature two'
    assert docstring.extended_summary == 'Features:\n\t1. Feature one\n\t2. Feature two'
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].annotation == 'int'
    assert docstring.params[0].description == 'The first argument.'

# Generated at 2022-06-23 17:20:43.950601
# Unit test for function parse
def test_parse():
    docstring = parse("""
Hello.
""")
    assert docstring == Docstring(summary="Hello.", description="")


# Generated at 2022-06-23 17:20:54.869851
# Unit test for function parse
def test_parse():
    # Create a test docstring
    test_doc = '''\
    This function has all the parameters and returns
    a value.
    :param param1: this has a type and a description
    :type param1: int or float
    :param param2: self-explanatory
    :returns: output of this amazing function
    '''
    # Parse the test docstring
    doc = parse(test_doc)
    # Make sure each subsection was parsed correctly
    assert doc.short_description == 'This function has all the parameters and returns a value.'
    assert doc.long_description == ''
    assert doc.args == []

# Generated at 2022-06-23 17:21:02.674797
# Unit test for function parse
def test_parse():
    text = """Summary line.

Description of what the function does.

Parameters:
    arg1 (int): Description of arg1
    arg2 (str): Description of arg2

Returns:
    bool: Description of return value"""
    docstring = parse(text)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == 'Description of what the function does.\n'
    assert docstring.returns.arg_type == 'bool'
    assert docstring.returns.description == 'Description of return value'

# Generated at 2022-06-23 17:21:14.388655
# Unit test for function parse
def test_parse():
    # For example:
    # @name:
    text = """\
Short description.

    Long description.

    :param request:
        A django http request object.
    :type request: django.http.HttpRequest

    :returns:
        Something meaningful.
    :raises:
        An exception
"""
    # Then
    style = Style.parsed(text)
    assert style is Style.numpy
    docstring = parse(text)
    assert docstring.short_description.strip() == "Short description."
    assert docstring.long_description.strip() == "Long description."
    assert docstring.keys() == ['param', 'returns', 'raises']
    assert docstring['param'][0].arg_name == "request"

# Generated at 2022-06-23 17:21:21.669898
# Unit test for function parse
def test_parse():
    import pprint
    text = '''The Pygments reStructuredText directive

.. pygments:: python
  :linenos:
  :lineno-start: 5
  :emphasize-lines: 3,5-7

  def f(x):
  5  return x**2
  6
  7
  8  f(5)
  9
'''
    pprint.pprint(parse(text))

# Generated at 2022-06-23 17:21:25.574974
# Unit test for function parse
def test_parse():
    doc = '''    This is a sample docstring.
    Here is the second line.
    '''
    docstring = parse(doc, style='numpy')
    summary = docstring.short_description
    assert summary == 'This is a sample docstring.'
    

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:21:30.538720
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a multi-line docstring.

    Parameters
    ----------
    one : str
        The first parameter.
    two : str
        The second parameter.
    '''

    # Try to parse with all different styles
    for style in STYLES.keys():
        docstring_tuple = parse(docstring, style)
        assert isinstance(docstring_tuple, Docstring)

# Generated at 2022-06-23 17:21:41.711304
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Style
    docstring = parse("This is a function")
    assert docstring.short_description == "This is a function" and docstring.style == Style.numpy
    docstring1 = parse("Method for testing purposes")
    assert docstring1.short_description == "Method for testing purposes" and docstring1.style == Style.numpy
    docstring2 = parse("Implementation of the __init__ method")
    assert docstring2.short_description == "Implementation of the __init__ method" and docstring2.style == Style.numpy
    docstring3 = parse("Implementation of the __init__ method", Style.google)
    assert docstring3.short_description == "Implementation of the __init__ method" and docstring3.style == Style.numpy

# Generated at 2022-06-23 17:21:50.855112
# Unit test for function parse
def test_parse():
    text = '''
    Test parse docstring.

    :param str text: docstring text to parse
    :param Style style: docstring style
    :returns: parsed docstring representation
    '''
    result = parse("text")
    assert result is not None, 'The result of parse("text") is None'

if __name__ == "__main__":
    text = '''
    Test parse docstring.

    :param str text: docstring text to parse
    :param Style style: docstring style
    :returns: parsed docstring representation
    '''
    result = parse(text)
    print(result)

# Generated at 2022-06-23 17:21:58.227776
# Unit test for function parse
def test_parse():
    text = '''Test func
    :param arg1: first arg
    :param arg2: second arg
    :return: what this function returns
    '''
    print("Unit testing for parse")
    docstring = parse(text)
    assert len(docstring.args) == 2
    assert docstring.meta["return"] == "what this function returns"
    assert docstring.args[0].arg_name == "arg1"
    assert docstring.args[0].description == "first arg"
    assert docstring.args[1].arg_name == "arg2"
    assert docstring.args[1].description == "second arg"
    assert docstring.description == "Test func"

# Generated at 2022-06-23 17:22:07.943288
# Unit test for function parse
def test_parse():
    docstring = parse('\n'.join([
        "The ``docstring_parser`` module provides a single function that",
        "implements docstring parsing. The function returns a namedtuple with",
        "the following attributes:",
        "",
        "* ``short_description``: Single line summary of the docstring.",
        "* ``long_description``: Optional multi-line description.",
        "* ``params``: Names and descriptions of parameters.",
        "* ``returns``: Names and descriptions of return values.",
        "* ``raises``: Names and descriptions of exceptions.",
        "* ``meta``: Names and descriptions of additional attributes.",
    ]))
    assert docstring.short_description == 'The ``docstring_parser`` module provides a single function that implements docstring parsing.'

# Generated at 2022-06-23 17:22:18.194826
# Unit test for function parse
def test_parse():
    """Test function parse"""
    import pytest

    # test Style.auto
    text1 = '''
    Test the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    docstring1 = Docstring(
        content='\nTest the docstring into its components.',
        params=['text: docstring text to parse',
                'style: docstring style'],
        returns='parsed docstring representation',
        meta=None
    )
    assert parse(text1) == docstring1
    assert parse(text1, style=Style.auto) == docstring1
    assert parse(text1, style=Style.google) == docstring1


# Generated at 2022-06-23 17:22:29.917765
# Unit test for function parse
def test_parse():
    text = """This function does one thing and another

:param param1: This is the first parameter.
:param param2: This is a second parameter.
:returns: This is what is returned.
:raises keyError: We get a key error
    and this is a second line of the docstring
"""
    doc = parse(text)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.meta['param1'])
    print(doc.meta['param2'])
    print(doc.meta['returns'])
    print(doc.meta['keyError'])
    print(doc.return_type) # default None

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:39.591767
# Unit test for function parse
def test_parse():
    example = """Summary line.

Extended description.

:param arg1: Description of arg1
:type arg1: str
:param arg2: Description of arg2
:type arg2: List[int]
:returns: Description of return value
:rtype: int
:raises keyError: raises an exception
"""

    docstring = parse(example)

    assert docstring.summary == 'Summary line.'
    assert docstring.description == 'Extended description.'
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_type == str
    assert docstring.params['arg2'].arg_type == list
    assert len(docstring.returns) == 1
    assert docstring.returns[0].arg_type == int

# Generated at 2022-06-23 17:22:42.180177
# Unit test for function parse
def test_parse():
    text = """The function's docstring."""
    output = parse(text)
    correct_output = Docstring(summary="The function's docstring.")
    assert output == correct_output

# Generated at 2022-06-23 17:22:50.218377
# Unit test for function parse
def test_parse():
    """Test of parse function."""
    text = """\
A simple function.

:param arg1: first arg
:param arg2: second arg
:returns: None
"""
    docstring = parse(text)
    assert docstring.short_description == "A simple function."
    assert docstring.long_description.startswith("A simple function.")
    assert len(docstring.params) == 2
    assert docstring.params.keys() == ['arg1', 'arg2']
    assert docstring.params.values() == ["first arg", "second arg"]
    assert docstring.params.items() == [('arg1', "first arg"), ('arg2', "second arg")]
    assert docstring.returns == ["None"]
    assert docstring.return_type == "None"

# Generated at 2022-06-23 17:22:58.222985
# Unit test for function parse
def test_parse():
    docstring = """description
    :param arg1: description1
    :type arg2: description2
    :returns:
    :rtype: """
    ret = parse(docstring, style=Style.google)
    assert (ret.short_description == "description")
    assert (len(ret.sections) == 3)
    assert (ret.sections[0].title == "Parameters")
    assert (ret.sections[0].content == "arg1: description1\n")
    assert (ret.sections[1].title == "Types")
    assert (ret.sections[1].content == "arg2: description2\n")
    assert (ret.sections[2].title == "Returns")

# Generated at 2022-06-23 17:23:03.870291
# Unit test for function parse
def test_parse():
    text = '''\
        Module summary goes here.
        
        Parameters
        ----------
        arg1 : int
            Description of arg1
        arg2 : str
            Description of arg2
        
        Returns
        -------
        bool
            Description of return value
        '''
    # print(parse(text))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:05.996772
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()
 
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:23:17.692702
# Unit test for function parse
def test_parse():
    text = """\
        Single-line docstring.
        """
    d = parse(text)
    assert d.short_description == 'Single-line docstring.'
    assert not d.long_description
    assert not d.meta
    assert not d.params
    assert not d.returns
    assert not d.yields
    text = """\
        Single-line docstring.

        More description.
        """
    d = parse(text)
    assert d.short_description == 'Single-line docstring.'
    assert d.long_description == 'More description.'
    text = """\
        Single-line docstring.

        :type name: str
        :param name: name of the object
        """
    d = parse(text)
    assert d.short_description == 'Single-line docstring.'
   

# Generated at 2022-06-23 17:23:24.664682
# Unit test for function parse
def test_parse():
    """Testing docstring parsing."""

    from docstring_parser.common import Section, Param, Return, Else

    PARSED = parse("""Summary line.

    Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value

    Raises:
        AttributeError: The ``AssertionError`` exception is raised.

        AnotherError: The ``AnotherError`` exception is raised.

    """)

    assert PARSED.summary == "Summary line."
    assert PARSED.description == "Extended description."
    assert PARSED.extended_description == []

# Generated at 2022-06-23 17:23:31.008527
# Unit test for function parse
def test_parse():
    docstring = '''A docstring for testing
    :param foo: a parameter"""
    '''
    doc = parse(docstring)
    assert(doc.description == 'A docstring for testing\n')
    assert(len(doc.meta) == 1)
    param = doc.meta[0]
    assert(param.type == 'param')
    assert(param.name == 'foo')
    assert(param.description == 'a parameter')

# Generated at 2022-06-23 17:23:34.130732
# Unit test for function parse
def test_parse():
    text = '''
    The parse method follows the below example.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    assert parse(text)



# Generated at 2022-06-23 17:23:45.505101
# Unit test for function parse

# Generated at 2022-06-23 17:23:52.669511
# Unit test for function parse

# Generated at 2022-06-23 17:23:53.269695
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:23:58.867185
# Unit test for function parse
def test_parse():
    doc = """
    Test function to understand the parse function of the parser
    Args:
        a: an int
        b: a string
    """
    res = parse(doc)
    assert res.short_description == "Test function to understand the parse function of the parser"
    assert res.args[0].name == "a"
    assert res.args[0].type == "an int"
    assert res.args[1].type == "a string"

# Generated at 2022-06-23 17:24:02.915441
# Unit test for function parse
def test_parse():
    text = "This is a test docstring."
    assert parse(text) is not None

if __name__ == "__main__":
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-23 17:24:14.655152
# Unit test for function parse
def test_parse():
    text = '''
This function does something.

:param int arg1: the first value
:param arg2: the second value
:returns: description of return value
:raises KeyError: when a key error
    '''

    docstring = parse(text)

    assert docstring.short_description == 'This function does something.'
    assert docstring.long_description == ''
    assert docstring.params['arg1'].type_name == 'int'
    assert docstring.params['arg1'].description == 'the first value'
    assert docstring.params['arg2'].type_name == 'UNKNOWN'
    assert docstring.params['arg2'].description == 'the second value'
    assert docstring.returns.type_name == 'UNKNOWN'

# Generated at 2022-06-23 17:24:17.045679
# Unit test for function parse
def test_parse():
    from . import test_styles
    test_styles.test(parse)

# Generated at 2022-06-23 17:24:27.545509
# Unit test for function parse
def test_parse():
    class_docstring = """
    Class docstring appear as such.
    
    Parameters
    ----------
    \x1b[1mparam1\x1b[0m : \x1b[4mint\x1b[0m
        Parameter 1.
    \x1b[1mparam2\x1b[0m : \x1b[4mstr\x1b[0m, optional
        Parameter 2.
    
    \x1b[1mparam3\x1b[0m : \x1b[4mobject\x1b[0m
        Parameter 3.\n
    """


# Generated at 2022-06-23 17:24:34.682680
# Unit test for function parse
def test_parse():
    doc_text = """
    
            
    
    
        
    
    
    This is a sample docstring.
    """

    doc = parse(doc_text)
    assert doc.short_description is None
    assert doc.long_description is None
    assert len(doc.meta) == 0
    assert len(doc.params) == 0
    assert len(doc.returns) == 0

    doc_text = """
    
            
    
    
        
    
    
    This is a sample docstring.
    """

    doc = parse(doc_text)
    assert doc.short_description is None
    assert doc.long_description is None
    assert len(doc.meta) == 0
    assert len(doc.params) == 0
    assert len(doc.returns) == 0



# Generated at 2022-06-23 17:24:45.592069
# Unit test for function parse
def test_parse():
    import os
    import sys
    import unittest

    sys.path.insert(0, os.path.abspath('../../docstring_parser'))
    from docstring_parser.parser import parse
    from docstring_parser.common import Style
    from docstring_parser.styles import NumpyStyle


# Generated at 2022-06-23 17:24:56.330992
# Unit test for function parse
def test_parse():
    text1 = """
    This is a module docstring.

    :param arg1: Description of arg1
    :type arg1: int
    :param arg2: Description of arg2
    :param arg3: Description of arg3
    :returns: None
    :raises keyError: raises KeyError
    """
    text2 = """This is a module docstring."""
    text3 = """This is also a module docstring.
                But it's seperated by lines.
                """
    obj = parse(text1)
    assert obj.short_description == "This is a module docstring."
    assert obj.long_description == ""

# Generated at 2022-06-23 17:25:01.031194
# Unit test for function parse
def test_parse():
    """Test a parsing of a simple docstring."""
    doc = ':param x: number to double\n:type x: int\n:returns: doubled\n:rtype: int'
    parsed = parse(doc)
    print(parsed)
    print(parsed.metadata)
    print(parsed.params)
    print(parsed.returntype)
    print(parsed.returns)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:25:05.219536
# Unit test for function parse
def test_parse():
    text = "Example docstring.\n\nArgs:\n    arg1: int\n    arg2: str"
    assert parse(text) == parse(text, style=Style.pep257)

# Generated at 2022-06-23 17:25:16.021042
# Unit test for function parse
def test_parse():
    """ Unit test for parse function """
    docstring_text = """Docstring summary.
    [extended_summary]
    Parameters
    ----------
    arg1 : str, required
        Description of `arg1`
    arg2 : :obj:`int`, optional
        Description of `arg2`, defaults to 1.
    Returns
    -------
    str
        Description of return value.
    """
    doc = parse(docstring_text)
    assert doc.summary == 'Docstring summary.'
    assert doc.extended_summary == '[extended_summary]'
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == 'arg1'
    assert doc.params[0].type_name == 'str'
    assert doc.params[0].description == 'Description of `arg1`'

# Generated at 2022-06-23 17:25:18.567461
# Unit test for function parse
def test_parse():
    input1 = """
    Unit test for function parse
    """
    d1 = parse(input1)
    print(d1)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:30.296174
# Unit test for function parse
def test_parse():
    from .test_styles import assert_equal, test_numpy
    test_numpy()
    from .test_styles import test_google
    test_google()
    from .test_styles import test_reST
    test_reST()
    parse("", Style.auto)
    assert_equal(parse("foo\n", Style.auto).short_description, "foo")
    parse("foo\n\nbar\n", Style.auto)
    assert_equal(parse("foo\n\nbar\n", Style.auto).short_description, "foo")
    assert_equal(parse("foo\n\nbar\n", Style.auto).long_description, "bar\n")
    assert_equal(parse("foo\n\nbar\n", Style.auto).meta, {})

# Generated at 2022-06-23 17:25:35.876574
# Unit test for function parse
def test_parse():

    docstrings = """
        Todo: this is a short description
            - item 1
            - item 2

        Args:
            filename (str): filename to load

        Returns
            str: the loaded file content
    """

    assert parse(docstrings, style=Style.numpy)


if __name__ == "__main__":
    print("Test function parse")
    test_parse()

# Generated at 2022-06-23 17:25:37.863631
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:44.660110
# Unit test for function parse
def test_parse():
    doc = """
    @summary: 使用 request 库进行网络请求
            这是一段描述, 接收到的返回结果将记录在 response 变量中
            这是另一段描述
    @param headers:
        name: Authorization
        value: JWT ${token}
        description: 用户授权
        required: 1
    @param params:
        name: username
        value: ${username}
    """
    docstring = parse(doc)
    print(docstring)
    print(docstring.params)

if __name__ == "__main__":
    test

# Generated at 2022-06-23 17:25:55.006568
# Unit test for function parse

# Generated at 2022-06-23 17:25:58.316267
# Unit test for function parse
def test_parse():
    text = """
    """

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:26:03.541330
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Style
    
    assert parse("""
        This is a method.
        """, style=Style.numpy).short_description == "This is a method."
    assert parse("""
        This is a method.

        @param a: parameter a
        @param b: parameter b
        """, style=Style.google).short_description == "This is a method."

# Generated at 2022-06-23 17:26:09.032465
# Unit test for function parse
def test_parse():
    text = '''
    One line summary.

    Extended description.

    :param arg1: argument 1.
    :param arg2: argument 2.
    :returns: a string.
    :raises keyError: raises an exception.
    '''
    assert len(parse(text).args) == 2
    assert len(parse(text).returns) == 1
    assert len(parse(text).raises) == 1

# Generated at 2022-06-23 17:26:17.439550
# Unit test for function parse
def test_parse():
    p = parse("""Simple multi-line docstring.
    This function does some useful things.
    :param int x: The meaning of life.
    :type bool y: True.
    :param z: Meh.
    :returns: None
    :rtype: None
    :raises ValueError: If anything goes wrong.

    .. versionadded:: 1.2.0
    """)
    assert p.short_description == "Simple multi-line docstring."
    assert p.long_description == "This function does some useful things."
    assert len(p.meta.keys()) == 7
    assert p.meta['param'][0].arg_name == 'x'
    assert p.meta['param'][0].arg_type == 'int'
    assert p.meta['param'][0].description == 'The meaning of life.'


# Generated at 2022-06-23 17:26:29.126038
# Unit test for function parse
def test_parse():
    def foo(): pass
    foo.__doc__ = """
    One liner.

    Extended description.

    Args:
        foo (int): Describes `foo`
        bar (str): Describes `bar`

    Returns:
        str: Describes return value
    """
    parsed = parse(foo.__doc__)
    assert parsed.short_description == "One liner."
    assert parsed.long_description == 'Extended description.'
    assert parsed.returns.type_name == 'str'
    assert parsed.returns.description == 'Describes return value'
    assert len(parsed.params) == 2
    assert parsed.params[0].arg_name == 'foo'
    assert parsed.params[1].arg_name == 'bar'
    assert parsed.params[0].type_name == 'int'
   