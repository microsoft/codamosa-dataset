

# Generated at 2022-06-23 17:16:33.905647
# Unit test for function parse
def test_parse():
    doct = """$ Yields
               :return: 
               :rtype: list
               $ Parameters
               :param str arg1: The first argument.
               :param str arg2: The second argument.
               :param int arg3: The third argument (defaults to 0).
               $ Raises
               :raises ValueError: If `arg2` is equal to `arg1`.
               :raises RuntimeError: If `arg3` is not a number.
               $ Notes
               Here we have a note.
               It spans multiple lines.
               $ Examples
               >>> get_me_list(1,2,3)
               [1,2,3]"""
    
    
    res = parse(doct, style = Style.numpy)

# Generated at 2022-06-23 17:16:44.077304
# Unit test for function parse
def test_parse():
    # Unit test: docstring style (from Sphinx)
    docstring_text = '''
    test_parse()

    :param  style: docstring style
    :returns: parsed docstring representation
    '''
    actual_docstring = parse(docstring_text)

    expected_docstring = Docstring(
        short_description='test_parse()',
        long_description='',
        meta=[['param', 'style', 'docstring style']],
        returns=[['returns', 'parsed docstring representation']],
        examples=[],
        attributes=[],
        methods=[],
        see_also=[],
        warning=[],
        notes=[],
        notes_by_section={},
        todos=[],
        todos_by_section={},
    )

    assert actual_docstring == expected_docstring

# Generated at 2022-06-23 17:16:47.954988
# Unit test for function parse
def test_parse():
    docstring = '''Test Docstring
    Meta 1: Value1
    Meta 2: Value2

    Description
    '''

    parse(docstring)



# Generated at 2022-06-23 17:16:58.911301
# Unit test for function parse
def test_parse():
    print('Unit test for function parse:')

# Generated at 2022-06-23 17:17:06.218164
# Unit test for function parse
def test_parse():
    text="""
    This module provides a pluggable interface for parsing
    docstrings and returning the standard metadata.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    print(parse(text))
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-23 17:17:10.898809
# Unit test for function parse
def test_parse():
    d = parse('test()\n    :param a: test\n    :return: test')
    assert d.short_description == 'test()'
    assert d.long_description == ''
    assert d.meta['param'] == ['a']
    assert d.meta['return'] == ['test']

# Generated at 2022-06-23 17:17:13.333095
# Unit test for function parse
def test_parse():
    """Test for parse function"""
    assert parse("") == parse("\n")


# Generated at 2022-06-23 17:17:25.854496
# Unit test for function parse

# Generated at 2022-06-23 17:17:27.052519
# Unit test for function parse
def test_parse():
    from docstring_parser.__main__ import main
    main()

# Generated at 2022-06-23 17:17:31.013068
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == """Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation"""


# Generated at 2022-06-23 17:17:35.655264
# Unit test for function parse
def test_parse():
    """Test parse(text,style)."""
    text = """\n
        This is the example
        :param name1: description1
        :returns: description2
        """
    docstring = parse(text)
    assert docstring.description == 'This is the example'
    assert docstring.params['name1'].description == 'description1'
    assert docstring.retur

# Generated at 2022-06-23 17:17:41.847940
# Unit test for function parse
def test_parse():
    # unit test for function parse
    try:
        parse("")
    except ParseError:
        pass
    else:
        raise AssertionError("ParseError not raised")
    with open("tests/data/google.txt") as f:
        parse(f.read(), 'google')
    with open("tests/data/google.txt") as f:
        parse(f.read())

# Generated at 2022-06-23 17:17:51.977822
# Unit test for function parse
def test_parse():
    docstring = """One line summary.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of arg1

    arg2 : str
        Description of arg2

    Returns
    -------
    int
        Description of return value
    """
    doc = parse(docstring)
    if doc.short_description != "One line summary.":
        print("Parse short_description error")
    if doc.long_description != "Extended description.":
        print("Parse long_description error")
    if doc.params[0].arg_name != "arg1":
        print("Parse params error")
    if doc.returns.return_type != "int":
        print("Parse returns error")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:54.496117
# Unit test for function parse
def test_parse():
    docstring = parse('It\'s a test')
    assert docstring.short_description == "It's a test"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:18:00.004414
# Unit test for function parse
def test_parse():
    text = '''
        """
        short description

        long description
        """
    '''
    docstring = parse(text, style='google')
    assert docstring.short_description == 'short description'
    assert docstring.long_description == 'long description'



# Generated at 2022-06-23 17:18:09.811004
# Unit test for function parse

# Generated at 2022-06-23 17:18:19.567973
# Unit test for function parse
def test_parse():
    print("Unit test for parse.")
    assert(parse("""
    This is a test docstring
    """) == Docstring(
        content='This is a test docstring',
        description=None,
        returns=None,
        raises=None,
        meta={}
    ))


# Generated at 2022-06-23 17:18:25.208307
# Unit test for function parse
def test_parse():
    text = '''\
    """
    Summary line.
     
    Extended description of function.
    """
    '''
    docstring = parse(text)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == 'Extended description of function.'
    assert docstring.meta == {}


# Generated at 2022-06-23 17:18:33.525797
# Unit test for function parse
def test_parse():
    text = """
    This is a complete example of a reStructuredText docstring.
    :param int n: a parameter
    :param str s: a string parameter
    :returns: a return value
    :rtype: int
    :raises UserWarning: if the value of `n` is negative
    """

# Generated at 2022-06-23 17:18:45.056100
# Unit test for function parse
def test_parse():
    comment = '''
        Args:
            a: extra arg

        Returns:
            str: a string
    '''

    ans = parse(comment)
    print(ans)
    print(ans.meta)
    print(type(ans.meta))
    print(ans.meta['Args'])
    print(type(ans.meta['Args'])) 
    print(ans.meta['Args'][0]['name'])
    print(type(ans.meta['Args'][0]['name']))
    print(ans.meta['Returns'][0]['name'])
    print(type(ans.meta['Returns'][0]['name']))
    assert(ans.meta['Args'][0]['name'] == 'a')
    assert(ans.meta['Returns'][0]['name'] == 'str')

# Generated at 2022-06-23 17:18:46.154133
# Unit test for function parse
def test_parse():
    assert(parse("fjkdslajf") is None)


# Generated at 2022-06-23 17:18:57.582860
# Unit test for function parse
def test_parse():
    text = """\
    This is a summary.

    :param name: name

    :raises Exception: if something

    :returns: something
    """
    assert parse(text, Style.google).short_description == "This is a summary."

    text = """\
    This is a summary.
    :returns: something
    """
    assert parse(text, Style.google).short_description == "This is a summary."
    assert parse(text, Style.google).returns == "something"

    text = """\
    This is a summary.

    This is a description.

    :returns: something
    """
    assert parse(text, Style.google).short_description == "This is a summary."
    assert parse(text, Style.google).long_description == "This is a desctiption."


# Generated at 2022-06-23 17:19:09.678374
# Unit test for function parse
def test_parse():
    example_doc = '''
    This is a simple example.

    Important words are *italics* and **bold**.
    Other words are code `like this`.

    Examples:
        An example after a blank line.

        Another example.

    The last example has no blank line.

    Raises:
        ValueError: This is an exception.
        AnotherError: This is another exception.

    Yields:
        str: This is a return value.
        This is its description.
    '''


# Generated at 2022-06-23 17:19:13.788566
# Unit test for function parse
def test_parse():
    # Setup docstring text
    text = """
    This is the summary
    DETAILS
    This is more details.
    :param url: url
    :param xxx:
    :param yyy:
    :param zzz:
    """
    # Parse the docstring text
    doc = parse(text)
    # Check the parsed docstring
    # Summary must be equal to the first line
    assert doc.summary == 'This is the summary', "Summary mismatch"
    # Details must be equal to the second line
    assert doc.details == 'This is more details.', "Details mismatch"
    # Params
    # Must contain 'url', 'xxx', 'yyy' and 'zzz' elements
    assert 'url' in doc.params
    assert 'xxx' in doc.params
    assert 'yyy' in doc.params

# Generated at 2022-06-23 17:19:16.443026
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()


# Generated at 2022-06-23 17:19:26.951247
# Unit test for function parse
def test_parse():
    doc = parse('''This is a module docstring,
    This is the second line.
    ''')
    assert doc.description == 'This is a module docstring,\nThis is the second line.'

    doc = parse('''This is a module docstring,
    This is the second line.''')
    assert doc.description == 'This is a module docstring,\nThis is the second line.'

    doc = parse('''This is a module docstring,
This is the second line.''')
    assert doc.description == 'This is a module docstring,\nThis is the second line.'

    doc = parse('''This is a module docstring,

This is the second line.''')
    assert doc.description == 'This is a module docstring,\n\nThis is the second line.'


# Generated at 2022-06-23 17:19:37.564012
# Unit test for function parse
def test_parse():
    text = """
    The first line is a short summary of the module's purpose.
    This line can be on the same line as the opening quotes or on the next
    line.

    If you have a longer summary (a paragraph or so), it can come next.
    Just like this one.

    If you have a third paragraph, it can come next.
    Just like this one.

    :param str arg1: the first value
    :param str arg2: the second value
    :raises ValueError: if arg1 equals arg2
    :returns: the return value
    :rtype: bool
    """
    docstring = parse(text)
    assert docstring.short_description == "The first line is a short summary of the module's purpose."

# Generated at 2022-06-23 17:19:38.062990
# Unit test for function parse
def test_parse():
    parse('test')

# Generated at 2022-06-23 17:19:43.998617
# Unit test for function parse
def test_parse():
    s = """
        Short description.

        Args:
            arg1 (int): Description of arg1
            arg2 (str): Description of arg2
        Returns:
            str: Description of return value.
    """
    d = parse(s, style=Style.sphinx)
    assert d.description == ["Short description."]
    assert len(d.meta) == 2
    assert d.returndoc == ["Description of return value."]
    assert len(d.errors) == 0

# Generated at 2022-06-23 17:19:50.660263
# Unit test for function parse
def test_parse():
    expected = Docstring()
    expected.short_description = 'First line.'
    expected.long_description = ('Describes the module.\n\n'
                                 'With multiple lines.')
    expected.style = Style.google
    assert parse('''
        First line.

        Describes the module.

        With multiple lines.
        ''') == expected

# Generated at 2022-06-23 17:19:51.458458
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:19:55.110785
# Unit test for function parse
def test_parse():
    import sys
    import os
    import doctest
    sys.path.append(os.path.dirname(os.path.abspath(__file__))+'/../')
    from docstring_parser import parse
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 17:20:00.995815
# Unit test for function parse
def test_parse():
    """Test the parsing function."""
    test_text ="""This is a test
    This is the second line of the test."""
    result = parse(test_text, Style.google)
    assert result.short_description == 'This is a test'
    assert result.long_description == 'This is the second line of the test.'

# Generated at 2022-06-23 17:20:07.510206
# Unit test for function parse
def test_parse():
    text = """
    Some text
    :param integer val: some param
    :returns: some return
    """
    docstring = parse(text,Style.numpy)
    assert docstring.short_description == "Some text"
    assert docstring.long_description == ""
    assert docstring.params[0].args == "integer val"
    assert docstring.params[0].description == "some param"
    assert docstring.returns[0].description == "some return"



# Generated at 2022-06-23 17:20:17.575729
# Unit test for function parse
def test_parse():
    # Test 1
    input_text = '''\
    This is a short description.
    
    This is a long description.
    
    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    
    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    docstring = parse(input_text)
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == '\nThis is a long description.'
    assert docstring.returns.type_name == 'bool'
    assert docstring.returns.description == 'The return value. True for success, False otherwise.'
    assert len(docstring.arguments) == 2

# Generated at 2022-06-23 17:20:18.786572
# Unit test for function parse
def test_parse():
    # Basic test
    print(parse.__doc__)



# Generated at 2022-06-23 17:20:26.646827
# Unit test for function parse
def test_parse():
    from docstring_parser.styles._pep257 import PEP257Parser
    from docstring_parser.styles._google import GoogleParser
    from docstring_parser.styles._numpy import NumpyParser

    def get_failure_list(parser):
        try:
            parser.parse_parameters('Args:'.split())
        except ParseError as e:
            return e.failure_list


# Generated at 2022-06-23 17:20:30.410964
# Unit test for function parse
def test_parse():
    d = parse("""
    Hello this is a docstring.
    """)
    assert str(d) == """
Hello this is a docstring.
    """, str(d)
    assert d.summary == "Hello this is a docstring."



# Generated at 2022-06-23 17:20:40.413995
# Unit test for function parse
def test_parse():
    text = '''
    This module provides the :class:`A` class.

    :param ``Param``:
        Description of the parameter.
    :return:
        Description of return value.
    :raises ``Exception``:
        Description of the exception.
    '''
    docstring = parse(text)
    assert docstring.summary == 'This module provides the :class:`A` class.'
    assert docstring.params[0].name == 'Param'
    assert docstring.returns.type_name == 'return'
    assert docstring.raises[0].type_name == 'Exception'

    # test the error output
    text = 'a\n\n\n'

# Generated at 2022-06-23 17:20:52.530242
# Unit test for function parse
def test_parse():
    docstring2 = parse(docstring)
    print(docstring2)
    print(docstring2.summary)
    for param in docstring2.params:
        print(param.name)
    for param in docstring2.params:
        print(param.value)
    print(docstring2.meta.get('returns', [''])[0])
    print(docstring2.meta.get('raises', [''])[0])
    print(docstring2.meta.get('see_also', [''])[0])
    print(docstring2.meta.get('deprecated', [''])[0])
    print(docstring2.meta.get('note', [''])[0])
    print(docstring2.meta.get('example', [''])[0])

# Generated at 2022-06-23 17:20:55.746873
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    para = """This is a test docstring.
    It is a little bit long.
    """
    print(parse(para))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:21:07.127458
# Unit test for function parse
def test_parse():
    docstring = """Single line docstring."""
    docstring2 = """
        This is a
        multi-line docstring.
        """
    docstring3 = """
        This is a
        multi-line docstring
        with a blank line.

        """
    docstring4 = """
        This is a multi-line docstring.
        With a blank line.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.
        """
    docstring5 = """
        This is a multi-line docstring.
        With a blank line.

        Args:
            arg1 (int): The first argument.
        """

# Generated at 2022-06-23 17:21:10.034787
# Unit test for function parse
def test_parse():
    text = "def test_foo():\n    \"\"\"Return foo.\n    @a:bar\n    \"\"\""
    test_docstring = parse(text)
    assert test_docstring.short_desc == 'Return foo.'
    assert test_docstring.long_desc == ''
    assert test_docstring.meta == {'a':'bar'}
    assert test_docstring.returns == ''
    assert test_docstring.raises == ''

# Generated at 2022-06-23 17:21:11.229346
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:21:19.163525
# Unit test for function parse
def test_parse():
    import pytest
    with pytest.raises(ParseError):
        parse('')
    with pytest.raises(ParseError):
        parse('\n')
    with pytest.raises(ParseError):
        parse('\n\n')
    with pytest.raises(ParseError):
        parse('\n\n\n')
    with pytest.raises(ParseError):
        parse('\n\n\n\n')
    doc = parse('abc')
    assert doc.short_desc == 'abc'
    assert doc.long_desc is None
    assert doc.meta == {}
    doc = parse('\nabc\n')
    assert doc.short_desc == 'abc'
    assert doc.long_desc is None
    assert doc.meta == {}

# Generated at 2022-06-23 17:21:27.528274
# Unit test for function parse
def test_parse():
    text = """This is a docstring.
    :param int x: this is a param
    :type x: int
    :returns: None
    """
    print(parse(text,  Style.numpy))
    text = """This is another docstring.
    :param int x: this is a param
    :param str y: this is also a param
    :type x: int
    :returns: None"""
    print(parse(text,  Style.numpy))
    text = """This is another docstring.
    :param int x: this is a param
    :param str y: this is also a param
    :returns: None"""
    print(parse(text,  Style.numpy))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:21:38.357856
# Unit test for function parse
def test_parse():
    test_docstring = '''
    Hello world.

    :param name: your name
    :type name: str
    :returns: hello
    :rtype: str
    '''
    parsed_docstring = parse(test_docstring)
    assert parsed_docstring.short_description == 'Hello world.\n'
    assert parsed_docstring.long_description == ''
    assert parsed_docstring.meta['args'] == [{'name': 'name', 'type': 'str'}]
    assert parsed_docstring.meta['returns']['type'] == 'str'
    assert parsed_docstring.meta['returns']['annotation'] == 'hello'


# Generated at 2022-06-23 17:21:42.701590
# Unit test for function parse
def test_parse():
    text = '''
        This is a simple test
        :param test: test
        '''
    doc = parse(text)
    assert isinstance(doc, Docstring)
    assert isinstance(doc.short_description, str)
    assert isinstance(doc.long_description, str)
    assert isinstance(doc.meta, list)
    assert isinstance(doc.meta, list)


# Generated at 2022-06-23 17:21:49.042416
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import ALL_STYLES
    docstr = '''\
First line.

The rest of the docstring.
'''
    for style in ALL_STYLES:
        doc = parse(docstr, style)
        assert doc.short_description == 'First line.'
        assert doc.long_description == 'The rest of the docstring.'

# Generated at 2022-06-23 17:21:52.997409
# Unit test for function parse
def test_parse():
    text = """
    :Module: test_parser
    :Synopsis: test the parser
    :Author: kevin li
    :Email: kevin.li@firefly.ai

    """
    docstring = parse(text)
    assert docstring.module == 'test_parser'
    assert docstring.author == 'kevin li'
    assert docstring.email == 'kevin.li@firefly.ai'

    text = """
test the parser

Parameters
----------
input_path: str
    input file path
output_path: str
    output file path
    """
    docstring = parse(text)
    assert docstring.parameters[0].name == 'input_path'
    assert docstring.parameters[0].type_name == 'str'

# Generated at 2022-06-23 17:21:59.860109
# Unit test for function parse
def test_parse():
    ds = parse('The `parse` function is a function.\n\n')
    assert ds.short_description == 'The `parse` function is a function.'
    assert ds.long_description == ''
    ds = parse('The `parse` function is a function.\n\n'
               'And this is a long description.')
    assert ds.short_description == 'The `parse` function is a function.'
    assert ds.long_description == 'And this is a long description.'
    ds = parse('The `parse` function is a function.\n'
               '  Args:\n'
               '    text: docstring text to parse\n'
               '    style: docstring style\n'
               '  Returns:\n'
               '    parsed docstring representation\n')
    assert ds

# Generated at 2022-06-23 17:22:05.691137
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Param, Return
    from docstring_parser.styles import Style
    raw = '''
    :param str a: just a test
    :returns: nothing useful
    '''
    #print(parse(raw, style=Style.auto))
    assert parse(raw).params == [Param('a', 'just a test', 'str', None)]

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:16.377770
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    from docstring_parser.styles.google import GoogleStyle, GoogleDocstring

    docstring = r"""One line summary.

    Extended summary
    on multiple lines.

    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`

    Returns:
        bool: Description of return value

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `arg2` is equal to `arg1`.

    .. _PEP 257:
        https://www.python.org/dev/peps/pep-0257/

    .. _Google Python Style Guide:
        http://google.github.io/styleguide/pyguide.html
    """

# Generated at 2022-06-23 17:22:24.112618
# Unit test for function parse
def test_parse():
    """Unit test for parse function."""
    text_long = """
    This function is the first function created. It has some
    cool features.

    Args:
        p1 (list of int): param 1 documentation
        p2 (int): param 2 documentation

    Returns:
        string: return documentation
    """
    text_short = """
    This function is the first function created. It has some
    cool features.

    Args:
        p1 (int): param 1 doc
        p2 (string): param 2 doc

    Returns:
        string: return doc
    """
    try:
        assert parse(text_long) == parse(text_short)
    except AssertionError:
        raise AssertionError("The two texts are not parsed with the same result")

# Generated at 2022-06-23 17:22:31.647403
# Unit test for function parse
def test_parse():
    text = '''  
    This is a function docstring.

    Args:
        text (str): the string to test
        style: the style to test
    '''
    doc = parse(text)
    assert doc.short_description == "This is a function docstring."
    assert doc.long_description == ""
    assert doc.meta["Args"][0] == 'text (str): the string to test'
    assert doc.meta["Args"][1] == 'style: the style to test'

# Generated at 2022-06-23 17:22:39.759340
# Unit test for function parse
def test_parse():
    docstr = parse(text = """\
    This function parses a docstring into its components.
    
    :param text: Docstring text to parse
    :type text: str
    :param style: Docstring style
    :type style: :class:`~.Style`
    :returns: Parsed docstring representation
    :rtype: :class:`~.Docstring`
    """)

    print(docstr)
    assert(
        docstr.short_description ==
        "This function parses a docstring into its components."
    )
    assert(
        docstr.long_description ==
        "\n\n\n"
    )
    print(docstr)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:48.739682
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse
    from docstring_parser.styles import Style

    docstring = '''
    Module description
    ==================

    Lorem ipsum dolor sit amet, consectetur adipiscing elit.

    :param arg1: description for arg1
    :type arg1: int.

    :returns: description for return
    :rtype: str.
    '''
    ds = parse(docstring, style=Style.numpy)

    assert ds.summary == 'Module description'
    assert ds.description == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'

# Generated at 2022-06-23 17:22:58.424011
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import parse
    from docstring_parser.docstring import Docstring

    my_docstring = """
    The quick brown fox jumps over the lazy dog.

    :param name: The name of the person.
    :type name: str

    .. note:: This is a note.
    """

    docstring = parse(my_docstring)

    assert(isinstance(docstring, Docstring))
    assert(docstring.short_description.strip() == 'The quick brown fox jumps over the lazy dog.')
    assert(docstring.parameters[0].arg_name == 'name')
    assert(docstring.parameters[0].arg_type == 'str')
    assert(docstring.parameters[0].description.strip() == 'The name of the person.')

# Generated at 2022-06-23 17:23:01.066656
# Unit test for function parse
def test_parse():
    text = """docstring for parse for test."""
    result = parse(text)
    assert result.short_description == 'docstring for parse for test.'

# Generated at 2022-06-23 17:23:11.009820
# Unit test for function parse
def test_parse():
    """
    :returns: None
    """
    from docstring_parser.styles import SphinxStyle

    yapf_style_dataset = [
        '''This is a function.

    :param str abc: 123''',
        '''This is a function.

    :param str abc
        123
    :param str def
        456'''
    ]

    for dataset in yapf_style_dataset:
        assert isinstance(parse(dataset, Style.yapf), SphinxStyle)


# Generated at 2022-06-23 17:23:19.931198
# Unit test for function parse
def test_parse():
    assert parse("""
    # test doc
    """
    ) == Docstring(summary='', description='# test doc', meta={})
    assert parse(
        """
        """
    ) == Docstring(summary='', description='', meta={})
    assert parse(
        """
        Summary line.
        """
    ) == Docstring(summary='Summary line.', description='', meta={})
    assert parse(
        """
        Summary line.
        Extended description.
        """
    ) == Docstring(summary='Summary line.', description='Extended description.', meta={})
    assert parse(
        """
        Summary line.
        Extended description.

        More extended description.
        """
    ) == Docstring(summary='Summary line.', description='Extended description.\n\nMore extended description.', meta={})

# Generated at 2022-06-23 17:23:28.589258
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google
    s = """Summary line.

Extended description.

Args:
  foo (int): Description of `foo`.
  bar (str): Description of `bar`.
"""
    d = parse(s, style=Google)
    print(d)
    assert d == Google(s)
    assert d.meta["foo"] == "Description of foo."
    assert d.meta["bar"] == "Description of bar."

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:23:37.153088
# Unit test for function parse
def test_parse():
    # test that parse can be called with all possible styles
    docstring_text = '''
    Parse the docstring into its components.

    :param int text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    :rtype: str
    '''
    for style in (Style.auto, Style.numpy, Style.google):
        parse(docstring_text, style=style)

    # verify that auto-detection works as expected
    assert parse('halp').style == Style.numpy

    # cannot parse docstring with no style specified
    try:
        parse('halp', style=Style.auto)
    except ParseError:
        pass
    else:
        assert False

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:47.354461
# Unit test for function parse

# Generated at 2022-06-23 17:23:57.127000
# Unit test for function parse
def test_parse():
    docstring = """This is a simple docstring.
    It's got some lines.

    :param arg1: the first argument
    :type arg1: int"""

    ds = parse(docstring, Style.google)

    assert(ds.short_description == "This is a simple docstring.")
    assert(ds.long_description == "It's got some lines.")
    assert(len(ds.meta) == 2)
    assert(ds.meta.arg1.argname == 'arg1')
    assert(ds.meta.arg1.argtype == int)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:08.602721
# Unit test for function parse
def test_parse():
    text = '''\
        Single-line summary.

        Multi-line summary.

        Single-line description.

        Multi-line description.
        '''

    ret = parse(text)
    assert ret.short_description == 'Single-line summary.'
    assert ret.long_description == 'Multi-line summary.\n\nSingle-line description.'
    assert ret.meta == {}
    print(ret)
    text = '''\
        :param foo: this is foo
        :type foo: str
        :param bar: this is bar
        :type bar: int
        :returns: this is return
        :raises ValueError: if something bad happens
        '''
    ret = parse(text)
    print(ret)

# Generated at 2022-06-23 17:24:17.733864
# Unit test for function parse

# Generated at 2022-06-23 17:24:25.502769
# Unit test for function parse
def test_parse():
    s = """\
    This is my func.

    Args:
        param1 (int): this is the first param
        param2 (str): this is a second param

    Returns:
        bool: this is a description of what is returned

    Raises:
        KeyError: raises an exception
        ValueError: raises an exception
    """

    assert parse(s, Style.numpy).returns[0].type == 'bool'
    assert parse(s, Style.numpy).exceptions[0].name == 'KeyError'

# Generated at 2022-06-23 17:24:31.689746
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta=None)
    assert parse("a") == Docstring(summary="a", description="", meta=None)
    assert parse("a\nb") == Docstring(summary="a", description="b", meta=None)
    assert parse("a\n\nb") == Docstring(summary="a", description="\nb",
                                        meta=None)



# Generated at 2022-06-23 17:24:39.012943
# Unit test for function parse
def test_parse():
    assert(parse("this is a test") == Docstring("this is a test"))
    assert(parse("This is a test:  ", Style.google) == Docstring("This is a test:  "))
    assert(parse("This is a test: \n", Style.google) == Docstring("This is a test: \n", "\n"))
    assert(parse("This is a test:  ", Style.numpy) == Docstring("This is a test:  "))
    assert(parse("This is a test: \n", Style.numpy) == Docstring("This is a test: \n", "\n"))
    assert(parse("This is a test:  ", Style.sphinx) == Docstring("This is a test:  "))

# Generated at 2022-06-23 17:24:41.596323
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True, report=True)


#Program to read the text file in a memory

# Generated at 2022-06-23 17:24:42.830898
# Unit test for function parse
def test_parse():
    text = """
    """

# Generated at 2022-06-23 17:24:46.567341
# Unit test for function parse
def test_parse():
    text = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    print(parse(text))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:57.109945
# Unit test for function parse
def test_parse():

    """
    test function parse
    """
    docstring = '''Module docstring.

    Parameters
    ==========
    field : int
        This is a field

    Returns
    =======
    foo
        The foo

    Raises
    ======
    IndexError : Index out of range

    See Also
    ========
    bar : bar

    Notes
    =====
    Note 1.
    Note 2.

    Examples
    ========
    >>> func(10)
    18
    '''
    d = parse(docstring)
    assert d.summary == 'Module docstring.'
    assert d.description == ''
    assert d.tags[0].name == 'param'
    assert d.tags[0].type_name == 'int'
    assert d.tags[0].name == 'param'

# Generated at 2022-06-23 17:25:07.806861
# Unit test for function parse

# Generated at 2022-06-23 17:25:18.377019
# Unit test for function parse

# Generated at 2022-06-23 17:25:30.126620
# Unit test for function parse
def test_parse():
    """Test parsing function parse"""
    from docstring_parser.common import ReturnItem
    from docstring_parser.styles import Style
    """Define docstring to be tested"""
    text = """\
    This is a test docstring.\n\nThis is section one.\n\n\
    :param name: The first parameter.\n\
    :type name: str\n\
    :param date: The second parameter.\n\
    :type date: str\n\
    :returns:\n\
        The return value.\n\
    :rtype: int"""
    docstring = parse(text, Style.google)
    """Define the expect result of test"""

# Generated at 2022-06-23 17:25:40.036799
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    from docstring_parser.styles import GoogleStyle, NumpyStyle
    assert parse('', style=Style.google) == \
        GoogleStyle('')
    assert parse('', style=Style.numpy) == \
        NumpyStyle('')
    assert parse('', style=Style.google).main_description == \
        GoogleStyle('').main_description
    assert parse('', style=Style.numpy).main_description == \
        NumpyStyle('').main_description
    assert parse('', style=Style.google).short_description == \
        GoogleStyle('').short_description
    assert parse('', style=Style.numpy).short_description == \
        NumpyStyle('').short_description

# Generated at 2022-06-23 17:25:42.485082
# Unit test for function parse
def test_parse():
    s = """
    This is a example for test parse funcation.
    """
    Docstring = parse(s)
    print(Docstring)
    
if __name__ == "__main__":    
    test_parse()




# Generated at 2022-06-23 17:25:45.214979
# Unit test for function parse
def test_parse():
    do

# Generated at 2022-06-23 17:25:51.490098
# Unit test for function parse
def test_parse():
    src = """
    """
    ret = parse(src)
    assert ret.short_description == ""
    #assert ret.long_description == ""
    assert ret.meta == {}
    assert ret.meta_end == 0
    assert ret.parameters == {}
    assert ret.returns == {}
    assert ret.yields == {}
    assert ret.raises == {}

# Generated at 2022-06-23 17:25:52.781772
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-23 17:26:01.559082
# Unit test for function parse
def test_parse():
    text_1 = '''
    Testing the function
    '''
    text_2 = '''
    
    Testing the function
    '''
    output = Docstring(short_description='Testing the function')
    input = Docstring(short_description='Testing the function')
    input2 = Docstring(short_description='Testing the function')

    assert parse(text_1) == output
    assert parse(text_2) == output
    assert parse(text_1, Style.nnn) == input
    assert parse(text_2, Style.nnn) == input2

# Generated at 2022-06-23 17:26:08.901791
# Unit test for function parse
def test_parse():
    text = """
    This is a test of the parse method.

    Parameters
    ----------
    text : str
        docstring text to parse
    style : Style
        docstring style
    """
    
    parsed = parse(text)
    
    assert parsed.summary_text == """This is a test of the parse method."""
    assert parsed.full_text == text.strip()
    assert parsed.params.get('text').type == 'str'
    assert parsed.params.get('style').type == 'Style'
    
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:26:14.200621
# Unit test for function parse
def test_parse():
    test_str = """
    Here is an unformatted docstring.
    """
    rets = parse(test_str)
    assert rets.short_description == ""
    assert rets.long_description == "Here is an unformatted docstring.\n"
    assert rets.meta['args'] == []
    assert rets.meta['raises'] == []
    assert rets.meta['returns'] == []



# Generated at 2022-06-23 17:26:20.476969
# Unit test for function parse
def test_parse():
    docstring = '''
    this is the description
    
    Parameters
    ----------
    param1 : type
        description
    param2 : type, optional
        description (the default is value)
    '''
    parsed_docstring = parse(docstring)
    
    assert parsed_docstring.short_description == 'this is the description'
    assert len(parsed_docstring.meta) == 2
    assert (parsed_docstring.meta['param1'][0].type_name == 'type' and
            parsed_docstring.meta['param1'][0].description == 'description')

# Generated at 2022-06-23 17:26:30.398393
# Unit test for function parse
def test_parse():
    docstring = parse(
        """Summary line.

        Extended description.

        Args:
            arg1 (int): Description of `arg1`
            arg2 (str): Description of `arg2`

        Raises:
            AttributeError: The `AttributeError` exception.
            ValueError: The `ValueError` exception.

        Returns:
            bool: Description of return value

        """
    )
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description.\n"
    assert len(docstring.params) == 2
    assert len(docstring.raises) == 2
    assert len(docstring.returns) == 1