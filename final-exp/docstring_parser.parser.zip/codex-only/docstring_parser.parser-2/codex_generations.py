

# Generated at 2022-06-23 17:16:30.991423
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ReturnItem
    docstring = parse("""Summary.

This is a long description.

:return: a value
:rtype: str
""")
    assert docstring.short_description == "Summary."
    assert docstring.long_description == "This is a long description."
    assert docstring.returns == [ReturnItem("a value", "str")]

# Generated at 2022-06-23 17:16:35.322032
# Unit test for function parse
def test_parse():
    docstring = """This is a sample docstring

This is a longer description.

    with some code
    indented 4 spaces
    """
    assert [l.strip() for l in docstring.splitlines()] == parse(docstring).lines

if __name__ == '__main__':
    test_parse()
    print("All tests run ok")

# Generated at 2022-06-23 17:16:44.833168
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import PEP0257, Google, Numpy, Default, Doxygen

    # Test for auto style parsing
    test_docstring_0 = '''This is a module docstring.
    This module does stuff.

    Parameters:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        int: The return value. True for success, False otherwise.

    '''

    docstring_0 = parse(test_docstring_0)
    assert docstring_0.meta['summary'] == 'This is a module docstring.'
    assert docstring_0.meta['extended_summary'] == 'This module does stuff.'

# Generated at 2022-06-23 17:16:50.473564
# Unit test for function parse
def test_parse():
    class TestClass:
        def __init__(self):
            # This is a class constructor.
            pass
    ds = parse(TestClass.__doc__)
    assert ds.short_description == "This is a class constructor."
    assert ds.long_description == ""

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:01.395746
# Unit test for function parse
def test_parse():
    test_text = '''\
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    result = parse(text=test_text, style=Style.numpy)
    expected = Docstring(
        short_description='Parse the docstring into its components.',
        long_description='',
        content_type=None,
        sections=[],
        returns=Docstring.Return(
            description='parsed docstring representation',
            type='',
            examples=[]
        ),
        raises=[],
        meta={
            'text': 'docstring text to parse',
            'style': 'docstring style'
        },
    )
    assert result.__dict__ == expected.__dict__

# Generated at 2022-06-23 17:17:12.174788
# Unit test for function parse
def test_parse():
    dstring = """short summary\n\nextended summary\n\n:param int x: first param
    \n\n:param int y: second param\n\n:returns: z\n\n:raises Exception: on fail
    \n\n.. note:: A one-line note.\n   A multi-line note."""
    doc = parse(dstring)
    assert doc.short_description == 'short summary'
    assert doc.extended_description == 'extended summary'
    assert doc.params[0].name == 'x'
    assert doc.params[0].type_name == 'int'
    assert doc.params[0].description == ''
    assert doc.params[1].name == 'y'
    assert doc.params[1].type_name == 'int'

# Generated at 2022-06-23 17:17:19.801813
# Unit test for function parse
def test_parse():
    text = """To pass multiple, space-separated arguments to the config option, \
    wrap the value in double quotes, as shown:

    --config="key1=value1 key2=value2"
    """
    docstring = parse(text)
    assert docstring.short_description == 'To pass multiple, space-separated arguments to the config option, wrap the value in double quotes, as shown:'
    assert docstring.long_description == '--config="key1=value1 key2=value2"'

    text = """To pass multiple, space-separated arguments to the config option, \
    wrap the value in double quotes, as shown:

    --config="key1: value1
    key2: value2"
    """
    docstring = parse(text)

# Generated at 2022-06-23 17:17:21.614114
# Unit test for function parse
def test_parse():
    docstring = """
    Given a list of numbers and a number k, return whether any two numbers from
    the list add up to k.
    """
    assert parse(docstring).short_description == "Given a list of numbers and a number k, return whether any two numbers from the list add up to k."

# Generated at 2022-06-23 17:17:31.063175
# Unit test for function parse
def test_parse():
    text = '''\
Parameters
----------
a: array_like
    Array_like means all those objects -- lists, nested lists, etc. -- that can
    be converted to an array. We can also refer to `variables`\
b: int
    Integer'''
    doc = parse(text)
    assert len(doc.sections) == 1
    assert doc.sections[0].name == "Parameters"
    assert len(doc.sections[0].content) == 2
    for key, value in doc.sections[0].content.items():
        assert value == text.split(":")[-1].strip().split('\n')[1].strip()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:36.287574
# Unit test for function parse
def test_parse():

	text = ""
	style = Style.google
	expect = None
	output = parse(text,style)
	assert output == expect
	print(parse(text,style))

	text = "This is a docstring"
	style = Style.google
	expect = "This is a docstring"
	output = parse(text,style)
	assert output == expect
	print(parse(text,style))

test_parse()

# Generated at 2022-06-23 17:17:41.390651
# Unit test for function parse
def test_parse():
    text = '''
    this function adds numbers together
    :param: x - the first number to add
    :param: y - the second number to add
    :return: the added result of x and y
    '''
    assert parse(text)
    #adding a test comment
test_parse()

# Generated at 2022-06-23 17:17:51.578930
# Unit test for function parse
def test_parse():
    class TestClass():
        '''
        This is a test class intended to serve as a test case for the docstring_parser
        package. It has two docstrings, one on the class and one on the method.

        :param param1: This is a first param
        :param param2: This is a second param
        :returns: This is a description of what is returned
        :raises keyError: raises an exception
        '''
        def test_method(self, a, b):
            '''
            This is a test method to serve as an example docstring.

            :param a: first param
            :param b: second param
            :returns: nothing
            '''
            pass

    d = parse(TestClass.__doc__)

# Generated at 2022-06-23 17:17:56.912960
# Unit test for function parse
def test_parse():
    assert parse('my first line\nmy second line.\n')
    assert parse('my first line\n\nmy second line.\n')
    assert parse('my first line\n\n:param integer x:XXX\n\nmy second line.\n')
    assert parse('my first line\n\n:param integer x:XXX\n\n:returns:\n\nmy second line.\n')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:18:07.210305
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle
    from docstring_parser import parse

    text = """
    This is a function.

    :param int not_default: no default
    :param int with_default: 0
    :returns: nothing
    """

    docstring = parse(text)
    assert isinstance(docstring, Docstring)

    assert docstring.short_description == "This is a function."
    assert len(docstring.long_description) == 0

    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "not_default"
    assert docstring.params[0].type_name == "int"
    assert len(docstring.params[0].description) == 0

    assert docstring.params[1].arg_name == "with_default"


# Generated at 2022-06-23 17:18:16.633749
# Unit test for function parse
def test_parse():
    text = r'''\
 blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah
    '''
    assert text == parse(text).raw

# Generated at 2022-06-23 17:18:27.218077
# Unit test for function parse
def test_parse():
    s = '''
    This is an example of a docstring written in reST.
    This defines a simple function, that can be called with:
    ``y = my_function(x)``
    :param x: the number to be squared
    :type x: int
    :param str y: the string that is added to x
    :returns: x squared
    :rtype: int
    '''
    d = parse(s, style=Style.pep257)
    assert d.short_description == 'This is an example of a docstring written in reST.'
    assert d.summary == 'This is an example of a docstring written in reST.\nThis defines a simple function, that can be called with:\n``y = my_function(x)``'
    assert d.long_description == ''
    assert d.meta

# Generated at 2022-06-23 17:18:37.591119
# Unit test for function parse
def test_parse():
    text = """
    #
    # summary_line
    #
    example
        - example_item
    
    :param keyword: description
    :type keyword:  str
    :param keyword: description
    :type keyword:   dict
    :return:  description
    :rtype:   tuple
    
    description
    
    
    description example
    """

    result = parse(text)

    assert result.meta["summary_line"] == "summary_line"
    assert result.meta["example"] == "example"
    assert result.meta["example_item"] == "- example_item"

    assert result.params["keyword"]["type"] == ["str"]
    assert result.params["keyword"]["description"] == ["description"]

# Generated at 2022-06-23 17:18:45.303179
# Unit test for function parse
def test_parse():
    ds = parse("""
    This is a docstring
    for a function.

    :param x:
        Parameter x.
    :type x: int
    :returns:
        Nothing.
    """)

    assert ds.short_description == 'This is a docstring for a function.'
    assert ds.long_description == ''
    assert ds.returns.description == 'Nothing.'
    assert ds.parameters['x'].description == 'Parameter x.'
    assert ds.parameters['x'].annotation == 'int'

# Generated at 2022-06-23 17:18:56.756569
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    # Normal case
    text = """
    This is a very awesome tool to do something.

    :type value: int or None
    :param value: value in seconds. if None use default Timeout.
    """
    doc = parse(text)
    assert isinstance(doc, Docstring)
    assert doc.description == "This is a very awesome tool to do something."
    assert doc.params[0] == ("value", "int or None", "value in seconds. if None use default Timeout.")

    # ParseError
    with pytest.raises(ParseError):
        parse("")

    # Style miss-match

# Generated at 2022-06-23 17:19:08.947072
# Unit test for function parse
def test_parse():
    # test for a numpy style
    docstring = """
    This is a numpy style docstring.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    bool
        Description of return value
    """
    parsed = parse(docstring)

    assert parsed.short_description == "This is a numpy style docstring."
    assert parsed.long_description == ""
    assert parsed.params == {
        "arg1": "Description of arg1",
        "arg2": "Description of arg2"
    }
    assert parsed.returns == "Description of return value"

    # test for a google style

# Generated at 2022-06-23 17:19:17.505630
# Unit test for function parse
def test_parse():
    text = """\
    """
    doc = parse(text)
    assert doc.short_description == ""


text = """\
Single line docstrings should be backtick quoted.
This is so they can be used as a function or class attribute.

The same applies to the first line of multi line docstrings.
"""

doc = parse(text)
assert doc.short_description == "Single line docstrings should be backtick quoted."

# Parse warning with no blank lines
text = """\
Warning message, which ends with a period.
Summary line.
"""

doc = parse(text)
assert doc.short_description == "Warning message, which ends with a period."
assert doc.long_description == "Summary line."

# Parse warning with blank lines

# Generated at 2022-06-23 17:19:20.152244
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    assert parse("""
    """
    ) == ''

# Generated at 2022-06-23 17:19:29.890404
# Unit test for function parse
def test_parse():
    """parse() test"""
    print("---\ntest_parse()")
    text = """Summary line.
This is a longer description.
It can be several paragraphs.

Each paragraph must be indented.

- One
- Two
- Three

Args:
    arg1 (int): The first argument.
    arg2 (str): The second argument.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.

Returns:
    bool: The return value. True for success, False otherwise.
"""

    doc = parse(text)
    assert len(doc.meta) == 6
    assert doc.meta[0].name == "arg1"
    assert doc.meta[0].type

# Generated at 2022-06-23 17:19:38.218838
# Unit test for function parse
def test_parse():
    doc = parse("""
    The ``sample()`` function's docstring.

    Parameters
    ----------
    first: str
        First parameter
    second: str, optional
        Second parameter

    Returns
    -------
    int
        Result of sample()

    Examples
    --------
    >>> sample('hello world')
    42
    """)

    print(doc.meta)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.sections)
    print(doc.params)
    print(doc.returns)
    print(doc.examples)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:41.811480
# Unit test for function parse
def test_parse():
    docstring = parse("""Short summary.

    Longer description.

    Args:
      x: First argument.
      y: Second argument.

    Returns:
      Sum of arguments.

    Raises:
      ValueError: If x is negative.
      TypeError: If x is a string.
    """, Style.google)
    print(docstring)
    print("--------------------------")
    print("Summary:", docstring.short_description)

# Generated at 2022-06-23 17:19:43.677866
# Unit test for function parse
def test_parse():
    """
    Example:
    >>> test_parse()
    >>> a = {'Library': 'docstring_parser'}
    >>> a == parse("Test")
    True
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:19:55.390326
# Unit test for function parse
def test_parse():
    assert parse("No param.") == {'description': ['No param.'], 'meta': {}}
    assert parse("\nNo param.\n") == {'description': ['No param.'], 'meta': {}}
    assert parse("No param.\n") == {'description': ['No param.'], 'meta': {}}
    assert parse("No param.\n") == {'description': ['No param.'], 'meta': {}}
    assert parse(":param X: \n    abc\n") == {'description': [''], 'meta': {'param': {'X': 'abc'}}}
    assert parse(":param X: \n    abc\n") == {'description': [''], 'meta': {'param': {'X': 'abc'}}}
    assert parse(":param X: \n    abc\n")

# Generated at 2022-06-23 17:20:06.854571
# Unit test for function parse
def test_parse():
    docstr = '''
    Foo bar
    =======

    The foo bar algorithm.

    It is multiline.

    Parameters
    ----------
    x : Number
        The x value.

    y : Number
        The y value.

    Returns
    -------
    Number
        The value of x.

    Raises
    ------
    ValueError
        If x is zero.
    '''
    docstr = parse(docstr)
    assert docstr.short_description == 'Foo bar'
    assert docstr.long_description == 'The foo bar algorithm.\n\nIt is multiline.'
    assert len(docstr.params) == 2
    assert docstr.params[0].arg_name == 'x'
    assert docstr.params[0].type_name == 'Number'

# Generated at 2022-06-23 17:20:09.919229
# Unit test for function parse
def test_parse():
    text = """This is a test"""
    style = Style.auto
    parsed = parse(text)
    assert(parsed.summary == "This is a test")

# Generated at 2022-06-23 17:20:15.161133
# Unit test for function parse
def test_parse():
    text = '''Function Foo
--------------

Args:
    arg1 (str): The first argument.
    arg2 (int, optional): The second argument. Defaults to None.

Returns:
    bool: The return value. True for success, False otherwise.
'''
    docstring = parse(text)
    print("---[docstring in .parse]---")
    print(docstring)


# Generated at 2022-06-23 17:20:20.224614
# Unit test for function parse
def test_parse():
    docstring = """Short desciption

Longer description.

:param a: first argument foo
:param b: second argument bar
:returns: return value
:raises SomeException: on some condition
"""

    doc = parse(docstring)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.return_annotation)
    print(doc.meta)
    print(doc.meta_list)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:20:31.606313
# Unit test for function parse

# Generated at 2022-06-23 17:20:38.382584
# Unit test for function parse
def test_parse():
    # case 1: style is auto
    text = "Todo: add docstring here"
    assert isinstance(parse(text, Style.auto), Docstring) == True

    # case 2: style is not auto
    text = "Todo: add docstring here"
    assert isinstance(parse(text, Style.google), Docstring) == True

    # case 3: style is auto, but it cannot be parsed
    text = "add docstring here"
    assert parse(text, Style.google) == None

# Generated at 2022-06-23 17:20:44.780605
# Unit test for function parse
def test_parse():
    assert parse(' single line ') == Docstring(brief='single line', content='')
    assert parse('no brief') == Docstring(brief='no brief', content='')
    assert parse(' no brief\n\nno content\n') == Docstring(brief='no brief', content='no content')
    assert parse(' no brief\n\nno content') == Docstring(brief='no brief', content='no content')
    assert parse(' no brief\n\n no content\n') == Docstring(brief='no brief', content='no content')
    assert parse(' no brief\n\n no content') == Docstring(brief='no brief', content='no content')
    assert parse(' no brief\n\n no content\n\n') == Docstring(brief='no brief', content='no content')
   

# Generated at 2022-06-23 17:20:53.187838
# Unit test for function parse
def test_parse():
    text = '''Parsing the docstring into its components.


        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        '''

    assert parse(text).short_description == 'Parsing the docstring into its components.'
    assert parse(text).full_description == ''
    assert parse(text).params == {'text': 'docstring text to parse', 'style': 'docstring style'}
    assert parse(text).returns == 'parsed docstring representation'
    assert parse(text).returns_description == ''

# Generated at 2022-06-23 17:20:56.787525
# Unit test for function parse
def test_parse():
    text = """
    Test parsing
    
    :param foo: a foo
    :return: a return value
    """
    assert parse(text)
    text = """
    Test parsing
    
    :param foo: a foo
    :return: a return value
    """

# Generated at 2022-06-23 17:21:03.722075
# Unit test for function parse
def test_parse():
    test_docstring = """
    This is an example function.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first parameter is invalid.
        OSError: The second parameter cannot be read.
    """

    test_docstring2 = """
    This is an example function.

    Parameters
    ----------
    arg1
        The first argument.
    arg2
        The second argument.

    Returns
    -------
    The return value. True for success, False otherwise.

    Raises
    ------
    ValueError
        The first parameter is invalid.
    OSError
        The second parameter cannot be read.
    """


# Generated at 2022-06-23 17:21:08.601046
# Unit test for function parse
def test_parse():
    text_input = """This is a test method.

:param param: parameter name
:param param1: parameter name
:returns: return info
:raises error: if something bad happens
:keyword var: keyword name
:keyword var1: keyword name
"""
    assert parse(text_input) == Docstring(meta={'param': 'parameter name\nparameter name',
        'param1': 'parameter name\nparameter name',
        'var': 'keyword name\nkeyword name',
        'var1': 'keyword name\nkeyword name'},
        content = 'This is a test method.',
        returns = 'return info',
        raises = 'error: if something bad happens')


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:21:18.157565
# Unit test for function parse
def test_parse():
    # This is the docstring we want to parse
    text = '''
    Docstring for a function
    :param param1: This is the first param.
    :param param2: This is the second param.
    :returns: This is a description of what is returned.
    :raises keyError: raises an exception
    '''
    # Parse the docstring, and store the result
    result = parse(text, style=Style.google)

    # The first line of the docstring is brief description.
    assert result.short_description == 'Docstring for a function'

    # The rest of the lines are longer description
    assert len(result.long_description) == 1
    assert result.long_description[0] == ''

    # Check the keys of parsed results
    assert len(result.returns) == 1
    assert len

# Generated at 2022-06-23 17:21:27.336796
# Unit test for function parse
def test_parse():
    # Test the parser on all docstring styles
    text = """Summary line.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    bool
        Description of return value

    """

    assert parse(text) == parse(text, style=Style.numpy)
    assert parse(text) == parse(text, style=Style.google)

    text = """Summary line.

    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`

    Returns:
        bool: Description of return value

    """

    assert parse(text) == parse(text, style=Style.numpy)

# Generated at 2022-06-23 17:21:34.610704
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    assert type(parse('')) == GoogleStyle
    assert parse('').summary == ''
    assert parse('').description == ''
    assert parse('').meta == {}
    assert parse('').params_sections == []
    assert parse('').raises_sections == []
    assert parse('').returns_section == ''
    assert parse('').to_code() == ''

# Generated at 2022-06-23 17:21:41.711948
# Unit test for function parse
def test_parse():
    assert parse("This is a docstring.") == Docstring(summary="This is a docstring.", params={},
                                                      returns="")
    assert parse("This is a docstring.\nThis is a docstring.", style=Style.google) == Docstring(
        summary="This is a docstring.\nThis is a docstring.", params={}, returns="")
    assert parse("This is a docstring.\n\nThis is a docstring.") == Docstring(
        summary="This is a docstring.\n\nThis is a docstring.", params={}, returns="")



# Generated at 2022-06-23 17:21:53.529634
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, Section, Field
    
    #########################################################################
    # split_paragraphs method test
    #########################################################################
    # should split paragraphs by '\n\n', rather than '\n'
    a = '''Life is like riding a bicycle. To keep your balance you must keep moving.

- Albert Einstein'''
    a_split = ['Life is like riding a bicycle. To keep your balance you must keep moving.',
              '- Albert Einstein'
              ]
    assert(parse(a).paragraphs == a_split)
    #########################################################################
    # split_sections method test
    #########################################################################
    # split_sections should group paragraphs/line by headings

# Generated at 2022-06-23 17:21:55.028877
# Unit test for function parse
def test_parse():
    text = """Single line docstring."""
    assert parse(text)


# Generated at 2022-06-23 17:22:06.129642
# Unit test for function parse
def test_parse():
    f=open('test_data.txt','r')
    contents=f.read()
    docstring=parse(contents)
    assert docstring.lines == [
        'This is a small example.',
        'This is an example where the longest line exceeds the margin.',
        'There are two kinds of lines that are too long, and they are handled differently.'
    ]
    assert docstring.has_param('arg1')
    assert docstring.meta['arg1']['type'] == 'str'
    assert docstring.meta['arg1']['optional'] is False
    assert docstring.meta['arg1']['description'] == 'The first argument.'
    assert docstring.meta['arg2']['type'] == 'int'
    assert docstring.meta['arg2']['optional'] is False
    assert doc

# Generated at 2022-06-23 17:22:16.788473
# Unit test for function parse
def test_parse():
    """Test function parse
    """
    from docstring_parser.common import Param, Docstring

    text = """Test docstring
    """
    parsed = parse(text)
    expected = Docstring(
        summary='Test docstring',
        description='',
        params=[],
        returns=None,
        meta={}
    )
    assert parsed==expected

    text = """
    This is the summary.
    It should not be indented.

    This is a description.
    It should be indented.
    """
    parsed = parse(text)
    expected = Docstring(
        summary='This is the summary.',
        description='It should be indented.',
        params=[],
        returns=None,
        meta={}
    )
    assert parsed==expected


# Generated at 2022-06-23 17:22:21.831987
# Unit test for function parse
def test_parse():
    """A test for function parse"""
    from docstring_parser.styles import Google

    if parse("Parsetest") != Google("Parsetest"):
        print("Error")
    if parse("Parsetest", style=Style.numpy) != Google("Parsetest"):
        print("Error")
    if parse("", style=Style.numpy) != Google(""):
        print("Error")
    if parse("", style=Style.google) != Google(""):
        print("Error")

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:33.574628
# Unit test for function parse
def test_parse():
    """
    parse the docstring into its components.

    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    text = """
    parse the docstring into its components.
    Parse the docstring into its components.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    

# Generated at 2022-06-23 17:22:37.878808
# Unit test for function parse
def test_parse():
    docstring = """
    Parameters
    __________
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.
    """
    doc = parse(docstring)
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "param1"
    assert doc.meta[1].arg_name == "param2"

# Generated at 2022-06-23 17:22:47.276940
# Unit test for function parse
def test_parse():
    doc = parse(text)
    print(doc)

if __name__ == "__main__":
    text = r"""
    Compute the King-Oakes power spectrum of the input frame.
    Reference:
    [1] T. C. O'Haver and S. L. King, “Fast Fourier transform
    algorithms for autocorrelation and power spectrum analysis
    using the FFT,” Review of Scientific Instruments, vol. 56, no. 11,
    pp. 2114–2117, Nov. 1985.
    Parameters
    ----------
    input : ndarray
        The input frame/point.
    axis : int, optional
        The axis over which to compute the King-Oakes power
        spectrum.
    Returns
    -------
    King-Oakes power spectrum
    """
    test_parse()

# Generated at 2022-06-23 17:22:52.833994
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param arg1: Description of arg1
:type arg1: str
:param arg2: Description of arg2
:type arg2: int, optional
:returns: Description of return value
:rtype: bool
:raises keyError: raises an exception
"""

    assert len(parse(text)) == 7


# Generated at 2022-06-23 17:23:00.411439
# Unit test for function parse
def test_parse():
    """Test for function parse"""

# Generated at 2022-06-23 17:23:09.811278
# Unit test for function parse
def test_parse():
    """Test the docstring parser."""
    text = """\
Module's docstring

Args:
    arg1 (str): The first argument.

Kwargs:
    kwarg1 (str): The first keyword argument.

Returns:
    bool: The return value. True for success, False otherwise.
"""
    docstring = parse(text)
    assert docstring.short_desc == "Module's docstring"
    assert len(docstring.long_desc) == 0
    assert len(docstring.meta) == 3
    assert len(docstring.meta['args']) == 1
    assert len(docstring.meta['kwargs']) == 1
    assert len(docstring.meta['returns']) == 1
    assert docstring.meta['args'][0].arg_name == 'arg1'
    assert doc

# Generated at 2022-06-23 17:23:18.888282
# Unit test for function parse
def test_parse():
    assert parse("""\
        
        A simple var.
        
        Parameters
        ----------
        x : int
            This is a test.
        y : float
            This is also a test.
        
        """) == Docstring(
        meta={
            "returns": {'desc': 'A simple var.', 'type': None},
            "parameters": [{'name': 'x',
                            'type': 'int',
                            'desc': 'This is a test.',
                            'default': None},
                           {'name': 'y',
                            'type': 'float',
                            'desc': 'This is also a test.',
                            'default': None}]
        },
        content='',
        errors=[]
    )

# Generated at 2022-06-23 17:23:22.324146
# Unit test for function parse
def test_parse():
    print("Testing parse()...", end="")
    import doctest
    doctest.testmod()
    print("  Done!")


# Generated at 2022-06-23 17:23:32.977936
# Unit test for function parse
def test_parse():
    doc = (
        "Summary line.\n"
        "\n"
        "Extended description.\n"
        "\n"
        ":param name: Description of `name`.\n"
        ":type name: str\n"
        ":param int age: Description of `age`.\n"
        ":returns: Description of `return` value.\n"
        ":rtype: str\n"
        ":raises AttributeError: Description of `AttributeError` exception.\n"
        ":raises TypeError: Description of `TypeError` exception.\n"
    )
    docstring = parse(doc)

    # Summary
    assert docstring.short_description == "Summary line."

    # Long description
    assert docstring.long_description == "Extended description.\n"

   

# Generated at 2022-06-23 17:23:39.505524
# Unit test for function parse
def test_parse():
    text = """Python docstring parsing
    :param int limit: The upper limit of the range.
    :returns: The range of integers [0, `limit`).
    """
    docstring = parse(text)
    assert len(docstring.params) == 1
    assert len(docstring.returns) == 1

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:40.404196
# Unit test for function parse
def test_parse():
    assert parse("")


# Generated at 2022-06-23 17:23:43.660621
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    assert parse.__doc__ == "The main parsing routine."
    try: assert parse("Hello world")
    except: assert False


# Generated at 2022-06-23 17:23:45.627874
# Unit test for function parse
def test_parse():
  text = '''
  This is the first line
  This is the second line
  '''
  print(parse(text))

# test_parse()

# Generated at 2022-06-23 17:23:52.745514
# Unit test for function parse
def test_parse():
    text = """\
This is a test class docstring.

:param str name: The name of something.
:param bool value: The value of something.
:ivar int something: The value of something.
:ivar str someother: The value of some other.
:vartype something: int
:vartype someother: str
:raises ValueError: Raise error if value is not valid.
:var bool somevar: This is some var.
:var bool someothervar: This is some other var.
:returns: bool
:rtype: bool
:returns: int
:rtype: int
:returns: str
:rtype: str

This is just some more documentation.
"""
    test_parse = parse(text)
    assert test_parse

# Generated at 2022-06-23 17:24:00.659445
# Unit test for function parse
def test_parse():
    text = """
This is the docstring for the example.py file.

:param arg1: The first argument.
:type arg1: int
:param arg2: The second argument.
:rtype: int
:returns: returns nothing.
"""
    d = parse(text)
    assert d.short_description == "This is the docstring for the example.py file."
    assert d.long_description == None
    assert d.section('Parameters')
    assert d.section('Returns')
    assert len(d.args) == 2
    assert len(d.returns) == 1

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:04.198384
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()


if __name__ == "__main__":
    # Test all styles:
    text = "Hello, World!"
    for style in STYLES.keys():
        try:
            docstring = parse(text, style)
            print(f"Style: {style.name}, description: {docstring.description}")
        except ParseError:
            print(f"Style: {style.name}, parsing error")
    # Test function parse
    test_parse()

# Generated at 2022-06-23 17:24:06.465759
# Unit test for function parse
def test_parse():
      doc = '''Example docstring.'''
      assert parse(doc).short_description == 'Example docstring.'


# Generated at 2022-06-23 17:24:15.973847
# Unit test for function parse
def test_parse():
    expected = ['Title: Name.\n',
                'Paragraph: A description of the function.\n',
                'Arguments:\n',
                '\targ1 (type): Description of arg1.\n',
                '\targ2 (type): Description of arg2.\n',
                'Returns:\n',
                '\ttype: Description of return value.\n']
    assert(parse("""Name.

A description of the function.

:param arg1: Description of arg1.
:type arg1: type
:param arg2: Description of arg2.
:type arg2: type
:returns: Description of return value.
:rtype: type""") == expected)



# Generated at 2022-06-23 17:24:21.270856
# Unit test for function parse
def test_parse():
    text = "The parse() method turns an argument string into an object hierarchy."
    docstring = parse(text)
    assert(docstring.description == text)
    assert(docstring.short_description == "The parse() method turns an argument string into an object hierarchy.")

test_parse()

# Generated at 2022-06-23 17:24:29.057786
# Unit test for function parse
def test_parse():
    doc = '''Summary line.

Description
    Extended description of function.

Parameters
----------
arg1: int
    Description of arg1
arg2: str
    Description of arg2
arg3: float
    Description of arg3

Returns
-------
int
    Description of return value

Raises
------
FileNotFoundError
    Description of exception.

Examples
--------
>>> print(fsolve(f, [0, 1]))
0.5
'''

    parsed = parse(doc, Style.google)

    assert parsed.summary == 'Summary line.'
    assert parsed.extended_summary == 'Description\n'
    assert parsed.description == 'Description\n    Extended description of function.\n'

    assert parsed.metadata['Parameters']['arg1'] == 'int\n    Description of arg1'

# Generated at 2022-06-23 17:24:31.018416
# Unit test for function parse
def test_parse():
    assert parse('Hello') == Docstring('Hello', 'None', 'None')


# Generated at 2022-06-23 17:24:41.055163
# Unit test for function parse
def test_parse():
    # No docstring
    assert parse('') == Docstring()

    # One non-empty line
    assert parse('A.') == Docstring(short_description='A.')

    # Two lines without blank line inbetween
    assert parse('A.\nB.') == Docstring(short_description='A.\nB.')

    # A blank line between
    assert parse('A.\n\nB.') == Docstring(short_description='A.', long_description='\nB.')

    # Section

# Generated at 2022-06-23 17:24:50.075979
# Unit test for function parse
def test_parse():
    text = ('Hello this is a test\n'
            '\n'
            ':param a: parameter a\n'
            ':param b: parameter b\n'
            ':type a: int\n'
            ':type b: float\n'
            ':returns: returns a dict\n'
            ':rtype: dict\n'
            ':raises ValueError: if the value is too high\n'
            ':raises TypeError: if the value is of the wrong type\n')

    docstring = parse(text)

    assert docstring.short_description == 'Hello this is a test'
    assert docstring.long_description == ''
    assert docstring.meta['param']['a']['description'] == 'parameter a'

# Generated at 2022-06-23 17:24:59.321742
# Unit test for function parse
def test_parse():
    text = """
        Short summary:

        Extended summary.

        Parameters
        -----------
        a : int
            The first parameter
        b : bool
            The second parameter

        Returns
        -------
        int
            The return value
    """

    doc = parse(text)
    assert doc.short_description == "Short summary"
    assert doc.long_description == "Extended summary."
    assert doc.params[0].name == "a"
    assert doc.params[0].arg_type == "int"
    assert doc.params[0].description == "The first parameter"
    assert doc.params[1].name == "b"
    assert doc.params[1].arg_type == "bool"
    assert doc.params[1].description == "The second parameter"

# Generated at 2022-06-23 17:25:05.356954
# Unit test for function parse
def test_parse():
    """
    Test case for function parse
    """
    x = parse("Test docstring parser\n\nThis is a test function for testing\nfunction parse")
    print(x.short_description)
    print(x.long_description)
    print(x.__dict__)
    print(x.parse)
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:09.623445
# Unit test for function parse
def test_parse():
    class A:
        """Python Docstring"""
        def a1(self):
            """Function A1

            This function is used for unit testing
            """
            pass

    from pprint import pprint
    doc = parse(A.a1.__doc__)
    pprint(doc)

# Generated at 2022-06-23 17:25:19.099872
# Unit test for function parse
def test_parse():
    """Test parsing of a Google docstring."""

    text = """\
    >>> text = 'Hello World'
    >>> print(text)

    Sample docstring with no sections.

    >>> text = 'Hello World'
    >>> print(text)

    >>> text = 'Hello World'
    >>> print(text)
    """


# Generated at 2022-06-23 17:25:30.826343
# Unit test for function parse
def test_parse():
    text = "This is the first sentence.\n\nThis is the second sentence.\n\nArgs:\n  arg1 (int): the first argument\n  arg2 (str): the second argument\n\nReturns:\n  str: a return value\n"

    # Parse as RST
    parsed = parse(text, style=Style.rst)
    assert parsed.short_description == "This is the first sentence."
    assert parsed.long_description == "This is the second sentence."
    assert parsed.args[0]['name']== "arg1"
    assert parsed.args[0]['type_name']== "int"
    assert parsed.returns[0]['type_name']== "str"

    # Auto parse
    parsed = parse(text)

# Generated at 2022-06-23 17:25:40.485713
# Unit test for function parse
def test_parse():
    input_text = """
    Calculate the Gini Index for a sample.

    The Gini Index is defined as the mean absolute difference between values,
    normalised by the mean of the sample. i.e.

    .. math:: G = \\frac{1}{n}\\sum_{i=1}^{n}\\frac{\\sum_{j=1}^{n}|x_{i}-x_{j}|}{2mx_{m}}

    where :math:`x_{m}` is the mean of the sample.

    :param array_like values: sample to calculate Gini Index from. Must be 1-D.
    :returns: The Gini Index of the sample.
    :raises StatisticsError: if more than one unique value is present in
        the sample.

    """

    parsed_text = parse(input_text)
    print

# Generated at 2022-06-23 17:25:47.233943
# Unit test for function parse
def test_parse():
    text = '''""" This is the docstring of the function Parse.
    This function parses a text.
    """'''
    result = parse(text, style=Style.auto)
    assert result.short_description == 'This is the docstring of the function Parse.'
    assert result.long_description == 'This function parses a text.'

# Generated at 2022-06-23 17:25:55.210970
# Unit test for function parse
def test_parse():
    # Python docstring example
    text = """
    This function does nothing.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    bool
        The return value. True for success, False otherwise.
    """
    docstring = parse(text)
    # Example of the parsed object
    assert docstring.short_description == "This function does nothing."

# Generated at 2022-06-23 17:26:06.518368
# Unit test for function parse
def test_parse():
    ds = parse("""
        Function that takes some arguments.

        :param x: first argument
        :param y: second argument
        :returns: some value
        """)

    assert isinstance(ds, Docstring)
    assert ds.short_description == "Function that takes some arguments."
    assert ds.long_description is None
    assert isinstance(ds.params, dict)
    assert len(ds.params) == 2
    assert ds.params['x'].type_name is None
    assert ds.params['x'].description == 'first argument'
    assert ds.params['y'].type_name is None
    assert ds.params['y'].description == 'second argument'
    assert ds.returns.type_name is None

# Generated at 2022-06-23 17:26:07.658814
# Unit test for function parse
def test_parse():
    docstring_parser.parse("")

# Generated at 2022-06-23 17:26:16.634062
# Unit test for function parse
def test_parse():
    str = '''
        Properties of the Docstring
        --------------------------
        
        variables:
        ========
        
            name1: (int) var1
            name2: (int) var2
        
        Return:
        =======
        
            (int)
    '''

# Generated at 2022-06-23 17:26:19.417023
# Unit test for function parse
def test_parse():
    
    text = "this is a test"
    assert parse(text).short_description == "this is a test"
    assert parse(text).long_description == None
    
    

# Generated at 2022-06-23 17:26:28.654210
# Unit test for function parse
def test_parse():
    text = '''\
    The main parsing routine.

    :param text: docstring text to parse
    :returns: parsed docstring representation'''
    docstring = parse(text)
    assert len(docstring.short_desc) == 13
    assert len(docstring.long_desc) == 13
    assert len(docstring.extended_desc) == 0
    assert len(docstring.meta.params) == 1
    assert len(docstring.meta.returns) == 1
    assert len(docstring.meta.raises) == 0
    assert len(docstring.meta.other) == 0