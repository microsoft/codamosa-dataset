

# Generated at 2022-06-23 17:16:34.399894
# Unit test for function parse

# Generated at 2022-06-23 17:16:41.052687
# Unit test for function parse
def test_parse():
    """Unit test."""
    assert parse('', Style.numpy) == Docstring('')
    assert parse('', Style.google) == Docstring('')
    assert parse('', Style.auto) == Docstring('')
    assert parse('_', Style.numpy) == Docstring('_')
    assert parse('_', Style.google) == Docstring('_')
    assert parse('_', Style.auto) == Docstring('_')
    assert parse('_\n', Style.numpy) == Docstring('_')
    assert parse('_\n', Style.google) == Docstring('_')
    assert parse('_\n', Style.auto) == Docstring('_')
    assert parse('_\n\n', Style.numpy) == Docstring('_')

# Generated at 2022-06-23 17:16:47.853681
# Unit test for function parse
def test_parse():
    parse_lines = '''
    The main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation'''
    parse_result = {'description': 'The main parsing routine.',
    'params': [{'name': 'text', 'type': None, 'description': 'docstring text to parse'}, {'name': 'style', 'type': None, 'description': 'docstring style'}],
    'returns': {'type': None, 'description': 'parsed docstring representation'}}
    assert (parse(parse_lines, 'numpy') == parse_result)
    # print(parse(parse_lines, 'numpy'))

# Generated at 2022-06-23 17:16:58.800917
# Unit test for function parse
def test_parse():
    assert parse("hello") != parse("")
    try:
        parse("")
        assert False
    except ParseError:
        assert True
    assert parse("hello") == parse("hello")
    assert parse("hello", Style.pep257) == parse("hello")
    assert parse("hello", Style.numpy) == parse("hello")
    assert parse("hello") != parse("hello", Style.numpy)
    assert parse("hello", Style.auto) == parse("hello", Style.pep257)
    assert parse("hello", Style.auto) == parse("hello", Style.google)
    assert parse("hello", Style.auto) == parse("hello", Style.doxygen)
    assert parse("hello", Style.auto) == parse("hello", Style.sphinx)

# Generated at 2022-06-23 17:17:02.250960
# Unit test for function parse
def test_parse():
    docstring = """
test_parse(): this docstring does not follow any style guide recommendations.
"""
    expected = Docstring(
        summary="test_parse(): this docstring does not follow any style guide recommendations.",
        description="",
        meta={},
        extra="",
        examples=[],
    )
    assert parse(docstring) == expected


# Generated at 2022-06-23 17:17:06.468434
# Unit test for function parse
def test_parse():
    text = """Parse the docstring into its components.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    string = "Parses the docstring into its components"
    assert docstring_parser.parse(text).short_description == string

# Generated at 2022-06-23 17:17:09.096363
# Unit test for function parse
def test_parse():
    ret = parse('hogehoge')
    assert(ret.summary == 'hogehoge')
    assert(ret.description == '')
# EOF

# Generated at 2022-06-23 17:17:12.440983
# Unit test for function parse
def test_parse():
    test_string = """
    Args:
        foo: first argument
        bar: second argument
    """
    parsed = parse(test_string)
    assert parsed.meta["foo"].description == "first argument"
    assert parsed.meta["bar"].description == "second argument"

# Generated at 2022-06-23 17:17:19.915952
# Unit test for function parse
def test_parse():
    from pprint import pprint
    from docstring_parser.styles import NumpyStyle


# Generated at 2022-06-23 17:17:25.197555
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse
    from docstring_parser.styles import Style
    from docstring_parser.common import Docstring

    assert isinstance(parse('hello', Style.google), Docstring)
    assert isinstance(parse('hello', Style.numpy), Docstring)
    assert isinstance(parse('hello', Style.reST), Docstring)

# Generated at 2022-06-23 17:17:35.616627
# Unit test for function parse
def test_parse():
    text1 = """\
    Example function with types documented in the docstring.

    Args:
        param1 (str): The first parameter.
        param2 (int, optional): The second parameter. Defaults to 42.

    Returns:
        str: The return value. True for success, False otherwise.
    """
    docstring1 = parse(text1)
    assert docstring1.short_description == 'Example function with types documented in the docstring.'
    assert docstring1.long_description == ''

    assert len(docstring1.params) == 2

    assert docstring1.params[0].arg_name == 'param1'
    assert docstring1.params[0].description == 'The first parameter.'

    assert docstring1.params[1].arg_name == 'param2'

# Generated at 2022-06-23 17:17:45.985552
# Unit test for function parse
def test_parse():
    docstring = parse('''
    A very simple test

    :param type1: test type1
    :param type2: test type2
    :param type3: test type3
    :param type4: test type4
    ''')
    assert(docstring.short_description == 'A very simple test')
    assert(docstring.long_description == '')
    assert(docstring.tags[0].tag_name == 'param')
    assert(docstring.tags[0].name == 'type1')
    assert(docstring.tags[0].annotation == '')
    assert(docstring.tags[0].default == '')
    assert(docstring.tags[0].description == 'test type1')
    assert(docstring.meta == [])




# Generated at 2022-06-23 17:17:49.513503
# Unit test for function parse
def test_parse():
    s = parse.__doc__
    if type(s) == type(None):
        test = '<class \'NoneType\'>'
    else:
        test = '<class \'str\'>'
    assert test == '<class \'str\'>', 'test_parse(): parse function does not work!'


# Generated at 2022-06-23 17:17:57.254538
# Unit test for function parse
def test_parse():
    readme = open('./docstring_parser/README.rst', 'r')
    text = readme.read()
    rets = parse(text)
    print(rets.short_description)
    print(rets.long_description)
    for arg in rets.params:
        print(arg.name)
        print(arg.desc)
    for arg in rets.returns:
        print(arg.name)
        print(arg.desc)
    print(rets.raises)
    print(rets.warns)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:18:07.779233
# Unit test for function parse
def test_parse():
    test_tags = '@author: Jakub Hejduk'
    test_params = '@param: name: Type: Description'
    # test for naming convention
    test_returns = '@returns: Type: Description'
    test_returns2 = '@return: Type: Description'
    test_examples = '@example: Description'

    d = parse(test_tags)
    # print(d.meta['@author'])
    assert d.meta['@author'] == 'Jakub Hejduk'

    d = parse(test_params)
    # print(d.params['name'])
    assert d.params['name'] == {'Type': 'Type', 'Description': 'Description'}

    d = parse(test_returns)
    # print(d.returns['Type'])
   

# Generated at 2022-06-23 17:18:18.284653
# Unit test for function parse
def test_parse():
    # - function parse(text, style = Style.auto) -> Docstring:
    #   - case1
    text = '''
    Text.
    '''
    style = Style.auto
    ret = parse(text, style)
    assert ret.summary == 'Text.'
    #   - case2
    text = '''
    Text.
    '''
    style = Style.auto
    ret = parse(text, style)
    assert ret.summary == 'Text.'
    #   - case3
    text = '''
    Summary.
    '''
    style = Style.auto
    ret = parse(text, style)
    assert ret.summary == 'Summary.'
    #   - case4
    text = '''
    Summary.
    '''
    style = Style.auto

# Generated at 2022-06-23 17:18:23.198509
# Unit test for function parse
def test_parse():
    try:
        assert parse("def func():", style = Style.auto)
        assert parse("def func():")
        assert parse("def func():", style = Style.google)
        assert parse("def func():", style = Style.numpy)
        assert parse("def func():", style = Style.pep257)
        assert parse("def func():", style = Style.reST)
    except ParseError as e:
        print(e)
        assert False == True
    else:
        assert True == True

# Generated at 2022-06-23 17:18:30.983546
# Unit test for function parse
def test_parse():
    text = """
    The main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    assert parse(text, Style.google)
    text = """
    The main parsing routine.

    :param text: docstring text to parse
    :type style: Style
    :returns: parsed docstring representation
    """
    assert parse(text, Style.numpy)
    assert parse(text, Style.google)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:18:43.168665
# Unit test for function parse
def test_parse():
    test_docstring = '''
    Single-line docstring.

    Here's the description. It can have multiple lines.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    Returns:
        str: The return value. True for success, False otherwise.
    '''

    parsed_docstring = parse(test_docstring)
    print(parsed_docstring)
    assert parsed_docstring.short_description == 'Single-line docstring.'
    assert parsed_docstring.long_description == ("Here's the description. It "
                                                 'can have multiple lines.\n')
    assert parsed_docstring.returns.type_name == 'str'

# Generated at 2022-06-23 17:18:51.765457
# Unit test for function parse
def test_parse():
    """ Test parse """
    # Testing with simple_example
    parsed_docstring = parse(simple_example, Style.auto)
    print(parsed_docstring)
    print("Short Description:", parsed_docstring.short_description)
    # Testing with gtts
    from gtts import gTTS
    from io import BytesIO
    import sys
    import os
    from docx import Document
    from docxtpl import DocxTemplate
    from docxtpl import InlineImage
    filename = 'simple_example.mp3'
    tts = gTTS(text=simple_example, lang='en')
    tts.save(filename)

# Generated at 2022-06-23 17:18:57.065661
# Unit test for function parse
def test_parse():
    docstring = """\
    This is a simple example.

    :param int one: first integer
    :param int two: second integer
    :rtype int
    :return: sum of integers
    """
    assert parse(docstring) == Docstring(
        content='This is a simple example.',
        meta={
            'param': [
                ('one', 'first integer', 'int'),
                ('two', 'second integer', 'int')],
            'return': [('', 'sum of integers')],
            'rtype': [('int', '')]})

# Generated at 2022-06-23 17:19:08.373429
# Unit test for function parse
def test_parse():
    assert parse("""
        Args:
            name (str): The name to use.

        Keyword Args:
            state (bool): Current state to be in.

        Returns:
            int. The return code.

        Raises:
            AttributeError, KeyError
    """) == Docstring(
        "",
        [
            ("Args", [("name (str)", "The name to use.")], "", ""),
            ("Keyword Args", [("state (bool)", "Current state to be in.")], "", ""),
        ],
        "int. The return code.",
        "AttributeError, KeyError",
        "",
        "",
        [],
        [],
        ""
    )

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:17.289995
# Unit test for function parse
def test_parse():
    # Parse docstring from example file
    text = open('example.py', 'r').read()
    parsed_docstring = parse(text)
    # Make sure it has the correct parts
    assert parsed_docstring.short_description == 'This is a short description.'
    assert parsed_docstring.long_description == 'This is a long description.\nIt is perfectly fine to have multiple paragraphs in the description.'
    assert parsed_docstring.extended_description == 'For example, see the pandas DataFrame.iterrows function.'
    assert parsed_docstring.meta == {'license': 'GPLv3', 'version': '0.1'}

# Generated at 2022-06-23 17:19:21.463058
# Unit test for function parse
def test_parse():
    text = """calculates the sum of a and b"""
    ret = parse(text)
    assert ret.summary == 'calculates the sum of a and b'
    assert ret.description == ''
    assert ret.returns == {}


# Generated at 2022-06-23 17:19:29.503981
# Unit test for function parse
def test_parse():
    text = '''
    This is a test parse function, which parses a docstring into its components.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''

    assert parse(text) == Docstring(meta={
        'text': 'docstring text to parse',
        'style': 'docstring style',
        }, description=[
        'This is a test parse function, which parses a docstring into its components.',
        '',
        ], returns=[
        'parsed docstring representation',
        ],)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:39.416136
# Unit test for function parse
def test_parse():
    text = """\
    One line summary.

    Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value

    """
    d = parse(text, Style.numpy)
    assert d.summary == 'One line summary.'
    assert d.description == 'Extended description.'
    assert d.args == {'arg1': 'Description of arg1',
                      'arg2': 'Description of arg2'}
    assert d.returns == 'Description of return value'



# Generated at 2022-06-23 17:19:40.989288
# Unit test for function parse
def test_parse():
    """Test the parsing of docstrings."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:19:45.113064
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("", style=Style.spinx) == Docstring()
    assert parse("", style=Style.numpy) == Docstring()
    assert parse("", style=Style.google) == Docstring()



# Generated at 2022-06-23 17:19:56.097386
# Unit test for function parse
def test_parse():
    assert parse("""A short summary

Some further description
""").short_description == "A short summary"
    assert parse("""A short summary

Some further description
""").long_description == "Some further description"
    assert parse("""A short summary
    Some further description
""").short_description == "A short summary"
    assert parse("""A short summary
    Some further description
""").long_description == "Some further description"
    assert parse("""A short summary

    Some further description
""").short_description == "A short summary"
    assert parse("""A short summary

    Some further description
""").long_description == "Some further description"
    assert parse("""A short summary

:param foo: the foo param
:returns: bar

    Some further description
""").short_description == "A short summary"

# Generated at 2022-06-23 17:20:03.281791
# Unit test for function parse
def test_parse():
    docstring = '''one line summary
    more detailed summary

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first parameter is invalid.
        FileNotFoundError: The file pointed to by the second parameter was not
            found.
    '''
    print(parse(docstring))

test_parse()

# Generated at 2022-06-23 17:20:13.654215
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.epytext import _parse_epytext
    docstring = """
    @param name: user's name
    @type name: str
    @return (int, str): test
    @rtype (int, str): test
    @raises NameError: raises this error
    """
    doc = parse(docstring)
    assert doc.params == [{'name':'name','type':'str','desc':['user\'s name']}]
    assert doc.returns == [{'type':'(int, str)','desc': ['test']}]
    assert doc.raises == [{'type': 'NameError', 'desc': ['raises this error']}]


# Generated at 2022-06-23 17:20:15.449837
# Unit test for function parse
def test_parse():
    """Test the function parse."""
    assert type(parse(" Here comes the documentation")) == Docstring

# Generated at 2022-06-23 17:20:22.173740
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import GoogleStyle
    #the input text is a function
    text = '''
    This is docstring_parser test
    :param int a: The a
    '''
    output = parse(text)
    assert isinstance(output, Docstring)
    assert output.params == {'a': 'The a'}
    assert output.sections == {'args': 'The a'}
    assert output.summary == 'This is docstring_parser test'
    assert output.description == ''

    #the input text is a class
    text = '''
    This is docstring_parser test
    :ivar int a: The a
    '''
    output = parse(text)
    assert isinstance(output, Docstring)

# Generated at 2022-06-23 17:20:33.710258
# Unit test for function parse
def test_parse():
    text = \
        """This function is used to compute the cost and gradient
        \nof using theta as the parameter for regularized logistic regression and the
        \ngradient of the cost w.r.t. to the parameters.
        \n\n
        \n@param theta: a column vector containing the values of the parameters
        \n@param X: Data matrix of the samples
        \n@param y: a column vector containing the labels of the samples
        \n@param lambda_param: the regularization parameter
        \n@returns: cost: the cost of using theta as the parameter for regularized
        \nlogistic regression
        \n\n@returns: grad: the gradient of the cost w.r.t. to the parameters
        \n"""

    assert str(parse(text)) == text

# Generated at 2022-06-23 17:20:42.523749
# Unit test for function parse
def test_parse():
    text = "Classify the image."
    docstring = parse(text, STYLES[Style.numpy])
    assert docstring.short_description == "Classify the image."
    assert docstring.long_description == None

    text = '"""Classify the image.\n\nArgs:\nimg: Image to be classified.\n\nReturns:\nint: A prediction for the image."""'
    docstring = parse(text, STYLES[Style.numpy])
    assert docstring.short_description == "Classify the image."
    assert docstring.long_description == None
    assert docstring.params[1].name == "img"
    assert docstring.params[1].param_type == "image"
    assert docstring.params[1].description == "Image to be classified."
    assert docstring.returns

# Generated at 2022-06-23 17:20:49.598487
# Unit test for function parse
def test_parse():
    """Test the parse function"""

    assert parse.__doc__.strip() == """Parse the docstring into its components."""

    text = """
    This is a short summary.

    This is a long
    summary.
    """
    result = parse(text)

    assert len(result.summary) == 3
    assert result.short_description == 'This is a short summary.'
    assert result.description == 'This is a long\nsummary.'

# Generated at 2022-06-23 17:20:59.098667
# Unit test for function parse
def test_parse():
    # One line test
    assert parse("first line\n").short_description == "first line"

    # Multi line test
    assert parse("first line\n"
                 "\n"
                 "  - second line\n").short_description == "first line"
    assert parse("first line\n"
                 "\n"
                 "  - second line\n").long_description == "\n  - second line"
    assert parse("first line\n"
                 "\n"
                 "  - second line\n"
                 "  - third line\n"
                 "  - fourth line\n").long_description == (
        "\n  - second line\n  - third line\n  - fourth line"
    )

    # Arguments test

# Generated at 2022-06-23 17:21:03.451684
# Unit test for function parse
def test_parse():
    s = '''
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    r = parse(s)
    assert r.short_description == 'Parse the docstring into its components.'

# Generated at 2022-06-23 17:21:15.235427
# Unit test for function parse
def test_parse():
    assert parse("Hello").short_description == "Hello"
    assert parse("Hello\nWorld").short_description == "Hello"
    assert parse("Hello\nWorld").long_description == "World"
    assert parse("Hello\nWorld\nHello").long_description == "World\nHello"
    assert parse("Hello\nWorld\nHello\n\nWorld").long_description == "World\nHello"
    assert parse("Hello\nWorld\nHello\nHello\nWorld").long_description == "World\nHello\nHello\nWorld"
    assert parse("Hello\nWorld\nHello\nHello\nWorld\n\nWorld").long_description == "World\nHello\nHello\nWorld"

# Generated at 2022-06-23 17:21:26.275694
# Unit test for function parse
def test_parse():
    docstring = \
"""One-line short summary.

One-line long summary which can be longer.

This paragraph is part of the long summary.  It is useful to give
the user information about the function.  See
:ref:`documenting-functions` for more information.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`
varargs : \*, optional
    Description of `varargs` (variable arguments)
kwargs : \*\*, optional
    Description of `kwargs` (keyword arguments)

Returns
-------
bool
    True if successful, False otherwise.
"""
    p = parse(docstring)
    print(p)
    print(p.meta)
    print(p.short_description)

# Generated at 2022-06-23 17:21:37.960071
# Unit test for function parse
def test_parse():
    assert parse("""\
    Returns the mean of the input array.

    Parameters
    ----------
    arr : numpy.ndarray
        The input array.

    Returns
    -------
    float
        The mean of the input array.

    Raises
    ------
    ValueError
        If `arr` is empty.
    """).style == "google"

    assert parse("""\
    Returns the mean of the input array.

    Parameters
    ----------
    arr : numpy.ndarray
        The input array.

    Returns
    -------
    float
        The mean of the input array.

    Raises
    ------
    ValueError
        If `arr` is empty.
    """, Style.google).style == "google"


# Generated at 2022-06-23 17:21:45.629503
# Unit test for function parse
def test_parse():
    """Test for when the documentation for a specific function is found."""

    # Example doxygen documentation
    doxygen_block = """
    This is an example of a function. There is no
    input and no output.
    \return void
    """

    # Example numpydoc documentation
    numpydoc_block = """
    This is an example of a function. There is no
    input and no output.
    # Returns
    # -------
    # void
    """

    # Example sphinx documentation
    sphinx_block = """
    This is an example of a function. There is no
    input and no output.
    :returns: void
    """

    # Example Google documentation

# Generated at 2022-06-23 17:21:50.753846
# Unit test for function parse
def test_parse():
    from docstring_parser.styleguides import GoogleStyleGuide
    x = GoogleStyleGuide()
    doc = """This is a multiline docstring
    that spans several lines.
    """
    assert parse(doc).body == 'This is a multiline docstring\nthat spans several lines.\n'

# Generated at 2022-06-23 17:21:57.032450
# Unit test for function parse
def test_parse():
    test_text = '''This function does a lot of stuff.
    :param string: Name of the stuff
    :param foo: What kind of stuff
    :return: Stuff'''
    assert parse(test_text).doc == 'This function does a lot of stuff.'
    assert parse(test_text).params['string'] == 'Name of the stuff'
    assert parse(test_text).params['foo'] == 'What kind of stuff'
    assert parse(test_text).returns == 'Stuff'

# Generated at 2022-06-23 17:22:07.015323
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    # Test for parse function
    test_fun = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation"""
    from docstring_parser import parse
    assert parse(test_fun).params == [{'name': 'text', 'type': None, 'desc': 'docstring text to parse'},
                                     {'name': 'style', 'type': None, 'desc': 'docstring style'}]
    assert parse(test_fun).summary == 'Parse the docstring into its components.'
    assert parse(test_fun).returns == {'type': None, 'desc': 'parsed docstring representation'}

# Generated at 2022-06-23 17:22:16.854487
# Unit test for function parse
def test_parse():
    docs = parse("""
        Args:
            key (int): description of key
        Description of function.
        Returns:
            int
    """)
    print(docs)
    assert docs.short_description == 'Description of function.'
    assert docs.long_description == ''
    assert docs.keywords == {}
    assert docs.returns_annotation == 'int'
    assert docs.returns_description == ''
    assert docs.meta['Args'] == [('key', 'int', 'description of key')]
    assert docs.meta_single['Returns'][1] == 'int'
    assert docs.meta_single['Returns'][2] == ''

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:23.575494
# Unit test for function parse
def test_parse():
    docstring = '''This is a module docstring.'''
    parsed = parse(docstring)
    assert parsed.summary == docstring
    assert parsed.description == ''
    assert parsed.params == {}
    assert parsed.raises == {}
    assert parsed.returns is None
    assert parsed.yields is None

    docstring = '''One line summary.

        Extended description.
        '''
    parsed = parse(docstring)
    assert parsed.summary == 'One line summary.'
    assert parsed.description == 'Extended description.\n'

    docstring = '''This function does nothing.

        """
        Multiline quotes
        """
        '''
    parsed = parse(docstring)
    assert parsed.description == '"""\nMultiline quotes\n"""'


# Generated at 2022-06-23 17:22:34.970675
# Unit test for function parse
def test_parse():
    doc = """
    Function annotation.
    Lots of text.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``AttributeError`` exception.
        ValueError: The ``ValueError`` exception.
    """
    doc = parse(doc)
    assert len(doc.sections) == 4
    assert doc.sections[0].title == "Args"
    assert doc.sections[1].title == "Returns"
    assert doc.sections[2].title == "Raises"

    assert len(doc.sections[0].options) == 2
    assert len(doc.sections[1].options) == 1
    assert len(doc.sections[2].options)

# Generated at 2022-06-23 17:22:41.708461
# Unit test for function parse
def test_parse():
    text = '''\
    :param p1: this is p1
    :type p1: (int, int) -> list(list(int))
    :param p2: this is p2
    :type p2: float
    :returns: a list of list of integers
    :raises KeyError: raises an exception
    '''
    p = parse(text)
    assert p.meta['summary'] == ''
    assert p.meta['param']['p1'] == 'this is p1'
    assert p.meta['param']['p2'] == 'this is p2'
    assert p.meta['type']['p1'] == 'int, int -> list(list(int))'
    assert p.meta['type']['p2'] == 'float'

# Generated at 2022-06-23 17:22:42.320946
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:22:48.113849
# Unit test for function parse
def test_parse():
    docstring = """Function 1

    Description of function 1.
    
    Args:
        arg1 (int): Description of arg1.
        arg2 (str): Description of arg2.

    Returns:
        int: Description of return.

    Raises:
        ValueError: Description of error.
    """
    res = parse(docstring, Style.google)

    assert res.description.strip() == 'Description of function 1.'
    assert res.args[0].arg_name == 'arg1'
    

# Generated at 2022-06-23 17:22:57.978066
# Unit test for function parse
def test_parse():
    text = """This function does something.
    
    :param int arg_0: argument 0
    :param arg_1: argument 1
    :param arg_2: argument 2
    :returns: 0
    :raises ValueError: on invalid values
    
    Raise ValueError on invalid values
    
    >>> print('hi')
    hi
    
    """
    docstring = parse(text)
    assert docstring.short_description == 'This function does something.'
    assert docstring.long_description == '\nRaise ValueError on invalid values'
    assert docstring.meta['param']['arg_0'] == {'type': 'int', 'optional': False, 'default': None, 'annotation': 'argument 0'}

# Generated at 2022-06-23 17:23:04.353114
# Unit test for function parse
def test_parse():

    docstring = """Module name: helloworld.py

Author: J. Smith <js@example.com>

A short description of the module.

Functions:
    hello (name, place='World')
        Print 'Hello <name> <place>!'

Classes:
    Greet (name, place='World')
        Print 'Hello <name> <place>!' when object is called
    """

    assert parse(docstring).doc == docstring

# Generated at 2022-06-23 17:23:16.208950
# Unit test for function parse
def test_parse():
    answer = Docstring(
        'Documentation for the myprog program.',
        [],
        [],
        "This program is a simple demo.\n\nIt doesn't really do anything.",
        []
    )

# Generated at 2022-06-23 17:23:23.923997
# Unit test for function parse
def test_parse():
    docstring = """
    Test for parse function.
    Parameters
    ----------
    text : docstring text to parse
    style : docstring style
    Returns
    -------
    parsed docstring representation
    """

# Generated at 2022-06-23 17:23:28.885814
# Unit test for function parse
def test_parse():

    text = """A small example of the Docstring class.

Parameters
----------
one : str
    The first parameter.
two : int
    The second parameter.

Returns
-------
str
    The return value.
"""
    ds = parse(text)
    assert str(ds) == text

# Generated at 2022-06-23 17:23:33.844204
# Unit test for function parse
def test_parse():
    test_text = """
    A test doc string with a meta-data, a summary, and a list of returns.

    :param int a: A parameter named a
    :param int b: A parameter named b
    :returns: an int"""
    assert parse(test_text, Style.numpy).summary == "A test doc string with a meta-data, a summary, and a list of returns."


# Generated at 2022-06-23 17:23:36.540516
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'

# Generated at 2022-06-23 17:23:42.797838
# Unit test for function parse
def test_parse():
    text = '''
        This is a line
        """This is a line
        This is another line
        """
    '''
    style = Style.auto
    docstring = parse(text, style)
    assert docstring != None
    assert docstring.summary == "This is a line"
    
# Test the function
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:50.916605
# Unit test for function parse
def test_parse():
    text = '''\
    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    assert parse(text).summary == ''
    assert parse(text).description == ''
    assert parse(text).params == [
        {
            'name': 'param1',
            'type': 'int',
            'desc': 'The first parameter.',
            'meta': {}
        },
        {
            'name': 'param2',
            'type': 'str',
            'desc': 'The second parameter.',
            'meta': {}
        }
    ]

# Generated at 2022-06-23 17:23:57.174889
# Unit test for function parse
def test_parse():
	test_text = """
		Parameters
		----------
		arg1 : int
			description of arg1

		arg2 : str
			description of arg2
		Returns
		-------
		int
			description of return value
		"""
	ret = parse(test_text)
	print(ret)
	print(ret.returns)


# Generated at 2022-06-23 17:24:08.651258
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError


# Generated at 2022-06-23 17:24:12.074035
# Unit test for function parse
def test_parse():
    text = '''Do My Docstring
    """This is a docstring."""
    '''
    result = parse(text)
    assert result is not None

# Generated at 2022-06-23 17:24:19.995989
# Unit test for function parse
def test_parse():
    # assert styles are parsed correctly
    assert parse(
        text="""
        :param x: param x
        :returns: param y
        :raises: param z
        """, style=Style.google) == Docstring(
            meta={
                'param': {
                    'x': 'param x'
                },
                'returns': 'param y',
                'raises': 'param z'
            },
            content=''
        )

# Generated at 2022-06-23 17:24:28.545911
# Unit test for function parse
def test_parse():
    text = '''Parameters
----------
        a: integer
            parameter a'''
    ret = parse(text)
    assert ret
    assert ret.params[0].name == 'a'
    assert ret.params[0].type_name == 'integer'

    text = '''a: integer
        parameter a'''
    ret = parse(text)
    assert ret.params[0].name == 'a'
    assert ret.params[0].type_name == 'integer'

    text = '''Parameters
    ----------
    a: integer
    parameter a'''
    ret = parse(text)
    assert ret.params[0].name == 'a'
    assert ret.params[0].type_name == 'integer'


# Generated at 2022-06-23 17:24:37.892653
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    try:
        parse('nothing')
    except ParseError:
        print('Pass')
    else:
        print('Fail')

    assert parse('nothing', Style.epytext) == STYLES[Style.epytext]('nothing')
    assert parse('nothing', Style.sphinx) == STYLES[Style.sphinx]('nothing')

    assert parse('nothing') == STYLES[Style.sphinx]('nothing')

#    parse([1, 2])

#    parse((1,2))

#    parse(1, 2)

#    parse(style='style')

#    parse(style=[1,2])

#    parse(style=(1

# Generated at 2022-06-23 17:24:40.669948
# Unit test for function parse
def test_parse():
    text = '''Keyword arguments:
        arg -- The argument (default 5)
    '''
    ret = parse(text)
    assert ret

# Generated at 2022-06-23 17:24:43.260825
# Unit test for function parse
def test_parse():
    text = 'Data to be parsed'
    doc_string = parse(text)
    assert doc_string.short_description == ''


# Generated at 2022-06-23 17:24:50.934316
# Unit test for function parse
def test_parse():
    text = """
    Parameters
    ----------
    x: int
        The meaning of life.
    y: str
        The answer to the meaning of life.
    Returns
    -------
    int
        The sum of the meaning of life and the answer to the meaning of life.
    """

    docstring = parse(text)

    assert(docstring.short_description == '')
    assert(docstring.long_description == '')
    assert(len(docstring.params) == 2)
    assert(docstring.params['x'].type == 'int')
    assert(docstring.params['x'].description == 'The meaning of life.')
    assert(docstring.params['y'].type == 'str')
    assert(docstring.params['y'].description == 'The answer to the meaning of life.')


# Generated at 2022-06-23 17:24:55.659460
# Unit test for function parse
def test_parse():
    docstring = parse(text = '''This is a test docstring
This is a new line.
    ''')
    assert docstring.short_description == 'This is a test docstring'
    assert docstring.long_description == 'This is a new line.'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:25:01.958669
# Unit test for function parse
def test_parse():
    test_list = [
    (parse.__doc__, Style.numpy, True),
    (
        """Propagate input through the network and compute loss.

Args:
    x (torch.Tensor): the input to the network
    target (torch.Tensor): the target output for the batch of input

"""
        , Style.google, True
    )
    ]

    for one in test_list:
        try:
            doc = parse(one[0], one[1])
            assert isinstance(doc, Docstring)
        except (ParseError, AssertionError):
            assert not one[2]


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:13.396343
# Unit test for function parse
def test_parse():
    my_doc = """A simple addition function

    Args:
        arg1 (int): The first argument.
        arg2 (int): The second argument.

    Returns:
        int: The return value.
    """

    my_parsed_doc = parse(my_doc)
    assert my_parsed_doc.short_description == "A simple addition function"
    assert len(my_parsed_doc.params) == 2
    assert my_parsed_doc.params[0].arg_name == "arg1"
    assert my_parsed_doc.params[1].arg_name == "arg2"
    assert len(my_parsed_doc.returns) == 1
    assert my_parsed_doc.returns[0].description == "The return value."


# Generated at 2022-06-23 17:25:17.486665
# Unit test for function parse
def test_parse():
    text = '''This is a module.

    Meta
    ----
    rand : str
        Random module.'''
    d = parse(text)
    assert d.doc == 'This is a module.'
    assert d.meta == [('rand', 'str', 'Random module.')]
    return True

# Generated at 2022-06-23 17:25:29.194993
# Unit test for function parse
def test_parse():
    assert parse("""
Hello
""") == Docstring(
        summary='Hello',
        meta=[]
    )

    assert parse("""
Hello
-------
""") == Docstring(
        summary='Hello',
        description='-------',
        meta=[]
    )

    assert parse("""
Hello

-------
""") == Docstring(
        summary='Hello',
        description='-------',
        meta=[]
    )

    assert parse("""
Hello

-------

The world
""") == Docstring(
        summary='Hello',
        description='-------\n\nThe world',
        meta=[]
    )

    assert parse("""
Hello:
    World
""") == Docstring(
        summary='Hello:',
        meta=[('Hello', 'World')]
    )


# Generated at 2022-06-23 17:25:39.717762
# Unit test for function parse
def test_parse():
    def f():
        """This is a function.

        :param foo: this is foo
        :type foo: str
        :raises ValueError: if foo is empty
        :returns: None
        """
        pass
    docstring = parse(f.__doc__)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 1
    assert docstring.params[0].arg_name == 'foo'
    assert docstring.params[0].description == 'this is foo'
    assert docstring.params[0].annotation == 'str'
    assert docstring.params[0].default_value == None
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == 'None'

# Generated at 2022-06-23 17:25:45.670377
# Unit test for function parse
def test_parse():
  text = '''
        This is the summary line.

        This is the description block.
        There can be several paragraphs.

        :param name: Name of the person
        :type name: str
        :param age: Age of the person
        :type age: int
        :returns: The status of the person
        :rtype: bool
        :raises ValueError: If the person is too young
        :raises TypeError: If the age is not an integer
        '''
  test = parse(text)
  print("\n\n")
  print("The object type of the return function is {}".format(type(test)))
  print("The summary is : {}".format(test.short_description))
  print("The description is : {}".format(test.long_description))

# Generated at 2022-06-23 17:25:55.572084
# Unit test for function parse
def test_parse():

    assert parse('') == Docstring(
        meta={},
        short_description='',
        long_description='',
        extras=[]
    )

    assert parse('Example.') == Docstring(
        meta={},
        short_description='Example.',
        long_description='',
        extras=[]
    )

    assert parse('Example.\nDescription.') == Docstring(
        meta={},
        short_description='Example.',
        long_description='Description.',
        extras=[]
    )

    assert parse('Example.\n\nDescription.') == Docstring(
        meta={},
        short_description='Example.',
        long_description='Description.',
        extras=[]
    )


# Generated at 2022-06-23 17:26:02.581764
# Unit test for function parse
def test_parse():
    test_input = '''
    simple

    :param
    :returns:
    '''
    expected_output = Docstring(short_description='simple',
                                long_description='',
                                returns=Docstring.Return(description=''),
                                meta={'param': {}})
    assert parse(test_input, Style.numpy) == expected_output
    assert parse(test_input) == expected_output

# Generated at 2022-06-23 17:26:11.825003
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError

    # test for style.auto
    try:
        test_case1 = parse('  test: you')
        assert test_case1.short_description == ""
        assert test_case1.long_description == ""
        assert test_case1.meta.get('test') == ""
        assert list(test_case1.returns) == []
    except ParseError as e:
        exc_case1 = e
    assert exc_case1 is None


# Generated at 2022-06-23 17:26:19.137784
# Unit test for function parse
def test_parse():
    # Unit Tests for function parse
    doc_string = """One line summary.
    
    Extended description.
    
    Parameters
    ----------
    arg1 : int
        Description of ``arg1``.
    arg2 : str
        Description of ``arg2``.
    
    Returns
    -------
    str
        Description of return value.
    
    """
    doc_obj = parse(doc_string)
    assert (doc_obj.short_description == 'One line summary.')
    assert (doc_obj.long_description == 'Extended description.\n\n')
    assert (doc_obj.meta['arg1'] == 'Description of ``arg1``.\n')
    assert (doc_obj.meta['arg2'] == 'Description of ``arg2``.\n')

# Generated at 2022-06-23 17:26:19.651380
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:26:27.144478
# Unit test for function parse
def test_parse():
    text = """
    This is a short summary
    of my function.

    :param str my_input: This is a parameter
    :returns: This is the text describing the return value
    """
    result = parse(text)
    assert(result.params['my_input'].description == 'This is a parameter')
    assert(result.returns.description == 'This is the text describing the return value')
    assert(result.short_description == 'This is a short summary of my function.')