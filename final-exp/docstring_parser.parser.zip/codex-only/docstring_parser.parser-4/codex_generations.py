

# Generated at 2022-06-23 17:16:33.377740
# Unit test for function parse
def test_parse():
    docstring1 = """One line summary.
    
    Further description.
    """

    docstring2 = """One line summary.
    
    :param arg1: Description of arg1
    :type arg1: str
    :param arg2: Description of arg2
    :type arg2: int, optional
    :returns: Description of return value
    :rtype: bool
    
    Further description.
    """

    docstring3 = """One line summary.
    
    Args:
        arg1 (str): Description of arg1
        arg2 (int, optional): Description of arg2
    
    Returns:
        bool: Description of return value
    
    Further description.
    """


# Generated at 2022-06-23 17:16:34.407352
# Unit test for function parse
def test_parse():
	assert parse.__doc__ is not None

# Generated at 2022-06-23 17:16:44.527561
# Unit test for function parse

# Generated at 2022-06-23 17:16:56.350285
# Unit test for function parse
def test_parse():
    from pprint import pprint
    def test(text, expected, style=Style.auto):
        result = parse(text, style)
        assert result == expected
        print(result.summary)

    text = '''
        This is long description.

        Args:
            arg1: description of arg1
            arg2: description of arg2

        Returns:
            description of return value
    '''
    expected = Docstring(
        summary='This is long description.',
        description='',
        args=[
            ('arg1', 'description of arg1'),
            ('arg2', 'description of arg2')
        ],
        return_=('', 'description of return value'),
        raises=[],
        meta={},
    )
    test(text, expected)


# Generated at 2022-06-23 17:17:04.944864
# Unit test for function parse
def test_parse():
    text = '''\
    Parameters
    ----------
    x : int
        new x value
    y : float
        new y value
    '''
    assert parse(text) == Docstring(
        summary='',
        description='',
        params=[
            ('x', 'int', '', 'new x value'),
            ('y', 'float', '', 'new y value')
        ],
        returns=[],
        raises=[],
        meta=[],
        style=Style.numpy)
    # Alternate style, without type annotations
    text = '''\
    Parameters
    ----------
    x
        new x value
    y
        new y value
    '''

# Generated at 2022-06-23 17:17:10.073145
# Unit test for function parse
def test_parse():
    test_data = '''
    This is a test for the parser
    '''
    print(test_data)
    docstring = parse(test_data)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta)
    
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:17.737501
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    docstring = """
    This function does something.
    :arg1: The first argument
    :returns: The return value
    """
    result = parse(docstring)
    assert result.short_description == "This function does something."
    assert result.long_description == ""
    assert len(result.meta) == 1
    assert result.meta['returns'].args == ['The return value']
    assert len(result.args) == 1
    assert result.args[0].arg_name == 'arg1'
    assert result.args[0].description == 'The first argument'

# Generated at 2022-06-23 17:17:29.182841
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    try:
        assert callable(parse)
    except AssertionError as e:
        print("Function parse not defined\n")
        raise e
    try:
        assert type(parse("")) is Docstring
    except AssertionError as e:
        print("Function parse() does not return a Docstring object\n")
        raise e
    try:
        assert STYLES[Style.sphinx]('') == parse('')
    except AssertionError as e:
        print("Function parse() does not return a Sphinx Docstring object\n")
        raise e

# Generated at 2022-06-23 17:17:35.500373
# Unit test for function parse
def test_parse():
    text = """\
    :param int a: first param
    :param b: second param
    :raises RuntimeError: if baz
    """

    expected = Docstring(
        summary='',
        description='\n',
        params=[
            ('a', 'first param', 'int'),
            ('b', 'second param', None),
        ],
        exceptions=[
            ('RuntimeError', 'if baz'),
        ],
    )
    assert parse(text) == expected



# Generated at 2022-06-23 17:17:43.771291
# Unit test for function parse
def test_parse():
    from io import StringIO
    from unittest import TestCase, main as unittest_main, mock

    class ParseTests(TestCase):
        """Test parse."""

        @mock.patch('sys.stdout', new_callable=StringIO)
        def test_parse(self, mock_stdout):
            """Test parse."""
            parser = DocstringParser(docstring="text")
            parser.parse()
            expected_out = "Test parse.\n"
            self.assertEqual(mock_stdout.getvalue(), expected_out)

    unittest_main()

# Generated at 2022-06-23 17:17:48.540010
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    text = '''"""A simple string"""'''
    style = Style.google
    parse(text, style) == Docstring(text, style)


# Generated at 2022-06-23 17:17:58.569210
# Unit test for function parse
def test_parse():
    text = """
Args:
    arg1: The first argument.
    arg2: The second argument.
Returns:
    None
"""
    docstring = parse(text)
    assert docstring.args == [{"name": "arg1", "type": None, "desc": "The first argument."}, {"name": 'arg2', "type": None, "desc": "The second argument."}]
    assert docstring.returns == [{"type": "None", "desc": None}]
    assert docstring.meta == {"Args": "", "Returns": ""}
    assert docstring.summary == "The docstring for this function."
    assert docstring.extended_summary == ""
    assert docstring.body == 'This is the **body** of the docstring, with a `section`.'

# Generated at 2022-06-23 17:18:09.323443
# Unit test for function parse

# Generated at 2022-06-23 17:18:15.015207
# Unit test for function parse
def test_parse():
    """
    Test parse function
    """
    doc = parse("""
    Args:
      arg1: An argument
    """)
    assert doc.summary == ""
    assert doc.long_description == ""
    assert len(doc.args) == 1
    assert len(doc.returns) == 0

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:18:23.171162
# Unit test for function parse
def test_parse():
    doc = parse("""
    single-line docstring

    Args:
        arg1: the first argument
        arg2: the second argument
    Returns:
        something
    """)

# Generated at 2022-06-23 17:18:32.765003
# Unit test for function parse
def test_parse():
    ret = parse("""This is a summary line.

    This is the first paragraph.

    This is the second paragraph.

    Args:
        arg1 (int): First argument.

        arg2 (str): Second argument.

    Returns:
        int: Output value.

    Raises:
        ValueError: If the input is negative.
        TypeError: If the input is not a string.

    """)
    assert ret.meta['summary'] == 'This is a summary line.'
    assert ret.meta['description'] == 'This is the first paragraph.\n\nThis is the second paragraph.'
    assert [p['name'] for p in ret.meta['params']] == ['arg1', 'arg2']
    assert ret.meta['returns']['type'] == 'int'

# Generated at 2022-06-23 17:18:42.610463
# Unit test for function parse
def test_parse():
    text = """
    This is a function to test the parse function
    :param a: This is argument a
    :param b: This is argument b
    :return: whatever you input
    """

    assert parse(text) == parse(text, style=Style.google)

    assert parse(text) == parse(text, style=Style.numpy)

    assert parse(text) == parse(text, style=Style.sphinx)

    assert parse(text) == parse(text, style=Style.pep)

if __name__ == "__main__":
    test_parse()

    print ('passed')

# Generated at 2022-06-23 17:18:50.966761
# Unit test for function parse
def test_parse():
    test_string = '''
        test docstring
        :param a: test parameter a
        :param b: test parameter b
        :param c: test parameter c
        :throws ValueError1: if a is negative
        :throws ValueError2: if b is negative
        '''
    doc_string = parse(test_string)
    assert doc_string.short_description == 'test docstring'
    assert doc_string.body == ''
    assert doc_string.long_description == ''
    assert len(doc_string.meta) == 6
    assert [meta for meta in doc_string.meta if meta.type == "param" and meta.name == "a" and meta.description == "test parameter a"] != []

# Generated at 2022-06-23 17:18:58.396311
# Unit test for function parse
def test_parse():
    text1 = '''
    Hello

    :author: Wu
    :param a: a
    :returns: 2*a
    '''
    text2 = '''
    Hello

    This is a test that parses the docstring into Docstring object.

    :param a: a
    :param b: b
    :returns: a+b
    '''

    text3 = '''
    Hello

    This is a test that parses the docstring into Docstring object.

    :param a: a
    :param b: b
    :returns: a+b
    :raises: TypeError
    '''


# Generated at 2022-06-23 17:19:03.928791
# Unit test for function parse
def test_parse():
    ds = parse("""
        test1()

        test2()
    """)
    assert str(ds) == """test1()

    test2()"""

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:19:14.054263
# Unit test for function parse
def test_parse():
    from ddt import ddt, data
    import os
    import sys
    sys.path.append(os.getcwd())
    from data_driven_tests.reader_csv import read_csv
    STYLES = read_csv('data_driven_tests/data_driving_test_parse.csv')
    #print("STYLES: {}".format(STYLES))

    @ddt
    class TestParse:

        @data(*STYLES)
        def test_parse(self, style_data):
            docstring = style_data['docstring']
            print("docstring: {}".format(docstring))
            style = style_data['style']
            # print("style: {}".format(style))
            result = parse(text=docstring, style=style)

# Generated at 2022-06-23 17:19:19.559327
# Unit test for function parse
def test_parse():
    text = """
    Hello, world.

    This is a test.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: the return value
    :raises Exception: if any error occurs
    """

    parse(text)

# Generated at 2022-06-23 17:19:27.917593
# Unit test for function parse
def test_parse():
    text1 = """
    foo function

    :param str arg1:
        foo
    :param arg2:
        bar

    """
    assert(parse(text1) == Docstring(
        summary = "foo function",
        description = None,
        params = [
            ("arg1", "foo"),
            ("arg2", "bar")
        ],
        return_type = None,
        exceptions = None,
        is_reference = False,
        meta = {
            "param" : [
                (
                    "arg1",
                    "str",
                    None,
                    "foo"
                ),
                (
                    "arg2",
                    None,
                    None,
                    "bar"
                )
            ]
        }
    ))

# Generated at 2022-06-23 17:19:35.916720
# Unit test for function parse
def test_parse():
    text = """
    A summary line for a docstring.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    bool
        Description of return value

    """
    docstring = parse(text)
    print(docstring)
    print(repr(docstring))
    for field in docstring.meta:
        print(field.name, field.type_name)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:42.261622
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    assert parse('This is a docstring') == Docstring('''This is a docstring''')
    assert parse('This is a docstring', style=Style.google) == Docstring('''This is a docstring''')
    assert parse('This is a docstring', style=Style.reStructuredText) == Docstring('''This is a docstring''')
    assert parse('This is a docstring', style=Style.numpy) == Docstring('''This is a docstring''')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:48.288793
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == "Parse the docstring into its components.\n" \
                             "\n" \
                             "    :param text: docstring text to parse\n" \
                             "    :param style: docstring style\n" \
                             "    :returns: parsed docstring representation\n"

# Generated at 2022-06-23 17:19:57.023019
# Unit test for function parse
def test_parse():
    assert parse('''
        """
        This is the name
        This is the summary.  It is important.
    
        This is the description.  It is also important.
    
        This is the extended description.  It seriously goes on and on.
    
        :param name: The name
        :param value: The value
        :param other:  The other
        :type name: str
        :type value: object
        :type other: None
        :returns: The return value
        :raises: ValueError
        """
    ''').get_sections() == {
        "": "This is the summary.  It is important.",
        "Description": "This is the description.  It is also important."
        }

# Generated at 2022-06-23 17:20:08.449243
# Unit test for function parse
def test_parse():
    text = '''\
        short summary

        More detailed summary.

        Args:
            arg1 (int): the first argument
            arg2 (str): the second argument

        Returns:
            int: return value
            str: another return value
        '''
    styl = Style.NUMPY
    d = parse(text, styl)
    assert(d.short_description=="short summary")
    assert(len(d.long_description)==1)
    assert(d.long_description[0]=="More detailed summary.")
    assert(len(d.args)==2)
    assert(d.args[0].arg_name=='arg1')
    assert(d.args[0].type_name=='int')
    assert(d.args[0].description=='the first argument')

# Generated at 2022-06-23 17:20:18.146101
# Unit test for function parse
def test_parse():
    docstr = '''This function is used to test the parsing features of this package.

:param arg1: The first argument
:param arg2: The second argument
:returns: The return value

This is an example of a Google-style docstring.

Args:
    arg1 (int): The first argument.
    arg2 (str): The second argument.

Returns:
    bool: The return value. True for success, False otherwise.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.

'''
    result = parse(docstr, Style.google)
    assert result.short_description == "This function is used to test the parsing features of this package."

# Generated at 2022-06-23 17:20:29.053627
# Unit test for function parse
def test_parse():
    """Test function parse."""
    from docstring_parser.parser import parse
    from docstring_parser.styles.numpy import NumpyStyle
    from docstring_parser.styles.google import GoogleStyle

    docstring = """One line summary.

Extended description.

Args:
    arg1 (int): Description of `arg1`
    arg2 (str): Description of `arg2`

Returns:
    bool: Description of return value
"""

    doc = parse(docstring, style=GoogleStyle)
    doc0 = NumpyStyle(docstring)

    assert doc.short_description == doc0.short_description == "One line summary."
    assert doc.long_description == doc0.long_description == "Extended description."

# Generated at 2022-06-23 17:20:32.419769
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test
    :param test: test
    """
    doc = parse(docstring)
    assert doc.summary == "This is a test"
    assert doc.params[0].name == "test"



# Generated at 2022-06-23 17:20:39.142724
# Unit test for function parse
def test_parse():
    text = """
    Summary line.

    Extended description of function.

    :param int arg1: the first value
    :param arg2: the second value
    :type arg2: str
    :returns: description of return value
    :rtype: int
    :raises TypeError: if arg1 is not int
    """
    d = parse(text)
    print(d.summary)
    print(d.description)
    print(d.long_description)
    print(d.meta)

# Generated at 2022-06-23 17:20:40.904895
# Unit test for function parse
def test_parse():
    docstring = "Test Docstring"
    assert parse(docstring) == "Test Docstring"
    assert parse(docstring).style == Style.google

# Generated at 2022-06-23 17:20:53.014266
# Unit test for function parse
def test_parse():
    text = '''This technique is the fastest way to process any continuous data.

Parameters:
----------
  data : numpy.ndarray
    The array you want to normalize.
  axis : integer
    Specify the axis that you want to get statistics.
  bias : integer
    The bias value of the statistics.  Default is 1.

Returns:
-------
  numpy.ndarray
    The normalized array.

Examples:
--------
  >>> x = numpy.random.randn(10)
  >>> y = normalize(x)
  >>> x.mean()  # 0.1918...
  >>> y.mean()  # 1.0
  >>> z = normalize(x, axis=0, bias=0)
  >>> z.mean()  # -1.0

'''
    docstring = parse(text)

# Generated at 2022-06-23 17:21:00.947655
# Unit test for function parse
def test_parse():
    assert parse("""A multi-line docstring.

    :param foo: this is foo
    :type foo: int
    :param bar: this is bar
    :type bar: str
    :returns: nothing
    :rtype: None

    With a final line.""") == Docstring("""A multi-line docstring.

    :param foo: this is foo
    :type foo: int
    :param bar: this is bar
    :type bar: str
    :returns: nothing
    :rtype: None

    With a final line.""", ['foo', 'bar'], {'foo': 'int', 'bar': 'str'}, 'nothing', 'None')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:21:13.016787
# Unit test for function parse
def test_parse():
    # Test case for Function parse
    docstring = parse("""Hierarchical clustering of a data matrix.

Parameters
----------
data : ndarray
    Contingency table. The data can be thought as a 2-D array where the
    rows are the samples, the columns are the features, and the values are
    the observed frequencies.
data_dist : ndarray (optional)
    The distance matrix between the rows of the contingency table. If None,
    the data distances will be calculated using the metrics.

""")

    docstring.meta
    docstring.params
    docstring.returns

    # Test case for Function Documentation

# Generated at 2022-06-23 17:21:16.085827
# Unit test for function parse
def test_parse():
    text = '''
    Here is the first line.
    This is the docstring summary.
    This is the second line of the docstring.
    '''

    section = parse(text, Style.numpy)


# Generated at 2022-06-23 17:21:23.720815
# Unit test for function parse
def test_parse():
    ret = parse("""This is a docstring.
    This is another line.""", Style.google)
    assert ret.short_description == "This is a docstring."
    assert ret.long_description == "This is another line."

    ret = parse("""This is a docstring.
    This is another line.""", Style.google)
    assert ret.short_description == "This is a docstring."
    assert ret.long_description == "This is another line."

# Generated at 2022-06-23 17:21:25.798702
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    text = "An example of a docstring test"
    result = parse(text)
    assert(result.summary == text)

# Generated at 2022-06-23 17:21:35.396267
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    text = '''\
    :summary: Short summary.

    :param arg1: Argument 1.
    :keyword arg2: Keyword argument 2.
    :returns: return value.
    '''
    doc = parse(text)
    assert doc.summary == 'Short summary.'
    assert doc.arguments == [{'name': 'arg1', 'type': None, 'description': 'Argument 1.'}]
    assert doc.kwargs == [{'name': 'arg2', 'type': None, 'description': 'Keyword argument 2.'}]
    assert doc.returns == {'type': None, 'description': 'return value.'}

# Generated at 2022-06-23 17:21:44.624688
# Unit test for function parse
def test_parse():
    class test_class:
        def __init__(self):
            self.data = ""

    class test_f:
        def __init__(self, fname):
            self.data = ""
            self.fname = fname
            self.iter = 0
            self.num_o = 0
            self.num_c = 0

    test_list = []
    test_list.append(test_f('test_parse.py'))

    test_list[0].data = "This is a docstring"
    parse(test_list[0].data)

    test_list[0].data = "This is a docstring."
    parse(test_list[0].data)

    test_list[0].data = "This is a docstring that uses multiple lines."
    parse(test_list[0].data)

# Generated at 2022-06-23 17:21:46.040834
# Unit test for function parse
def test_parse():
    text = "This is a docstring."
    assert parse(text).content == text

# Generated at 2022-06-23 17:21:51.137807
# Unit test for function parse
def test_parse():
    assert(parse("hello").summary == "hello")
    assert(parse("hello", style=Style.numpy).summary == "hello")
    assert(parse("hello", style=Style.google).summary == "hello")
    assert(parse("hello", style=Style.sphinx).summary == "hello")

# Generated at 2022-06-23 17:21:59.205524
# Unit test for function parse
def test_parse():
    docstring = """
    Objective:
        Find the mean and median of array.

    Returns:
        mean: (float) The mean of array.
        median: (float) The median of array.

    Raises:
        ZeroDivisionError: When the input array is empty.
    """
    res = parse(docstring)
    assert res.params[0].name == 'array'
    assert res.params[0].type == 'array_like'
    assert res.params[0].desc == 'The input array.'
    assert res.returns[0].name == 'mean'
    assert res.returns[0].type == 'float'
    assert res.returns[0].desc == 'The mean of array.'
    assert res.returns[1].name == 'median'
    assert res.returns[1].type

# Generated at 2022-06-23 17:22:08.071358
# Unit test for function parse
def test_parse():
    text = """This is an example docstring.
    The text is indented.

    Arguments:
        param1: desc1
        param2 (type): desc2
        param3:
            sub1 (type): desc3
            sub2: desc3

    """
    a = parse(text)
    assert a.short_description == "This is an example docstring."
    assert a.long_description == "The text is indented."
    assert a.meta["param1"] == "desc1"
    assert a.meta["param2"] == "desc2"
    assert a.meta["param3"]["sub1"] == "desc3"
    assert a.meta["param3"]["sub2"] == "desc3"


# Generated at 2022-06-23 17:22:12.682401
# Unit test for function parse
def test_parse():
    s = '''Function to print hello world
    :param name: The name of the person.
    :type name: str
    :param int num: The number
    :returns: None
    :raises ValueError: If `name` is empty.
    '''
    
    d = parse(s)

# Generated at 2022-06-23 17:22:20.681106
# Unit test for function parse
def test_parse():
    """Test the main parser."""
    with open("docstring_parser/test/test_parse.txt", "r") as fh:
        text = fh.read()
    docstring = parse(text)
    assert docstring.short_description == "Test module"
    assert docstring.long_description == "With some\nlong description."
    assert docstring.meta["authors"] == ["Ian"]
    assert docstring.meta["blah"] == "something"
    assert len(docstring.params) == 1
    assert docstring.params["arg"].description == "The argument."
    assert len(docstring.raises) == 1
    assert docstring.raises["Exception"].description == "If something bad happens."

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:25.517092
# Unit test for function parse
def test_parse():
    docstring = """Authors: Me, Myself
    Params:
    ----------
    left : int, default is 5
        Description for left
    """
    ds = parse(docstring)
    assert(ds.params['left'] == 'Description for left')


# Generated at 2022-06-23 17:22:32.053115
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    This is a section.
    """
    import textwrap
    text = textwrap.dedent(text).strip()
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == "\nThis is a section."
    assert not docstring.meta


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:37.694780
# Unit test for function parse
def test_parse():
    text = """\
        Hello and welcome to this lovely module.

        This module was written by John Snow.

        :Args:
          - a: Not a noun, but a.
          - b: A noun.

        :Raises:
          - An error.
          - Another error.

        :Returns:
          this thing.

        :todo: finish this docstring
    """

    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:47.132057
# Unit test for function parse
def test_parse():
    text = """Description of the function.

    :param name: the name to say hello to
    :type name: str
    :param title: the title of this person
    :type title: str, optional
    :param capital: whether to capitalize the name or not
    :type capital: bool, optional
    :returns: None
    :raises ValueError: If `name` is empty or not a string
    :Example:

    >>> hello("jack", title="sir")
    Hello sir Jack!
    """

    docstring = parse(text, style=Style.google)
    assert docstring.short_description == "Description of the function."
    assert docstring.long_description == "Description of the function.\n\n"
    assert "name" in docstring.params

# Generated at 2022-06-23 17:22:57.398155
# Unit test for function parse

# Generated at 2022-06-23 17:23:05.350181
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    print(parse.__doc__)
    # assert parse.__doc__ == 'The main parsing routine.'
    docstring = Docstring(description='\n'
                                      'The main parsing routine.\n'
                                      '\n',
                          params=['text: str', 'style: Style=Style.auto'],
                          returns='parsed docstring representation',
                          meta={})
    # print(parse('The main parsing routine.','Description'))
    assert parse('The main parsing routine.',style='style') == docstring

# Generated at 2022-06-23 17:23:17.549786
# Unit test for function parse

# Generated at 2022-06-23 17:23:24.565246
# Unit test for function parse
def test_parse():
    """Test function parse"""

    # test parse with style.auto
    docstr = '''
        short summary.

        Extended summary 
            
        Parameters
        ----------
        arg1 : int
            Description of `arg1` (with type annotation).
        arg2 : str
            Description of `arg2`
            
        Returns
        -------
        int
            Description of the return value.
        '''
    style_docstring = parse(docstr, style=Style.google)
    assert style_docstring.short_description == 'short summary.'
    assert style_docstring.long_description == 'Extended summary'
    assert style_docstring.summary() == 'short summary.'
    assert style_docstring.parameters[0].arg_name == 'arg1'
    assert style_docstring.parameters[0].arg_

# Generated at 2022-06-23 17:23:31.301180
# Unit test for function parse
def test_parse():
    text = """
    Parameters
    ----------
    arg1 : str
        the first argument
    arg2 : int
        the second argument
    """

    docstring = parse(text)
    assert docstring.meta['arg1']['type_name'] == 'str'
    assert docstring.meta['arg2']['type_name'] == 'int'

if __name__ == "__main__":
    test_parse()

    print("Unit tests passed")

# Generated at 2022-06-23 17:23:35.290388
# Unit test for function parse
def test_parse():
    example_docstring = '''Example function with types documented in the docstring.
    :param int a: The value for a.
    :param str b: The value for b.
    :returns: The return value.
    :rtype: int
    '''
    assert parse(example_docstring, "google") is not None


# Generated at 2022-06-23 17:23:38.808092
# Unit test for function parse
def test_parse():
    text = '''
    """
        My first line.
        My second line.

    """
    '''
    print(parse(text))

test_parse()

# Generated at 2022-06-23 17:23:48.445910
# Unit test for function parse
def test_parse():
    text = """This is the first line of a docstring.
    This is the second line of the docstring.
    """
    dstr = parse(text)
    assert dstr.short_description == "This is the first line of a docstring."
    assert dstr.long_description == "This is the second line of the docstring."
    assert dstr.meta == {}

    text = """This is the first line of a docstring.
    This is the second line of the docstring.
    :param arg1: Does nothing.
    :param arg2: Does slightly less than nothing.
    :returns: Does nothing.
    :raises keyError: Raises an exception
    """
    dstr = parse(text)
    assert dstr.short_description == "This is the first line of a docstring."

# Generated at 2022-06-23 17:23:59.759427
# Unit test for function parse
def test_parse():
    docstring = """\
        Test function for docstring parser.

        Args:
            param1 (int): The first parameter.
            param2 (str): The second parameter.

        Returns:
            bool: The return value. True for success, False otherwise.
        """
    result = parse(docstring).to_dict()
    print(result)
    expect = {
        'args': [
            {'name': 'param1', 'type': 'int'}, 
            {'name': 'param2', 'type': 'str'}
        ], 
        'returns': [
            'bool: The return value. True for success, False otherwise.'
        ], 
        'description': ['Test function for docstring parser.']
    }
    assert result == expect

if __name__ == '__main__':
    test_

# Generated at 2022-06-23 17:24:03.024355
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    #TODO: write a unit test for this function
    pass


# Generated at 2022-06-23 17:24:04.178116
# Unit test for function parse
def test_parse():
    return

# Generated at 2022-06-23 17:24:15.237400
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    from docstring_parser.styles import google, numpy, reST

    text_ar = \
        """ Single line.
        """
    text_def = \
        """ Summary line.

        Extended description.

        Args:
            arg1: Description of `arg1`.
        """
    text_func = \
        """ Compute the square of a number.

        Args:
            x (float): The number to square.

        Returns:
            float: The square of number `x`.
        """
    text_meth = \
        """ Compute the square of a number.

        Args:
            self: This object.
            x (float): The number to square.

        Returns:
            float: The square of number `x`.
        """

# Generated at 2022-06-23 17:24:18.274924
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring

    assert parse("") == GoogleDocstring("")

# Generated at 2022-06-23 17:24:19.209349
# Unit test for function parse
def test_parse():
    docstring = '''Sample docstring.'''
    d = parse(docstring)
    assert d

# Generated at 2022-06-23 17:24:27.986530
# Unit test for function parse
def test_parse():
    text = """
    This is a great function.

    :param foo:  This is an integer.
    :type foo:  int
    :rtype:  str
    :returns:  A string.
    """
    result = parse(text)
    assert result.short_description == "This is a great function."
    assert result.long_description == ""

    assert result.returns.description == "A string."
    assert result.returns.type == "str"
    assert result.returns.name == ""

    assert len(result.params) == 1
    assert len(result.raises) == 0

    assert result.params["foo"].description == "This is an integer."
    assert result.params["foo"].type == "int"


# Generated at 2022-06-23 17:24:34.389395
# Unit test for function parse
def test_parse():
    assert parse('Lorem\n:param foo:\nipsum') \
        == parse('\nLorem\n:param foo:\nipsum\n')
    assert parse('\nLorem\n:param foo:\nipsum') \
        != parse('\nLorem\n:param foo:bar\nipsum\n')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:45.285484
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ReturnItem, ParamItem
    from docstring_parser.styles import Style
    from fractions import Fraction
    from typing import Any

    text = '''
        Parameters
        ----------
        text : str
            text to parse
        style : Style = Style.auto
            docstring style
        return d : Docstring
            parsed docstring representation
    '''

    d = parse(text)
    assert d.meta['Parameters'] == [ParamItem('text', 'str', 'text to parse'),
                                    ParamItem('style', 'Style', 'docstring style', default = Style.auto)]
    assert d.meta['Returns'] == [ReturnItem('d', 'Docstring', 'parsed docstring representation')]


# Generated at 2022-06-23 17:24:49.280162
# Unit test for function parse

# Generated at 2022-06-23 17:24:58.746251
# Unit test for function parse
def test_parse():
    if __name__ == "__main__":
        print("\nTesting function parse...")

        try:
            text = '''
            Heading
            =======

            Subheading
            ----------

            <text>

            A variable.
            '''
            assert parse(text) == Docstring(
                summary="Heading",
                description="Subheading",
                extra_args="<text>",
                args={"heading": "A variable."},
                returns=[],
                metadata={"Heading": ["Subheading", "A variable."]},
                meta=[],
                style=Style.numpy,
            )
            print("  PASS")
        except:
            print("  FAIL")


# Generated at 2022-06-23 17:25:10.595399
# Unit test for function parse
def test_parse():
    """Test for parse function using the func-funcdef-return style
    """

    # Creates a temporary docstring_parser file with a specific format
    import tempfile
    
    f = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-23 17:25:13.481936
# Unit test for function parse
def test_parse():
    """Validate the style selection works as expected."""

    from docstring_parser.styles import GoogleStyle

    assert isinstance(parse(""), Docstring)
    assert isinstance(parse("", Style.google), GoogleStyle)

# Generated at 2022-06-23 17:25:19.148371
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle
    docstring = """This is a function.

    Args:
        arg1 (int): the first value
        arg2 (str): the second value

    Returns:
        bool: the return value

    Raises:
        AttributeError
    """
    doc = parse(docstring)
    assert len(doc) == 4
    doc = parse(docstring, style=NumpyStyle)

# Generated at 2022-06-23 17:25:30.866755
# Unit test for function parse
def test_parse():
    docstr = '''
        This function tests whether the parse function works as intended.
        The following arguments are accepted:
        :param name: The user's name
        :param age: The user's age
        :param weight: The weight of a user
    '''
    res = parse(docstr)

# Generated at 2022-06-23 17:25:37.358518
# Unit test for function parse
def test_parse():
    text = ("This is a test.\n" +
            "  This is a test.\n" +
            "  This is a test.\n" +
            "  This is a test.\n")
    assert parse(text, style=Style.google) == parse(text, style=Style.google)
    assert parse(text, style=Style.numpy) == parse(text, style=Style.numpy)


# Generated at 2022-06-23 17:25:44.293562
# Unit test for function parse
def test_parse():
    import pytest


# Generated at 2022-06-23 17:25:54.976543
# Unit test for function parse
def test_parse():
    docstring = """Parses docstring into its parts.

    :param text:  docstring to parse
    :type text: str
    :param style: docstring style
    :type style: docstring_parser.Style
    :returns: parsed docstring representation
    :rtype: docstring_parser.Docstring
    """


# Generated at 2022-06-23 17:26:04.031891
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyDocstring, GoogleDocstring
    from docstring_parser.common import Docstring
    assert parse("\nFoo bar\n") == Docstring(" Foo bar", "", "", "", "")
    assert parse("Foo bar\n") == Docstring("Foo bar", "", "", "", "")
    assert parse("Foo bar\n", style='google') == GoogleDocstring("Foo bar", "", "", "", "")
    assert parse("Foo bar\n", style='numpy') == NumpyDocstring("Foo bar", "", "", "", "")

# Generated at 2022-06-23 17:26:13.957784
# Unit test for function parse
def test_parse():

    text = """
The first line is brief explanation, which may be completed with
a longer one. For instance, to discuss about its functionalities.

The only argument `bar` is the only argument, which does nothing.

:param bar: description of `bar`, which may include markup like
            *emphasis* or `code()`.
:type bar: str
:returns: description of the return value
:rtype: bool
:raises ImportError: when the module is not found
"""

    docstring = parse(text)

    assert docstring.short_description == 'The first line is brief explanation, which may be completed with a longer one. For instance, to discuss about its functionalities.'
    assert docstring.long_description == 'The only argument `bar` is the only argument, which does nothing.\n'

# Generated at 2022-06-23 17:26:22.806467
# Unit test for function parse
def test_parse():
    text = """\
        Summary line.

        Extended description.

        Args:
          arg1 (int): Description of `arg1`
          arg2 (str): Description of `arg2`

        Returns:
          bool: Description of return value

        Raises:
          AttributeError: The ``Raises`` section is a list of all exceptions
          that are relevant to the interface.
          ValueError: If `arg2` is equal to `arg1`.
        """
    docstring = parse(text)
    # print(docstring.short_description)
    # print(docstring.long_description)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == 'Extended description.'
    assert docstring.returns.type_name == 'bool'