

# Generated at 2022-06-23 17:16:33.907863
# Unit test for function parse
def test_parse():
    docstring = parse("""This function is to test the function parse
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation""")

    assert(docstring.short_description == 'This function is to test the function parse\n')
    assert(docstring.long_description == '')
    assert(len(docstring.params) == 2)
    assert(docstring.params[0].arg_name == 'text')
    assert(docstring.params[0].type_name == '')
    assert(docstring.params[0].description == 'docstring text to parse')
    assert(docstring.params[1].arg_name == 'style')
    assert(docstring.params[1].type_name == '')

# Generated at 2022-06-23 17:16:44.076954
# Unit test for function parse
def test_parse():
    import os
    import sys
    from docstring_parser.common import Docstring, Parameter, ReturnValue
    from docstring_parser import parse
    filepath = os.path.realpath(__file__)
    directory = os.path.dirname(filepath)
    # sys.path.insert(0, directory + "../")
    filepath_test = directory + "/test_parse.py"
    # print(filepath)
    # print(sys.path)
    # print(filepath_test)
    with open(filepath_test, 'r') as f:
        docstring_text = f.read()
    docstring = parse(docstring_text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "Parses the docstring into its components."
    assert doc

# Generated at 2022-06-23 17:16:56.269634
# Unit test for function parse
def test_parse():
    docstring = parse('''
This is a test docstring for a function.
    
    :param x: abc
    :type x: str
    :param y: 123
    :type y: int
    :param z: xyz
    :type z: bool
''')
    assert docstring.short_description == "This is a test docstring for a function."
    assert docstring.long_description == ""
    assert docstring.tags[0].arguments == "x"
    assert docstring.tags[0].valid_types == ["str"]
    assert docstring.tags[0].default == None
    assert docstring.tags[0].description == "abc"
    assert docstring.tags[1].arguments == "y"
    assert docstring.tags[1].valid_types == ["int"]
    assert docstring

# Generated at 2022-06-23 17:17:03.975357
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a test docstring.

    :param test_parameter: The test parameter
    :keyword keyword_arg: the keyword arg
    :returns: something
    :rtype: something
    '''

# Generated at 2022-06-23 17:17:09.950354
# Unit test for function parse
def test_parse():
    text = '''This is a simple test for function parse
        Parameters
        ----------
        text : str
            docstring text to parse
        style : Style = Style.auto
            docstring style
        Returns
        -------
        Docstring
            parsed docstring representation
    '''
    parse_result = parse(text)
    assert len(parse_result.params) == 2
    assert len(parse_result.returns) == 1


# Generated at 2022-06-23 17:17:19.142819
# Unit test for function parse
def test_parse():
    text = """\
    This is a docstring
    It will do something
    Console line
        """
    d = parse(text)
    assert d.short_description == 'This is a docstring'
    assert d.long_description == 'It will do something'
    assert d.params == {'Console line':''}
    assert d.meta == {}

    text = """\
    This is a docstring
    It will do something
    Console line
    :param parameter1: this is a parameter
        """
    d = parse(text)
    assert d.short_description == 'This is a docstring'
    assert d.long_description == 'It will do something'
    assert d.params == {'Console line':''}
    assert d.meta == {'parameter1': 'this is a parameter'}

    text

# Generated at 2022-06-23 17:17:30.511966
# Unit test for function parse
def test_parse():
	class test_class:
		def test_method(self):
			pass

	def test_function():
		pass

	assert parse(test_function.__doc__) == parse(test_class.test_method.__doc__)


# Generated at 2022-06-23 17:17:38.777301
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import google
    doc = """One line summary.

Extended description.

Args:
  arg1 (int): Description of `arg1`
  arg2 (str): Description of `arg2`
Returns:
  bool: Description of return value
"""

    docstring = parse(doc)
    assert docstring.short_description == 'One line summary.'
    assert docstring.long_description == 'Extended description.\n'
    assert len(docstring.args) == 2
    assert len(docstring.returns) == 1
    google_docstring = google(doc)
    assert google_docstring.short_description == 'One line summary.'
    assert google_docstring.long_description == 'Extended description.\n'
    assert len(google_docstring.args) == 2
   

# Generated at 2022-06-23 17:17:48.212423
# Unit test for function parse
def test_parse():
    import sys
    #import os
    #import io
    #import traceback
    #from test.test_utils import run_unittest
    #from test.support import check_warnings
    #from test.support import TESTFN, unlink, run_unittest
    #from test.support import import_module

    #print(os.path.abspath(__file__))
    #print(os.path.dirname(os.path.abspath(__file__)))
    #print(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    #print(os.path.basename(__file__))
    #print(os.path.dirname(__file__))
    print(sys.path[0])
    #print(os.path.

# Generated at 2022-06-23 17:17:54.292076
# Unit test for function parse
def test_parse():
    doc = parse(""" This is a function to add x, y""", style=Style.numpy)
    assert doc.short_description == 'This is a function to add x, y'
    doc = parse(""" This is a function to add x, y""", style=Style.google)
    assert doc.short_description == 'This is a function to add x, y'


# Generated at 2022-06-23 17:18:00.817950
# Unit test for function parse
def test_parse():
    # Unit test 1
    text = "A library that parses docstrings."
    docstring = parse(text)
    if not docstring.short_description == text:
        print ("test_parse 1.1 failed")
        print (docstring.short_description)
    if not docstring.style == Style.google:
        print ("test_parse 1.2 failed")
        print (docstring.style)

    # Unit test 2
    text = '''Here are all the things you can do:

    1. Format text as a string.
    2. Format docstring into its components (short, long, etc.).
    3. Check if a docstring is well formed.'''
    docstring = parse(text)
    if not docstring.long_description == text:
        print ("test_parse 2.1 failed")

# Generated at 2022-06-23 17:18:08.701394
# Unit test for function parse
def test_parse():
    from .examples import numpy_example
    numpy_docstring = parse(numpy_example)
    print(numpy_docstring.short_description)
    print(numpy_docstring.long_description)
    print(numpy_docstring.meta)
    assert numpy_docstring.short_description == "Perform a linear least-squares fit."
    assert numpy_docstring.meta['Parameters'][0].args == ("x",)
    assert numpy_docstring.meta['Returns'][0].type_name == "tuple"
    assert numpy_docstring.meta['Raises'][0].exception_name == "ValueError"

# Generated at 2022-06-23 17:18:18.662062
# Unit test for function parse
def test_parse():

	text = """Misc zero-dimensional tensor type.

	Args:
		arg1: The first argument.
		arg2: The second argument.

	"""
	expect = Docstring(summary=['Misc zero-dimensional tensor type.'], args=['arg1', 'arg2'], arg_desc=['The first argument.', 'The second argument.'])
	assert(parse(text) == expect)
	text = """Returns a short description of the export.

        The export is uniquely identified by its name.
        So this method returns a short human-readable description of the export.

        Args:
            name: The name of the export.
            export_args: The export's arguments.

        Returns:
            A short human-readable description of the export.

        """

# Generated at 2022-06-23 17:18:26.884399
# Unit test for function parse
def test_parse():
    assert parse("Function 1: Summary") == Docstring(summary="Summary")
    assert parse("Function 1: Summary", Style.google) == Docstring(summary="Summary")
    assert parse("@brief Function 1: Summary", Style.doxygen) == Docstring(summary="Summary")
    assert parse("Function 1: Summary....", Style.numpy) == Docstring(summary="Summary")
    assert parse("Function 1: Summary....", Style.sphinx) == Docstring(summary="Summary")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:18:33.435324
# Unit test for function parse
def test_parse():
    docstring = parse("""Function parse_args
    Reads arguments from the command line and returns an argparse
    object.
    :return: the populated namespace
    :rtype: argparse.Namespace
    """)
    assert(docstring.short_description == "Function parse_args")
    assert(docstring.long_description == "Reads arguments from the command line and returns an argparse object.")
    assert(docstring.return_type == "argparse.Namespace")
    assert(docstring.returns == "the populated namespace")


# Generated at 2022-06-23 17:18:43.993045
# Unit test for function parse
def test_parse():
    text = """\
Return the value of 2 to the power of x.

:param x: the number to raise 2 to
:type x: int or float
:param y: the second parameter
:returns: 2 ** x
:raises ValueError: if x isn't numeric"""

    assert parse(text) == Docstring(
        summary='Return the value of 2 to the power of x.',
        body='',
        meta={
            'Returns': '2 ** x',
            'Raises': 'ValueError: if x isn\'t numeric',
            'Parameters': [
                {'x': 'the number to raise 2 to',
                 'y': 'the second parameter'}]
        })


__all__ = ['parse']

# Generated at 2022-06-23 17:18:44.887507
# Unit test for function parse
def test_parse():
    assert parse("") is not None

# Generated at 2022-06-23 17:18:54.655297
# Unit test for function parse
def test_parse():
    doc = '''This is the first paragraph.
    This is the second paragraph.
    '''
    assert parse(doc).full_text == doc
    # Test for Unicode characters
    assert parse('\xbfHola Mundo?').full_text == '\xbfHola Mundo?'
    assert parse('\xbfHola Mundo?\n\n').full_text == '\xbfHola Mundo?\n'
    assert parse('\xbfHola Mundo?\nAqu\xed hay m\xe1s texto.').full_text == '\xbfHola Mundo?\nAqu\xed hay m\xe1s texto.'
    
test_parse()


# Generated at 2022-06-23 17:18:59.153812
# Unit test for function parse
def test_parse():
    s = """Some text.
    :param a: the first parameter
    :param b: the second parameter
    :returns: the return value
    """
    expected = Docstring("""Some text.
    """, {
        'a': 'the first parameter',
        'b': 'the second parameter',
        }, 'the return value')
    assert parse(s) == expected

# Generated at 2022-06-23 17:19:03.349467
# Unit test for function parse

# Generated at 2022-06-23 17:19:06.993522
# Unit test for function parse
def test_parse():
    text = '''
    This is text
    '''
    style = 'numpy'
    docstring = parse(text, style)
    print(docstring)
    print(docstring.short_description)


# Generated at 2022-06-23 17:19:09.436690
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:17.838457
# Unit test for function parse
def test_parse():
    # Check for function docstring
    def add(x, y):
        """
        Do addition of two numbers x and y.

        :param x: number
        :param y: number
        """
        return x + y

    docstr = parse(add.__doc__)
    assert len(docstr.short_description) == 30
    assert len(docstr.long_description) == 0
    # Check for method docstring
    class A:
        def add(self, x, y):
            """
            Do addition of two numbers x and y.

            :param x: number
            :param y: number
            """
            return x + y

    docstr = parse(A.add.__doc__)
    assert len(docstr.short_description) == 30
    assert len(docstr.long_description) == 0


# Generated at 2022-06-23 17:19:28.095788
# Unit test for function parse
def test_parse():

    # test auto style
    test_str1 = \
    '''
    """
    This function test function parse.
    It takes as input a string and return nothing.
    
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    '''
    assert parse(test_str1).short_description == 'This function test function parse.'
    assert parse(test_str1).long_description == 'It takes as input a string and return nothing.'
    assert parse(test_str1).params == {'text':'docstring text to parse', 'style':'docstring style'}
    assert parse(test_str1).returns == 'parsed docstring representation'

    # test numpy style

# Generated at 2022-06-23 17:19:33.537963
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    print(parse.__doc__)
    text="""This is the first sentence. This is the second sentence"""
    print(parse(text, style=Style.rst).short_description())
    print(parse(text, style=Style.numpy).short_description())


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:41.703888
# Unit test for function parse
def test_parse():
    doc = parse("""
        aaaa

        Parameters
        ----------
        arg1 : str
            aaaaa

        arg2 : int
            bbbbb

        Returns
        -------
        str
            My return!
        """)

    assert doc.meta['Parameters'][0].arg_name == 'arg1'
    assert doc.meta['Parameters'][0].type_name == 'str'
    assert doc.meta['Parameters'][0].description == 'aaaaa'
    assert doc.meta['Parameters'][1].arg_name == 'arg2'
    assert doc.meta['Parameters'][1].type_name == 'int'
    assert doc.meta['Parameters'][1].description == 'bbbbb'

    assert doc.returns.type_name == 'str'

# Generated at 2022-06-23 17:19:44.839664
# Unit test for function parse
def test_parse():
    text = """
    
    :param param1: This is a first param
    :param param2: This is a second param
    :returns: All the return
    :raises keyError: raises an exception
    """
    
    parsed = parse(text)
    check = {'params': [('param1', 'This is a first param'), ('param2', 'This is a second param')],
             'raises': [('keyError', 'raises an exception')],
             'returns': 'All the return'}
    assert(parsed.meta == check)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:55.002395
# Unit test for function parse
def test_parse():
    assert parse('Hello') == Docstring('Hello\n', '', '', '')
    assert parse('Hello!') == Docstring('Hello!\n', '', '', '')
    assert parse('Hello', Style.napoleon) == Docstring('Hello\n', '', '', '')
    assert parse('Hello!', Style.napoleon) == Docstring('Hello!\n', '', '', '')
    assert parse('Hello', Style.google) == Docstring('Hello\n', '', '', '')
    assert parse('Hello!', Style.google) == Docstring('Hello!\n', '', '', '')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:20:01.768581
# Unit test for function parse
def test_parse():
    text = """one more test
    :param a: a test value
    :return: a test return value
    """
    docstring = parse(text)
    assert docstring.short_description == "one more test"
    assert docstring.long_description == ""
    assert docstring.meta["parameters"]["a"] == "a test value"
    assert docstring.meta["return"] == "a test return value"

# Generated at 2022-06-23 17:20:06.725453
# Unit test for function parse
def test_parse():
    text = """This is the documentation string.
    It is on multiple lines, indented 4 spaces."""
    docstring = parse(text)
    assert docstring.meta == []
    assert docstring.short_description == "This is the documentation string."
    assert docstring.long_description == ("It is on multiple lines, indented 4 "
                                          "spaces.")


# Generated at 2022-06-23 17:20:16.892613
# Unit test for function parse
def test_parse():
    d = parse("""
    Hello world.
    """)
    assert d.short_description == "Hello world."
    assert d.long_description == ""

    d = parse("""
    Hello world.

    Goodbye world.
    """)
    assert d.short_description == "Hello world."
    assert d.long_description == "Goodbye world."

    d = parse("""
    Hello world.

    :param testing: test
    """)
    assert d.short_description == "Hello world."
    assert d.long_description == ""
    assert len(d.params) == 1

    d = parse("""
    Hello world.

    :returns: test
    """)
    assert d.short_description == "Hello world."
    assert d.long_description == ""
    assert d.returns is not None

# Generated at 2022-06-23 17:20:20.964102
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param x: int
:returns: int
"""
    parsed = parse(text)
    assert parsed.args == []
    assert parsed.returns
    assert parsed.meta['returns'].args == ['int']
    assert parsed.meta['x'].args == ['int']

# Generated at 2022-06-23 17:20:22.486256
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=False)

# Generated at 2022-06-23 17:20:31.057205
# Unit test for function parse
def test_parse():
    d = parse("""Parse the docstring into its components.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
""")
    assert d.short_description == "Parse the docstring into its components."
    assert len(d.long_description) == 0
    assert len(d.meta) == 3
    assert 'text' in d.meta
    assert 'style' in d.meta
    assert 'returns' in d.meta

# Test result from function test_parse
test_parse()

# Generated at 2022-06-23 17:20:40.985484
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google, NumPy, reStructuredText
    from docstring_parser import Docstring, Description, Meta, Param, Return
    from docstring_parser import ParseError

    doc_str = """
    This is a description.

    And another one.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: some value
    """
    doc = parse(doc_str)

    assert doc == NumPy(doc_str)
    assert doc == Google(doc_str)
    assert doc == reStructuredText(doc_str)
    assert not doc == Google("")
    assert isinstance(doc, Docstring)

    # Test the properties
    assert doc.description == Description("This is a description.\n\nAnd another one.")
    assert doc.meta

# Generated at 2022-06-23 17:20:53.021367
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", None, None, None)
    assert parse("""\
description
""") == Docstring("description", None, None, None)
    assert parse("""\
description

:param a: a
""") == Docstring("description", None, [(None, "a", "a")], None)

    assert parse("""\
description

:param a: a
:return: b
""") == Docstring("description", None, [(None, "a", "a")], "b")

    assert parse("""\
description

:param a: a
:type a: aa
:param b: b
:type b: bb
:return: b
""") == Docstring("description", None, [(None, "a", "aa"), (None, "b", "bb")], "b")



# Generated at 2022-06-23 17:20:59.231262
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "", "", "")
    assert parse("""\
        Test

        Parameters
        ----------
        a : int
            Test

        Returns
        -------
        b : int
            Test
        """) == Docstring("Test",
                "Parameters\n----------\na : int\n    Test",
                "Returns\n-------\nb : int\n    Test", "")

# Generated at 2022-06-23 17:21:10.548759
# Unit test for function parse
def test_parse():
    """
    >>> docstring = parse("A function that does something.  This is a useful function.")
    >>> vars(docstring)
    {'summary': 'A function that does something.', 'description': ' This is a useful function.'}
    >>> docstring = parse("Parameters:\\n\\targ1 (int): the first argument\\n\\targ2 (str): the second argument\\nReturns:\\n\\tstr: the return value", 'numpy')
    >>> vars(docstring)
    {'meta': [DocstringSection(title='Parameters', content=['\\targ1 (int): the first argument', '\\targ2 (str): the second argument']), DocstringSection(title='Returns', content=['\\tstr: the return value'])], 'summary': '', 'description': ''}
    """
    pass



# Generated at 2022-06-23 17:21:12.916053
# Unit test for function parse
def test_parse():
    d = """This is a function.
    :param a: This is a
    """
    p = parse(d)

# Generated at 2022-06-23 17:21:20.861354
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    # example from http://sphinx-doc.org/domains.html#info-field-lists

# Generated at 2022-06-23 17:21:24.450868
# Unit test for function parse
def test_parse():
    assert parse("""\
    Test function.

    :param test_1: some test
    :type test_1: str
    """) == parse("""\
    Test function.

    :param test_1: some test
    :type test_1: str
    """, Style.sphinx)


# Generated at 2022-06-23 17:21:27.152347
# Unit test for function parse
def test_parse():
	text = '''This is a docstring.
    :param str id: This is a parameter.
    :return: This is a return value.
    '''
	style = Style.numpy
	parse(text, style)
	

# Generated at 2022-06-23 17:21:31.839720
# Unit test for function parse
def test_parse():
	try:
		with open('./test.py', 'r') as f:
			docstring = f.read()
		print(parse(docstring))
	except FileNotFoundError:
		raise

if __name__ == '__main__':
	test_parse()

# Generated at 2022-06-23 17:21:42.378188
# Unit test for function parse
def test_parse():
    # Single line
    assert parse('Test') == Docstring(content=[], meta={'summary': 'Test'})

    # Summary with wrap
    text = 'Test' * 20
    assert parse(text) == Docstring(content=[], meta={'summary': text})

    # Google
    text = 'Test\n'
    assert parse(text, style=Style.google) == Docstring(content=[], meta={'summary': text})

    # Google
    text = 'Test\n\nMore test\n'
    assert parse(text, style=Style.google) == Docstring(content=[], meta={'summary': 'Test'})

    # Google
    text = 'Test\n\nMore test\n' * 2

# Generated at 2022-06-23 17:21:50.504230
# Unit test for function parse
def test_parse():
    # Test every style
    for style in STYLES.keys():
        docstring = parse("""
            Line 1
            Line 2
            Line 3
        """, style=style)
        assert isinstance(docstring, Docstring)
        assert len(docstring.lines) == 3

    # Test auto style
    docstring = parse("""
        Line 1
        Line 2
        Line 3
    """)
    assert isinstance(docstring, Docstring)
    assert len(docstring.lines) == 3


# Generated at 2022-06-23 17:21:58.880680
# Unit test for function parse
def test_parse():
    class ClassWithoutDocstring:
        pass

    class ClassWithDocstring:
        "The docstring-ed class."

    assert parse("") == Docstring()

    # Trivial example
    assert parse("My docstring.") == Docstring("My docstring.")

    # Examples
    assert parse("My docstring.\n\nExamples:\n\n>>> import foo\n>>> foo.MyClass()\n<MyClass>") == Docstring("My docstring.", examples=[">>> import foo\n>>> foo.MyClass()\n<MyClass>"])

    # Returns
    assert parse("My docstring.\n\nReturns:\n    str: the return value") == Docstring("My docstring.", returns="str: the return value")

    # Yields

# Generated at 2022-06-23 17:22:08.393352
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    docstring = """
    This line is the short summary.
    It occurs directly after the one-line summary.
    More lines can be added here.
    """
    assert parse(docstring).short_description == "This line is the short summary."

    docstring = """
    This line is the short summary.
    It occurs directly after the one-line summary.
    More lines can be added here.
    :returns: nothing
    """
    assert parse(docstring).returns.raw == "nothing"

    docstring = """
    This line is the short summary.
    It occurs directly after the one-line summary.
    More lines can be added here.
    :param arg1: first arg
    :param arg2: second arg
    :returns: nothing
    """

# Generated at 2022-06-23 17:22:16.543799
# Unit test for function parse
def test_parse():
    assert parse(
        """Summary line.

        Extended description.

        Args:
            param1: Description of param1.
            param2: Description of param2.

        Returns:
            Description of return value.
        """
    ) == Docstring(
        summary="Summary line.",
        description="Extended description.\n",
        tags=[
            Docstring.Tag(tag="param", name="param1", description="Description of param1."),
            Docstring.Tag(tag="param", name="param2", description="Description of param2."),
            Docstring.Tag(tag="return", name="", description="Description of return value."),
        ],
        meta={},
    )

# Generated at 2022-06-23 17:22:23.168254
# Unit test for function parse
def test_parse():
    docstring_text = """
    :param x: First parameter
        with a long description
    :param y: Second param
        on two lines
    :returns: a thing
    """
    docstring = parse(docstring_text)
    assert str(docstring) == docstring_text
    assert docstring.params['x'].description == 'First parameter\n    with a long description'
    assert docstring.params['y'].description == 'Second param\n   on two lines'
    assert docstring.returns == 'a thing'
    # Test simplification too
    assert str(docstring.shorten()) == '    :param x:\n    :param y:\n    :returns:'

# Generated at 2022-06-23 17:22:32.761506
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param str arg1: The first argument.
"""

    docstring = parse(text)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."
    assert docstring.meta["arg1"].name == "arg1"
    assert docstring.meta["arg1"].type_name == "str"
    assert docstring.meta["arg1"].description == "The first argument."
    assert docstring.meta["arg1"].default == ""

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:37.580687
# Unit test for function parse
def test_parse():
    docstring = """Description line.
    Parameters:
        p1 (int): Description of p1.
        p2 (str): Description of p2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: If `bar` is less than `foo`.

    """
    parse(docstring)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:47.058959
# Unit test for function parse
def test_parse():
	parsed = parse('Here is a docstring.')
	print(parsed.text)
	print(parsed.meta)
	assert parsed.text == 'Here is a docstring.'
	assert parsed.meta == {}
	parsed = parse('Here is a docstring.\n:param foo: with a parameter')
	print(parsed.text)
	print(parsed.meta)
	assert parsed.text == 'Here is a docstring.'
	assert parsed.meta == {'foo': 'with a parameter'}
	parsed = parse('Here is a docstring.\n:param foo: with a parameter\n:return: Something!')
	print(parsed.text)
	print(parsed.meta)
	assert parsed.text == 'Here is a docstring.'

# Generated at 2022-06-23 17:22:57.392534
# Unit test for function parse
def test_parse():
    text = '''
    This is the description for parse.

    :param text: docstring text to parse
    :param style: docstring style
    :param type: type for meta data
    :returns: parsed docstring representation
    :raises: ParseError
    '''

    docstring = parse(text)

    assert(docstring.summary == 'This is the description for parse.')
    assert(isinstance(docstring.meta, dict))
    assert(len(docstring.meta) == 3)
    assert(docstring.meta['param'][0]['name'] == 'text')
    assert(docstring.meta['param'][0]['type'] == ' ')
    assert(docstring.meta['param'][0]['desc'] == 'docstring text to parse')

# Generated at 2022-06-23 17:23:07.762301
# Unit test for function parse
def test_parse():
    ds = '''
    This function gives the string concatenation of two strings
    :param str1: The first string
    :param str2: The second string
    :return: Concatenation of two strings
    '''
    ds_parsed = parse(ds)
    assert ds_parsed.short_description == ds_parsed.long_description == \
        'This function gives the string concatenation of two strings'
    assert ds_parsed.meta['params'] == {'str1': 'The first string', 'str2': 'The second string'}
    assert ds_parsed.meta['return'] == 'Concatenation of two strings'
    assert ds_parsed.meta['returns'] == 'Concatenation of two strings'
    assert ds_

# Generated at 2022-06-23 17:23:16.251747
# Unit test for function parse
def test_parse():
    text1 = """One line summary.
    Extended description.
    Args:
    arg1 (int): The arg1 description.
    arg2 (str): The arg2 description.
    Returns:
    bool: The return value. True for success, False otherwise.
    Raises:
    AttributeError: The reason for an attribute error.
    """

    text2 = """One line summary.

    Extended description.

    Args:
    arg1 (int): The arg1 description.
    arg2 (str): The arg2 description.

    Returns:
    bool: The return value. True for success, False otherwise.

    Raises:
    AttributeError: The reason for an attribute error.

    """
    assert parse(text1) == parse(text2)
    assert parse(text1).summary == "One line summary."

# Generated at 2022-06-23 17:23:23.951709
# Unit test for function parse
def test_parse():
    text = '''\
        Converts the numpy array to string.

        Arguments:
            x (numpy.array): an array to be converted to string.

        Returns:
            str: string representation of the array.
        '''

    docstring = parse(text, Style.google)

    assert docstring.short_description == 'Converts the numpy array to string.'
    assert len(docstring.long_description) == 1  # empty line at the end
    assert len(docstring.params) == 1
    assert docstring.params[0].arg_name == 'x'
    assert docstring.params[0].arg_type == 'numpy.array'
    assert docstring.params[0].description == 'an array to be converted to string.'  # noqa
    assert len(docstring.returns) == 1


# Generated at 2022-06-23 17:23:34.330619
# Unit test for function parse
def test_parse():
    text = '''
    """
    This is a docstring.
    """
    '''
    ds = parse(text)
    assert ds.short_description == text
    assert ds.new_short_description == text
    assert ds.long_description == ''
    assert ds.meta == {}
    assert dict(ds) == {'short_description': text, 'long_description': '', 'meta': {}}
    assert ds.get('short_description') == text
    assert ds.get('long_description') == ''
    assert ds.get('meta') == {}
    assert ds.get('meta', {}).get('params') == {}

    text = '''
    """
    This is a docstring.

    Lorem ipsum dolor sit amet.
    """
    '''

# Generated at 2022-06-23 17:23:39.159488
# Unit test for function parse
def test_parse():
    docstring = parse('''Title: something\nAuthor: Someone else\n\nHello''')
    assert docstring.title == 'something'
    assert docstring.author == 'Someone else'
    assert docstring.content == 'Hello'


# Unit tests for class Docstring

# Generated at 2022-06-23 17:23:46.217421
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring(
        content='', summary='', extended_summary='', returns=None, params={},
        meta={}
    )
    
    # style tests
    assert parse('').style == parse('', style=Style.numpy).style == Style.numpy
    assert parse('', style=Style.pep257).style == parse('', style=Style.pep257).style == Style.pep257
    assert parse('', style=Style.google).style == parse('', style=Style.google).style == Style.google

# Generated at 2022-06-23 17:23:53.081997
# Unit test for function parse
def test_parse():
    """Parse a docstring."""
    from docstring_parser import parse

    docstring = parse(
        """Short summary.

    Extended description.

    :param arg1: Description of arg1
    :type arg1: str
    :param arg2: Description of arg2
    :type arg2: int, optional
    :returns: Description of return value
    :rtype: bool
    :raises keyError: raises an exception
    :raises ImportError: if something bad happens
    :raises TypeError: if something really bad happens

    """
    )


# Generated at 2022-06-23 17:24:00.335415
# Unit test for function parse
def test_parse():
    from pathlib import Path
    import sys

    # Parse all examples
    examples_dir = Path("examples")
    for example_file in examples_dir.glob("*"):
        source_path = str(example_file)
        with open(source_path) as source_file:
            example_text = source_file.read()
        style_name = example_file.stem
        style = Style[style_name]
        parsed = parse(example_text, style)
        print("Style:", style_name, "Parsed:", parsed, file=sys.stderr)

# Generated at 2022-06-23 17:24:08.508193
# Unit test for function parse
def test_parse():
    item = parse("""\
Summary line.

Description:
    - body1
    - body2
    \t- body2
    - body3
    \t\t- body3
    - body4
    \t\t\t- body4
""")
    assert str(item) == """\
Summary line.

Description:
    - body1
    - body2
        - body2
    - body3
            - body3
    - body4
                - body4
"""

# Generated at 2022-06-23 17:24:14.405163
# Unit test for function parse
def test_parse():
    f = open('/home/allan/Python/docstring_parser/test_data/test_parse.txt', 'r')
    f1 = open('/home/allan/Python/docstring_parser/test_data/test_parse_expected.txt', 'r')
    expected = f1.read()
    for line in f:
        x = parse(line)
        assert str(x) == expected

# Generated at 2022-06-23 17:24:20.263913
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    from docstring_parser.common import Return, Param, Docstring

    text = '''
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation

    :rtype: Docstring
    '''

    docstring_=Docstring(
    content='Parse the docstring into its components.',
    params=[
        Param(decl='text', description='docstring text to parse'),
        Param(decl='style', description='docstring style')
    ],
    returns=Return(description='parsed docstring representation'),
    returns_rtype= 'Docstring'
    )


    assert parse(text) == docstring_
    assert parse(text, style="Sphinx") == doc

# Generated at 2022-06-23 17:24:24.763735
# Unit test for function parse
def test_parse():
    test_text = [
        """
        This is a test docstring
        Get a random number
        """
    ]
    test_ret = Docstring(
        summary = "This is a test docstring",
        body = "Get a random number",
        meta = {},
        args = [],
        returns = None,
        raises = [],
        hooks = {},
        style = "googledoc"
    )
    assert test_ret == parse(test_text[0])

    test_text = [
        """
        This is a test docstring
        Get a random number
        :param: static
        :type static: int
        """
    ]

# Generated at 2022-06-23 17:24:30.606657
# Unit test for function parse
def test_parse():
    text = """\
    Test the parsing of docstrings.

    :param int param1: the first parameter
    :param str param2: the second parametere
    :returns: None
    :raises KeyError: raises exception
    """
    doc = parse(text)
    assert doc.long_description == 'Test the parsing of docstrings.'


# Generated at 2022-06-23 17:24:34.534533
# Unit test for function parse
def test_parse():
    assert isinstance(parse(""), Docstring)
    assert isinstance(parse("Test", Style.google), Docstring)
    assert isinstance(parse("Test", Style.sphinx), Docstring)
    assert isinstance(parse("Test", Style.numpy), Docstring)
    assert isinstance(parse("Test", Style.auto), Docstring)

# Generated at 2022-06-23 17:24:40.037697
# Unit test for function parse
def test_parse():
	text = """
	Test for function parse().

	:param object: object to parse
	:returns: parsed object
	"""
	ret = parse(text)
	print(ret)
	print(ret.short_description)
	print(ret.long_description)
	print(ret.params)
	print(ret.returns)
	print(ret.meta)

# Generated at 2022-06-23 17:24:49.489488
# Unit test for function parse
def test_parse():
    docstring = "This function does something.\n\nArgs:\n  arg1: the first argument\n  arg2: the second argument"
    assert parse(docstring) == {'description': 'This function does something.', 'args': [{'arg1': 'the first argument'}, {'arg2': 'the second argument'}]}
    docstring = "This function does something.\n\nArgs\n  arg1: the first argument\n  arg2: the second argument"
    assert parse(docstring) == {'description': 'This function does something.', 'args': [{'arg1': 'the first argument'}, {'arg2': 'the second argument'}]}
    docstring = "This function does something.\n\nParameters\n  arg1: the first argument\n  arg2: the second argument"


# Generated at 2022-06-23 17:24:58.886486
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    assert parse("This is the short description. \n\nThis is the first line of the longer description.\nAnd this is the second line.")
    assert Docstring([], 'This is the short description. ', 'This is the first line of the longer description. And this is the second line.', dict(), '', '', False)
    assert parse("This is the short description. \n\nThis is the first line of the longer description.\nAnd this is the second line.", style=Style.numpy)
    assert Docstring(list(), 'This is the short description. ', 'This is the first line of the longer description. And this is the second line.', dict(), '', '', False)
    assert parse('')
   

# Generated at 2022-06-23 17:25:10.595438
# Unit test for function parse
def test_parse():
    """test case: docstring with ``'''`` (shortDock, __doc__.strip())
    """
    docstring = """
This is a short docstring

:param str input: This is an input parameter
:param int, float treshold: This is a treshold
"""

    doc = parse(docstring)

    assert(doc.short_description == 'This is a short docstring')
    assert(len(doc.meta) == 2)
    assert(doc.meta[0].arg_name == 'input')
    assert(doc.meta[0].type_name == 'str')
    assert(doc.meta[0].description == 'This is an input parameter')
    assert(doc.meta[1].arg_name == 'treshold')
    assert(doc.meta[1].type_name == 'int, float')
   

# Generated at 2022-06-23 17:25:19.821203
# Unit test for function parse
def test_parse():
    """Tests for function parse"""

    def test_fixed_style(text: str, style: Style, expected: Docstring) -> None:

        ret = parse(text, style=style)
        assert ret == expected
        assert str(ret) == text

    def test_auto_style_success(text: str, expected: Docstring) -> None:

        ret = parse(text)
        assert ret == expected
        assert str(ret) == text

    def test_auto_style_failure(text: str) -> None:
        try:
            parse(text)
            assert False
        except ParseError:
            assert True


# Generated at 2022-06-23 17:25:31.303587
# Unit test for function parse
def test_parse():
    text = '''
_Foo_ is a great module. This module does stuff.

This module is for doing stuff.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
:rtype: dict
:raises ParseError: if we cannot parse
'''
    d = parse(text)
    assert d.description == '''_Foo_ is a great module. This module does stuff.

This module is for doing stuff.'''
    assert len(d.meta) == 4
    assert d.get_param('text') == 'docstring text to parse'
    assert d.get_return() == 'parsed docstring representation'
    assert d.get_return_type() == 'dict'

# Generated at 2022-06-23 17:25:33.299547
# Unit test for function parse
def test_parse():
    test_parse_numpy()
    test_parse_google()


# Generated at 2022-06-23 17:25:41.578814
# Unit test for function parse
def test_parse():
    text = '''One line summary.
    Extended description.
    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: Description of return value.
    :raises keyError: raises an exception
    '''
    doc = parse(text)
    assert(doc.summary == "One line summary.")
    assert(doc.extended_summary == "Extended description.")
    assert(len(doc.params) == 2)
    assert(len(doc.returns) == 1)
    assert(len(doc.raises) == 1)

# Generated at 2022-06-23 17:25:52.650799
# Unit test for function parse
def test_parse():
    text = '''\
    Testing parse function.
    :param str name: username
    :rtype: str
    '''
    doc = parse(text)
    assert doc.summary == 'Testing parse function.'
    assert doc.meta['name'].desc == 'username'
    assert doc.meta['name'].type == 'str'
    assert doc.return_type.desc == 'str'
    doc = parse(text, style=Style.google)
    assert doc.summary == 'Testing parse function.'
    assert doc.meta['name'].desc == 'username'
    assert doc.meta['name'].type == 'str'
    assert doc.return_type.desc == 'str'
    text = '''\
    Testing parse function.
    :param str name: username
    :return: str
    '''
    doc

# Generated at 2022-06-23 17:25:59.167100
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google, Numpy, Epytext
    from docstring_parser.parser import parse

    assert isinstance(parse('', style=Google), Google)
    assert isinstance(parse('', style=Numpy), Numpy)
    assert isinstance(parse('', style=Epytext), Epytext)
    assert isinstance(parse(''), Google)

# Generated at 2022-06-23 17:26:03.336187
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True)
    print('done')

# Generated at 2022-06-23 17:26:13.227842
# Unit test for function parse
def test_parse():
    assert parse("""returns the average of a list of numbers""", style=Style.auto) == Docstring("""returns the average of a list of numbers""", "returns the average of a list of numbers")
    # assert parse("""returns the average of a list of numbers""", style=Style.google) == Docstring("""returns the average of a list of numbers""", "returns the average of a list of numbers")
    # assert parse("""returns the average of a list of numbers""", style=Style.numpy) == Docstring("""returns the average of a list of numbers""", "returns the average of a list of numbers")
    # assert parse("""returns the average of a list of numbers""", style=Style.reStructuredText) == Docstring("""returns the average of a list of numbers""", "returns the

# Generated at 2022-06-23 17:26:15.422028
# Unit test for function parse
def test_parse():
    text = "A simple command line script that"
    result = parse(text)
    if isinstance(result, Docstring):
        assert(result.short_description == text)
    assert(result.short_description == text)

# Generated at 2022-06-23 17:26:18.400743
# Unit test for function parse
def test_parse():
    d = parse(
'''Computes the XOR of two strings.

Parameters
----------
a : str
    First string.
b : str
    Second string.

Returns
-------
str
    XOR of `a` and `b`.

'''
    )
    assert d.short_description == 'Computes the XOR of two strings.'

# Generated at 2022-06-23 17:26:29.749069
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    from docstring_parser.styles import Style
    from docstring_parser import parse

    # Test for content in docstring
    text = '''
    :param name: The name to use.
    :param state: Whether to start or stop.

    This is a summary::

        this is a text
    '''
    docstring = parse(text)
    assert docstring.summary == 'This is a summary.'
    assert docstring.text == 'this is a text'
    assert docstring.meta['parameters'] == [('name', 'The name to use.'), ('state', 'Whether to start or stop.')]

    # Test for content with docstring style