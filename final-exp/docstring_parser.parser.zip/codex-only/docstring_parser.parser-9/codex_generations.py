

# Generated at 2022-06-23 17:16:28.496204
# Unit test for function parse
def test_parse():
    text = '''\
    Unit test
    Usage
        Name:
            Type: Value
        Arguments:
            Name: Value
        Keyword Arguments:
            Name: Value
'''
    docstring = parse(text, style=Style.google)
    print(docstring)


# Generated at 2022-06-23 17:16:36.811310
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    # pylint: disable=line-too-long
    docstring = """
        Docstring: Description of the function
        :param param1: Description of the first parameter
        :param param2: Description of the second parameter
        :return: Description of the return
        :rtype: int
        """
    assert parse(docstring).params[0] == "param1"
    assert parse(docstring).params[1] == "param2"
    assert parse(docstring).returns == "Description of the return"


# Generated at 2022-06-23 17:16:42.795398
# Unit test for function parse
def test_parse():
    text = '''
    Short summary.

    Extended description.

     - item 1
     - item 2
     - item 3
    '''

    docstring = parse(text, style=Style.google)
    assert 'Short summary' == docstring.short_description
    assert 'Extended description.' == docstring.long_description
    assert '- item 1\n- item 2\n- item 3' == docstring.body

    assert str(docstring) == text.strip()

# Generated at 2022-06-23 17:16:49.378953
# Unit test for function parse
def test_parse():
    test_docstring = """This is a docstring with some content.

Attributes:
    attr_a: first attr
    attr_b: second attr

Raises:
    ValueError: Raises an exception.

"""
    assert parse(test_docstring, style=Style.numpy).meta == {'Attributes': '\n    attr_a: first attr\n    attr_b: second attr\n\n', 'Raises': '\n    ValueError: Raises an exception.\n\n'}

# Generated at 2022-06-23 17:16:57.093254
# Unit test for function parse
def test_parse():
    text = """This function does something.

Args:
    arg1: The first argument.
    arg2: The second argument.

Returns:
    desc: The description of return value.
    The actual return value.
"""
    docstring = parse(text, style=Style.numpy)
    assert len(docstring.args_list) == 2
    assert len(docstring.kwargs_list) == 1

# Main function 
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:16:59.245433
# Unit test for function parse
def test_parse():
    print('Test function parse')
    print(parse('''
    sample:
        Hello world!
        @author by me
    '''))
    print('End test')

# Generated at 2022-06-23 17:17:01.073120
# Unit test for function parse
def test_parse():
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:17:10.266484
# Unit test for function parse
def test_parse():
    text = '''First sentence.

A paragraph.
Another one.

Parameters:
    first_param (bool): A boolean value
    second_param (int): A integer value
Returns:
    None
    '''
    ret = parse(text)
    assert ret.first_sentence == 'First sentence.'
    assert ret.description == 'A paragraph.\nAnother one.'
    assert ret.sections[0].get('Parameters').get('first_param') == 'A boolean value'
    assert ret.sections[0].get('Parameters').get('second_param') == 'A integer value'
    assert ret.sections[0].get('Returns') == 'None'

# Generated at 2022-06-23 17:17:15.089825
# Unit test for function parse
def test_parse():
    docstring = """Summary line.
Extended description.

Args:
    arg1 (int): Description.
    arg2 (str): Description.

Returns:
    bool: Description.
"""
    parsed = parse(docstring)
    print(parsed)

# Generated at 2022-06-23 17:17:24.634217
# Unit test for function parse
def test_parse():
    text = '''
    Adds two numbers.

    Args:
        a: first number
        b: second number

    Returns:
        sum of two numbers
    '''
    parsed_docstring = parse(text)
    print(parsed_docstring.meta["summary"])
    print(parsed_docstring.meta["params"])
    print(parsed_docstring.meta["returns"])
    print(parsed_docstring.meta["raises"])

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:26.545484
# Unit test for function parse
def test_parse():
    text = 'Test'
    style = Style.google
    parse(text, style)
    parse(text)


# Generated at 2022-06-23 17:17:28.370639
# Unit test for function parse
def test_parse():
    text = ''
    style = Style.auto
    doc1 = parse(text,style)
    doc2 = parse(text)
    print(doc1)
    print(doc2)

# Generated at 2022-06-23 17:17:32.452665
# Unit test for function parse
def test_parse():
	docstring = '''\
Header line components:
    - Creator: Creator name
    - creation date: date
'''
	print(parse(docstring))
	
if __name__ == '__main__':
	test_parse()

# Generated at 2022-06-23 17:17:38.691743
# Unit test for function parse
def test_parse():
    text = '''Example function with types documented in the docstring.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    print(param1)
    '''
    obj = parse(text)
    assert obj.short_description == 'Example function with types documented in the docstring.'
    assert obj.long_description == ''
    assert obj.returns.type_name == 'bool'
    assert obj.params['param1'].type_name == 'int'
    assert len(obj.params) == 2

# Generated at 2022-06-23 17:17:44.360744
# Unit test for function parse
def test_parse():
    text = """
        The first line is brief explanation, which may be completed with
        a longer one.

        For example::

            anything here is shown as regular text,
            so ordinary parsing apply.

        The only special thing is that the first line is stripped.

    """
    result = parse(text)
    print(result)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:52.777102
# Unit test for function parse
def test_parse():
    text = """\
The `unittest` module supports a very wide range of
functionality. You can write tests for a module, a class, a single method,
or a single function. You can run the tests from the command line, from an
IDE, or from within a script.

"""
    docstring = parse(text)

    print('Summary: %s' % docstring.summary)
    print('Description: %s' % docstring.description)

# python -m doctest -v __init__.py
# >>> test_parse()
# Summary: The `unittest` module supports a very wide range of
#   functionality.
# Description: You can write tests for a module, a class, a single method,
#   or a single function. You can run the tests from the command line, from an
#   IDE, or from within a

# Generated at 2022-06-23 17:17:56.413198
# Unit test for function parse
def test_parse():
    docstring = '''This function does something.
    :param p1: param 1
    :returns: int -- the return code.'''
    assert parse(docstring)[0].text == 'This function does something.'

# Generated at 2022-06-23 17:18:00.980216
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    assert parse("hello") == parse("hello", style=Style.google)
    assert parse("hello") == parse("hello", style=Style.numpy)
    assert parse("hello") == parse("hello", style=Style.sphinx)

# Generated at 2022-06-23 17:18:11.532672
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyDocstring
    from docstring_parser.styles import GoogleDocstring
    import pytest

    assert parse("") == Docstring("")
    assert parse("", style=Style.numpy) == NumpyDocstring("")
    assert parse("foo") != Docstring("foo")
    assert parse("foo", style=Style.google) == GoogleDocstring("foo")
    assert parse("foo bar") != Docstring("foo bar")
    with pytest.raises(Exception):
        parse("foo bar", style=Style.auto)
    assert parse("foo bar", style=Style.numpy) == NumpyDocstring("foo bar")
    with pytest.raises(Exception):
        parse("foo bar", style=Style.google)

# Generated at 2022-06-23 17:18:17.178502
# Unit test for function parse
def test_parse():
    test_doc = """
    Args:
        text: docstring text to parse
        style: docstring style
    Returns:
        parsed docstring representation"""

    result = parse(test_doc, style=Style.numpy)
    assert len(result.params[0][0]) == 2
    assert result.params[0][1] == "docstring text to parse"
    assert result.returns == "parsed docstring representation"

# Generated at 2022-06-23 17:18:20.224030
# Unit test for function parse
def test_parse():
    text = """\
Module description

Args:
    arg1: argument 1
    arg2 (str): argument 2

Returns:
    None
"""
    assert str(parse(text)) == text

# Generated at 2022-06-23 17:18:31.281944
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.reST import parse as parseREST
    from docstring_parser.styles.numpy import parse as parseNUMPY
    from docstring_parser.styles.google import parse as parseGOOGLE
    from docstring_parser.common import Docstring

    # reST test
    dsREST = parseREST("""
    This is the first paragraph and is not intended to be a Docstring

    This is an example of a simple doctring.

    Args:
        a (int): A number to be squared.
        b (int): Another number to be squared.

    Returns:
        int: The sum of the squares.


    """
)

    assert dsREST.summary == """This is an example of a simple doctring."""

# Generated at 2022-06-23 17:18:41.385991
# Unit test for function parse
def test_parse():
    text = """This is a summary.

    This is the first line of the body.

    This is the second line of the body.

    :param str name: Name of person
    :param int age: Age of person
    :returns: None
    :raises ValueError: If the age is not positive
    """
    docstring = parse(text)
    print(docstring.params['name'])
    print(docstring.params['age'])
    print(docstring.returns)
    print(docstring.raises)
    print(docstring.summary)
    print(docstring.description)


# Generated at 2022-06-23 17:18:43.750974
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:18:47.379865
# Unit test for function parse
def test_parse():
    x = parse(
        """
        this is a test
        :param aa:aa1
        """)
    print(x.summary)
    print(x.meta)
    print(x.sects)
    print(x.sects['parameters'])


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:18:58.182443
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring('')
    assert parse('\n') == Docstring('')
    assert parse('    ') == Docstring('')
    assert parse('\n    ') == Docstring('')
    assert parse('Hello, world!\n') == Docstring('Hello, world!')
    assert parse('Hello, world!\n    ') == Docstring('Hello, world!')
    assert parse('Hello, world!\n    ') == Docstring('Hello, world!')
    assert parse('Hello, world!\n') == Docstring('Hello, world!')
    assert parse('\nHello, world!\n') == Docstring('Hello, world!')
    assert parse('\nHello, world!\n') == Docstring('Hello, world!')

# Generated at 2022-06-23 17:19:07.840978
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    text = ''' """
This function parses the docstring into its components.
:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
""" '''
    ret = parse(text)
    expect = Docstring(brief='This function parses the docstring into its components.',
                       description='This function parses the docstring into its components.',
                       params = [('text', 'docstring text to parse'), ('style', 'docstring style')],
                       returns ='parsed docstring representation'
                       )
    assert ret == expect

# Generated at 2022-06-23 17:19:12.101353
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    print(parse(docstring))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:17.066132
# Unit test for function parse
def test_parse():
    docstring = '''
    author:
        - name: User1
        - name: User2
        - name: User3
    code:
        - a = 1
        - b = 2
        - c = 3
    content:
        - word1
        - word2
        - word3
    '''
    ds = parse(docstring)
    print(ds.author)
    print(ds.code)
    print(ds.content)


# Generated at 2022-06-23 17:19:27.562003
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(None, None, None, None)

    assert parse("""
    No description
    """) == Docstring(None, None, None, None)

    assert parse("""
    No description
    """) == Docstring(None, None, None, None)

    assert parse("""
    A very brief description.
    """) == Docstring("""\
A very brief description.
""", None, None, None)

    assert parse("""
    Hello World!
    """) == Docstring("""\
Hello World!
""", None, None, None)

    assert parse("""
    Hello World!
    """) == Docstring("""\
Hello World!
""", None, None, None)


# Generated at 2022-06-23 17:19:34.882978
# Unit test for function parse
def test_parse():
    text = """
        One line summary.

        Extended description.

        :param arg1: Description of arg1
        :param arg2: Description of arg2
        :type argD: type description of argD
        :param arg3: Description of arg3
        :type arg3: Description of the type of arg3
        :returns: Description of return value
        :raises keyError: Why it can raise keyError
        """
    parse(text)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:37.796776
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style


    parses = parse("""
    my first docstring
    """)
    print(parses)
test_parse()

# Generated at 2022-06-23 17:19:44.537039
# Unit test for function parse
def test_parse():
    docstring = '''qwerty
    :param name: description
    :returns: description
    '''

    result = parse(docstring, Style.sphinx)
    assert result.meta['name'] == 'description'
    assert result.meta['returns'] == 'description'

    result = parse(docstring, Style.google)
    assert result.meta['name'] == 'description'
    assert result.meta['returns'] == 'description'

    result = parse(docstring, Style.numpy)
    assert result.meta['name'] == 'description'
    assert result.meta['returns'] == 'description'

    result = parse(docstring, Style.napoleon)
    assert result.meta['name'] == 'description'
    assert result.meta['returns'] == 'description'


# Generated at 2022-06-23 17:19:53.279907
# Unit test for function parse
def test_parse():
    text = '''"""\nParsing of docstrings.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
:raises ParseError: if parsing failed
"""'''
    style = Style.numpy
    doc = parse(text, style)
    assert doc.summary == "Parsing of docstrings."
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert len(doc.returns) == 1
    assert len(doc.raises) == 1


# Generated at 2022-06-23 17:19:55.923095
# Unit test for function parse
def test_parse():
    text = '''    :param str foo: foo is foo
    '''
    ret = parse(text, Style.sphinx)
    print (ret)

# Generated at 2022-06-23 17:20:00.996163
# Unit test for function parse
def test_parse():
    text = '''
    Parses a docstring into its various components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    assert parse(text) == parse(text)

# Generated at 2022-06-23 17:20:11.419622
# Unit test for function parse
def test_parse():
    text1 = '''
    One line summary.

    Extended description.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: Description of return value.
    :rtype: bool
    :raises keyError: raises an exception
    '''

    docstring1 = parse(text1)

    assert 'py' in docstring1.style
    assert docstring1.short_description == 'One line summary.'
    assert docstring1.long_description == 'Extended description.'
    assert docstring1.is_attribute is False
    assert len(docstring1.params) == 2
    assert len(docstring1.meta) == 4


# Generated at 2022-06-23 17:20:16.621298
# Unit test for function parse
def test_parse():
    d = parse('''
:param a: 1

:param b: 2

''', style=Style.google)
    assert d.params[0].field_name == 'a'
    assert d.params[0].type_name == None
    assert d.params[0].description == '1'
    assert d.params[1].field_name == 'b'
    assert d.params[1].type_name == None
    assert d.params[1].description == '2'

# Generated at 2022-06-23 17:20:20.285100
# Unit test for function parse
def test_parse():
    text = """\
    This is a short summary.

    This is a long description.
    """
    doc = parse(text)
    assert doc.short_description == "This is a short summary."
    assert doc.long_description == "This is a long description."
    assert len(doc.params) == 0
    assert len(doc.meta) == 0
    assert doc.style == Style.auto



# Generated at 2022-06-23 17:20:30.807957
# Unit test for function parse
def test_parse():
    text = """This is a docstring.

:param x: The first parameter.
:param y: The second parameter.
:returns: The return value.
"""
    d = parse(text)
    assert d.short_description == "This is a docstring."
    assert d.long_description == ""
    assert d.returns == "The return value."
    assert d.return_type == ""
    assert d.meta["parameters"] == [
        ("x", "The first parameter."),
        ("y", "The second parameter."),
    ]
    assert d.meta["raises"] == []
    assert d.meta["keywords"] == []

    print(d)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:20:40.756079
# Unit test for function parse
def test_parse():
    docstring = """This is a test
    :param param1: this is a first param
    :type param1: int
    :param param2: this is a second param
    :type param2: str
    :returns: this is a description of what is returned
    :rtype: int"""
    res = parse(docstring)
    assert isinstance(res, Docstring)
    print(res)
    assert res.short_description == "This is a test"
    assert res.extended_description == ""
    assert res.meta[0].name == "param1"
    assert res.meta[0].type_name == "int"
    assert res.meta[0].description == "this is a first param"
    assert res.meta[1].name == "param2"
    assert res.meta[1].type_name

# Generated at 2022-06-23 17:20:46.204275
# Unit test for function parse
def test_parse():
    text = """\
    This is a short summary.

    And here is a long description.

    :param int x: the first param
    """
    assert parse(text).meta["x"] == "the first param"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:20:55.404554
# Unit test for function parse
def test_parse():
    input = '''
    :param a: First param
    :type a: int
    :param b: Second param
    :type b: float
    
    :returns: None
    :rtype: NoneType
    '''
    result = parse(input,Style.numpy)
    assert result.short_desc == ''
    assert result.long_desc == ''
    assert len(result.meta) == 4
    assert result.meta[0].args[0] == 'a'
    assert result.meta[0].desc == 'First param'
    assert result.meta[0].annotation == 'int'
    assert result.meta[0].type_line == ':type a: int'

# Generated at 2022-06-23 17:21:02.943028
# Unit test for function parse
def test_parse():
    docstring = parse('''
        This is a summary.

        This is description.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.

        Note:
            * An Example of Note

            See also

            * https://github.com/takluyver/docstrin_parser
    ''')
    assert docstring.summary == 'This is a summary.'
    assert docstring.description == 'This is description.'
    assert docstring.extra_args == []
    assert docstring.extra_kwargs == []
    assert docstring.returns == {
        'name': 'bool',
        'description': 'The return value. True for success, False otherwise.',
    }

# Generated at 2022-06-23 17:21:04.748884
# Unit test for function parse
def test_parse():
    text0 = """
    Get a random Wikipedia article title.

    :returns: A random Wikipedia article title.
    :rtype: unicode
    """
    text1 = """
    Get a random Wikipedia article title.
    """

# Generated at 2022-06-23 17:21:15.871637
# Unit test for function parse
def test_parse():
    class Square:
        """This is Square class docstring.
        
        Some extra words....

        :param num: number that needs to square
        :type num: int
        :returns: square of parameter
        :rtype: int
        :raises TypeError: if parameter is not integer
        """
        def get_square(self, num):
            pass

    doc = Square.__doc__
    ret = parse(doc, style=Style.google)
    assert ret.summary == 'This is Square class docstring.'
    assert ret.meta['param']['num'].description == 'number that needs to square'
    assert ret.meta['returns'].description == 'square of parameter'
    assert ret.meta['raises']['TypeError'].description == 'if parameter is not integer'

# Generated at 2022-06-23 17:21:26.704659
# Unit test for function parse
def test_parse():
    s = '''
        sum of two num

        :param a: first num
        :param b: second num
        :return: sum
    '''
    a = docstring_parser.parse(s)
    assert a.summary == 'sum of two num'
    assert a.params[0].arg_name == 'a'
    assert a.params[0].description == 'first num'
    assert a.params[1].arg_name == 'b'
    assert a.params[1].description == 'second num'
    assert a.returns.description == 'sum'

    s = '''
        :param a: first num
        :param b: second num
        sum of two num
        :return: sum
    '''

    a = docstring_parser.parse(s)

# Generated at 2022-06-23 17:21:33.754427
# Unit test for function parse
def test_parse():
    text = """
    one-line summary

    one-line description

    :param: one line description
    :type: one
    :returns: one line description
    :rtype: one
    :raises: one line description
    :raise: one
    """
    docstring = parse(text)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.params)

# Generated at 2022-06-23 17:21:39.484051
# Unit test for function parse
def test_parse():
    text = """Metrics functions.
Args:
    array: array of values to be measured
    var: list of list of variables
Returns:
    returns sum of the values

"""
    res = parse(text)
    assert res.args == 'array: array of values to be measured\n    var: list of list of variables'
    assert res.returns == 'returns sum of the values'


# Generated at 2022-06-23 17:21:41.622078
# Unit test for function parse
def test_parse():
    test_docstring = "Test docstring parse."
    docstring = parse(test_docstring)
    assert docstring.short_description == test_docstring



# Generated at 2022-06-23 17:21:53.359655
# Unit test for function parse
def test_parse():
    text = '''
        New Function.

        :param int a:
            Integer from 1 to 10.
        :param float b:
            Float from 1 to 10.
        :param str c:
            Name of the planet.
        :type c: str
        :return: Integer 1, float 2.3, string 'planet name'
        :rtype: (int, float, str)
        :raises ValueError: if 1 occured in the list
        :raise ValueError: if 2 occured in the list
        :except ValueError: if 3 occured in the list
    '''
    doc = parse(text)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.meta)
    print(doc.meta.params['a'].description)

# Generated at 2022-06-23 17:22:04.649401
# Unit test for function parse
def test_parse():
    text = """\
    :param apples: How many apples?
    :param oranges: How many oranges?
    :returns: Apples and oranges galore!
    """
    docstring = parse(text)

    assert docstring.short_description == ""
    assert docstring.long_description == ""
    assert docstring.meta["returns"][0].description == "Apples and oranges galore!"
    assert docstring.meta["parameters"]["apples"][0].description == "How many apples?"
    assert docstring.meta["parameters"]["oranges"][0].description == "How many oranges?"
    assert docstring.returns.type_name == ""
    assert docstring.returns.description == "Apples and oranges galore!"
    assert docstring.returns.name == ""



# Generated at 2022-06-23 17:22:05.895776
# Unit test for function parse
def test_parse():
    parse('This is a test docstring.', style='yaml')

# Generated at 2022-06-23 17:22:14.823163
# Unit test for function parse
def test_parse():
    """Test function parse"""
    lines = ['This function returns the length of a string',
             '',
             'Parameters:',
             '    s: str',
             '        the string to measure',
             '',
             'Returns:',
             '    the length of s',
             ]
    str_ = '\n'.join(lines)
    ds = parse(str_)
    assert ds.short_description == lines[0]
    assert len(ds.long_description) == 0
    assert ds.params['s'] == lines[4]
    assert ds.returns == lines[8]

test_parse()

# Generated at 2022-06-23 17:22:22.325617
# Unit test for function parse
def test_parse():
    text = '''Summary line.

Extended description.


Args:
    arg1 (int): Description of arg1
    arg2 (str): Description of arg2

    arg3 (list): Description of arg3
    arg4 (pd.DataFrame): Description of arg4

Returns:
    int: Description of return value
'''

    args = [('arg1', 'int', 'Description of arg1'),
            ('arg2', 'str', 'Description of arg2'),
            ('arg3', 'list', 'Description of arg3'),
            ('arg4', 'pd.DataFrame', 'Description of arg4')]

    rtype = 'int'
    rdesc = 'Description of return value'

    doc = parse(text, style=Style.numpy)

    assert doc.short_description == 'Summary line.'

# Generated at 2022-06-23 17:22:29.026185
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param arg1: Explain arg1.
:type arg1: str
:param arg2: Explain arg2.
:type arg2: int, optional
:returns: Explanation of return value.
:rtype: int
:raises error: explain exception.
"""
    docstring = parse(text)
    print("Succeeded")

# Generated at 2022-06-23 17:22:36.469844
# Unit test for function parse
def test_parse():
    text = '''
      title: This is a title
      author: Spam
      date: January 1, 1970

      This is a paragraph.

      This is another paragraph.

      .. list-table:: List Title
         :header-rows: 1
         :stub-columns: 1

         * - Title 1
           - Title 2
           - Title 3
         * - 1
           - 2
           - 3
         * - 4
           - 5
           - 6
    '''
    d = parse(text)
    print(d.meta['title'])

test_parse()

# Generated at 2022-06-23 17:22:46.793888
# Unit test for function parse
def test_parse():
    docstring = parse('''
        :param a1:
            This is the first parameter.
        :param a2:
            :type a2: str
            :default "b"

            This is the second parameter.
        :keyword: b
            This is the keyword parameter.
        :return:
            This is the return value
    ''')
    print(docstring.meta['parameters']['a1'])
    print(docstring.meta['parameters']['a2']['metadata']['default'])
    print(docstring.meta['parameters']['a2']['metadata']['type'])
    print(docstring.meta['parameters']['a2']['body'])
    print(docstring.meta['keywords']['b'])

# Generated at 2022-06-23 17:22:55.658146
# Unit test for function parse
def test_parse():
    test_str = """
    This is a test docstring
    
    : param x: variable x
    : param y: variable y 
    : param z: variable z
    
    :return: variable z
    """
    test_parse = parse(test_str)
    assert test_parse.summary == 'This is a test docstring'
    assert test_parse.meta['x']['type'] == None
    assert test_parse.meta['y']['type'] == None
    assert test_parse.meta['z']['type'] == None
    assert test_parse.meta['return']['type'] == None

test_parse()

# Generated at 2022-06-23 17:23:01.755785
# Unit test for function parse
def test_parse():
    import sys
    import os
    import pandas as pd

    pytest_plugins = ['pytester']


# Generated at 2022-06-23 17:23:03.041521
# Unit test for function parse
def test_parse():
    d = parse.__annotations__["returns"]
    assert d == Docstring
test_parse()

# Generated at 2022-06-23 17:23:11.815912
# Unit test for function parse
def test_parse():
    raw_text = """
    This is a module for parsing docstrings.

    :param text: text to parse
    :param style: which style to use
    :returns: parsed docstring
    """
    docstring = parse(raw_text, style=Style.google)
    assert docstring.short_description == "This is a module for parsing docstrings."
    assert len(docstring.long_description) == 0
    assert len(docstring.meta) == 1
    meta = docstring.meta['Parameters']
    assert meta[0].arg_name == 'text'
    assert meta[0].description == 'text to parse'
    assert meta[1].arg_name == 'style'
    assert meta[1].description == 'which style to use'
    assert len(docstring.returns) == 1

# Generated at 2022-06-23 17:23:14.736799
# Unit test for function parse
def test_parse():
    test = parse("""TODO: docstring for simple_parse""")
    assert test.short_description.strip() == "TODO: docstring for simple_parse"

# Generated at 2022-06-23 17:23:21.205730
# Unit test for function parse
def test_parse():
    text = """This is the docstring of a module
    \n\n 
    This is the first paragraph
    \n\n
    This is the second paragraph
    \n\n
    :param str arg1: description of arg1
    :param int arg2: description of arg2
    \n\n
    """
    d = parse(text)
    assert d.short_description == "This is the docstring of a module"
    assert d.long_description == "This is the first paragraph\n\nThis is the second paragraph"
    assert d.params["arg1"] == "description of arg1"
    assert d.params["arg2"] == "description of arg2"

# Test python_numpy module


# Generated at 2022-06-23 17:23:23.064753
# Unit test for function parse
def test_parse():
    parse(text='Description\n')

# Test to check if styles inside STYLES if present for Style.auto

# Generated at 2022-06-23 17:23:31.132181
# Unit test for function parse
def test_parse():
    key = ['name', 'start', 'end', 'content']
    text = """
    This is a docstring.

    :param a: Parameter a
    :param b, c: Parameter b and c
    :raises D, E:
    :returns: a value
    """
    ret = parse(text)

# Generated at 2022-06-23 17:23:34.854961
# Unit test for function parse
def test_parse():
    doc = """
    This is a multiline docstring.
    You can do anything.
    """
    parsed = parse(doc)
    assert(parsed.short_description == "This is a multiline docstring.")
    assert(parsed.long_description == "You can do anything.")



# Generated at 2022-06-23 17:23:46.093913
# Unit test for function parse
def test_parse():
    text = """
        One line summary.

        Extended description.

        :param arg1: description
        :param arg2: description continued
        :type arg1: str
        :type arg2: int, optional
        :returns: description
        :rtype: bool
        """
    result = parse(text)
    assert result.short_description == 'One line summary.'
    assert result.long_description == 'Extended description.'
    assert result.returns.description == 'description'
    assert result.returns.type_annotation == 'bool'
    assert result.params['arg1'].description == 'description'
    assert result.params['arg1'].type_annotation == 'str'
    assert result.params['arg2'].description == 'description continued'
    assert result.params['arg2'].type_annotation

# Generated at 2022-06-23 17:23:58.071529
# Unit test for function parse
def test_parse():
    class Test:
        def __init__(self, a, b, c=1) -> "Test":
            """Creates a Test object.

            Args:
                a (int): first parameter
                b (list): second parameter
                c (int, optional): third parameter

            Returns:
                Test: Test instance

            """
    parsed = parse(Test.__init__.__doc__)
    assert parsed.short_description.strip() == "Creates a Test object."
    assert parsed.long_description.strip() == ""
    assert parsed.meta["Args"][0].argname == "a"
    assert parsed.meta["Args"][0].type_name == "int"
    assert parsed.meta["Args"][0].description.strip() == "first parameter"

# Generated at 2022-06-23 17:24:02.914664
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    # should raise error
    try:
        parse("")
    except ParseError as e:
        assert(e.args[0] == 'Cannot identify style')

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:06.819752
# Unit test for function parse
def test_parse():
    assert parse(__doc__, style=Style.numpy)

if __name__ == '__main__':
    print(__doc__)
    print(parse.__doc__)
    print(parse(__doc__, style=Style.numpy))

# Generated at 2022-06-23 17:24:13.907813
# Unit test for function parse
def test_parse():
    docstr = """One line summary
    Extended description

    :param foo: description of foo
    :param bar: description of bar
    :type bar: str
    :returns: description of return value
    :rtype: int
    :raises: Http404
    """
    parsed = parse(docstr)
    print(parsed.__dict__)
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:22.030218
# Unit test for function parse
def test_parse():
    s = '''
    LSTM for sequence to sequence prediction.

    Args:
        input_dim (int): Input dimensio.  

    Returns:
        x: sum of input_dim and 2.
    '''
    assert parse(s).returns == 'x: sum of input_dim and 2.'
    assert parse(s).args == 'input_dim (int): Input dimensio.'
    assert parse(s).description == 'LSTM for sequence to sequence prediction.'

# Generated at 2022-06-23 17:24:25.127428
# Unit test for function parse
def test_parse():
    docstring = '''
    This is the docstring summary.
    '''

    parsed_docstring = parse(docstring)

    assert(parsed_docstring.summary == "This is the docstring summary.")

# Generated at 2022-06-23 17:24:35.017885
# Unit test for function parse
def test_parse():
    docstring = """Summary line.
    Extended description.

    Args:
    a: argument a

    Kwargs:
    b: argument b

    Returns:
    c: argument c

    Raises:
    d: argument d
    """

    dd = parse(docstring)
    assert dd.short_description == 'Summary line.'
    assert dd.long_description == 'Extended description.'
    assert len(dd.meta) == 4
    assert len(dd.args) == 2
    assert len(dd.returns) == 2
    assert len(dd.raises) == 2

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:39.437654
# Unit test for function parse
def test_parse():
    text = ""
    style = Style.numpy
    doc = parse(text, style)
    text = """
    Cheers!
    :param x: input value
    """
    doc = parse(text, style)
    print(doc)

# test_parse()

# Generated at 2022-06-23 17:24:42.422788
# Unit test for function parse
def test_parse():
    text = '''
    Hello world.
    '''
    assert parse(text).summary_raw == text.strip()
    assert parse(text).style == Style.google

# Generated at 2022-06-23 17:24:46.895870
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    docstring = """
        parse(text, style=Style.auto)
        Parse docstring into a Docstring 

        :param text: docstring text to parse
        :param style: docstring style
        """

    docstring2 = parse(docstring)
    print(docstring2)

# Main function for testing this script

# Generated at 2022-06-23 17:24:53.190819
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    doc = '''\
    Hello world.

    :param int a: Value a
    :param int b: Value b
    :return: Value of a and b
    :rtype: int
    '''

    assert isinstance(parse(doc), GoogleStyle)
    assert isinstance(parse(doc, style=Style.google), GoogleStyle)
    assert isinstance(parse(doc, style=Style.numpy), GoogleStyle)

# Generated at 2022-06-23 17:24:58.279726
# Unit test for function parse
def test_parse():
    docstring_text = '''test module.

:param int arg1: the first argument
:param arg2: the second argument
:returns: description of return value
:raises keyError: raises an exception
:var list x: the first variable
'''
    docstring = parse(docstring_text)
    print(docstring)

    if __name__ == '__main__':
        test_parse()

# Generated at 2022-06-23 17:25:04.254956
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google, Numpy, Epytext
    from docstring_parser.common import Docstring
    docstring = parse(
        """A one-line summary that does not use variable names or the
    function name.

    Several sentences providing an extended description. Refer to
    variables using back-ticks, e.g. `var`.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    bool
        Description of return value
    """
    )
    assert isinstance(docstring, Docstring)
    assert len(docstring.meta) == 3
    assert docstring.meta[0].argname == "arg1"
    assert docstring.meta[0].type_name == "int"


# Generated at 2022-06-23 17:25:14.778735
# Unit test for function parse
def test_parse():
    ds = parse("""
    hello world
    """, Style.google)
    assert ds.short_description == 'hello world'
    assert ds.long_description == 'hello world'
    assert ds.meta == {}
    assert ds.returns == None
    assert ds.styles == Style.google
    assert ds.style == Style.google

    ds = parse("""
    hello world \
    hello world again
    """, Style.google)
    assert ds.short_description == 'hello world'
    assert ds.long_description == 'hello world hello world again'
    assert ds.meta == {}
    assert ds.returns == None
    assert ds.styles == Style.numpy
    assert ds.style == Style.numpy


# Generated at 2022-06-23 17:25:26.249031
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NUMPY, GOOGLE
    text = '''
        Single-line summary.

        Extended description.

        Args:
          param1: The first parameter.
          param2: The second parameter.

        Returns:
          The return value. True for success, False otherwise.

        Raises:
          KeyError: The function raises an exception.
        '''
    expected = """
        Single-line summary.
        Extended description.
        Args:
            param1 (:obj:`int`, optional): The first parameter.
            param2 (:obj:`str`, optional): The second parameter.
        Returns:
            The return value. True for success, False otherwise.
        Raises:
            KeyError: The function raises an exception.
    """

    parsed = parse(text)

# Generated at 2022-06-23 17:25:34.203326
# Unit test for function parse
def test_parse():
    text = '''Function
    This function to return the sum between the parameters
    :param a: argument a
    :type a: int
    :param b: argument b
    :type b: float
    :return: the sum between a and b
    :rtype: float
    :raises: TypeError
    :Using:
        >>> parse()
            test
    '''

    ret = parse(text)
    assert ret.short_description == 'Function'
    assert ret.long_description == 'This function to return the sum between the parameters'
    assert ret.params['a'].arg_type == 'int'
    assert ret.params['b'].arg_type == 'float'
    assert ret.returns.return_type == 'float'
    assert ret.returns.description == 'the sum between a and b'
   

# Generated at 2022-06-23 17:25:40.570390
# Unit test for function parse
def test_parse():
    text = """
    This is a test of the parse function.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a test of the parse function.'
    assert docstring.long_description == None
    assert docstring.meta == {}
    assert docstring.return_annotation == None
    assert docstring.params == []
    assert docstring.extra_sections == []
    assert docstring.examples == []
    assert docstring.import_errors == []
    assert docstring.style == Style.google

# Example 2: Complex


# Generated at 2022-06-23 17:25:48.578382
# Unit test for function parse
def test_parse():
    text = '''\
    This function does something.

    :param x: argument x
    :type x: int

    :returns: something
    :rtype: list
    '''

    docstring = parse(text)
    assert docstring.short_description == "This function does something."
    assert docstring.full_description == ""
    assert docstring.params["x"] == "argument x"
    assert docstring.returns == "something"
    assert docstring.return_type == "list"



# Generated at 2022-06-23 17:25:53.786585
# Unit test for function parse
def test_parse():
    sty = {
        'spacy': Cogolib,
        'google': Google,
        'numpy': Numpy
    }
    doc = '''
        Name
        -------

        This is a test.
    '''

    for k, v in sty.items():
        docstring = parse(doc, style=v)
        print(docstring)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:26:03.867133
# Unit test for function parse
def test_parse():
    doc = """This is the module docstring.

Args:
    arg1 (int): Description of arg1
    arg2 (:obj:`list` of :obj:`str`): Description of arg2
"""
    assert parse(doc, style=Style.google).args == ("arg1", "arg2")
    assert parse(doc, style=Style.google).returns == ()
    assert parse(doc, style=Style.numpy).args == ("arg1", "arg2")
    assert parse(doc, style=Style.numpy).returns == ()
    assert parse(doc, style=Style.sphinx).args == ("arg1", "arg2")
    assert parse(doc, style=Style.sphinx).returns == ()

# Generated at 2022-06-23 17:26:06.100241
# Unit test for function parse
def test_parse():
    docstr = '''
    hello
    '''
    doc = parse(docstr)
    assert doc.summary == 'hello'



# Generated at 2022-06-23 17:26:15.587266
# Unit test for function parse
def test_parse():
    text = """Short line without period.

Short one line summary.

Longer description. Can be several paragraphs long.

Args:
  arg1 (int): Description of `arg1`
  arg2 (str): Description of `arg2`

Returns:
  bool: some bool value

Raises:
  NameError: if `name` not in list
"""
    docstring = parse(text, Style.pep257)
    assert docstring.short_description == 'Short one line summary.'
    assert docstring.long_description == '\nLonger description. Can be several paragraphs long.\n'
    assert docstring.meta['Args'][0].arg_name == 'arg1'
    assert docstring.meta['Args'][0].arg_type == 'int'

# Generated at 2022-06-23 17:26:16.314924
# Unit test for function parse
def test_parse():
    pass
    # assert False



# Generated at 2022-06-23 17:26:26.904558
# Unit test for function parse
def test_parse():
    s = """Summary line.

Extended description.

:keyword hello: Description
:keyword world: Description 2
:return: Description
:raises ValueError: if
:raises TypeError: if not
"""
    p = parse(s)
    assert p.summary == "Summary line."
    assert p.extended_summary == "Extended description."
    assert p.returns == "Description"
    assert len(p.raises) == 2
    assert {r.type for r in p.raises} == {"ValueError", "TypeError"}
    assert p.keywords
    assert len(p.keywords) == 2
    assert {k.arg_name for k in p.keywords} == {"hello", "world"}