

# Generated at 2022-06-23 17:16:30.667123
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "", "", [])
    assert parse("abc") == Docstring("", "", "abc", [])
    assert parse("""\
a
:type: int
""") == Docstring("a", "int", "", [])
    assert parse("""\
a: int
    b
    :type: list
    """) == Docstring("a: int", "list", "b", [])



# Generated at 2022-06-23 17:16:38.938511
# Unit test for function parse
def test_parse():
    text = """Summary line.

Test message without "Returns" and "Yields"

Args:
    param1 (int): The first parameter.
    param2 (str): The second parameter.

Returns:
    bool: The return value. True for success, False otherwise.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        raised by the method.
"""
    ret = parse(text)
    assert ret.short_description == 'Summary line.'
    assert ret.long_description == 'Test message without "Returns" and "Yields"'
    assert ret.extended_summary == ''
    assert len(ret.params) == 2
    assert ret.params[0].arg_name == 'param1'
    assert ret.params[0].type_name == 'int'

# Generated at 2022-06-23 17:16:40.917853
# Unit test for function parse
def test_parse():
    assert(parse("a", Style.google) == Docstring(summary="a", description='', params=[], examples=[]))


# Generated at 2022-06-23 17:16:44.643601
# Unit test for function parse
def test_parse():
    text = '''This is a test docstring with a Keyword, Version and Note.
    \nKeyword: keyword
    \nVersion: 1.0.0
    \nNote: This is a note.
    '''

    style = Style.auto

    parse(text, style = style)



# Generated at 2022-06-23 17:16:56.390514
# Unit test for function parse
def test_parse():
    dict_1 = {'name': 'docstring_parser', 'short_summary': 'Docstring parser.'}
    dict_2 = {'name': 'docstring_parser', 'short_summary': None, 'summary': 'Docstring parser.'}
    dict_3 = {'name': 'docstring_parser', 'short_summary': None, 'summary': 'Docstring parser.'}
    dict_4 = {'name': 'docstring_parser', 'short_summary': None, 'summary': 'Docstring parser.'}
    dict_5 = {'name': 'docstring_parser', 'short_summary': None, 'summary': 'Docstring parser.'}
    dict_6 = {'name': 'docstring_parser', 'short_summary': None, 'summary': 'Docstring parser.'}
    dict_7 = {}

# Generated at 2022-06-23 17:17:04.944768
# Unit test for function parse
def test_parse():
    from unittest.case import TestCase
    from unittest.mock import patch, MagicMock
    import docstring_parser.styles
    # Patch the existant parse functions with a mock that always raise
    # a ParseError
    with patch.multiple(
        docstring_parser.styles,
        sphinx=MagicMock(side_effect=ParseError()),
        numpy=MagicMock(side_effect=ParseError()),
        google=MagicMock(side_effect=ParseError()),
    ):
        with self.assertRaises(ParseError):
            parse("")
    # Patch the existant parse functions with a mock that always succeed

# Generated at 2022-06-23 17:17:13.410997
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test of the docstring_parser. 
    This is a line which should be in a second paragraph.
    """
    Docstring = parse(docstring, style=Style.google)
    assert Docstring.short_description == "This is a test of the docstring_parser."
    assert Docstring.long_description == ("This is a line which should be in a second paragraph.\n")
    assert Docstring.parameters == []
    assert Docstring.returns == []
    assert Docstring.exceptions == []
    assert Docstring.meta == {}

# Generated at 2022-06-23 17:17:20.436939
# Unit test for function parse
def test_parse():
    text = '''
    """This is a docstring.

:param x: description
:param y: description
:key z: description
:returns: description
:raises: description
:attr: description
:ivar: description
:cvar: description
:vartype: description
:type: description
:rtype: description
:context: description
:other: description

More text.
    """
    '''
    s = parse(text)
    assert s.short_description == 'This is a docstring.'
    assert len(s.long_description) == 2
    assert s.long_description[0] == ''
    assert s.long_description[1] == 'More text.'
    assert len(s.meta) == 14
    assert s.meta['param'][0] == ('x', 'description')


# Generated at 2022-06-23 17:17:24.635628
# Unit test for function parse
def test_parse():
    text = """
    :param foo: the foo
    :type foo: int
    :returns: None
    :rtype: int
    """
    d = parse(text)
    assert len(d.params) == 1
    assert len(d.returns) == 1

# Generated at 2022-06-23 17:17:31.458787
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    def func():
        """
        This function does nothing.

        :param a: a parameter
        """
        pass

    expected = Docstring(
        summary='This function does nothing.',
        params=[
            ('a', 'a parameter')
        ],
        return_='',
        raise_='',
        meta={
            'param a': 'a parameter'
        }
    )

    assert parse(func.__doc__) == expected
    assert parse(func.__doc__, style=Style.numpy) == expected
    assert parse(func.__doc__, style=Style.google) == expected


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:17:39.155783
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    from docstring_parser.common import Docstring, Parameter

    doc = parse("""
        Args:
            arg1: First argument
            arg2: Second argument
        Keyword Args:
            kwarg1: First keyword argument
            kwarg2: Second keyword argument
        Returns:
            None
        """)

    assert doc == Docstring(
        summary='',
        description='',
        parameters=[
            Parameter('arg1', 'First argument', '', '', False),
            Parameter('arg2', 'Second argument', '', '', False)
        ],
        returns=None,
        return_description='',
        examples=None
    )


# Generated at 2022-06-23 17:17:43.281306
# Unit test for function parse
def test_parse():
    docstring = """
    Summary line.

    Extended description.

    :param foo: Description of foo
    :param bar: Description of bar
    :returns: Description of return value
    :raises KeyError: Description of exception
    """
    assert parse(docstring) == Docstring(
        summary='Summary line.',
        description='Extended description.',
        extra_params=[],
        params=[
            ('foo', 'Description of foo'),
            ('bar', 'Description of bar'),
        ],
        returns=Docstring.Param('Description of return value', None),
        raises=[
            Docstring.Param('Description of exception', 'KeyError'),
        ]
    )


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:53.644869
# Unit test for function parse
def test_parse():
    # style_auto
    docstring_auto = """Summarize the Docstring parser.

Definition:
    Parse a single python docstring.

Args:
    text (str): The docstring text to parse
    style (Style): the docstring style

    Returns:
        Docstring: parsed docstring representation
"""
    assert parse(docstring_auto) == parse(docstring_auto, Style.auto)
    docstring_auto = """Summarize the Docstring parser.

    Definition:
        Parse a single python docstring.

    Args:
        text (str): The docstring text to parse
        style (Style): the docstring style
    
    Returns:
        Docstring: parsed docstring representation
"""
    assert parse(docstring_auto) == parse(docstring_auto, Style.auto)
    docstring_

# Generated at 2022-06-23 17:18:05.708415
# Unit test for function parse
def test_parse():

    example_text = """
    This function calculates the square root of a number
    :param x: The number to square root
    :type x: int
    :param y: The step value (optional)
    :type y: float
    :returns: The square root of x
    :rtype: float
    """
    docstring = parse(example_text)

    assert isinstance(docstring.short_description, str)
    assert docstring.short_description == 'This function calculates the square root of a number'

    assert isinstance(docstring.long_description, str)
    assert docstring.long_description is None

    assert isinstance(docstring.meta, dict)
    assert isinstance(docstring.meta['x'], tuple)
    assert docstring.meta['x'][0] == 'param'
    assert docstring

# Generated at 2022-06-23 17:18:16.730148
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={}, returns=None,
                                  examples=[])
    assert parse("Hello, world!") == Docstring(summary="Hello, world!", description="", meta={}, returns=None,
                                               examples=[])
    assert parse("Hello,\nworld!") == Docstring(summary="Hello, world!", description="", meta={}, returns=None,
                                                examples=[])
    assert parse("Hello,\n\nworld!") == Docstring(summary="Hello, world!", description="", meta={}, returns=None,
                                                  examples=[])
    assert parse("Hello,\n\nworld!\n\nFoo") == Docstring(summary="Hello, world!", description="Foo", meta={}, returns=None,
                                                          examples=[])
    assert parse

# Generated at 2022-06-23 17:18:27.393517
# Unit test for function parse
def test_parse():
    # first check to see if the docstring is formatted properly
    assert parse("test docstring") is None
    assert parse("""\
Test docstring

:param n: the size of the list
:returns: an n element list
""") is not None
    assert parse("Test docstring") is None
    assert parse("""\
Test docstring

Parameters
----------
n: int
    the size of the list
Returns
-------
list
    an n element list
""") is not None
    assert parse("""\
Test docstring

Args:
    n: int
        the size of the list
Returns:
    list: an n element list
""") is not None
    # check the parameters section
    assert parse("""\
Test docstring

:param n: the size of the list
""") is not None
    #

# Generated at 2022-06-23 17:18:32.307715
# Unit test for function parse
def test_parse():
    text = '''
this is the main description,
more lines
:param p1: paramter 1
:param p2: parameter 2
:returns: return something
:raises Exception: maybe
:meta: some meta information
'''
    print(parse(text, style='Google'))
    print(parse(text, style='Numpy'))
    print(parse(text, style='auto'))
# Unit test:
# test_parse()

# Generated at 2022-06-23 17:18:44.459548
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import Style
    import re

    "Tests for docstring_parser.parse"

    if __name__ == "__main__":
        # This doctest is ran from the package directory, so look for examples
        # in the examples directory
        import os
        examples_dir = os.path.join(os.path.dirname(__file__), "examples")
    else:
        # This doctest is ran from the python interpreter, so look for examples
        # in the parent directory
        examples_dir = os.path.join(os.path.dirname(__file__), "..", "examples")

    # Check that when no style is given, the best docstring is returned

# Generated at 2022-06-23 17:18:55.271757
# Unit test for function parse
def test_parse():
    docstring = """
        Функция позволяет задать возраст.

        :param age: возраст
        :type age: int
        :returns: возраст
        :raises ValueError: если возраст меньше 0 или больше 200
    """


# Generated at 2022-06-23 17:19:01.930517
# Unit test for function parse
def test_parse():
    parse_ = parse(docstring)
    assert parse_.short_description == "A random module"
    assert parse_.long_description == "Really, just random stuff."
    assert parse_.extended_description == "A bit more detail.\n\nAnd a final bit."

# Generated at 2022-06-23 17:19:11.926419
# Unit test for function parse
def test_parse():
    """
    Function test_parse()

    - Tests a string against all parsing styles (except the auto selector),
      and checks if the returned Docstring is equal to the result of the
      respective style.
    """
    docstring = """
    This is a function to make sure that this function works.

    Parameters
    ----------
    arg_1: str
        This is the first argument of the function.
    arg_2: int
        This is the second argument of the function.

    Returns
    -------
    list
        This is the return of the function.
    """
    
    for key, parse_ in STYLES.items():
        if key == Style.auto:
            continue
        assert docstring == str(parse(docstring, key))

# Generated at 2022-06-23 17:19:19.263771
# Unit test for function parse
def test_parse():
    text = '''\
    A function.

    Parameters
    ----------
    arg_1 : int
        The first arg.
    arg_2 : str
        The second arg.
    kw_1 : str
        The first kw args.

    Returns
    -------
    str
        The return value.
    int
        The return value.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'A function.'
    assert docstring.long_description == ''
    assert docstring.params == {'arg_1': 'int\n        The first arg.', 'arg_2': 'str\n        The second arg.',
                                'kw_1': 'str\n        The first kw args.'}

# Generated at 2022-06-23 17:19:22.312756
# Unit test for function parse
def test_parse():
    parse('''
    Parameters
    ----------
    alpha: float
    """
    ''')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:26.839532
# Unit test for function parse
def test_parse():
    text = """This is a function.
        :param name: Name
        :type name: str
        :returns: the name"""
    
    expected = {'returns': 'the name', 'params': {'name': 'Name'}}
    result = parse(text)
    assert result.params == expected['params']
    assert result.returns == expected['returns']

# Generated at 2022-06-23 17:19:37.172110
# Unit test for function parse
def test_parse():
    """Test the source code example"""
    docstring = """One line summary.

Extended description.

:param str param1: The first parameter.
:param int param2: The second parameter.
:returns: Description of return value.
:raises Exception1: Description of exception.
:raises Exception2: Description of exception.


Additional text.
"""

    expected = """One line summary.
:param param1: The first parameter.
:param param2: The second parameter.
:returns: Description of return value.
:raises Exception1: Description of exception.
:raises Exception2: Description of exception.

Extended description.

Additional text.
"""

    result = parse(docstring)
    #print(result)
    assert(result == expected)

# Generated at 2022-06-23 17:19:47.730908
# Unit test for function parse
def test_parse():
    text = '''
        One-line summary
        
        Multiline summary
        Multiline summary
        
        Multiline extended description
        Multiline extended description
        
        Parameters
        ----------
        param1: type of x
            param1
        param2: type of y
            param2
        Returns
        -------
        type of z
            return
        '''
    result = parse(text, style=Style.numpy)
    assert(result.summary == 'One-line summary')
    assert(result.extended == 'Multiline extended description\nMultiline extended description')

# Generated at 2022-06-23 17:19:57.411751
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None

    docstring = '''
    .. seealso:: :class:`example1`, :class:`example2`
    .. warning:: This is a warning.
    '''
    parsed = parse(docstring)
    assert len(parsed.summary) == 0
    assert len(parsed.description) == 0
    assert len(parsed.long_description) == 0
    assert len(parsed.params) == 0
    assert len(parsed.returns) == 0
    assert len(parsed.raises) == 0
    assert len(parsed.warnings) == 1
    assert len(parsed.meta) == 1
    assert len(parsed.extended_summary) == 0
    assert len(parsed.extended_description)

# Generated at 2022-06-23 17:20:08.123153
# Unit test for function parse
def test_parse():
    text = """This is a function.
    :param a: first param
    :param b: second param
    :returns: a plus b
    """

    doc = parse(text)

    parsed_text = doc.text
    parsed_params = doc.params
    parsed_return = doc.returns

    assert parsed_text == "This is a function."
    assert parsed_params[0].name == "a" and parsed_params[0].type == None and parsed_params[0].desc == "first param"
    assert parsed_params[1].name == "b" and parsed_params[1].type == None and parsed_params[1].desc == "second param"
    assert parsed_return.type == None and parsed_return.desc == "a plus b"

# Generated at 2022-06-23 17:20:17.875197
# Unit test for function parse
def test_parse():
    text = '''Example function with types documented in the docstring

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.

    '''
    function = parse(text)
    assert function is not None
    assert function.summary == 'Example function with types documented in the docstring'
    assert len(function.params) == 2
    assert function.params[0].name == 'param1'
    assert function.params[0].type == 'int'
    assert function.params[0].doc == 'The first parameter.'
    assert function.params[1].name == 'param2'
    assert function.params[1].type == 'str'

# Generated at 2022-06-23 17:20:22.667681
# Unit test for function parse
def test_parse():
    assert parse("""
    def foo():
        '''Test that this function gets documented.'''
        pass
    """).signature == 'def foo():'
    assert parse("""
    def foo():
        '''Test that this function gets documented.'''
        pass
    """).summary == 'Test that this function gets documented.'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:20:25.990669
# Unit test for function parse
def test_parse():
    docstring = parse("This is a docstring.")
    assert(docstring.short_description == "This is a docstring.")

test_parse()

# Generated at 2022-06-23 17:20:30.316507
# Unit test for function parse
def test_parse():
    text = """
        This is a test func.

        Parameters
        ----------
        name: str
            Full name
        age: int
            Age in years

        Returns
        -------
        str:
            Full name and age
        """
    assert parse(text).full == text


# Generated at 2022-06-23 17:20:33.476334
# Unit test for function parse
def test_parse():
	text = "This is a test"
	style = Style.numpy
	rets = parse(text, style)
	print(rets)

if __name__ == "__main__":
	test_parse()

# Generated at 2022-06-23 17:20:39.866451
# Unit test for function parse
def test_parse():
    assert parse("A simple docstring.") == Docstring(
        description = "A simple docstring.",
    )
    assert parse("A simple docstring.\nAnother paragraph.") == Docstring(
        description = "A simple docstring. Another paragraph.",
    )
    assert parse("A simple docstring.\n\nAnother paragraph.") == Docstring(
        description = "A simple docstring.\n\nAnother paragraph.",
    )

if __name__ == '__main__':
    print(test_parse())

# Generated at 2022-06-23 17:20:51.813406
# Unit test for function parse
def test_parse():
    """Function to test parsing a docstring.
       Example from: https://www.python.org/dev/peps/pep-0257/#multi-line-docstrings
    """
    text='''One-line summary and a description of the module.

    This can be several lines long.

    Args:
        arg1 (str): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        None

    Raises:
        ValueError: The first argument is invalid.
        TypeError: The second argument is invalid.
    '''
    result=parse(text)
    #docstring class can be found in common.py
    assert result.short_description=='One-line summary and a description of the module.'
    assert result.long_description=='This can be several lines long.'
    assert result.meta

# Generated at 2022-06-23 17:21:02.919449
# Unit test for function parse
def test_parse():
    text = """
    Example function with types documented in the docstring.

    :param int bar: The bar parameter.
    :param foobar: The foobar parameter.
    :param bool simple: The simple parameter.
    :returns: The return type.
    :rtype: str
    """

# Generated at 2022-06-23 17:21:07.797512
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GOOGLE

    text = """Single line docstring.
    """
    assert len(parse(text=text, style=GOOGLE).meta) == 1
    assert len(parse(text=text).meta) == 1

    text = """Single line docstring.

    Args:
        arg1: The first argument.
    """

    assert len(parse(text=text, style=GOOGLE).meta) == 2
    assert len(parse(text=text).meta) == 2

    text = """Multiline docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """


# Generated at 2022-06-23 17:21:13.881904
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("Hello, world!") == Docstring(summary="Hello, world!",
                                               description="", meta={})
    assert parse("Hello, world!", style=Style.sphinx) == \
        Docstring(summary="Hello, world!", description="", meta={})
    assert parse("Hello, world!", style=Style.google) == \
        Docstring(summary="Hello, world!", description="", meta={})
    assert parse("Hello, world!", style=Style.numpy) == \
        Docstring(summary="Hello, world!", description="", meta={})
    assert parse("Hello, world!", style=Style.epytext) == \
        Docstring(summary="Hello, world!", description="", meta={})

# Generated at 2022-06-23 17:21:20.194114
# Unit test for function parse
def test_parse():
    text = r'''
    Kablooie!
    '''
    doc = parse(text)
    assert isinstance(doc, Docstring)

    text = r'''
    Kablooie!
    '''
    doc = parse(text)
    assert isinstance(doc, Docstring)

# Generated at 2022-06-23 17:21:27.822499
# Unit test for function parse
def test_parse():
    source = """Simple example:

    >>> square(2)
    4

    More examples:

    >>> def square(x): return x * x
    >>> square(3)
    9
    >>> square(square(3))
    81
    """
    doc = parse(source,style=Style.sphinx)
    assert doc.args == []
    assert doc.short_description == "Simple example:"
    assert doc.long_description == ["",">>> square(2)","4","","More examples:","",">>> def square(x): return x * x",">>> square(3)","9",">>> square(square(3))","81"]
    assert doc.meta == {"__examples__":["",">>> square(2)","4"]}
    assert doc.returns == {}

# Generated at 2022-06-23 17:21:33.948348
# Unit test for function parse
def test_parse():
    assert parse('Parse the docstring into its components.')
    assert not parse('Parse the docstring into its components.', style=Style.auto)
    assert parse('Parse the docstring into its components.', style=Style.numpy)
    assert parse('Parse the docstring into its components.', style=Style.google)

# Generated at 2022-06-23 17:21:40.958700
# Unit test for function parse
def test_parse():
    text = """\
Summary line.

    Extended description.

Args:
    arg1 (int): Description of arg1
    arg2 (str): Description of arg2

Returns:
    bool: Description of return value

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.
"""
    parse(text)
    try:
        parse("")
        assert False
    except ParseError:
        assert True

# Generated at 2022-06-23 17:21:52.126642
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param test_param: description of the test_param
:type test_param:  int
:returns: description of what is returned
:rtype: int
:raises keyError: raises an exception
"""
    docstring = parse(text, style=Style.google)
    assert docstring.summary == "Summary line."
    assert docstring.extended_summary == "Extended description."
    assert docstring.body == []
    assert len(docstring.params) == 1
    assert docstring.params[0].arg_name == "test_param"
    assert docstring.params[0].description == "description of the test_param"
    assert docstring.params[0].annotation == "int"

# Generated at 2022-06-23 17:21:56.999869
# Unit test for function parse
def test_parse():
    text = """
    This is a summary.

    This is a description.

    :param name: the name of this function
    :type name: str
    :returns: the result of this function
    :rtype: int
    """

    d = parse(text)
    assert d.summary == 'This is a summary.'
    assert d.description == 'This is a description.'

# Generated at 2022-06-23 17:22:02.068852
# Unit test for function parse
def test_parse():
    docstring_text = '''
    Parameters:
        x: integer
        y: integer
    '''

    parse_ = parse(docstring_text)
    assert 'Parameters' in parse_.meta
    assert parse_.meta['Parameters'][0]['x'] == 'integer'
    assert parse_.meta['Parameters'][1]['y'] == 'integer'

# Generated at 2022-06-23 17:22:10.869835
# Unit test for function parse

# Generated at 2022-06-23 17:22:19.750451
# Unit test for function parse
def test_parse():
    text = '''\
    Routines:
    =========
    - a(x)
        returns x+1
    - b(x, y)
        returns x-y
    '''

    # Parse
    docstr = parse(text)
    assert docstr

    # Check data
    assert len(docstr.sections) == 1
    sec = docstr.sections[0]
    assert sec.name == 'Routines'
    assert len(sec.items) == 2
    item0 = sec.items[0]
    assert item0.name == 'a'
    assert item0.args == 'x'
    assert item0.desc == '\nreturns x+1\n'
    item1 = sec.items[1]
    assert item1.name == 'b'

# Generated at 2022-06-23 17:22:31.647900
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Field

# Generated at 2022-06-23 17:22:32.243759
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:22:39.385431
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(lines=[], meta=[], content=[])

    assert parse("lines", style=Style.google) == Docstring(lines=['lines'], meta=[], content=[])
    assert parse("lines", style=Style.numpy) == Docstring(lines=['lines'], meta=[], content=[])

    try:
        assert parse("", style=Style.google)
    except ParseError as e:
        assert str(e) == 'No description in google style doc string'

    try:
        assert parse("", style=Style.numpy)
    except ParseError as e:
        assert str(e) == 'No description in numpy style doc string'

# Generated at 2022-06-23 17:22:48.487895
# Unit test for function parse
def test_parse():
    def test_func():
        """This is a test function.

        Parameters
        ----------
        arg1 : int
            The first argument.
        arg2 : str
            The second argument.

        Returns
        -------
        bool
            The return value. True for success, False otherwise.
        
        """
        return True

    docstring = parse(test_func.__doc__)

    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert "arg1" in docstring.params
    assert docstring.params["arg1"].arg_name == "arg1"
    assert docstring.params["arg1"].type_name == "int"

# Generated at 2022-06-23 17:22:58.257886
# Unit test for function parse
def test_parse():
    text = """\
    This is a function for testing.

    :param x: A test param
    :type x: int
    :param y: Another test param
    :type y: int
    :returns: sum of x and y
    """
    text2 = """
    This is a function for testing.

    :param x: A test param
    :type x: int
    :param y: Another test param
    :type y: int
    :returns: sum of x and y
    """
    text3 = """
    This is a function for testing.

    Parameters
    ----------
    x : int
        A test param
    y : int
        Another test param
    returns : int
        sum of x and y
    """

# Generated at 2022-06-23 17:23:08.319404
# Unit test for function parse
def test_parse():
    assert parse("""Summary line.

    Description
        of
          several
               lines.

    :param test: test
    """) == Docstring(
        summary="Summary line.",
        description="Description of several lines.",
        params={'test': 'test'}
    )
    assert parse("""Summary line.

    :param test: test
    :raises ValueError: I raise
    :returns: whatever
    :rtype: int
    :keyword test: test
    """) == Docstring(
        summary='Summary line.',
        params={'test': 'test'},
        returns='whatever',
        rtype='int',
        raises={'ValueError': 'I raise'},
        keywords={'test': 'test'}
    )

# Generated at 2022-06-23 17:23:18.590189
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring
    :param arg: arg
    :return: Nothing
    :raises ValueError: When arg is invalid
    '''
    doc = parse(text)
    assert len(doc) == 3
    assert doc.paras[0].content == ''
    assert doc.paras[1].content == 'This is a docstring'
    assert repr(doc.metas) == '''[<Meta end=23 start=15 title=param>, <Meta end=69 start=50 title=return>, <Meta end=117 start=88 title=raises>]'''
    assert doc.metas[0].title == 'param'
    assert doc.metas[1].title == 'return'
    assert doc.metas[2].title == 'raises'

# Generated at 2022-06-23 17:23:30.492401
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param arg1: Description of arg1
:type arg1: str
:param arg2: Description of arg2
:type arg2: int, optional
:returns: Description of return value
:rtype: bool
:raises keyError: Raises an exception
:raises ImportError: If python is not found
:raises TypeError: If param2 has wrong type
:raises ValueError: If param2 is out of range
"""
    re = parse(text)
    assert re.summary == "Summary line."
    assert re.description == "Extended description."

# Generated at 2022-06-23 17:23:38.851232
# Unit test for function parse
def test_parse():
    docstring = '''This function does something.

This is a longer explanation.
It can span multiple lines.

:param int a: the first param
:param b: the second param
:returns: description of the return value
:raises keyError: explains a raised exception
'''

    parsed = parse(docstring);
    assert parsed.short_description == 'This function does something.'
    assert parsed.long_description == 'This is a longer explanation.\nIt can span multiple lines.'
    assert parsed.meta.params['a'] == 'the first param'


# Generated at 2022-06-23 17:23:39.970086
# Unit test for function parse
def test_parse():
    """Assert that parsing results are equal."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:23:41.297246
# Unit test for function parse
def test_parse():
    docstring = "This is a test to parse text"
    doc = parse(docstring)
    assert doc.full == docstring


# Generated at 2022-06-23 17:23:50.513063
# Unit test for function parse
def test_parse():
    # Writes a docstring in the expected format
    file_name = 'example.py'

    docstring_text = 'This is a module docstring.'
    class_docstring = 'This is a class docstring.'
    function_docstring_1 = 'This is a function docstring.'
    function_docstring_2 = 'This is another function docstring.'

    function_docstring_3 = 'This is a really really really really really really really long function docstring.'
    function_docstring_4 = 'This is a another really really really really really really really long function docstring.'

    # Todo: include more complex test cases
    # Todo: test case with **kwargs
    # Todo: test case with positional args that have a default value


# Generated at 2022-06-23 17:23:55.383832
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import (
        epytext,
        google,
        numpy,
        restructuredtext,
    )

    for parse_ in (epytext, google, numpy, restructuredtext):
        print(parse_)



# Generated at 2022-06-23 17:24:06.327800
# Unit test for function parse
def test_parse():
    text = """This is a multi-line
docstring"""

    # Style.auto will choose the best fit from the available styles; this
    # is the default behavior

    docstring = parse(text)

    print("ReST:")
    print("Summary:", docstring.short_description)
    for param, descr in docstring.params.items():
        print("  Parameter {:<10}: {:<25}".format(param, descr))
    print("Long Description:")
    print(docstring.long_description)

    # Alternatively, you can choose a specific style

    docstring = parse(text, style=Style.sphinx)

    # You can also obtain the original text of docstrings by setting the
    # preserve_quotes parameter to True


# Generated at 2022-06-23 17:24:10.113379
# Unit test for function parse
def test_parse():
    text = """
        This is a summary line.

        This is a longer, detailed description.  It can
        span multiple lines.
    """
    print("Parse result: %s" % parse(text))

# Unit test execution
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:18.307300
# Unit test for function parse

# Generated at 2022-06-23 17:24:23.078162
# Unit test for function parse
def test_parse():
    docstring_text = """
        This is a very simple function.

        Arguments:
            param1 (str): This is the first param.
            param2 (int, optional): This is a second param.

        Returns:
            bool: This is a description of what is returned.

        Raises:
            AttributeError, KeyError
        """

    docstring = parse(docstring_text, style=Style.auto)
    assert docstring.summary == 'This is a very simple function.'
    assert len(docstring.kwargs['arguments']) == 2
    assert docstring.kwargs['returns'][0] == 'bool'
    assert docstring.keys['raises'] == ['AttributeError', 'KeyError']


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:25.429088
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    from .test.test import TEST_DOCSTRINGS
    for style in STYLES.values():
        for key, value in TEST_DOCSTRINGS.items():
            docstring = parse(key, style)
            for attr in value:
                if docstring.__getattribute__(attr) != value[attr]:
                    return False
    return True


# Generated at 2022-06-23 17:24:36.422326
# Unit test for function parse

# Generated at 2022-06-23 17:24:47.126983
# Unit test for function parse
def test_parse():
    docstring = '''
    function_name
    This function is test function.

    :param testing1: test param1
    :type testing1: int, long
    :param testing2: test param2
    :type testing2: bool
    :returns: test return
    :rtype: double
    '''
    ds = parse(docstring, style=Style.google)
    assert ds.summary == 'function_name\nThis function is test function.'
    assert ds.meta['parameters'] == {'testing1': {'type': 'int, long', 'description': 'test param1'}, 'testing2': {'type': 'bool', 'description': 'test param2'}}
    assert ds.meta['returns']['type'] == 'double'

# Generated at 2022-06-23 17:24:57.380740
# Unit test for function parse
def test_parse():
    text = """\
    This is a summary.

    This is an extended description. Here you can use reStructuredText markup.

    This is another paragraph.

    :param arg1: This is the arg1 argument.
    :type arg1: int
    :param arg2: This is the arg2 argument.
    :returns: This is the return value.
    :rtype: str
    """

    docstring = parse(text)

    assert docstring.summary == "This is a summary."
    assert docstring.extended == "This is an extended description. Here you can use reStructuredText markup.\n\nThis is another paragraph."

# Generated at 2022-06-23 17:25:01.875938
# Unit test for function parse
def test_parse():
    docstring = """Short summary.
    Extended description.
    Args:
        arg_name (int): Description of arg_name
        arg_name2 (str): Description of arg_name2
    Returns:
        bool: Description of return value
    """

    print(parse(docstring))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:13.305869
# Unit test for function parse
def test_parse():
    """This is a unit test for the function parse."""

    test_docstring = """
    This docstring is for testing the function parse.

    :param int a: This is the int parameter a.
    :param str b: This is the str parameter b.
    :param list c: This is the list parameter c.
    :returns: This is the return statement.
    """

# Generated at 2022-06-23 17:25:17.105622
# Unit test for function parse
def test_parse():
    """Tests the parse method of DocstringParser"""
    testStr = """Unit test for function parse"""
    result = parse(testStr)
    assert result.summary == "Unit test for function parse"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:28.797119
# Unit test for function parse
def test_parse():
    text = """Function interface.
        
        Parameters
        ----------
        s: string
            String to process.
        n: int
            Number of iterations.
        
        Returns
        -------
        string
            Processed string.
        """

    docstring = parse(text, style=Style.spacy)
    assert docstring.short_description == "Function interface."
    assert docstring.long_description == ""
    params = docstring.params
    assert params[0].arg_name == "s"
    assert params[0].type_name == "string"
    assert params[0].description == "String to process."
    assert params[1].arg_name == "n"
    assert params[1].type_name == "int"
    assert params[1].description == "Number of iterations."

# Generated at 2022-06-23 17:25:34.158708
# Unit test for function parse
def test_parse():
    assert parse("class Message:\n  \"\"\"Represents a Message.\"\"\"") == Docstring(
        content=["Represents a Message."],
        args=[],
        return_="",
        exceptions=[],
        options=[],
    )


# Generated at 2022-06-23 17:25:40.942860
# Unit test for function parse
def test_parse():
    text = '''\
    Print the given message.

    :param msg: message to print
    :type msg: str
    :param level: log level (default: INFO)
    :type level: int
    '''
    docstring = parse(text)
    assert len(docstring.meta) == 2
    assert docstring.meta[0] == Docstring.Meta(
        name='msg', type='str',
        description='message to print'
    )
    assert docstring.meta[1] == Docstring.Meta(
        name='level', type='int',
        description='log level (default: INFO)'
    )

parse_docstring = parse

# Generated at 2022-06-23 17:25:52.238346
# Unit test for function parse
def test_parse():
    text = '''
    Summary line.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    int
        Description of return value

    '''
    docstring = parse(text)
    assert docstring.summary == "Summary line."
    assert docstring.description == "Extended description of function."

    assert docstring.returns.type_name == "int"
    assert docstring.returns.description == "Description of return value"

    assert len(docstring.params) == 2
    assert docstring.params['arg1'].type_name == "int"
    assert docstring.params['arg1'].description == "Description of arg1"

# Generated at 2022-06-23 17:26:03.205339
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring, NumpyDocstring
    assert_docstring = "Expected Docstring was:\n{}."
    assert_style = "Expected style was {}."
    assert_diff = "Expected Docstring() != Given Docstring().\n\
                   Expected Docstring was:\n{}\n\
                   Given Docstring was:\n{}."

# Generated at 2022-06-23 17:26:11.824240
# Unit test for function parse
def test_parse():
    from io import StringIO
    from docstring_parser.styles import NUMPY

    s = ("Name\n====\n"
         "my_func\n"
         "=======\n"
         "\n"
         "Summary\n"
         "-------\n"
         "func summary\n"
         "\n"
         "Parameters\n"
         "----------\n"
         "x:\n"
         "    parameter x\n"
         "y:\n"
         "    parameter y\n"
         "\n"
         "Returns\n"
         "-------\n"
         "None\n"
         "\n"
         "Notes\n"
         "-----\n"
         "my func notes\n")
    d = parse(s, NUMPY)

# Generated at 2022-06-23 17:26:14.160910
# Unit test for function parse
def test_parse():
    ds = parse('''
    A module which does something
    ''')
    assert ds.short_description == 'A module which does something'


# Generated at 2022-06-23 17:26:20.455059
# Unit test for function parse
def test_parse():
    test_doc = """Summary line.

Description of what the function does.

Args:
    Optional argument with no description.
    arg2 (int): Description of arg2.
    arg3 (str): Description of arg3.
        The description has multiple lines.
    arg4 (bool): Description of arg4.
    arg5 (list): Description of arg5.
        - The description has multiple lines.
        - the description continues.

Returns:
    The return value description.
        It has multiple lines.
"""
    doc = parse(test_doc)
    assert doc.summary == "Summary line."
    assert doc.description == "Description of what the function does."
    assert doc.meta['Args']['arg2']['type_name'] == 'int'

# Generated at 2022-06-23 17:26:32.305655
# Unit test for function parse