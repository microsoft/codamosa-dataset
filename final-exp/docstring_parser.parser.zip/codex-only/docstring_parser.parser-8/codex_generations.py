

# Generated at 2022-06-23 17:16:34.489608
# Unit test for function parse
def test_parse():
    docstring = '''
        This is a function for testing parse() function.
        :param a: param a
        :type a: int
        :param b: param b
        :type b: int
        :param c: param c
        :type c: int
        '''
    ds = parse(docstring, style=Style.numpy)
    assert ds.short_description == 'This is a function for testing parse() function.'
    assert ds.long_description == ''
    assert ds.params[0].name == 'a'
    assert ds.params[0].type_name == 'int'
    assert ds.params[0].description == 'param a'
    assert ds.params[1].name == 'b'
    assert ds.params[1].type_name == 'int'

# Generated at 2022-06-23 17:16:39.254569
# Unit test for function parse
def test_parse():
    found = parse("""
    This is a docstring text that is expected to be parsed.
    """, style=Style.numpy)
    assert found.short_description.strip() == "This is a docstring text that is expected to be parsed."
    assert found.long_description.strip() == ""


# Generated at 2022-06-23 17:16:47.395259
# Unit test for function parse
def test_parse():
    from .common import Docstring, Params, Returns
    from .styles import STYLES
    from .styles import Style
    from .utils import trim_docstring
    docstring = trim_docstring("""
    This is a very short description

    This is a longer description
    that spans multiple lines.

    We also have a paragraph
    that spans multiple lines.

    :param str x: this is x
    :param int y: this is y
    :return: the return value
    :rtype: str
    """)

    obj = parse(docstring)
    assert obj.short_description == trim_docstring("""
    This is a very short description
    """)

# Generated at 2022-06-23 17:16:58.401536
# Unit test for function parse
def test_parse():
    import pytest
    from docstring_parser.common import Methods
    doc = """Simple example:
    :param request: the request
    :type request: :class:`Request`
    :param param1: the first parameter
    :param param2: the second parameter
    :returns: something
    :rtype: str
    :raises TypeError: if something bad has happened
    """
    docstring = parse(doc)
    assert docstring.short_description == 'Simple example:'
    assert docstring.long_description == ''
    assert docstring.params.get('param1') == None
    assert docstring.params.get('param2') == None
    assert docstring.params.get('request').get('name') == 'request'
    assert docstring.params.get('request').get('kind') == Methods.POSITIONAL

# Generated at 2022-06-23 17:17:03.486198
# Unit test for function parse
def test_parse():
    docstring = parse(text_epytext)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta)
    print(docstring.params)
    print(docstring.returns)
    print(docstring.raises)
    print(docstring.warns)
    print(docstring.warns)
    print(docstring.sections)
    print(docstring.notes)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:17:08.209072
# Unit test for function parse
def test_parse():
    docstring = "A function that tests the parse function"
    parsed = parse(docstring)
    print(parsed)
    print(type(parsed))
    print(dir(parsed))
    assert parsed.short_description == 'A function that tests the parse function'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:17:17.842575
# Unit test for function parse
def test_parse():
    docstring = "This is a test doc.\n\n"
    docstring += ":param test: TestParam\n"
    docstring += ":type test: str\n"
    docstring += ":return: None\n"
    docstring += ":rtype: None\n"
    docstring += ":raises ValueError: If an error is raised\n"
    docstring += ":raises OverflowError: If a number is too large"
    output = parse(docstring, Style.google)
    assert len(output.meta["params"]) == 2
    assert len(output.meta["returns"]) == 1
    assert len(output.meta["raises"]) == 2
    return

# Generated at 2022-06-23 17:17:26.172933
# Unit test for function parse
def test_parse():
    # Test parse function
    text = """\
    Function to add two numbers
    :param a: First number
    :param b: Second number
    :returns: Sum of the two numbers
    """
    doc = parse(text)
    assert doc.short_description == "Function to add two numbers"
    assert doc.long_description == ""
    assert doc.returns.type_name == "Sum of the two numbers"
    assert doc.params["a"].description == "First number"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:32.591908
# Unit test for function parse
def test_parse():
    docstrings = {
        "Google": '''Google’s Backbone Network.
        Args:
          param1 (str): The first parameter.
          param2 (int, optional): The second parameter. Defaults to 42.
          *args: Variable length argument list.
          **kwargs: Arbitrary keyword arguments.
        Raises:
          AttributeError: The ``Raises`` section is a list of all exceptions
              that are relevant to the interface.
          ValueError: If `param2` is equal to `param1`.
        '''
    }
    for k, docstring in docstrings.items():
        parsed = parse(docstring)
        assert isinstance(parsed, Docstring)
        parsed_as_dict = parsed.as_dict(key_with_types=True)

# Generated at 2022-06-23 17:17:43.406566
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.google import GoogleDocstring
    from docstring_parser.styles.np import NumPyDocstring
    from docstring_parser.styles.numpy import NumpyDocstring
    from docstring_parser.styles.pep257 import PEP257Docstring

    def parse(text: str, style: Style = Style.auto) -> Docstring:
        """Parse the docstring into its components.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """

        if style != Style.auto:
            return STYLES[style](text)
        rets = []
        for parse_ in STYLES.values():
            try:
                rets.append(parse_(text))
            except ParseError as e:
                exc = e

# Generated at 2022-06-23 17:17:53.768630
# Unit test for function parse
def test_parse():
    from docstring_parser.style_google import GoogleStyle
    from docstring_parser.style_numpy import NumpyStyle
    docstr = """
    A short summary.

    Extended description.

    :param arg1: description
    :type arg1: str
    :param arg2: description
    :type arg2: int, optional
    :returns: description
    :rtype: bool
    :raises keyError: raises an exception
    """
    ret = parse(docstr)
    assert isinstance(ret, Docstring)
    assert isinstance(ret, GoogleStyle)


# Generated at 2022-06-23 17:18:05.705087
# Unit test for function parse
def test_parse():
    # test1
    # given
    docstring = parse.__doc__
    # when
    docstring = parse(docstring)
    # then
    try:
        assert docstring.meta['parse'] == 'docstring_parser.parser.parse'
        assert docstring.full_summary == 'Parse the docstring into its components.'
        assert docstring.args['text'] == 'docstring text to parse'
        assert docstring.args['style'] == 'docstring style'
        assert docstring.returns == 'parsed docstring representation'
    except AssertionError:
        print("parse failed.")

    # test2

# Generated at 2022-06-23 17:18:14.109766
# Unit test for function parse
def test_parse():
    text = """\
    This is a module docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: a number
    :raises Exception: when something bad happens
    """ # the text to be parsed
    docstring = parse(text, Style.numpy)
    assert str(docstring) == text
    print(docstring)
    print(docstring.summary)
    print(docstring.extended_summary)
    print(docstring.params)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:18:19.284232
# Unit test for function parse
def test_parse():
    text = '''
    Summary line.

    Description
        extended description

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    int
        Description of return value

    '''
    docstring = parse(text)
    print(str(docstring.meta))
    print(str(docstring.content))


# Generated at 2022-06-23 17:18:25.882994
# Unit test for function parse
def test_parse():
    docstring = '''
    Header
    ------

    :param aa: aaa
    :type aa: int

    '''
    d = parse(docstring)
    assert(d.short_description == 'Header')
    assert(d.long_description == '')
    assert(len(d.meta) == 1)
    assert(len(d.meta['Parameters']) == 1)


# Generated at 2022-06-23 17:18:31.823073
# Unit test for function parse
def test_parse():
    """Basic usage, no error"""
    text = """
    我是
    文档字符串

    [haha] [you]

    :return: Nothing
    """
    doc = parse(text)
    assert doc.description == '我是\n文档字符串'
    assert len(doc.meta) == 1
    assert doc.meta[0].name == 'returns:'
    assert doc.meta[0].description == 'Nothing'



# Generated at 2022-06-23 17:18:44.099463
# Unit test for function parse
def test_parse():
    '''Test output of the parse function'''
    docstring = '''
    This is a docstring.

    This is its second paragraph. It has quite a few words. This
    will be used to test the parse function.

    Parameters
    ----------
    arg: str
        My argument.
    out: str, optional
        Another argument.
    '''

    parsed = parse(docstring)

    assert parsed.summary == 'This is a docstring.'
    assert parsed.description == 'This is its second paragraph. It has quite a few words. This will be used to test the parse function.'

# Generated at 2022-06-23 17:18:54.779386
# Unit test for function parse
def test_parse():
    # Example 1
    doc = """\
    Name of module or package.

    :param arg: description

    :type arg: string
    :returns: description

    :raises exception_name: description
    """
    parsed = parse(doc)
    assert parsed.summary == 'Name of module or package.'
    assert parsed.args == 'arg: description'
    assert parsed.retval == 'description'
    assert parsed.errors == 'exception_name: description'
    assert parsed.meta == {'param': 'arg: description',
                           'returns': 'description',
                           'raises': 'exception_name: description'}

    # Example 2

# Generated at 2022-06-23 17:18:56.078789
# Unit test for function parse
def test_parse():
    print(parse('Test string'))

# Generated at 2022-06-23 17:19:01.467703
# Unit test for function parse
def test_parse():
    d = parse("""This is a short summary.

And this is a long

description.

:param request: the current request
:type request: :class:`django.http.HttpRequest`
:param template_name: the template to render
:type template_name: str or :class:`django.template.Template` object
:param dictionary: template context
:type dictionary: dict
:param using: template backend
:type using: str
:returns: rendered template
:rtype: :class:`django.http.HttpResponse`
:raises: :class:`django.template.TemplateDoesNotExist`
""")
    print(d)

test_parse()

# Generated at 2022-06-23 17:19:12.553410
# Unit test for function parse
def test_parse():
    # test parsing docstrings with styles auto, google and numpy
    for style, parsers in {Style.auto: [], Style.google: [], Style.numpy: []}.items():
        styles = []
        for Parse in STYLES.values():
            p = (Parse, Parse.__name__)
            if p not in styles:
                styles.append(p)
        if style != Style.auto:
            styles = [STYLES[style]]

        for Parse, name in styles:
            docstring = """Docstring without any field.

Arguments:
    param1: bla bla
        que pasa
    param2 - a parameter
    param3 (str): bla
"""
            parsed = parse(docstring, style)
            assert parsed.short_description == 'Docstring without any field.'


# Generated at 2022-06-23 17:19:15.976109
# Unit test for function parse
def test_parse():
    a = '''
    I am a description.

    :param: foo
    '''
    assert parse(a).description == 'I am a description.'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:19.939302
# Unit test for function parse
def test_parse():
	from docstring_parser.common import ParseError
	
	try:
		parse('{"a":"a"}')  
	except ParseError: 
		pass
	else:
		raise RuntimeError("test_parse failed")

# Generated at 2022-06-23 17:19:22.874862
# Unit test for function parse
def test_parse():
    text = 'Function with a docstring.'
    print(parse(text))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:26.763506
# Unit test for function parse
def test_parse():
    assert str(parse('Hello, World!', Style.Google).summary) == 'Hello World'
    assert str(parse('Hello, World!', Style.Google).meta) == ''

# Generated at 2022-06-23 17:19:36.400413
# Unit test for function parse
def test_parse():
    docstring = """One line summary.

Multiple line description.

Attributes:
    attr1: Description of `attr1`.
    attr2: Description of `attr2`.

Returns:
    Description of return value.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.

.. _PEP 257:
    https://www.python.org/dev/peps/pep-0257/
"""
    docstring_parser = parse(docstring, style=Style.google)
    print(docstring_parser)

test_parse()

# Generated at 2022-06-23 17:19:40.444856
# Unit test for function parse
def test_parse():
    docstring = parse(
        """
        Example function with types documented in the docstring.

        :param int x: The number x.
        :param str y: The string y.
        :return: int
        :raises ValueError: If `x` is negative.
        """
    )
    print(docstring.return_type)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:46.269438
# Unit test for function parse
def test_parse():
    text = ('"""A module docstring."""\n'
            '"""A module docstring."""\n'
            '"A module docstring."\n'
            '"A module docstring.\n'
            '"A module docstring.\n')

    docstring = parse(text, Style.google)
    assert docstring.summary.strip() == 'A module docstring.'
    assert len(docstring.description.strip()) == 0
    assert len(docstring.extended_summary.strip()) == 0
    assert len(docstring.returns.strip()) == 0
    assert len(docstring.epilog.strip()) == 0
    assert docstring.meta == {}
    assert len(docstring.params) == 0
    assert docstring.has_errors == False


# Generated at 2022-06-23 17:19:56.586272
# Unit test for function parse
def test_parse():
    code = '''\
"""
Description

:param arg1: First argument
:type arg1: int
:param arg2: Second argument
:type arg2: str
:returns: str -- The return value
:raises keyError: raises an exception
"""'''
    docstring = parse(code, style=Style.google)
    assert 'Description' in docstring.short_description, "short description isn't correctly parsed"
    assert docstring.arguments == [
        {'name': 'arg1', 'type': 'int', 'description': 'First argument'},
        {'name': 'arg2', 'type': 'str', 'description': 'Second argument'},
    ], 'arguments description isn\'t correctly parsed'
    assert docstring.returns['type'] == 'str', 'return type isn\'t correctly parsed'
   

# Generated at 2022-06-23 17:19:57.139500
# Unit test for function parse
def test_parse():
    parse("test")

# Generated at 2022-06-23 17:20:06.591781
# Unit test for function parse
def test_parse():
    text = """This is the function summary line.

    This is the function description paragraph.

    :param x: int
    :param y: int
    :return: int
    """
    assert parse(text).Summary == "This is the function summary line."
    assert parse(text).Description == "This is the function description paragraph."
    assert parse(text).Parameters['x'].Description == " int"
    assert parse(text).Parameters['y'].Description == " int"
    assert parse(text).Returns.Description == " int"
    assert parse(text).Returns.Type == "int"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:20:16.736237
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring for testing purposes.

    Parameters:
    param1 (int): A parameter
    param2 (float): Another parameter

    Returns:
    bool: A bool

    Raises:
    TypeError: If the type is wrong
    ValueError: If the value is wrong
    """
    expected = Docstring(
        short_description="This is a test docstring for testing purposes.",
        long_description="",
        params=[
            ("param1", "int", "A parameter"),
            ("param2", "float", "Another parameter"),
        ],
        return_=("bool", "A bool"),
        raises=["TypeError", "If the type is wrong", "ValueError", "If the value is wrong"],
    )
    assert expected == parse(docstring)

# Generated at 2022-06-23 17:20:22.460429
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google

    docstring_text = """
        Attributes:
            param1 (int): The first parameter.
            param2 (str): The second parameter. Mutually exclusive with *param3*.

        Keyword Args:
            param3 (list of str): List of strings. Mutually exclusive with *param2*.
            param4 (str): The fourth parameter.

        Raises:
            KeyError: Raises an exception.
    """
    docstring_parsed = parse(docstring_text)
    assert isinstance(docstring_parsed, Google)
    docstring_text_1 = """
        New docstring.
    """
    docstring_parsed_1 = parse(docstring_text_1)
    assert not isinstance(docstring_parsed_1, Google)

   

# Generated at 2022-06-23 17:20:26.649301
# Unit test for function parse
def test_parse():
    assert isinstance(parse(""), Docstring)
    assert isinstance(parse("", Style.google), Docstring)
    assert isinstance(parse("", Style.numpy), Docstring)


# Generated at 2022-06-23 17:20:36.987010
# Unit test for function parse
def test_parse():
    d = parse("- foo : bar")
    assert d.short_description == ""
    assert d.long_description == ""
    assert d.meta['foo'] == 'bar'
    assert d.returns == None
    d = parse("- foo : bar\n- hello: world")
    assert d.short_description == ""
    assert d.long_description == ""
    assert d.meta['foo'] == 'bar'
    assert d.meta['hello'] == 'world'
    assert d.returns == None
    d = parse(""""This is a short description.

This is a long description.

- foo : bar

- hello: world""")
    assert d.short_description == 'This is a short description.'
    assert d.long_description == 'This is a long description.'

# Generated at 2022-06-23 17:20:41.018097
# Unit test for function parse
def test_parse():
    text = """
        Function to add two numbers.

        Parameters
        ----------
        x: int
            The first number.
        y: int
            The second number.

        Returns
        -------
        int
            The sum of the two numbers.
    """
    style = Style.numpy
    assert (parse(text, style) is not None)

# Generated at 2022-06-23 17:20:53.020554
# Unit test for function parse
def test_parse():
    text = '''
            This function does nothing.

                """
                This is a docstring.
                Args:
                    arg1: An argument.
                    arg2: Another argument.
                """
                '''
    a = parse(text)
    assert a.short_description == "This function does nothing."
    assert a.long_description == "This is a docstring."
    assert a.return_type == None
    assert a.meta["Args"].get_arguments() == [
            {"name": "arg1", "types": None, "desc": "An argument."},
            {"name": "arg2", "types": None, "desc": "Another argument."}
            ]
    assert a.meta["Args"].get_args_str() == "arg1: An argument.\narg2: Another argument."

# Generated at 2022-06-23 17:21:00.113352
# Unit test for function parse
def test_parse():
    docstring = """This function is a test function to test parse.
    
    :param aaa: aaaa
    :param bbb: bbbb
    :returns: ccccc
    """
    result = parse(docstring, Style.Numpy)
    assert(result.short_desciption == 'This function is a test function to test parse.')
    assert(result.meta['param']['aaa'].description == 'aaaa')
    assert(result.meta['param']['bbb'].description == 'bbbb')
    assert(result.meta['return'].description == 'ccccc')


# Generated at 2022-06-23 17:21:10.059588
# Unit test for function parse
def test_parse():
    try:
        docstring = parse("")
    except ParseError as e:
        assert str(e) == "Empty docstring."
    else:
        assert False

    docstring = parse("Hello world.")
    assert docstring.short_description == "Hello world."
    assert docstring.long_description == ""
    assert docstring.meta == {}

    docstring = parse("""Hello world.

Long description.

Args:
  argument (int): the argument.
""")
    assert docstring.short_description == "Hello world."
    assert docstring.long_description == "Long description."
    assert docstring.meta == {"Args": [("argument", "the argument.", "int")]}

# Generated at 2022-06-23 17:21:16.752681
# Unit test for function parse
def test_parse():
    a = parse("""T1
    T1.1
    :param T2: T3
    """)
    assert a.meta.get("T2") == "T3"
    assert a.summary == "T1"
    assert a.extended_summary == "T1.1"
    try:
        from docstring_parser.styles import _GoogleStyle
        a = _GoogleStyle("""T1
        T3

        T4
        """)
        assert False
    except ParseError:
        pass

# Generated at 2022-06-23 17:21:26.842970
# Unit test for function parse
def test_parse():
    """Test for function parse"""

    from docstring_parser.styles import PEP257

    doc = r"""This is a test
    :meta1: meta1
    :meta2: meta2
    """

    meta, descriptions = parse(doc, style=Style.pep257)
    assert meta['meta1'] == 'meta1'
    assert meta['meta2'] == 'meta2'

    meta, descriptions = PEP257(doc)
    assert meta['meta1'] == 'meta1'
    assert meta['meta2'] == 'meta2'

    doc = r"""
    This is a test
    :meta1: meta1
    :meta2: meta2
    """

    meta, descriptions = parse(doc, style=Style.pep257)
    assert meta['meta1'] == 'meta1'

# Generated at 2022-06-23 17:21:38.726505
# Unit test for function parse
def test_parse():
    text = """
:param int a: test a
:param int b: test b
    """
    docstring = parse(text)
    assert isinstance(docstring,Docstring)
    # print(docstring.params)
    # print(docstring.meta)
    # assert isinstance(docstring.meta,List[Section])
    assert isinstance(docstring.params,list)
    assert len(docstring.params) == len(docstring.meta)
    # print(docstring.params[0])
    # print(docstring.meta[0])
    # print(docstring.params[0].name)
    # print(docstring.meta[0].description)
    assert docstring.params[0].name == docstring.meta[0].name
    assert docstring.params[0].type_name == docstring

# Generated at 2022-06-23 17:21:41.563774
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring
    :param name: Your name
    '''
    res = parse(docstring)
    assert set(res.meta.keys()) == {'param'}


# Generated at 2022-06-23 17:21:53.322977
# Unit test for function parse
def test_parse():
    docstring = '''    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation'''
    result = parse(docstring)
    # print(result.short_description)
    # print(result.long_description)
    # print(result.meta)
    # print(result.meta['param'])
    # print(result.meta['return'])
    assert result.short_description == "Parse the docstring into its components."
    assert len(result.meta) == 2
    assert len(result.meta['param']) == 2
    assert result.meta['param'][0].arg_name == "text"
    assert result.meta['param'][0].description == "docstring text to parse"

# Generated at 2022-06-23 17:22:03.924718
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    doc = parse.__doc__
    rets = parse(doc, style=Style.numpy)
    print(rets)
    assert rets.meta[0]['name'] == 'text'
    assert rets.meta[0]['type'] == 'str'
    assert rets.meta[1]['name'] == 'style'
    assert rets.meta[1]['type'] == 'Style'
    assert rets.description == 'Parse the docstring into its components.'
    assert rets.long_description == '\n    :param text: docstring text to parse\n    :param style: docstring style\n    :returns: parsed docstring representation\n    '

# Generated at 2022-06-23 17:22:14.697093
# Unit test for function parse
def test_parse():
    
    # Test case 1
    text1 = """
    Summarize the function here.
    
    This part of documentation will be printed.
    
    :param x: Description of parameter `x`.
    :param y: Description of parameter `y`.
    :return: Description of the return value.
    """
    result1 = parse(text1, style=Style.google)
    assert result1.long_description == 'Summarize the function here.\n\nThis part of documentation will be printed.'
    assert result1.short_description == 'Summarize the function here.'
    assert result1.meta == {'param': ['x: Description of parameter `x`', 'y: Description of parameter `y`'], 'return': ['Description of the return value']}
    

# Generated at 2022-06-23 17:22:15.925325
# Unit test for function parse
def test_parse():
    assert parse("""
"""
)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:21.495996
# Unit test for function parse
def test_parse():
    text = """
    This is a function.
    :param a: this is a
    :warning:: This is a warning
    :returns: the return value
    """
    print(parse(text))
    print("\n")
    print(parse(text, 1))
    print("\n")
    print(parse(text, 2))
    print("\n")
    print(parse(text, 3))
    print("\n")
    print(parse(text, 4))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:33.382739
# Unit test for function parse
def test_parse():
    docstring = '''
    Hello world.
    :return: nothing
        '''
    assert parse(docstring).short_description == 'Hello world.'
    assert parse(docstring).long_description == ''
    assert parse(docstring).meta['return'] == 'nothing'

    docstring = """
    Parse the docstring into its components.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    assert parse(docstring).short_description == 'Parse the docstring into its components.'
    assert parse(docstring).long_description == ''
    assert parse(docstring).meta['param']['text'] == 'docstring text to parse'
    assert parse(docstring).meta['param']['style'] == 'docstring style'
   

# Generated at 2022-06-23 17:22:40.835289
# Unit test for function parse

# Generated at 2022-06-23 17:22:44.507751
# Unit test for function parse
def test_parse():
    doc = """
            This is a docstring.

            :param int a: argument a
            :param b: argument b

            :rtype: int
            """
    print(parse(doc))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:56.009510
# Unit test for function parse
def test_parse():
    text = '''
    Main objective of this model is to detect whether a given news is real or fake.

    :param filepath: Location of file to be loaded.
    :type filepath: str
    :returns: A `pandas.DataFrame` object.
    :rtype: `pandas.DataFrame`
    :raises: IOError
    '''
    docstring1 = parse(text)
    assert docstring1.short_description == "Main objective of this model is to detect whether a given news is real or fake."
    assert docstring1.long_description == None
    assert docstring1.meta[0]['params'] == "filepath"
    assert docstring1.meta[0]['type'] == "str"

# Generated at 2022-06-23 17:23:07.691970
# Unit test for function parse
def test_parse():
    sample = """
    This is a docstring.

    :param arg1: The first argument
    :param arg2: The second argument

    :Example:

    >>> a = 5
    >>> b = 7
    >>> print(a+b)

    :returns: A number
    """


# Generated at 2022-06-23 17:23:18.223901
# Unit test for function parse
def test_parse():
    def test_docstring_parser(self):
        text = '''Single line docstring.'''
        self.assertEqual(parse(text), Docstring(text))
        text = '''First line\n\nSecond line.\n'''
        self.assertEqual(parse(text), Docstring(text))
        text = '''
        First line.

        Second line.

        Third line.
        '''
        self.assertEqual(parse(text), Docstring(text))
        text = '''First line\nSecond line\n\nThird line\nFourth line'''
        self.assertEqual(parse(text), Docstring(text))
        text = '''
        TITLE


        DESCRIPTION

        A paragraph.
        '''

# Generated at 2022-06-23 17:23:30.098409
# Unit test for function parse
def test_parse():
    text = """\
    This is a sample docstring.

    :param = input: the input
    :type input: int
    :param = output: the output
    :type output: dict
    :rtype: dict
    """
    docstring = parse(text)

    assert docstring.short_description == 'This is a sample docstring.'
    assert docstring.long_description is None
    assert docstring.extended_description is None
    assert len(docstring.meta) == 2
    assert docstring.meta['input']['type'] == 'int'
    assert docstring.meta['input']['description'] == 'the input'
    assert docstring.meta['output']['type'] == 'dict'
    assert docstring.meta['output']['description'] == 'the output'
    assert docstring.ret

# Generated at 2022-06-23 17:23:40.529983
# Unit test for function parse
def test_parse():
    text = """
    """
    doc = parse(text)
    assert not doc.short_description
    assert not doc.long_description
    assert not doc.meta

    text = """
    This is a test
    string.

    Section
    -------
    Block 1
    Block 2

    """
    doc = parse(text)
    assert doc.short_description == "This is a test\nstring."
    assert doc.long_description == "Section\n-------\nBlock 1\nBlock 2\n\n"
    assert not doc.meta

    text = """
    This is another test
    string.

    Section
    -------
    Block 1
    Block 2

    :param x: parameter x
    :raises UserWarning: when x > 0

    """
    doc = parse(text)
    assert doc.short_

# Generated at 2022-06-23 17:23:49.899396
# Unit test for function parse
def test_parse():
    s = """
    Test parse docstring

    Parameters
    ----------
    a : float
        for test
    b : str
        for test

    Returns
    -------
    float
        for test
    str
        for test
    """

    expected = Docstring(params=[
        (
            "a",
            {
                "type": "float",
                "description": "for test"
            }
        ),
        (
            "b",
            {
                "type": "str",
                "description": "for test"
            }
        )],
        returns=[
            {
                "type": "float",
                "description": "for test"
            },
            {
                "type": "str",
                "description": "for test"
            }
        ]
    )


# Generated at 2022-06-23 17:23:53.714181
# Unit test for function parse
def test_parse():
    docstring_str = """
    Example module.
    """
    docstring = parse(docstring_str)
    assert docstring.short_description == "Example module."

# Generated at 2022-06-23 17:24:02.242573
# Unit test for function parse
def test_parse():
    text = """\
This is a multi line docstring formatted with reStructuredText
(reST).

Parameters
----------

param1 : str
    The *first* parameter.
param2 : int
    The second parameter.

Returns
-------

value : int
    The return value.

Raises
------

exc2
    The second exception.

.. rubric:: Footnotes

.. [#f1] This is a footnote
.. [#f2] This is another footnote
"""

    docstring = parse(text, style=Style.rst)
    assert docstring.short_description == "This is a multi line docstring formatted with reStructuredText (reST)."
    assert docstring.long_description == ""
    assert docstring.params["param1"] == "The *first* parameter."

# Generated at 2022-06-23 17:24:09.311317
# Unit test for function parse
def test_parse():
    
    def add(a, b):
        """Add two numbers.

        Multiline description

        :param a: first number
        :param b: second number 
        :type a: int, b: int
        :returns: sum of numbers
        :rtype: int
        """

    docstring = parse(add.__doc__)
    assert isinstance(docstring, Docstring)

#============Unit test for function parse ends===============
#===========Unit test for function parse_docstring===========


# Generated at 2022-06-23 17:24:18.088707
# Unit test for function parse
def test_parse():
    doc = parse(docstring_text)
    assert doc.short_description == "Solve the quadratic equation a*x**2 + b*x + c = 0"
    assert doc.long_description == "Returns a tuple of solutions, or raises\nNoSolution if no solution could be found."
    assert len(doc.params) == 3
    assert len(doc.returns) == 1
    assert len(doc.raises) == 1


# Generated at 2022-06-23 17:24:27.962717
# Unit test for function parse
def test_parse():
    doc = """This is a short description.

This is a long description.

.. py:method:: my_method(a, b, c=1)

    This is a short description.

    This is a long description.

    :param a: A parameter
    :param b: Another parameter
    :param c: Third parameter
    :returns: The data
    :rtype: int
"""

    docstring = parse(doc, style=Style.google)

    # Test overall
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.meta == {'py:method': [{'args': ['a', 'b', 'c=1'],
                                             'name': 'my_method'}]}

    # Test method


# Generated at 2022-06-23 17:24:31.018878
# Unit test for function parse
def test_parse():
    assert parse('This is test.') == Docstring(content=[('This is test.',[])], meta=[])


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:41.055385
# Unit test for function parse
def test_parse():
    test_docstring = """
    This is a test of the parse function.

    :param test_string: a test string
    :type test_string: str
    :returns: a test string
    :rtype: str
    """
    doc = parse(test_docstring)
    assert doc.short_description == "This is a test of the parse function."
    assert len(doc.long_description) == 0
    assert doc.meta['parameters'][0].arg_name == "test_string"
    assert doc.meta['parameters'][0].type_name == "str"
    assert doc.meta['parameters'][0].description == "a test string"
    assert doc.meta['returns'][0].type_name == "str"

# Generated at 2022-06-23 17:24:48.836342
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    my_docstring = """This is my docstring.
    
    Args:
        param1: The first parameter
        param2: The second parameter
    
    Returns:
        Return 1
    """
    expected_docstring = Docstring(
        content = 'This is my docstring.',
        args = ['param1: The first parameter', 'param2: The second parameter'],
        returns = 'Return 1'
    )
    assert parse(my_docstring) == expected_docstring
    
    
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:58.425189
# Unit test for function parse
def test_parse():
    doc_contents = '''\
Test docstring for function.

:param test_param: This is a test parameter.
:returns: Test return value.
'''
    doc_contents = parse(doc_contents)
    assert doc_contents.short_description == 'Test docstring for function.'
    assert doc_contents.long_description == 'Test docstring for function.'
    assert doc_contents.params[0].arg_name == 'test_param'
    assert doc_contents.params[0].description == 'This is a test parameter.'
    assert doc_contents.raises[0].type == 'TestException'
    assert doc_contents.raises[0].description == 'Test exception description.'
    assert doc_contents.returns.description == 'Test return value.'
    assert doc_cont

# Generated at 2022-06-23 17:25:08.987532
# Unit test for function parse
def test_parse():
    """Test function parse"""
    text = '''
        This is a function that tests the parse function

        :param x: float
            add to y
        :param y: float
            add to x
        :return: float
            addition of x and y
        :key style: str
            the style of docstring,
            like google, numpy or reStructuredText
        :key param: str
            the type of param and name of param,
            like int x or string s
        :key return: str
            the type of return or
            string None if the method does not return anything
    '''

    assert type(parse(text)) == Docstring

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:18.594543
# Unit test for function parse
def test_parse():
    text = '''
    1. Style: Google
    
    Args:
        param1 (int): Description of `param1`
    '''
    result = parse(text)
    assert result.meta['Args'] == {'param1': {'type': 'int', 'description': 'Description of `param1`'}}

    text = '''
    2. Style: Numpy
    
    Parameters
    ----------
    param1 : int
        Description of `param1`
    '''
    result = parse(text)
    assert result.meta['Parameters'] == {'param1': {'type': 'int', 'description': 'Description of `param1`'}}

    text = '''
    3. Style: ReStructuredText
    
    :param param1: Description of `param1`
    '''
    result

# Generated at 2022-06-23 17:25:23.024671
# Unit test for function parse
def test_parse():
    example = """Summary line.

Extended description.

:param str  param1: The first parameter.
:param int  param2: The second parameter.
:returns: Description of `returns`.
:raises TypeError: Raises TypeError if `param2` is not an int
"""

    d = parse(example)

    assert d.summary == "Summary line."
    assert d.description == "Extended description."
    assert len(d.params) == 2
    assert len(d.returns) == 1
    assert len(d.raises) == 1


# Generated at 2022-06-23 17:25:32.426719
# Unit test for function parse
def test_parse():
    s = """one line short description
        
        more detailed description, typically several sentences.
        
        :param argument: description of parameter
        :type argument: str (or another type)
        :returns: return value
        :rtype: str
        """
    res = parse(s)
    assert(res)
    assert(res.short_description == 'one line short description')
    assert(res.long_description == 'more detailed description, typically several sentences.')
    assert(res.params[0].name == 'argument')
    assert(res.params[0].type_name == 'str')
    assert(res.params[0].description == 'description of parameter')
    assert(res.returns.description == 'return value')
    assert(res.returns.type_name == 'str')

# Generated at 2022-06-23 17:25:43.383087
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

# Generated at 2022-06-23 17:25:53.272132
# Unit test for function parse
def test_parse():
    m = parse("""
    summary.
    """)
    assert m.summary == 'summary.'
    m = parse("""
    summary.

    extra.
    """)
    assert m.summary == 'summary.'
    assert m.extras == ['extra.']
    m = parse("""
    summary.

    Args:
      arg.
    """)
    assert m.summary == 'summary.'
    assert m.arguments == [{'name': 'arg', 'type': '', 'desc': ''}]
    m = parse("""
    summary.

    Arguments:
      arg.
    """)
    assert m.summary == 'summary.'
    assert m.arguments == [{'name': 'arg', 'type': '', 'desc': ''}]

# Generated at 2022-06-23 17:26:04.031856
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    from docstring_parser.styles import Style
    
    single_line = parse("""A test.""", Style.single_line)
    assert single_line.short_description == "A test."
    assert single_line.long_description == ""
    assert not single_line.return_annotation
    assert not single_line.return_description
    assert not single_line.meta

    google = parse("""A test.
    Args:
    arg1:
    Returns:
    """, Style.google)
    assert google.short_description == "A test."
    assert google.long_description == ""
    assert not google.return_annotation
    assert not google.return_description
    assert not google.meta


# Generated at 2022-06-23 17:26:13.270482
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """
        The quick brown fox jumps over the lazy dog.
        :param str a_string: A test string
        :param list b_list: A test list
        :param list c_list: A test list
        :returns str: The input string
        :raises ValueError: Test exception
    """
    parsed = parse(text)
    assert parsed.summary == 'The quick brown fox jumps over the lazy dog.'
    assert len(parsed.params) == 2
    assert len(parsed.raises) == 1
    assert parsed.returns.annotation == 'str'


# Run the unit tests, if this is the main module
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:26:18.040767
# Unit test for function parse
def test_parse():
    docstr = '''
    Sample docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :return: The return value. True for success, False otherwise.
    '''

    result = parse(docstr)

    assert(result.short_description == 'Sample docstring.')
    assert(len(result.long_description) == 0)

    assert(result.returns['desc'] == 'The return value. True for success, False otherwise.')

# End unit test for function parse



# Generated at 2022-06-23 17:26:25.820228
# Unit test for function parse
def test_parse():
    text = """
    Parameters
    ----------
    x: int
        The first operand.
    y: int
        The second operand.
    Returns
    -------
    int
        The result.
    """
    rets = parse(text)
    assert len(rets.meta) == 2
    assert rets.meta[0].type_name == 'int'
    assert rets.returns.type_name == 'int'
    assert rets.returns.description == 'The result.'

if __name__ == '__main__':
    test_parse()