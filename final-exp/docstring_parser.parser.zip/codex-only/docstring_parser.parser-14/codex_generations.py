

# Generated at 2022-06-23 17:16:30.059698
# Unit test for function parse
def test_parse():
    """Test function 'parse'"""
    from docstring_parser.styles import GoogleStyle
    c = GoogleStyle('Module for testing docstring_parser')
    assert isinstance(c, Docstring)
    c = GoogleStyle('''Module for testing docstring_parser.
    
    Parameters
    ----------
    :param str
    :returns None (should not work)
    ''')
    assert isinstance(c, Docstring)

# Generated at 2022-06-23 17:16:34.614021
# Unit test for function parse
def test_parse():
    with open('bin/test_docstring_parser.txt', 'r') as docstring:
        text = docstring.read()
        parse_ = parse(text, style=Style.pep257)
        print(parse_)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:16:44.528149
# Unit test for function parse
def test_parse():
    '''
    >>> parse('text')
    Traceback (most recent call last):
    docstring_parser.common.ParseError: Docstring format not detected.
    >>> parse('text', Style.auto)
    Traceback (most recent call last):
    docstring_parser.common.ParseError: Docstring format not detected.
    '''
    doc = parse('text', Style.numpy)
    assert str(doc) == 'text'
    doc = parse('text', Style.google)
    assert str(doc) == 'text'
    assert repr(doc) == "Docstring(text='''text''')"
    doc = parse('''
    text
    ''', Style.numpy)
    assert str(doc) == 'text'

# Generated at 2022-06-23 17:16:56.359903
# Unit test for function parse
def test_parse():
    from .examples import (
        APACHE_2,
        BOOST,
        Google,
        Numpy,
        NumpyGoogle,
        RST,
    )

    # Test parse() with different formats
    assert parse(APACHE_2) == APACHE_2
    assert parse(Google) == Google
    assert parse(Numpy) == Numpy
    assert parse(RST) == RST

    # Test parse() with a style
    assert parse(Google, Style.google) == Google
    assert parse(Numpy, Style.numpy) == Numpy
    assert parse(RST, Style.rst) == RST

    # Try a docstring which matches two parsers
    assert parse(NumpyGoogle) == Google

    # Try a docstring which matches multiple parsers
    assert parse(BOOST)

# Generated at 2022-06-23 17:17:04.956454
# Unit test for function parse
def test_parse():
    docstring = parse(text="""Summary line.

    Extended description.

    Args:
      arg1: A string.

    Returns:
      An integer.

    Raises:
      ValueError: When the arg is not valid.

    """
    )
    if docstring.summary != "Summary line.":
        raise AssertionError()
    if docstring.extended_summary != "Extended description.":
        raise AssertionError()
    if len(docstring.params) != 1:
        raise AssertionError()

    param = docstring.params[0]
    if param.arg_name != "arg1":
        raise AssertionError()
    if param.description != "A string.":
        raise AssertionError()

    if docstring.returns != "An integer.":
        raise Ass

# Generated at 2022-06-23 17:17:15.573845
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "", [], [], [])
    assert parse("Foo bar\n\nFoo bar") == Docstring("", "Foo bar\nFoo bar", [], [], [])
    assert parse(".. code-block:: python\n\n    Foo bar\n\n    Foo bar") == Docstring(
        "", "", [], [], [], code="Foo bar\nFoo bar", code_language="python"
    )
    assert parse("Args:\n    foo (str): Foo\n\nReturns:\n    str: Foo") == Docstring(
        "", "", [], [], [], args="Args:\nfoo: Foo", returns="Returns:\nFoo"
    )



# Generated at 2022-06-23 17:17:27.130268
# Unit test for function parse
def test_parse():
    class Test_class:
        def test_method(self):
            """Method definition

            Args:
                arg1 (int): The first argument.
                arg2 (str): The second argument.

            Returns:
                bool: The return value. True for success, False otherwise.

            """
            return True

        def other_test_method(self):
            """Method definition

            Args:
                arg1: The first argument.
                arg2: The second argument.

            Returns:
                The return value. True for success, False otherwise.

            """
            return True

    import pprint
    pp = pprint.PrettyPrinter()
    a = parse(Test_class.test_method.__doc__)
    pp.pprint(a._asdict())


# Generated at 2022-06-23 17:17:37.317035
# Unit test for function parse
def test_parse():
    text = '''\
    :param foo: a foo
    :param bar: a bar!
    :return: returns a baz
    '''
    d = parse(text)
    assert d.meta['param']['foo'].args == ['foo']
    assert d.meta['param']['foo'].description == ['a foo']
    assert d.meta['param']['bar'].args == ['bar']
    assert d.meta['param']['bar'].description == ['a bar!']
    assert d.meta['return'].args == []
    assert d.meta['return'].description == ['returns a baz']
    assert d.content == []
    assert d.short_description == ""


# Generated at 2022-06-23 17:17:47.173783
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import GoogleStyle
    d = Docstring(description=('This is a module docstring.\n'
                               'More text, on the next line.'),
                  short_description='This is a module docstring.',
                  meta=[]
                  )
    assert parse('') == Docstring(description='', short_description='', meta=[])
    assert parse('Short description.') == Docstring(description='Short description.', short_description='Short description.', meta=[])
    assert parse('Short description\nLong description') == Docstring(description='Short description\nLong description', short_description='Short description', meta=[])

# Generated at 2022-06-23 17:17:53.295218
# Unit test for function parse
def test_parse():
    from docstring_parser.common import NameValue
    from docstring_parser.styles import Style
    from docstring_parser.docstring import Docstring
    from docstring_parser.parse import parse
    d = parse("This is a test string.", Style.numpy)
    assert(d.short_description == "This is a test string.")
    d = parse("""This is a test string.
                  It has multiple lines.""", Style.numpy)
    assert(d.short_description == "This is a test string.")
    assert(d.long_description == "It has multiple lines.")

# Generated at 2022-06-23 17:18:05.103797
# Unit test for function parse
def test_parse():
    text = """A function to add two numbers.

Args:
    a (int): First number.
    b (int): Second number.

Returns:
    int: The sum of the two numbers.
"""
    assert parse(text) == \
        Docstring(
            content='A function to add two numbers.',
            returns=Docstring.Returns(type_hint='int', description='The sum of the two numbers.'),
            args=[Docstring.Arg(name='a', type_hint='int', description='First number.'),
                Docstring.Arg(name='b', type_hint='int', description='Second number.')]
            )
    text = """A function to add two numbers.

:param int a: First number.
:param int b: Second number.
:return: The sum of the two numbers.
"""

# Generated at 2022-06-23 17:18:16.060174
# Unit test for function parse
def test_parse():
    docstring = r'''
    Test function to test parse function.
    :param a: Dummy parameter a
    :type a: int
    :param b: Dummy parameter b
    :type b: int
    :param c: Dummy parameter c
    :type c: int
    :returns: maximum of a and b
    :rtype: int
    :raises ValueError: If c is equal to 10.
    '''
    parsed = parse(docstring)
    # Check the docstring itself
    assert parsed.short_description == "Test function to test parse function."
    assert parsed.long_description == ""
    # Check the function parameters
    assert parsed.params['a'].name == "a"
    assert parsed.params['a'].arg_type == "int"

# Generated at 2022-06-23 17:18:23.140816
# Unit test for function parse
def test_parse():
    docstring = """Some regular text.

    One-liner summary.

    Extended description.

    :param x: Parameter x.
    :type x: int
    :param y: Parameter y.
    :type y: int
    :returns: Return value.
    :rtype: int
    """
    parsed = parse(docstring)
    assert parsed.short_description == 'One-liner summary.'
    assert parsed.long_description == 'Extended description.'
    assert parsed.meta == {'x': 'Parameter x.',
                           'y': 'Parameter y.',
                           'returns': 'Return value.'}
    assert parsed.return_type == 'int'
    assert parsed.return_annotation is None

# Generated at 2022-06-23 17:18:31.809731
# Unit test for function parse
def test_parse():
    a = parse("""\
        This is the first line of this docstring.
        This is the second line of this docstring.

        Parameters
        ----------
        arg1: int
            this is arg1
        arg2: str
            this is arg2
        arg3: bool
            this is arg3

        Returns
        -------
        None

        """
    )
    assert a.short_description == "This is the first line of this docstring."
    assert a.long_description == """\
This is the second line of this docstring.
"""
    assert len(a.params) == 3
    assert len(a.returns) == 1



# Generated at 2022-06-23 17:18:44.099959
# Unit test for function parse
def test_parse():
    assert parse("") == None
    assert parse("""
        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        Proin ac diam justo.
        """) == None
    assert parse("""
        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        Proin ac diam justo.
        :returns: Quisque vel dictum justo
        Nullam accumsan eros et nisl hendrerit scelerisque.
        """) == None

# Generated at 2022-06-23 17:18:46.419039
# Unit test for function parse
def test_parse():
    assert parse('this is a docstring') == Docstring(
        summary='this is a docstring',
        description=None,
        meta={},
        examples=[]
    )



# Generated at 2022-06-23 17:18:57.896021
# Unit test for function parse
def test_parse():
    """Tests for function parse"""

    # Test for function parse with style epytext and sphinx
    def test_parse_style():
        """Tests for function parse with style epytext and sphinx"""

        # Test for function parse for epytext style
        def test_parse_epytext():
            """Tests for function parse for epytext style"""

            # Test for function parse for epytext style
            def test_parse_epytext():
                """Tests for function parse for epytext style"""

                # Test for function parse for epytext
                def test_parse_epytext_class():
                    """Tests for function parse for epytext"""
                    class Test:
                        """Test class docstring."""
                        pass

                    parse(Test.__doc__)

                test_parse_epytext_

# Generated at 2022-06-23 17:19:10.114410
# Unit test for function parse
def test_parse():
    print('Parsing Examples')
    print('---------------\n')

# Generated at 2022-06-23 17:19:18.212923
# Unit test for function parse
def test_parse():
    ret = parse('''
    A quick utility to resize streaming videos to a given height.
    The program loops over the input framerate, downscaling each frame
    with OpenCV and emitting the result.
    :param height: height in pixels
    :param framerate: framerate of the input video
    :param input: filename of the input video
    :param output: filename of the output video
    :param method: algorithm used to resize the image
    :returns: None
    ''')

    assert ret.short_description == 'A quick utility to resize streaming videos to a given height.'
    assert ret.long_description == 'The program loops over the input framerate, downscaling each frame\n    with OpenCV and emitting the result.'

# Generated at 2022-06-23 17:19:28.127350
# Unit test for function parse
def test_parse():
    """
    function description
    :param arg1: This is arg1
    :param arg2: This is arg2
    :returns: what it returns
    :rtype: string
    :raises keyError: raises keyError

    test_parse(arg1,arg2)
    """
    docstring = parse(test_parse.__doc__)
    print(docstring)
    assert docstring.short_description == "function description"
    assert docstring.long_description == ""
    assert docstring.meta["param"][0] == "arg1:This is arg1"
    assert docstring.meta["returns"] == "what it returns"
    assert docstring.meta["rtype"] == "string"
    assert docstring.meta["raises"][0] == "keyError:raises keyError"
    print

# Generated at 2022-06-23 17:19:31.041335
# Unit test for function parse
def test_parse():
    """
    >>> d = parse('This is a test', Style.numpy)
    >>> d.short_description
    'This is a test'
    """
    pass

# Generated at 2022-06-23 17:19:40.193057
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = '''
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    docstring = parse(text=text)
    assert docstring.summary == ''
    assert docstring.meta['param'][0].var == 'text'
    assert docstring.meta['param'][0].type == ''
    assert docstring.meta['param'][0].description == 'docstring text to parse'
    assert docstring.meta['param'][1].var == 'style'
    assert docstring.meta['param'][1].type == ''
    assert docstring.meta['param'][1].description == 'docstring style'
    assert docstring.meta['returns'][0].type == ''
    assert doc

# Generated at 2022-06-23 17:19:43.624741
# Unit test for function parse
def test_parse():
    text = """\
    This is test function.

    :param int arg: This is arg
    :returns: This is return
    :rtype: tuple
    """
    p = parse(text)
    print(p.__dict__)


# Generated at 2022-06-23 17:19:53.547119
# Unit test for function parse
def test_parse():
    text = """\
    :param str arg1: The first argument
    :param arg2: The second argument
    :returns: The output
    """
    style = Style.numpydoc
    assert parse(text, style=style).meta == {'arg1': 'The first argument',
                                             'arg2': 'The second argument',
                                             'returns': 'The output'}
    assert parse(text, style=style).summary == ''
    assert parse(text, style=style).content == ''
    assert parse(text, style=style).returns == 'The output'
    assert parse(text, style=style).return_desc == ''

# Generated at 2022-06-23 17:20:05.631977
# Unit test for function parse
def test_parse():
    doc = parse("""Example docstring.

    Args:
      arg1 (int): The first parameter.
      arg2 (str): The first parameter.
      arg3 (tuple): The first parameter.

    Returns:
      True if successful, False otherwise.

    Raises:
      AttributeError, KeyError
    """)
    assert doc.short_description == 'Example docstring.'
    assert doc.long_description == ['', '']
    assert doc.meta['args'][0].arg_name == 'arg1'
    assert doc.meta['args'][0].arg_type == 'int'
    assert doc.meta['args'][0].description == ['The first parameter.']
    assert doc.meta['args'][1].arg_name == 'arg2'
    assert doc.meta['args'][1].arg_

# Generated at 2022-06-23 17:20:11.916377
# Unit test for function parse
def test_parse():
	# Load text file
	text = open('docstring_parser/test/test_parse.txt', mode='r')
	text = text.readlines()

	# Load result
	result = open('docstring_parser/test/test_parse_result.txt', mode='r')
	result = result.read()

	# Run function
	output = parse(''.join(text))
	
	# Compare results
	assert(result == output)

test_parse()

# Generated at 2022-06-23 17:20:15.706174
# Unit test for function parse
def test_parse():
    d = parse('''This is the summary.

    Some details
    ''')
    assert d.summary == 'This is the summary.'
    assert d.details == 'Some details'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:20:21.058936
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring
    docstring = """Summary line.

Extended description.

Args:
    arg1 (int): Description of arg1
    arg2 (str): Description of arg2

Returns:
    bool: Description of return value

"""
    expected = GoogleDocstring(docstring)

    # Parse the input docstring
    parsed = parse(docstring)

    # Verify the input and output are the same
    assert parsed.summary == expected.summary
    assert parsed.description == expected.description
    assert parsed.args == expected.args
    assert parsed.returns == expected.returns

# Generated at 2022-06-23 17:20:28.589023
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    docstring = '''This function does something.
It is useful.

:param x: parameter x

:y: parameter y
:returns: nothing
:raises ValueError: if something bad happens

'''
    doc = parse(docstring)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.params)
    print(doc.returns)
    print(doc.raises)

# Generated at 2022-06-23 17:20:35.488753
# Unit test for function parse
def test_parse():
    # Arrange
    text = '''
    This is a sample docstring.

    :param name: The name to use.
    :type name: str.
    :param state: Whether to activate or disable.
    :type state: bool.
    :returns: str -- The processed name.
    :raises keyError: Raises an exception
    '''
    # Act
    ret = parse(text)
    # Assert
    assert isinstance(ret, Docstring)



# Generated at 2022-06-23 17:20:42.082645
# Unit test for function parse
def test_parse():
    assert (parse("""
        This is a multi-line docstring.

        :param foo: first param
        :param bar: second param
        :raises RuntimeError: foo
        :return: baz
    """).params == {'foo': 'first param', 'bar': 'second param'})


# Generated at 2022-06-23 17:20:46.648841
# Unit test for function parse
def test_parse():
    docstring = '''Line 1.
Line 2.

Line 3.
Line 4.'''

    doc = parse(docstring)
    assert not doc.short_description
    assert doc.long_description == 'Line 1.\nLine 2.\n\nLine 3.\nLine 4.'
    assert not doc.meta
    assert not doc.content


    docstring = '''Line 1.
Line 2.

Line 3.
Line 4.

:param arg1: The first argument.
:param arg2: The second argument.
:returns: Description of return value.
:raises keyError: raises an exception
'''

    doc = parse(docstring)
    assert not doc.short_description

# Generated at 2022-06-23 17:20:50.298368
# Unit test for function parse
def test_parse():
    assert parse('Hello World')
    assert parse('Hello World', Style.google)
    assert parse('Hello Wordl', Style.pep257)
    assert parse('Hello World', Style.numpy)
    assert not parse('Hello Wordl', Style.numpy)

# Generated at 2022-06-23 17:20:59.638313
# Unit test for function parse

# Generated at 2022-06-23 17:21:00.192089
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:21:08.875285
# Unit test for function parse
def test_parse():
    res = parse("""
        This is a test docstring.

        It defines a function that adds to numbers.

        Args:
            x: first number
            y: second number

        Returns:
            result: addition result
        """)
    assert res.short_description == "This is a test docstring."
    assert res.long_description == "It defines a function that adds to numbers."
    assert res.meta["args"] == ["x: first number", "y: second number"]
    assert res.meta["returns"] == ["result: addition result"]
    assert res.meta.get("author", None) == None

# Generated at 2022-06-23 17:21:18.325787
# Unit test for function parse
def test_parse():
    class DocstringTest(object):
        """Class containing test docstring.

        Short Summary
        -------------
        This class contains a test docstring.

        Long Summary
        ------------
        This is an example of a long summary.  It occurs after the short
        summary and before the first section heading.
        """

    # Initialize the style.
    test_object = DocstringTest()
    my_docstring = parse(test_object.__doc__)

    # Check the short summary and long summary.
    assert my_docstring.summary == 'Class containing test docstring.'
    assert my_docstring.long_description == 'This is an example of a long summary.  It occurs after the short\n' \
                                            'summary and before the first section heading.'

    # Check the parameters.

# Generated at 2022-06-23 17:21:27.370661
# Unit test for function parse

# Generated at 2022-06-23 17:21:29.044997
# Unit test for function parse
def test_parse():
    # TODO: Implement unit tests for the parse function
    return

# Generated at 2022-06-23 17:21:30.022244
# Unit test for function parse
def test_parse():
    assert(parse("hello world"))

# Generated at 2022-06-23 17:21:37.824975
# Unit test for function parse
def test_parse():
    docstring = '''
    	Summarize the Docstring.

        Args:
            param1 (int): The first parameter.
            param2 (str): The second parameter.

        Returns:
            bool: The return value. True for success, False otherwise.
        '''
    print(parse(docstring))
    docstring1 = '''test
    '''
    print(parse(docstring1))


if __name__== '__main__':
	test_parse()

# Generated at 2022-06-23 17:21:45.580485
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    import doctest
    from collections import namedtuple

    DocstringTest = namedtuple('DocstringTest', ['docstring', 'parse', 'expected'])


# Generated at 2022-06-23 17:21:56.627466
# Unit test for function parse
def test_parse():
    str1 = """Test function.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    assert(parse(str1).short_description == 'Test function.')
    assert(parse(str1).long_description == None)
    assert(parse(str1).params == {'text':'docstring text to parse', 'style':'docstring style'})
    assert(parse(str1).returns == 'parsed docstring representation')
    assert(parse(str1).raises == None)
    
    str2 = """Test function.

    Arguments:
        text {str} -- docstring text to parse
        style {str} -- docstring style

    Returns:
        Docstring -- parsed docstring representation
    """

# Generated at 2022-06-23 17:22:00.387069
# Unit test for function parse
def test_parse():
    import sys
    sys.path.append('../')
    from main import parse
    assert(parse("Custom doc string") == 
            Docstring([("Custom doc string", "", 0)], {}, "", [], {}))

# Generated at 2022-06-23 17:22:07.015542
# Unit test for function parse
def test_parse():
    text = 'Sample docstring'
    assert parse(text).summary == text
    text = 'First line\nSecond line'
    assert parse(text).summary == 'First line'
    assert parse(text).description == 'Second line'
    text = 'First line\n\nSecond line'
    assert parse(text).description == 'Second line'
    text = 'First line\n\n    indented code'
    assert parse(text).description == 'First line'
    assert parse(text).body == '\nindented code'

# Generated at 2022-06-23 17:22:09.066752
# Unit test for function parse
def test_parse():
    parse(text="Hello world")


# Generated at 2022-06-23 17:22:18.660774
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.sphinx_style import parse_sphinx
    from docstring_parser.styles.google_style import parse_google
    from docstring_parser.docstring import Docstring

    assert parse('one\ntwo') == Docstring(summary='one', details='two')
    assert parse('one\ntwo', style=Style.google) == parse_google('one\ntwo')
    assert parse('one\ntwo', style=Style.sphinx) == parse_sphinx('one\ntwo')
    assert parse('one\ntwo', style=Style.auto) == parse_sphinx('one\ntwo')
    assert parse('one\n\ntwo') == Docstring(summary='one', details='two')

# Generated at 2022-06-23 17:22:28.678998
# Unit test for function parse
def test_parse():
    """Function to test function parse"""
    docstring = "This is a docstring for testing."
    result = parse(docstring, Style.sphinx)
    assert result == "sphinx", "Assertion failed for sphinx docstring."
    result = parse(docstring, Style.numpy)
    assert result == "numpy", "Assertion failed for numpy docstring."
    result = parse(docstring, Style.google)
    assert result == "google", "Assertion failed for google docstring."
    result = parse(docstring, Style.auto)
    assert result == "google", "Assertion failed for auto docstring."

# Generated at 2022-06-23 17:22:32.996355
# Unit test for function parse
def test_parse():
    #Tested using the example Google format
    doct = """
    This is a long summary
    
    Args:
        arg_one (str): This is the first argument
        arg_two (int): This is the second argument
        
    Returns:
        bool: True if successful, False otherwise.

    """
    
    expected_output = 'This is a long summary\n\nArgs:\n    arg_one (str): This is the first argument\n    arg_two (int): This is the second argument\n\nReturns:\n    bool: True if successful, False otherwise.\n'
    assert str(parse(doct)) == expected_output


# Generated at 2022-06-23 17:22:36.230382
# Unit test for function parse
def test_parse():
    d = '''This is a summary.

    This is the extended summary.
    '''

    parsed = parse(d)
    assert parsed.summary == 'This is a summary.'
    assert parsed.description == 'This is the extended summary.'


# Generated at 2022-06-23 17:22:42.927232
# Unit test for function parse
def test_parse():
    docstring = '''
>>> parser = DocstringParser()
>>> docstring = '''
    """This module is for testing the docstring_parser library.
    """
    # Unit test for attribute docstring
    def test_docstring():
        assert docstring == parser.parse(docstring)

# Generated at 2022-06-23 17:22:44.276935
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    pass


# Generated at 2022-06-23 17:22:47.663471
# Unit test for function parse
def test_parse():
    text = "Function to summarize text"
    result = parse(text,style=Style.google)
    print(result.short_description)
    rex = result.short_description
    expected = "Function to summarize text"
    assert rex == expected

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:57.688969
# Unit test for function parse
def test_parse():
    docstring = '''\
This is a test function.

Arguments:
    arg1 (str): arg1
'''
    doc = parse(docstring)
    assert doc.short_description == 'This is a test function.'
    assert doc.arguments == [('arg1', 'str', 'arg1')]
    assert doc.returns == None
    assert doc.return_type == None
    assert doc.meta == {"Arguments": "Arguments:", "Return": None, "Raises": None, "Yields": None}

    docstring = '''\
This is a test function.

:param arg1: arg1
:type arg1: str
'''
    doc = parse(docstring)
    assert doc.short_description == 'This is a test function.'

# Generated at 2022-06-23 17:23:07.924194
# Unit test for function parse
def test_parse():
    assert parse("""
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """) == Docstring(
        content='Parse the docstring into its components.',
        meta={'param': [{'name': 'text', 'desc': 'docstring text to parse'}, {'name': 'style', 'desc': 'docstring style'}], 'return': 'parsed docstring representation'}
    )


# Generated at 2022-06-23 17:23:14.187401
# Unit test for function parse
def test_parse():
    text = """
    An overview of the module.

    Attributes
    ----------
    foo : int
        A variable that is not really interesting.
    bar : str
        Another variable that is not really interesting.

    Methods
    -------
    foobar(a, b)
        A method that is not really interesting.
    """
    parse(text)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:20.965721
# Unit test for function parse
def test_parse():
    docstring = """This is a docstring.
    :param arg1: this is arg1
    :param arg2: this is arg2
    :param arg3: this is arg3
    :returns: description of return value
    """
    print("Style: numpy")
    ds = parse(docstring, style=Style.numpy)
    print("Short description:", ds.short_description)
    print("Long desciption:", ds.long_description)
    print("Arguments:", ds.meta.arguments)
    print("Returns:", ds.ret)
    print("Style: rest")
    ds = parse(docstring, style=Style.rest)
    print("Short description:", ds.short_description)
    print("Long desciption:", ds.long_description)

# Generated at 2022-06-23 17:23:32.175452
# Unit test for function parse
def test_parse():
    # docstring
    text = '''
    """This is an example module.

    This module does stuff.
    """
    '''
    result = parse(text, Style.numpy)
    assert result.meta == (0, 0)
    # end docstring
    text = '''
    """This is an example module.

    This module does stuff.
    """
    '''
    result = parse(text, Style.google)
    assert result.meta == (0, 0)
    # docstring
    text = '''
    """This is an example module.

    This module does stuff.
    """
    '''
    result = parse(text, Style.numpy)
    assert result.short_description == "This is an example module."
    # end docstring

# Generated at 2022-06-23 17:23:38.521008
# Unit test for function parse
def test_parse():
    assert parse("This is a module docstring.")
    assert parse("This is a module docstring.\n")
    assert parse("This is a module docstring.\n\n")
    assert parse("This is a module\n     docstring.")
    assert parse(
        "This is a module docstring.\n"
        "\n"
        "It can have multiple paragraphs."
    )
    assert parse(
        "This is a module docstring.\n"
        "\n"
        "It can have multiple paragraphs.\n"
        "\n"
        "With new line."
    )


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:48.179167
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring

    :param arg1: this is arg1
    :param arg2: this is arg2
    :returns: None
    """
    text = text.strip()
    docstring = parse(text)
    assert docstring == Docstring(
        summary="This is a docstring",
        body=[],
        args=[
            Docstring.Arg(
                name="arg1",
                type=None,
                desc="this is arg1",
                default=None,
                optional=False,
            ),
            Docstring.Arg(
                name="arg2",
                type=None,
                desc="this is arg2",
                default=None,
                optional=False,
            ),
        ],
        returns=None,
        other=[],
    )

# Generated at 2022-06-23 17:23:59.156918
# Unit test for function parse
def test_parse():
    text = '''
    :param param1: the first parameter
    :param param2: the second parameter
    :returns: description of the return value
    :raises keyError: raises an exception
    '''
    r = parse(text)
    assert r.meta['param1'].dst == 'the first parameter'
    assert r.meta['param2'].dst == 'the second parameter'
    assert r.returns.dst == 'description of the return value'
    assert r.raises['keyError'].dst == 'raises an exception'

    def parse(text):
        r = parse(text)
        print('\n'.join(map(lambda x: str(x), r.__dict__.items())))

    parse(text)

# Generated at 2022-06-23 17:24:09.389756
# Unit test for function parse
def test_parse():
    text = '''\
        This is the docstring summary.

        This is the extended description of the docstring.
        It can span multiple lines.

        Parameters:
            first_param: This is the first parameter.
            second_param: This is the second parameter.
        Returns:
            This is the return value.
        '''
    doc = parse(text)
    assert doc.summary == "This is the docstring summary."
    assert doc.body == "This is the extended description of the docstring.\nIt can span multiple lines."
    assert doc.params.keys() == {"first_param", "second_param"}
    assert doc.returns.keys() == {"return"}

# Generated at 2022-06-23 17:24:14.048624
# Unit test for function parse
def test_parse():
    test_text = '''\
    title
    -----
    summary
    '''
    assert repr(parse(test_text)) == \
        """Docstring(summary=u'summary', title=u'title')"""

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:17.544712
# Unit test for function parse
def test_parse():
    text = """This is the summary.

    This is the description.

    Args:
        arg1 (str): description of arg1
        arg2 (str): description of arg2
    """
    docstring = parse(text)
    print(docstring)
    print(docstring.meta)
    print(docstring.params)
    print(docstring.returns)

# Generated at 2022-06-23 17:24:25.089482
# Unit test for function parse
def test_parse():
    text = '''
    Python docstring_parser:
    ---------------------
    A pure-python library for parsing docstrings.
    '''
    assert parse(text).short_description=="A pure-python library for parsing docstrings."
    assert parse(text).long_description=="Python docstring_parser:\n---------------------\nA pure-python library for parsing docstrings.\n"
    assert parse(text).style == Style.google
    assert parse(text).meta == {}


# Generated at 2022-06-23 17:24:34.654151
# Unit test for function parse
def test_parse():
    text1 = """
    Test function.

    :param x: Test variable
    :type x: int
    :param y: Test variable
    :type y: str
    :return: test return
    :rtype: float
    """
    text2 = """
    Test function.

    :param x: Test variable
    :param y: Test variable
    :return: test return
    """
    text3 = """
    Test function.

    :param x: Test variable
    :param y: Test variable
    """

    print(parse(text1))
    print(parse(text2))
    print(parse(text3))

# Generated at 2022-06-23 17:24:45.586213
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Arg, Return

    docstring = parse(text='Test function.\n\n:param x: asdf')
    assert docstring.summary == 'Test function.'
    docstring = parse(text='Test function.\n\n:param x: asdf\n:returns: 1')
    assert docstring.summary == 'Test function.'
    assert docstring.returns == Return(type_name='', description='1')
    docstring = parse(text='Test function.\n\n:param x: asdf\n:returns: (1, 2)')
    assert docstring.summary == 'Test function.'
    assert docstring.returns.description == '(1, 2)'

# Generated at 2022-06-23 17:24:47.305045
# Unit test for function parse
def test_parse():
    ret = parse(text="""
        This is a test
        """
        )

# Generated at 2022-06-23 17:24:56.870362
# Unit test for function parse
def test_parse():
    docstring = """
    A short summary.

    A longer description.

    :param arg1: the first value
    :param arg2: the second value
    :returns: description of return value
    :raises keyError: description of exception
    """
    pds = parse(docstring)
    assert(pds.short_description == 'A short summary.')
    assert(pds.long_description == 'A longer description.')
    assert(pds.params['arg1'] == 'the first value')
    assert(pds.params['arg2'] == 'the second value')
    assert(pds.returns == 'description of return value')
    assert(pds.raises['keyError'] == 'description of exception')


# Generated at 2022-06-23 17:25:03.358193
# Unit test for function parse
def test_parse():
    text = '''
    A short summary.

    Optional longer description.

    :param arg1: Description of `arg1`.
    :type arg1: int
    :param arg2: Description of `arg2`.
    :type arg2: str
    :param arg3: Description of `arg3`.
    :type arg3: object
    :return: Description of `return` value.
    :rtype: object
    '''
    docstring = parse(text)
    assert docstring.short_description == 'A short summary.'
    assert docstring.long_description == 'Optional longer description.'
    assert len(docstring.params) == 3
    assert len(docstring.returns) == 1
    assert docstring.params[0].arg_name == 'arg1'

# Generated at 2022-06-23 17:25:14.400569
# Unit test for function parse
def test_parse():
    test_text = '''\
    This is a module level docstring
    
    This is the first line of the paragraph
      - This is the first item of the bullet list
      - This is the second item of the bullet list
      - This is the third item of the bullet list
          - This is the first item of the nested bullet list
              - This is the first item of the nested nested bullet list
        This is the first line of the paragraph
    
    
      - This is the first item of the bullet list
    
    
        This is the first line of the paragraph
    
    This is the first item of the bullet list
        This is the first line of the paragraph
    This is the third item of the bullet list
        - This is the first item of the nested bullet list
        - This is the second item of the nested bullet list
    '''
    #

# Generated at 2022-06-23 17:25:25.929844
# Unit test for function parse
def test_parse():
    # Just some simple test
    assert parse("Hello World") == Docstring(examples=[], params=[], returns=[], summary="Hello World", meta={})

    # Test if ParserError is correctly raised
    try:
        parse("")
    except ParseError:
        pass
    else:
        assert False

    # Test if the right docstring parser is used
    assert parse(".. note:: Note\n\n.. code-block:: py\n\n    print('Hello')", style=Style.sphinx)
    assert parse("+\nHello World\n+\n\nDescription", style=Style.numpy)
    assert parse("#####\nHello World\n#####", style=Style.google)

    # Test if the correct parser is used for automatic detection

# Generated at 2022-06-23 17:25:33.544680
# Unit test for function parse
def test_parse():
    text = """Summary line.

Description

Args:   path (str): path to file.
    
Returns:   str -- the read text.
"""
    expected_arg = [{'name':'path', 'type':'str', 'description':'path to file.'}]
    expected_return = [{'type':'str', 'description':'the read text.'}]
    ds = parse(text)
    assert ds.summary == 'Summary line.'
    assert ds.description == 'Description'
    assert ds.returns == expected_return
    assert ds.args == expected_arg


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:43.442088
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(
            summary="", description="", tags=[])
    assert parse("  \n   \t   \n") == Docstring(
            summary="", description="", tags=[])
    assert parse("summary.") == Docstring(
            summary="summary.", description="", tags=[])
    assert parse("summary.\ndescription.") == Docstring(
            summary="summary.", description="description.", tags=[])
    assert parse("summary.\n\n\ndescription.\n\n") == Docstring(
            summary="summary.", description="description.", tags=[])
    assert parse("summary.\n\n\ndescription.\n\n", style=Style.pep257) == Docstring(
            summary="summary.", description="description.", tags=[])

# Generated at 2022-06-23 17:25:51.356812
# Unit test for function parse
def test_parse():
    text = """First line
    Second line
    :return:
    """

    result = parse(text).__dict__
    expected = {'short_description': 'First line\nSecond line',
                'long_description': '',
                'meta': {'return': ''},
                'tags': {},
                'examples': [],
                'extended_sections': []}
    assert result == expected

# Generated at 2022-06-23 17:25:52.199686
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None

# Generated at 2022-06-23 17:25:54.262562
# Unit test for function parse
def test_parse():

    assert(parse("""
                 foo
                 """) ==
        Docstring(short_description='foo\n',
            long_description='',
            tags=None,
            epilog=None
        )
    )

# Generated at 2022-06-23 17:25:59.165007
# Unit test for function parse
def test_parse():
    text = """
    This is a test
    :param one: parameter one
    :return: nothing
    """
    assert (len(parse(text).params) == 1)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:26:04.007050
# Unit test for function parse
def test_parse():
    text = '''
'''
    assert parse(text, style=Style.numpy).summary.strip() == 'Unit test for function parse'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:26:06.565660
# Unit test for function parse
def test_parse():

    docstring = """Parse the docstring into its components.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
    """
    doc = parse(docstring, style=Style.google)
    print(doc)


# Generated at 2022-06-23 17:26:15.999054
# Unit test for function parse
def test_parse():
    docstr = """\
    This is a module-level docstring.
    """
    doc = parse(docstr)
    assert doc.short_description == "This is a module-level docstring."
    assert doc.long_description == ""
    assert not doc.params
    assert not doc.returns
    assert not doc.raises
    assert not doc.yields
    assert not doc.warns
    assert not doc.others
    assert doc.meta == {}
    assert not doc.newlines

    docstr = """\
    This is a module-level docstring.

    It can extend beyond one line.
    """
    doc = parse(docstr)
    assert doc.short_description == "This is a module-level docstring."
    assert doc.long_description == "It can extend beyond one line."
   

# Generated at 2022-06-23 17:26:27.145677
# Unit test for function parse
def test_parse():
    test_docstring = '''This is a test docstring

Args:
    arg1 (int): The first argument
    arg2 (int): The second argument

Returns:
    int: The return value.
'''
    parsed_docstring = parse(test_docstring, style=Style.google)
    assert(parsed_docstring.short_description == 'This is a test docstring')
    assert(parsed_docstring.long_description.strip() == '')
    assert(parsed_docstring.params['arg1'].arg_name == 'arg1')
    assert(parsed_docstring.params['arg1'].annotation == 'int')
    assert(parsed_docstring.params['arg2'].arg_name == 'arg2')