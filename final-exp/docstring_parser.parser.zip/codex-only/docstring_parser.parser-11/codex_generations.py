

# Generated at 2022-06-23 17:16:36.038437
# Unit test for function parse
def test_parse():
    docstring = parse("")
    assert docstring == Docstring("", "", [], [], [], [], {}, {}, "", "", "")
    
    docstring = parse("Hello, world!")
    assert docstring == Docstring("", "Hello, world!", [], [], [], [], {}, {}, "", "", "")
    
    docstring = parse("Hello, world!\nBlah blah.")
    assert docstring == Docstring("", "Hello, world!", [], [], [], [], {}, {}, "Blah blah.", "", "")
    
    docstring = parse("Hello, world!\n\nBlah blah.")
    assert docstring == Docstring("", "Hello, world!", [], [], [], [], {}, {}, "Blah blah.", "", "")

# Generated at 2022-06-23 17:16:45.231753
# Unit test for function parse
def test_parse():
    text= """
    This function we are testing
    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: The return value.
    :raises keyError: The exception type raised.
    """
    assert len(parse(text,Style.google)) == 5
    assert parse(text,Style.google).short_description == 'This function we are testing'
    assert len(parse(text,Style.google).params) == 2
    assert parse(text,Style.google).params.get('param1').description == 'The first parameter.'
    assert len(parse(text,Style.google).returns) == 1
    assert len(parse(text,Style.google).raises) == 1

# Generated at 2022-06-23 17:16:49.508976
# Unit test for function parse
def test_parse():
    doc_string = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    print(parse(doc_string))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:01.220303
# Unit test for function parse
def test_parse():
    docstring = parse("""\
        This is a docstring.

        :param str name: A positional argument.
        :arg str name: An optional argument.
        :param int num: An integer.
        :param bool flag: A boolean flag.
        :returns: What this function returns.
        :rtype: dict
        :raises ValueError: When something bad happens.
        """, style=Style.google)

    assert docstring.short_description == 'This is a docstring.'
    assert len(docstring.long_description) == 0

    assert len(docstring.arguments) == 2
    assert docstring.arguments[0] == ('name', 'A positional argument.', False)
    assert docstring.arguments[1] == ('name', 'An optional argument.', True)


# Generated at 2022-06-23 17:17:04.196712
# Unit test for function parse
def test_parse():
    from .examples import google as g, numpy as n
    for doc, style in g + n:
        assert parse(doc, style)

# Generated at 2022-06-23 17:17:11.088282
# Unit test for function parse
def test_parse():
    ds = """
author:
    - Christian S. Perone
website:
    - http://www.github.com/perone
"""
    parsed = parse(ds)
    assert(parsed.meta["author"] == ['- Christian S. Perone'])
    assert(parsed.meta["website"] == ['- http://www.github.com/perone'])
    assert(parsed.signature is None)
    assert(parsed.summary == "")
    assert(parsed.description == "")


# Generated at 2022-06-23 17:17:16.403990
# Unit test for function parse
def test_parse():
    s = '''
    aaa
    :param key1:
        value1
    :param key2:
        value2
    '''
    docstring = parse(s)
    assert docstring.meta['key1'].start_line == 3
    assert docstring.meta['key1'].end_line == 4


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:17:23.658466
# Unit test for function parse
def test_parse():
    """
    >>>docstring = parse("""

# Generated at 2022-06-23 17:17:34.314643
# Unit test for function parse
def test_parse():
    D = parse("title\n\nThis is a paragraph.\n")
    assert D.short_description == "title"
    assert D.long_description == "This is a paragraph.\n"
    D = parse("title   \n\nThis is a paragraph.\n")
    assert D.short_description == "title"
    assert D.long_description == "This is a paragraph.\n"
    D = parse("title\n\nThis is a paragraph.\n\nThis is the second paragraph.\n")
    assert D.short_description == "title"
    assert D.long_description == "This is a paragraph.\n\nThis is the second paragraph.\n"
    D = parse("title\n\nThis is a paragraph.\n\nSecond Paragraph\n")
    assert D.short

# Generated at 2022-06-23 17:17:37.993166
# Unit test for function parse
def test_parse():
    docstring = """\
    Example function with types documented in the docstring.

    :param param1: The first parameter.
    :type param1: int
    :param param2: The second parameter.
    :type param2: str, optional
    :returns: Description of return value.
    :rtype: int

    """
    print(parse(docstring))

# Generated at 2022-06-23 17:17:47.543606
# Unit test for function parse
def test_parse():
    # Test case
    text = "Test Parse\n Function Test"

    # Expected
    expected_text = "Test Parse\n Function Test"

    # Actual
    actual_text = parse(text)

    # Compare
    assert actual_text == expected_text

    # Test case
    text = "Test Parse\n Function Test"

    # Expected
    expected_text = "Test Parse Function Test"

    # Actual
    actual_text = parse(text, style = 'Google')

    # Compare
    assert actual_text == expected_text

    # Test case
    text = "Test Parse\n Function Test"

    # Expected
    expected_text = "Test Parse Function Test"

    # Actual
    actual_text = parse(text, style = 'Numpy')

    # Compare
    assert actual_

# Generated at 2022-06-23 17:17:51.576715
# Unit test for function parse
def test_parse():
    test_docstring = """
    This is a test docstring.
    It will be used for unit test.
    """
    assert parse(test_docstring).short_description == 'This is a test docstring.'

# Generated at 2022-06-23 17:17:56.912549
# Unit test for function parse
def test_parse():
    text = """A short description.
    
    A long description.
    
    :param name: description
    :param name2: description2
    :type name: string
    :type name: string
    """
    input = Docstring(description=("A short description.", "A long description."),
                      params=[("name", "description", "string"), ("name2", "description2", "string")])
    output = parse(text)
    assert input == output


# Generated at 2022-06-23 17:17:59.368054
# Unit test for function parse
def test_parse():
    function_parse = parse(text = "Hello world!")
    assert function_parse.short_description == "Hello world!"



# Generated at 2022-06-23 17:18:06.652784
# Unit test for function parse
def test_parse():
    """Test function parse."""
    docstring_1 = """Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    docstring_2 = """Parse the docstring into its components.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation

    """
    assert parse(docstring_2) == parse(docstring_1)
    print("test_parse passed!")

# Generated at 2022-06-23 17:18:17.480132
# Unit test for function parse
def test_parse():
    txt = """
    This is a sentence.
    A second sentence.

    :param arg1: description
    :type arg1: int
    :param arg2: description line 1
                  description line 2
    :type arg2: str
    :returns: description
    :rtype: float
    """
    docstring = parse(txt)
    assert docstring.summary == 'This is a sentence. A second sentence.'
    assert len(docstring.parameters) == 2
    for arg in docstring.parameters:
        if arg.arg_name == 'arg1':
            assert arg.arg_type == 'int'
            assert arg.description == 'description'
        elif arg.arg_name == 'arg2':
            assert arg.arg_type == 'str'

# Generated at 2022-06-23 17:18:24.621123
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring(summary='', description='',
        meta={}, tags={})
    assert parse('no description') == Docstring(summary='no description', description='',
        meta={}, tags={})
    assert parse('single line description') == Docstring(summary='', description='single line description',
        meta={}, tags={})
    assert parse('summary\n\nDescription') == Docstring(summary='summary', description='Description',
        meta={}, tags={})
    assert parse('summary\n\nDescription\n\nmeta') == Docstring(summary='summary', description='Description',
        meta={'meta':None}, tags={})
    assert parse('summary\n\nDescription\n\nmeta\n') == Docstring(summary='summary', description='Description',
        meta={'meta':None}, tags={})


# Generated at 2022-06-23 17:18:26.023360
# Unit test for function parse
def test_parse():
    text = """
    test
    """
    assert parse(text)

# Generated at 2022-06-23 17:18:28.411593
# Unit test for function parse
def test_parse():
    text = '''This is a test for docstring parser and there are multiple styles.
    '''
    doc = parse(text)
    print(doc)


# Generated at 2022-06-23 17:18:35.003939
# Unit test for function parse
def test_parse():
    docstring = """
    Short summary.

    Extended description.

    :param str param1: Parameter 1.
    :param int param2: Parameter 2.
    :return: Description of return value.
    :rtype: bool
    """

    pydocstyle = parse(docstring)
    numpy = parse(docstring, style=Style.numpy)

    assert pydocstyle.short_description == "Short summary."
    assert numpy.short_description == "Short summary."

    assert pydocstyle.long_description == "Extended description."
    assert numpy.long_description == "Extended description."

    assert pydocstyle.meta["param1"] == "Parameter 1."
    assert numpy.meta["param1"] == "Parameter 1."


# Generated at 2022-06-23 17:18:45.964191
# Unit test for function parse
def test_parse():
    def test(ds, style, s=None, i=None, r=None, e=None, c=None, o=None, a=None, m=None, labels=None, unknown=None):
        pds = parse(ds, style)
        assert pds.summary == s
        assert pds.index == i
        assert pds.returns == r
        assert pds.exceptions == e
        assert pds.context == c
        assert pds.other == o
        assert pds.author == a
        assert pds.meta == m
        assert pds.labels == labels or []
        assert pds.unknown == unknown or []

    test('', Style.google)
    test('test', Style.google, s='test')

# Generated at 2022-06-23 17:18:50.035418
# Unit test for function parse
def test_parse():
    text = '''"""
    This is a module.
    
    This module does stuff.
    """
    '''
    assert parse(text).short_description == "This is a module."
    
test_parse()

# Generated at 2022-06-23 17:18:56.308372
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    assert isinstance(parse('x'), Docstring)
    assert parse('x') == Docstring(description='x')


if __name__ == '__main__':
    text = '''
    Return the inverse of the argument.
    :param x: any object supporting numeric operators
    :returns: the inverse of x
    '''
    d = parse(text)
    print(d)

# Generated at 2022-06-23 17:18:57.770894
# Unit test for function parse
def test_parse():
    print(parse('""""\n'))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:09.972413
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, Section
    assert parse('this is a simple docstring') == Docstring(summary='this is a simple docstring')
    assert parse('this is a simple docstring with\nnewline') == Docstring(summary='this is a simple docstring with\nnewline')
    assert parse('this is a simple docstring\n\nwith\n\nnewlines\n\n') == Docstring(summary='this is a simple docstring', body='with\n\nnewlines')
    assert parse('this is a simple docstring\n\nwith\n\nnewlines\n\n and meta', style=Style.numpy) == Docstring(summary='this is a simple docstring', body='with\n\nnewlines', meta='and meta')

# Generated at 2022-06-23 17:19:13.391711
# Unit test for function parse
def test_parse():

    assert parse('this is a test')
    assert parse('this is a test', style=Style.google)

    try:
        parse('this is a test', style=Style.numpy)
        assert False
    except Exception:
        assert True

test_parse()

# Generated at 2022-06-23 17:19:17.217520
# Unit test for function parse
def test_parse():
    text = """
"""
    parsed_docstring = parse(text)


if __name__ == "__main__":
    test_parse()
    print("Docstring parsing [PASSED]")

# Generated at 2022-06-23 17:19:27.389186
# Unit test for function parse
def test_parse():
    from . import test_data_parser
    for func in dir(test_data_parser):
        if func.startswith("test_"):
            #print(func, getattr(test_data_parser, func)(), "\n")
            docstring = getattr(test_data_parser, func)()
            print("\n", func)
            print("Summary: ", docstring.short_description)
            print("Extended description: ", docstring.long_description)
            print("Raw meta: ", docstring.meta)
            print("Parsed meta: ", docstring.params)
            print("Returns: ", docstring.returns)
            print("Raises: ", docstring.raises)
            print("Yields: ", docstring.returns)

# Generated at 2022-06-23 17:19:30.502586
# Unit test for function parse
def test_parse():
    doctest = r"""
    """
    print(parse(doctest))

################################################################################

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:35.098545
# Unit test for function parse
def test_parse():
    ds = parse("""
    This is a docstring
    
    :param arg1: argument 1
    :param arg2: argument 2
    :returns: return values
    """)
    print(ds)
    return ds
    
ds = test_parse()
ds.summary


# Generated at 2022-06-23 17:19:38.072742
# Unit test for function parse
def test_parse():
    # test for parse function
    text_test = "this is a test for parse function"
    assert parse(text_test).text == text_test

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 17:19:44.709551
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Calculate the square numbers of the given values.

    Optional constant value to add.

    :param values: value list to be squared
    :param add: constant value to add
    :type values: list
    :type add: int
    :returns: squared and (optional) summed values
    :raises ValueError: if any value is not numerical
    """)

    assert docstring.short_description == "Calculate the square numbers of the given values."
    assert docstring.long_description == "Optional constant value to add."
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "values"
    assert docstring.params[0].description == "value list to be squared"
    assert docstring.params[0].type_name == "list"
   

# Generated at 2022-06-23 17:19:55.815321
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import STYLES
    from docstring_parser.styles.numpy import NumpyStyle
    from docstring_parser.styles.google import GoogleStyle
    from docstring_parser.docstring import parse
    docstring = parse('''
    Single line summary.
    Single line description.

    Extended description.
    Extended description continued.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    ''')
    assert isinstance(docstring, Docstring)
    assert docstring.style == Style.auto
    assert docstring.summary == 'Single line summary.'
    assert docstring.description == 'Single line description.'


# Generated at 2022-06-23 17:20:07.163243
# Unit test for function parse
def test_parse():
    text = """One line summary.

    Extended description.

    :param arg1: description of arg1
    :param arg2: description of arg2
    :type arg1: int, float,...
    :type arg2: str
    :returns: description of return value
    :rtype: int, float,...

    """

    # parse docstring into a Docstring object
    docstring = parse(text, Style.pep257)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta['arg1'])
    print(docstring.meta['arg2'])
    print(docstring.meta['returns'])
    print(docstring.meta['rtype'])

    # convert Docstring object back to docstring
    print(docstring)

test_

# Generated at 2022-06-23 17:20:08.634115
# Unit test for function parse
def test_parse():
    """ test_parse()
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:20:10.044702
# Unit test for function parse
def test_parse():
    assert True


# Generated at 2022-06-23 17:20:14.215995
# Unit test for function parse
def test_parse():
    text = """
    @param: text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    style: Style = Style.auto
    print(parse(text, style))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:20:17.923010
# Unit test for function parse
def test_parse():
    """Test case.
    """
    text = "A test docstring."
    assert parse(text, style=Style.numpy).meta["Summary"] == text
    assert parse(text, style=Style.google).meta["Summary"] == text
    assert parse(text, style=Style.napoleon).meta["Summary"] == text

# Generated at 2022-06-23 17:20:25.884751
# Unit test for function parse
def test_parse():
    test_cases = """
    def test_parse():
    \"\"\"Test function for function parse.
    :param test_cases: docstring text to parse
    :returns: parsed docstring representation
    \"\"\"
    """
    assert parse(test_cases).short_description == 'Test function for function parse.'
    assert parse(test_cases).long_description == ''
    assert parse(test_cases).meta['param'] == 'test_cases'
    assert parse(test_cases).meta['return'] == 'parsed docstring representation'


# Generated at 2022-06-23 17:20:29.848107
# Unit test for function parse
def test_parse():
    print(parse('hello, world!'))
    print(parse('hello, world!'))
    print(parse('hello, world!'))
    print(parse('hello, world!'))

#if __name__ == '__main__':
#    test_parse()

# Generated at 2022-06-23 17:20:33.721125
# Unit test for function parse
def test_parse():
    assert parse("\n   ") == Docstring()
    assert parse("") == Docstring()

    docstring = Docstring(meta=[('section', 'A section'),
                                ('section', 'Another section')],
                         returns='A return statement.',
                         raises='A raise statement.',
                         effects='A side effect statement.',
                         misc=[('misc_key', 'misc_value')])

    assert parse(
        ' :section: A section\n   :section: Another section\n'
        ' :returns: A return statement.\n   :raises: A raise statement.\n'
        ' :effects: A side effect statement.\n   :misc_key: misc_value') == docstring



# Generated at 2022-06-23 17:20:40.982202
# Unit test for function parse
def test_parse():
    args = parse('''
    Test for parsing a docstring with different styles.

    Args:
        arg1(str): the first argument
        arg2(int): the second argument

    Returns:
        int: return value
    ''')
    assert args.arguments == [
        {'name': 'arg1', 'annotation': 'str', 'description': 'the first argument'},
        {'name': 'arg2', 'annotation': 'int', 'description': 'the second argument'}
    ]
    assert args.return_annotation == 'int'
    assert args.return_description == 'return value'

# Generated at 2022-06-23 17:20:48.494786
# Unit test for function parse
def test_parse():
	s = """
		This is the first line of the docstring
		This is the second line of the docstring
		This is the third line of the docstring
	"""
	obj = parse(s)
	assert obj.short_description == 'This is the first line of the docstring'
	assert obj.long_description == '\nThis is the second line of the docstring\nThis is the third line of the docstring\n'

# Generated at 2022-06-23 17:20:56.161643
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    text = '''
"""The module docstring of module ``module_name``.

This module is designed to test main parsing routine.

""""""

Another paragraph with no meta data.

:param args: the arguments
:param kwargs: the keyword arguments
:returns: something
"""
    '''
    style = Style.numpy
    ds = parse(text, style)
    assert(len(ds.meta['args']) == 2)
    assert(ds.meta['returns'] == 'something')
    assert(len(ds.sections) == 1)

# Generated at 2022-06-23 17:21:03.585631
# Unit test for function parse
def test_parse():
    text = '''
    Hello world

    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    ret = parse(text)
    assert ret.short_description == 'Hello world'
    assert ret.long_description == 'Parse the docstring into its components.'
    assert len(ret.params) == 2
    assert len(ret.returns) == 1
    assert len(ret.meta) == 0


# Generated at 2022-06-23 17:21:08.651723
# Unit test for function parse
def test_parse():
    
    text = "This document describes the function 'f'\r \n\r \nArgs:\r \n    a : int\r \n    b : int\r \n\r \nReturns:\r \n    int\r \n    int\r \n\r \nRaises:\r \n    ValueError if a < 0\r \n    TypeError if b is not an integer"

    # Test parse without style argument
    doc = parse(text)
    assert doc.description == "This document describes the function 'f'\n\n"
    assert doc.meta == {'Args': [['a', ':', 'int'], ['b', ':', 'int']], 'Returns': [['int'], ['int']], 'Raises': ['ValueError if a < 0', 'TypeError if b is not an integer']}

# Generated at 2022-06-23 17:21:09.765745
# Unit test for function parse

# Generated at 2022-06-23 17:21:17.615090
# Unit test for function parse
def test_parse():
    docstring = """Test parse function

    :param arg1: The first argument
    :type arg1: str
    :returns: None
    """
    s = parse(docstring)
    assert s.short_description == "Test parse function"
    assert not s.long_description
    assert s.returns.type == "None"
    assert isinstance(s.params, list)
    assert s.params[0].arg_name == "arg1"
    assert s.params[0].type == "str"
    assert s.params[0].description == "The first argument"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:21:21.667855
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = "test"
    ret = parse(text, Style.pep257)
    assert type(ret) == Docstring
    ret = parse(text, Style.auto)
    assert type(ret) == Docstring

# Generated at 2022-06-23 17:21:29.050144
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", meta={})
    assert parse("Summary") == Docstring(summary="Summary", description="", meta={})
    assert parse("Summary\n") == Docstring(summary="Summary\n", description="", meta={})
    assert parse("Summary\n\n") == Docstring(summary="Summary", description="", meta={})
    assert parse("Summary\n\nDescription") == Docstring(summary="Summary", description="Description", meta={})
    assert parse("Summary\n\nDescription\n\n") == Docstring(summary="Summary", description="Description", meta={})
    assert parse("Summary\n\nMeta: Meta") == Docstring(summary="Summary", description="", meta={"Meta": "Meta"})

# Generated at 2022-06-23 17:21:31.940707
# Unit test for function parse
def test_parse():
    text="""This is a test
    :param test_param: This is test_param.
    :returns: This is return.
    """
    parse(text)

# Generated at 2022-06-23 17:21:40.028675
# Unit test for function parse
def test_parse():
    assert parse('Test') == Docstring(text='Test')
    assert parse('Test', Style.auto).style == Style.sphinx
    assert parse('Test', Style.sphinx) == Docstring(text='Test')
    assert parse('Test', Style.google) == Docstring(text='Test')
    assert parse('Test', Style.numpydoc) == Docstring(text='Test')
    assert parse('Test', Style.gas) == Docstring(text='Test')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:21:47.055343
# Unit test for function parse
def test_parse():
    text = """\
    :param foo: first param
    :keyword bar: second param
    :type foo: list
    :type bar: str
    :returns: None
    :rtype: None
    """
    parsed = parse(text)
    assert isinstance(parsed.params, list)
    assert isinstance(parsed.keywords, list)
    assert isinstance(parsed.returns, dict)
    assert parsed.returns['desc'] == ''
    assert parsed.returns['type'] == 'None'

# Generated at 2022-06-23 17:21:57.557494
# Unit test for function parse
def test_parse():
    # Example docstrings
    google_docstring = '''Args:
    arg1: int - The id of the user.
    arg2: str - The name of the user.
    '''
    numpy_docstring = '''Parameters
    ----------
    arg1: int
        The id of the user.
    arg2: str
        The name of the user.
    '''
    reStructuredText_docstring = ''':param arg1: int
    The id of the user.
    :param arg2: str
    The name of the user.
    '''
    # Testing
    assert parse(google_docstring, style=Style.google) == parse(google_docstring, style=Style.auto)

# Generated at 2022-06-23 17:22:05.975825
# Unit test for function parse
def test_parse():
    doc = parse("""
        This is a simple docstring to test the basic
        functionality of the library.

        :param int a: variable a
        :param str b: variable b
        :returns: 1
        :raises: ArithmeticError, KeyError
        """)

    assert doc
    assert len(doc.summary.split()) > 1
    for p in doc.params:
        assert p.name
        assert p.type
        assert p.desc
    assert len(doc.raises) == 2
    assert doc.returns
    assert doc.returns.desc


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:16.625841
# Unit test for function parse
def test_parse():
    from pytest import raises
    from docstring_parser.styles.restructuredtext import parse as parse_rst

    doc = """
        Single line summary

        First line of description

        Second line of description

        Args:
            arg1 (type1): Description of arg1
            arg2 (type2): Description of arg2

        Returns:
            Description of return value of this function
        """
    docstring = parse(doc)
    assert docstring.short_description == 'Single line summary'
    assert docstring.long_description == 'First line of description\nSecond line of description'
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert len(docstring.returns) == 1

# Generated at 2022-06-23 17:22:24.112112
# Unit test for function parse
def test_parse():
    """Setup the test cases.

    :returns: None
    """
    assert parse('This is a test')
    assert parse('This is a test', Style.google)
    assert parse('This is a test', Style.numpy)
    assert parse('This is a test', Style.pep257)
    assert parse('This is a test', Style.pep8)
    try:
        assert parse('This is a test', 'not a real style')
    except ParseError as e:
        assert e.args[0] == "Invalid style: not a real style"
    try:
        assert parse('no docstring at all')
    except ParseError as e:
        assert e.args[0] == "No docstring found"

# Generated at 2022-06-23 17:22:35.309956
# Unit test for function parse
def test_parse():
    """Test parse function output against expected output."""

    from docstring_parser.regexes import guess_style
    from docstring_parser.common import Section

    # Test for docstring with no field
    parse_result = parse(text='')
    expected_result = Docstring(summary="", body="", style=guess_style(''),
                                is_init=False, meta={})
    assert parse_result == expected_result

    # Test for a docstring with one section
    parse_result = parse(text='''
This is a docstring.
    ''')
    assert parse_result.summary == 'This is a docstring.'
    assert parse_result.body == ''
    assert parse_result.style == guess_style('''This is a docstring.
    ''')

# Generated at 2022-06-23 17:22:41.874217
# Unit test for function parse
def test_parse():
    assert parse(
        '''\
title
---

Args:
  arg1: First argument.
Return:
  Return value.
'''
    ).meta == {
        'title': 'title',
        'args': [
            ('arg1', 'First argument.')
        ],
        'return': 'Return value.'
    }
    assert parse(
        '''\
Args:
    arg1: First argument.
Return:
    Return value.
'''
    ).meta == {
        'args': [
            ('arg1', 'First argument.')
        ],
        'return': 'Return value.'
    }

# Generated at 2022-06-23 17:22:50.052475
# Unit test for function parse
def test_parse():
    assert parse("") == parse("", style = "google")
    assert parse("") == parse("", style = "numpydoc")
    assert parse("") == parse("", style = "sphinx")
    assert parse("") == parse("", style = "reST")
    assert (
        parse("abc")
        == parse("abc", style = "google")
        == parse("abc", style = "numpydoc")
        == parse("abc", style = "sphinx")
        == parse("abc", style = "reST")
    )
    assert parse("\n\n") == parse("\n\n", style = "reST")
    assert parse("\n\n") == parse("\n\n", style = "reST")

# Generated at 2022-06-23 17:22:54.851438
# Unit test for function parse
def test_parse():
    # init
    s = '''
        title: Documentation string.
        summary: short summary.
        '''
    style = Style.google
    # function call
    result = parse(s, style)
    # test conditions
    assert(result.summary == 'short summary.')
    assert(result.title == 'Documentation string.')

# Generated at 2022-06-23 17:23:01.047445
# Unit test for function parse
def test_parse():
    text = """One line summary.

Extended description.

:param arg1: The first argument.
:param arg2: The second argument.
:returns: Description of return value.
:raises keyError: Raises an exception.
    """
    out = parse(text)
    assert out.short_description == "One line summary."
    assert out.long_description == "Extended description."
    assert out.returns == "Description of return value."
    assert out.raises == "Raises an exception."
    assert out.params == {
        'arg1': 'The first argument.',
        'arg2': 'The second argument.'
    }
    assert out.meta == {'keyError': 'Raises an exception.'}



# Generated at 2022-06-23 17:23:10.188178
# Unit test for function parse
def test_parse():
    text = """Name.

    Short summary.

    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`

    Returns:
        list: Description of return value
    """
    text_list = text.split("\n")
    docstring = parse(text)
    assert docstring.short_description == text_list[1].strip()
    assert docstring.long_description == text_list[3].strip()
    assert docstring.meta['Args'][0].arg_name == 'arg1'
    assert docstring.meta['Args'][0].arg_type == 'int'
    assert docstring.meta['Args'][0].description == 'Description of `arg1`'

# Generated at 2022-06-23 17:23:12.608744
# Unit test for function parse
def test_parse():
    text = """
        This is a docstring
        Which contains 4 lines
        And this is the 4th line
        """
    assert parse(text)

# Generated at 2022-06-23 17:23:20.511580
# Unit test for function parse

# Generated at 2022-06-23 17:23:31.551224
# Unit test for function parse

# Generated at 2022-06-23 17:23:38.863208
# Unit test for function parse
def test_parse():
    text = """
        Title

        :param str arg1: The first argument
        :param str arg2: The second argument
        :returns: None

        """
    docstring = parse(text)
    assert docstring.description == "Title"
    assert docstring.params[0].name == "arg1"
    assert docstring.params[0].type == "str"
    assert docstring.params[0].description == "The first argument"
    assert docstring.params[1].name == "arg2"
    assert docstring.params[1].type == "str"
    assert docstring.params[1].description == "The second argument"
    assert docstring.returns.type == "None"
    assert docstring.returns.description == ""

# Generated at 2022-06-23 17:23:44.700646
# Unit test for function parse
def test_parse():

    text = """\
        This is the first line of the docstring. Next line is part of the
        docstring too. But not this one.

        :param name: name of the person
        :type name: str
        :param age: age of the person
        :type age: int
        :returns: this is what returns
        :rtype: str
        :raises TypeError: if the parameter is not a str
        """

# Generated at 2022-06-23 17:23:55.992028
# Unit test for function parse

# Generated at 2022-06-23 17:24:06.645536
# Unit test for function parse
def test_parse():
    text = """
        A docstring.

        :param int a: first param name
        :param int b: second param name
        :returns: description
        :raises ValueError: if something bad happens
    """
    d = parse(text)
    assert d.short_description == "A docstring."
    assert d.long_description == ""
    assert d.params[0].arg_name == "a"
    assert d.params[1].arg_name == "b"
    assert d.params[0].description == "first param name"
    assert d.params[1].description == "second param name"
    assert d.returns.description == "description"
    assert d.raises[0].type_name == "ValueError"
    assert d.raises[0].description == "if something bad happens"

# Generated at 2022-06-23 17:24:16.373604
# Unit test for function parse
def test_parse():
    text = """\
Returns:
    int: The answer
"""
    res = parse(text, style=Style.numpy)
    assert res.returns[0].type_name == "int"
    assert res.returns[0].description == "The answer"

    res = parse(text, style=Style.google)
    assert res.returns[0].type_name == "int"
    assert res.returns[0].description == "The answer"

    res = parse(text, style=Style.auto)
    assert res.returns[0].type_name == "int"
    assert res.returns[0].description == "The answer"

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:27.187711
# Unit test for function parse
def test_parse():
    text = """Finds the shortest path between nodes in a graph by breadth first search.

    Returns the list of nodes visited.

    :param graph: The graph to search.
    :param source: The node to start from.
    :param target: (Optional.) The node to stop at, or None if the path
      should continue to the end.
    :param ignore: (Optional.) An iterable of nodes that should be ignored.
    :returns: A list of nodes visited, in order.
    """


# Generated at 2022-06-23 17:24:37.446895
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.

    :param x: a number
    :returns: the square of the number
    '''
    d = parse(text)
    assert d.summary == 'This is a docstring.'
    assert d.meta['param'][0].name == 'x'
    assert d.meta['param'][0].description == 'a number'
    assert d.meta['returns'][0].description == 'the square of the number'

    text = '''
    This is a docstring.

    :param x: a number
    :return: the square of the number
    '''
    d = parse(text)
    assert d.summary == 'This is a docstring.'
    assert d.meta['param'][0].name == 'x'

# Generated at 2022-06-23 17:24:40.291603
# Unit test for function parse
def test_parse():
    text = """
    hello world
    """
    print(parse(text))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:46.489081
# Unit test for function parse
def test_parse():
    assert parse("this is a test")
    assert parse("this is a test", style=Style.auto)
    assert parse("this is a test", style=Style.google)
    assert parse("this is a test", style=Style.numpy)
    assert parse("this is a test", style=Style.reST)
    assert parse("this is a test", style=Style.sphinx)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:55.044853
# Unit test for function parse
def test_parse():
    import unittest
    class Test_Docstring_Parser(unittest.TestCase):
        def test_parse(self):
            ds = parse('This is a docstring')
            self.assertEqual(ds.short_description, 'This is a docstring')
            self.assertEqual(ds.long_description, '')
            self.assertEqual(ds.body, '')
            self.assertEqual(ds.table, None)
            self.assertEqual(ds.returns, None)
            self.assertEqual(ds.meta, {})
    unittest.main()

# Generated at 2022-06-23 17:24:56.666240
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:25:03.230558
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle
    from docstring_parser.styles import GoogleStyle
    lines = ['Summary.', '', 'Args:', '  arg1 (int): Description.', '  arg2 (str): Description.', '', 'Returns:', '  int: Description.']
    text = '\n'.join(lines)
    assert parse(text, style=NumpyStyle) == parse(text, style=GoogleStyle)
    assert parse(text, style=GoogleStyle) == parse(text, style=NumpyStyle)
    assert text in parse(text, style=GoogleStyle).to_str()
    assert text in parse(text, style=NumpyStyle).to_str()


# Generated at 2022-06-23 17:25:06.603269
# Unit test for function parse
def test_parse():
    text = "Hello, this is my docstring. Can you parse it?"
    assert text == parse(text).text
    print("function parse is verified.")

test_parse()

# Generated at 2022-06-23 17:25:16.988055
# Unit test for function parse
def test_parse():
    """Test the function parse"""
    assert parse('''\
        """This is a sentence."""''') == Docstring(summary='This is a sentence.')
    # Test docstring with newline
    assert parse('''\
        """This is a sentence.
        """''') == Docstring(summary='This is a sentence.')
    # Test docstring with many newlines
    assert parse('''\
        """This is a
        sentence.
        """''') == Docstring(summary='This is a\nsentence.')
    # Test docstring with many newlines and indentation
    assert parse('''\
        """This is a
          sentence.
        """''') == Docstring(summary='This is a\n  sentence.')
    # Test docstring with parameters

# Generated at 2022-06-23 17:25:27.930290
# Unit test for function parse
def test_parse():
    docstring = """Function to multiply 2 numbers
    :param a: first number
    :param b: second number
    :returns: multiplication of two numbers
    """
    try:
        parse(docstring)
        assert(True)
    except ParseError:
        assert(False)
    docstring = """Function to multiply 2 numbers
    :param a: first number
    :param b: second number
    """
    try:
        parse(docstring)
        assert(True)
    except ParseError:
        assert(False)
    docstring = """Function to multiply 2 numbers
    """
    try:
        parse(docstring)
        assert(True)
    except ParseError:
        assert(False)


# Generated at 2022-06-23 17:25:28.888295
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:25:30.295260
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:25:40.167536
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError, NAPALM_HEADER
    from docstring_parser.styles import STYLES
    assert parse('""" Short"""') == Docstring(description=' Short', meta={})
    assert parse('"""Short"""') == Docstring(description='Short', meta={})
    assert parse('r"""Short"""') == Docstring(description='Short', meta={})
    assert parse('"""\nShort"""') == Docstring(description='\nShort', meta={})
    assert parse('"""\n\nShort\n\n"""') == \
            Docstring(description='\n\nShort\n\n', meta={})

    assert parse('"""\n\nShort\n\n"""', style=Style.google).short_description == \
            'Short'


# Generated at 2022-06-23 17:25:43.353604
# Unit test for function parse
def test_parse():
    assert parse("""Arguments:
    arg1: Tom
    arg2: New York
Returns:
    str: The person and city
""").as_kwargs() == {
                'arguments': {'arg1': 'Tom', 'arg2': 'New York'},
                'returns': 'str: The person and city'
            }

# Generated at 2022-06-23 17:25:46.107492
# Unit test for function parse
def test_parse():
    text = '''
    Simple test paragraph

    Extra line
    '''
    assert parse(text).short_description == "Simple test paragraph"


__all__ = ['parse']

# Generated at 2022-06-23 17:25:49.412608
# Unit test for function parse
def test_parse():
    pass



# Generated at 2022-06-23 17:25:56.802302
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    assert parse("") == Docstring()
    assert parse("This is just a string.") == Docstring(content="This is just a string.")
    assert parse("Another string.") == Docstring(content="Another string.")
    assert parse("\nA first paragraph.\n\nA second paragraph.") == Docstring(content="\nA first paragraph.\n\nA second paragraph.")
    assert parse("\na\n\n\n\nb\n\n") == Docstring(content="a\n\n\nb")
    assert parse("This is a string with a @param.") == Docstring(content="This is a string with a @param.")

# Generated at 2022-06-23 17:26:04.815213
# Unit test for function parse
def test_parse():
    text = """First sentence.

    Second sentence.
    Third sentence.
    """
    assert parse('First sentence.') == Docstring(first_sentence = 'First sentence.', description = ['First sentence.'], meta = {}, examples = [])
    assert parse(text) == Docstring(first_sentence = 'First sentence.', description = ['First sentence.', 'Second sentence.', 'Third sentence.'], meta = {}, examples = [])
    assert parse('First sentence.\n\nSecond sentence.') == Docstring(first_sentence = 'First sentence.', description = ['First sentence.', 'Second sentence.'], meta = {}, examples = [])

# Generated at 2022-06-23 17:26:06.702444
# Unit test for function parse
def test_parse():
    text = ':param name: Full Name of person.\n'
    style = Style.google
    assert parse(text, style)

# Generated at 2022-06-23 17:26:13.916359
# Unit test for function parse
def test_parse():
    text = """This is a summary.

    This is a description.

    :param arg1: A description for arg1
    :param arg2: A description for arg2

    :return: A description for return"""
    docstring = parse(text)
    assert docstring.summary == "This is a summary."
    assert docstring.description == "This is a description."
    assert docstring.meta['arg1'] == "A description for arg1"
    assert docstring.meta['arg2'] == "A description for arg2"
    assert docstring.meta['return'] == "A description for return"

# Generated at 2022-06-23 17:26:20.186063
# Unit test for function parse
def test_parse():
    test_docstring = '''
    Summary line.
    Extended description.
        - Bullet points are okay.
        - Typically a hyphen or asterisk is used.
    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
    Returns:
        bool: True if successful, False otherwise.
    '''
    assert parse(test_docstring).__dict__ == {'summary': 'Summary line.', 'extended_summary': 'Extended description.\n    - Bullet points are okay.\n    - Typically a hyphen or asterisk is used.', 'extended_description': '', 'meta': {'Args': ['arg1 (int): Description of arg1', 'arg2 (str): Description of arg2'], 'Returns': ['bool: True if successful, False otherwise.']}}



# Generated at 2022-06-23 17:26:32.062249
# Unit test for function parse