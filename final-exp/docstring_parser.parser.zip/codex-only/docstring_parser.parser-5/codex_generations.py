

# Generated at 2022-06-23 17:16:30.751144
# Unit test for function parse
def test_parse():
    text = """@param x: a number
    @param y: another number
    """
    style = Style.google

    docstring = parse(text, style)
    assert docstring.params[0].name == "x:"
    assert docstring.params[0].description == "a number"
    assert docstring.params[1].name == "y:"
    assert docstring.params[1].description == "another number"

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:16:36.915445
# Unit test for function parse
def test_parse():

    style = "google"
    s = """
Solve the coupled ODE system

.. math::
   \\ddot{x} + x = 0
   \\ddot{y} + y = 0

:param numpy.array t: time steps
:param numpy.array x: state vector of size (2,)
:returns numpy.array x: solution for time steps `t`
    """
    docstring = parse(s, style)
    print(docstring)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:16:38.328878
# Unit test for function parse
def test_parse():
	assert parse("") == parse("", Style.Google) == Docstring()

# Generated at 2022-06-23 17:16:46.938203
# Unit test for function parse
def test_parse():
    test_docstring = '''
        This is an example docstring.

        This is a multi-line description

        :param param1: this is a parameter
        :param param2: this is a parameter
        :return: this is a return

        :raises type1: if something
        :raises type2: if something else
        '''
    docstring = parse(test_docstring, style=Style.numpy)
    assert docstring.short_description == 'This is an example docstring.'
    assert docstring.long_description == 'This is a multi-line description'
    assert docstring.params == [
        ('param1', 'this is a parameter'),
        ('param2', 'this is a parameter')
    ]
    assert docstring.returns == 'this is a return'

# Generated at 2022-06-23 17:16:54.308951
# Unit test for function parse
def test_parse():
    docstring = """
    Summarize the Docstring_parser module.
    Extendend summary.

    This module provides a simple way of parsing numpy style and google style
    docstrings.

    Parameters
    ----------
    text : str
        Docstring text to parse
    style : str
        Docstring style, 'numpy' or 'google', default is 'numpy'

    Returns
    -------
    docstring : :class:`Docstring`
        Parsed docstring representation
    """
    print(parse(docstring))

# Generated at 2022-06-23 17:17:01.389824
# Unit test for function parse
def test_parse():
    """
    Test parse function
    """
    text = """A short summary.
    This is the first line of a description.

    This is the second line of a description.
    """
    nptext = """A short summary.
    This is the first line of a description.

    This is the second line of a description.
    """
    style = Style.google
    result = parse (text, style)
    #print(result)
    assert result == parse(nptext, style)
    #assert result == parse(nptext, style)


# Generated at 2022-06-23 17:17:07.237088
# Unit test for function parse
def test_parse():
    assert parse("Parse a docstring into its components.") == {
        'summary': 'Parse a docstring into its components.',
        'description': '',
        'meta': {},
        'parameters': [],
        'returns': None,
        'raises': [],
        'yields': None,
        'other': []
    }

# Generated at 2022-06-23 17:17:17.937303
# Unit test for function parse
def test_parse():

    # test multi-line docstring
    docstring = """Function that computes the area of circles.
    This function takes a radius as input, and returns the area
    of the circle with that radius.
    :param radius: radius of the circle
    :return: area of the circle
    """
    doc = parse(docstring)
    assert(doc.short_description == "Function that computes the area of circles.")
    assert(doc.long_description == 'This function takes a radius as input, and returns the area\nof the circle with that radius.')
    assert(len(doc.params) == 1)
    assert(doc.params[0].arg_name == 'radius')
    assert(doc.params[0].description == 'radius of the circle')
    assert(len(doc.returns) == 1)

# Generated at 2022-06-23 17:17:29.331025
# Unit test for function parse

# Generated at 2022-06-23 17:17:38.334684
# Unit test for function parse
def test_parse():
    text = """
    Type: function

    Summary line.

    Description of what the function does.

    Args:
        arg1 (str): Description of arg1
        arg2 (Optional[str]): Description of arg2
    """
    docstring = parse(text)
    print(docstring.summary)
    print(docstring.description)
    print(docstring.returns)
    print(docstring.type)
    print(docstring.meta['Args'][0].arg_name)
    print(docstring.meta['Args'][1].arg_name)
    print(docstring.meta['Args'][0].arg_type)
    print(docstring.meta['Args'][1].arg_type)
    print(docstring.meta['Args'][0].description)

# Generated at 2022-06-23 17:17:45.012245
# Unit test for function parse
def test_parse():
    text = """
This is an example docstring, with a function and a string

Args:
    word: word to say
    times (int): optional number of times to say it
"""
    # Style
    style = Style.google
    docstring = parse(text, style=style)
    assert docstring.short_description == "This is an example docstring, with a function and a string"
    assert docstring.style == style


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:17:48.674904
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    df = open('./docstring.txt')
    try:
        text = df.read()
    finally:
        df.close()
    print(parse(text))

# Generated at 2022-06-23 17:17:58.701220
# Unit test for function parse
def test_parse():
    docstring = """
    A first sentence.

    A longer description.

    :param arg1: Description of arg1
    :param arg2: Description of arg2
    :type arg1: str
    :type arg2: int
    :returns: Description of the return value
    :raises Exception1: Description of exception1
    :raises Exception2: Description of exception2

    :Example:

    >>> my_function('test') #doctest: +ELLIPSIS
    <...>
    """
    parsed = parse(docstring)
    assert parsed.short_description == 'A first sentence.'
    assert parsed.long_description == 'A longer description.'
    assert parsed.params['arg1'].arg_type == 'str'
    assert parsed.params['arg1'].description == 'Description of arg1'
    assert parsed

# Generated at 2022-06-23 17:18:09.459392
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    from docstring_parser.styles.sphinx import GoogleStyle, NumpyStyle
    assert parse("") == Docstring()
    assert parse("one") == Docstring(content="one")
    assert parse("one\ntwo") == Docstring(content="one\ntwo")
    assert parse("one\n\ntwo") == Docstring(content="one\n\ntwo")
    assert parse("one\n    two") == Docstring(content="one\n    two")
    assert parse("one\n\n    two") == Docstring(content="one\n    two")
    assert parse("one\n    two\n    three") == Docstring(
        content="one\n    two\n    three"
    )

# Generated at 2022-06-23 17:18:13.110361
# Unit test for function parse
def test_parse():
    docstring = '''
    Basic function.
    More description.
    '''
    doc = parse(docstring)
    assert doc.short_description == 'Basic function.'
    assert doc.long_description == 'More description.'



# Generated at 2022-06-23 17:18:21.773046
# Unit test for function parse
def test_parse():
    d1 = parse('Test docstring')
    assert d1.meta == {}, d1.meta
    assert d1.summary == 'Test docstring', d1.summary
    assert d1.body == '', d1.body
    d2 = parse('Test docstring with some explanation')
    assert d2.meta == {}, d2.meta
    assert d2.summary == 'Test docstring', d2.summary
    assert d2.body == 'with some explanation', d2.body
    d3 = parse('Test docstring\nwith some explanation')
    assert d3.meta == {}, d3.meta
    assert d3.summary == 'Test docstring', d3.summary
    assert d3.body == 'with some explanation', d3.body
    d4 = parse('\nTest docstring\nwith some explanation')

# Generated at 2022-06-23 17:18:32.439403
# Unit test for function parse
def test_parse():
    doc = '''
        :param param1: The first parameter.

        :type param1: str
        :param param2: The second parameter.
        :type param2: int, optional
        :returns: Description of return value
        :rtype: int
        '''
    docstring = parse(doc)
    assert docstring.short_description == ""
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "param1"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "The first parameter."
    assert docstring.params[1].arg_name == "param2"

# Generated at 2022-06-23 17:18:36.028076
# Unit test for function parse
def test_parse():
    text = """
    This is a sentence.
    """
    d = parse(text)
    assert d.short_description == "This is a sentence."


# Generated at 2022-06-23 17:18:43.956156
# Unit test for function parse
def test_parse():

    assert parse('simple docstring with nothing') == parse('simple docstring with nothing', Style.google)

    assert parse('') == parse('', Style.google)

    # should return default strings from the parse method
    assert parse('\n') == parse('\n', Style.google)

    #return parsed list
    assert parse('Args:\n  param1: test_param1\n  param2: test_param2\n') == parse('Args:\n  param1: test_param1\n  param2: test_param2\n', Style.google)

# Generated at 2022-06-23 17:18:54.566741
# Unit test for function parse
def test_parse():
    """Test Module parse."""
    doc ="""Single-line docstring."""
    assert parse(doc) is not None
    assert parse(doc).summary == 'Single-line docstring.'
    doc = """
    Single-line docstring summarized by the first line.
    """
    assert parse(doc) is not None
    assert parse(doc).summary == 'Single-line docstring summarized by the first line.'
    doc = """
    Summary

    Extended description.

    """
    assert parse(doc) is not None
    assert parse(doc).summary == 'Summary'
    assert parse(doc).description == '\nExtended description.\n\n'

# Generated at 2022-06-23 17:18:56.390910
# Unit test for function parse
def test_parse():
    docstring = parse('Computes the gradient of a scalar function.')
    return docstring

# Generated at 2022-06-23 17:19:06.711437
# Unit test for function parse
def test_parse():
    """Test parse function."""
    print("Test parse function")

    test_docstrings = [
        """Module docstring"""
    ]

    for test_docstring in test_docstrings:
        print("Test docstring:\n", test_docstring)
        parsed_docstring = parse(test_docstring)
        print("Parsed docstring:\n", parsed_docstring)
        try:
            assert parsed_docstring.short_description == "Module docstring"
        except:
            print("Parsed docstring doesn't match.")
        else:
            print("Parsed docstring matched.")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:16.077940
# Unit test for function parse
def test_parse():
    text = '''
Examples
--------

>>> import numpy as np
>>> from sklearn import neighbors
>>> from sklearn import datasets
>>> iris = datasets.load_iris()
>>> X, y = iris.data[:, :2], iris.target
>>> knn = neighbors.KNeighborsClassifier(n_neighbors=5)
>>> knn.fit(X, y)
KNeighborsClassifier(...)
>>> y_pred = knn.predict(X)
>>> knn.score(X, y)
0.9
    '''


# Generated at 2022-06-23 17:19:17.602943
# Unit test for function parse
def test_parse():
    ret = parse('''
        docstring
    ''')
    assert ret.short_description == 'docstring'

# Generated at 2022-06-23 17:19:27.965273
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    Just for test purpose.

    :param a: a param
    :param b: another param
    :returns: something
    :raises Exception: when an error occurs
    """
    docstring = parse(text, style=Style.google)
    assert docstring.short_description == 'This is a test docstring.'
    assert len(docstring.long_description) == 1
    assert docstring.long_description[0] == 'Just for test purpose.'
    assert len(docstring.params) == 2
    assert docstring.params['a'].arg_type == 'param'
    assert docstring.params['a'].arg_name == 'a'
    assert docstring.params['a'].description == 'a param'

# Generated at 2022-06-23 17:19:38.220159
# Unit test for function parse

# Generated at 2022-06-23 17:19:43.517060
# Unit test for function parse
def test_parse():
    text = """\
    Example docstring.

    Another paragraph.

    :param foo:
        This is a long description. It can even
        span multiple lines
    :type foo: str
    :param bar: This is a short description.
    :type bar: int
    :returns:
        This is a long description. It can even
        span multiple lines
    :rtype: dict
    """
    docstring = parse(text)
    assert docstring is not None
    assert docstring.short_description == 'Example docstring.'
    assert docstring.long_description == 'Another paragraph.'
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == 'foo'

# Generated at 2022-06-23 17:19:55.229521
# Unit test for function parse
def test_parse():
    style = Style.google
    text = '''\
Extracts a list of words from a file.

The words are returned in a list of tuples where the first item in
the tuple is the word itself, and the second item is the number of
times that word occurs.

:param file_handle: file to read
:type file_handle: file object
:returns: list of (word, frequency) tuples
:rtype: list
:raises TypeError: if file_handle is closed
'''
    d = parse(text, style)
    assert d.style == style
    assert len(d.meta) == 3
    assert d.meta[0].meta == 'param'
    assert d.meta[0].name == 'file_handle'
    assert d.meta[0].description == 'file to read'
    assert d

# Generated at 2022-06-23 17:20:06.683952
# Unit test for function parse
def test_parse():
    text = '''\
This is a docstring.

Parameters
----------
a : int
    parameter a
b : float
    parameter b
c : str
    parameter c

Returns
-------
int
    The answer.
'''


# Generated at 2022-06-23 17:20:11.541147
# Unit test for function parse
def test_parse():
    # Example of a simple Docstring - Gaetan Semet
    text = """This function does something.

Parameters
----------
a : int
    The first parameter.
b : str
    The second parameter.

Returns
-------
bool
    The return value. True for success, False otherwise.
"""
    print(parse(text))



# Generated at 2022-06-23 17:20:19.478115
# Unit test for function parse
def test_parse():
    test_cases = {
        "text": "This is a test.",
        "style": Style.google,
        "error": None,
        "expected": {
            "text": "This is a test.",
            "meta": {},
            "params": [],
            "returns": None
        }
    }

    result_docstring = parse(test_cases["text"], test_cases["style"])

    assert test_cases["expected"]["text"] == result_docstring.text
    assert test_cases["expected"]["meta"] == result_docstring.meta
    assert test_cases["expected"]["params"] == result_docstring.params
    assert test_cases["expected"]["returns"] == result_docstring.returns

# Generated at 2022-06-23 17:20:30.729541
# Unit test for function parse
def test_parse():
    def test_func():
        """Hello

        :param x: x
        :param y: y
        :type x: int
        :type y: str
        :returns: x+y
        :rtype: str

        test_func does this and that

        """
        return x+y
    doc_napoleon = parse(test_func.__doc__)
    assert doc_napoleon.short_description == "Hello"
    assert doc_napoleon.long_description == "test_func does this and that"
    assert len(doc_napoleon.params) == 2
    assert doc_napoleon.params[0].arg_name == "x"
    assert doc_napoleon.params[0].arg_type == "int"

# Generated at 2022-06-23 17:20:35.097856
# Unit test for function parse
def test_parse():
    """test function parse"""
    text = '''\
        This is the first line.

        This is the second line.
    '''
    d = parse(text)
    assert d.short_description == 'This is the first line.'
    assert d.long_description == 'This is the second line.'

# Generated at 2022-06-23 17:20:43.237213
# Unit test for function parse
def test_parse():
    input_string = """\
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam
    consectetur nunc non turpis dictum, in dictum lacus finibus.
    Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
    posuere cubilia Curae; Fusce dui diam, bibendum ac neque ut,
    semper convallis ipsum. Vestibulum non metus vel elit vestibulum
    venenatis. Quisque feugiat scelerisque neque, dignissim ornare
    lectus sagittis nec. Nulla a aliquam mauris.
    """

    ans = Docstring(
        description=input_string,
        meta={}
    )

    assert parse

# Generated at 2022-06-23 17:20:49.812261
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    from docstring_parser.styles import GoogleDocstring, NumpyDocstring
    from docstring_parser.tests import PrintMixin

    # Google style
    doc = parse("""
    Args:
        a: bla
        b: bla
        c: bla

    Returns:
        bla
    """)
    assert isinstance(doc, GoogleDocstring)

    # Numpy style
    doc = parse("""
    Parameters
    ----------
    a : int
        bla
    b : int
        bla
    c : int
        bla
    Returns
    -------
    int
        bla
    
    """)
    assert isinstance(doc, NumpyDocstring)

    # Auto-detect style

# Generated at 2022-06-23 17:20:55.961049
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    text = '''\
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    style = Style.numpy
    print(parse(text, style))
    assert( isinstance(parse(text, style), Docstring))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:21:07.338546
# Unit test for function parse
def test_parse():
    assert parse('# foo\nbar') == Docstring(
        content='bar',
        meta={'foo'},
        params=set(),
        returns=None,
    )

    assert parse('# foo\n# bar\nqux') == Docstring(
        content='qux',
        meta={'foo', 'bar'},
        params=set(),
        returns=None,
    )

    assert parse('# foo\n# bar\n# qux\n\nhello world') == Docstring(
        content='hello world',
        meta={'foo', 'bar', 'qux'},
        params=set(),
        returns=None,
    )


# Generated at 2022-06-23 17:21:11.244188
# Unit test for function parse
def test_parse():
    doc = parse("""A short description.
    A long description.

    :param name: The name to use.
    :param state: Current state to be in.
    """)
    assert doc.short_description == "A short description."
    assert doc.long_description == "A long description."
    assert doc.params['name'] == "The name to use."
    assert doc.params['state'] == "Current state to be in."

# End unit test

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:21:22.049564
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("") == Docstring()
    assert parse("\short_description\n content") == Docstring(content="content",short_description="short_description")
    assert parse("\short_description\n \content\n \Args: arg1 arg2 arg3\n arg1 arg2 arg3") == Docstring(content="content",short_description="short_description",Args=" arg1 arg2 arg3 arg1 arg2 arg3")
    assert parse("\short_description\ncontent\n\Args: arg1 arg2 arg3\narg1 arg2 arg3") == Docstring(content="content",short_description="short_description",Args=" arg1 arg2 arg3 arg1 arg2 arg3")
    #assert parse("\short_description\ncontent\n\Args: arg1 arg2 arg3

# Generated at 2022-06-23 17:21:23.721622
# Unit test for function parse
def test_parse():
    
    """Testing"""

    text = "This is a test function"
    result = parse(text)
    assert result

# Generated at 2022-06-23 17:21:29.903065
# Unit test for function parse
def test_parse():
    docstring = parse("""
    This is a docstring
    with multi-line text

    And a return sentence.
    """)
    assert docstring.short_description == 'This is a docstring'
    assert docstring.long_description == 'with multi-line text'
    assert docstring.returns.description == 'And a return sentence.'
    assert docstring.extra_sections == []

    docstring = parse("""
    This is a docstring
    with multi-line text

    :param arg1: the first argument
    :param arg2: the second argument
    :returns: description of return value
    :raises keyError: description of exception
    """)
    assert docstring.short_description == 'This is a docstring'
    assert docstring.long_description == 'with multi-line text'
    assert doc

# Generated at 2022-06-23 17:21:40.918226
# Unit test for function parse
def test_parse():
    text = '''Summary line.

Extended description.

Sphinx directives.
'''
    docstring = parse(text)
    assert docstring.short_description == 'Summary line.'
    assert docstring.extended_description == 'Extended description.\n\nSphinx directives.'
    assert docstring.meta == {}
    assert docstring.params == {}
    assert docstring.returns == {}
    assert docstring.yields == {}
    assert docstring.raises == {}
    assert docstring.warns == {}
    assert docstring.attributes == {}
    assert docstring.see_also == {}
    assert docstring.notes == {}
    assert docstring.examples == ''
    assert docstring.references == ''



# Generated at 2022-06-23 17:21:52.138075
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    from docstring_parser.parse import parse
    print(parse.__doc__)

    text = (
        "Example module.\n"
        "\n"
        "This is a module with a number of functions.\n"
        "\n"
        "Args:\n"
        "    param1 (int): The first parameter.\n"
        "    param2 (str): The second parameter.\n"
        "        Second line of the second parameter's description.\n"
        "\n"
        "Returns:\n"
        "    bool: The return value. True for success, False otherwise.\n"
    )


# Generated at 2022-06-23 17:21:55.524402
# Unit test for function parse
def test_parse():
    text = """This is a test.
    :param str: test
    """
    assert len(text) > 0
    assert type(text) == type("abc")
    assert parse(text) != ""

# Generated at 2022-06-23 17:22:06.630552
# Unit test for function parse
def test_parse():
    
    s = "This is a test docstring"
    expected = dict(short_description=s,
                    long_description="",
                    meta="")
    assert expected == parse(s).__dict__

    s = "This is a test docstring\n\nThis is a long description"
    expected = dict(short_description="This is a test docstring",
                    long_description="This is a long description",
                    meta="")
    assert expected == parse(s).__dict__

    s = "This is a test docstring\n\nThis is a long description\n\n:param a: first param"
    expected = dict(short_description="This is a test docstring",
                    long_description="This is a long description",
                    meta=":param a: first param")
    assert expected == parse(s).__dict__

# Generated at 2022-06-23 17:22:16.543633
# Unit test for function parse
def test_parse():
    docstring = """Short summary

    Longer description.

    :param foo: The first parameter.
    :param bar: The second parameter.
    :returns: description of the return value
    :raises Exception123: when things go wrong
    """

    assert parse(docstring) == Docstring(
        short_description="Short summary",
        long_description="Longer description.",
        parameters=[
            {'name': 'foo', 'description': 'The first parameter.'},
            {'name': 'bar', 'description': 'The second parameter.'},
        ],
        return_value="description of the return value",
        exceptions=[{'type': 'Exception123', 'description': 'when things go wrong'}],
        meta={}
    )


test_parse()

# Generated at 2022-06-23 17:22:24.515814
# Unit test for function parse
def test_parse():
    """Test the parse function."""

    text = '''
        A description of this module.

    :param arg1: The first argument.
    :type arg1: int.
    :param arg2: The second argument.
    :type arg2: str.
    :returns: None.
    :raises Exception1: If something bad happens.
    :raises Exception2: If something even worse happens.
    '''
    docstring = parse(text, style=Style.google)
    assert len(docstring.meta) == 2
    assert docstring.meta[0]['arg1']['type'] == 'int.'
    assert docstring.meta[0]['arg1']['description'] == "The first argument."
    assert docstring.meta[0]['arg2']['type'] == 'str.'

# Generated at 2022-06-23 17:22:28.462538
# Unit test for function parse
def test_parse():
    docstring = 'This is a docstring of module'

# Generated at 2022-06-23 17:22:38.232902
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Style
    from docstring_parser.styles import SphinxStyle
    from docstring_parser.styles import NumpyStyle
    from docstring_parser.styles import GoogleStyle
    from docstring_parser.styles import Doc8Style
    from docstring_parser.styles import JsDoc
    from docstring_parser.styles import GtkStyle
    from docstring_parser.styles import EpytextStyle
    from docstring_parser.styles import PandasStyle
    from docstring_parser.styles import ArpeggioStyle
    from docstring_parser.styles import BoogieStyle
    from docstring_parser.styles import DevhelpStyle
    from docstring_parser.styles import BreezeStyle
    from docstring_parser.styles import NumpydocStyle
    from docstring_parser.styles import DoxyDoxygenStyle

# Generated at 2022-06-23 17:22:47.491621
# Unit test for function parse
def test_parse():
    assert parse('Short summary.\n\nLonger summary.\n\nArgs:\n    param1: You should mention the parameters.\n    param2: You should mention the parameters.\nReturns: E.g.: Returns None.\n') == Docstring(summary='Short summary.', description='Longer summary.', meta={'Args': [{'param1': 'You should mention the parameters.', 'param2': 'You should mention the parameters.'}], 'Returns': ['E.g.: Returns None.']})


# Generated at 2022-06-23 17:22:51.198493
# Unit test for function parse
def test_parse():
    from docstring_parser.parse import parse
    from docstring_parser.styles import Style
    print(parse("""
    blah blah blah
    """))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:59.749726
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Pep257
    ds = """
    :param date_str: date string.
    :type date_str: str, default is None.
    :raises: ValueError, KeyError
    :returns: date object.
    """
    p = parse(ds)
    assert p.params == {'date_str':
    {'type': 'str, default is None.', 'desc': 'date string.'}}
    assert p.returns == {'return': 'date object.'}
    assert p.raises == {'ValueError': '', 'KeyError': ''}
    print(p)

    p = Pep257().parse_data(ds)

# Generated at 2022-06-23 17:23:03.288610
# Unit test for function parse
def test_parse():
    text = '''
    Blah blah blah.
    '''
    docstring = parse(text, style=Style.numpy)
    assert docstring.short_description == 'Blah blah blah.'

# Generated at 2022-06-23 17:23:07.076487
# Unit test for function parse
def test_parse():
    text = '''This is
        a description.

        :param str a: parameter a
        :param str b: parameter b'''

    assert parse(text).meta['a'] == 'parameter a'
    assert parse(text).meta['b'] == 'parameter b'


# Generated at 2022-06-23 17:23:15.136035
# Unit test for function parse
def test_parse():
    text1 = """Summary line.

Extended description.

:param int x: the x
:param str y: the y
:returns: the sum
:rtype: float
"""
    text2 = """Summary line.

:param int x: the x
:param str y: the y
:returns: the sum
:rtype: float
Extended description.
"""
    result = parse(text1)
    assert result.short_description == "Summary line."
    assert result.long_description == "Extended description."
    assert result.meta["param"][0]["name"] == "x"
    assert result.meta["param"][0]["type"] == "int"
    assert result.meta["param"][0]["description"] == "the x"

# Generated at 2022-06-23 17:23:18.808211
# Unit test for function parse
def test_parse():
    assert parse('"""Test"""') == Docstring(summary='Test',
                                            description='')
    assert parse('"""Test\n\nTest 2\n"""') == Docstring(summary='Test',
                                                        description='Test 2')

# Generated at 2022-06-23 17:23:30.748696
# Unit test for function parse
def test_parse():
    assert parse('hello') == Docstring()
    assert parse('hello\nworld').short_description == 'hello\nworld'
    assert parse('hello\n\nworld') == Docstring(short_description='hello', long_description='world')
    assert parse('hello\n\nworld\nagain') == Docstring(short_description='hello',
                                                        long_description='world\nagain')
    assert parse(
        'hello\n:param world: earth\n:type world: str') == Docstring(
        short_description='hello',
        params=[{'name': 'world', 'type': 'str', 'description': 'earth'}])

# Generated at 2022-06-23 17:23:38.776495
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("""
a paragraph.

:param a: asda asdasd
:param b: asdasd
    """) == Docstring(
        lines=[[], [], [], [], [], []],
        meta={'param': [('a', 'asda asdasd'), ('b', ['asdasd'])]},
        description='a paragraph.\n')
    assert parse("""
title
=====

description
    """) == Docstring(
        sections=[Section(
            title='title',
            lines=[[], [], []],
            description='description')],
        lines=[[], [], [], [], []],
        meta={})

# Generated at 2022-06-23 17:23:43.354566
# Unit test for function parse
def test_parse():
    """
    >>> parse('A function which does everything')
    Docstring([Meta([Line('A function which does everything')])])
    """

# TODO:
#    * Add tests for Error cases

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:23:45.918993
# Unit test for function parse
def test_parse():
    assert parse('This is a *docstring*').summary == 'This is a *docstring*'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:50.812182
# Unit test for function parse

# Generated at 2022-06-23 17:24:01.000676
# Unit test for function parse

# Generated at 2022-06-23 17:24:11.541601
# Unit test for function parse
def test_parse():
    # pylint: disable=missing-docstring
    return

    import docstring_parser
    docstring_parser.parse.__doc__

    from docstring_parser.common import ParseError
    from docstring_parser.styles import Style

    parse("hi")
    parse("hi", Style.numpy)
    parse("hi", Style.sphinx)

    try:
        parse("", Style.auto)
    except ParseError as e:
        assert str(e) == "Failed to detect docstring style"

    try:
        parse("hi", Style.unknown)
    except ParseError as e:
        assert str(e) == "Unknown docstring style `unknown`"


# Generated at 2022-06-23 17:24:19.305576
# Unit test for function parse
def test_parse():
    text = """
    This is a summary.
    
    This is a description.
    This is a description.
    This is a description.
    This is a description.

    This is a description.

    :param arg1: This is a description.
    :param arg2: This is a description.

    :returns: This is a description.

    :raises keyError: raises an exception
    """
    docstring = parse(text)
    print(docstring.summary)
    print(docstring.description)
    print(docstring.meta)
    print(docstring.meta['arg1'].type_name)
    

if __name__ == "__main__":
	test_parse()

# Generated at 2022-06-23 17:24:25.761205
# Unit test for function parse
def test_parse():
    from docstring_parser import get_supported_styles
    from docstring_parser.styles import Style
    from docstring_parser.parser import parse
    from docstring_parser import parse_docstring

    for style in get_supported_styles():
        if style is Style.auto:
            continue
        data = parse_docstring(style=style)
        assert isinstance(data, Docstring)
        data = parse(data.raw, style=style)
        assert isinstance(data, Docstring)

# Generated at 2022-06-23 17:24:36.672911
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import google
    from pytest import raises
    from docstring_parser import Docstring, DocstringParam, DocstringSection

    assert parse('') == Docstring()
    assert parse('\n') == Docstring()
    assert parse('   \n   \n   ') == Docstring()

    assert parse('hello') == Docstring(content='hello')
    assert parse('hello\n') == Docstring(content='hello')
    assert parse('hello\n   ') == Docstring(content='hello')
    assert parse('hello\n\n') == Docstring(content='hello')
    assert parse('hello\n\n   ') == Docstring(content='hello')

    assert parse('hello\nworld') == Docstring(content='hello\nworld')

# Generated at 2022-06-23 17:24:45.595928
# Unit test for function parse
def test_parse():
    text = """
    three
    :param a: blub
    :type a: str
    """
    ds = parse(text)
    assert ds.short_description == "three"
    assert ds.long_description == ""
    assert len(ds.meta["returns"]) == 0
    assert len(ds.meta["params"]) == 1
    assert ds.meta["params"][0].arg_name == "a"
    assert ds.meta["params"][0].description == "blub"
    assert ds.meta["params"][0].annotation == "str"

# Generated at 2022-06-23 17:24:52.281491
# Unit test for function parse
def test_parse():
    text = """
    A test docstring.

    :param str a: a string
    :param int b: an integer
    :return: a return value
    """
    doc = parse(text)
    assert doc.summary == 'A test docstring.'
    assert doc.body == ''
    assert len(doc.meta['params']) == 2
    assert len(doc.meta['returns']) == 1

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:25:00.786794
# Unit test for function parse
def test_parse():
    assert parse('# Hello') == Docstring(
        short_description='Hello',
        )
    assert parse('Hello') == Docstring(
        short_description='Hello',
        )
    assert parse('Hello #\n# World') == Docstring(
        short_description='Hello',
        long_description='World',
        )
    assert parse('Hello \n\n World') == Docstring(
        short_description='Hello',
        long_description='World',
        )
    assert parse('Hello #\n# World\n#\n# Bye') == Docstring(
        short_description='Hello',
        long_description='World\n\nBye',
        )

# Generated at 2022-06-23 17:25:05.193453
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    s_text = '''\
    """
    Some example docstring
    """
    '''
    doc1 = parse(s_text)
    print(doc1)

# Generated at 2022-06-23 17:25:08.992938
# Unit test for function parse
def test_parse():
    docstring = """This is a test line.
    :param a: A param.
    :returns: nothing
    """
    assert parse(docstring)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:25:18.594604
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import google as gs, numpy as ns, epytext as es, default as ds

# Generated at 2022-06-23 17:25:24.334842
# Unit test for function parse
def test_parse():
    doc = """This function does something.

    :param foo:  Foo
    :type foo:  int | str
    :param bar:  Bar
    :type bar:  str
    :returns:  str
    """
    docstring = parse(doc)
    assert docstring.short_description == "This function does something."
    assert docstring.long_description == ""
    assert docstring.return_type == "str"
    assert docstring.meta["param"]["foo"].description == "Foo"
    assert len(docstring.meta["param"]["foo"].type_name) == 2
    assert docstring.meta["param"]["foo"].type_name[0] == "int"
    assert docstring.meta["param"]["foo"].type_name[1] == "str"
   

# Generated at 2022-06-23 17:25:33.142084
# Unit test for function parse
def test_parse():
    docstring = """\
        """
    result = parse(docstring)
    assert result.short_description == ''
    print(result.short_description)

    docstring = """\
        Hello world
        """
    result = parse(docstring)
    assert result.short_description == 'Hello world'
    print(result.short_description)

    docstring = """\
        Hello world.
        """
    result = parse(docstring)
    assert result.short_description == 'Hello world.'
    print(result.short_description)

    docstring = """\
        Hello world.
        Hello world.
        Hello world.
        """
    result = parse(docstring)
    assert result.short_description == 'Hello world.'
    print(result.short_description)


# Generated at 2022-06-23 17:25:43.413551
# Unit test for function parse
def test_parse():
    """Test for function that parses a Python docstring into its components

    """
    doc = """
    This function does something.

    :param: parameter
    :type: str
    :returns: str
    """
    parsed = parse(doc)
    assert(parsed.short_description == "This function does something.")
    assert(parsed.long_description == None)
    assert(parsed.meta['par'] == 'parameter')
    assert(parsed.meta['type'] == 'str')
    assert(parsed.returns == 'str')
    doc = """
    This is a description
    that spans multiple lines.
    """
    parsed = parse(doc)
    assert(parsed.short_description == "This is a description")

# Generated at 2022-06-23 17:25:52.916415
# Unit test for function parse
def test_parse():
    from docstring_parser.parsers.google import parse
    ds = parse("""Here is my docstring.

        Args:
            blah (int): blah blah.
            blah2 (int): blah2 blah2.
        Returns:
            int: blah blah.
    """)
    assert ds.short_description == "Here is my docstring."
    assert len(ds.long_description.split('\n')) == 1
    assert len(ds.params) == 2
    assert len(ds.returns) == 1

# Test for function parse with style argument

# Generated at 2022-06-23 17:26:03.993113
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(lines=[], meta=[], tags=[])
    assert parse("   ") == Docstring(lines=[], meta=[], tags=[])
    assert parse("\n") == Docstring(lines=[], meta=[], tags=[])

    assert parse("test") == Docstring(lines=["test"], meta=[], tags=[])

    assert parse("test\n\n") == Docstring(lines=["test"], meta=[], tags=[])
    assert parse("test\n\n   ") == Docstring(lines=["test"], meta=[], tags=[])
    assert parse("test\n\n   \n") == Docstring(lines=["test"], meta=[], tags=[])

    assert parse("test\n\n   meta\n\n") == Docstring(lines=["test"], meta=["meta"], tags=[])

# Generated at 2022-06-23 17:26:11.145181
# Unit test for function parse
def test_parse():
    text = """A one-line summary that does not use variable names
        or the function name.

        Several sentences providing an extended description.

        :param name: The name to use
        :type name: str
        :param state: Whether to use the state
        :type state: bool
        :param return: What to return
        :rtype: int
        """
    try:
        assert len(parse(text).description) == 2
    except AssertionError:
        print('Parse failed')
        exit(-1)

# Generated at 2022-06-23 17:26:16.034683
# Unit test for function parse
def test_parse():
    docstring = parse('This is a test', Style.PEP257)
    assert docstring == Docstring(short_description='This is a test')


if __name__ == '__main__':
    print(parse('Parse the docstring into its components.\n\n\
    :param text: docstring text to parse\n\
    :param style: docstring style\n\
    :returns: parsed docstring representation'))

# Generated at 2022-06-23 17:26:27.191695
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyleDocstring, NumpydocStyleDocstring