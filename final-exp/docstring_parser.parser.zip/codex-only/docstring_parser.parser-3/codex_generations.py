

# Generated at 2022-06-23 17:16:34.445909
# Unit test for function parse
def test_parse():
    assert parse("", Style.numpy) == Docstring(
            short_description='',
            long_description=None,
            content=None,
            returns=None,
            raises=None,
            meta={},
            style=Style.numpy)

    # Default style
    assert parse("") == parse("", Style.auto) == parse("", Style.google)

    # Style: NumPy
    assert parse("", Style.numpy) == Docstring(
            short_description='',
            long_description=None,
            content=None,
            returns=None,
            raises=None,
            meta={},
            style=Style.numpy)

    # Style: Google

# Generated at 2022-06-23 17:16:44.528006
# Unit test for function parse
def test_parse():
    text_one = "This is a test."
    text_two = "\nThis is a test.\n"
    text_three = "\nThis is a test.\n\n"

# Generated at 2022-06-23 17:16:53.312921
# Unit test for function parse
def test_parse():
    text = '''This is a test docstring.

:param foo: some test parameter
:param bar: another test parameter
'''
    doc = parse(text)
    assert doc.short_description == 'This is a test docstring.'
    assert doc.long_description == ''
    assert doc.params['foo'].description == 'some test parameter'
    assert doc.params['bar'].description == 'another test parameter'
    assert len(doc.meta) == 2
    assert len(doc.params) == 2


# Generated at 2022-06-23 17:17:03.060438
# Unit test for function parse
def test_parse():
    """Test for docstring parsing."""
    docstring_examples = {
        "simple": """\
    Just a short one-liner.

    And the rest of the docstring.

    Note
    None.

    Examples
    --------
    >>> 1 + 2 + 3
    6
    """,
        "empty": r"""\
    """,
    }
    docstring_examples = {key: parse(val) for key, val in docstring_examples.items()}

    # Some simple smoke tests and sanity checks.
    assert docstring_examples["simple"].short_description == "Just a short one-liner."
    assert "the rest of the docstring" in docstring_examples["simple"].long_description
    assert len(docstring_examples["simple"].meta) == 1
    assert docstring_

# Generated at 2022-06-23 17:17:12.797571
# Unit test for function parse
def test_parse():

    assert  parse("""
    This is a test.

    :param param1: this is a parameter
    :param param2: this is a second parameter
    :returns: this is a return
    :raises keyError: raises an exception
    """) ==  Docstring("""
    This is a test.
    
    
    
    
    """,
    {'param1':'this is a parameter','param2':'this is a second parameter','returns':'this is a return','raises keyError':'raises an exception'})

# Generated at 2022-06-23 17:17:20.110970
# Unit test for function parse
def test_parse():
   # An example of a docstring with style google
   assert parse('test_parse()\n\nThe main parsing routine.')
   assert parse('test_parse\n\nThe main parsing routine.')
   assert parse('test_parse(text: str, style: Style = Style.auto)\n\nThe main parsing routine.')
   assert parse('test_parse()\n\nThe main parsing routine.\n\n:param text: docstring text to parse\n:param style: docstring style\n:returns: parsed docstring representation')
   assert parse('test_parse()\n\nThe main parsing routine.\n\n:param text: docstring text to parse\n:param style: docstring style\n:returns: parsed docstring representation\n:raises ParseError: if some things happened')

# Generated at 2022-06-23 17:17:31.648628
# Unit test for function parse
def test_parse():
    import os
    import sys
    import pandas as pd
    from pandas.util.testing import assert_frame_equal

    module_path = os.path.abspath(os.path.join('..'))
    if module_path not in sys.path:
        sys.path.append(module_path)
    from test_docstring_parser import read_file
    from test_docstring_parser import get_answer_dataframe
    from test_docstring_parser import get_answer_json

    # Test function parse
    test_file_path=os.path.abspath(os.path.join('..', 'test_docstring_parser', 'docstring_parser_input.csv'))
    csv_reader = pd.read_csv(test_file_path, quoting=1)
    answer_df

# Generated at 2022-06-23 17:17:34.787549
# Unit test for function parse
def test_parse():
	assert parse("This is a test") == True
	assert parse("This is a test1") == False
	assert parse("This is a test", 1) == False
	assert parse("This is a test", Style.sphinx) == True


# Generated at 2022-06-23 17:17:45.794703
# Unit test for function parse
def test_parse():
    d = parse('''
    Docstring for get_ipython.  Return an IPython running shell.

    This launches a new ipython if it isn't already running, and returns
    a running instance.  It does not start a blocking event loop, as
    in the :func:`embed` function.

    This function is not needed when a :program:`kernel` is running.

    :Parameters: None
    :Returns: None
    :Raises: None
    ''')
    assert d.meta == [
        'Docstring for get_ipython.  Return an IPython running shell.'
    ]

# Generated at 2022-06-23 17:17:52.845897
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    # test the exceptions
    with pytest.raises(ParseError):
        parse("""\
        wrong keyword
        """)
    with pytest.raises(ParseError):
        parse("""\
        :param x:
          wrong type
        """)

    # test the valid signature and metadata
    docstring = parse("""\
        This is a one-line summary.

        This is a ducstring which spans multiple lines.
        """)
    assert not docstring.meta
    assert docstring.summary == "This is a one-line summary."
    assert docstring.description == "This is a ducstring which spans multiple lines."


# Generated at 2022-06-23 17:18:00.236739
# Unit test for function parse
def test_parse():
    assert parse(parse.__doc__)
    assert parse('Hello world!', style=Style.sphinx).short_description == 'Hello world!'
    assert parse('Hello world!', style=Style.google).short_description == 'Hello world!'
    assert parse('Hello world!', style=Style.numpy).short_description == 'Hello world!'
    assert parse('Hello world!', style=Style.auto).short_description == 'Hello world!'

# Generated at 2022-06-23 17:18:01.525553
# Unit test for function parse
def test_parse():
    parse()

# Generated at 2022-06-23 17:18:07.264200
# Unit test for function parse
def test_parse():
    style = Style.google
    docstring = parse(text='This is a docstring for a parser unit test.', style=style)
    assert docstring.short_description == 'This is a docstring for a parser unit test.'
    assert docstring.long_description == ''
    assert docstring.returns == []
    assert docstring.meta == []
    assert docstring.examples == []
    assert docstring.notes == []
    assert docstring.references == []


# Generated at 2022-06-23 17:18:18.071793
# Unit test for function parse
def test_parse():
    docstring = """An overview of the challenge, with a few paragraphs about each of the parts.

New paragraph in the overview.

The name of this part is "Part 1"

The name of this part is "Part 2"

The name of this part is "Part 3"

New part was added on Sep 6, 2018
    """
    doc = parse(docstring)
    assert doc.meta['overview'][0] == """An overview of the challenge, with a few paragraphs about each of the parts.

New paragraph in the overview."""
    assert doc.meta['part1'] == 'The name of this part is "Part 1"'
    assert doc.meta['part2'] == 'The name of this part is "Part 2"'
    assert doc.meta['part3'] == 'The name of this part is "Part 3"'

# Generated at 2022-06-23 17:18:19.606517
# Unit test for function parse
def test_parse():
    docfile = open("doc.txt", "r")
    text = docfile.read()
    parse(text)

# Generated at 2022-06-23 17:18:21.183037
# Unit test for function parse
def test_parse():
    doc = parse(text = 'A sample docstring')
    assert doc == 'A sample docstring'

# Generated at 2022-06-23 17:18:32.068590
# Unit test for function parse
def test_parse():
    docstring = """This is the first line
    and this is the second line.
    :param name: name argument
    :type where: str
    :param address: address argument
    :type where: str
    :raises ValueError: if something fails
    :return: what's being returned
    :rtype: int
    :ivar name: name instance attribute
    :vartype name: str
    :ivar address: address instance attribute
    :vartype address: str
    """
    assert parse(docstring).short_description == 'This is the first line'
    assert parse(docstring).long_description == 'and this is the second line.'
    assert parse(docstring).returns == 'what\'s being returned'
    assert parse(docstring).return_type == 'int'
    assert parse(docstring).var_

# Generated at 2022-06-23 17:18:43.123110
# Unit test for function parse
def test_parse():
    test_docstring = '''\
        Calculate the square value of the input number
        Parameters
        ----------
        x : int
            The number to be squared.
        Returns
        -------
        y : int
            The input number squared.
        Examples
        --------
        >>> square(2)
        4
        >>> square(4)
        16
        '''

    # test the function parse
    docstring = parse(test_docstring)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.params)
    print(docstring.returns)
    print(docstring.examples)
    print(docstring.meta)

# Generated at 2022-06-23 17:18:44.502634
# Unit test for function parse
def test_parse():
    assert parse("This project is licensed under the MIT License")

# Generated at 2022-06-23 17:18:51.568448
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    assert parse('').text == ''
    assert parse('a').text == 'a'

    # Test with invalid type of parameter text
    try:
        parse(0)
    except TypeError as error:
        assert str(error) == "text must be of type str"

    # Test with invalid type of parameter style
    try:
        parse('', 0)
    except TypeError as error:
        assert str(error) == "style must be of type Style"

# Generated at 2022-06-23 17:18:54.693247
# Unit test for function parse
def test_parse():
    text = """Module documentation
    Module documentation goes here

    """
    docstring = parse(text)
    assert docstring.short_description == 'Module documentation'
    assert docstring.long_description == 'Module documentation goes here'
    assert docstring.meta['package'] == 'test'


# Generated at 2022-06-23 17:18:59.664492
# Unit test for function parse
def test_parse():
    plain_text = "This is a docstring."
    print(parse(plain_text))

    numpydoc_text = """A function.
    :param a: A parameter.
    :type b: A type.
    :returns: A return value.
    :rtype: A return type.
    """
    print(parse(numpydoc_text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:19:09.044956
# Unit test for function parse
def test_parse():
    text = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    style = Style.google

    s = parse(text, style)
    assert s.summary == "Parse the docstring into its components."
    assert s.params == {'text': 'docstring text to parse', 'style': 'docstring style'}
    assert s.returns == "parsed docstring representation"
    assert s.raises == {}
    assert s.meta == {}

# Generated at 2022-06-23 17:19:17.572111
# Unit test for function parse
def test_parse():
    # Expect Docstring(description='Hello World!', meta=[])
    docstring = parse('Hello World!')
    assert docstring.description == 'Hello World!'
    assert len(docstring.meta) == 0

    # Expect Docstring(description='Hello World!', meta=[])
    docstring = parse('Hello World!', style='google')
    assert docstring.description == 'Hello World!'
    assert len(docstring.meta) == 0

    # Expect Docstring(description='Hello World!', meta=[])
    docstring = parse('Hello World!', style='numpy')
    assert docstring.description == 'Hello World!'
    assert len(docstring.meta) == 0

    # Expect Docstring(description='Hello World!', meta=[])
    docstring = parse('Hello World!', style='sphinx')
    assert docstring

# Generated at 2022-06-23 17:19:24.091216
# Unit test for function parse
def test_parse():
    input = """This function multiplies two numbers
    :param first: the first number
    :param second: the second number
    :return: the multiple of the two numbers
    """
    output = parse(input)
    assert output.short_description == "This function multiplies two numbers"
    assert output.long_description == ""
    assert output.returns[0].description == "the multiple of the two numbers"

# Generated at 2022-06-23 17:19:31.452098
# Unit test for function parse
def test_parse():
    style = None
    docstr = """

    This is the docstring of a function.

    :param x: This is the first parameter.
    :param y: This is the second parameter.
    :type y: int
    :returns: This is what is returned.
    :raises KeyError: We always raise KeyError.
    """
    parsed_doc = parse(docstr, style)
    assert isinstance(parsed_doc, Docstring)

# Generated at 2022-06-23 17:19:39.160036
# Unit test for function parse
def test_parse():
    parse('Foo bar baz')
    parse('Foo bar baz', Style.numpy)
    parse('Foo bar baz', Style.google)
    parse('Foo bar baz', Style.auto)

    d = parse("""This is a description

Foo bar baz

:param foo: A foo
:rtype: string
:returns: A foo
""", Style.numpy)
    assert d.short_description == 'This is a description'
    assert d.long_description == 'Foo bar baz'
    assert d.returns.description == 'A foo'
    assert d.returns.annotation is None

# Generated at 2022-06-23 17:19:50.476494
# Unit test for function parse
def test_parse():
    assert 'here' in parse("""
        :Summary line.

        Body text here.

        :param int arg1: first argument
        :param str arg2: second argument
        :return: no return
        :rtype: None"""
    ).body
    assert 'here' in parse("""
        Summary line.

        Body text here.

        :param int arg1: first argument
        :param str arg2: second argument
        :return: no return
        :rtype: None"""
    ).body
    assert 'here' in parse("""
        Summary line.

        Body text here.

        :Args:
            arg1 (int): first argument
            arg2 (str): second argument
        :Returns:
            None"""
    ).body

# Generated at 2022-06-23 17:19:51.283052
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-23 17:19:57.736897
# Unit test for function parse
def test_parse():
    text = """
    This is a test 
    """
    parser = parse(text)
    assert isinstance(parser,Docstring)

    text = """
    :param str sample: This is a sample
    :return: This is a return
    """
    parser = parse(text)
    assert isinstance(parser,Docstring)
    assert parser.returns == [{'type': '', 'description': 'This is a return'}]
    assert parser.arguments == [{'type': 'str', 'name': 'sample', 'default': None, 'description': 'This is a sample'}]

# Generated at 2022-06-23 17:20:09.535980
# Unit test for function parse

# Generated at 2022-06-23 17:20:13.614245
# Unit test for function parse
def test_parse():
    s = '''\
This is a short summary.

This is a longer description that spans
multiple lines.

This is a the last paragraph of a function's docstring.
'''
    print('def parse(text: str) -> Docstring:')
    print('\t', parse(s))

# Generated at 2022-06-23 17:20:18.553366
# Unit test for function parse
def test_parse():
    text = """Summary line.

Description:
    
    This section contains a longer description
    that is separated by blank lines.

Args:
    
    arg1 (str): Description of arg1.
    arg2 (int): Description of arg2.

Returns:
    
    bool: True if successful
"""
    print(parse(text))

if __name__ == "__main__" :
    test_parse()

# Generated at 2022-06-23 17:20:29.662378
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "", "", "", [], [], [])
    assert parse("""
    This is a docstring.

    :param arg1: the first argument
    :returns: something
    """) == Docstring("This is a docstring.", "", "", "",
                      [("arg1", "the first argument")], [],
                      ["something"])
    assert parse("""
    This is a docstring.

    :param arg1: the first argument
    :param arg2: the second argument
    """) == Docstring("This is a docstring.", "", "", "",
                      [("arg1", "the first argument"),
                       ("arg2", "the second argument")], [], [])

# Generated at 2022-06-23 17:20:39.785669
# Unit test for function parse
def test_parse():
    # Some tests taken from test_parser.py (https://github.com/agronholm/sphinxtesters/blob/master/sphinxtesters/test_parser.py)
    # Further tests provided by me
    # Function parse corresponds to the following text in test_parser.py
    '''
    def test_parse(self):
        res = self.parse('''

# Generated at 2022-06-23 17:20:51.764174
# Unit test for function parse
def test_parse():
    """Unit test for parse function"""
    docstring_str = """This function does something.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :type arg1: int
    :type arg2: int
    :returns: The return value. True for success, False otherwise.
    :rtype: bool"""
    docstring = parse(docstring_str, Style.numpy)
    assert docstring.short_description == "This function does something."
    assert docstring.long_description == ""
    assert docstring.returns.description == "The return value. True for success, False otherwise."
    assert docstring.returns.type_annotation == "bool"
    assert docstring.params["arg1"].description == "The first argument."

# Generated at 2022-06-23 17:21:00.581625
# Unit test for function parse
def test_parse():
    docstring = """
    Short summary.

    Extended description.

    Parameters
    ----------
    arg1 : str
        Description of `arg1`

    arg2 : bool, optional
        Description of `arg2`, defaults to True

    Returns
    -------
    str
        Description of return value

    Examples
    --------
    >>> example
    some output
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Short summary."
    assert parsed.long_description == "Extended description."
    assert parsed.returns == ('str', 'Description of return value')
    assert parsed.return_type == "str"
    assert parsed.return_desc == "Description of return value"
    assert parsed.meta['arg1']['type'] == "str"
    assert parsed.meta['arg1']['desc']

# Generated at 2022-06-23 17:21:12.539270
# Unit test for function parse
def test_parse():
    #Sphinx style
    text = """This is a test module
    :param a: test a
    :type a: boolean
    :param b: test b
    :type b: int
    :raises ValueError: test error
    """
    docstring = parse(text)
    assert docstring.params['a'] == "test a"
    assert docstring.params['b'] == "test b"
    assert docstring.errors[0] == "test error"
    assert docstring.returns == None

    #NumPy style
    text = """This is a test module
    Parameters
    ----------
    a : boolean
        test a
    b : int
        test b
    Returns
    -------
    c : boolean
        test c
    Raises
    ------
    ValueError
        test error
    """
   

# Generated at 2022-06-23 17:21:24.106687
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle

# Generated at 2022-06-23 17:21:30.298307
# Unit test for function parse
def test_parse():
    docstring = """One line summary.

Longer description.

Args:
    foo: Description for `foo`.
    bar: Description for `bar`.

Returns:
    Description of return value.
    """
    doc = parse(docstring)
    assert doc.short_description, 'One line summary.'
    assert doc.long_description, """Longer description.
"""
    assert len(doc.options) == 0
    assert len(doc.args) == 2
    assert len(doc.returns) == 1

# Generated at 2022-06-23 17:21:40.918643
# Unit test for function parse
def test_parse():
    text = '''\
    hello

        :param x: x axis
        :type x: int
        :param y: y axis
        :type y: int
    '''

    docstring = parse(text)
    assert docstring.summary == 'hello'
    assert len(docstring.parameters) == 2
    assert docstring.parameters[0].name == 'x'
    assert docstring.parameters[0].description == 'x axis'
    assert docstring.parameters[0].type == 'int'
    assert docstring.parameters[1].name == 'y'
    assert docstring.parameters[1].description == 'y axis'
    assert docstring.parameters[1].type == 'int'



# Generated at 2022-06-23 17:21:45.288777
# Unit test for function parse
def test_parse():
    doc ="""
   This is a  very simple test.
   This is a  new line.
   """
    result = parse(doc)
    if result is not None :
       pass
    else :
       assert False


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:21:56.376691
# Unit test for function parse
def test_parse():
    assert parse("""This is a test
    :param text: docstring text to parse
    :raises ParseError: raised when the docstring is not well-formatted
    :returns: parsed docstring representation
    """, style = Style.google).params == {'text': 'docstring text to parse'}

    assert parse("""This is a test
    @param text: docstring text to parse
    @raises ParseError: raised when the docstring is not well-formatted
    @returns: parsed docstring representation
    """, style = Style.numpy).params == {'text': 'docstring text to parse'}


# Generated at 2022-06-23 17:21:59.708035
# Unit test for function parse
def test_parse():
    exapmle = """
    :param inp: str type
    """
    assert parse(exapmle).meta['param']['inp'] == 'str type'

# Generated at 2022-06-23 17:22:05.228907
# Unit test for function parse
def test_parse():
    assert parse('Hello world!')
    assert parse('Hello world!', style=Style.numpy)
    assert parse('Hello world!', style=Style.google)
    assert parse('Hello world!', style=Style.reST)
    assert parse('Hello world!', style=Style.auto) == parse('Hello world!', style=Style.reST)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:11.079811
# Unit test for function parse
def test_parse():
    docstrings = __doc__.split("\n\n")
    for docstring in docstrings:
        parsed = parse(docstring)
        print(parsed.short_description)
        print(parsed.long_description)
        print(parsed.params)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:19.803569
# Unit test for function parse
def test_parse():
    text = '''\
    Parameters
    ----------
    :param text: string
        The text to search.
    :param repl: string
        The replacement string.
    :returns: string
        The string with all occurances of ``pattern`` replaced.
    '''
    doc = parse(text)
    assert doc.short_description == ''
    assert doc.long_description == ''
    assert doc.sections[0].name == 'Parameters'
    assert doc.sections[0].descriptions == ['']
    assert doc.sections[0].parameters == [
        ('text', 'string', 'The text to search.'),
        ('repl', 'string', 'The replacement string.'),
    ]
    assert doc.sections[1].name == 'Returns'
    assert doc.sections[1].descriptions == ['']


# Generated at 2022-06-23 17:22:22.205793
# Unit test for function parse
def test_parse():
    text = """\
    This is a multiline docstring
    which should be parsed.
    """
    parse(text)

# Generated at 2022-06-23 17:22:34.119007
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.google import GoogleStyleDocstring
    from docstring_parser.styles.numpy import NumpyStyleDocstring
    from docstring_parser.styles.sphinx import SphinxStyleDocstring


# Generated at 2022-06-23 17:22:45.871684
# Unit test for function parse
def test_parse():
    result = parse("""This is a module docstring.
            Hello, testing!
              Parameters
              ----------
              int myint : integer
              str mystr : string
              dic mydic : dictionary
              sfu mysfu : sfu
              Returns
              -------
              int
              list
              str
              """)
    assert result.short_description == "This is a module docstring."
    assert result.long_description == "Hello, testing!\n"
    assert result.parameters["int myint"] == "integer"
    assert result.parameters["str mystr"] == "string"
    assert result.parameters["dic mydic"] == "dictionary"
    assert result.parameters["sfu mysfu"] == "sfu"
    assert result.returns["int"] == ""

# Generated at 2022-06-23 17:22:51.440046
# Unit test for function parse
def test_parse():
    docstr = '''
    Args:
        param1: The first parameter.
        param2: The second parameter.
    Returns:
        The return value. True for success, False otherwise.
    '''
    parse(docstr)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:59.021710
# Unit test for function parse
def test_parse():
    text1 = """
    Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    bool
        Description of return value

    Raises
    ------
    KeyError
        Description of exception
    """
    print(parse(text1))

    text2 = """
    Summary line.

    Extended description.

    Attributes
    ----------
    attr1 : str
        Description of `attr1`
    """
    print(parse(text2))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:05.076291
# Unit test for function parse
def test_parse():
    docstring = """
    :param name: Name of the person.
    :type name: str
    :param age: Age of the person.
    :type age: int
    :param sex: Gender of the person.
    :type sex: str
    :return: the person's info.
    """
    print(parse(docstring))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:06.328595
# Unit test for function parse
def test_parse():
    doc = parse('Summary')
    assert doc.summary == 'Summary'


# Generated at 2022-06-23 17:23:15.768712
# Unit test for function parse
def test_parse():
    text="""Parses the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    assert(parse(text)=="Docstring(description='Parses the docstring into its components.',\
    long_description=None, meta={'param': ['text: (:obj:`str`) docstring text to parse', 'style: (:obj:`str`) docstring style'], 'returns': ['parsed docstring representation']}, tags={})")


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:23.631420
# Unit test for function parse
def test_parse():
    """
    test parsing a google docstring
    """
    
    expected_docstring = Docstring(summary="This is a python script used to calculate summary statistics", meta=[
        ('param', 'design', 'A full path to design file.\n    Please see an example in `data/design.txt`'),
        ('param', 'group', 'A string for specifying the key of group vector in design file'),
        ('param', 'covariate', 'A string for specifying the key of covariate vector in design file')],
        content="If you have any problem with this script, plese contact <genome-clc@lsce.ipsl.fr>",
        returns="None")
    

# Generated at 2022-06-23 17:23:29.031169
# Unit test for function parse
def test_parse():
    try:
        text = """This module provides a simple HTTP server"""
        assert parse(text)
        text = """This is a module for sending HTTP requests"""
        assert parse(text)
        text = """This is a module for parsing HTTP requests"""
        assert parse(text)
    except Exception as e:
        assert False, 'Not working as expected'

# Generated at 2022-06-23 17:23:35.182487
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    docstring = parse("docstring")
    assert(docstring == Docstring(description='docstring', params=[], returns="", summary='docstring'))
    docstring = parse("docstring\n")
    assert(docstring == Docstring(description='docstring', params=[], returns="", summary='docstring'))
    docstring = parse("docstring\n\n")
    assert(docstring == Docstring(description='docstring', params=[], returns="", summary='docstring'))


# Generated at 2022-06-23 17:23:39.159187
# Unit test for function parse
def test_parse():
    assert parse("hello") == Docstring(
        summary="hello",
        meta=[],
        description="",
        examples=[],
        return_=None,
        raises=[],
    )


# Generated at 2022-06-23 17:23:41.633310
# Unit test for function parse
def test_parse():
    """ """
    d = parse('Test parse function. \n\nDescription : no markup to check')
    assert d.meta['short_description'] == 'Test parse function.'
    assert d.content == 'Description : no markup to check'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:45.479518
# Unit test for function parse
def test_parse():
    docstring = """\
The main parsing routine.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
"""
    doc = parse(docstring)
    assert doc.short_description == "The main parsing routine."
    assert doc.long_description == ""
    assert doc.meta['text'].args == 'docstring text to parse'
    assert doc.meta['style'].args == 'docstring style'
    assert doc.meta['returns'].args == 'parsed docstring representation'

# Generated at 2022-06-23 17:23:50.255588
# Unit test for function parse
def test_parse():
    assert parse("""\
Class for representing square matrices.

:param n: dimension of square matrix
:type n: int
:param k: fill value
:type k: int
:returns: matrix object
:rtype: SquareMatrix
""") == Docstring("""\
Class for representing square matrices.

:param n: dimension of square matrix
:param k: fill value
:returns: matrix object
:rtype: SquareMatrix
""")


# Generated at 2022-06-23 17:23:57.174596
# Unit test for function parse
def test_parse():
    text = '''
    A simple example
    :param name: the name of the person
    :param email: the email of the person
    '''
    result = parse(text)
    assert result.short_des == 'A simple example'
    assert result.long_des == ''
    assert result.params == [('name', 'the name of the person'), ('email', 'the email of the person')]
    assert result.returns == ''

# Generated at 2022-06-23 17:24:03.595143
# Unit test for function parse
def test_parse():
    text = """\
    This is a function.

    :param a: param a
    :param b: param b"""

    docstring = parse(text)

    assert docstring.short_description == "This is a function."
    assert docstring.long_description == ""
    assert len(docstring.meta) == 2
    assert docstring.meta[0]["name"] == "a"
    assert docstring.meta[0]["description"] == "param a"
    assert docstring.meta[1]["name"] == "b"
    assert docstring.meta[1]["description"] == "param b"
    assert len(docstring.errors) == 0



# Generated at 2022-06-23 17:24:14.806935
# Unit test for function parse
def test_parse():
    """Main unit test for function parse"""
    docstring = """The main parsing routine.
    
    This function returns a parsed docstring.
    
    Args:
        text (str): docstring text to parse
        style (docstring_parser.styles.Style, optional): docstring style
    Returns:
        docstring_parser.common.Docstring: parsed docstring representation
    
    Raises:
        docstring_parser.common.ParseError: if the input is not a docstring
    
    """
    expected_docstring = """The main parsing routine.
    
    This function returns a parsed docstring.
    """

# Generated at 2022-06-23 17:24:26.854232
# Unit test for function parse
def test_parse():
    answer = parse('''
    This is an example of google docstring.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Return True if deleted successfully, False otherwise.
    ''')
    assert answer.short_description == "This is an example of google docstring."

    answer = parse('''
    This is an example of Numpy docstring.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    bool: Return True if deleted successfully, False otherwise.
    ''')

    assert answer.short_description == "This is an example of Numpy docstring."

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:33.705284
# Unit test for function parse
def test_parse():
    sample = parse(
        """\
Arguments:
    arg1 (int): Description of arg1.
    arg2 (str): Description of arg2.
"""
    )
    assert sample.args == {'arg1': ('int', 'Description of arg1.'), 'arg2': ('str', 'Description of arg2.')}

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:41.724734
# Unit test for function parse
def test_parse():
    text = '''Foo bar baz
    You can write:
        sin(x)
        e**2
    And, you can use [1, 2, 3]
    '''
    d = parse(text, Style.numpy)
    assert d.summary == 'Foo bar baz'
    assert d.description == ['You can write:\nsin(x)\ne**2', 'And, you can use [1, 2, 3]']
    assert d.meta['Parameters'] == []
    assert d.meta['Returns'] == []

# Generated at 2022-06-23 17:24:50.272847
# Unit test for function parse
def test_parse():
    docstring = """Multiline docstring with
    some text.

    Args:
        pos_arg (str): Description of this argument.
        kwonly_arg (str): Description of this keyword-only argument.
        pos_or_kw_arg (str): Description of this positional-or-keyword argument.
    Kwargs:
        kwarg (str): Description of this keyword argument.
    Keyword Arguments:
        kwarg (str): Description of this keyword argument.
    Raises:
        ValueError: Description of exception.
    Returns:
        None: Description of return value.
    """
    docstring_obj = parse(docstring)
    assert docstring_obj.short_description == 'Multiline docstring with\nsome text.'
    assert len(docstring_obj.long_description) == 2
   

# Generated at 2022-06-23 17:24:58.603071
# Unit test for function parse
def test_parse():
    text = """
This is a function
    
Parameters
----------
x : float, optional
    Default 1
    bla
    bla
    bla
    f
    f
    f
    f
"""
    assert parse(text, style = Style.google).meta['x'] == 'float, optional\n    Default 1\n    bla\n    bla\n    bla\n    f\n    f\n    f\n    f'
    assert parse(text, style = Style.sphinx).meta['x'] == 'float, optional\n    Default 1\n    bla\n    bla\n    bla\n    f\n    f\n    f\n    f'

# Generated at 2022-06-23 17:25:10.510867
# Unit test for function parse

# Generated at 2022-06-23 17:25:13.441673
# Unit test for function parse
def test_parse():
    # We do this in a function so that we don't clutter the namespace
    parse("""\
A docstring
""")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:25:17.492914
# Unit test for function parse
def test_parse():
    test_docstring = """Hi, I'm a test docstring.

    :param test: a dummy parameter

    """
    result = parse(test_docstring)
    print(result)
    assert len(result.meta) == 1


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:25:18.645424
# Unit test for function parse
def test_parse():
    from .models import Docstring
    assert parse("hello") == Docstring('hello')

# Generated at 2022-06-23 17:25:30.334997
# Unit test for function parse
def test_parse():
    assert parse('sometext') == Docstring(meta=None, content='sometext', args=[], returns=None)
    assert parse('args: (sometext)\n') == Docstring(meta={'args': 'sometext'}, content='', args=[], returns=None)
    assert parse('args: (sometext)\ncontent') == Docstring(meta={'args': 'sometext'}, content='content', args=[], returns=None)
    assert parse('args: (sometext)\ncontent\n') == Docstring(meta={'args': 'sometext'}, content='content', args=[], returns=None)
    assert parse('args: sometext\n') == Docstring(meta={'args': 'sometext'}, content='', args=[], returns=None)

# Generated at 2022-06-23 17:25:40.198020
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Param, Return, Raise, Example
    doc = """
    A simple example of a docstring.

    :param x: The first parameter
    :type x: type
    :param y: The second parameter
    :type y: type
    :param z: The third parameter
    :type z: type
    :param a: The fourth parameter
    :type a: type
    :param b: The fifth parameter
    :type b: type
    :raises: TypeError
    :raises: ValueError
    :return: the result
    :rtype: type
    :Examples:
        >>> func(1, 2, 3, 4)
        """
    d = parse(doc)
    assert d.short_description == "A simple example of a docstring."
    assert d.long_description == ""


# Generated at 2022-06-23 17:25:45.886426
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('x\ny') == Docstring(description='x\ny')
    assert parse('Args:\n  x: 0') == Docstring(args=['x'])
    assert parse('Args:\n  x: 0\n\nReturns:\n  42\n') == Docstring(args=['x'], returns='42')
    assert parse('Returns: 42\n') == Docstring(args=[], returns='42')
    assert parse('Args:\n  x: 0\n\n  y: 0\n\nReturns: 42\n') == Docstring(args=['x', 'y'], returns='42')

    ## legacy
    assert parse('Args:\n\n  x: 0\n') == Docstring(args=['x'])

# Generated at 2022-06-23 17:25:53.625749
# Unit test for function parse
def test_parse():
    import unittest
    class TestParse(unittest.TestCase):
        def test(self):
            self.assertEqual(
                parse(
                """
                This is a test docstring.

                Args:
                    arg1 (int): the first argument
                """
                ).meta,
                {'args': {'arg1': 'the first argument'}}
            )

    unittest.main()

if __name__ == '__main__':
    # Unit test for function parse
    test_parse()

# Generated at 2022-06-23 17:26:04.319852
# Unit test for function parse
def test_parse():
    text1 = '''
    This is a test of
    the emergency broadcast system.
    '''
    rets1 = parse(text1)
    assert len(rets1) == 1

    text2 = '''
    This is a test of
    the emergency broadcast system.

    Params:
      test (int):  This is a test
    '''
    rets2 = parse(text2)
    assert len(rets2) == 2

    text3 = '''
    This is a test of
    the emergency broadcast system.

    Returns:
      int: This is a test of
      the emergency broadcast system.
    '''
    rets3 = parse(text3)
    assert len(rets3) == 2

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:26:14.241278
# Unit test for function parse
def test_parse():
    docstring = parse("""
    "A simple test.

    :param a: A parameter.
    :type a: int
    :param b: Another parameter.
    :type b: str
    :returns: return value
    :rtype: int
    :raises RuntimeError: raises error
    """)
    assert docstring.short_description == "A simple test."
    assert docstring.long_description == ""
    assert docstring.meta["param"]["a"] == "A parameter."
    assert docstring.meta["type"]["a"] == "int"
    assert docstring.meta["param"]["b"] == "Another parameter."
    assert docstring.meta["type"]["b"] == "str"
    assert docstring.meta["returns"] == "return value"

# Generated at 2022-06-23 17:26:20.348862
# Unit test for function parse
def test_parse():
    """Test parsing of docstring with different styles."""
    import pytest

    text = """
        A docstring.

        :param int param1: a parameter
        :param param2: another parameter
        :returns: whatever
        :raises ValueError: when something goes wrong
        """

    ds = parse(text, Style.google)

    assert isinstance(ds.short_description, str)
    assert ds.short_description == "A docstring."
    assert isinstance(ds.long_description, str)
    assert ds.long_description == ""
    assert isinstance(ds.params, list)
    assert len(ds.params) == 2
    assert ds.params[0].arg_name == "param1"
    assert ds.params[0].type_name == "int"
    assert isinstance

# Generated at 2022-06-23 17:26:29.243879
# Unit test for function parse
def test_parse():
    assert len(parse("hello world")) == len(parse("hello world", style=Style.google))
    assert len(parse("hello world")) == len(parse("hello world", style=Style.numpy))
    assert len(parse("hello world")) == len(parse("hello world", style=Style.pep257))
    assert len(parse("hello world")) == len(parse("hello world", style=Style.javadoc))
    assert len(parse("hello world")) == len(parse("hello world", style=Style.auto))
    assert len(parse("hello world")) > 0