

# Generated at 2022-06-23 17:16:34.852433
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import SphinxStyle, GoogleStyle
    assert parse('', style='goog') == GoogleStyle('')
    assert parse('', style='sphinx') == SphinxStyle('')
    assert parse('', style='numpy') == SphinxStyle('')
    assert parse('', style='google') == GoogleStyle('')
    assert parse('') == SphinxStyle('')
    x = parse('hello')
    assert x.short_description == 'hello'
    assert x.long_description == ''
    assert x.style == 'sphinx'
    x = parse('hello', style='goog')
    assert x.short_description == 'hello'
    assert x.long_description == ''
    assert x.style == 'goog'

#------------------------------------------------------------------------------
# __all__
#

# Generated at 2022-06-23 17:16:44.757636
# Unit test for function parse
def test_parse():
    text = """Functions with two arguments.
  Args:
    arg: The first argument.
    arg2: The second argument.
  """

    docstring = parse(text)

    assert docstring.short_description == "Functions with two arguments."
    assert docstring.long_description == None

# Generated at 2022-06-23 17:16:47.317475
# Unit test for function parse
def test_parse():
    ds = 'Test'
    docstring = parse(ds)
    assert docstring.summary == ds

# Generated at 2022-06-23 17:16:58.359191
# Unit test for function parse
def test_parse():
    sample = """Short summary

    Examples
    --------
    >>> import docstring_parser as dsp
    >>> dsp.parse(dsp.__doc__) #doctest: +ELLIPSIS
    Docstring([(('Short summary',), '\\n    '), (('Examples',), '\\n    ...
    >>> dsp.parse(dsp.__doc__, dsp.Style.numpydoc) #doctest: +ELLIPSIS
    Docstring([(('Short summary',), '\\n    '), (('Parameters',), []), ...
"""

    # docstring_parser.common
    assert parse(
        'Parse the docstring into its components.\n', Style.google
    ).short_description == 'Parse the docstring into its components.'

# Generated at 2022-06-23 17:17:01.860231
# Unit test for function parse
def test_parse():
    text = '''
    This is a test docstring.

    Parameters
    ----------
    x : int
        The first parameter
    y : float
        The second parameter
    z : str
        The third parameter

    Raises
    ------
    ValueError
        If nothing went wrong
    '''
    assert parse(text)


# Generated at 2022-06-23 17:17:12.205587
# Unit test for function parse
def test_parse():
    doc = '''This module is the top-level module for pVAC-seq.

It provides two command-line scripts:
pvacseq run

A module to test parse function.

This module is the top-level module for pVAC-seq.

It provides two command-line scripts:
pvacseq run

Usage
-----
python -m pVACseq run -h
python -m pVACseq score -h

To see full documentation, go to https://github.com/OpenGene/pVAC-seq

'''
    parsed_doc = parse(doc)

# Generated at 2022-06-23 17:17:19.793524
# Unit test for function parse
def test_parse():
    doc = """Compute the variance of X along the specified axis.

Parameters
----------
X : array_like
    A variable.
axis : int, optional
    Axis along which to calculate the variance.
ddof : int, optional
    Delta Degrees of Freedom. The divisor used in calculations
    is ``N - ddof``, where ``N`` represents the number of elements.
keepdims : bool, optional
    If this is set to True, the axes which are reduced are left
    in the result as dimensions with size one. With this option,
    the result will broadcast correctly against the original X.

"""

    assert parse(doc)
    assert parse(doc).short_description == "Compute the variance of X along the specified axis."

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:17:22.435165
# Unit test for function parse
def test_parse():
    text = '''\
    Main command-line interface.

    Parses command-line options and executes the command.
    '''

    assert parse(text).short_description == 'Main command-line interface.'
    assert parse(text).long_description == 'Parses command-line options and executes the command.'

if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:17:28.557240
# Unit test for function parse
def test_parse():
    text = 'This module provides ...'
    assert parse(text, Style.google).description == text
    text = 'This is a summary.\nThis is the rest of the paragraph.'
    assert parse(text, Style.numpy).description == text
    text = 'This is another summary. More text.'
    docstring = parse(text, Style.numpy)
    assert docstring.short_description == 'This is another summary.'
    assert docstring.long_description == 'More text.'

# Generated at 2022-06-23 17:17:29.779808
# Unit test for function parse
def test_parse():
    docstring = parse("""
    This is a summary.
    """)
    assert docstring.short_description == "This is a summary."



# Generated at 2022-06-23 17:17:37.897262
# Unit test for function parse
def test_parse():
    test_docstring = '''
    This is a normal paragraph.
    

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    
    Raises:
        TypeError: if arg1 is invalid.
    
    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    test_parse_result = parse(test_docstring)
    print('Parse Result:', test_parse_result)
    print('Parse to Numpy/Sphinx format doc string: \n', test_parse_result.to_numpy())
    print('Parse to Google format doc string: \n', test_parse_result.to_google())


# Generated at 2022-06-23 17:17:43.488754
# Unit test for function parse
def test_parse():
	text = '''
	.. high-level overview of what your module does.
	
	:param int arg1: the first value
	:param arg2: the second value
	:returns int: description of return value
	:raises keyError: raises an exception
	'''
	#text = '''High-level description...'''
	print(parse(text))
	assert 0


# Generated at 2022-06-23 17:17:46.741204
# Unit test for function parse
def test_parse():
    s = parse('', style = Style.auto)
    # print(type(s))
    # print(s)
    if type(s) is Docstring:
        print('test_parse passed')
    else:
        print('test_parse failed')

# test_parse()

# Generated at 2022-06-23 17:17:47.815613
# Unit test for function parse
def test_parse():
    parse()


# Generated at 2022-06-23 17:17:55.166454
# Unit test for function parse
def test_parse():
    d = parse('hello there')
    assert d.short_description == 'hello there'
    assert d.long_description == ""
    assert d.params == {}
    assert d.returns == {}

    d = parse('hello there\n\nlong description')
    assert d.short_description == 'hello there'
    assert d.long_description == "long description"
    assert d.params == {}
    assert d.returns == {}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:18:06.128344
# Unit test for function parse
def test_parse():
    d = parse("""\
    This is a summary.

    :param param: this is the first param
    :param param2: this is a second param
    :param param3: a third param
    :returns: this is returned
    """, style=Style.google)

    assert str(d) == """\
This is a summary.

:param param: this is the first param
:param param2: this is a second param
:param param3: a third param
:returns: this is returned""".strip()
    assert d.summary == "This is a summary."
    assert d.description == ""
    assert d.extended_summary == ""

# Generated at 2022-06-23 17:18:17.176827
# Unit test for function parse
def test_parse():

    # Test auto detection
    assert parse("Description\n") == Docstring("Description\n", "", "", "")
    assert parse("Description\n :returns: description\n") == Docstring("Description\n", "", "", "description")

    # Test Google style
    assert parse("description\n\nArgs:\n  arg1 (type): description\n", Style.google) == Docstring("description\n", "Args:\n  arg1 (type): description\n", "", "")

    # Test Numpy style
    assert parse("description\n\nParameters\n----------\narg1 : type\ndescription", Style.numpy) == Docstring("description\n", "Parameters\n----------\narg1 : type\ndescription", "", "")

    # Test epytext style

# Generated at 2022-06-23 17:18:24.006295
# Unit test for function parse
def test_parse():
    a = parse("""This is a function that returns a value."""
              """
              :param param1: this is a first param
              :param param2: this is a second param
              :returns: this is a description of what is returned
              :raises keyError: raises an exception
              """)

    assert a.short_description == "This is a function that returns a value."
    assert a.long_description == ""
    assert a.meta['param1'] == "this is a first param"
    assert a.meta['param2'] == "this is a second param"
    assert a.meta['returns'] == "this is a description of what is returned"
    assert a.meta['keyError'] == "raises an exception"

# Generated at 2022-06-23 17:18:32.944098
# Unit test for function parse
def test_parse():
	# test normal cases
	docstring = '''
	Summary line.

		Description of the function.
		Args:
			arg1, arg2, arg3: Here are some arguments.
				
		Kwargs:
			kwarg1, kwarg2, kwarg3: Here are some arguments.
				
				
		Returns:
			None
	'''

# Generated at 2022-06-23 17:18:39.470143
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google as G
    g = G()
    assert g.parse('foo') == parse('foo')
    text = """
    Simple line.

    :param int foo:
        This is the first paragraph
        of the description.

        This is the second one.
    """
    assert g.parse(text) == parse(text)

# Generated at 2022-06-23 17:18:48.585936
# Unit test for function parse
def test_parse():
    text= """Hello, world!"""

    doc1 = parse(text)
    doc2 = parse(text, style=Style.numpy)
    doc3 = parse(text, style=Style.google)
    doc4 = parse(text, style=Style.reST)
    doc5 = parse(text, style=Style.auto)
    assert doc1 == doc2
    assert doc1 == doc3
    assert doc1 == doc4
    assert doc1 == doc5

    text2 = """
Hello, world!
    """

    doc1 = parse(text2)
    doc2 = parse(text2, style=Style.numpy)
    doc3 = parse(text2, style=Style.google)
    doc4 = parse(text2, style=Style.reST)

# Generated at 2022-06-23 17:18:57.035857
# Unit test for function parse
def test_parse():
    text = """
    A quick brown fox

    Parameters:
        param1 (str): The first parameter.
        param2 (int): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert len(docstring.meta) == 3
    assert docstring.short_description == 'A quick brown fox'
    assert docstring.long_description == '\n    A quick brown fox\n'
    assert docstring.returns.type_name == 'bool'
    assert docstring.returns.description == 'The return value. True for success, False otherwise.'
    assert len(docstring.params) == 2
    assert docstring.params[0].type_name == 'str'

# Generated at 2022-06-23 17:19:02.379538
# Unit test for function parse
def test_parse():
    class TestClass:

        def test_docstring(self):
            """Test function.
            :returns: Nothing
            """

    text = TestClass.test_docstring.__doc__
    assert parse(text)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:12.932486
# Unit test for function parse
def test_parse():
    """Unit-test for the function parse.
       This docstring is parsed, and then be compared with the expected parsed docstring.
       """

# Generated at 2022-06-23 17:19:19.431285
# Unit test for function parse
def test_parse():
    test_docstring = '''This is a docstring.

    This is the second line of the docstring.
    '''
    try:
        test_docstring = parse(test_docstring)
    except ParseError as e:
        print(e)

    print('summary = ' + test_docstring.summary)
    print('description = ' + test_docstring.description)


test_parse()

# Generated at 2022-06-23 17:19:28.595575
# Unit test for function parse

# Generated at 2022-06-23 17:19:37.864102
# Unit test for function parse
def test_parse():
    print('Testing parse')
    parseText = """Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    d = parse(parseText)
    assert d.title == 'parse'
    assert d.args == [{'name': 'text', 'type': None, 'desc': 'docstring text to parse'}, {'name': 'style', 'type': None, 'desc': 'docstring style'}]
    assert d.returns == {'type': None, 'desc': 'parsed docstring representation'}
    assert d.meta == {'param': {'text': 'docstring text to parse', 'style': 'docstring style'}, 'return': 'parsed docstring representation'}
    assert d

# Generated at 2022-06-23 17:19:48.835329
# Unit test for function parse

# Generated at 2022-06-23 17:19:50.659124
# Unit test for function parse
def test_parse():
    assert parse("This is a line")


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:19:58.765533
# Unit test for function parse
def test_parse():
    """
    Test for the parse function in docstring_parser/parser.py in docstring_parser.
    :return:
    """
    from docstring_parser.parser import parse
    docstring = parse("""
    This is a test for the parse function in docstring_parser/parser.py in docstring_parser.
    This function parse docstring into components.

    :param input: The input.
    :type input: str
    :param style: The style of the parsing.
    :type style: Style
    :returns: parsed docstring representation
    :rtype: Docstring
    """, style="google")
    assert docstring.short_description == "Test for the parse function in docstring_parser/parser.py in docstring_parser."

# Generated at 2022-06-23 17:20:09.623814
# Unit test for function parse
def test_parse():
    text = '''
    This is the docstring
    
    :param p1: arg1
    :param p2: arg2
    :type p1: int
    :type p2: str
    
    :returns: this
    :rtype: str
    '''
    ret = parse(text)
    import pprint
    pprint.pprint(ret)
    assert ret.short_description == 'This is the docstring'
    assert len(ret.sections) == 1
    assert len(ret.meta) == 4
    assert len(ret.long_description) == 0
    assert ret.meta['p1'][0] == 'int'
    assert ret.meta['p2'][0] == 'str'
    assert ret.meta['returns'][0] == 'this'
    assert ret.meta

# Generated at 2022-06-23 17:20:12.573640
# Unit test for function parse
def test_parse():
    """
    >>> parse('function(x, y)')
    Docstring([('', 'function(x, y)')])
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:20:15.397756
# Unit test for function parse
def test_parse():
    '''Check if the function parse gives the correct output.'''
    assert parse('Hello world') == "Hello world"
    assert type(parse('Hello world')) == str

# Generated at 2022-06-23 17:20:22.106819
# Unit test for function parse
def test_parse():
    text = '''\
    This is a test program
    '''
    parser = parse(text)
    parser.short_description
    parser.long_description
    parser.returns
    parser.params
    parser.row_type
    parser.raises

# if __name__ == '__main__':
#     text = '''\
#     This is a test program
#     '''
#
#     d = parse(text)
#     print(d.short_description)
#     print(d.long_description)
#     print('=' * 20)
#     for param in d.params:
#         print(param)
#     print('=' * 20)
#     print(d.returns)
#     print('=' * 20)
#     print(d.raises)
#     print('

# Generated at 2022-06-23 17:20:28.346793
# Unit test for function parse
def test_parse():
    docstring = '''
    This function print Hello world
    :param name: Name to be printed
    :type name: str
    :returns: A greeting message
    :rtype: str
    '''
    doc1 = parse(docstring)
    assert str(doc1) == docstring

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:20:38.682781
# Unit test for function parse
def test_parse():
    """Test parse function of docstring_parser."""
    from docstring_parser.styles import SPHINX, GOOGLE, NUMPYDOC
    assert parse(
        """This is a test.

Args:
    param1: The first parameter.
    param2: The second parameter.
""",
        style=SPHINX) == Docstring(
        content='This is a test.',
        returns=None,
        params=[
            ('param1', 'The first parameter.'),
            ('param2', 'The second parameter.'),
        ],
        meta={},
        exceptions=None,
        warnings=None,
        notes=None)


# Generated at 2022-06-23 17:20:46.353578
# Unit test for function parse
def test_parse():
    print(parse("""
    This is a test
    """))
    print(parse("""+---------------+------------+
           | Header 1      | Header 2   |
           +===============+============+
           | item 1        | item 2     |
           +---------------+------------+
           | long thing    | thing 2    |
           +---------------+------------+
           | item 3        | item 4     |
           +---------------+------------+""",
           style=Style.napoleon))

# Generated at 2022-06-23 17:20:49.946764
# Unit test for function parse
def test_parse():
    text = """This is an example.
    
    This is a multiline string.
    
    """
    print(parse(text, Style.sphinx))
    pass

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:20:57.844376
# Unit test for function parse
def test_parse():
    def f():
        """This is a function

        :param x: x value
        :returns: some value
        """
        pass

    docstring = parse(f.__doc__)
    assert docstring.short_description == "This is a function"
    assert [[a.name, a.desc] for a in docstring.arguments] == [['x', 'x value']]
    assert [[a.name, a.desc] for a in docstring.returns] == [['', 'some value']]
    assert docstring.meta == {'param x': 'x value', 'returns': 'some value'}

# Generated at 2022-06-23 17:21:00.775231
# Unit test for function parse
def test_parse():
    docstring = """short description

long description
"""

    doc = parse(docstring)
    assert doc.short_description == 'short description'
    assert doc.long_description == 'long description'



# Generated at 2022-06-23 17:21:06.831199
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    from docstring_parser import parse
    import pytest
    text = """
        Module summary line.
        """
    style = Style.numpy
    style = Style.Google
    style = Style.auto
    parse(text, style)

# Generated at 2022-06-23 17:21:17.052873
# Unit test for function parse
def test_parse():
    text = """
    This is a short summary.

    This is a long description.

    Description should be indented.

    :param arg1: this is arg1
    :type arg1: str
    :param arg2: this is arg2
    :type arg2: str
    :returns: None
    :rtype: None
    :raises keyError: raises an exception
    """
    doc = parse(text, style=Style.sphinx)
    assert doc.short_description == "This is a short summary."
    assert doc.long_description == "This is a long description.\nDescription should be indented."
    assert doc.params[0].arg_name == "arg1"
    assert doc.params[0].type_name == "str"

# Generated at 2022-06-23 17:21:25.461197
# Unit test for function parse
def test_parse():
    doc = '''A multi-line docstring.

    :params arg1: The first parameter.
    :param arg2: The second parameter.

    :returns: None.

    '''
    parsed = parse(doc)
    assert parsed.summary == 'A multi-line docstring.'
    assert len(parsed.description) == 1
    assert parsed.description[0] == 'None.'
    assert len(parsed.params) == 2
    assert parsed.params['arg1'] == 'The first parameter.'
    assert parsed.params['arg2'] == 'The second parameter.'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:21:36.751417
# Unit test for function parse

# Generated at 2022-06-23 17:21:46.813124
# Unit test for function parse

# Generated at 2022-06-23 17:21:57.382144
# Unit test for function parse
def test_parse():
    # 1
    text = \
"""
This is a function.
:param str name: The name of the function.
:returns: Nothing
"""
    expected = Docstring(
        summary = 'This is a function.',
        description = '',
        params = { 'name': 'The name of the function.' },
        returns = 'Nothing',
        see_also = None,
        author = None,
        version = None,
        copyright = None,
        meta = None,
        examples = None,
        notes = None,
        references = None,
        attributes = None,
        alias = None,
    )
    doc = parse(text, style = Style.pep257)
    for key in expected.__dict__:
        assert expected.__dict__[key] == doc.__dict__[key]
    # 2

# Generated at 2022-06-23 17:21:58.706468
# Unit test for function parse
def test_parse():
    parse('Hello, World!')

# Generated at 2022-06-23 17:22:08.276176
# Unit test for function parse
def test_parse():
    code_str="""
        """
    docstr=parse(code_str)
    assert type(docstr) is Docstring
    assert docstr.summary == []
    assert docstr.returns == None
    assert docstr.meta == {}
    assert docstr.content == {}
    assert docstr.text == ''

    code_str="""This is a test docstring
    Parameters:
        foo: a
        bar: b
    Returns:
        value
    """
    docstr=parse(code_str)
    assert type(docstr) is Docstring
    assert docstr.summary == ['This is a test docstring']
    assert docstr.returns == 'value'
    assert docstr.meta == {}
    assert docstr.content['Parameters']== {'foo':'a', 'bar':'b'}


# Generated at 2022-06-23 17:22:14.445040
# Unit test for function parse
def test_parse():
    text = """Example docstring.
    
    This function does something.
    
    :param a: description of a
    :type a: int
    :param b: description of b
    :type b: str
    :return: description of return value
    :rtype: bool
    """

    result = parse(text)
    #print(result)
    assert result.short_description == 'Example docstring.'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:22:19.365958
# Unit test for function parse
def test_parse():
    def parser(style):
        def test(text):
            return parse(text, style)
        return test

    def main():
        assert parser(Style.numpy)('''
        Short summary.

        Extended description.
        ''').short_description == 'Short summary.'
        assert parser(Style.google)('''
        Short summary.

        Extended description.

        Args:
            arg: description
        ''').params['arg'] == 'description'

    if __name__ == '__main__':
        main()

# Generated at 2022-06-23 17:22:31.263493
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    
    from docstring_parser.parser import parse

    docstring = parse("""
    This is an example of Google style.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
)

    assert docstring.short_description == "This is an example of Google style."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'param1'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].description == 'The first parameter.'
    assert len(docstring.returns) == 1
   

# Generated at 2022-06-23 17:22:36.559322
# Unit test for function parse
def test_parse():
    test_docstring = '''
    This extension adds a resized_img() function (and others) to the
    image processing library Pillow.

    Use it to resize images to match the given width and height.
    '''
    assert parse(test_docstring) is not None
    print("test_parse() passed!")

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:22:46.794516
# Unit test for function parse
def test_parse():
    assert parse('Hello there.\n') == Docstring(short_description='Hello there.')
    assert parse('Hello there.\n\nSome more text.') == Docstring(short_description='Hello there.',
                                                                  long_description='Some more text.')

    assert parse('Hello there.\n\n:param foo: Hello world') == Docstring(short_description='Hello there.',
                                                                         params=['foo'],
                                                                         param_descriptions=['Hello world'])

    assert parse('Hello there.\n\n:param foo: Hello world\n:returns: some stuff') == Docstring(
        short_description='Hello there.',
        params=['foo'],
        param_descriptions=['Hello world'],
        returns='some stuff')

# Generated at 2022-06-23 17:22:57.364413
# Unit test for function parse
def test_parse():
    text = """
    Docstring: docstring
    \tData: data
    \tNotes: notes
    """

    doc = parse(text)
    print("doc = %s" % doc)
    assert "Docstring" in doc.meta
    assert doc.meta["Docstring"] == "docstring"
    assert "Data" in doc.meta
    assert doc.meta["Data"] == "data"
    assert "Notes" in doc.meta
    assert doc.meta["Notes"] == "notes"
    assert not doc.description
    assert not doc.args
    assert not doc.kwargs
    assert not doc.returns
    assert not doc.raises
    assert not doc.yields
    assert not doc.others


# Generated at 2022-06-23 17:23:07.762840
# Unit test for function parse
def test_parse():
    docstring = """\
    Summary line.
    
    Extended description.
    
    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2
    
    Returns
    -------
    int
        Description of return value
    """

    doc = parse(docstring)

    assert doc.summary == 'Summary line.'
    assert doc.description == 'Extended description.'
    assert doc.extended_description == 'Extended description.'
    assert 'arg1' in doc.params
    assert 'arg2' in doc.params
    assert doc.params['arg1'].arg_type == 'int'
    assert doc.params['arg2'].arg_type == 'str'
    assert doc.params['arg1'].description == 'Description of arg1'
    assert doc

# Generated at 2022-06-23 17:23:16.253067
# Unit test for function parse
def test_parse():
    xtest = """This is a very long description of the function, which
    has lots of lines of text here.
            Parameters:
                some_param (str): This is a parameter
    Args:
        some_param (str): This is a parameter
    """
    stest = """This is a very long description of the function, which
    has lots of lines of text here.
            Parameters:
                some_param (str): This is a parameter
    Args:
        some_param (str): This is a parameter
    """
    atest = """This is a very long description of the function, which
    has lots of lines of text here.
            Parameters:
                some_param (str): This is a parameter
    Args:
        some_param (str): This is a parameter
    """

# Generated at 2022-06-23 17:23:21.182449
# Unit test for function parse
def test_parse():
    given = """
    Parse the docstring into its components.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    expected = parse(given)

    print(expected.text)
    print(expected.meta)
    print(expected.params)
    print(expected.returns)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:23:22.731824
# Unit test for function parse
def test_parse():
    try:
        parse("Docstring")
    except:
        assert False
    assert True

# Generated at 2022-06-23 17:23:26.225766
# Unit test for function parse
def test_parse():
    docstring = parse("""
    Hello
    ========
    """)
    assert docstring.short_description == "Hello"


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:23:33.227092
# Unit test for function parse
def test_parse():
    # Raise exception with invalid attributes
    from docstring_parser.styles import rst
    from docstring_parser import Docstring
    try:
        rst.parse("")
        raise Exception
    except Exception:
        pass

    d = Docstring()
    try:
        d.as_rst()
        raise Exception
    except Exception:
        pass

    try:
        d.as_google()
        raise Exception
    except Exception:
        pass

    try:
        d.as_numpy()
        raise Exception
    except Exception:
        pass

# Generated at 2022-06-23 17:23:44.636861
# Unit test for function parse
def test_parse():
    text = '''This is a test
    of the docstring parser.
    
    :param int a: first parameter
    :param str b: second parameter
    :returns: the sum of a and b
    '''
    assert parse(text) ==  Docstring(
        summary= 'This is a test\n   of the docstring parser.',
        description= '',
        meta= [
            ('a', 'int', 'first parameter'),
            ('b', 'str', 'second parameter')
        ],
        return_ = 'the sum of a and b',
        return_annotation= '',
        style= 'numpy',
        exceptions= [],
        warnings= [],
        notes= [],
        see_also= [],
        references= []
        )

# Generated at 2022-06-23 17:23:52.125902
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test docstring
    """

    # Use the parse() function to get the components of the docstring
    doc = parse(docstring)
    doc_lines = doc.lines
    meta = doc.meta
    summary = doc.summary
    description = doc.description
    tags = doc.tags
    body = doc.body
    code = doc.code

    print(docstring)

    if (doc_lines is not None):
        print("\nOriginal docstring: ", doc_lines)
    if (meta is not None):
        print("\nDocstring meta-data: ", meta)
    if (summary is not None):
        print("\nDocstring summary: ", summary)
    if (description is not None):
        print("\nDocstring description: ", description)

# Generated at 2022-06-23 17:24:01.469613
# Unit test for function parse
def test_parse():
    # Arrange
    text = """\
        :keyword arg2: this is arg2
        :type arg2: int
        :raises KeyError: raises KeyError
        :rtype: dict
        :returns: a dictionary
        :param arg1: this is arg1
        :type arg1: str
        """
    expected_keys = ["arg1", "arg2"]
    # Act
    docstring = parse(text)
    actual_keys = [arg.arg_name for arg in docstring.args]
    # Assert
    assert actual_keys == expected_keys
    assert docstring.returns.type_name == "dict"
    assert docstring.returns.desc == "a dictionary"
    assert docstring.raises.type_name == "KeyError"

# Generated at 2022-06-23 17:24:09.659253
# Unit test for function parse
def test_parse():
    text = """This function does something.

:param x: description of x
:type x: int
:param y: description of y
:type y: int
:returns: description of return value
:rtype: int
"""
    assert parse(text).args == [('x', 'int'), ('y', 'int')]
    assert parse(text).returns == ('', 'int')
    assert parse(text).errors == []
    assert parse(text).meta == {'x': 'int', 'y': 'int'}

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:24:18.694877
# Unit test for function parse
def test_parse():
    doc = '''
        The `parse` function has multiple purposes.
        1. The `parse` function should be able to parse any docstring styles.
        2. The `parse` function should be able to parse only the docstring styles.
        3. The `parse` function should be able to parse only the docstring styles.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
    '''
    d = parse(doc)
    assert d.summary == 'The `parse` function has multiple purposes.'
    assert len(d.description) == 4
    assert d.description[0].text == 'The `parse` function has multiple purposes.'
    assert d.description[1].text == '1. The `parse` function should be able to parse any docstring styles.'
    assert d

# Generated at 2022-06-23 17:24:26.018255
# Unit test for function parse
def test_parse():
    doc = '''
    Module summary.

    Long description.

    :param foo: Description of foo.
    :param bar: Description of bar.
    :type bar: str
    :type foo: str
    :returns: Description of return value.
    :returns type: bool
    :type bar: str
    :raises ValueError: Description of error.
    '''
    assert parse(doc) == parse(doc, style=Style.numpy)
    assert parse(doc) == parse(doc, style=Style.google)

# Generated at 2022-06-23 17:24:36.881575
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
   
    # Test cases

# Generated at 2022-06-23 17:24:46.001899
# Unit test for function parse
def test_parse():
    docstring1 = '''
    This is the docstring for a function.

    Args:
      x: the first parameter

      y: the second parameter

    Returns:
      a result
    '''
    docstring2 = '''Parameters
    ----------
    x: the first parameter
    y: the second parameter
    '''
    assert parse(docstring1, style=Style.google) == parse(docstring2, style=Style.numpy)
    assert parse(docstring1, style=Style.auto) == parse(docstring2, style=Style.auto)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:24:55.397995
# Unit test for function parse
def test_parse():
    d = Docstring(
        summary="This is a docstring.",
        description='Descriptions are optional.\n\nThis is a paragraph.',
        extended_summary='This is an extended summary.\n\nThis is a paragraph.',
        raises=[
            {'type': 'Exception', 'description': 'The exception description.'}
        ],
        type=None,
    )
    text = """This is a docstring.

Descriptions are optional.

This is a paragraph.

:raises Exception: The exception description.

This is an extended summary.

This is a paragraph.
"""
    assert parse(text) == d


# Generated at 2022-06-23 17:25:00.329228
# Unit test for function parse
def test_parse():
    text = '''Foo:
        Args:
            foo (str): first arg
            bar (str): second arg
        Returns:
            None
        '''
    expected = Docstring(
        'Foo:',
        args=[
            ('foo', 'first arg', 'str'),
            ('bar', 'second arg', 'str')
        ],
        returns=['None'],
        raises=[],
        meta=[])
    assert parse(text) == expected

# Generated at 2022-06-23 17:25:12.026983
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style
    """Tests the docstring parser implementation."""
    rets = []
    style = Style.sphinx
    text = '''
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    ret = "\n    :param text: docstring text to parse\n    :param style: docstring style\n    :returns: parsed docstring representation\n    "
    if style != Style.auto:
        assert (STYLES[style](text) == ret)
    for parse_ in STYLES.values():
        parser = parse_(text)
        assert (parser == ret)

# Generated at 2022-06-23 17:25:20.683165
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring for a first class.
    :param param1: this is the description for param1
    :param normal: this is the description for normal
    :param param3: this is another description for param3
    """
    docstring = parse(text, style=Style.google)

    assert docstring.short_description == "This is a docstring for a first class."
    assert docstring.long_description == ""
    assert docstring.params == {
        "param1": "this is the description for param1",
        "normal": "this is the description for normal",
        "param3": "this is another description for param3\n",
    }
    assert docstring.returns is None
    assert docstring.yields is None

# Generated at 2022-06-23 17:25:31.923561
# Unit test for function parse
def test_parse():

    print(parse.__doc__)
    docstring = parse(text, style)
    print(docstring.tostr())

if __name__ == '__main__':
    test_parse()


#______________________________________________________________________________

'''
This module defines the classes that implement read-only and read-write types
for use in dynamically implemented attribute access.
'''

#______________________________________________________________________________

"""This module contains definitions for the following predicate functions:
isDataDescriptor(object) -- Return true if object is a data descriptor.
isGetSetDescriptor(object, name) -- Return true if object is a get/set descriptor.
mro_internal(C) -- Return the mro of class C as a tuple of classes.
"""

#______________________________________________________________________________


# Generated at 2022-06-23 17:25:37.961034
# Unit test for function parse
def test_parse():
    text = '''
    This is a module.

    >>> print('Hello world')
    Hello World!
    '''
    assert parse(text).short_desc == "This is a module."

# Generated at 2022-06-23 17:25:41.953197
# Unit test for function parse
def test_parse():
    text = """
        Args:
            arg1 (int): The first argument.
        """
    output = parse(text)
    assert output.args[0].arg_name == "arg1"
    assert output.args[0].arg_type == "int"
    assert output.args[0].description == "The first argument."
    assert output.returns is None
    assert output.meta == "Args"

# Generated at 2022-06-23 17:25:45.496385
# Unit test for function parse
def test_parse():
    assert isinstance(parse(''), Docstring)
    assert parse('hello world').short_description == 'hello world'

# Generated at 2022-06-23 17:25:55.473592
# Unit test for function parse
def test_parse():
    docstring = """
    Function which multiplies two numbers.

    Args:
        a: first integer
        b: second integer

    Returns:
        a*b: result of multiplication
    """
    actual = parse(docstring)

# Generated at 2022-06-23 17:25:57.244666
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-23 17:26:01.307035
# Unit test for function parse
def test_parse():
    s = parse("""Title\nDescription\nParameters: in1(int) - input ...\nReturns: int - output""")
    assert s.meta["Title"] == "Title"
    assert s.meta["Description"] == "Description"
    assert s.meta["Parameters"] == {"in1": {"type": "int", "parsed_type": "int", "desc": "input ...", "optional": False}}
    assert s.meta["Returns"] == {"return": {"type": "int", "parsed_type": "int", "desc": "output", "optional": False}}

# Generated at 2022-06-23 17:26:06.372916
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    docstring = parse("""Example docstring.
    :param int a: some value
    :return: some return value
    """)
    assert len(docstring.body) == 1
    assert 'a' in docstring.params
    assert docstring.params['a'].arg_type.raw == 'int'
    assert 'return' in docstring.returns
    assert docstring.returns['return'].raw == 'some return value'

# Generated at 2022-06-23 17:26:15.816128
# Unit test for function parse
def test_parse():
    text_1 = """A line of text"""
    assert parse(text_1) == parse(text_1, style=Style.pep257)
    assert parse(text_1) == parse(text_1, style=Style.google)
    assert parse(text_1) == parse(text_1, style=Style.numpy)
    assert parse(text_1) == parse(text_1, style=Style.auto)

    text_2 = """A line of text
    Another line of text"""
    assert parse(text_2) == parse(text_2, style=Style.pep257)
    assert parse(text_2) == parse(text_2, style=Style.google)
    assert parse(text_2) == parse(text_2, style=Style.numpy)

# Generated at 2022-06-23 17:26:22.572120
# Unit test for function parse
def test_parse():
	
	assert parse("") == parse("\n") == parse("\n\n")
	assert parse("a") == parse("a\n") == parse("a\n\n")
	
	assert parse("a\nb") == parse("a\nb\n") == parse("a\nb\n\n")
	assert parse("a b") == parse("a b\n") == parse("a b\n\n")
	
	assert parse("a\n\nb") == parse("a\n\nb\n")

# Generated at 2022-06-23 17:26:28.412591
# Unit test for function parse
def test_parse():
    from pprint import pprint

    docstring = """One line summary.

Extended description.

:param s: sample parameter
:type s: str
:returns: None
:raises TypeError: raises an exception
"""
    d = parse(docstring)
    pprint(d.__dict__)

if __name__ == "__main__":
    test_parse()