

# Generated at 2022-06-21 11:55:13.009323
# Unit test for function parse
def test_parse():
    """You should run the DocstringParse unit test.
    """
    text = '''
            First Line - Summary line

            Extended description -
            can be several lines.

            :param a: Param a
            :type a: int
            :param b: Param b
            :type b: str
            :returns: c
            :rtype: float
            :raises Exception: Raises exception
            '''
    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:23.347095
# Unit test for function parse
def test_parse():
    docstring = """This is a sample module.
This module does stuff.

Args:
    param1: The first parameter.
    param2: The second parameter.

Returns:
    bool: The return value. True for success, False otherwise.

"""
    doc = parse(docstring)
    print(docstring)
    print(doc)
    print("======================")
    print("Summary: ", doc.summary)
    print("Extended Summary: ", doc.extended_summary)
    print("======================")
    print("Parameters: ", doc.params)
    print("======================")
    print("Returns: ", doc.returns)
    print("======================")
    print("Raises: ", doc.raises)
    print("======================")
    print("Yields: ", doc.yields)
    print

# Generated at 2022-06-21 11:55:29.739176
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    assert isinstance(parse('hello'), Docstring)
    assert isinstance(parse('hello', Style.google), Docstring)
    assert isinstance(parse('hello', Style.sphinx), Docstring)
    assert isinstance(parse('hello', Style.numpy), Docstring)
    assert parse('hello') == parse('hello', Style.auto)
    assert parse('hello', Style.google) != parse('hello', Style.numpy)
    assert parse('hello', Style.numpy) != parse('hello', Style.sphinx)

# Generated at 2022-06-21 11:55:33.709585
# Unit test for function parse
def test_parse():
    text = """\
    This is a test function.
    
    Arguments
    =========
    arg: argument to test
    """
    assert parse(text).arglist == ['arg: argument to test']
    return

# Test if Exceptions are thrown appropriately
import pytest

# Generated at 2022-06-21 11:55:41.889644
# Unit test for function parse
def test_parse():
    """
    Test the parse function
    """
    text='''
    Test the parse function
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    func_doc=parse(text)
    assert func_doc.short_description=='Test the parse function'
    assert func_doc.long_description=='Test the parse function'

    assert func_doc.parameters=={'text':'docstring text to parse'}
    assert func_doc.returns=={'returns':'parsed docstring representation'}

# Generated at 2022-06-21 11:55:47.324729
# Unit test for function parse
def test_parse():
    """Test function parse."""
    text = ""
    # text = """This is a docstring
    
    # Args:
    #     arg1: arg1 description
    #     arg2: arg2 description
    # Returns:
    #     return description
    # """
    
    docstring = parse(text)
    print(docstring.description)
    print(docstring.returns)
    print(docstring.args)
    print(docstring.meta)
    print(docstring.style)
    print(docstring.empty)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:55:56.974236
# Unit test for function parse
def test_parse():

    text = """Yield successive n-sized chunks from l.
    Args:
        lst (list): list of items
        n (int): num of items in each chunk
    Returns:
        array-like of n-sized chunks from ``l``
    """

    parsed = parse(text)
    print(parsed)
    print(parsed.style)
    print(parsed.short_description)
    print(parsed.long_description)
    print(parsed.params)
    print(parsed.returns)
    print(parsed.meta)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:03.118432
# Unit test for function parse
def test_parse():
    text = """summary

    This is a long summary.

    Args:
        arg1 (int): The first parameter.
        arg2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.
    """

    # This function will be tested in test_styles.py
    parse(text, style=Style.google)


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    # test_parse()

# Generated at 2022-06-21 11:56:08.094573
# Unit test for function parse
def test_parse():
    s = '''
        Add two numbers.

        :param: x the first number
        :param: y the second number
        :type: x int
        :type: y int
        :returns: the sum
        :rtype: int
    '''
    print(parse(s))

test_parse()

# Generated at 2022-06-21 11:56:19.283915
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    
    text = """
    This is a docstring.

    Parameters
    ----------
    arg1 : array_like
        Description of arg1.
    arg2 : int
        Description of arg2.
    arg3 : str, optional
        Description of arg3.

    Returns
    -------
    bool
        Description of return value.

    Raises
    ------
    RuntimeError
        Description of exception.
    """
    

# Generated at 2022-06-21 11:56:34.686341
# Unit test for function parse
def test_parse():
    print("testing parse()")
    print("testing parse() when style is auto")
    from docstring_parser.tests import test_parse3
    test_parse3.test_parse3()
    print("testing parse() when style is google")
    from docstring_parser.tests import test_parse1
    test_parse1.test_parse1()
    print("testing parse() when style is numpy")
    from docstring_parser.tests import test_parse2
    test_parse2.test_parse2()
    print("testing parse() when style is epytext")
    from docstring_parser.tests import test_parse4
    test_parse4.test_parse4()
    return None


# Generated at 2022-06-21 11:56:44.848623
# Unit test for function parse
def test_parse():
    # The basic test
    doc1 = """
    A very simple test
    """
    docstring = parse(doc1)
    assert docstring.short_description == 'A very simple test'
    assert docstring.long_description == ''

    # Description
    doc2 = """
    A very simple test
    Long description.
    This module does this and that.
    """
    docstring = parse(doc2)
    assert docstring.short_description == 'A very simple test'
    assert docstring.long_description == 'Long description.'
    assert len(docstring.long_description_lines) == 1

    doc3 = """
    A very simple test
    Long description.
    This module does this and that.

    Other paragraph.
    """
    docstring = parse(doc3)
    assert docstring.short_description

# Generated at 2022-06-21 11:56:54.440885
# Unit test for function parse
def test_parse():
    text = '''\
    The quick brown\n\n 
    fox jumps over\n\n 
    the lazy dog.\n\n 
    :param x: first param
    :param y: second param\n\n 
    :return: None\n\n
    :raises ValueError: if x is negative \n\n
    '''
    d = parse(text)
    assert d.short_description == "The quick brown"
    assert d.description == "  \nfox jumps over\n\n  \nthe lazy dog.\n\n  "
    assert d.params['x'].description == "first param"
    assert d.params['y'].description == "second param\n\n  "
    assert d.returns.description == "None\n\n"
    assert d

# Generated at 2022-06-21 11:57:05.415139
# Unit test for function parse
def test_parse():
    # This should return a DocString with no fields
    print("Test 1: ------------------")
    d = parse("")
    assert d.short_description == ""
    assert d.long_description == ""
    assert len(d.meta) == 0
    assert len(d.sections) == 0
    assert d.summary == ""

    # This should return a DocString with one field
    print("Test 2: ------------------")
    d = parse("This is the short description.\n\nThis is the long description.")
    assert d.short_description == "This is the short description."
    assert d.long_description == "This is the long description."
    assert len(d.meta) == 0
    assert len(d.sections) == 0
    assert d.summary == "This is the short description."

    # This should return a DocString

# Generated at 2022-06-21 11:57:09.056456
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring
    text = """
    Google style docstring
    Args:
    Returns:
    """
    docstring = parse(text, style=Style.Google)
    assert isinstance(docstring, GoogleDocstring)


# Generated at 2022-06-21 11:57:21.624295
# Unit test for function parse

# Generated at 2022-06-21 11:57:30.810232
# Unit test for function parse
def test_parse():
    text = """
    One line summary.

    More detailed description.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: Description of return value.
    :rtype: int

    """
    doc = parse(text)
    # 1
    print(doc.short_description)
    # 2
    print(doc.long_description)
    # 3
    print(doc.long_description_markup)
    # 4
    print(doc.parse_errors)
    # 5
    assert doc.has_errors
    # 6
    print(doc.return_annotation)
    # 7
    print(doc.return_annotation_markup)
    # 8

# Generated at 2022-06-21 11:57:36.909073
# Unit test for function parse
def test_parse():
    text = """
    This is a decription
    :param int val: Parameter value
    :param str name: Parameter name
    """
    docstring = parse(text)
    assert(docstring.short_description == "This is a decription")
    assert(len(docstring.params) == 2)
    assert(docstring.params[1].arg_name == "name")

# Generated at 2022-06-21 11:57:41.893235
# Unit test for function parse
def test_parse():
    text = '''
    Test a sentence.

    Test a sentence.
    '''
    assert parse(text)

# Test docstring parser with package level docstring
if __name__ == '__main__':
    import docstring_parser
    test_parse()

# Generated at 2022-06-21 11:57:43.332609
# Unit test for function parse
def test_parse():
    pass

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:57:55.567519
# Unit test for function parse
def test_parse():

    # test  parse(text: str, style: Style = Style.auto) -> Docstring
    # expected output is the same as input
    text = '''Returns True'''
    output = parse(text)
    assert text == output.body
    assert output.summary == 'Returns True'

    text = '''Return True on True'''
    output = parse(text)
    assert text == output.body
    assert output.summary == 'Return True on True'

    # test with capital letters
    text = '''Returns True'''
    output = parse(text)
    assert text == output.body
    assert output.summary == 'Returns True'

    # test with useless content
    text = '''This is a useless docstring'''
    output = parse(text)
    assert text == output.body

# Generated at 2022-06-21 11:58:03.949652
# Unit test for function parse
def test_parse():
    import pytest
    docstr = """Sample docstring.

Args:
    arg1 (int): The first argument.
    arg2 (Optional[str]): The second argument. Defaults to None.

Returns:
    bool: The return value. True for success, False otherwise.
    """
    doc = parse(docstr)
    with pytest.raises(ParseError) as excinfo:
        parse('fsdf', style='sphinx')
    assert str(excinfo.value) == 'Unknown style: sphinx'



# Generated at 2022-06-21 11:58:13.267746
# Unit test for function parse

# Generated at 2022-06-21 11:58:22.775923
# Unit test for function parse
def test_parse():
    d = parse('''some text''')
    assert d.short_description == d.full_description == 'some text'
    d = parse('''some text\n\nmore text''')
    assert d.short_description == 'some text'
    assert d.full_description == 'some text\n\nmore text'
    d = parse('''some text\n\nmore text\nmore text again''')
    assert d.short_description == 'some text'
    assert d.full_description == 'some text\n\nmore text'
    d = parse('''some text\n\nmore text\nmore text again\n\nmore more text''')
    assert d.short_description == 'some text'

# Generated at 2022-06-21 11:58:27.968151
# Unit test for function parse
def test_parse():
    def f():
        '''Sample docstring
        with two lines.

        More lines.'''
    assert parse(f.__doc__).short_description == 'Sample docstring\nwith two lines.'

# Test from command line
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:58:37.986503
# Unit test for function parse
def test_parse():
    doc = parse('''
    The quick brown fox jumps over the lazy dog
    
    Parameters
    ----------
    fox : str
        The fox 
    dog : str
        The dog
    
    Returns
    -------
    str
        A new string
    ''')
    assert doc.short_description == 'The quick brown fox jumps over the lazy dog'
    assert doc.params[0].arg_name == 'fox'
    assert doc.params[0].arg_type == 'str'
    assert doc.params[0].description == 'The fox'
    assert doc.params[1].arg_name == 'dog'
    assert doc.params[1].arg_type == 'str'
    assert doc.params[1].description == 'The dog'
    assert doc.returns.ret_type == 'str'

# Generated at 2022-06-21 11:58:49.600259
# Unit test for function parse
def test_parse():
    text = '''
    x:int, y:int
        Params:
            x (int): x-coordinate
            y (int): y-coordinate

        Returns:
            int: Euclidean distance
    '''
    doc = parse(text)
    params = doc.params

    assert len(params) == 2
    assert params[0].param_type == 'int'
    assert params[0].param_name == 'x'
    assert params[0].description == 'x-coordinate'
    #assert params[1].description == 'y-coordinate'

    assert len(doc.returns) == 1
    assert doc.returns[0].param_type == 'int'
    assert doc.returns[0].description == 'Euclidean distance'

# Generated at 2022-06-21 11:58:58.774983
# Unit test for function parse
def test_parse():
    # test for google
    test_google = """
    This function does something.
    Args:
        x (int): The x param.
        y (str): The y param.
    Returns:
        The return value. True for success, False otherwise.
    """
    ds = parse(test_google)
    assert ds.short_description == "This function does something."
    assert len(ds.params) == 2
    assert len(ds.returns) == 1
    assert ds.returns[0].type_name == "bool"
    assert ds.returns[0].description == "The return value. True for success, False otherwise."

    # test for numpy

# Generated at 2022-06-21 11:59:08.415832
# Unit test for function parse
def test_parse():
    text = '''
    Summary line.

    Extended description.

    Args:
        arg1: Description
        arg2: Description
        arg3: Description

    Returns:
        Description.
    '''

    docstring = parse(text, Style.google)
    assert docstring.summary == 'Summary line.'
    assert docstring.description == 'Extended description.'

    args = docstring.args
    assert len(args) == 3
    assert args[0].arg_name == 'arg1'
    assert args[0].description == 'Description'
    assert args[1].arg_name == 'arg2'
    assert args[1].description == 'Description'
    assert args[2].arg_name == 'arg3'
    assert args[2].description == 'Description'

    ret = docstring.returns
    assert ret

# Generated at 2022-06-21 11:59:17.202096
# Unit test for function parse
def test_parse():
    text = '''
    :param name: This is the name.

    :param request: The request object.
    :type request: :class:`django.http.HttpRequest`
    :returns: `HttpResponse` object

    '''
    style = Style.google
    ret = parse(text, style)
    print(ret)
    text = '''
    :param name: This is the name.

    :param request: The request object.
    :type request: :class:`django.http.HttpRequest`

    :returns: `HttpResponse` object

    '''
    ret = parse(text, style)
    print(ret)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:33.049871
# Unit test for function parse
def test_parse():
    docstring = """Example of Google style.

Args:
    param1: The first parameter.
    param2: The second parameter.
Returns:
    True if successful, False otherwise.
Raises:
    ValueError: If `param2` is equal to `param1`.
"""

    doc = parse(docstring)
    assert doc.short_description == "Example of Google style."
    assert doc.long_description == ""
    assert len(doc.params) == 2
    assert doc.params["param1"].arg_name == "param1"
    assert doc.params["param1"].description == "The first parameter."
    assert doc.params["param2"].arg_name == "param2"
    assert doc.params["param2"].description == "The second parameter."
    assert len(doc.returns) == 1


# Generated at 2022-06-21 11:59:42.460141
# Unit test for function parse
def test_parse():
    text = '''
    Description
    -----------
    This is a test docstring

    Arguments
    ---------
    arg1: str
        This is the first argument

    Returns
    -------
    str
        Return value

    Raises
    ------
    ValueError
        Error raised when something goes wrong
    '''
    result = parse(text)
    assert isinstance(result.description, str)
    assert isinstance(result.args, list)
    assert isinstance(result.raises, list)
    assert isinstance(result.returns, list)
    assert isinstance(result.meta, dict)
    assert result.description == 'This is a test docstring'
    assert result.args[0].name == 'arg1'
    assert result.args[0].type == 'str'

# Generated at 2022-06-21 11:59:49.239785
# Unit test for function parse
def test_parse():

    text = '''
    This is a multi-line docstring.

    Docstring continues with few empty lines.
        - First item
        - Second item
    '''
    parsed = parse(text)
    assert(parsed.short_description == 'This is a multi-line docstring.')
    assert(parsed.long_description == 'Docstring continues with few empty lines.')
    assert(parsed.meta == OrderedDict([('First item', None), ('Second item', None)]))

# Generated at 2022-06-21 12:00:01.219728
# Unit test for function parse
def test_parse():
    docstring = r"""
    
    
    
    
    
    
    This is a sample docstring with a summary.
    
    Args:
        arg1 : this is the first argument with a summary
        arg2 : this is the second argument with a summary
    
    Returns:
        None
    
    
    
    
    
    
    """
    docstring_parser = parse(docstring)
    print("Summary: " + docstring_parser.summary)

    parameter_table = ""
    for parameter in docstring_parser.meta["args"]:
        parameter_table += "| " + parameter.arg_name + " | " + parameter.description + " |\n"
    print("Arguments:\n" + parameter_table)

    return_table = ""

# Generated at 2022-06-21 12:00:03.638777
# Unit test for function parse
def test_parse():
    text = '''
    some text
    '''
    docstring = parse(text)
    print(docstring.short_description)
# test_parse()

# Generated at 2022-06-21 12:00:06.201571
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param int a: this is a
    :param int a: this is b
    '''
    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:17.272548
# Unit test for function parse
def test_parse():
    from mock import parse_sphinx_docstring, parse_google_docstring

    docstr = """Module docstring

"""

    docstr2 = """Summary line.

Extended description.

Args:
    arg_a: description
    arg_b (int): description

Returns:
    str: description

Raises:
    ValueError: description
"""
    assert parse(docstr) == Docstring(summary='', description='', meta=None)
    assert parse(docstr2) == parse_google_docstring(docstr2)
    assert parse(docstr2, style=Style.google) == parse_google_docstring(docstr2)
    assert parse(docstr2, style=Style.numpy) == parse_sphinx_docstring(docstr2)



# Generated at 2022-06-21 12:00:19.881570
# Unit test for function parse
def test_parse():
    text = parse("""Hello world!""")
    assert text.summary == "Hello world!"
    assert text.details == ""
    assert text.meta['parameters']['a'] == ""

# Generated at 2022-06-21 12:00:30.293036
# Unit test for function parse
def test_parse():
    text1='''
        Create a new instance of a crontab.

        :param user: (optional) the user whose crontab this will manipulate
        :returns: the newly created crontab object
        :rtype: Crontab
        '''
    d = parse(text1)
    print(d.summary)
    print(d.meta)
    print(d.params)
    print(d.returns)
    print(d.return_type)
    print(d.raises)
    print(d.see_also)
    print(d.notes)
    print(d.references)
    print(d.examples)


# Generated at 2022-06-21 12:00:35.488694
# Unit test for function parse
def test_parse():
    docstring = \
    """
    This function does something.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    assert isinstance(parse(docstring), Docstring)

test_parse()

# Generated at 2022-06-21 12:00:49.078833
# Unit test for function parse
def test_parse():
    docstring = """Summary line here.
    Extended description here.
    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
    Returns:
        bool: Description of return value
    """
    r = parse(docstring)
    assert r.arguments == [{'name': 'arg1', 'type': 'int', 'description': 'Description of arg1'},
                           {'name': 'arg2', 'type': 'str', 'description': 'Description of arg2'}]
    assert r.returns == {'type': 'bool', 'description': 'Description of return value'}
    assert r.short_description == 'Summary line here.'
    assert r.long_description == 'Extended description here.'

# Generated at 2022-06-21 12:00:58.868165
# Unit test for function parse
def test_parse():
    test_text = (
        "Test to see if this function works.\n"
        "This is a second line of the description"
        "It should allow spaces after periods and newlines between sentences"
    )

    assert parse(test_text).short_description == "Test to see if this function works."
    assert parse(test_text).long_description == "This is a second line of the descriptionIt should allow spaces after periods and newlines between sentences"

    test_text_two = (
        "First line of description.\n"
        "Second line of description.\n"
        "Third line of description."
    )

    assert parse(test_text_two).short_description == "First line of description."
    assert parse(test_text_two).long_description == "Second line of description.Third line of description."



# Generated at 2022-06-21 12:01:09.996537
# Unit test for function parse
def test_parse():
    # Parses standard docstring
    ds = '''\
    foo

    This is a docstring for the function foo.
    From here you can reach the bar function by foo.bar()

    :param x: optional x
    :type x: int
    :return: the answer
    :rtype: int
    '''

    doc = parse(ds)
    assert doc.short_description == 'foo'
    assert doc.long_description == '\nThis is a docstring for the function foo.\nFrom here you can reach the bar function by foo.bar()'
    assert doc.params['x'].type == 'int'

    # Parses standard docstring with no indentation

# Generated at 2022-06-21 12:01:20.338875
# Unit test for function parse
def test_parse():
    assert parse('hello, world') == "hello, world"
    assert parse("This is a test\nstring.") == "This is a test string."
    assert parse("Hello, world.\nThis is a test string.") == "Hello, world. This is a test string."
    assert parse("Hello, world.\n\nThis is a test string.") == "Hello, world. This is a test string."
    assert parse("Hello, world.\nThis is a test string.\n\n") == "Hello, world. This is a test string."
    assert parse("\nHello, world.\nThis is a test string.\n\n") == "Hello, world. This is a test string."

# Generated at 2022-06-21 12:01:28.902331
# Unit test for function parse
def test_parse():
    assert parse('Hello world') == Docstring(summary='Hello world')
    assert parse('Hello\nworld').summary == 'Hello world'
    assert parse('Hello\r\nworld').summary == 'Hello world'
    assert parse('Hello\r\n\r\nworld', 'numpy').summary == 'Hello  world'
    # print(parse('Hello\nworld', 'restructuredtext').description == 'world')

if __name__ == '__main__':
    test_parse()
    print('Test finished')

# Generated at 2022-06-21 12:01:30.267144
# Unit test for function parse
def test_parse():
    assert True


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:01:40.453833
# Unit test for function parse
def test_parse():
    text = '''
        FOO BAR
        ~~~~~~~

        Key:: Value

        This is **reST**.

        No args.

        :param arg1: Description of `arg1`.
        :param arg2: Description of `arg2`.
        :returns: Description of the return value.
        :raises Exception: If something goes wrong.

        Examples
        --------
        This is a long example.

        >>> print(hello)
        hello, world

        But a short one is also good.
        '''

# Generated at 2022-06-21 12:01:47.005560
# Unit test for function parse
def test_parse():
    text = """Short summary line.

Extended description, which can go to multiple lines.

Parameters
----------
arg1 : int
    Description of `arg1`.
arg2 : str, optional
    Description of `arg2`, defaults to 'baz'.

Returns
-------
out : int
    Description of return value.

Raises
------
ValueError
    If `arg2` is equal to `arg1`.
"""
    docstring = parse(text)
    assert docstring.short_description == "Short summary line."
    assert (
        docstring.long_description
        == "Extended description, which can go to multiple lines."
    )

# Generated at 2022-06-21 12:01:56.774852
# Unit test for function parse
def test_parse():
    from .example_google import text, docstring
    from .test_google import test1_docstring
    assert parse(text) == docstring, 'parse failed!'
    assert parse(text, Style.google) == docstring, 'parse failed!'
    assert parse(text, 1) == docstring, 'parse failed!'
    assert parse(text, Style.auto) == docstring, 'parse failed!'
    assert parse(text, Style.numpy) == test1_docstring, 'parse failed!'
    assert parse(text, 0) == test1_docstring, 'parse failed!'
    return 'test_parse done!'

if __name__ == '__main__':
    print(test_parse())
    print(parse.__doc__)
    print(help(parse))

# Generated at 2022-06-21 12:01:58.747966
# Unit test for function parse
def test_parse():
    docstring_parsed = parse(docstring)
    print(docstring_parsed)

test_parse()

# Generated at 2022-06-21 12:02:09.182191
# Unit test for function parse
def test_parse():
    print("parse function testing start...")
    # Sample docstring
    sample = """\
        One line summary.

        Extended description.

        :param arg_1: Description of arg_1
        :param arg_2: Description of arg_2
        :type arg_1: str
        :type arg_2: str
        :returns: Description of return value
        :rtype: int
        """
    # Test style auto
    print("\tstyle auto testing start")
    result = parse(sample)
    assert result.summary == "One line summary."
    assert result.description == "Extended description."
    assert len(result.meta) == 5
    assert result.meta["arg_1"] == "Description of arg_1"
    assert result.meta["arg_2"] == "Description of arg_2"

# Generated at 2022-06-21 12:02:18.802639
# Unit test for function parse
def test_parse():
	text = '''\
	This is a test function.

	Args:
		a: the first parameter
	Returns:
		b: the second parameter
	Raises:
		ValueError: if `a` is zero

	'''

	text2 = '''\
	This is a test function.

	:param a: the first parameter
	:returns: b
	:raises ValueError: if `a` is zero

	'''

	my_docstring = parse(text)
	my_docstring2 = parse(text2)

	print(my_docstring.short_description)
	print(my_docstring.long_description)
	print(my_docstring.returns)
	print(my_docstring.other)
	print(my_docstring.errors)

# Generated at 2022-06-21 12:02:30.520793
# Unit test for function parse
def test_parse():
    """
    Test correctness of function parse

    :return: None
    """

    import pytest


# Generated at 2022-06-21 12:02:32.730564
# Unit test for function parse
def test_parse():
    docstring = """
    This is a test function
    """
    style = parse(docstring)
    print(style)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:02:36.163122
# Unit test for function parse
def test_parse():
	assert parse('''
	
	''') == Docstring(summary="", description="", params=None, returns=None, examples=None)

if __name__ == '__main__':
	test_parse()
	print('All test were successfully passed')

# Generated at 2022-06-21 12:02:45.765631
# Unit test for function parse
def test_parse():
    ds = parse("""
        A function that sums two variables.

        :param x: first variable
        :param y: second variable
        :returns: sum of the two variables
        """)
    assert ds.short_description == 'A function that sums two variables.'
    assert ds.long_description == ''
    assert len(ds.params) == 2
    assert ds.returns.arg_type == 'return'
    assert ds.returns.type == ''
    assert ds.returns.description == 'sum of the two variables'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:02:50.030368
# Unit test for function parse
def test_parse():
    docstring = '''Line1 \nLine2
    line3
    Line4'''
    style = Style.google
    parse(docstring, style)
    yapf_test_helper.assert_that(parse(docstring, style), yapf_test_helper.IsEqual('a'))

# Generated at 2022-06-21 12:02:57.541137
# Unit test for function parse
def test_parse():
    text = """
    Test parse function
    :returns:
    """

    text2 = """
    Test parse function
    :returns:
    :returns1:
    """

    style = Style.auto
    result = parse(text, style)
    result1 = parse(text2, style)
    assert result.summary == "Test parse function"
    assert result.meta['returns'] == ""
    assert result1.meta['returns'] == ""
    assert result1.meta['returns1'] == ""



# Generated at 2022-06-21 12:03:00.824419
# Unit test for function parse
def test_parse():
    parseable = '''
    Get the value of the first header

    :header: header
    :param: name the header name
    :returns str: header value
    '''
    print(parse(parseable))

# Generated at 2022-06-21 12:03:03.307691
# Unit test for function parse
def test_parse():
    text = """Test the docstring parsing."""
    style = Style.google
    assert parse(text,style)==parse(text)

# Generated at 2022-06-21 12:03:13.266787
# Unit test for function parse
def test_parse():
    from pprint import pprint
    import re
    import json

    with open("data/docstrings.json", "r") as f:
        docstrings = json.load(f)

    for k, v in docstrings.items():
        assert isinstance(k, str)
        assert isinstance(v, str)
        c = parse(v)

        pprint({"name": k, "docstring": v, "parsed": c.as_dict()})
        print("-" * 20)

        # Strip all whitespace, except newlines.
        expected = re.sub("[^\S\n]+", " ", v)
        actual = re.sub("[^\S\n]+", " ", str(c))
        assert expected == actual

# Generated at 2022-06-21 12:03:20.275260
# Unit test for function parse
def test_parse():
    text = """\
Summary

A longer description
of the module.

:param param1: explain
:type param1: int
:param param2: explain
:type param2: str
Returns: explain
"""
    expected = Docstring(
        summary='Summary',
        description='A longer description\nof the module.',
        params=[('param1', 'explain', 'int'),
                ('param2', 'explain', 'str')],
        return_='explain')


# Generated at 2022-06-21 12:03:31.521579
# Unit test for function parse
def test_parse():
    from docstring_parser import FunctionDocstring
    from docstring_parser.common import Parameter

    docstring = """Calculate the product of two numbers

    Args:
        a: First number.
        b (int): Second number.
    """

    assert isinstance(parse(docstring), FunctionDocstring)
    assert parse(docstring).short_description == 'Calculate the product of two numbers'
    assert parse(docstring).long_description is None
    assert parse(docstring).params == {'a': Parameter('a', 'First number.'),
                                       'b': Parameter('b', 'Second number.', type='int')}
    assert parse(docstring).returns == Parameter(None, None)



# Generated at 2022-06-21 12:03:38.264197
# Unit test for function parse
def test_parse():
    text = """
    This is a normal paragraph.
    This is the first paragraph of the multi-line docstring.
    This is the second paragraph of the multi-line docstring.

    Attributes:
        attr1 (str): Description of `attr1`.
        attr2 (str): Description of `attr2`.

    """
    parse_result = parse(text=text, style=Style.numpy)
    return parse_result

if __name__ == "__main__":
    print(test_parse())

# Generated at 2022-06-21 12:03:50.079407
# Unit test for function parse
def test_parse():
    raw_docstring = '''
Calculate the square of a number
Args:
    val (int): the value to be squared
Returns:
    val^2
Raises:
    ZeroDivisionError: If val is 0
'''
    # Without specifying style
    docstring = parse(raw_docstring)
    assert len(docstring.meta) == 4
    assert docstring.short_description == 'Calculate the square of a number'
    assert len(docstring.params) == 1
    assert docstring.params[0].description == 'the value to be squared'
    assert docstring.params[0].argument_type == 'int'
    assert docstring.params[0].name == 'val'
    assert docstring.returns.description == 'val^2'
    assert len(docstring.raises) == 1

# Generated at 2022-06-21 12:03:58.449509
# Unit test for function parse
def test_parse():
    s = """\
    A function to sum up a and b.

    :param a: first number
    :param b: second number
    :return: sum of a and b
    :rtype: int
    """
    assert parse(s) == Docstring(
        summary="A function to sum up a and b.",
        body="",
        parameters=["param a: first number", "param b: second number"],
        return_=":return: sum of a and b",
        returns="int",
        meta={},
    )


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:04:09.617091
# Unit test for function parse
def test_parse():
    text = '''
        """This function adds two numbers.

        :param a: the first number
        :param b: the second number
        :returns: the sum

        **Usage**

        >>> add(1, 1)
        2
        >>> add(5, 5)
        10
        """
    '''
    res = parse(text)
    print(res)
    assert res.short_description == 'This function adds two numbers.'
    assert res.long_description == 'This function adds two numbers.\n\n'
    assert len(res.params) == 2
    assert res.params[0].arg_name == 'a'
    assert res.params[0].type_name == 'the first number'
    assert res.params[1].arg_name == 'b'
    assert res.params[1].type_

# Generated at 2022-06-21 12:04:13.973141
# Unit test for function parse
def test_parse():
    text = """
          This is a command to do something.

          Args:
              param1: The first parameter.
              param2: The second parameter.
              param3: The third parameter.

          Returns:
              This is a description of what is returned.

          Raises:
              ValueError: If `param2` is equal to `param1`.

          """    
    
    test = parse(text)
    assert type(test) is not None
    
test_parse()

# Generated at 2022-06-21 12:04:17.871892
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    assert (isinstance(parse("Example docstring"), Docstring))


if __name__ == "__main__":
    test_parse()
    print("Everything passed")

# Generated at 2022-06-21 12:04:27.533425
# Unit test for function parse
def test_parse():
    """test the parse function via unittest"""
    import unittest

    class TestParsing(unittest.TestCase):
        """class for test the function parse"""

        def test_parse(self):
            """test for parse"""
            style = Style.sphinx
            text = '''print '''
            ds = parse(text, style)
            self.assertEqual(ds.short_description, '')
            self.assertEqual(ds.long_description, None)
            self.assertEqual(ds.meta, {})
            self.assertEqual(ds.returns, None)
            self.assertEqual(ds.errors, [])

            text = '''
            print '''
            ds = parse(text, style)

# Generated at 2022-06-21 12:04:39.722467
# Unit test for function parse
def test_parse():
    assert parse('Hello world') == Docstring(
        content='Hello world',
        meta={},
        description='Hello world',
        tags=[],
    )
    with pytest.raises(ParseError):
        parse('Hello world\n')
    assert parse('Hello world\n', style=Style.numpy) == Docstring(
        content='Hello world\n',
        meta={},
        description='Hello world',
        tags=[],
    )
    with pytest.raises(ParseError):
        parse('Hello\nworld', style=Style.numpy)
    assert parse('Hello\nworld', style=Style.google) == Docstring(
        content='Hello\nworld',
        meta={},
        description='Hello world',
        tags=[],
    )

# Generated at 2022-06-21 12:04:45.467608
# Unit test for function parse
def test_parse():
    assert parse('Hello world') == Docstring(
        short_description='Hello world',
        long_description=None,
        extra_sections=None)

    assert parse('Hello world\n\nGoodbye cruel world') == Docstring(
        short_description='Hello world',
        long_description='Goodbye cruel world',
        extra_sections=None)

    assert parse(
        'Hello world\n\nGoodbye cruel world\n\n:param str name: The name of some person') == Docstring(
            short_description='Hello world',
            long_description='Goodbye cruel world',
            extra_sections=[
                ('Parameters', [('name', 'str', None, 'The name of some person')])
            ])


# Generated at 2022-06-21 12:04:46.835749
# Unit test for function parse
def test_parse():
    assert parse("") == parse('')

# Generated at 2022-06-21 12:04:49.257532
# Unit test for function parse
def test_parse():
    string = """\
    This is a simple function

    Args:
        arg0 (int): some arg
        arg1 (str): some other arg

    Returns:
        int: some int return value
    """
    dd = parse(string)
    print(dd.short_description)
    print(dd.long_description)
    print(dd.args)
    print(dd.returns)


# Generated at 2022-06-21 12:04:55.437365
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Return
    from docstring_parser.styles import Google


# Generated at 2022-06-21 12:05:06.509909
# Unit test for function parse