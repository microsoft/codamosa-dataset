

# Generated at 2022-06-21 11:55:12.164777
# Unit test for function parse
def test_parse():

    # Test for invalid input
    try:
        parse('')
    except ParseError:
        pass
    except BaseException as e:
        raise e

    # Test for a valid input
    try:
        parse('arg1: type: description')
    except BaseException as e:
        print(e)
        raise e

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:22.880681
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description of function.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`

Returns
-------
bool
    Description of return value

"""

    docstring = parse(text)

    assert docstring.summary == "Summary line."

    # String escape is used to keep indentation
    assert docstring.description == r"""Extended description of function.

"""

    assert docstring.returns.type_name == "bool"
    assert docstring.returns.description == "Description of return value"

    assert docstring.params['arg1'].arg_name == "arg1"
    assert docstring.params['arg1'].type_name == "int"

# Generated at 2022-06-21 11:55:27.279792
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Test") == Docstring("Test")
    assert parse("""
    Test
    """) == Docstring("Test")
    assert parse("""
    :param x: the thing
    """) == Docstring("", Params({'x': 'the thing'}))
    assert parse("""
    :type x: int
    """) == Docstring("", Types({'x': 'int'}))

# Generated at 2022-06-21 11:55:29.099415
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 11:55:38.975416
# Unit test for function parse
def test_parse():
    docstr = '''Parses the docstring into its components.
        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
    '''
    parts = parse(docstr)
    assert parts.short_description == 'Parses the docstring into its components.'
    assert parts.long_description == ''
    assert parts.meta['returns'][0]['type'] == 'parsed docstring representation'
    assert parts.meta['param']['text']['type'] == 'docstring text to parse'
    assert parts.meta['param']['style']['type'] == 'docstring style'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:46.276693
# Unit test for function parse
def test_parse():
    text = "Summary line.\n\nDescription.\n:param name: Description.\n:type name: str\n:raises exception: Description"
    d = parse(text)
    assert d.summary == 'Summary line.'
    assert d.description == 'Description.'
    assert d.params['name'].name == 'name'
    assert d.params['name'].description == 'Description.'
    assert d.raises['exception'].name  == 'exception'
    assert d.raises['exception'].description == 'Description'

# Generated at 2022-06-21 11:55:50.048110
# Unit test for function parse

# Generated at 2022-06-21 11:55:59.127860
# Unit test for function parse
def test_parse():
    text = """
    This is a multiline docstring with no directive in it.

    Params:
        param1: The first parameter.
        param2: The second parameter.
    """
    assert parse(text).summary == "This is a multiline docstring with no directive in it."

    text = """
    :param int param1: The first parameter.
    :param str param2: The second parameter.
    :returns: Description of return value.
    :rtype: int
    """
    assert parse(text).params["param1"].desc == "The first parameter."


# Generated at 2022-06-21 11:56:03.351708
# Unit test for function parse
def test_parse():
    text = """
    Returns:
        The answer.
    """
    doc = parse(text)
    print(doc.meta['return'])

#test_parse()

if __name__ == "__main__":
    text = """
    Returns:
        The answer.
    """
    doc = parse(text)
    print(doc.meta['return'])

# Generated at 2022-06-21 11:56:14.625102
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    text_1 = '''\
        Docstring with no sections in epytext style
        '''

    text_2 = '''\
        Docstring with no sections in google style
        '''

    text_3 = '''\
        Docstring with no sections in numpy style
        '''

    text_4 = '''\
        Docstring with no sections in reST style
        '''

    text_5 = '''\
        Docstring with no sections in sphinx style
        '''

    text_6 = '''\
        @param text: docstring text to parse
        @param style: docstring style
        @returns: parsed docstring representation
        '''

    doc_1 = parse(text_1)
    doc_2 = parse(text_2)
   

# Generated at 2022-06-21 11:56:29.001370
# Unit test for function parse
def test_parse():
    text = '''
    Summary line.

    Extended description

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    int
        Description of return value
    '''

    docstring = parse(text)

    assert docstring.meta['summary'] == 'Summary line.'
    assert docstring.meta['description'] == 'Extended description'

    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[1].arg_name == 'arg2'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[1].type_name == 'str'

# Generated at 2022-06-21 11:56:39.627947
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.sphinx import Parser
    from docstring_parser.common import Param
    from docstring_parser.common import Return
    from docstring_parser.common import Note
    from docstring_parser.common import Warning
    from docstring_parser.common import Raises
    from docstring_parser.common import Author
    from docstring_parser.common import Section
    from docstring_parser.common import Meta
    from docstring_parser.common import Docstring
    from docstring_parser.common import MetaField
    from docstring_parser.styles import Style


# Generated at 2022-06-21 11:56:50.578136
# Unit test for function parse
def test_parse():
    """
    >>> def test(style, text, expected):
    ...     ret = parse(text, style)
    ...     got = repr(ret)
    ...     if got != expected:
    ...         print(style, got)
    ...         raise AssertionError(f'{style}:\n{text}\nexpected\n{expected}')
    ...
    >>> test(Style.auto,
    ... """

# Generated at 2022-06-21 11:56:59.831968
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = '''\
        This is the summary.
        '''
    ds = parse(text)
    assert ds.summary == 'This is the summary.'

    text = '''\
        This is the summary.

        This is the description.
        '''
    ds = parse(text)
    assert ds.summary == 'This is the summary.'
    assert ds.description == 'This is the description.'

    text = '''\
        This is the summary.

        :param int x:
            Parameter x
        '''
    ds = parse(text)
    assert ds.summary == 'This is the summary.'
    assert len(ds.params) == 1
    assert ds.params[0].name == 'x'

# Generated at 2022-06-21 11:57:07.123157
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, parse


    docstring = r'''The format of the whole string
    has to be:
    :param x: first value
    :type x: float
    :param y: second value
    :type y: float
    :return: The sum of x and y
    :rtype: float
    '''
    docstring = parse(docstring)
    print(docstring)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:57:18.160012
# Unit test for function parse
def test_parse():
    from . import common

    # Test auto detection
    text = """\
    Short summary.

    Longer description that spans
    multiple lines.

    Args:
        param1 (int): Description of param1
        param2 (str): Description of param2

    Returns:
        bool: Description of return value

    Raises:
        AttributeError: The text raises AttributeError.
    """
    docstring = parse(text)
    common.compare(docstring, text)

    # Test no description
    text = """\
    Args:
        param1 (int): Description of param1
        param2 (str): Description of param2

    Returns:
        bool: Description of return value

    Raises:
        AttributeError: The text raises AttributeError.
    """
    docstring = parse(text)
    common

# Generated at 2022-06-21 11:57:22.821370
# Unit test for function parse
def test_parse():
    text = """Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1` (with type annotation).
    arg2 : str
        Description of `arg2`
    arg3 : :obj:`list` of :obj:`str`
        Description of `arg3`

    Returns
    -------
    int
        Description of return value

    Raises
    ------
    AttributeError
        The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError
        If `arg2` is equal to `arg1`.

    See Also
    --------
    some_other_object_with_section : This is a cross-reference
    """
    doc = parse(text)
    assert 'Summary line.' == doc.short_description


# Generated at 2022-06-21 11:57:26.885764
# Unit test for function parse
def test_parse():
    """Should parse all available styles."""

    for _, style in STYLES.items():
        try:
            style('')
        except ParseError:
            # Middleman style does not support empty docstrings
            pass
        else:
            assert parse(style('').docstring).style == style

# Generated at 2022-06-21 11:57:37.543998
# Unit test for function parse
def test_parse():

    # Parse with no style and incorrect style
    try:
        parse("")
    except Exception as e:
        assert isinstance( e, ParseError)
        assert e.msg == "Style is required"
    try:
        parse("", style="NonexistingStyle")
    except Exception as e:
        assert isinstance( e, ParseError)
        assert e.msg == "Unknown style"
    assert parse("", Style.numpy) is None

    # Parse with style auto and incorrect style
    try:
        parse("", style="Auto")
    except Exception as e:
        assert isinstance( e, ParseError)
        assert e.msg == "Style is required"

# Generated at 2022-06-21 11:57:48.886690
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Parameter
    from docstring_parser.styles import NumpyStyle
    docstring = "One line summary.\n\n    Extended summary.\n    \n    Parameters\n    ----------\n    arg1 : int\n        Description of `arg1`\n    arg2 : str\n        Description of `arg2`.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n"


# Generated at 2022-06-21 11:57:59.535334
# Unit test for function parse
def test_parse():
    text = '''\
        Short summary.

        Long description.

        Args:
            param1: The first parameter.
            param2: The second parameter.

        Returns:
            True if successful, False otherwise.

        .. note::
            An example of a note.

        '''
    assert parse(text).short_description == 'Short summary.'
    assert parse(text).long_description == 'Long description.'


# Generated at 2022-06-21 11:58:03.092506
# Unit test for function parse
def test_parse():
    """Unit test for parsing."""
    ts = """
        """
    d = parse(ts)
    print("status:", d)

# Generated at 2022-06-21 11:58:09.771546
# Unit test for function parse
def test_parse():
    text = 'test doc string'
    a = parse(text)
    assert type(a) == Docstring
    assert a.brief == 'test doc string'
    assert a.description == ''
    assert a.long_description == ''
    assert a.returns == ''
    assert len(a.meta) == 0
    assert len(a.params) == 0
    assert len(a.raises) == 0
    assert len(a.keywords) == 0
    
    
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:58:22.344930
# Unit test for function parse
def test_parse():
    text = """Summary line here.

Formatted description of class/function here.

Args:
    arg1 (int): Description of `arg1`
    arg2 (str): Description of `arg2`

Returns:
    bool: Description of return value.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `arg2` is equal to `arg1`.

"""
    parsed = parse(text, style=Style.google)
    assert parsed.short_description == "Summary line here."
    assert parsed.long_description == "Formatted description of class/function here.\n"
    assert isinstance(parsed.long_description, str)

# Generated at 2022-06-21 11:58:30.485821
# Unit test for function parse
def test_parse():
    s = '''
    :param option1: option1 description
    :param option2: option2 description
    :returns: description
    '''
    result1 = parse(s)
    result2 = parse(s, Style.google)
    result3 = parse(s, Style.numpy)
    result4 = parse(s, Style.auto)
    assert type(result1) == Docstring
    assert type(result2) == Docstring
    assert type(result3) == Docstring
    a

# Generated at 2022-06-21 11:58:39.318974
# Unit test for function parse
def test_parse():
    text = """Type-inference-based automatic differentiation in pure Python.
    
    :param x: input scalar or array.
    :param jacobian: bool, default is False
    :raises: ZeroDivisionError
    :return: dervative of scalar or array
    """

    text_numpy = """
    test_function(func, x, args=(), kwargs={},
                  chunk_size=10, progress_bar=True,
                  verbose=0)
    """
    text_google = """
    This is a test for google style
    
    Args:
        x: the input
    """
    import pprint
    pprint.pprint(parse(text))
    pprint.pprint(parse(text_numpy))
    pprint.pprint(parse(text_google))




# Generated at 2022-06-21 11:58:51.533087
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.reST import parse

    text = '''\
    Hello
    There
    '''
    docstring = parse(text)
    assert docstring.short_description == 'Hello'
    assert docstring.long_description == 'There\n'

    text = '''\
    Hello
    There
    '''
    docstring = parse(text)
    assert docstring.short_description == 'Hello'
    assert docstring.long_description == 'There\n'

    text = '''\
    Hello
    :returns: the return
    '''
    docstring = parse(text)
    assert docstring.short_description == 'Hello'
    assert docstring.long_description == ''
    assert docstring.returns.type_name == 'the return'

# Generated at 2022-06-21 11:58:58.575241
# Unit test for function parse
def test_parse():
	text = '''"""The main parsing routine."""'''
	style_auto = 'auto'
	style_sphinx = 'sphinx'
	style_numpy = 'numpy'
	style_google = 'google'
	style_pep = 'pep'

	assert parse(text, style_auto), "auto"
	assert parse(text, style_sphinx), "sphinx"
	assert parse(text, style_numpy), "numpy"
	assert parse(text, style_google), "google"
	assert parse(text, style_pep), "pep"

test_parse()

# Generated at 2022-06-21 11:59:02.229425
# Unit test for function parse
def test_parse():
    text = """
    My first docstring.
    """
    docstring = parse(text=text)
    assert docstring.short_description == "My first docstring."

test_parse()

# Generated at 2022-06-21 11:59:09.277647
# Unit test for function parse
def test_parse():
    docstr = '''
    This is a docstring.

    :param name: Name to print
    :param state: State to print
    '''
    parsed_docstr = parse(docstr, style=Style.google)

    assert parsed_docstr.short_description == 'This is a docstring.'
    assert len(parsed_docstr.long_description) == 0
    assert len(parsed_docstr.meta) == 2
    assert parsed_docstr.meta['param']['name'] == 'Name to print'
    assert parsed_docstr.meta['param']['state'] == 'State to print'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:20.567452
# Unit test for function parse
def test_parse():
    docstring1 = """\
    Test for parse function.

    Args:
        name (str): The name of the person.

    Returns:
        bool: The return value. True for success, False otherwise.\
    """
    assert parse(docstring1).as_dict() == {'Args': [('name', 'str', None, 'The name of the person.')], 'Returns': [('bool', None, 'True for success, False otherwise.')]}

# Generated at 2022-06-21 11:59:26.598784
# Unit test for function parse
def test_parse():
	text = """
	primes = get_primes()

	first_hundred_primes = primes[:100]
	print(first_hundred_primes)
	"""
	parse(text, style = Style.google)
	

	text = """
	primes = get_primes()

	first_hundred_primes = primes[:100]
	print(first_hundred_primes)
	"""
	parse(text, style = Style.numpy)
	

	text = """
	primes = get_primes()

	first_hundred_primes = primes[:100]
	print(first_hundred_primes)
	"""
	parse(text, style = Style.pep257)

# Generated at 2022-06-21 11:59:31.616539
# Unit test for function parse
def test_parse():
    text="""\
This is the first line
This is the second line.
This is the third line.
"""
    doc = parse(text, style=Style.google)
    print(doc.__dict__)
    a = 1
# ------------------------------------------------------------------------------
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:41.447088
# Unit test for function parse
def test_parse():
	# Test case 1: parse a docstring with style auto
	sample_docstring = '''This is a small example
						:param str a: This is a test param
						:return: This is a test return
						:rtype: str
						:raises ValueError: An error has occurred
						:raises TypeError: This is a test type error
						:author: Ting
						:date: 12/07/2020'''
	style = Style.auto
	result = parse(sample_docstring, style)
	assert result.short_description == 'This is a small example'
	assert result.long_description == None

# Generated at 2022-06-21 11:59:45.033732
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google
    text = """
        This is a module docstring.
        It is parsed, but not as a docstring.
        """
    assert str(parse(text, style=Google)) == str(Google(text))

# Generated at 2022-06-21 11:59:48.903003
# Unit test for function parse
def test_parse():
    docstring = '''
    This is the first line.

    This is the second line.
    '''
    assert parse(docstring).short_description == 'This is the first line.'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:55.300733
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Meta
    from docstring_parser.styles import NumpyStyle
    docstring_format = NumpyStyle(' ')
    mystring = ''':param int i: some parameter
:raises TypeError: if i is not integer
:returns: a square
'''
    assert parse(mystring,style='numpy') == docstring_format(mystring)


# Generated at 2022-06-21 12:00:00.755315
# Unit test for function parse
def test_parse():
    docstring_text = """
    """
    # Use `parse` to parse docstring
    docstring = parse(docstring_text)
    print(docstring)

# -----------------------------------------------------------------------------
# Main script
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    # Unit test for function parse
    test_parse()

# Generated at 2022-06-21 12:00:08.577686
# Unit test for function parse
def test_parse():
    header = '''Summary line should be in the first line
    Extends summary to the second line
    The body can continue here.'''

    parameters = ''':param foo: The parameter foo
    :type foo: int
    :param bar: The parameter bar
    :type bar: str'''

    returns = ''':returns: The return value
    :rtype: str'''

    raw = '\n'.join([header, parameters, returns])
    docstring = parse(raw)
    print(docstring)
    assert(docstring.summary == header)
    assert(docstring.parameters['foo'] == 'The parameter foo')
    assert(docstring.parameters['bar'] == 'The parameter bar')
    assert(docstring.returns == 'The return value')


# Generated at 2022-06-21 12:00:14.939859
# Unit test for function parse
def test_parse():
    text = """
    This is a test for unit test.
    Args:
        x: test string
    Returns:
        test integer
    """
    docstring = parse(text)
    assert docstring.long_description == "This is a test for unit test."
    assert docstring.short_description == "This is a test for unit test."
    assert docstring.args['x'] == "test string"
    assert docstring.returns == "test integer"

# Generated at 2022-06-21 12:00:28.356510
# Unit test for function parse
def test_parse():
    doc = """One liner summary

extended summary

:param arg1: param1
:param arg2: param2
:returns: return
"""
    d = parse(doc)
    assert d.short_description == "One liner summary"
    assert d.blankline == True
    assert d.long_description == "extended summary"
    assert d.return_annotation == "return"
    assert d.meta['param1']['arg'] == "arg1"
    assert d.meta['param2']['arg'] == "arg2"


# Generated at 2022-06-21 12:00:34.461471
# Unit test for function parse
def test_parse():
    d = parse('''\
    Deobfuscate and reformat all of the javascript in the given files that,
    when deobfuscated, match the given regular expression.''')
    assert d.short_description == 'Deobfuscate and reformat all of the javascript in the given files that, when deobfuscated, match the given regular expression.'
    assert d.long_description == None

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:00:46.162754
# Unit test for function parse
def test_parse():
    s = """Testing

    :param x: something

  23  """
    doc = parse(s)
    assert (doc.short_description == "Testing")
    assert (doc.long_description == "")
    assert (doc.params.get('x', '') == 'something')
    assert (doc.returns == None)

    s = """Testing

    :param x: something

    Returns:
        x (str): something
    """
    doc = parse(s)
    assert (doc.short_description == "Testing")
    assert (doc.long_description == "")
    assert (doc.params.get('x', '') == 'something')
    assert (doc.returns.name == 'something')
    assert (doc.returns.type == 'x')


# Generated at 2022-06-21 12:00:57.053185
# Unit test for function parse
def test_parse():
    """Test parsing docstring"""
    print("\nTesting function parse...")
    text = "This is a docstring."
    assert(parse(text).short_description == "This is a docstring.")
    text = """This is a docstring.

This is another paragraph.
    """
    assert(parse(text).short_description == "This is a docstring.")
    assert(parse(text).long_description[0] == "This is another paragraph.")
    text = """This is a docstring.

This is the first paragraph.

This is the second paragraph.
    """
    assert(parse(text).short_description == "This is a docstring.")
    assert(parse(text).long_description[0] == "This is the first paragraph.")

# Generated at 2022-06-21 12:01:08.724547
# Unit test for function parse
def test_parse():
    assert parse('hello') == Docstring('hello')
    assert parse('') == Docstring()
    assert parse('\n') == Docstring()
    assert parse('hello\nworld\n') == Docstring('hello\nworld')
    assert parse('hello\nworld\n', Style.sphinx) == Docstring('hello\nworld')
    assert parse('hello\nworld\n', Style.numpy) == Docstring('hello\nworld')
    assert parse('hello\nworld\n', Style.google) == Docstring('hello\nworld')
    assert parse('hello\nworld\n', Style.epytext) == Docstring('hello\nworld')
    assert parse('hello\nworld\n', Style.domain) == Docstring('hello\nworld')

# Generated at 2022-06-21 12:01:18.652520
# Unit test for function parse
def test_parse():
    """Test the parsing function."""

    print("Testing parse function")
    print("Testing exception when there are no parsers")
    try:
        parse("TEST",Style.auto)
        raise Exception("No exception raised")
    except ParseError as e:
        pass

    docstring = Docstring("TEST")
    styles = {style:style(docstring.text) for style in STYLES}
    print("Testing selecting the longest docstring")
    print("Docstring: {!r}".format(docstring.text))
    print("Parsed as: {!r}".format(parse(docstring.text).meta))
    for style in STYLES:
        print("\t{:10}: {!r}".format(style.name,styles[style].meta))

# Generated at 2022-06-21 12:01:24.370514
# Unit test for function parse
def test_parse():
    """Unit test for function parse.
    
    :returns: True on success
    :rtype: bool
    """
    test_string = '''    Example from stackoverflow.

    :param name: name

    '''
    parsed = parse(test_string)
    return parsed.short_description == "Example from stackoverflow." and parsed.long_description == "" and parsed.meta['name'] == "name" and parsed.meta['return'] == None

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:01:30.509117
# Unit test for function parse
def test_parse():
    text = '''"""
    A very long docstring that contains a lot of
    text that you probably shouldn't read right now.
    Description:

        This is a longer description that spans multiple
        lines.

    Parameters
    ----------
    x: int
        A parameter that you shouldn't read.
    y: float
        A parameter that you shouldn't read.

    Returns
    -------
    out: int
        A value that you shouldn't read.
    """'''
    assert parse(text).description == 'This is a longer description that spans multiple lines.'


# Generated at 2022-06-21 12:01:40.709587
# Unit test for function parse
def test_parse():
    doc = """Some text.

:param int a: some param
:param b: some param
:type b: str
:return: some return
:rtype: bool
:raises ValueError: if something bad happens
:raises TypeError: if something else bad happens
:attr a: some attribute
:type a: int
:Other: some other section
"""
    parsed = parse(doc)
    assert parsed.short_description == "Some text."
    assert parsed.long_description == ""
    assert len(parsed.params) == 2
    assert len(parsed.returns) == 1
    assert len(parsed.raises) == 2
    assert len(parsed.other) == 1
    assert parsed.attributes == ["a"]
    assert parsed.params['a'] == "some param"

# Generated at 2022-06-21 12:01:47.120577
# Unit test for function parse
def test_parse():
    assert parse('hello, world') == Docstring(
        content=[('hello, world', [])], tags=[])
    assert parse('Here is some\n\n    code.\n    More code.') == Docstring(
        content=[('Here is some', []),
                 (('\ncode.\nMore code.', (4, 0, 0, 2)), [])],
        tags=[])

# Generated at 2022-06-21 12:01:56.043332
# Unit test for function parse
def test_parse():
    text = '''
    """
    Test docstring.
    """
    '''
    doc = parse(text)
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.meta is None
    assert doc.style is None
    assert doc.content_offset is None
    assert doc.line_range is None

# Generated at 2022-06-21 12:02:00.819601
# Unit test for function parse
def test_parse():
    docstrings = (
        'This is a simple docstring.',
        'This is another\nmultiline docstring.',
        '',
        'This is a\n    multiline indented docstring.'
    )
    results = []
    for doc in docstrings:
        results.append(parse(doc))
    assert results[0].short_description == 'This is a simple docstring.'
    assert results[1].short_description == 'This is another'
    assert results[2].short_description == ''
    assert results[3].short_description == 'This is a'

test_parse()

# Generated at 2022-06-21 12:02:05.841915
# Unit test for function parse
def test_parse():
    docstring = '''"""This is a sample docstring that is several lines long.
    This is a sample docstring that is several lines long.
    This is a sample docstring that is several lines long.
    This is a sample docstring that is several lines long.
    This is a sample docstring that is several lines long.
    """'''
    #print(parse(docstring))
    assert 1 == 1

# Generated at 2022-06-21 12:02:09.028213
# Unit test for function parse
def test_parse():
    text = "This function does something.\n\n    :param int x: The X argument.\n    :returns: result"
    assert parse(text).text == "This function does something."



# Generated at 2022-06-21 12:02:12.900967
# Unit test for function parse
def test_parse():
    print('Test function parse')
    print(parse('''This is the docstring.

    This is the second paragraph of the docstring.
    '''))
    print('test_parse passed')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:02:20.769182
# Unit test for function parse
def test_parse():
    # Tests for parsers of different types
    from docstring_parser.parser.google import parse_google
    from docstring_parser.parser.numpy import parse_numpy
    from docstring_parser.parser.recommonmark import parse_recommonmark
    from docstring_parser.parser.sphinx import parse_sphinx
    def test_google(text):
        """Tests for google style parser"""
        return parse(text, style=Style.google)

    def test_numpy(text):
        """Tests for numpy style parser"""
        return parse(text, style=Style.numpy)

    def test_recommonmark(text):
        """Tests for recommonmark style parser"""
        return parse(text, style=Style.recommonmark)


# Generated at 2022-06-21 12:02:32.114158
# Unit test for function parse
def test_parse():
    import pytest
    from docstring_parser.common import DEFAULT_CLASS_ATTRIBUTES
    docstring = '''Summary line.

Extended description.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`

Returns
-------
str
    Description of return value.

Raises
------
ValueError
    If `arg2` is equal to `arg1`.

Examples
--------
>>> print([i for i in example()])
[0, 1, 2, 3]
'''
    test_docstring = parse(docstring)

# Generated at 2022-06-21 12:02:40.961646
# Unit test for function parse

# Generated at 2022-06-21 12:02:43.274965
# Unit test for function parse
def test_parse():
    '''Test of function parse'''
    assert parse('Test function parse') is not None
    return parse('Test function parse')

# Generated at 2022-06-21 12:02:48.156451
# Unit test for function parse
def test_parse():
    text = """
    The first sentence.

    The rest of the docstring.

    :param foo: the foo parameter
    :type foo: int
    :param bar: the bar parameter
    :type bar: str
    :returns: something
    :rtype: int
    """
    print(parse(text))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:03:00.605369
# Unit test for function parse
def test_parse():
    docstring = '''
    This is first line
    This is second line
    '''
    parsed_docstring = parse(docstring)
    print(parsed_docstring)
    print(parsed_docstring.summary)
    print(parsed_docstring.meta)
    print(parsed_docstring.description)
    print(parsed_docstring.returns)
    print(parsed_docstring.raises)
    print(parsed_docstring.yields)

# Generated at 2022-06-21 12:03:09.453210
# Unit test for function parse
def test_parse():
    text = """This function does something.
    :param a: parameter 'a'
    :type a: int
    :param b: parameter 'b'
    :type b: str
    :param c: parameter 'c'
    :type c: float
    :return: something
    :rtype: str
    """

    expected_meta = {'a': {'type': 'int'}, 'b': {'type': 'str'}, 'c': {'type': 'float'}}
    expected_return = {'type': 'str'}

    parsed = parse(text)
    assert parsed.meta == expected_meta
    assert parsed.returns == expected_return

# Generated at 2022-06-21 12:03:16.125332
# Unit test for function parse
def test_parse():

    import pytest

    with pytest.raises(ParseError):
        parse(
            """

            """
        )
    with pytest.raises(ParseError):
        parse(
            """

            """
        )
    docstring = parse(
        """A longer description.

        Args:
            param1(int): Some param description
            param2 (str): Some param description
            param3(ParamType): Some param description

          param4: Some param description
        """
    )
    assert docstring.short_description == "A longer description."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 4
    assert len(docstring.returns) == 0
    assert len(docstring.raises) == 0


# Generated at 2022-06-21 12:03:24.925849
# Unit test for function parse
def test_parse():
    rexpected = """
    meta:
        short: 'Get the intersection of two sets'
        authors: ['Chris Arndt', 'Jason R. Coombs']
        version: '1.0'
    description:
        summary: 'Get the intersection of two sets'
        body: >
            Returns a new set with elements common to the sets of n1 and n2.
    args:
        n1: >
            First set of elements.
        n2: >
            Second set of elements.
    returns: >
        New set with common elements.
    """

# Generated at 2022-06-21 12:03:36.761174
# Unit test for function parse
def test_parse():
    # From: https://github.com/uliska/docstring-parser/blob/master/tests/test_parser.py
    from docstring_parser.common import Argument, Docstring, Section
    from docstring_parser.styles import GoogleStyle


# Generated at 2022-06-21 12:03:48.753133
# Unit test for function parse
def test_parse():
    from pprint import pprint
    import os
    import sys
    import subprocess

    # Find all python files in the current dir
    src_files = [f for f in os.listdir('.') if f.endswith('py')]
    for src_file in src_files:
        src_path = '{}'.format(src_file)
        # Run pydoc -w on the file
        PYTHON_INTERPRETER = sys.executable
        pydoc_cmd = [PYTHON_INTERPRETER, '-m', 'pydoc', '-w', src_path]
        subprocess.run(pydoc_cmd)
        pydoc_path = src_path.replace('.py', '.html')

# Generated at 2022-06-21 12:03:50.860572
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("",[], [], [], [], [], [], [])

# Generated at 2022-06-21 12:03:59.376674
# Unit test for function parse
def test_parse():
    doc = """
    This is a test docstring.
    :param a: a
    :param b: b
    :returns: returns
    """
    ret = parse(doc)
    assert ret.style == Style.google
    assert not ret.meta
    assert ret.summary == 'This is a test docstring.'
    assert ret.extended_summary == ''
    assert ret.params == [('a', 'a'), ('b', 'b')]
    assert ret.returns == 'returns'
    assert ret.raises == []
    assert ret.yields == []
    assert ret.warns == []
    assert ret.other == []

# Generated at 2022-06-21 12:04:10.391555
# Unit test for function parse
def test_parse():
    
    assert parse("\n    Hello world.\n    ") == Docstring(
        summary="Hello world.", content="",
        extras=[], returns=[], params=[])

    assert parse("Hello world.") == Docstring(
        summary="Hello world.", content="",
        extras=[], returns=[], params=[])

    assert parse("Hello world.\n") == Docstring(
        summary="Hello world.", content="",
        extras=[], returns=[], params=[])

    assert parse("\nHello world.\n") == Docstring(
        summary="Hello world.", content="",
        extras=[], returns=[], params=[])

    assert parse("\nHello world.\n\n") == Docstring(
        summary="Hello world.", content="",
        extras=[], returns=[], params=[])


# Generated at 2022-06-21 12:04:14.850475
# Unit test for function parse
def test_parse():
    text = """
        test
        test
        :param test: test
    """
    assert parse(text, Style.google) is not None

if __name__ == "__main__":
    print("Running unit tests")
    test_parse()
    print("Pass!")

# Generated at 2022-06-21 12:04:26.084602
# Unit test for function parse
def test_parse():
    docstring = '''Base class for all sparql parsers.
    
    :param query: an object that defines a __str__ method,
                  or None to use the query attribute
    :returns: the query that results from the format
              substitution
    :rtype: string
    :raises: TypeError of an object without a __str__ method is passed in
    '''
    rets = parse(docstring)
    print(rets)
    
    
    

# Generated at 2022-06-21 12:04:36.526922
# Unit test for function parse
def test_parse():
    docstring = """Summary line.
    Extended description.

    Parameters:
        param1 (int): Description of `param1`
        param2 (:obj:`str`, optional): Description of `param2`

        (bool): Description of `param3`
        param4 (list of str): Description of `param3`

    Returns:
        bool: True if successful, False otherwise.
        int: The number of rabbits.
        str: The name of the winner.

    Raises:
        AttributeError: The ``Queue`` object has no ``task_done`` method.

    .. _PEP 484:
        https://www.python.org/dev/peps/pep-0484/
    """


# Generated at 2022-06-21 12:04:42.787986
# Unit test for function parse
def test_parse():
    from textwrap import dedent
    from docstring_parser.utils import dedent_docstring
    docstring = '''
    :param name:
    :type name: Type
    '''

    docstring = dedent(docstring)
    docstring = dedent_docstring(docstring)
    print(parse(docstring))

# Generated at 2022-06-21 12:04:46.196221
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    
    """
    assert parse(text = "name", style = "numpy").name == "name"
    assert parse(text = "name", style = "google").name == "name"

# Generated at 2022-06-21 12:04:54.134173
# Unit test for function parse
def test_parse():
    docstring = """
This is a docstring for a function.

:param arg1: This is an argument.

:type arg1: str

:returns: This is a return value.

:rtype: bool

:Example:

>>> from foo import bar
>>> print(bar('spam'))
True
"""

    parsed = parse(docstring)
    assert parsed.short_description == "This is a docstring for a function."
    assert parsed.long_description == ""
    assert len(parsed.params) == 1
    assert len(parsed.meta) == 2
    assert parsed.params["arg1"] == "This is an argument."
    assert parsed.meta["type"]["arg1"] == "str"
    assert parsed.returns == "This is a return value."

# Generated at 2022-06-21 12:05:01.239986
# Unit test for function parse
def test_parse():
    s = parse(r'''
    Description

    :param arg1: Description of arg1
    :param arg2: Description of arg2
    :return: Description of return value
    ''')
    print(s)
    print(repr(s))
    print(s.short_description)
    print(s.long_description)
    print(s.returns)
    print(s.meta)
    print(s.params)

if __name__ == "__main__":
    test_parse()