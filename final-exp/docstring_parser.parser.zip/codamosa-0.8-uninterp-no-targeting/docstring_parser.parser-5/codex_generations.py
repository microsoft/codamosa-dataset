

# Generated at 2022-06-21 11:55:15.399758
# Unit test for function parse
def test_parse():
    text = """
        Main Work procedure

        Args:
            arg1: some description
            arg2: some description

        Returns:
            bool: True if some condition

        Raises:
            RuntimeError: if some condition
    """
    d = parse(text)

    assert d.short_description == "Main Work procedure"
    assert len(d.params) == 2
    assert d.params[0].arg_name == "arg1"
    assert d.params[0].description == "some description"
    assert len(d.returns) == 1
    assert d.returns[0].type_name == "bool"
    assert d.returns[0].description == "True if some condition"
    assert len(d.exceptions) == 1
    assert d.exceptions[0].type_name == "RuntimeError"


# Generated at 2022-06-21 11:55:25.437668
# Unit test for function parse
def test_parse():
    test_docstring = """This function solves the equation a*x**2 + b*x + c

    Parameters
    ----------
    a : float
        The quadratic coefficient.
    b : float
        The linear coefficient.
    c : float
        The constant coefficient.

    Returns
    -------
    list
        A list of the two real roots.
    """


# Generated at 2022-06-21 11:55:37.427769
# Unit test for function parse
def test_parse():
    def foo():
        """
        This is foo's docstring.

        :param param1: parameter 1
        :param param2: parameter 2
        :type param1: string
        :type param2: integer
        :returns: None
        :raises exception1: always

        additional test paragraph
        """
        print("foo")

    doc = parse(foo.__doc__)
    assert doc.short_desc == "This is foo's docstring."
    assert doc.long_desc == "additional test paragraph"
    assert doc.params['param1'] == "parameter 1"
    assert doc.params['param2'] == "parameter 2"
    assert doc.returns == "None"
    assert doc.meta['param1'] == "string"
    assert doc.meta['param2'] == "integer"
    assert doc

# Generated at 2022-06-21 11:55:43.035313
# Unit test for function parse
def test_parse():
	# For the various docstring styles
    for style in Style:
        print ('Testing style: {}'.format(style))
        doc = parse('This is a docstring.', style=style)
        assert doc.short_description == 'This is a docstring.'
        print ('\tTest success\n')
        
if __name__ == '__main__':
	print ('Running function parse unit tests')
	test_parse()

# Generated at 2022-06-21 11:55:50.700223
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Return, Argument
    import re
    docstring = """
    This is a summary
    of a docstring
    """
    doc = parse(docstring)

    assert doc.__dict__ == {
        'summary': 'This is a summary of a docstring',
        'description': '',
        'meta': {},
        'returns': [],
        'raises': [],
        'yields': []
    }

    docstring2 = """
    This is a summary
    of a docstring

    Description is
    more then one line
    """

    doc = parse(docstring2)

# Generated at 2022-06-21 11:56:01.764609
# Unit test for function parse
def test_parse():
    docstring = parse('''
    This is a docstring.

    Params:
      x (int): this is a param
      y (str): this is a param

    Returns:
      float: return value

    Raises:
      RuntimeError: if something goes wrong
    ''')

# Generated at 2022-06-21 11:56:13.116212
# Unit test for function parse
def test_parse():
    class A(object):
        """A test module.

        test for `parse` function
        """
        #: key: value
        attr_a = None
        #: key: value
        attr_b = None

        def test_fun(self):
            """A function docstring.

            A function docstring
            """

    a = A()
    docstr = parse(a.__doc__)
    assert a.__doc__ == docstr.decode()
    assert len(docstr.meta) == 0

    docstr = parse(a.attr_a.__doc__)
    assert a.attr_a.__doc__ == docstr.decode()
    assert len(docstr.meta) == 1 and 'key' in docstr.meta and docstr.meta['key'][0] == 'value'



# Generated at 2022-06-21 11:56:17.197579
# Unit test for function parse
def test_parse():
    text="""Hello World\n\nArgs:\n    arg_a (str): Hello\n    arg_b (str): World\n\nReturns:\n    dict: dict"""
    #print(parse(text))
    print(parse(text).short_description)
    print(parse(text).long_description)
    print(parse(text).params)
    print(parse(text).returns)
    print(parse(text).meta)
    print(parse(text).meta.get('Args').get('arg_a'))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:23.140725
# Unit test for function parse
def test_parse():
	docstring = [['\n            Parse the docstring into its components.\n            \n            :param text: docstring text to parse\n            :param style: docstring style\n            :returns: parsed docstring representation\n            ']]
	docstring = [(i[0]) for i in docstring]
	doc = parse(docstring[0])
	return doc.short_desc

# Generated at 2022-06-21 11:56:30.781072
# Unit test for function parse
def test_parse():
    from .common import Docstring
    from .styles import Google, Numpy
    from .compat import OrderedDict

    doc = """One line summary.

Extended description.

:keyword one: Description of one.
:type one: str
:keyword two: Description of two.
:type two: int
:keyword three: Description of three.
:type three: bool
:returns: Description of return value.
:rtype: str
:raises Exception1: Description of potential exception.
:raises Exception2: Description of another potential exception.
:raises Exception3: Description of another potential exception.
"""

# Generated at 2022-06-21 11:56:35.735706
# Unit test for function parse
def test_parse():
    print(parse.__doc__)

# Generated at 2022-06-21 11:56:43.067275
# Unit test for function parse
def test_parse():
    imp_text = """
        import numpy as np # add numpy

        def func():
            """
    exp_text = """
        import numpy as np # add numpy

        def func():
            # add main comment for this function
            """
    ipython_text = """
        import numpy as np # add numpy

        def func():
            """
    func_text = """
        def func():
            """
    func_text_ = """
        def func():
            """
    func_text__ = """
        def func():
            """
    func_text___ = """
        def func():
            """
    text = "\n".join([imp_text, exp_text, ipython_text, func_text,
                      func_text_, func_text__, func_text___])

# Generated at 2022-06-21 11:56:53.601152
# Unit test for function parse
def test_parse():
    def f1():
        """blah blah blah"""
        pass

    def f2():
        """
        blah blah blah with newline
        """
        pass

    def f3():
        """
        blah blah blah with style
        :param param: explanation
        :type param: str
        """
        pass

    def f4():
        """
        blah blah blah with style
        :param param: explanation
        :type param: str
        :returns: blah blah blah
        :rtype: int
        """
        pass

    def f5():
        """
        blah blah blah with style
        :param param: explanation
        :param param2: explanation
        :type param: str
        """
        pass


# Generated at 2022-06-21 11:57:04.244991
# Unit test for function parse
def test_parse():
    class A:
        """
        Hello, world!

        :param param1: The first parameter.
        :param param2: The second parameter.
        :returns: Nothing.
        :raises keyError: Raises an exception.
        """

        def __init__(self):
            print("suri")
        def f(self,p1,p2):
            """
            dfjksldjfklsdjflksdjflkdjs f

            :param p1: The first parameter.
            :param p2: The second parameter.
            :return: Nothing.
            :raises keyError: Raises an exception.
            """
            print("suri")

    a = A()
    print(a)
    print(a.__doc__)
    print(a.f.__doc__)
    print

# Generated at 2022-06-21 11:57:10.967410
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle
    docstring = '''This is a short summary.

    This is a longer description.  Not too long, though.

    Parameters
    ----------
    first_param : param_type, optional
        The first parameter.
    second_param : param_type
        The second parameter.

    Returns
    -------
    The return type.  The return description.

    Other Parameters
    ----------------
    third_param : param_type, optional
        The third parameter.
    '''

    assert parse(docstring) == NumpyStyle(docstring)

# Generated at 2022-06-21 11:57:23.565912
# Unit test for function parse

# Generated at 2022-06-21 11:57:31.885811
# Unit test for function parse
def test_parse():
    """Test function parse."""

    # Basic parsed docstring
    docstring = '''\
        a function has a docstring.
        '''
    assert parse(docstring) == Docstring(docstring)

    # Error case: no docstring
    docstring = ''
    error = 'Unable to find the docstring'
    with pytest.raises(ParseError, match=error):
        parse(docstring)

    # Case: basic parsed docstring (reStructuredText)
    docstring = '''\
        a function has a docstring.

        :param x:
            a parameter, with two sentences.

        :returns:
            a return value, with two sentences.
        '''
    assert parse(docstring, style=Style.rst) == Docstring(docstring)

    # Case: basic parsed doc

# Generated at 2022-06-21 11:57:43.703084
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    from docstring_parser.styles import Style, STYLES
    from docstring_parser.docstring import Docstring

    # Test for KeyError
    try:
        parse('', style=Style('doesntexist'))
    except KeyError as e:
        assert issubclass(type(e), KeyError)

    # Test for ParseError
    try:
        parse('nothing', style=Style.numpy)
    except ParseError as e:
        assert issubclass(type(e), ParseError)

    docstring = """
    Short summary.

    Extended description.

    Parameters
    ----------
    arg1
        Description of `arg1`.
    Returns
    -------

    """
    doc = STYLES[Style.numpy](docstring)

# Generated at 2022-06-21 11:57:45.363252
# Unit test for function parse
def test_parse():
    parse('')
    parse('hello world')

# Generated at 2022-06-21 11:57:48.682488
# Unit test for function parse
def test_parse():
    """
    A basic unit test for function parse to make sure it returns the right thing.
    """
    input = "The quick brown fox jumps over the lazy dog."
    expected = Docstring(summary=input)
    actual = parse(input)
    assert actual == expected

# Generated at 2022-06-21 11:57:53.636077
# Unit test for function parse
def test_parse():
    assert parse("test") is not None

# Generated at 2022-06-21 11:58:05.000061
# Unit test for function parse
def test_parse():
    """Test for function parse"""

    # is style correct?
    print(parse('', style=Style.sphinx))
    #print(parse('', style=Style.auto)
    print(parse('', style=Style.google))
    print(parse('', style=Style.numpy))

    # is style auto correct?
    print(parse('', style=Style.auto))

    # test whether ParseError is raised
    try:
        parse('', style=Style.sphinx)
    except ParseError as e:
        print(e.args)
    try:
        parse('', style=Style.google)
    except ParseError as e:
        print(e.args)

# Generated at 2022-06-21 11:58:13.970816
# Unit test for function parse
def test_parse():
    """Try to parse some docstrings.
    """

# Generated at 2022-06-21 11:58:18.651841
# Unit test for function parse
def test_parse():
    docstring = """One line summary.
      Extended description.
      """
    expected = Docstring(
        short_description="One line summary.",
        long_description="Extended description.",
        content=""
    )
    actual = parse(docstring)
    assert actual == expected

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:58:25.990085
# Unit test for function parse
def test_parse():
    text = """
        Summary line.

        Extended description.

        Parameters
        ----------
        arg1 : int
            Description of `arg1`

        Returns
        -------
        str
            Description of return value
        """

    docstring = parse(text)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."

    arg1 = docstring.params["arg1"]
    assert arg1.arg_name == "arg1"
    assert arg1.type_name == "int"
    assert arg1.description == "Description of `arg1`"

    assert docstring.returns.type_name == "str"
    assert docstring.returns.description == "Description of return value"



# Generated at 2022-06-21 11:58:36.735187
# Unit test for function parse
def test_parse():
    text = """A one-liner sentence.

With a paragraph.

And a
multiple-line
description.

Returns:
    Return value description.

Yields:
    Yield value description.

Raises:
    Exception1: If something bad happens.
    Exception2: If something else bad happens.
"""
    parsed = parse(text)
    assert parsed.short_description == "A one-liner sentence."
    assert parsed.long_description == (
        "With a paragraph.\n\nAnd a\nmultiple-line\ndescription.\n"
    )
    assert parsed.returns.type_name == "Return value description."
    assert parsed.yields.type_name == "Yield value description."
    assert len(parsed.raises) == 2

# Generated at 2022-06-21 11:58:48.144912
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import AUTO
    docstring = parse(
        """Hello world.
    
        :param name: The name to say hello to
        :type name: str
        :param times: The number of times to say hello
        :type times: int, optional
        :returns: None
        :raises ValueError: If times is negative.
    
        """
    )

# Generated at 2022-06-21 11:58:52.176815
# Unit test for function parse
def test_parse():
    """Test for function parse
    """
    text = """\
    Parameters
    ----------
    x : int
        The meaning of life.
    """
    assert parse(text) == parse(text, Style.numpy) == parse(text, Style.auto)

# Generated at 2022-06-21 11:58:56.276463
# Unit test for function parse
def test_parse():
    text = """\
    This is a summary.

    This is a description.
    """
    assert parse(text)
    assert parse(text, style=Style.google).summary == "This is a summary."
    assert parse(text, style=Style.google).description == "This is a description."

# Generated at 2022-06-21 11:58:59.639573
# Unit test for function parse
def test_parse():
    assert parse('test') == Docstring('test')
    assert parse('test\ntest') == Docstring('test\ntest')
    assert parse('test\n:param: test\nparameter\n') == Docstring('test',
                                                                 parameters=['test'],
                                                                 returns='')

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:10.395375
# Unit test for function parse
def test_parse():
    import unittest
    import os
    import docstring_parser

    class ParseTestCase(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def test_parse_docstring(self):
            """unit test"""
            file_path = os.path.join(os.path.dirname(docstring_parser.__file__), 'test_data/test.py')
            with open(file_path) as f:
                self.assertEqual(parse(f.read()), eval(f.read()))

        def test_parse_issue_3(self):
            """unit test for issues https://github.com/agronholm/docstring_parser/issues/3"""

# Generated at 2022-06-21 11:59:16.403073
# Unit test for function parse
def test_parse():
    text = '''
    :param table: pandas.DataFrame
    :param group_by: column to group by and aggregate
    :param stats: aggregation statistics to compute
    :param agg_name: name of aggregation column(s)
    :param stat_name: name of statistic column(s)
    :return: pandas.DataFrame with multi-level index
    '''
    style = Style.google
    assert parse(text, style).meta['return'][0] == 'pandas.DataFrame with multi-level index'

# Generated at 2022-06-21 11:59:24.114235
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle

    test_text = """Docstring for test_parse.

    * Parameters:
        - first_param (str): First parameter
        - second_param (:obj:`int`, optional): Second parameter
        - third_param (:obj:`int`, optional): Third parameter
        - fourth_param (:obj:`int`, optional): Fourth parameter, with
          default value of 2
          and second line of description
          and third line of description.
          ```
          $ pip install docstring-parser
          ```

    * Returns:
        int: The return value.

    * Raises:
        ValueError: If `param1` is equal to `param2`.

    """

    doc = parse(test_text)
    assert isinstance(doc, Docstring)
    assert doc.short

# Generated at 2022-06-21 11:59:28.792346
# Unit test for function parse
def test_parse():
    docstr = """
        This is a docstring
        :param int a:
        :param str b:
        :returns:
        :raises ValueError:
    """
    doc = parse(docstr)
    print(doc)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:39.804256
# Unit test for function parse
def test_parse():
    text = """\
    One line summary.

    Extended description.

    :param arg1: The first argument.
    :type arg1: str
    :param arg2: The second argument.
    :type arg2: int, optional
    :returns: Description of return value.
    :rtype: bool
    :raises keyError: raises an exception
    """

    parsed = parse(text)
    assert parsed.short_description == "One line summary."
    assert parsed.long_description == "Extended description."
    assert parsed.return_type == "bool"
    assert parsed.return_annotation == "Description of return value."

# Generated at 2022-06-21 11:59:50.333334
# Unit test for function parse
def test_parse():
    """Test function parse"""

    text = """
    * This is a function
    * that do nothing
    *
    * Parameters
    * ----------
    * first : str
    *     the first one
    * second : str
    *     the second one
    *
    * Returns
    * -------
    * str
    *     test string
    *
    * Raises
    * ------
    * ValueError
    *     if something wrong
    * KeyError
    *     if something bad
    """
    assert parse(text, style=Style.numpy) == parse(text)

# Generated at 2022-06-21 12:00:02.254397
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

# Generated at 2022-06-21 12:00:13.536302
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    dummy_text = "dummy text"
    dummy_style = Style.numpy
    dummy_parse_ = STYLES[dummy_style]
    dummy_docstring = dummy_parse_(dummy_text)
    assert parse(dummy_text, dummy_style) == dummy_docstring
    assert parse(dummy_text, Style.google) != dummy_docstring
    # assert parse(dummy_text, Style.auto) == dummy_docstring

    dummy_text = "blah blah blah"
    dummy_style = Style.numpy
    dummy_parse_ = STYLES[dummy_style]
    dummy_docstring = dummy_parse_(dummy_text)
    # assert

# Generated at 2022-06-21 12:00:24.173858
# Unit test for function parse
def test_parse():
    test_doc1 = """One line summary.
Extended description.
    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises keyError: raises KeyError exception.
    """
    test_doc2 = """One line summary.
Extended description.
:param arg1: The first argument.
:param arg2: The second argument.
:returns: Description of return value.
:raises keyError: raises KeyError exception.
"""
    test_doc3 = """One line summary.
Extended description.
Args:
    arg1 (int): The first argument.
    arg2 (str): The second argument.
Returns:
    bool: Description of return value.
Raises:
    keyError: raises KeyError exception.
"""
    test

# Generated at 2022-06-21 12:00:31.683436
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a sample docstring.

    :param x: The first argument.
    :type x: str
    :returns: The ``x`` arg.
    :rtype: str
    '''
    assert(parse(docstring).description.strip() == "This is a sample docstring.")
    assert(parse(docstring).params['x'].description.strip() == "The first argument.")
    assert(parse(docstring).params['x'].type.strip() == "str")
    assert(parse(docstring).returns.description.strip() == "The ``x`` arg.")
    assert(parse(docstring).returns.type.strip() == "str")

test_parse()

# Generated at 2022-06-21 12:00:38.833698
# Unit test for function parse
def test_parse():
    """Test parse function.
    """
    assert(parse("A simple test", style=Style.numpy).short_description == "A simple test")

# Generated at 2022-06-21 12:00:49.973618
# Unit test for function parse
def test_parse():
    """Test parse function."""
    docstring1 = """
    One line summary.
    Extended description with multiple lines.

    :param param: Example parameter
    :type param: str
    :returns: Example return value
    :rtype: int
    :raises error: Example exception
    """
    docstring2 = """
    One line summary.
    Extended description with multiple lines.

    Args:
        param (str): Example parameter
    Returns:
        Example return value (int)
    Raises:
        error: Example exception
    """

    ds = parse(docstring1)

# Generated at 2022-06-21 12:00:59.456283
# Unit test for function parse
def test_parse():
    # Prepare
    from docstring_parser.styles import GOOGLE
    sty = GOOGLE
    sty.meta_type_map['param'] = 'str'
    sty.meta_type_map['return'] = 'str'
    sty.meta_type_map['rtype'] = 'str'
    sty.meta_type_map['type'] = 'str'
    sty.meta_type_map['raises'] = 'str'
    sty.meta_type_map['yields'] = 'str'
    sty.meta_type_map['ytype'] = 'str'
    
    # Positive tests

# Generated at 2022-06-21 12:01:00.767783
# Unit test for function parse
def test_parse():
    pass


if __name__ == "main":
    test_parse()

# Generated at 2022-06-21 12:01:11.857751
# Unit test for function parse
def test_parse():
    docstring = """
        This is a test function.

        It takes the following arguments:
            arg1: the first function argument

        Kwargs:
            keyword1: the first function keyword argument
            keyword2: the second function keyword argument

        Returns:
            the return value
    """

# Generated at 2022-06-21 12:01:21.604860
# Unit test for function parse

# Generated at 2022-06-21 12:01:25.826705
# Unit test for function parse
def test_parse():
  text = """
  nargs='*'
  type=int
  """
  # result = parse(text)
  # assert (result.summary, result.body) == ("", text)
  assert 1

# Generated at 2022-06-21 12:01:32.927613
# Unit test for function parse
def test_parse():
    """Test case for function parse"""
    from docstring_parser.styles import Sphinx as sph
    from docstring_parser.styles import Google as ggl
    from docstring_parser.styles import Numpydoc as npd
    text = '''
    This is a summary.
    This is the first line.

    This is the second line.
    '''
    assert parse(text, Style.sphinx) == sph(text)
    assert parse(text, Style.google) == ggl(text)
    assert parse(text, Style.numpy) == npd(text)
    assert parse(text) == sph(text)

# Generated at 2022-06-21 12:01:39.438604
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import STYLES

    doc = """
    :param name: full name of the person
    :type name: str
    :param greeting: greeting text
    :type greeting: str
    :returns: a gretted name
    :rtype: str
    """
    d = parse(doc, style=Style.auto)
    print(d)
    print(d.params)

# Generated at 2022-06-21 12:01:46.484808
# Unit test for function parse
def test_parse():
    """Function to test function parse"""
    text = """This function computes the all the elements as inputs.

    Parameters
    ----------
    a : int
        First parameter.
    b : int
        Second parameter.

    Returns
    -------
    int
        The sum of a and b.

    """
    result = parse(text)

# Generated at 2022-06-21 12:01:58.660439
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary=None, description=None,
                                  body=None, tags=None)
    assert parse("Summary") == Docstring(summary="Summary", description=None,
                                         body=None, tags=None)
    assert parse("Summary\n") == Docstring(
        summary="Summary", description=None, body=None, tags=None)
    assert parse("Summary\nDescription") == Docstring(
        summary="Summary", description="Description", body=None, tags=None)
    assert parse("Summary\n\nDescription\n") == Docstring(
        summary="Summary", description="Description", body=None, tags=None)
    assert parse("Summary\n\nDescription\n\nBody") == Docstring(
        summary="Summary", description="Description", body="Body", tags=None)

# Generated at 2022-06-21 12:02:03.096406
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()
    def test_parse():
        import doctest
        doctest.testmod()
        # Unit test for function test_parse


# ==============================================================================
# Main
# ==============================================================================


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:09.774888
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Return
    # Test Google style docstring parsing
    text = """
        :param name: The name to say hello to
        :type name: str
        :param loud: Whether to yell or not
        :type loud: bool
        :returns: None
        :raises: RuntimeError
    """
    docstring = parse(text)
    assert docstring.short_description == ""
    assert docstring.long_description == ""
    assert docstring.returns.type_name == 'None'
    assert len(docstring.params) == 2
    assert docstring.params["name"].type_name == "str"
    assert docstring.params["name"].description == "The name to say hello to"
    assert docstring.params["loud"].type_name == "bool"

# Generated at 2022-06-21 12:02:15.148167
# Unit test for function parse
def test_parse():
    from pprint import pprint
    s = '''This is a module docstring.'''
    print('-' * 78)
    print(parse(s))
    print('-' * 78)
    print(parse(s, style=Style.numpy))
    print('-' * 78)
    print(parse(s, style=Style.google))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:02:18.507669
# Unit test for function parse
def test_parse():
    text = "First line.\n\nSecond line."
    t = parse(text, Style.reStructuredText)
    assert str(t) == text
    assert t.short_description == "First line."
    assert t.long_description == "Second line."


# Generated at 2022-06-21 12:02:22.677853
# Unit test for function parse
def test_parse():
    text = """A very short description.
    
    A longer description.
    
    Parameters:
        some_parameters (str): description
        other_parameters (dict): description
    """
    result = parse(text, Style.numpy)
    print(result)


# Generated at 2022-06-21 12:02:33.540490
# Unit test for function parse
def test_parse():
    """
    :param text: string to be parsed.
    :return: a list of strings that are the description and the arguments.
    """
    docstring_text = '''
    This function parses a docstring text
    and returns the description and the arguments.

    :param text: string to be parsed.
    :return: a list of strings that are the description and the arguments.
    '''
    d = parse(docstring_text)
    assert d.short_description == 'This function parses a docstring text and returns the description and the arguments.'
    assert d.long_description == ''
    assert d.args[0].arg_name == 'text'
    assert d.args[0].type_name == 'str'
    assert d.args[0].description == 'string to be parsed.'
    assert d.returns.type

# Generated at 2022-06-21 12:02:41.182906
# Unit test for function parse
def test_parse():
    """Test function parse"""

    docstring = """One line summary.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    int
        Description of return value

    """
    parsed = parse(docstring)
    assert parsed.short_description == "One line summary."
    assert parsed.long_description == "Extended description."

# Generated at 2022-06-21 12:02:47.945778
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle as g, NumpyStyle as n, GoogleStyle as g, DefaultStyle as d
    assert g('The quick brown fox.').short_description == 'The quick brown fox.'
    assert n('The quick brown fox.').short_description == 'The quick brown fox.'
    assert d('The quick brown fox.').short_description == 'The quick brown fox.'
    # assert g('The quick brown fox.').short_description == 'The quick brown fox.'

# Generated at 2022-06-21 12:02:59.163550
# Unit test for function parse
def test_parse():
    doc = parse(
        """One-line summary.

        Extended description.

        :param foo: Description of foo.
        :type foo: int
        :param bar: Description of bar.
        :type bar: str
        :returns: Description of return value.
        :rtype: bool
        :raises ValueError: Description of exception.
        """)
    assert doc.short_description == 'One-line summary.'
    assert doc.long_description == '\nExtended description.\n'
    assert doc.meta['foo'] == ('Description of foo.', 'int')
    assert doc.meta['bar'] == ('Description of bar.', 'str')
    assert doc.returns == ('Description of return value.', 'bool')
    assert doc.raises == {'ValueError': 'Description of exception.'}



# Generated at 2022-06-21 12:03:10.744275
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    text = "This is a description.\nThis is a description too.\n\nParameters:\n    x1 (int): The first parameter.\n    x2 (str): The second parameter.\n\nReturns:\n    bool: The return value. True for success, False otherwise.\n\nRaises:\n    ValueError: If `x1` is zero.\n"
    document = parse(text,style=Style.google)
    print(document)
    #print(document.short_description)
    #document = parse(text,style=Style.numpy)
    #print(document)

# Generated at 2022-06-21 12:03:15.067304
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """Header.

Some text.
"""
    docstring = parse(text)
    assert docstring.short_description == 'Header.'
    assert docstring.long_description == 'Some text.\n'


# Generated at 2022-06-21 12:03:22.375951
# Unit test for function parse
def test_parse():
    """
    >>> parse('This is a docstring') #doctest: +ELLIPSIS
    Docstring(meta=None, summary='This is a docstring', extended_summary=None, body=None)
    
    >>> parse('This is a docstring\\n\\nwith a body') #doctest: +ELLIPSIS
    Docstring(meta=None, summary='This is a docstring', extended_summary=None, body='with a body')
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:03:23.851326
# Unit test for function parse
def test_parse():
    assert True

# Generated at 2022-06-21 12:03:34.806076
# Unit test for function parse
def test_parse():
    txt = "Function to add two numbers\n" \
          "\n" \
          ":param int a: first number\n" \
          ":param int b: second number\n" \
          ":returns: sum of a and b\n" \
          ":rtype: int"
    doc = parse(txt)
    assert doc.signature == ''
    assert doc.short_description == "Function to add two numbers"
    assert doc.long_description == ''
    assert doc.return_type == 'int'
    assert doc.return_annotation == 'sum of a and b'
    assert doc.meta['a'] == 'first number'
    assert doc.meta['b'] == 'second number'

# Generated at 2022-06-21 12:03:37.176519
# Unit test for function parse
def test_parse():
    assert parse("""\
    test
    """
    ).summary == "test"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:03:39.201271
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    parse_results = parse()
    assert parse_results == None

# Generated at 2022-06-21 12:03:50.188850
# Unit test for function parse
def test_parse():
    sample_docstring = """This is a sample docstring
    This is the description

    :param param1: The first parameter.
    :param param2: The second parameter.

    :returns: This is a description of what is returned.
    :rtype: str

    :raises keyError: raises an exception

    """
    doc = parse(sample_docstring) # doctest: +ELLIPSIS
    assert doc.short_description == "This is a sample docstring"
    assert len(doc.long_description) == 2
    assert len(doc.params) == 2
    assert len(doc.returns) == 1
    assert len(doc.raises) == 1
    assert len(doc.examples) == 0



# Generated at 2022-06-21 12:04:01.046470
# Unit test for function parse
def test_parse():
    doc = r"""
    Some method here with some generic text
    :param a: some param
    :type a: int
    :returns: some return value
    :rtype: str
    """
    ret = parse(doc)
    assert 'ParseError' not in str(ret)

    doc = r"""
    Some method here with some generic text
    :param a: some param
    :returns: some return value
    :rtype: str
    """
    assert 'ParseError' in str(parse(doc))

    doc = r"""
    Some method here with some generic text
    :returns: some return value
    :rtype: str
    :param a: some param
    """
    ret = parse(doc)
    assert 'ParseError' not in str(ret)

# Generated at 2022-06-21 12:04:05.151418
# Unit test for function parse
def test_parse():
    a = parse("""This is a test.
    :param x: int
    """)
    print(a.arguments)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:04:17.774369
# Unit test for function parse
def test_parse():
    """Test main parse function."""
    assert parse('') == Docstring()
    assert parse('\n') == Docstring()
    assert parse('foo') == Docstring(content='foo')
    assert parse('foo\nbar') == Docstring(content='foo\nbar')
    assert parse('foo\nbar\n') == Docstring(content='foo\nbar')
    assert parse('foo', style=Style.numpy) == Docstring(content='foo')
    assert parse('foo', style=Style.google) == Docstring(content='foo')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:04:27.477439
# Unit test for function parse
def test_parse():
    text = '''Interpolates a given curve into given number of samples.
    
    Given a curve defined by a function, interpolate points on it
    into a uniform knot vector.
    
    Args:
        curve: Single-argument function that defines the curve
        n_samples: Number of samples to interpolate
        
    Returns:
        curve: List of points representing the curve
    '''
    ds = parse(text)
    assert ds.summary == 'Interpolates a given curve into given number of samples.'
    assert ds.description == 'Given a curve defined by a function, interpolate points on it\ninto a uniform knot vector.'
    assert len(ds.params) == 2
    assert ds.params['curve'].desc == 'Single-argument function that defines the curve'

# Generated at 2022-06-21 12:04:37.886008
# Unit test for function parse
def test_parse():
    import os
    import glob
    import subprocess
    import shutil
    from tempfile import mkdtemp
    from os.path import join
    from docstring_parser.common import ParseError

    def check_parse(source):
        def f():
            pass

        f.__doc__ = source
        try:
            result = parse(source)
        except ParseError:
            result = ''
        return repr(result)

    example_dir = os.path.join(os.path.dirname(__file__), 'examples')
    for path in glob.glob(os.path.join(example_dir, '*.py')):
        with open(path, 'r') as f:
            source = f.read().rstrip()
        expected = check_parse(source)

        temp_path = mkdtemp

# Generated at 2022-06-21 12:04:49.318305
# Unit test for function parse
def test_parse():
    def func():
        """This is a function.
        :param str a: A string parameter."""

    doc = parse(func.__doc__)

    assert doc.full_docstring == func.__doc__
    assert doc.short_description == "This is a function."
    assert doc.long_description == ""
    assert doc.params[0].name == "a"
    assert doc.params[0].type == "str"
    assert doc.params[0].descr == "A string parameter."

    doc = parse("""This is a function.

:param str a: A string parameter.
:rtype: bool
""")

    assert doc.full_docstring == """This is a function.

:param str a: A string parameter.
:rtype: bool"""

# Generated at 2022-06-21 12:04:52.021184
# Unit test for function parse
def test_parse():
    s = '''
    Hello World!
    '''
    print(s)
    doc = parse(s)
    print(doc.short_description)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:04:53.060663
# Unit test for function parse
def test_parse():
    assert(3==3)

# Generated at 2022-06-21 12:04:55.050740
# Unit test for function parse
def test_parse():
    assert parse("") == parse("", style=Style.numpy)


# Generated at 2022-06-21 12:05:01.319400
# Unit test for function parse
def test_parse():
    from textwrap import dedent

    docstring = dedent('''\
        Args:
            arg1: The first argument.
            arg2: The second argument.
        ''')

    print(parse(docstring))
    print(parse('Hello World.', Style.pep))
    print(parse('Hello World.', Style.numpy))
    print(parse('Hello World.', Style.google))

if __name__ == '__main__':
    test_parse()