

# Generated at 2022-06-21 11:55:18.831002
# Unit test for function parse
def test_parse():
    text = '''Summary line.

    Description

    Description continued.
    Description ended.

    Args:
        arg1: Description of arg1
        arg2: Description of arg2

    Returns:
        Description of return value

    Raises:
        Exception1: When this exception is raised
        Exception2: If this exception is raised

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

    >>> a=[1,2,3]
    >>> print [x + 3 for x in a]
    [4, 5, 6]
    >>> print "a\n\nb"
    a
    b
    '''
    docstring = parse(text,style='pep257')
    print(docstring.summary)
    print(docstring.description)

# Generated at 2022-06-21 11:55:25.232010
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import RSTStyle

    docstring = """\
        Short summary.

        Long description.

        :param arg1: Description of `arg1`
        :type arg1: str
        :param arg2: Description of `arg2`
        :type arg2: int
        :returns: Description of return value
        :rtype: str
        :raises exception1: Description of exception1
        :raises exception2: Description of exception2
    """

    parsed_docstring = parse(docstring, style=RSTStyle)

# Generated at 2022-06-21 11:55:33.518694
# Unit test for function parse
def test_parse():
    docstring = """
    This function parses a docstring and returns a Docstring object
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    parsed_docstring = parse(docstring)
    print(parsed_docstring.text)
    print(parsed_docstring.params)
    print(parsed_docstring.returns)
    print(parsed_docstring.meta)


# Generated at 2022-06-21 11:55:36.371712
# Unit test for function parse
def test_parse():
    doc = parse(__doc__)
    assert doc.short_description == "The main parsing routine."

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:38.466623
# Unit test for function parse
def test_parse():
  text = '''The parse_docstring method of the Docstring class.
  :param docstring: The docstring to parse"""
    :param style: docstring style
    :returns: parsed docstring representation'''
  style = '''The parse_docstring method of the Docstring class.
  :param docstring: The docstring to parse"""
    :param style: docstring style
    :returns: parsed docstring representation
    '''
  parsed = parse(text, text)
  assert parsed == style

# Generated at 2022-06-21 11:55:48.296097
# Unit test for function parse
def test_parse():
    from copy import copy


# Generated at 2022-06-21 11:55:49.348936
# Unit test for function parse
def test_parse():
    assert parse(file_name) == docstring

# Generated at 2022-06-21 11:55:59.291634
# Unit test for function parse
def test_parse():
	text = '''
		This is a function to test the parse function.

		:param text: docstring text to parse
		:param style: docstring style
		:returns: parsed docstring representation
	'''
	print('parse(text, style = Style.google)')
	print(parse(text, style = Style.google))
	print('parse(text, style = Style.numpy)')
	print(parse(text, style = Style.numpy))
	print('parse(text, style = Style.rst)')
	print(parse(text, style = Style.rst))

if __name__ == '__main__':
	test_parse()

# Generated at 2022-06-21 11:56:11.848899
# Unit test for function parse
def test_parse():
    assert parse('def test():\n    """Test"""') == Docstring(summary='Test')
    assert parse('def test():\n    r"""Test"""') == Docstring(summary='Test')
    assert parse('def test():\n    """Test\n    """') == Docstring(summary='Test')
    assert parse('def test():\n    """Test"""\n    abc') == Docstring(summary='Test')
    assert parse('def test():\n    """Test\n\n    """') == Docstring(summary='Test')
    assert parse('def test():\n    """Test\n    t2"""') == Docstring(summary='Test')
    assert parse('def test():\n    """Test\n    t2\n    """') == Docstring(summary='Test')

# Generated at 2022-06-21 11:56:23.483818
# Unit test for function parse
def test_parse():
    assert parse("").style == Style.numpy
    assert parse("Summary\n").style == Style.numpy
    assert parse("Summary\n:param x:").style == Style.numpy
    assert parse("Summary\n\n:param x:").style == Style.sphinx
    assert parse("Summary\n\nArgs:\n    x:").style == Style.google
    assert parse("Summary\n\nStatic Method\n\nArgs:\n    x:").style == Style.numpy
    assert parse("Summary\n\nAttributes:\n    x:").style == Style.google
    assert parse("summary\n\nYield:\n    x:").style == Style.numpy
    assert parse("Summary\n\nKeyword Arguments:\n    x:").style == Style.numpy

# Generated at 2022-06-21 11:56:29.987566
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True, report=True)
# test_parse()


# Generated at 2022-06-21 11:56:40.196657
# Unit test for function parse
def test_parse():
    # Docstring text with a signature and one-line description
    text = "A function that does something.\n"
    text += "\n:param int foo: The foo to bar."
    doc = parse(text)
    assert doc.short_description == "A function that does something."
    assert doc.long_description == ""
    assert doc.meta == {'foo': 'int'}
    assert doc.signature == ""
    # Docstring text with a signature and two-line description
    text = "A function that does something.\nMore stuff here\n"
    text += "\n:param int foo: The foo to bar."
    doc = parse(text)
    assert doc.short_description == "A function that does something."
    assert doc.long_description == "More stuff here"

# Generated at 2022-06-21 11:56:51.013156
# Unit test for function parse
def test_parse():
    assert parse("").meta == {}
    assert parse("").description == ""
    assert parse("").params == {}
    assert parse("").returns == {}
    assert parse("").raises == {}
    assert parse("").warns == {}
    assert parse("").see_also == {}
    assert parse("").notes == {}
    assert parse("").references == {}
    assert parse("").examples == {}
    assert parse("").attributes == {}
    assert parse("").methods == {}
    assert parse("").yields == {}

    assert parse(None).meta == {}
    assert parse(None).description == ""
    assert parse(None).params == {}
    assert parse(None).returns == {}
    assert parse(None).raises == {}
    assert parse(None).warns == {}
    assert parse(None).see_

# Generated at 2022-06-21 11:56:56.307946
# Unit test for function parse
def test_parse():
    text = '''
    :param text: docstring text to parse
    :returns: parsed docstring representation
    '''
    actual = parse(text)
    expected = Docstring(
        summary='',
        body='',
        returns=Docstring.ReturnsBlock('parsed docstring representation'),
        meta={'param': [Docstring.ParamBlock('text', 'docstring text to parse')]},
    )
    assert actual == expected

# Generated at 2022-06-21 11:57:06.973797
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import google
    from docstring_parser.styles import numpy
    from docstring_parser.styles import reStructuredText

    text = """\
        int test(foo, bar=None) -> None

        Words go here and here and here.

        Args:
            foo: Foo goes here.
            bar: Bar goes here.

        Returns:
            None
        """


# Generated at 2022-06-21 11:57:17.160094
# Unit test for function parse
def test_parse():
    docstrings = "Parses a docstring into components.\n\nArgs:\n\ttext (str): docstring text to parse\n\tstyle (Style): docstring style\n\nReturns: Docstring: parsed docstring representation"
    parser = parse(docstrings)

# Generated at 2022-06-21 11:57:23.954290
# Unit test for function parse
def test_parse():
    doc = parse("""This is a test
    to check whether parse works
    And this is a test case""")
    assert(len(doc.group)==0)
    assert(len(doc.meta)==0)
    assert(doc.summary=="This is a test to check whether parse works")
    assert(len(doc.content)==1)
    assert(doc.content[0]=="And this is a test case")


# Generated at 2022-06-21 11:57:28.191587
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    text = """Summary line.

Description:

I'm a description.

Args:
  consumer_key (str): This is a consumer key.
  consumer_secret (str): This is a consumer secret.

Returns:
  None

    """
    print(parse(text))


# Generated at 2022-06-21 11:57:34.355343
# Unit test for function parse
def test_parse():
    assert parse("Hello") == parse("Hello", Style.pep257)
    assert parse("Hello") != parse("World", Style.pep257)
    assert parse("Hello", style=Style.numpy) == parse("Hello", style=Style.numpy)
    assert parse("Hello", style=Style.google) == parse("Hello", style=Style.google)


if __name__ == "__main__":

    test_parse()

# Generated at 2022-06-21 11:57:39.595458
# Unit test for function parse
def test_parse():
    print("\nParse example docstrings:")

# Generated at 2022-06-21 11:57:50.547867
# Unit test for function parse
def test_parse():
    text = '''This function does something.

:param int a: the first parameter
:param str b: the second parameter
:return: None
:raises ValueError: if something bad happens
'''
    docstring = parse(text)
    assert len(docstring.meta) == 4
    assert docstring.summary == 'This function does something.'
    assert docstring.body == ''
    assert docstring.returns.type_name == 'None'
    assert len(docstring.exc_list) == 1

# Generated at 2022-06-21 11:57:53.901328
# Unit test for function parse
def test_parse():
    text = '''
    Unit test for function parse

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    parse(text, style=Style.google)



if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:58:05.433671
# Unit test for function parse
def test_parse():
    text = \
    """
    This is the module docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Return:
        bool: The return value. True for success, False otherwise.
    """

    docstring = parse(text)

    assert docstring.short_description == "This is the module docstring."
    assert len(docstring.long_description) == 1
    assert "The second argument." in docstring.long_description[0]

    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == "arg1"
    assert docstring.params[0].type_name == "str"
    assert docstring.params[0].description == "The first argument."

    assert len(docstring.returns)

# Generated at 2022-06-21 11:58:09.937246
# Unit test for function parse
def test_parse():
    docstring = """ One line summary.

            Extended description.

            Parameters
            ----------
            arg1 : int
                Description of `arg1`

            arg2 : str
                Description of `arg2`

            Returns
            -------
            str
                Description of return value

            """
    assert parse(docstring, style=Style.numpy) is not None



# Generated at 2022-06-21 11:58:22.344318
# Unit test for function parse
def test_parse():
    # test for google style
    google_style = '''Sums two numbers
    :param a: The first number
    :param b: The second number
    :returns: The sum of the two numbers
    '''
    result = parse(google_style)
    assert result.short_description == "Sums two numbers"
    assert result.long_description == ''
    assert len(result.returns) == 1
    assert result.returns[0]['type'] == ''
    assert result.returns[0]['description'] == 'The sum of the two numbers'
    assert result.returns[0]['name'] == ''
    assert len(result.raises) == 0
    assert len(result.fields) == 0
    assert len(result.examples) == 0
    assert len(result.warnings) == 0


# Generated at 2022-06-21 11:58:34.083444
# Unit test for function parse
def test_parse():
    """Test suite for docstring_parser.parse."""
    import pytest
    from .examples import NUMPY, GOOGLE, GOOGLE_FUNC, GOOGLE_CLS
    from .examples import GOOGLE_PARAM, GOOGLE_ARG, GOOGLE_RAISE
    from .examples import GOOGLE_RETURN


# Generated at 2022-06-21 11:58:40.109508
# Unit test for function parse
def test_parse():
  # Test a valid docstring to make sure it gets parsed
  text = """
  Hello!
  :param a: the a
  :rtype: str
  """
  doc = parse(text)
  assert doc.short_description == "Hello!"
  assert "a" in doc.params
  assert doc.returntype == "str"

  # Test an invalid docstring to make sure it throws an exception
  text = """
  :param a: the a
  :rtype: str
  """
  try:
    parse(text)
    assert False
  except ParseError:
    assert True

# Generated at 2022-06-21 11:58:46.383974
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    docstring = '''
    dj-stripe is a django app that allows users to subscribe to a stripe plan.
    It also allows you to create multiple stripe customer objects in a single
    django user account and sync the django user to multiple stripe customer
    objects.
    '''

    assert parse(docstring)


# Generated at 2022-06-21 11:58:48.275046
# Unit test for function parse
def test_parse():
    ds = parse('boobs')
    assert len(ds.sections) == 0

# Generated at 2022-06-21 11:58:52.649623
# Unit test for function parse
def test_parse():
    text = """
            This is a summary
            This is the rest

            Args:
                a (int): name of the arg
                b (str): name of the arg
        """
    print(parse(text, style=Style.numpy))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:04.395639
# Unit test for function parse
def test_parse():
    """ Test for function parse"""
    try:
        text_1 = """
    This is the first line
    This is the second line
    """
        text_2 = """
        This is a test docstring.
        """
        text_3 = """
    This is a test docstring.
    """
        parse(text_1)
        parse(text_2)
        print("Unit test passed!")
    except ParseError:
        print("Unit test failed!")


# Generated at 2022-06-21 11:59:14.879065
# Unit test for function parse
def test_parse():
    try:
        one = "This is a docstring."
        two = """This is a docstring.

Other text.

:param int x: some parameter
"""
        d1 = parse(one)
        assert d1.short_description == "This is a docstring.", "Short description parse error."

        d2 = parse(two)
        assert d2.short_description == "This is a docstring.", "Short description parse error."
        assert d2.long_description == "Other text.\n", "Long description parse error."
        assert d2.meta == {"x": "some parameter"}, "Meta parse error."

        assert len(d1) == 0
        print(d1)

        assert len(d2) == 1
        print(d2)
    except ParseError as e:
        print(e)
       

# Generated at 2022-06-21 11:59:17.207627
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    assert 1
    return

# Generated at 2022-06-21 11:59:21.704237
# Unit test for function parse
def test_parse():
    if __name__ == "__main__":
        from docstring_parser.common import ParseError

        src = '''Docstring should contain a one-line summary
            docstring should contain a one-line summary,
            and may optionally contain a more verbose description.
            params:
                :param param1: description of param1
                :param param2: description of param2
            returns: return value description
            raises: Exception
            '''
    

# Generated at 2022-06-21 11:59:32.662694
# Unit test for function parse
def test_parse():
    """Test the docstring_parser.parse function."""
    import sys
    import pytest
    from pathlib import Path

    # setup
    data_folder = Path(__file__).parent / 'data'
    filepath_numpy = data_folder / ('example_numpy.py')
    filepath_google = data_folder / ('example_google.py')
    filepath_sphinx = data_folder / ('example_sphinx.py')
    filepath_other = data_folder / ('example_other.py')
    files = [filepath_numpy, filepath_google, filepath_sphinx, filepath_other]
    if sys.version_info[0] > 2:
        files = [str(f) for f in files]

    # run tests

# Generated at 2022-06-21 11:59:42.170143
# Unit test for function parse
def test_parse():
    assert parse("") == parse("")
    assert parse("""
        This is main paragraph
        """) == parse("""
        This is main paragraph
        """)
    assert parse("""
        :param int x: this is x
        :return int: this is return value
        :raises ValueError: if x > 10
        """) == parse("""
        :param int x: this is x
        :return int: this is return value
        :raises ValueError: if x > 10
        """)

# Generated at 2022-06-21 11:59:47.494405
# Unit test for function parse
def test_parse():
    text = '''
    Hello world

    Parameters
    ----------
    a : int
        the first param
    b : str
        the second param
    c : dict
        the third param
    '''
    ans = parse(text, Style.numpy)
    print(ans)
    
    
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:50.596767
# Unit test for function parse
def test_parse():
    text = """\
Class name

Some basic class.
"""
    style = Style.numpy

    assert parse(text, style).short_description == 'Class name'
    assert parse(text, style).long_description == 'Some basic class.'


# Generated at 2022-06-21 12:00:02.160702
# Unit test for function parse
def test_parse():
    # Test for 'numpydoc' style
    print('Testing for numpydoc style')
    text = "Parse a docstring\n\n:param text: docstring text to parse\n:param style: docstring style\n:returns: parsed docstring representation\n"
    parse(text)
    print('Test succesful')
    #Test for 'sphinx' style
    print('Testing for sphinx style')
    text = "Parse the docstring into its components.\n\n:param text: docstring text to parse\n:param style: docstring style\n:returns: parsed docstring representation"
    parse(text)
    print('Test succesful')

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:00:04.736370
# Unit test for function parse
def test_parse():
    doc_text = '''
    This is a docstring
    with 2 lines of text.
    '''
    assert parse(doc_text).lines[0] == 'This is a docstring'

# Generated at 2022-06-21 12:00:24.234352
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    test0 = "This is a neat program."
    doc0 = Docstring(summary=["This is a neat program."], meta=[])
    test1 = "This is a neat program.\n\nThis is a longer description."
    doc1 = Docstring(summary=["This is a neat program."],
                     description=["This is a longer description."],
                     meta=[])
    test2 = "This is a neat program.\n\nArgs:\n\tn (int): a number\n\tname (str): a name"
    doc2 = Docstring(summary=["This is a neat program."],
                     args=[("n", "int: a number"), ("name", "str: a name")],
                     meta=[])

# Generated at 2022-06-21 12:00:28.108127
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import google
    docstring = google.parse("""Summary line.

    Extended description.
    """)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."

# Generated at 2022-06-21 12:00:34.117657
# Unit test for function parse
def test_parse():
    with open('unittest_parse.txt', 'r') as file:
        lines = file.readlines()
        parsed_words = []
        words = lines[0].replace(',','').replace('\'','').replace(':','').replace('(','').replace(')','').split()
        parsed_words.append(parse(lines[0].replace('\n', '')))
        assert parsed_words == words

# Generated at 2022-06-21 12:00:44.445673
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    from docstring_parser import parse
    docstring = """\
    This is a test docstring.

    Args:
      param1 (int): Parameter 1.
      param2 (str): Optional parameter 2.
    """

    my_docstring = parse(docstring)
    assert my_docstring.short_description == "This is a test docstring."
    assert my_docstring.long_description == ""
    assert my_docstring.params['param1'].arg_type == "int"
    assert my_docstring.params['param2'].arg_type == "str"
    assert my_docstring.params['param2'].default == "Optional"


# Generated at 2022-06-21 12:00:55.867266
# Unit test for function parse
def test_parse():
	import pytest
	def test_parse_docstring(text, style, expected):
	    docstring = parse(text, style)
	    print(docstring)
	    print(expected)
	    assert docstring == expected

	test_parse_docstring(
		text="",
		style=Style.auto,
		expected=Docstring(
		    short_description="",
		    long_description="",
		     meta={},
	    ))

	test_parse_docstring(
	    text="""
	    Exercise the parser.
	    """,
	    style=Style.none,
	    expected=Docstring(
	        short_description="Exercise the parser.",
	        long_description="",
	         meta={},
	    ))


# Generated at 2022-06-21 12:01:02.415004
# Unit test for function parse
def test_parse():
    docstring = '''\
This is a function.

Keyword arguments:
param1 -- the first parameter
param2 -- the second parameter
'''
    expected = Docstring(
        content='This is a function.',
        params=['param1 -- the first parameter', 'param2 -- the second parameter']
    )
    assert parse(docstring) == expected


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:01:04.862169
# Unit test for function parse
def test_parse():
    ds = '''
    :param name:
    :param address::
    '''
    print(parse(ds, style=Style.google))

# Generated at 2022-06-21 12:01:15.052993
# Unit test for function parse
def test_parse():

    text = '''Go to the next item. If no items to go, do nothing.

        arg1: The string to be printed
        arg2: The duration to be printed
        arg3: The format of arg1

    :param arg1:
    :type arg1:
    :param arg2:
    :type arg2:
    :param arg3:
    :type arg3:
    :returns: 
    :rtype: 
    '''
    docstring = parse(text)
    assert len(docstring.content) == 1
    assert len(docstring.params) == 3
    assert len(docstring.returns) == 0
    assert len(docstring.raises) == 0


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:01:17.173461
# Unit test for function parse
def test_parse():
    assert parse('hello world') == Docstring(summary='hello world', body='', returns=None, args=None, examples=None)


# Generated at 2022-06-21 12:01:21.516751
# Unit test for function parse
def test_parse():
    """
    This function tests the function parse.
    >>> parse('returns the area of a rectangle')
    Docstring({})

    >>> parse('returns the area of a rectangle', style=Style.google)
    Docstring({})
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 12:01:32.220881
# Unit test for function parse
def test_parse():
    """
    Unit tests for function parse
    """
    assert parse("a") == Docstring(lines=["a"], meta=[])


# Generated at 2022-06-21 12:01:41.479067
# Unit test for function parse
def test_parse():
    docstring_before = '''The main parsing routine.

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
'''
    docstring_after = Docstring(
        content=[
            'The main parsing routine.',
            '',
            ':param text: docstring text to parse',
            ':param style: docstring style',
            ':returns: parsed docstring representation'
        ],
        sections=[],
        returns="parsed docstring representation",
        meta=dict(
            text="docstring text to parse",
            style="docstring style")
    )
    assert parse(docstring_before) == docstring_after

# Generated at 2022-06-21 12:01:48.464476
# Unit test for function parse
def test_parse():
    doctxt = '''\
    This routine parses markdown.

    # Parameters:
        name: the file name
        **args: positional arguments

    # Returns:
        result: something

    # Raises:
        ValueError: see below

    # Notes
    This is a note.
    '''
    doc = parse(doctxt)
    print(doc.short_description)
    for param in doc.params:
        print(param.arg_name, param.description)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:01:57.734996
# Unit test for function parse
def test_parse():
    text = """
    .. module:: my_module

    .. versionadded:: 1.0.13

    This is the main module.

    :param param1: this is a first param
    :param param2: this is a second param
    :raises keyError: raises an exception
    :returns: None
    :rtype: None
    """
    docstring = parse(text)
    assert docstring.meta["module"] == "my_module"
    assert docstring.meta["versionadded"] == "1.0.13"
    assert docstring.short_description == "This is the main module."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1

# Generated at 2022-06-21 12:02:08.173904
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    assert parse("Simple test docstring")
    assert parse("This is a simple test docstring.")
    assert parse("This is an one liner docstring.")
    assert parse("\nThis is a multiline docstring\n")
    try:
        parse("This is an invalid docstring")
        assert False
    except ParseError:
        pass
    try:
        parse("This is an invalid docstring.", style=Style.google)
        assert False
    except ParseError:
        pass
    try:
        parse("This is an invalid docstring.", style=Style.numpy)
        assert False
    except ParseError:
        pass

# Generated at 2022-06-21 12:02:11.080670
# Unit test for function parse
def test_parse():
    print("\nTest for function parse")
    print(parse.__doc__)
    text = "This is a test docstring."
    print(parse(text))

# Generated at 2022-06-21 12:02:19.900904
# Unit test for function parse
def test_parse():
    docstring = '''\
One line summary.

Extended description.

Args:
    arg1 (int): Description of arg1.
    arg2 (:obj:`list` of :obj:`str`): Description of arg2.

Returns:
    bool: Description of return value.

'''

# Generated at 2022-06-21 12:02:23.141197
# Unit test for function parse
def test_parse():
    # Test for the style
    test1 = parse("123")
    assert isinstance(test1, Docstring)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:32.072058
# Unit test for function parse
def test_parse():
    """Test parse function"""
    docstring1 = """This is an example docstring.
    It's a short description
    Keyword arguments:
    age -- age of the person (default 12)
    name -- name of the person
    Returns:
    Credentials
    """
    STYLES["sphinx-napoleon"](docstring1)
    STYLES["numpy"](docstring1)
    STYLES["rest-reST"](docstring1)
    STYLES["google"](docstring1)
    STYLES["go"](docstring1)
    STYLES["doxygen"](docstring1)

# Generated at 2022-06-21 12:02:35.663561
# Unit test for function parse
def test_parse():
    doc = parse("""Summary
        Multiple
        Lines

    Keyword Arguments:
        arg1: description
        arg2: description
        arg3: description

    Returns:
        description

    Raises:
        Exception1
        Exception2

    Other Parameters:
        param1: description
        param2: description
    """)
    print(doc.meta)


# Generated at 2022-06-21 12:02:54.931520
# Unit test for function parse
def test_parse():
    text = '''"""Summary line.

Description:
    Description continued.
    - list item 1
    - list item 2

Args:
    arg1 (int): Description of arg1

Returns:
    int: Description of return value

"""
'''

    result = parse(text)
    assert result.meta["summary"] == "Summary line."
    assert result.meta["description"] == "Description continued.\n- list item 1\n- list item 2"
    assert result.meta["returns"]["desc"] == "Description of return value"
    assert result.meta["args"][0]["name"] == "arg1"
    assert result.meta["args"][0]["desc"] == "Description of arg1"

    print("test_parse(): OK")

# Generated at 2022-06-21 12:03:06.017296
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    from docstring_parser import parse
    docstring = """
    Parse docstrings and organize it as an object model.
    :param arg1: The first argument.
    :type arg1: int, optional
    :param arg2: The second argument.
    :type arg2: str, optional
    :returns: None
    :rtype: int
    :raises ValueError: Raised when `arg2` is equal to 'raise'.
    """
    actual = parse(docstring)
    expected = """
    Parse docstrings and organize it as an object model.
    """
    assert expected == actual.short_description

# Generated at 2022-06-21 12:03:11.152103
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    docstring = '''
    This is a longer description. It can contain multiple paragraphs.
    * and *
    **bold**
    *italic*
    http://google.com
    https://google.com
    .. code-block:: python

        print('hello world!')
    '''
    parsed = parse(docstring)
    print(parsed.long_description)


test_parse()

# Generated at 2022-06-21 12:03:17.226084
# Unit test for function parse
def test_parse():
    doc=r'''
        Docstring with summary followed by extra line.

        Extra line contains a list item:
            - with a bullet point
        '''
    docstring=parse(doc)
    print(docstring)
    print(docstring.summary)
    print(docstring.description)
    print(docstring.meta)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:03:23.641048
# Unit test for function parse
def test_parse():
    doc_string = '''
    test - This module defines a class of similar objects.
    :param str arg1: The first argument.
    :param int arg2: This is a second argument
    :param arg3: And a third, with no type specified.
    :returns int: The return value.
    :raises SomeException: For some reason.
    '''
    doc = parse(doc_string)
    print("test_parse() - doc: %s "%(doc))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:03:34.001730
# Unit test for function parse
def test_parse():

    # Unit test for function parse with style not auto
    # test 1
    text = """ 
    This is a test 1
    """
    docstring = parse(text, style=Style.spinx)
    assert docstring.__str__() == text

    # test 2
    text = """ 
    This is a test 2
    """
    docstring = parse(text, style=Style.google)
    assert docstring.__str__() == text
    # Unit test for function parse with style auto
    # test 3
    text = """ 
    This is a test 3
    """
    docstring = parse(text)
    assert docstring.__str__() == text

# Generated at 2022-06-21 12:03:45.519882
# Unit test for function parse
def test_parse():
    d = parse("""
        Short description
        Long description
        Long description line 2
        Args:
            arg1 (int): First argument
            arg2 (str): Second argument
        Returns:
            int: Return value
        """)
    assert str(d) == """
        Short description

        Long description
        Long description line 2

        Args:
            arg1 (int): First argument
            arg2 (str): Second argument

        Returns:
            int: Return value
        """, str(d)
    assert d.long_desc == """
        Long description
        Long description line 2
        """
    assert d.short_desc == "Short description"
    assert d.args == [('arg1', 'int', 'First argument'),
                      ('arg2', 'str', 'Second argument')]

# Generated at 2022-06-21 12:03:56.958832
# Unit test for function parse
def test_parse():
	d = parse("""This is a docstring.""")
	assert isinstance(d, Docstring)
	assert d.summary == "This is a docstring."
	assert d.full_doc == "This is a docstring."
	assert d.meta==list()
	assert d.optimize_index(("a", "b"))==("a", "b")
	assert d.extended_args==list()
	
	d = parse("""This is a docstring.
				Parameters:
					arg1 (str): arg1
					arg2 (int): arg2
				Returns:
					str: return string""")
	assert isinstance(d, Docstring)
	assert d.summary == "This is a docstring."

# Generated at 2022-06-21 12:04:05.151626
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    text = """
    This is a short summary.

    This is a long
    multi-line summary.

    This is a code block:

        >>> print('code')
    """
    expected = Docstring(
        short_description="This is a short summary.",
        long_description="""This is a long
multi-line summary.""",
        metadata={},
        examples=[([">>> print('code')", ], '')],
    )
    actual = parse(text)
    assert expected == actual

# Generated at 2022-06-21 12:04:05.766659
# Unit test for function parse
def test_parse():
    assert parse("")

# Generated at 2022-06-21 12:04:17.438602
# Unit test for function parse
def test_parse():
    text = """\
        Single line summary.

        Extended description of the function.

        :param a: first param
        :param b: second param
        :key a: first key
        :key b: second key
        :return: return description
        :rtype: str
    """
    print(parse(text))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:04:26.354022
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    text = '''
    """The main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    '''
    rets = parse(text)
    assert rets.short_description == 'The main parsing routine.'
    assert rets.long_description == ''
    assert rets.meta['param'] == 'text'
    assert rets.meta['param text'] == 'docstring text to parse'
    assert rets.meta['param style'] == 'docstring style'
    assert rets.meta['return'] == 'parsed docstring representation'


# Generated at 2022-06-21 12:04:36.803802
# Unit test for function parse
def test_parse():
    docstring = """\
    This function does something.

    :param foo: the foo to bar
    :type foo: :class:`Foo`
    :param bar: the bar to foo
    :type bar: str
    :raises ValueError: if bad things happen
    :returns: None
    :rtype: None

    .. seealso:: :func:`spam`
    """
    parsed = parse(docstring, Style.sphinx)
    assert parsed.short_description == "This function does something."
    assert parsed.long_description == ""
    assert parsed.params == [
        {"type": ":class:`Foo`", "description": "the foo to bar", "name": "foo"},
        {"type": "str", "description": "the bar to foo", "name": "bar"},
    ]


# Generated at 2022-06-21 12:04:48.822348
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GOOGLE

    # A docstring in google style
    text = """A short summary.
    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`
    Returns:
        bool: Description of return value"""
    doc = parse(text)
    assert doc.short_description == 'A short summary.'
    assert len(doc.long_description) == 0
    assert len(doc.params) == 2
    assert len(doc.returns) == 1
    assert doc.returns[0].arg_name == 'bool'

    # A docstring in numpy style

# Generated at 2022-06-21 12:04:55.098012
# Unit test for function parse
def test_parse():
    docstring = """\
    Overview line (function name)

    Function description

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str, optional
        Description of arg2

    Returns
    -------
    int
        Description of return value

    Raises
    ------
    AttributeError
        Description of exception
    """
    d = parse(docstring, style=Style.numpy)
    assert d.short_description == "Overview line (function name)"
    assert d.long_description == ["Function description"]
    assert d.returns.arguments == [("int", "Description of return value")]
    assert d.yields.arguments == []

# Generated at 2022-06-21 12:05:06.401483
# Unit test for function parse
def test_parse():
    chunk = """
    Function to reduce the rotation angle

    Parameters
    ----------
    angle: float
        angle to reduce

    Returns
    -------
    out: float
        reduced angle
    """

    # parse
    d = parse(chunk)

    # check
    assert d.short_description == "Function to reduce the rotation angle"
    assert d.long_description == ""
    assert len(d.params) == 1
    assert len(d.returns) == 1
    assert d.params[0].name == "angle"
    assert d.params[0].type == "float"
    assert d.params[0].description == "angle to reduce"
    assert d.returns[0].name == "out"
    assert d.returns[0].type == "float"
    assert d.returns[0].description