

# Generated at 2022-06-21 11:55:19.177541
# Unit test for function parse
def test_parse():
    text = """
    :param self:
    :param text: text to parse
    :returns: docstring representation
    :raises ParseError: if a parsing fails
    """

    parsed = parse(text)
    assert parsed.params[0].arg_name == 'self'
    assert parsed.params[0].description == ''
    assert parsed.params[1].arg_name == 'text'
    assert parsed.params[1].description == 'text to parse'
    assert parsed.returns.description == 'docstring representation'
    assert parsed.raises[0].exception_name == 'ParseError'
    assert parsed.raises[0].description == 'if a parsing fails'

################################################################################
#                                                                              #
#                           TEST FUNCTIONS FOR MODULE                          #
#                                                                              #

# Generated at 2022-06-21 11:55:27.431768
# Unit test for function parse
def test_parse():
    import docstring_parser

    text = """One line summary.

    Extended description.

    :param arg: description
    :type arg: str
    :returns: description
    :rtype: int

    """

    docstring = docstring_parser.parse(text, docstring_parser.Style.numpy)
    assert type(docstring) is docstring_parser.Docstring

    assert docstring.short_description == "One line summary."
    assert docstring.long_description == "Extended description."
    assert docstring.extended_description == []
    assert docstring.params['arg'].description == 'description'
    assert docstring.params['arg'].type_name == 'str'
    assert docstring.returns.description == 'description'
    assert docstring.returns.type_name == 'int'
   

# Generated at 2022-06-21 11:55:31.107870
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """\
    This is my docstring.
    """
    assert parse(text).short_description == 'This is my docstring.'

# Generated at 2022-06-21 11:55:35.250561
# Unit test for function parse
def test_parse():
    from docstring_parser import parse, ParseError

    docstrings = (
        """Summary line.

This is a function which returns the second input argument.

This is a longer description which spans over several
lines of text.

:param str1: first string
:param str2: second string
:returns: the second input argument
:rtype: str
:raises ValueError: if the second input argument is 'raises'
""",
        """Short summary.

This is a long description. It spans over several
lines of text, and is not a single line.
""",
        """Short summary.

:param a_str: str
:return: None
:raises TypeError: if a is not str
""",
    )

    l = len(parse(docstrings[0]).params)  # 3

# Generated at 2022-06-21 11:55:38.540098
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    assert parse("""Test
    =============""") == Docstring(summary='Test',
                                   body='',
                                   return_type='',
                                   return_desc='')

# Generated at 2022-06-21 11:55:48.364131
# Unit test for function parse
def test_parse():
    def function_test_parse():
        """
        Test function parse(text, style)

        :param text: text to parse
        :param style: docstring style
        """
        pass
    docstring = parse(function_test_parse.__doc__)
    assert hasattr(docstring, 'params')
    assert hasattr(docstring, 'returns')
    assert hasattr(docstring, 'meta')
    assert hasattr(docstring.returns, 'type')
    assert hasattr(docstring.returns, 'desc')
    assert hasattr(docstring.params, 'type')
    assert hasattr(docstring.params, 'desc')

    assert len(docstring.params) == len(docstring.params.desc)
    assert len(docstring.params) == len(docstring.params.type)




# Generated at 2022-06-21 11:55:49.400664
# Unit test for function parse
def test_parse():
    assert 1 == 1

# Generated at 2022-06-21 11:55:56.652849
# Unit test for function parse
def test_parse():
    docstring = """
    Summary line.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    bool
        Description of return value

    Other Parameters
    ----------------
    arg3 : list
        Description of arg3
    """
    print(parse(docstring))

if __name__=='__main__':
    test_parse()

# Generated at 2022-06-21 11:56:05.487141
# Unit test for function parse
def test_parse():
    import io
    import os
    import unittest

    def _test(s, style):
        print("Style is", style)
        print(s)
        ds = parse(s, style)
        print("Summary:", ds.summary)
        print("Description:")
        print(ds.description)
        print("Metadata:")
        for key in ds.meta.keys():
            print("\t{0:25}: {1}".format(key, ds.meta[key]))

    def _read(fn):
        with io.open(
            os.path.join(os.path.dirname(__file__), "parsing", fn),
            encoding="utf-8",
        ) as f:
            return f.read()


# Generated at 2022-06-21 11:56:10.084962
# Unit test for function parse
def test_parse():
    text = """\
    This is a one line summary.

    This is a longer description.
    It spans multiple lines.

    :param name: param description
    :type name: param type
    :returns: return description
    :rtype: return type

    """
    print(parse(text))

# Generated at 2022-06-21 11:56:18.448157
# Unit test for function parse
def test_parse():
    docstring = '''This is a function. Use it.
    :param arg1: this one is for testing
    :param arg2: hello world
    :returns int: hello world
    :raises ValueError: If something bad happens
    '''

    # return value of parse() is typed as docstring_parser.Docstring
    parsed = parse(docstring)
    print(parsed.summary)
    print(parsed.returns)
    print(parsed.params)
    print(parsed.raises)
    print(parsed.meta)
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:28.441348
# Unit test for function parse
def test_parse():
    import os
    import re
    from pathlib import Path
    from pprint import pprint
    import ast

    path = os.path.dirname(__file__)
    with open(os.path.join(path, 'test_snippets/docstrings.py')) as f:
        source = f.read()

    # automatically be discovered by the current script
    _test_pattern = re.compile(
        r'#\s*doctest\s+python3?(?P<options>(?:\s+\S+)+)'
        r'\s*(?P<code>.*?)\s*$',
        re.M | re.S,
    )

    # test that the docstring is able to be parsed.

    for match in _test_pattern.finditer(source):
        code = ast

# Generated at 2022-06-21 11:56:30.085740
# Unit test for function parse
def test_parse():
    """Unit test for fuction parse"""
    pass

# Example usage

# Generated at 2022-06-21 11:56:40.276149
# Unit test for function parse
def test_parse():
    text = '''
    :param a: Short description
    :param b:
        Long description
        On two lines

        :type b: str

        With extra stuff

    :returns: Return description
    '''
    doc = parse(text)
    print(doc)
    assert doc.short_description == ''
    assert doc.long_description == ''
    assert doc.returns == 'Return description'
    assert len(doc.params) == 2
    assert doc.params['a'].arg_name == 'a'
    assert doc.params['a'].description == 'Short description'
    assert doc.params['a'].annotation == None
    assert doc.params['a'].default == None
    assert doc.params['b'].description == """
        Long description
        On two lines
    """

# Generated at 2022-06-21 11:56:44.599017
# Unit test for function parse
def test_parse():
    text = r'''
    Docstring for class 
    """
    This is a class with one method

    :param x: int
    :returns: int
    """'''

    r1 = parse(text, Style.reST)
    print([r1])



# Generated at 2022-06-21 11:56:46.287075
# Unit test for function parse
def test_parse():
    pass

if __name__ == '__main__':
  test_parse()

# Generated at 2022-06-21 11:56:51.123556
# Unit test for function parse
def test_parse():

    # Test for Style.auto
    assert parse("test") == parse("test", style=Style.auto)

    # Test for Style.numpy
    assert parse("test", style=Style.numpy) == parse("test", style=Style.numpy)

    # Test for Style.google
    assert parse("test", style=Style.google) == parse("test", style=Style.google)

# Generated at 2022-06-21 11:56:56.451817
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    text = '''This is a test docstring.

    It should contains description, parameter and return information.

    :param a: parameter a
    :type a: int
    :param b: parameter b
    :param c: parameter c
    :returns: the sum
    :rtype: int
    '''
    parsed_docstring = parse(text)
    print(parsed_docstring.to_dict())

# Generated at 2022-06-21 11:57:07.123600
# Unit test for function parse
def test_parse():
    import unittest
    import docstring_parser
    import os

    class TestParse(unittest.TestCase):
        def setUp(self):
            # find the current location of the test file
            self.filename = os.path.abspath(os.path.join(os.path.dirname(__file__),"parse_test.py"))

            # get the docstrings from the test file
            with open(self.filename, "r") as f:
                self.functions = docstring_parser.parse(f.read())

            # pull out the "parse" function
            self.parseFunction = self.functions[0]

        # make sure the parse function is documented correctly
        # TODO: make better

# Generated at 2022-06-21 11:57:10.419310
# Unit test for function parse
def test_parse():
    text = '''\
Matlab style docstrings

Parameters
----------
x ... an integer

Returns
-------
y ... an integer'''
    print(repr(parse(text)))
    print(repr(parse(text, Style.matlab)))
    print(repr(parse(text, Style.google)))


# Generated at 2022-06-21 11:57:23.368121
# Unit test for function parse
def test_parse():
    text = """
    A function with a docstring.

    :param arg1: The first argument
    :type arg1: str
    :param arg2: The second argument
    :type arg2: str
    :returns: None
    :raises someexception: Because you shouldn't have done that
    """
    result = parse(text)
    assert result.short_description == 'A function with a docstring.'
    assert result.long_description == ''
    assert result.returns is None
    assert result.raises is None
    assert len(result.params) == 2
    assert len(result.meta) == 4


# Generated at 2022-06-21 11:57:26.611095
# Unit test for function parse
def test_parse():
    text = """This is one line documentation.
    This is second line.
    This is third line.
    """
    style = Style.numpy
    with pytest.raises(ParseError):
        parse(text, style)



# Generated at 2022-06-21 11:57:28.504197
# Unit test for function parse
def test_parse():
    assert parse('Hello, World!') == Docstring(summary='Hello, World!')

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:57:36.755495
# Unit test for function parse
def test_parse():
    docstring = """VISUALIZATION PIPELINE
    Args:
        image_path: path to image
        style: style of image
    Returns:
        image_object : Image object
    """
    assert parse(docstring, style=Style.google).args == [("image_path", "path to image"), ("style", "style of image")]
    assert parse(docstring, style=Style.google).returns == [("image_object", "Image object")]
    assert parse(docstring, style=Style.google).meta == ["VISUALIZATION PIPELINE"]



# Generated at 2022-06-21 11:57:45.221724
# Unit test for function parse
def test_parse():
  if __name__ == '__main__':
    ps = parse("""
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """)
    print(ps.short_description)
    print(ps.long_description)
    print(ps.parameters)
    print(ps.returns)
    print(ps.meta)
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:57:49.526537
# Unit test for function parse
def test_parse():
    comment = """
    Hello,
    something about the function ..
    """
    #print("Comment: ", comment)
    #print("Parsed Comment: ", parse(comment))
    #print("Parsed Comment: ", parse(comment).short_description)
    #print("Parsed Comment: ", parse(comment).long_description)

#test_parse()

# Generated at 2022-06-21 11:57:54.254339
# Unit test for function parse
def test_parse():
    """Test parse function"""

    text = """
    This is a test function.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :returns: None
    :raises ValueError: if arg1 is equal to arg2.

    """
    ret = parse(text)
    assert ret.brief == "This is a test function."

# Generated at 2022-06-21 11:58:02.885914
# Unit test for function parse
def test_parse():
    text = '''This is a docstring.

This is a paragraph in the docstring. It may span multiple
lines.

:param somelongvariable: some long variable
:type somelongvariable: str
'''
    ret = parse(text)
    assert ret.short_description == 'This is a docstring.'
    assert ret.long_description == '\nThis is a paragraph in the docstring. It may span multiple\nlines.'
    assert ret.return_type == None
    assert ret.meta == {'somelongvariable': ('some long variable', 'str')}

# Generated at 2022-06-21 11:58:06.070090
# Unit test for function parse
def test_parse():
    text = '''
    This is a simple documentation.
    '''
    parsed_doc = parse(text)
    assert parsed_doc.short_description == 'This is a simple documentation.'


# Generated at 2022-06-21 11:58:15.519694
# Unit test for function parse
def test_parse():
    text = "This function is to test parse function."
    style = Style.numpy
    print(parse(text, style))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:58:23.817993
# Unit test for function parse
def test_parse():
    docstr = """
    This is a summary

    Parameters:
        a : int
            the first parameter
        b : float
            the second parameter

    Returns:
        str: a string
    """
    doc = parse(docstr, Style.google)
    assert doc.summary == "This is a summary"
    assert doc.returns.type == "str"
    assert doc.returns.desc == "a string"

    assert len(doc["Parameters"]) == 2
    assert doc["Parameters"][0].name == "a"
    assert doc["Parameters"][1].name == "b"

# Generated at 2022-06-21 11:58:25.920838
# Unit test for function parse
def test_parse():
    assert True

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:58:35.395572
# Unit test for function parse
def test_parse():
    text = '''The class instance variable is used to count the number of times
    the increment() method has been called. The count() method returns the
    current value of the counter.
    Args:
        val (int): The initial value of the counter.
    '''
    result = parse(text)
    assert result.short_description == 'The class instance variable is used to count the number of times the increment() method has been called. The count() method returns the current value of the counter.'
    assert result.long_description == ''
    assert result.meta['Args'] == 'The initial value of the counter.'
    assert result.meta['Args'].type_name == 'int'


# Generated at 2022-06-21 11:58:44.757375
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "", "", "", [])
    assert parse("one\nline\ndocstring".replace("\n", "\\n")) == Docstring("", "", "", "one line docstring", [])
    assert parse("one\n\nline\n\ndocstring".replace("\n", "\\n")) == Docstring("", "", "", "one line docstring", [])
    assert parse("start\n\none\n\nline\n\ndocstring\nend".replace("\n", "\\n")) == Docstring("start", "one", "line", "docstring", [])

# Generated at 2022-06-21 11:58:52.801819
# Unit test for function parse
def test_parse():
    assert parse("""
.. rubric:: Arguments

    :param a: first parameter
    :type a: :class:`str`
    :param b: second parameter
    :type b: :class:`int`
""") == Docstring(
        meta=[('param', 'a', 'first parameter'), ('type', 'a', ':class:`str`'), ('param', 'b', 'second parameter'), ('type', 'b', ':class:`int`'), ('rubric', 'Arguments', '')],
        content='\n',
        )

# Generated at 2022-06-21 11:59:00.480826
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.google import GoogleDocstring
    docstring = '''Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    parsed = parse(docstring)
    assert isinstance(parsed, GoogleDocstring)

    docstring = """
    This is a docstring by epytext style.

    @author: Hequn
    @date: 02/06/2020
    """
    from docstring_parser.styles.epytext import EpytextDocstring
    parsed = parse(docstring)
    assert isinstance(parsed, EpytextDocstring)


# Generated at 2022-06-21 11:59:01.880499
# Unit test for function parse
def test_parse():
    assert parse('Return a foo.').returns.description == 'Return a foo.'

# Generated at 2022-06-21 11:59:04.023455
# Unit test for function parse
def test_parse():
    docstring = ''' 123456789 '''

    assert parse(docstring, style=Style.auto) == Docstring(description='', meta=dict())

# Generated at 2022-06-21 11:59:08.319602
# Unit test for function parse
def test_parse():
    text = '''
    :param gfg: kj
    :return: None
    :rtype: None
    '''
    parsed_text = parse(text)
    assert parsed_text is not None
    assert parsed_text.long_description is not None
    assert len(parsed_text.meta) > 0
    assert parsed_text.meta['param'][0]['name'] == 'gfg'

# Generated at 2022-06-21 11:59:14.629770
# Unit test for function parse
def test_parse():
    docstring = """This is one sentence.
    This is another sentence."""
    doc = parse(docstring)
    print("Title: ", doc.title)
    print("Description: ", doc.description)
    print("Short Description: ", doc.short_description)
    print("Long Description: ", doc.long_description)
    print("Sections: ", doc.sections)
    print("Meta: ", doc.meta)
    print("Style: ", doc.style)


# Generated at 2022-06-21 11:59:23.038391
# Unit test for function parse
def test_parse():
    text = """
    This is a method to do something.

    :param foo: the foo argument
    :type foo: any
    :param bar: the bar argument
    :type bar: any
    :returns: a value
    :rtype: any
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a method to do something."
    assert docstring.long_description is None
    assert docstring.params[0].name == "foo"
    assert docstring.params[1].name == "bar"
    assert docstring.returns.name is None
    assert docstring.returns.desc == "a value"

# Generated at 2022-06-21 11:59:25.520913
# Unit test for function parse
def test_parse():
    text = '''The main parsing routine.'''
    assert parse(text) == Docstring(summary='The main parsing routine.',
                                    meta=[])


if __name__ == '__main__':
    # test_parse()
    print(parse.__doc__)

# Generated at 2022-06-21 11:59:28.844133
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    :return: Nothing
    """
    try:
        parse("")
    except Exception:
        pass


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:38.227617
# Unit test for function parse
def test_parse():
    docstring = """
    Multiply two numbers.

    Arguments:
        a: First number
        b: Second number

    Returns:
        Product of two numbers

    Raises:
        ZeroDivisionError: Raised when b is zero
    """
    expected = Docstring(
        content=["Multiply two numbers."],
        args=[
            ("a", "First number"),
            ("b", "Second number")
        ],
        ret="Product of two numbers",
        exceptions=[
            ("ZeroDivisionError", "Raised when b is zero")
        ]
    )
    assert parse(docstring) == expected



# Generated at 2022-06-21 11:59:49.679488
# Unit test for function parse

# Generated at 2022-06-21 12:00:01.617048
# Unit test for function parse
def test_parse():
    docstring = '''\
    A short summary of the object.

    The first line is brief explanation, which may be completed with
    a longer one. For instance to discuss about its methods. The only
    method here is :func:`function1`. The main idea is to document
    the class and methods and to extract validation tests.

    :param arg1: description of arg1, (type:`str`, default:`None`)
    :param arg2: description of arg2
    :type arg3: str
    :param arg3: description of arg3
    :type arg4: list of str

    :returns: output of the function
    :raises keyError: raises an exception
    '''
    doc = parse(docstring)
    assert doc['summary'] == 'A short summary of the object.'

# Generated at 2022-06-21 12:00:12.752031
# Unit test for function parse
def test_parse():
    docstring = parse("""This function does things
    :param foo: bar parameter
    :param a: b""")
    assert docstring.short_description == "This function does things"
    assert docstring.long_description == ""
    assert docstring.params["foo"].description == "bar parameter"
    assert docstring.params["a"].description == "b"
    assert docstring.meta == {}
    assert not docstring.returns

    docstring = parse("""This function does things

    Long description.
    :param foo: bar parameter
    :param a: b
    :returns: None
    :rtype: None
    :raises TypeError: if nothing happened
    """)
    assert docstring.short_description == "This function does things"
    assert docstring.long_description == "Long description."
   

# Generated at 2022-06-21 12:00:17.077924
# Unit test for function parse
def test_parse():
    """Test function parse"""
    print(parse("""
    This is a docstring.
    Here is some more information about it.

    :param key1: value for key1
    :type key1: str
    :param key2: value for key2
    :type key2: int
    :returns: the return value
    :rtype: int
    """))


# Generated at 2022-06-21 12:00:26.326584
# Unit test for function parse
def test_parse():
    """Test parser function."""
    assert parse('Test') == Docstring(summary='Test')
    assert parse('\nTest\n') == Docstring(summary='Test')
    assert parse(' Test ') == Docstring(summary='Test')
    assert parse(' Test', style='google') == Docstring(summary='Test')
    assert parse('\nTest\n', style='google') == Docstring(summary='Test')
    assert parse(' Test ', style='google') == Docstring(summary='Test')
    assert parse('Test', style='google') == Docstring(summary='Test')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:29.895935
# Unit test for function parse
def test_parse():
    """Function to run unit test for module"""

    from docstring_parser import parse
    parse('''
    Hello

    :example:
        >>> print(hello)
        hello
    ''')

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:00:43.410092
# Unit test for function parse
def test_parse():
    """Test parse function."""
    import inspect
    docstring = """\
    This is a short description.

    This is a long
    description.
    """

    ds = parse(docstring, Style.auto)
    assert ds.short_desc == "This is a short description."
    assert ds.long_desc.endswith("description.")
    assert ds.long_desc_start == 1
    assert ds.long_desc_end == 7
    assert ds.meta == {}
    assert ds.examples == []
    assert ds.style == Style.sphinx

    sig, ds = parse(inspect.getdoc(DS_ALIGN_ARGS.__init__))
    assert sig == "DS_ALIGN_ARGS(arg1, ar2)"

# Generated at 2022-06-21 12:00:46.558003
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(name="parse", verbose=True)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:57.168443
# Unit test for function parse
def test_parse():
    """Test for the parsing of the docstring."""

    text = '''
    Desc: This is the description for the docstring.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    doc_obj = parse(text, style=Style.auto)
    assert doc_obj.short_description == 'This is the description for the docstring.'
    assert doc_obj.long_description == '\n'
    assert doc_obj.meta[0].type_name == 'param'
    assert doc_obj.meta[0].name == 'text'
    assert doc_obj.meta[0].description == 'docstring text to parse'
    assert doc_obj.meta[1].type_name == 'param'

# Generated at 2022-06-21 12:01:07.548672
# Unit test for function parse
def test_parse():
	text = '''
	      This is a class
	
	      :classname: `MyClass`
	      :classdesc: This is a class
	
	      :param foo: some description
	      :type foo: str
	      :param bar: another description
	      :type bar: int
	
	      :returns: something
	      :rtype: str
	
	      :attritube: some attribute
	
	      :raises: SomeError
	
	      :version: 1.0
	
	      :author: someone
	
	      :date: Nov 25, 2019
	      '''
	style = Style.numpy
	parse(text,style)
	

# Generated at 2022-06-21 12:01:17.256069
# Unit test for function parse
def test_parse():
    text = '''
    this is a signature.
    :param arg1: this is arg1.
    :param arg2: this is arg2.
    :returns: description of return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'this is a signature.'
    assert docstring.long_description == ''
    assert len(docstring.meta) == 2
    assert docstring.meta['arg1'] == 'this is arg1.'
    assert docstring.meta['arg2'] == 'this is arg2.'
    assert docstring.returns == 'description of return value'
    assert docstring.returns_description == ''
    assert docstring.decorators == []

# Generated at 2022-06-21 12:01:25.418321
# Unit test for function parse
def test_parse():
    """
    Test function docstring_parser.parse(text, style)
    """
    from docstring_parser.styles import GoogleStyle
    import numpy as np
    
    text = """
    """
    
    # Test 1: style = Style.google, no docstring
    try:
        assert GoogleStyle(text) == parse(text, Style.google)
    except ParseError:
        print("Case 1: Pass!")

    # Test 2: style = Style.google, docstring with no module
    text = """
    """
    try:
        assert GoogleStyle(text).module is None
    except ParseError:
        print("Case 2: Pass!")

    # Test 3: style = Style.google, docstring with no module
    text = """
    """

# Generated at 2022-06-21 12:01:35.350199
# Unit test for function parse
def test_parse():
    docstr = '''    Short summary.

    Long summary.

    Longer summary.

    Parameters
    ----------
    arg1, arg2 : str
        The two args.
    arg3 : int, optional
        The third arg.

    Returns
    -------
    list, optional
        A list of integers.

    Raises
    ------
    ValueError
        When arg1 < 0.

    See Also
    --------
    arg1, arg2, arg3

    References
    ----------
    .. [REF] reference citation

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    additional notes.
    further notes.
    '''

    docstr_parsed = parse(docstr)

    assert docstr_parsed.short_description == 'Short summary.'

# Generated at 2022-06-21 12:01:41.135843
# Unit test for function parse
def test_parse():
    text = '''
        Parameters
        ----------
        :param data: optional

    '''
    param_test = parse(text, style=Style.google)
    assert len(param_test.params) == 0
    assert len(param_test.meta) == 1
    assert param_test.meta[0]['name'] == 'data'
    assert param_test.meta[0]['type'] == 'optional'
    assert param_test.meta[0]['description'] == ''

# Generated at 2022-06-21 12:01:46.314976
# Unit test for function parse
def test_parse():
    text = """The parse method returns a Docstring summary, description, and the
the parameters and return values in the docstring"""
    docstring = parse(text)
    assert docstring.summary == 'The parse method returns a Docstring summary, description, and the the parameters and return values in the docstring'
    assert docstring.description == ''
    assert len(docstring.params) == 0
    assert len(docstring.returns) == 0

# Generated at 2022-06-21 12:01:56.512995
# Unit test for function parse
def test_parse():

    text = "A long description of the module, which can be" \
           "multiple lines long"
    doc = parse(text, style = Style.google)
    assert(doc.long_description == text)

    text = "A short description of the function, which can be" \
           "multiple lines long"
    doc = parse(text, style = Style.google)
    assert(doc.short_description == text)

    text = "parameter1 -- Explanation of the parameter1"
    doc = parse(text, style = Style.google)
    assert(doc.params['parameter1'] == 'Explanation of the parameter1')


# Generated at 2022-06-21 12:02:08.351357
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param arg1: Description of arg1
:param arg2: Description of arg2
:returns: Description of return value
:raises keyError: raises an exception
:var test: description of test variable
:var test2: description of test2 variable
"""

    docstring = parse(text)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."
    assert docstring.extended_description == "Extended description."
    assert docstring.returns.description == "Description of return value"
    assert docstring.meta["keyError"] == "raises an exception"
    assert docstring.meta["test"] == "description of test variable"

# Generated at 2022-06-21 12:02:18.316824
# Unit test for function parse
def test_parse():
    print("==========Test parse()==========")
    docstring = '''\
    This is a test docstring
    This is the second line.
    '''
    result = parse(docstring)

    print(result.short_description)
    assert result.short_description == 'This is a test docstring'
    print(result.long_description)
    assert result.long_description == 'This is the second line.'
    print(result.meta)
    assert result.meta == dict()
    print(result.style)
    assert result.style == 'google'

    docstring = '''\
    This is a test docstring.
    This is the second line.
    '''
    result = parse(docstring)

    print(result.short_description)

# Generated at 2022-06-21 12:02:29.918216
# Unit test for function parse
def test_parse():
    """Test parse with different docstring styles."""

# Generated at 2022-06-21 12:02:36.287791
# Unit test for function parse
def test_parse():
    assert parse("", style = Style.numpy) == parse("", style = Style.google)
    assert parse("", style = Style.numpy) == parse("", style = Style.auto)
    assert parse("asd", style = Style.numpy) != parse("", style = Style.google)
    assert parse("asd", style = Style.numpy) != parse("", style = Style.auto)
    assert parse("asd", style = Style.numpy) == parse("asd", style = Style.auto)

# Generated at 2022-06-21 12:02:47.528891
# Unit test for function parse

# Generated at 2022-06-21 12:02:58.882407
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google, NumPy
    import pytest

    s = '''\
    Function to do something.

    This function does something.

    Args:
        a (int): an integer.
        b (int)
        c (float): a floating point number.

    Returns:
        int: something.

    Example:
        >>> import some_module
        >>> some_module.some_function()
        '''


# Generated at 2022-06-21 12:03:01.736498
# Unit test for function parse
def test_parse():
    text = '''
    This is a test for the parse function.
    '''
    assert parse(text).short_description == "This is a test for the parse function."

# Generated at 2022-06-21 12:03:11.420195
# Unit test for function parse
def test_parse():
    text = '''
    Short summary.

    More detailed description. Can contain several paragraphs.

    :param arg1: description of arg1
    :type arg1: str
    :param arg2: description of arg2
    :type arg2: int, optional
    :returns: description of return value
    :rtype: bool
    :raises keyError: description of exception
    '''
    docstring = parse(text)

    assert docstring.short_description == 'Short summary.'
    assert len(docstring.long_description) == 2
    assert docstring.returns.description == 'description of return value'
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].description == 'description of arg1'
    assert len(docstring.raises) == 1
    assert docstring.ra

# Generated at 2022-06-21 12:03:17.080941
# Unit test for function parse
def test_parse():
    text = """\
Synoposis
---------
The synoposis goes here

This is a test.
    """
    expected = Docstring(
        summary='The synoposis goes here',
        description='This is a test.',
        meta={'Synoposis': 'The synoposis goes here'},
    )
    actual = parse(text)
    assert actual == expected

# Generated at 2022-06-21 12:03:25.433554
# Unit test for function parse
def test_parse():
    from docstring_parser.common import parse_docstring
    from docstring_parser.styles.google import GoogleDocstring
    from docstring_parser.styles.numpy import NumpyDocstring
    from docstring_parser.styles.restructuredtext import RestructuredtextDocstring
    def f():
        """Return func name.

        Args:
            arg1: first arg
            arg2: second arg
        """

    docstring = parse_docstring(f.__doc__)
    assert isinstance(docstring, NumpyDocstring)
    assert docstring == f.__doc__
    assert repr(docstring) == repr(f.__doc__)
    assert docstring == parse(f.__doc__)
    assert docstring == parse(f.__doc__, Style.numpy)

# Generated at 2022-06-21 12:03:36.128871
# Unit test for function parse
def test_parse():

    assert parse('no args') == Docstring(summary='no args')
    assert parse('no args', style=parse.__no_type_check__) == Docstring(summary='no args')
    assert parse('no args', style=parse.__no_type_check__) == Docstring(summary='no args')
    assert parse('no args', style='sphinx') == Docstring(summary='no args')
    assert parse('no args', style='google') == Docstring(summary='no args')
    assert parse('no args', style='numpy') == Docstring(summary='no args')
    assert parse('no args', style='both/go/no') == Docstring(summary='no args')

# Generated at 2022-06-21 12:03:38.309992
# Unit test for function parse
def test_parse():
    test_function = parse("this is a test")
    assert test_function.short_description == "this is a test"

# Generated at 2022-06-21 12:03:48.807527
# Unit test for function parse
def test_parse():
    text = """Short summary.
      
      Longer description.
      
      """
    d = parse(text)
    assert d.short_description == 'Short summary.'
    assert d.long_description == 'Longer description.\n\n'
    assert d.style == 'numpy'
    assert isinstance(d.params, list)
    assert len(d.params) == 0
    assert isinstance(d.returns, list)
    assert len(d.returns) == 0
    assert isinstance(d.raises, list)
    assert len(d.raises) == 0
    assert isinstance(d.meta, dict)
    assert len(d.meta) == 0

# Generated at 2022-06-21 12:03:57.007954
# Unit test for function parse
def test_parse():
    text = """\
    This docstring illustrates that the contents of the
    first line are ignored, and that blank lines at the beginning
    and end of the docstring are ignored.

    Parameters
    ----------
    arg1 : int
        Description of `arg1` (with typos)
        which is really great.
    arg2 : str
        Description of `arg2`

    Raises
    ------
    Exception
        Because you shouldn't have done that.

    Returns
    -------
    int
        Description of return value
    """
    assert parse(text) == parse(text, Style.google)

# Generated at 2022-06-21 12:03:59.184807
# Unit test for function parse
def test_parse():
    """Test function parse."""
    doc = """
    This is test.
    """
    assert parse(doc).content == doc


# Generated at 2022-06-21 12:04:10.222156
# Unit test for function parse
def test_parse():
    text = '''\
    Summary line here.

    Extended description here.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    bool
        Description of return value
    '''

    docstring = parse(text)
    assert docstring.summary == 'Summary line here.'
    assert docstring.extended_summary == 'Extended description here.'
    assert docstring.params == [
        ('arg1', 'int', 'Description of arg1'),
        ('arg2', 'str', 'Description of arg2')
    ]
    assert docstring.returns == ('bool', 'Description of return value')
    assert docstring.yields == ()
    assert docstring.raises == ()
    assert docstring.other == []
   

# Generated at 2022-06-21 12:04:21.651553
# Unit test for function parse
def test_parse():

    assert(parse.__doc__ is not None)

    assert(parse('Parse the docstring into its components.',
                 style=Style.numpy)
           == Docstring(short_description='Parse the docstring into its components.'))

    assert(parse('Parse the docstring into its components.',
                 style=Style.google)
           == Docstring(short_description='Parse the docstring into its components.'))

    assert(parse('Parse the docstring into its components.',
                 style=Style.reST)
           == Docstring(short_description='Parse the docstring into its components.'))

    assert(parse('Parse the docstring into its components.')
           == Docstring(short_description='Parse the docstring into its components.'))

test_parse()

# Generated at 2022-06-21 12:04:29.544916
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    from docstring_parser.common import Docstring, ParseError

    from docstring_parser.styles import BaseStyle

    text = "hello world"
    style = Style.local
    parsed = parse(text, style)
    assert parsed.short_description == text
    assert parsed.long_description == ""
    assert parsed.meta == {}

    text = "hello world\n"
    style = Style.local
    parsed = parse(text, style)
    assert parsed.short_description == text
    assert parsed.long_description == ""
    assert parsed.meta == {}

    text = "hello world\n\nThere is\nthis."
    style = Style.local
    parsed = parse(text, style)
    assert parsed.short_description == "hello world"
    assert parsed

# Generated at 2022-06-21 12:04:38.074050
# Unit test for function parse
def test_parse():
    text = '''
    ..

    Main section

    sub section
    '''
    assert parse(text).short_description == 'Main section'
    assert parse(text).long_description == 'Main section\n\nsub section'
    assert parse(text).meta == {'author': '', 'contact': '', 'copyright': '', 'date': '', 'deprecated': False,
                                'example': '', 'see_also': '', 'status': '', 'todo': '', 'version': ''}
    assert parse(text).returns == None
    assert parse(text).yields == None



# Generated at 2022-06-21 12:04:39.567878
# Unit test for function parse
def test_parse():
    parse("This is a simple docstring")

# Generated at 2022-06-21 12:04:50.897110
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google
    text = """Return a list of students with the given `first_name` and `last_name` and the provided `year` and all other
    paramaters.
    Args:
        first_name (str, optional): The first name of the student.
        last_name (str, optional): The last name of the student.
        year (int, optional): The year of the student.
        age (int, optional): The age of the student.
    
    Returns:
        List[str]: A list of strings that represents the students with the given params.
    """
    result = parse(text, style=Google)
    assert result.returns[0].descriptions == ['A list of strings that represents the students with the given params.']

# Generated at 2022-06-21 12:04:55.571576
# Unit test for function parse
def test_parse():
    """
    >>> parse('Hello \\n World')
    <Docstring: 'Hello \\n World'>
    
    >>> parse('')
    <Docstring: ''>
    """

    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:05:06.576897
# Unit test for function parse
def test_parse():
    assert not parse("")
    assert parse("") == parse(" ") == parse("\n")

    assert parse("Hello") == parse("Hello\n") == parse("Hello\n\n")
    assert parse("Hello\nworld") == parse("Hello\nworld\n") == parse("Hello\nworld\n\n")

    doc = parse("#$Hello")
    assert doc.short_desc == "Hello"
    assert doc.long_desc == ""
    assert doc.meta == []

    doc = parse("#$Hello\nWorld")
    assert doc.short_desc == "Hello"
    assert doc.long_desc == "World"
    assert doc.meta == []

    doc = parse("#$ Hello\nWorld")
    assert doc.short_desc == "Hello"
    assert doc.long_desc == "World"
   