

# Generated at 2022-06-21 11:55:21.738777
# Unit test for function parse
def test_parse():
    """Function to test the docstring parser."""
    # Simple docstring to test
    test_string = """
    This is the first line of the docstring.

    This is the second line of the docstring.

    :param a: This is the first parameter.
    :type a: int

    :param b: This is the second parameter.
    :type b: float

    :return: This is returned
    :rtype: int
    """

    # Parse the docstring
    test_parsed = parse(test_string)

    # Check the summary line to be as expected
    assert test_parsed.summary == "This is the first line of the docstring."

    # Check the parameters to be as expected

# Generated at 2022-06-21 11:55:24.625855
# Unit test for function parse
def test_parse():
    from docstring_parser.util import get_docstring
    d = parse(get_docstring(parse))
    assert str(d).startswith('The main parsing routine.')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:30.322137
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    parsed_napoleon = parse("""
    This is a function.

    :param int x: a parameter
    :returns: a return value
    """, style=Style.napoleon)

    assert parsed_napoleon.summary == 'This is a function.'
    assert parsed_napoleon.returns == 'a return value'
    assert parsed_napoleon.params['x'].full_name == 'x'
    assert parsed_napoleon.params['x'].type == 'int'
    assert parsed_napoleon.params['x'].summary == 'a parameter'


# Generated at 2022-06-21 11:55:34.252774
# Unit test for function parse
def test_parse():
    text='This is a test'
    result = parse(text)
    expected = Docstring(description='This is a test', examples=None,
                                  returns=None, raises=None, params=None, meta=None)
    assert(result == expected)


# Generated at 2022-06-21 11:55:38.234585
# Unit test for function parse
def test_parse():

    model_docstring = parse('''The main parsing routine.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    ''')

    assert model_docstring.summary == "The main parsing routine."

# Generated at 2022-06-21 11:55:48.125846
# Unit test for function parse
def test_parse():
    docstring = parse("""\
    One line summary.

    Extended description.

    :param foo: Foo param description.
    :type foo: int
    :param bar: Bar param description.
    :type bar: str
    :returns: Nothing
    :rtype: None
    :raises ValueError: If anything goes wrong.
    :raises TypeError: If anything else goes wrong.

    More description after the fields.
    """)
    assert docstring.short_description == "One line summary."
    assert docstring.long_description == "Extended description.\n\nMore description after the fields."
    assert docstring.params == {
        'foo': 'Foo param description.',
        'bar': 'Bar param description.',
    }
    assert docstring.returns == 'Nothing'

# Generated at 2022-06-21 11:55:59.741304
# Unit test for function parse
def test_parse():
    text = '''
        :param x:
            The x attribute.
        :param y:
            The y attribute.
    '''
    d = parse(text, style=Style.google)
    assert d.meta['args'] == {'x': 'The x attribute.', 'y': 'The y attribute.'}

    text = '''
        :param x:
            The x attribute.
        :param y:
            The y attribute.
        :raises KeyError:
            Raised when x is not present in the dictionary.
    '''
    d = parse(text, style=Style.google)
    assert d.meta['args'] == {'x': 'The x attribute.', 'y': 'The y attribute.'}

# Generated at 2022-06-21 11:56:12.481405
# Unit test for function parse
def test_parse():
    # Test for function parse for a docstring of Google Style
    text = '''\
    This is a multi line docstring
    Args:
        arg_1(int): This is the first argument
        arg_2(str): This is a second argument
    Returns:
        bool: This is a description of what is returned
    Raises:
        KeyError: Raises an exception
        ValueError: Raises an exception
    '''
    docstring = parse(text, style=Style.google)
    assert docstring.short_description == "This is a multi line docstring"
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.returns.description == 'This is a description of what is returned'
    assert len(docstring.raises) == 2
    # Test for

# Generated at 2022-06-21 11:56:24.076676
# Unit test for function parse
def test_parse():
    import pytest

    def check_docstring(text, name, summary, description, params, returns,
                        raises, meta, style):
        docstring = parse(text, style)
        assert docstring.name == name
        assert docstring.summary == summary
        assert docstring.description == description
        assert docstring.parameters == params
        assert docstring.returns == returns
        assert docstring.raises == raises
        assert docstring.meta == meta

    # docstring with spaces

# Generated at 2022-06-21 11:56:33.409959
# Unit test for function parse
def test_parse():
    ds = parse("""\
This is my function

:param foo: The first pos arg
  :type: str
:param bar: The second pos arg
  :type: int
:return: none
:rtype: dict
:raises ValueError: If invalid value
""")

    print(ds.short_description)
    print()
    for meta in ds.meta:
        print(meta[0])
        for key, value in meta[1].items():
            print(' ', key)
            print('     ', value)
    print()
    print(ds.long_description)


# Generated at 2022-06-21 11:56:49.044617
# Unit test for function parse
def test_parse():
    # Test with default auto style
    text = """Hello
    :param a: 
    :returns: 
    :keya: valuea
    :keyb: valueb """
    res = parse(text)
    assert res.description == """Hello"""
    assert res.params == {"a": ""}
    assert res.returns == ""
    assert res.meta == {"keya": "valuea", "keyb": "valueb"}

    # Test with sig style
    text = """Hello
    :param a: 
    :returns: 
    :keya: valuea
    :keyb: valueb """
    res = parse(text, Style.sig)
    assert res.description == ""
    assert res.params == {"a": ""}
    assert res.returns == ""

# Generated at 2022-06-21 11:56:57.206993
# Unit test for function parse
def test_parse():
    # input text
    text = """
    Summary line.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    int
        Description of return value
    """
    # input style
    style = Style.google
    # desired output
    output = Docstring(summary='Summary line.', description='Extended description of function.',
                       params=['arg1 : int\n        Description of `arg1`', 'arg2 : str\n        Description of `arg2`'],
                       returns=['int\n        Description of return value'])
    # actual output
    actual = parse(text, style)
    # check if equality of actual
    # output and desired output
    assert actual == output

# Generated at 2022-06-21 11:57:07.867137
# Unit test for function parse
def test_parse():
    """
    Testing parse function
    """
    from docstring_parser.styles.google import GoogleDocstring
    from docstring_parser.styles.numpy import NumpyDocstring
    from docstring_parser.styles.gfm import GfmDocstring
    from docstring_parser.styles.pandas import PandasDocstring

    text = '''
        This is an example of using the `Google`_ style.

        :param line: The line to parse.
        :param column: The column to parse.
        :returns: The parsed column.
        :rtype: int
        :raises ValueError: If the column doesn't exist.

        .. _`Google`: http://www.google.com
        '''

    # auto
    doc = Docstring(text)
    assert parse(text) == doc

    # google
   

# Generated at 2022-06-21 11:57:11.755687
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    text = '''"""
    This is a test string
    Used for testing
    """'''
    print(parse(text))
    #This is a test string
    #Used for testing

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:57:24.289915
# Unit test for function parse
def test_parse():
    text = """
    Parameters
    ----------
    next_element : list-like object
        This is the next element in a series.
    """
    doc = parse(text)
    assert doc.params[0].name == 'next_element'
    assert doc.params[0].desc == 'This is the next element in a series.'
    assert doc.params[0].type_name == 'list-like object'
    assert doc.summary == ''
    assert doc.extended_summary == ''

    text = """
    Parameters
    ----------
    next_element : list-like object
        This is the next element in a series.

    Returns
    -------
    d : dict
        A dictionary representing the point.
    """
    doc = parse(text)
    assert doc.params[0].name == 'next_element'
   

# Generated at 2022-06-21 11:57:32.366493
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring('')
    assert parse('hello world') == Docstring('hello world')
    assert parse('hello world\n    ') == Docstring('hello world')

# Generated at 2022-06-21 11:57:44.423187
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    print("testing parse()")


    # Tests for docstring_parser:parse
    # Tests for parsing style python
    # Tests for parsing style google
    # Tests for parsing style numpy
    # Tests for parsing style rd
    # Tests for parsing style epytext
    # Tests for parsing style epytext_fenced
    # Tests for parsing style epytext_fenced_tagged
    # Tests for parsing auto detection
    # Tests for parsing auto detection with errors
    # Tests for parsing errors
    # Tests for parsing errors in epytext
    # Tests for parsing errors in epytext_fenced
    # Tests for parsing errors in epytext_fenced_tagged
    # Tests for parsing errors in google
    # Tests for parsing errors in numpy
    # Tests for parsing errors in python
    #

# Generated at 2022-06-21 11:57:47.722285
# Unit test for function parse
def test_parse():
    docstring = """Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    assert parse(docstring) == parse(docstring)

# Generated at 2022-06-21 11:57:55.655012
# Unit test for function parse
def test_parse():
    # test1
    text = """Parameters:
    a(int): a's description
    b(str): b's description
    Returns:
    bool: return description
    """
    result = parse(text)
    assert result.meta['Parameters'] == ['a(int): a\'s description', 'b(str): b\'s description']
    assert result.meta['Returns'] == ['bool: return description']
    assert result.returns == ['bool: return description']
    assert result.returns_description == ['return description']
    assert result.returns_type == ['bool']
    assert result.short_description == ''

    # test2

# Generated at 2022-06-21 11:58:07.357605
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Param, Return, Yield
    docstring = parse('"""Test"""')
    docstring.short_description == 'Test'
    docstring.long_description == ''
    docstring.params == []
    docstring.returns == None
    docstring.yields == None
    docstring.extras == {}
    docstring.examples == ''
    docstring.meta == {}
    docstring = parse('r"""Test\nlong\n"""')
    docstring.short_description == 'Test'
    docstring.long_description == 'long'
    docstring.params == []
    docstring.returns == None
    docstring.yields == None
    docstring.extras == {}
    docstring.examples == ''

# Generated at 2022-06-21 11:58:18.203958
# Unit test for function parse
def test_parse():
    """
    Testing parse function
    """
    
    test = Docstring(short_description='test',
        long_description='test',
        tags={},
        meta={},
        returns={},
        arguments={},
        exceptions={},
        warnings={},
        see_also={},
        notes={})
    
    test2 = Docstring(short_description='test2',
        long_description='test2',
        tags={},
        meta={},
        returns={},
        arguments={},
        exceptions={},
        warnings={},
        see_also={},
        notes={})
    
    assert parse("""test""") == test
    assert parse("""test2""") != test

# Generated at 2022-06-21 11:58:23.390960
# Unit test for function parse
def test_parse():
    def test():
        """Silly test docstring.

        :param param1:
        :param param2:
        :returns:

        """

    ret = parse(test.__doc__)
    assert ret.summary == 'Silly test docstring.'
    assert ret.returns.desc == ''
    assert ret.meta['param1'].desc == ''
    assert ret.meta['param2'].desc == ''
    assert len(ret.sections) == 0



# Generated at 2022-06-21 11:58:30.749058
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    This line is longer than the first.

    And this line is longer than the previous.
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == 'This line is longer than the first.\n\nAnd this line is longer than the previous.'

# Sample code for data extraction
# ------------------------------------------------------------------

# Generated at 2022-06-21 11:58:34.418657
# Unit test for function parse
def test_parse():
    test_docstring = '''
        :param some_type:
        :param some_type1:
    '''

    result = parse(test_docstring)

    assert isinstance(result, Docstring)
    print(result)

test_parse()

# Generated at 2022-06-21 11:58:38.773896
# Unit test for function parse
def test_parse():
    assert parse("""
    """
    ).summary == ""
    assert parse("""This is a very short summary.

    Returns:
        None: NoneType
    """
    ).returns == {'return': {'type': 'NoneType', 'desc': ''}}
    assert parse("""This is a very short summary.

    Returns:
        None: NoneType
    """
    ).summary == 'This is a very short summary.'

# Generated at 2022-06-21 11:58:43.761111
# Unit test for function parse
def test_parse():
    text = "this is a test"
    assert parse(text).text == text, "Test failed: text != parse(text).text"
    text = "this is a test, and the other is a test"
    assert parse(text).text == text, "Test failed: text != parse(text).text"


# Generated at 2022-06-21 11:58:54.769417
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(description="")
    assert parse("abc") == Docstring(description="abc")
    assert parse("abc\n") == Docstring(description="abc")
    assert parse("abc\n\n") == Docstring(description="abc")
    assert parse("abc\ndef") == Docstring(description="abc\ndef")
    assert parse("abc\ndef\n") == Docstring(description="abc\ndef")
    assert parse("abc\ndef\n\n") == Docstring(description="abc\ndef")

    assert parse("\n") == Docstring(description="")
    assert parse("abc\n\ndef") == Docstring(description="abc\n\ndef")
    assert parse("abc\n\ndef\n") == Docstring(description="abc\n\ndef")

# Generated at 2022-06-21 11:59:02.500563
# Unit test for function parse
def test_parse():
    text1 = """
    Check if there is a common element in two numpy arrays.

    Both the arrays must be of same size.

    Parameters
    ----------
    A : numpy.array of integers
        An array of integers

    B : numpy.array of integers
        An array of integers

    Returns
    -------
    boolean
        A boolean indicating presence of a common element

    """
    print(parse(text1))


# Generated at 2022-06-21 11:59:03.517131
# Unit test for function parse
def test_parse():
    """Sample docstring for the parse function.
    This is a python docstring.
    """
    assert parse(test_parse.__doc__).summary == "Sample docstring for the parse function."


# Generated at 2022-06-21 11:59:07.707976
# Unit test for function parse
def test_parse():
    text = '''
    This is a function.

    :param p1: parameter 1
    :returns: return value
    '''
    doc = parse(text)
    assert len(doc.meta) == 2
    assert any(['param' in x['name'] for x in doc.meta])
    assert any(['return' in x['name'] for x in doc.meta])

# Generated at 2022-06-21 11:59:20.154411
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.google import GoogleStyle

    text = """One line summary.

    Extended description.

    Args:
      param1: Description of `param1`.
      param2: Description of `param2`

    Returns:
      Description of return value.

    Raises:
      AttributeError, KeyError
    """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring, GoogleStyle)
    assert docstring.short_description == "One line summary."
    assert (
        docstring.long_description
        == "Extended description.\n\n"
        "[`param1`] Description of `param1`.\n"
        "[`param2`] Description of `param2`"
    )

# Generated at 2022-06-21 11:59:25.262261
# Unit test for function parse
def test_parse():
    doc = parse("""
    doc string for this method

    :param a: a is a string
    :type a: str
    :returns: None
    :rtype: int
    """)
    assert doc.short_description == "doc string for this method"
    assert len(doc.params) == 1
    assert doc.params['a'].description == 'a is a string'
    assert doc.params['a'].type == 'str'
    assert doc.returns.description == 'None'
    assert doc.returns.type == 'int'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:37.223074
# Unit test for function parse
def test_parse():
    # test the function parse
    text = '''\
    Module summary line.

    This is a longer description.  It can even contain
    multiple paragraphs.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`
    '''
    docstring = parse(text)
    assert docstring.short_description == 'Module summary line.'
    assert docstring.long_description == '\nThis is a longer description.  '\
                                         'It can even contain\nmultiple '\
                                         'paragraphs.\n\n'
    assert docstring.meta['Parameters'] \
        == [('arg1 : int\n        Description of `arg1`', None),
            ('arg2 : str\n        Description of `arg2`', None)]

# Generated at 2022-06-21 11:59:41.555962
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    test = 'Function that does nothing'
    result = parse(test)
    assert(str(result) == test)
    assert(result.summary == 'Function that does nothing')
    assert(result.returns == None)
    assert(len(result.meta) == 0)
    print(result)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:51.113166
# Unit test for function parse
def test_parse():
    # Test value
    text = 'This function does something.\n\n' + \
           ':param int foo: a foo parameter\n' + \
           ':param int bar: a bar parameter\n' + \
           ':returns: the result\n' + \
           ':rtype: int\n'
    style = Style.sphinx
    # Expected value
    expected_summary = 'This function does something.'
    expected_meta = [('param', 'int foo', 'a foo parameter'),
                     ('param', 'int bar', 'a bar parameter'),
                     ('returns', None, 'the result'),
                     ('rtype', 'int')]
    expected_empty_lines = []
    expected_description = ''

    # Function to test

# Generated at 2022-06-21 12:00:01.012757
# Unit test for function parse
def test_parse():
    ds = [
        'blah blah',
        'blah:',
        'blah: foo',
        'blah: bar\nbaz\nblubb',
        'blah:\nfoo\nbar\n\nbaz',
        'blah:\nfoo\nbar\n\n\nbaz',
        'blah: foo\nbar\n\n\nbaz',
        'blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah',
    ]
    for text in ds:
        print(parse(text))


# Generated at 2022-06-21 12:00:08.696594
# Unit test for function parse
def test_parse():
    """Tests for function parse.
    """
    doc = parse("""This function returns the sum of two integers.
       Parameters:
         a: the first integer
         b: the second integer
       Returns:
         the sum of a and b
       Raises:
         ValueError: if either a or b is not an integer.
    """)
    assert doc.short_description == "This function returns the sum of two integers."
    assert dict(doc.params) == {
        'a': 'the first integer',
        'b': 'the second integer'
    }
    assert doc.returns == 'the sum of a and b'
    assert doc.raises == 'ValueError: if either a or b is not an integer.'


# Generated at 2022-06-21 12:00:17.958089
# Unit test for function parse
def test_parse():
    assert parse('main():\n\t"""\n\tComment\n\t"""\n')

    # Test multiline string
    assert parse('main():\n\t"""Multiline\n\tcomment\n\t"""\n')

    # Test multiline string colors
    assert parse('main():\n\t"""Multiline\n\tcomment\n\t"""\n').description_colors == [0x80, 0x80, 0x80]

    # Test function name
    assert parse('main():\n\t"""\n\tComment\n\t"""\n').name == 'main'

    # Test docstring colors

# Generated at 2022-06-21 12:00:24.127728
# Unit test for function parse
def test_parse():
    # Case 1: A correct example
    text="""
        This is a test
    """
    assert parse(text = text)
    # Case 2: A non-exsiting style
    text="""
        This is a test
    """
    assert parse(text = text, style = Style.appendix)
    # Case 3: An erroneous example
    text="""
        This is a test
        """
    assert parse(text = text)

# Generated at 2022-06-21 12:00:32.255490
# Unit test for function parse
def test_parse():
    """Test function parse"""
    assert parse(
        """Function/method description.

Args:
    arg1 (int): Description of arg1
    arg2 (str): Description of arg2

Returns:
    bool: Result of operation.
    """
    ).summary == "Function/method description."
    assert parse(
        """Function/method description.

Args:
    arg1 (int): Description of arg1
    arg2 (str): Description of arg2

Returns:
    bool: Result of operation.
    """
    ).description == "\nArgs:\n    arg1 (int): Description of arg1\n    arg2 (str): Description of arg2\n\nReturns:\n    bool: Result of operation."

# Generated at 2022-06-21 12:00:48.469010
# Unit test for function parse
def test_parse():
    text = """Summary line.

This is a module-level docstring.

Args:
    arg1 (int): The arg1.
    arg2 (Sequence): The arg2 (a tuple or list).
    arg3 (str): The arg3 (default 'hello world').

Returns:
    str: The return value. True for success, False otherwise.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.

"""
    ds = parse(text)
    assert ds.summary == 'Summary line.'
    assert ds.extended_summary == 'This is a module-level docstring.'

# Generated at 2022-06-21 12:00:53.274308
# Unit test for function parse
def test_parse():
    text = """
        Summarize the function.

        :param x: the first value
        :param y: the second value
        :returns: the sum of the two values
    """
    print(parse(text))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:00:58.833024
# Unit test for function parse
def test_parse():
    text1 = """
    Parameters
    ----------
    some_string : str
        One of the strings to be analyzed.
    """
    text2 = """
    Parameters
    ----------
    some_string : str
        One of the strings to be analyzed.
    """
    text3 = """
    Parameters
    ----------
    some_string : str
        One of the strings to be analyzed.
    """
    test = parse(text1)
    print(test)

test_parse()

# Generated at 2022-06-21 12:01:09.101691
# Unit test for function parse
def test_parse():
    text = '''\
This is a summary

This is the description.

Args:
    arg1 (int): the first argument
    arg2 (str): the second argument

Returns:
    str: a return value
'''
    expected = Docstring(
        summary='This is a summary',
        description='This is the description.',
        parameters=[
            {'name': 'arg1', 'type': 'int', 'description': 'the first argument'},
            {'name': 'arg2', 'type': 'str', 'description': 'the second argument'},
        ],
        returns={'type': 'str', 'description': 'a return value'},
    )
    assert parse(text) == expected


# Generated at 2022-06-21 12:01:19.659291
# Unit test for function parse
def test_parse():
    assert parse('a') == Docstring(description='a')
    assert parse(':param a: b') == Docstring(description='', parameters=[('a', 'b')])
    assert parse(':param a: b\nc') == Docstring(description='c', parameters=[('a', 'b')])
    assert parse(':param a: b\n:return: c') == Docstring(description='', parameters=[('a', 'b')], returns='c')
    assert parse(':return: c\n:param a: b') == Docstring(description='', parameters=[('a', 'b')], returns='c')
    assert parse('a\n:param a: b') == Docstring(description='a', parameters=[('a', 'b')])

# Generated at 2022-06-21 12:01:26.372883
# Unit test for function parse
def test_parse():
    assert parse("""just a little test""") == Docstring(summary="just a little test")
    assert parse("""just a little test\n""") == Docstring(summary="just a little test")
    assert parse("""just a little test\n\n""") == Docstring(summary="just a little test")
    assert parse("""\tjust a little test\n""") == Docstring(summary="just a little test")
    assert parse("""\tjust a little test\n\n""") == Docstring(summary="just a little test")
    assert parse("""\tjust a little test\n\n\t""") == Docstring(summary="just a little test")

# Generated at 2022-06-21 12:01:28.622765
# Unit test for function parse
def test_parse():
    import doctest, docstring_parser
    return doctest.testmod(docstring_parser)

if __name__ == "__main__":
    print(test_parse())

# Generated at 2022-06-21 12:01:38.789917
# Unit test for function parse
def test_parse():
    test_data = {
        '''Author: Alex Tkachenko <alextkachenko@fb.com>\nA simple example showing logging in Python.\n''':
        [
            2,{},'''A simple example showing logging in Python.\n'''
        ],
        '''Author: Alex Tkachenko <alextkachenko@fb.com>\n
        A simple example showing logging in Python.\n''':
        [
            2,{},'''A simple example showing logging in Python.\n'''
        ]
    }

    for d in test_data.keys():
        parsed_docstring = parse(d)
        print(parsed_docstring)
        assert parsed_docstring.num_lines == test_data[d][0]
        assert parsed_docstring.meta == test

# Generated at 2022-06-21 12:01:46.193482
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    import pytest
    # Ensure correct behavior with non-docstrings
    text = "This isn't a docstring!"
    with pytest.raises(ParseError):
        parse(text)
    assert parse(text, style=Style.google) == Docstring()

    # Ensure correct behavior with Google-style docstrings
    text = """
        This is a Google-style docstring
        :param param1: this is a parameter
        :type param1: str
        :param param2: this is param2
        :type param2: dict
        :returns: this is the return type
        :rtype: int
        """

# Generated at 2022-06-21 12:01:56.402415
# Unit test for function parse
def test_parse():
    from docstring_parser.styles.google import GoogleStyle
    from docstring_parser.styles.numpy import NumpyStyle
    from docstring_parser.styles.sphinx import SphinxStyle

    short = """
        A short summary.
    """
    short_sphinx = """
        A short summary.
    """
    short_numpy = """
        A short summary.
    """
    short_google = """
        A short summary.
    """
    assert parse(short) == parse(short, style=Style.auto)
    assert parse(short) == parse(short, style=Style.sphinx)
    assert parse(short) == parse(short, style=Style.numpy)
    assert parse(short) == parse(short, style=Style.google)

# Generated at 2022-06-21 12:02:04.841978
# Unit test for function parse
def test_parse():
    def test_func():
        """This is a test function

        This is the first line of a test function.
        This is the second paragraph.
        The first argument is 'a'
        The second argument is 'b'

        :param a: This is the first argument.
        :param b: This is the second argument.
        :returns: This is the return value.
        """
        pass
    assert parse(test_func.__doc__)

# Generated at 2022-06-21 12:02:12.038199
# Unit test for function parse
def test_parse():
    text = """
        Args:
            param1: The first parameter.
            param2: The second parameter.
        Returns:
            True if successful, False otherwise.
        """
    print(parse(text))

# Reference:
# https://github.com/agronholm/docstring_parser
# https://pypi.org/project/docstring-parser/
# https://docs.python.org/3/distutils/setupscript.html
# https://docs.python.org/3/distributing/index.html

# Generated at 2022-06-21 12:02:20.361107
# Unit test for function parse
def test_parse():
    test_input1 = """
    test-input
    """
    test_input2 = """test-input
    """
    test_input3 = """test-input
    """
    test_input4 = """test-input
    """
    test_input5 = """test-input"""
    test_input6 = """test-input"""
    test_input7 = """test-input"""
    test_input8 = """test-input"""
    test_input9 = """test-input"""
    test_input10 = """test-input"""

    result = parse(test_input1)
    assert result.full_docstring == """test-input
    """
    result = parse(test_input2)
    assert result.full_docstring == """test-input
    """
    result = parse(test_input3)

# Generated at 2022-06-21 12:02:29.197600
# Unit test for function parse
def test_parse():
    status_code, body = parse("""
    :param message: Message to send,
        cannot be empty
    """
    )
    assert status_code == 200
    assert body == """
    :param message: Message to send,
        cannot be empty
    """
    status_code, body = parse("""
    :param message: Message to send,
        cannot be empty
    """
    )
    assert status_code == 200
    assert body == """
    :param message: Message to send,
        cannot be empty
    """

# Generated at 2022-06-21 12:02:31.868441
# Unit test for function parse
def test_parse():
    test_parse_string = "This is a test\nstring\nfor parse function"
    result = docstring_parser.parse(test_parse_string)
    assert isinstance(result, docstring_parser.Docstring)

# Generated at 2022-06-21 12:02:35.852312
# Unit test for function parse
def test_parse():
    test_docstring = '''
    Test parse
    example
    '''

    docstring = parse(test_docstring)

    assert docstring.__repr__() == 'Test parse\nexample'
    assert docstring.__str__() == 'Test parse\nexample'
    assert docstring.short_description == 'Test parse'
    assert docstring.long_description == 'example'

# Generated at 2022-06-21 12:02:42.095289
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    docstring = '''
    This function does something.

    There is an example:
        >>> print('example')
        example
    '''
    dc = parse(docstring, style=Style.numpy)
    assert dc.short_description=='This function does something.'
    assert dc.long_description=='\nThere is an example:\n    >>> print(\'example\')\n    example\n'
    assert dc.examples[0]=='>>> print(\'example\')\n    example\n'
    assert dc.meta['arguments'][0].name=='example'
    assert dc.meta['arguments'][0].type=='str'
    assert dc.meta['arguments'][0].description=='This is an example'


# Generated at 2022-06-21 12:02:50.537926
# Unit test for function parse
def test_parse():
    assert parse(r'''
    """Summary line.

    Extended description of function.

    :param a: Description of arg1
    :type  a: int

    :returns: Description of return value
    :rtype:   float
    """
    ''') == parse(r'''
    """Summary line.

    Extended description of function.

    :param a: Description of arg1
    :type a: int
    :returns: Description of return value
    :rtype: float
    """
    ''')


# Generated at 2022-06-21 12:03:01.736998
# Unit test for function parse
def test_parse():
    def _test_parse_input(text: str, style: Style = Style.google, **expected):
        docstring = parse(text, style)
        for key, value in expected.items():
            assert getattr(docstring, key) == value, "Failed for {}".format(text)

    def _parse_input(text: str, **expected):
        _test_parse_input(text, **expected)
        _test_parse_input(text, Style.google, **expected)

    def _parse_fail(text: str):
        with raises(ParseError):
            parse(text)


# Generated at 2022-06-21 12:03:05.412968
# Unit test for function parse
def test_parse():
    class A():
        def __init__():
            """Initializes the class A
            :param x: The length of the box
            :param y: The width of the box
            """   
    print(parse(A.__init__.__doc__))

# Generated at 2022-06-21 12:03:14.986113
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    # import doctest
    # doctest.testmod()

    assert parse.__doc__ == "Parse the docstring into its components.\n\n    :param text: docstring text to parse\n    :param style: docstring style\n    :returns: parsed docstring representation\n    "


if __name__ == '__main__':
    # import doctest
    # doctest.testmod()

    assert parse.__doc__ == "Parse the docstring into its components.\n\n    :param text: docstring text to parse\n    :param style: docstring style\n    :returns: parsed docstring representation\n    "

    import pytest
    pytest.main("-q test_parse.py")
    # test_parse()

# Generated at 2022-06-21 12:03:20.965810
# Unit test for function parse
def test_parse():
    import unittest
    test_cases = [
        "This function is used to test function parse",
        "This function is used to test function parse.",
        str(["This function is used to test function parse."])
    ]
    for test_case in test_cases:
        ret = parse(text = test_case)
        expected = test_case
        assert expected == ret.short_description
        assert expected == ret.long_description


# Generated at 2022-06-21 12:03:22.838097
# Unit test for function parse
def test_parse():
    assert parse('Hello World') == 'Hello World'
    return

# Run unit test
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:03:32.643439
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    assert parse.__doc__[0] == '"'
    assert parse.__doc__[-1] == '"'

    res = parse(
        """
    Parameters
    -------------
    input_path : str
        input path of file
    output_path : str, optional
        output path of file
        by default is ./
    """
    )

    print(res)
    assert res.params == {
        "input_path": "input path of file",
        "output_path": "output path of file\nby default is ./",}

# Generated at 2022-06-21 12:03:35.031292
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring(summary='', description='', returns=None, meta={})


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:03:41.777711
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    docstring = '''
        Args:
            input (str):
            param2 (int):
        Returns:
            str: result
        '''

    result = parse(docstring)
    assert result.args == 'input (str):\n            param2 (int):'
    assert result.returns == 'result'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:03:48.592737
# Unit test for function parse
def test_parse():
    class A(object):
        def __init__(self):
            self.__doc__ = """
            :param str a: param a
            :param str b: param b
            """
            pass

    a = A()
    d = parse(a.__doc__, style=Style.numpy)
    assert d.params['a'].description == 'param a'
    assert d.params['b'].description == 'param b'

# Generated at 2022-06-21 12:03:56.753454
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    print('-----------')
    docstring = """
        Summarize the docstring here.

        Extended
        summary
        here.

        :param foo: Description of `foo` goes here.
        :param bar: Description of `bar` goes here.
        :raises Exception: If something bad happens.
        :returns: Description of return value.
        :return: Description of return value.
        :rtype: str
        """
    print(parse(docstring))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:04:08.064077
# Unit test for function parse
def test_parse():
    doc = """Dummy docstring."""
    assert parse(doc).short_description == "Dummy docstring."
    doc = """Dummy docstring.

This is a multiline description and some sections:

Keyword arguments:
arg -- first argument
kwarg -- example keyword argument, with a long description
    which spans multiple lines"""

    assert parse(doc).short_description == "Dummy docstring."
    assert parse(doc).long_description == "This is a multiline description and some sections:"
    assert parse(doc).sections == [
        (
            "Keyword arguments:",
            [
                ("arg", "first argument"),
                (
                    "kwarg",
                    "example keyword argument, with a long description\nwhich spans multiple lines",
                ),
            ],
        )
    ]

# Generated at 2022-06-21 12:04:15.083414
# Unit test for function parse
def test_parse():
    code = """
    """
    docstring = parse(code)
    #print(docstring.to_dict())
    assert len(docstring.short_description) == 0
    assert len(docstring.long_description) == 0
    assert len(docstring.meta) == 0

    code = """Single line docstring."""
    docstring = parse(code)
    #print(docstring.to_dict())
    assert len(docstring.short_description) == 1
    assert docstring.short_description[0] == 'Single line docstring.'
    assert len(docstring.long_description) == 0
    assert len(docstring.meta) == 0

    code = """Single line docstring.
    
    More stuff in the docstring.
    """
    docstring = parse(code)
    #print(docstring

# Generated at 2022-06-21 12:04:21.697013
# Unit test for function parse
def test_parse():
    f = """
    I am a function.

    My name is parse.
    
    :param x: a parameter
    :type x: int
    :param y: another parameter
    :type y: str
    """
    ret = parse(f)
    assert ret.short_summary == 'I am a function.'


# Generated at 2022-06-21 12:04:27.008509
# Unit test for function parse
def test_parse():
    text = \
        """Do two things.
        
        :param a: a
        :param b: b
        :param c: c

        :returns: something
        """
    style = Style.auto
    result = parse(text, style)
    assert result.description == ['Do two things.']

# Generated at 2022-06-21 12:04:37.339901
# Unit test for function parse
def test_parse():
    assert parse("""\
        This is a short summary.
        """) == Docstring(summary='This is a short summary.')

    # Note, no newlines between the summary and the description.
    assert parse("""\
        This is a short summary.  This is a long description.""") == \
        Docstring(summary='This is a short summary.',
                  description='This is a long description.')

    # A bad docstring: no summary.

# Generated at 2022-06-21 12:04:40.721170
# Unit test for function parse
def test_parse():
    expected = '''Parses the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation

    :raises ParseError: if the docstring is malformed'''
    assert expected == parse('Parses the docstring into its components.')

# Generated at 2022-06-21 12:04:51.058305
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    text = '''\
        Something about a function.

        Args:
            x (int): Description of x.

        Returns:
            int: Description of return value.
        '''

    docstring = parse(text, style=Style.auto)
    assert docstring.short_description == "Something about a function."
    assert docstring.long_description == ""
    assert len(docstring.meta) == 2
    assert docstring.meta["args"]["x"].raw_type == "int"
    assert docstring.meta["args"]["x"].description == "Description of x."
    assert docstring.meta["return"].raw_type == "int"
    assert docstring.meta["return"].description == "Description of return value."
    assert docstring.style == Style

# Generated at 2022-06-21 12:04:57.442506
# Unit test for function parse
def test_parse():
    text = """\
A function that returns the sum of its two arguments.

:param a: The first value.
:type a: int
:param b: The second value.
:type b: int
"""
    ds = parse(text)
    print(ds)
    print(ds.__dict__)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:05:02.358507
# Unit test for function parse
def test_parse():
    doc = parse("test")
    assert doc.short_desc == "test"
    assert not hasattr(doc, 'long_desc')
    assert not hasattr(doc, 'meta')
    assert not hasattr(doc, 'params')
    assert not hasattr(doc, 'raises')
    assert not hasattr(doc, 'returns')


# Generated at 2022-06-21 12:05:05.191014
# Unit test for function parse
def test_parse():
    """Function parse() unit test"""
    import doctest
    doctest.testmod(verbose=True)

