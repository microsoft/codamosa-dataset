

# Generated at 2022-06-21 11:55:16.009433
# Unit test for function parse
def test_parse():
    text = """A summary line.

    A multiline description.
    Goes on to a second line.

    :param name1: The first parameter.
    :type name1: str.
    :param name2: The second parameter.
    :type name2: int.
    :returns: Description of return value.
    :rtype: int.

    """
    assert parse(text).summary == "A summary line."
    assert (
        parse(text).description
        == """A multiline description.\nGoes on to a second line."""
    )
    assert parse(text).params[0].name == "name1"
    assert parse(text).params[1].description == "The second parameter."
    assert parse(text).returns.description == "Description of return value."

# Generated at 2022-06-21 11:55:19.806124
# Unit test for function parse
def test_parse():
    docstring = "hello world!"
    parsed_docstring = parse(docstring)
    assert(parsed_docstring.summary == "hello world!")
    assert(parsed_docstring.meta == {})

# Generated at 2022-06-21 11:55:26.045356
# Unit test for function parse
def test_parse():


# in test_parse():
    text = '''\
        Parse the docstring into its components.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        '''


    docstring = parse(text)
    print(docstring)
    print(docstring.long_description)
    print(docstring.short_description)
    print(docstring.params)
    print(docstring.returns)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:55:31.778189
# Unit test for function parse
def test_parse():
    text = '''
    this is a test
    :summary: summary of the test
    :param a: param a
    :returns: tbd'''
    result = parse(text)
    assert result.summary == 'summary of the test'
    assert result.params == {'a': 'param a'}

# Generated at 2022-06-21 11:55:36.286660
# Unit test for function parse
def test_parse():
    tests = [
        # (expected, text, style)
        (
            Docstring(description=['description 1']),
            'description 1',
            Style.google
        )
    ]
    for expected, text, style in tests:
        assert parse(text, style) == expected


# Generated at 2022-06-21 11:55:46.602476
# Unit test for function parse
def test_parse():
    test_docstring = """\
Test function.

Parameters
----------
arg1: int
a first argument.

arg2: str
a second argument.

arg3: str, optional
a third argument. default is 'c'

Returns
-------
out: numpy.array
out[0, 0] = arg1
out[1, 1] = arg2

Raises
------
error1: ValueError
a first error example.
error2: RuntimeError
a second error example.
"""


# Generated at 2022-06-21 11:55:51.904640
# Unit test for function parse
def test_parse():
    text = '''
Function to square a number.

:param x: The number to square
:type x: int, float
:returns: x ** 2
:rtype: int, float
:raises TypeError: if x is not a number
'''
    # print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:02.446154
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    import doctest
    import sys
    if sys.version_info[0] == 2:
        doctest.testmod()
    else:
        doctest.testmod(exclude_empty=True)

    # Test invalid style
    invalid_style = 'invalid'
    try:
        parse('', style=invalid_style)
    except ParseError as e:
        assert invalid_style in str(e)
    else:
        assert False

    # Test auto style
    text = """
    :param arg1: something
    :param arg2: something else
    :returns: something
    """
    parse(text, style=Style.auto)

    # Test parse function is well-behaved
    # when style is set to Style.auto.

# Generated at 2022-06-21 11:56:13.802373
# Unit test for function parse
def test_parse():
    assert parse('This is a simple function.').short_description == 'This is a simple function.'
    assert parse('This is a simple function.').long_description == ''

    assert parse('This is a simple function.\n    It has a long description').short_description == 'This is a simple function.'
    assert parse('This is a simple function.\n    It has a long description').long_description == 'It has a long description'


# Generated at 2022-06-21 11:56:18.303781
# Unit test for function parse
def test_parse():
    text = """\
Summary line.

Extended description.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`

Returns
-------
str
    Description of return value.
"""
    docstring = parse(text)
    assert docstring.short_description == 'Summary line.'
    assert len(docstring.long_description) == 1
    assert docstring.long_description[0] == 'Extended description.'
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert 'str' in docstring.returns
    assert 'Description of return value.' in docstring.returns['str']

# Generated at 2022-06-21 11:56:27.878016
# Unit test for function parse
def test_parse():
    docstring = '''
        Returns a message.

        :param message: text to print
        :param location: where to print
    '''
    assert parse(docstring)
    parsed = parse(docstring)
    assert parsed.short_description == 'Returns a message.'
    assert len(parsed.params) == 2
    assert parsed.params['message'].description == 'text to print'
    assert parsed.params['location'].description == 'where to print'

# Generated at 2022-06-21 11:56:38.604975
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, Description, Parameter, Return, Note, Warn, Todo, Author, Date, SeeAlso, References, Example, Attribute, Method, Other
    from typing import List, Dict
    text = '''
    This is a test for me!
    '''
    text_with_meta = '''
    This is a test!
    :param key1: first parameter
    :type key1: str
    :param key2: second parameter
    :type key2: str
    :returns: a test
    :rtype: str
    :raises KeyError: Exception 1
    :raises ValueError: Exception 2
    '''

# Generated at 2022-06-21 11:56:46.798501
# Unit test for function parse
def test_parse():
    doc = parse('''This is a docstring.
    
    :param int x: this is x
    :return: int''')
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == ''
    assert doc.params['x'].type_name == "int"
    assert doc.params['x'].description == "this is x"
    assert doc.returns.type_name == "int"
    assert doc.returns.description == ''

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:55.509088
# Unit test for function parse
def test_parse():
    code = '''    """This is the description.
    :param int arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    :raises ValueError: If something bad happens.
    """'''
    result = parse(code)
    assert result.short_description == 'This is the description.'
    assert result.long_description == 'This is the description.'
    assert result.meta['arg1'].description == 'The first argument.'
    assert result.meta['arg1'].annotation == 'int'
    assert result.meta['arg2'].description == 'The second argument.'
    assert result.meta['arg2'].annotation == str
    assert result.returns.description == 'Description of return value.'
    assert result.raises['ValueError'].description

# Generated at 2022-06-21 11:56:57.018472
# Unit test for function parse
def test_parse():
    assert parse('a') == parse('a', style = Style.multi)


# Generated at 2022-06-21 11:56:57.959614
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 11:57:08.569544
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse
    docstring = """This is a test.
    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    Returns:
        bool: The return value. True for success, False otherwise.
        """
    parsed = parse(docstring)
    print(parsed.sections)
    print(type(parsed.sections))
    print(parsed.sections.keys())
    print(type(parsed.sections['Args']))
    print(type(parsed.sections.get('Args')))
    print(parsed.sections['Args'][0])
    print(parsed.sections['Returns'][0])
    assert parsed.sections['Args'][0].name == 'arg1'
    assert parsed.sections

# Generated at 2022-06-21 11:57:21.021702
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    # Parse auto
    print('Parse auto')
    text = '''
    Test 1 first line
    """
    Test 1 second line
    
    Test 1 blank
    
    Test 1 closed
    """
    '''
    print(text)
    print(parse(text, Style.auto))
    # Parse epytext
    
    # Parse numpydoc
    print('Parse numpydoc')
    text = '''
    Test 2 first line
    :param test 2 param
    
    Test 2 last line
    '''
    print(text)
    print(parse(text, Style.numpydoc))
    # Parse reStructuredText
    print('Parse reStructuredText')

# Generated at 2022-06-21 11:57:30.390271
# Unit test for function parse
def test_parse():
    import unittest
    import re
    from docstring_parser.common import (
        Docstring, FunctionDoc,
        ClassDoc, ModuleDoc, Param,
        Return, ReturnType, ReturnDescription,
        Exception_, Example,
    )

    class ParseTestCase(unittest.TestCase):
        style: Style
        text: str
        expected: Docstring

        def test_parse(self):
            style = self.style
            text = self.text
            expected = self.expected
            with self.subTest(style=style, text=text):
                doc = parse(text, style)
                self.assertIsInstance(doc, Docstring)
                self.assertEqual(doc.meta, expected.meta)
                self.assertEqual(doc.description, expected.description)

# Generated at 2022-06-21 11:57:36.209138
# Unit test for function parse
def test_parse():
    docstring = parse("""
Function description

:param name: description
:type name: str
""")
    assert docstring.short_description == "Function description"
    assert docstring.long_description == ""
    assert docstring.params.name == "name"
    assert docstring.params.description == "description"
    assert docstring.params.type == "str"

# Generated at 2022-06-21 11:57:46.085800
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    docstring = '''
    Example function with types documented in the docstring.

    :param int param1: The first parameter.
    :param str param2: The second parameter.
    :returns: The return value.
    :rtype: bool
    '''
    assert parse(docstring) == parse(docstring, Style.google)



# Generated at 2022-06-21 11:57:50.189526
# Unit test for function parse
def test_parse():
    text = 'Raise a ``RuntimeError``\n\n'\
           ':param name: The name to use with the greeting.\n'\
           ':type name: str\n'\
           ':param age: Your age.\n'\
           ':type age: int\n'\
           ':returns int -- The return value.'
    ans = parse(text)
    assert ans is not None


# Generated at 2022-06-21 11:57:53.018344
# Unit test for function parse
def test_parse():
    text = '''
        This function does something.

        :param int y: this is y

        :returns:
        :rtype:
    '''
    import pytest
    with pytest.raises(ParseError):
        parse(text)

# Generated at 2022-06-21 11:58:04.367061
# Unit test for function parse
def test_parse():
    # Test for simple style
    text = 'Testing, testing, 1, 2, 3.'
    assert parse(text) == parse(text, style=Style.simple) == Docstring(
        content=[], summary='', description=[], meta={}, examples=[], raises=[],
        attributes=[], returns=(None, None), see_also=[], note=[],
        warnings=[], todos=[]
    )
    # Test for numpy style
    text = 'Testing, testing, 1, 2, 3.'
    assert parse(text, style=Style.numpy) == Docstring(
        content=[], summary='Testing, testing, 1, 2, 3.', description=[],
        meta={}, examples=[], raises=[], attributes=[], returns=(None, None),
        see_also=[], note=[], warnings=[], todos=[]
    )
    #

# Generated at 2022-06-21 11:58:09.102367
# Unit test for function parse
def test_parse():
    from os.path import join, dirname
    import re
    import doctest
    with open(join(dirname(__file__), "test_parse.doctest")) as f:
        globs = {"parse": parse, "re": re}
        doctest.testfile(f, globs=globs)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:58:16.581355
# Unit test for function parse

# Generated at 2022-06-21 11:58:24.724221
# Unit test for function parse

# Generated at 2022-06-21 11:58:26.370793
# Unit test for function parse
def test_parse():
    assert parse('Hello world.').short_description == 'Hello world.'

# Generated at 2022-06-21 11:58:32.717379
# Unit test for function parse
def test_parse():
    test_string = '''
        Args:
            param1: description
            param2: description
        Returns:
            Return description
        '''
    assert(parse(test_string) == {"args":
            {"param1": "description",
            "param2": "description"}, "returns": "Return description"})

if __name__=="__main__":
    test_parse()

# Generated at 2022-06-21 11:58:40.654968
# Unit test for function parse
def test_parse():
    # Input docstrings
    docstring_spaces = """Summary line.

Description
   Extended description

   Second paragraph of extended description.

:param: arg1
:type: arg1: str
:param: arg2
:type: arg2: int
:returns: Description of return value
:rtype: bool

:Example:
:param: arg1
:type: arg1: str
:param: arg2
:type: arg2: int
:returns: Description of return value
:rtype: bool

"""

# Generated at 2022-06-21 11:58:54.570568
# Unit test for function parse
def test_parse():

    text = '''
    "This is a dummy docstring
    """

    Args:
        arg1 (int): The first parameter.
        arg2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    '''

    d = parse(text)

    # test to be implemented
    # assert d.short_description == 'This is a dummy docstring'
    # assert d.long_description == ''
    # assert d.return_type == 'bool'
    # assert d.return_description == 'The return value. True for success, False otherwise.'



if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:06.303567
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    from docstring_parser.common import Docstring
    from docstring_parser.styles import PARAM_TYPES, GoogleStyle, NumpyStyle, ReStructuredTextStyle

    rets = parse('', style='autodetect')
    assert rets.__class__ == Docstring
    assert rets.full_name == ''
    assert rets.params == {}
    assert rets.returns == {}
    assert rets.raises == {}
    assert rets.meta == {}

    # Test Google docstring style

# Generated at 2022-06-21 11:59:08.502421
# Unit test for function parse
def test_parse():
    def thistest():
        """This is a test docstring.
    
        :returns: Nothing"""
        pass
    print(parse(str(thistest.__doc__)))

# Generated at 2022-06-21 11:59:17.277323
# Unit test for function parse
def test_parse():
    text = """
    docstring example

    :param arg1: short description
    :param arg2: short description
    :type arg1: int
    :type arg2: str
    :returns: description of return value
    :rtype: int
    """
    doc = parse(text)
    assert len(doc.params) == 2
    assert len(doc.returns) == 1
    assert doc.params[0].name == "arg1"
    assert doc.params[0].annotation == "int"
    assert doc.params[1].name == "arg2"
    assert doc.params[1].annotation == "str"
    assert doc.returns[0].annotation == "int"


# Generated at 2022-06-21 11:59:24.551201
# Unit test for function parse
def test_parse():
    d = parse("""Summary line.

Description:
  This is a description.
  The description is indented.

  More description.

  Parameters
  -----------
  arg1 : int
      The first argument.
  arg2 : str
      The second argument.
  arg3 : list
      The third argument.

  Yields
  -------
  int
      The return value.

  Examples
  --------
  Examples should be written in doctest format, and should illustrate how
  to use the function/class.
  >>> print([i for i in example_generator(4)])
  [0, 1, 2, 3]
""")
    assert d.short_description == 'Summary line.'

# Generated at 2022-06-21 11:59:36.407245
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyPEP257, GooglePEP257, reStructuredText

    text = """\
    This function does something amazing.

    :param x: The first parameter.
    :type x: int
    :param y: The second parameter.
    :type y: int, optional
    :returns: Description of return value.
    :rtype: int
    """

    docstrings = {
        'numpy': NumpyPEP257,
        'google': GooglePEP257,
        'rst': reStructuredText,
    }

    for style, docstring_class in docstrings.items():
        doc = docstring_class(text)
        assert doc.summary == 'This function does something amazing.'
        assert doc.description == ''

# Generated at 2022-06-21 11:59:44.264917
# Unit test for function parse
def test_parse():
    from docstring_parser.utils import dedent
    text = dedent("""
        One line summary.

        Extended description.

        :param arg1: The first argument.
        :param arg2: The second argument.
        :returns: Description of return value.
        :raises keyError: raises an exception
        """)
    res = parse(text)
    assert res.short_description == "One line summary."
    assert res.long_description == "Extended description."
    assert len(res.meta) == 3
    assert res['returns'].args == "Description of return value."
    assert res.returns.args == "Description of return value."
    assert res.returns.params == []
    assert res.raises.params == [('keyError', 'raises an exception')]

# Generated at 2022-06-21 11:59:52.851606
# Unit test for function parse
def test_parse():
    text = """Sample function with types documented in the docstring.
        :param int a: The operand a
        :param int b: The operand b
        :return: The return value
        :rtype: int
        """
    result = parse(text)
    assert result.short_description == "Sample function with types documented in the docstring."
    assert result.long_description.strip() == ""
    assert result.returns.description.strip() == "The return value"
    assert result.returns.annotation.strip() == "int"
    assert result.params[0].name == "a"
    assert result.params[0].description.strip() == "The operand a"
    assert result.params[0].annotation.strip() == "int"
    assert result.params[1].name == "b"

# Generated at 2022-06-21 12:00:04.192986
# Unit test for function parse
def test_parse():
    a = parse('''
    yyyfeihfiuhf
    :param test: test
    ''')
    assert a.short_description == 'yyyfeihfiuhf'
    assert a.params['test'].description == 'test'
    b = parse('''
    yyyfeihfiuhf
    :param test: test
    :returns: i don't know
    :raises: an error
    ''')
    assert b.short_description == 'yyyfeihfiuhf'
    assert b.params['test'].description == 'test'
    assert b.returns.description == "i don't know"
    assert b.raises['an error'].description == 'an error'


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:00:15.803334
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    # Test for Google style
    ret = parse("""
                    A function for parse doc string to DocString object.
                    :param text: docstring text to parse
                    :param style: docstring style
                    :returns: parsed docstring representation
                  """)
    assert ret.short_description == "A function for parse doc string to DocString object."
    assert ret.long_description == None
    assert ret.params["text"].description == "docstring text to parse"
    assert ret.params["style"].description == "docstring style"
    assert ret.returns.description == "parsed docstring representation"

    # Test for Numpy style

# Generated at 2022-06-21 12:00:30.201492
# Unit test for function parse

# Generated at 2022-06-21 12:00:34.610673
# Unit test for function parse
def test_parse():
    text = """
    :param int test: this is a test
    :return: this is a test return
    :raises ValueError: if test
    """
    ret = parse(text)
    print(ret)


if __name__=='__main__':
    test_parse()

# Generated at 2022-06-21 12:00:46.615237
# Unit test for function parse

# Generated at 2022-06-21 12:00:57.206642
# Unit test for function parse
def test_parse():
    def func(arg):
        """This is a docstring.

        It has a main description followed by a blank line.

        :param arg: this argument is documented
        :type arg: str

        :returns: this is what is returned
        :rtype: str
        """
        pass

    docstring = parse(func.__doc__)
    print('docstring:', docstring)
    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == 'It has a main description followed by a blank line.'
    assert len(docstring.meta) == 4
    assert docstring.meta['param'][0][0] == 'arg'
    assert docstring.meta['param'][0][1] == 'this argument is documented'

# Generated at 2022-06-21 12:00:59.962746
# Unit test for function parse
def test_parse():
    result = parse('hello', style='google')
    assert(result.short_description == 'hello')

# Generated at 2022-06-21 12:01:11.060063
# Unit test for function parse
def test_parse():
    text = """\
    This function parses some text.

    :meta private:
    :param text: text to be parsed
    :returns parsed text
    :raises ParseError: if text cannot be parsed
    """

    d = parse(text, style=Style.sphinx)
    print(d.short_description)
    print(d.long_description)
    assert d.meta['private'] is True
    print(d.params[0].name)
    print(d.params[0].type_name)
    print(d.params[0].description)
    print(d.returns.type_name)
    print(d.returns.description)
    assert d.raises[0].type_name == 'ParseError'
    print(d.raises[0].description)


# Generated at 2022-06-21 12:01:13.559450
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring of function test_parse
    Parameters
    ----------
    text: str
    :return: Docstring
    """
    print(parse(text))

# Generated at 2022-06-21 12:01:21.952509
# Unit test for function parse
def test_parse():
    """Test function parse."""

    class myDocstring(Docstring):
        """myDocstring."""

        def __init__(self):
            super(myDocstring, self).__init__()
            self.meta = {}

    parsed_docstring = parse('Summary.\n\nExtra line.')
    my_docstring = myDocstring()
    my_docstring.summary = 'Summary.'
    my_docstring.body = 'Extra line.'
    my_docstring.meta = {}
    assert my_docstring.__dict__ == parsed_docstring.__dict__, \
        'test_parse: parsing fails!'


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:01:24.534835
# Unit test for function parse
def test_parse():
    assert parse("")
    assert parse("untest")


# Generated at 2022-06-21 12:01:33.240268
# Unit test for function parse
def test_parse():
    "Unit test for function parse."
    text = (
        "This is the first line of my docstring.  It is nicely wrapped."
        "  It has multiple paragraphs also.\n"
        "\n"
        "This is the second paragraph of my docstring.  It is also nicely wrapped.\n"
        "\n"
        "This is the third paragraph of my docstring.  It is not so nicely wrapped.  "
        "I don't think it's as nice as the others.\n"
    )
    assert "This is the first line of my docstring." in parse(text).short_description
    assert "It is nicely wrapped." in parse(text).short_description
    assert "It has multiple paragraphs also." in parse(text).short_description
    assert "It is also nicely wrapped." in parse(text).long_description
   

# Generated at 2022-06-21 12:01:42.137305
# Unit test for function parse
def test_parse():
    """Unit test for function parse
    """
    text = """This sentence is so long it will not fit in one line.
    """
    print(parse(text, style=Style.numpy))
    text = """This sentence is so long it will not fit in one line.
    """
    print(parse(text, style=Style.auto))


# pytest -s docstring_parser.py

# Generated at 2022-06-21 12:01:49.682917
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True)

# Main
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        'style',
        choices=list(STYLES.keys()),
        nargs='?',
        help='docstring style')
    args = parser.parse_args()
    test_parse()

# Generated at 2022-06-21 12:01:56.209207
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Style
    docstring = "This is a test docstring."

    doc = parse(docstring, Style.google)
    assert doc.meta["Summary"] == "This is a test docstring."

    doc = parse(docstring, Style.numpy)
    assert doc.meta["Summary"] == "This is a test docstring."

    doc = parse(docstring)
    assert doc.meta["Summary"] == "This is a test docstring."

    doc = parse("")
    assert doc.style == ""

test_parse()

# Generated at 2022-06-21 12:02:00.561267
# Unit test for function parse
def test_parse():
    text = """
    Something that needs to be tested.
    More content here.
    """
    ds = parse(text)

    assert ds.short_description == "Something that needs to be tested."
    assert ds.long_description == "More content here."

# Generated at 2022-06-21 12:02:08.571910
# Unit test for function parse
def test_parse():
    import re, os
    import docstring_parser.parse as p
    from docstring_parser.styles import Style

    with open(os.path.join(os.path.dirname(__file__), 'test_parse.py'), 'r') as f:
        lines = f.readlines()

        for line in lines:
            if '===' in line:
                # Start of test case
                docstring_style = Style.google
                if 'numpy' in line or 'sphinx' in line or 'google' in line:
                    docstring_style = Style[line.split('===')[0].strip()]

                def_block = [ line ]

                while '===' not in line:
                    line = lines.pop(0)
                    def_block.append( line )

# Generated at 2022-06-21 12:02:13.896705
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    from docstring_parser.styles import Google

    TEST_DOCSTRING = """\
    Summarize the BagOfWords class.

    Attributes:
        bow (dict): Dictionary of word frequency in a sentence
                        Key:str: Word
                        Value:int: Word Count

    Example:
        >>> from collections import Counter
        >>> sentence = "hello. hello there. how are you? fine thanks. and you?"
        >>> BoW = BagOfWords(sentence)
        >>> BoW.bow
        Counter({'hello': 2, 'you': 2, 'how': 1, 'fine': 1, 'and': 1,
                'are': 1, 'thanks': 1, 'there': 1})

    Warnings:
        Use with caution.
    """


# Generated at 2022-06-21 12:02:17.010204
# Unit test for function parse
def test_parse():
    doc = """
    This is the docstring
    """
    parseddoc = parse(doc, Style.numpy)
    assert parseddoc == """
    This is the docstring
    """.strip()



# Generated at 2022-06-21 12:02:22.644635
# Unit test for function parse
def test_parse():
    import pytest
    from docstring_parser.parse import parse
    docstring = """This is a single line docstring."""
    assert parse(docstring) == parse(docstring, style='google')
    docstring = """This is a multi
        line docstring."""
    assert parse(docstring) == parse(docstring, style='google')
    def func(self):
        """This is a docstring.

        Args:
            self (object) - example of self args
        """
        return 0
    assert parse(func.__doc__) == parse(func.__doc__, style='google')
    docstring = """This is a multi
        line docstring.

        Args:
            self (object) - example of self args

        Returns:
            int: 0
        """

# Generated at 2022-06-21 12:02:31.031700
# Unit test for function parse
def test_parse():
    """Tests that parse function works."""
    
    style = Style.restructuredtext
    text = '\nTitle\n=====\n\n:Description:\nDescription\nDescription\n\n:Args:\narg1 (str): Description\n\n:Returns:\nstr: Description\n'
    a = parse(text, style)
    assert a.title == 'Title'
    assert a.description == 'Description\nDescription'
    assert a.args[0][0] == 'arg1'
    assert a.returns[0] == 'Description'

# Generated at 2022-06-21 12:02:32.235802
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=False)

# Generated at 2022-06-21 12:02:42.151886
# Unit test for function parse
def test_parse():
    actual = parse("""
    This is a summary
    """)
    print("test_parse: summary:", actual.summary, actual.summary_raw)
    # test_parse: summary: This is a summary This is a summary

    actual = parse("""
    This is a summary.Longer and longer and longer.
    """)
    print("test_parse: summary:", actual.summary, actual.summary_raw)
    # test_parse: summary: This is a summary.Longer and longer and longer. This is a summary.Longer and longer and longer.

    actual = parse("""
    This is a summary.
    Longer and longer and longer.
    """)
    print("test_parse: summary:", actual.summary, actual.summary_raw)
    # test_parse: summary: This is a summary.Longer and longer

# Generated at 2022-06-21 12:02:47.212214
# Unit test for function parse
def test_parse():
    text = '''\
Summary line here.

Extended description here.
'''
    docstring = parse(text, style=Style.numpy)
    assert str(docstring) == text.strip()
    assert docstring.short_description == 'Summary line here.'
    assert docstring.long_description == 'Extended description here.'

# Generated at 2022-06-21 12:02:58.414239
# Unit test for function parse
def test_parse():
    test_doc = """This is sample docstring.
    :param a: parameter a
    :type a: string
    :returns: something
    :raises ValueError: When something wrong happens.
    """
    assert parse(test_doc).summary == "This is sample docstring."
    assert parse(test_doc).params["a"].description == "parameter a"
    assert parse(test_doc).params["a"].type == "string"
    assert parse(test_doc).returns.description == "something"
    assert parse(test_doc).raises["ValueError"].description == "When something wrong happens."

"""The main parsing routine."""

from docstring_parser.common import Docstring, ParseError
from docstring_parser.styles import STYLES, Style



# Generated at 2022-06-21 12:03:04.454466
# Unit test for function parse
def test_parse():
	'''Test function parse()'''
	text = '''Longer description of this class.
    Longer description of this class.
    Attributes:
        attr1 (str): Description of `attr1`.
        attr2 (:obj:`int`, optional): Description of `attr2`.
    '''
	text = text[1 // 4:]
	print(parse(text))


# test_parse()

# Generated at 2022-06-21 12:03:12.652541
# Unit test for function parse
def test_parse():
    example_text = """\
    Summary line.

    This is a longer description. It may contain multiple paragraphs.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    bool
        Description of return value

    """

    expected = Docstring(summary="Summary line.",
                         description="This is a longer description. It may contain multiple paragraphs.",
                         params={'arg1': 'int\n        Description of `arg1`',
                                 'arg2': 'str\n        Description of `arg2`'},
                         return_val='bool\n        Description of return value')
    actual = parse(example_text, style=Style.numpy)
    assert actual == expected

# Generated at 2022-06-21 12:03:22.950780
# Unit test for function parse
def test_parse():
    # Test the simple case of summary
    str = 'This is a test docstring to parse'
    doc = parse(str)
    assert doc.summary == str
    # Test the summary and description case
    str = 'This is a test docstring to parse. \n This is the description'
    doc = parse(str)
    assert doc.summary == 'This is a test docstring to parse.'
    assert doc.description == 'This is the description'
    # Test the case of meta
    str = 'This is a test docstring to parse. \n :param: key:value'
    doc = parse(str)
    assert doc.meta == {'key': 'value'}
    # Test the case of extra_content
    str = 'This is a test docstring to parse. \n :param: key:value\nMore stuff'
   

# Generated at 2022-06-21 12:03:31.478442
# Unit test for function parse
def test_parse():
    text = """
    Summary
    -----------

    This is a long description.
    """

    assert(parse(text) == parse(text + " ", Style.numpy))
    assert(parse(text) != parse(text + " ", Style.google))
    assert(parse(text) == parse(text + " ", Style.auto))
    assert(parse(text) == parse(text, Style.auto))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:03:41.052392
# Unit test for function parse
def test_parse():
    inputs = [
        """
        :param list pos: positional arguments
        :param dict kw: keyword arguments
        :raises Exception: something bad happened
        """
    ]
    expected = [
        Docstring(
            meta={
                "param": ["pos", "list", "positional arguments"],
                "param": ["kw", "dict", "keyword arguments"],
                "raises": ["Exception", "something bad happened"],
            }
        )
    ]
    for i, e in zip(inputs, expected):
        ret = parse(i)
        assert (
            ret.meta["param"] == e.meta["param"]
            and ret.meta["raises"] == e.meta["raises"]
        )

# Generated at 2022-06-21 12:03:52.763228
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    docstring = '''Single-line docstring.
    :param arg1: The first parameter.
    :param arg2: The second parameter.
    :returns: The return value.
    
    The rest of the docstring is a longer
    explanation, which may include other useful information.'''
    
    assert parse(docstring)[0].summary == 'Single-line docstring.'
    assert parse(docstring)[0].description == '    The rest of the docstring is a longer\n    explanation, which may include other useful information.'
    assert parse(docstring)[0].params['arg1'] == 'The first parameter.'
    assert parse(docstring)[0].params['arg2'] == 'The second parameter.'
    assert parse(docstring)[0].returns == 'The return value.'
    assert parse

# Generated at 2022-06-21 12:03:59.946362
# Unit test for function parse
def test_parse():
    text = '''
    This is a module docstring.

    :param x: a parameter for the function
    :type x: string
    :returns: testing function
    :raises: optional
    '''
    # print(parse(text))
    assert(parse(text) == Docstring(description='This is a module docstring.',
        params=[Param(description='a parameter for the function',
        name='x', type='string')], returns=Return(description='testing function'),
        raises=[],
        meta={}))

# Generated at 2022-06-21 12:04:12.614901
# Unit test for function parse
def test_parse():
    def f():
        """hello world

        :param a: this is a
        :type a: int
        :param b: this is b
        :type b: string
        :returns: this is returned
        :rtype: int
        """
        pass
    docstring = parse(f.__doc__)
    assert docstring.short_description == "hello world"
    assert docstring.summary == "hello world"
    assert docstring.long_description == None
    assert docstring.returns == {"type": "int", "desc": "this is returned"}
    assert docstring.return_type == "int"
    assert docstring.raises == None
    assert docstring.yields == None

# Generated at 2022-06-21 12:04:17.773930
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True)

# Example of use
if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)
    # Don't run example
    # doctest.testfile('example.txt')

# Generated at 2022-06-21 12:04:27.466718
# Unit test for function parse
def test_parse():
    text = '''\
    This is a module docstring.
    '''
    style = Style.google
    assert parse(text, style) == '''\
    This is a module docstring.
    '''

    text = '''\
    def foo(thing, bar):
    """Make a foo
    :param thing: thing
    :param bar: bar
    :return: foo
    """
    '''
    style = Style.sphinx
    assert parse(text, style) == '''\
    def foo(thing, bar):
        """Make a foo
        :param thing: thing
        :param bar: bar
        :return: foo
        """
    '''


# Generated at 2022-06-21 12:04:37.887357
# Unit test for function parse
def test_parse():
    # Unit test: test_parse
    # Case 1:
    text1 = '''
    This is a test of the main parsing routine.
    
    :param text: docstring text to parse
    :param style: docstring style

    :returns: parsed docstring representation
    '''
    docstring1 = parse(text1)
    text2 = '''
    This is a test of the main parsing routine.
    
    Parameters
    ----------
    text : docstring text to parse
    style : docstring style

    Returns
    -------
    parsed docstring representation
    '''
    docstring2 = parse(text2)
    assert docstring1 == docstring2, "parse() does not behave correctly"

    # Case 2:

# Generated at 2022-06-21 12:04:46.513231
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Parameter
    text = '''\
    Description.

    Keyword Arguments:
        foo: Description.
        bar: Description.
    Returns:
        Description.
    '''

    docstring = parse(text)

    assert docstring.short_description == 'Description.'
    assert docstring.long_description == 'Description.'
    assert docstring.params['foo'] == Parameter(name='foo',
                                                description='Description.')
    assert docstring.returns == Parameter(name='', description='Description.')

# Generated at 2022-06-21 12:04:49.394295
# Unit test for function parse
def test_parse():
    text = "I am testing"
    ret = parse(text)
    assert ret.short_description == "I am testing"


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:04:52.334236
# Unit test for function parse
def test_parse():
    text = """
    A simple function.

    :param a: parameter a
    :param b: parameter b
    :returns: return a + b

    :rtype: float

    Example:

    >>> a(0, 1)
    1
    """
    parse(text)

# Generated at 2022-06-21 12:04:55.115201
# Unit test for function parse
def test_parse():
    from tests.tester import parse_test
    parse_test(parse)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:05:03.740922
# Unit test for function parse
def test_parse():
    assert parse("""
    A multi-line docstring

    Args:
        arg1 (str): The first argument
        arg2(str, optional): The second argument
    """).meta == {
        "Arguments": [
            {
                "Name": "arg1",
                "Type": "str",
                "Description": "The first argument"
            },
            {
                "Name": "arg2",
                "Type": "str, optional",
                "Description": "The second argument"
            }
        ]
    }
    assert parse("""
    A single-line docstring
    """).meta == {
        "Summary": "A single-line docstring"
    }