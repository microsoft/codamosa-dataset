

# Generated at 2022-06-21 11:55:21.242785
# Unit test for function parse
def test_parse():
    text = '''This is a description.

Parameters
----------
arg1 : int
    Description of `arg1`.
arg2 : str
    Description of `arg2`.

Returns
-------
str
    Description of return value.

Raises
------
RuntimeError
    If something bad happens.'''
    doc = parse(text)

# Generated at 2022-06-21 11:55:28.639284
# Unit test for function parse
def test_parse():
    docstring = parse('Transforms the data.\n\nComponent 1.\n\nComponent 2.')
    assert docstring.summary == 'Transforms the data.'
    assert docstring.short_description == 'Transforms the data.'
    assert docstring.long_description == 'Component 1.\n\nComponent 2.'
    docstring = parse('Transforms the data.\n\nReturn 1.\n\nReturn 2.')
    assert docstring.summary == 'Transforms the data.'
    assert docstring.short_description == 'Transforms the data.'
    assert docstring.long_description == 'Return 1.\n\nReturn 2.'
    docstring = parse('Transforms the data.\n\nReturns:\n    1.\n\n    2.')
    assert docstring.summary == 'Transforms the data.'

# Generated at 2022-06-21 11:55:39.520573
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring("", "", [], [], [])
    assert parse("Hello world") == Docstring("Hello world", "", [], [], [])
    assert parse("Hello world\n") == Docstring("Hello world", "", [], [], [])
    assert parse("Hello\nworld\n") == Docstring("Hello\nworld", "", [], [], [])
    assert parse("Hello world.", "") == Docstring("Hello world.", "", [], [], [])
    assert parse("Hello world.\n\ntest.") == Docstring("Hello world.\n\ntest.", "", [], [], [])
    assert parse("Hello world\n\n:param test", "") == Docstring("Hello world", "", [], [], [])

# Generated at 2022-06-21 11:55:48.160110
# Unit test for function parse
def test_parse():
    expected_result = Docstring(short_description='Short description',
                                long_description='Long description',
                                returns=('returns', 'The return type'),
                                meta={'args': [('arg', 'The arg type')],
                                      'kwargs': [('kwarg', 'The kwarg type')]})
    actual_result = parse("""Short description
Long description

Args:
    arg (The arg type):
        The arg description

Kwargs:
    kwarg (The kwarg type):
        The kwarg description

Returns:
    The return type
""")
    assert actual_result == expected_result

# Get the test coverage
test_parse()

# Generated at 2022-06-21 11:55:59.729204
# Unit test for function parse
def test_parse():
    text = """
    Parses the HTML file, and return a list of Token(s)
    :param file: Input File Stream
    :param len: The length of input file, used for efficiency
    :return: A list of Token, containing the tokens in the HTML file
    """
    d = parse(text)
    assert d.short_description == 'Parses the HTML file, and return a list of Token(s)'
    assert d.long_description == ''
    assert len(d.params) == 2
    p = d.params[0]
    assert p.arg_name == 'file'
    assert p.description == 'Input File Stream'
    assert not p.annotation
    assert p.default_value is None
    p = d.params[1]
    assert p.arg_name == 'len'

# Generated at 2022-06-21 11:56:12.483382
# Unit test for function parse
def test_parse():
    text = '''This is a title
    This is a description
    :param test: This is a param
    :type test: int
    :returns: This is a return
    :rtype: str
    '''
    d = parse(text)
    assert len(d.meta) == 4
    assert d.title == 'This is a title'
    assert d.description == 'This is a description'
    assert d.summary == 'This is a titleThis is a description'
    m = d.meta[0]
    assert m.args == 'test'
    assert m.description == 'This is a param'
    assert m.type == 'int'
    assert m.returns == None
    assert m.rtype == None
    m = d.meta[1]
    assert m.args == None

# Generated at 2022-06-21 11:56:21.049229
# Unit test for function parse
def test_parse():

    doc = """
    This is a summary line.

    This is the first paragraph. It contains a list:
     * First item
       Second line of the first item
       indented another space
     * Second item
       Second line of the second item not indented
     * Third item
       Second line of the third item indented one space more

    This is the second paragraph. It contains:
      * a list
      * also a list

    This is the third paragrah.
   - This is a list item
   - This is another list item
    """
    print(parse(doc))

# Generated at 2022-06-21 11:56:24.976453
# Unit test for function parse
def test_parse():

    # 1: argument text is of type str, style is of type Style
    assert isinstance(parse(str, Style), Docstring)
    # 2: argument text is of type str, style is of type Style = Style.auto
    assert isinstance(parse(str), Docstring)


# Generated at 2022-06-21 11:56:36.401066
# Unit test for function parse
def test_parse():
    text1 = '''\
Hello world!

This is a simple hello world example

Args:
    name: str:

        The name of person to greet.
'''

    d1 = parse(text1)
    assert d1.short_description == 'Hello world!\n'
    assert d1.long_description == '\nThis is a simple hello world example\n'
    assert isinstance(d1.long_description, str)
    assert d1.meta['Args']['name'].arg_type == 'str:'
    assert d1.meta['Args']['name'].description == 'The name of person to greet.'

    text2 = '''\
a short overview

a long overview


Args:
    aaa: Aaaa
    bbb: Bbbb
'''

    d2 = parse

# Generated at 2022-06-21 11:56:39.233676
# Unit test for function parse
def test_parse():
    docstring = """
    Returns:
        Returns the True
    """
    result = parse(docstring, Style.google)
    print(result)
    assert result.summary == ''

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:50.393224
# Unit test for function parse
def test_parse():
    d = parse("""
        :param i: index
        :raises ValueError:""")
    assert d.params[0].arg_name == "i"
    assert d.params[0].arg_type == None
    assert d.params[0].description == ""
    assert len(d.raises) == 1
    assert d.raises[0].exception_name == "ValueError"
    assert d.raises[0].description == ""


# Generated at 2022-06-21 11:56:54.331453
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring
    assert isinstance(parse(""), Docstring)
    assert isinstance(parse("", style=Style.google), GoogleDocstring)
    assert isinstance(parse("", style=Style.numpy), Docstring)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:56:57.960791
# Unit test for function parse
def test_parse():
    text = '''
    """
    :param name:
    :type name: str
    """
    '''
    d = parse(text)
    assert d.meta['name']['type'] == 'str'


# Generated at 2022-06-21 11:57:00.052351
# Unit test for function parse
def test_parse():
    if __name__ == "__main__":
        from sample_docstrings import samplestr
        print(parse(samplestr))

# Generated at 2022-06-21 11:57:04.911471
# Unit test for function parse
def test_parse():
    d = parse("""Summary line.

Description: first line.
    continuation.

Args:
    arg1: first argument
    arg2: second argument
    arg3: third argument

Returns:
    None
""")


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:57:09.472758
# Unit test for function parse
def test_parse():
    repo_path = os.path.join(os.pardir, os.pardir)
    print(repo_path)
    file_path = os.path.join(repo_path, 'tests', 'docstring_source.py')
    with open(file_path) as f:
        file_docstring = f.read()
    docstring = parse(file_docstring)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring.params['args'], list)
    assert isinstance(docstring.returns, dict)
    assert isinstance(docstring.yields, dict)
    assert isinstance(docstring.raises, dict)
    assert isinstance(docstring.meta, dict)
    assert isinstance(docstring.description, str)

# Generated at 2022-06-21 11:57:21.919572
# Unit test for function parse
def test_parse():
    test_docstring = """
    MyFunction

    Args:
        my_arg: My argument

    Returns:
        My return value

    Raises:
        MyException: In case of error
    """

    test_docstring_returns = """
    MyFunction

    Args:
        my_arg: My argument

    Raises:
        MyException: In case of error
    """

    test_docstring_returns_value = """
    MyFunction

    Args:
        my_arg: My argument

    Returns:
        My return value
    """

    test_docstring_returns_and_yields = """
    MyFunction

    Args:
        my_arg: My argument

    Returns:
        My return value

    Yields:
        My yield value
    """

    test_doc

# Generated at 2022-06-21 11:57:31.011597
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Return
    from docstring_parser.context import Context
    
    text = """
    This function generates a random number between two boundaries.
    :param a: lower boundary
    :param b: upper boundary
    :returns: a random integer between a and b
    """
    
    d = parse(text, style=Style.google)

    assert d.short_description == "This function generates a random number between two boundaries."
    r = d.returns
    c = r.context
    assert c.name == "returns"
    assert c.description == "a random integer between a and b"
    assert len(d.params) == 2
    c0, c1 = d.params
    assert c0.name == "a"
    assert c0.description == "lower boundary"
    assert c

# Generated at 2022-06-21 11:57:42.965529
# Unit test for function parse
def test_parse():
    """."""

    text = '''
        Example function with types documented in the docstring.

        :param int param1: The first parameter.
        :param str param2: The second parameter.
        :returns: The return value.
        :rtype: str
        '''
    docstring = parse(text)
    assert docstring.short_description == 'Example function with types documented in the docstring.'
    assert docstring.long_description == ''
    assert docstring.tags['param'] == [
        'param1',
        'The first parameter.',
        'int,optional',
        '',
    ], docstring.tags['param']

# Generated at 2022-06-21 11:57:52.449352
# Unit test for function parse
def test_parse():
    string1 = """\
    Hello.
    """

    string2 = """\
    Hello.
    hello
    """

    # Create object for class parse and print object
    # print(string1)
    parse1 = parse(string1)
    # print(parse1.args)
    # print(parse1.meta)
    # print(parse1.desc)
    # print(parse1.returns)
    # print(parse1.raises)

    print(string2)
    parse2 = parse(string2)
    print(parse2.args)
    # print(parse2.meta)
    # print(parse2.desc)
    # print(parse2.returns)
    # print(parse2.raises)


# Generated at 2022-06-21 11:58:05.384085
# Unit test for function parse
def test_parse():
    text = """
        :param x: this is the first param
        :type x: int
        :param y: this is the second param
        :type y: float
        :returns: this is return value
        :rtype: str
    """
    expected = Docstring(
        params={
            "x": "this is the first param",
            "y": "this is the second param",
        },
        returns="this is return value",
    )
    actual = parse(text)

    assert expected == actual

# Generated at 2022-06-21 11:58:13.643920
# Unit test for function parse
def test_parse():
    text = """Single-line docstring."""
    assert parse(text) == Docstring(short_description='Single-line docstring.', long_description='')
    text = """
    Single-line docstring.
    """
    assert parse(text) == Docstring(short_description='Single-line docstring.', long_description='')
    text = ["""
    Single-line docstring.
    """]
    assert parse(text) == Docstring(short_description='Single-line docstring.', long_description='')
    text = ["""
    Single-line docstring.
    """]
    assert parse(text) == Docstring(short_description='Single-line docstring.', long_description='')

# Generated at 2022-06-21 11:58:20.606791
# Unit test for function parse
def test_parse():

    # Sample docstring to be used for testing
    sample = """This is a test docsting.

    Parameters
    ----------

    arg1: int
        A test parameter.

    arg2: str
        A test parameter.

    Returns
    -------

    int, optional
        A test return value.

    """

    # Main test
    assert parse(sample).__eq__('This is a test docsting.')

# Execute the unit test
if __name__ == "__main__":

    test_parse()

# Generated at 2022-06-21 11:58:27.080414
# Unit test for function parse
def test_parse():
    docstring = parse("""\
        Summary line.

        Extended description.

        Args:
            arg1 (int): Description of arg1
            arg2 (str): Description of arg2
        Raises:
            IOError: An error occured accessing the bigtable.Table object.
        Returns:
            int: Description of return value
        """)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == 'Extended description.\n'
    assert len(docstring.params) == 2
    assert docstring.params['arg1'].arg_type == 'int'
    assert docstring.params['arg1'].description == 'Description of arg1'
    assert docstring.params['arg2'].arg_type == 'str'

# Generated at 2022-06-21 11:58:31.296643
# Unit test for function parse
def test_parse():
    """
    This function tests the parse function.
    """
    
    f = open('test_docstr.py','r')
    text = f.read()
    f.close()
    doc_string = parse(text)

# Generated at 2022-06-21 11:58:34.187055
# Unit test for function parse
def test_parse():
    text = """blabla


<text>
        aa
        bb
    cc
    """

    print(parse(text))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:58:41.466188
# Unit test for function parse
def test_parse():
    docstring_text1 = """
This is a long docstring.
It should cover several lines.

Parameters
----------
arg1 : int
    The first argument.
arg2 : str
    The second argument.

Returns
-------
str
    The returned value.
"""

    doc = parse(docstring_text1)
    assert doc.short_description == 'This is a long docstring.'
    assert doc.long_description == 'It should cover several lines.'
    assert doc.params == {'arg1': 'int\n    The first argument.', 'arg2': 'str\n    The second argument.'}
    assert doc.returns == 'str\n    The returned value.'
    assert doc.meta == {'Parameters': 'arg1, arg2', 'Returns': ''}


# Generated at 2022-06-21 11:58:53.110017
# Unit test for function parse
def test_parse():
    assert parse("Test: toto\nTitle: the title\n") == {'Summary': 'Test: toto\nTitle: the title\n', 'Description': '', 'Extended': '', 'Return': '', 'Parameters': [], 'Raises': [], 'Yields': [], 'Warns': [], 'Note': '', 'Examples': [], 'See Also': [], 'References': [], 'Meta': {'Test': ['toto'], 'Title': ['the title']}}

# Generated at 2022-06-21 11:59:00.636897
# Unit test for function parse
def test_parse():
    text = '''The ``compress`` method removes the whitespace between lines.

    The compress method works by looking for one or more blank lines
    in a row, and replacing them with a single blank line. For example,
    consider the following text:

        This text has many


        blank lines

        in it.

    If you compress this text, you get:

        This text has many

        blank lines

        in it.

    Note that the original text has a double newline between the line
    with the word "many" and the line that begins "blank lines", and
    after "blank lines" and before "in it".  The compressed version of
    the text replaces the two newlines with a single newline; it does
    not actually remove the newlines.
    '''

    docstring = parse(text, style=Style.numpy)

# Generated at 2022-06-21 11:59:06.539481
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    print('\nTest for function parse:')
    try:
        docstring = parse('''
            This is a test docstring.

            :param s: some string
            :returns: the same string
        ''')
        print(docstring)
    except Exception as e:
        print(e.__class__.__name__ + ':', e)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:18.267029
# Unit test for function parse
def test_parse():
    # Positive testing
    text = "bla bla"
    docstring = parse(text)
    assert docstring.short_description == None
    assert docstring.long_description == None
    docstring = parse(text, style=Style.numpy)
    assert docstring.short_description == None
    assert docstring.long_description == None

    text = "one-line docstring"
    docstring = parse(text)
    assert docstring.short_description == text
    assert docstring.long_description == None
    docstring = parse(text, style=Style.numpy)
    assert docstring.short_description == text
    assert docstring.long_description == None

    text = "one-line docstring\n"
    docstring = parse(text)

# Generated at 2022-06-21 11:59:25.608632
# Unit test for function parse
def test_parse():
    assert parse('hello') == Docstring(content='hello')
    assert parse('hello\n') == Docstring(content='hello')
    assert parse('hello\nworld\n') == Docstring(content='hello\nworld')
    assert parse('hello\n\nworld\n') == Docstring(content='hello\n\nworld')
    assert (parse('hello\n\nworld\n\n', style=Style.google) ==
            Docstring(content='hello\n\nworld'))
    assert (parse('hello\n\nworld\n\n', style=Style.numpy) ==
            Docstring(content='hello\n\nworld'))

# Generated at 2022-06-21 11:59:31.474965
# Unit test for function parse
def test_parse():
    assert parse('A docstring.') == Docstring(short_description='A docstring.')
    assert parse('A docstring.', style=Style.google) == Docstring(
        short_description='A docstring.',
        )
    assert parse('A docstring.', style=Style.numpy) == Docstring(
        short_description='A docstring.',
        )

# Generated at 2022-06-21 11:59:39.567098
# Unit test for function parse
def test_parse():
    """Test for the function parse()"""
    input_str = """

    Function docstring
    :param arg1: [int] First argument
    :param arg2: [str] Second argument
    :raises ValueError: There is a problem"""

    expected_result = Docstring(
        summary="Function docstring",
        description=None,
        returns=None,
        raises=[("ValueError", "There is a problem")],
        meta=[("param", "arg1", "int", "First argument"),
              ("param", "arg2", "str", "Second argument")])

    assert parse(input_str) == expected_result

# Generated at 2022-06-21 11:59:40.962047
# Unit test for function parse
def test_parse():
    parse("test")

# Generated at 2022-06-21 11:59:49.872688
# Unit test for function parse
def test_parse():
    docstring = '''\
        This is a YARD-style docstring.

        @params a: first parameter
        @params b: second parameter
            second line of b
        @return: the return value
            second line of return
        '''
    result = parse(docstring, Style.yard)
    assert result.short_description == 'This is a YARD-style docstring.'
    assert result.long_description == ''
    assert len(result.params) == 2
    assert result.params['a'].description == 'first parameter'
    assert result.params['b'].description == 'second parameter\nsecond line of b'
    assert result.returns.description == 'the return value\nsecond line of return'

# Generated at 2022-06-21 11:59:52.814209
# Unit test for function parse
def test_parse():
    text = '''\
    Some text.
    '''

    parsed = parse(text)
    assert parsed.short_description == 'Some text.'


# Generated at 2022-06-21 12:00:04.148381
# Unit test for function parse
def test_parse():
    CLASS_DOCSTRING = '''Two sentence class summary.

Long class description

Attributes
----------
numFoo : int
    Number of foo bars

numBaz : int
    Number of baz frobs
'''

    NUMPY_DOCSTRING = '''Two sentence module summary.

Long module description that can contain
multiple paragraphs.

This module defines:

ex1 : int
    Description of variable ex1.
    This can contain multiple paragraphs.
ex2 : int
    Description of variable ex2.
ex3 : int
    Description of variable ex3.

Etc...
'''


# Generated at 2022-06-21 12:00:12.802002
# Unit test for function parse
def test_parse():
    print("Testing parse")

    docstring = parse("""
    Module to test docstring parsing.

    Args:
        message (str, required): message to print

    Returns:
        str: the passed message, after printing it
    """)

    print(docstring.summary)
    print(docstring.description)
    print(docstring.returns.type_name)
    print(docstring.params)
    print(docstring.params['args'].description)
    

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:19.825466
# Unit test for function parse
def test_parse():
    short_description="""This is a short description."""
    long_description="""
    This is a long description.

    This could be multiple paragraphs if you would like.
    """
    examples="""
    This is examples.

    Examples:
    >>> import example
    >>> example.hello()
    'Hello world!'
    """
    docstring = parse(short_description)
    assert docstring.short_description == "This is a short description."
    assert len(docstring.long_description) == 0
    assert len(docstring.examples) == 0
    docstring = parse(long_description)
    assert docstring.short_description == ""
    assert docstring.long_description == "This is a long description. This could be multiple paragraphs if you would like."
    assert len(docstring.examples) == 0
    doc

# Generated at 2022-06-21 12:00:31.257470
# Unit test for function parse
def test_parse():
    from docstring_parser.binary_parser import parse as parse_binary
    from docstring_parser.google_parser import parse as parse_google
    from docstring_parser.numpy_parser import parse as parse_numpy
    assert parse_binary("/**\n   Does something\n*/") == parse('/**\n   Does something\n*/')
    assert parse_numpy("""def foo(x):
    \"\"\"Does something.

    Parameters
    ----------
    x : int
        Meaning of x

    Returns
    -------
    int
        Meaning of return
    \"\"\"
""") == parse("""def foo(x):
    \"\"\"Does something.

    Parameters
    ----------
    x : int
        Meaning of x

    Returns
    -------
    int
        Meaning of return
    \"\"\"
""")

# Generated at 2022-06-21 12:00:35.009111
# Unit test for function parse
def test_parse():
    s = '''
    test2
    -------
    t2
    '''
    print(parse(s, style=Style.numpy))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:41.694993
# Unit test for function parse
def test_parse():
    def target():
        """This is the docstring.

        Args:
            foo (int): parameter foo
            bar (str): parameter bar
            baz (float, optional): parameter baz
        """
        pass

    print(parse(target.__doc__))

# This is the standard boilerplate that calls the main() function.
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:00:51.333926
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    input_ = """
    This function does a simple test
    @param a: The first parameter
    @param b: The second parameter
    @return: True iff all is good
    """

    docstring = parse(input_, style=Style.numpy)
    assert docstring.short_description == "This function does a simple test"
    assert docstring.long_description == ""
    assert [p.arg_name for p in docstring.params] == ["a", "b"]
    assert docstring.returns.type_name == "bool"
    assert docstring.returns.description == "True iff all is good"

# Generated at 2022-06-21 12:01:00.104905
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

# Generated at 2022-06-21 12:01:11.240182
# Unit test for function parse

# Generated at 2022-06-21 12:01:13.341533
# Unit test for function parse
def test_parse():
    assert parse("""
    """ == Docstring('',''))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:01:19.284440
# Unit test for function parse
def test_parse():
    # Some test scenarios
    assert parse("This is a tes") == "This is a tes"
    assert parse("This is a tes", Style.google) == "This is a tes"
    assert parse("This is a tes", Style.numpy) == "This is a tes"
    assert parse("This is a tes", Style.pep257) == "This is a tes"

# Generated at 2022-06-21 12:01:30.146350
# Unit test for function parse
def test_parse():
    text = '''Summary line.

Extended description. 

Args:
    arg1(int): Description of arg1
    arg2(str): Description of arg2
    
    arg3(bool): Description of arg3
        on multiple lines with indentation.
    
Raises:
    ValueError: If `arg2` is equal to `arg1`.

Returns:
    bool: Description of return value.
'''

# Generated at 2022-06-21 12:01:40.317278
# Unit test for function parse

# Generated at 2022-06-21 12:01:53.116356
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    from docstring_parser.styles import Style

    docstring1 = parse("""
                                Docstring description.
                                """)
    docstring2 = parse('Module description', style=Style.numpy)

    assert docstring1.short_description == 'Docstring description.'
    assert docstring1.parameters == []
    assert docstring1.returns == None
    assert docstring1.raises == []
    assert docstring1.warnings == None
    assert docstring1.meta == {}

    assert docstring2.short_description == 'Module description'
    assert docstring2.parameters == []
    assert docstring2.returns == None
    assert docstring2.raises == []
    assert docstring2.warnings == None
    assert docstring2.meta == {}



# Generated at 2022-06-21 12:02:00.056650
# Unit test for function parse
def test_parse():
    ds = """\
    A short summary.

    A much longer description.

    :param a: A.
    :type a: int
    :param b: B.
    :type b: str
    :returns: A + B
    :rtype: int
    """
    doc = parse(ds)
    assert type(doc)==Docstring
    assert str(doc)==ds.strip()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:02:03.798725
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse
    from docstring_parser.docstring import Docstring
    doc = parse('This is a short description.')
    assert type(doc) == Docstring
    assert doc.short_description == 'This is a short description.'


# Generated at 2022-06-21 12:02:14.196657
# Unit test for function parse
def test_parse():
    text = """Yapf's main purpose is to format code so that it conforms to the
    style guide. It is not concerned with fixing coding style errors, but
    instead enforcing a consistent coding style.

    Args:
        path (str): Path to the file to be reformatted.
        style_config (Optional[str]): Style config file path.

    Returns:
        A dictionary containing the fields:

        `path`: The path to the file that was reformatted.
        `in_place`: True if the reformatting was done in place.
        `encoding`: The encoding of the file that was reformatted.
        `changed`: The reformatted code.
    """
    parsed = parse(text)

# Generated at 2022-06-21 12:02:22.406039
# Unit test for function parse
def test_parse():
    docstring = """
    Summary line.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of the first argument.
    arg2 : str
        Description of the second argument.

    Returns
    -------
    bool
        Description of the return value.

    Raises
    ------
    AttributeError
        The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError
        If `arg2` is equal to `arg1`.
    """
    style = Style.auto
    result = parse(docstring, style)
    print("\n\n")
    print(result.summary)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:02:28.173685
# Unit test for function parse
def test_parse():
    class SimpleClass:
        """Class docstring."""
        def __init__(self):
            pass
    
    def test_docstring_parser():
        assert parse.__doc__ is not None

    if __name__ == "__main__":
        test_docstring_parser()
        print("Everything passed")


# Generated at 2022-06-21 12:02:37.625420
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    from pprint import pprint
    text = """Summary line.
    
    Extended description.
    
    Args:
        text: docstring text to parse
        style: docstring style
        retval: always True
    
    Returns:
        parsed docstring representation
    """
    d = parse(text, style=Style.google)
    assert d == GoogleStyle(text)
    assert d.summary_raw == 'Summary line.'
    assert d.description_raw == """
        Extended description.
        """

# Generated at 2022-06-21 12:02:43.653423
# Unit test for function parse
def test_parse():
    t = """
    This is test
    """
    assert parse(t).short_description == "This is test"
    assert parse(t).long_description == "This is test"
    assert parse(t).returns == None
    assert parse(t).raises == None
    assert parse(t).yields == None
    assert parse(t).params == None


# Generated at 2022-06-21 12:02:54.431735
# Unit test for function parse
def test_parse():
    text = """
        short summary.

        long
        multi-line
        summary.

        Args:
            arg1 (type): description
            arg2 (type): description

        Returns:
            description
    """
    docstring = parse(text, style=Style.auto)
    print("------parse result:")
    print("==========summary==========")
    print(docstring.short_description)
    print(docstring.long_description)
    print("==========parameters==========")
    for arg in docstring.params:
        print("name: ", arg.arg_name)
        print("description: ", arg.description)
    print("==========returns==========")
    print("return: ", docstring.returns.description)
    return

if __name__ == '__main__':
    test_parse

# Generated at 2022-06-21 12:02:56.649790
# Unit test for function parse
def test_parse():
    try:
        d = parse("")
    except ParseError as e:
        print(e)

test_parse()

# Generated at 2022-06-21 12:03:00.103142
# Unit test for function parse
def test_parse():
    assert parse('Example docstring.').short_description == 'Example docstring.'
    assert parse('') == ''

# Generated at 2022-06-21 12:03:05.968670
# Unit test for function parse
def test_parse():
    docstring = parse(
'''
Single line summary.

Single line description.

Args:
    arg1 (int): Description of arg1
    arg2 (str): Description of arg2

Returns:
    bool: Description of return value
''',
        style=Style.numpy
    )

    print(docstring)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:03:13.919794
# Unit test for function parse
def test_parse():
    text = '''This is the first line.

    This is the second line, which is longer
    than the first line.

    This is the third line.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is the first line.'
    assert docstring.long_description == '''This is the second line, which is longer
    than the first line.

    This is the third line.'''
    assert docstring.meta == {}


# Generated at 2022-06-21 12:03:18.437115
# Unit test for function parse
def test_parse():
    from . import PEP257_EXAMPLES
    for text, style in PEP257_EXAMPLES:
        try:
            parse(text, style=style)
        except ParseError as e:
            print("%r, %s" % (text, e))
            raise


# Generated at 2022-06-21 12:03:19.938069
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=False)

# Generated at 2022-06-21 12:03:27.077902
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    rst_str = """This function does something.

:param foo: the foo parameter
:param bar: the bar parameter
:returns: None
:raises ValueError: if something bad happens
    """
    numpy_str = """This function does something.

Parameters
----------
foo : int
    The foo parameter.
bar
    The bar parameter.

Returns
-------
None

Raises
------
ValueError
    If something bad happens.
    """
    google_str = """This function does something.

Args:
    foo: The foo parameter.
    bar: The bar parameter.

Returns:
    None

Raises:
    ValueError: If something bad happens.
    """
    # Test with different string (numpy, reSturcturedText, google)
    #

# Generated at 2022-06-21 12:03:37.827275
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    :param int param1: The first parameter.
    :param str param2: The second parameter.
    :returns: Description of return value.
    :raises KeyError: raises an exception
    """
    docstring = parse(text)
    assert docstring.short_description == 'Short description.'
    assert docstring.long_description == 'Long description.'

# Generated at 2022-06-21 12:03:49.754402
# Unit test for function parse
def test_parse():
    """Test docstring_parser.parse."""
    text = """This is a description.

This is more description.

:param path: path to file
:type path: str
:param size: size of file
:type size: int
:returns: return value
:raises OSError: when there's an OS error
"""
    doc = parse(text)
    assert len(doc.args) == 2
    assert doc.short_description == "This is a description."
    assert doc.long_description == "This is more description."
    assert doc.returns == "return value"
    assert doc.raise_ == "OSError: when there's an OS error"
    assert doc.args[0].arg_name == "path"
    assert doc.args[0].type_name == "str"
    assert doc.args

# Generated at 2022-06-21 12:03:59.325922
# Unit test for function parse
def test_parse():
    """Function to unit test function parse."""
    text = """\
    This is a test docstring.

    :param request: <your request>
    :param json: <your json>
    :returns: <your return>

    """
    p = parse(text, style=Style.google)
    print(p)
    print(p.params)
    print(p.returns)
    print(p.summary)
    print(p.yields)
    print(p.raises)
    print(p.attention)    # Attention is a custom section
    print(p.meta)
    print(p.extras)
    print(p.extras_dict)

test_parse()

# Generated at 2022-06-21 12:04:10.382321
# Unit test for function parse

# Generated at 2022-06-21 12:04:23.155551
# Unit test for function parse
def test_parse():
    text = """
    This is a function description.

    Args:
        arg_1: The first argument.
        arg_2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    d = parse(text)
    # Test docstring's attributes
    assert d.short_description == 'This is a function description.'
    assert d.long_description == ''
    # Test arguments parsing
    assert d.args[0].arg_name == 'arg_1'
    assert d.args[0].description == 'The first argument'
    assert d.args[1].arg_name == 'arg_2'
    assert d.args[1].description == 'The second arguement'
    # Test return parsing

# Generated at 2022-06-21 12:04:30.235575
# Unit test for function parse
def test_parse():
    long_str = \
'''
Short summary

Detailed summary

:param key1: value1
:param key2: value2
:param key3: value3
:return: value4
:raises: value5
:rtype: value6
'''
    summary, description, params, returns, rtype, raises = \
        parse(long_str)
    assert summary == "Short summary"
    assert description == "Detailed summary"
    assert params == {"key1" : "value1", "key2" : "value2", "key3" : "value3"}
    assert returns == "value4"
    assert rtype == "value6"
    assert raises == "value5"


# Generated at 2022-06-21 12:04:33.370702
# Unit test for function parse
def test_parse():
    docstring = parse("test", Style.pep257)

    assert docstring.short_description == "test"

# Generated at 2022-06-21 12:04:38.584719
# Unit test for function parse
def test_parse():
    doc = parse("""Example function with types documented in the docstring.

        :param int a: The integer to print
        :returns: Describe return value here
        :rtype: str
    """)
    print(doc.summary)
    print(doc.description)
    print(doc.parameters)
    print(doc.returns)
    print(doc.exceptions)
    print(doc.meta)
    

# Generated at 2022-06-21 12:04:48.956680
# Unit test for function parse
def test_parse():
    text = '''\
    This is a docstring for a function.

    :param arg1: argument 1
    :type arg1: int
    :param arg2: argument 2
    :type arg2: str
    :returns: list of str
    :raises ValueError:
        display a pretty error message
    :raises TypeError:
        display a another error message
    '''

    expected_doc = Docstring(short_description='This is a docstring for a function.',
                             long_description='',
                             parameters=[],
                             examples=[],
                             return_annotation='',
                             raises=[])
    assert parse(text, style=Style.napoleon) == expected_doc

# Generated at 2022-06-21 12:04:55.101333
# Unit test for function parse
def test_parse():
    param = """
        Test Description
        :param str test_param: parameter
    """
    doct = parse(param)
    assert doct.short_description == "Test Description"
    assert doct.params['test_param'].arg_type == 'str'
    assert doct.params['test_param'].description == 'parameter'


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:05:06.401428
# Unit test for function parse
def test_parse():
    """Test parse function."""
    from docstring_parser.common import Docstring, Field, MultiLine
    from docstring_parser.styles import reST
    description = 'My description'
    field = Field('meta', 'value')
    docstring = Docstring(description, [field])
    assert parse(reST(description, [field])) == docstring
    assert parse('My description', style=Style.reST) == docstring
    assert parse(reST(description, [MultiLine(field)])) == docstring
    assert parse(reST(description, [MultiLine(field)]), style=Style.reST) == docstring
    from docstring_parser.styles import numpy
    assert parse(numpy(description, field)) == docstring
    assert parse(numpy(description, field), style=Style.numpy) == docstring