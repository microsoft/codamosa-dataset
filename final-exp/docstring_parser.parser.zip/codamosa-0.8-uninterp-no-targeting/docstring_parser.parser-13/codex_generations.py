

# Generated at 2022-06-21 11:55:22.189759
# Unit test for function parse
def test_parse():
    # test_simple
    text = '''This is the summary.
    Description.
    '''
    d = parse(text)
    assert d.summary == 'This is the summary.'
    assert d.description == 'Description.'
    assert d.meta == {}

    # test_parameters_only
    text = '''This is the summary.
    :param foo: description of foo.
    :type foo: int
    '''
    d = parse(text)
    assert d.summary == 'This is the summary.'
    assert d.parameters == {
        'foo': {
            'description': 'description of foo.',
            'type': 'int'
        }
    }
    assert d.meta == {}

    # test_extra_indent

# Generated at 2022-06-21 11:55:29.023126
# Unit test for function parse

# Generated at 2022-06-21 11:55:35.082470
# Unit test for function parse
def test_parse():
    test_docstrings = [
        """\
    The ``Foo`` class.

    :param foo: The first foo.
    :type foo: int
    :param bar: The second foo.
    :type bar: str
    """
    ]

    for ds in test_docstrings:
        assert parse(ds)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:45.527508
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import PEP257
    from docstring_parser.common import Docstring
    import sys
    print("Testing function parse...", end="")

    ret = parse("")
    #init Docstring(summary='', description='', extra_block=None, tags=None, meta=None)
    ret_example = Docstring("","","",None,None)
    assert type(ret) == type(ret_example)
    assert ret == ret_example
    assert ret.meta == {}

    ret2 = parse("Testing the document string")
    assert ret2.summary == "Testing the document string"

    sys.modules["__main__"].__name__ = "__main__"
    ret3 = parse("Testing the document string", style = PEP257)
    assert ret3.summary == "Testing the document string"


# Generated at 2022-06-21 11:55:48.329627
# Unit test for function parse
def test_parse():
    @parse.register(str)
    def _parse(s: str, *a, **kw):
        return s
    assert parse('he') == 'he'

# Generated at 2022-06-21 11:55:59.922382
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Return, Parameter
    from docstring_parser.styles import Style
    assert isinstance(parse('', Style.auto), Docstring)
    assert isinstance(parse('', Style.google), Docstring)
    assert isinstance(parse('', Style.numpy), Docstring)
    assert isinstance(parse('', Style.sphinx), Docstring)
    assert isinstance(parse('', Style.napoleon), Docstring)
    assert isinstance(parse('', Style.napoleon_google), Docstring)
    assert isinstance(parse('', Style.napoleon_numpy), Docstring)
    assert isinstance(parse('', Style.makefun), Docstring)
    # Some unsupportted styles

# Generated at 2022-06-21 11:56:12.579403
# Unit test for function parse
def test_parse():
    assert parse(
        '''"""Converts numpy arrays to torch tensors.
        """
        '''
    )
    assert parse(
        '''"""Converts numpy arrays to torch tensors."""
        '''
    )
    assert parse(
        '''"""Converts numpy arrays to torch tensors.

        Args:
            data (np.ndarray): 3-dimensional numpy array of the form (channels,
                width, height).

        Returns:
            torch.Tensor: 3-dimensional torch tensor.
        """
        '''
    )

# Generated at 2022-06-21 11:56:23.387296
# Unit test for function parse
def test_parse():
    text = '''
    The main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    docstring = parse(text)

    assert docstring.short_description == 'The main parsing routine.'
    assert len(docstring.long_description) == 2
    assert docstring.long_description[1] == ':returns: parsed docstring representation'
    assert docstring.meta['param']['text'] == 'docstring text to parse'
    assert docstring.meta['param']['style'] == 'docstring style'
    assert docstring.meta['return']['parsed docstring representation'] == ''

test_parse()

# Generated at 2022-06-21 11:56:30.903838
# Unit test for function parse
def test_parse():
    assert(parse("""\
To be
Or not to be
""").summary == "To be\nor not to be")
    assert(parse("""
To be
====
Or not to be
-------
""").summary == "To be or not to be")
    assert(parse("""\
To be
Or not to be

A question
""").summary == "To be\nor not to be")
    assert(parse("""\
To be
Or not to be

A question
""").description == "A question")
    assert(parse("""
To be
====
Or not to be
-------

A question
""").description == "A question")
    assert(parse("""\
To be
Or not to be

A question
""").description == "A question")

# Generated at 2022-06-21 11:56:40.727226
# Unit test for function parse
def test_parse():
    """Testing the parse function."""
    import textwrap

    doc = """
    This is a function docstring.

    :param name: parameter name
    :param list list_name: parameter named list_name
    :type list_name: List[str]
    :param param2: another parameter
    :type param2: int
    :returns: something
    :rtype: str
    """


# Generated at 2022-06-21 11:56:53.275746
# Unit test for function parse
def test_parse():
    text = '''
    This is a doc string

    :param name: is a name
    :type name: str
    :returns: hello
    :raises Exception: if something bad happened
    '''
    doc = parse(text)
    assert doc.short_description == 'This is a doc string'
    assert doc.long_description == ''
    assert doc.params == [
        ('name', 'is a name', 'str', '/param'),
    ]
    assert doc.returns == ('hello', '/returns')
    assert doc.throws == [('Exception', 'if something bad happened', '/raises')]


# Generated at 2022-06-21 11:57:03.799259
# Unit test for function parse
def test_parse():

    d = parse('')
    assert not d.summary
    assert not d.meta

    d = parse('test docstring')
    assert not d.summary
    assert len(d.meta) == 1
    meta = d.meta[0]
    assert meta.description == 'test docstring'
    assert not meta.args
    assert not meta.returns

    d = parse('param a\r\nreturn b\r\n')
    assert not d.summary
    assert len(d.meta) == 3
    meta = d.meta[0]
    assert not meta.description
    assert len(meta.args) == 1
    arg = meta.args[0]
    assert arg.name == 'a'
    meta = d.meta[1]
    assert not meta.description
    assert not meta.args

# Generated at 2022-06-21 11:57:12.556928
# Unit test for function parse
def test_parse():
    text = (
        ":param str a: parameter a\n"
        ":param int b: parameter b\n"
        ":returns: something\n"
        ":raises ValueError: if something wrong happens\n"
        "\n"
        "my docstring"
    )
    doc = parse(text)
    # a
    assert doc.meta["a"].type_name == "str"
    assert doc.meta["a"].description == "parameter a"
    # b
    assert doc.meta["b"].type_name == "int"
    assert doc.meta["b"].description == "parameter b"
    # return
    assert doc.returns.type_name == ""
    assert doc.returns.description == "something"
    # raise

# Generated at 2022-06-21 11:57:24.966531
# Unit test for function parse
def test_parse():
    """test parse function"""
    import doctest
    doctest.testmod()
    assert parse("""
    This function does something.
    """) == Docstring(
        content='This function does something.',
        meta={},
        style=Style.pep257,
    )
    assert parse("""
    This function does something.

    :param str x: X parameter
    :param int y: Y parameter
    :returns: result
    """) == Docstring(
        meta={
            'Parameters': {
                'x': 'X parameter'
            },
            'Returns': 'result',
        },
        content='This function does something.',
        style=Style.pep257,
    )

# Generated at 2022-06-21 11:57:32.802288
# Unit test for function parse
def test_parse():
    kwargs = {
        "a" : 1,
        "b" : "2",
        "c" : 3.0,
        "d" : 4 + 4j,
        "e" : ["f", "g"],
        "h" : ("i", "j", "k"),
        "l" : {"m" : 1, "n" : 2, "o" : 3},
        "p" : {"q" : {"r" : {"s" : (1, 2, 3)}}},
        "t" : "u" * 100
    }


# Generated at 2022-06-21 11:57:38.462110
# Unit test for function parse
def test_parse():
    text = """\
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    res = parse(text)
    print(res)
    assert isinstance(res, Docstring)
    assert res.full_text == text


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:57:49.869475
# Unit test for function parse
def test_parse():
    text = """"""
    docstring = parse(text)

# Generated at 2022-06-21 11:57:55.156961
# Unit test for function parse
def test_parse():
    """
    The main testing routine.
    """

    return parse(text)


if __name__=="__main__":
    text="""This is a single-line summary.
    And this is the multi-line description.
    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.
    Returns
    -------
    int
        The return value.
    Other Parameters
    ----------------
    foo : int
        The first argument.
    bar : int
        The second argument.
    """


    print(test_parse())

# Generated at 2022-06-21 11:58:06.806627
# Unit test for function parse
def test_parse():
    content = '''
    Test function parse.

    Parameters
    ----------
    text : str
        docstring text to parse
    style : Style = Style.auto
        docstring style
    returns : Docstring
        parsed docstring representation
    '''
    actual = parse(content)

# Generated at 2022-06-21 11:58:22.193451
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle, NumpyStyle
    # Test GoogleStyle
    google_docstring = """\
    Single-line short summary.

    Extended description. No new line at the end.

    Args:
        arg1 (str): Description of `arg1`
        arg2 (list): Description of `arg2`
    """
    assert isinstance(parse(google_docstring, style=Style.google), GoogleStyle)
    assert isinstance(parse(google_docstring), GoogleStyle)
    # Test NumpyStyle
    numpy_docstring = """\
    Single-line short summary.

    Extended description.

    Parameters
    ----------
    arg1 : str
        Description of `arg1`.
    arg2 : list
        Description of `arg2`.
    """

# Generated at 2022-06-21 11:58:36.581637
# Unit test for function parse
def test_parse():
    '''test_parse test case'''
    docstring = """
    A docstring.

    :param a: 1st param
    :param b: 2nd param
    :return: doc
    """
    data = parse(docstring)
    assert data.short_description == 'A docstring.'
    assert data.long_description == 'A docstring.'
    assert data.params == [
        {'name': 'a', 'type': None, 'desc': '1st param', 'optional': False},
        {'name': 'b', 'type': None, 'desc': '2nd param', 'optional': False},
    ]
    assert data.returns == {'type': None, 'desc': 'doc'}
    assert data.meta == {}

# Generated at 2022-06-21 11:58:40.599342
# Unit test for function parse
def test_parse():
    text = """This is a description.
    This is a continuation.
    
    :param x: a parameter
    :type x: int
    """
    doc = parse(text)
    assert doc.short_description == "This is a description."
    assert doc.long_description == "This is a continuation."
    assert len(doc.meta) == 1
    assert doc.meta["x"].arg_type == "int"



# Generated at 2022-06-21 11:58:52.600846
# Unit test for function parse

# Generated at 2022-06-21 11:59:00.370114
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import STYLES, Style

    assert(parse("test_parse") == Docstring(
        content="test_parse",
        short_description="test_parse",
        long_description=None,
        meta={},
        tags=[],
        style=Style.doxygen,
    ))
    assert(parse("test_parse", style=Style.google) == Docstring(
        content="test_parse",
        short_description="test_parse",
        long_description=None,
        meta={},
        tags=[],
        style=Style.google,
    ))

# Generated at 2022-06-21 11:59:09.052924
# Unit test for function parse
def test_parse():
    import os
    import sys
    import pytest

    # Locate test module
    package_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(package_dir, 'tests')
    sys.path.insert(0, test_dir)
    test_parse_module = __import__('test_parse_suite', 
                                   globals(), 
                                   locals(), 
                                   ['*'], 
                                   0)

    # Run tests
    # List of test functions: ('name', 'style', 'failure_message')

# Generated at 2022-06-21 11:59:12.020861
# Unit test for function parse
def test_parse():
    text = '''Test function for parsing docstring'''
    p = parse(text)
    assert(p.long_description == 'Test function for parsing docstring')

# Generated at 2022-06-21 11:59:20.140879
# Unit test for function parse

# Generated at 2022-06-21 11:59:25.979515
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError
    from docstring_parser.styles import STYLES, Style

    assert parse("This is a docstring") == Docstring(short_description='This is a docstring')
    assert parse("This is a docstring", style=Style.google) == Docstring(short_description='This is a docstring')
    assert parse("This is a docstring", style=Style.numpy) == Docstring(short_description='This is a docstring')
    assert parse("This is a docstring", style=Style.sphinx) == Docstring(short_description='This is a docstring')
    assert parse("This is a docstring", style=Style.default) == Docstring(short_description='This is a docstring')
    assert parse("This is a docstring", style=Style.auto)

# Generated at 2022-06-21 11:59:37.711133
# Unit test for function parse
def test_parse():
    text = """\
Some description

    Single line description
    that takes
    more than one line.

:param name: Description of the argument
:param peremeter: Description of the argument
:param argument: Description of the argument

"""
    docstring = parse(text, Style.google)
    assert isinstance(docstring, Docstring)
    assert len(docstring.meta) == 3
    assert docstring.meta[0].arg_name == 'name'
    assert docstring.meta[0].arg_desc == 'Description of the argument'
    assert docstring.meta[1].arg_name == 'peremeter'
    assert docstring.meta[1].arg_desc == 'Description of the argument'
    assert docstring.meta[2].arg_name == 'argument'
    assert docstring.meta[2].arg_

# Generated at 2022-06-21 11:59:49.444203
# Unit test for function parse
def test_parse():
    text = '''I have a long one-line summary,
which is a good thing for the module. It is followed by a blank line.

I have a long description. I should be wrapped at 79 characters, but
may be longer if it spans multiple paragraphs.

:param str param: This is a parameter.
:param str one_with_default: Default value.
:param str another_one_with_default: Default value.
:returns: Test return docstring
:rtype: str
'''
    style = Style.google
    result = parse(text, style)
    assert result != None
    assert result.short_description == 'I have a long one-line summary, which is a good thing for the module. It is followed by a blank line.'

# Generated at 2022-06-21 12:00:04.709144
# Unit test for function parse
def test_parse():
	docstring="""Summary line.

    Description of what your object does.

    Attributes:
        attr1 (str): Description of `attr1`.
        attr2 (:obj:`int`, optional): Description of `attr2`.

    Example:
        Examples should be written in doctest format, and
        should illustrate how to use the function/class.
        >>> foo = MyObject()
        >>> foo.bar()

    """
	ret=parse(docstring)
	assert ret.summary == "Summary line."
	assert ret.description == "Description of what your object does."
	assert ret.meta[0].name == "attr1 (str): "
	assert ret.meta[0].content == "Description of `attr1`."
	assert ret.meta[1].name == "attr2 (:obj:`int`, optional): "
	

# Generated at 2022-06-21 12:00:09.537237
# Unit test for function parse
def test_parse():
    """Test function parse."""

    doc = """Multiple lines docstring.

This docstring should contain a summary line and a blank line.
"""
    ds = parse(doc)
    assert ds.summary == 'Multiple lines docstring.'


# Generated at 2022-06-21 12:00:15.972935
# Unit test for function parse
def test_parse():
    text = '''
    function \n
    :param param1: this is the first param
    :param param2: this is a second param
    :returns: this is a description of what is returned
    :raises keyError: raises an exception
    '''

    d = parse(text, style=Style.numpy)
    if(d.short_description == 'function'):
        print("parse works") 
    else:
        print("parse doesn't work")


test_parse()

# Generated at 2022-06-21 12:00:27.215196
# Unit test for function parse
def test_parse():
    text = [
    'Example class.',
    '',
    'Long description.',
    '',
    'Attributes:',
    '    attr1 (int): Description of `attr1`.',
    '    attr2 (:obj:`str`, optional): Description of `attr2`.',
    '',
    'Example:',
    '    Examples should be written in doctest format, and should illustrate how',
    '    to use the function/class. ',
    '    >>> foo = Fixture()'
    ]
    text = '\n'.join(text)
    docstring = parse(text)
    assert len(docstring.short_description) > 0
    assert len(docstring.long_description) > 0
    assert len(docstring.example) > 0
    assert len(docstring.meta)

# Generated at 2022-06-21 12:00:33.360006
# Unit test for function parse
def test_parse():
    text1 = "This is a test.\n\nAnd this is a meta.\n\nThis is the description."
    text2 = "This is a test.\n\n  And this is a meta.\n\n  This is the description."
    text3 = "This is a test.\n\nAnd this is a meta.\n\n  This is the description."
    text4 = "This is a test.\n\nAnd this is a meta.\n\nThis is the description."
    assert parse(text1).meta == "And this is a meta."
    assert parse(text1).description == "This is the description."
    assert parse(text2).meta == "And this is a meta."
    assert parse(text2).description == "This is the description."

# Generated at 2022-06-21 12:00:44.495425
# Unit test for function parse
def test_parse():
    text = """
    Returns the maximum of all function values.

    :param arg1: the first value.
    :param arg2: the second value.
    :type arg1: int, float,...
    :type arg2: int, float,...
    :returns: the maximum of arg1 and arg2.
    :rtype: int, float
    """
    assert parse(text).returns == ("Returns the maximum of all function values.", "the maximum of arg1 and arg2.")
    assert parse(text).meta == {"arg1": "the first value.", "arg2": "the second value."}
    assert parse(text).meta_types == {"arg1": ["int", " float", "..."], "arg2": ["int", " float", "..."]}


# Generated at 2022-06-21 12:00:55.906835
# Unit test for function parse
def test_parse():
    from pprint import pprint
    print(__doc__)
    print("Testing function parse")
    doc_string = """
    This function produces error messages in either the smtp or imap servers
    depending on the update status of the stated user.

    :param user: User to create the error for
    :returns: None
    :raises ValueError: If the user is not found or is of the wrong type
    """
    parsed = parse(doc_string)
    pprint(parsed)
    assert parsed.params == [
                              { 'type': None,
                                'name': 'user',
                                'desc': 'User to create the error for'
                                }
                             ]

# Generated at 2022-06-21 12:01:07.246393
# Unit test for function parse
def test_parse():
    """Test for function parse"""

# Generated at 2022-06-21 12:01:17.778529
# Unit test for function parse
def test_parse():
    doc_str0 = '''
        This is a function template

        Args:
            a (int): This is the first parameter
            b (int): This is the second parameter

        Returns:
            int: The return value is a+b
        '''

    ds = parse(doc_str0)
    print(ds.meta['Args'])
    print(ds.meta['Returns'])
    assert ds.meta['Args'][0]['name'] == 'a'
    assert ds.meta['Args'][1]['name'] == 'b'
    assert ds.meta['Returns'][0]['type'] == 'int'
    assert ds.meta['Returns'][0]['desc'] == 'The return value is a+b'


# Generated at 2022-06-21 12:01:22.168801
# Unit test for function parse
def test_parse():
    """test parse() """
    text = '''
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    docstring = parse(text)
    print(docstring)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:01:30.588935
# Unit test for function parse
def test_parse():
    docstring = '''
        """A docstring.
        :param foo: Foo param
        :param bar: Bar param
        :returns: A value
        """
        '''
    assert parse(docstring).meta["bar"].description == "Bar param"
    assert parse(docstring).returns.description == "A value"

# Generated at 2022-06-21 12:01:37.359259
# Unit test for function parse
def test_parse():
    text = """
    Hello world

    :param x: This is x
    :rtype: int
    """

    docstr_obj = parse(text)

    # Test the value of docstr_obj
    assert docstr_obj.description == "Hello world"
    assert docstr_obj.meta['x'][0] == "This is x"
    assert docstr_obj.meta['rtype'] == "int"


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:01:43.961004
# Unit test for function parse
def test_parse():
    text = """
    The parse function of a docstring.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation

    """
    result = parse(text)
    assert result.short_description == "The parse function of a docstring."
    assert result.long_description == ""
    assert result.meta == {
        'param': [{'name': 'text', 'description': 'docstring text to parse', 'type': None}],
        'return': {'description': 'parsed docstring representation', 'type': 'None'}
    }

# Generated at 2022-06-21 12:01:48.598159
# Unit test for function parse
def test_parse():
    def f(i):
        """Foo bar
        :param i: baz quux

        """
        pass
    testf = parse(f.__doc__)
    assert testf.short_description == 'Foo bar'
    assert testf.long_description == ""
    assert testf.params[0].name == 'i'

# Generated at 2022-06-21 12:01:55.111659
# Unit test for function parse
def test_parse():
    import os
    import sys
    pyfile = open(os.path.join(os.getcwd(), 'docstring_parser', '__init__.py'))
    docstring = pyfile.read()
    pyfile.close()
    print("\nUnit test for function parse from docstring_parser.__init__.py\n")
    print(parse(docstring, Style.auto))
    
#Unit test for function parse
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:05.096666
# Unit test for function parse
def test_parse():
    text = """The ``parse`` function parses a given docstring into its
    components.

    This is a short summary.

    This is the extended summary.

    :param text: docstring to parse
    :param style: docstring style
    :returns: parsed representation
    """
    parsed = parse(text)
    assert len(parsed.short_description.split()) == 5
    assert len(parsed.long_description.split()) == 5
    assert parsed.meta['parameters']['text'].type == 'str'
    assert parsed.meta['parameters']['style'].type == 'Style'
    assert parsed.meta['returns'].type == 'Docstring'
 
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:15.368939
# Unit test for function parse
def test_parse():
    # The function test_parse() tests the function parse()
    # We have to give some text to parse
    # The style should be the same with the style of text we have, otherwise it will raise the ParseError
    # We can also give a variable style
    # The return value should be Docstring type
    doc = '''This is a test docstring.
    :param name: The name to say hello to
    :type name: str
    :param quiet: Whether to print or not
    :type quiet: bool'''

    assert(type(parse(doc)) == Docstring)
    assert(type(parse(doc, Style.google)) == Docstring)
    assert(type(parse(doc, Style.numpy)) == Docstring)
    assert(type(parse(doc, Style.auto)) == Docstring)


test_parse()

# Generated at 2022-06-21 12:02:26.585960
# Unit test for function parse
def test_parse():
  text = """This docstring has two paragraphs. The second of them
  
  spans two lines.
  Author: Foo Bar
  Email: foobar@example.com
  Date: Today
  
  """
  assert parse(text).__dict__ == {'desc': 'This docstring has two paragraphs. The second of them\n\nspans two lines.', 'first': 'The second of them\n\nspans two lines.', 'meta': {'author': 'Foo Bar', 'email': 'foobar@example.com', 'date': 'Today'}}

  text = """\
  This docstring has two paragraphs. The second of them
  spans two lines.


  """

# Generated at 2022-06-21 12:02:36.492347
# Unit test for function parse
def test_parse():
    import os.path as osp
    from docstring_parser.common import Docstring
    from docstring_parser.styles import reStructuredTextStyle
    from sphinx.util.docstrings import prepare_docstring

    test_file = osp.join(osp.dirname(__file__), 'test_data.txt')
    text = open(test_file, 'r').read()
    mydoc = docstring_parser.parse(text)

    rst_docstring = prepare_docstring(text)
    rst_doc = reStructuredTextStyle(rst_docstring)

    srt_docstring = __doc__
    srt_doc = reStructuredTextStyle(srt_docstring)

    assert type(mydoc) is Docstring
    assert str(mydoc) == text

# Generated at 2022-06-21 12:02:43.865149
# Unit test for function parse
def test_parse():
    py_docstring = '''
    This is the module docstring.

    This is the section for module level docstring which
    explains about the module.
    '''

    parsed = parse(py_docstring, style=Style.google)

    assert parsed['summary'] == 'This is the module docstring.'
    assert parsed['description'] == 'This is the section for module level docstring which explains about the module.'
    assert parsed['args'] == list()

test_parse()

# Generated at 2022-06-21 12:02:58.469633
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Line
    from docstring_parser.styles import RST
    docstring = "Authors: Jesse Stone\n" \
                "          John Smith\n" \
                "------------------\n" \
                "Date:   2015-09-17\n" \
                "------------------\n" \
                "Summary:\n" \
                "     This is a summary.\n" \
                "\n" \
                "Parameters:\n" \
                "    arg1: Parameter 1\n" \
                "    arg2: Parameter 2\n" \
                "    arg3: Parameter 3\n" \
                "    arg4: Parameter 4\n" \
                "\n" \
                "Returns:\n" \
                "    Return value\n"

    docs = parse

# Generated at 2022-06-21 12:03:08.056773
# Unit test for function parse
def test_parse():
    code1 ="""function1 description 

    Params
    -------
    p1: int
        parameter1 description

    p2: str
        parameter2 description
        """
    result1 = parse(code1)
    assert result1.long_description == "function1 description"
    assert result1.sections[0].title == "Params"
    assert result1.sections[0].content == "p1: int\n\tparameter1 description\np2: str\n\tparameter2 description\n\t"
    assert result1.sections[0].content_list == [("p1", "int", "parameter1 description"), ("p2", "str", "parameter2 description")]

# Generated at 2022-06-21 12:03:11.729826
# Unit test for function parse
def test_parse():
    assert isinstance(parse(""), Docstring) == True
    assert isinstance(parse("", style=Style.auto), Docstring) == True
    assert isinstance(parse("", style=Style.numpy), Docstring) == True
    assert isinstance(parse("", style=Style.google), Docstring) == True

# Generated at 2022-06-21 12:03:15.610493
# Unit test for function parse
def test_parse():
    str = """\
    This is a test
    """
    doc = parse(str)
    assert doc.short_description == 'This is a test'
    print (doc)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:03:20.726379
# Unit test for function parse
def test_parse():
    text = '''
    Parses the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    #print(parse(text))
    print(parse(text).__dict__)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:03:26.379935
# Unit test for function parse
def test_parse():
    code = """
    This is an example code.

    :param text: docstring text to parse
    :returns: parsed docstring representation
    """
    print(parse(code))
    print(parse(code, style=Style.google))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:03:33.591235
# Unit test for function parse
def test_parse():
    text1 = """
        Parameters
        ----------
        a: str
            The first parameter.
        b: str, optional
            The second parameter.


        Returns
        -------
        c: bool
            The return value.

        """
    text2 = """
        Parameters
        ----------
        a : str
            The first parameter.
        b : str, optional
            The second parameter.


        Returns
        -------
        c : bool
            The return value.

        """

# Generated at 2022-06-21 12:03:34.507040
# Unit test for function parse
def test_parse():
    text = """This is the docstring"""
    print(parse(text))

# Generated at 2022-06-21 12:03:44.016035
# Unit test for function parse
def test_parse():
	text = '''This function does something.
			:param foo: Foo
			:type foo: int
			:returns: Return
			:rtype: str
			'''
	docstring = parse(text)
	assert docstring.short_description == 'This function does something.'
	assert docstring.long_description is None
	assert docstring.params['foo'].description == 'Foo'
	assert docstring.params['foo'].type_name == 'int'
	assert docstring.returns.description == 'Return'
	assert docstring.returns.type_name == 'str'

# Generated at 2022-06-21 12:03:48.810803
# Unit test for function parse
def test_parse():
    from .test_simple import DOCSTRING, DOCSTRING_JSON
    docstring = parse(DOCSTRING)
    assert(str(docstring) == DOCSTRING)
    docstring = parse(DOCSTRING_JSON, Style.google)
    assert(str(docstring) == DOCSTRING_JSON)


# Generated at 2022-06-21 12:03:57.863015
# Unit test for function parse
def test_parse():
    text = """Summary line here.

Extended description of function here.

Parameters
----------
arg1 : int
    Description of arg1
arg2 : str
    Description of arg2
arg3 : str
    Description of arg3

Returns
-------
:obj:`int`
    Description of return value

Raises
------
IOError
    Description of exception raised
"""
    docstring = parse(text)
    assert docstring.long_description.strip() == "Extended description of function here."
    assert docstring.args['arg1'].description.strip() == 'Description of arg1'
    assert docstring.args['arg2'].description.strip() == 'Description of arg2'
    assert docstring.args['arg3'].description.strip() == 'Description of arg3'
    assert docstring.returns.description

# Generated at 2022-06-21 12:04:09.121097
# Unit test for function parse
def test_parse():
    docstring = "title\nparagraph\n"
    d = parse(docstring)
    assert d.meta == dict()
    assert d.short_description == "title"
    assert d.long_description == "paragraph"
    assert len(d.params) == 0
    assert len(d.yields) == 0
    assert len(d.raises) == 0
    assert d.returns is None
    assert len(d.others) == 0

    # test for numpy style
    docstring = """
    title

    paragraph
    args:
    param1:
    """
    d = parse(docstring)
    assert d.meta == dict()
    assert d.short_description == "title"
    assert d.long_description == "paragraph"
    assert len(d.params) == 1

# Generated at 2022-06-21 12:04:16.522712
# Unit test for function parse
def test_parse():
    d = parse("""Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    int
        Description of return value
    """)
    assert d.short_description == "Summary line."
    assert d.long_description == "Extended description."
    assert d.params[0].arg_name == "arg1"
    assert d.returns.arg_name == "int"


# Generated at 2022-06-21 12:04:18.884444
# Unit test for function parse
def test_parse():
    docstringtext="""test function"""
    docstring=parse(docstringtext)
    assert str(docstring)==docstringtext

test_parse()

# Generated at 2022-06-21 12:04:21.426868
# Unit test for function parse
def test_parse():
    """Function test for module"""
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:04:28.587771
# Unit test for function parse

# Generated at 2022-06-21 12:04:34.451081
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google
    assert isinstance(parse(''), Docstring)
    assert isinstance(parse(''), Google)
    assert isinstance(parse('', style=Google), Google)
    assert isinstance(parse('', style=Style.google), Google)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:04:42.131890
# Unit test for function parse
def test_parse():
    docstring = '''
    Short summary, which can be one line

    Extended description with indented paragraphs,

    bullet-list, quote sections,
    or code examples.

    :param a: parameter description
    :type a: str
    :param b:
        parameter description
        spanning multiple lines
    :type b: int
    :returns: object description
    '''
    assert parse(docstring).short_description == 'Short summary, which can be one line'
    assert parse(docstring).long_description == '\nExtended description with indented paragraphs,\n\nbullet-list, quote sections,\nor code examples.'
    assert parse(docstring).params['a'].description == 'parameter description'
    assert parse(docstring).params['b'].description == '\nparameter description\nspanning multiple lines'

# Generated at 2022-06-21 12:04:47.097695
# Unit test for function parse
def test_parse():
    expected_results = {
        # no meta, no content
        ' ': {'meta': {}, 'content': ''},
        # meta, no content
        ':arg a: 1': {'meta': {'arg': {'a': '1'}}, 'content': ''},
        # no meta, content
        'a\nb': {'meta': {}, 'content': 'a\nb'},
        # meta, content
        ':arg a: 1\n\na\nb': {'meta': {'arg': {'a': '1'}}, 'content': 'a\nb'}
    }

    results = {
        key: parse(key).to_dict()
        for key in expected_results
    }
    assert results == expected_results

# Generated at 2022-06-21 12:04:54.478843
# Unit test for function parse
def test_parse():
    print('Test function parse')
    from docstring_parser.styles import google
    from docstring_parser.styles import Numpy
    from docstring_parser.styles import Google

    print('Test Google style docstring')
    text = """
    Calculate the square of an integer
    :param x: The number to square
    :type x: int
    :returns: int -- The number squared
    """
    docstring = parse(text, style='google')
    print('Summary: ', docstring.short_description)
    print('Long Description: ', docstring.long_description)
    print('Return: ', docstring.returns)
    print('Yield: ', docstring.yields)
    print('Args: ', docstring.args)
    print('Parameters: ', docstring.params)

# Generated at 2022-06-21 12:05:04.535256
# Unit test for function parse
def test_parse():
    ds = '''\
    :param foo: asdgas
    :type foo: int
    :returns: a
    :rtype: str
    '''
    assert parse(ds).params == [('foo', 'int', 'a', 'asdgas')]
    assert parse(ds).returns == [('a', 'str')]
    ds = '''\
    :param foo: asdgas
    :type foo: int
    :returns: a
    :rtype: str
    '''
    assert parse(ds).params == [('foo', 'int', 'a', 'asdgas')]
    assert parse(ds).returns == [('a', 'str')]