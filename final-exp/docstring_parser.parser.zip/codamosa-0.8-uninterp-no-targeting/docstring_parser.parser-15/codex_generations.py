

# Generated at 2022-06-21 11:55:21.484815
# Unit test for function parse
def test_parse():
    """Unit test for function parse.
    """
    text = """This is a test docstring.
    This line is indented.

    This is a paragraph.

    :param arg1: the first argument
    :param arg2: the second argument
    :return: None
    :raises Exception: if something bad happened
    """
    docstring = parse(text)
    assert docstring.summary == 'This is a test docstring.'
    assert docstring.indented == 'This line is indented.'
    assert docstring.params == ['arg1', 'arg2']
    assert docstring.meta['return']['desc'] == 'None'
    assert len(docstring.meta['raises']) == 1
    assert docstring.meta['raises'][0]['type'] == 'Exception'

# Generated at 2022-06-21 11:55:23.087178
# Unit test for function parse
def test_parse():
    text = '''
    summary
    '''
    output = parse(text, style=Style.numpy)

# Generated at 2022-06-21 11:55:29.512474
# Unit test for function parse
def test_parse():
    expected = Docstring(
        'Summary.\n',
        'Description.\n',
        ':param path: The path to the file to wrap\n:param mode: The mode to open the file with\n',
        ':raises ValueError: If `mode` is invalid\n:return: a file object\n',
        ':rtype: BufferedReader[AnyStr]\n',
        '',
        ':Example:\n    with open_file(path, mode="rb") as fp:\n        fp.read()\n'
    )

# Generated at 2022-06-21 11:55:35.427847
# Unit test for function parse
def test_parse():
    text = 'This is a test.\n\nThis is a test.'
    style = Style.numpy
    assert False == isinstance(parse(text, style), Docstring)
    assert True == isinstance(parse(text, style), Docstring)
    assert False == isinstance(parse(text), Docstring)
    assert True == isinstance(parse(text), Docstring)

test_parse()

# Generated at 2022-06-21 11:55:42.190680
# Unit test for function parse
def test_parse():
    text = '''
    Some function.

    Args:
        arg1: First argument.
    '''
    parsed = parse(text, style=Style.numpy)

    assert parsed.short_description == 'Some function.'
    assert parsed.long_description == ''

    assert parsed.args[0].arg_name == 'arg1'
    assert parsed.args[0].description == 'First argument.'
    assert parsed.args[0].default_value == None
    assert parsed.args[0].annotations == dict()

# Generated at 2022-06-21 11:55:50.294580
# Unit test for function parse
def test_parse():
    """Test for parsing docstrings."""

# Generated at 2022-06-21 11:56:00.447123
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    text = """Summary line.
    Extended description.
    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`
    Returns
    -------
    bool
        Description of return value
    """
    assert parse(text) == Docstring(
        summary='Summary line.',
        description="Extended description.",
        extended_description='',
        params=[
            ('arg1', 'int', 'Description of `arg1`'),
            ('arg2', 'str', 'Description of `arg2`'),
        ],
        returns=('bool', 'Description of return value')
    )

# Generated at 2022-06-21 11:56:03.144227
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()


# Generated at 2022-06-21 11:56:04.288396
# Unit test for function parse
def test_parse():
    assert parse("test") is not None

# Generated at 2022-06-21 11:56:15.395087
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Pep257, Google
    from docstring_parser.common import Docstring
    assert isinstance(parse('Hello, World!', style=Style.google), Docstring)
    assert isinstance(parse('Hello, World!', style=Style.pep257), Docstring)
    assert isinstance(parse('Hello, World!', style=Style.auto), Docstring)
    assert isinstance(parse('Hello, World!', style=Google), Docstring)
    assert isinstance(parse('Hello, World!', style=Pep257), Docstring)
    assert not isinstance(parse('Hello, World!', style=Style.numpy), Docstring)
    assert not isinstance(parse('Hello, World!', style=Style.sphinx), Docstring)

# Generated at 2022-06-21 11:56:29.232585
# Unit test for function parse
def test_parse():
    ds = parse("""Python library for parsing docstrings.

    :param text: docstring text to parse
    :param style: docstring style
    """)
    assert ds.short_description == "Python library for parsing docstrings.\n"
    assert ds.long_description == ""
    assert ds.meta[0].arg_name == "text"
    assert ds.meta[0].type_name == ""
    assert ds.meta[0].description == "docstring text to parse"
    assert ds.meta[0].default_value == ""
    assert ds.meta[1].arg_name == "style"
    assert ds.meta[1].type_name == ""
    assert ds.meta[1].description == "docstring style"

# Generated at 2022-06-21 11:56:31.879378
# Unit test for function parse
def test_parse():
    text = "1. this is a text"
    parse_result = parse(text)
    print(parse_result)


# Generated at 2022-06-21 11:56:41.343548
# Unit test for function parse
def test_parse():
    """Test that parse correctly parses its argument"""
    docstring = """
    A short summary
    A second line of summary.

    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: Description of return value.
    :raises Exception1: An exception.
    :raises Exception2: Another exception.
    """
    parsed = parse(docstring)
    assert parsed == Docstring(summary='A short summary\nA second line of summary.',
                               description='',
                               returns='Description of return value.',
                               raises=[('Exception1', 'An exception.'), ('Exception2', 'Another exception.')],
                               params=[('param1', 'The first parameter.'), ('param2', 'The second parameter.')],
                               meta={})



# Generated at 2022-06-21 11:56:42.895704
# Unit test for function parse
def test_parse():
    pass

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:56:48.028086
# Unit test for function parse
def test_parse():
    docstring = parse.__doc__
    print(docstring)
    for p in STYLES.values():
        result = p(docstring)
        print(result.summary)
        print(result.meta)
        print(result.description)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:56:54.507824
# Unit test for function parse
def test_parse():
    text = """An example docstring.

:param foo: A positional argument
:param bar: A keyword argument
:ivar baz: An attribute
:cvar quux: A class attribute
:raises IndexError: if the index is out of range.
:return:
:rtype: :class:`Model`
"""
    docstring = parse(text)
    assert docstring is not None
    assert docstring.short_description == 'An example docstring.'
    assert len(docstring.long_description) == 10
    assert len(docstring.meta) == 5

# Generated at 2022-06-21 11:56:57.065173
# Unit test for function parse
def test_parse():
    text = parse("""
    This is a docstring
    """)
    assert text.short_description == "This is a docstring"

# Generated at 2022-06-21 11:56:59.555607
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    with pytest.raises(ParseError):
        parse("aaa")
    with pytest.raises(TypeError):
        parse(1)

# Generated at 2022-06-21 11:57:06.766815
# Unit test for function parse
def test_parse():
    # Function - parse
    # Test docstring - "This is my test docstring."
    test = parse("This is my test docstring.")
    expected = Docstring(short_description='This is my test docstring.',
                         long_description='',
                         meta={})
    if test == expected:
        print("Successfully tested function - parse.")
        print("Test docstring - This is my test docstring.")
    else:
        print(str(test))
        print(str(expected))


# Generated at 2022-06-21 11:57:14.093352
# Unit test for function parse
def test_parse():
    text = """\
        This is a summary.
        This continues the summary.

        This is a parameter.
        :param arg1: this is arg1
        :param arg2: this is arg2
        :param arg3: this is arg3

        :returns: Something
        :rtype: str

        This is the end of the docstring."""

    p = parse(text)
    assert p.summary == "This is a summary. This continues the summary."
    assert p.extended_summary == "This is the end of the docstring."
    assert len(p.params) == 3
    assert len(p.returns) == 1
    assert p.returns[0].name == "returns"
    assert p.returns[0].argument == "Something"

# Generated at 2022-06-21 11:57:25.981716
# Unit test for function parse
def test_parse():
    """Test for correct parsing of a docstring."""
    from docstring_parser.docstring import Docstring
    from docstring_parser import parse

    docstring = Docstring(
            summary="This module implements ...",
            description="This module implements ...",
            extra_sections=[
                ("Arguments", "Args:\n    arg: Description"),
                ("Return type", "Returns:\n    Description")
            ]
        )

    test_str = """This module implements ...

This module implements ...

Args:
    arg: Description

Returns:
    Description
    """

    assert docstring == parse(test_str)

# Generated at 2022-06-21 11:57:33.306504
# Unit test for function parse
def test_parse():
    text = 'This is docstring of function.\n\n' \
           'And this is description for internal of function.\n' \
           '   - item5\n' \
           '   - item6\n' \
           '   - item7\n\n' \
           'Arguments:\n' \
           '  int test: test for function\n' \
           'Returns:\n' \
           '  bool: just return True'

# Generated at 2022-06-21 11:57:45.022278
# Unit test for function parse
def test_parse():

    doct = """
    Parse the docstring into its components.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    doct_docstring = parse(doct)
    assert doct_docstring.short_description == "Parse the docstring into its components."
    assert doct_docstring.long_description == ""
    assert doct_docstring.meta["text"].arg_type == "str"
    assert doct_docstring.meta["text"].description == "docstring text to parse"
    assert doct_docstring.meta["style"].arg_type == "docstring_parser.Style"
    assert doct_docstring.meta["style"].description == "docstring style"

# Generated at 2022-06-21 11:57:52.290952
# Unit test for function parse
def test_parse():
    def w1(s):
        class w2(s):
            def w3(s, k):
                def w4(j):
                    def w5(k):
                        def w6(l):
                            def w7(e):
                                return 0
                            return 0
                        return 0
                    return 0
                return 0
            return 0
        return 0
    assert parse.__doc__ == "Parse the docstring into its components.\n\n    :param text: docstring text to parse\n    :param style: docstring style\n    :returns: parsed docstring representation\n    "
    assert w1.__doc__ == False

# Generated at 2022-06-21 11:58:03.653639
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle, GoogleStyle, EpytextStyle
    text = '''\
    This is a really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really long docstring.

    :param a:
        A parameter named "a". It's type is whatever you want it to be.
    :param b: Arbitrary type
    :param c: int
    :param e: Arbitrary type
    :param d: int

    :returns: Arbitrary type
    '''

# Generated at 2022-06-21 11:58:13.033559
# Unit test for function parse
def test_parse():
    # Test for Style.auto
    text = """Parses the docstring into it's components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    d = parse(text)
    assert d.summary == "Parses the docstring into it's components."
    assert d.description == ''
    assert d.style is Style.numpydoc
    assert d.params == {
        'text': {
            'type': None,
            'desc': 'docstring text to parse',
            'name': 'text',
            'default': None
        },
        'style': {
            'type': None,
            'desc': 'docstring style',
            'name': 'style',
            'default': None
        }
    }
   

# Generated at 2022-06-21 11:58:17.550061
# Unit test for function parse
def test_parse():
    """Test parse()."""
    assert parse('test')
    assert parse('test\n')
    assert parse('test', Style.sphinx)
    assert parse('test', Style.google)
    assert parse('test', Style.numpy)
    assert parse('test', Style.auto)
    assert parse('test', None)

# Generated at 2022-06-21 11:58:21.873285
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """This is a test.

    It is a test.

    :param arg1: test arg1
    :param arg2: test arg2
    :returns: test returns
    """
    print(parse(text))
    print(parse(text, Style.google))



# Generated at 2022-06-21 11:58:33.499979
# Unit test for function parse
def test_parse():
    text = """One line summary.
    Extended description.
    Args:
        arg1(int): Description of arg1
        arg2(str): Description of arg2

    Keyword Args:
        kwarg1(str): Description of kwarg1
        kwarg2(str): Description of kwarg2

    Returns:
        bool: Description of return value
    """

    result = parse(text)
    assert result.short_description == 'One line summary.'
    assert result.long_description == 'Extended description.'
    assert result.meta['args'] == ['arg1(int): Description of arg1', 'arg2(str): Description of arg2']

# Generated at 2022-06-21 11:58:36.273723
# Unit test for function parse
def test_parse():
    result = parse('unknow')
    assert result == ('unknow',"null")
    #result = parse('unknow','restructuredtext')
    #assert result == ('unknow','restructuredtext')

# Generated at 2022-06-21 11:58:51.679895
# Unit test for function parse
def test_parse():
    # class Docstring
    def test_docstring():
        docstring = parse('TODO: write a docstring!')
        assert docstring.summary == 'TODO: write a docstring!'
        assert docstring.description == ''
        assert len(docstring.params) == 0
        assert len(docstring.returns) == 0

    def test_docstring():
        docstring = parse("""
        First line.

        More lines.

        Raises:
            ValueError: When it's not a square.
        """)
        assert docstring.summary == 'First line.'
        assert docstring.description == 'More lines.'
        assert len(docstring.params) == 0
        assert len(docstring.raises) == 1
        assert docstring.raises[0].type == 'ValueError'
        assert doc

# Generated at 2022-06-21 11:58:59.862880
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ReturnItem, Param, ExceptionItem

    style = 'numpy'
    text = """
    Test docstring

    Parameters
    ----------
    param1: int
        Description of param1.
    param2: str
        Description of param2.

    Returns
    -------
    int
        Description of return value.
    list
        Description of the return value.

    Raises
    ------
    ValueError
        If `param2` is equal to `param1`.

    See Also
    --------
    other_func1: related function 1
    other_func2: related function 2

    Notes
    -----
    Some notes.

    Examples
    --------
    Here is an example:

        >>> print(param1)
    """
    parse_obj = parse(text, style)
    assert parse_obj

# Generated at 2022-06-21 11:59:09.000341
# Unit test for function parse
def test_parse():
    # DocstringParser is the parser that is used by parse.
    from docstring_parser.parser import DocstringParser
    text = (
        "This function does something.\n"
        "    \n"
        "    :param str name: The name of it.\n"
        "    :param str dtype: Its data type.\n"
        "    :returns: A thing\n"
        "    :raises ValueError: If a value is out of range.\n"
        "    \n"
        "    Examples:\n"
        '        >>> do_thing("a", "b")'
    )
    docstring = parse(text)
    assert docstring.short_description == "This function does something."
    assert docstring.long_description == ""

# Generated at 2022-06-21 11:59:09.731261
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-21 11:59:18.593997
# Unit test for function parse
def test_parse():
    ans = parse('"""haha"""')
    assert ans.short_description == 'haha'
    assert ans.long_description == ''

    ans = parse('"""line1\nline2"""')
    assert ans.short_description == 'line1'
    assert ans.long_description == 'line2'

    ans = parse('"""Line1\nLine2\n\nLine4"""')
    assert ans.short_description == 'Line1'
    assert ans.long_description == 'Line2\n\nLine4'

    ans = parse(""""Line1\nLine2\n\nLine4\n\nArgs:\n    haha: haha""")
    assert ans.short_description == 'Line1'
    assert ans.long_description == 'Line2\n\nLine4'

# Generated at 2022-06-21 11:59:25.580771
# Unit test for function parse
def test_parse():
    text = """
    This is a multimodal VAE.

    :param z_size: output z size
    :param x_size: input x size
    :param y_size: input y size
    :param hidden_size: hidden size
    """
    d = parse(text)
    assert d.short_description == "This is a multimodal VAE."
    assert d.long_description == ""
    assert d.meta['param']['z_size'] == "output z size"
    assert d.meta['param']['x_size'] == "input x size"
    assert d.meta['param']['y_size'] == "input y size"
    assert d.meta['param']['hidden_size'] == "hidden size"
    return

# Generated at 2022-06-21 11:59:32.769595
# Unit test for function parse
def test_parse():
    from .tests import test_parse_docstrings
    test_parse_docstrings(parse)
    ds = '''Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`.
    arg2 : list of str
        Description of `arg2`.

    Returns
    -------
    int
        Description of return value.

    '''
    assert parse(ds).returns == "    Description of return value."

# Generated at 2022-06-21 11:59:42.287853
# Unit test for function parse
def test_parse():
    text = '''\
    Multi-line docstring.

    :param iterable iterable: The iterable.
    :param key: sorting key
    :keyword reverse: sort in reverse
    :type key: function
    :type reverse: boolean
    :returns list: The sorted list.
    :raises ValueError: If any value is not comparable.
    :rtype: list
    '''

    d = parse(text)
    print(d)
    print(f"d.summary: {d.summary}")
    print(f"d.extended_summary: {d.extended_summary}")
    print(f"d.body: {d.body}")
    print(f"d.meta: {d.meta}")

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:51.597523
# Unit test for function parse
def test_parse():
    from .styles.google import Google
    from .styles.numpy import Numpy
    from .styles.pep0257 import PEP257

    assert parse('', Style.pep257) == PEP257('', [], [])
    assert parse('', Style.numpy) == Numpy('', [], [], [])
    assert parse('', Style.google) == Google('', [], [], [])

    assert parse('', Style.auto) == PEP257('', [], [])

    # Invalid style raises error
    wrong_style = {'a': '', 'b': '', 'c': ''}
    try:
        parse('', style=wrong_style)
        assert False
    except ValueError:
        assert True

    # Unit test parse_section

# Generated at 2022-06-21 12:00:00.422493
# Unit test for function parse
def test_parse():
    assert parse("Test docstring")
    assert parse("""
    Test
    docstring
    """)
    assert parse("""
    Test
    docstring""")
    assert parse("""
    Test
    docstring
    """, style=Style.numpy)
    assert parse("""
    Test
    docstring
    """, style=Style.google)
    assert parse("""
    Test
    docstring
    """, style=Style.reST)
    assert parse("""
    Test
    docstring
    """, style=Style.napoleon)

# Generated at 2022-06-21 12:00:13.724812
# Unit test for function parse
def test_parse():
    import pytest
    from docstring_parser.styles import parse_google
    STR_SINGLELINE = 'This is a single line test.'
    STR_MULTILINE = '''This is multi line test.
             This is multi line test.'''
    STR_MULTILINE_WITH_NEWLINE = '''\nThis is multi line test.
             This is multi line test.'''
    STR_EMPTY = ''
    STR_EMPTY_WITH_NEWLINE = '\n'
    
    assert parse(STR_SINGLELINE) == parse_google(STR_SINGLELINE)
    assert parse(STR_MULTILINE) == parse_google(STR_MULTILINE)

# Generated at 2022-06-21 12:00:24.221817
# Unit test for function parse
def test_parse():
    print("Testing function parse")
    text = """
This is a long docstring that can span over several lines

Foo:
  - bar

Baz:
  - qux
  - quux

Quuux:
  - corge
"""
    style = Style.numpy
    docstring = parse(text, style)
    if docstring.short_description != "This is a long docstring that can span over several lines":
        print("ERROR: Incorrect short_description")
    if docstring.long_description != None:
        print("ERROR: Incorrect long_description")
    if docstring.parameters != []:
        print("ERROR: Incorrect parameters")
    if len(docstring.meta) != 3:
        print("ERROR: Incorrect meta length")

# Generated at 2022-06-21 12:00:32.303432
# Unit test for function parse
def test_parse():
    import re
    import sphinx
    import docstring_parser

# Generated at 2022-06-21 12:00:43.839469
# Unit test for function parse
def test_parse():
    text = '''
    This is a module docstring.

    Parameters
    ----------
    a : int
        The first parameter.
    b : str
        The second parameter.

    Returns
    -------
    str
        The greeting.
    '''

# Generated at 2022-06-21 12:00:46.615007
# Unit test for function parse
def test_parse():
    parse_result = parse("""This is a docstring.""")
    assert parse_result.short_description == "This is a docstring."

# Generated at 2022-06-21 12:00:57.244872
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(meta=None, content=[])
    assert parse("  ") == Docstring(meta=None, content=[])
    assert parse("\n\n") == Docstring(meta=None, content=[])
    assert parse("\n") == Docstring(meta=None, content=[])
    assert parse("\n\n\n") == Docstring(meta=None, content=[])
    assert parse("test") == Docstring(meta=None, content=["test"])
    assert parse(" test") == Docstring(meta=None, content=["test"])
    assert parse("test ") == Docstring(meta=None, content=["test"])
    assert parse(" test ") == Docstring(meta=None, content=["test"])

# Generated at 2022-06-21 12:01:08.966590
# Unit test for function parse

# Generated at 2022-06-21 12:01:16.972520
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring
    from docstring_parser.parser import parse
    import os
    dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    text = open(dir+"/tests/data/google/google.txt").read() 
    #text += open(dir+"/tests/data/google/google.txt").read()
    #text += open(dir+"/tests/data/numpy/numpy.txt").read()
    print(parse(text))
    print(GoogleDocstring(text))



# Generated at 2022-06-21 12:01:24.562679
# Unit test for function parse
def test_parse():
    # A docstring with ':param'
    def test_func():
        """
        This is a test function.

        :param a: docstring with ':param'
        :returns: docstring with ':returns'
        """
        pass

    # A docstring without ':param'
    def test_func1():
        """
        This is a test function.

        This is a test function with no ':param'
        :returns: docstring with ':returns'
        """
        pass
    
    assert parse(test_func.__doc__).meta['param'][0].args == 'a'
    assert parse(test_func1.__doc__).meta['param'] == []

# Generated at 2022-06-21 12:01:33.280314
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Some random text") == Docstring()

# Generated at 2022-06-21 12:01:37.047449
# Unit test for function parse
def test_parse():
	print(parse("""
			This is my docstring
		""",Style.numpy
		).short_description)

# Generated at 2022-06-21 12:01:45.224725
# Unit test for function parse
def test_parse():
    text = """This function parses a docstring.

    Parameters
    ----------
    text : str
        Docstring text
    style : Style
        Docstring style

    Returns
    -------
    parsed docstring representation
    """
    d = parse(text)
    assert d.short_description == 'This function parses a docstring.'
    assert d.long_description == ''
    assert d.params['text'].name == 'text'
    assert d.params['text'].type_name == 'str'
    assert d.params['text'].desc == 'Docstring text'
    assert d.params['text'].default_value == ''
    assert d.params['style'].name == 'style'
    assert d.params['style'].type_name == 'Style'

# Generated at 2022-06-21 12:01:50.438849
# Unit test for function parse
def test_parse():
    text ="""This is a module docstring.
            This is a module docstring.
            This is a module docstring."""
    assert hasattr(parse, "__annotations__"), "Should have type annotations."


if __name__ == '__main__':
    import sys
    import pytest
    
    pytest.main(sys.argv)

# Generated at 2022-06-21 12:01:53.332724
# Unit test for function parse
def test_parse():
    text = '''
    This is a test for function parse in 
    docstring_parser package.
    '''
    doc = parse(text)
    print(doc.short_description)

# test_parse()

# Generated at 2022-06-21 12:02:00.395964
# Unit test for function parse
def test_parse():
    from pprint import pprint
    from docstring_parser.common import Docstring
    from docstring_parser.styles import Style
    # Define test data
    text='''
     Parameters
    ----------
    a : int
        The first integer to be added.
    b : int
        The second integer to be added.

    Raises
    ------
    TypeError
        If the inputs are not integers.
    '''

# Generated at 2022-06-21 12:02:08.448216
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    from io import StringIO
    import sys
    from unittest import main, TestCase

    from docstring_parser.utils import parse_docstring

    class TestParse(TestCase):
        """Tests for `parse()`."""

        # Units tests for function parse
        def test_parse(self):
            """Test for function parse"""
            output = StringIO()
            saved_stdout = sys.stdout
            try:
                sys.stdout = output
                #
                parse('foo')
            finally:
                sys.stdout = saved_stdout

            output = output.getvalue()
            self.assertTrue(len(output) == 0)
            docs = parse_docstring(parse.__doc__)
            del docs.style, docs.summary
            output = {}
           

# Generated at 2022-06-21 12:02:18.357152
# Unit test for function parse
def test_parse():
    text = ':param path: The path to the file to wrap\n\
    :param file: The file object\n\
    :type file: file object\n\
    :param mode: The mode to open the file object with\n\
    :type mode: str\n\
    :param bufsize: The buffer size to use\n\
    :type bufsize: int'

# Generated at 2022-06-21 12:02:19.525000
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    assert parse("test")

# Generated at 2022-06-21 12:02:31.243924
# Unit test for function parse
def test_parse():

    from docstring_parser import parse as dp
    from docstring_parser.common import Docstring, ParseError

    s1 = """
        PYQUERY CLASS
        This is the documentation for the pyquery class.
        Version 1.0.0

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
    """

    assert dp(s1).version == '1.0.0' 
    assert dp(s1).returns == "parsed docstring representation"
    assert dp(s1).description == "This is the documentation for the pyquery class."

# Generated at 2022-06-21 12:02:35.179902
# Unit test for function parse
def test_parse():
    def f(x):
        "Example function."
        pass
    docstring = parse(f.__doc__)
    print(docstring.short_description)
    print(docstring.long_description)
    for name, value in docstring.fields:
        print(name, ":", value)
    print(docstring.meta)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:47.758590
# Unit test for function parse
def test_parse():
    text = parse('Hello')
    assert text.short_description == 'Hello'
    assert text.long_description == ''
    assert text.returns.type_name == ''
    assert text.returns.description == ''
    text = parse("Hello\nWorld\n")
    assert text.long_description.strip() == 'World'
    text = parse("Hello\n:return: Hello")
    assert text.returns.description == 'Hello'
    text = parse("Hello\n:returns: Hello\n:rtype: str")
    assert text.returns.type_name == 'str'
    assert text.returns.description == 'Hello'
    text = parse("Hello\n:returns str: Hello")
    assert text.returns.type_name == 'str'

# Generated at 2022-06-21 12:02:59.163352
# Unit test for function parse
def test_parse():
    parsestyle1 = parse("""
    converts values from page to pixel coordinates.

    :param list vals: a pair of pixel values, e.g. [x,y]

    :returns: a pair of page coordinates, e.g. [top,left]
    """)
    parsestyle2 = parse("""
    converts values from page to pixel coordinates.

    :param list vals: a pair of pixel values, e.g. [x,y]

    :returns: a pair of page coordinates, e.g. [top,left]
    """, style=Style.numpy)

# Generated at 2022-06-21 12:03:09.583347
# Unit test for function parse
def test_parse():
    from doctest import testmod
    from textwrap import dedent
    from docstring_parser import parse


# Generated at 2022-06-21 12:03:20.322670
# Unit test for function parse
def test_parse():
    text = '''
    Calculates the sum of two numbers.

    :param a: The first number.
    :param b: The second number.
    :returns: The sum of the two numbers.
    '''
    ret = parse(text, style=Style.sphinx)
    assert len(ret.body) == 1, 'Invalid length of ret.body'
    assert ret.body[0] == 'Calculates the sum of two numbers.', 'Invalid value of ret.body'
    assert len(ret.meta) == 3, 'Invalid length of ret.meta'
    assert ret.meta[0].name == 'param', 'Invalid meta[0].name'
    assert ret.meta[0].arguments == 'a: The first number.', 'Invalid meta[0].arguments'

# Generated at 2022-06-21 12:03:30.159817
# Unit test for function parse
def test_parse():
    text = """
    Test function parse.
    :param: Test parameter
    :returns: Test return
    :keyword: Test keyword
    """
    docstring = parse(text)
    assert docstring.short_description == 'Test function parse.'
    assert docstring.long_description == ''
    assert docstring.params[0] == ('param', 'Test parameter')
    assert docstring.returns == ('returns', 'Test return')
    assert docstring.keywords[0] == ('keyword', 'Test keyword')
    assert docstring.meta == {'param', 'returns', 'keyword'}

# Generated at 2022-06-21 12:03:34.092137
# Unit test for function parse
def test_parse():
    text = """
    Parameters
    ----------
    n : integer
        The number of points to plot
    l : integer
        The type of line to use
    m : integer
        The type of marker to use
    """

    style = Style.Numpy
    print(parse(text, style))

# Generated at 2022-06-21 12:03:42.335022
# Unit test for function parse
def test_parse():
    """Unit tests for the parse function."""

    result = parse('''\
    This module defines a function named "func".
    ''')
    assert result.short_description == 'This module defines a function named "func".'

    result = parse('''\
    def func():
        """
        My function description.

        :param x: a parameter
        :type x: int
        """
    ''')
    assert result.long_description == \
            'My function description.'
    assert result.params['x'].description == 'a parameter'



# Generated at 2022-06-21 12:03:54.294493
# Unit test for function parse
def test_parse():
    test_docstring = parse("""A one-line docstring (Google)""")
    assert str(test_docstring) == """A one-line docstring (Google)"""

    test_docstring = parse("""A one-line docstring (Sphinx)""")
    assert str(test_docstring) == """A one-line docstring (Sphinx)"""

    test_docstring = parse(
        """A one-line docstring that spans multiple lines (Google)
        """
    )
    assert str(test_docstring) == """A one-line docstring that spans multiple lines (Google)"""

    test_docstring = parse(
        """A one-line docstring that spans multiple lines (Sphinx)
        """
    )

# Generated at 2022-06-21 12:04:04.396522
# Unit test for function parse
def test_parse():
    #print(parse.__doc__)
    print("Testing ... ")
    print("---------------")

    # Arrange
    # Act
    parsed = parse("""
    def func(x: Any,
             y: Any,
             z: Any = ...) -> None:
        '''This is docstring for func
        
        Args:
            x (Any): this is x
            y (Any): this is y
            z (Optional[Any]): this is z
            
        Returns:
            None
        '''
    """)

    # Assert
    assert parsed.short_description == "This is docstring for func"


# Invoke unit test for function parse
test_parse()

# Generated at 2022-06-21 12:04:05.276144
# Unit test for function parse
def test_parse():
    """Test function parse"""
    from .tests.test_parse import test_parse
    test_parse()

# Generated at 2022-06-21 12:04:14.331506
# Unit test for function parse
def test_parse():
    import logging
    import os
    import re

    import docstring_parser
    docstring_parser_dir = os.path.dirname(docstring_parser.__file__)
    docstring_parser_dir = os.path.join(docstring_parser_dir, 'styles')
    for filename in os.listdir(docstring_parser_dir):
        if not re.match(r'.+\.py$', filename):
            continue
        if filename in ['__init__.py', 'common.py']:
            continue
        logger = logging.getLogger(filename)
        style_name = filename[:-3]
        style = getattr(Style, style_name)
        with open(os.path.join(docstring_parser_dir, filename)) as fp:
            text = fp.read()

# Generated at 2022-06-21 12:04:17.486453
# Unit test for function parse
def test_parse():
    parse(
        '''
            This is the first line
            This is the second line
            '''
        )

# Test for bad input

# Generated at 2022-06-21 12:04:27.258040
# Unit test for function parse
def test_parse():
    style = Style.auto
    # Google
    googledocstring = "This function does something.\n\nArgs:\n  param1: The first parameter.\n  param2: The second parameter.\n\nReturns:\n  The return value. True for success, False otherwise.\n\n"
    assert parse(googledocstring, style) == parse(googledocstring, Style.google)
    # Numpy
    numpydocstring = "Docstring for foo.\n\nParameters\n----------\nbar : int\n    Description of `bar`.\n\nbaz : str\n    Description of `baz`.\n\nReturns\n-------\nbool\n    Description of return value.\n\n"

# Generated at 2022-06-21 12:04:33.601901
# Unit test for function parse
def test_parse():
    """Test the parse function

    :returns: None
    """
    docstring = '''\
    The default implementation raises NotImplementedError.
    '''
    ds = parse(docstring)
    assert ds.summary == 'The default implementation raises NotImplementedError.'
    assert ds.description == ''
    assert ds.params == []
    assert ds.returns == []
    assert ds.raises == []

# Generated at 2022-06-21 12:04:36.850416
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == "Parse the docstring into its components.\n\n    :param text: docstring text to parse\n    :param style: docstring style\n    :returns: parsed docstring representation\n    "

# Generated at 2022-06-21 12:04:41.482808
# Unit test for function parse
def test_parse():
    class DocstringTester(Docstring):
        def __init__(self, meta, description):
            self.meta = meta
            self.description = description
    assert parse("meta description") == DocstringTester(meta={"meta"}, description={"description"})

# Generated at 2022-06-21 12:04:51.613947
# Unit test for function parse
def test_parse():
    text = """
        Function that does stuff.
        """
    result = parse(text)
    assert(result.short_description == 'Function that does stuff.')

    text = """
        Function that does stuff.
        
        This function is a long description.
        """
    result = parse(text)
    expected = """
        Function that does stuff.
        
        This function is a long description.
        """
    assert(result.long_description == expected)

    text = """
        Function that does stuff.
        
        :param a: Int
        :param b: Str
        """
    result = parse(text)
    assert(len(result.meta) == 2)
    assert(len(result.short_description) > 0)
    assert(result.long_description is None)


# Generated at 2022-06-21 12:05:02.974829
# Unit test for function parse
def test_parse():
    text = '''\
    Args:
        arg1 : str
              This is the first argument. It is mandatory
              and should be a string.
        arg2 (str):
            This is the second argument. It is optional and
            should be a string.
    Keyword Args:
        arg3 (str):
            This is the third argument. It is optional and
            should be a string.'''

    docstring = parse(text, style=Style.numpy)
    assert docstring.args[0].name == 'arg1'
    assert docstring.args[0].type_name == 'str'
    assert docstring.args[0].description == 'This is the first argument. It is mandatory and should be a string.'
    assert docstring.args[0].default == None
    assert docstring.args[0].optional == False