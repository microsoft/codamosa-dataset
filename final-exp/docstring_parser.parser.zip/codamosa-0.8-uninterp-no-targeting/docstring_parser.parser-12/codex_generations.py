

# Generated at 2022-06-21 11:55:16.874420
# Unit test for function parse
def test_parse():
    # Example docstring
    text = """
    This is a summary.

    This is a description.

    :param str example_param: example parameter
        with a long description
        that is several lines long

    :returns: example return type
        with a long description
        that is several lines long

    :rtype: str
    """
    # Parse the docstring
    doc = parse(text)

    # Print a summary report of the docstring
    print(repr(doc))

# Generated at 2022-06-21 11:55:26.499098
# Unit test for function parse
def test_parse():
    text = '''Summary line.

Description of what the function does.

:param arg1: The first argument.
:param arg2: The second argument.
:returns: The return value.
:raises keyError: The exception description.
'''
    docstring = parse(text)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == 'Description of what the function does.'
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].description == 'The first argument.'
    assert docstring.params[1].arg_name == 'arg2'
    assert docstring.params[1].description == 'The second argument.'
    assert docstring.return_type.description == 'The return value.'

# Generated at 2022-06-21 11:55:36.911323
# Unit test for function parse
def test_parse():
    # test: pass the docstring string, return Docstring
    style = Style.GOOGLE
    text = """Single-line docstring.
        Args:
            first: The first answer.
            second: The second answer.

        """
    assert type(parse(text, style)) == Docstring 
    # test: no docstring or docstring format error
    text = """Single-line docstring.
            Args:
                first: The first answer.
                second: The second answer.

        """
    try:
        parse(text, style)
    except ParseError:
        pass

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:40.063268
# Unit test for function parse
def test_parse():
    test_cases = [
        ("test\n---\n\ntest", "Numpy", "",
         {"header": "test", "body": "test"}),
        ("test\n---\n\ntest", "Google", "",
         {"params": [], "returns": [], "header": "test", "body": "test"}),
    ]    
    for case in test_cases:
        docstring = parse(case[0], case[1])
        assert docstring.meta == case[3]

# Generated at 2022-06-21 11:55:45.667525
# Unit test for function parse
def test_parse():
    assert parse("one: two") == Docstring(
        title="", description="", meta=[("one", "two")]
    )
    assert parse("one: two\n\nthree") == Docstring(
        title="",
        description="three",
        meta=[("one", "two")],
        examples=[],
    )

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:55:48.374940
# Unit test for function parse
def test_parse():
    from test_parse_test import test_parse_test as tpt
    tpt()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:54.061609
# Unit test for function parse
def test_parse():
    d = parse("""Summary line.

Extended description.

:param str param1: The first parameter.
:param int param2: The second parameter.
:returns: Description of return value.
:raises ExceptionType: Possible exception.

""")
    print("=" * 10, d)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:02.803303
# Unit test for function parse
def test_parse():
    from docstring_parser.parser import parse
    from docstring_parser.models import Param, Return
    docstring = '''\
        Parameters
        ----------
        a: int
            aaa
        b: float
            bbb
        Returns
        -------
        res: int
            result value
    '''
    d = parse(docstring)
    assert d.params == [
        Param(arg='a', type_name='int', desc='aaa'),
        Param(arg='b', type_name='float', desc='bbb'),
    ]
    assert d.returns == [
        Return(arg='res', type_name='int', desc='result value'),
    ]

# Generated at 2022-06-21 11:56:06.501006
# Unit test for function parse
def test_parse():
    assert parse("""
    test
    """)
    assert parse("""
    test
    """, Style.google)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:56:17.276321
# Unit test for function parse
def test_parse():
    docstring_1 = """Single-line docstring.
    """
    docstring_2 = """Single-line docstring.

    Extended description.
    """
    docstring_3 = """Single-line docstring.

    Args:
        arg1: The first argument.
    """
    docstring_4 = """Single-line docstring.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value.
    """
    docstring_5 = """Single-line docstring.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value.

    Raises:
        AttributeError, KeyError
    """

# Generated at 2022-06-21 11:56:25.829919
# Unit test for function parse
def test_parse():
    docstring = parse(text="""
    This is a summary
    Hello world

    this is a longer description
    """)
    assert docstring.summary == "This is a summary"
    assert docstring.description == "this is a longer description"


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:36.859736
# Unit test for function parse
def test_parse():
    print(parse('''
    Example function with types documented in the docstring.

    :param int x: The meaning of x
    :returns: int
    '''))

    print(parse('''
    This function does one thing.

    :raises ValueError: If any value is too big
    :type x: float
    :param x: Description of x
    :returns: Description of return value
    :rtype: float
    '''))

    print(parse('\n'))

    print(parse('''
    This function does one thing.

    Args:
        x (int): Description of x
    '''))

    print(parse('''
    This function does one thing.

    Args:
        x (int): Description of x
        y (int): Description of y
    '''))

# Generated at 2022-06-21 11:56:47.688157
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyDocstring
    from docstring_parser.styles import GoogleDocstring
    from docstring_parser.styles import RestructuredTextDocstring
        
    text = '''This is a line of text.
    This is another line of text.'''
    docstring = NumpyDocstring(text)
    docstring = GoogleDocstring(text)
    docstring = RestructuredTextDocstring(text)
    assert docstring

    text = '''
        This is a line of text.
        '''

    docstring = NumpyDocstring(text)
    docstring = GoogleDocstring(text)
    docstring = RestructuredTextDocstring(text)
    assert docstring

    text = '  This is a line of text.'
    docstring = NumpyDocstring(text)
    docstring

# Generated at 2022-06-21 11:56:55.989803
# Unit test for function parse
def test_parse():
    assert parse('a') == {'body': 'a', 'meta': '', 'fields': []}
    assert parse('a\nb') == {'body': 'a\nb', 'meta': '', 'fields': []}
    assert parse('a\n\nb') == {'body': 'a\n\nb', 'meta': '', 'fields': []}
    assert parse('a\n\n\nb') == {'body': 'a\n\n\nb', 'meta': '', 'fields': []}


# Generated at 2022-06-21 11:57:00.010806
# Unit test for function parse
def test_parse():
    text = '''
This function does something.
:return: nothing
'''
    docstring = parse(text)
    assert(docstring.short_description == 'This function does something.')
    assert(docstring.long_description == '')
    assert(docstring.meta['return'] == ['nothing'])

# Generated at 2022-06-21 11:57:10.376380
# Unit test for function parse
def test_parse():
    docstring = """
    Summary line.

    Extended description.
    """
    doc = parse(docstring)
    assert doc.short_description == "Summary line."
    assert doc.long_description == "Extended description."

    docstring = """Summary line.

    :param arg1: Description of arg1
    :type arg1: str
    :param arg2: Description of arg2
    :type arg2: int, optional
    :returns: Description of return value
    :returns: str

    Extended description.
    """
    doc = parse(docstring)
    arg1 = doc.params[0]
    assert arg1.arg_name == "arg1"
    assert arg1.arg_type == "str"
    assert arg1.description == "Description of arg1"

# Generated at 2022-06-21 11:57:20.920832
# Unit test for function parse
def test_parse():
    docstring_text = '''Solves the optimization problem with
        :param xt: sample means from CPCA
        :param yt: sample means from PCA
        :param xtt: eigenvalues of sample covariance matrix from CPCA
        :param ytt: eigenvalues of sample covariance matrix from PCA
        :param u: the ratio of the two variance of the two variables
        :returns:
            cpcacoef: the optimal coefficients
    '''
    parsed = parse(docstring_text)
    assert len(parsed.meta) == 3
    assert len(parsed.params) == 5


# Generated at 2022-06-21 11:57:30.318645
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Style, GoogleDocstring

    text = """
    Short summary.

    Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value

    """
    result = parse(text, Style.google)
    assert isinstance(result, GoogleDocstring)
    assert result.short_description == 'Short summary.'
    assert result.long_description == 'Extended description.'
    assert result.params[0].arg_name == 'arg1'
    assert result.params[0].type_name == 'int'
    assert result.params[0].description == 'Description of arg1'
    assert result.params[1].arg_name == 'arg2'
    assert result.params[1].type

# Generated at 2022-06-21 11:57:41.299811
# Unit test for function parse
def test_parse():
    text = '''
    Some heading.
    --------------
    Some summary.

    Some extra text.

    :returns: something
    :rtype: int
    '''
    docstring = parse(text)
    assert docstring.summary == 'Some summary.'
    assert docstring.extended_summary == ['Some extra text.']
    assert docstring.params == []
    assert docstring.returns == 'something'
    assert docstring.return_type == 'int'
    assert docstring.meta == {
        'returns': (2, ':returns: something'),
        'rtype': (3, ':rtype: int')
    }
    assert docstring.raw == text


# Generated at 2022-06-21 11:57:51.468759
# Unit test for function parse
def test_parse():
    assert parse('').summary == ''
    assert parse('      ').summary == ''
    assert parse('\n').summary == ''
    assert parse('\n\n').summary == ''
    assert parse('short description\n').summary == 'short description'
    assert parse('short description\n\n').summary == 'short description'
    assert parse('short description\nlong description\n').summary == 'short description'
    assert parse('short description\n\nlong description\n').summary == 'short description'

    assert parse('').description is None
    assert parse('\n').description is None
    assert parse('short description\n').description is None
    assert parse('short description\nlong description\n').description == 'long description'
    assert parse('short description\n\nlong description\n').description == 'long description'

# Generated at 2022-06-21 11:58:07.485487
# Unit test for function parse
def test_parse():
    def f():
        """This function does something.
        :param
        :param foo: first param
        :param baz: second param
        :returns: None
        :raises keyError: raises an exception
        """
        pass
        # Use f.__doc__ as str
        docstring = parse(f.__doc__)
        assert docstring.short_description == 'This function does something.', f.__doc__
        assert len(docstring.long_description) == 0, f.__doc__
        assert len(docstring.params) == 2, f.__doc__
        assert len(docstring.returns) == 1, f.__doc__
        assert len(docstring.raises) == 1, f.__doc__
        assert len(docstring.meta) == 2, f.__doc__

   

# Generated at 2022-06-21 11:58:20.970238
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring(summary="", description="", returns=None)
    assert parse("asdf") == Docstring(summary="asdf", description="", returns=None)
    assert parse("asdf. This is a description.") == Docstring(summary="asdf", description="This is a description.", returns=None)
    assert parse("summary : asdf. This is a description.") == Docstring(summary="asdf", description="This is a description.", returns=None)
    assert parse("summary : asdf. This is a description.\nThis is a multiline description.") == Docstring(summary="asdf", description="This is a description. This is a multiline description.", returns=None)

# Generated at 2022-06-21 11:58:23.290878
# Unit test for function parse
def test_parse():

    test_string = '''
    def func(arg1, arg2):

        '''
    style = Style.numpy

    text = parse(text = test_string, style = style)

    return text

# Generated at 2022-06-21 11:58:32.659580
# Unit test for function parse
def test_parse():
    """Unit test for parse function."""
    from nose.tools import assert_equal
    assert_equal(parse("test"), Docstring(
        summary="test",
        description="",
        extended_summary="",
        parameters=[],
        returns=None,
        other_sections={},
        meta={}
    ))
    assert_equal(parse("test\n\nmore\n"), Docstring(
        summary="test",
        description="more",
        extended_summary="",
        parameters=[],
        returns=None,
        other_sections={},
        meta={}
    ))


# Generated at 2022-06-21 11:58:40.627830
# Unit test for function parse
def test_parse():
    """Test parse function."""
    text = '''
        Example docstring.

        :param int x: Some number.
        :param str y: Some string.
        :returns:
            Example return docstring.
        :raises:
            Example exception.
    '''
    docstring = parse(text)
    assert docstring.short_description == "Example docstring."

    param_x = docstring.params[0]
    assert param_x.arg_name == "x"
    assert param_x.type_name == "int"
    assert param_x.description == "Some number."

    param_y = docstring.params[1]
    assert param_y.arg_name == "y"
    assert param_y.type_name == "str"
    assert param_y.description == "Some string."

# Generated at 2022-06-21 11:58:42.940430
# Unit test for function parse
def test_parse():
    obj = parse(text, style)
    assert obj.__class__ == docstring_parser.common.Docstring

# Generated at 2022-06-21 11:58:54.277672
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    from docstring_parser.common import ParseError
    from docstring_parser.styles import Style

    text = '''\
    One line summary.

    Extended description.

    :param arg1: Description of `arg1`
    :type arg1: str
    :param arg2: Description of `arg2`
    :type arg2: bool
    :param arg3: Description of `arg3`
    :type arg3: int
    :raises ValueError: If arg1 is less than zero
    :returns: Description of what is returned
    :rtype: int
    '''

# Generated at 2022-06-21 11:59:06.146363
# Unit test for function parse
def test_parse():
    class Test1:
        """
        This is a test docstring
        
        """

    class Test2:
        """
        This is a test docstring
        
        Keyword Arguments:
            param1 {str} -- first argument (default: {"test"})
        
        """

    class Test3:
        """
        This is a test docstring
        
        :param param1: first argument
        :type param1: str
        :param param2: second argument
        :type param2: int
        :return: return value
        :rtype: int
        """


# Generated at 2022-06-21 11:59:10.704431
# Unit test for function parse
def test_parse():
    text = '''some text'''
    assert parse(text, style = Style.numpy) == Docstring(summary=text,extended_summary=None,deprecated=False,
                                                         parameters=[],returns=None,raises=None,yields=None,see_also=None,
                                                         meta=None)

# Generated at 2022-06-21 11:59:14.972304
# Unit test for function parse
def test_parse():
    text = '''
        This is a test docstring.

        Args:
            param1: The first parameter.
            param2: The second parameter.

        Returns:
            True if successful, False otherwise.

        '''
    return parse(text)

if __name__ == "__main__":
    print(test_parse())

# Generated at 2022-06-21 11:59:26.222040
# Unit test for function parse
def test_parse():
    text = '''\
    def func(arg1, arg2, arg3):
        """
        This is the summary line

        A longer description
        of the function.

        :param arg1: The first argument.
        :param arg2: The first argument.
        :param arg3: The first argument.
        :returns: Description of return value
        :raises keyError: raises an exception
        """
    '''
    docstring = parse(text)
    assert len(docstring.meta) == 3
    assert len(docstring.content) == 11
    assert len(docstring.params) == 3
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1
    docstring = parse(text, style=Style.numpy)
    assert len(docstring.meta)

# Generated at 2022-06-21 11:59:37.970167
# Unit test for function parse
def test_parse():
    assert parse('This is a docstring\n') == Docstring(
        content='This is a docstring\n',
        description='This is a docstring',
        meta={},
        style=Style.pep257,
        empty=False,
        invalid=False
    )

    assert parse('This is a docstring\n\nAnd this is the description\n') == Docstring(
        content='This is a docstring\n\nAnd this is the description\n',
        description='And this is the description',
        meta={},
        style=Style.pep257,
        empty=False,
        invalid=False
    )


# Generated at 2022-06-21 11:59:47.734889
# Unit test for function parse
def test_parse():
    import docstring_parser
    docstring = docstring_parser.parse('''
Test function
=============

:param arg1: dummy arg1
:type arg1: str
:param arg2: dummy arg2
:type arg2: int


:return: nothing
:rtype: None

:raises KeyError: dummy exception
    ''')

    assert docstring.summary == 'Test function'
    assert docstring.returns is not None
    assert docstring.returns.type == 'None'
    assert docstring.returns.desc == 'nothing'
    assert len(docstring.params) == 2

# Generated at 2022-06-21 11:59:54.172550
# Unit test for function parse
def test_parse():
    """Test docstring_parser.parse with given examples."""


# Generated at 2022-06-21 11:59:56.716335
# Unit test for function parse
def test_parse():
    doc = '''Single line docstring.'''
    doc_out = parse(doc)
    assert doc == doc_out.content


# Generated at 2022-06-21 12:00:01.573251
# Unit test for function parse
def test_parse():
    style = Style.numpy
    text = '''
    Test the foo function
    Test the foo function long
    '''
    doc = parse(text, style)
    assert doc.short_description == 'Test the foo function'
    assert doc.long_description == 'Test the foo function long'


# Generated at 2022-06-21 12:00:12.665073
# Unit test for function parse
def test_parse():
    test_text = '''\
    This function is a function.

    :param p1: a parameter
    :type p1: str
    :returns: the return
    :rtype: int
    '''
    result = parse(text=test_text)
    assert len(result.params) == 1
    assert len(result.returns) == 1
    assert result.content == 'This function is a function.'
    assert result.params[0].arg_name == 'p1'
    assert result.params[0].type_name == 'str'
    assert result.params[0].description == 'a parameter'
    assert result.returns[0].type_name == 'int'
    assert result.returns[0].description == 'the return'
    assert result.throws == []

# Generated at 2022-06-21 12:00:19.434421
# Unit test for function parse
def test_parse():
    import json
    text = '''
    Parameters
    ----------
    arg1:
        Test arg1
        arg1 test
    arg2:
        Test arg2
        arg2 test
    arg3:
        Test arg3
        arg3 test
    Raises
    ------
    OneError
        Error description
    TwoError
        Error description
    ThreeError
        Error description
    Returns
    -------
    Return values
    Return values
    Return value
    '''
    res = parse(text)
    f = open('foo.txt', "w")
    f.write(str(res)+'\n')
    f.write(res.yaml())
    f.close()
    print(res.yaml())


# Generated at 2022-06-21 12:00:23.753634
# Unit test for function parse
def test_parse():
    text = '''\
        This is the module docstring.
        '''
    docstring = parse(text)
    assert docstring.short_description == 'This is the module docstring.\n'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:00:28.681487
# Unit test for function parse
def test_parse():
    text = """Parameters:
    x - this is the first param
    y - this is the second param

Returns:
    This is a description of what is returned
    value of x + y

Raises:
    KeyError - raises an exception"""
    print(parse(text))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:44.202677
# Unit test for function parse
def test_parse():
  global style_data

# Generated at 2022-06-21 12:00:51.801609
# Unit test for function parse
def test_parse():
    text = '''
        This is the example:
        
        Example
        -----
        >>> a = np.array([1,2,3])
        >>> print(a)
        [1,2,3]
        
        Note
        ----
        - No curve
        - No undersampling
        - No regularization

        Description of the `n_components` parameter.

    '''
    print()
    print(parse(text))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:59.846305
# Unit test for function parse
def test_parse():
    comment_line = "Parse the docstring into its components."
    assert comment_line in str(parse.__doc__)
    func_docstring = """Conv2D(filters, kernel_size, strides=(1, 1), padding='valid', data_format=None, dilation_rate=(1, 1), activation=None, use_bias=True, kernel_initializer='glorot_uniform', bias_initializer='zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)"""
    assert func_docstring in parse(str(Conv2D.__doc__))

# Generated at 2022-06-21 12:01:10.709275
# Unit test for function parse
def test_parse():
    docstring = """
    This method does something.

    :param str a: Does something for string a
    :param int b: Does something for integer b
    :param str c: Does something for string c
    :returns: The return value
    :raises Exception: If something bad happens
    :param str d: Does something for string d
    :type d: str
    :keyword str e: Does something for string e
    :key type e: str
    :returns: The return value
    :rtype: int
    """
    docstring = docstring.strip()
    parsed = parse(docstring)
    assert parsed.short_description == "This method does something."
    assert parsed.long_description == ''
    assert len(parsed.params) == 5

# Generated at 2022-06-21 12:01:16.973088
# Unit test for function parse
def test_parse():
    text = """
        Summary line here.

        Extended description of function.

        Parameters
        ----------
        arg1 : int
            Description of arg1
        arg2 : str
            Description of arg2

        Returns
        -------
        str
            Description of return value

        Raises
        ------
        ValueError
            If `arg2` is equal to `arg1`.
        """

    parsed_obj = parse(text)
    print(parsed_obj)


# Generated at 2022-06-21 12:01:25.229114
# Unit test for function parse
def test_parse():
    from docstring_parser.tests import sample
    ds = parse(sample)
    assert ds.short_description == 'Sample docstring\n'

# Generated at 2022-06-21 12:01:28.209424
# Unit test for function parse

# Generated at 2022-06-21 12:01:35.349934
# Unit test for function parse
def test_parse():
    text = """
    This function returns nothing.

    Args:
      x (int): The first number
      y (int): The second number

    Returns:
      None
    """

    result = parse(text)

    assert result.short_description == "This function returns nothing."
    assert result.long_description == result.short_description
    assert len(result.params) == 2
    assert len(result.returns) == 1
    assert result.returns[0].type_name == "None"
    assert result.returns[0].description == ""

# Generated at 2022-06-21 12:01:44.126361
# Unit test for function parse
def test_parse():
    """Test for parse()"""
    docstring_text = \
    """
    First line
    Second line
    Third line

    :param foo: The foo parameter
    :param bar: The bar parameter
    :returns: Nothing
    :rtype: None
    """
    p = parse(docstring_text)
    assert p.short_description == 'First line'
    assert p.long_description == 'Second line Third line'
    assert p.meta['param']['foo'] == 'The foo parameter'
    assert p.meta['param']['bar'] == 'The bar parameter'
    assert p.meta['returns'] == 'Nothing'
    assert p.meta['rtype'] == 'None'


# Generated at 2022-06-21 12:01:46.269485
# Unit test for function parse
def test_parse():
    docstring = """Argument description.
    """

    expected = ("Argument description.", None)
    result = parse(docstring)
    assert result.arguments[0] == expected

# Generated at 2022-06-21 12:01:53.245882
# Unit test for function parse
def test_parse():
    text = """A short description of what this function does.
    
    More details.
    """
    ds = parse(text)
    assert ds.short_description == "A short description of what this function does."

# Generated at 2022-06-21 12:02:00.349294
# Unit test for function parse
def test_parse():
    test_doc = parse("""A test module.
    :param first: The first parameter.
    :type first: int
    :param second: The second parameter.
    :param third: The third parameter.
    :return: None
    :rtype: NoneType
    """)
    assert test_doc.short_description == "A test module."
    assert test_doc.long_description == ""
    assert test_doc.params[0].arg_name == "first"
    assert test_doc.params[0].description == "The first parameter."
    assert test_doc.params[0].type_name == "int"
    assert test_doc.params[1].arg_name == "second"
    assert test_doc.params[1].description == "The second parameter."
    assert test_doc.params[1].type_name

# Generated at 2022-06-21 12:02:08.395380
# Unit test for function parse
def test_parse():
    text = """Single line summary.

    Extended description.

    :param int num1: the first number
    :param num2: the second number
    :returns: num1 / num2
    """

    expected = parse(text, style=Style.google)

    assert expected.short_description == "Single line summary."
    assert expected.long_description == "Extended description."
    assert len(expected.params) == 2
    assert expected.params[0].arg_name == "num1"
    assert expected.params[0].param_type == "int"
    assert expected.params[0].description == "the first number"
    assert expected.params[1].arg_name == "num2"
    assert expected.params[1].param_type is None
    assert expected.params[1].description == "the second number"
   

# Generated at 2022-06-21 12:02:18.358029
# Unit test for function parse
def test_parse():
    from .styles import NUMPY
    s = """
    This function does something.
    
    This function can do multiple things.
    
    Parameters
    ----------
    arg1 : int
        This describes `arg1`.
    arg2 : str
        This describes `arg2`.
    
    Returns
    -------
    bool
        This describes `return`.
    """
    d = parse(s, style=Style.numpy)
    assert d.meta == NUMPY.parse(s).meta
    assert isinstance(d.meta, dict)
    assert d.summary == "This function does something."
    assert d.extended_summary == "This function can do multiple things."
    assert d.params["arg1"].type == "int"

# Generated at 2022-06-21 12:02:28.467161
# Unit test for function parse
def test_parse():
    text = """This is a summary.

    Some more description...

    :param arg: description
    :param arg2: description2
    :type arg2: something
    :returns: description
    :raises Exception: description
    """

    assert parse(text) == Docstring(description=["This is a summary.", "Some more description..."],
        summary="This is a summary.", args=[{"name": "arg", "type": "", "desc": ""},
        {"name": "arg2", "type": "something", "desc": "description2"}],
        returns={"type": "", "desc": ""}, raises=[{"type": "Exception", "desc": "description"}])


# Generated at 2022-06-21 12:02:37.847917
# Unit test for function parse
def test_parse():
    test_docstring_with_style = parse(
        text="""
        Test

        :param arg1: the first argument
        :param arg2: the second argument
        :arg arg3: the third argument
        :arg arg4: the fourth argument
        """, style=Style.numpy
    )

    test_docstring_autodetect = parse(
        text="""
        Test

        :param arg1: the first argument
        :param arg2: the second argument
        :arg arg3: the third argument
        :arg arg4: the fourth argument
        """
    )


# Generated at 2022-06-21 12:02:47.089687
# Unit test for function parse
def test_parse():
    text = """\
        This is a test docstring.

        :param a: First parameter
        :type a: bool
        :param b: Second parameter
        :type b: int
        :param c: Third parameter
        :type c: str
        :returns: Something
        :rtype: bool
        """
    assert parse(text) == Docstring(
        content = 'This is a test docstring.',
        meta = {
            'a': 'First parameter',
            'b': 'Second parameter',
            'c': 'Third parameter',
        },
        returns = 'Something',
        returntype = 'bool',
    )


# Generated at 2022-06-21 12:02:58.215082
# Unit test for function parse
def test_parse():
    result = parse("""hello world""", style = Style.google)
    assert result.summary == "hello world"
    result = parse("""hello world""", style = Style.sphinx)
    assert result.summary == "hello world"
    result = parse("""hello world""", style = Style.numpy)
    assert result.summary == "hello world"
    result = parse("""hello world""", style = Style.auto)
    assert result.summary == "hello world"
    try:
        result = parse("""hello world""", style = Style.auto_rst)
    except Exception as e:
        assert type(e) == ParseError
    # result = parse("""hello world""", style = Style.auto_rst)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:03:08.966545
# Unit test for function parse

# Generated at 2022-06-21 12:03:19.796135
# Unit test for function parse
def test_parse():
    text = '''
    A method for testing.

    Parameters
    ----------
    arg1 : int
        An argument.
    arg2 : float, optional
        Another argument.
    arg2 : int, optional
        Another argument.

        .. note::
            This is a note.

        .. warning::
            This is a warning.

    Returns
    -------
    int
        The sum of `arg1` and `arg2`.
    '''
    parsed_docstring = parse(text)

    assert parsed_docstring.short_description == 'A method for testing.'
    assert parsed_docstring.long_description == ''
    assert parsed_docstring.params['arg1'].arg_type == 'int'
    assert parsed_docstring.params['arg1'].description == 'An argument.'
    assert parsed_docstring.params

# Generated at 2022-06-21 12:03:29.005317
# Unit test for function parse
def test_parse():
    r = parse("Test\n:param w: int\n :type w: int")
    assert r.short_description == "Test"
    assert r.params[0].arg_name == "w"
    assert r.params[0].type_name == "int"


__all__ = ('parse',)

# Generated at 2022-06-21 12:03:35.916285
# Unit test for function parse
def test_parse():
    text = """Summary line.

This is a longer description. It can contain multiple lines.

Attributes:
    attr1 (int): First attribute.
    attr2 (str): Second attribute.

Returns:
    bool: Description of return value.

Raises:
    ValueError: If `param` is equal to `"bad"`.
"""


# Generated at 2022-06-21 12:03:45.934252
# Unit test for function parse
def test_parse():
    d = parse("""Sums two numbers together.
 
    :param: num1 (int): The first number.
    :param: num2 (int): The second number.
    :returns: The sum of the two numbers.
    :raises: ValueError: If num1 is less than zero.
    :raises: TypeError: If num2 is not an integer.
    
    """
    )
    assert len(d.meta) == 3
    assert d.meta[1]['name'] == 'num1'
    assert d.meta[1]['type'] == 'int'
    assert d.meta[1]['description'] == 'The first number.'


# Generated at 2022-06-21 12:03:49.489136
# Unit test for function parse
def test_parse():
    import doctest
    (failure_count, test_count) = doctest.testmod()
    assert failure_count == 0

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:04:00.293820
# Unit test for function parse
def test_parse():
    docstring = parse(
        """\
    Blabla.
    :param a: Bla
    :type a: str
    :param b: Blabla
        Blabla bla
        bla bla.
    :type b: int
    :param c: Bla
    :type c: float
    :returns: Bla
        Bla.
    :rtype: str
    :raises RuntimeError: Blabla
        Blabla
    """
    )
    print(docstring.meta)

# Generated at 2022-06-21 12:04:04.912573
# Unit test for function parse
def test_parse():
    assert (parse("hello World!") ==
            Docstring(
                short_description="hello World!",
                long_description="",
                meta=[],
                attributes=[],
                examples=[],
                see_alsos=[]))

# Generated at 2022-06-21 12:04:13.399443
# Unit test for function parse
def test_parse():
    # Test parse function
    text = """\
This is the docstring
======================

:param text: docstring text to parse
:param style: docstring style
:returns: parsed docstring representation
:raises ImportError: if no parser class matching ``style`` is found
"""

    assert parse(text, style = Style.numpy).meta == {
        'param': [
            ('text', 'docstring text to parse'),
            ('style', 'docstring style')
        ],
        'returns': [('', 'parsed docstring representation')],
        'raises': [('ImportError', 'if no parser class matching ``style`` is found')]
    }

# Generated at 2022-06-21 12:04:18.202808
# Unit test for function parse
def test_parse():
    text = '''A random library.

A random library, do random stuff.

:param x: how much random
:returns: None'''
    assert parse(text).meta['param'] == [{'x': 'how much random'}]

test_parse()

# Generated at 2022-06-21 12:04:27.768536
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import Style
    from docstring_parser.styles.google.parser import Google

    test_docstring_1 = parse("""
    Args:
        _: Define a vector for an arbitrary vector x. This vector is the
           mean for each dimension of x.
    Returns:
        _: The mean of x.
    """)

# Generated at 2022-06-21 12:04:28.598442
# Unit test for function parse

# Generated at 2022-06-21 12:04:34.075542
# Unit test for function parse
def test_parse():
    text = """
    One line summary.

    Additional details.
    """

    docstring = parse(text)
    assert docstring.short_description == 'One line summary.'
    assert docstring.long_description == 'Additional details.'



# Generated at 2022-06-21 12:04:37.877498
# Unit test for function parse
def test_parse():
    text = """
        Short summary.

        Extended description.

        :param str name: The name to use.
        :param bool state: Current state to be in.
        :returns: Description of return value.
        :rtype: str
        """
    docstring = parse(text)



# Generated at 2022-06-21 12:04:47.032440
# Unit test for function parse
def test_parse():
    doc1 = """Sum two integer numbers together.

:param a: int, a number
:param b: int, another number
:returns: int, the sum of a and b
"""
    doc2 = """Sum two integer numbers together.

:param a: a number
:param b: another number
:raise ValueError: if ``a`` and ``b`` are negative
:returns: the sum of a and b
"""
    import pprint
    pprint.pprint(parse(doc1))
    pprint.pprint(parse(doc2))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:04:51.539874
# Unit test for function parse
def test_parse():
    text = ('Returns\n'
            '   dictionary with word as key and its frequency as value\n')
    actual = parse(text, style=Style.google)
    expected = Docstring(
        summary="Returns dictionary with word as key and its frequency as value",
        description="",
        returns=[],
        args=[],
        raises=[],
        examples=[],
        meta={}
    )
    assert actual == expected


# Generated at 2022-06-21 12:04:56.236004
# Unit test for function parse
def test_parse():

    text = '''
        This function does something.

        :param
        :type
        :returns:
            description
        :rtype: type
        '''

    assert parse(text)['Parameters'][0]['Name'] == 'param'

# Generated at 2022-06-21 12:04:57.037844
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-21 12:04:59.542289
# Unit test for function parse
def test_parse():
    text = '''
    Hello, this is a docstring
    '''
    print(parse(text))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:05:07.054674
# Unit test for function parse
def test_parse():
    text = '''
    """A very short description.

    A very long description.

    :param arg1: what is arg1 needed for?
    :param arg2: what is arg2 needed for?
    :returns: what does the method return?
    :raises keyError: explains which exceptions can be raised
    """
    '''
    from docstring_parser import parse
    print(parse(text))
    print(type(parse(text)))



if __name__ == '__main__':
    test_parse()