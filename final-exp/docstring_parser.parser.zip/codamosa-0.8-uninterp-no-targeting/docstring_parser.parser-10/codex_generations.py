

# Generated at 2022-06-21 11:55:09.391506
# Unit test for function parse
def test_parse():
    docstring = """
    This is the test for docstring-parse.
    This is the test for docstring-parse.
    This is the test for docstring-parse.
    This is the test for docstring-parse.
    """
    assert parse(docstring) == parse(docstring)

# Generated at 2022-06-21 11:55:15.299130
# Unit test for function parse
def test_parse():
    """Test for function 'parse'."""
    text = 'Test for parse.\n'
    doc = parse(text)
    assert text[:21] == doc.short_description, 'parse short description error'
    assert '\n' not in doc.short_description, 'parse short description error'
    assert len(doc.short_description) <= 21, 'parse short description error'



# Generated at 2022-06-21 11:55:23.384347
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import Docstring
    from docstring_parser.metadata import Metadata
    from docstring_parser.sections import Sections

    text = """This is a summary

This is a description.

Parameters:
    param1 (str): This is the first param.
    param2 (int, optional): This is a second param. Defaults to 42.

Returns:
    int: This is a return description.
"""

    docstring = parse(text)
    assert type(docstring) == Docstring
    assert type(docstring.sections) == Sections
    assert type(docstring.metadata) == Metadata

# Generated at 2022-06-21 11:55:25.890206
# Unit test for function parse
def test_parse():
    text = """
    This is a test for parse function
    """
    assert parse(text) == Docstring(summary='This is a test for parse function',
                                    body='\n',
                                    meta={})

# Generated at 2022-06-21 11:55:35.996947
# Unit test for function parse
def test_parse():
    text='''
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    parsed=parse(text)
    assert parsed.meta[0].args=='text'
    assert parsed.meta[0].description=='docstring text to parse'
    assert parsed.meta[0].argspec=='text'
    assert parsed.meta[0].annotation==None
    assert parsed.meta[1].argspec=='style'
    assert parsed.meta[2].argspec=='returns'
    assert parsed.meta[2].description=='parsed docstring representation'

# Generated at 2022-06-21 11:55:46.319801
# Unit test for function parse

# Generated at 2022-06-21 11:55:57.719215
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring.

    Parameters
    ----------
    a : int
        The first parameter.
    b : float
        The second parameter.

    Returns
    -------
    int
        The sum of `a` and `b`.

    Raises
    ------
    ValueError
        Raised if `a` is less than zero.
    """


# Generated at 2022-06-21 11:56:04.131497
# Unit test for function parse
def test_parse():
    text = """A list of colors.

    :param colors: list of colors to display
    :type colors: list[str]
    :return: list of colors
    :rtype: list[str]"""
    doc = parse(text)
    assert len(doc.params) == 1
    param = doc.params[0]
    assert param.arg_name == "colors"
    assert param.type_name == "list[str]"
    assert len(doc.returns) == 1
    ret = doc.returns[0]
    assert ret.type_name == "list[str]"

# Generated at 2022-06-21 11:56:15.231919
# Unit test for function parse
def test_parse():
    assert parse('foo') == Docstring(('', []))
    text = '''foo\n:param apple: this is apple\n:returns: nothing\n'''
    assert parse(text) == Docstring(('foo', [('apple', 'this is apple')], 'nothing'))
    text = '''foo\n:param apple: this is apple\n:returns: nothing\n'''
    assert parse(text, Style.google) == Docstring(('foo', [('apple', 'this is apple')], 'nothing'))
    text = '''foo\n\nArgs:\napple: this is apple\n\nReturns:\nnothing\n'''
    assert parse(text, Style.numpy) == Docstring(('foo', [('apple', 'this is apple')], 'nothing'))


#@pytest.

# Generated at 2022-06-21 11:56:26.342853
# Unit test for function parse
def test_parse():
    doc = parse('''
    docstring: the main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    ''')
    if doc.short_description != "The main parsing routine.":
        return False
    if doc.long_description != '':
        return False
    if len(doc.meta) != 2:
        return False
    if doc.meta[0].arg_name != 'text':
        return False
    if doc.meta[0].arg_type != 'docstring text to parse':
        return False
    if doc.meta[1].arg_name != 'style':
        return False
    if doc.meta[1].arg_type != 'docstring style':
        return False

# Generated at 2022-06-21 11:56:39.956286
# Unit test for function parse
def test_parse():
    import unittest

    def test_matches(text, style):
        parsed = parse(text, style)
        assert text == parsed.raw, "Did not parse itself"

    class TestParse(unittest.TestCase):
        def test_numpy(self):
            test_matches(
                """
            This is a test docstring.

            Parameters
            ----------
            param1 : int
                The first parameter.
            param2
                The second parameter.

            Returns
            -------
            int
                Test return value.

            """
                ,
                Style.numpy,
            )


# Generated at 2022-06-21 11:56:50.753829
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param str param1: The first parameter.
:param int param2: The second parameter.
:returns: Description of return value.
:raises ValueError: Description
    """
    docstring = parse(text)
    print(docstring.short_description)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."
    # Summary and description fields are always strings
    assert isinstance(docstring.short_description, str)
    assert isinstance(docstring.long_description, str)
    assert docstring.params == {
        "param1": "The first parameter.",
        "param2": "The second parameter.",
    }
    assert docstring.returns == "Description of return value."
    assert doc

# Generated at 2022-06-21 11:57:00.058214
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    
    text = r'''
    This is a test docstring.
    :param arg1: this is argument 1
    :param arg2: this is argument 2
    :param arg3: this is argument 3
    :type arg1: int
    :type arg2: str
    :type arg3: list
    :returns: the sum of arg1, arg2 and arg3
    :rtype: something

    '''
    print(text)
    print(parse(text))
    print(parse(text, style="google"))


# Generated at 2022-06-21 11:57:10.416605
# Unit test for function parse
def test_parse():
    # input
    text = """An example docstring.

An example of a docstring that has metadata headers.

:param arg1: The first argument.
:type arg1: str
:param arg2: The second argument.
:type arg2: int
:returns: description of return value
:rtype: bool
:raises keyError: raises an exception
    """
    result = parse(text, style=Style.auto)
    # output
    assert result.short_description == "An example docstring."
    assert result.long_description == "An example of a docstring that has metadata headers."
    assert result.meta['param'][0]['name'] == "arg1"
    assert result.meta['param'][0]['type'] == "str"

# Generated at 2022-06-21 11:57:15.662091
# Unit test for function parse
def test_parse():
    try:
        parse("")
    except:
        assert False
        print('Should not raise the exception')

    # Check if it raises ParserError
    try:
        parse("'''")
    except:
        assert True
        print('It raises an exception')

# Generated at 2022-06-21 11:57:26.886436
# Unit test for function parse
def test_parse():
    from docstring_parser.common import ParseError
    from docstring_parser.styles import GoogleStyle
    import textwrap
    simple = "My function does something simple."
    try:
        docstring = parse(simple)
        assert docstring.short_description == simple
        assert docstring.long_description == ''
        assert docstring.sections == []
    except ParseError as e:
        print("Simple docstring '{0}' raised ParseError {1}.".format(simple, e))
        assert False

    sections = "My function does\n\n    something complex.\n    See the examples."

# Generated at 2022-06-21 11:57:35.501492
# Unit test for function parse
def test_parse():
    text="""
    Parameters
    ----------
    a: int
        a is an int

    Returns
    -------
    a: int
        a is still an int
    """
    style=Style.numpy
    assert (parse(text) == Docstring(
        text=text,
        short_description=None,
        long_description=None,
        meta=[{'name': 'a', 'annotation': 'int', 'type': 'param',
               'desc': 'a is an int'},
              {'name': 'a', 'annotation': 'int', 'type': 'return',
               'desc': 'a is still an int'}],
        style=style))



# Generated at 2022-06-21 11:57:47.482755
# Unit test for function parse
def test_parse():
    text = """
    This is the docstring
    
    Parameters
    ----------
    a : int
        first param
    """
    text2 = """
    This is the docstring
    
    Arguments
    ---------
    a : int
        first param
    """
    text3 = """This is the docstring
    
    Parameters
    ----------
    a : int
        first param
    """
    text4 = """
    This is the docstring
    
    Parameters
    ----------
    a : int
        first param
    """
    text5 = """
    This is the docstring
    
    Args:
        a (int): first param
    """
    text6 = """
    This is the docstring
    
    Args
    ----
    a : int
        first param
    """
   

# Generated at 2022-06-21 11:57:52.685828
# Unit test for function parse
def test_parse():
    func_list = ['func.py', 'func_sphinx.py', 'func_numpy.py', 'func_google.py']
    for func in func_list:
        text = open('tests/' + func, 'r').read()
        doc_string = parse(text, style=Style.auto)
        assert doc_string.content == ['This is a function','Writing to csv','This is another line','And another','And another']

# Generated at 2022-06-21 11:57:55.868247
# Unit test for function parse
def test_parse():
    """Unit test function for function parse"""
    assert parse("") == Docstring(lines=[], summary="", meta=[])
    assert parse("This is a test") == Docstring(lines=[], summary="This is a test", meta=[])


# Generated at 2022-06-21 11:58:03.093368
# Unit test for function parse
def test_parse():
    text = """A module that defines a class, and functions to read a file."""

    assert parse(text).summary == "A module that defines a class, and functions to read a file."

# Generated at 2022-06-21 11:58:09.772161
# Unit test for function parse
def test_parse():
    'Test function parse.'
    print('Testing function parse ... ', end='')

    text = ("""
    title
    -----
    
    this is text
    
    and more text
    """)

    docstring = parse(text)

    assert docstring.title == 'title'
    assert docstring.desc == 'this is text\n\nand more text'

    print('Passed.')

# Test function parse
# test_parse()

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:58:20.739095
# Unit test for function parse
def test_parse():
    #print("\nTesting function parse()\n")
    text = "This is a project for testing docstring parser.\n\n" + \
        "There are some key points to be considered in this project.\n\n" + \
        "The first point is the input text must be a valid docstring.\n\n" + \
        "The second point is the input text must follow one of the styles."
    style = Style.numpy
    doc = parse(text, style)
    print("\nThe parsed result is: \n")
    print(doc)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:58:22.527582
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring
    '''
    ret = parse(docstring)
    print(ret)


# Generated at 2022-06-21 11:58:31.098568
# Unit test for function parse

# Generated at 2022-06-21 11:58:39.686483
# Unit test for function parse
def test_parse():
    docstring = '''This is a module docstring'''
    docstring_meta = parse(docstring)
    assert docstring_meta.short_description == 'This is a module docstring'
    #assert docstring_meta.long_description == ''
    #assert docstring_meta.parameters == []
    #assert docstring_meta.returns == []
    #assert docstring_meta.exceptions == {}
    #assert docstring_meta.author == ''
    #assert docstring_meta.author_email == ''
    #assert docstring_meta.keywords == []
    #assert docstring_meta.notes == ''
    #assert docstring_meta.references == ''
    #assert docstring_meta.copyright == ''
    #assert docstring_meta.credits == ''
    #assert docstring_meta.example

# Generated at 2022-06-21 11:58:51.825089
# Unit test for function parse
def test_parse():
    import pytest
    from docstring_parser.styles import GoogleDocstring
    text = """
        Tests the function parse.

        This is one line of description.

        This is the first paragraph of description.

        Args:
            arg1: This is the description of arg1.
            arg2: This is the description of arg2.
            arg3: This is the description of arg3.
            arg4: This is the description of arg4.

        Returns:
            A boolean.
        """
    docstring = parse(text)
    assert isinstance(docstring, GoogleDocstring)
    assert isinstance(docstring.short_description, str)
    assert docstring.short_description == 'Tests the function parse.'
    assert isinstance(docstring.long_description, str)


# Generated at 2022-06-21 11:58:54.570225
# Unit test for function parse
def test_parse():
    style = Style.google
    parse("nothing")
    parse("nothing", style)
    parse("nothing", style)


# Validate that parsing doesn't fail with any of the predefined styles

# Generated at 2022-06-21 11:58:57.739716
# Unit test for function parse
def test_parse():
    docstring = """
    hello world!
    """
    print(parse(docstring))

test_parse()

# Generated at 2022-06-21 11:58:59.426104
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    import doctest
    doctest.testmod()


# Generated at 2022-06-21 11:59:10.032254
# Unit test for function parse
def test_parse():
    text = """
    This is a pretty normal description.

    param text: it should be parsed correctly
    param style: it should be parsed correctly
    returns: nothing should be parsed
    """

    docstring = parse(text)
    assert docstring.short_description == 'This is a pretty normal description.'
    assert len(docstring.long_description) == 1
    assert docstring.long_description[0] == ''
    assert len(docstring.params) == 2
    p1, p2 = docstring.params
    assert p1['name'] == 'text'
    assert p1['description'] == 'it should be parsed correctly'
    assert p2['name'] == 'style'
    assert p2['description'] == 'it should be parsed correctly'
    assert docstring.returns is None

# Generated at 2022-06-21 11:59:11.395614
# Unit test for function parse
def test_parse():
    # TODO: Implement
    return

# Generated at 2022-06-21 11:59:19.648846
# Unit test for function parse
def test_parse():
    from .parse import parse
    from docstring_parser.common import Docstring, ParseError

    docstring = r'''\
    Title.

    Description.

    Keyword Arguments:
        arg1: arg1 description
        arg2: arg2 description

    Arguments:
        arg1: arg1 description
        arg2: arg2 description

    Returns:
        str: return value description
    '''

    result = parse(docstring, style='google')
    assert result.title == 'Title.'
    assert result.description == 'Description.'
    assert result.arguments == [
        {'name': 'arg1', 'type': None, 'description': 'arg1 description'},
        {'name': 'arg2', 'type': None, 'description': 'arg2 description'}
    ]
    assert result.keyword_

# Generated at 2022-06-21 11:59:25.767565
# Unit test for function parse
def test_parse():
    text = """Summary line.

Extended description.

:param  x: description of x
:type x: int
:param y: description of y
:type y: str, optional
:raises: NameError

Run with ``nosetests -v --nocapture .``
"""
    d = parse(text)
    assert d.short_description == "Summary line."
    assert (
        d.long_description
        == "Extended description.\n"
        + "Run with ``nosetests -v --nocapture .``\n"
    )
    assert d.params == [
        ("x", "description of x", "int"),
        ("y", "description of y", "str, optional"),
    ]
    assert d.returns == ""
    assert d.return_type == ""
   

# Generated at 2022-06-21 11:59:37.546860
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Arg, Meta, Return
    from docstring_parser.styles import Style
    #
    docstring = '''
    This is a description of the function.

    Args:
        arg1 (int): description of arg1
        arg2 (str): description of arg2
    '''
    doc = parse(docstring, Style.numpy)
    assert doc.description == 'This is a description of the function.'
    assert doc.meta == [
        Arg(name='arg1', type_='int', description='description of arg1'),
        Arg(name='arg2', type_='str', description='description of arg2')
    ]
    #

# Generated at 2022-06-21 11:59:43.721917
# Unit test for function parse
def test_parse():
    docstring = '''\
    :param param1: this is a first param
    :type param1: int
    :param param2: this is a second param
    :type param2: str, optional
    :returns: description of return value
    :rtype: int
    '''
    assert parse(docstring) is not None


# Generated at 2022-06-21 11:59:49.871345
# Unit test for function parse
def test_parse():
    if __name__ == '__main__':
        print(__doc__)
        text = '''\
One line summary.

Extended description.
This gets indented.
:param f: first param
:param s: second param
:returns: dict with one key
:raises keyError: raises *Exception* when d has no key k
'''
    print(parse(text))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:56.773568
# Unit test for function parse
def test_parse():
    doc = '''
    test parse.

    :param a: param a
    :type a: int
    :param b: param b
    :type b: int
    :returns: return value

    '''
    d = parse(doc)
    print(d)
    print(d.params)
    print(d.returns)
    print(d.summary)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:04.148098
# Unit test for function parse
def test_parse():
    assert parse(
        'This is a test.'
    ).description == 'This is a test.'

    assert parse(
        ':param foo: bar\n:param baz: qux'
    ).params == {
        'foo': 'bar',
        'baz': 'qux',
    }

    assert parse(
        ':param foo:\n\n  bar\n:param baz:\n\n  qux'
    ).params == {
        'foo': 'bar',
        'baz': 'qux',
    }

# Generated at 2022-06-21 12:00:14.318570
# Unit test for function parse
def test_parse():
    """Test function parse"""
    import os
    import json
    import random
    import docstring_parser

    dir_work = os.path.dirname(os.path.abspath(docstring_parser.__file__))
    dir_test = os.path.join(dir_work, "tests")
    path_docstrings = os.path.join(dir_test, "docstrings.json")
    with open(path_docstrings) as handle:
        docstrings = json.load(handle)
    for docstring in random.choices(docstrings, k=5):
        for style in Style:
            docstring_parser.parse(docstring, style=style)

# Generated at 2022-06-21 12:00:20.465624
# Unit test for function parse
def test_parse():
    assert parse('Hello, world') == Docstring(
        summary='Hello, world',
        description='',
        returns=None,
        raises=None,
        parameters=[],
        examples=[])



# Generated at 2022-06-21 12:00:27.913810
# Unit test for function parse
def test_parse():
    docstring = "Test string multi-line parameter\n" \
                "with two lines\n" \
                "\n" \
                ":param name: Description of parameter\n" \
                ":type name:  type\n" \
                ":param name2: Description of parameter2\n" \
                ":type name2:  type2\n" \
                ":returns: Description of return value\n" \
                ":rtype:  int"
    assert parse(docstring).params

# Generated at 2022-06-21 12:00:31.168858
# Unit test for function parse
def test_parse():
    assert parse(text = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """, style = Style.google)




# Generated at 2022-06-21 12:00:43.355992
# Unit test for function parse
def test_parse():
    text = '''
    Input : test_input: int
        description_input: str
        description_output: str
    Output : test_output: float
            description_output: str
    '''

    parsed_docstring = parse(text)

    # test return docstring class
    assert type(parsed_docstring) == Docstring
    # test input
    assert parsed_docstring.input_args[0].name == 'test_input'
    assert parsed_docstring.input_args[0].type_name == 'int'
    assert parsed_docstring.input_args[0].type_def == 'int'
    assert parsed_docstring.input_args[0].description == 'description_input'
    assert parsed_docstring.input_args[1].name == 'description_input'
    assert parsed_docstring

# Generated at 2022-06-21 12:00:54.968227
# Unit test for function parse

# Generated at 2022-06-21 12:00:59.449309
# Unit test for function parse
def test_parse():
    parse_text = """
    :param int a: parameter A
    :param int b: parameter B
    :param int c: parameter C
    :returns: the sum of a, b and c
    :raises ValueError:
    """
    assert parse(parse_text) == parse(parse_text, style=Style.google)
    assert parse(parse_text) == parse(parse_text, style=Style.numpydoc)

# Generated at 2022-06-21 12:01:08.119574
# Unit test for function parse
def test_parse():
    text = """
        Parameters
        ----------
        a : int
            Parameters for a
        b : float
            Parameters for b
        name : str
            Parameters for name
    """
    ds = parse(text)
    assert ds.long_description == ""
    assert ds.short_description == ""
    assert ds.meta["parameters"] == [
        [
            ("Parameters", ""),
            ("----------", ""),
            ("name", "Parameters for name"),
            ("", ""),
            ("a", "Parameters for a"),
            ("", ""),
            ("b", "Parameters for b"),
        ]
    ]

# Generated at 2022-06-21 12:01:11.899769
# Unit test for function parse
def test_parse():
	try:
		parse("Hello world")
	except ParseError as e:
		print("The function parse works well.\n")
	else:
		print("The function parse does not work well.\n")

# test_parse()

# Generated at 2022-06-21 12:01:21.630411
# Unit test for function parse

# Generated at 2022-06-21 12:01:32.110818
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    :param s: parameter s
    :type s: str
    :param t: parameter t
    :type t: str
    """
    doc = parse(text)

    assert doc.summary == 'This is a test docstring.'
    assert len(doc.meta) == 2
    assert doc.meta.get('s') == 'parameter s'
    assert doc.meta.get('t') == 'parameter t'
    assert len(doc.parsed_meta) == 2
    assert doc.parsed_meta.get('s') == ('parameter s', 'str')
    assert doc.parsed_meta.get('t') == ('parameter t', 'str')
    assert not doc.raises
    assert not doc.warnings

# Generated at 2022-06-21 12:01:44.061086
# Unit test for function parse
def test_parse():
    '''Test for parse()'''

# Generated at 2022-06-21 12:01:52.975555
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import numpy, google, reStructuredText
    assert parse("""Some text""", Style.numpy) == numpy("""Some text""")
    assert parse("""Some text""", Style.google) == google("""Some text""")
    assert parse("""Some text""", Style.rst) == reStructuredText("""Some text""")

    assert parse("""Some text""") == numpy("""Some text""")

    try:
        parse("""Some text""", Style.auto)
        assert False
    except ParseError:
        assert True

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:00.174730
# Unit test for function parse
def test_parse():
    text = '''\
    Summary line.

    Extended description of function.

    Args:
      arg1(str): Description of `arg1`
      arg2(int, optional): Description of `arg2`

    Returns:
      bool: Description of return value

    Raises:
      AttributeError, KeyError

    '''
    r = parse(text)
    assert str(r) == text
    assert r.short_description == 'Summary line.'
    assert r.long_description == 'Extended description of function.'
    assert r.returns.type_name == 'bool'
    assert r.returns.description == 'Description of return value'
    assert len(r.arguments) == 2
    assert r.arguments[0].name == 'arg1'

# Generated at 2022-06-21 12:02:08.498602
# Unit test for function parse
def test_parse():
    functionDocstring = """Hello
:param name: The name to say hello to
:type name: str
:returns: A message saying hello to the specified person
:rtype: str
"""
    assert parse(functionDocstring).long_description == "Hello"
    assert parse(functionDocstring).params['name'].description == "The name to say hello to"
    assert parse(functionDocstring).params['name'].type == "str"
    assert parse(functionDocstring).returns.description == "A message saying hello to the specified person"
    assert parse(functionDocstring).returns.type == "str"
    assert parse(functionDocstring).long_description == "Hello"

# Generated at 2022-06-21 12:02:10.592425
# Unit test for function parse
def test_parse():
    text = """
        This is a docstring
        which is going to be parsed
        by the parser
    """
    docstring = parse(text, style=Style.google)
    assert docstring.summary == 'This is a docstring which is going to be parsed by the parser'
    assert len(docstring.meta) == 0
    assert len(docstring.sections) == 0

# Generated at 2022-06-21 12:02:19.638518
# Unit test for function parse
def test_parse():
    text = """
        :param style: docstring style
        :returns: parsed docstring representation
    """
    annotation = Docstring(
        summary = '',
        description = '',
        meta = [
            {
                "name": 'style',
                "value": 'docstring style',
                "desc": '',
                "type": 'param'
            },
            {
                "name": 'returns',
                "value": 'parsed docstring representation',
                "desc": '',
                "type": 'return'
            }
        ],
        return_type = '',
        exceptions = [],
        see_also = [],
        notes = [],
        examples = []
    )
    result = parse(text)
    assert result.meta[0].name == annotation.meta[0].name
   

# Generated at 2022-06-21 12:02:31.325533
# Unit test for function parse
def test_parse():
    sample_str = '''
    Args:
        a (int): First digit
        b (int): Second digit

    Returns:
        int: The sum of the digits
    '''
    parsed_sample = parse(sample_str)
    assert parsed_sample.short_description == ""
    assert len(parsed_sample.long_description) == 0
    assert len(parsed_sample.params) == 2
    assert len(parsed_sample.returns) == 1
    assert len(parsed_sample.raises) == 0
    assert len(parsed_sample.yields) == 0
    assert len(parsed_sample.meta) == 0
    assert len(parsed_sample.examples) == 0
    assert len(parsed_sample.see_also) == 0


# Generated at 2022-06-21 12:02:32.804712
# Unit test for function parse
def test_parse():
    print(parse(text='''This is a test docstring, will be changed to use arguement parsing soon'''))

# Generated at 2022-06-21 12:02:38.350441
# Unit test for function parse
def test_parse():
    import json

    text = """
    First line
    
    - Parameters:
        - times (int): Description
        - x (int): Description
    """
    d = parse(text)
    print(d)
    print(d.short_description)
    print(d.long_description)
    print(d.sections)
    print(json.dumps(d.meta))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:48.678190
# Unit test for function parse
def test_parse():
    text = """
    Summary line.

    Extended description.

    :param foo: Test 1
    :type foo: str
    :param bar: Test 2
    :type bar: int, optional
    :return: Test 3
    :rtype: bool
    """
    doc = parse(text, style='numpy')
    assert doc.short_description == 'Summary line.'
    assert doc.long_description == 'Extended description.'
    assert doc.tags[0].arg_name == 'foo'
    assert doc.tags[0].arg_type == 'str'
    assert doc.tags[0].description == 'Test 1'
    assert doc.tags[1].arg_name == 'bar'
    assert doc.tags[1].arg_type == 'int, optional'
    assert doc.tags[1].description == 'Test 2'

# Generated at 2022-06-21 12:03:03.062216
# Unit test for function parse
def test_parse():
    
    docstring1 = ""
    docstring2 = '''
    :param path: The path to be validated
    :type path: str
    :returns: True if the path is valid, False otherwise
    :rtype: bool
    
    '''
    
    docstring3 = '''
    This function creates a Poisson distribution.

    Parameters
    ----------
    lambd : float
        Input parameter.
    '''
    
    docstring4 = '''
    Parameters
    ----------
    path : str
        The path to be validated
    Returns
    -------
    bool
        True if the path is valid, False otherwise
    
    '''
    

# Generated at 2022-06-21 12:03:12.103197
# Unit test for function parse
def test_parse():
    text1 = """One line summary

More detailed description.
With multiple paragraphs if necessary.

:param arg1: description of arg1
:param arg2: description of arg2
:returns: description of return value

:raises keyError: raises an exception
:raises ImportError: when something import related fails
:raises TypeError: when type is wrong
"""
    assert parse(text1).short_description == "One line summary"
    assert parse(text1).long_description == "More detailed description.\nWith multiple paragraphs if necessary."
    assert parse(text1).params == [{'arg1': 'description of arg1'}, {'arg2': 'description of arg2'}]
    assert parse(text1).returns == "description of return value"

# Generated at 2022-06-21 12:03:22.573220
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import EpytextStyle
    from textwrap import dedent

    def func(x: int, y: int = 1, *args, **kwargs):
        """Sums two numbers.

        :param x: first number
        :param y: second number; defaults to 1
        :returns: the sum of `x` and `y`
        """
        return x + y

    docstring = parse(func.__doc__)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring, EpytextStyle)
    assert docstring.short_description == 'Sums two numbers.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1

# Generated at 2022-06-21 12:03:27.828824
# Unit test for function parse
def test_parse():
    assert parse("""
    This is a test docstring.
    """).short_description == "This is a test docstring."

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:03:31.565882
# Unit test for function parse
def test_parse():
    text = """This is an example of google docstring style."""
    doc = parse(text, style = Style.google)
    assert(doc.short_description == "This is an example of google docstring style.")


# Generated at 2022-06-21 12:03:38.698615
# Unit test for function parse
def test_parse():
    doc_str1 = '''
    Function to parse docstring
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    doc_str2 = '''
    Function to parse docstring
    :param text: docstring text to parse
    :param style: docstring style
    '''
    assert parse(doc_str1, style=Style.google).returns == 'parsed docstring representation'
    assert parse(doc_str2, style=Style.google) == None

# Generated at 2022-06-21 12:03:50.669609
# Unit test for function parse
def test_parse():
    text = "This is a docstring.\n\n" \
           ":param foo: first parameter\n" \
           ":param bar: second parameter\n" \
           ":returns: return value\n" \
           ":raises Exception: on error\n"

    doc = parse(text, Style.numpy)


# Generated at 2022-06-21 12:04:01.473502
# Unit test for function parse

# Generated at 2022-06-21 12:04:11.800285
# Unit test for function parse
def test_parse():
    """Unit test for function parse
    """
    example_text1 = """
    Single line docstring.
    """

    example_text2 = """
    This is one line docstring.
    Another line of the same docstring.
    """

    example_text3 = """
    Single line indented docstring.
    """

    ds = parse(example_text1)
    assert ds.short_description == 'Single line docstring.'

    ds = parse(example_text2)
    assert ds.short_description == 'This is one line docstring.'
    assert ds.long_description == """Another line of the same docstring."""

    ds = parse(example_text3)
    assert ds.short_description == """Single line indented docstring."""

    return 0


# Generated at 2022-06-21 12:04:23.244761
# Unit test for function parse
def test_parse():

    # No input
    try:
        parse('')
        raise AssertionError
    except Exception as e:
        print(e)

    # Parse error
    try:
        parse('Hello!')
        raise AssertionError
    except ParseError as e:
        print(e)

    # Google
    print(parse('Hello!\n\nArgs:\n    param1: The first parameter.\n    param2: The second parameter.'))

    # Numpy
    print(parse('Hello world!\n\n:param arg1: The first argument.\n:type arg1: str.\n:param arg2: The second argument.\n:type arg2: int.'))

    # epytext

# Generated at 2022-06-21 12:04:39.584355
# Unit test for function parse
def test_parse():
    text = r'''\
    """
    Execute a command and return a tuple (status, output) of the result.

    The arguments are the same as for the Popen constructor.
    """'''
    result = parse(text, Style.sphinx)
    assert result.summary == "Execute a command and return a tuple (status, output) of the result."
    assert result.extended_summary == "The arguments are the same as for the Popen constructor."

    text = r'''\
    """
    The arguments are the same as for the Popen constructor.

    :param args: command to execute
    :type args: str
    """'''
    result = parse(text, Style.sphinx)
    assert result.summary == "The arguments are the same as for the Popen constructor."
    assert len(result.fields)

# Generated at 2022-06-21 12:04:45.466717
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    item = """
        This is docstring summary.
        This is docstring body.

        :param arg1: This is argument 1
        :param arg2: This is argument 2
        :param arg3: This is argument 3
        :returns: This is what is returned
        :raises keyError: This is an exception
    """
    assert parse(item)


# Generated at 2022-06-21 12:04:47.479339
# Unit test for function parse
def test_parse():
    doc_string = \
"""SUMMARY

This will parse a docstring into it's components. 


ARGUMENTS
text -- A Description
style -- Another Description

RETURNS
docstring -- The parsed string

"""
    assert str(parse(doc_string)) == doc_string

# Generated at 2022-06-21 12:04:51.171146
# Unit test for function parse
def test_parse():
    text = '''
:param i: an integer
'''
    assert parse(text).params[0].name == 'param'
    assert parse(text).params[0].args[0] == 'i'
    assert parse(text).params[0].desc == 'an integer'


# Generated at 2022-06-21 12:04:57.581433
# Unit test for function parse
def test_parse():
    text = """
    This is an example.

    :param one: first parameter
    """

    doc = parse(text)
    assert doc.summary == 'This is an example.'
    assert doc.meta['param'][0].name == 'one'

    doc = parse(text, Style.numpy)
    assert doc.summary == 'This is an example.'



# Generated at 2022-06-21 12:05:05.112468
# Unit test for function parse
def test_parse():
        test_docstring = '''"""
   Title:
        A docstring with a single line.


        Params:
            param1:
                desc: Param1 description.
                type: str
            param2:
                desc: Param2 description.
                type: int

        Returns:
            str: The docstring title.

        Raises:
            Exception: Raises an exception.

        """
        '''


# Testing code
if __name__ == "__main__":
    # First, test the parse function
    test_parse()