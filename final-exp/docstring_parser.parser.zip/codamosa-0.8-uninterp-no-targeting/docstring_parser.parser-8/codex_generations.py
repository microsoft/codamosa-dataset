

# Generated at 2022-06-21 11:55:09.920837
# Unit test for function parse
def test_parse():
    from docstring_parser.tests import docstrings
    for text, style, meta, summary, body, returns in docstrings:
        d = parse(text, style)
        assert meta == d.meta
        assert summary == d.summary
        assert body == d.body
        assert returns == d.returns


# Generated at 2022-06-21 11:55:15.219177
# Unit test for function parse
def test_parse():
    t = parse("""String with only one double quote (") inside.""")
    assert t.long_description == """String with only one double quote (\") inside."""


# Generated at 2022-06-21 11:55:22.315958
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Field

    doc = parse(
        """This is a single line docstring.
        :param path: The path to the file to wrap
        :param mode: The mode to use for opening"""
    )

    assert doc.summary == "This is a single line docstring."
    assert doc.meta == {
        "param": Field("param", "path", "The path to the file to wrap"),
        "param": Field("param", "mode", "The mode to use for opening")
    }

# Generated at 2022-06-21 11:55:25.233037
# Unit test for function parse
def test_parse():
    style = Style.numpy
    text = """
    This is a numpy style docstring.
    
    Parameters
    ----------
    1. Some name
    
    2. Some name 2
    """
    parse(text, style)

# Generated at 2022-06-21 11:55:37.295770
# Unit test for function parse
def test_parse():
    print('Testing function parse...', end='')

    from docstring_parser.styles import Google, NumPy, NAPALM

    assert parse('\n') == Docstring()
    assert parse('\nfoo') == Docstring()
    assert parse('\nfoo\n') == Docstring()
    assert parse('\nfoo\n\n') == Docstring()

    assert parse('\nfoo\nbar\n') == Docstring()

    assert parse('\nfoo\n\nbar') == Docstring(short_description='foo\n',
                                              long_description='bar')

    assert parse('\nfoo\nbar\n\nbaz') == Docstring(short_description='foo\n',
                                                   long_description='bar\n\nbaz')


# Generated at 2022-06-21 11:55:47.405756
# Unit test for function parse
def test_parse():
    text = '''
    A short summary of the module.

    :param x: This is a positional argument
    :param y: This is a keyword argument
    :returns: This is what is returned
    :raises keyError: This is a list of exceptions
                                            \t
    This is a longer description.  It can
    even take up multiple lines
    '''

    docstring = parse(text)

    assert str(docstring) == text
    assert docstring.short_description == "A short summary of the module."
    assert (
        docstring.long_description
        == "This is a longer description.  It can\n" + "even take up multiple lines"
    )

# Generated at 2022-06-21 11:55:58.857397
# Unit test for function parse
def test_parse():
    class D(object):
        """Class for testing parse() function.
        
        :param str a: parameter a
        """
        def method(self, a, b=2, c=3):
            """Method for testing parse() function.
            
            :param str a: parameter a
            :param int b: parameter b
            :param int c: parameter c
            :return: None
            """
            pass
    d = D()

    str1 = """Class for testing parse() function.
        
        :param str a: parameter a
        """
    str2 = """Method for testing parse() function.
            
            :param str a: parameter a
            :param int b: parameter b
            :param int c: parameter c
            :return: None
            """

# Generated at 2022-06-21 11:56:06.906732
# Unit test for function parse
def test_parse():
    docstring_parser = parse('Return a list of the indices of all occurrences of substring sub in string s[start:end].')
    expected_meta = {
        'short_description': 'Return a list of the indices of all occurrences of substring sub in string s[start:end].',
        'long_description': '',
        'tags': {}
    }
    assert docstring_parser.meta == expected_meta

# Generated at 2022-06-21 11:56:11.947300
# Unit test for function parse
def test_parse():
    # Function to test parse
    test_text = """
    This is a short description.

    This is a description with a long description.

    Args:
        arg1: This is the first argument.
        arg2: This is a second argument.

    Returns:
        This is a return value.
    """
    assert parse(test_text) == parse(test_text, Style.google)

# Generated at 2022-06-21 11:56:20.951240
# Unit test for function parse
def test_parse():
    #case 1
    text='docstring need to be parsed'
    style= Style.auto()
    assert parse(text, style) == 'docstring'
    #case 2
    text='docstring'
    style= Style.auto()
    assert parse(text, style) == 'docstring'
    #case 3
    text='docstring need to be parsed'
    style= Style.auto()
    assert parse(text, style) == 'docstring'
    #case 4
    text='docstring need to be parsed or not'
    style= Style.auto()
    assert parse(text, style) == 'docstring'

# Generated at 2022-06-21 11:56:29.592202
# Unit test for function parse
def test_parse():

    parser_test = """
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    from pprint import pprint
    pprint(parse(parser_test))


# Test Function

# Generated at 2022-06-21 11:56:39.875280
# Unit test for function parse
def test_parse():
    """This function tests for the parse function
    in the docstring_parser.parser.

    Args:
        None.

    Returns:
        None.

    """

    # This is a sample docstring used for testing the parse function.
    test_parse_docstring = """Summary line.

    Extended description.
    :param arg1: Description of arg1.
    :type arg1: str.
    :param arg2:
        Description of arg2.
        continued.
    :type arg2: int.
    :returns: Description of return value.
    :rtype: int.

    """

    # This is a sample docstring used for testing the parse function.

# Generated at 2022-06-21 11:56:46.392618
# Unit test for function parse
def test_parse():
    """Test function parse"""

    assert parse('"""doc"""') == Docstring(
        content='doc',
        params=[],
        returns=None,
        raises=[],
        meta=[],
    )

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(["-vv", "--tb=short", "--capture=no", __file__]))

# Generated at 2022-06-21 11:56:55.260215
# Unit test for function parse
def test_parse():
    parsed = parse(
        "This is a simple example.\n\n:key:value:key2:value2:\n")
    assert len(parsed.meta) == 2
    assert parsed == Docstring(
        'This is a simple example.',
        [('key', 'value'), ('key2', 'value2')])
    parsed = parse(
        "This is a simple example.\n\n:key:value:key2:value2:")
    assert len(parsed.meta) == 2
    assert parsed == Docstring(
        'This is a simple example.',
        [('key', 'value'), ('key2', 'value2')])
    parsed = parse(
        "This is a simple example.\n:key:value:key2:value2:\n")

# Generated at 2022-06-21 11:56:57.536503
# Unit test for function parse
def test_parse():
    assert parse('').__str__() == ''
    assert parse('hello').__str__() == 'hello'


# Generated at 2022-06-21 11:57:08.228572
# Unit test for function parse
def test_parse():
    docstring = parse("")
    assert(docstring.short_description == "")
    assert(docstring.long_description == "")
    assert(docstring.signature == "")
    assert(docstring.meta == {})
    assert(docstring.arguments == [])
    assert(docstring.returns == None)
    assert(docstring.exceptions == [])
    assert(docstring.warns == None)
    assert(docstring.warnings_section == "")
    assert(docstring.author == None)
    assert(docstring.author_section == "")
    assert(docstring.copyright == None)
    assert(docstring.copyright_section == "")
    assert(docstring.credits == None)
    assert(docstring.credits_section == "")

# Generated at 2022-06-21 11:57:13.316008
# Unit test for function parse
def test_parse():
    doc_to_test = """Short summary.

Rock the mic right.

More description.
"""

    doc_test = parse(doc_to_test, style=Style.sphinx)
    assert doc_test.short_description == "Short summary." and doc_test.description == """Rock the mic right.

More description.
"""

# Generated at 2022-06-21 11:57:25.281663
# Unit test for function parse
def test_parse():
    """Test parse function

      This test executes a specific Python docstring through the parse
      function and checks for expected values.

    """
    style = Style.auto
    text = """
    This is a test docstring.
    :param x: First parameter
    :param y: Second parameter
    :arg x: First parameter
    :arg y: Second parameter
    :kwarg x: First parameter
    :kwarg y: Second parameter
    :return: returns something
    :rtype: int
    :raises TypeError: if x not defined
    """
    assert parse(text) is not None
    try:
        assert parse(text, style=Style.google) is not None
    except ParseError:
        assert False

# Generated at 2022-06-21 11:57:32.990687
# Unit test for function parse
def test_parse():
    from docstring_parser import parse

    assert parse.__doc__ is not None

    text = '''\
    This is a module-level docstring.
    :param str foo: module-level parameter
    '''
    docstring = parse(text)
    assert len(docstring) == 2
    assert docstring.short_description == 'This is a module-level docstring.'
    assert len(docstring.params) == 1
    assert docstring.params['foo'].description == 'module-level parameter'

    text = '''\
    This is another module-level docstring.

    :param str foo: module-level parameter

    This is a module-level docstring for numpydoc-style.
    '''
    docstring = parse(text)
    assert len(docstring) == 3

# Generated at 2022-06-21 11:57:36.861897
# Unit test for function parse
def test_parse():
    text = '''
    :param a: first parameter
    :param b: second parameter
    :return: return value
    :raises ValueError: for invalid values
    '''
    doc = parse(text)
    print(doc)

# Generated at 2022-06-21 11:57:44.838905
# Unit test for function parse
def test_parse():
	text="a test function"
	style=Style.numpy
	result=parse(text,style)
	#print(result)
	result.populate()
	print(result.short_description)

if __name__ == "__main__":
	test_parse()

# Generated at 2022-06-21 11:57:49.204533
# Unit test for function parse
def test_parse():
    
    try:
        assert parse("Returns: 1 - indicates success") is not None
    except:
        assert False
    try:
        assert parse("Return: 1 - indicates success") is None
    except:
        assert True
    try:
        assert parse("Return: 1 - indicates success",Style.google) is not None
    except:
        assert False


# Generated at 2022-06-21 11:57:56.242471
# Unit test for function parse
def test_parse():
    doc = r'''
    This is a simple function.
    
    Args:
        name (str): the name of the person
        
    Returns:
        str: the hello message to the person
    '''
    parsed = parse(doc)
    assert parsed.short_description == 'This is a simple function.'
    assert parsed.long_description == ''
    assert parsed.returns.description == 'the hello message to the person'
    assert parsed.args[0].name == 'name'

    doc = r'''
    This is a simple function.
    :param name: the name of the person
    :return: the hello message to the person
    '''
    parsed = parse(doc, style='google')
    assert parsed.short_description == 'This is a simple function.'
    assert parsed.long_description == ''
   

# Generated at 2022-06-21 11:57:56.814378
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-21 11:58:04.697004
# Unit test for function parse
def test_parse():
    docstring = """\
Module docstring.

:param arg1: the first parameter
:param arg2: the second parameter
"""
    doc = parse(docstring)
    assert doc.short_description == 'Module docstring.'
    assert doc.long_description == ''
    assert len(doc.params) == 2
    assert doc.params['arg1'] == 'the first parameter'
    assert doc.params['arg2'] == 'the second parameter'


# Generated at 2022-06-21 11:58:10.388129
# Unit test for function parse
def test_parse():
  text = '''This is a docstring
  :param x: int
  :param y: int
  :return: int'''
  docstring = parse(text)
  assert docstring.meta['param'] == 'x: int'
  assert docstring.meta['param'] == 'y: int'
  assert docstring.meta['return'] == 'int'
  assert docstring.short_description == 'This is a docstring'
  assert docstring.long_description == ''

# Generated at 2022-06-21 11:58:22.345205
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle, NumpyStyle, SphinxStyle
    text1 = '''\
        One line summary.

        Extended description.

        Args:
            arg1 (str): Description of `arg1`

        Returns:
            bool: Description of return value.\
        '''
    text2 = '''\
        One line summary.
        Args:
            arg1(str): Description of `arg1`
        Returns:
            bool: Description of return value.\
        '''

# Generated at 2022-06-21 11:58:26.019532
# Unit test for function parse
def test_parse():
    # parse function
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    # Unit test for the package
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 11:58:30.798788
# Unit test for function parse
def test_parse():
    docstring = """A very short function.

Parameters
----------
arg1 : int
    the first argument
arg2 : str
    the second argument

Returns
-------
str
    The return value. True for success, False otherwise.
    """
    assert parse(docstring)

# Generated at 2022-06-21 11:58:38.949352
# Unit test for function parse
def test_parse():
    def f():
        """
        Dummy functio
        :param x:
        :param y:
        """
        pass

    str1 = '''
    Dummy functio:
        :param x:
        :param y:
    '''
    str2 = '''
    Dummy functio:
        :param x:
        :param y:
        :return:
    '''
    assert parse(str1).short_description.strip() == 'Dummy functio'
    assert parse(str2).short_description.strip() == 'Dummy functio'
    assert parse(str1) == parse(str2)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:58:45.803281
# Unit test for function parse
def test_parse():
    from docstring_parser.docstring import parse
    docstring = '''This is the signature's docstring.'''
    assert parse(docstring).short_description == "This is the signature's docstring."

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:58:56.684524
# Unit test for function parse
def test_parse():
    def f(text, style, ret):
        try:
            assert parse(text, style) == ret
        except (AssertionError, ParseError) as e:
            print(text, style, '\n', parse(text, style), '\n', ret, '\n', e)
        else:
            print(text, style, 'ok')

    ds = Docstring(meta=None, details='',
        summary='', returns=None, raises=None, params=None)
    f('', Style.google, ds)
    f('', Style.google, ds)
    ds = Docstring(meta=None, details='',
        summary='', returns=None, raises=None, params=None)
    f('', Style.google, ds)

# Generated at 2022-06-21 11:59:07.071745
# Unit test for function parse
def test_parse():
    text = """
    A function that returns a value.

    :param int x: Integer to multiply by 2.
    :return: The result of the multiplication.
    :rtype: int
    """
    docstring = parse(text)
    assert docstring.short_description == "A function that returns a value."
    assert len(docstring.long_description) == 0
    assert len(docstring.params) == 1
    assert docstring.params['x'].arg_type == "int"
    assert docstring.params['x'].description == "Integer to multiply by 2."
    assert len(docstring.returns) == 1
    assert docstring.returns[0].description == "The result of the multiplication."
    assert docstring.returns[0].ret_type == "int"

# Generated at 2022-06-21 11:59:11.537226
# Unit test for function parse
def test_parse():
    text = parse("""
    Feature function
    
    A function that returns the feature given the index.

    Parameters
    ----------
    i : int
        Feature index.
    """
    )
    assert text.short_description == 'Feature function\nA function that returns the feature given the index.'

# Generated at 2022-06-21 11:59:13.949101
# Unit test for function parse
def test_parse():
    text = """Example function with types documented in the docstring"""
    rets = parse(text)
    assert len(rets.meta) == 0, "meta error"


# Generated at 2022-06-21 11:59:23.524092
# Unit test for function parse
def test_parse():
    text = """one line summary

    extended description

    :param arg1: description
    :type arg1: str
    :param arg2: description
    :type arg2: int, optional
    :returns: description
    :rtype: bool
    :raises keyError: raises an exception
    :raises TypeError: does not raise an exception
    """

    docstring = parse(text)
    assert docstring.short_description == 'one line summary'
    assert docstring.long_description == 'extended description'
    assert docstring.returns.type_name == 'bool'
    assert docstring.returns.description == 'description'
    assert docstring.raises[0].type_name == 'keyError'
    assert docstring.raises[0].description == 'raises an exception'



# Generated at 2022-06-21 11:59:29.965330
# Unit test for function parse
def test_parse():
    # Arrange
    text = """This is a test

    Parameters:
    -----------
    first: str
        The first parameter
    second: str
        The second parameter"""
    style = Style.numpy

    # Act
    ret = parse(text, style)

    # Assert
    assert len(ret.params) == 2


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:33.860987
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import ReSTStyle
    assert parse('hello') == ReSTStyle('hello')
    assert parse('hello', Style.reST) == ReSTStyle('hello')
    assert parse('hello', Style.google) == ReSTStyle('hello')

# Generated at 2022-06-21 11:59:42.980888
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring, ParseError, Argument, ReturnValue
    from docstring_parser.styles import STYLES, Style

    string_to_test = '''
    
    
    
    
    
    
    
    
    
    
    
    
    Args:
        for_updating (bool): The flag of updating the list
    Returns:
        A list of :class:`~.Album` objects.
    Raises:
        :class:`~.errors.RequestError`: if status code is not 200.
    '''


# Generated at 2022-06-21 11:59:52.105527
# Unit test for function parse
def test_parse():
    assert parse(text="", style=Style.auto).text == ""
    assert parse(text="meow", style=Style.auto).text == "meow"
    assert parse(text="meow: )", style=Style.google).text == "meow: )"
    assert parse(text="meow: )", style=Style.auto).text == "meow: )"
    assert parse(text="meow", style=Style.google).text == "meow"
    assert parse(text="meow", style=Style.numpy).text == "meow"
    assert parse(text="meow: )", style=Style.numpy).text == "meow"
    assert parse(text="meow", style=Style.numpy).text == "meow"

# Generated at 2022-06-21 12:00:04.829786
# Unit test for function parse
def test_parse():
    import pytest
    doc = """
    this is a test what I wanted to do
    """
    parsed_doc = parse(doc, style=Style.google)
    assert parsed_doc.short_description == 'this is a test what I wanted to do'
    assert parsed_doc.long_description == None
    assert parsed_doc.params == {}
    assert parsed_doc.returns == None
    assert parsed_doc.raises == {}


# Generated at 2022-06-21 12:00:10.626481
# Unit test for function parse
def test_parse():
    doc = "Test DocString"
    assert parse(doc).long_description == doc
    assert parse("").long_description is None

if __name__ == "__main__":
    print("This is a module not intended to be ran stand alone.")
    print("Run docstring_parse_test.py instead.")

# Generated at 2022-06-21 12:00:18.865970
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    # test case 1
    test_data = '''
    Unit test for function parse

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''

# Generated at 2022-06-21 12:00:27.263531
# Unit test for function parse
def test_parse():
    docstring = '''\
    Parameters
    ----------
    alpha : first parameter
    beta : second parameter
    '''

    parsed = parse(docstring)
    
    # Assert that the parameters were properly parsed.
    assert len(parsed.params) == 2

    alpha = parsed.params['alpha']
    assert alpha.arg_name == 'alpha'
    assert alpha.type_name == 'first parameter'

    beta = parsed.params['beta']
    assert beta.arg_name == 'beta'
    assert beta.type_name == 'second parameter'

# Generated at 2022-06-21 12:00:30.002014
# Unit test for function parse
def test_parse():
    """this is a test"""
    text = 'this is a test'
    result = parse(text)
    assert result.short_description == 'this is a test'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:34.760017
# Unit test for function parse
def test_parse():
    class Dummy:
        def __init__(self, param=None):
            """Create a fake object.

            :param param: description of parameter
            """
            pass

    assert parse(Dummy.__init__.__doc__)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:43.033487
# Unit test for function parse
def test_parse():
    """Test parsing a docstring

    Examples:
        >>> test_parse()
        True
    """
    assert parse('Line 1\nLine 2') == Docstring(
        content='Line 1\nLine 2\n',
        meta={},
        sections=[],
        style=Style.google)
    assert parse('Line 1\nLine 2\n', style=Style.numpy) == Docstring(
        content='Line 1\nLine 2\n',
        meta={},
        sections=[],
        style=Style.numpy)


# Generated at 2022-06-21 12:00:50.590403
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle
    docstring = """
        This is a test docstring.

        Args:
            arg_a (int): the first argument
            arg_b (:obj:`list` of :obj:`str`): the second argument

        Returns:
            int: the return value

        Raises:
            KeyError: raises an exception
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring == GoogleStyle(docstring)



# Generated at 2022-06-21 12:00:54.501771
# Unit test for function parse
def test_parse():
    source_text = '''
        this is a sample docstring
        :param bar: param bar
        '''
    ds = parse(source_text)
    assert 'this is a sample docstring' == ds.short_description



# Generated at 2022-06-21 12:00:57.357543
# Unit test for function parse
def test_parse():
    text = '''
    """
    Args:
    Returns:"""
    '''
    docstring = parse(text)
    assert len(docstring.meta) != 0

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:01:10.101271
# Unit test for function parse

# Generated at 2022-06-21 12:01:18.424610
# Unit test for function parse
def test_parse():
    text = """\
Command to add new annotations to dataset. Parameters:
  data_type_name (string): Name of data type
  file_path (string): Path of file to upload
Returns:
  response (string): Response of server
"""

    style = Style.google

    ds = parse(text, style)

    assert ds.short_description.strip() == 'Command to add new annotations to dataset.'
    assert ds.long_description.strip() == ''
    assert len(ds.params) == 2
    assert ds.returns

    ds_text = ds.as_docstring(style)
    assert text == ds_text

# Generated at 2022-06-21 12:01:25.927383
# Unit test for function parse
def test_parse():
    # Test the function parse with string input "text"
    text = '''
    def function_name(param1, param2):
        """Example docstring

        :param param1: The first parameter.
        :type param1: int
        :param param2: The second parameter.
        :type param2: str
        :returns: Description of return value.
        :rtype: bool
        """
    '''
    docstring = parse(text)
    assert docstring.short_description == 'Example docstring'
    assert docstring.long_description == ''
    assert docstring.params[0].arg_name == 'param1'
    assert docstring.params[0].description == 'The first parameter.'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[1].arg_

# Generated at 2022-06-21 12:01:31.510860
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

# Generated at 2022-06-21 12:01:40.361336
# Unit test for function parse
def test_parse():
    text = '''\
    This module provides a function, A, that returns a string.

    Arguments:
        x: A string to return.

    Returns:
        The string ``x``, unmodified.
    '''

    assert parse(text, style=Style.numpy) == Docstring(
        content=['This module provides a function, A, that returns a string.'],
        args=[],
        arg_descs=['x: A string to return.'],
        returns=Docstring.Return('The string ``x``, unmodified.', None),
        raises=[],
        see_also=[],
        notes=[],
        examples=[],
        meta={},
    )

# Generated at 2022-06-21 12:01:43.961813
# Unit test for function parse
def test_parse():
    assert STYLES[Style.pep257]('test') == Docstring(
        short_description='test', long_description='', meta=[],
        content_offset=0)
    assert len(parse('test')) == len(Docstring())
    assert len(parse('test', style=Style.pep257)) == len(Docstring())

# Generated at 2022-06-21 12:01:52.587044
# Unit test for function parse
def test_parse():
    import sys
    import os
    import inspect
    filename = os.path.abspath(sys.argv[0]) #absolute path of the python script
    path = os.path.dirname(filename)
    path = path + "/../docstring_parser"
    sys.path.append(path)
    from styles import STYLES
    from styles import Style
    from common import Docstring, ParseError

    for parse_ in STYLES.values():
        try:
            s = parse_("""
            This is a docstring.
            """)
            assert isinstance(s, Docstring)
        except ParseError:
            assert 0

# Generated at 2022-06-21 12:01:59.987865
# Unit test for function parse
def test_parse():
    ds = parse("""
    A docstring.

    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: Description of return value.
    """)
    assert ds.short_description == 'A docstring.'
    assert ds.long_description == ''
    assert ds.metadata["arg1"] == "The first argument."
    assert ds.metadata["arg2"] == "The second argument."
    assert ds.metadata["returns"] == "Description of return value."

    ds = parse("""
    A docstring.

    Arguments
    ---------
    arg1: The first argument.
    arg2: The second argument.

    Returns
    -------
    Description of return value.
    """)
    assert ds.short_description == 'A docstring.'

# Generated at 2022-06-21 12:02:08.203724
# Unit test for function parse
def test_parse():
    from docstring_parser.common import Docstring
    from docstring_parser.styles import GoogleStyle

    test_text = """A one line summary.

    A description that
    spans multiple lines

    Args:
        first (int): The first value
        second (int, optional): The second value. Defaults to 0.

    Returns:
        int: The sum of the two values
    """
    result = parse(test_text)

# Generated at 2022-06-21 12:02:18.198340
# Unit test for function parse

# Generated at 2022-06-21 12:02:24.961847
# Unit test for function parse
def test_parse():
    text = "* key1: value1\n* key2: value2\n\nbody\n"
    assert parse(text) == Docstring(meta={'key1': 'value1', 'key2': 'value2'}, body='body', style=Style.numpy)
    
test_parse()
 
# Unit Test for class Docstring

# Generated at 2022-06-21 12:02:27.615864
# Unit test for function parse
def test_parse():
    x = """
    This module contains all the wrapper modules of the framework
    """
    assert parse(x) == x

# Generated at 2022-06-21 12:02:28.712300
# Unit test for function parse
def test_parse():
    # TODO
    pass

# Generated at 2022-06-21 12:02:38.028579
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import Google, NumPy
    text = """One-line short summary.

    Extended description.
    Extended description continued.

    Args:
        arg1 (str): Description of arg1.
        arg2 (:obj:`int`, optional): Description of arg2. Defaults to None.

    Returns:
        bool: Description of return value.

    """
    parsed = parse(text)
    assert parsed.short_description == "One-line short summary."
    assert parsed.long_description == "Extended description.\n" \
        "Extended description continued."
    assert parsed.meta["Args"][0].arg_name == "arg1"
    assert parsed.meta["Args"][0].annotation == "str"
    assert parsed.meta["Args"][0].description == "Description of arg1."

# Generated at 2022-06-21 12:02:48.614133
# Unit test for function parse
def test_parse():
    assert parse('a,b,c').args == ['a', 'b', 'c']
    assert parse('a,b=2,*c, **d').kwargs == ['b=2', '*c', '**d']
    assert parse('a,b=2,*c, **d').kwargs.get('b') == '2'
    assert parse('a,b=2,*c, **d').arg_types == [None, None, 'c', 'd']
    assert parse("""
        Round a number to a given precision in decimal digits.
        
        The return value is an integer if ndigits is omitted or None.  Otherwise
        the return value has the same type as the number.  ndigits may be negative.
        """).summary == "Round a number to a given precision in decimal digits."

# Generated at 2022-06-21 12:02:59.458946
# Unit test for function parse
def test_parse():
    import pytest

    TEST_DOCSTRING = """Example docstring.
    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises Exception: An exception.
    :raises ValueError: A value error.
    """

    expected = Docstring(summary="Example docstring.",
        meta={'param': ['The first argument.', 'The second argument.'], 'returns': ['The return value.'], 'raises': ['An exception.', 'A value error.']})

    assert parse(TEST_DOCSTRING) == expected
    assert parse(TEST_DOCSTRING, Style.google) == expected

# Generated at 2022-06-21 12:03:01.886962
# Unit test for function parse
def test_parse():
    style = Style.auto
    assert isinstance(parse(""), Docstring)
    assert isinstance(parse("", style), Docstring)

# Generated at 2022-06-21 12:03:10.716660
# Unit test for function parse
def test_parse():
    """Test for the docstring_parser.parse() function."""
    docstring = """Summary line.

Description: extended description.

Args:
    arg1 (int): Description of `arg1`
    arg2 (str): Description of `arg2`

Returns:
    bool: Description of return value
"""
    assert parse(docstring, style=Style.sphinx) == Docstring(
        summary='Summary line.',
        description='Description: extended description.',
        params=[
            ('arg1', '(int): Description of `arg1`'),
            ('arg2', '(str): Description of `arg2`'),
        ],
        returns='bool: Description of return value',
    )
    return

# Generated at 2022-06-21 12:03:21.552636
# Unit test for function parse
def test_parse():
    assert parse("""
    Docstring with nothing else
    """).summary == 'Docstring with nothing else'
    assert parse("""
    Docstring with nothing else
    """).description is None
    assert not parse("""
    Docstring with nothing else
    """).params
    assert not parse("""
    Docstring with nothing else
    """).raises
    assert not parse("""
    Docstring with nothing else
    """).returns
    assert not parse("""
    Docstring with nothing else
    """).yields
    assert parse("""
    Keyword arguments:
    
    param1 -- Dictionary of parameters
    param2 -- Parameter 2
    param3 -- Parameter 3
    param4 -- Parameter 4
    """).params[0].name == 'param1'

# Generated at 2022-06-21 12:03:34.439177
# Unit test for function parse
def test_parse():
    text = '''
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style

    :returns: parsed docstring representation
    '''
    assert parse(text).__dict__ == {'lines': ['Parse the docstring into its components.'], 'meta': ['text', 'style'], 'returns': ['parsed docstring representation']}
    text = '''
    Parse the docstring into its components..

    :param text: docstring text to parse
    :param style: docstring style

    :returns: parsed docstring representation
    '''

# Generated at 2022-06-21 12:03:47.854471
# Unit test for function parse
def test_parse():
	from docstring_parser.styles import google
	from docstring_parser.styles import numpy
	from docstring_parser.common import Docstring, ParseError
	from docstring_parser.utils import get_style_from_text
	text = '''Longer description.
	
	Args:
		arg1 (int): Description of arg1
		arg2 (str): Description of arg2
	
	Returns:
		bool: Description of return value.
	'''
	assert(parse(text) == google(text))
	text = '''Longer description.
	
	Parameters
	----------
	arg1 : int
		Description of arg1
	arg2 : str
		Description of arg2
	
	Returns
	-------
	bool
		Description of return value.
	'''

# Generated at 2022-06-21 12:03:54.446050
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == 'Parse the docstring into its components.\n\n    :param text: docstring text to parse\n    :param style: docstring style\n    :returns: parsed docstring representation\n    '
    assert parse("", style="auto") == Docstring(summary=None, description=None, extended_summary=[], examples=[], params={}, returns=None, see_also=[], notes=[], references=[], meta=[])

# Generated at 2022-06-21 12:04:05.766915
# Unit test for function parse
def test_parse():
    from .google import parse as parse_google

# Generated at 2022-06-21 12:04:13.915448
# Unit test for function parse
def test_parse():
    text = """function1(param1, param2, param3, \
            param4, param5, param6, param7, ...)

Description of function1

Parameters:
    param1 (:obj:`int`, optional): \
        Description of param1 (Typically set to zero by default)
    param2 (:obj:`bool`): Description of param2
    param3 (:obj:`list`): Description of param3
    param4 (:obj:`int`, optional): \
        Description of param4 (Typically set to zero by default)

Returns:
    :obj:`bool`: Description of returned value

Raises:
    :py:exc:`MyError`: Description of exception
    :py:exc:`Exception`: Description of exception
"""

# Generated at 2022-06-21 12:04:25.276486
# Unit test for function parse
def test_parse():
    text = """
        A function showing how to do addition.

        :param a: first value to add (int/float)
        :param b: second value to add (int/float)
        :returns: the sum of a and b (int/float)
        :raises TypeError: if either a or b is not a number
    """
    d = parse(text)
    assert d.short_description == "A function showing how to do addition."
    assert d.long_description == ""
    assert len(d.params) == 2
    assert d.params["a"].arg_type == "int/float"
    assert d.params["b"].arg_type == "int/float"
    assert d.returns.arg_type == "int/float"
    assert len(d.raises) == 1
    assert d

# Generated at 2022-06-21 12:04:36.017864
# Unit test for function parse
def test_parse():
    """Test Parse function"""

    docstring = """
    Function to do something.

    Args:
        a (int): first argument.
        b (float): second argument.

    Returns:
        int, float: Return a tuple of int and float.
    """

    docstring = parse(docstring)

    assert len(docstring.meta) == 4
    assert docstring.description == "Function to do something."
    assert docstring.short_description == "Function to do something."
    assert docstring.args == [("a", {"type": "int", "desc": "first argument."}), ("b", {"type": "float", "desc": "second argument."})]
    assert docstring.returns == ("int, float", "Return a tuple of int and float.")

# Generated at 2022-06-21 12:04:41.968000
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    d = parse.__doc__ + '\n'
    assert parse(d).short_description == 'Parse the docstring into its components.'
    assert parse(d).long_description == ':param text: docstring text to parse\n:param style: docstring style\n:returns: parsed docstring representation'
    assert parse(d).style == Style.reStructuredText
    assert parse(d).meta['param'] == ['text', 'style']
    assert parse(d).meta['type'] == ['str', 'Style']
    assert parse(d).meta['returns'] == ['Docstring']

# Generated at 2022-06-21 12:04:51.209812
# Unit test for function parse
def test_parse():
    """Test parse function"""
    from docstring_parser.common import Arg, Docstring
    from docstring_parser.styles import GoogleDocstring, NumpyDocstring
    
    # Test for Class GoogleDocstring
    assert(isinstance(parse("", style=Style.google), Docstring))
    assert(isinstance(parse("", style=Style.numpy), Docstring))

    assert(isinstance(parse("", style=Style.google), GoogleDocstring))
    assert(isinstance(parse("", style=Style.numpy), NumpyDocstring))

    assert(isinstance(parse("", style=Style.numpy).args[0], Arg))
    assert(isinstance(parse("", style=Style.google).args[0], Arg))

# Generated at 2022-06-21 12:05:02.696026
# Unit test for function parse
def test_parse():
    doc = parse("""This is an example of a google-style docstring.

    This is the summary line.
    This is the second sentence of the summary.

    This is a description of the function.
    """)

    assert doc.short_description == ("This is the summary line.\n"
        "This is the second sentence of the summary.")
    assert doc.long_description == (
        "This is a description of the function.\n"
        "\n"
        "Args:\n"
        '    arg1 (int): The first argument.\n'
        '    arg2 (str): The second argument.\n'
        "\n"
        "Returns:\n"
        "    bool: The return value. True for success, False otherwise."
    )