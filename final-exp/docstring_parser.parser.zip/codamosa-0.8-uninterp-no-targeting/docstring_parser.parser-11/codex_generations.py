

# Generated at 2022-06-21 11:55:20.944865
# Unit test for function parse
def test_parse():
    docstring = '''\
This is a sample docstring.

This is a meta data section.

:param name: name of the person
:type name: str
:param age: age of the person
:type age: int

:return: dummy name and age
:rtype: tuple

:raises ValueError: raised when types don't match

:example:

>>> person = Person('John Doe', 42)
>>> print(person.name, person.age)
John Doe 42
'''
    style = Style.google
    result = parse(docstring, style)
    print(result)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:28.462475
# Unit test for function parse
def test_parse():
    text1 = '''
    Parameters
    ----------
    arg1 : int
        description
    arg2:
        description2
    arg3 : float
        description3
    arg4 : str
        description4
    '''

    ret = parse(text1)
    expected_ret = {'arg1': ['int', 'description'],
                    'arg2': ['', 'description2'],
                    'arg3': ['float', 'description3'],
                    'arg4': ['str', 'description4']}

    ret_list = list(ret.params)
    assert len(ret_list) == 4
    for item in ret_list:
        assert item.arg_name in list(expected_ret.keys())
        assert item.type_name == expected_ret[item.arg_name][0]
        assert item.description

# Generated at 2022-06-21 11:55:39.471847
# Unit test for function parse
def test_parse():
    docstring = """Summary line here.

    Extended description here.

    Args:
        arg1 (int): Help on arg1
        arg2 (str): Help on arg2
    Kwargs:
        kwarg1 (str): Help on kwarg1
        kwarg2 (str): Help on kwarg2
    Returns:
        int: Return value description
    Raises:
        ValueError: If `division_by_zero` is True.
    """
    d = parse(docstring)
    assert d['Args'] == ['arg1 (int): Help on arg1', 'arg2 (str): Help on arg2']
    assert d['Kwargs'] == ['kwarg1 (str): Help on kwarg1', 'kwarg2 (str): Help on kwarg2']

# Generated at 2022-06-21 11:55:48.879201
# Unit test for function parse
def test_parse():
    # Sample docstring
    text = """One line summary.
    
    Extended description.
    
    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    result=parse(text)
    # One line summary
    assert result.short_description=='One line summary.'
    # Extended description
    assert result.long_description=='Extended description.'
    # :param param1: The first parameter
    assert result.params[0].arg_name==':param param1: The first parameter'
    # :param param2: The second parameter
    assert result.params[1].arg_name==':param param2: The second parameter'
    # :returns: Description of return value

# Generated at 2022-06-21 11:55:59.632891
# Unit test for function parse
def test_parse():
    """Unittest for function parse"""
    print("Test for function parse")
    print("Testing parse")
    # title, params, returns, description
    title, params, returns, description = (
        'Title',
        [{'arg_name': 'param1', 'description': 'Param 1'},
        {'arg_name': 'param2', 'description': 'Param 2'}],
        {'description': 'Return 1'},
        'Description'
    )
    docstring = parse(
        Docstring(
            meta={
                'title': title,
                'params': params,
                'returns': returns,
                'description': description
            }
        ).to_plaintext(),
        Style.google
    )


# Generated at 2022-06-21 11:56:05.657896
# Unit test for function parse
def test_parse():
    """Test method parse"""
    assert parse('hello, world') == Docstring(summary='hello, world')
    assert parse('hello, world', Style.numpy) == Docstring(summary='hello, world')


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:15.751218
# Unit test for function parse
def test_parse():
    text = """\
    Does some stuff.
    And some other stuff.

    :param stuff: some stuff to be done
    :param other: other stuff to be done
    :returns: stuff
    :raises ValueError: if some stuff crashes
    """
    expected = {'signature': '',
    'short_description': 'Does some stuff.\nAnd some other stuff.',
    'long_description': '',
    'extended_description': '',
    'meta': {'param': [('stuff', 'some stuff to be done'), ('other', 'other stuff to be done')], 'return': ['stuff'], 'raises': [('ValueError', 'if some stuff crashes')]}
    }
    assert parse(text) == Docstring(expected)

# Generated at 2022-06-21 11:56:22.095456
# Unit test for function parse
def test_parse():
    text = """
    This is a function.
    
    Arguments:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = parse(text)
    assert len(docstring.args) == 1
    assert len(docstring.returns) == 1

# Generated at 2022-06-21 11:56:23.360045
# Unit test for function parse
def test_parse():
    text = """
Multiline
docstring
that includes
multiple lines.
"""
    ds = parse(text)
    assert str(ds) == text


# Generated at 2022-06-21 11:56:30.903067
# Unit test for function parse
def test_parse():
    test_string = '''
This function does some magical job

:param a: first parameter
:param b: second parameter
:returns: a + b
:raises ValueError: when a is negative
    '''
    test_docstring = parse(test_string)

    assert test_docstring.meta['a'].name == 'a'
    assert test_docstring.meta['b'].name == 'b'
    assert test_docstring.meta['returns'].name == 'returns'
    assert test_docstring.meta['ValueError'].name == 'ValueError'

    assert test_docstring.meta['a'].description == 'first parameter'
    assert test_docstring.meta['b'].description == 'second parameter'

# Generated at 2022-06-21 11:56:43.151324
# Unit test for function parse
def test_parse():
    text = """Summary line.
    Extended description.
    foo
    Parameters
        ----------
        :param a: bla
        :param b: bla bla

    :param a: bla
    :param b: bla bla

    Returns
        -------
        :return: bla bla
        :rtype: int
    :return: bla bla
    :rtype: int"""
    parse(text, style=Style.google)
    assert(parse(text, style=Style.google).name == 'parse')

# Generated at 2022-06-21 11:56:47.047957
# Unit test for function parse
def test_parse():
    text = 'Unit test for function parse'
    text1 = 'This is a test String'
    assert parse(text) == parse(text)
    assert parse(text) != parse(text1)


# Generated at 2022-06-21 11:56:55.656220
# Unit test for function parse
def test_parse():
    text = """
    This is a summary line.

    This is the description. It can span multiple lines.

    :param arg1: The first argument
    :param arg2: The second argument
    :returns: Description of return value
    :raises keyError: raises an exception
    """
    doc = parse(text)
    print(doc.short_description)
    # This is a summary line.
    print(doc.long_description)
    # This is the description. It can span multiple lines.
    print(doc.return_annotation)
    print(doc.meta)
    print(doc.meta['arg1'])
    print(doc.meta['arg2'])
    print(doc.meta['returns'])
    print(doc.meta['keyError'])


# Generated at 2022-06-21 11:57:02.406799
# Unit test for function parse
def test_parse():
    assert parse('''
This is a sample module.

:param a: parameter a
:param b: parameter b
:raises ValueError: raised when a == 0
''') == Docstring(
        summary='This is a sample module.',
        body='',
        meta=[
            ('param', 'a', 'parameter a'),
            ('param', 'b', 'parameter b'),
            ('raises', 'ValueError', 'raised when a == 0'),
        ]
    )

# Generated at 2022-06-21 11:57:11.640328
# Unit test for function parse
def test_parse():
    text = """
    short summary

    Long summary
    with more lines.

    :param some_param: Some param
    :param other_param: other param
    :returns: a value

    Raises:
        SomeError

    A trailing paragraph
    """

    long_summary_text = """
    short summary

    Long summary
    with more lines.

    """

    parsed = parse(text)
    assert parsed.short_description == 'short summary'
    assert parsed.long_description == long_summary_text
    assert parsed.meta == {
        'returns': 'a value',
        'raises': 'SomeError',
    }
    assert parsed.params['some_param'] == 'Some param'
    assert parsed.params['other_param'] == 'other param'
    assert parsed.summary_text == long_summary

# Generated at 2022-06-21 11:57:23.419090
# Unit test for function parse
def test_parse():
    text = '''\
    Header.

    Sub Header.

    :param param1: this is a parameter
    :param param2: this is a second parameter
    :returns: description of return value
    :raises keyError: raises an exception
    '''

    ret = parse(text)
    assert len(ret.sections) == 4
    assert ret.sections[0].title == 'Header'
    assert ret.sections[1].title == 'Sub Header'
    assert len(ret.sections[2].content) == 2
    assert ret.sections[3].content == ['raises an exception']
    assert ret.sections[3].title == 'raises keyError'
    assert ret.meta['param1'] == 'this is a parameter'

# Generated at 2022-06-21 11:57:31.790321
# Unit test for function parse
def test_parse():
	docstring = """
			Test function for docstring parser
			:param:  a - first parameter
			:param:  b - second parameter
			:returns: sum of two parameters
			"""
	assert parse(docstring)
	assert parse(docstring).params[0].name == "a"
	assert parse(docstring).params[1].name == "b"
	assert parse(docstring).returns.desc == "sum of two parameters"

	docstring = """
			Test function for docstring parser
			:param a - first parameter
			:param: b - second parameter
			:returns: sum of two parameters
			"""
	assert not parse(docstring)

# Generated at 2022-06-21 11:57:43.618198
# Unit test for function parse
def test_parse():
    import pytest
    from docstring_parser.common import Argument

    def test(text: str, style: Style, parsed: Docstring):
        assert parse(text, style) == parsed

    def test_exception(text: str, style: Style):
        with pytest.raises(ParseError):
            parse(text, style)

    test_exception("", Style.auto)
    test_exception("", Style.numpy)
    test_exception("", Style.google)
    test_exception("", Style.sphinx)

    test("", Style.auto, Docstring(summary="", description="", arguments=[],
        return_="", raise_="", meta={}, examples=[]))


# Generated at 2022-06-21 11:57:53.274648
# Unit test for function parse
def test_parse():
    style = Style.auto
    text = """
    Label vector to apply to data as a transform.

    Parameters
    ----------
    X
        Labels to be transformed.
    """

# Generated at 2022-06-21 11:57:55.995263
# Unit test for function parse
def test_parse():
    p = parse(text = 'Hello',
              style = 'numpy')
    print(p)

# Main function to call the test function
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:58:12.240524
# Unit test for function parse
def test_parse():
    assert parse(text="""\
    Lorem ipsum dolor sit amet, consectetur adipiscing elit,
    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
    """) == Docstring(
        first_line="Lorem ipsum dolor sit amet, consectetur adipiscing elit,",
        short_description="Lorem ipsum dolor sit amet, consectetur adipiscing elit,",
        long_description="sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        meta=dict(),
        style=Style.numpy,
    )
    for style in list(Style)[:-1]:
        if style == Style.numpy:
            continue

# Generated at 2022-06-21 11:58:13.681153
# Unit test for function parse
def test_parse():
    assert docstring_parser.parse(text)


if __name__=="__main__":
    test_parse()

# Generated at 2022-06-21 11:58:23.086470
# Unit test for function parse

# Generated at 2022-06-21 11:58:34.797666
# Unit test for function parse
def test_parse():
    text1 = '''
    """A short summary.

    This is a short multi-line descrpition. It can continue for a
    number of lines. But there is no need to be too verbose.

    :param a: Parameter a.
    :param b: Parameter b.
    :param c: Parameter c.
    :returns: Parameter d.
    """
    '''

# Generated at 2022-06-21 11:58:38.204210
# Unit test for function parse
def test_parse():
    docstring = """
    Metadata. 

    :param int max_depth: How deep the recursion will go.
    :param int current_depth: This is the current depth.
    :return: A recursive data structure.
    """
    print(parse(docstring))

# test_parse()

# Generated at 2022-06-21 11:58:50.094525
# Unit test for function parse
def test_parse():
    text = """Summary line.

    Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value

    """
    docstring = parse(text)

    # Test summary
    assert docstring.summary == "Summary line."

    # Test description
    assert docstring.description == "Extended description."

    # Test returns
    assert docstring.returns.type_name == "bool"
    assert docstring.returns.description == "Description of return value"

    assert docstring.arguments[0].arg_name == "arg1"
    assert docstring.arguments[0].type_name == "int"
    assert docstring.arguments[0].description == "Description of arg1"
    assert docstring.arg

# Generated at 2022-06-21 11:58:55.001782
# Unit test for function parse
def test_parse():
    text = """Short summary.

Command-line interface entry point.

:param arg1: first argument
:return: return value
:rtype: int"""
    style = Style.auto
    # parse_ = parse(text, style)
    return parse(text, style)


if __name__ == "__main__":
    # test_parse()
    print(test_parse())

# Generated at 2022-06-21 11:59:02.277542
# Unit test for function parse
def test_parse():
    text = """
A Sample Docstring

    :param x: The x-coordinate
    :type x: int
    :param func: The function
    :type func: str
    :param kwargs: The keyword args
    :type kwargs: dict
    :raises ValueError: if func is not callable
    :returns: Result of the function call

    """
    assert parse(text)


# Generated at 2022-06-21 11:59:08.185865
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring
    test_docstring = GoogleDocstring('Sums numbers\n\nArgs:\n    x (int): The first number.\n    y (int): The second number.\n\nReturns:\n    The sum of x and y.\n')
    assert parse('Sums numbers\n\nArgs:\n    x (int): The first number.\n    y (int): The second number.\n\nReturns:\n    The sum of x and y.\n') == test_docstring

# Generated at 2022-06-21 11:59:16.099521
# Unit test for function parse
def test_parse():
    """Test function parse."""
    text = """This is a test function."""
    ds = parse(text)
    print(ds)
    text = """This is a test function.

    :param a: a parameter
    :param b: a parameter
    :return: a return value
    """
    ds = parse(text)
    print(ds)
    text = """This is a test function.

    :param a: a parameter
    :param b: a parameter
    :returns: a return value
    """
    ds = parse(text)
    print(ds)

test_parse()


# Generated at 2022-06-21 11:59:25.904170
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    docstring_text = """
    Test function text.
    Parameters
    ----------
    arg1 : int
        The first parameter.
    arg2 : str
        The second parameter.
    Returns
    -------
    str
        The returned value.
    """

    docstring = parse(docstring_text)
    assert docstring.short_description == "Test function text."
    assert docstring.long_description == ""
    assert docstring.extended_description == ""
    assert docstring.meta["Parameters"] == [
        {"arg1": ("int", "The first parameter.")},
        {"arg2": ("str", "The second parameter.")}
    ]
    assert docstring.meta["Returns"] == [
        {"": ("str", "The returned value.")}
    ]
    assert docstring

# Generated at 2022-06-21 11:59:37.630125
# Unit test for function parse
def test_parse():
    text = """
        This is the first line of the docstring.
        And the second one.

        :param int x: some x
        :param y: some y
        :param z: some z
        :return: something or other
        :rtype: str

        .. note::
            Some note.

        .. seealso::
            Some see also.

        .. warning::
            Some warning.

        .. todo::
            Some todo.

        .. versionadded:: 0.3
            Some versionadded.

        .. versionchanged:: 0.4
            Some versionchanged.

        .. deprecated:: 0.5
            Some deprecated.

        And some more text
        """
    doctest = Docstring(text)

    # Assert short description.

# Generated at 2022-06-21 11:59:49.403597
# Unit test for function parse
def test_parse():
    text = '''
    This is a test function

    Parameters
        x: int
            The first parameter
        y: float
            The second parameter

    Returns
        int
            x + y

    '''
    assert parse(text).short_description == 'This is a test function', 'Incorrect short description'
    assert parse(text).full_description == '', 'Incorrect full description'
    assert parse(text).returns == 'int\n    x + y', 'Incorrect returntype'
    assert len(parse(text).params) == 2, 'Incorrect number of parameters'
    assert parse(text).params[1] == ('y', 'float\n    The second parameter'), 'Incorrect key-value pair for a parameter'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:01.378021
# Unit test for function parse
def test_parse():
    text = '''
    Summarize what this function does.

    This is a multiline docstring.

    :param (str) name: The name of this person
    :param age: The age of this person
    :type age: (int)
    :returns: A string representation of this person

    '''

    docstring = parse(text)
    assert docstring.summary == 'Summarize what this function does.'
    assert len(docstring.description.strip()) > 0
    assert len(docstring.params) == 2
    assert docstring.params['name'].arg_name == 'name'
    assert docstring.params['name'].type_name == 'str'
    assert docstring.params['name'].description == 'The name of this person'

# Generated at 2022-06-21 12:00:12.153456
# Unit test for function parse
def test_parse():
    text_1 = '''
    Return the number of items of a given iterable
    '''
    text_2 = '''
    Return the number of items of a given iterable
    :arg1: iterable to count
    :type arg1: iterable
    '''
    text_3 = '''
    Return the number of items of a given iterable
    :param iterable: iterable to count
    :type iterable: iterable
    '''
    text_4 = '''
    Return the number of items of a given iterable
    :param iterable: iterable to count
    :type iterable: iterable
    :return: iterable count
    :rtype: int
    '''

# Generated at 2022-06-21 12:00:17.652569
# Unit test for function parse
def test_parse():
    docstring = '''
        This function counts the occurence of a word.

        :param word: search query
        :type word: str
        :param text: text to search into
        :type text: str

        :rtype: bool
        :returns: whether or not the word was found
        '''
    pydocstring = parse(docstring)
    assert pydocstring.short_description == 'This function counts the occurence of a word.'
    assert pydocstring.long_description == ''
    assert pydocstring.find_tag('param', 'word').type_name == 'str'
    assert pydocstring.find_tag('returns').type_name == 'bool'

# Generated at 2022-06-21 12:00:19.265325
# Unit test for function parse
def test_parse():
    import doctest
    doctest.run_docstring_examples(parse, globals(), verbose=False)

# Generated at 2022-06-21 12:00:29.896383
# Unit test for function parse
def test_parse():
    """
    Test function parse
    """
    from docstring_parser.utils import parse
    from docstring_parser.styles import NUMPYDOC, GOOGLESTYLE
    from docstring_parser import Docstring

    # Test for NUMPY style parsing
    text = """\
    This is a docstring for
    :func:`parse` function.
    :param arg1: Test arg1
    :param arg2: Test arg2
    :raises TestError:
    :returns: None
    :rtype: None

    """
    docstring = parse(text, NUMPYDOC)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "This is a docstring for"
    assert docstring.long_description == ""
    assert docstring.return_type == "None"

# Generated at 2022-06-21 12:00:35.006091
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = parse(
        """
            A test function.
        """,
        Style.numpy,
    )
    assert docstring.summary == "A test function."
    assert docstring.extended_summary == ""

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:00:43.646377
# Unit test for function parse
def test_parse():
    # Function with all tags
    text = """
    This is a module level docstring.

    :param name: the name to say hello to
    :type name: str
    :returns: None

    .. seealso:: :obj:`say_hello_to_name`
    """
    d = parse(text, style=Style.numpy)
    assert len(d.params) == 1
    assert d.params["name"] == "the name to say hello to"
    assert d.returns == "None"
    assert len(d.seealso) == 1


# Generated at 2022-06-21 12:00:53.133388
# Unit test for function parse
def test_parse():
    text = """
    Header.

    :key: value
    :arg: description
    """
    doc = parse(text)
    assert doc.short_description == 'Header.'
    assert len(doc.meta) == 2
    assert doc.meta[0].key == 'key'
    assert doc.meta[0].value == 'value'
    assert doc.meta[1].key == 'arg'
    assert doc.meta[1].value == 'description'



# Generated at 2022-06-21 12:01:03.852851
# Unit test for function parse
def test_parse():
    txt = r"""An example docstring.

Args:
    a: A string or a tuple of strings.
    b: Some integer.

Returns:
    A dict.
    """
    d = parse(txt)
    assert d.long_description == 'An example docstring.'
    assert d.short_description == 'An example docstring.'
    assert len(d.meta) == 2
    assert d.meta[0].arg_name == 'a'
    assert d.meta[0].type_name == 'str'
    assert d.meta[0].description == 'A string or a tuple of strings.'
    assert d.meta[1].arg_name == 'b'
    assert d.meta[1].type_name == 'int'
    assert d.meta[1].description == 'Some integer.'

# Generated at 2022-06-21 12:01:05.997181
# Unit test for function parse
def test_parse():
    doc = parse('hello world')
    assert isinstance(doc, Docstring) == True


# Generated at 2022-06-21 12:01:12.129423
# Unit test for function parse
def test_parse():
    docstring = """\
    This is a module docstring

    :param int a: this is a parameter
    :param str b: this is a string parameter
    :return: this is a return value
    :rtype: int
    """

    assert parse(docstring, style=Style.sphinx) == \
        parse(docstring, style=Style.auto)


# vim: ft=python ts=4 sts=4 sw=4 et:

# Generated at 2022-06-21 12:01:17.827107
# Unit test for function parse
def test_parse():
  docstring = '''
  This is a module docstring
  '''
  correct_meta = {
      'summary': 'This is a module docstring',
      'extended_summary': '',
      'parameters': [],
      'returns': {},
      'raises': [],
      'see_also': [],
  }
  ds = parse(docstring)
  assert ds.meta == correct_meta


# Generated at 2022-06-21 12:01:25.643748
# Unit test for function parse
def test_parse():
    out = parse("""
    Test function
    :param p1: Test parameter 1
    :param p2: Test parameter 2
    :returns: Test return
    :raises keyError: Test raise exception
    """)
    assert out.short_description == "Test function"
    assert out.long_description == ""
    assert out.tags[0].title == "param"
    assert out.tags[0].description == "p1: Test parameter 1"
    assert out.tags[1].title == "param"
    assert out.tags[1].description == "p2: Test parameter 2"
    assert out.tags[2].title == "returns"
    assert out.tags[2].description == "Test return"
    assert out.tags[3].title == "raises"

# Generated at 2022-06-21 12:01:35.579115
# Unit test for function parse
def test_parse():
    style = Style.auto
    docstring = parse('''
    :param int test_param: description of test parameter
    :returns: description of return value
    :raises RuntimeError: description of exception
    ''')
    assert docstring.meta['Test_param'].type == 'int'
    assert docstring.meta['Test_param'].desc == 'description of test parameter'
    assert docstring.returns.type == None
    assert docstring.returns.desc == 'description of return value'
    assert docstring.raises['RuntimeError'].desc == 'description of exception'
    style = Style.google

# Generated at 2022-06-21 12:01:37.638274
# Unit test for function parse
def test_parse():
    text = '''
    .. code:: python

        import test
    '''
    assert parse(text)


test_parse()

# Generated at 2022-06-21 12:01:42.812943
# Unit test for function parse
def test_parse():
	docstring = """Single-line docstring."""
	result = parse(docstring)
	assert result.short_description == 'Single-line docstring.'
	assert not result.long_description
	assert not result.meta
	

"""
Converts a Docstring object back into a docstring text.

:param docstring: Docstring instance to convert
:param style: style of docstring to generate
:returns: generated docstring text
"""

# Generated at 2022-06-21 12:01:46.496241
# Unit test for function parse
def test_parse():
    text = '''
    Clean up.

    :param A: a
    :param B: b
    :returns: c
    '''

    assert parse(text).short_description == 'Clean up.'

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:01:57.542256
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("   ") == Docstring()
    assert parse("Hi") == Docstring()
    assert parse(" Hi ") == Docstring(content="Hi")
    assert parse("Hi\n") == Docstring(content="Hi")
    assert parse("Hi\n\n") == Docstring(content="Hi")
    assert parse("Hi\n\n\n") == Docstring(content="Hi")
    assert parse("Hi\n\n\n\n") == Docstring(content="Hi")

    assert parse("Hi\n\nBye\n") == Docstring(content="Hi\n\nBye")

    assert parse("Hi\nBye\n") == Docstring(content="Hi\nBye")


# Generated at 2022-06-21 12:02:08.003480
# Unit test for function parse
def test_parse():
    assert parse('Return a copy of the string with all the cased characters.') == (
        'Return a copy of the string with all the cased characters.', '', '')
    assert parse('Return a copy of the string with all the cased characters.\n\n'
                 'Also see :func:`str.lower`.') == (
        'Return a copy of the string with all the cased characters.',
        'Also see :func:`str.lower`.', '')

# Generated at 2022-06-21 12:02:18.156650
# Unit test for function parse
def test_parse():
    """
    test for function "parse"
    """
    parser = parse("""This function does something.

        :param a: first parameter
        :param b: second parameter
        :raises Exception: some error
        :returns: True
        :rtype: bool

        with a multiline description
        even on multiple lines.
    """, Style.numpy)
    assert parser.short_description == 'This function does something.'
    assert parser.long_description == 'with a multiline description even on multiple lines.'
    assert parser.params[0] == ('a', 'first parameter')
    assert parser.params[1] == ('b', 'second parameter')
    assert parser.returns == ('True',)
    assert parser.return_type == 'bool'

# Generated at 2022-06-21 12:02:27.271483
# Unit test for function parse
def test_parse():
    text = '''
    This is a test for parse function
    '''
    doc = parse(text)
    assert doc.summary == 'This is a test for parse function'

    text = '''
    :param param: description
    :arg arg: description
    :returns: description
    :raises Exception: description
    '''
    doc = parse(text)
    assert doc.summary == ''
    assert doc.parameters == {'param': 'description', 'arg': 'description'}
    assert doc.returns == 'description'
    assert doc.raises == {'Exception': 'description'}

# Generated at 2022-06-21 12:02:29.917829
# Unit test for function parse
def test_parse():
    """Tests if the function parse can find the appropriate style
    """
    assert parse("")
    assert parse("") == parse("", Style.auto)
    


# Generated at 2022-06-21 12:02:38.940392
# Unit test for function parse
def test_parse():
    docstring = """
    Summary line.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    bool
        Description of return value

    Other Parameters
    ----------------
    kwarg1 : str
        Description of `kwarg1`
    """
    parsed_docstring = parse(docstring)
    print(parsed_docstring)
    print(parsed_docstring.summary)
    print(parsed_docstring.description)
    print(parsed_docstring.params['arg1'])
    print(parsed_docstring.params['arg2'])
    print(parsed_docstring.returns)

# Generated at 2022-06-21 12:02:45.359923
# Unit test for function parse
def test_parse():
    text = '''
    Title
    ---
    Args:
        arg1: first arg
        arg2: second arg
    '''
    docstring = parse(text)
    assert docstring.title == 'Title'
    assert docstring.long_description == ''
    assert docstring.params['arg1'].description == 'first arg'
    assert docstring.params['arg2'].description == 'second arg'

# Generated at 2022-06-21 12:02:49.160776
# Unit test for function parse
def test_parse():
    docstring = '''\
    This is a documentation for test parse
    '''
    ret = parse(docstring)
    print(ret.summary)
    print(ret.args)
    print(ret.kwargs)
    print(ret.raises)
    print(ret.returns)
    print(ret.meta)
    print(ret.description)

# Generated at 2022-06-21 12:02:59.954315
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleStyle, NumpyStyle
    google = parse("""A good day.

Args:
    test (str): The test.
    test2 (:obj:`int`): The second test.

Raises:
    ValueError: if the test raise ValueError.

Returns:
    bool: if the test fails.

""")
    assert google == GoogleStyle("""A good day.

Args:
    test (str): The test.
    test2 (:obj:`int`): The second test.

Raises:
    ValueError: if the test raise ValueError.

Returns:
    bool: if the test fails.

""")


# Generated at 2022-06-21 12:03:10.300206
# Unit test for function parse

# Generated at 2022-06-21 12:03:22.338276
# Unit test for function parse
def test_parse():
    text = """
    # test function
    :param x: first param
    :type x: int
    :param y: second param
    :type y: int
    :returns: None
    :raises ValueError: if x < 0 or y < 0
    """
    docstring = parse(text)
    assert docstring.short_description == "test function"
    assert len(docstring.long_description) == 0
    assert len(docstring.meta) == 2
    assert docstring.meta[0].arg_name == 'x'
    assert docstring.meta[0].type_name == 'int'
    assert docstring.meta[0].description == 'first param'
    assert docstring.meta[1].arg_name == 'y'
    assert docstring.meta[1].type_name == 'int'


# Generated at 2022-06-21 12:03:35.075075
# Unit test for function parse
def test_parse():
    text = """
    This is a description of the function. 
    :type a: int
    :param a: this is a param
    :param b: this is another param
    :returns: this is a return value
    :raises ValueError: this is a raised exception
    """
    docstring = parse(text)
    assert docstring.summary == "This is a description of the function."
    assert 'a' in docstring.meta and 'b' in docstring.meta
    assert docstring.meta['a'].description == 'this is a param'
    assert docstring.meta['b'].description == 'this is another param'
    assert docstring.extended_summary == ''
    assert docstring.returns.description == 'this is a return value'

# Generated at 2022-06-21 12:03:46.417867
# Unit test for function parse
def test_parse():
    doc_string = '''
    """
    This is a module docstring.
    
    This happens to be a multiline module docstring.
    
    :param param1: this is a first param
    :param param2: this is a second param
    :return: this is a description of what is returned
    :raises keyError: raises an exception
    :param param3: this is the third param
    """
    '''
    a = parse(doc_string)
    b = parse(doc_string, Style.numpy)
    c = parse(doc_string, Style.google)
    d = parse(doc_string, Style.auto)
    print(a)
    print(b)
    print(c)
    print(d)


test_parse()

# Generated at 2022-06-21 12:03:49.972611
# Unit test for function parse
def test_parse():
    text = """
    This is a docstring
    Examples:
    1. Example1
    2. Example2
    """
    ds = parse(text)
    return ds

# Generated at 2022-06-21 12:03:59.898579
# Unit test for function parse
def test_parse():
    assert parse('simple with no sections or content') == Docstring(summary='simple with no sections or content')
    assert parse('simple with :no: sections or content', style=Style.numpy) == Docstring(summary='simple with', args=[('no', 'sections or content')])
    assert parse('simple with :no: sections or content', style=Style.google) == Docstring(summary='simple with', args=[('no', 'sections or content')])
    assert parse('simple with :no: sections or content', style=Style.sphinx) == Docstring(summary='simple with :no: sections or content')
    assert parse('simple with :no: sections or content', style=Style.auto) == Docstring(summary='simple with :no: sections or content')

# Generated at 2022-06-21 12:04:10.812554
# Unit test for function parse
def test_parse():
    docstring = parse("""
        This is a module docstring.

        :param arg1: The first parameter.
        :type arg1: str
        :param arg2: The second parameter.
        :type arg2: int
        :param arg3: This parameter has no type specified.
        :returns: str
        :raises TypeError: if any of the parameters are invalid.

        .. versionadded:: 1.0.0

        .. versionchanged:: 2.0.0
            This version changed stuff.

        .. seealso:: bla()
            Some more info.

        .. notes::
            This is some additional notes.

        .. todo::
            This is a todo.

        This is the end of the docstring.
    """)
    metadata = docstring.meta
    assert 'param' in metadata
    assert 'type'

# Generated at 2022-06-21 12:04:18.156852
# Unit test for function parse
def test_parse():
    text = """
My title

:param x: Neat argument
:returns: Stuff
"""
    docstring = parse(text)
    assert docstring.short_description == 'My title'
    assert docstring.long_description == ''
    assert docstring.meta['param']['x'].args['x'] == 'Neat argument'
    assert docstring.meta['returns'].args['returns'] == 'Stuff'

# Generated at 2022-06-21 12:04:27.735511
# Unit test for function parse
def test_parse():
    text_1 = '''
    :param key: the key
    :param value: the value
    :returns: True if key is found, False otherwise
    :raises ValueError: if key is not found
    '''
    doc_1 = parse(text_1, Style.numpy)
    assert doc_1.meta['key'] == 'the key'
    assert doc_1.meta['value'] == 'the value'
    assert doc_1.content == 'if key is found, False otherwise'
    assert doc_1.errors == 'if key is not found'
    text_2 = '''
    :param key: the key
    :param value: the value
    :returns: True if key is found, False otherwise
    :exceptions: ValueError if key is not found
    '''
    doc_2 = parse

# Generated at 2022-06-21 12:04:32.278000
# Unit test for function parse
def test_parse():
    docstring_parser.parse("""
    This function does something.

    :param W: The width of the box.
    :param h: The height of the box.
    :param d: The depth of the box.
    :returns: volume of the box
    """)


# Generated at 2022-06-21 12:04:41.482225
# Unit test for function parse
def test_parse():
    text = """
    Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    int
        Description of return value

    Raises
    ------
    AttributeError
        The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError
        If `arg2` is equal to `arg1`.
    """
    d = parse(text)
    assert d.summary == d.description == ['Summary line.', '', 'Extended description.']
    assert d.extended_summary == '\nExtended description.\n'
    assert d.short_description == 'Summary line.'

# Generated at 2022-06-21 12:04:47.887765
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import parse_google


# Generated at 2022-06-21 12:04:51.812435
# Unit test for function parse
def test_parse():
    text = '''This is a test docstring.

:param a: test param
:returns: test return
'''
    assert parse(text).meta['a'] == 'test param'
    assert parse(text).meta['returns'] == 'test return'

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:05:02.975908
# Unit test for function parse
def test_parse():
    docstr = """One line summary.

    Extended description.

    :param a: blabla
    :type a: str
    :param b: blabla
    :type b: float
    :returns: blabla
    :rtype: int

    More description.

    """
    doc = parse(docstr)
    assert(doc.short_description == "One line summary.")
    assert(doc.long_description == "Extended description.")
    assert(doc.returns.description == "blabla")
    assert(doc.params[0].name == "a")
    assert(doc.params[0].type_name == "str")
    assert(doc.params[1].name == "b")
    assert(doc.params[1].type_name == "float")