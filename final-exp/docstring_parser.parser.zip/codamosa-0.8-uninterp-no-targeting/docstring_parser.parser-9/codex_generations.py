

# Generated at 2022-06-21 11:55:21.971801
# Unit test for function parse

# Generated at 2022-06-21 11:55:24.083885
# Unit test for function parse
def test_parse():
    docstring = """Example:
                  This is an example"""
    res = parse(docstring)

    assert(res.params == None)
    assert(res.example == 'This is an example')


# Generated at 2022-06-21 11:55:28.270490
# Unit test for function parse
def test_parse():
    docstring = '''
   Hello, world.
    :param foo: The foo argument.
    :type foo: str
    :returns: None
    :raises Exception: when an exception occurs
    '''
    doc = parse(docstring)
    assert (doc.short_description == 'Hello, world.')
    assert (doc.meta['param'][0]['arg'] == 'foo')
    assert (doc.meta['param'][0]['type'] == 'str')

# Generated at 2022-06-21 11:55:31.577821
# Unit test for function parse
def test_parse():
    assert parse("""
        This is just a sample
        to test how it works
        """) == """This is just a sample
        to test how it works""".split("\n")

# Generated at 2022-06-21 11:55:42.242208
# Unit test for function parse
def test_parse():
    text = '''
    Returns the request as seen by the middleware.
    This is the full WSGI environ, plus request.GET and request.POST
    (aka. PUT and DELETE).
    :returns: object
    :rtype: 
    '''
    ret_dict = parse(text)
    assert ret_dict.returns == 'object'
    assert ret_dict.rtype == ''
    assert ret_dict.function == 'parse'
    assert ret_dict.summary == 'Returns the request as seen by the middlewar' \
        'e. This is the full WSGI environ, plus request.GET and req' \
        'uest.POST (aka. PUT and DELETE).'
    assert ret_dict.warnings[0].text == 'This is a sample warning'


# Generated at 2022-06-21 11:55:49.448809
# Unit test for function parse
def test_parse():
    text = """
    Short Summary:
    This is the short one line summary

    Long Summary:
    This is the long multi-line summary

    Returns:
    ndarray: Returns an array of ones with shape (n, m).
    
    """
    parsed_docstring = parse(text)
    assert parsed_docstring.short_desc == "This is the short one line summary"
    assert parsed_docstring.long_desc == "This is the long multi-line summary"
    assert parsed_docstring.returns[0]["type"] == "ndarray"
    assert parsed_docstring.returns[0]["desc"] == "Returns an array of ones with shape (n, m)."

# Generated at 2022-06-21 11:55:58.907820
# Unit test for function parse
def test_parse():
    with open('example.py') as file:
        text = file.read()

    assert parse(text).short_description == 'Main module'
    assert parse(text).long_description == r'Detailed description of the module'
    assert parse(text).params['x'][0] == 'List of numbers to pick from'

    with open('example2.py') as file:
        text = file.read()

    assert parse(text).short_description == 'Main module'
    assert parse(text).long_description == r'Detailed description of the module'
    assert parse(text).params['x'][0] == 'List of numbers to pick from'

# Generated at 2022-06-21 11:56:08.597650
# Unit test for function parse
def test_parse():
    import docstring_parser as parser
    example_docstring = '''
    This is a module docstring

    This is another paragraph

    :param int a: param a
    :param str b: param b
    :returns: return doc
    :rtype: int
    '''
    docstring = parser.parse(example_docstring)
    print("\n ".join([str(docstring), str(docstring.description), str(docstring.short_description), str(docstring.long_description), str(docstring.meta)]))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:56:19.928039
# Unit test for function parse
def test_parse():
    # Valid python docstring
    assert parse("") == Docstring(
        summary="", description="", meta={}, sections=[], examples=[]
    )

    assert parse("Hello world") == Docstring(
        summary="Hello world", description="", meta={}, sections=[], examples=[]
    )

    assert parse("Hello\nworld") == Docstring(
        summary="Hello", description="world", meta={}, sections=[], examples=[]
    )

    assert parse("\n") == Docstring(
        summary="", description="", meta={}, sections=[], examples=[]
    )

    assert parse("\n\n") == Docstring(
        summary="", description="", meta={}, sections=[], examples=[]
    )


# Generated at 2022-06-21 11:56:28.163528
# Unit test for function parse
def test_parse():
    text = """
    This is a summary.

    This is a description, which can be multiple lines long, but should not
    contain two consecutive newlines.

    Parameters
    ----------
    a : int
        This variable is an integer.
    b : float
        This variable is a float.

    Returns
    -------
    tuple
        A tuple of two objects.
        The first element is a :class:`~foo.Bar` object, while the second
        element is a :class:`~foo.Baz` object.
    """

    print(parse(text, style=Style.numpy))

if __name__ == '__main__':
    # test_parse()
    pass

# Generated at 2022-06-21 11:56:41.469905
# Unit test for function parse
def test_parse():
    """Test parse"""
    doc_string = """
    Convert tensor to numpy array and return it.

    Same as ``x.cpu().numpy()`` in PyTorch,
    ``x.numpy()`` in MXNet, ``x.get()`` in TensorFlow.

    Args:
        x (:obj:`torch.Tensor` or :obj:`numpy.ndarray` or :obj:`mxnet.nd.NDArray`): Input tensor.

    Returns:
        :obj:`numpy.ndarray`: The converted numpy array.
    """

    parsed_docstring = parse(doc_string)
    # print(parsed_docstring.short_description)
    # print(parsed_docstring.long_description)
    # print(parsed_docstring.params

# Generated at 2022-06-21 11:56:52.392663
# Unit test for function parse
def test_parse():
    """Simple unit test for parse"""

    # Example
    simple_docstring = """One-line summary that does not use variable names or the function name.

Several sentences providing an extended description.  Refer to
variables using back-ticks, e.g. `var`.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`
Returns
-------
bool
    Description of return value
"""
    parsed_docstring = parse(simple_docstring)
    assert parsed_docstring.short_description == "One-line summary that does not use variable names or the function name."
    assert parsed_docstring.long_description == """Several sentences providing an extended description.  Refer to
variables using back-ticks, e.g. `var`."""

# Generated at 2022-06-21 11:56:55.756143
# Unit test for function parse
def test_parse():
    assert isinstance(parse(''), Docstring)
    assert isinstance(parse('', style=Style.auto), Docstring)

# Unit tests for function test_parse
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:56:58.725471
# Unit test for function parse
def test_parse():
    docstring = """
    Sum up lu and lo into one array, then replace missing values with 0s.

    """
    doc = parse(docstring)
    assert str(doc) == docstring

# Generated at 2022-06-21 11:57:09.268172
# Unit test for function parse
def test_parse():
    '''
    Test function parse
    '''
    ds = '''
        :param a: b
        :return: c
        '''
    assert parse(ds).short_description == ''
    assert parse(ds).long_description == ''
    assert parse(ds).meta['param'][0].name == 'a'
    assert parse(ds).meta['param'][0].type == ''
    assert parse(ds).meta['param'][0].description == 'b'
    assert parse(ds).meta['return'][0].name == ''
    assert parse(ds).meta['return'][0].type == ''
    assert parse(ds).meta['return'][0].description == 'c'

# Generated at 2022-06-21 11:57:21.825818
# Unit test for function parse
def test_parse():
    text = """
If you're using a custom subclass of :class:`~requests.Session`, you should
 also pass it to this function to ensure that the :class:`~requests.Session`
 created to do the fetch will be properly configured.
 
 """
    docstring = parse(text)
    assert docstring.meta == {}
    assert docstring.params == \
        [{'name': "you're using a custom subclass of ", 'type': '~requests.Session', 'desc': ''},
         {'name': '', 'type': '', 'desc': " also pass it to this function to ensure that the "},
         {'name': '', 'type': '~requests.Session', 'desc': ' created to do the fetch will be properly configured.'}]
    assert docstring.returns == {}
    assert docstring.ra

# Generated at 2022-06-21 11:57:30.946200
# Unit test for function parse
def test_parse():
    # Assert that a docstring is parsed properly
    docstring = parse('''
        Short summary.

        Extended description.

        Args:
            param1 (type): Description of `param1`
            param2 (type): Description of `param2`

        Returns:
            Description of return value

        Raises:
            Exception1: Description of exception
            Exception2: Description of exception
        ''')

    assert docstring.short_description == 'Short summary.'
    assert docstring.long_description == 'Extended description.'
    assert docstring.returns == 'Description of return value'
    assert docstring.returns_type is None
    assert docstring.parameters == {
        'param1': 'Description of `param1`',
        'param2': 'Description of `param2`',
    }
    assert docstring

# Generated at 2022-06-21 11:57:42.916719
# Unit test for function parse
def test_parse():
    """Test the docstring parser.
    
    :raises AssertError: If one of the parsed values does not match the expected value.
    """

    docstring = parse("""Single-line docstring.""")
    assert docstring.short_description == "Single-line docstring."
    assert docstring.long_description is None
    assert len(docstring.params) == 0
    assert len(docstring.returns) == 0
    assert len(docstring.raises) == 0
    assert len(docstring.others) == 0

    docstring = parse("""Single-line docstring.

    With a
    multiline
    long description.""")
    assert docstring.short_description == "Single-line docstring."
    assert docstring.long_description == "With a\nmultiline\nlong description."


# Generated at 2022-06-21 11:57:50.050531
# Unit test for function parse
def test_parse():
    docstrings = [
        '''Test 1.

:param int value: input value
:returns: increment by 1
:raises ValueError: if value is less than 0
''',

        '''Test 2.

Args:
    value (int): input value
Returns:
    increment by 1
Raises:
    ValueError: if value is less than 0
'''
    ]
    for docstring in docstrings:
        print(parse(docstring))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:57:52.607238
# Unit test for function parse
def test_parse():
    parse("""This is module_docstring_to_dict project docs.
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """)


# Generated at 2022-06-21 11:58:08.412156
# Unit test for function parse
def test_parse():
    docstring = parse('''
    Hello World
    ''')
    assert docstring.short_description == "Hello World"

    docstring = parse('''
    Hello
    World
    ''')
    assert docstring.short_description == "Hello\nWorld"

    docstring = parse('''
    Hello World.
    The End.
    ''')
    assert docstring.short_description == "Hello World."
    assert docstring.long_description == "The End."

    docstring = parse('''
    :param x: Parameter X
    :param y: Parameter Y
    ''')
    assert docstring.params[0].args == ["x"]
    assert docstring.params[0].description == "Parameter X"
    assert docstring.params[1].args == ["y"]
   

# Generated at 2022-06-21 11:58:11.152454
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == """Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

# Generated at 2022-06-21 11:58:13.861789
# Unit test for function parse
def test_parse():
    expected = '''\
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    actual = parse(expected)
    assert expected == actual.meta

# Generated at 2022-06-21 11:58:16.618138
# Unit test for function parse
def test_parse():
    text = """A really simple docstring that documents a function."""
    assert parse(text).summary == 'A really simple docstring that documents a function.'
    assert parse(text).description == ''

# Generated at 2022-06-21 11:58:24.749579
# Unit test for function parse

# Generated at 2022-06-21 11:58:35.962333
# Unit test for function parse
def test_parse():
    def test(text, result):
        assert result == parse(text)
        assert result == parse(text, Style.auto)
    ds = Docstring
    test(
        '''
    one line''',
        ds(
            content='one line',
            meta={},
            errors=[]
        )
    )
    test(
        '''
    single line''',
        ds(
            content='single line',
            meta={},
            errors=[]
        )
    )
    test(
        '''
    single line
    ''',
        ds(
            content='single line',
            meta={},
            errors=[]
        )
    )

# Generated at 2022-06-21 11:58:40.857894
# Unit test for function parse
def test_parse():
    data = ['numpy',"pyspark"]
    for d in data :
        path = "./data/"+ d + "/*.py"
        i = 0
        for filename in glob.glob(path):
            file = open(filename)
            lines = file.read()
            parse(lines)
            i += 1
            if i == 5 :
                break
        break



if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:58:52.068318
# Unit test for function parse
def test_parse():
    text = """\
    First line.

    This is a test docstring.

    :param foo: this is a parameter
    :type foo: str
    :param bar: this is a parameter
    :type bar: int, optional
    :param baz: this is a parameter
    :type baz: bool, optional
    :returns: None
    :raises ValueError: when something bad happens

    """
    docstring = parse(text)
    assert docstring.short_description == "First line."
    assert docstring.long_description == "This is a test docstring."
    assert len(docstring.params) == 3
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 1


# Generated at 2022-06-21 11:58:57.334300
# Unit test for function parse
def test_parse():
    docstringText = """Summary line.

Extended description."""
    docstring = parse(docstringText, Style.google)

    assert docstring.summary == "Summary line.\n"
    assert docstring.description == "Extended description."
    assert docstring.returns == None
    assert docstring.params == None
    assert docstring.raises == None
    assert docstring.notes == None
    assert docstring.references == None

# Generated at 2022-06-21 11:59:05.526984
# Unit test for function parse
def test_parse():
    import os
    import sys
    sys.path.append(os.getcwd())
    from docstring_parser.cars import Car
    import pdb;pdb.set_trace()
    car = Car('Mercedes-Benz', 'S600', 'V12')
    car.drive()
    print(parse(car.drive.__doc__, Style.google))
    print(parse(car.drive.__doc__, Style.numpy))
    print(parse(car.drive.__doc__, Style.auto))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:59:13.348968
# Unit test for function parse
def test_parse():
    assert parse("""\
This is the day
which the Lord hath made;
we will rejoice and be glad in it.

Psalm 118:24""").summary=="This is the day which the Lord hath made; we will rejoice and be glad in it."

# Generated at 2022-06-21 11:59:21.600789
# Unit test for function parse
def test_parse():
    """Unit test for parse
    
    :param text: docstring_test.txt
    :param style: Style.auto
    :returns: parsed docstring representation
    """
    #Open file
    f = open("docstring_test.txt", "r") 
    #Read file
    text = f.read()
    #Close file
    f.close()
    #Parse docstring
    parsed_dict = parse(text)

    #return parsed_dict
    return parsed_dict

#Print parsed_dict
print(test_parse())

# Generated at 2022-06-21 11:59:27.374538
# Unit test for function parse
def test_parse():
    text = '''\
This function does something.

:param int a: The first parameter
:param str b: The second parameter
:returns: The return value description
:raises ValueError: If something goes wrong'''
    docstring = parse(text)
    assert docstring.short_description == 'This function does something.'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params['a']['type'] == 'int'
    assert docstring.params['a']['desc'] == 'The first parameter'
    assert docstring.params['b']['type'] == 'str'
    assert docstring.params['b']['desc'] == 'The second parameter'
    assert docstring.returns['desc'] == 'The return value description'
    assert len

# Generated at 2022-06-21 11:59:32.509371
# Unit test for function parse
def test_parse():
    docstring_test = parse("hello world!")
    assert(docstring_test.meta == {})
    assert(docstring_test.short_description == "")
    assert(docstring_test.long_description == "hello world!")
    assert(docstring_test.sections == [])

# Generated at 2022-06-21 11:59:39.683141
# Unit test for function parse
def test_parse():
    """docstring for test_parse"""

    assert parse('""" docstring """', style=Style.sphinx)
    assert parse('""" docstring """', style=Style.google)
    assert parse('""" docstring """', style=Style.numpy)
    assert parse('""" docstring """', style=Style.auto)

    assert not parse('', style=Style.sphinx)
    assert not parse('', style=Style.google)
    assert not parse('', style=Style.numpy)
    assert not parse('', style=Style.auto)

# Generated at 2022-06-21 11:59:44.553656
# Unit test for function parse
def test_parse():
    text = '''
        a.
        b.
        c.
        d.
        e.
        f.
    '''
    instance = parse(text)
    print("=============parse test===============")
    print(instance)
    print("=============parse test end===============")

# Generated at 2022-06-21 11:59:52.237483
# Unit test for function parse
def test_parse():
    text = '''
    This is a docstring.
    :param foo: This is foo.
    :param bar: This is bar.
    '''
    # style = 'google'
    style = 'numpy'
    docstring = parse(text, style=style)

    assert docstring.short_description == 'This is a docstring.'
    assert docstring.long_description == ''
    assert docstring.parse_errors == []
    assert len(docstring.parameters) == 2
    assert len(docstring.returns) == 0
    assert len(docstring.raises) == 0
    assert len(docstring.summary) == 0


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:03.329561
# Unit test for function parse
def test_parse():
    '''
    Assert the correct value is returned
    '''
    text = '''\
    This is a test docstring.
    '''
    # style = Style.reStructuredText
    style = Style.numpy
    ret = parse(text,style)
    print("ret is ",ret)
    assert ret.summary == 'This is a test docstring.'

if __name__ == "__main__":
    # The arguments are text, style
    text = '''\
    This is a test docstring.
    '''
    # style = Style.reStructuredText
    style = Style.numpy
    ret = parse(text,style)
    print("ret is ",ret)
    assert ret.summary == 'This is a test docstring.'

# Generated at 2022-06-21 12:00:03.801860
# Unit test for function parse
def test_parse():
    pass

# Generated at 2022-06-21 12:00:14.176537
# Unit test for function parse
def test_parse():
    docstrings = [
        '''
        This function first searches for a "return" meta-variable line and
        then searches for a "returns" meta-variable line.

        Parameters
        ----------
        x : int
            Value for x.
        y : int, optional
            Value for y.

        Returns
        -------
        x + y

        See Also
        --------
        make_xy

        Examples
        --------
        >>> import scipy.special as sc
        >>> sc.ex(3)
        20.085536923187668
        '''
    ]
    
    for i in range(len(docstrings)):
        assert(parse(docstrings[i]) is not None)

# Generated at 2022-06-21 12:00:23.227329
# Unit test for function parse
def test_parse():
    docstring = """
    All-caps headers.

    :param param1: The first parameter.
    :param param2: The second parameter.

    :returns: Description of return value.
    :raises keyError: raises an exception
    """
    print(parse(docstring))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:24.361940
# Unit test for function parse
def test_parse():
    assert parse('Test') == Docstring('Test')

# Generated at 2022-06-21 12:00:28.227949
# Unit test for function parse
def test_parse():
    doc = 'a\nb\n\nc\n'
    my_doc = parse(doc)

    assert my_doc.description == "a\nb"
    assert my_doc.content == "c"



# Generated at 2022-06-21 12:00:39.688644
# Unit test for function parse
def test_parse():
    parsed = parse("""Class description.

:param arg1: description
:param arg2: description
:type arg3:  int
:type arg4: (int, float)
:return: description
:rtype: str
:Example:
text
:Example: text

""", style=Style.google)

    assert parsed == Docstring(
        summary='Class description.',
        description='',
        params={
            'arg1': 'description',
            'arg2': 'description',
            'arg3': 'int',
            'arg4': '(int, float)',
        },
        returns='description',
        return_type='str',
        meta={
            'return': 'description',
            'rtype': 'str',
            'Example': ['text', 'text'],
        },
    )


# Generated at 2022-06-21 12:00:45.015740
# Unit test for function parse
def test_parse():
    d = parse('''\
    This is a test for docstring parsing.

    :param test: This is a test.
    ''')
    assert d == {
        'content': 'This is a test for docstring parsing.',
        'meta': {
            'param': {
                'test': 'This is a test.',
            },
        },
    }

# Generated at 2022-06-21 12:00:52.423321
# Unit test for function parse
def test_parse():
    s = '''
"""Module docstring.

Details.
"""
    '''
    docstring = parse(s)
    assert docstring.short_description == "Module docstring."
    assert docstring.long_description == "Details."
    assert docstring.lines == ['Module docstring.', 'Details.']
    assert docstring.full_docstring == s
    assert not docstring.sections

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:01:02.554372
# Unit test for function parse
def test_parse():
	s = '''
		Summary line.

		Extended description.

		Parameters
		----------
		arg1 : int
			Description of arg1
		arg2 : str
			Description of arg2

		Returns
		-------
		str
			Description of return value

		Raises
		------
		KeyError
			When a key error
		'''
	doc = parse(s)
	assert doc.summary == 'Summary line.'
	assert doc.description == 'Extended description.'
	assert doc.extended_description == 'Extended description.'
	param_keys = list(doc.params.keys())
	assert param_keys[0] == 'arg1'
	assert param_keys[1] == 'arg2'

# Generated at 2022-06-21 12:01:12.319740
# Unit test for function parse
def test_parse():
    test_string = """
    Args:
        filename (str): The name of the file
        content (str): The content of the file
    
    Returns:
        (str): The full path to the file
    
    Raises:
        FileNotFound
    """
    test_return = parse(test_string)
    assert test_return.args == [("filename (str)", "The name of the file"), ("content (str)", "The content of the file")]
    assert test_return.returns == [("(str)", "The full path to the file")]
    assert test_return.raises == [("FileNotFound", "")]
    assert test_return.meta == {}

test_parse()

# Generated at 2022-06-21 12:01:14.132038
# Unit test for function parse
def test_parse():
    assert parse('"""A simple example docstring"""').short_description == 'A simple example docstring'


# Generated at 2022-06-21 12:01:17.827429
# Unit test for function parse
def test_parse():
    text = """
    This is a test

    :param str param: This is a param
    :returns: This is a return
    """

    d = parse(text)
    print(d)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:01:30.145685
# Unit test for function parse
def test_parse():
    assert parse('a') == Docstring(summary='a')
    assert parse('a\n\n    b') == Docstring(summary='a', body='b')
    assert parse('a\n\n    b\n\nc') == Docstring(summary='a', body='b', returns='c')
    assert parse('a\n\n    b\n\n:param a: x\n:type a: type\n:rtype: something\n:return: x') == Docstring(summary='a', body='b', params={'a': ('x', 'type')}, returns=('something', 'x'))

# Generated at 2022-06-21 12:01:30.669346
# Unit test for function parse
def test_parse():
    parse("")

# Generated at 2022-06-21 12:01:37.816424
# Unit test for function parse
def test_parse():
    docstring = '''This is a short description.
    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        Description of return value.
    '''
    result = parse(docstring)
    assert result.short_description == 'This is a short description.'
    assert result.description == 'This is a long description.'
    assert result.long_description == 'This is a long description.'
    assert result.returns['description'] == 'Description of return value.'

# Generated at 2022-06-21 12:01:45.685507
# Unit test for function parse
def test_parse():
    import docstring_parser
    from pprint import pprint
    ds = docstring_parser.parse("""
        My short description.

        My long description.

        :param str arg1: The first argument.
        :param arg2: The second argument.
        :returns: Description of return value.
        :raises keyError: raises an exception
    """)
    pprint(ds.__dict__)

if __name__ == "__main__":
    # Unit test, docstring_parser.py
    def parse(text: str, style: Style = Style.auto) -> Docstring:
        """Parse the docstring into its components.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """


# Generated at 2022-06-21 12:01:54.714811
# Unit test for function parse
def test_parse():
    from docstring_parser.spaces import _check_spaces
    from docstring_parser.styles import SPHINX_STYLE

    # Get the SPHINX docstring for the function parse, which doesn't necessarily match the docstring for parse here
    parse_docstring_text = """
    The main parsing routine.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """

    parse_doc = parse(parse_docstring_text, style=SPHINX_STYLE)
    assert parse_doc == parse_doc

    assert _check_spaces(parse_doc) == 2

# Generated at 2022-06-21 12:02:03.047689
# Unit test for function parse
def test_parse():
    text = '''
    hello

    Function to say hello to someone.

    :param str name: Name of the person to say hello to.
    :returns: The hello message in a string.

    '''

    result = parse(text)
    print(result)
    assert result.short_description == 'hello'
    assert result.long_description == 'Function to say hello to someone.'
    assert result.params == [{'name': 'name', 'type': 'str', 'description': 'Name of the person to say hello to.'}]
    assert result.returns == {'type': 'str', 'description': 'The hello message in a string.'}

# Generated at 2022-06-21 12:02:09.774148
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import GoogleDocstring, NumpyDocstring
    def test_parse_style():
        # First, test for all invalid or None styles
        for style in [None, -1, 'invalid', Style.auto]:
            try:
                parse('content', style=style)
            except ValueError:
                assert True
            except Exception:
                assert False

        # Then test that a valid style returns the correct Docstring class
        for style in [Style.google, Style.numpy]:
            # Ideally we would check the returned object's class,
            # but it should be a duck type

            doc = parse('', style=style)
            if style is Style.google:
                assert isinstance(doc, GoogleDocstring)
            elif style is Style.numpy:
                assert isinstance(doc, NumpyDocstring)

# Generated at 2022-06-21 12:02:19.174036
# Unit test for function parse
def test_parse():
    # All options
    str1 = """
    This is a paragraph.
    Use it wisely.

    :param request:
    :type request:
    :returns:
    :rtype:
    :raises ValueError:
    """

    # One option
    str2 = """
    This is a paragraph 2.
    Use it wisely.

    :returns:
    """

    # No options
    str3 = """
    This is a paragraph 3.
    Use it wisely.
    """

    # Bunch of options

# Generated at 2022-06-21 12:02:30.946028
# Unit test for function parse
def test_parse():
    text = """\
        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation"""

    text = "\n".join(text.splitlines())
    docstring = parse(text)
    assert docstring.short_description == ""
    assert docstring.long_description == ""
    assert docstring.meta["returns"] == "parsed docstring representation"
    assert docstring.meta["param"] == ["text: docstring text to parse", "style: docstring style"]
    assert docstring.errors == []

# Generated at 2022-06-21 12:02:32.706792
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:02:40.767603
# Unit test for function parse
def test_parse():
    docstring = '''
This is a example docstring

:param test_param: a test param
:param test_param_two: another test param
:returns: none
:raises type_error: if test_param_two >= test_param
'''
    doc = parse(docstring)
    print('\n', doc.meta)
    print('\n', doc.short_description)
    print('\n', doc.long_description)
    print('\n', doc.returns)
    print('\n', doc.raises)
    print('\n', doc.yields)


# Generated at 2022-06-21 12:02:41.678722
# Unit test for function parse
def test_parse():
    assert parse.__doc__ is not None

# Generated at 2022-06-21 12:02:50.495767
# Unit test for function parse
def test_parse():
    import pytest
    from docstring_parser.styles import Style
    from io import StringIO

    # Test the example in https://sphinx-rtd-tutorial.readthedocs.io/en/latest/docstrings.html
    text = """
    This function does something.

    :param name: The name to use.
    :type name: str.
    :param state: Current state to be in.
    :type state: bool.
    :returns:  int -- the return code.
    :raises: AttributeError, KeyError
    """

    docstring = parse(text)
    assert text == docstring.raw
    assert docstring.short_description == "This function does something."
    assert docstring.long_description == ''
    assert len(docstring.meta) == 6

# Generated at 2022-06-21 12:03:01.687190
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring('', '', '', '', '')
    assert parse('foo') == Docstring('foo', '', '', '', '')
    assert parse('foo\nbar') == Docstring('foo', 'bar', '', '', '')
    assert parse('foo\nbar\nbaz') == Docstring('foo', 'bar', 'baz', '', '')
    assert parse('foo\nbar\nbaz\nabc') == Docstring('foo', 'bar', 'baz', 'abc', '')
    assert parse('foo\nbar\nbaz\nabc\nxyz') == Docstring('foo', 'bar', 'baz', 'abc', 'xyz')

# Generated at 2022-06-21 12:03:04.565409
# Unit test for function parse
def test_parse():
    d = parse("""This is a title
    This is a description""")
    assert d.title =="This is a title"
    assert d.description == "This is a description"

# Generated at 2022-06-21 12:03:12.935743
# Unit test for function parse
def test_parse():

    dstr = """
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """


# Generated at 2022-06-21 12:03:22.844099
# Unit test for function parse
def test_parse():
    text = '''This is a docstring in NumPy format.

This docstring has two sections.

Args:
    arg1 (int): Description of `arg1`
    arg2 (str): Description of `arg2`

Returns:
    bool: Description of return value
    '''
    docstring = parse(text)
    assert docstring.short_description == 'This is a docstring in NumPy format.'
    assert docstring.long_description == 'This docstring has two sections.'
    assert docstring.meta['Args'] == '\n    arg1 (int): Description of `arg1`\n    arg2 (str): Description of `arg2`\n'
    assert docstring.meta['Returns'] == '\n    bool: Description of return value\n'

# Generated at 2022-06-21 12:03:33.009064
# Unit test for function parse
def test_parse():
    text = '''\
        This is a test

        :param something: a test
        :type something: str
        :returns: None
        '''

    parsed_docstring = parse(text, Style.auto)
    assert parsed_docstring.short_description == 'This is a test'
    assert parsed_docstring.long_description == ''
    assert parsed_docstring.returns == 'None'
    assert parsed_docstring.returns_description == ''
    assert parsed_docstring.meta == {
        'param something': 'a test',
        'type something': 'str',
    }

# Generated at 2022-06-21 12:03:39.099356
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle
    
    def f1():
        """
        docstring

        :param a: first parameter
        :param b: second parameter
        :returns: something
        """

    assert parse(f1.__doc__) is not None
    assert isinstance(parse(f1.__doc__), NumpyStyle)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:03:47.450463
# Unit test for function parse
def test_parse():
    text = '''
    Parameters:
    text: docstring text to parse
    style (str): docstring style
    :returns: parsed docstring representation
    '''
    docstring = parse(text)
    assert(docstring.params[0].arg_name == 'text')
    assert(docstring.params[1].arg_name == 'style')
    assert(docstring.returns.type_name == 'Docstring')
    print('test_parse: pass')


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:03:59.946211
# Unit test for function parse
def test_parse():
    docstring = '''
        This is a docstring. It has two paragraphs.

        It also has a section.
    '''
    doc = parse(docstring)
    assert doc.long_description == 'This is a docstring. It has two paragraphs.'

    docstring = '''
        This is a docstring.

        Parameters
        ----------
        arg1 : int
            The first argument.
        arg2 : str
            The second argument.

        Returns
        -------
        str
            A description of the return value.

        See Also
        --------
        otherfunc : some related other function
    '''

    doc = parse(docstring)
    assert doc.meta['arg1']['type'] == 'int'
    assert doc.meta['arg1']['description'] == 'The first argument.'

# Generated at 2022-06-21 12:04:08.565724
# Unit test for function parse
def test_parse():
    test_inputs = ['text', 'hello world', '']
    test_inputs_style = ['auto', 'numpy', 'google', 'pep257', 'reStructured']
    test_outputs = [Docstring('text'), Docstring('hello world'), Docstring('')]
    for test_input, test_output in zip(test_inputs, test_outputs):
        assert parse(test_input) == test_output
    for test_input in test_inputs_style:
        assert type(parse(test_inputs[0], style=test_input)) == Docstring

# Generated at 2022-06-21 12:04:19.156081
# Unit test for function parse
def test_parse():
    # Test for docstring with specific style
    good_docstring = '''
    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: The return value.
    :raises KeyError: Raises an exception.
    '''
    assert parse(good_docstring, style=Style.numpy).returns == "The return value."
    # Test for docstring annotations
    good_docstring = '''
    :param str param1: The first parameter.
    :param int param2: The second parameter.
    :returns: The return value.
    :rtype: int
    :raises KeyError: Raises an exception.
    '''
    assert parse(good_docstring, style=Style.google).short_description == ""
    # Test for docstring without any style


# Generated at 2022-06-21 12:04:23.973991
# Unit test for function parse
def test_parse():
    texte_base = "test : parametres, nom du  parametre et type du parametre"
    style_base = "Base"
    style = Style[style_base]
    rets = parse(texte_base,style)
    assert rets == texte_base

test_parse()

# Generated at 2022-06-21 12:04:29.066004
# Unit test for function parse
def test_parse():
    test_parse = parse("""
        This is a summary.

        This is a description.

        Parameters:
        a (int): a value
        b (int): b value
        c (int): c value

        Returns:
            int: the sum of a and b

        Raises:
        Exception,AnotherException
        """)
    print(test_parse)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:04:39.406403
# Unit test for function parse
def test_parse():
    """Test case for function parse"""


# Generated at 2022-06-21 12:04:40.653385
# Unit test for function parse
def test_parse():
    # TODO
    pass

# Generated at 2022-06-21 12:04:50.369573
# Unit test for function parse
def test_parse():
    dstr = r'''
    Attributes:
        _f (TYPE): Description of _f.

    Args:
        param1 (TYPE): Description of param1
        param2 (TYPE): Description of param2

    Returns:
        TYPE: Description of return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    '''

    result = parse(dstr, style='pep257')
    print(result.as_text())
    print(result.as_dict())
    print(result.as_obj())


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 12:04:55.006253
# Unit test for function parse
def test_parse():
    text = '''
    Headline
    ---------

    This is an abstract.
    '''

    d = parse(text)
    assert d.short_description == 'Headline'
    assert d.long_description == 'This is an abstract.'


# Generated at 2022-06-21 12:05:06.327710
# Unit test for function parse
def test_parse():
    assert str(parse("Hai")) == str(Docstring(short_description="Hai",
                                                long_description="",
                                                tags=[],
                                                meta={}))
    assert str(parse('Hai\nHow are you')) == str(Docstring(short_description="Hai",
                                                              long_description="How are you",
                                                              tags=[],
                                                              meta={}))
    assert str(parse('Hai : Hai\nHow are you : How')) == str(Docstring(short_description="Hai",
                                                                          long_description="How are you",
                                                                          tags=[],
                                                                          meta={'Hai': 'Hai', 'How are you': 'How'}))