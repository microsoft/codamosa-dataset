

# Generated at 2022-06-21 11:55:16.010706
# Unit test for function parse
def test_parse():
    from pdoc3.utils import parse_cli
    args = parse_cli()
    print(args)
    for name, doc in args.module.doc.objects.items():
        print(doc)
        docstring = parse(doc.docstring)
        print(docstring)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:55:25.868804
# Unit test for function parse
def test_parse():
    """Unit testing method for function parse"""
    a = """\
    first line
    second line

    Multiline description too long to fit
    on one line
    """
    b = """\
    Multiline description too long to fit
    on one line
    """
    c = """\
    first line
    second line

    Multiline description too long to fit
    on one line

    :param str a: a string parameter
    :param int b: an integer parameter

    :return: no return
    """
    d = """\
    first line second line

    :param str a: a string parameter
    :param int b: an integer parameter

    :return: no return
    """

# Generated at 2022-06-21 11:55:37.879662
# Unit test for function parse
def test_parse():
    text1 = '''
    This is the first line.
    This is the second line.
    This is the third line.
    '''
    text2 = '''
    This is the first line.
    This is the second line.
    This is the third line.
    '''
    text3 = '''
    This is the first line.
    This is the second line.
    This is the third line.
    '''
    text4 = 'This is the first line.This is the second line.This is the third line.'
    text5 = 'This is the first line.\nThis is the second line.\nThis is the third line.'
    text = [text1, text2, text3, text4, text5]
    for t in text:
        style = parse(t).style
        print(style)


# Generated at 2022-06-21 11:55:47.844712
# Unit test for function parse
def test_parse():
    # This should be a function for function parse
    example = """\
        This is a docstring.

        :param str param1:
        :param str param2:
        :param int param3:
        :returns:
        """
    # This should be a docstring object
    ret_parse = parse(example)
    assert ret_parse.short_description == 'This is a docstring.'
    assert ret_parse.params == [
        {
            'name': 'param1',
            'type': 'str',
            'desc': None
        },
        {
            'name': 'param2',
            'type': 'str',
            'desc': None
        },
        {
            'name': 'param3',
            'type': 'int',
            'desc': None
        }
    ]
    assert ret

# Generated at 2022-06-21 11:55:59.387747
# Unit test for function parse
def test_parse():
  text = """
This is a docstring for my great function

:param int my_parameter: This is my great parameter.
:returns: this is my great return value.
:raises RuntimeError: if my error occurs.
"""
  
  docstring = parse(text)
  assert(docstring.short_description == 'This is a docstring for my great function')
  assert(docstring.long_description == '')
  assert(len(docstring.meta) == 2)
  assert(docstring.meta[0].name == 'my_parameter')
  assert(docstring.meta[0].type_name == 'int')
  assert(docstring.meta[0].description == 'This is my great parameter.')
  assert(docstring.meta[1].name == 'returns')

# Generated at 2022-06-21 11:56:09.649314
# Unit test for function parse
def test_parse():
    text = '''
This function does something.

:param foo: Foo
:param bar: Bar
:returns: Something'''
    p = parse(text)
    assert p.short_description == 'This function does something.'
    assert p.long_description == ''
    assert p.params[0]['name'] == 'foo'
    assert p.params[0]['description'] == 'Foo'
    assert p.params[1]['name'] == 'bar'
    assert p.params[1]['description'] == 'Bar'
    assert p.returns['description'] == 'Something'



# Generated at 2022-06-21 11:56:17.865178
# Unit test for function parse
def test_parse():
    text = """This function is a function.

    Optional arguments:
        param - this is the first parameter
        param2 - this is the second parameter

    Returns: This is what is returned.
    """

    rets = parse(text)
    assert rets.short_description == 'This function is a function.'
    assert rets.meta['param'] == 'this is the first parameter'
    assert rets.meta['param2'] == 'this is the second parameter'
    assert rets.long_description == ''
    assert rets.returns == 'This is what is returned.'

# Generated at 2022-06-21 11:56:22.725487
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """Test parse.

    This is a test parse with multiple lines
    """
    docstring = parse(text)
    print(docstring.summary)
    print(docstring.description)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:56:28.781633
# Unit test for function parse
def test_parse():
    text = """
    This is a test docstring.

    @param text: docstring text to parse
    @param style: docstring style
    @returns: parsed docstring representation
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == ""
    assert len(docstring.params) == 2
    assert len(docstring.returns) == 1
    assert len(docstring.raises) == 0

    print(docstring)

# Generated at 2022-06-21 11:56:39.420941
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('foo') == Docstring(short_description='foo\n')
    assert parse('foo\nbar') == Docstring(short_description='foo\n',
                                          long_description='bar\n')
    assert parse('foo\n\nbar') == Docstring(short_description='foo\n',
                                            long_description='bar\n')
    assert parse('foo\n\nbar', style=Style.numpy) == Docstring(
        short_description='foo', long_description='bar\n')
    with pytest.raises(ParseError) as excinfo:
        parse('foo\n\nbar', style=Style.google)
    assert str(excinfo.value) == "Short description not found"

# Generated at 2022-06-21 11:56:49.338489
# Unit test for function parse
def test_parse():
    @docstring_parse
    def test_func(aasdf, b=5):
        """Test test
        asdfa
        :param aasdf: aasdfa
        :param b: b asdfa
        :return: returns nothing
        """
        return True

    assert(test_func.__doc__ == test_func.__doc__)

# Generated at 2022-06-21 11:56:57.724699
# Unit test for function parse
def test_parse():
    docstring = "This function parses multi-line docstrings.\n\nArgs:\n    a: 1st argument\n    b: 2nd argument\n    c: 3rd argument\n\nReturns:\n    The sum of all arguments."
    parsed = parse(docstring)
    assert parsed.short_description == "This function parses multi-line docstrings."
    assert len(parsed.long_description) == 0
    assert len(parsed.params['a']) == 1
    assert parsed.params['a'][0] == "1st argument"
    assert len(parsed.params['b']) == 1
    assert parsed.params['b'][0] == "2nd argument"
    assert len(parsed.params['c']) == 1

# Generated at 2022-06-21 11:57:00.180525
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    p = parse("""
    :param a: a
    """)
    assert p.meta["param"]["a"] == "a"

# Generated at 2022-06-21 11:57:09.266550
# Unit test for function parse
def test_parse():
    """Test the parsing of the docstring"""
    text = """This is an example docstring
    
    
    
    
    
    
    
    
    
    
    
    
    :param x: the object to be returned
    :rtype: str

    """

    result = parse(text, style=Style.numpy)
    assert result.short_description == "This is an example docstring"
    assert result.params[0].arg_name == "x"
    assert result.params[0].arg_type == "the object to be returned"
    assert len(result.params) == 1
    assert len(result.returns) == 1


# Generated at 2022-06-21 11:57:21.822086
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import SphinxDocstring
    text = '''Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    r = parse(text)
    assert isinstance(r, SphinxDocstring)
    assert r.summary == 'Parse the docstring into its components.'

# Generated at 2022-06-21 11:57:29.200013
# Unit test for function parse
def test_parse():
    text = """
    A short summary for this function

    Longer description.

    :param a: description for a
    :param b: description for b
    :returns: description for return value
    """
    docstring = parse(text)
    print("summary:", docstring.summary)
    print("long description:", docstring.long_description)
    print("returns:", docstring.returns)
    for p in docstring.params:
        print("parameter:", p.arg_name, p.description)


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:57:34.046770
# Unit test for function parse
def test_parse():
    docstring = '''This is the module docstring.
    This is the second line.'''
    doc = parse(docstring,style=Style.google)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.meta)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:57:46.421895
# Unit test for function parse
def test_parse():
    # If the docstring style is 'auto',
    # the corresponding docstring should be parsed
    docstring = parse("""
    Summary line.

    Extended description.

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

    Attributes:
        attr1 (str): Description of `attr1`.
        attr2 (:obj:`int`, optional): Description of `attr2`.

    Returns:
        bool: Description of return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """)
    assert docstring.summary == "Summary line."
    assert docstring.extended_summary == "Extended description."
   

# Generated at 2022-06-21 11:57:54.125823
# Unit test for function parse
def test_parse():
    # Positive test case
    text = '''\
    hello
    :param time: time in milliseconds
    :type time: int
    :param description: description
    :type description: str
    :param info: info
    :type info: dict'''
    # Parsed dictionary
    look = {'time': 'time in milliseconds', 'description': 'description', 'info': 'info'}
    # Negative test case
    neg_text = '''\
    hello
    :param time: time in milliseconds
    :type time: int
    :param description: description
    :type description: str
    :param info: info
    :type info: dict
    :param al: al
    :type al: int'''

# Generated at 2022-06-21 11:58:03.548546
# Unit test for function parse
def test_parse():
    """docstring for test_parse"""
    text = """\
        summary.

        :arguments:
            first (int): first argument
            second (str): second argument

        :returns:
            str: concatenated string
    """
    docstring = parse(text)
    print(docstring.summary)
    print(docstring.arguments[0].name, docstring.arguments[0].type)
    print(docstring.arguments[1].name, docstring.arguments[1].type)
    print(docstring.returns.type)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:58:22.268587
# Unit test for function parse
def test_parse():
    """Test funcion parse."""
    import pytest

# Generated at 2022-06-21 11:58:33.173634
# Unit test for function parse
def test_parse():
    """Assert that parse works."""

    from docstring_parser.models import META_SECTION_DESCRIPTION_KEY
    from docstring_parser.styles import Style

    docstring = """
        This is a module.

        :param name: name
        :type name: str
        :param value: values
        :type value: int
        :returns: one
        :rtype: int
        """
    expected = Docstring(
        meta={META_SECTION_DESCRIPTION_KEY: "This is a module."},
        params=[
            ("name", "str"),
            ("value", "int")
        ],
        returns=("one", "int")
    )
    assert parse(docstring, Style.numpy) == expected

# Generated at 2022-06-21 11:58:40.032161
# Unit test for function parse
def test_parse():
    text = '''
    Parses a docstring into a metadata dictionary and a trimmed version of
    the contents, suitable for use in a Sphinx field_list.

    :param text: text to be parsed
    :param style: docstring style
    :returns: parsed docstring representation

    :raises ValueError: if style is not one of the supported styles

    Usage:
        >>> from docstring_parser import parse

    '''

# Generated at 2022-06-21 11:58:45.605796
# Unit test for function parse
def test_parse():
    docstring = \
"""Summary line.

Extended description of function.
"""
    result = parse(docstring)
    assert result.summary == 'Summary line.'
    assert result.description == 'Extended description of function.'
    assert result.returns.annotation == 'None'
    assert result.returns.description == None


# Generated at 2022-06-21 11:58:50.519345
# Unit test for function parse
def test_parse():
    docstring = parse('''Args:
    arg1 (str): The first argument.
    arg2 (int): The second argument.
    
Returns:
    bool: The return value. True for success, False otherwise.
    ''')
    assert len(docstring.args) == 2
    


# Generated at 2022-06-21 11:58:54.402221
# Unit test for function parse
def test_parse():
    text = """
    A short summary
    Additional information
    """
    style = Style.goog_style
    assert parse(text, style).short_desc == 'A short summary'
    assert parse(text, style).long_desc == 'Additional information'


# Generated at 2022-06-21 11:59:03.715539
# Unit test for function parse
def test_parse():

        doc1 = """One line summary.
        Extended description.

        Args:
            arg1 (int): Description of arg1
            arg2 (str): Description of arg2
            arg3 (bool): Description of arg3

        Returns:
            bool: Description of return value

        Raises:
            AttributeError: The raised AttributeError
            ValueError: The raised ValueError
        """

        return_value = parse(doc1)
        assert(return_value.short_description == 'One line summary.')

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:59:10.542927
# Unit test for function parse
def test_parse():
    import os
    from glob import glob

    from docstring_parser.common import Docstring, DocstringStyle
    from docstring_parser.styles import STYLES, Style

    def parse(text: str, style: Style = Style.auto) -> Docstring:
        """Parse the docstring into its components.

        :param text: docstring text to parse
        :param style: docstring style
        :returns: parsed docstring representation
        """

        if style != Style.auto:
            return STYLES[style](text)
        rets = []
        for parse_ in STYLES.values():
            try:
                rets.append(parse_(text))
            except ParseError as e:
                exc = e
        if not rets:
            raise exc

# Generated at 2022-06-21 11:59:15.791508
# Unit test for function parse
def test_parse():
    # Create a text for testing
    text = 'Hello!\n\nSome\nlong\ndescription.'
    # Create a docstring object from text
    doc_string = parse(text)
    # Test short description
    assert doc_string.short_description() == 'Hello!'
    # Test long description
    assert doc_string.long_description() == 'Some\nlong\ndescription.'

# Test function test_parse
# test_parse()

# Generated at 2022-06-21 11:59:21.391754
# Unit test for function parse
def test_parse():
    d = parse('''
        :param str name: The name to say hello to
        :returns: The combined name
        :raises TypeError: If `name` is not a string
    ''')
    assert d.params['name'].arg_type == 'str'
    assert d.returns.arg_type == 'The combined name'
    assert d.raises['TypeError'].arg_type == 'If `name` is not a string'


# Generated at 2022-06-21 11:59:34.118340
# Unit test for function parse
def test_parse():
    d = parse('\n:param test: test\n:type test: str\n:returns: description\n:rtype: str\n')
    assert d.short_description == ""
    assert d.long_description == ""
    assert d.params[0].arg_name == 'test'
    assert d.params[0].description == 'test'
    assert d.params[0].type_name == 'str'
    assert d.returns.description == 'description'
    assert d.returns.type_name == 'str'


__all__ = ('parse',)

# Generated at 2022-06-21 11:59:38.398614
# Unit test for function parse
def test_parse():
    """Test if I can parse a string"""
    text = "This is the docstring"
    style = Style.google
    d = parse(text, style)
    print(d)

if __name__ == "__main__":
    test_parse()



# Generated at 2022-06-21 11:59:49.071858
# Unit test for function parse
def test_parse():
    assert parse("") is None
    doc = parse("Hello\n\nThis is a long description\nover two lines")
    assert doc.short_description == "Hello"
    assert doc.long_description == "This is a long description over two lines"
    doc = parse("Hello\n\nThis is a long description over two lines")
    assert doc.short_description == "Hello"
    assert doc.long_description == "This is a long description over two lines"
    doc = parse("Hello\n\nThis is a long description over two lines\n\nAnd a final third paragraph")
    assert doc.short_description == "Hello"
    assert doc.long_description == "This is a long description over two lines\n\nAnd a final third paragraph"

# Generated at 2022-06-21 11:59:52.608839
# Unit test for function parse
def test_parse():
    text = '''"Test string for parse()"'''
    style = Style.auto
    parse_ = parse(text, style)
    assert parse_

# test_parse()


# Generated at 2022-06-21 11:59:57.376324
# Unit test for function parse
def test_parse():
    assert parse("").__class__ == Docstring
    assert parse("none").__class__ == Docstring
    assert parse("None").__class__ == Docstring
    assert parse(None).__class__ == Docstring


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:05.383460
# Unit test for function parse
def test_parse():
    text = '''
    This is the usecase to calculate addition of two numbers

    :param num1: first number
    :type num1: integer
    :param num2: second number
    :type num2: integer
    :example:
        doctest.testmod()
    :return: sum of two numbers
    :rtype: integer
    '''
    doc = parse(text, style=Style.google)
    print(doc.short_description)
    print(doc.long_description)

    for arg in doc.args:
        print(arg.arg_name)
    for ret in doc.returns:
        print(ret.type_name)

# Generated at 2022-06-21 12:00:12.102573
# Unit test for function parse
def test_parse():
    """The main parsing routine."""
    assert parse("") == parse("", style=Style.numpy)
    assert parse("") == parse("", style=Style.google)

    # assert parse("", style=Style.numpy).meta == {}
    # assert parse("", style=Style.google).meta == {}


if __name__ == "__main__":
    print(parse(""))

# Generated at 2022-06-21 12:00:19.530591
# Unit test for function parse
def test_parse():
    from docstring_parser import parse
    from docstring_parser.common import Docstring, Parameter, ReturnValue


# Generated at 2022-06-21 12:00:30.102251
# Unit test for function parse
def test_parse():
    d = r"""
    Run a program to calculate K.

    :param int size: number of molecules
    :param str filename: output file (default: ``'out.txt'``)
    :returns: K value
    :rtype: float
    """
    dd = parse(d)

# Generated at 2022-06-21 12:00:40.289990
# Unit test for function parse
def test_parse():

    text = '''
    Test function.

    :param array: The array.
    :param new_array: The new array.
    :returns: The description.

    .. code-block:: python

        print "Hello, world!"
    '''

    desc = parse(text)

    assert desc.short_description == 'Test function.'
    assert 'The array.' == desc.params['array']
    assert 'The new array.' == desc.params['new_array']
    assert 'The description.' == desc.returns
    assert 'print "Hello, world!"' == desc.content[0].source_code

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:00:56.108821
# Unit test for function parse
def test_parse():
    example = """Summary line here.

The summary line may be on the first line or the second line.

This is the first paragraph of the docstring.  Paragraphs are separated by
a blank line.

Optional arguments:
arg1 -- An integer argument (default: 42)
arg2 -- A string argument (default: 'foobar')
arg3 -- A list argument (default: ['one', 'two', 'three'])

You may also include
some *bold* text,
or a *bold* control
with *bold*, or _italic_ text.
"""
    d = parse(example)

    assert d.code_block is None
    assert d.end_marker == ''
    assert d.summary == 'Summary line here.'

# Generated at 2022-06-21 12:01:07.467841
# Unit test for function parse
def test_parse():
    text = '''An example docstring.
    
    :param name: A name. Required.
    :type name: str
    :param age: An age. Default 20.
    :type age: int
    :param line: A line. Default None.
    :type line: str
    :returns: A string representation of the name and age.
    :raises ValueError: If age is less than 0.
    '''

    d = parse(text)
    assert d.short_description == 'An example docstring.'
    assert 'a string representation' in d.long_description.lower()
    assert len(d.params) == 3
    assert d.params['name'].required
    assert not d.params['age'].required
    assert d.params['age'].default == 20

# Generated at 2022-06-21 12:01:11.713870
# Unit test for function parse
def test_parse():
    text='''
    Parse the docstring into its components.

    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    '''
    style = Style.auto
    print('Result:',parse(text,style))

# Generated at 2022-06-21 12:01:21.479837
# Unit test for function parse
def test_parse():
    t1 = """
    Description
    -----------
    Do the thing that foo does, but better.

    Parameters
    ----------
    a: str
        First parameter.
    b: int
        Second parameter.

    Returns
    -------
    str
        A formatted string.

    Examples
    --------
    >>> foo()
    'bar'
    """

    t2 = """
    Description
    -----------
    Do the thing that foo does, but better.

    :param a: First parameter.
    :type a: str

    :param b: Second parameter.
    :type b: int

    :returns: A formatted string.
    :rtype: str
    """


# Generated at 2022-06-21 12:01:27.973821
# Unit test for function parse
def test_parse():
    doc = """
    Normal Text
    """
    assert parse(doc).short_description == "Normal Text"

    doc = """
    Normal Text
    """
    assert parse(doc, style=Style.default).short_description == ""
    

###############################################################################

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_parse()

# Generated at 2022-06-21 12:01:33.186294
# Unit test for function parse
def test_parse():
    docstr = """
        A sample docstring.

        :param int foo: some parameter
        :returns: a nice string
        """
    result = parse(docstr)
    assert result.short_description == "A sample docstring."
    assert len(result.long_description) == 0
    assert len(result.meta) == 2
    assert len(result.meta[0]['args']) == 1
    assert result.meta[0]['args'][0] == 'int foo'
    assert result.meta[1]['returns'] == 'a nice string'

    # Test that if there are multiple styles in the docstring, the most
    # complete one is selected.
    docstr = """
        A sample docstring.

        :param int foo: some parameter
        :returns: a nice string
        """
    result

# Generated at 2022-06-21 12:01:36.343619
# Unit test for function parse
def test_parse():
    """Test parse"""
    assert parse("""The main parsing routine.""")
    assert parse("""The main parsing routine.""", Style.auto)


# Generated at 2022-06-21 12:01:44.780787
# Unit test for function parse
def test_parse():
    single_class_docstring = '''An example class.

Example:
    >>> from test.common import Test
    >>> test = Test(1)
    >>> test.foo()
    1

Args:
    foo: some argument

Attributes:
    bar (int): an internal counter
    something (:obj:`list` of :obj:`int`): list of some numbers

'''
    ret = parse(single_class_docstring)
    assert len(ret.meta) == 3
    assert len(ret.content) == 5
    assert ret.meta[0].name == 'Args'
    assert ret.meta[0].arguments == [('foo', 'some argument')]
    assert ret.meta[1].name == 'Attributes'

# Generated at 2022-06-21 12:01:47.395865
# Unit test for function parse
def test_parse():
    import os
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)

# Command-line interface

# Generated at 2022-06-21 12:01:57.342091
# Unit test for function parse
def test_parse():
    """tests the function parse()"""
    assert parse("") == Docstring("", "", "")
    assert parse("one") == Docstring("one", "", "")
    assert parse("one two three") == Docstring("one two three", "", "")
    assert parse("one\ntwo\n") == Docstring("one\ntwo\n", "", "")
    assert parse("one\ntwo\n\n") == Docstring("one\ntwo\n", "", "")
    assert parse("one\ntwo\n\nthree") == Docstring("one\ntwo", "", "three")
    assert parse("one\ntwo\n\nthree\nfour\n\n") == Docstring("one\ntwo", "", "three\nfour\n")

# Generated at 2022-06-21 12:02:02.998631
# Unit test for function parse
def test_parse():
    """Test function parse."""

    te

# Generated at 2022-06-21 12:02:07.237424
# Unit test for function parse
def test_parse():
    docstring = """
    :param text: docstring text to parse
    :param style: docstring style
    :returns: parsed docstring representation
    """
    x=parse(docstring)
    assert x.meta['param'][0].description=='docstring text to parse'
    assert x.meta['return'][0].description=='parsed docstring representation'


# Generated at 2022-06-21 12:02:08.928728
# Unit test for function parse
def test_parse():
   text="""
        A docstring
        """
   parse(text)

# Generated at 2022-06-21 12:02:11.578296
# Unit test for function parse
def test_parse():
    text = "This is a test"
    parsed_text = parse(text)
    assert parsed_text.summary == "This is a test"
    assert parsed_text.args == []

# Generated at 2022-06-21 12:02:18.468407
# Unit test for function parse
def test_parse():
    text = """
    This is a single-line summary.

    This is a longer description that can span multiple lines.

    :param x: foo
    :type x: int.
    :param y: bar
    :type y: str.
    :returns: baz
    :rtype: float.
    """
    docstring = parse(text)
    print("Summary: {}".format(docstring.short_desc))
    print("Description: {}".format(docstring.long_desc))
    print("Params: {}".format(" ".join(str(p) for p in docstring.params)))
    print("Returns: {}".format(docstring.returns))
    print("Raises: {}".format(" ".join(str(r) for r in docstring.raises)))

# Generated at 2022-06-21 12:02:30.107842
# Unit test for function parse
def test_parse():
    text = '''Func with a docstring
      
    Args:
       arg1: The first argument.
       arg2 (str): The second argument.
    
    Returns:
       bool: The return value. True for success, False otherwise.

    Raises:
       AttributeError: The ``Raises`` section is a list of all exceptions
           that are relevant to the interface.
       ValueError: If `param2` is equal to `param1`.
    '''
    docstring = parse(text)
    assert docstring.short_description == 'Func with a docstring'
    assert docstring.long_description == ''
    assert len(docstring.params) == 2
    assert docstring.params[0].arg_name == 'arg1'
    assert docstring.params[0].type_name == None
    assert doc

# Generated at 2022-06-21 12:02:37.382304
# Unit test for function parse
def test_parse():
    text1 = '''
            This is a function that counts the number of times
            each letter in the alphabet occurs in a given string.

            :param str text: a string to process
            :returns: a dictionary with every letter of the alphabet as a key
                      and the number of times it occurs in the string as a value
            :rtype: dict
            '''
    text2 = '''
            This is another docstring

            :param str text: a string to process
            :returns: a dictionary with every letter of the alphabet as a key
                      and the number of times it occurs in the string as a value
            :rtype: dict
            '''

# Generated at 2022-06-21 12:02:46.677597
# Unit test for function parse
def test_parse():
    text = '''
    A simple test.

    :param x: What is x.
    :type x: str
    :returns: blah blah blah
    '''
    d = parse(text)
    assert d.summary == 'A simple test.'
    assert d.description == ''
    assert d.meta['parameters']['x'].description == 'What is x.'
    assert d.meta['parameters']['x'].type_name == 'str'
    assert d.meta['returns'].type_name == ''
    assert d.meta['returns'].description == 'blah blah blah'


# Generated at 2022-06-21 12:02:57.772342
# Unit test for function parse
def test_parse():

    # Check simple one-line summary.
    text = 'This is a summary.'
    docstring = parse(text)
    assert docstring.summary == text[:-1]

    # Check simple one-line descriptions.
    text = 'This is a description.'
    docstring = parse(text)
    assert docstring.description == text

    # Check that sections are successfully parsed from a multiline docstring.
    text = """This is a summary.

This is a description.

This is a description that spans multiple lines.

This is a description that spans multiple
lines.

:param int param: This is a parameter.
:param callable func: This is a function.
:returns: This is a return
:raises TypeError: This is a raised exception.
"""
    docstring = parse(text)

# Generated at 2022-06-21 12:03:05.007161
# Unit test for function parse
def test_parse():
    assert parse("") == \
        Docstring(summary='', description='', meta={})
    assert parse('Hello\nWorld!', style=Style.reST) == \
        Docstring(summary='Hello', description='World!', meta={})
    assert parse('Hello\nWorld!\n:param x: A parameter') == \
        Docstring(summary='Hello', description='World!', meta={'param x': 'A parameter'})

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:03:20.374740
# Unit test for function parse
def test_parse():
    from .common import ParseError
    from .styles import Style
    from .utils import tests_root
    import json
    import os

    style = Style.auto
    input_file = os.path.join(tests_root, 'input.py')
    expected_file = os.path.join(tests_root, 'expected.json')
    with open(input_file) as f:
        source = f.read()
    with open(expected_file) as f:
        expected = json.load(f)

    docstring = parse(source, style)

    assert isinstance(docstring, dict)

    docstring.pop('__module__')
    expected.pop('__module__')
    assert len(docstring.keys()) == len(expected.keys())

# Generated at 2022-06-21 12:03:26.448652
# Unit test for function parse
def test_parse():
    text = """  This is a function that
        does something.
 
        Args:
          arg1: The first argument.
          arg2: The second argument.
        Returns:
          One or more values.
 
        Raises:
          KeyError: Raises an exception.
    """
    print(parse(text,style=Style.auto))
    
test_parse()

# Generated at 2022-06-21 12:03:28.953688
# Unit test for function parse
def test_parse():
    assert parse('Test')
    assert parse('')
    # assert parse(1)



# Generated at 2022-06-21 12:03:35.892900
# Unit test for function parse
def test_parse():
    docstring = """Single-line
    multi-line docstring."""
    assert parse(docstring) == Docstring(
        description='Single-line\nmulti-line docstring.',
        metadata={}
    )

    docstring = """Single-line
        multi-line
        docstring.

        Arguments:

        Returns:
    """
    assert parse(docstring) == Docstring(
        description='Single-line\nmulti-line\ndocstring.\n',
        metadata={"Arguments": '', 'Returns': ''}
    )

    docstring = """Single-line
        multi-line
        docstring.

        Args:

        Returns:
    """

# Generated at 2022-06-21 12:03:42.589436
# Unit test for function parse
def test_parse():
    from docstring_parser.styles import NumpyStyle
    s = """
    One line summary.
    
    Extended description.
    
    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`
    Returns
    -------
    int
        Description of return value
    """
    d = parse(s)
    assert isinstance(d, NumpyStyle)

# Generated at 2022-06-21 12:03:54.496628
# Unit test for function parse
def test_parse():
    docstring_test_1 = """
        Function to test if the function parse of docstring parser works.
    """
    docstring_test_2 = """
        Function to test if the function parse of docstring parser works.
        :param name: Name of the person
        :type name: str
    """
    docstring_test_3 = """
        Function to test if the function parse of docstring parser works.
        :param name: Name of the person
        :type name: str
        :returns: None
    """
    docstring_test_4 = """
        Function to test if the function parse of docstring parser works.
        :param name: Name of the person
        :type name: str
        :returns: None
        :raises ValueError: If the value is less then zero
    """
    docstring_test_5

# Generated at 2022-06-21 12:03:57.463928
# Unit test for function parse
def test_parse():
    text = """
    Foo bar baz.
    :param int a: integer value
    :param str b: string value
    :returns: tuple
    """
    assert isinstance(parse(text), Docstring)

# Generated at 2022-06-21 12:04:04.442187
# Unit test for function parse
def test_parse():
    class Test:
        def __init__(self, arg1):
            """
            This is a constructor

            :param arg1: description
            """
            pass


    docstring = parse(Test.__init__.__doc__)
    assert str(docstring.summary) == "This is a constructor"
    assert str(docstring.meta['arg1']) == "description"
    assert len(docstring.meta) == 1



# Generated at 2022-06-21 12:04:13.164951
# Unit test for function parse
def test_parse():
    text = """Example function with types documented in the docstring
    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.
    Returns:
        bool: The return value. True for success, False otherwise.
    """

    doc = parse(text)
    assert doc.short_description == "Example function with types documented in the docstring"
    assert len(doc.long_description) == 1
    assert doc.long_description[0] == "    Args:"
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == "param1"
    assert doc.params[0].type_name == "int"
    assert doc.params[0].description == "The first parameter."
    assert doc.params[1].arg_name == "param2"
   

# Generated at 2022-06-21 12:04:24.760492
# Unit test for function parse
def test_parse():
    """Test parsing of docstring for function parse."""

    from os import path
    doc = parse(open(path.join(path.dirname(__file__),
                               '../tests/fixtures/function_parse.py')).read())

    assert doc.summary == 'Parses docstrings into its components.'
    assert doc.body == 'If the style is not given, this tries to detect it.\n'
    assert doc.returns.type_name == 'parsed docstring representation'
    assert len(doc.params) == 2
    assert doc.params[0].arg_name == 'text'
    assert doc.params[0].type_name == 'str'
    assert doc.params[0].description == 'docstring text to parse'
    assert doc.params[1].arg_name == 'style'

# Generated at 2022-06-21 12:04:39.513022
# Unit test for function parse
def test_parse():
    test_docstring = """
    This is the first line!
    The second line!
    The third line!

    :parameter this_is_first: This is the first parameter.
    :parameter this_is_second: This is the second one.
    :parameter this_is_third: This is the third one.
    :return: This is the return.
    """
    assert parse(test_docstring).short_description == 'This is the first line!'

    test_docstring1 = """
    This is called simple.
    Next Line?
    """
    assert parse(test_docstring1).short_description == 'This is called simple.'

    test_docstring2 = """
    This is called simple.
    Next Line?
    :return: This is the return.
    """

# Generated at 2022-06-21 12:04:47.329435
# Unit test for function parse
def test_parse():
    d = """Summary line.

This is a longer description. It may contain multiple paragraphs.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`

Returns
-------
bool
    Description of return value

"""
    doc = parse(d)
    doc2 = parse(doc.dump())
    assert doc.summary == doc2.summary
    assert doc.description == doc2.description
    assert doc.meta == doc2.meta
    assert doc.returns == doc2.returns

# Generated at 2022-06-21 12:04:52.922199
# Unit test for function parse
def test_parse():
    from textwrap import dedent
    import re
    y = dedent("""
    y = 3*x
        """).strip()
    class_ = dedent("""
    class Foo:
        "hello world!"
        def __init__(self):
            pass
        def foo():
            "hello world!"
            pass
        """).strip()
    for func, string in zip([parse, parse], [y, class_]):
        x = func(string)
    return x
if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 12:05:04.546144
# Unit test for function parse
def test_parse():
    text = """ A simple example

        :param min_size:
            description header

            description
        :return:
            description header

            description
    """
    style = Style.google
    docstring = parse(text, style)
    assert docstring.short_description == 'A simple example'
    assert len(docstring.long_description) == 2

    assert docstring.returns.name == 'return'
    assert docstring.returns.type_name == ''
    assert docstring.returns.desc_header == 'description header'
    assert docstring.returns.desc == 'description'

    param = docstring.params['min_size']
    assert param.name == 'min_size'
    assert param.type_name == ''
    assert param.desc_header == 'description header'