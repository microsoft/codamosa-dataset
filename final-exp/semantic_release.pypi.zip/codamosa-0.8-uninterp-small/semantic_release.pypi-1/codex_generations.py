

# Generated at 2022-06-26 01:28:42.656137
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)



# Generated at 2022-06-26 01:28:46.293797
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # We are using the following parameters:
    # path = "dist"
    # skip_existing = False
    # glob_patterns = None
    assert upload_to_pypi("dist", False, None) == None, "TestCase 0 failed"

# Generated at 2022-06-26 01:28:48.084091
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-26 01:28:50.850668
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os.path
    assert os.path.isfile(os.path.join(os.path.dirname(__file__), 'setup.py'))
    test_case_0()

# Generated at 2022-06-26 01:28:52.270821
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    assert True == True

# Generated at 2022-06-26 01:28:57.764137
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = ''
    skip_existing = ''
    glob_patterns = ''
    var_0 = upload_to_pypi(
        path=path,
        skip_existing=skip_existing,
        glob_patterns=glob_patterns
    )
    # assert var_0 == expected
    # assert var_0 == expected
    # assert var_0 == expected



# Generated at 2022-06-26 01:28:59.924620
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = None

    test_case_0()


# Generated at 2022-06-26 01:29:04.154635
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path='dist'
    skip_existing=False
    glob_patterns=['*']
    var_0 = upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)
    assert var_0 is None

# Generated at 2022-06-26 01:29:13.217998
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    print("Testing upload_to_pypi")
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_to_pypi() == None
    assert upload_

# Generated at 2022-06-26 01:29:16.127090
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-26 01:29:23.845707
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        tester = upload_to_pypi
    except:
        print(">>>Failed upload_to_pypi")
        return 0
    else:
        print(">>>Success upload_to_pypi")
        return 1

# Generated at 2022-06-26 01:29:26.786479
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Write a unit test for this function
    pass



if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:29:33.372400
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import pytest
    import tempfile
    import shutil
    import subprocess

    from semantic_release.upload_to_pypi import upload_to_pypi

    def twine_upload_mock(*args, **kwargs):
        assert args[0] == "twine upload", "generate command to upload with twine"
        return args, kwargs

    tempdir = tempfile.TemporaryDirectory()
    distdir = os.path.join(tempdir.name, "dist")
    os.makedirs(distdir)

# Generated at 2022-06-26 01:29:44.146033
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = os.environ.get("PYPI_TOKEN", "")
    assert var_0 == ""
    var_0 = os.environ.get("PYPI_USERNAME", "")
    assert var_0 == ""
    var_0 = os.environ.get("PYPI_PASSWORD", "")
    assert var_0 == ""
    var_0 = upload_to_pypi.__name__
    assert var_0 == "upload_to_pypi"
    var_0 = upload_to_pypi.__qualname__
    assert var_0 == "upload_to_pypi"
    var_0 = upload_to_pypi.__doc__

# Generated at 2022-06-26 01:29:53.780408
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path_1 = "dist"

    try:
        upload_to_pypi(path=path_1)
    except Exception as e:
        print(e)
        assert False
    
    path_2 = "dist"
    skip_existing_2 = bool()
    glob_patterns_2 = list()

    try:
        upload_to_pypi(path=path_2, skip_existing=skip_existing_2, glob_patterns=glob_patterns_2)
    except Exception as e:
        print(e)
        assert False
    
    path_3 = "dist"
    skip_existing_3 = bool()
    glob_patterns_3 = list()


# Generated at 2022-06-26 01:29:59.207104
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "test_PYPI_USERNAME"
    os.environ["PYPI_PASSWORD"] = "test_PYPI_PASSWORD"
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]

    var_0 = upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-26 01:30:03.809634
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert callable(upload_to_pypi)
    except:
        print("Function \'upload_to_pypi\' not defined\n")
    try:
        upload_to_pypi()
    except:
        print("Function \'upload_to_pypi\' failed")
    else:
        print("Function \'upload_to_pypi\' executed without error")

# Generated at 2022-06-26 01:30:08.354377
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)
    try:
        upload_to_pypi()
        assert False, 'Expected exception of type ImproperConfigurationError'
    except ImproperConfigurationError as e:
        # The exception of type ImproperConfigurationError is expected
        pass

# Generated at 2022-06-26 01:30:11.473834
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import mock
    import tempfile

    with mock.patch('os.getcwd', lambda: tempfile.gettempdir()):
        assert upload_to_pypi() == None



# Generated at 2022-06-26 01:30:13.755535
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert upload_to_pypi
    except NameError:
        assert False, "upload_to_pypi not defined"

# Generated at 2022-06-26 01:30:20.700545
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except SystemExit:
        assert True

# Coverage for function upload_to_pypi

# Generated at 2022-06-26 01:30:27.198940
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    skip_existing = True
    glob_patterns = ["*"]
    if type(skip_existing) is str:
        skip_existing = True # don't know how to handle string input
        print(">>> WARNING: Converted automatic input to True for parameter skip_existing...")
    if type(glob_patterns) is str:
        glob_patterns = ["*"] # don't know how to handle string input
        print(">>> WARNING: Converted automatic input to ['*'] for parameter glob_patterns...")
    path = ""
    # Calling upload_to_pypi(path, skip_existing, glob_patterns)
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-26 01:30:30.256036
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = [
        "*",
    ]

    assert_equal(upload_to_pypi(path, skip_existing, glob_patterns), )

# Generated at 2022-06-26 01:30:31.253054
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-26 01:30:40.985122
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import os
    import mock
    
    # Prepare test environment
    # Preserve cwd and sys.path
    pwd = os.getcwd()
    paths = list(sys.path)
    
    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Temporary paths
    scripts_path = os.path.join(tmp_dir, 'scripts')
    # Create temporary directory structure
    os.makedirs(scripts_path)
    
    # Change path to match temporary directory structure for imports
    sys.path.append(tmp_dir)
    os.chdir(scripts_path)
    

# Generated at 2022-06-26 01:30:48.341788
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # test case 0
    path_of_dist = "dist"
    file_name = None
    var_0 = upload_to_pypi(path_of_dist)
    assert var_0 is None

    # test case 1
    path_of_dist = "dist"
    file_name = None
    var_1 = upload_to_pypi(path_of_dist)
    assert var_1 is None

    # test case 2
    path_of_dist = "dist"
    file_name = None
    var_2 = upload_to_pypi(path_of_dist)
    assert var_2 is None

# Generated at 2022-06-26 01:30:52.611229
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if not os.path.exists('/Users/apple/.semantic-release/'):
        os.makedirs('/Users/apple/.semantic-release/')

# Generated at 2022-06-26 01:30:53.950585
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("path") == None



# Generated at 2022-06-26 01:30:54.917386
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() is None

# Generated at 2022-06-26 01:31:01.201175
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert callable(upload_to_pypi)
    except AssertionError as e:
        raise(e)

    try:
        test_case_0()
    except Exception as e:
        logger.critical(
            "Test case 0 of function upload_to_pypi failed:\n{e}"
            .format(e = e)
        )


# vim: set filetype=python ts=4 sw=4 tw=0 et :

# Generated at 2022-06-26 01:31:10.823177
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = upload_to_pypi()

# Generated at 2022-06-26 01:31:17.634168
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        path = "./test"
        skip_existing = True
        glob_patterns = "dummy"
        test_case_0()
        assert True
    except (AssertionError, ImproperConfigurationError) as e:
        assert False
    except Exception as e:
        assert True

# Generated at 2022-06-26 01:31:18.675699
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False



# Generated at 2022-06-26 01:31:23.623219
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except Exception:
        assert False
    else:
        assert True


# Testing with Pytest module
# pytest -v -s ../../tests/vcs_git/test_helpers.py

# Generated at 2022-06-26 01:31:27.551587
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)


    # Call upload_to_pypi
    upload_to_pypi()

    # Call upload_to_pypi
    upload_to_pypi()

# Generated at 2022-06-26 01:31:30.058425
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert callable(upload_to_pypi)
    except NameError:
        assert False

    assert True


# Generated at 2022-06-26 01:31:30.991625
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-26 01:31:41.389528
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    # Path to dist folder containing the files to upload.
    var_1 = upload_to_pypi(path)

    skip_existing = False
    # Continue uploading files if one already exists.
    # (Only valid when uploading to PyPI. Other implementations may not support this.)
    var_2 = upload_to_pypi(path, skip_existing)

    glob_patterns = ["*"]
    # List of glob patterns to include in the upload (["*"] by default).
    var_3 = upload_to_pypi(path, skip_existing, glob_patterns)


if __name__ == "__main__":
    test_case_0()
    test_upload_to_pypi()

# Generated at 2022-06-26 01:31:42.946568
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)


# Generated at 2022-06-26 01:31:48.129162
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_1 = "d2JjLW5vcnRoYW5nYW4tY3VybC1wb3dhcmUucGx1Z2luLnNvdXJjZS5jb25maWc="
    var_2 = UploadToPyPI(var_1)
    assert var_2

# Generated at 2022-06-26 01:32:15.526310
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = None

    mock_run = Mock(return_value=None)
    with patch("invoke.run", new=mock_run):
        with patch("semantic_release.uploaders.pypi.os") as mock_os:
            mock_os.environ = {"PYPI_TOKEN": "test"}
            upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)
            mock_run.assert_called_once_with("twine upload -u '__token__' -p 'test' __token__")

# Generated at 2022-06-26 01:32:25.953099
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi), "Function does not exist"

    # Test 1
    try:
        upload_to_pypi(
            path="dist", skip_existing=False, glob_patterns=["*"]
        )

    except Exception:
        assert False, "Function raised Exception unexpectedly"

    # Test 2
    try:
        upload_to_pypi(
            path="dist", skip_existing=False, glob_patterns=["*"]
        )

    except Exception:
        assert False, "Function raised Exception unexpectedly"

    # Test 3
    try:
        upload_to_pypi(
            path="dist", skip_existing=False, glob_patterns=["*"]
        )

    except Exception:
        assert False, "Function raised Exception unexpectedly"

    # Test 4


# Generated at 2022-06-26 01:32:30.914059
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path_var = "path var"
    skip_existing_var = "skip existing var"
    glob_patterns_var = "glob patterns var"

    var_0 = upload_to_pypi(path=path_var, skip_existing=skip_existing_var, glob_patterns=glob_patterns_var)

    assert True


# Unit tests for function upload_to_pypi

# Generated at 2022-06-26 01:32:41.804792
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]

    # Test for correct operation of function when there is an existing PyPI token.
    os.environ["PYPI_TOKEN"] = "pypi-token"

    # Test for correct operation of function when there are missing credentials.
    assert "PYPI_TOKEN" in os.environ
    os.environ.pop("PYPI_TOKEN")
    try:
        upload_to_pypi(path, skip_existing, glob_patterns)
        assert False
    except Exception as e:
        assert type(e) == ImproperConfigurationError
        assert str(e) == "Missing credentials for uploading to PyPI"

    # Test for correct operation of function when there is an existing PyPI username.
    os.environ

# Generated at 2022-06-26 01:32:51.429054
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Setup
    import tempfile
    import os
    import shutil
    import glob
    import semantic_release.tests
    config["repository"] = "test"
    config["dry_run"] = False
    config["keep_changelog"] = False
    config["dry_run"] = False
    tmp_dir = tempfile.mkdtemp()
    os.makedirs(tmp_dir + "/dist")
    shutil.copyfile(semantic_release.tests.__file__, tmp_dir + "/dist/wheel.whl")
    assert (
        glob.glob(tmp_dir + "/dist/wheel.whl")
    ), "Failed to prepare files for unit test"

    # Execute function

# Generated at 2022-06-26 01:33:01.143802
# Unit test for function upload_to_pypi

# Generated at 2022-06-26 01:33:03.812848
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set up test values

    # Invoke the function
    upload_to_pypi()

    # Check the result
    assert True == True

# Generated at 2022-06-26 01:33:06.897468
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = upload_to_pypi(skip_existing=False, glob_patterns=[])
    var_1 = upload_to_pypi(skip_existing=True, glob_patterns=["foo"])

# Generated at 2022-06-26 01:33:09.085252
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = None

    # Configure the parameters and expecte

# Generated at 2022-06-26 01:33:14.034038
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # mock

    # record
    try:
        result = upload_to_pypi()
        assert result is None
    except Exception as e:
        assert False

    # reset
    var_0 = None
    if var_0 is not None:
        var_0.ungettext.reset_mock()


# vim: set ai et ts=4 sw=4:

# Generated at 2022-06-26 01:33:57.538589
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch.object(logging, 'debug') as mock_debug:
        with patch.object(logging, 'warning') as mock_warning:
            with patch.object(invoke, 'run') as mock_run:
                var_0 = upload_to_pypi()
                mock_debug.assert_called_once_with("Calling upload_to_pypi")
                mock_warning.assert_not_called()
                mock_run.assert_not_called()
                assert var_0 == None


# Generated at 2022-06-26 01:34:01.029059
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert callable(upload_to_pypi)
    except AssertionError as e:
        print("Cannot use function upload_to_pypi")
        print(e)
        assert False


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 01:34:02.136884
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    globals(test_case_0.__name__)

# Generated at 2022-06-26 01:34:12.177596
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_1 = os.environ
    var_1 = os.environ
    var_1 = os.environ
    var_2 = os.environ
    var_3 = os.environ
    var_1 = os.environ
    var_1 = os.environ
    var_2 = os.environ
    var_1 = os.environ
    var_1 = os.environ
    var_2 = os.environ
    var_1 = os.environ
    var_1 = os.environ
    var_2 = os.environ
    var_1 = os.environ
    var_1 = os.environ
    var_1 = os.environ
    var_1 = os.environ
    var_2 = os.environ
    var_1 = os.environ

# Generated at 2022-06-26 01:34:13.496099
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = upload_to_pypi()
    assert var_0 is None

# Generated at 2022-06-26 01:34:20.130471
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create mock object
    config.set_config({
    'repository': "config_value",
    'pypi': {
        'repository': "pypi_value",
    }
    })

    var_0 = upload_to_pypi()

# Generated at 2022-06-26 01:34:24.457374
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set up test case inputs
    path = "test_path"
    skip_existing = True
    glob_patterns = ["test_glob_patterns"]

    # Call the function
    var_0 = upload_to_pypi(path, skip_existing, glob_patterns)

    # Check the results
    assert var_0 == None

# Generated at 2022-06-26 01:34:30.672212
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Test case for function upload_to_pypi

# Generated at 2022-06-26 01:34:40.183634
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    res_0 = -1
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        res_0 = str(e)
    assert 'PyPI token should begin with "pypi-"' in res_0

    res_1 = -1
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        res_1 = str(e)
    assert 'Missing credentials' in res_1

    res_2 = -1
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        res_2 = str(e)
    assert 'Missing credentials' in res_2

# Generated at 2022-06-26 01:34:44.348182
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi("a",False, ["a","b"])
    except Exception as e:
        assert type(e) == ImproperConfigurationError
    try:
        upload_to_pypi("a",False)
    except Exception as e:
        assert type(e) == RuntimeError

# Generated at 2022-06-26 01:36:00.627210
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert callable(upload_to_pypi)
    except AssertionError as e:
        raise(e)

    # Call the function
    test_case_0()

# vim: syntax=python.legacy.backport

# Generated at 2022-06-26 01:36:04.779202
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = "dist"  # type: str
    var_1 = False  # type: bool
    var_2 = ["*"]  # type: List[str]
    assert True == False  # TypeError: unorderable types: str() > bool()

# Generated at 2022-06-26 01:36:12.201398
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = None
    assert upload_to_pypi(path, skip_existing, glob_patterns) == None
    path = "dist"
    skip_existing = False
    glob_patterns = None
    assert upload_to_pypi(path, skip_existing, glob_patterns) == None

# Generated at 2022-06-26 01:36:16.030755
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path="dist"
    skip_existing=True
    glob_patterns=["*"]
    var_0 = upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-26 01:36:29.002973
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = None
    var_0 = upload_to_pypi(
        path, skip_existing, glob_patterns
    )
    assert var_0 == None

    path = "dist"
    skip_existing = False
    glob_patterns = "*"
    var_0 = upload_to_pypi(
        path, skip_existing, glob_patterns
    )
    assert var_0 == None

    path = "dist"
    skip_existing = False
    glob_patterns = "*.whl"
    var_0 = upload_to_pypi(
        path, skip_existing, glob_patterns
    )
    assert var_0 == None

    path = "dist"
    skip_existing = False
    glob

# Generated at 2022-06-26 01:36:30.861930
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)


# Generated at 2022-06-26 01:36:38.546838
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)
    try:
        # call without required argument
        upload_to_pypi()
        # Should not be reached.
        assert False
    except Exception as e:
        assert isinstance(e, ImproperConfigurationError)

# Generated at 2022-06-26 01:36:44.844956
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    filename = abspath(join(__file__ ,"../../../test/test_upload_to_pypi.py"))
    # Load the module, will raise an error if module cannot be loaded
    spec = importlib.util.spec_from_file_location("test.test_upload_to_pypi", filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Look for the test function, will raise AttributeError if not found
    func = getattr(module, "test_case_0")
    assert func

# Generated at 2022-06-26 01:36:50.765944
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    a = 0

    # arrangement
    path = "dist"
    skip_existing = False
    glob_patterns = None

    # action
    var_0 = upload_to_pypi(path)

    # assertion
    a = 1

    # return
    return [a, var_0]

# Generated at 2022-06-26 01:36:53.637085
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        var_0 = upload_to_pypi()
        # if we get here then all is good
        assert True
    except:
        assert True