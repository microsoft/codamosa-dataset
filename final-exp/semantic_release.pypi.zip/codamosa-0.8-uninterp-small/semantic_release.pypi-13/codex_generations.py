

# Generated at 2022-06-26 01:28:48.435700
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    file_path = os.path.abspath(os.path.dirname(__file__))
    sys.path.insert(0, file_path + '/../../')

    from release.helpers import upload_to_pypi
    import unittest

    class TestUploadToPypi(unittest.TestCase):
        """
        Test class for upload_to_pypi
        """

        def setUp(self):
            """
            Setup function which runs before every unit test
            """
            pass

        def tearDown(self):
            """
            Setup function which runs after every unit test
            """
            pass

        def test_upload_to_pypi_case_0(self):
            """
            Test case for upload_to_pypi.
            """


# Generated at 2022-06-26 01:28:49.841514
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None



# Generated at 2022-06-26 01:28:53.987844
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Check that the function runs
    assert upload_to_pypi() is None
    # Check that SemanticReleaseImproperConfigurationError is raised when necessary
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        raise AssertionError("Not all exception types were handled!")

# Generated at 2022-06-26 01:29:04.963062
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    home_dir = os.environ.get("HOME", "")
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]

    # Test case 0
    try:
        var_0 = upload_to_pypi()
        assert var_0 == None
        print("Success")
    except Exception as e:
        print(e)

    # Test case 1
    try:
        if not (home_dir or not os.path.isfile(os.path.join(home_dir, ".pypirc"))):
            var_1 = upload_to_pypi(path)
            assert var_1 == None
            print("Success")
    except Exception as e:
        print(e)

    # Test case 2

# Generated at 2022-06-26 01:29:11.161398
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # setup
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    
    # test the code
    result = upload_to_pypi(path, skip_existing, glob_patterns)
    
    # assert that there no errors
    assert result is None

if __name__ == "__main__":
    test_upload_to_pypi()
    print("Everything passed")

# Generated at 2022-06-26 01:29:14.944625
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = ""
    skip_existing = False
    glob_patterns = [""]
    try:
        upload_to_pypi(path, skip_existing, glob_patterns)
    except Exception:
        assert False
#


# Generated at 2022-06-26 01:29:16.329309
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)



# Generated at 2022-06-26 01:29:20.128929
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    my_path = "path"
    glob_patterns = ["*"]
    assert upload_to_pypi(path = my_path, glob_patterns = glob_patterns) == 0

# Generated at 2022-06-26 01:29:22.857505
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert callable(upload_to_pypi)
    except AssertionError as e:
        raise(e)

    test_case_0()

test_upload_to_pypi()

# Generated at 2022-06-26 01:29:27.577860
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "/tmp/dist"
    skip_existing = False
    glob_patterns = ["*"]

    result = upload_to_pypi(path, skip_existing, glob_patterns)
    assert result is None


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:29:46.465583
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Mock
    with mock.patch("os.environ", autospec=True) as mock_env, mock.patch("os.path", autospec=True) as mock_path, mock.patch("os.path.isfile", autospec=True) as mock_isfile, mock.patch("invoke.run", autospec=True) as mocked_run:
        mock_env.get.side_effect = lambda _: None
        mock_path.join.side_effect = os.path.join
        mock_isfile.side_effect = os.path.isfile
        mocked_run.side_effect = lambda _: None

        mock_env.get.return_value = "some_var"
        mock_path.join.return_value = "some_path"
        mock_isfile.return_value = False

# Generated at 2022-06-26 01:29:49.580629
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = run(f"ls ..")
    assert "automated_release.py" in var_0.stdout
    var_1 = run(f"pwd")
    assert "/app" in var_1.stdout


# Generated at 2022-06-26 01:29:51.021268
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = upload_to_pypi()
    assert var_0 == None

# Generated at 2022-06-26 01:29:54.293255
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Assert if upload_to_pypi raises an exception
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi(path='path', skip_existing='True', glob_patterns=['*'])

# Generated at 2022-06-26 01:30:03.261718
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    
    # Attempt to get an API token from environment
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")

# Generated at 2022-06-26 01:30:05.001897
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None


# vim: syntax=python.legacy:

# Generated at 2022-06-26 01:30:16.302752
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]

    # Attempt to get an API token from environment
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")
        if not (username or password) and (
            not home_dir or not os.path.isfile(os.path.join(home_dir, ".pypirc"))
        ):
            raise ImproperConfigurationError(
                "Missing credentials for uploading to PyPI"
            )

# Generated at 2022-06-26 01:30:19.589440
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        # Unit test for function upload_to_pypi
        test_case_0()
    except:
        logging.exception('Caught exception when testing upload_to_pypi')
        raise

# Generated at 2022-06-26 01:30:21.541528
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Checks for the class
    assert callable(upload_to_pypi)
    # Checks for the function
    assert upload_to_pypi()

# Generated at 2022-06-26 01:30:22.551092
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except Exception as e:
        # TODO: Check exception
        print(e)

# Generated at 2022-06-26 01:30:48.204153
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]

    # Attempt to get an API token from environment
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")
        if not (username or password) and (
            not home_dir or not os.path.isfile(os.path.join(home_dir, ".pypirc"))
        ):
            raise ImproperConfigurationError(
                "Missing credentials for uploading to PyPI"
            )


# Generated at 2022-06-26 01:30:51.278345
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = 'dist'
    skip_existing = False
    glob_patterns = None
    # Check for correct response
    assert upload_to_pypi(path, skip_existing, glob_patterns) == '__return__'

# Generated at 2022-06-26 01:30:55.984912
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Input parameters
    path = "dist"
    skip_existing = False
    glob_patterns = None

    # Expected output
    var_0 = "twine upload  \"dist/*\""
    assert var_0 == upload_to_pypi(path, skip_existing, glob_patterns)
    print("Success! function upload_to_pypi()")


# Generated at 2022-06-26 01:31:04.506584
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from random import randint

    # Set params

    # Set up mocks
    monkeypatch.setattr(logging, "warning", mock_callback)
    monkeypatch.setattr(logging, "error", mock_callback)
    monkeypatch.setattr(logging, "critical", mock_callback)
    monkeypatch.setattr(logging, "debug", mock_callback)
    monkeypatch.setattr(logging, "exception", mock_callback)

    # Call function
    var_0 = upload_to_pypi()

    # Test assertions
    assert var_0 is None
    assert mock_callback.call_count == 0  # 0

# Generated at 2022-06-26 01:31:11.503717
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = upload_to_pypi()
    var_1 = upload_to_pypi("test_python/test_utils/test_helpers/test_dist_tmp")
    var_2 = upload_to_pypi("test_python/test_utils/test_helpers/test_dist_tmp", True)
    var_3 = upload_to_pypi("test_python/test_utils/test_helpers/test_dist_tmp", False, ["test_python/test_utils/test_helpers/test_dist_tmp/*"])

# Generated at 2022-06-26 01:31:15.965788
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_patterns = ["*"]

    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        pass
    else:
        raise AssertionError("Expected ImproperConfigurationError")

    os.environ["PYPI_TOKEN"] = "pypi-token"

    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        pass
    else:
        raise AssertionError("Expected ImproperConfigurationError")

    os.environ["PYPI_TOKEN"] = "pypi-token"

    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        pass
    else:
        raise AssertionError("Expected ImproperConfigurationError")


# Generated at 2022-06-26 01:31:19.491299
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Get parameters from config file
    path = config.get("default_twine_location")
    glob_patterns = config.get("default_glob_patterns")

    upload_to_pypi(path, True, glob_patterns)

# Generated at 2022-06-26 01:31:24.896915
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    mocked_run = mocker.patch("invoke.run")
    mocked_environ = mocker.patch("os.environ")
    mocked_path = mocker.patch("os.path")

    mocked_environ.get.side_effect = lambda x: ""
    mocked_path.isfile.return_value = False

    upload_to_pypi("path", True, ["*"])
    mocked_run.assert_called_once_with("twine upload  --skip-existing \"path/*\"")



# Generated at 2022-06-26 01:31:37.295796
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # No value for args, kwargs
    path = "dist"
    skip_existing = False
    glob_patterns = None
    assert upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)

    # No value for args, kwargs
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    assert upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)

    # No value for args, kwargs
    path = "dist"
    skip_existing = True
    glob_patterns = ["*"]

# Generated at 2022-06-26 01:31:49.791055
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    plt.close("all")


# Generated at 2022-06-26 01:32:15.021178
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path_0 = "dist"
    path_1 = "dist"
    skip_existing_0 = False
    skip_existing_1 = True
    glob_patterns_0 = None
    glob_patterns_1 = None

    # Call the function
    var_0 = upload_to_pypi(path_0, skip_existing_0, glob_patterns_0)

    # Call the function
    var_1 = upload_to_pypi(path_1, skip_existing_1, glob_patterns_1)

# Generated at 2022-06-26 01:32:17.093541
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None


# Generated at 2022-06-26 01:32:19.386445
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert isinstance(upload_to_pypi(), None)
    except:
        print("Error in function upload_to_pypi.")
        raise


# Generated at 2022-06-26 01:32:20.797902
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)


# Generated at 2022-06-26 01:32:22.289665
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-26 01:32:25.524936
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        config["dry_run"] = True
        config["pypi_distributions"] = []
        upload_to_pypi()
    except Exception as exception:
        assert type(exception) == ImproperConfigurationError

# Generated at 2022-06-26 01:32:33.536463
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    func_args = [
        "test_upload_to_pypi",
        "test_upload_to_pypi"
    ]
    config.load_config(
        func_args[0], func_args[1],
    )
    func_args = func_args[2:]
    # Test normal operation
    try:
        upload_to_pypi(*func_args)
    except ImproperConfigurationError as e:
        print('Caught exception: ' + str(e))
        assert(False)
    except Exception as e:
        print('Caught exception: ' + str(e))
        assert(False)
    else:
        assert(True)
    # Test improper operation

# Generated at 2022-06-26 01:32:35.048830
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Unit test for function upload_to_pypi
    upload_to_pypi()
    assert True == True

# Generated at 2022-06-26 01:32:38.604612
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = None
    assert upload_to_pypi(path, skip_existing, glob_patterns) == None

# Generated at 2022-06-26 01:32:40.219792
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# test_case_0 should not crash

# Generated at 2022-06-26 01:33:16.711129
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path_0 = ""
    skip_existing_0 = False
    glob_patterns_0 = []
    var_0 = upload_to_pypi(path_0, skip_existing_0, glob_patterns_0)
    assert var_0 == None

# Generated at 2022-06-26 01:33:17.666761
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = upload_to_pypi()

# Generated at 2022-06-26 01:33:20.106062
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except SystemExit:
        assert False, (
            "Expected upload_to_pypi() to not raise an exception"
        )



# Generated at 2022-06-26 01:33:21.123693
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()  == None

# Generated at 2022-06-26 01:33:24.033863
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test case 0
    try:
        upload_to_pypi()
    except Exception as e:
        assert(e.args[0] == 'Missing credentials for uploading to PyPI')
    else:
        assert(False)

# Generated at 2022-06-26 01:33:25.623282
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-26 01:33:26.927702
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-26 01:33:29.495927
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        test_case_0()
    except SystemExit:
        pass
    except:
        print('Test failed')

# Generated at 2022-06-26 01:33:36.376753
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert len(upload_to_pypi()) == 0
    assert len(upload_to_pypi("path")) == 0
    assert len(upload_to_pypi("path", False)) == 0
    assert len(upload_to_pypi("path", False, [])) == 0
    assert len(upload_to_pypi("path", False, ["test"])) == 0

# Generated at 2022-06-26 01:33:37.515254
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for function upload_to_pypi with 0 input parameter
    test_case_0()

# Generated at 2022-06-26 01:34:44.777240
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-26 01:34:48.142293
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert upload_to_pypi(path="dist",skip_existing=False,glob_patterns=["*"]) == None
    except Exception as error:
        print(error)
        assert False


test_case_0()

# Generated at 2022-06-26 01:34:56.423342
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert callable(upload_to_pypi)
    except AssertionError as e:
        raise(e)
    try:
        upload_to_pypi()
    except UnboundLocalError as e:
        pass
    '''
    try:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)
    except UnboundLocalError as e:
        pass
    '''
    try:
        assert callable(test_case_0)
    except AssertionError as e:
        raise(e)

# Testing

# Generated at 2022-06-26 01:35:03.122139
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Capture arguments and replace the decorator
    try:
        _upload_to_pypi = upload_to_pypi

        # Capture the arguments to the function
        capturedArguments = []

        def upload_to_pypi(*args, **kwargs):
            capturedArguments.append(args)
            capturedArguments.append(kwargs)
            return _upload_to_pypi(*args, **kwargs)

        yield upload_to_pypi, capturedArguments

    finally:
        # Restore the function
        upload_to_pypi = _upload_to_pypi

# Generated at 2022-06-26 01:35:06.777435
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = None

    # Pass in parameters and check result
    assert upload_to_pypi(path, skip_existing, glob_patterns) == 0

# Generated at 2022-06-26 01:35:12.646140
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)
    assert upload_to_pypi(path="dist", skip_existing=True, glob_patterns=None)
    assert upload_to_pypi(path="another_dist", skip_existing=True, glob_patterns=None)
    assert upload_to_pypi(path="another_dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-26 01:35:20.684924
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = str()
    skip_existing = bool()
    glob_patterns = list()

    # PASS: Test case does not raise any exception
    upload_to_pypi(path, skip_existing, glob_patterns)

    # FAIL: Path example/dist does not exist
    upload_to_pypi("example/dist", skip_existing, glob_patterns)

    # FAIL: Path example/dist does not exist
    upload_to_pypi("example/dist", skip_existing, glob_patterns)


if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-26 01:35:24.179373
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    upload_to_pypi()

    if upload_to_pypi() == None:
        assert True
    else:
        assert False



test_upload_to_pypi()

# Generated at 2022-06-26 01:35:32.978582
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest import TestCase, mock

    import invoke

    class TestCase(TestCase):
        def setUp(self):
            self.patcher = mock.patch("subprocess.run", autospec=True, spec_set=True)
            self.subprocess_mock = self.patcher.start()
            config.load()

        def tearDown(self):
            self.patcher.stop()

        def test_0(self):
            var_0 = upload_to_pypi()
            invoke.run.assert_not_called()

        def test_1(self):
            with self.assertRaises(ImproperConfigurationError):
                upload_to_pypi(glob_patterns=["*"])
            invoke.run.assert_not_called()


# Generated at 2022-06-26 01:35:38.182807
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path="dist"
    skip_existing=False
    glob_patterns=["*"]
    var_0 = upload_to_pypi()
    if var_0:
        print('1 test passed!')
    else:
        print('1 test failed!')


try:
    test_upload_to_pypi()
except:
    print('1 test failed')

# Generated at 2022-06-26 01:36:49.809840
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    var_0 = upload_to_pypi()

# Generated at 2022-06-26 01:36:51.856310
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-26 01:36:58.988800
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    print("start test upload_to_pypi")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()

# Generated at 2022-06-26 01:37:03.496790
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Mock for Twine upload command
    mock_run = patch('distutils.command.bdist_wheel.bdist_wheel.run', autospec=True)
    mock_run.start()

    try:
        # Tests
        test_case_0()
    finally:
        mock_run.stop()

# Generated at 2022-06-26 01:37:05.291154
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        # Tests for function upload_to_pypi
        test_case_0()
    except ImproperConfigurationError as err:
        print(str(err))
        raise

# Generated at 2022-06-26 01:37:09.579505
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        # Test base case
        test_case_0()
    except Exception as e:
        # Display any expected exceptions
        print(f"Expected exception: {e}")
        raise
    else:
        # Display any unexpected exceptions
        print("No expected exception was raised")

# Execute the unit tests
test_upload_to_pypi()

# Generated at 2022-06-26 01:37:12.229537
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Define some objects for test
    # Also, need to create a mock "run" that can be used in place of invoke.run()
    # Need to define the expected outcome
    assert False

# Generated at 2022-06-26 01:37:16.302993
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with mock.patch.object(logging, 'getLogger', return_value=mock.MagicMock()) as mock_logger:
        var_0 = upload_to_pypi()
        assert mock_logger.mock_calls == []
        assert var_0 == None



# Generated at 2022-06-26 01:37:25.116678
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for correctness of return type
    assert isinstance(upload_to_pypi(), None)
    # Need to test for existence of the environment variable PYPI_TOKEN.
    # This cannot be done using a Python test.
    # The test must be done manually by creating an environment variable PYPI_TOKEN
    # and then running the test_upload_to_pypi() function via the Python interpreter.
    # If the test is passed, the message "Missing credentials for uploading to PyPI"
    # must not be displayed on the screen.
    assert isinstance(upload_to_pypi(), None)



# Generated at 2022-06-26 01:37:26.581779
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert upload_to_pypi() == None
    except:
        assert True

