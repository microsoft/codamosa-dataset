

# Generated at 2022-06-24 01:55:43.829187
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*.whl"])


__all__ = ["upload_to_pypi"]

# Generated at 2022-06-24 01:55:48.650402
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    with patch("invoke.run") as run_patched:
        upload_to_pypi("/usr/local/bin", True, ["*.txt", "*.xml"])
        run_patched.assert_called_once_with(
            'twine upload  --skip-existing "*/usr/local/bin/sometextfile.txt" "*/usr/local/bin/somexml.xml"'
        )

# Generated at 2022-06-24 01:55:56.898004
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with tempfile.TemporaryDirectory() as tmpdir, patch(
        "semantic_release.package_managers.twine.run"
    ) as run_mock:
        # test credentials from variables/config file
        with env_var("PYPI_USERNAME", "username"):
            with env_var("PYPI_PASSWORD", "password"):
                upload_to_pypi(tmpdir)
                run_mock.assert_called_with(
                    "twine upload -u \'username\' -p \'password\' \'"
                    f"{tmpdir}/'\'"
                )
        # test credentials from environment
        with env_var("PYPI_TOKEN", "pypi-token"):
            upload_to_pypi(tmpdir)
            run_mock.assert_

# Generated at 2022-06-24 01:55:59.050852
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function."""
    assert True

# Generated at 2022-06-24 01:55:59.703100
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:56:08.042528
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function calls twine cli as expected
    """
    class _run_mock(object):
        def __init__(self, called_processes):
            self.called_processes = called_processes

        def __call__(self, call_string):
            self.called_processes.append(call_string)

    called_processes = []
    original_run = run
    run = _run_mock(called_processes)
    try:
        upload_to_pypi()
        assert called_processes[0] == "twine upload -u '__token__' -p 'pypi-'"
    finally:
        run = original_run

# Generated at 2022-06-24 01:56:10.140557
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:56:10.684024
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:56:11.270544
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False

# Generated at 2022-06-24 01:56:12.072407
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:56:12.624908
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:56:13.917265
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import subprocess

    subprocess.run(['invoke', 'upload'])

# Generated at 2022-06-24 01:56:20.689139
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Construct the test files and run the function
    with tempfile.TemporaryDirectory() as tmpdir:
        packages_dir = os.path.join(tmpdir, "dist")
        filename = os.path.join(packages_dir, "package.tar.gz")
        os.makedirs(packages_dir)
        open(filename, "w").close()
        upload_to_pypi(tmpdir)

# Generated at 2022-06-24 01:56:21.661629
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-24 01:56:23.443345
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """This function tests for the upload_to_pypi function
    """
    pass

# Generated at 2022-06-24 01:56:28.623392
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ Test if upload_to_pypi() raises ImproperConfigurationError """
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-24 01:56:32.758603
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for upload_to_pypi function"""
    upload_to_pypi()
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 01:56:34.214339
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    assert upload_to_pypi("dist", True, ["*"])

# Generated at 2022-06-24 01:56:39.038483
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # create a dummy dist folder with some files
    os.system("mkdir dist")
    os.system("touch dist/dummy_dist_file")

    upload_to_pypi(glob_patterns=['*'])
    assert os.system("rm -rf dist") == 0

# Generated at 2022-06-24 01:56:39.603297
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 01:56:40.320818
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test", glob_patterns=["*"])

# Generated at 2022-06-24 01:56:51.111934
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import LoggedFunction, get_logger
    from .helpers import StringIO
    import sys

    # Mock the invoke call
    old_run = run
    invoke_calls = []
    def new_run(command):
        invoke_calls.append(command)
    run = new_run

    # Mock the logger
    old_get_logger = get_logger
    logger_calls = []
    def new_logger(name):
        logger_calls.append(name)
        return logger
    get_logger = new_logger


# Generated at 2022-06-24 01:57:01.225168
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        # Test credentials are taken from env
        os.environ["PYPI_TOKEN"] = "pypi-token"
        upload_to_pypi()
    finally:
        del os.environ["PYPI_TOKEN"]

    try:
        # Test username and password
        os.environ["PYPI_USERNAME"] = "username"
        os.environ["PYPI_PASSWORD"] = "password"
        upload_to_pypi()
    finally:
        del os.environ["PYPI_USERNAME"]
        del os.environ["PYPI_PASSWORD"]


# Generated at 2022-06-24 01:57:08.180219
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    os.environ['PYPI_TOKEN'] = 'pypi-test'
    upload_to_pypi(skip_existing=True, glob_patterns=["test_dist_dir/**/*"])

# Generated at 2022-06-24 01:57:13.826608
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Mock the run() method of the invoke module to be able to check the
    # value of the command
    global run
    run = lambda command: os.environ.update({"command": command})
    upload_to_pypi("dist", False)
    assert run.command.startswith("twine upload ")
    upload_to_pypi("dist", True)
    assert run.command.startswith("twine upload --skip-existing ")

# Generated at 2022-06-24 01:57:14.453604
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 01:57:25.553418
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Match:twine upload -u 'user' -p 'password' "dist/*"
    config["repository"] = None
    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()

    # Match:twine upload -u 'user' -p 'password' -r 'repo' "dist/*"
    config["repository"] = "repo"
    upload_to_pypi()

    # Match:twine upload -u '__token__' -p 'pypi-token' "dist/*"
    os.environ["PYPI_USERNAME"] = None
    os.environ["PYPI_PASSWORD"] = None

# Generated at 2022-06-24 01:57:26.672180
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:57:35.020885
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_getoutput, mock_env_token, mock_env_user_pass
    from semantic_release.pypi import upload_to_pypi
    from unittest.mock import patch
    import os

    # Ensure `PATH` is set to a non-empty path (so the `twine` command is found)
    os.environ["PATH"] = "/tmp"

    # Ensure all credentials are missing
    ctx = mock_getoutput()
    result = ctx.run("twine upload")
    assert result.exited == 1
    assert "Missing credentials for uploading to PyPI" in result.stderr

    # Ensure missing `PYPI_TOKEN` fails the upload

# Generated at 2022-06-24 01:57:35.761413
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    assert True

# Generated at 2022-06-24 01:57:36.771965
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Do nothing for now.
    return

# Generated at 2022-06-24 01:57:39.672464
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()


if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-24 01:57:41.658985
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # test will fail if not in venv
    upload_to_pypi()

# Generated at 2022-06-24 01:57:51.970025
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-some_token"
    os.environ["HOME"] = "/home/toto"
    os.path.isfile = lambda filename : True
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

    ctx = run.magic_run.Config()


# Generated at 2022-06-24 01:58:00.053342
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    import tempfile
    import shutil
    from semantic_release.hvcs.vcs import BaseWorkingCopy

    class FakeWorkingCopy(BaseWorkingCopy):

        def __init__(self):
            pass

        def checkout(self, ref):
            pass

        def commit(self, message):
            pass

        def tag(self, tag):
            pass

        def set_remote_url(self, url):
            pass

        def get_remote_url(self):
            pass

        def push(self, remote_name, push_master, push_tags) -> bool:
            return True

    working_copy = FakeWorkingCopy()

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 01:58:03.256155
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 01:58:04.082822
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-24 01:58:08.064968
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Testing function upload_to_pypi
    """
    from .helpers import mock_run
    import os

    from semantic_release import ImproperConfigurationError


# Generated at 2022-06-24 01:58:13.091710
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    path = tempfile.mkdtemp()
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    upload_to_pypi(path=path)

# Generated at 2022-06-24 01:58:15.662457
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("unit-tests/dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 01:58:17.605952
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()



# Generated at 2022-06-24 01:58:23.398631
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    import tempfile

    d = tempfile.mkdtemp()
    os.system("pip install wheel twine")
    os.system("touch {}/some_file".format(d))
    os.system("touch {}/some_other_file".format(d))
    os.system("touch {}/some_other_file_2".format(d))
    os.system(
        'twine upload --repository-url "https://test.pypi.org/legacy/" {}'.format(d)
    )

# Generated at 2022-06-24 01:58:33.030541
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # create dist folder with wheels
    os.mkdir("dist")
    open("dist/foobar-1.0.0-py3-none-any.whl", "a").close()

    # mock environment variables
    os.environ["PYPI_TOKEN"] = "pypi-foobar"

    # upload to pypi
    upload_to_pypi()

    # make sure twine was called
    assert os.system("twine upload -u '__token__' 'dist/*'") == 0

    # cleanup
    os.remove("dist/foobar-1.0.0-py3-none-any.whl")
    os.rmdir("dist")

# Generated at 2022-06-24 01:58:41.480595
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=missing-docstring
    import shutil
    import sys
    import tempfile

    from semantic_release.backends import pypi

    from . import helpers

    from .helpers import LoggedFunction

    helpers.TEST_REPOSITORY = "https://github.com/Una-buntu/semantic-release-test"

    class CalledProcessError(Exception):
        def __init__(self):
            self.returncode = 1

    class CapturingCalledProcessError(Exception):
        def __init__(self, output):
            self.returncode = 1
            self.stdout = output

    class run:
        CalledProcessError = CalledProcessError
        CapturingCalledProcessError = CapturingCalledProcessError


# Generated at 2022-06-24 01:58:44.945789
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # import time
    # time.sleep(50)
    upload_to_pypi(path="/Users/rajatmehta/Documents/Coding/Python/test_semantic", glob_patterns=["*"])

test_upload_to_pypi()

# Generated at 2022-06-24 01:58:47.005909
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi("dist", skip_existing=True,
                       glob_patterns=["aiohttp*"])
    except:
        pass

# Generated at 2022-06-24 01:58:55.893058
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    old_env = dict(os.environ)
    old_cwd = os.getcwd()
    try:
        os.chdir(os.path.dirname(os.path.realpath(__file__)))
        os.environ["PYPI_TOKEN"] = "pypi-faketoken"
        upload_to_pypi(path="test_files", skip_existing=True)
        upload_to_pypi(
            path="test_files", skip_existing=False, glob_patterns=["testfile-pypi.whl"]
        )
    finally:
        os.environ.clear()
        os.environ.update(old_env)
        os.chdir(old_cwd)

# Generated at 2022-06-24 01:58:58.238415
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-24 01:58:58.617571
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    return

# Generated at 2022-06-24 01:59:00.715757
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = True
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-24 01:59:07.377595
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if os.environ.get('TRAVIS_PULL_REQUEST') == 'false' and os.environ.get('TRAVIS_BRANCH') == 'master':
        upload_to_pypi(
            path="dist", skip_existing=True, glob_patterns=['*-py3-none-any.whl']
            )

# Generated at 2022-06-24 01:59:08.703810
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='./tests/fixtures/py-package', skip_existing=True)

# Generated at 2022-06-24 01:59:10.604335
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-24 01:59:18.630934
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = 'pypi-this_my_token'
    username = 'my_username'
    password = 'my_password'
    path = 'path/to/dist'
    glob_patterns = ['*.tar.gz', '*.whl']

    with patch('os.environ', {'PYPI_TOKEN': token}):
        with patch('invoke.run') as invoke_mock:
            upload_to_pypi(path=path, glob_patterns=glob_patterns)
            invoke_mock.assert_called_once_with(
                'twine upload -u \'__token__\' -p \'{0}\' \'{1}/{2}\''.format(
                    token, path, glob_patterns[0]
                )
            )


# Generated at 2022-06-24 01:59:27.008439
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with mock.patch("invoke.run", autospec=True) as mocked_run, mock.patch("os.environ", {
        "PYPI_TOKEN": "pypi-1234567890abcdef1234567890abcdef"}):
        upload_to_pypi("path", False, ["test_1.1.1.whl"])
        mocked_run.assert_called_once_with("twine upload -u '__token__' -p 'pypi-1234567890abcdef1234567890abcdef' \"path/test_1.1.1.whl\"")


# Generated at 2022-06-24 01:59:28.211097
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:28.766322
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:34.598226
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run
    from .helpers import original_run

    with mock_run() as mocked_run:
        upload_to_pypi(
            path="dist",
            skip_existing=False,
            glob_patterns=["one", "two"]
        )

    mocked_run.assert_has_calls([
        original_run('twine upload  "dist/one" "dist/two"')
    ])


# Generated at 2022-06-24 01:59:35.756613
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", False, None)

# Generated at 2022-06-24 01:59:39.444997
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True


# Upload to PyPI with Twine
upload = upload_to_pypi

# Generated at 2022-06-24 01:59:43.496822
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"

# Generated at 2022-06-24 01:59:44.333893
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:45.199630
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:45.736564
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:46.585036
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:47.106290
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("test_path")

# Generated at 2022-06-24 01:59:57.926535
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """This unit test tries to actually upload a wheel to test.pypi.

    It requires the following environment variables:

    - PYPI_USERNAME
    - PYPI_PASSWORD
    - PYPI_TEST_COMMAND: Command to run to use test pypi
    - PYPI_TEST_CLEANUP: Command to run to remove the test wheel
    - PYPI_TEST_PACKAGE_NAME: Name of the test wheel to upload.
    """
    import pytest

    # Skip if no test credentials are provided

# Generated at 2022-06-24 02:00:06.194706
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi()"""
    run("touch setup.py")
    run("touch empty.file")
    run("python setup.py sdist bdist_wheel")
    # Test uploading with a token as environment variable
    token = "pypi-tokentest"
    os.environ["PYPI_TOKEN"] = token
    upload_to_pypi()
    # Test uploading with username and password as environment variables
    username = "test_user"
    password = "test_pw"
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"] = password
    upload_to_pypi()
    # Test uploading multiple files

# Generated at 2022-06-24 02:00:07.310628
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:00:12.302586
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Simple unit test to check upload_to_pypi()"""
    upload_to_pypi(path="tests/twine_pypi_upload", glob_patterns=["*"], skip_existing=False)

# Generated at 2022-06-24 02:00:19.831734
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = 'test'
    token = 'pypi-123'
    username = 'username'
    password = 'password'

    try:
        os.environ['PYPI_TOKEN'] = token
        upload_to_pypi(path, glob_patterns=['a.whl', 'b.whl'])
        os.environ['PYPI_USERNAME'] = username
        os.environ['PYPI_PASSWORD'] = password
        upload_to_pypi(path, glob_patterns=['a.whl', 'b.whl'])
    finally:
        if 'PYPI_TOKEN' in os.environ:
            del os.environ['PYPI_TOKEN']

# Generated at 2022-06-24 02:00:28.998899
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set up environment and change to test/repo
    os.environ["PYPI_USERNAME"] = "test-username"
    os.environ["PYPI_PASSWORD"] = "test-password"
    os.environ["PYPI_TOKEN"] = "test-token"

    # Create empty file for testing
    open("test_file.txt", "a").close()
    assert os.path.isfile("test_file.txt")

    # Upload file to PyPI
    upload_to_pypi(".", ["*.txt"])

    # Check that file was deleted
    assert not os.path.isfile("test_file.txt")

# Generated at 2022-06-24 02:00:35.809576
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config["repository"] = "my_pypi"
    config["skip_existing"] = True
    config["glob_patterns"] = ["hello-1.2.3-py*"]
    os.environ["PYPI_TOKEN"] = "pypi-token"
    run = MagicMock()
    with patch("semantic_release.hvcs.pypi.os.environ") as mock_environ:
        mock_environ.get.side_effect = os.environ.get
        upload_to_pypi(path="my_dist", skip_existing=True, glob_patterns=["hello-1.2.3-py*"])

# Generated at 2022-06-24 02:00:36.720848
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # skip when testing
    pass

# Generated at 2022-06-24 02:00:47.115258
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    original_run_func = run

# Generated at 2022-06-24 02:00:49.283957
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function"""
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 02:00:54.993548
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi with an existing dist folder and a valid token."""
    glob_patterns = ["*"]
    path = "tests"
    token = "pypi-test"
    os.environ["PYPI_TOKEN"] = token

    def run_mock(*args, **kwargs):
        """Mock for run function."""
        assert "twine upload -u '__token__' -p '{}' --skip-existing 'tests/{}'".format(
            token, glob_patterns[0]
        ) in args[0]

    run_mock.side_effect = run
    upload_to_pypi(path, True, glob_patterns)

# Generated at 2022-06-24 02:00:55.848936
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi

# Generated at 2022-06-24 02:01:01.302623
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with mock.patch('invoke.run') as mocked_run:
        username = 'test'
        password = '1234'
        os.environ['PYPI_USERNAME'] = username
        os.environ['PYPI_PASSWORD'] = password
        del os.environ['HOME']
        upload_to_pypi()
        expected_args = f"-u '{username}' -p '{password}' *"
        mocked_run.assert_called_with(expected_args)



# Generated at 2022-06-24 02:01:01.863704
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:01:02.705653
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi

# Generated at 2022-06-24 02:01:04.493007
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # build test wheel
    run('python setup.py bdist_wheel')

    # upload wheel
    upload_to_pypi()

# Generated at 2022-06-24 02:01:08.158126
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "wheelhouse"
    token = "pypi-password"
    skip_existing = True

    os.environ["PYPI_TOKEN"] = token
    glob_patterns = ["*.whl"]

    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-24 02:01:15.717915
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil

    try:
        temp_folder = tempfile.mkdtemp()
        test_file_path = os.path.join(temp_folder, "test_file.txt")

        open(test_file_path, "a").close()

        upload_to_pypi(temp_folder, glob_patterns=["test_file.txt"])
    finally:
        shutil.rmtree(temp_folder)

# Generated at 2022-06-24 02:01:23.599940
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class MockConfig(object):
        def __init__(self, repository):
            self.repository = repository

        def get(self, key, default=None):
            if key == "repository":
                return self.repository

    class MockRun(object):
        def __init__(self):
            self.calls = []

        def __call__(self, command):
            self.calls.append(command)

    mock_run = MockRun()

    config.get = MockConfig("myrepo").get

    # Upload 3 wheels to myrepo
    os.environ["PYPI_TOKEN"] = "pypi-12345"

# Generated at 2022-06-24 02:01:24.466147
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:01:26.454867
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path=None,
        skip_existing=None,
        glob_patterns=[""]
        )

# Generated at 2022-06-24 02:01:32.753650
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.plugins.pypi import upload_to_pypi

    dist_folder = "dist"
    wheel_name = "foobar-1.0-py2.py3-none-any.whl"
    wheel_path = os.path.join(dist_folder, wheel_name)
    os.makedirs(os.path.dirname(wheel_path), exist_ok=True)
    with open(wheel_path, "w") as wheel_file:
        wheel_file.write("Hello world!!")

    dummy_env_value = "changeme"


# Generated at 2022-06-24 02:01:37.959233
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # This function is hard to test, since it requires the environment
    # variables to be set and a file to exist in a certain directory.
    # The tests in the unit tests folder don't run on a real machine,
    # but inside a Docker container.
    # For now, we can safely assume that this function works as intended.
    pass

# Generated at 2022-06-24 02:01:47.246994
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    token = os.environ.get("PYPI_TOKEN")
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")

    if not (token or (username and password)):
        raise ImproperConfigurationError(
            "Missing credentials for uploading to PyPI"
        )

    repository = config.get("repository", None)
    repository_arg = f" -r '{repository}'" if repository else ""

    username_password = (
        f"-u '{username}' -p '{password}'" if username and password else ""
    )

    dist = "dist/test_twine_upload_*.whl"

    skip_existing_param = " --skip-existing"


# Generated at 2022-06-24 02:01:51.780482
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    token = "pypi-token"
    username = "username"
    password = "password"
    path = "path"
    skip_existing = True
    glob_pattern = "pattern"

    # Ensure function is called correctly when token is present.
    with patch("invoke.run") as mock_invoke:
        os.environ["PYPI_TOKEN"] = token
        del os.environ["PYPI_USERNAME"]
        del os.environ["PYPI_PASSWORD"]
        upload_to_pypi(
            path, skip_existing, glob_patterns=[glob_pattern]
        )
        assert mock_invoke.call_count == 1

# Generated at 2022-06-24 02:01:52.534304
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
  pass

# Generated at 2022-06-24 02:01:59.625741
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ Unit test for function upload_to_pypi
    """
    # Note that this test should not be run in parallel with other tests that
    # use the .pypirc file. It removes the existing file, which will cause
    # problems if another test is running at the same time.
    home_dir = os.environ.get("HOME", "")
    pypirc_path = os.path.join(home_dir, ".pypirc")
    if os.path.isfile(pypirc_path):
        os.remove(pypirc_path)
    upload_to_pypi(path="./tests/fixture/dist", skip_existing=False, glob_patterns=["*.zip"])

    assert os.path.isfile(pypirc_path)

# Generated at 2022-06-24 02:02:08.522585
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import FakeSession, FakeResponse
    import pytest
    from unittest.mock import patch

    pytest.importorskip("twine")

    package_url = "https://pypi.org/pypi/semantic-release/2.0.0/json"
    with patch("semantic_release.upload.twine.run") as mock_run, patch(
        "requests.Session", new_callable=FakeSession
    ) as mock_session:
        mock_session.return_value.get.return_value = FakeResponse(
            200, {"info": {"version": "2.0.0"}}
        )
        upload_to_pypi(path="test_path/test_dist", skip_existing=True)

# Generated at 2022-06-24 02:02:11.492537
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:02:15.108836
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with credentials in environment variables
    os.environ["PYPI_TOKEN"] = "pypi-test-token"
    upload_to_pypi("test-dist-folder")



# Generated at 2022-06-24 02:02:24.433526
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Arrange
    path = "dist"
    file_name = "artifact.whl"
    glob_patterns = ["*.whl"]
    mocked_run = create_mock()

    # Act/Assert
    # Call with username and password set in environment variables
    expected = (
        "twine upload -u __token__ -p '' -r 'test_repository' "
        + f'"{path}/{file_name}"'
    )
    upload_to_pypi(path, repository="test_repository", glob_patterns=glob_patterns)
    mocked_run.assert_called_once_with(expected)

    # Call with token set in environment variable
    mocked_run.reset_mock()

# Generated at 2022-06-24 02:02:26.483822
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-24 02:02:26.963494
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:02:28.868101
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["dist/**/*.whl"])

# Generated at 2022-06-24 02:02:34.357132
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert run("pip uninstall -y twine", warn=True, hide=True).ok
    assert run("pip uninstall -y pypi-cli", warn=True, hide=True).ok
    assert run("pip install twine").ok
    upload_to_pypi()
    assert run("pip uninstall -y twine", warn=True, hide=True).ok
    assert run("pip uninstall -y pypi-cli", warn=True, hide=True).ok

# Generated at 2022-06-24 02:02:40.322945
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:02:41.067954
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-24 02:02:46.901840
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

    upload_to_pypi(path="toto")

    upload_to_pypi(
        path="toto",
        glob_patterns=["*.tar.gz", "*-cp27-cp27m-manylinux1_x86_64.whl"],
    )

# Generated at 2022-06-24 02:02:55.700457
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert os.environ.get("PYPI_TOKEN") == None
    assert os.environ.get("PYPI_USERNAME") == None
    assert os.environ.get("PYPI_PASSWORD") == None

    try:
        upload_to_pypi()
        assert False, "Credentials not specified!"
    except ImproperConfigurationError:
        pass
    finally:
        if os.environ.get("PYPI_TOKEN") != None:
            del os.environ["PYPI_TOKEN"]
        if os.environ.get("PYPI_USERNAME") != None:
            del os.environ["PYPI_USERNAME"]

# Generated at 2022-06-24 02:02:56.647845
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-24 02:03:05.889165
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.environ["PYPI_USERNAME"] = "username"
        os.environ["PYPI_PASSWORD"] = "password"

        repo = "pypi"
        repository_param = " -r '{}'".format(repo) if repo else ""

        username_password = "-u 'username' -p 'password'"

        dist = '"dist/file1.whl" "dist/file2.whl"'
        run(
            f"twine upload {username_password}{repository_param} --skip-existing {dist}"
        )

    except KeyError:
        raise ImproperConfigurationError("Missing credentials for uploading to PyPI")

# Generated at 2022-06-24 02:03:12.621886
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mocked_run(command):
        command
        return 0

    old_run = run
    run = mocked_run
    config['repository'] = "test_repository"

    os.environ['PYPI_USERNAME'] = "test_username"
    os.environ['PYPI_PASSWORD'] = "test_password"

    # Positive test: token in environment
    upload_to_pypi()

    # Positive test: username and password in environment, but token not.
    del os.environ['PYPI_TOKEN']
    upload_to_pypi()

    # Negative test: no username and password in environment, but token not.
    del os.environ['PYPI_USERNAME']

# Generated at 2022-06-24 02:03:20.418320
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test to check function upload_to_pypi()
    """
    import re
    import sys
    from io import StringIO
    from unittest import mock

    import invoke

    class Stdout(StringIO):
        def write(self, x):
            if x != "\n":  # suppress blank lines
                super(Stdout, self).write(x)

    sys.stdout = Stdout()
    mock_run = mock.Mock(return_value=None)
    with mock.patch("invoke.run", mock_run):
        upload_to_pypi(path="test_path")

        mock_run.assert_called_with(
            "twine upload -u '__token__' -p 'pypi-token' 'test_path/*'"
        )
        
       

# Generated at 2022-06-24 02:03:21.968039
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='dist', skip_existing=True)



# Generated at 2022-06-24 02:03:22.868853
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True, glob_patterns=["*"])

# Generated at 2022-06-24 02:03:33.214830
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ['*']
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")
        if not (username or password) and (
            not home_dir or not os.path.isfile(os.path.join(home_dir, ".pypirc"))
        ):
            raise ImproperConfigurationError(
                "Missing credentials for uploading to PyPI"
            )

# Generated at 2022-06-24 02:03:34.951429
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:37.176276
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Function upload_to_pypi should run without crashing and do nothing."""
    upload_to_pypi(".", ["*"])

# Generated at 2022-06-24 02:03:47.169284
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import environment_variable_temporary
    from .helpers import temporary_directory
    from .helpers import files_in_directory
    import shutil
    import glob

    with environment_variable_temporary(PYPI_USERNAME="__token__", PYPI_PASSWORD="pypi-FOO"):
        # Create some distributions
        with temporary_directory() as temp_dir:
            # Create a distribution
            run("python setup.py sdist bdist_wheel", cwd=temp_dir)

            # Check that it has been created to be uploaded
            assert len(glob.glob(os.path.join(temp_dir, "dist", "*"))) > 0

            # Upload to PyPI
            upload_to_pypi(path=temp_dir + "/dist")

# Generated at 2022-06-24 02:03:47.955480
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:49.468947
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:03:49.965741
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:04:00.127310
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from shutil import rmtree

    temp_dir = tempfile.mkdtemp()

    try:
        # Write some sample files to our temp dir
        data = ["hello", "world"]
        files = []
        for i in range(len(data)):
            files.append(tempfile.NamedTemporaryFile(mode="w+", delete=False, dir=temp_dir))
            files[i].write(data[i])
            files[i].close()

        # Try uploading files, should not raise
        upload_to_pypi(path=temp_dir, skip_existing=True, glob_patterns=[])
    finally:
        # Clean up temp dir
        for path in files:
            os.remove(path.name)
        rmtree(temp_dir)

# Generated at 2022-06-24 02:04:11.760614
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import subprocess
    import sys
    from unittest.mock import patch
    from semantic_release.settings import config

    if sys.version_info < (3, 5):
        return

    with patch('subprocess.run') as mock_run:
        upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"])
        token = config.get("pypi_token", "")
        username = config.get("pypi_username", "")
        password = config.get("pypi_password", "")
        repository = config.get("pypi_repository", "")
        repository_arg = f" -r '{repository}'" if repository else ""

# Generated at 2022-06-24 02:04:19.363698
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch, Mock

    with patch("invoke.run") as mock_run:
        upload_to_pypi()
        mock_run.assert_called_once_with('twine upload "*"')
        mock_run.reset_mock()

        upload_to_pypi(skip_existing=True)
        mock_run.assert_called_once_with('twine upload --skip-existing "*"')
        mock_run.reset_mock()

        upload_to_pypi(glob_patterns=["package1", "package 2"])
        mock_run.assert_called_once_with(
            'twine upload "package1" "package 2"'
        )
        mock_run.reset_mock()


# Generated at 2022-06-24 02:04:20.569089
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()



# Generated at 2022-06-24 02:04:27.158917
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockInvoke
    from .helpers import LoggerMock

    with MockInvoke(logger=LoggerMock()), logger.catch_warnings():
        upload_to_pypi()
    run_mock = MockInvoke.run

    assert run_mock.called
    assert len(run_mock.call_args_list) == 1
    assert 'twine upload "*"' in run_mock.call_args_list[0][0][0]



# Generated at 2022-06-24 02:04:36.084791
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    prep_test()
    try:
        upload_to_pypi()
    except RuntimeError:
        pass
    prep_test()
    os.environ["PYPI_TOKEN"] = "pypi-zZqbJgJo0M9tbRV7LQ2QwgV7rjsyrpZn"
    upload_to_pypi(skip_existing=True)
    prep_test()
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    upload_to_pypi(repository="test_repo")
    prep_test()
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ

# Generated at 2022-06-24 02:04:47.332124
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile
    
    from io import StringIO
    from unittest.mock import patch

    from semantic_release.errors import ImproperConfigurationError
    from semantic_release.uploaders.pypi import upload_to_pypi
    from invoke import Result

    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir)
    temp_file.close()

    # Missing PYPI_TOKEN
    os.environ.pop("PYPI_TOKEN", None)
    os.environ.pop("PYPI_USERNAME", None)
    os.environ.pop("PYPI_PASSWORD", None)

# Generated at 2022-06-24 02:04:56.142731
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .factories import setup_cfg_factory, setup_factory
    from .repository import init_repository
    from .package import create_package
    import tempfile
    import os
    import shutil

    # Setup temporary repository to simulate a user
    with tempfile.TemporaryDirectory() as tempdir:
        package_dir = os.path.join(tempdir, "test-package")
        init_repository(tempdir)
        package_name = create_package(package_dir, init=True)
        setup_cfg_factory(tempdir)
        setup_factory(package_dir, package_name)
        dist_dir = os.path.join(tempdir, "dist")
        # create dist folder
        os.mkdir(dist_dir)

        package_path = os.path.join

# Generated at 2022-06-24 02:04:58.166318
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:05:00.071067
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=['*'])



# Generated at 2022-06-24 02:05:08.998436
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import direct_execute_command

    from .helpers import FakeInvoke

    from .helpers import build_wheel
    from .helpers import build_wheel_for_version
    from .helpers import clear_dist_folder
    from .helpers import create_sample_package
    from .helpers import get_dist_folder
    from .helpers import clean_pypirc
    from .helpers import create_pypirc
    from .helpers import remove_pypirc

    import os
    import shutil

    from distutils.version import LooseVersion

    from semantic_release.settings import config

    from semantic_release.configuration import Configurate


# Generated at 2022-06-24 02:05:20.067866
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Check that the function upload_to_pypi returns correct command to upload
    to PyPI for the following conditions:

    - repository is provided
    - username/password are provided
    - skip existing is true
    - glob patterns are provided
    - token is provided
    """
    assert (
        upload_to_pypi(
            path="dist",
            skip_existing=True,
            repository="semantic-release",
            username="bob",
            password="my_password",
            glob_patterns=["file1*", "file2*"],
        )
        == "twine upload -u 'bob' -p 'my_password' -r 'semantic-release' --skip-existing 'dist/file1*' 'dist/file2*'"
    )

# Generated at 2022-06-24 02:05:26.070251
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    try:
        upload_to_pypi(glob_patterns=["*"])
        assert True
    except Exception as exc:  # pylint: disable=broad-except
        print(exc)
        assert False

# Generated at 2022-06-24 02:05:36.194053
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import re
    import sys
    import shutil
    # Create a dummy wheel
    try:
        shutil.rmtree("dummy_wheel")
    except:
        pass
    version = re.search("[0-9]+[.][0-9]+", sys.version).group(0)
    wheel_name = "dummy_package-0.0.0.0-py3."+version+"-none-any.whl"
    run("mkdir dummy_wheel")
    run("touch dummy_wheel/"+wheel_name)
    # Upload wheel
    # Need to check sys.argv to run from unittest

# Generated at 2022-06-24 02:05:40.296321
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = "dist", skip_existing = False, glob_patterns = None)
    upload_to_pypi(path = "dist", skip_existing = False, glob_patterns = ["*"])

# Generated at 2022-06-24 02:05:47.580522
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # This test will only run successfully on a Linux machine
    from pathlib import Path

    # Setup
    # Create dummy files
    Path("dist/dummy1.whl").touch()
    Path("dist/dummy2.whl").touch()

    # Define dummy environment variables
    os.environ["PYPI_TOKEN"] = "pypi-dummy-token"

    # Run function
    upload_to_pypi()

    # Assert
    # Test to make sure Twine was called with the right parameters