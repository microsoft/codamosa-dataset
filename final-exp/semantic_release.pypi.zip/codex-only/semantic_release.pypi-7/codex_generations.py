

# Generated at 2022-06-24 01:55:40.482713
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert(upload_to_pypi('/dist'))

# Generated at 2022-06-24 01:55:41.898432
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(None, None, None)

# Generated at 2022-06-24 01:55:42.840839
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False, "TODO"

# Generated at 2022-06-24 01:55:53.712219
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    # Should use PYPI_TOKEN if it exists
    os.environ["PYPI_TOKEN"] = "test-token"
    assert "test-token" in upload_to_pypi.__wrapped__.__call__.__code__.co_code.decode()

    # Should fall back on PYPI_USERNAME and PYPI_PASSWORD otherwise
    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "test-user"
    os.environ["PYPI_PASSWORD"] = "test-password"
    assert "-u 'test-user' -p 'test-password'" in upload_to_pypi.__wrapped__.__call

# Generated at 2022-06-24 01:55:55.637042
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO
    assert False

# Generated at 2022-06-24 01:55:58.246810
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 01:56:08.042659
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import LoggedFunctionTest
    from .helpers import TestException

    class TestUploadToPyPi(LoggedFunctionTest):

        def test_upload_to_pypi(self):
            def fake_run(command):
                if command == "twine upload  -u '__token__' -p 'pypi-mytoken' --skip-existing 'dist/semantic_release-0.0.0-py2.py3-none-any.whl'":
                    return "Upload successful."
                raise TestException("Unexpected twine command: " + command)

            self.upload_to_pypi_under_test.side_effect = fake_run
            os.environ["PYPI_TOKEN"] = "pypi-mytoken"

# Generated at 2022-06-24 01:56:11.646593
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist",
        skip_existing=True,
        glob_patterns=["flower*", "potato*"]
    )

# Generated at 2022-06-24 01:56:12.215575
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    
    assert True

# Generated at 2022-06-24 01:56:21.359316
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .mocks import MockRun
    from .helpers import LoggedFunctionTest

    def _upload(*args, **kwargs):
        raise Exception("Should not call run function")

    test_obj = LoggedFunctionTest(logger, _upload)
    test_obj.test_logger_calls(
        "upload_to_pypi",
        [
            (
                "release.uploaders.twine",
                20,
                "Uploading files to PyPI",
            ),
            (
                "release.uploaders.twine",
                10,
                "The following files were uploaded:",
            ),
        ],
        1,
        "Missing credentials for uploading to PyPI",
        error_class=ImproperConfigurationError,
    )


# Generated at 2022-06-24 01:56:30.395471
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    from unittest.mock import patch

    mock_run = patch("semantic_release.hvcs.twine.run").start()

    upload_to_pypi(
        path="dist",
        glob_patterns=["semantic_release*"],
        skip_existing=False,
    )

    mock_run.assert_called_with(
        "twine upload -u '__token__' -p 'token' "
        '"dist/semantic_release*"'
    )

    patch("semantic_release.hvcs.twine.run").stop()

# Generated at 2022-06-24 01:56:31.466598
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO
    assert False

# Generated at 2022-06-24 01:56:33.119535
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    upload_to_pypi()


# Generated at 2022-06-24 01:56:42.666494
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    with patch("invoke.run") as mock_run:
        path = "/test/dist"
        glob_patterns = ["test"]
        upload_to_pypi(path, glob_patterns=glob_patterns)
        mock_run.assert_called_once_with(
            'twine upload -u \'__token__\' -p \'pypi-123\' "test/test"'
        )

        with patch.dict("os.environ", {"PYPI_TOKEN": "123", "HOME": "/home/user"}):
            upload_to_pypi(path, glob_patterns=glob_patterns)

# Generated at 2022-06-24 01:56:47.021187
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for upload_to_pypi"""
    test_path = "./tests/my_test_dist"
    test_files = ["foo-1.2.0-py2.py3-none-any.whl"]
    for file_name in test_files:
        open(os.path.join(test_path, file_name), "a").close()
    try:
        upload_to_pypi(test_path, False, ["*.whl"])
    finally:
        for file_name in test_files:
            os.remove(os.path.join(test_path, file_name))

# Generated at 2022-06-24 01:56:48.442861
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == 'upload_to_pypi'

# Generated at 2022-06-24 01:56:56.507940
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os, shutil, tempfile

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary dist directory
    dist = os.path.join(tmp_dir, "dist")
    os.mkdir(dist)
    # Create the following files in the dist directory
    os.mkdir(os.path.join(dist, "examplepkg"))
    open(os.path.join(dist, "examplepkg-1.1.1.tar.gz"), "a").close()
    open(os.path.join(dist, "examplepkg-1.1.1-py2.py3-none-any.whl"), "a").close()
    open(os.path.join(dist, "examplepkg-1.1.1.zip"), "a").close()

    # Test that the upload

# Generated at 2022-06-24 01:57:01.984463
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = os.environ.get("PYPI_TOKEN")
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")

    # Check that we get an error on missing credentials
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    raised = False
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        raised = True

    assert raised, "upload_to_pypi should raise an error when no credentials are given"

    # Check that we get an error on malformed token

# Generated at 2022-06-24 01:57:14.050143
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function.
    """
    test_repository = "Testing PyPI"
    test_username = "test_username"
    test_password = "test_password"
    test_token = "testtoken_pypi"
    test_files = ["sdist/test.tar.gz"]

    import semantic_release.hvcs.git  # Avoid circular importing
    from unittest.mock import patch

    patch_run = patch("semantic_release.hvcs.git.run")
    patch_run.start()

    # Credentials should be used from the environment
    os.environ["PYPI_TOKEN"] = test_token
    upload_to_pypi(path="", glob_patterns=test_files)

# Generated at 2022-06-24 01:57:25.253598
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import patched_get_version

    pypi_token = "pypi-1234"
    pypi_username = "johndoe"
    pypi_password = "abcd1234"
    pypi_repository = "https://my.pypi.server"

    def patched_run(cmd):
        assert cmd == (
            f"twine upload -u '{pypi_username}' -p '{pypi_password}' -r '{pypi_repository}' --skip-existing "
            '"dist/package-0.0.0-py2.py3-none-any.whl"'
        )

    with patched_get_version() as mocked_get_version, patched_run as mocked_run:
        mocked_get_version

# Generated at 2022-06-24 01:57:26.759187
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:57:27.843812
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:57:29.825574
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

if __name__ == '__main__':
    test_upload_to_pypi()

# Generated at 2022-06-24 01:57:40.590548
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from random import randrange
    import shutil
    import tempfile

    def create_test_file(dir, name):
        """Create a test file with random content."""
        file = open(os.path.join(dir, name), "w")
        file.write(str(randrange(1000)))
        file.close()

    temp_dir = tempfile.TemporaryDirectory()

    # Create test files
    create_test_file(temp_dir.name, "test-1.1.0.tar.gz")
    create_test_file(temp_dir.name, "test-1.1.0.tar.gz.asc")

    upload_to_pypi(path=temp_dir.name)

    # Cleanup
    temp_dir.cleanup()

# Generated at 2022-06-24 01:57:42.570751
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

test_upload_to_pypi()

# Generated at 2022-06-24 01:57:49.179283
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command):
        assert "twine upload " in command
        assert "pypi-abc:defg@pypi" in command
        assert " -r 'my-repo'" in command
        assert " -u '__token__' -p 'pypi-abc:defg@pypi'" not in command
        assert " --skip-existing" not in command
        assert '"/fake/path/*"' in command

    old_run = run
    run = mock_run
    upload_to_pypi(path="/fake/path/", skip_existing=False, glob_patterns=["*"])
    run = old_run

# Generated at 2022-06-24 01:57:52.184346
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["*"]
    ) == "twine upload -u '__token__' -p 'pypi-xxx' 'dist/'"

# Generated at 2022-06-24 01:57:55.547142
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # This is a slow / interactive test so need to skip if running all tests
    skip()
    # TODO: write test for upload_to_pypi

# Generated at 2022-06-24 01:57:58.418617
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi using the twine-test package

    Note: Requires valid credentials stored in environment variables or ~/.pypirc.
    """
    upload_to_pypi(
        path="tests/packages/twine-test/dist",
        skip_existing=True,
        glob_patterns=["twine-test-*.whl"],
    )

# Generated at 2022-06-24 01:58:00.035194
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:58:01.374769
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:58:06.702312
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", username="", password="", repository="", glob_patterns=["*"])

# Generated at 2022-06-24 01:58:12.238203
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        glob_patterns=[
            "twine-1.13.0-py2.py3-none-any.whl",
            "twine-1.13.0.tar.gz",
            "twine-1.13.0.zip",
        ]
    )

# Generated at 2022-06-24 01:58:13.014896
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:58:23.888648
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test using token
    os.environ["PYPI_TOKEN"] = "pypi-test-token"
    try:
        upload_to_pypi()
        assert True
    except Exception as e:
        assert False, e

    # Test missing credentials
    os.environ["PYPI_TOKEN"] = ""
    try:
        upload_to_pypi()
        assert True
    except Exception as e:
        assert isinstance(e, ImproperConfigurationError), e

    # Test missing username and password credentials
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""

# Generated at 2022-06-24 01:58:27.432102
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    result = upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    assert result is None

# Generated at 2022-06-24 01:58:27.871383
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:58:33.497608
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = "foo"
    password = "bar"
    repository = "testpypi"
    token = "pypi-" + password
    test_patterns = ["test_pattern1", "test_pattern2"]

    def get_mock_run(
        username_password="",
        repository_arg="",
        skip_existing_param="",
        dist="",
    ):
        def mock_run(command):
            assert command == f"twine upload {username_password}{repository_arg}{skip_existing_param} {dist}"

        return mock_run

    # Check the function uses the token if available
    os.environ["PYPI_TOKEN"] = token
    run = get_mock_run(username_password="-u '__token__' -p 'pypi-bar'")


# Generated at 2022-06-24 01:58:34.694023
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for upload_to_pypi() function."""
    assert upload_to_pypi("dist/twine")

# Generated at 2022-06-24 01:58:35.268939
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:58:41.894122
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import json
    import shutil
    import requests
    import semantic_release
    import semantic_release.settings
    import semantic_release.history
    import semantic_release.pypi
    import semantic_release.plugins

    # Need to import the plugins to register them
    import semantic_release.plugins.jenkins_yaml

    dist_dir = "test_dist"
    try:
        shutil.rmtree(dist_dir)
    except FileNotFoundError:
        pass
    os.mkdir(dist_dir)

    config_file = "test.conf.yaml"

    r = requests.get(
        "https://api.github.com/repos/drbrowne/temp_semantic_release_test/releases/latest"
    )
    latest_release = r.json()


# Generated at 2022-06-24 01:58:49.444815
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from .helpers import LoggedFunction

    @LoggedFunction(logger)
    def upload_to_pypi(
        path: str = "dist", skip_existing: bool = False, glob_patterns: List[str] = None
    ):
        pass

    config["repository"] = "pypi"
    os.environ["PYPI_TOKEN"] = "pypi-mytoken"
    with patch('invoke.run') as run_mock:
        upload_to_pypi(
            path="dist",
            skip_existing=False,
            glob_patterns=["pkg1", "pkg2"],
        )

# Generated at 2022-06-24 01:58:50.037420
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:58:50.993008
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:58:57.116307
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"
    assert upload_to_pypi.__doc__ != ""
    assert upload_to_pypi.__doc__ != None

# Generated at 2022-06-24 01:58:58.037303
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 01:58:59.184163
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True)

# Generated at 2022-06-24 01:59:02.626043
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run = MockRun()
    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["pattern1", "pattern2"]
    )
    assert run.calls == [
        "twine upload  \"dist/pattern1\" \"dist/pattern2\"",
    ]



# Generated at 2022-06-24 01:59:13.246256
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit tests for function upload_to_pypi
    """
    # Attempt to get an API token from environment
    token = "pypi-123"
    os.environ["PYPI_TOKEN"] = token

    with open("pyproject.toml", "w") as f:
        f.write("[tool.poetry]\npackage_name = 'my_package'\n")

    run("poetry build")

    upload_to_pypi()

    run("pip uninstall -y my_package")

    run("poetry install")

    assert run("python -c 'import my_package; print(my_package.__version__)'").stdout.strip() == "1.0.0"

    run("poetry remove -y my_package")
    run("rm -rf dist")

# Generated at 2022-06-24 01:59:19.244736
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # test dummy token
    os.environ["PYPI_TOKEN"] = "pypi-DUMMYTOKEN"
    username = "pypi-DUMMYTOKEN"
    password = "pypi-DUMMYTOKEN"
    repository = ""
    glob_patterns = ["*"]
    dist = ' "dist/{}"'.format(glob_patterns[0])
    config["repository"] = ""
    upload_to_pypi()
    assert (
        f"twine upload --verbose -u '{username}' -p '{password}{repository} {dist}'"
        in run.calls[0].args
    )

# Generated at 2022-06-24 01:59:19.840460
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:29.868186
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    import tempfile
    import twine

    # Expect invalid twine inputs
    with tempfile.TemporaryDirectory() as dirname:
        config.set("repository", "pypi")
        shutil.copytree("tests/resources/valid_package", dirname)
        os.chdir(dirname)

        with open(os.path.join(dirname, "setup.py"), "w+") as file:
            file.write((f"setup(\n"
                         f"    name='{dirname}',\n"
                         f"    version='0.0.0',\n"
                         f"    packages=find_packages(),\n"
                        ))

        run("python setup.py sdist")
        assert os.path.isdir(os.path.join(dirname, "dist"))

# Generated at 2022-06-24 01:59:33.242634
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = True
    glob_patterns = ["*"]

    upload_to_pypi(
        path=path, skip_existing=skip_existing, glob_patterns=glob_patterns
    )

# Generated at 2022-06-24 01:59:35.134650
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["wheels/*.whl", "wheels/*.zip"])

# Generated at 2022-06-24 01:59:41.486747
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # mock up a package directory
    test_dir = os.path.join(os.path.dirname(__file__), '..', 'test_dir')
    os.mkdir(test_dir)

    # create some files
    os.makedirs(os.path.join(test_dir, 'dist'))
    files = ['testfile-1.0.0-py3-none-any.whl', 'testfile-1.0.0.tar.gz']
    for file in files:
        with open(os.path.join(test_dir, 'dist', file), 'w') as f:
            f.write('')

    # make sure there's nothing uploaded yet

# Generated at 2022-06-24 01:59:51.638821
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi.
    """
    from .mocks import invoke_run, mock_config
    from semantic_release import settings

    old_run = invoke_run.run
    old_config = settings.config

    def run_mock(cmd):
        if "twine upload" in cmd:
            return True
        else:
            return old_run(cmd)

    invoke_run.run = run_mock

    settings.config = mock_config.config


# Generated at 2022-06-24 01:59:54.469209
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:58.734401
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set up Twine config
    os.environ["HOME"] = ""
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    os.environ["TWINE_REPOSITORY_URL"] = "some.url"

    # Path to dist/
    path = "some/path"

    # List of glob patterns to match
    glob_patterns = [
        "some/glob/pattern",
        '"some/other/glob/pattern"'
    ]

    # Twine should be called with the above values
    upload_to_pypi(path=path, glob_patterns=glob_patterns)

    # Now make sure Twine was called with the right parameters
    twine_repo_arg = f

# Generated at 2022-06-24 01:59:59.457686
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:00:07.021754
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pytest.importorskip("twine")

    # Create dummy files
    os.mkdir("tmp_dist")
    with open("tmp_dist/package.zip", "w"):
        pass
    with open("tmp_dist/package.tar.gz", "w"):
        pass
    # Mock 'run' function called by _upload_to_pypi
    with mock.patch("invoke.run") as mocked_run:
        upload_to_pypi("tmp_dist", skip_existing=True, glob_patterns=["*.zip"])
        # Check if 'twine upload' is called with the correct parameters
        mocked_run.assert_called_with("twine upload "
                                      "--skip-existing "
                                      '"tmp_dist/package.zip"')

# Generated at 2022-06-24 02:00:17.012131
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """This is a unit test for the function upload_to_pypi.
    There are three different testing scenarios:
        1. upload to test.pypi.org
        2. upload to test.pypi.org and skip existing pakage
        3. upload to PyPI.org
    """
    os.environ["PYPI_TOKEN"] = "test"
    config.update({"repository": "http://test.pypi.org/legacy/"})
    upload_to_pypi(path="", skip_existing=False, glob_patterns=[""])

    os.environ["PYPI_TOKEN"] = "test"
    config.update({"repository": "http://test.pypi.org/legacy/"})

# Generated at 2022-06-24 02:00:19.371190
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns = "a")
    upload_to_pypi(glob_patterns = "a,b")
    upload_to_pypi(glob_patterns = "a,b,c")

# Generated at 2022-06-24 02:00:29.829758
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_env_username(name, value):
        os.environ["PYPI_USERNAME"] = "test_user"
        os.environ["PYPI_PASSWORD"] = "test_pass"
    with patch("os.environ.get", mock_env_username):
        with patch("subprocess.Popen") as mock_subproc_popen:
            # When
            upload_to_pypi()
            # Then
            assert mock_subproc_popen.call_args == call(
                "twine upload -u 'test_user' -p 'test_pass' 'dist/*'"
            )
    def mock_env_token(name, value):
        os.environ["PYPI_TOKEN"] = "test_token"

# Generated at 2022-06-24 02:00:30.767512
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = "dist")

# Generated at 2022-06-24 02:00:32.858437
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        "dist",
        skip_existing = False,
        glob_patterns = ["*.whl"],
    )

# Generated at 2022-06-24 02:00:42.583595
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Tests for upload_to_pypi
    # Test 1 - token
    token = "pypi-fake-token-1223"
    # Test 1.a - verify token is set in environment
    assert upload_to_pypi() == ImproperConfigurationError("Missing credentials for uploading to PyPI")
    os.environ["PYPI_TOKEN"] = token
    # Test 1.b - verify proper credentials are set in arguments
    assert "-u '__token__' -p '{}'".format(token) in upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test 2 - username and password
    username = "test_user"
    password = "test_password"
    # Test 2.a - verify username and password are set in the environment
    assert upload_to

# Generated at 2022-06-24 02:00:51.350296
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = "__token__"
    password = "pypi-asdfasdfasdfasdfjhaskldjfhasklfhalsjfhljashkldf"
    dist = '"dist/*.tar.gz"'
    repository = "pypi"
    skip_existing_param = " --skip-existing"
    expected_command = f"twine upload -u '{username}' -p '{password}' -r '{repository}'{skip_existing_param} {dist}"

# Generated at 2022-06-24 02:00:55.776236
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Successful upload function call
    assert upload_to_pypi(path="dist") == None
    # AssertionError raised since username and password are missing
    try:
        upload_to_pypi()
    except AssertionError as a_e:
        assert a_e.args[0] == "Missing credentials for uploading to PyPI"
    # AssertionError raised since token does not contain 'pypi-'
    try:
        upload_to_pypi(token='hello')
    except AssertionError as a_e:
        assert a_e.args[0] == 'PyPI token should begin with "pypi-"'

# Generated at 2022-06-24 02:00:56.636666
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-24 02:00:58.541968
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi == "twine upload -p 'password' -u 'user' --skip-existing 'path/to/dist/*'"

# Generated at 2022-06-24 02:01:08.650042
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Mock invoke.run
    from unittest.mock import patch
    from semantic_release.tests.invoke import mocked_run

    with patch("invoke.run", new=mocked_run):
        upload_to_pypi()
        assert mocked_run.call_args_list[0][0][0] == (
            "twine upload "
            "-u 'username' "
            "-p 'password' "
            "-r 'pypi' "
            '"dist/python_semantic_release-*.whl"'
        )
        mocked_run.reset_mock()

    with patch("invoke.run", new=mocked_run):
        upload_to_pypi(skip_existing=True)

# Generated at 2022-06-24 02:01:09.107248
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:01:19.940211
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from invoke import Context
    from .helpers import fake_context
    from .helpers import mock_run

    repository = "test_repo"
    glob_patterns = ["*.whl"]
    dist = "dist"
    username = "username"
    password = "password"
    token = "pypi-12345678"
    ctx = fake_context(Context())
    ctx.config["repository"] = repository
    ctx.config["repository_url"] = "test_url"
    ctx.config["repository_type"] = "test_type"
    ctx.config["repository_version"] = "test_version"
    ctx.config["repository_name"] = "test_name"

# Generated at 2022-06-24 02:01:21.338878
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 02:01:23.226543
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:01:30.969556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Assert that upload_to_pypi() correctly calls the Twine program.
    """
    from .helpers import mock_run

    username = "my_username"
    password = "my_password"
    repository = "my_repository"
    dist = "my_dist"

    run = mock_run(return_value=None)

    upload_to_pypi(repository=repository, skip_existing=True, glob_patterns=[dist])

    assert run.call_count == 1
    args, kwargs = run.call_args_list[0]
    assert len(args) == 1

# Generated at 2022-06-24 02:01:43.539559
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import subprocess

    # test case 1: without .pypirc file and without environment variables
    try:
        upload_to_pypi()
        assert False, "ImproperConfigurationError was not raised"
    except ImproperConfigurationError:
        assert True, "ImproperConfigurationError was raised"

    # test case 2: with .pypirc file and without environment variables
    # FIXME: this requires a .pypirc file, so can't be included in the test suite
    # home_dir = os.environ.get("HOME", "")
    # if os.path.isfile(os.path.join(home_dir, ".pypirc")):
    #     output = subprocess.check_output(["twine", "--version"]).decode()
    #     version = output.strip()
    #     upload_to_

# Generated at 2022-06-24 02:01:50.450955
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    assert run("python setup.py bdist_wheel")
    assert run("python setup.py sdist")

    import shutil
    shutil.rmtree("dist")
    assert os.path.exists("dist") is False
    upload_to_pypi()
    assert os.path.exists("dist") is True

# Generated at 2022-06-24 02:01:51.558765
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", True, ["*.whl"]) == None

# Generated at 2022-06-24 02:01:52.342406
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:01:53.765287
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    pass

# Generated at 2022-06-24 02:01:56.531375
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:02:01.885781
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Basic test for function upload_to_pypi.
    """
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)


if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-24 02:02:02.658124
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:02:07.768163
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Mocking invoke call"""
    # Mocking call of invoke
    env_variables_to_mock = [
        "PYPI_TOKEN",
    ]
    param_variables_to_mock = [
        "skip_existing",
    ]
    local_variables = locals()
    for variable in env_variables_to_mock:
        os.environ[variable] = local_variables[variable]
    run = lambda x: None
    upload_to_pypi()

# Generated at 2022-06-24 02:02:09.611273
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Assume that the function upload_to_pypi works fine
    # if no exception is raised
    upload_to_pypi()

# Generated at 2022-06-24 02:02:20.587402
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import unittest
    import unittest.mock
    from typing import Tuple
    from .helpers import LoggedFunction
    import os
    import os.path
    from invoke import run

    # Test helper for mocking `run`
    class TestCase(unittest.TestCase):
        def assertRunCalled(
            self,
            args: Tuple,
            kwargs: dict = None
        ):
            """Check `run` was called with the given args, and exit the test.
            """
            self.assertEqual(run.call_args[0], args)
            if kwargs:
                self.assertEqual(run.call_args[1], kwargs)
            self.assertIs(True, True)
            self.test_complete = True
            raise SystemExit


# Generated at 2022-06-24 02:02:21.759667
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("path", True, ["file"])

# Generated at 2022-06-24 02:02:32.473916
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypi_token = "pypi-00000000"

    # Test if we can upload to Test PyPI without a token
    upload_to_pypi(repository="testpypi")

    # Test that we fail if there is no credentials or .pypirc
    os.environ.pop("PYPI_TOKEN", None)
    os.environ.pop("PYPI_USERNAME", None)
    os.environ.pop("PYPI_PASSWORD", None)
    os.environ["HOME"] = os.getcwd()
    import shutil
    if os.path.isfile("~/.pypirc"):
        shutil.rmtree("~/.pypirc")


# Generated at 2022-06-24 02:02:40.938894
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.chdir(
            os.path.join(os.path.abspath(os.path.dirname(__file__)), "..", "examples")
        )
        upload_to_pypi(path=os.path.join(".", "dist"), glob_patterns=["*.whl", "*.tar.gz"])
    except Exception as e:
        print(e)


if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-24 02:02:50.180307
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert isinstance(upload_to_pypi.logger, logging.Logger)
    assert upload_to_pypi.__name__ == "upload_to_pypi"
    assert upload_to_pypi.__qualname__ == "upload_to_pypi"
    assert isinstance(upload_to_pypi.__doc__, str)
    assert upload_to_pypi.__module__ == "semantic_release.hvcs.vcs.upload_to_pypi"

    assert upload_to_pypi(path = "dist", skip_existing = False, glob_patterns = None) == None

# Generated at 2022-06-24 02:02:55.278145
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def check_function(
        path, skip_existing, glob_patterns,
    ):
        try:
            upload_to_pypi(path, skip_existing, glob_patterns)
        except ImproperConfigurationError:
            raise AssertionError(
                "The function upload_to_pypi is not working correctly"
            )

    os.environ["PYPI_TOKEN"] = "pypi-token"
    check_function("dist", True, ["*"])
    check_function("dist", False, [])
    check_function("dist", False, ["*"])
    check_function("dist", False, ["*", "*"])

    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

# Generated at 2022-06-24 02:02:55.860701
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 02:02:57.102633
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:07.408628
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for ``upload_to_pypi``.
    """
    from unittest import mock
    from semantic_release.hvcs import git

    def _check_git(*args, **kwargs):
        if args[0] == "config":
            return "test_name@test_email.com"
        return ""

    with mock.patch.object(git, "get_config") as mock_get_config:
        mock_get_config.side_effect = _check_git
        upload_to_pypi(path="my-package", skip_existing=True, glob_patterns=["a*", "b*"])
        mock_get_config.assert_called()

# Generated at 2022-06-24 02:03:16.650587
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import LoggedFunction
    from mock import patch

    # Test with valid PYPI_TOKEN
    with patch.object(LoggedFunction, "__call__") as mock_call:
        with patch.dict(
            "os.environ", {"PYPI_TOKEN": "pypi-testpypitoken"}, clear=True
        ):
            upload_to_pypi()
            mock_call.assert_called_once_with()
            args_string, kwargs = mock_call.call_args
            assert "twine upload -u '__token__' -p 'pypi-testpypitoken' '' " in str(
                args_string
            )

    # Test with no environment variables set

# Generated at 2022-06-24 02:03:19.447114
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """testing function upload_to_pypi
    """
    upload_to_pypi(skip_existing=True)


if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-24 02:03:20.196852
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='dist')

# Generated at 2022-06-24 02:03:21.195598
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='dist', skip_existing=False)

# Generated at 2022-06-24 02:03:21.991417
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:30.599158
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create dist folder
    os.makedirs("dist")
    # Create dummy file in dist folder
    with open("dist/dummy.txt", "w") as file:
        file.write("Some text")
    # Create pypirc file
    with open("/home/user1/.pypirc", "w") as file:
        file.write('[server-login]\n')
        file.write('username: user1\n')
        file.write('password: pass1')
    os.environ["HOME"] = "home/user1"
    upload_to_pypi("dist")

# Generated at 2022-06-24 02:03:32.544008
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:35.666372
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run = lambda x: print('running', x)
    upload_to_pypi(path="dist", run=run)
    assert True

# Generated at 2022-06-24 02:03:46.230662
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Set up function input and expected output
    path = "dist"
    skip_existing = False
    glob_pattern = "*"

    token = "pypi-TOKEN"

    # Set up mocks
    # os.environ.get
    os.environ.get = MagicMock(return_value=token)

    # Config file
    config.get = MagicMock(return_value="")

    # Run function to be tested
    upload_to_pypi(path, skip_existing, [glob_pattern])

    # Check that run was called with the correct arguments
    run.assert_called_once_with(
        'twine upload -u \'__token__\' -p \'pypi-TOKEN\'  "dist/*"'
    )

# Generated at 2022-06-24 02:03:48.614400
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_patterns = ["*"]
    assert upload_to_pypi(glob_patterns)

# Generated at 2022-06-24 02:03:59.315956
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest import mock
    from .fixtures import TestCase

    class TestUploadToPyPI(TestCase):

        def setUp(self):
            self.path = "foo"
            self.glob_patterns = ["bar"]
            self.credentials = {
                "pypi-username": (os.environ["PYPI_USERNAME"], "__token__"),
                "pypi-password": (os.environ["PYPI_PASSWORD"], "__token__"),
                "pypi-token": (os.environ["PYPI_TOKEN"], "pypi-__token__"),
            }
            self.repository = "http://repository.com"

            # Reset config values
            config.__delitem__("pypi_token")
            config.__

# Generated at 2022-06-24 02:04:10.829863
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(*args, **kwargs):
        return True

    # Tests without token
    with mock.patch.dict(
        os.environ,
        {"PYPI_USERNAME": "test", "PYPI_PASSWORD": "test"},
    ), mock.patch.object(invoke, "run", mock_run) as run:
        upload_to_pypi()

        run.assert_has_calls(
            [
                mock.call(
                    "twine upload -u 'test' -p 'test' --skip-existing 'dist/*'"
                )
            ]
        )

    # Tests with token

# Generated at 2022-06-24 02:04:16.908975
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import os
    import json

    current_dir = os.path.dirname(__file__)
    parsed_version = json.loads(open(current_dir + "/fixtures/parsed_version.json").read())
    dist_dir = tempfile.mkdtemp()
    os.chdir(current_dir + "/fixtures")
    run("python setup.py sdist bdist_wheel --dist-dir='{}'".format(dist_dir))
    wheel_paths = glob.glob(dist_dir + "/*.whl")
    wheel_path = wheel_paths[0] if wheel_paths else None
    os.chdir(current_dir)

    assert wheel_path is not None
    assert os.path.isfile(wheel_path)

    os

# Generated at 2022-06-24 02:04:19.299241
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    upload_to_pypi(glob_patterns=["a","b","c"])

# Generated at 2022-06-24 02:04:28.489445
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import setup_environment
    from .helpers import unset_environment

    setup_environment()

# Generated at 2022-06-24 02:04:29.431537
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO
    assert False

# Generated at 2022-06-24 02:04:34.217659
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-24 02:04:36.589228
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Function to test upload_to_pypi.
    """

    assert upload_to_pypi(skip_existing=False) == "twine upload "

# Generated at 2022-06-24 02:04:41.300268
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='/Users/sandy/Documents/Play/bitbucket',skip_existing= False,glob_patterns=None)


__all__ = ("upload_to_pypi")

# Generated at 2022-06-24 02:04:44.892120
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:04:53.840467
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi
    """
    # all files in dist are uploaded
    with open("myfile", 'w+') as f:
        f.write("this is myfile")
    with open("yourfile", 'w+') as f:
        f.write("this is yourfile")
    upload_to_pypi(path="./")
    os.remove("myfile")
    os.remove("yourfile")
    # only myfile is not uploaded
    with open("myfile", 'w+') as f:
        f.write("this is myfile")
    upload_to_pypi(path="./", skip_existing=True, glob_patterns=["myfile", "yourfile"])
    os.remove("myfile")

# Generated at 2022-06-24 02:04:54.339964
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True == True

# Generated at 2022-06-24 02:04:59.355752
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from distutils.spawn import find_executable

    if not find_executable("twine"):
        raise Exception("twine is not installed, stop.")

    # Setup
    path = 'test/test_assets/dist'

    # Execute
    upload_to_pypi(path=path, glob_patterns=["*.whl"])

# Generated at 2022-06-24 02:05:00.692909
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == (
        "twine upload  'dist/'"
    )

# Generated at 2022-06-24 02:05:09.034359
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    dist = "dist"
    glob_patterns = ["*"]
    username = "__token__"
    token = "pypi-"
    password = token

    repository = None
    repository_arg = f" -r '{repository}'" if repository else ""

    username_password = (
        f"-u '{username}' -p '{password}'" if username and password else ""
    )

    dist = " ".join(
        ['"{}/{}"'.format(dist, glob_pattern.strip()) for glob_pattern in glob_patterns]
    )

    skip_existing = False
    skip_existing_param = " --skip-existing" if skip_existing else ""

    test_command = f"twine upload {username_password}{repository_arg}{skip_existing_param} {dist}"
   

# Generated at 2022-06-24 02:05:11.542697
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("/path/to/dist", skip_existing = True, glob_patterns = ['glob'])

# Generated at 2022-06-24 02:05:19.289849
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockRun
    run.run = MockRun()
    upload_to_pypi("path", skip_existing=True, glob_patterns=["*"])
    assert run.run.call_args[0][0] == 'twine upload --skip-existing "path/\\*"'
    upload_to_pypi(glob_patterns=["twine*", "py2*"])
    assert run.run.call_args[0][0] == 'twine upload "dist/twine\\*" "dist/py2\\*"'

# Generated at 2022-06-24 02:05:20.205727
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:05:24.151471
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist",skip_existing=False,glob_patterns="*")

# Generated at 2022-06-24 02:05:26.545414
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("fake-path") is None

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-24 02:05:28.406093
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:05:29.302772
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert not upload_to_pypi()

# Generated at 2022-06-24 02:05:34.335782
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("/path/to/some/dist", False, ["*", "*.*"])

# Generated at 2022-06-24 02:05:45.805811
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Verify uploads with and without API token
    """
    # create and delete a dummy file
    os.system("echo hello | tee dist/test.txt")
    os.system("rm dist/test.txt")
    # test without API token
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    result1 = upload_to_pypi("dist", True, ["test.txt"])
    # test with API token