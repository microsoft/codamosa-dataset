

# Generated at 2022-06-24 01:55:42.744728
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-24 01:55:53.631887
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    setattr(config._Config, "repository", "https://test.pypi.org/legacy/")

    # Test with token secret
    setattr(os.environ, "PYPI_TOKEN", "pypi-abcdefghijklmnopqrstuvwxyz")
    assert os.environ.get("PYPI_TOKEN", None)

    # Test with username and password
    setattr(os.environ, "PYPI_USERNAME", "pypi-username")
    setattr(os.environ, "PYPI_PASSWORD", "pypi-password")
    assert os.environ.get("PYPI_USERNAME", None) and os.environ.get("PYPI_PASSWORD", None)

    # Test with missing credentials
    setattr

# Generated at 2022-06-24 01:56:01.001526
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .test_project.utils.git import run_git_command
    from .test_project.utils.files import create_files, delete_files
    from .test_project.utils.env import set_env_vars, unset_env_vars
    
    # Clean up the test project directory
    run_git_command("rm -r dist", cwd="test_project")

    # Create test files
    create_files(["test_project/dist/test_project-0.0.0-py3-none-any.whl"])

    # Test with username and password
    set_env_vars({"PYPI_USERNAME": "test", "PYPI_PASSWORD": "test"})
    upload_to_pypi(path="test_project/dist")
    unset_env_v

# Generated at 2022-06-24 01:56:09.406218
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    env = {
        "PYPI_USERNAME": "test_username",
        "PYPI_PASSWORD": "test_password",
        "HOME": "test_home",
    }
    from mock import patch
    from semantic_release.hvcs import write_file

    with patch("os.environ.get", lambda name: env[name]):
        with patch("os.path.isfile", lambda a: True):
            with patch("invoke.run") as mock_run:
                upload_to_pypi(
                    path="dist", skip_existing=False, glob_patterns=["filename1", "filename2"]
                )

# Generated at 2022-06-24 01:56:11.073034
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="./dist", glob_patterns=["*"])

# Generated at 2022-06-24 01:56:12.206311
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist")

# Generated at 2022-06-24 01:56:17.125728
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run_args = upload_to_pypi.__globals__["run"]
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    run_args.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-WDXh0a0VcUULl6p8V7o0rr43cod09V7' 'dist/*'"
    )

# Generated at 2022-06-24 01:56:27.080574
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Check that the upload_to_pypi function is behaving as expected.

    :return: None
    """
    os.environ["PYPI_TOKEN"] = "pypi-1234"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    try:
        upload_to_pypi()
        raise AssertionError("Missing credentials exception was not raised")
    except ImproperConfigurationError:
        pass

    home_

# Generated at 2022-06-24 01:56:37.566340
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "test_path"
    glob_pattern = "test_pattern"
    skip_existing = "True"
    token = "test_token"
    username = "test_username"
    password = "test_password"
    repo = "test_repo"

    config.setup(
        {
            "repository": {
                "url": "test_repo"
            }
        }
    )

    def mock_run(*args, **kwargs):
        assert "twine upload" in args[0]
        assert path in args[0]
        assert glob_pattern in args[0]
        assert skip_existing in args[0]
        if token:
            assert token in args[0]
        else:
            assert username in args[0]
            assert password in args[0]
        assert repo

# Generated at 2022-06-24 01:56:40.654014
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        with open("{}/sample.txt".format(tmpdirname), "w") as temp:
            temp.write("sample")

        upload_to_pypi(tmpdirname)

# Generated at 2022-06-24 01:56:46.612306
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import sys
    import shutil
    import tempfile
    import time

    if not os.path.isdir("dist"):
        os.mkdir("dist")

    filename = "dist/test_dist_{}.txt".format(int(time.time()))

    with open(filename, 'w+') as f:
        f.write("This is a test")

    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass

    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "pass"

    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass

    # Test with a real repository

# Generated at 2022-06-24 01:56:50.023685
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="path")

# Generated at 2022-06-24 01:56:56.864414
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import Runner

    r = Runner()
    r.invoke(upload_to_pypi, ["--help"])
    r.invoke(
        upload_to_pypi,
        [
            "--glob-patterns",
            "a",
            "--glob-patterns",
            "b",
            "--glob-patterns",
            "c",
            "--path",
            "d/e/f",
            "--skip-existing",
        ],
        run_exit=False,
    )
    assert r.command_args == [
        "twine",
        "upload",
        "--skip-existing",
        "d/e/f/a",
        "d/e/f/b",
        "d/e/f/c",
    ]


# Generated at 2022-06-24 01:56:58.156947
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:56:59.995295
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["*"]
    )

# Generated at 2022-06-24 01:57:00.823028
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert run("invoke upload-to-pypi")

# Generated at 2022-06-24 01:57:02.185291
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() is None

# Generated at 2022-06-24 01:57:03.619527
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:57:04.615014
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 01:57:14.644370
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil

    d = tempfile.mkdtemp()
    open(os.path.join(d, 'test.txt'), 'a').close()

    os.environ['PYPI_TOKEN'] = 'pypi-123'

    try:
        upload_to_pypi(d, glob_patterns=['*.txt'])
    except Exception:
        assert False, 'upload_to_pypi call should not raise exception'

    # let's make sure .pypirc is not present - it is only used for the exception
    os.environ['HOME'] = d


# Generated at 2022-06-24 01:57:25.694168
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest

    from .helpers import MockFunction, MockRun

    # Mock run() so we don't actually run anything
    original_run = run
    run = MockRun(original_run)

    # Mock set_config so we can test defaults
    original_set_config = config.set
    set_config = MockFunction(original_set_config)

    # Happy path
    config.set = set_config
    upload_to_pypi()
    assert run.command.startswith("twine upload")

    # Test skipping files that already exist on PyPI
    run.command = ""
    upload_to_pypi(skip_existing=True)
    assert run.command.startswith("twine upload")
    assert "--skip-existing" in run.command

    # Test PyPI repository
    run.command

# Generated at 2022-06-24 01:57:34.579024
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Assert upload_to_pypi fails if no credentials provided
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        assert True
    else:
        assert False

    # Assert upload_to_pypi fails if only one credential provided
    try:
        upload_to_pypi(username="user", password=None)
    except ImproperConfigurationError:
        assert True
    else:
        assert False

    # Assert upload_to_pypi raises exception if token does not start with
    # "pypi-"
    try:
        upload_to_pypi(token="notPypi")
    except ImproperConfigurationError:
        assert True
    else:
        assert False

    # Assert upload_to_pypi raises exception if token is set but username

# Generated at 2022-06-24 01:57:35.474589
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    true = upload_to_pypi()

# Generated at 2022-06-24 01:57:40.777011
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == LoggedFunction(logger)
    assert upload_to_pypi("dist") == LoggedFunction(logger)
    assert upload_to_pypi("dist", False) == LoggedFunction(logger)
    assert upload_to_pypi("dist", False, ["*"]) == LoggedFunction(logger)

# Generated at 2022-06-24 01:57:51.944915
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ TODO: Should be replaced with pytest fixture.
    """
    import pytest
    from semantic_release.settings import init_config
    from distutils.spawn import find_executable
    import os

    # OK to skip if twine is not installed.
    if not find_executable('twine'):
        pytest.skip('twine is not installed.')

    # OK to skip if not in a a git repo.
    if not os.path.isdir('.git'):
        pytest.skip('Not in a git repo')

    # OK to skip if no credentials available.
    if not os.environ.get('PYPI_USERNAME', None) or not os.environ.get('PYPI_PASSWORD', None):
        pytest.skip('No PyPI credentials found')

    # OK to

# Generated at 2022-06-24 01:58:00.036019
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class EmptyValueError(Exception):
        """Raise when the value is empty."""

    def fake_run(*args, **kwargs):
        return None

    def fake_run_with_token(*args, **kwargs):
        glob_patterns = ["*", "*", "*"]
        if not " ".join(
            ['"{}/{}"'.format("dist", glob_pattern.strip()) for glob_pattern in glob_patterns]
        ):
            raise EmptyValueError
        assert "twine upload -u '__token__' -p 'pypi-token' 'dist/*' 'dist/*' 'dist/*'" in args[0]

    def fake_run_with_username_password(*args, **kwargs):
        glob_patterns = ["*", "*", "*"]

# Generated at 2022-06-24 01:58:03.154540
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # setup function arguments
    path = "dist"
    skip_existing = False
    glob_patterns = []

    # Unit test
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-24 01:58:07.356403
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path= "C:/Users/pranav/PycharmProjects/test/test_data/test_pypi_upload/dist")

# Generated at 2022-06-24 01:58:16.498593
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile
    import warnings
    import sys
    from unittest.mock import patch

    # Fixtures
    temp_folder = tempfile.mkdtemp()
    os.mkdir(temp_folder + (os.path.normpath("/dist")))
    shutil.copyfile(os.path.dirname(__file__) + (os.path.normpath("/my_module-0.0.0.tar.gz")),
                    temp_folder + (os.path.normpath("/dist/my_module-0.0.0.tar.gz")))

    # Unit under test
    from .helpers import upload_to_pypi

# Generated at 2022-06-24 01:58:26.086245
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = os.environ["PYPI_USERNAME"]
    password = os.environ["PYPI_PASSWORD"]
    user_pass = f"-u '{username}' -p '{password}'"

    assert upload_to_pypi.__func__(path='tests/artifacts', skip_existing=True, glob_patterns=["*"])
    assert upload_to_pypi.__func__(path='tests/artifacts', skip_existing=False, glob_patterns=["*"])
    assert upload_to_pypi.__func__(path='tests/artifacts', skip_existing=True, glob_patterns=["setup", "README"])

# Generated at 2022-06-24 01:58:26.560421
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:58:28.270818
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run('mkdir -p dist')
    run('touch dist/test.txt')
    upload_to_pypi('dist', True)
    run('rm -rf dist')

# Generated at 2022-06-24 01:58:39.095237
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test that the upload_to_pypi function correctly builds a twine command.
    """
    with patch("semantic_release.hvcs.pypi.run") as mock_popen:
        upload_to_pypi()
        mock_popen.assert_called_with('twine upload "dist/*"')

    with patch("semantic_release.hvcs.pypi.run") as mock_popen:
        upload_to_pypi(skip_existing=True)
        mock_popen.assert_called_with('twine upload "dist/*" --skip-existing')

    with patch("semantic_release.hvcs.pypi.run") as mock_popen:
        upload_to_pypi(path="foo")
        mock_popen.assert_called_with

# Generated at 2022-06-24 01:58:46.516811
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Make sure that we fail the return code check when we get the required message
    with run("python3.8 -c 1", warn=True) as fail_result:
        assert fail_result.failed
        assert " failed with exit status " in fail_result.stderr
    # Make sure that we fail the return code check when we get the required message
    with run("python3.8 -c 1", warn=True) as fail_result:
        assert fail_result.failed
        assert " failed with exit status " in fail_result.stderr

# Generated at 2022-06-24 01:58:50.483300
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="./dist")

# Generated at 2022-06-24 01:58:51.466084
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("empty")

# Generated at 2022-06-24 01:59:02.435405
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from unittest.mock import patch
    from semantic_release.hvcs.py_pypi import upload_to_pypi
    with patch('os.environ.get', new=lambda x: None):
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()
    with patch('os.environ.get', new=lambda x: 'pypi-token'):
        with patch('invoke.run') as mock_invoke:
            upload_to_pypi()
            mock_invoke.assert_called_with(
                "twine upload -u '__token__' -p 'pypi-token' '*'"
            )

# Generated at 2022-06-24 01:59:04.248275
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

if __name__ == '__main__':
    test_upload_to_pypi()

# Generated at 2022-06-24 01:59:11.386305
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest import mock
    from unittest.mock import call

    with mock.patch("invoke.run.run", autospec=True) as mock_run:
        upload_to_pypi("test_dist")
        mock_run.assert_called_once_with('twine upload  "test_dist/*"')


    with mock.patch("invoke.run.run", autospec=True) as mock_run:
        upload_to_pypi("test_dist", True, ["pattern1", "pattern2"])
        mock_run.assert_called_once_with('twine upload  --skip-existing "test_dist/pattern1" "test_dist/pattern2"')

    with mock.patch("invoke.run.run", autospec=True) as mock_run:
        upload_to_pyp

# Generated at 2022-06-24 01:59:13.907509
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    upload_to_pypi(
        path="tests/test_module", skip_existing=False, glob_patterns=["*"]
    )



# Generated at 2022-06-24 01:59:18.171712
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-fake-token"
    upload_to_pypi()

# Generated at 2022-06-24 01:59:18.680576
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:24.871623
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit tests for function upload_to_pypi"""
    for path in ["dist", "dist/foo.whl", "dist/bar.whl"]:
        yield upload_to_pypi, path, False, None
        yield upload_to_pypi, path, False, ["foo*"]
        yield upload_to_pypi, path, False, ["foo*", "bar*"]
        yield upload_to_pypi, path, True, None
        yield upload_to_pypi, path, True, ["foo*"]
        yield upload_to_pypi, path, True, ["foo*", "bar*"]

# Generated at 2022-06-24 01:59:34.887269
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function, with and without password and/or repository
    :return:
    """
    import tempfile
    import shutil
    import uuid

    def _generate_wheel():
        temp_dir = tempfile.mkdtemp()
        run(f'echo "print(\'Hello World\')" > {temp_dir}/test_upload.py')
        return run(f"cd {temp_dir} && python3 setup.py sdist bdist_wheel", hide=True)


# Generated at 2022-06-24 01:59:41.361889
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_patterns = ["foobar", "123*", "github.com/semantic-release/foo"]
    repo_name = "some_repo"
    path_to_dist = "some_path/to/dist"
    api_token = "pypi-some_api_token"
    username = "some_user"
    password = "some_password"
    user_pass_msg = f"twine upload -u '{username}' -p '{password}' "
    token_msg = f"twine upload --repository-url '{api_token}' "
    tokens_msg = f"twine upload --repository-url '{api_token}' -u '{username}' -p '{password}' "

    filename= 'foo.txt'

# Generated at 2022-06-24 01:59:50.566827
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import subprocess
    import tempfile
    import unittest
    import yaml

    class TestUploadToPyPi(unittest.TestCase):
        @classmethod
        def setUp(cls):
            cls.tmp_path = tempfile.mkdtemp(suffix="-releases")
            cls.twine_path = tempfile.mkdtemp(suffix="-releases")
            cls.twine_files = [
                "twine.py",
                "twine-1.17.1.tar.gz",
                "twine-1.17.1-py2.py3-none-any.whl",
            ]
            cls.twine_files.sort()

# Generated at 2022-06-24 01:59:53.047913
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "pass"

    upload_to_pypi()

# Generated at 2022-06-24 01:59:54.923127
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    logging.debug('test_upload_to_pypi')
    upload_to_pypi(path="/tmp/dist", glob_patterns=["*"])

# Generated at 2022-06-24 01:59:59.026647
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for upload_to_pypi.
    """
    upload_to_pypi("tests/resources/dist")

# Generated at 2022-06-24 02:00:00.414174
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:00:09.199073
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test: upload with environment variable
    os.environ["PYPI_TOKEN"] = "pypi-1234567890"
    try:
        upload_to_pypi()
        assert True
    except ImproperConfigurationError:
        assert False

    # Test: failed upload without credentials (Failure expected)
    os.environ.pop("PYPI_TOKEN", None)
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-24 02:00:11.024152
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:00:11.831620
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()



# Generated at 2022-06-24 02:00:14.121673
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:00:16.117114
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.hvcs.git import get_local_repo_url

    upload_to_pypi(get_local_repo_url())

# Generated at 2022-06-24 02:00:16.608310
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:00:27.426626
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Mock run() so we can test our function
    old_run = run


# Generated at 2022-06-24 02:00:27.978797
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:00:30.285542
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi for code coverage
    """
    assert upload_to_pypi() is None

# Generated at 2022-06-24 02:00:31.405500
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == "twine upload"

# Generated at 2022-06-24 02:00:31.933086
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 02:00:33.050598
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="../dist/", skip_existing=False, glob_patterns=["*"])



# Generated at 2022-06-24 02:00:33.761629
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test
    """
    pass

# Generated at 2022-06-24 02:00:44.152689
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Assert token is taken from environment
    import os
    import sys

    os.environ["PYPI_TOKEN"] = "pypi-test-token"
    original_run = sys.modules["invoke.context"].run
    run_output = ""

    def mock_run(command):
        nonlocal run_output
        run_output = command

    sys.modules["invoke.context"].run = mock_run
    upload_to_pypi()
    sys.modules["invoke.context"].run = original_run

    assert run_output == "twine upload -u '__token__' -p 'pypi-test-token' 'dist/*'"

    # Assert credentials are taken from environment
    os.environ["PYPI_TOKEN"] = ""

# Generated at 2022-06-24 02:00:52.392587
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import subprocess
    import sys
    import time

    # Unit test requirements
    # 1. pypi username/password
    # 2. PYPI_USERNAME, PYPI_PASSWORD env vars
    # 3. twine, invoke
    # 4. dist/*.whl files
    # 5. main section 'name' must match the name of the *.whl files in the dist directory
    # 6. main section 'version' must match the version of the *.whl files in the dist directory
    # 7. main section 'scripts' must contain a delete_dist_files.sh script
    # 8. main section 'scripts' must contain a test_pypi_upload.sh script
    # 9. main section 'description' must include 'Test setup.py for semantic_release'
    # 10. main section 'description' must include 'Only

# Generated at 2022-06-24 02:00:52.877893
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:00:56.066359
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(glob_patterns=["A", "B"])
    upload_to_pypi(glob_patterns="A")

# Generated at 2022-06-24 02:00:59.890363
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    global os
    os = mock.Mock()
    os.environ = {}
    os.environ["HOME"] = "tmp"
    os.path.isfile.return_value = False
    with mock.patch("invoke.run") as run_mock:
        retval = upload_to_pypi()
        assert retval == False

# Generated at 2022-06-24 02:01:01.592057
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='dist', skip_existing=False, glob_patterns=['linux-x64'])

# Generated at 2022-06-24 02:01:02.397507
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-24 02:01:09.476496
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() is None
    assert upload_to_pypi(path='otherPath') is None
    assert upload_to_pypi(skip_existing=True) is None
    assert upload_to_pypi(glob_patterns=["pattern1", "pattern2"]) is None
    assert upload_to_pypi(glob_patterns=["pattern1", "pattern2"], skip_existing=True, path='otherPath') is None
    assert upload_to_pypi(glob_patterns=["pattern1", "pattern2"], skip_existing=True, path='otherPath', token="pypi-ABCD") is None

# Generated at 2022-06-24 02:01:15.845761
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if not getattr(test_upload_to_pypi, "cached_execute", None):
        test_upload_to_pypi.cached_execute = upload_to_pypi

        # Patch run so we don't make a real call.
        def run(cmd: str, **kwargs):
            return cmd

        upload_to_pypi.run = run

    # First, test good results.
    expected = (
        "twine upload -u 'username' -p 'password' -r 'repository' --skip-existing "
        '"dist/glob_pattern_1.whl" "dist/glob_pattern_2.whl"'
    )

# Generated at 2022-06-24 02:01:17.280664
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-24 02:01:20.761211
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path=".", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-24 02:01:22.297914
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    TODO: Add unit tests to test the upload_to_pypi function
    """

# Generated at 2022-06-24 02:01:24.508269
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # We can't test uploading to PyPI, but we can make sure it throws an error if
    # no credentials are found
    # TODO: unittest for this
    pass

# Generated at 2022-06-24 02:01:25.528801
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:01:26.812131
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="src", glob_patterns=["*"]) == 0

# Generated at 2022-06-24 02:01:29.036288
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    :return: bool: test passed / failed
    """
    return True

# Generated at 2022-06-24 02:01:30.282659
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="./", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 02:01:35.767851
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from unittest.mock import patch, MagicMock

    # Create a temporary folder to store the fake dist folder.
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a fake dist folder.
        distdir = os.path.join(tmpdir, "fake_dist")
        os.makedirs(distdir)
        # Create some fake files in it.
        fpulk = open(os.path.join(distdir, "fpulk.txt"), "w+")
        pluf = open(os.path.join(distdir, "pluf.txt"), "w+")
        [f.close() for f in (fpulk, pluf)]

        # Mock invoke.run() to make sure it is called with the right args,
        # and to be able to test the function without actually having

# Generated at 2022-06-24 02:01:40.532330
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing=False, glob_patterns=glob_patterns)

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-24 02:01:44.368816
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.environ["PYPI_TOKEN"] = "pypi-mytoken"
        os.environ["PYPI_USERNAME"] = "myusername"
        os.environ["PYPI_PASSWORD"] = "mypassword"
        upload_to_pypi()
    except Exception as e:
        raise e

# Generated at 2022-06-24 02:01:55.563683
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = "__token__"
    password = "pypi-atesttoken12345"
    repository = "staging"
    glob_pattern = "*.tar.gz"
    path = "dist"

    def stub_run(cmd):
        assert cmd.startswith("twine upload")
        assert f"-u '{username}' -p '{password}'" in cmd
        assert f" -r '{repository}'" in cmd
        assert '"dist/*.tar.gz"' in cmd

    import unittest.mock


# Generated at 2022-06-24 02:02:05.260707
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    from pathlib import Path
    import time
    import mock
    import pytest
    from semantic_release.hvcs import get_vcs
    from semantic_release.settings import build_config
    from semantic_release.settings import prepare_config
    basedir = Path(tempfile.mkdtemp())
    repodir = basedir / "repo"
    repodir.mkdir()
    distdir = basedir / "dist"
    distdir.mkdir()
    whl_file = distdir / "semantic_release-1.0.0-py3-none-any.whl"
    whl_file.touch()

# Generated at 2022-06-24 02:02:09.819162
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    insert = "semantic_release.pypi.upload_to_pypi.run"
    return_value = None
    with mock.patch(insert, return_value=return_value) as mock_fn:
        upload_to_pypi(path="dist", skip_existing=False)
        mock_fn.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' 'dist/'"
        )



# Generated at 2022-06-24 02:02:20.620405
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.hvcs.git import is_dirty, get_remote_url

    from .helpers import LoggedFunctionTest

    with LoggedFunctionTest(logger, "upload_to_pypi", "twine", "upload") as upload_to_pypi_mock:
        with LoggedFunctionTest(logger, "get_remote_url", "twine", "upload") as get_remote_url_mock:
            get_remote_url_mock.return_value = 'git@gitlab.com:user/repo.git'
            upload_to_pypi()
            assert upload_to_pypi_mock.call_count == 1
            assert get_remote_url_mock.call_count == 1

# Generated at 2022-06-24 02:02:21.439302
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:02:21.965983
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:02:29.138284
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Function upload_to_pypi should create a Twine command"""
    assert upload_to_pypi("dist", True, None) == \
           run("twine upload -u \'__token__\' -p \'pypi-xxx\' --skip-existing \"dist/*\"")



# Generated at 2022-06-24 02:02:30.657068
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:02:34.751040
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    global logger
    logger = logging.getLogger(__name__)
    logger.info('testing_upload_to_pypi')

# Generated at 2022-06-24 02:02:35.568543
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Implement unit test for function.
    return

# Generated at 2022-06-24 02:02:45.595355
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release import settings
    from semantic_release.settings import config
    from semantic_release.helpers import os_environ
    from semantic_release.uploaders import upload_to_pypi

    settings.CONFIG_FILE = "tests/fixtures/.release.conf"
    config.reload()

    path = 'tests/fixtures/testpackage'
    token = 'pypi-testtoken'
    username = 'testuser'
    password = 'testpassword'
    repository = 'test-repo-url'
    skip_existing = True
    glob_patterns = ['"*"', "random*"]


# Generated at 2022-06-24 02:02:50.806312
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing = False, glob_patterns=["*"])
    # This does not work due to the tkinter dependency
    # upload_to_pypi("dist", skip_existing = False, glob_patterns=["*"])

# Generated at 2022-06-24 02:02:52.901641
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    @classmethod
    def tearDownClass(cls):
        pass

    def tearDown(self):
        pass

    def setUp(self):
        pass

    def test_upload_to_pypi(self):
        pass
    """
    pass

# Generated at 2022-06-24 02:02:54.237898
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Expecting the functions to be raised when environment variables are not defined
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-24 02:03:05.369675
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "a/b/c"
    glob_patterns = ["*", "*.tar.gz"]
    skip_existing = True
    run_mock = {
        "ok": True,
        "stdout": "",
        "stderr": "",
        "encoding": "utf-8",
        "exited": 0,
        "failed": False,
        "warned": False,
        "command": "twine upload -u '__token__' -p 'pypi-test' --skip-existing 'a/b/c/*' 'a/b/c/*.tar.gz'",
    }
    os_environ = {}

# Generated at 2022-06-24 02:03:12.383785
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = 'test_user'
    password = 'test_pass'
    file = 'test_file.txt'
    path = 'dist'

    class MockEnvironment:
        def get(self, var, default=None):
            if var == 'PYPI_USERNAME':
                return username
            if var == 'PYPI_PASSWORD':
                return password
            return default

    os_mock = MockEnvironment()
    os_mock.path = os.path
    os_mock.path.join = os.path.join

    def run(cmd):
        assert cmd == f"twine upload -u '{username}' -p '{password}' --skip-existing '{path}/{file}'"

    upload_to_pypi(path, True, [file], os_mock, run)

# Generated at 2022-06-24 02:03:20.227486
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    from tempfile import TemporaryDirectory

    from semantic_release.settings import config

    def assert_dist(dist, glob_patterns):
        import glob
        import os
        import zipfile

        assert len(dist) >= len(glob_patterns)

        for pattern in glob_patterns:
            pattern_dist = glob.glob(os.path.join(dist, pattern))
            assert pattern_dist
            assert len(pattern_dist) == 1
            assert os.path.isfile(pattern_dist[0])
            assert zipfile.is_zipfile(pattern_dist[0])

    def assert_twine(path):
        import subprocess

        cmd = ["twine", "upload", path]
        assert subprocess.call(cmd) == 0


# Generated at 2022-06-24 02:03:26.189847
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi.
    """
    # Success case
    # Attempt to get an API token from environment
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi(path="dist", glob_patterns=["**/*", "*"])
    assert "--skip-existing" not in run.calls[0]
    del os.environ["PYPI_TOKEN"]

    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi(path="dist", glob_patterns=["**/*", "*"])
    assert "--skip-existing" not in run.calls[1]

# Generated at 2022-06-24 02:03:35.594160
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # GIVEN a repository with a pypi token
    from semantic_release.settings import config
    from os import environ

    environ["PYPI_TOKEN"] = "pypi-abc"

    # WHEN the function upload_to_pypi is called
    upload_to_pypi()

    # THEN it should build the expected command with the token
    assert config.get("repository") is None
    assert run.calls[0].kwargs["command"] == "twine upload -u '__token__' -p 'pypi-abc' 'dist/*'"

# Generated at 2022-06-24 02:03:37.135157
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi( "dist", False, ["*"])

# Generated at 2022-06-24 02:03:41.600448
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_pypi_response

    with mock_pypi_response():
        upload_to_pypi()

# Generated at 2022-06-24 02:03:45.986035
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run(command):
        assert command == "twine upload -u '__token__' -p 'pypi-test_token' 'dist/pkg.whl'", command

    os.environ["PYPI_TOKEN"] = "pypi-test_token"
    upload_to_pypi(glob_patterns=["pkg.whl"])

# Generated at 2022-06-24 02:03:48.318375
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", glob_patterns=["*", "!*dev*"]) == "twine upload -u '__token__' -p 'pypi-file' \"dist/*\" \"dist/!*dev*\""

# Generated at 2022-06-24 02:03:52.004488
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="path", skip_existing=True, glob_patterns=["*.egg"])

# Generated at 2022-06-24 02:03:54.725481
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    global run
    run = lambda cmd: print(cmd)

    upload_to_pypi()

# Generated at 2022-06-24 02:04:04.419739
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import unindent
    
    class TestRun:
        def __init__(self):
            self.called = 0
            self.command = ""
        
        def __call__(self, c):
            self.called += 1
            self.command = c
    
    def test_with_token(token, patterns, skip_existing, repository):
        r = TestRun()
        from .context import context
        context.config.set("repository", repository)
        with context.setenv("PYPI_TOKEN", token):
            upload_to_pypi("dist", skip_existing, patterns)
        assert r.called == 1

# Generated at 2022-06-24 02:04:06.447403
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:04:08.340111
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Check behaviour of upload_to_pypi."""
    upload_to_pypi()

# Generated at 2022-06-24 02:04:15.995411
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command):
        assert command == (
            "twine upload -u '__token__' -p 'pypi-mytoken' -r 'my_repository' --skip-existing 'dist/myfile.txt' 'dist/myfile2.txt'"
        )

        return "Mock run", "", 0

    old_run = run
    run = mock_run
    env_token = os.environ.get("PYPI_TOKEN")
    os.environ["PYPI_TOKEN"] = "pypi-mytoken"


# Generated at 2022-06-24 02:04:23.721767
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import context_manager_maker
    from .helpers import twine_version_string
    
    context_manager = context_manager_maker(
        twine_version_string,
        "1.11.0",
        "python3 -m twine upload -u __token__ -p pypi-whl --skip-existing ",
    )

    with context_manager as command_string:
        upload_to_pypi(
            path="dist",
            glob_patterns=('"my-package-0.1.0-py2.py3-none-any.whl"'),
        )

# Generated at 2022-06-24 02:04:27.515999
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=['*.whl'])

# Generated at 2022-06-24 02:04:28.682881
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist") is None

# Generated at 2022-06-24 02:04:29.270783
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:04:33.193749
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # should not raise an exception
    upload_to_pypi(path="path", skip_existing=True)

# Generated at 2022-06-24 02:04:35.051991
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Need to get unit test working with Twine
    pass

# Generated at 2022-06-24 02:04:42.971610
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import unittest
    import sys
    import os
    import subprocess

    import mock
    import httpretty
    import responses

    class TestUploadToPyPi(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            open(os.path.join(self.temp_dir, "hello.txt"), "w").close()
            self.temp_file = open("file.txt", "w")
            self.temp_file.close()
            self.temp_file = open("file1.txt", "w")
            self.temp_file.close()


# Generated at 2022-06-24 02:04:43.997742
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Testing upload_to_pypi function"""
    pass

# Generated at 2022-06-24 02:04:53.616207
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    token = os.environ.get("PYPI_TOKEN")
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")

    # Test with API Token
    if token:
        test_token = "test_token"
        os.environ["PYPI_TOKEN"] = test_token
        upload_to_pypi()
        test_twine_with_token(test_token, "__token__", token)
        os.environ["PYPI_TOKEN"] = token

        # Test with API Token that doesn't start with `pypi-`
        test_token = "test_token_2"

# Generated at 2022-06-24 02:05:00.343990
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import subprocess
    import tempfile
    import textwrap

    from unittest.mock import patch
    from invoke.runner import Runner

    def _mock_run(self, command, **kwargs):
        return subprocess.run(
            [i for i in command.split(" ") if i],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            **kwargs,
        )

    with tempfile.TemporaryDirectory() as dirname:
        os.mkdir("{}/dist".format(dirname))
        open("{}/dist/{}".format(dirname, "file.txt"), "w").close()

        runner_original_run = Runner.run
        Runner.run = _mock_run


# Generated at 2022-06-24 02:05:04.559028
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Do this as a unittest, not a doctest
    # doctest: +ELLIPSIS
    assert 1 == 1

# Generated at 2022-06-24 02:05:14.446773
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with a correct configuration
    os.environ["PYPI_TOKEN"] = "pypi-hjd8fhdjf89dhf9dh9dh9dh9dhf9dh"
    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["Python-semantic-release-*"]
    )
    os.environ.pop("PYPI_TOKEN")

    # Test with a wrong configuration
    os.environ["PYPI_TOKEN"] = "hjd8fhdjf89dhf9dh9dh9dh9dhf9dh"

# Generated at 2022-06-24 02:05:16.255345
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that the function upload_to_pypi is executed
    when the repository is of type PyPI
    """
    pass

# Generated at 2022-06-24 02:05:17.248221
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:05:18.506303
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 == 1

# Generated at 2022-06-24 02:05:28.398139
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import TemporaryDirectory, environment_variable
    from .helpers import run

    if run.called:
        run.called = False

    for var in ["PYPI_USERNAME", "PYPI_PASSWORD", "PYPI_TOKEN"]:
        os.environ["PYPI_USERNAME"] = ""
        os.environ["PYPI_PASSWORD"] = ""
        os.environ["PYPI_TOKEN"] = ""

    temp_dir = TemporaryDirectory()
    os.chdir(temp_dir.path)

    with environment_variable("PYPI_TOKEN", "pypi-FAKETOKEN"):
        upload_to_pypi()
    assert run.called

# Generated at 2022-06-24 02:05:30.513547
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='pkg/dist/test', skip_existing=True, glob_patterns=['*'])


# Generated at 2022-06-24 02:05:33.381462
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test upload_to_pypi will fail without any credentials
    import pytest
    from semantic_release.hvcs.exceptions import MissingTokenError
    with pytest.raises(MissingTokenError):
        upload_to_pypi()

# Generated at 2022-06-24 02:05:42.648595
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    glob_pattern = ["*"]
    token = "pypi-mytoken"
    home_dir = "/home/user"

    with invoke.Context(config={"run": {"hide": True}}):
        os.environ["PYPI_TOKEN"] = token
        os.environ["HOME"] = home_dir
        invoke.run.return_value.exited = 0

        upload_to_pypi(path=path, glob_patterns=glob_pattern)

        assert invoke.run.call_count == 1
        assert invoke.run.call_args[0][0] == f"twine upload -u '__token__' -p '{token}' 'dist/*'"

        del os.environ["PYPI_TOKEN"]