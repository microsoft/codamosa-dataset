

# Generated at 2022-06-24 01:55:47.090457
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from unittest.mock import patch
    from semantic_release.hvcs.git import parse_commit_message
    from semantic_release.vcs_helpers import get_current_version

    # Mock git API
    with patch("semantic_release.git.git_push") as git_push:
        git_push.return_value = "git_push"
        with patch("semantic_release.git.git_tag") as git_tag:
            git_tag.return_value = "git_tag"
            with patch("semantic_release.git.git_commit") as git_commit:
                git_commit.return_value = "git_commit"
                # Mock CHANGES.rst
                with patch("semantic_release.summary.write_summary") as write_summary:
                    write

# Generated at 2022-06-24 01:55:49.416251
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:55:52.824145
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("", False, []) == None
    # assert upload_to_pypi("dist", False, ['...']) == None

    with pytest.raises(ImproperConfigurationError) as e_info:
        upload_to_pypi()


# Generated at 2022-06-24 01:55:53.352858
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:55:54.887058
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("path", True, ["test_file"])
    assert True

# Generated at 2022-06-24 01:56:04.288763
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit tests for `upload_to_pypi` function
    """
    from .helpers import MockResult
    from .helpers import mock_run
    from .helpers import clear_runs

    runs = clear_runs()
    glob_patterns = ["*.whl", "*.gz", "*.zip"]
    dist_path = "dist"
    token = "pypi-foo"
    repository = "test-repo"

# Generated at 2022-06-24 01:56:04.757687
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:56:11.037697
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test running function upload_to_pypi"""
    import os
    import pytest
    from semantic_release.settings import config
    from semantic_release.settings import create_settings

    # TODO: Test when PYPI_TOKEN is set
    # TODO: Test when PYPI_USERNAME and PYPI_PASSWORD are set
    # TODO: Test when neither are set, but .pypirc is present
    # TODO: Test when neither are set and .pypirc is not present


    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

    # pylint: disable=unused-argument
    def mocked_run(*args, **kwargs):
        pass


# Generated at 2022-06-24 01:56:14.246949
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-token-test"
    upload_to_pypi(
        path="dist",
        skip_existing=False,
        glob_patterns=["*"],
    )

# Generated at 2022-06-24 01:56:22.517889
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import call
    run = MagicMock()
    with patch('builtins.print', MagicMock()) as mock_print, \
         patch('semantic_release.hvcs.git.logger', MagicMock()), \
         patch('semantic_release.hvcs.git.run', run) as mock_run:
        upload_to_pypi(path="test", skip_existing=True, glob_patterns=["*"])
    assert mock_print.call_count == 1
    assert mock_run.call_count == 1
    assert run.call_args == call('twine upload --skip-existing "test/*"')


# Generated at 2022-06-24 01:56:23.050875
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:56:26.717871
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    test_path = 'tests'
    test_glob_pattern = ['*.txt']
    try:
        upload_to_pypi(test_path, glob_patterns=test_glob_pattern)
    except ImproperConfigurationError as e:
        print(e)


# Generated at 2022-06-24 01:56:27.341754
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 01:56:32.215259
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi

    :return:
    """
    import pytest

    path = "dist"
    glob_patterns = ["*"]
    skip_existing = False
    try :
        upload_to_pypi(path, skip_existing, glob_patterns)
    except ImproperConfigurationError:
        assert True
    else :
        assert False

# Generated at 2022-06-24 01:56:33.574035
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()


# Generated at 2022-06-24 01:56:43.084844
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil

    from semantic_release.settings import config

    class Env(object):
        def __init__(self, **kwargs):
            self.environ = os.environ.copy()
            self.environ.update(kwargs)

        def __enter__(self):
            os.environ.clear()
            os.environ.update(self.environ)

        def __exit__(self, type, value, traceback):
            os.environ.clear()
            os.environ.update(self.environ)

    def create_distribution_files(number_of_files=3):
        for index in range(number_of_files):
            with open(f"dist/{index}", "w") as f:
                f.write("")


# Generated at 2022-06-24 01:56:51.946653
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class MockRun:
        def __init__(self, func_name, args):
            self.func_name = func_name
            self.args = args

    def mock_run(command):
        return MockRun(command.split(" ")[0], " ".join(command.split(" ")[1:]))

    old_run = run
    run = mock_run

    # Test credentials from environment config
    os.environ["PYPI_TOKEN"] = "pypi-fake-token"
    upload_to_pypi()
    assert run.func_name == "twine"
    assert run.args == "upload -u '__token__' -p 'pypi-fake-token'  \"dist/*\""


# Generated at 2022-06-24 01:56:57.595062
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    import tempfile
    import os

    tmpdir = tempfile.mkdtemp()
    os.makedirs(tmpdir + "/dist")

# Generated at 2022-06-24 01:56:58.626558
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Unit test needs to run in an invoke task
    # It will be run by the tests/test_pypi.py file
    pass

# Generated at 2022-06-24 01:57:00.541889
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-24 01:57:01.526726
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert hasattr(upload_to_pypi, "__call__")

# Generated at 2022-06-24 01:57:03.104810
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    '''test the upload_to_pypi method'''
    os.environ["PYPI_TOKEN"] = "test"



# Generated at 2022-06-24 01:57:03.765447
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:57:07.478393
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test_dist", glob_patterns=["test_file"])

# Generated at 2022-06-24 01:57:08.265309
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:57:09.507727
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 01:57:15.893008
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Check that environment is set
    assert os.environ.get("PYPI_TOKEN")
    assert os.environ.get("PYPI_USERNAME")
    assert os.environ.get("PYPI_PASSWORD")
    assert os.environ.get("HOME")
    assert os.path.isfile(os.path.join(os.environ.get("HOME"), ".pypirc"))

    # Check that credentials are correct
    assert os.environ.get("PYPI_TOKEN").startswith("pypi-")
    assert os.environ.get("PYPI_TOKEN") == os.environ.get("PYPI_USERNAME") + ":" + os.environ.get("PYPI_PASSWORD")

# Generated at 2022-06-24 01:57:17.896656
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist")
    assert True

# Generated at 2022-06-24 01:57:22.957077
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import set_environment

    set_environment(
        repository="testrepo", PYPI_TOKEN="pypi-1234", PYPI_USERNAME="testuser", PYPI_PASSWORD="testpass",
    )
    upload_to_pypi()

# Generated at 2022-06-24 01:57:31.764546
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == "twine upload  *.whl"
    assert upload_to_pypi(glob_patterns=["*PKG.whl"]) == "twine upload  *PKG.whl"
    assert (
        upload_to_pypi(path="SOME\\PATH", skip_existing=True)
        == "twine upload  --skip-existing \"SOME\\PATH\\*.whl\""
    )

# Generated at 2022-06-24 01:57:34.350768
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test to check if upload_to_pypi is uploading packages to PyPI
    """
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 01:57:39.717555
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the function upload_to_pypi, to see if it works as intended.
    """
    os.environ["PYPI_TOKEN"] = "pypi-test-token"
    glob_patterns = ["*"]
    upload_to_pypi("dist", glob_patterns=glob_patterns)

# Generated at 2022-06-24 01:57:48.720025
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import generate_wheel

    import tempfile
    import zipfile
    from os.path import isfile, join

    tmp_dir = tempfile.gettempdir()
    file_name = "test-package-0.0.0-py3-none-any.whl"
    path = generate_wheel()
    os.remove(path)
    tmp_dir_path = join(tmp_dir, file_name)
    if isfile(tmp_dir_path):
        os.remove(tmp_dir_path)
    assert not isfile(tmp_dir_path)
    upload_to_pypi(path=tmp_dir, glob_patterns=[file_name])
    assert isfile(tmp_dir_path)

# Generated at 2022-06-24 01:57:58.677366
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test if dist folder is uploaded successfully"""
    import pytest
    from .helpers import LoggedFunction
    from .helpers import log_file_contains
    from .helpers import reset_log
    import logging
    from invoke import run

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # generate log output
    log_file_path = "upload_to_pypi_test.log"
    handler = logging.FileHandler(log_file_path)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    reset_log(log_file_path)
    upload_to_pypi()

# Generated at 2022-06-24 01:58:04.673091
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(path="path")
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(glob_patterns=["*"])
    upload_to_pypi(skip_existing=True, glob_patterns=["*"])
    upload_to_pypi(path="path", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 01:58:07.962857
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-24 01:58:11.208590
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()



# Generated at 2022-06-24 01:58:16.652916
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command):
        assert command == (
                f"twine upload -u '__token__' -p 'pypi-secret123' {skip_existing_param} "
                f'"dist/test*"'
            )

    skip_existing_param = " --skip-existing"
    os.environ["PYPI_TOKEN"] = "pypi-secret123"
    old_run = run
    run = mock_run
    try:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["test*"])
    finally:
        run = old_run

# Generated at 2022-06-24 01:58:26.262882
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set environment variables for the tests
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    os.environ["REPO_NAME"] = "test_repo"

    # Test correct case
    upload_to_pypi(path="path")
    assert run.calls[0][0] == "twine upload -u 'test_username' -p 'test_password' -r 'test_repo' 'path/*'"

    # Test error case
    upload_to_pypi(path="path")
    assert run.calls[1][0] == "twine upload -u 'test_username' -p 'test_password' -r 'test_repo' 'path/*'"

# Generated at 2022-06-24 01:58:27.701998
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi is not None

# Generated at 2022-06-24 01:58:28.960204
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path=None, skip_existing=None, glob_patterns=None) == None

# Generated at 2022-06-24 01:58:31.945226
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:58:35.494865
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    '''
    This is a unit test for the function upload_to_pypi which is used to upload
    the created project onto pypi which it is a public repository.
    It checks whether the function has the right number of arguments and with
    the right names that we assigned.
    '''
    assert upload_to_pypi.__code__.co_argcount == 3
    assert upload_to_pypi.__code__.co_varnames == ('path', 'skip_existing', 'glob_patterns')

# Generated at 2022-06-24 01:58:45.841515
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # token is empty
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        print("missing credentials error")
    # token is null
    try:
        os.environ["PYPI_TOKEN"] = None
        upload_to_pypi()
    except ImproperConfigurationError:
        print("missing credentials error")
    # token is valid
    os.environ["PYPI_TOKEN"] = "token"
    upload_to_pypi()
    # token is invalid
    os.environ["PYPI_TOKEN"] = False
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        print("missing credentials error")
    os.environ["PYPI_TOKEN"] = None
    # username and password are valid
   

# Generated at 2022-06-24 01:58:46.194583
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:58:49.745831
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:58:50.607838
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    #TODO
    pass

# Generated at 2022-06-24 01:59:01.842694
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import mock
    from semantic_release.settings import config

    # Mock run to check that run gets called correctly
    with mock.patch.object(run, "__call__", return_value=None) as mock_run:
        upload_to_pypi(
            "dist",
            skip_existing=False,
            glob_patterns=["glob1", "glob2", "glob3", "glob4"],
        )
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' 'dist/glob1' 'dist/glob2' 'dist/glob3' 'dist/glob4'"
        )

    # Mock run to check that run gets called correctly

# Generated at 2022-06-24 01:59:11.854343
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    username = "__token__"
    password = "pypi-token"
    repository = "test"
    glob_patterns = ["test1", "test2"]
    skip_existing = True
    repository_arg = f" -r '{repository}'"
    skip_existing_param = " --skip-existing"
    dist = " ".join([f'"{path}/{glo_pat.strip()}"' for glo_pat in glob_patterns])
    import invoke

    orig_run = invoke.run

    def mock_run(command, **kwargs):
        if 'twine upload' not in command:
            orig_run(command)
        else:
            assert username in command
            assert password in command
            assert repository_arg in command
            assert skip_existing_param

# Generated at 2022-06-24 01:59:12.866076
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:23.276230
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert (
        upload_to_pypi.__doc__
        == "Upload wheels to PyPI with Twine.\n\nWheels must already be created and stored at the given path.\n\nCredentials are taken from either the environment variable\n``PYPI_TOKEN``, or from ``PYPI_USERNAME`` and ``PYPI_PASSWORD``.\n\n:param path: Path to dist folder containing the files to upload.\n:param skip_existing: Continue uploading files if one already exists.\n    (Only valid when uploading to PyPI. Other implementations may not support this.)\n:param glob_patterns: List of glob patterns to include in the upload (['*'] by default)."
    )

# Generated at 2022-06-24 01:59:32.679044
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function
    """
    from semantic_release import upload_to_pypi
    import os

    before = os.environ.get("PYPI_USERNAME")
    os.environ["PYPI_USERNAME"] = "username_test"
    os.environ["PYPI_PASSWORD"] = "password_test"
    upload_to_pypi()
    os.environ["PYPI_USERNAME"] = before
    before = os.environ.get("PYPI_PASSWORD")
    del os.environ["PYPI_PASSWORD"]
    upload_to_pypi()
    if before:
        os.environ["PYPI_PASSWORD"] = before

# Generated at 2022-06-24 01:59:37.386921
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    twine_upload_command = """twine upload -u '__token__' -p 'pypi-xxxxxxxxxxxxxxxxxxxx' --skip-existing 'dist/file1.whl' 'dist/file2.whl'"""  # noqa
    assert upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["file1.whl", "file2.whl"]) == twine_upload_command

# Generated at 2022-06-24 01:59:38.229220
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(skip_existing=True)

# Generated at 2022-06-24 01:59:48.884831
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import reset_config_and_changelog_versions

    # To test with a PyPI token, set PYPI_TOKEN=pypi-valid_token.
    # export PYPI_TOKEN=pypi-valid_token in bash or python -m os.environ["PYPI_TOKEN"]="pypi-valid_token" in python
    token = os.environ.get("PYPI_TOKEN")
    if token:
        reset_config_and_changelog_versions()
        config.username = "__token__"
        config.password = token
        upload_to_pypi()

    # To test with a username and password, set PYPI_USERNAME and PYPI_PASSWORD.
    # export PYPI_USERNAME=valid_username
   

# Generated at 2022-06-24 01:59:49.399091
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:50.232683
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("test_path")

# Generated at 2022-06-24 01:59:51.016282
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:53.493401
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    wheels = ["foo.whl", "bar.whl"]
    upload_to_pypi(path = "dist", skip_existing = False, glob_patterns = wheels)

# Generated at 2022-06-24 01:59:54.998847
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    assert True

# Generated at 2022-06-24 01:59:58.444719
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Ensure function does not raise an exception
    upload_to_pypi()

# Generated at 2022-06-24 01:59:59.000051
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:00:02.686236
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create dist folder
    os.mkdir("dist")

    # Create file to be uploaded
    with open("dist/upload_to_pypi.txt", "w") as f:
        f.write("Test file")

    # Run function with only required arguments
    upload_to_pypi()

    # Remove file and dist folder
    os.remove("dist/upload_to_pypi.txt")
    os.rmdir("dist")

# Generated at 2022-06-24 02:00:11.626490
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import hashlib

    # Function params
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]

    # Expected params
    expected_token = "pypi-123"
    expected_repository = "some_repository"
    expected_username = "__token__"
    expected_password = "pypi-123"
    expected_skip_existing = ""
    expected_dist = '"dist/*"'

    # Run code
    os.environ["PYPI_TOKEN"] = expected_token
    os.environ["PYPI_USERNAME"] = expected_username
    os.environ["PYPI_PASSWORD"] = expected_password

    cfg = config._config.copy()
    cfg["repository"] = expected_repository

   

# Generated at 2022-06-24 02:00:19.861536
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypi_username = '__token__'
    pypi_password = 'pypi-pytest'
    pypi_repository = 'test.pypi.org'
    current_working_directory = os.getcwd()

    os.environ['PYPI_USERNAME'] = pypi_username
    os.environ['PYPI_PASSWORD'] = pypi_password
    os.environ['PYPI_REPOSITORY'] = pypi_repository

    def _upload():
        upload_to_pypi()

    assert _upload() == 'twine upload -u __token__ -p pypi-pytest -r test.pypi.org "./dist/*"'

# Generated at 2022-06-24 02:00:20.409700
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:00:30.804153
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import LoggedFunction

    _logger = LoggedFunction.create_logger()

    config.update({"repository": "pypitest"})

    def _check_for_error_message(error_message):
        if _logger.call_count == 1:
            call_arguments = _logger.call_args[0]
            assert error_message in call_arguments[0]
        else:
            assert False

    # Test with wrong token
    os.environ["PYPI_TOKEN"] = "wrong_token"
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        os.environ.pop("PYPI_TOKEN")
    else:
        assert False

# Generated at 2022-06-24 02:00:34.200296
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run_mock(command: str):
        assert command.startswith("twine upload ")
        assert "pypi-token" in command
        assert "foo.whl" in command

    run.side_effect = run_mock
    upload_to_pypi("path", True, ["foo.whl"])

# Generated at 2022-06-24 02:00:35.077964
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 02:00:36.395547
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("test_dist", False, [])

# Generated at 2022-06-24 02:00:40.288700
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(*args, **kwargs):
        assert 'twine upload ' in args[0]

    with patch('mock.mock_run', new=mock_run):
        upload_to_pypi()

# Generated at 2022-06-24 02:00:42.395264
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for upload_to_pypi function
    """
    # TODO: Mock run()
    # upload_to_pypi()

# Generated at 2022-06-24 02:00:51.207859
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

    import invoke
    import unittest
    import unittest.mock

    class TestUploadToPyPI(unittest.TestCase):
        def test_upload_to_pypi_without_glob_patterns(self):
            # Arrange
            expected_command = "twine upload -u 'username' -p 'password' 'dist/foo'"

            with unittest.mock.patch("invoke.run", return_value=invoke.Result()):
                # Act
                upload_to_pypi(path="dist", glob_patterns=["foo"])

            # Assert
            invoke.run.assert_called_once_with(expected_command)

# Generated at 2022-06-24 02:00:51.960358
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi == UploadToPyPi

# Generated at 2022-06-24 02:00:57.951223
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run(*args, **kwargs):
        if len(args) > 0 and args[0] == "twine upload ":
            args = list(args)
            args[0] = "twine upload " + " ".join(
                ['"{}/{}"'.format("dist", glob_pattern.strip()) for glob_pattern in args[0].split(" ")[4:]]
            )
            return " ".join(args)
        return args[0]

    glob_patterns = ["*.whl", "*.gz", "*.tar.gz"]
    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=glob_patterns
    )

# Generated at 2022-06-24 02:00:58.941599
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:00:59.777939
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:01:00.539163
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:01:02.282880
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from . import upload_to_pypi
    upload_to_pypi("dist", False, ["*.whl"])

# Generated at 2022-06-24 02:01:02.832591
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:01:03.357417
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:01:05.608810
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*", "!*-py2.py3-none-any.whl", "!*-linux*.whl"])

# Generated at 2022-06-24 02:01:09.625099
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import assert_logger_count

    upload_to_pypi()
    assert_logger_count(logger, 3, "Uploading to PyPI using Twine")
    assert_logger_count(logger, 1, "Files to upload: 'dist/*'")
    assert_logger_count(logger, 1, "Trying to upload files to PyPI")

# Generated at 2022-06-24 02:01:11.301274
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with run.config(overrides={"run": {"echo": True}}):
        upload_to_pypi("dist", skip_existing=True)

# Generated at 2022-06-24 02:01:17.071507
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi = LoggedFunction(logger)(upload_to_pypi)

    # No glob patterns, path==dist
    run = LoggedFunction(logger)(run)
    upload_to_pypi()
    run.assert_called_once_with(
        "twine upload  dist/*"
    )

    run.reset_mock()

    # Using glob patterns
    upload_to_pypi(glob_patterns=["foo*"])
    run.assert_called_once_with(
        "twine upload  'dist/foo*'"
    )

    run.reset_mock()

    # Using environment variables
    os.environ["PYPI_TOKEN"] = "foo"
    run.reset_mock()
    upload_to_pypi()
    run

# Generated at 2022-06-24 02:01:17.576244
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:01:20.018785
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:01:28.385428
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import subprocess
    import sys
    import tempfile

    try:
        import twine
    except ImportError:
        logger.warning("Could not import twine package. Skipping test")
        return

    def temp_fn():
        import shutil
        from pathlib import Path
        from semantic_release.settings import config

        try:
            shutil.rmtree("dist")
            shutil.rmtree("build")
        except FileNotFoundError:
            pass

        os.environ["PYPI_USERNAME"] = "thisiscorrect"
        os.environ["PYPI_PASSWORD"] = "thisisincorrect"


# Generated at 2022-06-24 02:01:31.375758
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    from .mocks import mock_invoke
    from .mocks import mock_config

    # Setup mock invocations
    mock_config()
    mock_invoke([])
    # Begin unit test
    assert upload_to_pypi()

# Generated at 2022-06-24 02:01:36.775342
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='test')
    upload_to_pypi(path='test', skip_existing=True)
    upload_to_pypi(path='test', glob_patterns=["test1", "test2"])

# Generated at 2022-06-24 02:01:46.508864
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest import mock
    from unittest.mock import PropertyMock, patch
    from semantic_release import settings

    test_path = "dist"

    # Test with global config
    with patch.object(settings, "config", new_callable=PropertyMock) as mock_config:
        mock_config.return_value = {"repository": "test_upload_to_pypi"}
        upload_to_pypi(path=test_path)
        mock_run = mock.Mock()
        mock_run.called = True
        mock_run.assert_called_once_with(
            "twine upload  -r 'test_upload_to_pypi'  \"{}/{}\"".format(
                test_path, "*"
            )
        )

    # Test with

# Generated at 2022-06-24 02:01:51.080642
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class test_run:
        def __init__(self):
            self.return_code = 0
            self.stdout = 'Uploading distributions to PyPI...\nUploading foo_bar-0.1.0-py3-none-any.whl\n'
            self.stderr = ''

    my_run = test_run()
    def my_function(param):
        return my_run
    import semantic_release.upload_to_pypi
    semantic_release.upload_to_pypi.run = my_function
    import sys
    import logging
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp()
    sys._called_from_test = True

# Generated at 2022-06-24 02:01:51.820581
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:01:52.575275
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:01:59.646841
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for upload to PyPI
    """
    from .test_helpers import responses, MockContext
    from .helpers import LoggedFunction

    def create_mock_run(return_value):
        """Create a mock for invoke.run"""
        return lambda x: return_value

    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://test.pypi.org/simple/",
            body="<html><body>No matching distribution found</body></html>",
        )

        # Test file already exists
        logger.info = MockContext()
        run = MockContext()
        run.return_value = "Uploading test_pkg-1.2.3-py2.py3-none-any.whl"

# Generated at 2022-06-24 02:02:08.549790
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with open("tests/__init__.py", "w+") as f:
        f.write("test")

    with open("tests/__init__.py", "w") as f:
        f.write("test")

    run("python3 setup.py sdist bdist_wheel")

    assert os.path.isfile("dist/semantic_release_test-0.1.2-py3-none-any.whl")
    assert os.path.isfile("dist/semantic_release_test-0.1.2.tar.gz")

    upload_to_pypi(path="dist")

    os.remove("dist/semantic_release_test-0.1.2-py3-none-any.whl")

# Generated at 2022-06-24 02:02:20.520489
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    repo = config.get("repository", None)
    repo_arg = f" -r '{repo}'" if repo else ''

    token = os.environ.get("PYPI_TOKEN")
    if token and token.startswith('pypi-'):
        username = '__token__'
        password = token  
        token_flag = ''
    else:
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        token_flag = ' -u "{}" -p "{}"'.format(username, password)\
            if username and password else ''

    skip_existing_param = " --skip-existing" if config.get("skip_existing", False) else ""


# Generated at 2022-06-24 02:02:28.670412
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config.load(
        {
            "project_name": "simplekv",
            "repository": "https://github.com/mbr/simplekv",
        }
    )
    upload_to_pypi(
        os.path.join(os.environ.get("TRAVIS_BUILD_DIR", ""), "dist"),
        glob_patterns=["simplekv-*"],
    )

# Generated at 2022-06-24 02:02:36.127479
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for upload_to_pypi
    """
    import logging
    import tempfile
    import shutil
    import sys
    from pathlib import Path

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    temp_dir = tempfile.mkdtemp()

    with tempfile.TemporaryDirectory() as temp_dir:
        os.environ["PYPI_TOKEN"] = "pypi-token"
        os.environ["PYPI_USERNAME"] = "pypi-username"
        os.environ["PYPI_PASSWORD"] = "pypi-password"
        config["repository"] = "repository"

# Generated at 2022-06-24 02:02:44.034354
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set the test environment variables
    os.environ["PYPI_TOKEN"] = "pypi-12345"
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Example uploads
    upload_to_pypi(path="dist", glob_patterns=["*"])
    assert (
        run.result.stdout == ""
    )  # This function actually runs twine upload so it can't be tested properly
    assert run.result.stderr == ""
    upload_to_pypi(path="dist", glob_patterns=["*", "!*.zip"])
    assert (
        run.result.stdout == ""
    )  # This function actually runs twine upload so it can't be tested properly

# Generated at 2022-06-24 02:02:55.151286
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    from .helpers import patch_invoke
    from .helpers import PatchedRunResult

    repository = "test"
    username = "someuser"
    password = "somepassword"
    token = "some-token"
    skip_existing = True
    glob_patterns = ["*.py", "*.txt"]

    with patch_invoke() as mocked_run:

        mocked_run.return_value = PatchedRunResult("", 0)
        upload_to_pypi(
            path="dist",
            skip_existing=skip_existing,
            glob_patterns=glob_patterns,
        )
        assert mocked_run.call_args[0][0] == 'twine upload -u \'someuser\' -p \'somepassword\' "dist/*.py" "dist/*.txt"'

        mocked_run.return_value

# Generated at 2022-06-24 02:03:05.888024
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import get_logger_calls, get_logger_context
    from .helpers import delete_file

    upload_to_pypi(glob_patterns=["test-0.1.tar.gz"])
    # A file named test-0.1.tar.gz must exist at dist folder
    delete_file("dist/test-0.1.tar.gz")

    upload_to_pypi(glob_patterns=["test-0.1.tar.gz"], skip_existing=True)
    # A file named test-0.1.tar.gz must exist at dist folder
    delete_file("dist/test-0.1.tar.gz")


# Generated at 2022-06-24 02:03:07.033479
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:03:07.612026
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:03:09.079204
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi



# Generated at 2022-06-24 02:03:12.746233
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from distutils.core import setup

    with tempfile.TemporaryDirectory() as tempdir:
        setup(name="test", version="1.0", script_args=["sdist"])
        upload_to_pypi(path=tempdir)

# Generated at 2022-06-24 02:03:20.517290
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    test_username = "foo"
    test_password = "bar"
    os.environ["PYPI_USERNAME"] = test_username
    os.environ["PYPI_PASSWORD"] = test_password

    upload_to_pypi(skip_existing=True, glob_patterns=["**/*.tar.gz"])
    assert run.called

    assert run.call_args_list[0][0][0].find(test_username) != -1
    assert run.call_args_list[0][0][0].find(test_password) != -1

    assert "upload" in run.call_args_list[0][0][0]
    assert "skip-existing" in run.call_args_list[0][0][0]
    assert "**/*.tar.gz" in run

# Generated at 2022-06-24 02:03:30.470931
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = True
    glob_patterns = ["test"]

    class MockRun:
        def __init__(self):
            self.out = 'some output'
            self.return_value = None
        def __call__(self, command_str: str):
            return self.out
    mock_run = MockRun()

    def mock_getenv(key: str, default: str) -> str:
        if key == 'HOME':
            return default
        return 'test'

    m_os = __import__('os')
    original_run = m_os.getenv


# Generated at 2022-06-24 02:03:34.439855
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"



# Generated at 2022-06-24 02:03:34.998550
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:03:38.689753
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi_args = {
        "path": "dist",
        "skip_existing": True,
        "glob_patterns": None
    }

    r = upload_to_pypi(**upload_to_pypi_args)

    assert r == True

# Generated at 2022-06-24 02:03:47.427381
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from semantic_release.hvcs.base import BaseHvcs

    username = "username"
    password = "password"
    repository = "repository"
    token = "token"
    hvcs = BaseHvcs()

    with patch("semantic_release.settings.config.get") as get_config, patch(
        "invoke.run", return_value=None
    ) as run:
        get_config.return_value = {
            "username": username,
            "password": password,
            "repository": repository,
            "token": token,
        }
        upload_to_pypi(path="folder")

# Generated at 2022-06-24 02:03:47.946110
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:03:51.105147
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:52.577216
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test that uploading to PyPI works as expected."""
    upload_to_pypi()

# Generated at 2022-06-24 02:03:54.170531
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 02:04:01.541410
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # happy path test
    def run_mock(command):
        import distutils.spawn
        assert distutils.spawn.find_executable('twine')
        assert command.startswith("twine upload")
        assert " -u '__token__' -p 'pypi-token'" in command
        assert " -r 'test'" in command
        assert " --skip-existing" in command
        assert '"dist/test-*.whl"' in command
    global run
    run_save = run
    run = run_mock
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["test-*.whl"])
    run = run_save

    # missing credentials
    def run_mock(command):
        assert False
    global run
    run_save = run
   

# Generated at 2022-06-24 02:04:04.017900
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    """
    pass
test_upload_to_pypi()

# Generated at 2022-06-24 02:04:06.355765
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    raise NotImplementedError()

# Generated at 2022-06-24 02:04:07.441302
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass # test_upload_to_pypi

# Generated at 2022-06-24 02:04:08.440944
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:04:11.560962
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

    upload_to_pypi()

    assert True # TODO

# Generated at 2022-06-24 02:04:13.153877
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi == LoggedFunction(logger)(upload_to_pypi)

# Generated at 2022-06-24 02:04:15.879565
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 02:04:21.556352
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import create_dist_files, delete_dist_files

    # Ensure that the tests are not messing with the real files in PyPi
    repository = "test"

    try:
        create_dist_files(repository)
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
    finally:
        delete_dist_files(repository)



# Generated at 2022-06-24 02:04:30.010695
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mocked_run(cmd):
        mocked_run.host_command = str(cmd).split()
        mocked_run.host_command_len = len(mocked_run.host_command)

    run = mocked_run

    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    assert (
        run.host_command[
            run.host_command_len - 2 :
        ]
    ) == ['"dist/*"', "--skip-existing"]
    test_upload_to_pypi_token = {
        "PYPI_TOKEN": "pypi-w1gjew7t6HlvtOd7243fJW0u8H0Ej62tFirJtLxh",
    }
    test_upload_

# Generated at 2022-06-24 02:04:32.649389
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:04:34.812683
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Ensure the upload_to_pypi function can be called without throwing an exception
    upload_to_pypi()

# Generated at 2022-06-24 02:04:37.401625
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with open("test.py", "w+") as dist:
        dist.write("")
    upload_to_pypi(path="test.py")
    os.remove("test.py")

# Generated at 2022-06-24 02:04:39.383202
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi is not None

# Generated at 2022-06-24 02:04:47.702932
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command_string, **kwargs):
        assert command_string == 'twine upload -u username -p password -r pypi_test --skip-existing "test/test.tar.gz"'
        return None

    import semantic_release.pypi
    original_run = semantic_release.pypi.run
    semantic_release.pypi.run = mock_run

    try:
        upload_to_pypi(
            "test",
            username="username",
            password="password",
            skip_existing=True,
            repository="pypi_test",
            glob_patterns=['test.tar.gz'],
        )
    finally:
        semantic_release.pypi.run = original_run

# Generated at 2022-06-24 02:04:56.460262
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # We expect an exception because there are no credentials
    # If a system user is configured with a .pypirc file, this test
    # will also fail (probably)
    try:
        upload_to_pypi()
    except Exception as e:
        assert isinstance(e, ImproperConfigurationError)
    else:
        assert False, "upload_to_pypi should have raised an exception"

    # Now we provide the credentials and the test should pass
    os.environ["PYPI_USERNAME"] = "foo"
    os.environ["PYPI_PASSWORD"] = "bar"

    try:
        upload_to_pypi()
    except Exception:
        assert False, "upload_to_pypi should not have raised an exception"

# Generated at 2022-06-24 02:05:02.086427
# Unit test for function upload_to_pypi

# Generated at 2022-06-24 02:05:08.269864
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock

    with mock.patch("invoke.run", return_value=None, autospec=True) as m:

        # Use defaults
        upload_to_pypi()
        m.assert_called_with(
            "twine upload  -u '__token__' -p 'pypi-not-secret'  'dist/*'"
        )

        # Use all input parameters
        upload_to_pypi(
            path="other_dist",
            skip_existing=True,
            glob_patterns=["test1", "test2"],
        )

# Generated at 2022-06-24 02:05:09.166796
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:05:10.646396
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:05:19.686514
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi"""
    from .helpers import mock_run, fake_path
    from .helpers import BrokenPipeError

    # Mock out subprocess run
    run_mock = mock_run()
    # Execute function upload_to_pypi
    path = fake_path()
    try:
        upload_to_pypi(path)
    except BrokenPipeError:
        pass
    except Exception as error:
        raise error
    # Assert function ran properly
    assert run_mock.called
    assert run_mock.call_args == run.call_args


# Generated at 2022-06-24 02:05:20.944624
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True, ["*.whl"])

# Generated at 2022-06-24 02:05:24.778073
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
	try:
		upload_to_pypi()
	except ImproperConfigurationError:
		pass

# Generated at 2022-06-24 02:05:32.178197
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi(glob_patterns=["*"])
    os.environ["PYPI_TOKEN"] = "pypi-abcd"
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-24 02:05:34.294299
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert isinstance(upload_to_pypi(),None)

# Generated at 2022-06-24 02:05:37.707179
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    

# Generated at 2022-06-24 02:05:46.576065
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create a test file and directory
    with open("test_file.txt", "w") as test_file:
        test_file.write("Some test text")
    os.mkdir("test_dist")
    # this should upload the test_file.txt to the repo
    try:
        upload_to_pypi("test_dist", True, ["*.txt"])
    except:
        # on error, remove the created files and directories from the test
        os.remove("test_file.txt")
        os.rmdir("test_dist")
    # Assert that the files have been moved to the dist folder
    assert os.path.exists("test_dist/test_file.txt")
    # Remove the test files and directory
    os.remove("test_dist/test_file.txt")