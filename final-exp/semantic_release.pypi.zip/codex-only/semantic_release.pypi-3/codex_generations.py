

# Generated at 2022-06-24 01:55:40.608415
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False

# Generated at 2022-06-24 01:55:41.687013
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run('twine upload dist/*')


# Generated at 2022-06-24 01:55:43.322256
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Upload wheels to PyPI with Twine.
    """
    upload_to_pypi()

# Generated at 2022-06-24 01:55:53.989308
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    
    import unittest

# Generated at 2022-06-24 01:55:59.787814
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function.
    """
    # Expect an error to be raised if PYPI_TOKEN is missing
    os.environ["PYPI_TOKEN"] = None
    try:
        upload_to_pypi(path="test_path")
    except ImproperConfigurationError as e:
        assert "Missing credentials for uploading to PyPI" in str(e)

    # Expect an error to be raised if PYPI_TOKEN is invalid
    os.environ["PYPI_TOKEN"] = "test_token"
    try:
        upload_to_pypi(path="test_path")
    except ImproperConfigurationError as e:
        assert "PyPI token should begin with" in str(e)

    # Expect an error to be raised if PYPI_USERNAME or P

# Generated at 2022-06-24 01:56:07.228659
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .contextmanagers import temp_path

    with temp_path() as path:
        with temp_path() as inner_path:
            os.mkdir(os.path.join(path, "dist"))
            os.mkdir(inner_path)
            open(os.path.join(path, "dist", "test_dist.txt"), "w").close()
            open(os.path.join(inner_path, "test_inner.txt"), "w").close()
        upload_to_pypi(path, skip_existing=False)



# Generated at 2022-06-24 01:56:15.994842
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile

    with tempfile.TemporaryDirectory() as tempdir:
        # Place a fake file in our temp directory
        temp_file = open(os.path.join(tempdir, "fake_wheel"), "w")
        temp_file.close()

        # Set the environment variables
        os.environ["PYPI_USERNAME"] = "fake_username"
        os.environ["PYPI_PASSWORD"] = "fake_password"

        # Do the upload
        upload_to_pypi(tempdir)

# Generated at 2022-06-24 01:56:25.954720
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test uploading to PyPI.
    """
    import mock
    import os

    import semantic_release.upload
    from semantic_release.upload import upload_to_pypi

    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "password"

    expected_call_args = " ".join(
        [
            "twine upload",
            "-u 'user' -p 'password'",
            "--skip-existing",
            "some/path.whl",
        ]
    )

    with mock.patch("invoke.run") as mock_run:
        upload_to_pypi("some/path", skip_existing=True, glob_patterns="*.whl")

# Generated at 2022-06-24 01:56:36.220903
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .mock import create_mock_package
    from .mock import mock_env_var, mock_config_property

    mock_env_var("PYPI_USERNAME", "test")
    mock_env_var("PYPI_PASSWORD", "secret")

    package_name = "test_package"
    package_version = "0.0.1"
    package_file = create_mock_package(package_name, package_version)

    config.repository = "dev"
    mock_config_property("repository", "dev")

    upload_to_pypi()

    config.repository = "prod"
    mock_config_property("repository", "prod")

    upload_to_pypi()

    os.unlink(package_file)

# Generated at 2022-06-24 01:56:37.880701
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:56:44.921772
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .context import patch_working_directory
    from .helpers import get_random_string
    from .fake_pypi import FakePyPI

    repository = get_random_string()

    with patch_working_directory():
        with FakePyPI(repository=repository) as fakepypi:
            os.mkdir("dist")
            with open("dist/test-1.0.0-py2.py3-none-any.whl", "w") as f:
                f.write("test")
            with open("dist/test-1.0.1-py2.py3-none-any.whl", "w") as f:
                f.write("test2")

# Generated at 2022-06-24 01:56:45.405125
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False

# Generated at 2022-06-24 01:56:50.381556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test_path", skip_existing=True, glob_patterns=["**/test_pattern"])
    assert True

# Generated at 2022-06-24 01:56:53.905644
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns="*")

# Generated at 2022-06-24 01:56:55.601488
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    assert upload_to_pypi() == None

# Generated at 2022-06-24 01:57:03.593167
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile

    test_twine_archive = os.path.join(os.path.dirname(__file__), "utf-8-sig.whl")
    test_utf8_archive = os.path.join(os.path.dirname(__file__), "utf-8.whl")
    temp_dir = tempfile.mkdtemp()
    shutil.copy(test_twine_archive, temp_dir)
    shutil.copy(test_utf8_archive, temp_dir)

    upload_to_pypi(path=temp_dir, skip_existing=True, glob_patterns=["*.whl"])

    new_filename = "%s-%s" % (os.path.basename(test_utf8_archive), "pypi")

# Generated at 2022-06-24 01:57:08.550116
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if "PYPI_TOKEN" not in os.environ:
        raise ImproperConfigurationError("Please set PYPI_TOKEN in the environment")
    upload_to_pypi()

# Generated at 2022-06-24 01:57:16.147751
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=import-outside-toplevel
    from unittest.mock import patch, call
    from semantic_release.changelog import update_changelog_version
    from semantic_release.history import format_changelog_entry

    # Create test data
    changelog_version = update_changelog_version("test_changelog.rst", "2.2.2")
    changelog_entry = format_changelog_entry(
        changelog_version=changelog_version,
        package_name="test_app",
        force_version=True,
    )

# Generated at 2022-06-24 01:57:27.251522
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import mock
    import sys
    import shutil

    from semantic_release import ImproperConfigurationError
    from semantic_release.settings import config

    from .helpers import LoggedFunction, get_local_repo, get_local_repo_location
    from .test_release import test_do_release

    sys.path.insert(0, get_local_repo_location("tests"))
    test_do_release("tests")
    sys.path.pop(0)

    with get_local_repo("tests"):
        # Create a mock build and dist directory
        build = os.path.join(os.getcwd(), "build")
        dist = os.path.join(os.getcwd(), "dist")
        os.makedirs(build)
        os.makedirs(dist)

        # Create a mock

# Generated at 2022-06-24 01:57:35.212549
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Simple unit test for upload_to_pypi
    """
    from mock import patch
    from .helpers import pypi_result
    from .helpers import mocked_results
    from .helpers import is_path_exists

    # Test that twine correctly calls the upload function
    with patch("invoke.run", autospec=True) as mocked_run:
        mocked_run.return_value = mocked_results("")
        upload_to_pypi("dist/", skip_existing=True)
        mocked_run.assert_called_once_with(
            "twine upload --skip-existing 'dist/*'", hide=True
        )
        # Test that twine correctly calls the upload function
    with patch("invoke.run", autospec=True) as mocked_run:
        mocked_run.return_value = mocked

# Generated at 2022-06-24 01:57:44.760599
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Not much of a unit test, but just verifies that an error is raised if the API token is not set.
    """
    assert hasattr(upload_to_pypi, "original")
    # Check that an error is raised if credentials are missing
    assert os.environ.get("PYPI_TOKEN") is None
    assert os.environ.get("PYPI_USERNAME") is None
    assert os.environ.get("PYPI_PASSWORD") is None
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True



# Generated at 2022-06-24 01:57:51.756773
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def assert_run(cmd, **kwargs):
        from invoke import Context
        from textwrap import dedent

        # Shell-quote the command (we don't need to mock shlex here because twine is already shell-escaped)
        cmd = " ".join(cmd)

        # Allow reference to parameter in function below
        _kwargs = kwargs

        def context_run(self, command, **kwargs):
            from invoke.exceptions import Failure

            # Assert command
            assert command == cmd
            # Assert kwargs
            assert _kwargs == kwargs

            # Return fake result

# Generated at 2022-06-24 01:57:56.853639
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockContext

    # Will fail if missing arguments or bad credentials
    ctx = MockContext(config={})
    upload_to_pypi(ctx, path="dist")

# Generated at 2022-06-24 01:58:01.666399
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    :return: None
    """
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-24 01:58:07.026986
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"
    assert upload_to_pypi.__doc__ is not None

# Generated at 2022-06-24 01:58:10.871673
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except Exception as e:
        assert issubclass(type(e), ImproperConfigurationError)

# Generated at 2022-06-24 01:58:11.706579
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:58:12.497311
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert not upload_to_pypi()

# Generated at 2022-06-24 01:58:23.839679
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .test_helpers import InvokeContextMock, MockConfig

    config.set_config(MockConfig())

    with InvokeContextMock(config, os.environ):
        path = "test_dist"
        glob_patterns = ['test_entry_point.py']
        def _test(os_environ):
            os.environ["PYPI_TOKEN"] = os_environ["PYPI_TOKEN"]
            upload_to_pypi(path, glob_patterns=glob_patterns)
            assert "twine upload --skip-existing -u '__token__' -p 'pypi-token' 'test_dist/test_entry_point.py'" == config.run.call_args[0][0]
            config.run.reset_mock()


# Generated at 2022-06-24 01:58:27.390413
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

if __name__ == '__main__':
    test_upload_to_pypi()

# Generated at 2022-06-24 01:58:28.645124
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist",skip_existing=False,glob_patterns=None)

# Generated at 2022-06-24 01:58:40.472826
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "test_pypi_username"
    os.environ["PYPI_PASSWORD"] = "test_pypi_password"

    def _run(command, echo=True):
        if "twine upload" not in command:
            return

        assert " -u 'test_pypi_username' -p 'test_pypi_password'" in command
        assert '"dist/sphinx-semantic-release-changelog-*.whl"' in command

    run_patcher = mock.patch("invoke.run", side_effect=_run)
    run_patcher.start()

    upload_to_pypi(glob_patterns=["sphinx-semantic-release-changelog-*.whl"])

    run_

# Generated at 2022-06-24 01:58:41.436183
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:58:42.392949
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-24 01:58:48.589637
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "pass"
    os.environ["HOME"] = "~/"
    with open(os.path.join(os.environ["HOME"],".pypirc"),'w') as f:
        f.write('[distutils]\nindex-servers =\n    pypi\n')
        f.write('\n[pypi]\nusername: user\npassword: pass')
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["**"])

# Generated at 2022-06-24 01:58:49.397128
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True, ["*"])

# Generated at 2022-06-24 01:58:51.222332
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(skip_existing=True)

# Generated at 2022-06-24 01:58:55.286922
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", "False", ["*"])

# Generated at 2022-06-24 01:59:01.450497
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Tests that the upload to PyPI function works by checking the
    status code.
    """
    import tempfile
    import shutil
    from pathlib import Path

    tmp_path = Path(tempfile.mkdtemp() / "dist")
    tmp_path.mkdir(parents=True, exist_ok=True)

    # The status here should be non-zero, if not then the test fails
    ret = upload_to_pypi(str(tmp_path))

    shutil.rmtree(str(tmp_path.parent))

    assert ret == 0

# Generated at 2022-06-24 01:59:10.536763
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(
        skip_existing=False, glob_patterns=["fake*", "fakes*"]
    ) == "twine upload  --skip-existing 'dist/fake*' 'dist/fakes*'"
    assert upload_to_pypi(skip_existing=True, glob_patterns=["fake*", "fakes*"]) == "twine upload  --skip-existing 'dist/fake*' 'dist/fakes*'"
    assert upload_to_pypi(skip_existing=True, glob_patterns=["fake*"]) == "twine upload  --skip-existing 'dist/fake*'"
    assert upload_to_pypi() == "twine upload  'dist/*'"

# Generated at 2022-06-24 01:59:11.320634
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:11.856920
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True == True

# Generated at 2022-06-24 01:59:19.244751
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test to check if upload_to_pypi function works properly"""
    import pytest
    from subprocess import Popen, PIPE

    def mock_run(self, command, *args, **kwargs):
        """Mock for run"""
        self.command = command

    run_orig = run.Run
    run.Run = mock_run
    try:
        repo = "pypi"
        token = os.environ.get("PYPI_TOKEN")
        if not token:
            pytest.skip("pypi token is not set")
        config.set("repository", repo)
        upload_to_pypi()
        assert f"'{token}'" in run.command
    finally:
        run.Run = run_orig

# Generated at 2022-06-24 01:59:19.846137
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:29.889889
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import YOLO
    from .helpers import patch_os_environ
    from .helpers import patch_get_logger
    from .helpers import patch_run

    with patch_get_logger() as mock_logger, patch_os_environ({"PYPI_USERNAME": "me", "PYPI_PASSWORD":"iam123"}) as mock_os, patch_run() as mock_run:
        upload_to_pypi('dist')
        mock_logger.log.assert_called_with(25, 'Uploading to PyPI.')
        mock_run.assert_called_with('twine upload -u \'me\' -p \'iam123\' --skip-existing \'"dist/{}"\''.format(YOLO))
        mock_os.get.assert_called_

# Generated at 2022-06-24 01:59:37.673301
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert trim(upload_to_pypi.__doc__) == trim(
        """Upload wheels to PyPI with Twine.

    Wheels must already be created and stored at the given path.

    Credentials are taken from either the environment variable
    ``PYPI_TOKEN``, or from ``PYPI_USERNAME`` and ``PYPI_PASSWORD``.

    :param path: Path to dist folder containing the files to upload.
    :param skip_existing: Continue uploading files if one already exists.
        (Only valid when uploading to PyPI. Other implementations may not support this.)
    :param glob_patterns: List of glob patterns to include in the upload (["*"] by default).
        """
    )

# Generated at 2022-06-24 01:59:38.347512
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-24 01:59:39.465789
# Unit test for function upload_to_pypi

# Generated at 2022-06-24 01:59:42.677835
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-24 01:59:43.375762
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:45.362999
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi


# Generated at 2022-06-24 01:59:49.709301
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
    except ImportError:
        raise ImportError("twine is required for testing upload to PyPI")

    try:
        os.environ["PYPI_TOKEN"] = "test_token"
        upload_to_pypi()
    finally:
        del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-24 01:59:50.492170
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:52.972186
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])


__all__ = ("upload_to_pypi",)

# Generated at 2022-06-24 01:59:55.537744
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with (pytest.raises(ImproperConfigurationError)):
        upload_to_pypi()

# Generated at 2022-06-24 02:00:01.240083
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi using a dummy API.

    https://test.pypi.org/

    API token stored in ci/semantic-release/.pypirc
    """
    upload_to_pypi("dist")

# Generated at 2022-06-24 02:00:11.502325
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import get_test_directory
    from .helpers import get_test_repo
    from semantic_release.history import get_changelog
    from semantic_release.settings import config
    from semantic_release.settings import get_current_version

    # 1. Setup
    # 1.1. Create a test repository
    test_repo_url = get_test_repo("1.9", "setup.py")
    os.chdir(get_test_directory(test_repo_url))
    # 1.2. Init semantic-release config
    config.setup()
    # 1.3. Mock release version
    config.current_version = "0.0.0"
    # 1.4. Mock changelog

# Generated at 2022-06-24 02:00:13.879610
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:00:14.191317
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:00:20.858641
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the code of upload_to_pypi."""
    import os
    import json
    import shutil
    import tempfile
    import filecmp

    import semantic_release
    import semantic_release.packages.pypi.main

    temp_dir = tempfile.mkdtemp()
    original_PATH = os.environ.get("PATH", None)
    os.environ["PATH"] = f"{temp_dir}:{original_PATH}"
    os.environ["TWINE_USERNAME"] = "TWINE_USERNAME"
    os.environ["TWINE_PASSWORD"] = "TWINE_PASSWORD"

    cwd = os.getcwd()
    os.chdir(temp_dir)


# Generated at 2022-06-24 02:00:25.194243
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi.logger = logger
    upload_to_pypi()

# Generated at 2022-06-24 02:00:33.274016
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function"""
    import shutil
    import tempfile
    import textwrap
    import venv

    from invoke.context import Context
    from invoke.exceptions import Failure

    # Create virtualenv and pip install twine
    test_venv = tempfile.gettempdir() + "/test_venv"
    venv.create(test_venv, with_pip=True)
    ctx = Context()
    ctx.run("{0}/bin/python -m pip install twine".format(test_venv))

    # Create wheel and dist dir
    wheel = test_venv + "/test.whl"
    wheel_content = textwrap.dedent(
        """\
        test wheel
        """
    )

# Generated at 2022-06-24 02:00:33.877927
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()


# Generated at 2022-06-24 02:00:37.884254
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.environ["PYPI_TOKEN"] = "pypi-thisismysecret"
        os.environ["PYPI_USERNAME"] = "thisismyusername"
        os.environ["PYPI_PASSWORD"] = "thisismypassword"
        upload_to_pypi(
            path="",
            glob_patterns=["*"],
        )
    finally:
        del os.environ["PYPI_TOKEN"]
        del os.environ["PYPI_USERNAME"]
        del os.environ["PYPI_PASSWORD"]

# Generated at 2022-06-24 02:00:48.337319
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test calls to upload_to_pypi.
    """

    class MockSubprocess:
        """
        Mock invoke.run()
        """

        def __init__(self):
            self.call_stack = []

        def __call__(self, cmd: str, **kwargs: str) -> bool:
            """
            Mock invoke.run()
            """

            self.call_stack.append(cmd)

            return True

    # Create mock subprocess
    mock_subprocess = MockSubprocess()

    # Test no credentials
    os.environ = {}
    try:
        upload_to_pypi(mock_subprocess)
        assert False
    except ImproperConfigurationError:
        assert True

    # Test with username, password, and "pypi-" token

# Generated at 2022-06-24 02:00:58.832532
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import random
    import string
    import tempfile

    from .helpers import logged_function_result

    def random_string(length: int, exclude_chars: str = ""):
        return "".join(
            random.choice(
                "{}{}".format(
                    string.ascii_letters, string.digits
                ).replace(exclude_chars, "")
            )
            for _ in range(length)
        )

    glob_patterns = [
        random_string(8),
        random_string(8),
        random_string(8),
    ]

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dist_dir = os.path.join(temp_dir, "dist")
        os.mkdir(temp_dist_dir)

# Generated at 2022-06-24 02:01:08.825596
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    from invoke.context import Context

    from .helpers import LoggedFunction, get_logger_messages

    context = Context(run)
    context.configure(run=DummyRun())

    upload_to_pypi.ctx = context

    temp_folder = tempfile.mkdtemp()

    try:
        # Test upload on default path 'dist'
        upload_to_pypi()

        # Test upload on given path
        upload_to_pypi(temp_folder)

    finally:
        shutil.rmtree(temp_folder)

    logger_messages = get_logger_messages(LoggedFunction(logger))

    assert len(logger_messages) == 4


# Generated at 2022-06-24 02:01:13.095421
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for upload_to_pypi()
    """
    assert True == True


# Generated at 2022-06-24 02:01:21.026458
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.environ["PYPI_TOKEN"] = "pypi-my-token-123"
        upload_to_pypi()
    except ImproperConfigurationError as error:
        assert str(error) == "Missing credentials for uploading to PyPI"

    try:
        os.environ["PYPI_TOKEN"] = "my-token-123"
        upload_to_pypi()
        assert False
    except ImproperConfigurationError as error:
        assert str(error) == 'PyPI token should begin with "pypi-"'

    env = dict(os.environ)
    del os.environ["PYPI_TOKEN"]
    result = str(os.system("echo $PYPI_TOKEN")).split(" ")[1]
    assert result == "None"
   

# Generated at 2022-06-24 02:01:29.351520
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit tests for "upload_to_pypi" function."""
    from .helpers import raise_exception_for_log
    from unittest.mock import patch
    import pytest

    # Test config with only an API token
    token = "pypi-asdf"
    with patch("os.environ.get", return_value=token):
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

        with patch("invoke.run") as mock_run:
            upload_to_pypi(path="foo/bar", skip_existing=True, glob_patterns=["asdf"])

# Generated at 2022-06-24 02:01:30.149363
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert(upload_to_pypi)

# Generated at 2022-06-24 02:01:31.087382
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()


# Generated at 2022-06-24 02:01:34.609073
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: use mocks
    pass

# Generated at 2022-06-24 02:01:40.712916
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert isinstance(upload_to_pypi(), None)
    assert isinstance(upload_to_pypi(glob_patterns=['*.whl']), None)
    assert isinstance(upload_to_pypi(path='dist/some_path'), None)
    assert isinstance(upload_to_pypi(path='dist/some_path', skip_existing=True), None)

# Generated at 2022-06-24 02:01:41.655127
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:01:42.218279
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:01:43.420051
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='dist', skip_existing=False)

# Generated at 2022-06-24 02:01:51.591871
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import glob
    import shutil
    with tempfile.TemporaryDirectory() as directory:
        shutil.copy('tests/test-package.tar.gz', directory)
        shutil.copy('tests/test-package.tar.gz', directory)

        upload_to_pypi(glob_patterns=['*package*'], path=directory)

        assert len(glob.glob(f'{directory}/*')) == 0

# Generated at 2022-06-24 02:01:56.127156
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

    os.environ["TRAVIS_TAG"] = "travisTag"
    os.environ["TRAVIS_REPO_SLUG"] = "travisRepoSlug"

# Generated at 2022-06-24 02:01:56.647289
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:02:03.655618
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run_mock(command):
        run_mock.called = command

    run_mock.called = None
    setattr(run, "__wrapped__", run_mock)

    upload_to_pypi(path="fakedir", glob_patterns=["fakename-1.0.0*"])
    assert run_mock.called == "twine upload 'fakedir/fakename-1.0.0*'"

# Generated at 2022-06-24 02:02:14.993019
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=missing-function-docstring
    def run_side_effect(*args):
        if "upload" not in args[0]:
            raise Exception()

    with config.patch({"repository": "bla"}) as mock_config:
        mock_config.__contains__.side_effect = lambda key: False
        run.side_effect = run_side_effect
        upload_to_pypi()
        assert run.call_count == 1
        assert run.call_args[0][0] == "twine upload -u '__token__' -p 'pypi-xxx'"
    run.side_effect = None

    with config.patch() as mock_config:
        with config.get.patch() as mock_get:
            mock_get.return_value = "bli"

# Generated at 2022-06-24 02:02:17.549285
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='/Users/Shared/workspace/docs/semantic_release/examples/demo-python', skip_existing=False, glob_patterns=['*'])

# Generated at 2022-06-24 02:02:20.908659
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi."""
    from tempfile import TemporaryDirectory

    try:
        with TemporaryDirectory() as d:
            upload_to_pypi(d)
    except ImproperConfigurationError as e:
        assert "Missing credentials for uploading to PyPI" in str(e)

# Generated at 2022-06-24 02:02:29.648312
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=None)
    upload_to_pypi(
        path="dist", skip_existing=True, glob_patterns=None)
    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["*"])
    upload_to_pypi(
        path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 02:02:40.161725
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist", skip_existing=True, glob_patterns=["dummy_files.txt"]
    )
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["dummy_files.txt"])
    upload_to_pypi(
        path="dist", skip_existing=True, glob_patterns=["dummy_files.txt", "dummy_files2.txt"]
    )
    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["dummy_files.txt", "dummy_files2.txt"]
    )

# Generated at 2022-06-24 02:02:40.669066
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 02:02:41.186463
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 02:02:47.284192
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import invoke_in_temp_dir
    import glob
    import shutil
    import unittest
    import tempfile

    class TestUploadToPypi(unittest.TestCase):
        def run_twine(self, username_password, repository, skip_existing, *dist_files):
            # Run usernames, passwords, and token in a loop to test all cases
            for i in range(len(dist_files)):
                # Set envs
                if username_password[i]:
                    os.environ["PYPI_TOKEN"] = None
                    os.environ["PYPI_USERNAME"], os.environ["PYPI_PASSWORD"] = (
                        username_password[i]
                    )

# Generated at 2022-06-24 02:02:49.989556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("/path/to/dist", False, ["1.0.0.tar.gz"])

# Generated at 2022-06-24 02:02:56.841343
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    dist = "dist"
    glob_patterns = ["*"]
    run = lambda command: True
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")

    username_password = (
        f"-u '{username}' -p '{password}'" if username and password else ""
    )

    dist = " ".join(
        ['"{}/{}"'.format(dist, glob_pattern.strip()) for glob_pattern in glob_patterns]
    )

    repository = config.get("repository", None)

# Generated at 2022-06-24 02:02:57.654031
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ['PYPI_TOKEN'] = "token"
    upload_to_pypi()

# Generated at 2022-06-24 02:02:59.322153
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """No good way to unit test this function yet.
    """
    assert upload_to_pypi

# Generated at 2022-06-24 02:03:09.271689
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import unittest.mock
    import os.path

    with unittest.mock.patch("invoke.run") as run_mock:
        upload_to_pypi()
        run_mock.assert_called_once_with(
            "twine upload '' -r '' ./*.whl", warn=True
        )

    with unittest.mock.patch("invoke.run") as run_mock:
        upload_to_pypi(path="temp")
        run_mock.assert_called_once_with(
            "twine upload '' -r '' temp/*.whl", warn=True
        )


# Generated at 2022-06-24 02:03:09.841703
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:03:13.846902
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Given
    os.environ["PYPI_USERNAME"] = "foo"
    os.environ["PYPI_PASSWORD"] = "bar"

    # When
    upload_to_pypi("tests/files/dist")
    # Then
    assert True

# Generated at 2022-06-24 02:03:14.384583
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 == 1

# Generated at 2022-06-24 02:03:16.501529
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi", "Function has unexpected name"



# Generated at 2022-06-24 02:03:23.423304
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test when everything is set correctly
    os.environ['PYPI_TOKEN'] = 'pypi-token'
    try:
        upload_to_pypi('/tmp/test')
    except Exception:
        assert False
    os.environ.pop('PYPI_TOKEN')
    upload_to_pypi('/tmp/test')
    
    # Test when repository is set correctly
    os.environ['PYPI_USERNAME'] = 'username'
    os.environ['PYPI_PASSWORD'] = 'password'
    os.environ['repository'] = 'repo'
    upload_to_pypi('/tmp/test')
    os.environ.pop('PYPI_USERNAME')

# Generated at 2022-06-24 02:03:24.463350
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-24 02:03:25.184377
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:32.348818
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch("os.environ", {'PYPI_TOKEN': 'pypi-1234'}):
        upload_to_pypi()

    with patch("os.environ", {'PYPI_USERNAME': 'johnny.appleseed', 'PYPI_PASSWORD': '12345'}):
        upload_to_pypi()

# Generated at 2022-06-24 02:03:35.455236
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi", "Function name changed, change unit test as well"

# Generated at 2022-06-24 02:03:42.916769
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function

    """
    # We mock the subprocess.run function which the run of invoke use
    # We just check that the commands passed to subprocess.run are correct
    mock_run = MagicMock()
    mock_run.return_value = CompletedProcess(args=[], returncode=0)
    from unittest.mock import patch
    from semantic_release.hvcs.helpers import run
    with patch("semantic_release.hvcs.helpers.run", mock_run):
        # Test without token
        run("set PYPI_USERNAME=pypiusername")
        run("set PYPI_PASSWORD=pypipassword")
        del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-24 02:03:43.742871
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:51.882597
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with run.patch.object(run, "run") as mock_run:
        upload_to_pypi(
            path="dist",
            skip_existing=False,
            glob_patterns=["*.whl", "*.tar.gz"],
        )
        mock_run.assert_called_with(
            'twine upload -u \'__token__\' -p \'pypi-test\' "dist/test.whl" "dist/test.tar.gz"'
        )



# Generated at 2022-06-24 02:03:57.539121
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: I would prefer a pure unit test without shell calls.
    # TODO: is the test_pypi package a valid PyPI package?
    # TODO: How can I test the skip-existing option?
    test_path = "dist"
    test_glob_patterns = ["*"]
    upload_to_pypi(path=test_path, glob_patterns=test_glob_patterns)

# Generated at 2022-06-24 02:04:01.417060
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist")

# Generated at 2022-06-24 02:04:13.400831
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

  from .mocks import MockConfig, MockEnviron

  c = MockConfig()
  e = MockEnviron()

  # Test 1: No credentials
  try:
    upload_to_pypi()
    assert False, "Should throw an ImproperConfigurationError"
  except ImproperConfigurationError as e:
    assert True, "Should throw an ImproperConfigurationError"

  # Test 2: Success
  e.env['PYPI_USERNAME'] = 'test_username'
  e.env['PYPI_PASSWORD'] = 'test_password'
  e.env['HOME'] = 'test_home'
  upload_to_pypi()
  assert run.called, "Should invoke the run command"

# Generated at 2022-06-24 02:04:16.246956
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() is None

# Generated at 2022-06-24 02:04:17.051300
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:04:28.063978
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # setup
    os.environ["PYPI_TOKEN"] = "TOKEN"
    os.environ["PYPI_USERNAME"] = "USER"
    os.environ["PYPI_PASSWORD"] = "PASS"
    os.environ["HOME"] = "/"

    run.return_value = None

    # run
    upload_to_pypi()

    # assert
    run.assert_called_once_with("twine upload -u 'USER' -p 'PASS' __token__ 'dist/*'")

    # cleanup
    del os.environ["PYPI_TOKEN"]
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]
    del os.environ["HOME"]

# Generated at 2022-06-24 02:04:28.769852
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi( )

# Generated at 2022-06-24 02:04:29.630187
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() is None

# Generated at 2022-06-24 02:04:31.049127
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == "dist/*"

# Generated at 2022-06-24 02:04:41.488892
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that upload_to_pypi function works
    """
    from .helpers import mocked_config_dict
    from .helpers import mocked_run_subprocess
    from .helpers import mocked_subprocess
    from .helpers import mocked_subprocess_env_dict

    mocked_subprocess_env_dict.update(
        {"PYPI_USERNAME": "username", "PYPI_PASSWORD": "password"}
    )

    mocked_config_dict.update({"repository": "test_repo"})

    upload_to_pypi(skip_existing=True)
    cmd = mocked_subprocess.call_args[0][0]

# Generated at 2022-06-24 02:04:42.341898
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:04:48.728149
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Testcase for upload_to_pypi function
    """
    os.environ["PYPI_TOKEN"] = "token"
    upload_to_pypi()
    os.environ["PYPI_PASSWORD"] = "test"
    os.environ["PYPI_USERNAME"] = "test"
    upload_to_pypi()

# Generated at 2022-06-24 02:04:57.030485
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    user = "myuser"
    pwd = "mypassword"
    token = "mytoken"
    repository = "myrepository"

    def test_function():
        return [(name, val) for name, val in os.environ.items()]

    # Test credentials are taken from os.environ
    os.environ["PYPI_TOKEN"] = token
    assert upload_to_pypi.function(test_function) == [("PYPI_TOKEN", token)]
    del os.environ["PYPI_TOKEN"]

    os.environ["PYPI_USERNAME"] = user
    os.environ["PYPI_PASSWORD"] = pwd

# Generated at 2022-06-24 02:05:02.453385
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_invoke
    from .helpers import mock_run
    from .helpers import mock_get_version
    from .helpers import mock_create_local_git_tags
    import tempfile
    import shutil
    import os

    # mock_invoke(mock_run)
    # mock_get_version()
    # mock_create_local_git_tags()

    test_dir = tempfile.mkdtemp()
    dist_dir = os.path.join(test_dir, "dist")

    os.environ["PYPI_USERNAME"] = "pypi_username"
    os.environ["PYPI_PASSWORD"] = "pypi_password"

    files_to_upload = ["test.txt", "test2.txt"]


# Generated at 2022-06-24 02:05:03.629410
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    upload_to_pypi("dist")

# Generated at 2022-06-24 02:05:04.106610
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:05:05.943882
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()

# Generated at 2022-06-24 02:05:14.606628
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    def get_env_vars(old_env_vars):
        env_vars = os.environ.copy()
        env_vars.update(old_env_vars)
        return env_vars

    # try with no api token provided
    env = get_env_vars({})
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert e.message == "Missing credentials for uploading to PyPI"
    else:
        assert False, "An ImproperConfigurationError should have been raised."

    # try with an empty api token provided
    env = get_env_vars({"PYPI_TOKEN": ""})

# Generated at 2022-06-24 02:05:16.437475
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"

# Generated at 2022-06-24 02:05:18.114202
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Add tests for new behaviour of this function
    pass

# Generated at 2022-06-24 02:05:22.403356
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Upload wheels to PyPI with Twine."""
    path = "dist"
    skip_existing = True
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-24 02:05:25.255706
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    upload_to_pypi()

# Generated at 2022-06-24 02:05:30.878268
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test using Twine to upload to PyPI."""
    # Test uploading with username and password
    upload_to_pypi(skip_existing=True)
    # Test uploading with token
    upload_to_pypi(skip_existing=True)

# Generated at 2022-06-24 02:05:31.418108
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 == 1

# Generated at 2022-06-24 02:05:39.945674
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    with patch("invoke.run") as mock_run:
        upload_to_pypi(path="dist")
        mock_run.assert_called_once_with("twine upload 'dist/*'")

        upload_to_pypi(path="dist", glob_patterns=["wheels/*"])
        mock_run.assert_called_with("twine upload 'dist/wheels/*'")

        upload_to_pypi(
            path="dist",
            skip_existing=True,
            glob_patterns=["wheels/*"],
            repository="repository",
        )
        mock_run.assert_called_with(
            "twine upload --skip-existing -r 'repository' 'dist/wheels/*'"
        )
    

# Generated at 2022-06-24 02:05:48.946725
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run_args = {}
    def mock_run(cmd, **kwargs):
        run_args.update(kwargs)
        return cmd

    old_run = run
    run = mock_run