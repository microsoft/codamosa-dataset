

# Generated at 2022-06-24 01:55:47.284451
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from .helpers import get_git_version
    from .helpers import get_package_version

    version = get_git_version()
    assert get_package_version() == version

    with patch("invoke.run") as mock_run:
        upload_to_pypi()
        mock_run.assert_called_once()


# Generated at 2022-06-24 01:55:57.513637
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile

    from .test_helpers import assert_logs

    # Testing the API token
    token = "pypi-password"
    with tempfile.TemporaryDirectory() as tmp_dir, assert_logs(
        "DEBUG",
        f"Using PyPI API token from environment variable",
        f"Uploading {tmp_dir}/foo.txt to PyPI",
    ) as cm:
        with open(os.path.join(tmp_dir, "foo.txt"), "w"):
            pass
        os.environ["PYPI_TOKEN"] = token
        upload_to_pypi(tmp_dir)

    # Testing the username and password
    username = "username"
    password = "password"

# Generated at 2022-06-24 01:56:02.344347
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test to check upload function of pypi provider
    """
    path = "dist"
    skip = False
    patterns = ["*"]
    upload_to_pypi(path, skip_existing=skip, glob_patterns=patterns)

# Generated at 2022-06-24 01:56:09.219005
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test uploading a wheel with a token, using the default repo
    assert run("twine upload --help", hide=True).ok
    token = os.environ.get("PYPI_TOKEN")
    # Assume the test has been run
    assert token
    repo = config.get("repository", None)
    repo_arg = f" -r '{repo}'" if repo else ""
    username_password = f"-u '__token__' -p '{token}'"
    run(f"twine upload {username_password}{repo_arg} dist/semantic_release-0.1.0-py3-none-any.whl")
    # Test uploading a wheel with a token, specifying a repo
    assert run("twine upload --help", hide=True).ok
    token = os.environ.get

# Generated at 2022-06-24 01:56:10.093251
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:56:11.027763
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-24 01:56:20.772296
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    from distutils.dir_util import mkpath
    from distutils.file_util import copy_file
    from .helpers import LoggedFunction, mock_dict_env, mock_log_info

    logger = logging.getLogger(__name__)

    test_file_name = "test_twine_upload"
    test_username = "test_username"
    test_password = "test_password"
    test_path = "dist/"
    test_file_path = "dist/test_twine_upload"
    test_token = "test_token"
    test_repository = "test_repository"


# Generated at 2022-06-24 01:56:31.308840
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    # pylint: disable=unused-argument
    def mock_confirm(msg):
        return True

    def conf():
        return {"repository": "test-repo"}

    def os_env(name):
        if name == "PYPI_TOKEN":
            return "pypi-token"
        if name == "PYPI_USERNAME":
            return "user"
        if name == "PYPI_PASSWORD":
            return "pass"

    glob_patterns = ["*.whl"]
    with mock_run(mock_confirm, conf, os_env):
        upload_to_pypi(glob_patterns=glob_patterns)

    assert mock_run.called is True

# Generated at 2022-06-24 01:56:36.158375
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ['PYPI_TOKEN'] = 'pypi-xxxx'
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 01:56:39.265889
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="test_dist", skip_existing=True, glob_patterns=["test_dist/*.whl"]
    )

# Generated at 2022-06-24 01:56:43.174925
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    # pylint: disable=import-error
    from semantic_release.packages.pypi.helpers import upload_to_pypi
    # pylint: disable=no-value-for-parameter
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-24 01:56:45.460241
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-24 01:56:46.087777
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 01:56:56.338832
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    from .helpers import mock_run
    from semantic_release.plugins.pypi import upload_to_pypi
    from semantic_release.settings import config
    from semantic_release.errors import ImproperConfigurationError

    config.load("tests/fixtures/plugins_conf/pypi_no_auth.yaml")
    upload_to_pypi()
    assert mock_run.call_args[0][0] == "twine upload 'dist/*'"
    mock_run.reset_mock()

    config.load("tests/fixtures/plugins_conf/pypi_no_token.yaml")
    upload_to_pypi()

# Generated at 2022-06-24 01:57:04.066893
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    call_count = 0
    def run(command):
        nonlocal call_count
        call_count += 1
        assert command == "twine upload  *.whl"

    upload_to_pypi(path="", skip_existing=False, glob_patterns=["*.whl"])
    assert call_count == 1

    call_count = 0
    upload_to_pypi(path="/tmp/my-dist", skip_existing=False, glob_patterns=["*.whl"])
    assert call_count == 1

    call_count = 0
    upload_to_pypi(path="", skip_existing=False, glob_patterns=["*.whl", "*.gz"])
    assert call_count == 1

    call_count = 0

# Generated at 2022-06-24 01:57:12.317661
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run_mock(*args, **kwargs):
        return

    fake_args = {
        "path": "dist",
        "skip_existing": False,
        "glob_patterns": ["*"],
    }

    with patch("invoke.run") as run_mock:
        upload_to_pypi(**fake_args)
    run_mock.assert_called_once()
    # TODO: Check the command is correct.



# Generated at 2022-06-24 01:57:15.663784
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockContainer

    with MockContainer() as mock:
        mock.run.side_effect = [None]
        upload_to_pypi()
        mock.run.assert_called_once_with('twine upload "dist/*"')



# Generated at 2022-06-24 01:57:26.831061
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test uploading to PyPI with Twine."""
    import pytest
    from semantic_release.settings import config
    from semantic_release.plugins import upload_to_pypi

    # Test with a wrong token
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi.upload_to_pypi(glob_patterns=["package"])
    os.environ["PYPI_TOKEN"] = "blah"
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi.upload_to_pypi(glob_patterns=["package"])

    # Test with a wrong username
    os.environ["PYPI_USERNAME"] = "blah"
    with pytest.raises(ImproperConfigurationError):
        upload_

# Generated at 2022-06-24 01:57:35.141013
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # valid token authentication
    token = "pypi-dummytoken"
    os.environ["PYPI_TOKEN"] = token
    upload_to_pypi("dist", False, ["*"])
    os.environ["PYPI_TOKEN"] = ""

    # valid username and password authentication
    username = "dummyuser"
    password = "dummypassword"
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"] = password
    upload_to_pypi("dist", False, ["*"])
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""

    # valid username and password authentication with custom repository
    username = "dummyuser"


# Generated at 2022-06-24 01:57:40.155241
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .mock_twine_upload import mock_twine_upload_function

    upload_to_pypi(glob_patterns=["foo"], skip_existing=True)
    mock_twine_upload_function.assert_called_once_with(
        "--skip-existing 'dist/foo'"
    )

# Generated at 2022-06-24 01:57:40.779450
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 01:57:51.944826
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    from .helpers import context_for
    from .helpers import get_context
    from .helpers import mock_run_invoke
    from .helpers import patch_invoke_run

    path = "dist"
    glob_patterns = ["*"]

    mock_run_invoke()

    with context_for(
        config={"pypi_username": "username", "pypi_password": "password"}
    ):
        upload_to_pypi(path, skip_existing=True)
        upload_to_pypi(path, glob_patterns=glob_patterns)
        call_args_list = get_context().get("run").call_args_list

# Generated at 2022-06-24 01:57:55.723976
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    assert upload_to_pypi()

# Generated at 2022-06-24 01:57:56.467284
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist")

# Generated at 2022-06-24 01:58:03.554668
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile
    import unittest

    class UploadToPyPiTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            os.mkdir(os.path.join(self.temp_dir, "dist"))
            self.cwd = os.getcwd()
            os.chdir(self.temp_dir)

        def tearDown(self):
            os.chdir(self.cwd)
            shutil.rmtree(self.temp_dir, ignore_errors=True)

        def test_should_upload_with_env_credentials(self):
            os.environ["PYPI_USERNAME"] = "username"

# Generated at 2022-06-24 01:58:06.076792
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    fake_path = "some_path"
    fake_glob_pattern = "*.txt"
    upload_to_pypi(fake_path, False, [fake_glob_pattern])
    run.assert_called_once_with(f"twine upload  -u '__token__' -p 'pypi-test-token'  '{fake_path}/{fake_glob_pattern}'")

# Generated at 2022-06-24 01:58:10.102261
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test that uploading to PyPI works."""
    upload_to_pypi(glob_patterns=["a", "b"])
    assert run.calls == [
        f"twine upload  -u '__token__' -p 'pypi-xyz'  'dist/a' 'dist/b'"
    ]



# Generated at 2022-06-24 01:58:14.080967
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockTask
    from .helpers import mock_run

    mock_task = MockTask()
    path = 'dist'
    skip_existing = False
    glob_patterns = ['*']

    with mock_run(mock_task):
        upload_to_pypi(path, skip_existing, glob_patterns)

    assert mock_task.ran == 1
    assert mock_task.kwargs['command'][0] == f"twine upload -u '__token__' -p 'pypi-token' " \
                                            f"'{path}/{glob_patterns[0]}'".replace('[', '{').replace(']', '}')

# Generated at 2022-06-24 01:58:23.894112
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import warnings

    from invoke import Config
    from invoke import Context
    from invoke.exceptions import UnexpectedExit

    import semantic_release.settings as settings

    from .helpers import LoggedFunctionTestCase
    from .helpers import mock_path

    with mock_path("semantic_release.hvcs.git._run_git_command"):
        with mock_path("semantic_release.hvcs.git.vcs_api.VcsApi._run"):
            with mock_path("semantic_release.settings.get_project_management_service"):
                with mock_path("semantic_release.settings.get_vcs_service"):
                    from .helpers import ConfiguredTestCase


# Generated at 2022-06-24 01:58:35.165644
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Verify that the function upload_to_pypi will call the command
    'twine upload -u {username} -p {password} -r '{repo_name}' foo'
    """

    class MockRun:
        def __init__(self):
            self.log = []

        def __call__(self, command):
            self.log.append(command)

    mock_run = MockRun()

    def mock_get(key, default):
        if key == "repository":
            return "foo"
        return default

    old_run = run
    old_os_environ = os.environ
    old_config_get = config.get

    os.environ = {
        "PYPI_TOKEN": "pypi-123456",
    }

# Generated at 2022-06-24 01:58:37.179928
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test the function
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-24 01:58:47.581855
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run_mock(command: str):
        assert "twine upload " in command
        assert " -u 'username' -p 'password'" in command
        assert '"-r ' in command
        assert " --skip-existing" not in command
        assert '"dist/packagename-1.2.3-py3-none-any.whl"' in command

    path = "dist"
    package_filename = "packagename-1.2.3-py3-none-any.whl"
    glob_patterns = [package_filename]
    username = "username"
    password = "password"
    repository = "pypi"
    upload_to_pypi_params = {"run": run_mock, "path": path, "glob_patterns": glob_patterns}
    os.environ

# Generated at 2022-06-24 01:58:50.282788
# Unit test for function upload_to_pypi

# Generated at 2022-06-24 01:58:52.217854
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

if __name__ == '__main__':
    test_upload_to_pypi()

# Generated at 2022-06-24 01:58:55.052952
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist")

# Generated at 2022-06-24 01:58:57.198144
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config.set("repository", "PyPI")
    upload_to_pypi(glob_patterns=["*.whl"])

# Generated at 2022-06-24 01:59:00.265802
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class Object(object):
        pass

    class Config(object):
        pass

    conf = Config()
    conf.repository = "blah"

    config.set(conf)
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-24 01:59:05.704172
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert not config.get("repository", None)
    upload_to_pypi()
    assert os.environ.get("PYPI_TOKEN", None)


# Generated at 2022-06-24 01:59:07.693450
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:08.359972
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist")

# Generated at 2022-06-24 01:59:15.278236
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import prepare_environment
    from .helpers import reset_environment

    logger.info("Testing upload_to_pypi")
    prepare_environment(
        "testdir", pypirc={}, pypi={}, env={}, plugins=["semantic_release.hvcs.git"]
    )

    upload_to_pypi(
        path="testdir/dist",
        glob_patterns=["testdir/dist/package-0.0.0.tar.gz"],
        skip_existing=True,
    )

    reset_environment("testdir")

# Generated at 2022-06-24 01:59:15.740146
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:18.784646
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert isinstance(upload_to_pypi(path='dist'),None)
    assert isinstance(upload_to_pypi(path='dist',skip_existing=True),None)
    assert isinstance(upload_to_pypi(glob_patterns=["*"]),None)

# Generated at 2022-06-24 01:59:24.977430
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_patterns = ['test.tar.gz']
    username = "__token__"
    password = "pypi-654321"
    path = "dist"

    def side_effect(cmd):
        assert cmd == f"twine upload -u '{username}' -p '{password}' " \
              f' "dist/{glob_patterns[0]}" '
        return "Done"

    run.side_effect = side_effect
    upload_to_pypi(path=path, glob_patterns=glob_patterns, skip_existing=False)
    run.side_effect = None

# Generated at 2022-06-24 01:59:30.542933
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Check that it raises an exception without a token
    from semantic_release.hvcs import upload_to_pypi
    from semantic_release.settings import config
    from semantic_release.errors import ImproperConfigurationError

    config.configure({"repository": "1"})
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-24 01:59:31.492691
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:39.608351
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi()"""
    # pylint: disable=protected-access
    from semantic_release.upload_to_pypi import upload_to_pypi

    assert "Uploading to PyPI" in upload_to_pypi._log_function()
    assert "Uploading to PyPI" in upload_to_pypi._log_function(
        path="dist", skip_existing=False, glob_patterns=None
    )
    assert "Uploading to PyPI" in upload_to_pypi._log_function(
        path="dist", skip_existing=False, glob_patterns=["*"]
    )

# Generated at 2022-06-24 01:59:42.865651
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 01:59:45.058242
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 01:59:48.451090
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    This test is a stub as it is difficult to test this function without uploading to PyPI
    """
    # Setup
    path = "dist"
    glob_patterns = ["*"]

    # Call
    upload_to_pypi(path, glob_patterns=glob_patterns)

    pass

# Generated at 2022-06-24 01:59:50.650436
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-24 01:59:54.296238
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = "dist/test_wheels")
    upload_to_pypi(path = "dist/test_wheels", glob_patterns = ["*"])
    upload_to_pypi(path = "dist/test_wheels", glob_patterns = ["test*"])

# Generated at 2022-06-24 01:59:54.843173
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 02:00:05.241039
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import time
    import shutil
    import tempfile
    from pathlib import Path
    import pytest
    import invoke

    mock_run = pytest.Mock()
    task = invoke.Collection("semantic_release").get("upload_to_pypi")

    tmp = Path(tempfile.mkdtemp())
    tmp_dist = tmp / "dist"
    tmp_dist.mkdir()

    # Create two files
    tmp_file1 = tmp_dist / "file1"
    tmp_file1.touch()

    # This file will be modified to test retry feature
    tmp_file2 = tmp_dist / "file2"
    tmp_file2.touch()

    with pytest.raises(invoke.Exit):
        task(mock_run)

    # Ensure it does not attempt to upload twice
   

# Generated at 2022-06-24 02:00:15.625229
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create mock artifacts
    artifacts = {
        "dist/package-0.0.1-py3-none-any.whl": b"binary content",
        "dist/package-0.0.1.tar.gz": b"binary content",
    }

    # Import mock artifacts and set base path to import from
    import mock_artifacts
    mock_artifacts.artifacts = artifacts
    mock_artifacts.base_path = "./"

    # Mock twine run(cmd, hide='err')
    import mock_twine
    mock_twine.run = lambda cmd, **kwargs: print(cmd)

    # Upload with just the token
    os.environ["PYPI_TOKEN"] = "pypi-1234567890abcdef"
    upload_to_pypi(skip_existing=True)
    os

# Generated at 2022-06-24 02:00:19.991009
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 02:00:27.141147
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Ensures that we are calling twine as expected.
    """
    run_mock = Mock(return_value=True)
    path = "package_path"
    with patch("invoke.run", run_mock):
        upload_to_pypi(path=path)
        run_mock.assert_called()
        call_args = run_mock.call_args[0][0]
        assert call_args.startswith("twine upload")

# Generated at 2022-06-24 02:00:34.639919
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    from invoke.exceptions import UnexpectedExit

    from .helpers import (
        LoggedFunction,
    )
    from semantic_release.helpers import chdir

    from .test_settings import config

    logging.getLogger(__name__).info = Mock()
    input_params = {"path": "dist", "skip_existing": False, "glob_patterns": ["*"]}
    with chdir("tests/repositories/example"):
        os.environ["HOME"] = "."
        LoggedFunction((upload_to_pypi))(input_params)
        # remove the config files so that the next test is not disturbed
        os.remove(".pypirc")
        os.remove(".pypi-credentials")
        os.environ.pop("HOME")

    input_

# Generated at 2022-06-24 02:00:36.357958
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-24 02:00:37.848270
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=")")

# Generated at 2022-06-24 02:00:47.966730
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    with patch("invoke.run") as mocking_run:
        upload_to_pypi()
        mocking_run.assert_called_with(
            "twine upload -u '' -p ''  '*'"
        )

    with patch("invoke.run") as mocking_run:
        upload_to_pypi(
            path="foo", skip_existing=True, glob_patterns=["a", "b"],
        )
        mocking_run.assert_called_with(
            "twine upload -u '' -p '' --skip-existing 'foo/a'"
        )
        mocking_run.assert_called_with(
            "twine upload -u '' -p '' --skip-existing 'foo/b'"
        )

# Generated at 2022-06-24 02:00:48.622351
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Implement.
    pass

# Generated at 2022-06-24 02:00:54.888856
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from semantic_release.settings import config
    from semantic_release.settings import build_config

    config.update(build_config(enable_plugins=False))
    config.update({
        "repository_url": "https://pypi.org"
    })

    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

# Generated at 2022-06-24 02:00:55.731465
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:00:56.933076
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", True, ["*"])

# Generated at 2022-06-24 02:00:59.167320
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="temp_dir", skip_existing=False, glob_patterns=["*"])
    # upload_to_pypi()

# Generated at 2022-06-24 02:01:09.035423
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import pytest
    from invoke import Context
    from semantic_release.settings import config
    from semantic_release import distutils_upload
    from semantic_release.distutils_upload import upload_to_pypi

    def mock_run(command, warn=False, **_):
        # Run the command in a subprocess. If the command is a twine upload, check if the correct arguments are passed in.
        context = Context()
        if command.startswith("twine upload"):
            username = os.environ.get("PYPI_USERNAME", None)
            password = os.environ.get("PYPI_PASSWORD", None)
            token = os.environ.get("PYPI_TOKEN", None)
            require_password = username and password

# Generated at 2022-06-24 02:01:12.687587
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-24 02:01:18.252358
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi.logger = mock.Mock()
    upload_to_pypi.logger.info = mock.Mock()
    upload_to_pypi()
    upload_to_pypi.logger.info.assert_called()

# Generated at 2022-06-24 02:01:20.443859
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-24 02:01:25.441861
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(glob_patterns=["a.tar.gz"]) == True
    assert upload_to_pypi(glob_patterns=["README.md"]) == True
    assert upload_to_pypi(glob_patterns=["a.tar.gz", "README.md"]) == True
    assert upload_to_pypi(glob_patterns=[]) == True

# Generated at 2022-06-24 02:01:29.378975
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
        For now, just make sure that we don't throw exception when we call our function
    """
    import io
    from io import StringIO
    from contextlib import redirect_stdout

    f = io.StringIO()
    with redirect_stdout(f):
        upload_to_pypi()
    assert f.getvalue() == ''

# Generated at 2022-06-24 02:01:35.286325
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import glob
    import shutil

    from semantic_release.settings import config
    from semantic_release.settings import set_config_value
    from semantic_release.hvcs.git import get_commit_message
    from semantic_release.history.parser import split_commit_message

    from .helpers import mock_run
    from .helpers import mock_HVCS_get_commit_message
    from .helpers import mock_parser_split_commit_message

    # Create a directory for the test
    test_dir = os.path.join(os.getcwd(), 'test_pypi_upload')
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)
    os.makedirs(test_dir)


# Generated at 2022-06-24 02:01:39.428932
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(glob_patterns=['dist/*.tar', 'dist/*.zip']) == None
    assert upload_to_pypi(skip_existing=True) == None
    assert upload_to_pypi() == None

# Generated at 2022-06-24 02:01:45.233687
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi = UploadToPyPIMock()
    upload_to_pypi()
    upload_to_pypi('test/dist')
    upload_to_pypi(True)
    upload_to_pypi('test/dist', True)
    upload_to_pypi(True, False)
    upload_to_pypi('test/dist', True, False)


# Generated at 2022-06-24 02:01:47.686937
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test function with non existing directory
    try:
        upload_to_pypi(path='non_existing_directory')
    except ImproperConfigurationError:
        pass
    else:
        assert False, "Excepted ImproperConfigurationError"

# Generated at 2022-06-24 02:01:52.051236
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-24 02:01:53.934667
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Upload_to_pypi
    assert upload_to_pypi("dist") is None

# Generated at 2022-06-24 02:02:00.208997
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    import shutil
    import tempfile

    directory = tempfile.mkdtemp()


# Generated at 2022-06-24 02:02:02.404922
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-24 02:02:03.264800
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:02:05.851895
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = "12345token"
    os.environ['PYPI_TOKEN'] = token
    glob_patterns = ["pattern1.txt", "pattern2.txt"]
    upload_to_pypi(path="test_dist", skip_existing=True, glob_patterns=glob_patterns)
    return os.environ['PYPI_TOKEN']


# Generated at 2022-06-24 02:02:06.295486
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("bin")

# Generated at 2022-06-24 02:02:12.034539
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest import TestCase
    from unittest.mock import Mock, patch

    # Test uploading a single file
    class TestTwineUploadSingle(TestCase):
        def setUp(self):
            self.glob_patterns = ["*"]

        def test_upload_to_pypi(self):
            with patch("invoke.run") as mock_run:
                mock_run.return_value = ""
                upload_to_pypi(skip_existing=False, glob_patterns=self.glob_patterns)
                assert mock_run.called is True
                assert mock_run.call_args[0][0] == 'twine upload --skip-existing "dist/*"'


# Generated at 2022-06-24 02:02:12.973324
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:02:17.769053
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False, "TODO"

# Generated at 2022-06-24 02:02:26.901537
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import pathlib
    import glob
    import shutil
    import os

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = pathlib.Path(temp_dir)
        for i in range(2):
            p = temp_dir / f'test_wheel_{i}.whl'
            p.touch()

        try:
            import twine.commands.upload as _upload
        except:
            _upload = None

        if not _upload:
            assert True
        else:
            class Mock(object):

                def __init__(self, *args, **kwargs):
                    self.args = (args, kwargs)
                    self.distributions = []
                    self.username = ""
                    self.password = ""


# Generated at 2022-06-24 02:02:33.533967
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from python_semantic_release.helpers import load_pypirc_config
    from python_semantic_release.tests.helpers import captured_output, dict_clean
    from python_semantic_release.settings import load_pypi_config_from_pypirc

    # Load test PyPI config
    load_pypi_config_from_pypirc(load_pypirc_config())

    # If the user hasn't set a PyPI token, we can't run this test fully
    if not os.environ.get("PYPI_TOKEN"):
        # Since we need a token to test, just make sure that an error is raised without one
        with captured_output() as (out, err), pytest.raises(ImproperConfigurationError):
            upload_to_pypi()


# Generated at 2022-06-24 02:02:36.884230
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
  # TODO: Create mocks and write unit test.
  pass

# Generated at 2022-06-24 02:02:37.432269
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False

# Generated at 2022-06-24 02:02:44.909662
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_pattern = "*.py"
    dist = 'dist/my_wheel.whl'
    repository = "mypypi"
    username = "myusername"
    password = "mypassword"
    token = "pypi-mytoken"
    skip_existing = True
    run_mock = MagicMock()
    with patch("semantic_release.hvcs.pypi.run", run_mock, create=True):
        with patch("semantic_release.hvcs.pypi.os.environ", create=True) as env_mock:
            env_mock.get.side_effect = [token, username, password]
            upload_to_pypi(
                path="dist", skip_existing=skip_existing, glob_patterns=[glob_pattern]
            )


# Generated at 2022-06-24 02:02:46.946318
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi('dist')

# Generated at 2022-06-24 02:02:49.599839
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='./dist', skip_existing=False, glob_patterns=[])

# Generated at 2022-06-24 02:02:50.848528
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi."""
    upload_to_pypi()

# Generated at 2022-06-24 02:02:51.864381
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="tests/assets/dist", skip_existing=True)

# Generated at 2022-06-24 02:02:54.455952
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert (
        upload_to_pypi.__name__
        == "upload_to_pypi"
    ), "Function has unexpected name {}".format(
        upload_to_pypi.__name__
    )

# Generated at 2022-06-24 02:03:05.544493
# Unit test for function upload_to_pypi

# Generated at 2022-06-24 02:03:06.428463
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:08.660205
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:03:17.425977
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Mocking 'invoke.run' method
    def mock_invoke_run(command):
        assert command == "twine upload -u '__token__' -p 'pypi-token' -r 'test_repository' dist/test_glob_pattern"
        return None

    run_mock = mock_invoke_run
    path = 'dist'
    glob_patterns = ["test_glob_pattern"]
    repository = 'test_repository'
    token = "pypi-token"

# Generated at 2022-06-24 02:03:18.255052
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run(f"twine upload --help")

# Generated at 2022-06-24 02:03:25.923751
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Verify upload_to_pypi reads the environment properly and creates the correct
    command.
    """
    os.environ["PYPI_TOKEN"] = "test-token"
    os.environ["PYPI_REPOSITORY"] = "test-repository"
    os.environ["PYPI_SKIP_EXISTING"] = "true"
    os.environ["PYPI_FILE_PATTERNS"] = '["file1", "file2"]'

    actual_return = upload_to_pypi()

    assert actual_return == 'twine upload -u \'__token__\' -p \'test-token\' -r \'test-repository\' --skip-existing \'["file1", "file2"]\''

# Generated at 2022-06-24 02:03:28.388046
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test_dist", glob_patterns=["test"])

# Generated at 2022-06-24 02:03:36.375752
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

    assert upload_to_pypi(path="dist",skip_existing = False,glob_patterns = ["*"])

    assert upload_to_pypi(path="dist",skip_existing = True,glob_patterns = ["*"])

    assert upload_to_pypi(path="dist",skip_existing = True,glob_patterns = ["*"])

    assert upload_to_pypi(path="dist",skip_existing = True,glob_patterns = ["*"])

# Generated at 2022-06-24 02:03:40.137453
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-24 02:03:43.217383
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "sometoken"
    upload_to_pypi()
    assert "twine upload -u __token__ -p sometoken '*'" in LoggedFunction.call_log

# Generated at 2022-06-24 02:03:52.557981
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi using mock.
    """
    try:
        from unittest import mock
    except ImportError:
        import mock
    with mock.patch("semantic_release.hvcs.pypi.twine.upload_to_pypi.run") as run:
        upload_to_pypi(path="test", skip_existing=True, glob_patterns=["test1", "test2"])
        run.assert_called_once_with(
            "twine upload -u '__token__' -p 'test' --skip-existing "
            '"test/test1" "test/test2"'
        )

# Generated at 2022-06-24 02:03:55.851768
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = os.environ.get("PYPI_TOKEN")
    if not token:
        raise ImproperConfigurationError("Missing token for uploading to PyPI")

# Generated at 2022-06-24 02:03:59.827743
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi(
            path="/Users/user/Desktop/semantic-release/test/test_pypi",
            skip_existing=False,
            glob_patterns=[ "*" ],
        )
    except Exception as e:
        print("Error in test_upload_to_pypi: {}".format(e))

# Generated at 2022-06-24 02:04:00.254275
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-24 02:04:11.935220
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Creation unit test for upload_to_pypi.
    """

    def _conf(key: str, val: str) -> str:
        """
        A helper function for saving a configuration, and returning the value.
        """
        config.set(key, val)
        return val


# Generated at 2022-06-24 02:04:16.139226
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        # Successful upload
        os.environ["PYPI_TOKEN"] = "pypi-token"
        upload_to_pypi()
        assert True
    except ImproperConfigurationError:
        assert False

    # Missing credentials
    if "PYPI_TOKEN" in os.environ:
        del os.environ["PYPI_TOKEN"]

    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-24 02:04:20.712090
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    print("Testing upload_to_pypi")

    upload_to_pypi(
        path="/Users/ghm/Desktop/Courses/Lighthouse Labs/BC/Projects/week03/d3/02-Wednesday/lighthouse-python-string_slice/dist",
        skip_existing=True,
        glob_patterns=["*"])

# Generated at 2022-06-24 02:04:23.775064
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist")

# Generated at 2022-06-24 02:04:24.304418
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass # TODO

# Generated at 2022-06-24 02:04:25.660306
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test")

# Generated at 2022-06-24 02:04:35.984593
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import subprocess

    test_dir = tempfile.mkdtemp()
    runner_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    subprocess.check_call(["python3", "setup.py", "sdist", "bdist_wheel"], cwd=runner_dir)
    for file in os.listdir(os.path.join(runner_dir, "dist")):
        shutil.copy(os.path.join(runner_dir, "dist", file), os.path.join(test_dir, file))
    try:
        upload_to_pypi(path=test_dir, glob_patterns=["*.whl"])
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-24 02:04:39.217240
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi

# Generated at 2022-06-24 02:04:39.952478
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-24 02:04:49.333994
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test that upload_to_pypi is called correctly.
    """
    import pytest
    from unittest.mock import patch
    from semantic_release.settings import config
    from semantic_release.settings import active_option
    from .helpers import LoggedFunction
    from .helpers import LoggedMock

    with patch("semantic_release.hvcs.pypi.run") as run_mock:
        config["pypi"] = active_option
        LoggedFunction(logger).__call__(upload_to_pypi, "path", "True", glob_patterns=["*"])
    run_mock.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-token' --skip-existing 'path/'"
    )



# Generated at 2022-06-24 02:04:50.604517
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(os.getcwd())

# Generated at 2022-06-24 02:04:58.170577
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import create_package

    create_package(
        "package1",
        "1.0.0",
        "dist",
        (
            "package1-1.0.0-py3-none-any.whl",
            "package1-1.0.0.tar.gz",
            "package1-1.0.0-py2.py3-none-any.whl",
        ),
    )

    upload_to_pypi("dist")


# Generated at 2022-06-24 02:04:59.809251
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"

# Generated at 2022-06-24 02:05:06.655007
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test that upload_to_pypi works as expected

    """
    import mock

    with mock.patch("invoke.run") as invoke_mocked:
        upload_to_pypi()
        invoke_mocked.assert_called_once_with("twine upload  \"dist/*\"")

    with mock.patch("invoke.run") as invoke_mocked:
        upload_to_pypi(glob_patterns=["first", "second"])
        invoke_mocked.assert_called_once_with('twine upload  "dist/first" "dist/second"')

    with mock.patch("invoke.run") as invoke_mocked:
        upload_to_pypi(path="new_dist", skip_existing=True, glob_patterns=["*"])
        invoke_mocked.assert_

# Generated at 2022-06-24 02:05:07.151728
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:05:16.159882
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with mock.patch("os.environ", {}):
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

    with mock.patch("os.environ", {"PYPI_TOKEN": "pypi-test_token"}):
        with mock.patch("invoke.run") as mock_run:
            upload_to_pypi(glob_patterns=["test_glob"], skip_existing=True)

        mock_run.assert_called_once_with(
            'twine upload -u \'__token__\' -p \'pypi-test_token\' --skip-existing "dist/test_glob"'
        )


# Generated at 2022-06-24 02:05:17.172752
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-24 02:05:20.601459
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-24 02:05:31.013270
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from unittest.mock import patch

    import twine.commands.upload
    from semantic_release.helpers import chdir

    FAKE_DIST_FOLDER = Path("dist")
    FAKE_DIST_FOLDER.mkdir(parents=True, exist_ok=True)
    for fake_dist in ["fake_dist_a.whl", "fake_dist_b.whl"]:
        copyfile(Path("semantic_release/tests/fake_dist/{}".format(fake_dist)), FAKE_DIST_FOLDER / fake_dist)

    # Mock call to twine.commands.upload.upload

# Generated at 2022-06-24 02:05:39.094079
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import sys
    from unittest.mock import patch
    import pytest
    from invoke.exceptions import UnexpectedExit

    from semantic_release.settings import config

    with patch("os.environ.get") as env_mock, patch("invoke.run") as run_mock:
        env_mock.return_value = None

        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

        env_mock.return_value = "token"

        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

        env_mock.return_value = "pypi-token"


# Generated at 2022-06-24 02:05:48.910773
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test to ensure that the function upload_to_pypi works properly.
    This function is just a wrapper around the  twine command.
    """
    # Correctly upload to PyPI using token env variable
    os.environ['PYPI_TOKEN'] = "pypi-XXXXX"
    repository = config.get("repository", None)
    repository_arg = f" -r '{repository}'" if repository else ""
    username_password = f"-u __token__ -p {os.environ['PYPI_TOKEN']}"
    skip_existing_param = ""
    dist = " './*'"
    run_command = f"twine upload {username_password}{repository_arg}{skip_existing_param} {dist}"
    upload_to_pypi()
    upload_to_