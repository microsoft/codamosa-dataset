

# Generated at 2022-06-12 06:47:55.727865
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for upload_to_pypi
    """
    assert upload_to_pypi is not None

# Generated at 2022-06-12 06:48:03.912243
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    twine_upload = run.mock()

    def _get_env_var(key, default_value=None):
        if key == 'PYPI_TOKEN':
            return 'pypi-fake_token'

    run.env = {}
    run.env.get = _get_env_var
    run.exists = lambda x: True

    upload_to_pypi()

    twine_upload.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-fake_token'  'dist/*'"
    )

# Generated at 2022-06-12 06:48:12.610188
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test to verify if upload_to_pypi works as expected.
    """
    try:
        upload_to_pypi(path="dist")
    except ImproperConfigurationError:
        assert True

    try:
        upload_to_pypi(path="dist", skip_existing=True)
    except ImproperConfigurationError:
        assert True

    try:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
    except ImproperConfigurationError:
        assert True

    try:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*", "*/*"])
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-12 06:48:14.248332
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: unit test
    pass

# Generated at 2022-06-12 06:48:18.321455
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if not os.path.exists('tests/test_data'):
        raise ImproperConfigurationError("Test data is missing")

    upload_to_pypi(path='tests/test_data/pyproject_twine_data', skip_existing=False, glob_patterns=["*.whl"])

# Generated at 2022-06-12 06:48:28.038359
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # GIVEN
    os.environ["PYPI_TOKEN"] = "pypi-fake-token"
    os.environ["PYPI_USERNAME"] = "fake-username"
    os.environ["PYPI_PASSWORD"] = "fake-password"
    home_dir = os.environ.get("HOME", "")
    if os.path.isfile(os.path.join(home_dir, ".pypirc")):
        os.remove(os.path.join(home_dir, ".pypirc"))
    # WHEN
    upload_to_pypi()
    # THEN
    # Test that the expected command was called
    # (there is no need to check the output of the function because it is already tested by twine)

# Generated at 2022-06-12 06:48:29.006220
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='dist')

# Generated at 2022-06-12 06:48:29.622192
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:32.812383
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:48:37.534846
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run = MockRun()
    upload_to_pypi.run = run
    upload_to_pypi("test_folder", True)
    run.assert_called_with(
        'twine upload -u \'__token__\' -p \'pypi-test_token\' --skip-existing "test_folder/test_file.tar.gz"'
    )

# Generated at 2022-06-12 06:48:53.228345
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from string import ascii_letters
    import re
    from unittest.mock import patch

    from .compat import StringIO
    from .helpers import captured_output

    # Test uploading to pypi with a token
    with patch("invoke.run", return_value=None) as mock_run:
        with captured_output() as (out, err):
            upload_to_pypi(token="fake_token")
            assert re.search(r"twine upload -u '__token__' -p 'fake_token' \*",
                             out.getvalue().strip()) is not None
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'fake_token' *"
        )

    # Test uploading to pypi with a username and password

# Generated at 2022-06-12 06:49:02.241308
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from os import environ
    from pathlib import Path
    from invoke import MockContext
    from .context import Context

    Path('dist').mkdir(exist_ok=True)
    open("dist/foobar", 'w').write("")

    def test_upload_to_pypi_bad():
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

    def test_upload_to_pypi_token():
        environ['PYPI_TOKEN'] = 'pypi-asdf'
        with Context(runner=MockContext(), config={
            'repository': 'pypi'
        }):
            upload_to_pypi()


# Generated at 2022-06-12 06:49:11.379922
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    import tempfile
    import zipfile
    import re
    import glob

    with tempfile.TemporaryDirectory() as base_path:
        path = os.path.join(base_path, "dist")
        os.mkdir(path)
        shutil.copyfile(
            os.path.join(os.path.dirname(__file__), "wheel_test.whl"),
            os.path.join(path, "wheel_test-1.0.0-py3-none-any.whl"),
        )
        upload_to_pypi(path=path, skip_existing=True, glob_patterns=["wheel*"])
        # Check that the file hasn't been deleted from disk

# Generated at 2022-06-12 06:49:19.796943
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_logger
    from .helpers import mock_invoke_run

    username, password, repository, token, glob_patterns, path, skip_existing = (
        "username",
        "password",
        "pypi-repo",
        "pypi-token",
        ["pattern1", "pattern2"],
        "dist",
        True,
    )

    def mock_config(key):
        return {"repository": repository}.get(key, None)

    with mock_logger() as mock_logger_calls, mock_invoke_run() as mock_run_calls:
        mock_run_calls.side_effect = Exception  # Ensure an exception is thrown

        config.get = mock_config

        # No username/password, no token

# Generated at 2022-06-12 06:49:22.963780
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-12 06:49:25.846051
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # arrange
    path = "dist"
    glob_patterns = ["*"]

    # act
    upload_to_pypi(path, glob_patterns=glob_patterns)

# Generated at 2022-06-12 06:49:36.031929
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def test_invoke_command(command):
        os.environ["PYPI_TOKEN"] = "pypi-abcdefgh"
        os.environ["PYPI_USERNAME"] = "user"
        os.environ["PYPI_PASSWORD"] = "pass"
        upload_to_pypi()
        upload_to_pypi(skip_existing=True)
        assert "twine upload" in command.call_args_list[0]
        assert "twine upload --skip-existing" in command.call_args_list[1]

    def test_invoke_command_with_dist_name(command):
        os.environ["PYPI_TOKEN"] = "pypi-abcdefgh"
        upload_to_pypi(path="my_dist")

# Generated at 2022-06-12 06:49:47.422145
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""

    # Test: Invalid parameters (1)
    try:
        upload_to_pypi(path=None)
        assert False
    except:
        assert True

    # Test: Invalid parameters (2)
    try:
        upload_to_pypi(skip_existing=-1)
        assert False
    except:
        assert True

    # Test: Invalid parameters (3)
    try:
        upload_to_pypi(glob_patterns=None)
        assert False
    except:
        assert True

    # Test: Valid parameters
    try:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert True
    except:
        assert False

# Generated at 2022-06-12 06:49:48.029271
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:54.550656
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = os.environ.get("PYPI_TOKEN", None)
    username = os.environ.get("PYPI_USERNAME", None)
    password = os.environ.get("PYPI_PASSWORD", None)

    try:
        os.environ["PYPI_TOKEN"] = "test_token"
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert str(e) == "missing credentials for uploading to PyPI"
    else:
        assert False

    try:
        os.environ["PYPI_TOKEN"] = "pypi-test_token"
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert str(e) == "missing credentials for uploading to PyPI"

# Generated at 2022-06-12 06:50:08.200601
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockConfig
    from .helpers import MockRun

    # Create some dummy files to upload
    dummy_files = ["test_package-1.0.0-py3-none-any.whl"]
    for dummy_file in dummy_files:
        with open(dummy_file, "w") as f:
            f.write("Dummy content")

    with MockConfig() as mock_config, MockRun() as mock_run:
        mock_config.get.return_value = None
        # Test that upload succeeds with environment variable set
        os.environ["PYPI_TOKEN"] = "pypi-abcde12345"

# Generated at 2022-06-12 06:50:19.078652
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import get_upload_details, mock_upload_ok, mock_upload_skip_existing

    pypi_api_url = os.environ["PYPI_URL"]
    username = "username"
    password = "password"

    with mock_upload_ok(pypi_api_url, username, password):
        upload_to_pypi(
            glob_patterns=["fake-1.0.0*.whl"],
            skip_existing=False,
            path=os.path.join("tests", "files"),
        )

    files = get_upload_details(pypi_api_url)

    assert len(files) == 1
    assert files[0]["name"] == "fake-1.0.0-py3-none-any.whl"


# Generated at 2022-06-12 06:50:25.513058
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.environ["PYPI_TOKEN"] = "pypi-testtoken"
        upload_to_pypi(
            path="./tests/test_artifact",
            skip_existing=True,
            glob_patterns=["semantic_release_test*"],
        )
    except ImproperConfigurationError:
        pass
    finally:
        del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-12 06:50:34.569429
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Upload a few dummy packages.
    """
    # Create test packages
    run("python setup.py sdist bdist_wheel")

    # Upload test packages
    run(
        "TWINE_USERNAME=username TWINE_PASSWORD=password "
        "invoke twinepypi -t --dist-dir=dist"
    )

    # Unit test for function upload_to_pypi
    def test_upload_to_pypi():
        """Upload a few dummy packages.
    """
        # Create test packages
        run("python setup.py sdist bdist_wheel")

        # Upload test packages
        run(
            "TWINE_USERNAME=username TWINE_PASSWORD=password "
            "invoke twinepypi -t --dist-dir=dist"
        )



# Generated at 2022-06-12 06:50:37.000397
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-12 06:50:37.995365
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() is None

# Generated at 2022-06-12 06:50:39.596027
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-12 06:50:42.458285
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi('tests/data',True,["*.whl"])

# Generated at 2022-06-12 06:50:51.810918
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import sys, os
    abspath = os.path.abspath(__file__)
    dname = os.path.dirname(abspath)
    os.chdir(dname)
    sys.path.insert(0, dname)

    # Run function with no configuration
    try:
        upload_to_pypi()
        assert(False)
    except ImproperConfigurationError:
        pass
    except Exception:
        assert(False)

    # Run function with empty .pypirc
    os.environ["HOME"] = dname
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    try:
        upload_to_pypi()
        assert(False)
    except ImproperConfigurationError:
        pass


# Generated at 2022-06-12 06:51:01.254436
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
        twine.__name__
    except NameError:
        return

    # Upload
    os.environ["HOME"] = os.path.join(os.path.dirname(__file__), "test_files")
    upload_to_pypi("test_files/dist")

    # Upload using a token
    os.environ["HOME"] = os.path.join(os.path.dirname(__file__), "test_files")
    os.environ["PYPI_TOKEN"] = "pypi-foo"
    upload_to_pypi("test_files/dist")

# Generated at 2022-06-12 06:51:20.426866
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*.whl"])

# Generated at 2022-06-12 06:51:32.451052
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from semantic_release.settings import _default_config

    # Failing if no pypirc config
    if os.path.isfile(os.path.join(os.environ.get("HOME", ""), ".pypirc")):
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi(path="dist", skip_existing=True, glob_patterns=[])
    else:
        # Passing if proper config
        os.environ["PYPI_USERNAME"] = "somestring"
        os.environ["PYPI_PASSWORD"] = "somestring"
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=[])
        # Failing if no username

# Generated at 2022-06-12 06:51:34.493009
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        return True
    raise Exception("ImproperConfigurationError not raised!")

# Generated at 2022-06-12 06:51:35.084515
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:51:36.170196
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:51:41.112383
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for branch name."""
    orig_env = dict(os.environ)

    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    os.environ["PYPI_TOKEN"] = "token"
    try:
        upload_to_pypi("some/path")
    finally:
        os.environ.clear()
        os.environ.update(orig_env)

# Generated at 2022-06-12 06:51:44.771434
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(glob_patterns=["foo.whl"])

# Generated at 2022-06-12 06:51:50.762031
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def my_function(cmd):
        my_function.cmd = cmd
    try:
        run_old = run
        run = my_function
        upload_to_pypi(path = 'dist', skip_existing = True, glob_patterns = ['wheel_1.0.0-1.0.1.tar.gz'])
        assert my_function.cmd == "twine upload -u '__token__' -p 'pypi-xxx' --skip-existing 'dist/wheel_1.0.0-1.0.1.tar.gz'"
    finally:
        run = run_old

# Generated at 2022-06-12 06:51:52.059572
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.settings import config
    assert config.get("dry_run")

# Generated at 2022-06-12 06:51:56.468802
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    #TODO: Test
    return
    from semantic_release import upload_to_pypi

    upload_to_pypi(".", True)


if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-12 06:52:31.856285
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert not upload_to_pypi


# Generated at 2022-06-12 06:52:37.090575
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    shutil.copytree("tests/test_package", temp_dir)

    upload_to_pypi(
        path=temp_dir,
        glob_patterns=["test_package-1.0.0-py3-none-any.whl"],
        skip_existing=True,
    )

# Generated at 2022-06-12 06:52:44.853050
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from collections import namedtuple
    from pathlib import Path
    from unittest.mock import patch

    fake_args = namedtuple("fake_args", "path glob_patterns")
    fake_args.path = "dist"
    fake_args.glob_patterns = ["*"]

    # test token is used first if available
    with patch("os.environ.get") as mock_env:
        mock_env.return_value = "pypi-token"
        upload_to_pypi(fake_args.path, glob_patterns=fake_args.glob_patterns)
        mock_env.assert_called_with("PYPI_TOKEN")

    # test username and password used if available

# Generated at 2022-06-12 06:52:47.438668
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
        return False
    except ImproperConfigurationError:
        return True

# Generated at 2022-06-12 06:52:51.312993
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run("rm -rf dist")
    run("mkdir dist")
    run("touch dist/test_file.py")
    upload_to_pypi("dist", glob_patterns=["test_file.py"])

# Generated at 2022-06-12 06:52:53.655332
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    test_path = 'tests/samples/pypi'
    os.environ['PYPI_TOKEN'] = 'pypi-12345'
    upload_to_pypi(path=test_path)

# Generated at 2022-06-12 06:52:56.364014
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path=".", glob_patterns=["*"])

# Generated at 2022-06-12 06:53:05.799609
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Normal case
    def _normal_case():
        return upload_to_pypi(
            path="dist",
            skip_existing=False,
            glob_patterns=["*"],
        )

    # Normal case, API token
    def _normal_case_api_token():
        upload_to_pypi.logger.debug.assert_called_with("Uploading files to PyPI...")
        upload_to_pypi.logger.debug.assert_called_with(" - Using API token")
        upload_to_pypi.logger.debug.assert_called_with(" - Uploading: '\"dist/*\"'")
        upload_to_pypi.logger.debug.assert_called_with(" - to repository: 'None'")

# Generated at 2022-06-12 06:53:17.915489
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    # Create file and directory structures
    open("repository/dist/not_wheel.txt", "w").close()
    open("repository/dist/wheel.whl", "w").close()
    open("repository/dist/another_wheel.whl", "w").close()

    # Set environment variables for testing
    os.environ["PYPI_USERNAME"] = "test"
    os.environ["PYPI_PASSWORD"] = "test"

    # Run function
    upload_to_pypi(path="repository/dist", glob_patterns=["*.whl"])
    # Clean up file and directory structures
    os.remove("repository/dist/not_wheel.txt")
    os.remove

# Generated at 2022-06-12 06:53:26.390700
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi
    """

    # Test with no glob_patterns
    try:
        upload_to_pypi()
        assert False, "Expected an ImproperConfigurationError to be raised"
    except ImproperConfigurationError as e:
        # TODO: find a way to test the rest of this function
        assert e

    # Test with a valid path but no glob_patterns
    try:
        upload_to_pypi(path="dist")
        assert False, "Expected an ImproperConfigurationError to be raised"
    except ImproperConfigurationError as e:
        assert e

# Generated at 2022-06-12 06:54:43.571540
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns="*")
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=[])
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*", "**.**"])
    upload_to_pypi()

# Generated at 2022-06-12 06:54:49.432903
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch("os.environ.get", return_value="") as os_env, patch("invoke.run") as run:
        upload_to_pypi()
        run.assert_not_called()

    os.environ["PYPI_TOKEN"] = "pypi-token"
    with patch("invoke.run") as run:
        upload_to_pypi()
        run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
        )

    with patch("invoke.run") as run:
        upload_to_pypi(glob_pattern=["*", "!*.pyi"])

# Generated at 2022-06-12 06:54:56.217161
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import LoggedFunctionTest
    from .settings import mock_config
    from .settings import mock_run
    from .settings import mock_open

    def run_mocked(self, *args, **kwargs):
        args = args[0]
        self.assertEqual(
            args, "twine upload -u '__token__' -p 'pypi-token' --skip-existing 'dist/*'"
        )
        return True


# Generated at 2022-06-12 06:54:58.139188
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config["repository"] = "mytestpypi"
    upload_to_pypi()

# Generated at 2022-06-12 06:54:59.340518
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-12 06:55:08.169311
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with run.patch("invoke.run", return_value=None) as run_mock:
        upload_to_pypi()
        run_mock.assert_called_once()
        assert run_mock.call_args[0][0] == 'twine upload  "dist/*"'

        run_mock.reset_mock()
        upload_to_pypi("dist", True)
        assert run_mock.call_args[0][0] == 'twine upload  --skip-existing "dist/*"'

        run_mock.reset_mock()
        upload_to_pypi("dist", True, ["spam", "ham"])
        assert run_mock.call_args[0][0] == 'twine upload  --skip-existing "dist/spam" "dist/ham"'



# Generated at 2022-06-12 06:55:17.805268
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # test success upload with pypi token
    assert 0 == upload_to_pypi(
        path=".",
        skip_existing=True,
        glob_patterns=[
            "setup.py",
            "twine_plugins.py",
            "twine_plugins_test.py",
            "pypi_uploader_test.py",
        ],
    )
    # test success upload with pypi username and password
    os.environ["PYPI_USERNAME"] = "myusername"
    os.environ["PYPI_PASSWORD"] = "mypassword"

# Generated at 2022-06-12 06:55:23.525788
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with only a token, and also with a token that doesn't start with pypi-
    token = "pypi-abc123"
    assert upload_to_pypi.__wrapped__.__name__ == "upload_to_pypi"
    try:
        assert upload_to_pypi.__wrapped__() == 1
    except ImproperConfigurationError as e:
        assert "Missing credentials for uploading to PyPI" in str(e)

    try:
        os.environ["PYPI_TOKEN"] = "abc123"
        assert upload_to_pypi.__wrapped__() == 1
    except ImproperConfigurationError as e:
        assert "PyPI token should begin with 'pypi-'" in str(e)


# Generated at 2022-06-12 06:55:30.746025
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    '''
    Test init_pypi_vars function

    '''

    upload_to_pypi()
    upload_to_pypi(path="test", skip_existing=True)
    upload_to_pypi(path="test", skip_existing=True, glob_patterns=["test"])
    upload_to_pypi(path="test", skip_existing=True, glob_patterns=["test,test2"])

# Generated at 2022-06-12 06:55:31.333365
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass