

# Generated at 2022-06-12 06:47:56.422551
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    assert False, "Test not implemented"

# Generated at 2022-06-12 06:47:58.172726
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True


# Generated at 2022-06-12 06:48:06.628494
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=unused-argument
    def run_side_effect(*args, **kwargs):
        return

    with run.patch.object(run, "__call__", return_value=run_side_effect):
        upload_to_pypi()
        run.assert_called_once_with(
            'twine upload -u "__token__" -p "pypi-token" "dist/*"'
        )

        upload_to_pypi(skip_existing=True, glob_patterns=["*.whl", "*.tar.gz"])
        run.assert_called_with(
            'twine upload -u "__token__" -p "pypi-token" --skip-existing '
            '"dist/*.whl" "dist/*.tar.gz"'
        )



# Generated at 2022-06-12 06:48:11.229137
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "fake user"
    os.environ["PYPI_PASS"] = "fake pass"
    run.return_value = "fake return value"
    upload_to_pypi()
    run.assert_called_once_with(
        "twine upload -u 'fake user' -p 'fake pass' 'dist/*'"
    )

# Generated at 2022-06-12 06:48:12.449883
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:24.392240
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import io
    import logging
    import sys
    from unittest.mock import MagicMock

    # Mock invoke run function
    mock_run = MagicMock()
    mock_run.return_value = None

    from .helpers import mock_function_in_module

    with mock_function_in_module("invoke.run", mock_run):
        # Mock logging module
        mock_logger = MagicMock()
        mock_logger.debug = MagicMock()
        mock_logger.info = MagicMock()
        mock_logger.error = MagicMock()

        mock_logging = MagicMock()
        mock_logging.getLogger = MagicMock(return_value=mock_logger)


# Generated at 2022-06-12 06:48:24.916495
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 == 1

# Generated at 2022-06-12 06:48:26.189821
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Must be tested manually for now as it is dependent on Twine
    pass

# Generated at 2022-06-12 06:48:28.056386
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:48:28.677797
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:43.642540
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Ensure that upload_to_pypi calls twine correctly."""
    import mock
    import tempfile
    import shutil
    path = tempfile.mkdtemp()
    # Mock run to ensure that the correct parameters were passed
    mock_run = mock.Mock()
    with mock.patch("invoke.run", mock_run):
        upload_to_pypi(path)
    mock_run.assert_called_with(f'twine upload "*"', out=None, warn=True)
    # Check that a token is used
    mock_run.reset_mock()
    os.environ["PYPI_TOKEN"] = "pypi-TOKEN"
    with mock.patch("invoke.run", mock_run):
        upload_to_pypi(path)

# Generated at 2022-06-12 06:48:44.481505
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:48:45.611549
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:48:46.247092
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:48:52.458743
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # GIVEN a test environment with setup.cfg and mypackage-1.0.0.tar.gz in it
    # WHEN upload_to_pypi is called
    # THEN ensure that twine upload was called correctly
    run.side_effect = lambda command: [print(command)]
    upload_to_pypi()
    assert run.call_args.args[0] == "twine upload -u '__token__' -p 'pypi-12345' 'dist/*'"

# Generated at 2022-06-12 06:48:58.849518
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Tests unit function upload_to_pypi
    """
    import tempfile, os
    with tempfile.TemporaryDirectory() as dir:
        path = os.path.join(dir, 'dist')
        os.makedirs(path)
        open(os.path.join(path, 'a.txt'), 'a').close()
        upload_to_pypi(path)

# Generated at 2022-06-12 06:49:10.101839
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set environment variables for testing
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"

    # Set file path for testing
    file_name = "test_file.txt"
    file_path = os.path.join("dist", file_name)

    # Create file for testing
    with open(file_path, "w") as test_file:
        test_file.write("Test content")
        test_file.close()

    # Test upload_to_pypi function
    upload_to_pypi()

    # Remove file after testing
    os.remove(file_path)

# Generated at 2022-06-12 06:49:20.164227
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    from unittest.mock import MagicMock, patch, PropertyMock

    c = MagicMock()
    c.stdout = PropertyMock(side_effect=["/home/xyz/.pypirc", "/home/xyz/.pypirc"])
    c.return_value = c
    with patch("semantic_release.packages.twine.run", c), patch(
        "semantic_release.packages.twine.config", lambda x: "pypi-test"
    ), patch("os.environ", {"HOME": "/home/xyz"}):
        upload_to_pypi()

# Generated at 2022-06-12 06:49:20.473588
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:26.012618
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import pathlib

    from semantic_release import run

    # Test for upload_to_pypi
    temp_dir: tempfile.TemporaryDirectory = tempfile.TemporaryDirectory()
    _: pathlib.Path = pathlib.Path(temp_dir.name).mkdir(parents=True, exist_ok=False)
    run.upload_to_pypi(path=temp_dir.name)

# Generated at 2022-06-12 06:49:42.819334
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    dist_path = "/some/path"
    username = "myusername"
    password = "mypassword"
    repository = "https://example.pypi/simple"
    token = "pypi-mytoken"
    skip_existing = True

    def mock_run(command):
        # Check that the command is being executed correctly
        assert command == (
            "twine upload "
            f"-u '{username}' "
            f"-p '{password}' "
            f"-r '{repository}' "
            f"--skip-existing "
            f'"{dist_path}/foo" '
            f'"{dist_path}/bar"'
        )

    def mock_env(key, default=None):
        if key == "PYPI_TOKEN":
            return token

# Generated at 2022-06-12 06:49:50.704644
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    os.environ["PYPI_TOKEN"] = "pypi-1234567890"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    os.environ["PYPI_USERNAME"] = "foo"
    os.environ["PYPI_PASSWORD"] = "bar"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

# Generated at 2022-06-12 06:50:02.004659
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import unittest
    import mock
    import tempfile
    import os
    from semantic_release.settings import config
    import semantic_release.hvcs
    import semantic_release.packaging
    from semantic_release.packaging import pypi
    from semantic_release.utils import onerror

    class MockInvokeRun():
        def __init__(self):
            self.cmd = ""

        def __call__(self, cmd):
            self.cmd = cmd

    class MockSemanticReleaseHvcs():
        def __init__(self):
            self.vcs = "git"

        def get_config(self, key):
            if key == "repository":
                return "https://github.com/relekang/semantic-release"


# Generated at 2022-06-12 06:50:05.866821
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test 1, missing credentials
    with LoggedFunction(logger):
        try:
            upload_to_pypi()
        except ImproperConfigurationError as error:
            assert str(error) == "Missing credentials for uploading to PyPI"

# Generated at 2022-06-12 06:50:06.554035
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:07.259258
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:50:08.337758
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:09.988776
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi() function.
    """
    assert True

# Generated at 2022-06-12 06:50:20.468679
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test twine upload helper function."""
    patch_run = "semantic_release.hvcs.twine.run"

    with patch(patch_run) as mock_run:
        mock_run.return_value = "test"
        upload_to_pypi(path="./test", skip_existing=True)
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-test' --skip-existing './test/*'",
            warn=True,
        )

    with patch(patch_run) as mock_run:
        mock_run.return_value = "test"
        upload_to_pypi(path="./test")

# Generated at 2022-06-12 06:50:31.390914
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    import tempfile
    import shutil
    import os
    import glob

    # Create a test directory and a test package in it
    current_dir = os.getcwd()
    test_dir = tempfile.TemporaryDirectory()
    test_dir_path = test_dir.name
    os.chdir(test_dir_path)

    # Create the setup.py
    with open('setup.py', 'w') as fd:
        fd.write('from setuptools import setup\n'
                 'setup(name="test")')

    # Run sdist
    run('python setup.py sdist')

    # Remove the setup.py again
    os.unlink('setup.py')

    # Change to the dist folder to upload_to_p

# Generated at 2022-06-12 06:50:48.574670
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_pattern = []

# Generated at 2022-06-12 06:51:00.925433
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from .helpers import get_logger_output
    from .helpers import patch_function
    from .helpers import patch_os_environ

    with patch_function(logger, "info"), patch_function(logger, "debug"):
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi(skip_existing=True)

        with pytest.raises(ImproperConfigurationError):
            with patch_os_environ({"PYPI_TOKEN": "bad_token"}):
                upload_to_pypi(skip_existing=True)

        with patch_os_environ({"PYPI_TOKEN": "pypi-mytoken"}):
            upload_to_pypi(skip_existing=True)


# Generated at 2022-06-12 06:51:05.365868
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for module upload_to_pypi"""
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    os.environ["PYPI_TOKEN"] = "pypi-1"
    upload_to_pypi("dist", True)

# Generated at 2022-06-12 06:51:14.171550
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username_password = " -u __token__ -p pypi-abcdef"
    repository_arg = " -r 'my-repository'"
    skip_existing_param = " --skip-existing"

    response = upload_to_pypi(path="some/path",
                              skip_existing=True,
                              glob_patterns=["."])
    assert response == "invoke run 'twine upload {} {}'".format(
        username_password+skip_existing_param+repository_arg,
        '"some/path/."',
    )

# Generated at 2022-06-12 06:51:20.334808
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == 'upload_to_pypi'
    assert upload_to_pypi.__doc__ == 'Upload wheels to PyPI with Twine.\n\n    Wheels must already be created and stored at the given path.\n\n    Credentials are taken from either the environment variable\n    ``PYPI_TOKEN``, or from ``PYPI_USERNAME`` and ``PYPI_PASSWORD``.\n\n    :param path: Path to dist folder containing the files to upload.\n    :param skip_existing: Continue uploading files if one already exists.\n        (Only valid when uploading to PyPI. Other implementations may not support this.)\n    :param glob_patterns: List of glob patterns to include in the upload (["*"] by default).\n    '


# Generated at 2022-06-12 06:51:22.298199
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Check if functions runs without error.
    """
    upload_to_pypi()

# Generated at 2022-06-12 06:51:34.003909
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypi_token = os.environ.get("PYPI_TOKEN")
    pypi_username = os.environ.get("PYPI_USERNAME")
    pypi_password = os.environ.get("PYPI_PASSWORD")

    os.environ["PYPI_TOKEN"] = "pypi-TEST"
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

    os.environ["PYPI_USERNAME"] = "TEST_USER"
    os.environ["PYPI_PASSWORD"] = "TEST_PASSWORD"
    upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"])


# Generated at 2022-06-12 06:51:34.952324
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:51:42.474811
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import pandas as pd
    import pandas.testing as pt
    from contextlib import contextmanager
    from pathlib import Path
    from unittest.mock import patch

    @contextmanager
    def mock_environment(key: str, value: str):
        os.environ[key] = value
        yield
        del os.environ[key]

    with tempfile.TemporaryDirectory() as tmpdirname:
        Path(tmpdirname).mkdir(parents=True, exist_ok=True)
        Path(tmpdirname,"test.csv").touch()
        Path(tmpdirname,"test.csv").write_text("A,B\n1,2\n")


# Generated at 2022-06-12 06:51:50.895780
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function
    """
    # Generate a fake repo token
    repo_token = "pypi-fake_key"
    os.environ["PYPI_TOKEN"] = repo_token

    # Create a mocked function
    def mocked_run(*args, **kwargs):
        return None

    # Call the upload_to_pypi function
    pass_test = False
    try:
        upload_to_pypi(run=mocked_run)
    except ImproperConfigurationError:
        pass_test = True

    # Change the repo token to something that does not start with 'pypi-'
    repo_token = "fake_key"
    os.environ["PYPI_TOKEN"] = repo_token
    fail_token_test = True

# Generated at 2022-06-12 06:52:37.930277
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    try:
        token = "token"
        os.environ["PYPI_TOKEN"] = token
        upload_to_pypi()
    except ImproperConfigurationError:
        raise AssertionError(
            f"Using PYPI_TOKEN={token}, upload_to_pypi() raised ImproperConfigurationError unexpectedly!"
        )

    # Test with username and password

# Generated at 2022-06-12 06:52:45.338289
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile

    # Cleanup when finished
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 06:52:50.827184
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ Test for twine upload"""
    with run.patch("semantic_release.hvcs.git.run") as mock_run:
        upload_to_pypi(skip_existing=True)
        mock_run.assert_called_once_with(
            "twine upload  --skip-existing 'dist/*'"
        )



# Generated at 2022-06-12 06:53:01.471093
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    md5_base64 = 'YWJjMTIzIT8kKiYoKSctPUB+'
    digest = 'sha256={}'.format(md5_base64)
    wheel_filename = 'pytest-1.0.0-py3-none-any.whl'
    wheel_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'files', wheel_filename))

# Generated at 2022-06-12 06:53:09.421135
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        old_token = os.environ.get("PYPI_TOKEN")
        os.environ["PYPI_TOKEN"] = "pypi-abc123"
        old_repository = config.get("repository", None)
        config["repository"] = "test"
        old_skip_existing = os.environ.get("SKIP_EXISTING")
        os.environ["SKIP_EXISTING"] = "True"

        upload_to_pypi(path="tests/test_dist", skip_existing=True)
    finally:
        if old_skip_existing:
            os.environ["SKIP_EXISTING"] = old_skip_existing
        else:
            del os.environ["SKIP_EXISTING"]

# Generated at 2022-06-12 06:53:16.457484
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import config as fake_config

    with fake_config("pypi", {
        "repository": "test",
        "repository_url": "https://upload.pypi.org/legacy/",
        "username": "test_user",
        "password": "test_passw"}):

        upload_to_pypi(path="test_path", skip_existing=False, glob_patterns=["test_glob"])

# Generated at 2022-06-12 06:53:19.330270
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    cmd = "pypi"
    cmd += " -u 'harsh' -p '1234'"
    cmd += " -r 'pypi'"
    cmd += " --skip-existing"
    cmd += " 'dist/requirements.txt' 'dist/pkg'"
    assert upload_to_pypi() == cmd

# Generated at 2022-06-12 06:53:19.977065
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False

# Generated at 2022-06-12 06:53:21.077489
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi is not None

# Generated at 2022-06-12 06:53:28.635935
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest import mock
    from os import path
    from semantic_release.utils import run_cmd
    from semantic_release.settings import config
    from shutil import rmtree, copyfile

    old_config = config.copy()
    os.environ["PYPI_USERNAME"] = "pypi_username"
    os.environ["PYPI_PASSWORD"] = "pypi_password"

    def cleanup_dir(dir_name):
        if path.isdir(dir_name):
            rmtree(dir_name)

    def cleanup_file(file_name):
        if path.isfile(file_name):
            os.remove(file_name)

    dir_name = "test_dir"
    file_name = f"{dir_name}/test_file"
   

# Generated at 2022-06-12 06:54:44.256042
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command: str):
        assert command.startswith(
            "twine upload  "
            + "-u '__token__' -p 'pypi-token' "
            + "-r 'username/package' "
            + "\"dist/pkg-1.0.0-py3-none-any.whl\""
        )
    run = mock_run
    os.environ["PYPI_TOKEN"] = "pypi-token"
    config["repository"] = "username/package"
    config["glob_patterns"] = ["*.whl"]
    upload_to_pypi()

# Generated at 2022-06-12 06:54:54.629173
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def get_credentials(username, password):
        os.environ["PYPI_USERNAME"] = username
        os.environ["PYPI_PASSWORD"] = password
        os.environ["HOME"] = ""

    def get_token(token):
        os.environ["PYPI_TOKEN"] = token
        os.environ["HOME"] = ""

    def execute(username=None, password=None, token=None, repository=None, skip_existing=None, glob_patterns=None):
        if username:
            get_credentials(username, password)
            os.environ.pop("PYPI_TOKEN", None)
        if token:
            get_token(token)
            os.environ.pop("PYPI_USERNAME", None)

# Generated at 2022-06-12 06:55:05.422254
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="tests/testdata/dist")
    upload_to_pypi(path="tests/testdata/dist", glob_patterns=["*"])
    upload_to_pypi(path="tests/testdata/dist", glob_patterns=["*", "*"])
    upload_to_pypi(path="tests/testdata/dist", glob_patterns=["*", "*", "*"])
    upload_to_pypi(path="tests/testdata/dist", glob_patterns=["*", "*.tar.gz"])
    upload_to_pypi(path="tests/testdata/dist", glob_patterns=["*.py"])
    upload_to_pypi(path="tests/testdata/dist", skip_existing=False)

# Generated at 2022-06-12 06:55:06.326246
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ """
    upload_to_pypi()

# Generated at 2022-06-12 06:55:14.120863
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile
    try:
        shutil.rmtree("dist")
    except:
        pass
    os.mkdir("dist")
    with open("dist/random_file.txt", "w") as f:
        f.write("foo")
    upload_to_pypi()
    shutil.rmtree("dist")

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-12 06:55:26.280702
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import pytest
    from pathlib import Path
    from semantic_release.hvcs import git

    temp_dir = tempfile.TemporaryDirectory()
    dist_dir = Path(temp_dir.name,"dist")
    dist_dir.mkdir()
    package_dir = Path(temp_dir.name,"src","semantic_release")
    package_dir.mkdir(parents=True)
    init_dir = Path(temp_dir.name,"src","__init__.py")
    init_dir.touch()

    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

    upload_to_pypi(path=dist_dir,skip_existing=True)

    temp_dir.cleanup()

# Generated at 2022-06-12 06:55:27.474001
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:55:32.160392
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch('invoke.run', return_value=None) as run_patch:
        upload_to_pypi('/path/to/dist', False, ['**/*.whl'])
        run_patch.assert_called_once_with('twine upload -u \'\' -p \'\'  "**/*.whl"')

# Generated at 2022-06-12 06:55:43.796115
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # test 1, skip_existing: True, glob_pattern: "*"
    run_command = 'twine upload --skip-existing "dist/*"'
    upload_to_pypi(skip_existing=True)
    assert run.called == True
    assert run.call_args[0][0] == run_command

    # test 2, skip_existing: False, glob_pattern: "*"
    run_command = 'twine upload "dist/*"'
    upload_to_pypi(skip_existing=False)
    assert run.called == True
    assert run.call_args[0][0] == run_command

    # test 3, skip_existing: False, glob_pattern: "dist/*.whl"
    run_command = 'twine upload "dist/*.whl"'
    upload_to_pyp

# Generated at 2022-06-12 06:55:54.419760
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == 'twine upload  "dist/*"'
    assert upload_to_pypi(
        path="dist",
        skip_existing=False,
        glob_patterns=["*", "*.*", "*.whl"],
    ) == 'twine upload  "dist/*" "dist/*.*" "dist/*.whl"'
    assert upload_to_pypi(
        path="dist", skip_existing=True, glob_patterns=["*", "*.*", "*.whl"],
    ) == 'twine upload  --skip-existing "dist/*" "dist/*.*" "dist/*.whl"'