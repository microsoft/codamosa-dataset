

# Generated at 2022-06-12 06:48:04.593932
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def test_upload_to_pypi_no_username_and_password_and_no_token():
        import mock
        from semantic_release.errors import ImproperConfigurationError
        from semantic_release.packages.twine import upload_to_pypi
        from semantic_release.settings import config

        # Run test
        with mock.patch.dict(os.environ, clear=True), mock.patch.object(config, "get") as get:
            get.return_value = None
            with pytest.raises(ImproperConfigurationError):
                upload_to_pypi()

    def test_upload_to_pypi_no_username_and_password_with_invalid_token():
        import mock
        from semantic_release.errors import ImproperConfigurationError

# Generated at 2022-06-12 06:48:12.951238
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    from invoke.context import Context
    from invoke.exceptions import Failure

    def fake_run(*args, **kwargs):
        pass

    ctx = Context()
    ctx.run = fake_run
    fake_ctx = ctx

    # Test with invalid token
    os.environ["PYPI_TOKEN"] = "token"
    try:
        upload_to_pypi(ctx=fake_ctx)
        assert False, "Token should begin with 'pypi-'"
    except ImproperConfigurationError:
        pass
    finally:
        del os.environ["PYPI_TOKEN"]

    # Test with invalid username/password

# Generated at 2022-06-12 06:48:24.391559
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import get_file_contents, mock_pypirc, mock_pypirc_credentials

    config.update({
        "repository": "pypi"
    })

    # Test upload to pypi with token
    with mock_pypirc_credentials(token="pypi-token"):
        try:
            upload_to_pypi()
        except ImproperConfigurationError:
            pass
        else:
            raise Exception('Expected ImproperConfigurationError')

    # Test upload to pypi with username/password
    with mock_pypirc_credentials(username="pypi-username", password="pypi-password"):
        try:
            upload_to_pypi()
        except ImproperConfigurationError:
            pass
        else:
            raise Exception

# Generated at 2022-06-12 06:48:28.192432
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Tests: Test upload_to_pypi function.
    """
    upload_to_pypi(path="dist")
    upload_to_pypi(path="dist", skip_existing=True)
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["my_wheel_*.whl"])

# Generated at 2022-06-12 06:48:29.200239
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:48:31.196994
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("/dist", False, ["*", "*.*"])
    assert True

# Generated at 2022-06-12 06:48:42.884613
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token_credentials = (
        "twine upload -u '__token__' -p 'pypi-1234' "
        "-r 'repo' --skip-existing 'dist/semantic_release*.whl'"
    )
    username_password_credentials = (
        "twine upload -u 'username' -p 'password' "
        "-r 'repo' --skip-existing 'dist/semantic_release*.whl'"
    )
    default_credentials = (
        "twine upload -u '' -p '' -r 'repo' --skip-existing 'dist/semantic_release*.whl'"
    )

# Generated at 2022-06-12 06:48:45.613290
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="path", skip_existing=False, glob_patterns="*")

# Generated at 2022-06-12 06:48:54.308398
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    c = run("twine upload dist/* --skip-existing", warn=True, hide=True)
    assert c.ok == True

    c = run("twine upload dist/* --skip-existing --repository pypi", warn=True, hide=True)
    assert c.ok == True

    c = run(
        "twine upload dist/* --skip-existing --repository pypi --username {} --password {}".format(
            os.environ.get("PYPI_USERNAME"), os.environ.get("PYPI_PASSWORD")
        ),
        warn=True,
        hide=True,
    )
    assert c.ok == True


# Generated at 2022-06-12 06:49:02.842959
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with ConfiguredTestPackage() as package_dir:
        os.environ["PYPI_USERNAME"] = "ABC"
        os.environ["PYPI_PASSWORD"] = "DEF"
        os.environ["PYPI_TOKEN"] = "GHI"
        test_path = "/foo/bar"
        upload_to_pypi(test_path, True, ["test"])
        # Assert that twine upload is invoked for package_dir + test_path with token
        assert run.assert_called
        assert run.call_args[0][0] == (
            "twine upload -u '__token__' -p 'GHI' --skip-existing \"{}/{}/test\"".format(
                package_dir, test_path
            )
        )

# Generated at 2022-06-12 06:49:08.170921
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi is not None

# Generated at 2022-06-12 06:49:17.441280
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi"""
    import filecmp
    from pathlib import Path
    from unittest.mock import patch

    # https://github.com/python-semantic-release/python-semantic-release/issues/366
    # https://github.com/python-semantic-release/python-semantic-release/issues/388
    # https://github.com/python-semantic-release/python-semantic-release/issues/479
    # https://github.com/python-semantic-release/python-semantic-release/issues/482


# Generated at 2022-06-12 06:49:18.830934
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path=".", skip_existing=False, glob_patterns=["*.yml"])

# Generated at 2022-06-12 06:49:20.032972
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", False)

# Generated at 2022-06-12 06:49:22.330060
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-12 06:49:23.374683
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()


# Generated at 2022-06-12 06:49:26.173546
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = True
    glob_patterns = "*"
    upload_to_pypi(path, skip_existing, glob_patterns)



# Generated at 2022-06-12 06:49:26.601413
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:49:29.828220
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def upload_to_pypi_mock(cmd):
        assert 'twine upload' in cmd
        assert 'foo/bar' in cmd

    with LoggedFunction(logger, lambda *args: None):
        upload_to_pypi(path='foo', glob_patterns=['bar'])

# Generated at 2022-06-12 06:49:39.907259
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist")

    token = os.environ.get("PYPI_TOKEN")
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")

    username_password = (
        f"-u '{username}' -p '{password}'" if username and password else ""
    )

    repository = config.get("repository", None)
    repository_arg = f" -r '{repository}'" if repository else ""

    dist = "dist/*"

    run(f"twine upload {username_password}{repository_arg} {dist}")

# Generated at 2022-06-12 06:49:54.270310
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username_password = "-u 'user' -p 'pass'"
    repository_arg = " -r 'my_repository'"
    skip_existing_param = " --skip-existing"
    dist = '"my_dist"'
    pattern = '"my_dist/*.tar.gz"'
    with invoke_run(return_value=None) as run_:
        upload_to_pypi(
            path="my_dist", skip_existing=True, glob_patterns=["*.tar.gz"]
        )
        run_.assert_called_once_with(
            f"twine upload {username_password}{repository_arg}{skip_existing_param} {pattern}"
        )



# Generated at 2022-06-12 06:49:54.875636
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:57.548199
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="tests/test_package")

# Generated at 2022-06-12 06:49:58.623993
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:59.079394
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:59.492583
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:10.371761
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function.
    """
    import pytest
    from semantic_release.errors import ImproperConfigurationError

    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi(None, False)

    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi(None, True)

    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi("tests", False)

    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi("tests", True)

# Generated at 2022-06-12 06:50:20.860430
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import subprocess
    import urllib.parse

    from semantic_release.history import get_local_head_ref_and_sha

    from .helpers import LoggedFunction
    from .test_pypi import get_test_package_name
    from .test_release import test_commit

    def get_sha(sha):
        return subprocess.check_output(['git', 'rev-parse', sha]).decode('utf-8').strip()

    def get_classifiers_from_pypi(name):
        url = 'https://pypi.python.org/pypi/{}/json'.format(name)
        r = urllib.request.urlopen(url)
        data = json.load(r)
        return data['info']['classifiers']



# Generated at 2022-06-12 06:50:21.434702
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:50:23.875632
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", glob_patterns=["dist/*"])

# Generated at 2022-06-12 06:50:40.516641
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    (None, None)

# Generated at 2022-06-12 06:50:42.163410
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "."
    skip_existing = False
    glob_patterns = ["*"]

    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-12 06:50:42.861361
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:51.990418
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
    except ImportError:
        return
    run_mock = Mock()
    with patch.object(twine.twine, "run", run_mock):
        upload_to_pypi()
    assert run_mock.call_count == 1
    assert run_mock.call_args[0][0] == "twine upload -u '__token__' -p 'pypi-secret' *"

    run_mock = Mock()
    with patch.object(twine.twine, "run", run_mock):
        upload_to_pypi(skip_existing=True)
    assert run_mock.call_count == 1

# Generated at 2022-06-12 06:50:52.623250
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:55.754732
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"
    assert upload_to_pypi.__doc__

# Generated at 2022-06-12 06:51:04.911430
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test getting username and password from the environment
    os.environ["PYPI_USERNAME"] = "testuser"
    os.environ["PYPI_PASSWORD"] = "testpassword"
    try:
        upload_to_pypi()
    finally:
        del os.environ["PYPI_USERNAME"]
        del os.environ["PYPI_PASSWORD"]
    # Test getting an API token from the environment
    os.environ["PYPI_TOKEN"] = "pypi-token"
    try:
        upload_to_pypi()
    finally:
        del os.environ["PYPI_TOKEN"]
    # Test using the .pypirc file
    os.environ["HOME"] = "."

# Generated at 2022-06-12 06:51:06.629108
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"

# Generated at 2022-06-12 06:51:11.203933
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit testing upload_to_pypi.
    """
    upload_to_pypi(path = "test",
                    skip_existing = True,
                    glob_patterns = ["test.txt"])

# Generated at 2022-06-12 06:51:13.462836
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:51:52.971006
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for method upload_to_pypi."""
    # Simulate environment variables
    os.environ['PYPI_USERNAME'] = "test_username"
    os.environ['PYPI_PASSWORD'] = "test_password"
    upload_to_pypi('.')
    del os.environ['PYPI_USERNAME']
    del os.environ['PYPI_PASSWORD']

# Generated at 2022-06-12 06:51:59.100367
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    mock = Mock()
    upload_to_pypi(
        mock,
        path="foo",
        skip_existing=True,
        glob_patterns=["bar"],
    )
    mock.run.assert_called_with(
        "twine upload  -u '__token__' -p 'pypi-super_secret_token' --skip-existing 'foo/bar'"
    )

# Generated at 2022-06-12 06:52:10.736786
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from pathlib import Path

    from invoke import Context
    from invoke.exceptions import Failure

    from .helpers import temp_chdir
    from semantic_release.errors import ImproperConfigurationError as SemanticReleaseImproperConfigurationError

    package_name = "semantic-release-test-package"

    with temp_chdir():
        # create a package
        run(f"python -m pip install setuptools wheel twine")
        run(f"python -m pip install {package_name}==0.0.1")
        run(f"python -m pip install --upgrade {package_name}==0.0.2")

        # test authentication with PYPI_TOKEN
        os.environ.pop("PYPI_PASSWORD", None)
        os.environ.pop("PYPI_USERNAME", None)

# Generated at 2022-06-12 06:52:18.989002
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch('os.environ.get') as mock:
        mock.return_value = 'pypi-token'
        upload_to_pypi()
        assert mock.call_args_list == [call('PYPI_TOKEN')]
    with patch('os.environ.get') as mock:
        mock.return_value = 'pypi-token'
        upload_to_pypi(glob_patterns=['dist/test.pkg'])
        assert mock.call_args_list == [call('PYPI_TOKEN')]
    with patch('os.environ.get') as mock:
        mock.return_value = 'pypi-token'
        upload_to_pypi(skip_existing=True)

# Generated at 2022-06-12 06:52:27.486200
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile

    # Create mock file
    mock_dir_path = tempfile.mkdtemp()
    mock_file_path = os.path.join(mock_dir_path, "mockfile.txt")
    open(mock_file_path, "a").close()

    # Create mock .pypirc file
    mock_pypirc_contents = "[pypi]\nusername = mock_username\npassword = mock_password\n"
    mock_pypirc_path = os.path.join(os.environ.get("HOME", mock_dir_path), ".pypirc")
    

# Generated at 2022-06-12 06:52:38.663845
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class MockRun():
        def __init__(self):
            self.called = False

        def __call__(self, command):
            assert command == "twine upload -u 'mock' -p 'mock' --skip-existing 'dist/*'"
            self.called = True

    mock_run = MockRun()

    def mock_config_repository():
        return "mock"

    token = os.environ.get("PYPI_TOKEN")
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")

    os.environ["PYPI_USERNAME"] = "mock"
    os.environ["PYPI_PASSWORD"] = "mock"


# Generated at 2022-06-12 06:52:39.882136
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True



# Generated at 2022-06-12 06:52:46.249571
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import glob

    path = tempfile.mkdtemp()
    release_file = os.path.join(path, "test-1.0.tar.gz")


# Generated at 2022-06-12 06:52:46.953657
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:52:47.523840
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:54:00.362372
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:54:01.387138
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert run("which twine").returncode == 0

# Generated at 2022-06-12 06:54:04.482163
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert True

# Generated at 2022-06-12 06:54:06.682613
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-12 06:54:07.239980
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:54:18.705247
# Unit test for function upload_to_pypi

# Generated at 2022-06-12 06:54:29.216313
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """It gets credentials from the environment."""
    username = "test_user"
    password = "test_pass"
    token = "test_token"

    # First test with username and password
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"] = password
    upload_to_pypi()
    assert f"twine upload -u '{username}' -p '{password}' 'dist/*'" in run.calls[0]

    # Next test with a token
    run.calls = []
    os.environ["PYPI_TOKEN"] = token
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    upload_to_pypi()


# Generated at 2022-06-12 06:54:31.766567
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import argparse
    args = argparse.Namespace(skip_existing=True)
    assert args.skip_existing == True
    assert upload_to_pypi() == None

# Generated at 2022-06-12 06:54:32.951296
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="tests/fixtures/")

# Generated at 2022-06-12 06:54:33.414208
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:57:15.376134
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    #pylint: disable=protected-access
    from semantic_release import upload_to_pypi as upload_to_pypi_function

    twine_condition = "twine upload "

    os.environ["PYPI_TOKEN"] = "pypi-token"

    upload_to_pypi_function()

    assert twine_condition in upload_to_pypi_function._run.call_args[0][0]

    del os.environ["PYPI_TOKEN"]

    credentials = "-u '__token__' -p 'pypi-token' "

    upload_to_pypi_function()

    assert twine_condition + credentials in upload_to_pypi_function._run.call_args[0][0]


# Generated at 2022-06-12 06:57:16.311556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:57:23.486103
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert "_TOKEN_" not in run("twine upload -u '__token__' -p 'pypi-_TOKEN_' '*'", echo=True, warn=True).stdout
    assert "_TOKEN_" not in run("twine upload -u '__token__' -p 'pypi-_TOKEN_' '*' -r repository", echo=True, warn=True).stdout

# Generated at 2022-06-12 06:57:25.335238
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Function to unit test upload_to_pypi.
    """
    upload_to_pypi()
    print('Upload Tested')

# Generated at 2022-06-12 06:57:28.615736
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp_dir:
        Path(temp_dir).joinpath("foobar.zip").touch()
        upload_to_pypi(temp_dir, False, ["foobar.zip"])

# Generated at 2022-06-12 06:57:30.032457
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-12 06:57:41.674265
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    #pylint: disable=missing-function-docstring
    import tempfile
    import pathlib
    import shutil

    def write_file(path, text):
        with pathlib.Path(path).open("w") as f:
            f.write(text)

    def create_dir(path, files):
        pathlib.Path(path).mkdir(parents=True, exist_ok=True)
        for filename, contents in files.items():
            write_file(path + "/" + filename, contents)

    def glob_asterisk(path):
        return [p.name for p in pathlib.Path(path).iterdir() if p.is_file()]

    def glob_pattern(path, pattern):
        return [p.name for p in pathlib.Path(path).glob(pattern)]

    # TOD

# Generated at 2022-06-12 06:57:46.294250
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    #pylint: disable=protected-access
    #pylint: disable=no-self-use
    class TestUpload:
        """Upload class to test upload_to_pypi."""
        def test_upload(self):
            """Test upload function."""
            upload_to_pypi()

# Generated at 2022-06-12 06:57:47.149427
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()