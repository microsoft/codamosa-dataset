

# Generated at 2022-06-12 06:47:55.484531
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:47:58.514559
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Implemented in tests/unit/upload_to_pypi/test_upload_to_pypi.py
    """
    pass

# Generated at 2022-06-12 06:48:00.459282
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-12 06:48:07.697388
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # 1st setup
    from unittest.mock import patch, Mock
    from semantic_release.hvcs.git import Git
    from invoke.exceptions import UnexpectedExit
    c = Mock()
    c.run = Mock()
    c.exists = Mock()
    c.exists.return_value = True
    with patch("invoke.run", return_value=c), patch("os.path.isfile", return_value=True):
        # test when an API token is provided in the environment
        os.environ["PYPI_TOKEN"] = "pypi-test-token-1"
        upload_to_pypi("")

# Generated at 2022-06-12 06:48:12.608986
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.remove("/tmp/test_upload_to_pypi")
    except FileNotFoundError:
        pass
    os.mkdir("/tmp/test_upload_to_pypi")
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi("/tmp/test_upload_to_pypi", False, ["*"])

# Generated at 2022-06-12 06:48:24.391935
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    skip_existing = False
    glob_patterns = ["*"]

    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")
        if not (username or password) and (
            not home_dir or not os.path.isfile(os.path.join(home_dir, ".pypirc"))
        ):
            raise ImproperConfigurationError(
                "Missing credentials for uploading to PyPI"
            )
    elif not token.startswith("pypi-"):
        raise

# Generated at 2022-06-12 06:48:34.890036
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class ConfigMock(object):
        def __init__(self):
            self.repository = None
    config.config = ConfigMock()
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError as e:
        assert str(e) == "Missing credentials for uploading to PyPI"

    os.environ["PYPI_TOKEN"] = "pypi_token"
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError as e:
        assert str(e) == 'PyPI token should begin with "pypi-"'

    os.environ["PYPI_TOKEN"] = "pypi-token"
    os.environ["HOME"] = "~"
    upload_to_pypi()

# Generated at 2022-06-12 06:48:35.742200
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:36.253831
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:48:43.972924
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    test_settings = {
        "pypi_token": "pypi-mytoken",
        "repository": "test-repo",
        "dist": "dist/*"
    }
    config.update(test_settings)
    assert f'{config["dist"]}/*' == 'dist/*/*'
    assert "pypi-mytoken" in config["pypi_token"]
    upload_to_pypi(path=test_settings["dist"], skip_existing=False, glob_patterns=[f'{config["dist"]}/*'])


test_upload_to_pypi()

# Generated at 2022-06-12 06:48:53.477540
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    PYPI_TOKEN = 'aftership-token'
    os.environ["PYPI_TOKEN"] = PYPI_TOKEN
    test_path = '_test'

    upload_to_pypi(path=test_path, skip_existing=False, glob_patterns=["*"])
    print(f'{PYPI_TOKEN}')
    os.environ["PYPI_TOKEN"] = ''

# Generated at 2022-06-12 06:48:54.116357
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:02.725452
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from mock import patch, Mock

    with patch("invoke.run", Mock()) as run:
        upload_to_pypi("/my/path")
        run.assert_called_once_with(
            "twine upload  \"/my/path/*\"",
        )

    with patch("invoke.run", Mock()) as run:
        upload_to_pypi("/my/path", skip_existing=True, glob_patterns=["*.tar.gz"])
        run.assert_called_once_with(
            "twine upload  --skip-existing \"/my/path/*.tar.gz\"",
        )


# Generated at 2022-06-12 06:49:03.593215
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False == True

# Generated at 2022-06-12 06:49:11.868558
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Upload succeeds with token passed as environment variable.
    os.environ['PYPI_TOKEN'] = 'pypi-abcdefghijklmnopqrstuvwxyz'
    upload_to_pypi()
    del os.environ['PYPI_TOKEN']
    # Upload succeeds with username and password passed as environment variables.
    os.environ['PYPI_USERNAME'] = 'username'
    os.environ['PYPI_PASSWORD'] = 'password'
    upload_to_pypi()
    del os.environ['PYPI_USERNAME']
    del os.environ['PYPI_PASSWORD']
    # Upload succeeds with only a username passed as an environment variable.
    os.environ['PYPI_USERNAME'] = 'username'

# Generated at 2022-06-12 06:49:20.150093
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class Test:
        """
        Class for mocking the function
        """
        def __init__(self):
            self.param = ""

    test_obj = Test()
    test_obj.param = ""

    def run(param):
        test_obj.param = param

    # Test the execution of upload_to_pypi
    upload_to_pypi(path="dist", glob_patterns=[""])
    assert test_obj.param == f'twine upload  -r \'pypi\' "dist/"'

    test_obj.param = ""
    upload_to_pypi(path="dist", skip_existing=True)
    assert test_obj.param == f'twine upload  -r \'pypi\'  --skip-existing "dist/"'

    test_obj.param = ""
    upload_

# Generated at 2022-06-12 06:49:22.330727
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None
    assert upload_to_pypi == None

# Generated at 2022-06-12 06:49:30.225271
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mocked_run
    with mocked_run() as run_mock:
        upload_to_pypi()
    assert run_mock.called is True
    assert len(run_mock.call_args_list) == 1
    assert run_mock.call_args[0][0] == "twine upload *"

    with mocked_run() as run_mock:
        upload_to_pypi(repository = "my-repository")
    assert run_mock.called is True
    assert len(run_mock.call_args_list) == 1
    assert run_mock.call_args[0][0] == "twine upload -r 'my-repository' *"

    with mocked_run() as run_mock:
        upload_to_p

# Generated at 2022-06-12 06:49:30.806928
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:31.491997
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:49:50.086223
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert_message = "assertion message" # This is what the assert will print if it fails.
    log_messages = []

    # Remember the old logger and set a new logger
    old_logger = logger
    logger = type('', (), {})()
    logger.error = lambda x: log_messages.append(x)

    # Prepare the environment variables
    os.environ["HOME"] = "."
    token = "a" * 36
    os.environ["PYPI_TOKEN"] = token
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    os.environ["DISPLAY"] = ""

    # Prepare the .pypirc file

# Generated at 2022-06-12 06:49:54.427151
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(glob_patterns=["a", "b"])
    upload_to_pypi(path="path", skip_existing=True)

# Generated at 2022-06-12 06:49:56.089320
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert "no unit test for function upload_to_pypi"

# Generated at 2022-06-12 06:49:56.737067
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:05.154572
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # make sure it uses the proper variables to upload the files
    os.environ["PYPI_USERNAME"] = "foo"
    os.environ["PYPI_PASSWORD"] = "bar"
    upload_to_pypi("path/to/dist/folder")
    run.assert_called_with("twine upload -u 'foo' -p 'bar' --skip-existing "
                           '"path/to/dist/folder/*"')
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]
    # make sure it skips existing files when the argument is passed
    upload_to_pypi("path/to/dist/folder", skip_existing=True)

# Generated at 2022-06-12 06:50:07.581493
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi does not fail when all required information is provided."""
    upload_to_pypi()

# Generated at 2022-06-12 06:50:08.662262
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass



# Generated at 2022-06-12 06:50:19.520769
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    from .helpers import patch_run
    from .helpers import create_fake_proj

    # Create a fake project and change to the directory
    fake_proj = create_fake_proj(
        """
        encoding = utf8
        import os
        if os.environ.get('TRAVIS_OS_NAME') != 'osx':
            install_requires = ['pytest']
        """
    )

    # Create a distribution
    run('python setup.py sdist bdist_wheel', hide=True, warn=True)

    # Test uploading to test.pypi.org
    with patch_run() as mocked_run:
        os.environ['TWINE_PASSWORD'] = "xxx"

# Generated at 2022-06-12 06:50:20.136536
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:50:31.075560
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    This test uploads a wheel to PYPI (using environment variables
    PYPI_USERNAME, PYPI_PASSWORD and PYPI_REPOSITORY)
    """

    import uuid
    import requests

    package_name = f"semantic-release-test-{uuid.uuid4()}"

    release_info = {
        "version": "0.0.1",
        "next_version": "0.0.1",
        "major": False,
    }

    version_line = f"__version__ = {repr(release_info['version'])}"

    filename = f"{package_name}-{release_info['version']}.tar.gz"


# Generated at 2022-06-12 06:50:59.443506
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_invoke
    from .helpers import mock_which

    call_count = [0]
    def mock_run(self, *args, **kwargs):
        call_count[0] += 1
        if call_count[0] == 1:
            assert "twine upload --skip-existing " in "".join(args)
        else:
            assert "twine upload " in "".join(args)

    with mock_invoke(mock_run):
        with mock_which("twine"):
            upload_to_pypi(skip_existing=True)
            upload_to_pypi()
            assert call_count[0] == 2

# Generated at 2022-06-12 06:51:00.008485
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:01.213925
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    testUpload(upload_to_pypi)


# Generated at 2022-06-12 06:51:08.001337
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    token = 'pypi-abcdefg'
    username = '__token__'
    password = token
    repository = 'some_repo'
    glob_patterns = ['foo', 'bar/baz']

    os.environ['PYPI_TOKEN'] = token

    with patch('os.environ.get') as os_environ_get:
        # Mocking to bypass the check for existing os.environ data
        os_environ_get.side_effect = lambda x: os.environ.get(x)

        with patch('invoke.run') as invoke_run:
            upload_to_pypi(path='/some/path/to/dist',
                           skip_existing=True,
                           glob_patterns=glob_patterns)
            # Check that our command has been run
           

# Generated at 2022-06-12 06:51:08.921273
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("path", False)
    upload_to_pypi("path", skip_existing=False)


# Generated at 2022-06-12 06:51:10.277868
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function
    """

# Generated at 2022-06-12 06:51:18.505980
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test calls to the function when PYPI_TOKEN is defined in the environment
    os.environ["PYPI_TOKEN"] = "pypi-abcd123"
    upload_to_pypi(path="dist")
    # Test calls to the function when PYPI_USERNAME and PYPI_PASSWORD are defined in the environment
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi(path="dist")

    # Test that an error is raised when neither is defined
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""


# Generated at 2022-06-12 06:51:20.531666
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:51:26.177199
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    repo = "pypi-repo"
    token = "pypi-token"
    path = "path/to/dist"
    glob_patterns = ["*.whl"]

    upload_to_pypi_spy = Mock()
    run_spy = Mock()


# Generated at 2022-06-12 06:51:27.317837
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    return upload_to_pypi()

# Generated at 2022-06-12 06:52:03.806734
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:52:13.407214
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mocked_run, mocked_exists, mocked_token
    from mock import patch

    with patch("invoke.run", mocked_run), patch("os.path.exists", mocked_exists), patch(
        "semantic_release.utils.get_token", mocked_token
    ):
        upload_to_pypi()
        assert mocked_run.called
        assert mocked_run.call_args[0] == (
            "twine upload -u '' -p '' --repository-url '' 'dist/*'"
        )

        mocked_run.reset_mock()
        os.environ["PYPI_USERNAME"] = "any_username"
        os.environ["PYPI_PASSWORD"] = "any_password"
        upload_to_pypi()
        assert mocked_

# Generated at 2022-06-12 06:52:20.413314
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "test_upload_to_pypi/"
    os.makedirs(path, exist_ok=True)
    open(path + "some.whl", "a").close()
    open(path + "some.tar.gz", "a").close()
    with open(path + ".pypirc", "a") as f:
        f.write("[pypi]")
        f.write("\n")
        f.write("username = myusername")
        f.write("\n")
        f.write("password = mypassword")
        f.write("\n")
        f.write("repository = myrepo")
        f.write("\n")

    os.environ["PYPI_USERNAME"] = "myusername"

# Generated at 2022-06-12 06:52:23.137852
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "password"
    upload_to_pypi("dist")

# Generated at 2022-06-12 06:52:24.777683
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = "dist", skip_existing = False, glob_patterns = None)

# Generated at 2022-06-12 06:52:33.892677
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypirc_file = "\n[pypi] \nrepository=https://test.pypi.org/legacy/ \nusername=ludwig \npassword="
    with open(os.path.join(os.path.expanduser("~"), ".pypirc"), "w") as f:
       f.write(pypirc_file)
    environment = {
        "HOME": os.path.expanduser("~"),
        "PYPI_TOKEN": "pypi-ludwig",
        "PYPI_USERNAME": "ludwig",
        "PYPI_PASSWORD":"ludwig",
        "PATH": "/usr/bin/:$PATH"
    }

# Generated at 2022-06-12 06:52:35.155436
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:52:36.089682
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:52:36.675911
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    return

# Generated at 2022-06-12 06:52:38.648877
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    A unit test for the `upload_to_pypi` function
    """
    upload_to_pypi(path="dist")

# Generated at 2022-06-12 06:53:56.848980
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from unittest.mock import Mock
    from io import StringIO

    mock = MagicMock()
    mock.return_value.exists = Mock(return_value=True)
    mock.return_value.isdir = Mock(return_value=True)

    with patch("builtins.open", mock):
        f = StringIO()
        with patch("sys.stdout", f):
            glob_patterns = ["*"]
            upload_to_pypi(
                glob_patterns=glob_patterns
            )

# Generated at 2022-06-12 06:54:00.085671
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="wheelhouse",
        skip_existing=True,
        glob_patterns=["*.whl"],
    )

# Generated at 2022-06-12 06:54:01.486057
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-12 06:54:08.336722
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch, Mock

    from . import invoke_mock

    invoke_mock.reset()

    # Assert that credentials from PYPI_TOKEN are used
    invoke_mock.configure_mock(**{"env.get.side_effect": ["pypi-token", None, None]})

    upload_to_pypi("dist", skip_existing=False)

    invoke_mock.run.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
    )

    # Assert that credentials from PYPI_USERNAME and PYPI_PASSWORD are used
    invoke_mock.reset_mock()


# Generated at 2022-06-12 06:54:09.628211
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:54:19.328707
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    dist = "/tmp/dist"
    if not os.path.exists(dist):
        os.makedirs(dist)
    import shutil
    shutil.copyfile(
        "{}/{}".format(os.path.dirname(__file__), "files/testfile.txt"),
        "{}/{}".format(dist, "testfile.txt"),
    )
    token = config["pypi"]["token"]
    assert token
    repository = config["pypi"]["name"]
    username = config["pypi"]["username"]
    password = token
    upload_to_pypi(dist, skip_existing=True, glob_patterns=["testfile.txt"])

# Generated at 2022-06-12 06:54:29.677864
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for token
    token = "pypi-a-token"
    os.environ["PYPI_TOKEN"] = token
    package = "a_pypi_package"
    path = "path_to/"
    glob_patterns = ["*.whl"]
    upload_to_pypi(path=path, glob_patterns=glob_patterns)
    assert f"twine upload -u '__token__' -p '{token}' '{path}{package}'" in run.calls[0]

    # Test for username and password
    os.environ["PYPI_TOKEN"] = ""
    username = "user"
    password = "pass"
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"]

# Generated at 2022-06-12 06:54:30.073590
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False

# Generated at 2022-06-12 06:54:31.253651
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(os.getcwd())

# Generated at 2022-06-12 06:54:43.573588
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch("subprocess.run"):
        glob_patterns = ["**/*.whl"]
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=glob_patterns)
        subprocess.run.assert_called_with(
            'twine upload -u "__token__" -p "pypi-token" --skip-existing "dist/**/*.whl"', 
            shell=True,
            check=True,
        )
        
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=glob_patterns)

# Generated at 2022-06-12 06:57:16.806497
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    This function demonstrates that Semantic-Release will not raise an error if a project is
    using this plugin.
    """
    upload_to_pypi()

# Generated at 2022-06-12 06:57:20.054139
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert(upload_to_pypi("./test/test_repo/dist") == None)

# Generated at 2022-06-12 06:57:29.765534
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = "test"
    password = "test"
    token = "test"
    repository = "test"
    assert upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["*"]
    ) == f"twine upload -u '{username}' -p '{password}' 'dist/*'"
    assert upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["*.*"]
    ) == f"twine upload -u '{username}' -p '{password}' 'dist/*.*'"

# Generated at 2022-06-12 06:57:31.544443
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:57:32.738965
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:57:40.689391
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from invoke import task
    from .helpers import mocked_run

    @task
    def upload():
        upload_to_pypi(glob_patterns=["foo.whl", "bar-baz.whl"])

    with mocked_run(upload) as run_mock, mock_open(read_data=mocked_rc):
        run_mock.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-sometoken' 'dist/foo.whl' 'dist/bar-baz.whl'"
        )



# Generated at 2022-06-12 06:57:48.696536
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from .helpers import run_invoke_task

    def mock_run(cmd: str, *args, **kwargs):
        assert cmd == (
            r"twine upload -u '__token__' -p 'pypi-some_token' 'dist/wheel-*'"
        )

    with patch("invoke.run", side_effect=mock_run):
        # Mock the configuration and env
        config["repository"] = None
        os.environ["PYPI_TOKEN"] = "pypi-some_token"
        run_invoke_task(upload_to_pypi)

# Generated at 2022-06-12 06:57:54.123674
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run_mock(command):
        args = command.split()
        assert args[0] == "twine"
        assert args[1] == "upload"
        assert args[2] == "-u"
        assert args[3] == "__token__"
        assert args[4] == "-p"
        assert len(args[5]) > 31
        assert args[6] == "--skip-existing"
        assert args[7] == '"dist/foo-bar.whl"'
    run.side_effect = run_mock
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["foo-bar.whl"])