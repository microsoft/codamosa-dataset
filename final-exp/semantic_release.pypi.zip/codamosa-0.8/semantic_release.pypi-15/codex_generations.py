

# Generated at 2022-06-12 06:48:03.977216
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    sentinel = object()
    run_sentinel = []

    def run(command, *args, **kwargs):
        run_sentinel.append(command)

    config.repository = "pypi"
    os.environ["PYPI_TOKEN"] = "pypi-token"

    try:
        from .helpers import run
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
    finally:
        del run

    command = run_sentinel[0]
    assert command.startswith("twine upload ")
    assert "-u '__token__'" in command
    assert "-p 'pypi-token'" in command
    assert " --skip-existing" in command
    assert "'dist/*'" in command

# Generated at 2022-06-12 06:48:06.104657
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """simple test"""
    upload_to_pypi()

# Generated at 2022-06-12 06:48:08.904480
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(glob_patterns=[])
    upload_to_pypi(glob_patterns=["test", "test2"])

# Generated at 2022-06-12 06:48:15.931595
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-token-123"
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing, glob_patterns)
    expected = "twine upload -u '__token__' -p 'pypi-token-123' 'dist/*'"
    assert(expected == run.calls[0].args[0])

# Generated at 2022-06-12 06:48:21.723975
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the functionality of upload_to_pypi
    """
    expected_result = "twine upload -u '__token__' -p 'pypi-token' -r 'foo' --skip-existing 'dist/package.tar.gz'"
    result = upload_to_pypi("dist", True, ["package.tar.gz"], repository="foo")
    assert expected_result == result

# Generated at 2022-06-12 06:48:30.751522
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import pytest
    from pathlib import Path
    from contextlib import contextmanager
    from unittest.mock import patch
    from semantic_release import ImproperConfigurationError, settings

    # Set up a mock environment, with a test user token in it
    os.environ["PYPI_TOKEN"] = "pypi-test_token_0"
    os.environ["PYPI_USERNAME"] = "pypi-test_user"
    os.environ["PYPI_PASSWORD"] = "pypi-test_password"
    os.environ["HOME"] = "/home/test_user"

    # Make sure there is no .pypirc in the home directory

# Generated at 2022-06-12 06:48:33.228485
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: write unit test for function upload_to_pypi
    pass

# Generated at 2022-06-12 06:48:33.810702
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:44.027422
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function."""
    # TODO: how to test twine? For now we can just ensure that it gets run with the right arguments
    expected_command = "twine upload -u 'testuser' -p 'testpassword' --skip-existing 'testpackage.tar.gz' 'testsource.tar.gz'"
    class RunMock:
        def __init__(self):
            self.command = ''

        def __call__(self, command):
            self.command = command

    run_mock = RunMock()
    run_mock.command = ''
    upload_to_pypi(path="path", skip_existing=True, glob_patterns=["testpackage.tar.gz", "testsource.tar.gz"], run=run_mock)
    assert run_mock

# Generated at 2022-06-12 06:48:53.682798
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import patch_subprocess

    def mock_subprocess(path, skip_existing=False, glob_patterns=None):
        assert path == "dist"
        assert skip_existing is True
        assert glob_patterns == ['*']
        return True

    patch_subprocess(mock_subprocess, "twine.upload")

    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=['*'])

    def mock_subprocess(path, skip_existing=False, glob_patterns=None):
        assert path == "dist"
        assert skip_existing is False
        assert glob_patterns == ['*.whl', '*.gz']
        return True

    patch_subprocess(mock_subprocess, "twine.upload")

    upload_to_pyp

# Generated at 2022-06-12 06:49:01.413903
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
        res = upload_to_pypi()
        assert res=='twine upload  --skip-existing'

# Generated at 2022-06-12 06:49:08.694634
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    from .helpers import LoggedFunction

    assert upload_to_pypi()
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)
    assert upload_to_pypi(path="dist", skip_existing=True, glob_patterns=None)
    assert upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-12 06:49:09.640655
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config["repository"] = "test_repo"

# Generated at 2022-06-12 06:49:13.405255
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Given a expected value, we invoke the upload_to_pypi
    with enviroment values, and check whether the returned value is equals to
    the expected value.
    """
    assert upload_to_pypi("path") == "twine upload --skip-existing 'path/'"

# Generated at 2022-06-12 06:49:14.177919
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Write unit test
    pass

# Generated at 2022-06-12 06:49:26.173167
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from pathlib import Path
    from pathlib import WindowsPath
    from shutil import rmtree

    class FakeRun:
        def __init__(self, fake_run, side_effect=None):
            self.calls = []
            self.side_effect = side_effect
            if fake_run:
                self.side_effect = fake_run

        def __call__(self, command):
            self.calls.append(command)
            if self.side_effect is not None:
                return self.side_effect(command)


# Generated at 2022-06-12 06:49:26.601604
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:37.317197
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Setup:
    - Given a folder path and
    - A glob pattern
    - When I run the upload_to_pypi() function
    - Then the function should run without error

    Setup:
    - Given a global pattern that doesn't exist in a folder
    - When I run the upload_to_pypi() function
    - Then the function should error

    Setup:
    - Given a folder path and
    - A glob pattern that exists in the folder path
    - When I run the upload_to_pypi() function
    - Then the function should run without error
    """

    test_path = "dist"
    test_glob = "*"
    upload_to_pypi(test_path, glob_patterns=[test_glob])

    test_path = "dist"
    test_glob

# Generated at 2022-06-12 06:49:37.859265
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:40.287111
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:49:49.481773
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Need to mock run() call
    pass

# Generated at 2022-06-12 06:50:01.532548
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .mock_project import create_mock_project

    mock_project = create_mock_project()

# Generated at 2022-06-12 06:50:12.768537
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest import mock
    from .helpers import cached_property
    path = 'dist'
    skip_existing, glob_patterns = True, ['*']
    token = 'pypi-x'
    username = None
    password = None
    dist = '"dist/*"'
    skip_existing_param = " --skip-existing"
    repository = 'test-repo'
    repository_arg = f" -r '{repository}'" if repository else ""
    
    # Mock invoke, create directory and run function
    invoker = mock.MagicMock()

# Generated at 2022-06-12 06:50:13.345869
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:50:15.480765
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=['*-py3-none-any.whl'])

# Generated at 2022-06-12 06:50:17.332719
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-12 06:50:18.569002
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == "twine upload "

# Generated at 2022-06-12 06:50:19.424120
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:29.162265
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.environ['PYPI_USERNAME'] = 'test_username'
        os.environ['PYPI_PASSWORD'] = 'test_password'
        upload_to_pypi('dist', False)
        os.environ.pop('PYPI_USERNAME')
        os.environ.pop('PYPI_PASSWORD')
    except ImproperConfigurationError:
        print('ImproperConfigurationError')
    try:
        os.environ['PYPI_TOKEN'] = 'test_token'
        upload_to_pypi('dist', False)
    except ImproperConfigurationError:
        print('ImproperConfigurationError')


# Generated at 2022-06-12 06:50:36.550737
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    from unittest.mock import patch
    from .helpers import LoggedFunctionDecorator
    from semantic_release import ImproperConfigurationError

    with patch("invoke.run"):
        with LoggedFunctionDecorator(logger) as mock:
            upload_to_pypi(glob_patterns=["*glob*", "*glob2*"])
            assert mock.info_mock.call_count == 1
            assert mock.info_mock.call_args[0][0] == "uploading packages to PyPI."
            assert mock.info_mock.call_args[0][1] == dict()

# Generated at 2022-06-12 06:50:54.323495
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:55.016607
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:04.482810
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from pathlib import Path
    import shutil
    import tempfile
    import unittest
    from unittest import mock

    from semantic_release.settings import config

    config.setup()

    # All PyPI providers must accept the same parameters
    # so we don't need to test each one

    class PyPI(unittest.TestCase):
        def test_provider_exists(self):
            assert "pypi" in config.plugins["upload"].keys()

        def test_requires_token(self):
            # No token specified
            del os.environ["PYPI_TOKEN"]
            with self.assertRaises(ImproperConfigurationError):
                upload_to_pypi()


# Generated at 2022-06-12 06:51:05.089809
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:51:05.706510
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:07.563416
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()



# Generated at 2022-06-12 06:51:09.660012
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:51:11.311617
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

# Generated at 2022-06-12 06:51:19.128032
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi = __import__('semantic_release.hvcs.pypi.upload_to_pypi').upload_to_pypi
    run = __import__('semantic_release.hvcs.pypi.upload_to_pypi')\
        .__dict__['run']
    assert upload_to_pypi.__name__ == 'upload_to_pypi'
    assert upload_to_pypi.__doc__ == __doc__
    assert upload_to_pypi.__annotations__ == {
        'path': str,
        'skip_existing': bool,
        'glob_patterns': List[str]
    }

# Generated at 2022-06-12 06:51:30.977202
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Fail when missing credentials
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    with open(os.devnull, "w") as devnull:
        assert run("python upload_to_pypi.py", out_stream=devnull)

    # Success
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    with open(os.devnull, "w") as devnull:
        assert run("python upload_to_pypi.py", out_stream=devnull)

    test_upload_to_pypi.__name__ = "x"
    test_upload_to_pypi.__doc__ = "x"

# Generated at 2022-06-12 06:52:05.798862
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:52:14.732701
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that the correct arguments are sent to the proper twine methods
    """
    # set environment variables
    os.environ["PYPI_TOKEN"] = "123456"
    os.environ["HOME"] = "/"
    def mock_run(command):
        msg = "Unrecognized command"
        if command == f"twine upload -u '__token__' -p '123456' --skip-existing 'dist/file0' 'dist/file1'":
            msg = "Files will be uploaded"
        elif command == f"twine upload -u '__token__' -p '123456' --skip-existing 'dist/file2' 'dist/file3'":
            msg = "Files will be uploaded from repository"

# Generated at 2022-06-12 06:52:19.344311
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config.load()
    config.set("repository", "test-repository")
    upload_to_pypi()
    assert (
        config.get("repository") == "test-repository"
    ), "The Twine command should have the correct repository."
    config.set("repository", None)
    upload_to_pypi()
    assert (
        config.get("repository") is None
    ), "The Twine command should not have a repository when no repository is defined."

# Generated at 2022-06-12 06:52:19.860649
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:52:20.528922
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass


# Generated at 2022-06-12 06:52:30.036418
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="path", skip_existing=True, glob_patterns=["glob"])
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi(path="path", skip_existing=True, glob_patterns=["glob"])
    os.environ["PYPI_TOKEN"] = "token"
    try:
        upload_to_pypi(path="path", skip_existing=True, glob_patterns=["glob"])
        assert False
    except:
        assert True
    os.environ.pop("PYPI_TOKEN")
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"


# Generated at 2022-06-12 06:52:41.017809
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from typing import Any, Dict
    import mock
    import os
    import pytest

    from semantic_release.settings import config

    # Setting environment variables
    os.environ['PYPI_TOKEN'] = 'some_token'

    # Mocking run
    with mock.patch('semantic_release.hvcs.helpers.run') as mocked_run:
        # Try passing empty path
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi(path='')
        # Try passing path which is not a directory
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi(path='some_path')

        # Mocking dist directory
        dist_dir_path = 'some_dist_directory'
        mocked_dist_dir = mock.MagicM

# Generated at 2022-06-12 06:52:41.824749
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:52:49.998599
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import glob
    import sys
    import os

    # Create test files we'll upload to PyPI
    tempdir = tempfile.mkdtemp()
    testfiles = [
        open(os.path.join(tempdir, 'testfile.tar.gz'), 'w'),
        open(os.path.join(tempdir, 'testfile1.tar.gz'), 'w'),
    ]

    for testfile in testfiles:
        testfile.close()

    sys.argv = ['semantic-release', '--prepare']
    config['repository'] = 'pypi'
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"


# Generated at 2022-06-12 06:52:59.480513
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = True
    glob_patterns = ["*"]
    # Attempt to get an API token from environment
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")
        if not (username or password) and (
            not home_dir or not os.path.isfile(os.path.join(home_dir, ".pypirc"))
        ):
            raise ImproperConfigurationError(
                "Missing credentials for uploading to PyPI"
            )


# Generated at 2022-06-12 06:54:12.618245
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"

# Generated at 2022-06-12 06:54:14.660410
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:54:19.218198
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import WorkingDirectory, environment_variable

    test_path = "test/dist"
    test_globs = ["*.whl", "*.gz"]

    with WorkingDirectory("test/repo"), environment_variable(
        "PYPI_TOKEN", "pypi-token"
    ):
        upload_to_pypi(test_path, glob_patterns=test_globs)

# Generated at 2022-06-12 06:54:29.602909
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import unittest

    class TestUploadToPyPi(unittest.TestCase):
        # pylint: disable=no-self-use
        def test_works_with_token(self):
            run = MockRun()
            upload_to_pypi(run=run, glob_patterns=["some_file"])
            expected_command = "twine upload -u __token__ -p pypi-some_token --skip-existing \"dist/some_file\""
            self.assertEqual(run.command, expected_command)

        def test_works_with_username_password(self):
            run = MockRun()

# Generated at 2022-06-12 06:54:30.809398
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:54:31.622834
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:54:32.768708
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=['*'])

# Generated at 2022-06-12 06:54:45.154369
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import uuid, tempfile
    from shutil import rmtree

    def _create_temp_dir(dirname=None):
        # based on tempfile.mkdtemp, with added support for dirname
        prefix = (dirname + '-' if dirname else '') + 'tmp'
        name = tempfile.mktemp(prefix=prefix, suffix='')
        os.mkdir(name)
        return name

    def _create_temp_file(contents=b"hello world", dirname=None):
        temp_file = tempfile.NamedTemporaryFile(delete=False, dir=dirname)
        temp_file.write(contents)
        temp_file.close()  # close before returning name
        return temp_file.name

    temp_dir = _create_temp_dir()
    temp_file1

# Generated at 2022-06-12 06:54:54.225239
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"
    assert upload_to_pypi.__doc__ == """Upload wheels to PyPI with Twine.

Wheels must already be created and stored at the given path.

Credentials are taken from either the environment variable
``PYPI_TOKEN``, or from ``PYPI_USERNAME`` and ``PYPI_PASSWORD``.

:param path: Path to dist folder containing the files to upload.
:param skip_existing: Continue uploading files if one already exists.
    (Only valid when uploading to PyPI. Other implementations may not support this.)
:param glob_patterns: List of glob patterns to include in the upload (["*"] by default).
"""

# Generated at 2022-06-12 06:54:55.255665
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:57:43.261373
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Prepare
    from tempfile import mkdtemp
    from shutil import rmtree
    from semantic_release.settings import config

    # Fake `twine`
    from unittest.mock import patch
    from invoke.runners import Result

    def mockreturn(*args, **kwargs):
        return Result(None, 0, "", "")

    with patch("invoke.run", new=mockreturn):

        # Prepare a sample directory to upload
        tempdir = mkdtemp()
        f = open(f"{tempdir}/blah.tar.gz", "w")
        f.close()

        # No token or username and password

# Generated at 2022-06-12 06:57:44.250092
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()