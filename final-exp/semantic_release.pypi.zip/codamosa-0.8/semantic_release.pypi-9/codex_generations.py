

# Generated at 2022-06-12 06:47:53.451894
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    pass

# Generated at 2022-06-12 06:48:04.754086
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os, mock

    mock_run = mock.Mock()
    mock_run.return_value = None
    original_run = os.environ.get("PYPI_TOKEN")

# Generated at 2022-06-12 06:48:12.949035
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile

    # Create temp files for testing
    with tempfile.TemporaryDirectory() as tempdir:
        files = {"test-file"}
        for file in files:
            with open(f"{tempdir}/{file}", "w+") as f:
                pass

        # Test that the correct command is added for uploading files
        username = "test-user"
        password = "test-pass"
        os.environ["PYPI_USERNAME"] = username
        os.environ["PYPI_PASSWORD"] = password

        cmd_upload = f"twine upload -u '{username}' -p '{password}' \"{tempdir}/*\""

        assert upload_to_pypi(tempdir) == cmd_upload

        # Test that the correct command is added for uploading files to a specific

# Generated at 2022-06-12 06:48:15.418841
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # This is just a smoke test, but it's still useful.
    upload_to_pypi()

# Generated at 2022-06-12 06:48:24.259937
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Test for missing user credentials
    try:
        upload_to_pypi()
    except KeyError:
        pass

    # Test for proper upload without token
    try:
        upload_to_pypi(glob_patterns=["*"])
    except KeyError:
        pass

    # Test for proper upload with token
    try:
        os.environ["PYPI_TOKEN"] = "pypi-test-token"
        upload_to_pypi(glob_patterns=["*"])
    except KeyError:
        pass

    del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-12 06:48:30.966481
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create fake module
    import tempfile
    from .helpers import create_file

    path = tempfile.mkdtemp()
    package_name = 'fake_module'
    create_file(path, f"{package_name}-0.0.1-py3-none-any.whl")

    # Create fake PyPI config with token

# Generated at 2022-06-12 06:48:32.446717
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:48:33.496606
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:48:37.177181
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Ensure that we can upload a file that already exists
    os.environ["PYPI_TOKEN"] = "pypi-TOKEN"
    upload_to_pypi(path="tests/test_data/my_package.dist", skip_existing=True)



# Generated at 2022-06-12 06:48:39.292957
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:48:46.642971
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    1) Assumes .pypirc file to be present
    """
    upload_to_pypi(path = "./", glob_patterns = ["*"])

# Generated at 2022-06-12 06:48:54.631927
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from tempfile import TemporaryDirectory
    from importlib import resources
    from shutil import which
    from pathlib import Path

    path = TemporaryDirectory()
    test_files = [
        "test-package-0.0.0-py2.py3-none-any.whl",
        "test-package-0.0.0.tar.gz",
    ]

    os.chdir(path.name)

    with resources.path("semantic_release", "tests") as test_dir:
        for file in test_files:
            file_path = os.path.join(test_dir, file)
            with open(file, "wb") as f:
                with open(file_path, "rb") as file_to_read:
                    f.write(file_to_read.read())


# Generated at 2022-06-12 06:49:02.983974
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run = MockRun()
    upload_to_pypi("./dist", skip_existing=True, glob_patterns=["*", "a[c-e]*"], run=run)
    assert run.command == "twine upload  --skip-existing './dist/*' './dist/a[c-e]*'"

    run = MockRun()
    upload_to_pypi("./dist", skip_existing=False, glob_patterns=["*", "a[c-e]*"], run=run)
    assert run.command == "twine upload  './dist/*' './dist/a[c-e]*'"

    run = MockRun()

# Generated at 2022-06-12 06:49:04.129496
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:04.802412
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False, "TODO"

# Generated at 2022-06-12 06:49:05.990117
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for the upload_to_pypi function."""

# Generated at 2022-06-12 06:49:07.564887
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi('dist/',skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-12 06:49:16.833930
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with mock.patch.dict(os.environ, {"HOME": "foo"}):
        with mock.patch.dict(os.environ, {"PYPI_USERNAME": "foo", "PYPI_PASSWORD": "bar"}):
            # Test environment variables username/password
            with mock.patch("semantic_release.hooks.pypi.run") as run_patch:
                upload_to_pypi("path")
                run_patch.assert_called_once_with(
                    "twine upload -u 'foo' -p 'bar' -r '' 'path/*'"
                )
        # Test configuration token

# Generated at 2022-06-12 06:49:18.362375
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:19.905672
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi == upload_to_pypi

# Generated at 2022-06-12 06:49:34.926733
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from ._temp_dir import _temp_dir

    with _temp_dir() as temp_dir:
        with open(f"{temp_dir}/.pypirc", "w") as pypirc:
            pypirc.write("[pypi]\n")
        with open(f"{temp_dir}/test_package.txt", "w") as test_package:
            test_package.write("test package")
        upload_to_pypi(path=temp_dir, skip_existing=True)

# Generated at 2022-06-12 06:49:43.121403
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch, mock_open
    from io import TextIOWrapper
    from tempfile import mkdtemp
    from os import path, remove, environ

    from semantic_release import ImproperConfigurationError

    from .helpers import LoggedFunction
    from .helpers import getLogger

    # Constants
    sample_pypi_username = "TheUsername"
    sample_pypi_password = "ThePassword"
    sample_pypi_token = "pypi-TheToken"
    sample_pypi_repository = "TheRepository"

    # Tested function

# Generated at 2022-06-12 06:49:52.533954
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test upload
    repository = "test"
    glob_patterns = ["*.whl"]
    path = os.path.join(os.path.dirname(__file__), "test_data", "dist")
    username = "test_user"
    password = "test_password"
    token = "test_token"
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"] = password
    upload_to_pypi(path, False, glob_patterns)
    os.environ["PYPI_TOKEN"] = token
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]
    upload_to_pypi(path, True, glob_patterns)
   

# Generated at 2022-06-12 06:49:54.921908
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config["repository"] = "pypi"
    upload_to_pypi("dist")

# Generated at 2022-06-12 06:49:55.464017
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:00.623620
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Mock the functions
    run_mock = Mock(return_value=None)

    with patch("invoke.run", new=run_mock):
        upload_to_pypi(skip_existing=True)

        assert run_mock.call_args[0][0] == "twine upload --skip-existing 'dist/*'"

# Generated at 2022-06-12 06:50:02.587630
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:13.524162
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = "pypi-token"
    username = "username"
    password = "password"
    path = "path"
    repository = "repository"
    glob_patterns = ["*", "p*"]
    skip_existing = True

    os.environ["HOME"] = "/testing"

    # Test with token
    os.environ["PYPI_TOKEN"] = token
    upload_to_pypi(path, skip_existing, glob_patterns)
    command = run.call_args[0][0]
    assert "twine upload -u '__token__' -p 'pypi-token'" in command
    assert '"{}/{}"'.format(path, "*") in command

    # Test without token (use .pypirc)

# Generated at 2022-06-12 06:50:23.764128
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # As this function will delete the dist folder and all its contents,
    # it makes sense to use a temporary directory with mock files
    import shutil
    import tempfile
    import os
    import glob

    # Mock files are in the same directory as this file is located
    CUR_DIR = os.path.dirname(os.path.realpath(__file__))

    # Create a temporary directory, and copy the mock files there
    with tempfile.TemporaryDirectory() as tmpdir:
        # Make a folder named 'dist' within the temporary directory
        os.makedirs(os.path.join(tmpdir, "dist"), exist_ok=True)

        # Within the dist folder, copy over all the files from the current directory,
        # excluding the file named .keep (which is a placeholder file to force git to
        # keep the directory,

# Generated at 2022-06-12 06:50:33.534402
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Arrange
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, "file.tar.gz")
    with open(temp_file, "w+") as fp:
        fp.write("")
    os.environ["PYPI_TOKEN"] = "pypi-token"

    # Act
    import subprocess
    import sys

    proc = subprocess.Popen(
        [sys.executable, "-m", "invoke", "upload_to_pypi", "-p", temp_dir],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    # Assert

# Generated at 2022-06-12 06:50:49.124576
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert None

# Generated at 2022-06-12 06:51:01.615148
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    print('start unit test for function upload_to_pypi')
    ## 配置参数
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")

# Generated at 2022-06-12 06:51:02.482572
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:03.084600
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    return

# Generated at 2022-06-12 06:51:14.628367
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class DummyEnviron:
        def __init__(self):
            self.environ = {}

        def get(self, key, default=None):
            return self.environ.get(key, default)

    os.environ = DummyEnviron()
    os.environ.environ["HOME"] = "/home/test"

    assert os.path.isfile(os.path.join(os.environ.get("HOME"), ".pypirc"))

    # no credentials at all
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        pass

    # token
    os.environ.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()

    # username and password
    del os.environ

# Generated at 2022-06-12 06:51:15.606186
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:51:27.317954
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock

    mocked_run = "semantic_release.upload_helpers.twine.run"
    with mock.patch(mocked_run) as run_mock:
        upload_to_pypi(
            path="dist",
            skip_existing=False,
            glob_patterns=["spam*", "eggs"],
        )

        assert run_mock.call_count == 1
        assert run_mock.call_args == mock.call(
            r"twine upload -u 'spam' -p 'ham' --repository-url 'https://test.pypi.org/legacy/' '\"dist/spam*\"' '\"dist/eggs\"'"
        )
        run_mock.reset_mock()

        upload_to_pypi

# Generated at 2022-06-12 06:51:28.207094
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:51:38.077241
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import TempDirectory
    from .helpers import write_file
    from .helpers import MockRun
    import pytest
    from semantic_release.hvcs import get_remote_url
    from semantic_release.settings import build_config

    # Set up a mocked run function
    run.run = MockRun()

    # Create a temporary dist folder with a file, and patch its path in os.environ
    with TempDirectory() as d:
        os.environ['DIST_PATH'] = d.name
        pkg_version = "1.0.1"
        write_file(f"{d.name}/{pkg_version}.whl")

        # Write to .pypirc in the home dir
        write_file(f"{d.name}/.pypirc")

        # Set up mocked config


# Generated at 2022-06-12 06:51:39.610495
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:52:20.027764
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .mock_invoke import MockContext
    from .mock_invoke import MockConfig

    config.set_config(MockConfig({"repository": "test-repository"}))

    ctx = MockContext()

    ctx.run = lambda x: None

    upload_to_pypi(ctx)

    ctx.run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-ny8yFLcKjMfBwv1JwnC2QZAd9N7lHjzvhV' -r 'test-repository' 'dist/*'"
    )

    config.set_config(MockConfig({}))

    ctx.run = lambda x: None

    upload_to_pypi(ctx)


# Generated at 2022-06-12 06:52:22.257345
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert os.system("python -m semantic_release._internal.uploaders.upload_to_pypi") == 0



# Generated at 2022-06-12 06:52:24.096765
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function.
    """
    assert upload_to_pypi() == "Twine upload to PyPI"

# Generated at 2022-06-12 06:52:33.414986
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    import shutil
    import tempfile
    import os

    from semantic_release.settings import config

    config["repository"] = None
    old_home = os.environ.get("HOME", "")
    os.environ["HOME"] = "/tmp/"

    pypi_token = os.environ.get("PYPI_TOKEN")
    os.environ["PYPI_TOKEN"] = "pypi-token"

    tempdir1 = tempfile.mkdtemp()
    print("Created temporary directory", tempdir1)

    tempdir2 = tempfile.mkdtemp()
    print("Created temporary directory", tempdir2)


# Generated at 2022-06-12 06:52:34.958505
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True, glob_patterns="*")

# Generated at 2022-06-12 06:52:36.411081
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:52:38.049561
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:52:42.322042
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert run("twine", warn=True, hide=True).failed
    upload_to_pypi(
        path="tests/fixtures/twine",
        skip_existing=True,
        glob_patterns=["example-1.0.0-py2.py3-none-any.whl"]
    )
    assert run("twine --version").ok

# Generated at 2022-06-12 06:52:44.956525
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # For now just make sure this doesn't crash with some setup
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

if __name__ == "__main__":
    __test__ = False
    test_upload_to_pypi()

# Generated at 2022-06-12 06:52:45.804406
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:53:59.810778
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import random
    import string
    import pathlib
    import subprocess
    import pkg_resources

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = pathlib.Path(temp_dir)
        dist_dir = temp_dir / "dist"
        dist_dir.mkdir()

        # Create a random python package
        package_name = "".join(
            random.choice(string.ascii_lowercase) for _ in range(20)
        )
        version = "".join(random.choice(string.digits) for _ in range(2))
        pkg_dir = temp_dir / package_name
        pkg_dir.mkdir()
        setup_file = pkg_dir / "setup.py"

# Generated at 2022-06-12 06:54:07.679569
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil

    temp_folder = tempfile.mkdtemp(prefix="semantic_release")

# Generated at 2022-06-12 06:54:09.681136
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", glob_patterns=["*"])

# Generated at 2022-06-12 06:54:19.802545
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import subprocess
    import tempfile

    # Generate files for unit test
    _, dist_dir = tempfile.mkstemp()
    subprocess.run(["mkdir", "-p", dist_dir])
    subprocess.run(
        ["python3", "-m", "locust.distutils.command.upload", "fake", "-d", dist_dir]
    )
    assert os.path.isdir(dist_dir)

    token = os.getenv("PYPI_TOKEN")
    username = os.getenv("PYPI_USERNAME")
    password = os.getenv("PYPI_PASSWORD")

    if username and password:
        # Upload with username/password
        os.environ["PYPI_TOKEN"] = ""
        upload_to_pypi(dist_dir)

# Generated at 2022-06-12 06:54:27.782561
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=unused-argument
    def mock_run(command):
        assert command == 'twine upload -u \'__token__\' -p \'pypi-XXXXX\' "dist/*"'
        return ''

    old_run = run
    run = mock_run
    os.environ["PYPI_TOKEN"] = "pypi-XXXXX"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]
    run = old_run

# Generated at 2022-06-12 06:54:30.852461
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"]) == None

# Generated at 2022-06-12 06:54:32.915426
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Confirm that it fails when credentials aren't in environment
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-12 06:54:33.381265
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:54:34.268847
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:54:36.077782
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-12 06:57:01.473560
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert isinstance(e, ImproperConfigurationError)
    except Exception as e:
        assert e.__class__ != Exception

    upload_to_pypi("dist", False, ["*"])

# Generated at 2022-06-12 06:57:03.196019
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", False, ["foo"])

# Generated at 2022-06-12 06:57:09.826170
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # User has provided a PyPI token, should work
    os.environ["PYPI_TOKEN"] = "pypi-123456789abcdefghijklmnop"
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        assert False

    # User has not provided a PyPI token, should fail
    del os.environ["PYPI_TOKEN"]
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        pass

    # User has provided both username and password, should work
    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "pass"

# Generated at 2022-06-12 06:57:10.422272
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1

# Generated at 2022-06-12 06:57:12.890998
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
    except ModuleNotFoundError:
        pytest.skip("Twine is required to run this test")
    upload_to_pypi()

# Generated at 2022-06-12 06:57:16.136437
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="path", skip_existing=True, glob_patterns=["hello_world", "test"])
    assert True

# Generated at 2022-06-12 06:57:20.154410
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    assert upload_to_pypi(path="test/test-data/test-package/dist",skip_existing=False, glob_patterns=["*"]) == None

# Generated at 2022-06-12 06:57:29.898000
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from pathlib import Path

    repo_name = "semantic_release-test"
    dist_dir = Path(tempfile.mkdtemp() / repo_name)
    dist_dir.mkdir()
    (dist_dir / "semantic_release-test-0.0.1-py3-none-any.whl").touch()
    (dist_dir / "semantic_release-test-0.0.1.tar.gz").touch()

    config.set(
        "repository",
        "file://"
        + str(Path(tempfile.mkdtemp() / "repo").resolve())
        + f"/simple/{repo_name}",
    )
    os.environ["PYPI_USERNAME"] = "__token__"
    os.environ

# Generated at 2022-06-12 06:57:37.625418
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import get_cleanup_parameters, temp_chdir
    from .helpers import touch

    with get_cleanup_parameters(["dist", "dist/file.whl"]) as params:
        os.makedirs(params["dist"])
        touch(params["file.whl"])

        temp_dir = params["temp_dir"]

        with temp_chdir(temp_dir):
            upload_to_pypi()



# Generated at 2022-06-12 06:57:38.672165
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO
    pass