

# Generated at 2022-06-12 06:47:54.842444
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:47:55.892585
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:48:05.812641
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create mock env variable for token
    os.environ["PYPI_TOKEN"] = "pypi-sampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletokensampletoken"

    # Create a mock dist folder and file
    import tempfile
    import pathlib
    dist_folder = tempfile.TemporaryDirectory()
    path = pathlib.Path(dist_folder.name, "filename")

# Generated at 2022-06-12 06:48:13.450821
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import reset_env_variables_to_original_state, get_env_variables, set_env_variables

    original_pypi_token = os.environ.get("PYPI_TOKEN")
    original_pypi_username = os.environ.get("PYPI_USERNAME")
    original_pypi_password = os.environ.get("PYPI_PASSWORD")
    original_repository = config.get("repository")

    # Clean any existing env variables
    reset_env_variables_to_original_state()

    # Test case 1:
    # ! Repository arg (-r) not tested here
    # ! Invalid env variables not tested here
    # ! Invalid glob_patterns not tested here

# Generated at 2022-06-12 06:48:15.037910
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    pass

# Generated at 2022-06-12 06:48:20.234556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="./dist", glob_patterns=["*"]) is None
    assert upload_to_pypi(path="./dist", glob_patterns=["*"]) is None
    assert upload_to_pypi(path="./dist", glob_patterns=["*"]) is None

# Generated at 2022-06-12 06:48:22.312948
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=False)
    upload_to_pypi("dist", skip_existing=True)

# Generated at 2022-06-12 06:48:24.566034
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Should we unit test for this?
    pass

# Generated at 2022-06-12 06:48:31.122029
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from semantic_release.settings import config
    from tempfile import mkdtemp
    from distutils.dir_util import copy_tree

    # Create a temporary directory for fake wheels
    tempdir = mkdtemp()

    # Create a fake wheels directory
    assetdir = os.path.join(tempdir, "assets")
    os.mkdir(assetdir)
    copy_tree(os.path.join(os.path.dirname(__file__), "assets"), assetdir)

    # Set the environment variables for PyPI credentials
    os.environ["PYPI_TOKEN"] = "pypi-exampleToken"

    # Test upload by setting the path to the wheels directory that was created

# Generated at 2022-06-12 06:48:42.884155
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import (
        create_archive,
        create_source_distribution_archive,
        create_wheel_archive,
        delete_directory,
        delete_file,
    )

    import shutil
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from semantic_release.settings import config, load_configuration

    from semantic_release.hvcs import pypi

    # Create some temporary directories
    with TemporaryDirectory() as td:
        source_dir = Path(td) / "source"
        source_dir.mkdir()
        build_dir = Path(td) / "source" / "dist"
        build_dir.mkdir()
        twine_dir = Path(td) / "twine"
        twine_dir.mkdir()
        old_cwd = os.getc

# Generated at 2022-06-12 06:48:50.182221
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(path='dist', skip_existing=True, glob_patterns=['*'])

# Generated at 2022-06-12 06:49:01.226526
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    with patch("invoke.run") as mocked_run:
        mocked_run.return_value = None
        upload_to_pypi(skip_existing=True)

        mocked_run.assert_called_once_with(
            "twine upload  --skip-existing 'dist/*'"
        )

        mocked_run.reset_mock()

        upload_to_pypi(skip_existing=True, glob_patterns=["*.txt", "*.html"])

        mocked_run.assert_called_once_with(
            "twine upload  --skip-existing 'dist/*.txt' 'dist/*.html'"
        )


    with patch("invoke.run") as mocked_run:
        mocked_run.return_value = None
        upload_to_pypi

# Generated at 2022-06-12 06:49:10.083914
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = "__token__"
    password = "pypi-asdf"
    repository = "pypi"
    dist = '"dist/dist/*.whl"'

    skip_existing = False
    skip_existing_param = " --skip-existing" if skip_existing else ""

    username_password = f"-u '{username}' -p '{password}'"
    repository_arg = f" -r '{repository}'"
    arg = "twine upload {} {} {} {}".format(username_password, repository_arg, skip_existing_param, dist)
    run.assert_called_once_with(arg)

# Generated at 2022-06-12 06:49:18.796588
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Check that only the main function is executed.
    """
    import semantic_release.hvcs.git  # need to mock the git class

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch


# Generated at 2022-06-12 06:49:28.629644
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile
    from invoke import UnexpectedExit, run as run_invoke

    def _run_invoke(command):
        try:
            run_invoke(command)
        except UnexpectedExit as e:
            # If twine returns a non-zero exit code, it is because there was insufficient permissions
            if e.result.exited != 1:
                raise e

    def _clean_dist():
        shutil.rmtree(os.path.join(tempdir, "dist"), ignore_errors=True)

    tempdir = tempfile.mkdtemp()
    _clean_dist()
    os.makedirs(os.path.join(tempdir, "dist"))
    os.makedirs(os.path.join(tempdir, "dist", "other"))
    os.makedirs

# Generated at 2022-06-12 06:49:29.372840
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:30.055468
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:31.709485
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi

# Generated at 2022-06-12 06:49:33.263360
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass
    # TODO

# Generated at 2022-06-12 06:49:34.240389
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:43.790652
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi is not None

# Generated at 2022-06-12 06:49:44.646534
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:49:45.716757
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:47.005519
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:54.112819
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Purpose of this test is to test the code logic of upload_to_pypi
    # This test does not test the actual upload or any other logic or
    # invocation of `run()`

    # Check username and password set
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    args = {"skip_existing": False, "glob_patterns": None}
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Check token set
    os.environ["PYPI_TOKEN"] = "pypi-test_token"
    upload_to_pypi()
    del os

# Generated at 2022-06-12 06:50:03.850567
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # test case 1, normal case
    upload_to_pypi()

    # test case 2, custom glob patterns
    upload_to_pypi(glob_patterns=[])

    # test case 3, not using environment variable
    token = os.environ.get("PYPI_TOKEN")
    os.environ["PYPI_TOKEN"] = ""
    upload_to_pypi()
    os.environ["PYPI_TOKEN"] = token

    # test case 4, use default environment variable instead
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")
    os.environ["PYPI_USERNAME"] = "test_username"

# Generated at 2022-06-12 06:50:10.184982
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    upload_to_pypi(path="my_path", skip_existing=True, glob_patterns=["pattern1", "pattern2"])
    assert run.call_args[1]['command'] == "twine upload -u '__token__' -p 'pypi-token' --skip-existing \"my_path/pattern1\" \"my_path/pattern2\""

# Generated at 2022-06-12 06:50:12.325051
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="sample_dist", glob_patterns=["*.whl", "*.tar.gz"])

# Generated at 2022-06-12 06:50:22.635260
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Define test variables
    path = "dist"
    skip_existing = False
    glob_patterns = {'*.zip','*.whl'}
    # Define test function
    def test_run(command):
        print("Fake run function.")
        return True
    # Test with API token
    glob_patterns_joined = " ".join(
        ['"{}/{}"'.format(path, glob_pattern.strip()) for glob_pattern in glob_patterns]
    )
    token = "pypi-***"
    os.environ["PYPI_TOKEN"] = token
    run = test_run
    upload_to_pypi()
    os.environ["PYPI_TOKEN"] = ""
    del os.environ["PYPI_TOKEN"]
    # Test with username

# Generated at 2022-06-12 06:50:24.323430
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("test")

# Generated at 2022-06-12 06:50:45.038747
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Calls upload_to_pypi using test values
    """
    upload_to_pypi(path=".", skip_existing=True, glob_patterns=["*"])
    return

# Generated at 2022-06-12 06:50:45.708206
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:46.793360
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:47.282984
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:47.738825
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:59.779808
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class MockRun:
        def __init__(self, args):
            self.args = args
            self.called = False

        def __call__(self, args):
            if self.called:
                return
            self.called = True
            assert self.args == args

    logger.debug = MockRun("DEBUG")
    logger.info = MockRun("INFO")
    logger.error = MockRun("ERROR")
    logger.warning = MockRun("WARNING")
    logger.critical = MockRun("CRITICAL")

    import tempfile
    import json
    import shutil
    from textwrap import dedent

    # Prepare config

# Generated at 2022-06-12 06:51:11.620558
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import sys

    # Ensure that we don't actually hit PyPI, by mocking out run
    def mocked_run(command):
        print(command)
        return command

    sys.modules["invoke"].run = mocked_run

    # Ensure that we don't actually hit PyPI, by mocking out run
    dist_dir = "./dist"
    testfile = os.path.join(dist_dir, "test.txt")
    if not os.path.exists(dist_dir):
        os.makedirs(dist_dir)
    with open(testfile, "w") as f:
        f.write("test")

    # If it fails, then this will raise an exception
    upload_to_pypi(path=dist_dir)

    # Clean up

# Generated at 2022-06-12 06:51:14.502934
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi(
            path="dist", skip_existing=True, glob_patterns=["*"]
        )
    except:
        return False
    return True

# Generated at 2022-06-12 06:51:16.331946
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert "A valid token should be accepted"
    upload_to_pypi(glob_patterns=["a_pattern"])

# Generated at 2022-06-12 06:51:17.673361
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:51:51.045109
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:51:53.105100
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    return upload_to_pypi()


if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-12 06:51:59.779013
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    os.mkdir(temp_dir.name+"/dist")

    with open(temp_dir.name+"/dist/test_1.1.0.tar.gz", "w"):
        pass

    upload_to_pypi(temp_dir.name+"/dist", glob_patterns=["test_*"])

    temp_dir.cleanup()

# Generated at 2022-06-12 06:52:08.503850
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi with a PYPI_TOKEN environment variable
    """

    # Set environment variable for PyPI API key
    os.environ["PYPI_TOKEN"] = "pypi-XXXXXXXXXXXXXXXXXXXXXXXXXX"

    # Test run with upload_to_pypi function
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

    # Remove environment variable for PyPI API key
    del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-12 06:52:09.023425
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:52:09.494006
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:52:18.292336
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest

    # Adding constants to test different scenarios
    # Credentials with invalid pypi token
    pypi_token = "pypi-invalid-token"
    pypi_username = None
    pypi_password = None

    pypi_token = "pypi-my-token-123"
    pypi_username = None
    pypi_password = None

    pypi_token = None
    pypi_username = "my-username"
    pypi_password = "my-password"

    repository = "pypi"

    # path to dist
    path = "path/to/dist"

    # Add missing credentials
    with pytest.raises(ImproperConfigurationError) as exc:
        os.environ["PYPI_TOKEN"] = pyp

# Generated at 2022-06-12 06:52:23.666330
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    try:
        upload_to_pypi(None, None, None)
    except ImproperConfigurationError as e:
        assert "Missing credentials for uploading to PyPI" in str(e)

# Generated at 2022-06-12 06:52:25.252858
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for the function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-12 06:52:27.102722
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:53:45.323208
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", False)
    upload_to_pypi("tests/fixtures/fixture_dist")  # without glob_pattern
    upload_to_pypi("tests/fixtures/fixture_dist", glob_patterns=["*"])
    upload_to_pypi("tests/fixtures/fixture_dist", glob_patterns=["*-*"])


"""Helper for using Twine to upload to TestPyPI.
"""
import logging
import os
from typing import List

from invoke import run

from semantic_release import ImproperConfigurationError
from semantic_release.settings import config

from .helpers import LoggedFunction

logger = logging.getLogger(__name__)



# Generated at 2022-06-12 06:53:53.906039
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from mock import patch, Mock
    from invoke.exceptions import Failure
    from semantic_release.plugins import upload_to_pypi_plugin
    from semantic_release.errors import UploadToPyPIError

    mock = Mock()
    with patch('invoke.run', mock) as mock:
        upload_to_pypi_plugin.upload_to_pypi()

        assert mock.call_count == 1
        mock.assert_called_with('twine upload "" "dist/*"')

    mock = Mock()
    with patch('invoke.run', mock) as mock:
        upload_to_pypi_plugin.upload_to_pypi('/path', False, ['foo-bar'])

        assert mock.call_count == 1

# Generated at 2022-06-12 06:53:55.011714
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(dist_path, True)

# Generated at 2022-06-12 06:53:55.483372
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:53:59.900949
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    upload_to_pypi()

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-12 06:54:02.684993
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

test_upload_to_pypi()

# Generated at 2022-06-12 06:54:04.973967
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False 
    glob_patterns = None
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-12 06:54:11.646247
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # A complete dictionary to test the function
    test_dict = {
        "path": "dist",
        "glob_patterns": ["*.whl", "*.tar.gz"],
        "skip_existing": False,
    }
    run(f"twine upload --repository testpypi -u __token__ -p pypi-{test_dict['path']} {test_dict['path']}")

# Generated at 2022-06-12 06:54:14.416363
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

#
# if __name__ == "__main__":
#     test_upload_to_pypi()

# Generated at 2022-06-12 06:54:21.146294
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Arrange
    from tempfile import TemporaryDirectory
    from .helpers import FileCreator 
    from .helpers import MockObject
    from semantic_release import settings
    import shutil
    import os
    import glob

    # Create temporary folder
    with TemporaryDirectory() as path:

        # Create config file
        os.environ["HOME"] = path
        with open(f"{path}/.pypirc", "w") as pypi_f:
            pypi_f.write("")

        # Create mock env object
        os.environ["PYPI_USERNAME"] = "test_username"
        os.environ["PYPI_PASSWORD"] = "test_password"
        os.environ["PYPI_TOKEN"] = "pypi-token"

# Generated at 2022-06-12 06:56:51.521775
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import LoggedFunction

    upload_to_pypi.logger = LoggedFunction.logger = logging.getLogger(__name__)

    try:
        upload_to_pypi()
    except Exception:
        assert False, "Test should not fail in test_upload_to_pypi"
    else:
        assert True, "Test should succeed in test_upload_to_pypi"

# Generated at 2022-06-12 06:56:52.654677
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:56:54.981447
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:56:55.910205
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 == 1
    assert True == True

# Generated at 2022-06-12 06:57:02.509178
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    from unittest.mock import patch

    with patch("invoke.run") as mock:
        upload_to_pypi("dist", True)
        assert mock.call_args[0][0] == "twine upload --skip-existing 'dist/*'"

    with patch("invoke.run") as mock:
        upload_to_pypi("dist", True, ["*.whl", "*.tar.gz"])
        assert mock.call_args[0][0] == 'twine upload --skip-existing "dist/*.whl" "dist/*.tar.gz"'

    with patch("invoke.run") as mock:
        upload_to_pypi("dist", False, ["*.whl", "*.tar.gz"])

# Generated at 2022-06-12 06:57:03.680697
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    sys.exit(1)

# Generated at 2022-06-12 06:57:08.163039
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist")
    upload_to_pypi("dist", True)
    upload_to_pypi("dist", skip_existing=True)
    upload_to_pypi("dist", True, ['*.egg-info', '*.whl'])
    upload_to_pypi("dist", skip_existing=True, glob_patterns=['*.egg-info', '*.whl'])

# Generated at 2022-06-12 06:57:11.676690
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path = os.environ.get("TEST_DIST_PATH", "dist"),
        skip_existing = True,
        glob_patterns = ["*"]
    )

# Generated at 2022-06-12 06:57:13.749197
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for Twine uploader"""
    upload_to_pypi()

# Generated at 2022-06-12 06:57:14.538308
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()