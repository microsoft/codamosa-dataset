

# Generated at 2022-06-12 06:48:02.125781
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "test_path"
    skip_existing = True
    glob_patterns = ["Glob1", "Glob2"]
    expected_glob_patterns = "Glob1/Glob1 Glob2/Glob2"

    upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)

    call = run.call_args[0][0]

    assert f"twine upload --skip-existing {expected_glob_patterns}" in call

# Generated at 2022-06-12 06:48:08.263442
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from tempfile import TemporaryDirectory
    from invoke import MockContext
    from contextlib import contextmanager
    from os import environ
    from pathlib import Path

    @contextmanager
    def mock_pypi_login(username, password):
        environ['PYPI_USERNAME'] = username
        environ['PYPI_PASSWORD'] = password
        yield
        environ.pop('PYPI_USERNAME')
        environ.pop('PYPI_PASSWORD')

    # When the user has a PYPI_TOKEN in environment, then it should use it
    with mock_pypi_login(None, None), TemporaryDirectory() as path:
        # First, check that the PYPI_TOKEN is taken into account
        token = 'pypi-github_token'

# Generated at 2022-06-12 06:48:09.436784
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:09.927146
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:21.375476
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi
    """
    from .helpers import mock_environment, mock_run
    from .mock_run import MockRun

    for upl in [True, False]:
        for skip in [True, False]:
            for repo in ["repo", None]:
                for pat in [["*"], ["*", "*.egg-info"]]:
                    mock_run.reset()
                    mock_environment({"PYPI_TOKEN": "pypi-xyz"})

# Generated at 2022-06-12 06:48:29.559687
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from mock import MagicMock
    from semantic_release.uploaders.pypi import upload_to_pypi
    fake_config = MagicMock()
    fake_config.get.return_value = "pypi-FAKE_TOKEN"
    fake_config.__getitem__.side_effect = lambda key : lambda : fake_config.get(key)
    pypi_token = "pypi-FAKE_TOKEN"
    run = MagicMock()
    with config(fake_config):
        upload_to_pypi("", False)

# Generated at 2022-06-12 06:48:42.874437
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest

    test_path = "tests/test_files"
    test_pkg = "test-pkg"
    test_dist_path = f"{test_path}/{test_pkg}/dist"
    glob_patterns = ["*"]
    test_files = ["test-pkg-1.0.0-py3-none-any.whl"]

    # Create test files
    for test_file in test_files:
        tf = open(f"{test_dist_path}/{test_file}", "w+")
        tf.close()

    # Calling the function _correctly_ should not raise any errors
    upload_to_pypi(
        path=test_dist_path, skip_existing=False, glob_patterns=glob_patterns
    )

    # Calling the function with

# Generated at 2022-06-12 06:48:53.511962
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    file_name = "test-file"
    create_test_file(file_name)
    run("python -m pip install twine")

    # Create a twine configuration file with username and password
    config_file_name = ".pypirc"
    config_file = "[distutils]\nindex-servers =\n  pypi\n[pypi]\nrepository: https://test.pypi.org/legacy/\nusername: __token__\npassword: test-pypi-token"
    create_test_file(config_file_name, data=config_file)

    # Test with invalid token
    test_token = "invalid-test-pypi-token"

# Generated at 2022-06-12 06:48:55.977577
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("foo", True)
    upload_to_pypi("bar", False)

# Generated at 2022-06-12 06:48:57.016901
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    upload_to_pypi()

# Generated at 2022-06-12 06:49:26.939183
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    from mock import patch

    with patch("invoke.run") as mock_run:
        upload_to_pypi()
        mock_run.assert_called_once_with(
            "twine upload -u 'test_username' -p 'test_password' 'dist/*'"
        )

    with patch("invoke.run") as mock_run:
        upload_to_pypi(path="dist", glob_patterns=["*"], skip_existing=True)
        mock_run.assert_called_once_with(
            "twine upload -u 'test_username' -p 'test_password' --skip-existing 'dist/*'"
        )



# Generated at 2022-06-12 06:49:27.395358
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False

# Generated at 2022-06-12 06:49:28.164890
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:39.492133
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # test presence of important keywords in upload command
    token = "my-token"
    repository = "my-repo"
    _token = os.environ.get("PYPI_TOKEN")
    _repository = config.get("repository", None)
    os.environ["PYPI_TOKEN"] = token
    upload_to_pypi(glob_patterns=["*", "*/*"])
    assert f' -u "__token__" --skip-existing "{token}"' in LoggedFunction.get_last_command()
    assert f' -r "{repository}"' in LoggedFunction.get_last_command()
    LoggedFunction.reset()
    upload_to_pypi(glob_patterns=["*"])
    assert ' --skip-existing "*"' in LoggedFunction

# Generated at 2022-06-12 06:49:40.088310
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:42.692157
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["my-package-1.2.3-*"]
    )

# Generated at 2022-06-12 06:49:52.281242
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import sys
    import shutil


# Generated at 2022-06-12 06:49:54.134633
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:56.196698
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path=None, skip_existing=None, glob_patterns=None)

# Generated at 2022-06-12 06:50:03.719453
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        file_name = "test.txt"
        with open(os.path.join(temp_dir, file_name), "wt") as f:
            f.write("test")

        os.environ["PYPI_USERNAME"] = "username"
        os.environ["PYPI_PASSWORD"] = "password"
        upload_to_pypi(temp_dir, glob_patterns=[file_name])
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-12 06:50:14.237723
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for GitLab
    upload_to_pypi('/Users/rishabhkhandelwal/Desktop/test-repo-9/dist/')

# Generated at 2022-06-12 06:50:15.966303
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    assert upload_to_pypi

# Generated at 2022-06-12 06:50:17.289122
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:50:26.608721
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test ``upload_to_pypi``"""
    path = 'dist'
    skip_existing = False
    glob_patterns = {
        '*'
    }
    upload_to_pypi(
        path, skip_existing, glob_patterns
    )
    upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)
    upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)
    upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)

# Generated at 2022-06-12 06:50:27.673099
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:35.883832
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    assert mock_run(upload_to_pypi, glob_patterns=["*"]) == "twine upload \"*\""

    assert mock_run(upload_to_pypi, path="dist", glob_patterns=["*"]) == "twine upload \"dist/*\""

    assert mock_run(upload_to_pypi, glob_patterns=["*", "**/*"]) == "twine upload \"*\" \"**/*\""

    assert mock_run(upload_to_pypi, path="dist", skip_existing=True, glob_patterns=["*"]) == "twine upload  --skip-existing \"dist/*\""


# Generated at 2022-06-12 06:50:36.786096
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:50:37.780152
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:38.707570
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:49.048571
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi
    """
    config["repository"] = "test_repository"
    config["dry_run"] = True
    
    run = config.get("run")
    def mock_run(command, pty=False): 
        assert command == "twine upload -u '__token__' -p 'pypi-token' -r 'test_repository' 'dist/*'"
    config["run"] = mock_run
    
    upload_to_pypi(glob_patterns=["*"], path="dist", skip_existing=False)
    
    config["run"] = run

# Generated at 2022-06-12 06:51:15.061065
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(*args, **kwargs):
        return

    with mock.patch('invoke.run', mock_run):
        os.environ['PYPI_TOKEN'] = 'pypi-token'
        upload_to_pypi()

        os.environ['PYPI_TOKEN'] = 'token'
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

        del os.environ['PYPI_TOKEN']
        os.environ['PYPI_USERNAME'] = 'user'
        os.environ['PYPI_PASSWORD'] = 'password'
        upload_to_pypi()

# Generated at 2022-06-12 06:51:18.928793
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with mock.patch("invoke.run") as mock_run:
        upload_to_pypi()
    mock_run.assert_called_once_with(
        "twine upload  '.'/'*'"
    )

# Generated at 2022-06-12 06:51:19.965012
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True
    return None

# Generated at 2022-06-12 06:51:20.862733
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:21.544583
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:33.348309
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    from invoke import Context

    from .helpers import temp_chdir, create_temp_config

    class TempContext(Context):
        pass

    def temp_run(command, *args, **kwargs):
        return TempContext().run(command, *args, **kwargs)

    # Setup
    temp_path = "temp"
    os.mkdir(temp_path)
    package = "tests/fixture/package"
    files = ["dist/example_pkg-1.0-py3-none-any.whl", "README.rst"]
    for file in files:
        shutil.copy(os.path.join(package, file), os.path.join(temp_path, file))


# Generated at 2022-06-12 06:51:40.237801
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-12345"
    upload_to_pypi()
    # Test without username and password or token
    if "PYPI_USERNAME" in os.environ:
        del os.environ["PYPI_USERNAME"]
    if "PYPI_PASSWORD" in os.environ:
        del os.environ["PYPI_PASSWORD"]
    del os.environ["PYPI_TOKEN"]
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

# Generated at 2022-06-12 06:51:42.521411
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True, ["*.whl", "*.tar.gz"])

# Generated at 2022-06-12 06:51:47.889406
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Validate the behavior of the upload_to_pypi function,
    including whether all 3 types of credentials are accepted and
    otherwise handling the exceptions appropriately
    """
    import copy
    import pytest

    mock_environ = copy.deepcopy(os.environ)
    mock_environ["HOME"] = "/home/test_user"

    # Test that a valid token is accepted
    with pytest.raises(invoke.Exit):
        with mock.patch.dict(
            os.environ,
            {"HOME": "/home/test_user", "PYPI_TOKEN": "pypi-abcdefghijklmnopqrstuvwxyz"},
        ):
            upload_to_pypi()

    # Test that an invalid token is rejected

# Generated at 2022-06-12 06:51:52.482231
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mocked_run, mocked_config

    with mocked_run():
        with mocked_config():
            upload_to_pypi(glob_patterns=["*"])
            run.assert_called_once_with(
                "twine upload  -u '__token__' -p 'pypi-mytoken'   'dist/*'"
            )



# Generated at 2022-06-12 06:52:28.052291
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False

# Generated at 2022-06-12 06:52:30.981151
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test no glob pattern provided
    upload_to_pypi(glob_patterns=None)
    upload_to_pypi(glob_patterns=[])

# Generated at 2022-06-12 06:52:41.581006
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
        from unittest.mock import patch
        import requests
    except (ImportError, ModuleNotFoundError):
        return

    os.environ['PYPI_USERNAME'] = 'username'
    os.environ['PYPI_PASSWORD'] = 'password'

    logger = logging.getLogger(__name__)
    def check_upload_with_username_password(logger):
        upload_to_pypi(path="test/test_pypi", glob_patterns=["*py", "!*test*.py"])
        post_requests = []
        def mock_put(url, auth=None, files=[], headers={}, **kwargs):
            post_requests.append("twine")
            mock_response = requests.Response()
            mock_

# Generated at 2022-06-12 06:52:48.680005
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    dist = "dist"
    patterns = ["*.exe", "*.whl"]
    settings = {"repository": "test-repo"}
    os.environ["HOME"] = os.path.curdir
    token = "pypi-abcdefghijklmnopqrstuvwxyz1234567890"
    os.environ["PYPI_TOKEN"] = token
    
    with config(**settings):
        upload_to_pypi(dist, True, patterns)
    
    del os.environ["HOME"]
    del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-12 06:52:52.918039
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path='dist', skip_existing=True, glob_patterns=['*']
    )
    upload_to_pypi(path='dist')
    upload_to_pypi(path='dist', skipexisting=True)

# Generated at 2022-06-12 06:52:55.943077
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["dist/*"])

# Generated at 2022-06-12 06:53:02.917280
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # GIVEN a path, repo and user/pass
    path = "dist"
    repo = 'test-repo'
    username = 'TestUser'
    password = 'TestPassword'

    # WHEN uploading the package to pypi
    upload_to_pypi(
        path,
        False,
        glob_patterns=["*"],
        skip_existing=False,
    )

    # THEN ensure the command is constructed correctly
    assert 'dist/* --repository test-repo' == f'{path}/*'

# Generated at 2022-06-12 06:53:09.176956
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for upload_to_pypi function.
    """
    from .helpers import PathChoice
    from .helpers import PathFiles
    from .helpers import PathFolder
    from .helpers import remove_dir

    path = "build/test"

    path_choice = PathChoice(path)

    path_folder = PathFolder(path_choice)

    path_files = PathFiles(path_choice)

    path_folder.create()

    path_files.delete_files()

    path_files.create_files()

    upload_to_pypi()

    assert path_files.exist_files()

    path_files.delete_files()

    remove_dir(path)

# Generated at 2022-06-12 06:53:19.066290
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # PREPARE: Test environment
    # Set up the .pypirc file
    token = "pypi-abcd"

# Generated at 2022-06-12 06:53:22.050847
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi

    """
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-12 06:54:34.709659
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-12 06:54:38.345902
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that we can upload to PyPI with Twine.
    """
    upload_to_pypi("test/test_package")

# Generated at 2022-06-12 06:54:44.496536
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert "twine upload " == upload_to_pypi()
    os.environ["HOME"] = ""
    assert upload_to_pypi().startswith(
        "twine upload -u '__token__' -p 'pypi-sdfsdfsdfsdfsdfsdfsdfsdfsdfsdf' "
    )

# Generated at 2022-06-12 06:54:49.108685
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi('dist', skip_existing=True, glob_patterns=['*']) == True
    assert upload_to_pypi('dist', skip_existing=False, glob_patterns=['*']) == True

# Generated at 2022-06-12 06:54:56.152603
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from tests.utils import MockContext, MockRun

    c = MockContext()
    c.run = MockRun()

    dir_path = os.path.dirname(os.path.realpath(__file__))

    # Attempt to get an API token from environment
    upload_to_pypi(os.path.join(dir_path, "..", "..", "dist"))
    c.run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-3d5ff5a5-5a07-466f-8a75-2a675c0d30a0' "
        f'"{dir_path}/../../dist/*"'
    )

    c.run.reset()

# Generated at 2022-06-12 06:54:56.783494
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:54:57.475664
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:54:59.490299
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-12 06:55:01.602583
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", glob_patterns=["*"])


# Generated at 2022-06-12 06:55:03.622488
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:57:48.210207
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Setup
    
    # Expected
    expected_result = [
        "Attempt to upload package to PyPI using Twine.",
        "Uploaded:",
        "semantic_release-1.1.0-py3-none-any.whl (Size: 9.5kB)",
        "semantic_release-1.1.0.tar.gz (Size: 17.1kB)",
    ]

    # Actual
    actual_result = upload_to_pypi()

    # Result
    assert actual_result == expected_result
    assert type(actual_result) == type(expected_result)