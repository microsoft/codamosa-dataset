

# Generated at 2022-06-12 06:47:57.323431
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    # Call function that is being tested
    upload_to_pypi()

# Generated at 2022-06-12 06:47:58.320445
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True)

# Generated at 2022-06-12 06:48:03.744391
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    t = "test"
    os.environ["PYPI_USERNAME"] = t
    os.environ["PYPI_PASSWORD"] = "{}_password".format(t)
    os.environ["HOME"] = t
    open(os.path.join(t,".pypirc"), "w+")
    upload_to_pypi()
    assert(True)

# Generated at 2022-06-12 06:48:12.698096
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test upload_to_pypi with all type of valid inputs, no exception should be raised.
    assert upload_to_pypi(glob_patterns=["*"]) is None
    assert upload_to_pypi() is None
    assert upload_to_pypi(skip_existing=True) is None
    assert upload_to_pypi(glob_patterns=["*"], skip_existing=True) is None

    # Test if exception is raised when token env var not set.
    os.environ["PYPI_TOKEN"] = ""
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    # Test if exception is raised when token does not begin with pypi.
    os.environ["PYPI_TOKEN"] = "test"
   

# Generated at 2022-06-12 06:48:14.061599
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:16.543203
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
  try:
    upload_to_pypi()
  except Exception as e:
    assert type(e) is ImproperConfigurationError, "ImproperConfigurationError is not being thrown"

# Generated at 2022-06-12 06:48:28.038563
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from shutil import rmtree
    from pathlib import Path
    from semantic_release.settings import config
    
    def create_file(path, content = 'a'):
        with open(path, 'w') as f:
            f.write(content)
    
    with tempfile.TemporaryDirectory() as path:
        path = Path(path)
        (path/'file1.tar.gz').touch()
        (path/'file2.tar.gz').touch()
        (path/'file3.tar.gz').touch()
        os.environ['PYPI_USERNAME'] = 'username'
        os.environ['PYPI_PASSWORD'] = 'password'
        config['repository'] = 'repository'

# Generated at 2022-06-12 06:48:28.632463
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:37.066241
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-mytoken"
    upload_to_pypi(path="tests/unit/test_files", skip_existing=True)

    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "foo"
    os.environ["PYPI_PASSWORD"] = "bar"
    upload_to_pypi(path="tests/unit/test_files", skip_existing=True)
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

# Generated at 2022-06-12 06:48:45.680290
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run, patch_os_environ, patch_config

    with patch_os_environ({"PYPI_TOKEN": "pypi-token-value"}):
        with mock_run() as mock_subprocess:
            with patch_config({"repository": "repo-url"}):
                upload_to_pypi()

    mock_subprocess.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-token-value' -r 'repo-url' 'dist/'"
    )


# Generated at 2022-06-12 06:48:59.874054
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from . import context_manager, make_invoke_task
    task = make_invoke_task(upload_to_pypi)
    with context_manager(task, "environment") as c:
        c.configure_mock(**{"run.return_value": None})
        task.delay(path="another/path", skip_existing=True, glob_patterns=["*.txt", "*.zip"])
        c.run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-12345' --skip-existing 'another/path/*.txt' 'another/path/*.zip'"
        )

# Generated at 2022-06-12 06:49:10.884868
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import pytest
    import tempfile

    username = "my_username"
    password = "my_password"
    repo = "my_repo"
    token = "pypi-1234"

    with tempfile.TemporaryDirectory() as twine_folder:
        os.environ["PYPI_USERNAME"] = username
        os.environ["PYPI_PASSWORD"] = password
        os.environ["PYPI_TOKEN"] = token
        os.environ["HOME"] = twine_folder

        with pytest.raises(ImproperConfigurationError) as error:
            upload_to_pypi(path=twine_folder)
        assert str(error.value) == "Missing credentials for uploading to PyPI"


# Generated at 2022-06-12 06:49:17.065573
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    
    import os
    import shutil
    import pytest

    try:
        os.mkdir("test_dist")
        file = open("test_dist/test_file.whl" , "w")
        file.close()
        os.environ["PYPI_TOKEN"] = "pypi-token"

        upload_to_pypi()
    except pytest.raises(ImproperConfigurationError):
        pass
    else:
        raise ImproperConfigurationError
    finally:
        shutil.rmtree("test_dist")

# Generated at 2022-06-12 06:49:27.822083
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    # Test with a single file
    upload_to_pypi(glob_patterns=["file1"])
    assert run.calls == [
        f"twine upload -u 'username' -p 'password' 'dist/file1'"
    ]
    # Test with multiple files
    upload_to_pypi(glob_patterns=["file1", "file2"])

# Generated at 2022-06-12 06:49:39.087003
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    
    # Upload a new wheel to PyPI
    os.environ['PYPI_USERNAME'] = "test-username"
    os.environ['PYPI_PASSWORD'] = "test-password"
    
    # Invalid PyPI token
    try:
        os.environ['PYPI_TOKEN'] = "1"
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    
    # Invalid username and password
    os.environ['PYPI_TOKEN'] = "pypi-1"
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    
    # Invalid repository
    os.environ['PYPI_USERNAME'] = "test-username"

# Generated at 2022-06-12 06:49:40.085485
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Call function
    upload_to_pypi()

# Generated at 2022-06-12 06:49:42.296124
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Testing upload_to_pypi function.
    """
    upload_to_pypi("dist", False, ["*"])

# Generated at 2022-06-12 06:49:44.353663
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test_dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:49:53.012591
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Valid credentials with repository
    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "password"
    os.environ["PYPI_TOKEN"] = "pypi-123456789"
    os.environ["PYPI_REPOSITORY"] = "pypi"
    upload_to_pypi()
    assert "twine upload -u 'user' -p 'password' -r 'pypi' 'dist/*'" in LoggedFunction.log

    # Token only with repository
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]
    del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-12 06:50:03.221956
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    repo = "test-repo"
    token = "test-token"
    username = "test-username"
    password = "test-password"
    path = "test-dist"

    class MockRun:
        def __init__(self):
            self.called = False

        def __call__(self, cmd):
            self.called = True
            assert cmd.startswith("twine upload")

            assert not cmd.endswith(f"'{repo}'")
            assert f" -r '{repo}'" in cmd

            assert not cmd.startswith(f" -u '{username}'")
            assert not cmd.startswith(f" -p '{password}'")
            assert not cmd.endswith(f" -u '{username}'")
            assert not cmd.endsw

# Generated at 2022-06-12 06:50:13.522481
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test case for upload_to_pypi.
    """
    upload_to_pypi(path="dist", skip_existing=False)

# Generated at 2022-06-12 06:50:14.520589
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:50:24.554856
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from unittest import mock

    from semantic_release.plugins.pypi_publish import upload_to_pypi

    # Create a directory to put the test packages in, and remove it after
    base_dir = mkdtemp()
    rmtree_later = lambda: rmtree(Path(base_dir))
    rmtree_later()
    os.mkdir(base_dir)


# Generated at 2022-06-12 06:50:27.761790
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        error_msg = 'Missing credentials for uploading to PyPI'
        assert e.args[0] == error_msg

# Generated at 2022-06-12 06:50:35.899721
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from .helpers import MockFunction
    from .test_clients.test_pypi import mock_pypi_version_call

    mock_version_call_response = {
        "info": {"version": "5.5.5"},
        "releases": {"5.5.5": [{"url": "/foo.tar.gz"}, {"url": "/foo.zip"}]},
    }

    mock_version_call = MockFunction(mock_pypi_version_call, mock_version_call_response)
    upload_to_pypi.run()
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi.run("/foo", False)

# Generated at 2022-06-12 06:50:36.786796
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:49.099694
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch.object(invoke.run, "run") as mocked_run:
        upload_to_pypi()
        mocked_run.assert_called_with("twine upload --skip-existing 'dist/*'")

        mocked_run.reset_mock()
        upload_to_pypi(skip_existing=True)
        mocked_run.assert_called_with("twine upload --skip-existing 'dist/*'")

        mocked_run.reset_mock()
        upload_to_pypi(glob_patterns=["*", ".*"])
        mocked_run.assert_called_with("twine upload --skip-existing 'dist/*' 'dist/.*'")

        mocked_run.reset_mock()

# Generated at 2022-06-12 06:50:52.509337
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if os.environ.get('TRAVIS_REPO_SLUG') is not None:
        upload_to_pypi()

# Generated at 2022-06-12 06:51:03.272597
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for token mode, which should be the norm
    pypi_token = "abc123"
    os.environ["PYPI_TOKEN"] = pypi_token

    if "PYPI_USERNAME" in os.environ:
        del os.environ["PYPI_USERNAME"]
    if "PYPI_PASSWORD" in os.environ:
        del os.environ["PYPI_PASSWORD"]

    # Perform the upload
    upload_to_pypi()

    # Now test no token, wrong home folder
    del os.environ["PYPI_TOKEN"]
    os.environ["HOME"] = "."

    # Perform the upload
    upload_to_pypi()

    # Now test no token, correct home folder

# Generated at 2022-06-12 06:51:03.902350
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:22.201868
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-12 06:51:33.919711
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi"""
    # pylint: disable=import-outside-toplevel

# Generated at 2022-06-12 06:51:41.850574
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import contextlib
    from unittest.mock import patch

    from tests.helpers import assert_logs

    @contextlib.contextmanager
    def mock_run(task):
        # Returning None indicates that the task should be allowed to run
        yield None

    with patch("invoke.run", side_effect=mock_run, create=True):
        with assert_logs() as logs:
            upload_to_pypi()

        assert 1 == len(logs)
        assert "Uploading distribution files to PyPI" == logs[0]

    with patch("invoke.run", side_effect=mock_run, create=True):
        with assert_logs(capture_warnings=False) as logs:
            upload_to_pypi(skip_existing=True)

        assert 2 == len(logs)

# Generated at 2022-06-12 06:51:50.729895
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_upload
    from .helpers import mock_os_env
    from .helpers import mock_run
    from .helpers import assert_run_called_with

    # Test using an API token
    token = "pypi-r3m0t3ly-r3411y-54f3"
    with mock_os_env(PYPI_TOKEN=token):
        with mock_run():
            with mock_upload(token):
                upload_to_pypi(
                    path="dummy_path", skip_existing=True, glob_patterns=["*.whl"]
                )

                assert_run_called_with(
                    f"twine upload -u '__token__' -p '{token}' --skip-existing 'dummy_path/*.whl'"
                )

# Generated at 2022-06-12 06:51:52.445492
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.uploaders import upload_to_pypi
    assert upload_to_pypi() == None

# Generated at 2022-06-12 06:51:53.371668
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    pass

# Generated at 2022-06-12 06:52:01.747941
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    with patch('os.environ.get', return_value=None):
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

    with patch('os.environ.get', side_effect=['pypi-token']):
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

    with patch('os.environ.get') as env_get:
        env_get.side_effect = ['pypi-token', None, None]
        with patch('invoke.run') as run:
            upload_to_pypi()
            run.assert_called_once_with("twine upload -u '__token__' -p 'pypi-token'  'dist/*'")


# Generated at 2022-06-12 06:52:12.713180
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch, Mock

    from .helpers import patch_chdir

    m = Mock()
    with patch("semantic_release.hvcs.twine.logger.info") as info:
        with patch("invoke", m):
            with patch_chdir("tests/repos/twine"):
                upload_to_pypi(path="dist", skip_existing=True)

    assert info.call_count == 1
    assert m.run.call_count == 1
    assert "twine upload " in str(m.run.call_args)
    assert "example.whl" in str(m.run.call_args)
    assert "--skip-existing" in str(m.run.call_args)



# Generated at 2022-06-12 06:52:20.053160
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test pypi token upload
    os.environ["PYPI_TOKEN"] = "pypi-supersecret"

    def fake_run(command):
        assert "twine upload " in command
        assert " --skip-existing" not in command

        assert " -u '__token__' -p 'pypi-supersecret'" in command
        assert " -r 'repo'" not in command

        assert "dist/semantic_release*" in command

    upload_to_pypi(glob_patterns=["semantic_release*"])

    del os.environ["PYPI_TOKEN"]

    # Test pypi username and password upload
    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "password"

# Generated at 2022-06-12 06:52:21.444640
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi
    """
    pass

# Generated at 2022-06-12 06:52:56.363713
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=['test*'])

# Generated at 2022-06-12 06:53:04.906193
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from .helpers import replace_config, replace_environ

    with replace_config({}), replace_environ(
        {
            "PYPI_TOKEN": "pypi-token",
            "HOME": "/home/user",
            "PYPI_REPO": "pypi",
        }
    ):
        with patch("invoke.run") as run_mock:
            upload_to_pypi()
            run_mock.assert_called_once_with(
                "twine upload -u '__token__' -p 'pypi-token' -r 'pypi' "
                '"dist/*"'
            )

# Generated at 2022-06-12 06:53:16.984303
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function with both token and username/password credentials
    """
    # Test with an API token
    os.environ["PYPI_TOKEN"] = "pypi-12345"
    assert "pypi-" in upload_to_pypi.__signature__.parameters["username"].default
    assert "__token__" in upload_to_pypi.__signature__.parameters["username"].default
    assert "12345" in upload_to_pypi.__signature__.parameters["password"].default

    # Test with a username/password combination
    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "pypi-username"

# Generated at 2022-06-12 06:53:19.529881
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    assert upload_to_pypi()

# Generated at 2022-06-12 06:53:20.504505
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert not upload_to_pypi()

# Generated at 2022-06-12 06:53:21.615291
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:53:24.376121
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(path='path', skip_existing=True, glob_patterns=['*', '*.txt'])

# Generated at 2022-06-12 06:53:24.957084
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:53:34.002630
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch(
        "os.environ", {"PYPI_USERNAME": "myusername", "PYPI_PASSWORD": "mypassword"}
    ):
        upload_to_pypi(
            path="dist",
            skip_existing=False,
            glob_patterns = ["*.whl"],
        )

with patch(
    "os.environ", {"PYPI_USERNAME": "myusername", "PYPI_PASSWORD": "mypassword"}
):
    upload_to_pypi(
        path="dist",
        skip_existing=False,
        glob_patterns = ["*.whl"],
    )

# Generated at 2022-06-12 06:53:46.412636
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    m = Mock()
    m.files = {"/dist/example.whl": "example file"}
    upload_to_pypi("/dist", False, ["ex*"])
    assert m.called_with("twine upload  \"/dist/ex*\"")

    m = Mock()
    m.files = {"/dist/example.whl": "example file"}
    upload_to_pypi("/dist", False, ["*"])
    assert m.called_with("twine upload  \"/dist/*\"")

    m = Mock()
    m.files = {"/dist/example.whl": "example file"}
    upload_to_pypi("/dist", False)
    assert m.called_with("twine upload  \"/dist/*\"")

    m = Mock()

# Generated at 2022-06-12 06:54:56.931927
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .cli import runtests
    runtests("tests/test_pypi.py::test_upload_to_pypi")

# Generated at 2022-06-12 06:55:01.803997
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        "dist", skip_existing=False, glob_patterns=["*", "test/*"]
    )
    upload_to_pypi(
        "dist", skip_existing=False, glob_patterns=["*", "test/*"]
    )

# Generated at 2022-06-12 06:55:02.893805
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:55:09.645112
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command: str):
        return command

    # Example twine commands
    # twine upload -u 'username' -p 'password' -r 'repository' --skip-existing 'dist_path/packagename-1.0.0-py3-none-any.whl'
    # twine upload -u 'username' -p 'password' 'dist_path/packagename-1.0.0-py3-none-any.whl'
    # twine upload -u '__token__' -p 'pypi-xxxxxxxxxxxxxx' -r 'repository' 'dist_path/packagename-1.0.0-py3-none-any.whl'
    # twine upload -u '__token__' -p 'pypi-xxxxxxxxxxxxxx' 'dist_path/

# Generated at 2022-06-12 06:55:13.171488
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Arrange
    os.environ["PYPI_TOKEN"] = "pypi-1234567890abcdefghijklmnopqrstuvwxyz"
    # Act
    upload_to_pypi(path="dist")

# Generated at 2022-06-12 06:55:24.592465
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_patterns = ["*"]
    repo = 'test-repo'
    tokens = ['pypi-123', 'pypi-456', 'string-without-prefix']
    username_password = {'username': 'testuser1', 'password': 'testpass1'}
    path = 'dist'

    # No PYPI token or credentials
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        assert False

    # PYPI token specified
    # If token starts with 'pypi-', upload should succeed
    for token in tokens[:2]:
        os.environ["PYPI_TOKEN"] = token

# Generated at 2022-06-12 06:55:27.728617
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist",
        glob_patterns=["*"],
        skip_existing=False,
    )

# Generated at 2022-06-12 06:55:28.898586
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    assert True

# Generated at 2022-06-12 06:55:29.942354
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:55:30.405500
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None