

# Generated at 2022-06-12 06:47:58.081288
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Function should upload file dist to Test PyPI."""
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:48:05.271970
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(path="test/test_data", skip_existing=False)
    upload_to_pypi(path="test/test_data", skip_existing=False, glob_patterns=["test_data*"])
    upload_to_pypi(path="test/test_data", skip_existing=True, glob_patterns=["test_data*"])
    upload_to_pypi(path="test/test_data", skip_existing=False, glob_patterns=["*.whl"])

# Generated at 2022-06-12 06:48:10.969627
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function to upload_to_pypi
    """
    # pylint: disable=unused-variable
    def mocked_run(command):
        """
        Mock 'invoke.run' to test if the correct command is being passed
        """
        assert command == (
            "twine upload -u '__token__' "
            "-p 'pypi-token' -r 'pypi' "
            '"dist/testfile.whl"'
        )

    assert run == mocked_run

# Generated at 2022-06-12 06:48:13.429117
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-12 06:48:14.247004
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-12 06:48:24.919127
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    global run
    original_run_func = run

# Generated at 2022-06-12 06:48:25.891605
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist")

# Generated at 2022-06-12 06:48:37.322479
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import (assert_log_message, assert_no_log_message,
                          mock_environment_variables)

    with mock_environment_variables({
            'PYPI_TOKEN': None,
            'PYPI_USERNAME': "username",
            'PYPI_PASSWORD': "password",
            'HOME': os.path.abspath(os.path.join(__file__, '..', '..', '..'))
            }):
        assert_log_message(
            "Missing credentials for uploading to PyPI",
            upload_to_pypi,
            path='dist',
            skip_existing=False,
            glob_patterns=None
        )

# Generated at 2022-06-12 06:48:39.932849
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='tests/images', glob_patterns = ['*.png'], skip_existing=False)

# Generated at 2022-06-12 06:48:41.007381
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="")

# Generated at 2022-06-12 06:48:47.528512
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == 'upload_to_pypi'

# Generated at 2022-06-12 06:48:54.900458
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # If a PYPI_TOKEN is set, it should use it
    token = os.environ.get("PYPI_TOKEN", "")
    if token:
        os.environ["PYPI_TOKEN"] = "token"
        upload_to_pypi.log = ""
        upload_to_pypi(path="", skip_existing=False, glob_patterns=["*"])
        assert "twine upload -u '__token__' -p 'token' *.whl" in upload_to_pypi.log

    # If no PYPI_TOKEN, should use username and password
    else:
        os.environ["PYPI_USERNAME"] = "username"
        os.environ["PYPI_PASSWORD"] = "password"
        upload_to_p

# Generated at 2022-06-12 06:48:56.176902
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:49:01.128318
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Arrange
    os.environ["PYPI_TOKEN"] = "test_token"
    os.environ["HOME"] = "/home"
    os.path.isfile = lambda x: True
    glob_patterns = ["*"]

    # Act
    upload_to_pypi()

    # Assert
    assert True

# Generated at 2022-06-12 06:49:07.612441
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create a fake package distribution
    run('mkdir -p dist && touch dist/test.whl')

    try:
        upload_to_pypi(path="dist")
        # Assert it got uploaded
        assert('test.whl' in run('twine upload --list-repos', hide='stdout'))
    finally:
        # Clean up dist
        run('rm -r dist')

# Generated at 2022-06-12 06:49:11.880042
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config.load({
        "repository": {
            "url": "https://www.github.com/jgehrcke/semantic-release-demo-python",
            "type": "git",
        },
    })

    upload_to_pypi(path="./dist", skip_existing=True)

# Generated at 2022-06-12 06:49:20.149537
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set up a dummy repo
    run("rm -rf testrepo && mkdir testrepo && cd testrepo && git init")
    run("cd testrepo && echo a >> file.txt && git add file.txt && git commit -m 'version 0.1.0'")
    run("cd testrepo && git tag -a v0.1.0 -m 'version 0.1.0'")
    run("cd testrepo && echo a >> file.txt && git commit -am 'version 0.1.1'")
    run("cd testrepo && git tag -a v0.1.1 -m 'version 0.1.1'")
    run("cd testrepo && echo a >> file.txt && git commit -am 'version 0.2.0'")

# Generated at 2022-06-12 06:49:23.913248
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi()."""
    # Test for `repository` config set
    config["repository"] = "test_rep"
    upload_to_pypi(glob_patterns=["test.txt", "test.py"])
    assert (
        run.calls[0].args[0]
        == "twine upload -r 'test_rep' \"dist/test.txt\" \"dist/test.py\""
    )

    # Test for `username` and `password` args
    config["repository"] = "test_rep"
    upload_to_pypi(glob_patterns=["test.txt", "test.py"], username="user", password="pass")

# Generated at 2022-06-12 06:49:25.970584
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function.
    """
    upload_to_pypi("./dist", False, "*")

# Generated at 2022-06-12 06:49:36.274035
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil

    temporary_directory = tempfile.mkdtemp()
    temporary_file = tempfile.NamedTemporaryFile(dir=temporary_directory).name
    temporary_token = "pypi-" + os.urandom(24).hex()

    os.environ["PYPI_TOKEN"] = temporary_token
    upload_to_pypi(path=temporary_directory, glob_patterns=["*"])
    os.environ.pop("PYPI_TOKEN")

    os.environ["PYPI_USERNAME"] = "semantic_release"
    os.environ["PYPI_PASSWORD"] = os.urandom(24).hex()
    upload_to_pypi(path=temporary_directory, glob_patterns=["*"])


# Generated at 2022-06-12 06:49:50.923985
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run(cmd):
        return ""

    glob_patterns = ["*"]

    home_dir = os.environ.get("HOME", "")
    os.environ["HOME"] = home_dir

    # Test PYPI_TOKEN
    token = "pypi-123456"

    os.environ["PYPI_TOKEN"] = token
    upload_to_pypi("dist", True, glob_patterns, run)

    # Test PYPI_USERNAME and PYPI_PASSWORD
    username = "username"
    password = "password"
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"] = password
    upload_to_pypi("dist", True, glob_patterns, run)

    # Test

# Generated at 2022-06-12 06:50:00.261557
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*.whl"]
    username = "username"
    password = "password"
    repository = "pypi"

    upload_to_pypi(path, skip_existing, glob_patterns)

    full_command = "twine upload -p 'password' -u 'username' -r 'pypi' 'dist/*.whl'"
    try:
        assert run.called_with(full_command)
    except AssertionError:
        raise
    finally:
        run.reset()


# Generated at 2022-06-12 06:50:12.122737
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Tests the upload_to_pypi function"""

    # Test for config file
    os.environ["HOME"] = ""
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    try:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)
    except ImproperConfigurationError as e:
        print(e)
    else:
        assert False

    # Test for missing password
    os.environ["HOME"] = "/"
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = ""

# Generated at 2022-06-12 06:50:22.466415
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    from .helpers import make_temp_directory
    from .helpers import get_version
    from .helpers import create_config

    def upload_to_pypi_test_helper(
        version: str,
        package_name: str = "package",
        repository: str = None,
        expected_version: str = None,
    ):
        # Create our temporary folder
        with make_temp_directory() as temp_dir:

            # Create a wheel file
            wheel = f"{package_name}.{get_version(version)}-py3-none-any.whl"
            wheel_file = f"{package_name}-{get_version(version)}.tar.gz"
            shutil.copy(f"./tests/resources/{wheel_file}", wheel)
            shutil

# Generated at 2022-06-12 06:50:33.168377
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import set_python_path
    from .helpers import get_tox_envs
    from .helpers import run_tox

    env_name = "invoke-upload-to-pypi"

    python_path = set_python_path(env_name)

    cmd_args = {
        "package_name": "semantic-release-testpackage-invoke-upload-to-pypi",
        "version": "1.0.1",
        "next_version": "1.0.2",
        "conan_user_settings": f'conan_user_settings = "{python_path}/conan_user_settings"',
    }

    # Install package
    envs = get_tox_envs(env_name)

# Generated at 2022-06-12 06:50:41.098777
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from mock import patch, MagicMock

    with patch("semantic_release.plugins.upload_to_pypi.run") as patched_run:
        patched_run.return_value = MagicMock()
        test_path = "test_path"
        test_skip_existing = True
        test_token = "test_token"
        test_username = "test_username"
        test_password = "test_password"
        test_repository = "test_repository"

        os.environ["PYPI_TOKEN"] = test_token
        upload_to_pypi(test_path, test_skip_existing, ["test_glob2", "test_glob1"])

# Generated at 2022-06-12 06:50:43.981901
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = "dist", skip_existing= True, glob_patterns = [""] )

# Generated at 2022-06-12 06:50:50.523791
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import patch_run
    from .test_helpers import input_output

    config["repository"] = "test_repository.org"
    results = []
    patch_run(lambda cmd, **kwargs: results.append(cmd))
    upload_to_pypi()

    assert results == [
        "twine upload -u '__token__' -p 'pypi-xxx' -r 'test_repository.org' 'dist/*'"
    ]

# Generated at 2022-06-12 06:50:55.311280
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()
    assert upload_to_pypi(glob_patterns=["fake1.txt", "fake2.txt"])
    assert upload_to_pypi(skip_existing=True)

# Generated at 2022-06-12 06:51:04.647787
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test success with API token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert (
        run.calls[-1].kwargs["command"]
        == "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
    )
    # Test success with repository
    config.set("repository", "test")
    upload_to_pypi()
    assert (
        run.calls[-1].kwargs["command"]
        == "twine upload -u '__token__' -p 'pypi-token' -r 'test' 'dist/*'"
    )
    # Test success with username and password
    config.set("repository", None)
    os.environ

# Generated at 2022-06-12 06:51:19.502100
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Mock environment variables
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"

    # Mock out the module-level run function
    def run_mock(command):
        assert command == "twine upload -u 'test_username' -p 'test_password' -r 'test_repository' --skip-existing 'path/package' *"

    from .helpers import MockFunction
    MockFunction(run, run_mock)

    upload_to_pypi(
        path="path",
        skip_existing=True,
        glob_patterns=["*"],
        repository="test_repository",
    )

# Generated at 2022-06-12 06:51:31.589515
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Attempt to upload to PyPI.
    #
    # (This will fail if there aren't credentials for uploading to PyPI,
    # but this test is still useful for checking the expected behavior.)
    try:
        from .helpers import set_config
        set_config({"upload_to_pypi": True})
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    except SystemExit:
        pass

    # Attempt to upload with an invalid PyPI token
    os.environ["PYPI_TOKEN"] = "invalid_token"
    try:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    except SystemExit as e:
        assert e.code == 2

    #

# Generated at 2022-06-12 06:51:40.339167
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Test which should succeed
    try:
        os.environ["PYPI_TOKEN"] = "12345"
        upload_to_pypi()
    except Exception as e:
        assert False

    try:
        del os.environ["PYPI_TOKEN"]
        os.environ["PYPI_USERNAME"] = "12345"
        os.environ["PYPI_PASSWORD"] = "12345"
        upload_to_pypi()
    except Exception as e:
        assert False


# Generated at 2022-06-12 06:51:41.356209
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:51:42.472642
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:50.884253
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=redefined-outer-name
    class TestRun:
        def __init__(self):
            self.args = None

        def __call__(self, args):
            self.args = args

    run = TestRun()
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
    assert run.args == "twine upload  --skip-existing 'dist/*'"

    run = TestRun()
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=[])
    assert run.args is None

    run = TestRun()
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:51:51.448442
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:51:57.076288
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for upload_to_pypi
    """
    path = "dist"
    skip_existing = True
    glob_patterns = ["someRandomPattern", "anotherRandomPattern"]
    upload_to_pypi(path=path,skip_existing=skip_existing,glob_patterns=glob_patterns)

# Generated at 2022-06-12 06:51:59.247257
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    dist = "dist"
    glob_pattern = "*"
    upload_to_pypi(path=dist, glob_patterns=[glob_pattern])

# Generated at 2022-06-12 06:52:04.319688
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test Twine config
    assert config.get("twine", "username")
    assert config.get("twine", "password")
    assert config.get("twine", "repository")
    # Test artifact path
    assert config.get("path", "dist")

# Generated at 2022-06-12 06:52:22.654066
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:52:31.820344
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = "username"
    password = "password"
    repository = "repository"
    dist = "dist"
    glob_patterns = ["*"]
    token = "pypi-token"
    skip_existing = True

    with patch("os.environ.get") as env_mock:
        env_mock.side_effect = [None, username, password]
        with patch("semantic_release.hvcs.pypi.run") as run_mock:
            upload_to_pypi(dist, skip_existing, glob_patterns)
            assert run_mock.call_args[0][0] == (
                "twine upload -u 'username' -p 'password' \"dist/{}\"".format(
                    glob_patterns[0]
                )
            )



# Generated at 2022-06-12 06:52:34.607533
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist",
        skip_existing=False,
        glob_patterns=['*.whl'],
    )

# Generated at 2022-06-12 06:52:35.201681
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:52:37.388815
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='dist', glob_patterns=['dist/*'])

# Generated at 2022-06-12 06:52:38.580924
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-12 06:52:44.000929
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]

    @LoggedFunction(logger)
    def mock_run(command: str):
        os.environ["PYPI_TOKEN"] = "success"
        assert (
            command == f"twine upload -u '__token__' -p 'success' {skip_existing_param} {dist}"
        )

    run = mock_run
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-12 06:52:55.152956
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test upload to PyPI with token only
    with tempfile.TemporaryDirectory() as dir:
        open(os.path.join(dir, "package-0.0.0-py3-none-any.whl"), "w+").close()

        with mock.patch("invoke.run") as run_mock:
            upload_to_pypi(path=dir, glob_patterns=["*.whl"])
            run_mock.assert_called()

    # Test upload to PyPI with username + password
    with tempfile.TemporaryDirectory() as dir:
        open(os.path.join(dir, "package-0.0.0-py3-none-any.whl"), "w+").close()


# Generated at 2022-06-12 06:52:56.609692
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ Upload to pypi is tested through twine.
    """
    assert True == True

# Generated at 2022-06-12 06:52:57.170316
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:53:42.933104
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Check that the upload_to_pypi function uploads the required distribution
    """
    from .helpers import get_temp_dir
    from .helpers import touch

    # We don't wanna upload any file to PyPI
    skip_existing = True

    # We need a temporary folder for the distribution
    path = get_temp_dir()

    # We touch one file, named after the version
    filename = 'unit_test-0.1.2.tar.gz'
    touch(path + '/' + filename)

    # We call upload_to_pypi
    upload_to_pypi(path, skip_existing=skip_existing)

    return True

# Generated at 2022-06-12 06:53:49.473349
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    import semantic_release
    import sys

    if sys.version_info < (3, 6):
        pytest.skip("Skipping test_upload_to_pypi(since it uses os.makedirs)")

    from pathlib import Path

    config.use_default()
    with pytest.raises(
        semantic_release.exceptions.ImproperConfigurationError, match="Missing credentials"
    ):
        upload_to_pypi()

    config.use_default()
    os.environ["PYPI_TOKEN"] = "pypi-very-secret-token"
    with pytest.raises(
        semantic_release.exceptions.ImproperConfigurationError,
        match="PyPI token should begin with 'pypi-'",
    ):
        upload_to_pypi

# Generated at 2022-06-12 06:53:57.202808
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token_string = '-u "__token__" -p "pypi-abc123abc1234abc123abc123"'
    username_password = '-u "test" -p "pass"'
    with config.patch({"repository":"test_repo"}):
        assert upload_to_pypi.__wrapped__(glob_patterns=["test_glob*"]) == f"twine upload {token_string} -r 'test_repo' \"dist/test_glob*\""

# Generated at 2022-06-12 06:53:59.951341
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    This will test if upload_to_pypi is a callable method
    """
    assert callable(upload_to_pypi)

# Generated at 2022-06-12 06:54:00.920188
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:54:02.622969
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi
    """
    assert True

# Generated at 2022-06-12 06:54:03.716299
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:54:05.325405
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:54:06.237553
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:54:07.149866
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:55:26.708209
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .get_repository_url import get_repository_url
    from .helpers import create_test_file, delete_test_file


# Generated at 2022-06-12 06:55:31.240491
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    dist_path = os.path.dirname(__file__) + '/../../dist'
    token = os.environ.get("PYPI_TOKEN")
    os.environ["PYPI_TOKEN"] = token
    upload_to_pypi(path=dist_path)

# Generated at 2022-06-12 06:55:32.198892
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist")

# Generated at 2022-06-12 06:55:39.382280
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import os.path

    with tempfile.TemporaryDirectory() as tmp_dirname:
        test_path = os.path.join(tmp_dirname, "test.txt")
        with open(test_path, 'w') as test_file:
            test_file.write('test file')
        upload_to_pypi(tmp_dirname, False, ["test.txt"])

    assert True

# Generated at 2022-06-12 06:55:42.355517
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-12 06:55:43.127743
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:55:53.975174
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    def run_mock(command):
        """Fake function run
        """
        assert command == "twine upload -u 'username' -p 'password' -r 'repository' --skip-existing 'dist/file1' 'dist/file2'"

    import sys
    from unittest.mock import patch
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    with patch.object(sys, "argv", ["upload_to_pypi", "--skip-existing"]):
        with patch("invoke.run", new=run_mock):
            import semantic_release.cli
            semantic_release.cli.upload_to_pypi()



# Generated at 2022-06-12 06:55:55.985566
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    test_upload = Upload_to_pypi_Test()
    test_upload.test_upload_to_pypi()


# Generated at 2022-06-12 06:55:58.210216
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert(upload_to_pypi(path="path", skip_existing=True, glob_patterns=["pattern"]))

# Generated at 2022-06-12 06:56:06.620447
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Success token
    os.environ["PYPI_TOKEN"] = "pypi-abcdefghijklmnopqrstuvwxyz"
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(skip_existing=False)

    # Success username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(skip_existing=False)

    # Success username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pyp