

# Generated at 2022-06-12 06:48:03.916173
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from mock import patch

    # Assert that upload_to_pypi uses run with the expected arguments
    with patch("semantic_release.hvcs.pypi.upload_to_pypi.run") as mock_run:
        upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])
        assert mock_run.call_args[0][0].startswith("twine ")
        assert mock_run.call_args[0][0].endswith("'upload' 'dist/*'")
        assert mock_run.call_args[0][0].find("--skip-existing") > -1

    # Assert that upload_to_pypi uses run with the expected arguments when config provided

# Generated at 2022-06-12 06:48:05.654897
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("mypath")

# Generated at 2022-06-12 06:48:13.387339
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    from semantic_release.hvcs.bitbucket import BitbucketClient
    from semantic_release.settings import config
    from semantic_release.hvcs.git import GitClient
    import unittest
    from unittest.mock import patch

    class test_upload_to_pypiCase(unittest.TestCase):
        """Test class for testing the upload_to_pypi
        """

        def setUp(self):
            config.hvcs = GitClient()
            # Create a temp dist directory in the os
            self.temp_path = "temp_upload_dist"
            try:
                os.mkdir(self.temp_path)
            except FileExistsError:
                pass
            self.temp_file = "temp_upload_file.txt"

# Generated at 2022-06-12 06:48:24.391072
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import os
    import shutil
    import pytest
    from semantic_release.settings import config

    def side_effect_missing_env_var(key, default=None):
        if key == "PYPI_TOKEN":
            return None
        elif key == "PYPI_USERNAME":
            return None
        elif key == "PYPI_PASSWORD":
            return None
        else:
            return os.environ.get(key)

    def side_effect_with_token(key, default=None):
        if key == "PYPI_TOKEN":
            return "pypi-SECRET_TOKEN"
        elif key == "HOME":
            return "PATH"
        else:
            return os.environ.get(key)


# Generated at 2022-06-12 06:48:34.894841
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import subprocess
    import tempfile

    def fake_run(*args, **kwargs):
        return subprocess.run(
            " ".join(args[0].split()[1:]),
            shell=True,
            cwd=temp_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True
        )

    # Create a fake file in a temporary directory
    temp_dir = tempfile.mkdtemp()
    filename = os.path.join(temp_dir, "fake.txt")
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'w') as file:
        file.write("Hello")

    # Test with a token (preferred)
    token

# Generated at 2022-06-12 06:48:37.286063
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.chdir(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    upload_to_pypi()

# Generated at 2022-06-12 06:48:45.843894
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Tests that upload_to_pypi function uploads wheel files to pypi.
    """

    # Attempt to get an API token from environment
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")

# Generated at 2022-06-12 06:48:46.444314
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:49.579036
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    test_config = config
    test_config.update({"repository": "test"})
    test_config["repository"].get = test_config.get

# Generated at 2022-06-12 06:49:00.771858
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
    except ImportError:
        raise ImproperConfigurationError(
            "Missing `twine` dependency to upload to PyPI"
        )

    # Test 1: No credentials
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert "Missing credentials" in str(e)
    else:
        assert False

    # Test 2: Bad token
    os.environ["PYPI_TOKEN"] = "badtoken"
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert "PyPI token" in str(e)
    else:
        assert False

    os.environ["PYPI_TOKEN"] = "pypi-token"

    # Test 3: Good token

# Generated at 2022-06-12 06:49:05.697255
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:49:07.055672
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Function upload_to_pypi does not return anything."""
    pass

# Generated at 2022-06-12 06:49:07.534118
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 == 1

# Generated at 2022-06-12 06:49:13.317080
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_os

    with mock_os("PYPI_TOKEN", "test_token"):
        upload_to_pypi("dist", True, ["test_one", "test_two"])

    with mock_os("PYPI_USERNAME", "test_user", "PYPI_PASSWORD", "test_password"):
        upload_to_pypi("dist", True, ["test_one", "test_two"])

# Generated at 2022-06-12 06:49:16.950734
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    expect = "twine upload " + '-u "__token__" -p "pypi-token" --skip-existing "dist/*"'
    assert expect == upload_to_pypi.__wrapped__(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-12 06:49:23.631949
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    from .contexts import PyPiContext
    from .package_info import PackageInfo
    from .upload import PyPiUploader
    with PyPiContext(PackageInfo("1.0.0", "1.0.0", False), PyPiUploader()) as ctx:
        upload_to_pypi(skip_existing=True)

# Generated at 2022-06-12 06:49:25.052291
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("testing_path")
    assert True

# Generated at 2022-06-12 06:49:35.180379
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_settings, mock_run
    from . import pypi_plugin

    pypi_plugin.run = mock_run

    with open("tests/fixtures/pypirc", "r") as pypirc:
        pypi_plugin.config = mock_settings(
            {"repository": "test", "pypirc": pypirc.read(), "skip_existing": True}
        )

    pypi_plugin.upload_to_pypi()
    pypi_plugin.run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-test'  --skip-existing 'dist/*'"
    )

    pypi_plugin.run = mock_run

# Generated at 2022-06-12 06:49:41.935785
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None
    assert upload_to_pypi(glob_patterns=[]) == None
    assert upload_to_pypi(glob_patterns=["*.whl"]) == None
    assert upload_to_pypi(skip_existing=True) == None
    # test that upload_to_pypi fails properly
    if os.environ.get("PYPI_TOKEN"):
        del os.environ["PYPI_TOKEN"]
    assert upload_to_pypi() == False

# vim: ts=4 sw=4 expandtab

# Generated at 2022-06-12 06:49:43.350480
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("/dist", False)
    assert True

# Generated at 2022-06-12 06:49:54.280043
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    r = upload_to_pypi(path=".")
    assert r is None

# Generated at 2022-06-12 06:49:55.505898
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:59.265041
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True)
    upload_to_pypi("dist", True, ["*.whl"])
    upload_to_pypi("dist", True, ["*.whl", "*.exe"])

# Generated at 2022-06-12 06:50:00.064657
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:50:05.462634
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Only test that no error is raised, actual upload to PyPI is tested in integration tests
    upload_to_pypi(skip_existing=True, glob_patterns=["*"])
    upload_to_pypi(skip_existing=True, glob_patterns=["*", "*.*"])

# Generated at 2022-06-12 06:50:13.909728
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    """
    import os

    os.environ["PYPI_TOKEN"] = "pypi-token"

    upload_to_pypi(skip_existing=True, glob_patterns=["*.txt"])

    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "pass"

    upload_to_pypi(skip_existing=False, glob_patterns=["*.txt"])

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-12 06:50:24.002778
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from mock import patch, mock_open
    from tempfile import NamedTemporaryFile

    with patch("invoke.run", autospec=True) as mock_run:
        upload_to_pypi(
            path="some/path", skip_existing=False, glob_patterns=["file1", "file2"]
        )
    mock_run.assert_called_once_with(
        "twine upload  \"some/path/file1\" \"some/path/file2\""
    )

    with patch("invoke.run", autospec=True) as mock_run:
        upload_to_pypi(path="some/path", skip_existing=True, glob_patterns=["*.rpm"])

# Generated at 2022-06-12 06:50:26.054532
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns='dist/example-*', skip_existing=True)



# Generated at 2022-06-12 06:50:34.912239
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import twine
    from twine import PackageUploader

    class MockPackageUploader(PackageUploader):
        def __init__(self, username, password):
            self.username = username
            self.password = password

        def upload(self, dist):
            assert self.username == '__token__'
            assert self.password == 'pypi-TESTTOKEN'
            assert dist == ['dist/my-dist.whl']

    # Mock twine.PackageUploader
    twine.PackageUploader = MockPackageUploader

    test_token = 'TESTTOKEN'

# Generated at 2022-06-12 06:50:40.053809
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run
    with mock_run():
        upload_to_pypi(path="dist",
                       skip_existing=False,
                       glob_patterns=["*.whl"])
        assert run.call_count == 1
        assert run.call_args[0][0] == "twine upload  'dist/*.whl'"

# Generated at 2022-06-12 06:51:04.690527
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from pathlib import Path
    from unittest.mock import patch
    import tempfile

    temp_folder = tempfile.mkdtemp()
    original_pypi_token = os.environ.get("PYPI_TOKEN")
    original_pypi_username = os.environ.get("PYPI_USERNAME")
    original_pypi_password = os.environ.get("PYPI_PASSWORD")


# Generated at 2022-06-12 06:51:09.708886
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    except:
        assert False, "Unable to upload to PyPI"
    else:
        assert True

# Generated at 2022-06-12 06:51:10.241066
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:18.476457
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi."""
    from .helpers import setup_environment_variables

    # pylint: disable=R0915
    def upload_to_pypi_mock(
        path: str = "dist", skip_existing: bool = False, glob_patterns: List[str] = None
    ):
        """Mock function for upload_to_pypi."""
        if not glob_patterns:
            glob_patterns = ["*"]

        # Attempt to get an API token from environment
        token = os.environ.get("PYPI_TOKEN")
        username = None
        password = None
        if not token:
            # Look for a username and password instead
            username = os.environ.get("PYPI_USERNAME")
            password = os.environ

# Generated at 2022-06-12 06:51:20.479544
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(glob_patterns=["*"], skip_existing=False) == None

# Generated at 2022-06-12 06:51:32.451837
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for upload_to_pypi
    """
    import mock
    from semantic_release.hvcs import logger
    from semantic_release.errors import ImproperConfigurationError

    with mock.patch("invoke.run") as mock_run:
        mock_run.return_value = True
        # Incorrect token
        with mock.patch("os.environ", {"PYPI_TOKEN": "invalid-token"}):
            with logger.log_to_list() as log, pytest.raises(
                ImproperConfigurationError
            ) as e:
                upload_to_pypi()
            assert "PyPI token should begin with 'pypi-'" in str(e)
            assert "is not a correct API token" not in str(e)
            assert len(log) == 1

        # No credentials

# Generated at 2022-06-12 06:51:32.993592
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:34.664305
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-12 06:51:36.424276
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-12 06:51:38.276645
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert  upload_to_pypi.__name__ == "upload_to_pypi"
    assert upload_to_pypi.__doc__

# Generated at 2022-06-12 06:52:18.416188
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Test for checking credentials exists
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError as e:
        assert "credentials" in str(e)

    # Test for checking credentials are valid
    os.environ["PYPI_TOKEN"] = "bad-token"
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError as e:
        assert "credentials" in str(e)

# Generated at 2022-06-12 06:52:21.108148
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", True, ["*"])

# Generated at 2022-06-12 06:52:23.056897
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(**{"path": "dist"})

# Generated at 2022-06-12 06:52:32.120303
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest

    from .helpers import has_file_contents

    from .test_helpers import replace_environ

    # Test missing credentials
    with pytest.raises(ImproperConfigurationError) as exception:
        upload_to_pypi()

    assert "Missing credentials for uploading to PyPI" in str(exception.value)

    # Test missing a 'pypi-' prefix on the token
    with pytest.raises(ImproperConfigurationError) as exception:
        with replace_environ({"PYPI_TOKEN": "mytoken"}):
            upload_to_pypi()

    assert "should begin with 'pypi-'" in str(exception.value)

    # Test doing a dry run of a successful package upload

# Generated at 2022-06-12 06:52:36.433001
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi == "twine upload dist/*"
    os.environ["PYPI_TOKEN"] = "pypi-mysecret"
    assert upload_to_pypi == "twine upload -u '__token__' -p 'pypi-mysecret' dist/*"

# Generated at 2022-06-12 06:52:38.622746
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert(upload_to_pypi.__name__ == "upload_to_pypi")
    assert(upload_to_pypi.__doc__ != None)

# Generated at 2022-06-12 06:52:39.220006
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:52:42.426561
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    os.environ["PYPI_TOKEN"] = "token"
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    upload_to_pypi(path)

# Generated at 2022-06-12 06:52:50.064190
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    from pathlib import Path
    from semantic_release import settings
    from semantic_release.exceptions import Fail

    class MockRun:
        def __init__(self, config, expected_run_command):
            self.config = config
            self.expected_run_command = expected_run_command

        def __call__(self, command):
            if command != self.expected_run_command:
                raise Fail("Wrong command")

    def create_files(files, dir=None):
        for file in files:
            open("/".join([dir, file]), 'a').close()


# Generated at 2022-06-12 06:52:59.562863
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run(cmd):
        return MockRun(cmd)

    def env(var, default=None):
        if var == "HOME":
            return "/home"
        else:
            return os.environ.get(var, default)

    class MockRun(object):
        def __init__(self, cmd):
            self.cmd = cmd

    original_run = run
    original_env = env

    import semantic_release.upload_to_pypi
    semantic_release.upload_to_pypi.invoke.run = run
    semantic_release.upload_to_pypi.os.environ.get = env


# Generated at 2022-06-12 06:54:17.187217
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_patterns = ["semantic_release-*", "python_semantic_release-*"]
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=glob_patterns)

# Generated at 2022-06-12 06:54:28.093278
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    expected_call_args = ""
    available_packages_before = []
    available_packages_after = []

    def mock_run(call):
        nonlocal expected_call_args

        expected_call_args = call
        # Simulate scenario in which no package was available before the upload.
        return ["1 package(s) uploaded successfully!", None]

    class MockConfig:
        def get(self, _, default=None):
            return default if default else ""

    mock_config = MockConfig()

    def run_test(skip_existing, glob_patterns):
        expected_call_args = ""
        os.environ["PYPI_TOKEN"] = "pypi-test-token"
        upload_to_pypi(skip_existing=skip_existing, glob_patterns=glob_patterns)
       

# Generated at 2022-06-12 06:54:29.492690
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:54:36.721602
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Config
    os.environ["PYPI_TOKEN"] = "pypi-12345678910"
    os.environ["HOME"] = "/"
    os.environ["PATH"] = "/"

    from invoke.context import Context

    from mock import MagicMock
    from mock import patch

    m_run = MagicMock(name="m_run")
    m_run.return_value = None

    c = Context()
    c.run = m_run

    with patch("invoke.run", m_run):

        # Test different values for skip_existing
        upload_to_pypi(skip_existing=False)

# Generated at 2022-06-12 06:54:46.919307
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    This function unit tests the upload_to_pypi with a mocked run of the os environment and invoke.run
    """
    from unittest.mock import patch

    def mock_run(command):
        return "mocked run " + command

    with patch("invoke.run", side_effect=mock_run) as mock_method:
        assert upload_to_pypi("dist") == "mocked run twine upload 'dist/*'"
        assert upload_to_pypi("dist/", glob_patterns=["*"]) == "mocked run twine upload 'dist/*'"
        assert (
            upload_to_pypi("dist/", skip_existing=True)
            == "mocked run twine upload  --skip-existing 'dist/*'"
        )

# Generated at 2022-06-12 06:54:48.962873
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = "dist", skip_existing = False, glob_patterns = ["*"])

# Generated at 2022-06-12 06:54:50.500945
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-12 06:54:51.947284
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Return true if upload_to_pypi is defined."""
    return upload_to_pypi

# Generated at 2022-06-12 06:54:55.630718
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import get_new_version

    new_version = get_new_version("patch")
    upload_to_pypi(skip_existing=True, glob_patterns=["*.whl"])

# Generated at 2022-06-12 06:54:56.688438
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:57:35.897269
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    logger.info("**************** Entering unit test for function upload_to_pypi")
    upload_to_pypi("dist", skip_existing=True, glob_patterns="*")

# Generated at 2022-06-12 06:57:46.404544
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = "PYPI_USERNAME"
    password = "PYPI_PASSWORD"
    token = "PYPI_TOKEN"
    local_path = "/user/home/dist"
    glob_pattern = "*"

    upload_to_pypi_cmd = "twine upload "

    user_pass_template = "{} -u '{}' -p '{}' "
    token_template = "{} -u '{}' -p '{}' "

    skip_existing_template = "--skip-existing "
    glob_patterns_template = " ".join(
        ['"{}/{}"'.format(local_path, glob_pattern.strip())]
    )

    # Test with username and password
    os.environ["PYPI_USERNAME"] = username
    os