

# Generated at 2022-06-12 06:47:54.043886
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="")

# Generated at 2022-06-12 06:47:59.524034
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["intellistock-0.0.0-py3-none-any.whl",])
    upload_to_pypi(glob_patterns=["intellistock-0.0.0.tar.gz",])

# Generated at 2022-06-12 06:48:07.207951
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def _mock_run(command, *args, **kwargs):
        # Make sure command is what we expect
        command_parts = command.split(" ")
        expected_parts = [
            "twine",
            "upload",
            "-p",
            "hunter2",
            "-u",
            "test",
            "dist/*"
        ]
        assert command_parts == expected_parts, "Wrong command!"

    # Use the mocked run for this test
    invoke_run_save = run
    run = _mock_run
    # Test with a token and a repository
    os.environ["PYPI_TOKEN"] = "hunter2"
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        assert False, "Should not be missing credentials"

# Generated at 2022-06-12 06:48:14.110873
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # this is a test of the function upload_to_pypi and not a
    # unit test of twine and pypi. No local pypi server or token
    # is needed to run this test.
    import tempfile
    import shutil
    from unittest.mock import patch, MagicMock
    from collections import namedtuple

    # fake a twine Configuration from twine.commands.upload._configuration()
    FakeConfiguration = namedtuple("FakeConfiguration", ["repository_url", "username", "password", "sign_with", "comment"])
    fake_configuration = FakeConfiguration("fake_url", "fake_user", "fake_password", False, False)
    fake_auth_config = MagicMock()

# Generated at 2022-06-12 06:48:24.752906
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from mock import MagicMock
    from semantic_release.hvcs import set_repo_url
    from semantic_release.settings import config
    from semantic_release.uploaders import upload_to_pypi

    set_repo_url('https://github.com/repoowner/reponame')
    config['upload_to_pypi'] = True
    config['pypi_url'] = 'https://upload.pypi.org/legacy/'

    run_mock = MagicMock()
    run_mock.return_value = MagicMock(stdout='Successfully registered repository')

    upload_to_pypi(
        path="dist",
        skip_existing=False,
        glob_patterns=['*'],
    )

# Generated at 2022-06-12 06:48:27.421753
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="./tests/fixtures/dist", glob_patterns=["*"])
    upload_to_pypi(path="./tests/fixtures/dist", glob_patterns=["*.whl"])

# Generated at 2022-06-12 06:48:37.856976
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from pathlib import Path
    from .mocks import MockRepository
    from .mocks.pypi.server import PyPIServer
    from .mocks.git.server import GitServer

    # Start pypi server
    with PyPIServer():
        # Set up a repository
        with MockRepository("pypi"):
            # Create a wheel
            run("python setup.py bdist_wheel")
            wheels = glob.glob("dist/*")
            assert len(wheels) == 1

            # Upload the wheel
            upload_to_pypi()

        # Verify wheel was uploaded to pypi
        response = requests.get("http://127.0.0.1:8080/simple/package/")
        assert response.status_code == 200

        # Verify wheel was downloaded from pypi

# Generated at 2022-06-12 06:48:42.257960
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "tests/test_files/project/dist"
    skip_existing = False
    glob_patterns = ["*"]

    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-12 06:48:53.479794
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command):
        return


# Generated at 2022-06-12 06:48:54.111859
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:49:02.489859
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    

# Generated at 2022-06-12 06:49:09.979157
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    logger.info("Testing upload_to_pypi()")
    os.chdir(os.path.join(os.path.dirname(os.path.realpath(__file__)), "examples/simple"))
    config["twine_username"] = "__token__"
    config["twine_password"] = "pypi-12345"
    upload_to_pypi(path="tests/dist", skip_existing=True, glob_patterns=["*"])
    config.pop("twine_username")
    config.pop("twine_password")

# Generated at 2022-06-12 06:49:18.722399
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test upload with username and password
    os.environ["PYPI_USERNAME"] = "my-username"
    os.environ["PYPI_PASSWORD"] = "my-password"
    upload_to_pypi(glob_patterns=["my-repo/my-wheel-name.whl"])
    os.environ.pop("PYPI_USERNAME")
    os.environ.pop("PYPI_PASSWORD")

    # Test upload with token
    os.environ["PYPI_TOKEN"] = "pypi-my-token"
    upload_to_pypi(glob_patterns=["my-repo/my-wheel-name.whl"])
    os.environ.pop("PYPI_TOKEN")

    # Test upload with

# Generated at 2022-06-12 06:49:19.906522
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    :return:
    """

# Generated at 2022-06-12 06:49:29.250197
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import TemporaryDirectory
    from .helpers import read_from_file
    from .helpers import write_to_file
    from .helpers import mock_run
    from .helpers import mock_exists

    with TemporaryDirectory() as temp_dir:
        dist_folder = temp_dir / "dist"
        dist_folder.mkdir()

        package_file = dist_folder / "package.whl"
        write_to_file(package_file, "package")

        # Assert default values
        upload_to_pypi(str(temp_dir))
        assert mock_run.call_count == 1
        assert "-u '__token__' -p 'pypi-'" in mock_run.call_args[0][0]
        assert "--skip-existing" not in mock_run.call

# Generated at 2022-06-12 06:49:32.072932
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert run("python -c 'from semantic_release.package_managers.pypi import upload_to_pypi'").failed

# Generated at 2022-06-12 06:49:41.771233
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    os.environ["PYPI_SERVICE_URL"] = "test"
    os.environ["PYPI_REPOSITORY"] = "test"

    upload_to_pypi()
    upload_to_pypi(skip_existing=True)
    
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    os.environ["PYPI_SERVICE_URL"] = ""
    os.environ["PYPI_REPOSITORY"] = ""


test_upload_to_pypi()

# Generated at 2022-06-12 06:49:43.550416
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi.
    """
    upload_to_pypi()

# Generated at 2022-06-12 06:49:45.244056
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", glob_patterns=["*"])

# Generated at 2022-06-12 06:49:53.421826
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import subprocess
    import tempfile

    # Create temp directory
    tempdir = tempfile.mkdtemp()

    # Create folders
    os.makedirs(os.path.join(tempdir, "dist"))

    # Create token
    token_file_name = os.path.join(tempdir, ".pypi_token")
    with open(token_file_name, "w") as f:
        f.write("pypi-token_123456789")

    # Create config file
    config_file_name = os.path.join(tempdir, ".pypirc")

# Generated at 2022-06-12 06:50:04.654767
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='testdata', glob_patterns=["*.txt"])

# Generated at 2022-06-12 06:50:15.102524
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from semantic_release.plugins.invoke import run as invoke_run

    with patch("semantic_release.plugins.pypi.invoke.run", new=invoke_run) as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    mock.assert_called_once_with('twine upload  "dist/*"')

    with patch("semantic_release.plugins.pypi.invoke.run", new=invoke_run) as mock:
        upload_to_pypi(
            path="dist", skip_existing=True, glob_patterns=["*", "spam-*", "*eggyolks*"]
        )

# Generated at 2022-06-12 06:50:17.679882
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="/fakes", skip_existing=True, glob_patterns="*")

# Generated at 2022-06-12 06:50:19.223673
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.uploaders import upload_to_pypi
    upload_to_pypi()

# Generated at 2022-06-12 06:50:21.994685
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create mock variables for the function
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]

    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-12 06:50:32.754662
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Ensure that twine is called with the proper arguments.
    """
    token = 'test-token'
    username = 'test_user'
    password = 'test_password'
    repository = 'pypi-repository'

    with patch('semantic_release.upload_to_pypi.run') as mock_run:
        upload_to_pypi(path='test_path', glob_patterns=['*.whl'], skip_existing=True)
        mock_run.assert_called_once_with('twine upload  --skip-existing "test_path/*.whl"')

    mock_run.reset_mock()

    os.environ['PYPI_TOKEN'] = token

# Generated at 2022-06-12 06:50:39.884151
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    import tempfile
    import unittest

    from unittest.mock import patch
    from invoke.context import Context

    from .fakes import FakeClass

    class TestUploadToPyPi(unittest.TestCase):

        def setUp(self):
            self.temp_directory = tempfile.TemporaryDirectory()
            self.temp_directory_path = self.temp_directory.name
            self.dist_path = os.path.join(self.temp_directory_path, "dist")
            os.makedirs(self.dist_path)
            
            os.environ["PYPI_TOKEN"] = "test_token"
            os.environ["PYPI_USERNAME"] = "test_username"

# Generated at 2022-06-12 06:50:49.049021
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    auth = { "username": "test_user", "password": "test_password" }
    repository = "test_repository"
    expected_cmd = """twine upload -u 'test_user' -p 'test_password' -r 'test_repository' 'dist/test_file1' 'dist/test_file2'"""
    run.return_value = expected_cmd
    result = upload_to_pypi(path, None, None, auth, repository)
    assert result == expected_cmd

# Generated at 2022-06-12 06:51:01.535994
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "foo"
    os.environ["PYPI_PASSWORD"] = "bar"
    os.environ["HOME"] = "/test/"
    os.path.isfile = lambda *args: True
    os.environ.get = lambda *args: "test"
    # Test with an API token
    os.environ["PYPI_TOKEN"] = "pypi-1234"
    result = upload_to_pypi()
    assert result == "twine upload -u __token__ -p pypi-1234  -r 'test'  'dist/*'"
    # Test with username and password
    os.environ["PYPI_TOKEN"] = ""
    result = upload_to_pypi()

# Generated at 2022-06-12 06:51:03.272528
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob = "dist/*"
    upload_to_pypi(path = "dist", skip_existing = True, glob_patterns = [glob])

# Generated at 2022-06-12 06:51:32.408025
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """It reads pypi authentication variables and uploads files to pypi.
    """
    def run_mock(shell_command):
        """Mock of run()
        """
        assert "twine upload" in shell_command
        assert "-u 'username'" in shell_command
        assert "-p 'password'" in shell_command
        assert "upload/dist_1.0.0-why-are-you-doing-this.tar.gz" in shell_command
        assert "upload/dist_1.0.0-why-are-you-doing-this.whl" in shell_command
        assert "upload/dist_1.0.0.tar.gz" in shell_command
        assert "upload/dist_1.0.0.whl" in shell_command


# Generated at 2022-06-12 06:51:35.167723
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert run("true", hide=True).ok is True, "Module invoke is not working."
    assert isinstance(upload_to_pypi(), NoneType), "Function upload_to_pypi is not working."

# Generated at 2022-06-12 06:51:36.932021
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-12 06:51:38.743248
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist",
        skip_existing=False,
        glob_patterns=["*"]
    )

# Generated at 2022-06-12 06:51:49.102512
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Path
    upload_to_pypi(path=None) == "twine upload  *"
    upload_to_pypi(path="foo") == 'twine upload  "foo/*"'
    # Glob_patterns
    upload_to_pypi(glob_patterns=["foo/*", "bar/*", "baz/*"]) == 'twine upload  "foo/*" "bar/*" "baz/*"'
    # Skip_existing
    upload_to_pypi(skip_existing=False) == "twine upload  *"
    upload_to_pypi(skip_existing=True) == "twine upload  * --skip-existing"
    # Username and Password
    os.environ["PYPI_USERNAME"] = "Foo"

# Generated at 2022-06-12 06:51:49.860458
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:51:50.363329
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:52.793827
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    glob_patterns = '["*"]'
    skip_existing = False
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-12 06:51:56.134800
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import make_dist_file

    make_dist_file()
    upload_to_pypi(skip_existing=True)

# Generated at 2022-06-12 06:51:59.098363
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import os

    path = tempfile.mkdtemp()

    # Test environment variable
    os.environ['PYPI_TOKEN'] = 'pypi-xxx'
    upload_to_pypi(path)

# Generated at 2022-06-12 06:52:35.106984
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    
    upload_to_pypi()

# Generated at 2022-06-12 06:52:36.770726
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = ".", skip_existing = True)


# Generated at 2022-06-12 06:52:41.534308
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
    except ImportError:
        return  # Twine is not installed

    twine.commands.upload.register("",  # Use an empty string for the command
                                   upload_to_pypi,
                                   upload_to_pypi.__doc__)

    upload_to_pypi(path=".", glob_patterns=["*.md"])

# Generated at 2022-06-12 06:52:49.998652
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""

    import pytest
    import tempfile
    import shutil
    import subprocess

    with tempfile.TemporaryDirectory() as dist_dir:
        # Generate a minimal setup.py in the temporary directory,
        # so that twine doesn't blow up when trying to use it.
        # In fact, this directory is so minimal that the generated
        # setup.py has a different name, so we need to tell twine
        # to use that instead.
        with open("setup-semantic_release.py", "w") as setupfile:
            setupfile.write("from setuptools import setup")
        subprocess.call(
            ["python3", "setup-semantic_release.py", "bdist_wheel", "-d", dist_dir]
        )
        # Create

# Generated at 2022-06-12 06:52:52.830441
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os

    os.system("python -m invoke build")

    # Perform test to upload to PyPI
    os.system("python -m semantic_release.hvcs.pypi_upload")

# Generated at 2022-06-12 06:52:53.331609
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:52:54.198894
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-12 06:53:04.741477
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import invoke
    import tempfile
    from pathlib import Path
    from pprint import pformat
    from semantic_release.settings import load_config, config

    load_config()

    tmpdir = Path(tempfile.mkdtemp())

# Generated at 2022-06-12 06:53:07.488148
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test function
    upload_to_pypi()
    # Test function with repository
    upload_to_pypi(repository='test')
    # Test function with repository and skip existing
    upload_to_pypi(repository='test', skip_existing=True)

# Generated at 2022-06-12 06:53:09.045298
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:54:31.375424
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Arrange
    import tempfile
    import shutil
    import glob
    from pathlib import Path

    temp_path = tempfile.mkdtemp()

    with open(os.path.join(temp_path, "test_file.txt"), "w") as fh:
        fh.write("test")

    repo = "test_repo"
    username = "username"
    password = "password"
    token = "pypi-token"

    # Act

# Generated at 2022-06-12 06:54:32.243083
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-12 06:54:43.669947
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os

    os.environ["PYPI_TOKEN"] = "this-is-fake-token"
    os.environ["HOME"] = "fake-home-dir"
    upload_to_pypi()
    os.environ["PYPI_TOKEN"] = "pypi-this-is-fake-token"
    upload_to_pypi()
    os.environ["PYPI_TOKEN"] = "this-is-fake-token"
    os.environ["PYPI_USERNAME"] = "fake-username"
    os.environ["PYPI_PASSWORD"] = "fake-password"
    upload_to_pypi()

# Generated at 2022-06-12 06:54:45.121170
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", True, ["myfile.whl"]) == None

# Generated at 2022-06-12 06:54:53.754856
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if not os.environ.has_key('PYPI_TOKEN'):
        sys.exit("Error: Test requires environment variable PYPI_TOKEN to be set.")
    if not os.environ.has_key('PYPI_USERNAME'):
        sys.exit("Error: Test requires environment variable PYPI_USERNAME to be set.")
    if not os.environ.has_key('PYPI_PASSWORD'):
        sys.exit("Error: Test requires environment variable PYPI_PASSWORD to be set.")

    upload_to_pypi(path='/tmp', skip_existing=True, glob_patterns=['*'])

# Generated at 2022-06-12 06:55:04.800514
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    import pytest
    from semantic_release.plugins.pypi.helpers import upload_to_pypi

    class TestException(Exception):
        pass

    def mock_run(cmd):
        if cmd.startswith("twine upload -u '__token__' -p 'pypi-a1b2c3d4'"):
            return
        else:
            raise TestException("Calling twine with invalid command:", cmd)

    with pytest.raises(TestException):
        upload_to_pypi("dummy", glob_patterns=["*"])

    with pytest.raises(TestException):
        upload_to_pypi("dummy", skip_existing=True, glob_patterns=["*"])

    with pytest.raises(TestException):
        upload_to_p

# Generated at 2022-06-12 06:55:06.070652
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Sample function test for upload_to_pypi"""


# Generated at 2022-06-12 06:55:10.529412
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    print(upload_to_pypi(
        path = "dist",
        skip_existing = False,
        glob_patterns = ["*"]
    ))

test_upload_to_pypi()

# Generated at 2022-06-12 06:55:11.536604
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:55:19.165081
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test uploading to PyPI using Twine."""
    # pylint: disable=unused-argument
    def get_credentials(username):
        """Return the correct credentials for the test."""
        if username == "__token__":
            return "test-repository-testapitoken"
        return "test-repository-username", "test-repository-password"

    def run_cmd(_cmd, _in_stream, _pty, _out_stream, _err_stream, _hide):
        """Print to std out the command run by upload_to_pypi to assist in test debugging."""
        print(_cmd)

    # Mock run method
    run.run = run_cmd

    # Test