

# Generated at 2022-06-12 06:47:55.928162
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:48:03.644273
# Unit test for function upload_to_pypi

# Generated at 2022-06-12 06:48:11.127056
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypi_token = "pypi-XXXXXXXXXXXXXXXXXX"
    os.environ["PYPI_TOKEN"] = pypi_token
    repository = "pypitest"
    os.environ["PYPI_REPOSITORY"] = repository

    # Call upload_to_pypi()
    upload_to_pypi()
    # Check that twine is called with the correct command line
    assert run.calls[0].command == "twine upload -u '__token__' -p 'pypi-XXXXXXXXXXXXXXXXXX' -r 'pypitest' 'dist/*'"

# Generated at 2022-06-12 06:48:20.010555
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('semantic_release.hvcs.pypi.run') as mock_run:
        upload_to_pypi(
            path="test",
            skip_existing=True,
            glob_patterns=["*", "*.tar.gz"],
        )
    mock_run.assert_called_once_with(
        "twine upload  --skip-existing \"test/*\" \"test/*.tar.gz\""
    )

# Generated at 2022-06-12 06:48:21.872155
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"])



# Generated at 2022-06-12 06:48:25.203490
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.hvcs.git.local import run


# Generated at 2022-06-12 06:48:37.322795
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function."""
    from .helpers import patch
    from .helpers import mock_env
    from .helpers import mock_run

    # Test missing PYPI_TOKEN
    with patch(
        "semantic_release.hvcs.git.upload_to_pypi", "invoke", "run", "importerror"
    ):
        with mock_run:
            with mock_env(
                REPOSITORY="pypi", PYPI_TOKEN="", PYPI_USERNAME="", PYPI_PASSWORD=""
            ):
                upload_to_pypi(glob_patterns=[])

# Generated at 2022-06-12 06:48:38.575067
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: write unit test
    pass

# Generated at 2022-06-12 06:48:41.714588
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(glob_patterns=['*.whl']) == True

# Generated at 2022-06-12 06:48:52.907865
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi
    """
    from .utils import mock
    from .utils import os
    from .utils import unittest

    class TestUploadToPyPi(unittest.TestCase):
        def test_exception_raised_if_bad_token(self):
            with self.assertRaises(ImproperConfigurationError):
                with mock.patch.dict(
                    os.environ, {"PYPI_TOKEN": "not-a-pypi-token"}, clear=True
                ):
                    upload_to_pypi()

        def test_exception_raised_if_missing_credentials(self):
            with self.assertRaises(ImproperConfigurationError):
                with mock.patch.dict(os.environ, {}, clear=True):
                    upload_to_p

# Generated at 2022-06-12 06:49:10.072022
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import subprocess
    import os

    from invoke import run

    from .helpers import LoggedFunction

    temp_path = tempfile.mkdtemp()
    test_file_name = os.path.join(temp_path, "foo.txt")

    @LoggedFunction(logger)
    def upload_to_pypi(
        path: str = "dist", skip_existing: bool = False, glob_patterns: List[str] = None
    ):
        temp_path = tempfile.mkdtemp()
        test_file_name = os.path.join(temp_path, "foo.txt")

        if not glob_patterns:
            glob_patterns = ["*"]

        # Attempt to get an API token from environment

# Generated at 2022-06-12 06:49:10.984069
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:19.509836
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # When a PYPI_TOKEN is used, the username and password is set accordingly
    from semantic_release.upload_to_pypi import upload_to_pypi

    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert "__token__" in run.calls[0]
    assert "-p 'pypi-token'" in run.calls[0]

    # When a PYPI_USERNAME and PYPI_PASSWORD is used, those values are passed
    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    run.calls = []
    upload

# Generated at 2022-06-12 06:49:21.767056
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.hvcs import upload_to_pypi

    upload_to_pypi()

# Generated at 2022-06-12 06:49:28.831737
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    global username, password, token
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")
    token = os.environ.get("PYPI_TOKEN")

    try:
        run(f"twine upload -u '{username}' -p '{password}' twine")
    except:
        raise (Exception("Could not authenticate in PyPI"))
    try:
        run(f"twine upload -u '{username}' -p '{password}' twine")
    except:
        raise (Exception("Could not authenticate in PyPI"))

# Generated at 2022-06-12 06:49:39.870498
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Uploads a file to PyPI.
    Make sure you don't already have this file uploaded, or the
    test will fail.
    """
    # Create a file to upload
    import tempfile
    import os
    import shutil
    
    try:
        tempdir = tempfile.mkdtemp(prefix='tmp')
        test_file_path = os.path.join(tempdir, 'test_upload.py')
        test_file = open(test_file_path, 'w')
        test_file.write('print("Hello World")')
        test_file.close()
        upload_to_pypi(tempdir, skip_existing=True, glob_patterns=['*'])
    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-12 06:49:41.317578
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(skip_existing=True)

# Generated at 2022-06-12 06:49:42.296554
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:49:43.702394
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("tests/fixtures/python-example/dist")

# Generated at 2022-06-12 06:49:45.035194
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist","*")

# Generated at 2022-06-12 06:50:03.439925
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import os
    import pathlib
    import glob
    import twine.commands.upload

    twine.commands.upload.upload = lambda *args, **kwargs: None

    # Create temporary directory to store test files
    tmpdir = tempfile.mkdtemp()
    # Create temporary files to upload
    try:
        files = ["test1.tar.gz", "test2.tar.gz"]
        for filename in files:
            pathlib.Path(os.path.join(tmpdir, filename)).touch()

        upload_to_pypi(path=tmpdir)
    finally:
        shutil.rmtree(tmpdir)

    twine.commands.upload.upload = twine.commands.upload._upload



# Generated at 2022-06-12 06:50:03.884297
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-12 06:50:12.853830
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.settings import config
    from semantic_release.settings.config import Config

    assert callable(upload_to_pypi)

    os.environ["PYPI_TOKEN"] = "pypi-token"

    try:
        config.update(
            {
                "repository": "dummy",
                "upload_to_pypi": {
                    "skip_existing": True,
                    "glob_patterns": ["*.whl"],
                },
            }
        )
        upload_to_pypi()
    finally:
        config.update(Config)
        del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-12 06:50:19.663204
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import os

    logger.info("Testing function upload_to_pypi")
    path = tempfile.mkdtemp()
    try:
        with open(os.path.join(path, "a"), 'w') as f:
            f.write("a")
        upload_to_pypi(path, True, glob_patterns=["a"])
    finally:
        shutil.rmtree(path)

# Generated at 2022-06-12 06:50:30.623220
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    glob_patterns = ["*"]
    username = "bob"
    token = "pypi-123"
    # Assert that an exception is raised when no credentials are found
    try:
        upload_to_pypi(path, glob_patterns=glob_patterns)
    except ImproperConfigurationError:
        assert True
    else:
        assert False
    # Assert that an exception is raised when no PyPI token is found
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"] = username
    try:
        upload_to_pypi(path, glob_patterns=glob_patterns)
    except ImproperConfigurationError:
        assert True
    else:
        assert False
    # Assert

# Generated at 2022-06-12 06:50:37.150487
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with mock.patch("os.environ", {"PYPI_TOKEN": "pypi-1234567890ABCDEF"}):
        with mock.patch("invoke.run") as mock_run:
            upload_to_pypi(glob_patterns=["*.whl"])
            mock_run.assert_called_once_with(
                'twine upload -u "__token__" -p "pypi-1234567890ABCDEF" "*.whl"'
            )

    with mock.patch("os.environ", {"PYPI_USERNAME": "username", "PYPI_PASSWORD": "password"}):
        with mock.patch("invoke.run") as mock_run:
            upload_to_pypi(glob_patterns=["*.whl"])

# Generated at 2022-06-12 06:50:45.215097
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for upload_to_pypi function
    """

    def run_mock(command):
        """Mock for TwineRun
        """
        return command

    upload_to_pypi.run = run_mock

    # Test proper credentials
    os.environ["PYPI_TOKEN"] = "pypi-mytoken"
    dist = "dist"
    glob_patterns = ["*"]
    skip_existing_param = " --skip-existing"
    dist = '"dist/*"'
    skip_existing_param = ""
    expected_command = f"twine upload -u '__token__' -p 'pypi-mytoken'{skip_existing_param} {dist}"

# Generated at 2022-06-12 06:50:49.625907
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with open("tests/utils/_version.py", "r") as f:
        version = f.read()
    with open("dist/semantic-release-2.0.0.tar.gz", "w") as f:
        f.write(version)
    upload_to_pypi()

# Generated at 2022-06-12 06:51:02.012326
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    global run
    global logger

    # Unit test for function upload_to_pypi

    # Arrange
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.ERROR)
    logger.propagate = False

    def mock_run(command):
        expect(command).to_equal(
            (
                "twine upload -u 'test_user' -p 'test_pass'"
                " -r 'test_repo' --skip-existing"
                " 'dist/semantic_release-1.1.1-py2.py3-none-any.whl'"
            )
        )

    run = mock_run

    # Act

# Generated at 2022-06-12 06:51:03.984285
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Sample test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-12 06:51:27.462253
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """This function is a unit test to ensure that the Twine wrapper works
    """
    os.environ["PYPI_USERNAME"] = "semanticrelease"
    os.environ["PYPI_PASSWORD"] = "semanticrelease"

    try:
        upload_to_pypi()
        assert True
    except:
        assert False

# Generated at 2022-06-12 06:51:31.910961
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-12 06:51:40.498743
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function for upload_to_pypi."""
    assert upload_to_pypi.__name__ == "upload_to_pypi"

    glob_patterns = ["*"]
    upload_to_pypi(path="./dist", skip_existing=True, glob_patterns=glob_patterns)

    glob_patterns = ["*"]
    upload_to_pypi(path="./dist", skip_existing=False, glob_patterns=glob_patterns)

    glob_patterns = ["*-py3-none-any.whl"]
    upload_to_pypi(path="./dist", skip_existing=True, glob_patterns=glob_patterns)

    glob_patterns = ["*-py3-none-any.whl"]
   

# Generated at 2022-06-12 06:51:44.122428
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = 'dist'
    glob_patterns = ["*.tar.gz", "*.whl", "*.gz", "*.zip"]
    upload_to_pypi(path, glob_patterns)

# Generated at 2022-06-12 06:51:44.732756
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:51:51.954368
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    from pathlib import Path

    from invoke.context import Context
    from invoke.runners import Result
    from pytest import fixture
    from semantic_release import ci_cd
    from semantic_release.settings import config

    import semrel_pypi.helpers

    @fixture
    def mocked_result(monkeypatch):
        mocked = Result("", 0, "", "")

        def mock_run(*args, **kwargs):
            return mocked

        monkeypatch.setattr(run, "run", mock_run)
        return mocked

    @fixture
    def mocked_run_with_token(monkeypatch):
        calls = []

        def mock_run(*args, **kwargs):
            calls.append(" ".join(args[0]))


# Generated at 2022-06-12 06:52:01.226782
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile, os, shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    original_working_dir = os.getcwd()
    os.chdir(temp_dir)

    # Create a temporary .pypirc
    f = open(".pypirc", "w+")
    f.write("[pypi]\n")
    f.write("username:chuckycheese\n")
    f.write("password:SuperSecretToken\n")
    f.close()

    # Create some temporary folders and files
    os.mkdir("dist")
    f = open("dist/a.txt", "w+")
    f.close()
    f = open("dist/b.txt", "w+")
    f.close()

    # Upload

# Generated at 2022-06-12 06:52:04.662930
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Verify that package can be uploaded to a remote repository.
    """
    pass



# Generated at 2022-06-12 06:52:13.988080
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest import mock
    from unittest.mock import Mock, patch

    import invoke
    invoke.run = Mock(return_value=None)

    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
    invoke.run.assert_called_once_with('twine upload  --skip-existing "dist/*"')

    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    invoke.run.assert_called_with('twine upload  "dist/*"')

    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=[])
    invoke.run.assert_called_with('twine upload  "dist/*"')

    upload_to_pyp

# Generated at 2022-06-12 06:52:22.730775
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from tempfile import mkdtemp
    from shutil import copy, rmtree
    from filecmp import cmp

    dist = mkdtemp()
    dist_archive = dist + "/archive.whl"
    source_archive = os.path.join(os.path.dirname(__file__), 'fixtures', 'archive.whl')

    if os.path.isfile(dist_archive):
        os.remove(dist_archive)

    copy(source_archive, dist_archive)


# Generated at 2022-06-12 06:53:00.766406
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="/Users/ruben/Repos/twine/dist",
        skip_existing=True,
        glob_patterns=["*"],
    )

# Generated at 2022-06-12 06:53:01.650265
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-12 06:53:02.592192
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert(1)

# Generated at 2022-06-12 06:53:09.840643
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    f = open('./tests/test_files/upload_to_pypi.txt', 'w')

    f.write('Uploading {name} module to PyPI')
    f.close()
    f = open('./tests/test_files/upload_to_pypi_dist.txt', 'w')

    f.write('"dist/{name}-1.0.0-py3-none-any.whl"')
    f.close()

    upload_to_pypi(path="test_files/upload_to_pypi_dist", glob_patterns=['{name}-1.0.0-py3-none-any.whl'])


# Generated at 2022-06-12 06:53:19.509764
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test that no exception is raised if token is provided
    os.environ["PYPI_TOKEN"] = "pypi-secret"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test that no exception is raised if username and password are provided
    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "pwd"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test that no exception is raised if no authentication is provided but a .pypirc file exists
    os.environ["HOME"] = "/"
    upload_to_pypi()
   

# Generated at 2022-06-12 06:53:22.379452
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    upload_to_pypi should return a None object
    """
    ret = upload_to_pypi()
    assert(ret == None)

# Generated at 2022-06-12 06:53:29.065143
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Upload fails if missing username and password
    try:
        upload_to_pypi()
        raise ValueError('Expected ImproperConfigurationError exception.')
    except ImproperConfigurationError as e:
        assert str(e) == 'Missing credentials for uploading to PyPI'

    # Upload fails if given invalid PyPI token
    username = os.environ.get("PYPI_USERNAME")
    os.environ["PYPI_USERNAME"] = ""
    token = "not-a-valid-token"
    password = os.environ.get("PYPI_PASSWORD")
    os.environ["PYPI_PASSWORD"] = ""
    token = os.environ.get("PYPI_TOKEN")
    os.environ["PYPI_TOKEN"] = token

# Generated at 2022-06-12 06:53:33.157846
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        path = "dist"
        for glob_pattern in ["*", "*.whl", "*.gz"]: 
            skip_existing = False
            upload_to_pypi(path, skip_existing, glob_pattern)
    except Exception as e:
        print(e)
# End unit test

# Generated at 2022-06-12 06:53:34.028316
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-12 06:53:46.414595
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # check default args
    assert "twine upload " in upload_to_pypi()
    assert "twine upload " in upload_to_pypi(glob_patterns=["*"])
    assert "twine upload " in upload_to_pypi(path="dist", skip_existing=False)

    # check with glob_patterns
    assert 'twine upload "dist/pattern"' in upload_to_pypi(
        path="dist", glob_patterns=["pattern"]
    )
    assert 'twine upload "dist/pattern1" "dist/pattern2"' in upload_to_pypi(
        path="dist", glob_patterns=["pattern1", "pattern2"]
    )

    # check with skip_existing
    assert "twine upload --skip-existing " in upload_to_p

# Generated at 2022-06-12 06:55:00.801419
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Unitary function, no test
    pass

# Generated at 2022-06-12 06:55:06.238131
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Arrange
    path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) + "/tests/fixtures/dist/"
    glob_patterns = ["*", "*/*.whl"]

    # Act
    upload_to_pypi(path=path, glob_patterns=glob_patterns)

# Generated at 2022-06-12 06:55:17.114345
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch("invoke.run", return_value=None) as _run:
        with patch.dict(os.environ, {}, clear=True):
            upload_to_pypi()
            _run.assert_called_once_with("twine upload  dist/*")

            upload_to_pypi(skip_existing=True)
            _run.assert_called_with("twine upload  --skip-existing dist/*")

        with patch.dict(os.environ, {"PYPI_USERNAME": "username", "PYPI_PASSWORD": "password"}, clear=True):
            upload_to_pypi()
            _run.assert_called_with("twine upload -u 'username' -p 'password' dist/*")


# Generated at 2022-06-12 06:55:27.292633
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import glob
    import time
    import random
    import string
    import shutil
    import zipfile
    import tarfile
    import pathlib
    
    # Setup
    temp_dir = tempfile.mkdtemp()
    tar_file_path = os.path.join(temp_dir, "package.tar.gz")
    zip_file_path = os.path.join(temp_dir, "package.zip")
    with tarfile.open(tar_file_path, "w:gz") as tar:
        test_dir = os.path.join(temp_dir, "test")
        pathlib.Path(test_dir).mkdir(parents=True, exist_ok=True) 

# Generated at 2022-06-12 06:55:31.589730
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """This function is called by the Travis build to verify that the function upload_to_pypi
    throws the desired error if no credentials are available.
    """
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert str(e) == "Missing credentials for uploading to PyPI"

# Generated at 2022-06-12 06:55:36.537837
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from packaging.version import parse
    from distutils.version import LooseVersion
    version_string = parse(__version__).base_version
    version = LooseVersion(version_string)
    assert version >= LooseVersion("0.18.0")

# Generated at 2022-06-12 06:55:43.794973
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with glob patterns
    glob_patterns = ["*.whl", "*.zip", "*.tar.gz"]
    try:
        upload_to_pypi("dist", glob_patterns=glob_patterns)
    except Exception as e:
        raise AssertionError("upload_to_pypi FAILED") from e

    # Test without glob patterns
    try:
        upload_to_pypi("dist")
    except Exception as e:
        raise AssertionError("upload_to_pypi FAILED") from e


# Generated at 2022-06-12 06:55:54.418222
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from unittest.mock import Mock, patch

    from semantic_release.settings import config
    from semantic_release.settings import set_config_value


# Generated at 2022-06-12 06:55:54.873425
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-12 06:55:56.731361
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist")