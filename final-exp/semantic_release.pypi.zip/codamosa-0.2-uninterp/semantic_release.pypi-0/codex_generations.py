

# Generated at 2022-06-18 03:17:29.993328
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:30.633948
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:17:31.549307
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:32.438590
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:34.555176
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:35.418526
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:36.811370
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:17:37.697518
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:45.859479
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile
    import unittest

    from semantic_release.settings import config

    class TestUploadToPyPI(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, "test.txt")
            with open(self.temp_file, "w") as f:
                f.write("test")

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_upload_to_pypi_with_token(self):
            os.environ["PYPI_TOKEN"] = "pypi-test"

# Generated at 2022-06-18 03:17:48.487174
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:17:57.855501
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:58.869710
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:00.584417
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:02.227158
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:04.877877
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:05.578222
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:18:06.678159
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:07.886726
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:08.499446
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:18:09.743628
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:29.849824
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:18:30.677516
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:18:32.060239
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:32.967415
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:34.930450
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:36.035050
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"]) == None

# Generated at 2022-06-18 03:18:37.580930
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:18:38.869573
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:44.949270
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload  'dist/*'"

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload  --skip-existing 'dist/*'"

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*.whl"])
        assert mock.called

# Generated at 2022-06-18 03:18:45.947245
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:19.910825
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:20.729961
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:21.678758
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:27.436911
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that upload_to_pypi function works as expected
    """
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import json
    import requests

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.write(b"Hello World")
    temp_file.close()

    # Create a temporary .pypirc file
    temp_pypirc = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)

# Generated at 2022-06-18 03:19:36.039484
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    from unittest.mock import patch

    with patch("invoke.run") as mock_run:
        upload_to_pypi("dist", True, ["*"])
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' --skip-existing 'dist/*'"
        )

    with patch("invoke.run") as mock_run:
        upload_to_pypi("dist", False, ["*"])
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
        )

    with patch("invoke.run") as mock_run:
        upload_to_p

# Generated at 2022-06-18 03:19:38.160988
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:39.407908
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:44.181356
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    from .helpers import mocked_run

    with mocked_run() as mocked:
        upload_to_pypi(
            path="dist",
            skip_existing=True,
            glob_patterns=["*.whl", "*.tar.gz"],
        )
        mocked.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' --skip-existing 'dist/*.whl' 'dist/*.tar.gz'"
        )

# Generated at 2022-06-18 03:19:44.775018
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:45.800593
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:54.625417
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:55.697602
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:56.273932
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:58.271942
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:07.486863
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from semantic_release.settings import config
    from semantic_release.hvcs.git import get_repository_owner
    from semantic_release.hvcs.git import get_repository_name
    from semantic_release.hvcs.git import get_repository_url

    config["repository"] = get_repository_url()
    config["repository_owner"] = get_repository_owner()
    config["repository_name"] = get_repository_name()

    with patch("invoke.run") as mock_run:
        upload_to_pypi()

# Generated at 2022-06-18 03:21:08.896007
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:10.710334
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:11.469537
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:12.168418
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:13.861690
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:23:53.910040
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:23:54.698000
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:23:55.947860
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:23:56.691558
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    upload_to_pypi()

# Generated at 2022-06-18 03:23:57.905255
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:23:58.609634
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:23:59.268987
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:24:00.604298
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:24:02.042728
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:24:03.242240
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()