

# Generated at 2022-06-18 03:17:42.737068
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from unittest import TestCase

    class TestUploadToPyPI(TestCase):
        def setUp(self):
            self.path = "dist"
            self.skip_existing = False
            self.glob_patterns = ["*"]
            self.token = "pypi-token"
            self.username = "username"
            self.password = "password"
            self.repository = "test"
            self.dist = '"dist/*"'


# Generated at 2022-06-18 03:17:43.997088
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:44.626103
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:49.965792
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from semantic_release.settings import config

    with patch("invoke.run") as mock_run:
        config.set("repository", "test")
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-test' -r 'test' --skip-existing 'dist/*'"
        )

# Generated at 2022-06-18 03:17:53.686691
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:55.682250
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:17:59.400794
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:00.416226
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:08.016203
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function.
    """
    from .helpers import mock_run
    from .helpers import mock_run_fail
    from .helpers import mock_run_success

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    mock_run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
    )
    mock_run.reset_mock()

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
   

# Generated at 2022-06-18 03:18:09.029117
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:14.426863
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:23.609067
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from semantic_release.settings import config
    from semantic_release.settings import load_config
    from semantic_release.settings import update_config
    from semantic_release.settings import validate_config
    from semantic_release.settings import validate_config_file
    from semantic_release.settings import validate_config_repository
    from semantic_release.settings import validate_config_version_source
    from semantic_release.settings import validate_config_version_scheme
    from semantic_release.settings import validate_config_version_formats
    from semantic_release.settings import validate_config_version_format
    from semantic_release.settings import validate_config_version_format_regex
    from semantic_release.settings import validate_config_version_format_regex_group

# Generated at 2022-06-18 03:18:31.431738
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockRun
    from .helpers import mock_run_factory

    with mock_run_factory(MockRun) as mock_run:
        upload_to_pypi()
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-123' 'dist/*'"
        )

        mock_run.reset_mock()
        upload_to_pypi(skip_existing=True)
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-123' --skip-existing 'dist/*'"
        )

        mock_run.reset_mock()

# Generated at 2022-06-18 03:18:32.293513
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:33.681207
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:34.557516
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:35.990872
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:36.765181
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:37.740092
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:46.121931
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    # pylint: disable=protected-access
    from .helpers import MockContext
    from .helpers import MockRun

    ctx = MockContext()
    ctx.run = MockRun()

    upload_to_pypi(ctx)
    assert ctx.run.call_count == 1
    assert ctx.run.call_args[0][0] == "twine upload  *"

    ctx.run.reset_mock()
    upload_to_pypi(ctx, "dist", True, ["*"])
    assert ctx.run.call_count == 1
    assert ctx.run.call_args[0][0] == "twine upload  --skip-existing *"

    ctx.run.reset_mock()
   

# Generated at 2022-06-18 03:18:56.201023
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:00.917494
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-test-token"
    upload_to_pypi()
    assert os.environ["PYPI_TOKEN"] == "pypi-test-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "test-username"
    os.environ["PYPI_PASSWORD"] = "test-password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "test-username"
    assert os.environ["PYPI_PASSWORD"] == "test-password"
    del os

# Generated at 2022-06-18 03:19:03.149143
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:19:04.785498
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:19:05.921957
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:15.969156
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    from .helpers import mock_run

    with mock_run() as mocked_run:
        upload_to_pypi()
        mocked_run.assert_called_once_with("twine upload  'dist/*'")

    with mock_run() as mocked_run:
        upload_to_pypi(skip_existing=True)
        mocked_run.assert_called_once_with("twine upload  --skip-existing 'dist/*'")

    with mock_run() as mocked_run:
        upload_to_pypi(glob_patterns=["*.whl", "*.tar.gz"])

# Generated at 2022-06-18 03:19:24.468150
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    """
    from .helpers import LoggedFunction
    from .helpers import mock_run
    from .helpers import mock_run_fail
    from .helpers import mock_run_success
    from .helpers import mock_run_success_with_output
    from .helpers import mock_run_with_output
    from .helpers import mock_run_with_output_fail
    from .helpers import mock_run_with_output_success
    from .helpers import mock_run_with_output_success_with_output
    from .helpers import mock_run_with_output_success_with_output_fail
    from .helpers import mock_run_with_output_success_with_output_success
    from .helpers import mock_run_with_

# Generated at 2022-06-18 03:19:25.196608
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:27.134323
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:28.103978
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:48.033724
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:49.019590
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:50.190851
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-18 03:19:52.405565
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:19:53.175770
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:53.777686
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:19:54.449906
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:55.141684
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:57.257711
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:19:58.667230
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:33.133855
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:35.621920
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:36.369557
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:37.633364
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:20:40.485540
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:20:41.243743
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:50.038823
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function
    """
    import tempfile
    import shutil
    import os
    from invoke import run
    from semantic_release.settings import config
    from semantic_release.hvcs.git import get_repo_url
    from semantic_release.hvcs.git import get_repo_owner
    from semantic_release.hvcs.git import get_repo_name
    from semantic_release.hvcs.git import get_repo_hostname
    from semantic_release.hvcs.git import get_repo_hostname_url
    from semantic_release.hvcs.git import get_repo_hostname_url_with_auth
    from semantic_release.hvcs.git import get_repo_hostname_url_with_auth_

# Generated at 2022-06-18 03:20:50.781680
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:20:51.471764
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:52.520832
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:22:16.931582
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:18.602118
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:22:20.532169
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:22:21.303911
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:23.590445
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function.
    """
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:24.381102
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:25.152381
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:22:26.472929
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:27.206156
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:38.376894
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    with mock_run() as mock:
        upload_to_pypi()
        assert mock.called
        assert mock.call_args[0][0] == "twine upload *"

    with mock_run() as mock:
        upload_to_pypi(path="foo")
        assert mock.called
        assert mock.call_args[0][0] == "twine upload 'foo/*'"

    with mock_run() as mock:
        upload_to_pypi(glob_patterns=["foo", "bar"])
        assert mock.called
        assert mock.call_args[0][0] == 'twine upload "dist/foo" "dist/bar"'


# Generated at 2022-06-18 03:25:27.951048
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:25:28.747481
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:29.512422
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:30.280312
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:32.687239
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:33.321225
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:41.247165
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function.
    """
    from .helpers import mock_run

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    mock_run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
    )

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

# Generated at 2022-06-18 03:25:43.198783
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:25:44.758696
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:52.586457
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with username and password and repository
    os.environ["PYPI_USERNAME"] = "username"