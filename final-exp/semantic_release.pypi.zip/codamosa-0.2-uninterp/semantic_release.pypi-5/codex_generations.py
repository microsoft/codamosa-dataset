

# Generated at 2022-06-18 03:17:28.733028
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:37.771457
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

# Generated at 2022-06-18 03:17:38.911593
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:40.058572
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:41.092413
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:42.747470
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:44.468370
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:45.174277
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:45.834869
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:48.487334
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:57.856531
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:05.893688
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile

    from semantic_release.settings import config

    def _create_temp_dir(dir_name):
        dir_path = os.path.join(temp_dir, dir_name)
        os.makedirs(dir_path)
        return dir_path

    def _create_temp_file(file_name, dir_name=None):
        file_path = os.path.join(temp_dir, dir_name, file_name) if dir_name else os.path.join(temp_dir, file_name)
        with open(file_path, "w") as f:
            f.write("")
        return file_path


# Generated at 2022-06-18 03:18:06.536042
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:08.216585
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:09.028981
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:10.144725
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:12.246659
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:14.108302
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:14.974593
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:15.776249
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:24.924484
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:32.301688
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    from .helpers import mock_run
    from .helpers import mock_os

    # Test with token
    mock_os.environ = {"PYPI_TOKEN": "pypi-token"}
    upload_to_pypi()
    assert mock_run.call_count == 1
    assert mock_run.call_args[0][0] == "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"

    # Test with username and password
    mock_os.environ = {"PYPI_USERNAME": "username", "PYPI_PASSWORD": "password"}
    upload_to_pypi()
    assert mock_run.call_count == 2
    assert mock_run.call_

# Generated at 2022-06-18 03:18:34.055744
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    upload_to_pypi()

# Generated at 2022-06-18 03:18:34.941945
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:35.526324
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:36.333023
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:37.182334
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:38.090665
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:18:39.486545
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:40.510883
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:59.211612
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:00.020205
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:02.452516
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:03.441589
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:14.074371
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "__token__"
    assert os.environ["PYPI_PASSWORD"] == "pypi-token"

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"

    # Test with repository

# Generated at 2022-06-18 03:19:14.866230
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:19.881375
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with username and password
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-test_token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with repository
    os.environ["PYPI_TOKEN"] = "pypi-test_token"
    upload_to_pypi(repository="test_repository")

# Generated at 2022-06-18 03:19:21.366888
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:19:27.285467
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with repository
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"


# Generated at 2022-06-18 03:19:28.714863
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:07.566297
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:08.542569
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:09.992045
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:11.880209
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:20:13.967177
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:16.253691
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:20:17.161978
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:18.840286
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:20:19.809854
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:21.450873
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:45.793731
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_TOKEN"] == "pypi-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "pypi-username"
    os.environ["PYPI_PASSWORD"] = "pypi-password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "pypi-username"

# Generated at 2022-06-18 03:21:46.413188
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:53.402455
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_TOKEN"] == "pypi-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"
    del os.environ["PYPI_USERNAME"]

# Generated at 2022-06-18 03:21:53.962655
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:55.177132
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:21:55.830248
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:56.690210
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:57.512332
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:59.121695
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:22:07.030862
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch, Mock
    from semantic_release.settings import config
    from semantic_release.hvcs import get_repository_url

    config["repository"] = get_repository_url()
    config["repository"]["url"] = "https://github.com/relekang/python-semantic-release"
    config["repository"]["type"] = "git"

    with patch("invoke.run") as run_mock:
        upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-18 03:24:53.056993
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-123456789"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with repository
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

# Generated at 2022-06-18 03:24:59.582176
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for upload_to_pypi function
    """
    from .helpers import mock_run, mock_config

    mock_config(
        {
            "repository": "test_repository",
            "pypi_username": "test_username",
            "pypi_password": "test_password",
        }
    )
    mock_run.return_value = None
    upload_to_pypi()
    mock_run.assert_called_with(
        "twine upload -u 'test_username' -p 'test_password' -r 'test_repository' 'dist/*'"
    )

# Generated at 2022-06-18 03:25:00.383059
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:01.694714
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:25:02.444247
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:03.832532
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:25:04.549106
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:05.283410
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:25:05.958085
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-18 03:25:08.943660
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])