

# Generated at 2022-06-18 03:17:31.504901
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-18 03:17:32.398995
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:33.495951
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:34.753406
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:37.509086
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:39.317317
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:40.665857
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:17:47.582679
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    from unittest.mock import patch
    from unittest import mock

    with patch("invoke.run") as mock_run:
        upload_to_pypi()
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
        )

    with patch("invoke.run") as mock_run:
        upload_to_pypi(glob_patterns=["*.whl"])
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' 'dist/*.whl'"
        )

    with patch("invoke.run") as mock_run:
        upload_

# Generated at 2022-06-18 03:17:48.605844
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:50.388267
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:02.435519
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:04.879090
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:05.832533
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:06.476595
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:07.378783
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:18:12.180780
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "__token__"
    assert os.environ["PYPI_PASSWORD"] == "pypi-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"

# Generated at 2022-06-18 03:18:13.348177
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:14.287185
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:15.126679
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:15.930545
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:32.276829
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run
    from .helpers import mock_run_fail
    from .helpers import mock_run_success
    from .helpers import mock_run_output

    # Test with no glob patterns
    mock_run_success()
    upload_to_pypi()
    assert mock_run.call_count == 1
    assert mock_run.call_args[0][0] == "twine upload 'dist/*'"

    # Test with glob patterns
    mock_run_success()
    upload_to_pypi(glob_patterns=["*.whl", "*.tar.gz"])
    assert mock_run.call_count == 2
    assert mock_run.call_args[0][0] == "twine upload 'dist/*.whl' 'dist/*.tar.gz'"

   

# Generated at 2022-06-18 03:18:33.680682
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:34.557614
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:35.390723
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:36.796234
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:38.356517
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:18:39.122330
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:40.237700
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-18 03:18:41.161485
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:45.984316
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    from .helpers import mock_run

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"

# Generated at 2022-06-18 03:19:14.073755
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    from .helpers import mock_run

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload  'dist/*'"

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload  --skip-existing 'dist/*'"


# Generated at 2022-06-18 03:19:22.758575
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that upload_to_pypi function works as expected.
    """
    # Test that upload_to_pypi raises an exception if no credentials are provided
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        assert False, "Should have raised an exception"

    # Test that upload_to_pypi raises an exception if token does not start with "pypi-"
    try:
        upload_to_pypi(token="not-pypi-token")
    except ImproperConfigurationError:
        pass
    else:
        assert False, "Should have raised an exception"

    # Test that upload_to_pypi raises an exception if username is not provided

# Generated at 2022-06-18 03:19:23.434079
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:33.311881
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-1234567890"
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    mock_run.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-1234567890' 'dist/*'"
    )
    mock_run.reset_mock()

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

# Generated at 2022-06-18 03:19:34.090416
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:35.359814
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:36.072766
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:38.689251
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:40.170023
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:19:40.874972
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:27.351103
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that upload_to_pypi() works as expected.
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir)

    # Create a temporary .pypirc file
    temp_pypirc = tempfile.NamedTemporaryFile(dir=temp_dir)

    # Write to the .pypirc file

# Generated at 2022-06-18 03:20:27.881527
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:20:28.841136
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:30.396624
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:31.233488
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:32.040953
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:32.837928
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:34.202650
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:35.542656
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:36.314869
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:22:01.273981
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:02.108067
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:22:03.257451
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:22:03.965303
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:05.116902
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:06.114524
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:06.676549
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:16.772601
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that upload_to_pypi() works as expected.
    """
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Write some data to the temporary file
    temp_file.write(b"some data")
    temp_file.close()
    # Get the name of the temporary file
    temp_file_name = os.path.basename(temp_file.name)

    # Create a temporary directory for the dist
    temp_dist_dir = tempfile.mkdtemp()
    # Create a temporary file in the dist

# Generated at 2022-06-18 03:22:17.850401
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:18.638560
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:09.176582
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:25:10.184996
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:11.477556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:13.238668
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:13.945879
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:19.720910
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == 'twine upload -u \'__token__\' -p \'pypi-token\' "dist/*"'

# Generated at 2022-06-18 03:25:27.769594
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    import os
    import shutil
    import tempfile
    import unittest

    from semantic_release.settings import config

    class TestUploadToPyPI(unittest.TestCase):
        """Test upload_to_pypi function"""

        def setUp(self):
            """Setup test environment"""
            self.tempdir = tempfile.mkdtemp()
            self.distdir = os.path.join(self.tempdir, "dist")
            os.mkdir(self.distdir)
            self.pypirc = os.path.join(self.tempdir, ".pypirc")

# Generated at 2022-06-18 03:25:33.607512
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    # pylint: disable=import-outside-toplevel
    from .helpers import mock_run
    from .helpers import mock_exists
    from .helpers import mock_isfile
    from .helpers import mock_getenv
    from .helpers import mock_getcwd
    from .helpers import mock_chdir
    from .helpers import mock_listdir
    from .helpers import mock_isfile
    from .helpers import mock_isdir
    from .helpers import mock_join
    from .helpers import mock_abspath
    from .helpers import mock_getcwd
    from .helpers import mock_getenv
    from .helpers import mock_isfile
    from .helpers import mock_isdir


# Generated at 2022-06-18 03:25:34.268561
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:34.934499
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()