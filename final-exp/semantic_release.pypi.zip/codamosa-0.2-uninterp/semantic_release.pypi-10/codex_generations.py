

# Generated at 2022-06-18 03:17:30.044255
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:17:31.103243
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:32.668681
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"]) == None

# Generated at 2022-06-18 03:17:42.837716
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi
    """
    from .helpers import mock_run

    with mock_run() as run_mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert run_mock.call_count == 1
        assert run_mock.call_args[0][0] == "twine upload  \"dist/*\""

    with mock_run() as run_mock:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
        assert run_mock.call_count == 1
        assert run_mock.call_args[0][0] == "twine upload  --skip-existing \"dist/*\""


# Generated at 2022-06-18 03:17:43.561610
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:44.622907
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:45.186302
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:46.077990
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:48.487492
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:57.619875
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with repository
    os.environ["PYPI_TOKEN"] = "pypi-token"

# Generated at 2022-06-18 03:18:08.376411
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:09.134059
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:09.817218
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:10.552345
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True, ["*"])

# Generated at 2022-06-18 03:18:12.302556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:18:13.422847
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:13.953216
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-18 03:18:15.125957
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: add unit test for function upload_to_pypi
    pass

# Generated at 2022-06-18 03:18:15.932572
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:25.222288
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with missing credentials
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-18 03:18:35.352973
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:18:36.133308
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:37.660940
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:46.123131
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run, mock_config

    with mock_run() as run_mock, mock_config(
        {
            "repository": "test-repo",
            "pypi_token": "pypi-test-token",
            "pypi_username": "test-username",
            "pypi_password": "test-password",
        }
    ):
        upload_to_pypi(path="test-path", skip_existing=True, glob_patterns=["test-glob"])
        run_mock.assert_called_once_with(
            "twine upload -u 'test-username' -p 'test-password' -r 'test-repo' --skip-existing 'test-path/test-glob'"
        )


# Generated at 2022-06-18 03:18:47.044747
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:48.556472
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:50.701439
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:52.086586
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:59.109028
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    mock_run.return_value = None
    upload_to_pypi()
    mock_run.assert_called_once_with("twine upload  'dist/*'")

    mock_run.reset_mock()
    upload_to_pypi(path="my_dist", skip_existing=True, glob_patterns=["*", "*.whl"])
    mock_run.assert_called_once_with(
        "twine upload  --skip-existing 'my_dist/*' 'my_dist/*.whl'"
    )

    mock_run.reset_mock()

# Generated at 2022-06-18 03:18:59.942042
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:19.324820
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:20.149586
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:20.966194
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:21.880153
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:23.199456
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:23.874609
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:24.595942
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:25.329937
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:27.330121
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:28.257950
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:11.020620
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:12.412685
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:13.923539
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:16.209827
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:25.085969
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function.
    """
    from .helpers import mock_run

    with mock_run() as run_mock:
        upload_to_pypi()
        assert run_mock.call_count == 1
        assert run_mock.call_args[0][0] == "twine upload 'dist/*'"

    with mock_run() as run_mock:
        upload_to_pypi(glob_patterns=["*.whl"])
        assert run_mock.call_count == 1
        assert run_mock.call_args[0][0] == "twine upload 'dist/*.whl'"

    with mock_run() as run_mock:
        upload_to_pypi(skip_existing=True)
        assert run_

# Generated at 2022-06-18 03:20:26.655171
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:27.555853
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:28.395315
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:29.549874
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    upload_to_pypi()

# Generated at 2022-06-18 03:20:31.651285
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:22:03.551238
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with repository
    os.environ["PYPI_TOKEN"] = "pypi-token"

# Generated at 2022-06-18 03:22:04.189622
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:05.779749
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:06.539196
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Add unit test for function upload_to_pypi
    pass

# Generated at 2022-06-18 03:22:07.277923
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    upload_to_pypi()

# Generated at 2022-06-18 03:22:08.735815
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:10.280251
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:12.582695
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:14.211516
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:15.708811
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:14.874459
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:15.638669
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:16.375188
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:19.171526
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:20.692390
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:25:21.508923
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:23.149063
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    upload_to_pypi()

# Generated at 2022-06-18 03:25:23.668661
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:25:24.529587
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Add unit test
    pass

# Generated at 2022-06-18 03:25:31.800171
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run
    from .helpers import mock_open
    from .helpers import mock_isfile
    from .helpers import mock_environ

    with mock_environ({"PYPI_TOKEN": "pypi-token"}):
        with mock_isfile(True):
            with mock_open():
                with mock_run():
                    upload_to_pypi()

    with mock_environ({"PYPI_USERNAME": "username", "PYPI_PASSWORD": "password"}):
        with mock_isfile(True):
            with mock_open():
                with mock_run():
                    upload_to_pypi()
