

# Generated at 2022-06-18 03:17:40.561735
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "__token__"
    assert os.environ["PYPI_PASSWORD"] == "pypi-token"
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()

# Generated at 2022-06-18 03:17:42.702006
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:17:48.087845
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with no credentials
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-18 03:17:49.924337
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:53.689491
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:55.128741
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:58.836182
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:00.008830
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:01.373763
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:04.879001
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:15.027170
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:16.456383
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:18.022492
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:19.565823
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:28.363175
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockRun

    with MockRun() as mock_run:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert mock_run.call_count == 1
        assert mock_run.call_args[0][0] == "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"

    with MockRun() as mock_run:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
        assert mock_run.call_count == 1
        assert mock_run.call_args[0][0] == "twine upload -u '__token__' -p 'pypi-token' --skip-existing 'dist/*'"


# Generated at 2022-06-18 03:18:29.977221
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-18 03:18:30.792500
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:32.740838
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:34.137439
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:36.504901
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with no glob patterns
    upload_to_pypi(glob_patterns=[])
    # Test with glob patterns
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-18 03:18:55.750081
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:56.539875
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:18:57.280556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:58.260336
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:59.364853
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:01.247927
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:02.653045
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:03.661060
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:14.223268
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    from .helpers import mock_run

    with mock_run() as run_mock:
        upload_to_pypi()
        run_mock.assert_called_once_with(
            "twine upload  'dist/*'", hide=True, warn=True
        )

    with mock_run() as run_mock:
        upload_to_pypi(
            path="dist",
            skip_existing=True,
            glob_patterns=["*.whl", "*.tar.gz"],
        )

# Generated at 2022-06-18 03:19:15.008962
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:57.621657
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:58.422982
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:59.171527
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:01.661030
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:20:03.688281
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"]) == None

# Generated at 2022-06-18 03:20:05.078200
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:05.996481
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:07.023906
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:15.239429
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    from .helpers import mock_run

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload 'dist/*'"

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*", "*.tar.gz"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload 'dist/*' 'dist/*.tar.gz'"


# Generated at 2022-06-18 03:20:16.786183
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:51.152131
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that the upload_to_pypi function works as expected
    """
    from .helpers import MockRun
    from .helpers import MockEnv

    # Test that the function raises an error if no credentials are provided
    with MockEnv({}):
        try:
            upload_to_pypi()
            assert False, "Should have raised an error"
        except ImproperConfigurationError:
            pass

    # Test that the function raises an error if a token is provided that doesn't start with 'pypi-'
    with MockEnv({"PYPI_TOKEN": "not-a-token"}):
        try:
            upload_to_pypi()
            assert False, "Should have raised an error"
        except ImproperConfigurationError:
            pass

    # Test that the function uses the token if it is

# Generated at 2022-06-18 03:21:52.447248
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:21:53.536907
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:54.092659
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:55.830530
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:56.691139
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:58.065053
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    assert upload_to_pypi()

# Generated at 2022-06-18 03:21:59.512736
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:01.207202
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:02.051417
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:02.516280
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:03.412442
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:13.600666
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "__token__"
    assert os.environ["PYPI_PASSWORD"] == "pypi-token"

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"

    # Test with no token or username

# Generated at 2022-06-18 03:25:14.779785
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:25:16.081549
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:18.765676
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:19.638301
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:21.121785
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:22.761796
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:25:23.589112
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()