

# Generated at 2022-06-18 03:17:30.688389
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:32.312916
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:17:33.685298
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    upload_to_pypi()

# Generated at 2022-06-18 03:17:43.631617
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    with mock_run() as mocked_run:
        upload_to_pypi(
            path="dist",
            skip_existing=False,
            glob_patterns=["*.whl", "*.tar.gz"],
        )
        mocked_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' 'dist/*.whl' 'dist/*.tar.gz'"
        )

    with mock_run() as mocked_run:
        upload_to_pypi(
            path="dist",
            skip_existing=True,
            glob_patterns=["*.whl", "*.tar.gz"],
        )

# Generated at 2022-06-18 03:17:44.622980
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:17:45.796711
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:17:48.487256
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:49.688688
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-18 03:17:50.453481
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:54.820891
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:06.755458
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:18:07.615863
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:08.511882
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:09.285660
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:19.630523
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi.
    """
    # Test for missing credentials
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True

    # Test for missing repository
    os.environ["PYPI_TOKEN"] = "pypi-token"
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True

    # Test for invalid token
    os.environ["PYPI_TOKEN"] = "token"
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True

    # Test for valid token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    os

# Generated at 2022-06-18 03:18:28.398034
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    import tempfile
    import shutil
    import os
    import glob

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.write(b"test")
    temp_file.close()

    # Create a temporary dist folder
    dist_dir = os.path.join(temp_dir, "dist")
    os.mkdir(dist_dir)

    # Copy the temporary file to the dist folder
    shutil.copy(temp_file.name, dist_dir)

    # Test upload_to_pypi

# Generated at 2022-06-18 03:18:30.601387
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:31.944703
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:33.972000
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:34.849266
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:52.453018
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:58.333482
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    from .helpers import mock_run

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi(glob_patterns=["*"])
    mock_run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-token' '*'"
    )

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-18 03:18:59.443044
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:00.233615
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:01.554238
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:12.906886
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run
    from .helpers import mock_run_fail
    from .helpers import mock_run_success
    from .helpers import mock_run_output

    # Test that it fails if no credentials are provided
    with mock_run_fail():
        upload_to_pypi()

    # Test that it fails if token is not prefixed with "pypi-"
    with mock_run_fail():
        upload_to_pypi(token="bad-token")

    # Test that it fails if username is not provided
    with mock_run_fail():
        upload_to_pypi(password="password")

    # Test that it fails if password is not provided
    with mock_run_fail():
        upload_to_pypi(username="username")

    # Test that it fails if username

# Generated at 2022-06-18 03:19:13.315005
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:14.754190
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:15.330029
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-18 03:19:16.106216
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:53.359960
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:02.716907
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run
    from unittest.mock import patch

    with patch("invoke.run", mock_run):
        upload_to_pypi()
        assert mock_run.call_args[0][0] == "twine upload  'dist/*'"

    with patch("invoke.run", mock_run):
        upload_to_pypi(skip_existing=True)
        assert mock_run.call_args[0][0] == "twine upload  --skip-existing 'dist/*'"

    with patch("invoke.run", mock_run):
        upload_to_pypi(glob_patterns=["*.whl"])
        assert mock_run.call_args[0][0] == 'twine upload  "dist/*.whl"'


# Generated at 2022-06-18 03:20:03.560299
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:04.399714
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:13.995980
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    from .helpers import mock_run
    from .helpers import mock_run_failure
    from .helpers import mock_run_success

    # Test missing credentials
    with mock_run_failure():
        upload_to_pypi()

    # Test missing token
    with mock_run_failure():
        upload_to_pypi(username="user", password="pass")

    # Test missing username and password
    with mock_run_failure():
        upload_to_pypi(token="pypi-token")

    # Test token without pypi- prefix
    with mock_run_failure():
        upload_to_pypi(token="token")

    # Test successful upload

# Generated at 2022-06-18 03:20:24.046351
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    from .helpers import mock_run

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi(glob_patterns=["*"])
    mock_run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-token' '*'"
    )

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "pypi-username"
    os.environ["PYPI_PASSWORD"] = "pypi-password"
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-18 03:20:25.900163
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:26.744862
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:27.676654
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:28.650965
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:49.299384
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:51.117754
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:52.412573
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:21:53.509366
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:55.044958
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:21:55.715481
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:57.216866
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:57.949143
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:00.977753
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:01.809960
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:24:53.232159
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "__token__"
    assert os.environ["PYPI_PASSWORD"] == "pypi-token"

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"

    # Test with no credentials
   

# Generated at 2022-06-18 03:24:54.123831
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:24:54.962919
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:24:55.556771
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:24:56.926109
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:24:57.877410
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:24:58.672338
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:24:59.361409
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:00.793736
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:02.678792
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()