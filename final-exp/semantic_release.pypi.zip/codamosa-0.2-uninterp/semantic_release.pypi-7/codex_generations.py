

# Generated at 2022-06-18 03:17:27.022476
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    upload_to_pypi()

# Generated at 2022-06-18 03:17:28.366607
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:29.865062
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:39.993421
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_TOKEN"] == "pypi-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"
    del os.environ["PYPI_USERNAME"]

# Generated at 2022-06-18 03:17:40.865052
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:17:46.756953
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_TOKEN"] == "pypi-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"
    del os.environ["PYPI_USERNAME"]

# Generated at 2022-06-18 03:17:56.536864
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    from .helpers import mock_run

    with mock_run() as run_mock:
        upload_to_pypi("dist", True, ["*"])
        run_mock.assert_called_once_with(
            'twine upload  --skip-existing "dist/*"'
        )

    with mock_run() as run_mock:
        upload_to_pypi("dist", False, ["*"])
        run_mock.assert_called_once_with(
            'twine upload  "dist/*"'
        )

    with mock_run() as run_mock:
        upload_to_pypi("dist", True, ["*.whl"])

# Generated at 2022-06-18 03:17:58.833896
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:00.005348
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:00.718073
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:13.994873
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:15.776981
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"]) == None

# Generated at 2022-06-18 03:18:23.107299
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function.
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Upload the file
    upload_to_pypi(temp_dir, glob_patterns=[os.path.basename(temp_file.name)])

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 03:18:31.049425
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "__token__"
    assert os.environ["PYPI_PASSWORD"] == "pypi-token"

    # Test with username and password
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"

    # Test with no credentials

# Generated at 2022-06-18 03:18:39.212578
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run
    from semantic_release.settings import config

    config.update(
        {
            "repository": "test_repo",
            "pypi_username": "test_user",
            "pypi_password": "test_pass",
        }
    )

    upload_to_pypi(
        path="test_path",
        skip_existing=True,
        glob_patterns=["test_glob_pattern"],
    )

    mock_run.assert_called_once_with(
        "twine upload -u 'test_user' -p 'test_pass' -r 'test_repo' --skip-existing 'test_path/test_glob_pattern'"
    )

# Generated at 2022-06-18 03:18:40.949534
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:41.897117
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-18 03:18:42.655440
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:48.589158
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    from .helpers import mock_run
    from .helpers import mock_env
    from .helpers import mock_open
    from .helpers import mock_isfile
    from .helpers import mock_exists
    from .helpers import mock_join
    from .helpers import mock_get
    from .helpers import mock_getcwd
    from .helpers import mock_chdir
    from .helpers import mock_listdir
    from .helpers import mock_isfile
    from .helpers import mock_isdir
    from .helpers import mock_walk
    from .helpers import mock_isfile
    from .helpers import mock_isfile
    from .helpers import mock_isfile
    from .helpers import mock_isfile


# Generated at 2022-06-18 03:18:50.071815
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:59.828889
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:02.096941
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:19:04.031603
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:19:05.840423
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:15.897850
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_TOKEN"] == "pypi-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"
    del os.environ["PYPI_USERNAME"]

# Generated at 2022-06-18 03:19:17.475403
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:18.702483
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-18 03:19:19.522491
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:20.979131
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:22.406831
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:40.920455
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:41.593583
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:42.788286
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:48.786697
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with repository
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi(repository="test")

# Generated at 2022-06-18 03:19:49.926872
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:19:52.187243
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:19:52.913409
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:58.717699
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-test-token"
    upload_to_pypi()
    assert os.environ["PYPI_TOKEN"] == "pypi-test-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "test-username"
    os.environ["PYPI_PASSWORD"] = "test-password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "test-username"
    assert os.environ["PYPI_PASSWORD"] == "test-password"
    del os.environ["PYPI_USERNAME"]

# Generated at 2022-06-18 03:20:01.201188
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:20:02.326735
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:35.731912
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:36.470018
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:37.984559
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:39.951736
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:41.318665
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:20:42.915709
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:51.345371
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["TWINE_USERNAME"] == "__token__"
    assert os.environ["TWINE_PASSWORD"] == "pypi-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["TWINE_USERNAME"] == "username"
    assert os.environ["TWINE_PASSWORD"] == "password"

# Generated at 2022-06-18 03:20:52.950114
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:54.459514
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:21:03.018532
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    from .helpers import mock_run

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        mock.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
        )

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
        mock.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' --skip-existing 'dist/*'"
        )


# Generated at 2022-06-18 03:22:24.518433
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:25.876461
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:36.492479
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    with mock_run() as mocked_run:
        upload_to_pypi()
        mocked_run.assert_called_once_with("twine upload  *")

    with mock_run() as mocked_run:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
        mocked_run.assert_called_once_with("twine upload  --skip-existing *")

    with mock_run() as mocked_run:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*", "*.whl"])
        mocked_run.assert_called_once_with("twine upload  --skip-existing '*' '*.whl'")


# Generated at 2022-06-18 03:22:38.221859
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:39.517747
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:22:49.486723
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    from .helpers import mock_run

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload --skip-existing 'dist/*'"

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload 'dist/*'"


# Generated at 2022-06-18 03:22:58.268667
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with no credentials
    os.environ["HOME"] = "."

# Generated at 2022-06-18 03:22:58.896236
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:23:00.706574
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:23:01.467264
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:48.063346
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:25:48.766415
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:50.034888
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:50.765804
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:51.546773
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:26:01.429186
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that the upload_to_pypi function is called correctly.
    """
    from unittest.mock import patch
    from semantic_release.hvcs.git import Git
    from semantic_release.hvcs.git import GitRepo
    from semantic_release.hvcs.git import GitTag
    from semantic_release.hvcs.git import GitCommit
    from semantic_release.hvcs.git import GitConfig
    from semantic_release.hvcs.git import GitConfigEntry
    from semantic_release.hvcs.git import GitConfigEntryValue
    from semantic_release.hvcs.git import GitConfigEntryValueType

    # Create a mock git repo

# Generated at 2022-06-18 03:26:02.254468
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:26:09.793450
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with repository
    config["repository"] = "testpypi"
    upload_to_pypi()
    del config["repository"]

    # Test with skip_existing

# Generated at 2022-06-18 03:26:10.660928
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:26:13.087769
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])