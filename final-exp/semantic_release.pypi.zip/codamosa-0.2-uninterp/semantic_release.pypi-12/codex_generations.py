

# Generated at 2022-06-18 03:17:30.882594
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:32.487128
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:33.534444
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:35.456949
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:36.811473
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:17:45.236114
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function."""
    from .helpers import mock_run

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi(glob_patterns=["*"])
    mock_run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-token' '*'"
    )
    mock_run.reset_mock()

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi(glob_patterns=["*"])
    mock_run.assert_called_with

# Generated at 2022-06-18 03:17:46.079693
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:48.487445
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:17:49.688487
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:53.721322
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    with mock_run() as mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert mock.called
        assert mock.call_args[0][0] == "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"

# Generated at 2022-06-18 03:18:04.255080
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:05.541746
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:11.275565
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_TOKEN"] == "pypi-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"
    del os.environ["PYPI_USERNAME"]

# Generated at 2022-06-18 03:18:13.824727
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:15.355176
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:16.755543
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:17.900251
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:18:26.907095
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    from .helpers import LoggedFunction
    from .helpers import LoggedFunctionTest

    def mock_run(command):
        """
        Mock run function
        """
        assert command == "twine upload -u '__token__' -p 'pypi-token' --skip-existing 'dist/test.whl'"


# Generated at 2022-06-18 03:18:30.489637
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:31.828523
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:41.836332
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:43.132903
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:44.524372
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:46.087123
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:18:46.699242
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:49.651369
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:51.796791
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:18:52.654052
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:53.571133
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:59.775986
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that the upload_to_pypi function works as expected.
    """
    # Test that an error is raised if no credentials are given
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        raise AssertionError("No credentials should raise an ImproperConfigurationError")

    # Test that an error is raised if the token is not prefixed with "pypi-"
    try:
        upload_to_pypi(token="not-a-token")
    except ImproperConfigurationError:
        pass
    else:
        raise AssertionError("Invalid token should raise an ImproperConfigurationError")

    # Test that the token is used if given
    upload_to_pypi(token="pypi-token")

# Generated at 2022-06-18 03:19:18.638406
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:25.700149
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from semantic_release.settings import config

    with patch("invoke.run") as mock_run:
        upload_to_pypi()
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
        )

    with patch("invoke.run") as mock_run:
        config["repository"] = "testpypi"
        upload_to_pypi()
        mock_run.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-token' -r 'testpypi' 'dist/*'"
        )

    with patch("invoke.run") as mock_run:
        config["repository"]

# Generated at 2022-06-18 03:19:30.129262
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run
    from .helpers import mock_exists
    from .helpers import mock_isfile
    from .helpers import mock_getenv
    from .helpers import mock_open

    with mock_run(), mock_exists(), mock_isfile(), mock_getenv(), mock_open():
        upload_to_pypi()

# Generated at 2022-06-18 03:19:33.628504
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:34.944518
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-18 03:19:35.666938
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:43.785615
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert "twine upload -u '__token__' -p 'pypi-token' 'dist/*'" in LoggedFunction.log
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert "twine upload -u 'username' -p 'password' 'dist/*'" in LoggedFunction.log
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    #

# Generated at 2022-06-18 03:19:44.466193
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:44.841287
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:19:45.423256
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:23.243114
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:24.226850
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:33.541788
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "__token__"
    assert os.environ["PYPI_PASSWORD"] == "pypi-token"

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"

    # Test with no token or username

# Generated at 2022-06-18 03:20:35.368964
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:20:36.165124
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:36.893699
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:39.796519
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:20:41.171759
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:42.016452
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:42.910015
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:11.925508
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:22:13.300194
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:22:14.352212
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:22:16.436091
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:17.611068
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:22:25.750167
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    import os
    import shutil
    import tempfile
    import unittest

    from semantic_release.settings import config

    class UploadToPyPITestCase(unittest.TestCase):
        """Test upload_to_pypi function.
        """

        def setUp(self):
            """Create a temporary directory for testing.
            """
            self.temp_dir = tempfile.mkdtemp()
            self.old_dir = os.getcwd()
            os.chdir(self.temp_dir)
            config.set("repository", "testpypi")

        def tearDown(self):
            """Remove the temporary directory.
            """
            os.chdir(self.old_dir)

# Generated at 2022-06-18 03:22:27.052019
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:29.891254
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:31.610210
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:33.732960
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:26.215532
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:25:27.584024
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:25:28.929339
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:29.684776
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:25:30.430453
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:37.839277
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

# Generated at 2022-06-18 03:25:41.935472
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    """
    # pylint: disable=protected-access
    from semantic_release.hvcs.git import _get_commit_message

    # Create a fake commit message
    commit_message = _get_commit_message()
    assert commit_message == "chore(deps): bump semantic-release from 0.0.0 to 0.0.1"

    # Create a fake version
    version = "0.0.1"

    # Create a fake package
    package = "semantic_release"

    # Create a fake path
    path = "dist"

    # Create a fake glob_patterns
    glob_patterns = ["*"]

    # Create a fake skip_existing
    skip_existing = False

    # Create a fake repository

# Generated at 2022-06-18 03:25:44.542981
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:25:52.430845
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    assert os.environ["PYPI_TOKEN"] == "pypi-token"
    del os.environ["PYPI_TOKEN"]

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert os.environ["PYPI_USERNAME"] == "username"
    assert os.environ["PYPI_PASSWORD"] == "password"

# Generated at 2022-06-18 03:25:53.557950
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()