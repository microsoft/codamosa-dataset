

# Generated at 2022-06-18 03:17:34.595167
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:36.644789
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:17:37.585309
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:38.061429
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-18 03:17:39.887345
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:40.542287
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:42.072471
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:42.801796
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:17:44.047891
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function.
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:17:44.724551
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:17:50.748607
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:17:54.820961
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:17:55.727859
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:18:05.852991
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    with mock_run() as run_mock:
        upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
        assert run_mock.call_count == 1
        assert run_mock.call_args[0][0] == "twine upload  \"dist/*\""

    with mock_run() as run_mock:
        upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
        assert run_mock.call_count == 1
        assert run_mock.call_args[0][0] == "twine upload  --skip-existing \"dist/*\""

    with mock_run() as run_mock:
        upload_to_pypi

# Generated at 2022-06-18 03:18:11.505139
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import os
    import glob
    import subprocess

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary .pypirc file
    pypirc_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary .pypirc file
    pypirc_file_2 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary .pypirc file
    pypirc_file_3 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary .

# Generated at 2022-06-18 03:18:13.114850
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:13.777401
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:15.320482
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:16.716427
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:18.227639
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:29.935209
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:30.749403
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:33.930639
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:34.808991
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:35.448810
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:36.247445
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:37.070599
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:44.009331
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    from .helpers import mock_run

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
    mock_run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-token' --skip-existing 'dist/*'"
    )

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-18 03:18:44.976183
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:18:45.947222
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:14.905440
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function
    """
    from .helpers import mock_run

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    mock_run.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
    )
    mock_run.reset_mock()

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()

# Generated at 2022-06-18 03:19:15.451807
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:16.261218
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:17.776384
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:18.741608
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:19.560567
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:20.382453
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:21.195372
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:19:22.441027
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:19:23.166533
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:03.886705
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:05.252803
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:06.130971
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:07.870198
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:08.885418
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:20:11.332807
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:20:12.135567
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:20:13.275492
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:20:23.611195
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that the upload_to_pypi function works correctly
    """
    # Test that the function raises an error when no credentials are provided
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        raise AssertionError("No credentials should raise an ImproperConfigurationError")

    # Test that the function raises an error when a token is provided but doesn't start with "pypi-"
    try:
        upload_to_pypi(token="test")
    except ImproperConfigurationError:
        pass
    else:
        raise AssertionError("Token should start with 'pypi-'")

    # Test that the function raises an error when a username is provided but no password

# Generated at 2022-06-18 03:20:25.512300
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:21:52.447112
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:01.414209
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    from .helpers import mock_run

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    mock_run.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
    )
    mock_run.reset_mock()

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()

# Generated at 2022-06-18 03:22:02.635625
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:06.537337
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test that upload_to_pypi() works as expected.
    """
    from semantic_release.hvcs import git
    from semantic_release.settings import config
    from semantic_release.version_service import get_next_version
    from semantic_release.workflow import get_commit_message, get_version_bump

    # Set up a temporary git repository
    git.init()
    git.commit("Initial commit")
    git.commit("feat: Add new feature", allow_empty=True)
    git.commit("fix: Fix bug", allow_empty=True)
    git.commit("docs: Update documentation", allow_empty=True)
    git.commit("style: Reformat code", allow_empty=True)
    git.commit("refactor: Refactor code", allow_empty=True)
    git.commit

# Generated at 2022-06-18 03:22:07.459667
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi function
    """
    upload_to_pypi()

# Generated at 2022-06-18 03:22:08.519586
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:22:11.808336
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:13.152371
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:16.067788
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-18 03:22:16.931257
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:26.104130
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    from .helpers import mock_run

    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    mock_run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
    )
    mock_run.reset_mock()

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()

# Generated at 2022-06-18 03:25:26.936749
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:28.022714
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:29.403228
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-18 03:25:30.175550
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:32.689305
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-18 03:25:33.322683
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:33.996862
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:34.662071
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-18 03:25:35.802597
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi
    """
    upload_to_pypi()