

# Generated at 2022-06-21 21:00:04.034923
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    return upload_to_pypi()

# Generated at 2022-06-21 21:00:15.065499
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Uploading wheels to PyPI with Twine.
    # Wheels must already be created and stored at the given path.
    # Credentials are taken from either the environment variable
    # ``PYPI_TOKEN``, or from ``PYPI_USERNAME`` and ``PYPI_PASSWORD``.
    try:
        glob_patterns = ["*"]
        dist = " ".join(
            ['"{}/{}"'.format(path, glob_pattern.strip())] for glob_pattern in glob_patterns
        )
        skip_existing_param = " --skip-existing" if skip_existing else ""
        run(f"twine upload {username_password}{repository_arg}{skip_existing_param} {dist}")
    except:
        print("Could not upload file to PyPI repository")

# Generated at 2022-06-21 21:00:16.408508
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["test"])

# Generated at 2022-06-21 21:00:21.398802
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create a dummy dist folder
    dist_folder = "dist"
    try:
        os.mkdir(dist_folder)
    except FileExistsError:
        pass

    # Add dummy files to the dist folder
    with open(os.path.join(dist_folder, "some_file"), "w") as file:
        file.write(":)")

    upload_to_pypi(dist_folder, glob_patterns=["*"])

# Generated at 2022-06-21 21:00:26.734906
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test exception if neither token or credentials for upload available
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    assert upload_to_pypi

    # Test exception if token does not start with pypi-
    os.environ["PYPI_TOKEN"] = "test-pypi"
    assert upload_to_pypi

# Generated at 2022-06-21 21:00:27.954982
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:00:30.102007
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function.
    """
    upload_to_pypi()
    assert True

# Generated at 2022-06-21 21:00:35.371258
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_object(**kwargs):
        pass

    glob_patterns = ["*"]
    mock = mock_object
    mock.return_value = "Test"
    mock.config = {}
    mock.config.get = mock_object
    mock.config.get.return_value = "Test"
    upload_to_pypi(glob_patterns=glob_patterns)
    assert mock.config.get.called

# Generated at 2022-06-21 21:00:38.403687
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-21 21:00:39.870349
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Write unit tests
    pass

# Generated at 2022-06-21 21:00:51.649502
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        # Test for missing credentials
        upload_to_pypi()
    except ImproperConfigurationError:
        pass # Test passes if error is raised
    else:
        assert False # Test fails if no error is raised

    # Test for PYPI_TOKEN
    os.environ["PYPI_TOKEN"] = "12345"
    upload_to_pypi()

    # Test for PYPI_USERNAME and PYPI_PASSWORD
    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()

    # Test for invalid PYPI_TOKEN format

# Generated at 2022-06-21 21:00:56.064774
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if not os.getenv('PYPI_TOKEN'):
        os.environ['PYPI_TOKEN'] = 'pypi-fake-token'

    upload_to_pypi(glob_patterns=['build/*'])

    if os.getenv('PYPI_TOKEN'):
        del os.environ['PYPI_TOKEN']



# Generated at 2022-06-21 21:01:03.374298
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    pypirc_contents = """
    [distutils]
    index-servers=
        pypi
        testpypi
    [pypi]
    repository: https://upload.pypi.org/legacy/
    username: __token__
    password: pypi-wylcjL0x1O
    [testpypi]
    repository: https://test.pypi.org/legacy/
    username: __token__
    password: test-wylcjL0x1O
    """
    with TemporaryDirectory() as d:
        home_dir = Path(d)
        # ensure ~/.pypirc exists
        pypirc = home_dir / ".pypirc"

# Generated at 2022-06-21 21:01:13.915510
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    from unittest.mock import patch, MagicMock
    
    if not os.path.exists("dist"):
        os.makedirs("dist")
    if not os.path.exists("dist/test"):
        with open("dist/test", "w") as dist_file:
                dist_file.write("test")
    
    # Successful upload to pypi
    with patch('invoke.run') as run_mock:
        run_mock.return_value = True
        upload_to_pypi()
        run_mock.assert_called_once()

    # Successful upload to pypi
    with patch('invoke.run') as run_mock:
        run_mock.return_value = True
        upload_to_pyp

# Generated at 2022-06-21 21:01:24.799957
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.

    Mocking is used to replace the `run` function, which is used
    to call the underlying shell commands.
    """
    from unittest.mock import patch

    # Mock out the shell commands
    with patch("invoke.run") as mock_run:
        # Call function with named parameters
        upload_to_pypi(glob_patterns=["a*", "b*"], path="path", skip_existing=True)

        # Check that the shell command was called correctly
        mock_run.assert_called_once_with(
            'twine upload -u \'__token__\' -p \'pypi-token\' --skip-existing "path/a*" "path/b*"'
        )

# Generated at 2022-06-21 21:01:29.139896
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-secret"
    config["repository"] = "test-repo"
    upload_to_pypi(path="test/test-path")

# Generated at 2022-06-21 21:01:37.371772
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Testing to see if the function gets invoked when no glob_patterns are defined
    try:
        upload_to_pypi(path="dist", glob_patterns=[])
        fail_check = False
    except SystemExit as e:
        fail_check = True
    assert fail_check

    # Testing to see if the function gets invoked when no path is defined
    try:
        upload_to_pypi(path="", glob_patterns=["*"])
        fail_check = False
    except SystemExit as e:
        fail_check = True
    assert fail_check

    # Testing to see if the function gets invoked if the PyPI_TOKEN environment variable is not defined

# Generated at 2022-06-21 21:01:40.802431
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=None)

# Generated at 2022-06-21 21:01:48.848857
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    with mock_run() as mocked:
        upload_to_pypi("dist", True, ["*"])
        # Twine uploads distributions to the default PyPI repository.
        mocked.assert_called_with("twine upload -u '__token__' -p 'pypi-token' --skip-existing \"dist/*\"")

        upload_to_pypi("dist", False, ["*"])
        mocked.assert_called_with("twine upload -u '__token__' -p 'pypi-token' \"dist/*\"")

        # Twine takes a space-separated list of distributions.
        upload_to_pypi("dist", False, ["*.whl", "*.tar.gz"])

# Generated at 2022-06-21 21:01:52.665757
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for upload_to_pypi function
    """
    # Test that the function upload_to_pypi has been imported correctly
    assert upload_to_pypi.__name__ == "function_upload_to_pypi"

# Generated at 2022-06-21 21:02:01.272254
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:02:05.136840
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    test upload_to_pypi function with known good values
    """
    upload_to_pypi("dist", False, ["*"])

# Generated at 2022-06-21 21:02:12.158494
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for upload_to_pypi.
    """
    from .helpers import MockRun, MockConfig

    def run_app(command, *args, **kwargs):
        if command.startswith("twine upload"):
            return True
        return False

    with MockConfig(), MockRun(run_app):
        upload_to_pypi(glob_patterns=["*.whl"])
        assert True

# Generated at 2022-06-21 21:02:15.985110
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-1234"
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi("test")
    assert os.environ.get("PYPI_TOKEN") is None
    assert os.environ.get("PYPI_USERNAME") is None
    assert os.environ.get("PYPI_PASSWORD") is None

# Generated at 2022-06-21 21:02:17.030230
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    print ("Test upload_to_pypi")

# Generated at 2022-06-21 21:02:19.276550
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:02:27.134775
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    mocked_run = lambda x: print(x)
    mocked_os_environ = {
        "PYPI_TOKEN": "pypi-correctToken",
        "HOME": "/home/user",
    }
    glob_patterns = ["*.whl"]
    path = "some_path"
    skip_existing = True
    expected_command = "twine upload -u '__token__' -p 'pypi-correctToken'  --skip-existing 'some_path/wheel_1-1.0-py3-none-any.whl'"
    expected_command += " 'some_path/wheel_2-1.0-py3-none-any.whl'"
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

# Generated at 2022-06-21 21:02:27.537811
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:02:35.292287
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_patterns = ["*"]
    # Attempt to get an API token from environment
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")
        if not (username or password) and (
            not home_dir or not os.path.isfile(os.path.join(home_dir, ".pypirc"))
        ):
            raise ImproperConfigurationError(
                "Missing credentials for uploading to PyPI"
            )

# Generated at 2022-06-21 21:02:36.256700
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # mock stuff
    pass

# Generated at 2022-06-21 21:02:53.056286
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:02:54.065518
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-21 21:03:02.129405
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(
        path="dist",
        skip_existing=False,
        glob_patterns=["*.whl", "*.gz", "*.zip","*.tar.gz"],
    )
    upload_to_pypi(
        path="dist",
        skip_existing=True,
        glob_patterns=["*.whl", "*.gz", "*.zip","*.tar.gz"],
    )

# Generated at 2022-06-21 21:03:02.487553
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:03:10.494438
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Make sure function upload_to_pypi works properly"""
    from .helpers import more_context
    from .helpers import set_config
    
    with more_context(config=set_config({"repository":"pypi"})):
        upload_to_pypi("dist")

    with more_context(config=set_config({"repository":"pypi"})):
        upload_to_pypi("dist", skip_existing=True)

    with more_context(config=set_config({"repository":"pypi"})):
        upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:03:17.401631
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for upload_to_pypi()
    """
    import tempfile, shutil
    import pytest
    from semantic_release.hvcs import ReleaseWithHvcs
    from semantic_release.settings import config
    from semantic_release.settings import ConfigFileError
    from semantic_release.package_managers import PackageManager, UnknownPackageManagerError

    pypi_token = "pypi-0123456789abcdef"
    pypi_username = "my_username"
    pypi_password = "my_password"
    test_cfg = {
        "repository": "https://github.com/test/test.git",
        "upload_to_pypi_repository": "testpypi",
        "python_package_manager": "poetry",
    }
   

# Generated at 2022-06-21 21:03:22.057218
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # def upload_to_pypi(path: str = "dist", skip_existing: bool = False, glob_patterns: List[str] = None):
    #   return run(f"twine upload {username_password}{repository_arg}{skip_existing_param} {dist}")
    pass

# Generated at 2022-06-21 21:03:24.188870
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == ''

# Generated at 2022-06-21 21:03:27.743750
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test missing credentials
    upload_to_pypi()
    # Test missing path
    upload_to_pypi(path="dist")
    # Test if path and glob_patterns exists
    upload_to_pypi(path="dist", glob_patterns=["*"])

# Generated at 2022-06-21 21:03:33.603108
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile

    with tempfile.TemporaryDirectory() as dist_dir:
        test_package = "my-new-package-0.0.1.tar.gz"

        # Create a file in the test directory
        open(os.path.join(dist_dir, test_package), "a").close()

        # Set environment variables for PYPI
        os.environ["PYPI_USERNAME"] = "test_username"
        os.environ["PYPI_PASSWORD"] = "test_password"

        upload_to_pypi(path=dist_dir)

# Generated at 2022-06-21 21:04:17.368387
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """This function should get the twine command, parse the credentials,
    and return the function call to that command.
    """
    # Test with a token (and no username / password)

# Generated at 2022-06-21 21:04:26.581909
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = os.environ.get("PYPI_TOKEN")
    os.environ["PYPI_TOKEN"] = "faketoken"
    repository = config.get("repository", None)
    os.environ['REPO'] = repository
    repo = os.environ.get("REPO")

    upload_to_pypi()
    assert "pypi-faketoken" in run.calls[0].args
    assert repo in run.calls[0].args
    del run.calls[:]

    os.environ["PYPI_TOKEN"] = "pypi-fake"
    upload_to_pypi()
    assert "pypi-fake" in run.calls[0].args
    assert repo in run.calls[0].args

# Generated at 2022-06-21 21:04:38.839620
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from semantic_release import ImproperConfigurationError

    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    os.environ["PYPI_USERNAME"] = "foo"
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    os.environ["PYPI_PASSWORD"] = "bar"
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    os.environ["PYPI_TOKEN"] = "pypi-fizzbuzz"
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi(glob_patterns=["foo bar"])


# Generated at 2022-06-21 21:04:40.894483
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-21 21:04:43.605468
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Ensure the upload can be run."""
    upload_to_pypi("dist", glob_patterns=["*"])

# Generated at 2022-06-21 21:04:52.871554
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test method"""
    def mock_run(command, **args):
        """Mock calls to invoke.run"""
        assert args.get("pty", False)
        assert args.get("encoding", None) == "utf8"
        assert args.get("hide", None) == "both"

        assert command == f"twine upload -u '__token__' -p 'pypi-token' 'dist/wheel'".format(os.getcwd())

        return "Uploaded wheel to pypi"

    run_orig = run
    run = mock_run

    try:
        upload_to_pypi(path="dist", glob_patterns=["wheel"])
    finally:
        run = run_orig

# Generated at 2022-06-21 21:04:55.925712
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(skip_existing=True)

# Generated at 2022-06-21 21:04:59.750757
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """A function which uploads a package file to pypi using
    twine.
    """
    assert upload_to_pypi(glob_patterns=["*.whl"]) == "twine upload *"

# Generated at 2022-06-21 21:05:03.648696
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config['repository'] = 'test-pypi'
    try:
        upload_to_pypi()
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-21 21:05:11.322755
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test that calls upload_to_pypi to verify basic functionality.

    If you encounter an error running this unit test, please check the following:

    1. You are running this unit test on a stable network connection.
    2. You are connected to the internet.
    3. You have not used Invoke to run `inv twine` in the past hour.

    Twine is rate-limited to 1 file upload per hour per API token.
    """
    from .pypi_config import test_pypi_token

    if test_pypi_token.startswith("pypi-"):
        upload_to_pypi(glob_patterns=[test_pypi_token])
    else:
        print("No API token available for testing. All checks passed.")

# Generated at 2022-06-21 21:06:21.221380
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="./test_path", skip_existing=True, glob_patterns=["*.txt", "*.jpg"])

# Generated at 2022-06-21 21:06:22.510184
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(".", skip_existing=True)

# Generated at 2022-06-21 21:06:23.085351
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1

# Generated at 2022-06-21 21:06:27.036325
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi().
    """
    # Test default upload, no arguments
    upload_to_pypi()

    # Test upload, skip existing, directory
    upload_to_pypi(skip_existing=True, path="test_dir")

    # Test upload, custom glob patterns
    upload_to_pypi(glob_patterns=["test_pattern"])

# Generated at 2022-06-21 21:06:38.165714
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import patch_run
    from .helpers import TemporaryWorkingDirectory

    config.set(
        "repository", "pypi", config.get("repository", {}), config.get("project", {})
    )
    username = "__token__"
    password = "pypi-test-token"
    with patch_run() as mock_run:
        with TemporaryWorkingDirectory() as tmpdir:
            os.mkdir(os.path.join(tmpdir, "dist"))
            open(os.path.join(tmpdir, "dist", "test1"), "a").close()
            open(os.path.join(tmpdir, "dist", "test2"), "a").close()
            open(os.path.join(tmpdir, "dist", "test3"), "a").close()

           

# Generated at 2022-06-21 21:06:41.156724
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    upload_to_pypi(path="./dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:06:52.537700
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class FakeRun(object):
        def __init__(self):
            self.cmd = None

        def __call__(self, cmd):
            self.cmd = cmd
            return self

        def stdout(self, *args, **kwargs):
            return None

    fake_run = FakeRun()

    # Check PyPI upload with Username and Password
    os.environ["PYPI_USERNAME"] = "name"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    assert fake_run.cmd == "twine upload -u 'name' -p 'password' 'dist/*'"

    # Check PyPI upload with Token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()

# Generated at 2022-06-21 21:07:03.250387
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    distribution = "testdistribution"
    fake_path_to_dist = "path/to/dist"
    with patch.dict(os.environ, {"PYPI_TOKEN": "pypi-test_upload_to_pypi"}) as patched_env, patch(
        "invoke.run", return_value="ran"
    ) as patched_run:
        assert True == upload_to_pypi(fake_path_to_dist, glob_patterns=[distribution])
        patched_env.assert_called_with({"PYPI_TOKEN": "pypi-test_upload_to_pypi"})

# Generated at 2022-06-21 21:07:04.831582
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(None)

# Generated at 2022-06-21 21:07:07.029986
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", glob_patterns=["*"]) # test if upload to pypi works

# Generated at 2022-06-21 21:09:40.140289
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:09:51.081593
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test env var token
    token = "pypi-some_token"
    os.environ["PYPI_TOKEN"] = token
    upload_to_pypi(path="dist")
    assert f"-u '__token__' -p '{token}'" in LoggedFunction.last_log
    os.environ.pop("PYPI_TOKEN")

    # Test env vars username/password
    username = "some_user"
    password = "some_password"
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"] = password
    upload_to_pypi(path="dist")
    assert f"-u '{username}' -p '{password}'" in LoggedFunction.last_log

# Generated at 2022-06-21 21:10:02.240557
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"
    assert upload_to_pypi.__doc__ is not None


if __name__ == "__main__":
    """This code will run when this module is called from the command-line
    """
    # This code will run when this module is called from the command-line.
    #
    # Usage:
    #   $ python3 -m semantic_release.pypi_upload
    #
    # Use pytest to execute unit tests.
    #
    # Use:
    #   $ pip install pytest
    #   $ pytest
    #
    upload_to_pypi()