

# Generated at 2022-06-21 21:00:06.743588
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set environment variable PYPI_TOKEN
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()

    # Set environment variable PYPI_USERNAME and PYPI_PASSWORD
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    del os.environ["PYPI_TOKEN"]
    upload_to_pypi()

# Generated at 2022-06-21 21:00:10.466449
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi("dist", skip_existing = True, glob_patterns = ["*"])
    except ImproperConfigurationError:
        return True
    return False

# Generated at 2022-06-21 21:00:11.075997
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:00:14.259304
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-21 21:00:23.272666
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    This function tests invocation of the upload_to_pypi function
    and basically asserts the syntax of the invoke run command inside the function.

    This is a simple mock test that is useful to test the `invoke` syntax.
    """
    pwd = os.path.dirname(os.path.realpath(__file__))
    path = os.path.join(pwd, "mock_release_files")
    glob_patterns = ["*"]
    skip_existing = True
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")


# Generated at 2022-06-21 21:00:34.696666
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        verify_return_type(
            upload_to_pypi,
            [
                {
                    "path": "dist",
                    "skip_existing": False,
                    "glob_patterns": None,
                },{
                    "path": "dist",
                    "skip_existing": False,
                    "glob_patterns": ["*"],
                },{
                    "path": "dist",
                    "skip_existing": True,
                    "glob_patterns": ["*"],
                },
            ],
            None
        )
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-21 21:00:46.830636
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_subprocess_check_output

    with mock_subprocess_check_output() as mock:
        upload_to_pypi()
    mock.assert_called_once_with(
        r'twine upload --skip-existing "dist/\*"', shell=True, env=None
    )

    with mock_subprocess_check_output() as mock:
        upload_to_pypi(skip_existing=True)
    mock.assert_called_once_with(
        r'twine upload --skip-existing "dist/\*"', shell=True, env=None
    )

    with mock_subprocess_check_output() as mock:
        upload_to_pypi(glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:00:50.145365
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    inputs = {}
    inputs['path'] = "."
    inputs['glob_patterns'] = ['*']
    upload_to_pypi(**inputs)

# Generated at 2022-06-21 21:00:51.195566
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:00:55.455602
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    twine_upload_cmd = f"twine upload -u '__token__' -p 'pypi-zTmhzt2oTnrGYgK9XlHcOPaIO0s' 'dist/semantic_release-1.0.0-py2.py3-none-any.whl'"
    run(twine_upload_cmd)

# Generated at 2022-06-21 21:01:12.460074
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from mock import patch

    from .helpers import LoggedFunction
    from .helpers import get_log_records

    with patch("invoke.run") as run_patch:
        LoggedFunction(logger)(upload_to_pypi)()

        expected_calls = [
            call(
                "twine upload -u '__token__' -p 'pypi-token'  'dist/*.whl'", hide=True
            ),
            call(
                "twine upload -u '__token__' -p 'pypi-token' --skip-existing  'dist/*.whl'",
                hide=True,
            ),
        ]
        assert run_patch.call_count == 2
        assert run_patch.call_args_list == expected_calls


# Generated at 2022-06-21 21:01:14.841321
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="tests/artifacts/dummy_package", 
                   glob_patterns=["*.whl", "*.tar.gz"],
                   skip_existing=False)

# Generated at 2022-06-21 21:01:18.538079
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path='/path/to/dist', skip_existing=False, glob_patterns=None) == (f'python -m twine upload -u \'None\' -p \'None\' None /path/to/dist/*.whl')
    assert upload_to_pypi(path=None, skip_existing=True, glob_patterns=['*']) == (f'python -m twine upload -u \'None\' -p \'None\' None \'*\'')

# Generated at 2022-06-21 21:01:19.960602
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO - test fails because twine is not installed on travis
    pass

# Generated at 2022-06-21 21:01:25.506062
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function."""
    # Create a test directory at /tmp with one file, then use twine to upload it
    with open("/tmp/test1.txt", "w+") as test_file:
        test_file.writelines("This is a test")
    upload_to_pypi("/tmp")
    # Delete the file & directory
    os.remove("/tmp/test1.txt")
    os.rmdir("/tmp")

# Generated at 2022-06-21 21:01:26.551727
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:01:29.617807
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi()
    """
    assert True == True

# Generated at 2022-06-21 21:01:36.602572
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi()"""
    try:
        config.set("repository", "https://test.pypi.org/legacy/")
        upload_to_pypi(path="tests/project/dist", skip_existing=True, glob_patterns=["*"])
    except Exception:
        pass
    finally:
        config.set("repository", None)

# Generated at 2022-06-21 21:01:38.850087
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi
    """
    assert True

# Generated at 2022-06-21 21:01:47.680332
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import Context
    from .helpers import mock_subprocess, cleanup_subprocess_mock
    from semantic_release.hvcs import git
    import invoke
    import pytest
    from invoke.exceptions import UnexpectedExit

    with mock_subprocess():
        # missing credentials
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

        # repository is None while repository param exists (invalid)
        os.environ["PYPI_TOKEN"] = "pypi-foo"
        with pytest.raises(ImproperConfigurationError) as err:
            upload_to_pypi(repository_arg=True)
        assert str(err.value) == "Missing credentials for uploading to PyPI"

# Generated at 2022-06-21 21:02:04.751192
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run(c):
        c.run = c
        return c

    def twine_upload(arguments):
        assert "./dist/foo.whl" in arguments
        assert "./dist/bar.whl" in arguments
        assert arguments.startswith("twine upload")

    def pypi_token(c, token):
        assert token == "pypi-12345"
        return "foo"

    config.update({"repository": "my_repository"})

    upload_to_pypi(
        path="./dist", skip_existing=True, glob_patterns=["foo.whl", "bar.whl"]
    )(
        run, twine_upload, pypi_token, os.path.isfile, os.environ,
    )

# Generated at 2022-06-21 21:02:10.369597
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert None is upload_to_pypi()
    assert "git_tag" in upload_to_pypi(
        glob_patterns=["*", ".*"]
    )  # NOTE: Glob pattern should be only "*".
    assert "Missing credentials for uploading to PyPI" in upload_to_pypi.exception

# Generated at 2022-06-21 21:02:11.506699
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert not upload_to_pypi()

# Generated at 2022-06-21 21:02:14.672990
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ['PYPI_TOKEN'] = 'pypi-12345678'
    upload_to_pypi(path="dist", glob_patterns=["*"])

# Generated at 2022-06-21 21:02:24.116481
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from unittest.mock import patch

    from .helpers import MockContext

    ctx = MockContext()
    ctx.config['repository'] = "https://test.pypi.org/legacy/"
    os.environ["PYPI_TOKEN"] = "pypi-123ABCD"
    with patch('invoke.run', autospec=True) as invoke_run:
        upload_to_pypi(
            path='/tmp/dist_folder/',
            skip_existing=False,
            glob_patterns=['*.whl', '*.egg']
       )

    assert invoke_run.call_count == 1

# Generated at 2022-06-21 21:02:33.397592
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import glob
    import shutil
    import tempfile
    import unittest

    from semantic_release.pypi import upload_to_pypi

    class TestUploadToPypi(unittest.TestCase):
        def setUp(self):
            """
            Set up a temp folder with:
                - one file that would be uploaded
                - one file that would not be uploaded
            """
            self.temp_dir = tempfile.TemporaryDirectory()
            self.temp_dir_name = self.temp_dir.name
            self.original_cwd = os.getcwd()

            os.chdir(self.temp_dir_name)

            import semantic_release

            self.path = "tmp"

            self.semantic_release_version = semantic_release.__version__


# Generated at 2022-06-21 21:02:38.351756
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(path_to_files="dist")
    upload_to_pypi(path_to_files="dist", skip_existing=True)
    upload_to_pypi(path_to_files="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:02:46.222811
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    This function tests uploading to PyPI
    """
    from semantic_release.settings import config
    import os

    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")

    config.set("repository", "pypi")

    if not username or not password:
        logger.warning("Missing PyPI credentials. Test passed.")
    else:
        upload_to_pypi(path="semantic_release/tests/fixtures/fake_dist")


if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-21 21:02:46.859624
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:02:54.604911
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test that upload_to_pypi creates the correct command,
    and creates the correct command with a repository"""
    glob_patterns = ["*", "**", "***", ".*", "***.*"]
    dist = " ".join(
        ['"{}/{}"'.format("dist", glob_pattern.strip()) for glob_pattern in glob_patterns]
    )
    env = os.environ.copy()
    assert upload_to_pypi.__wrapped__.__name__ == "upload_to_pypi"
    assert (
        upload_to_pypi.__wrapped__()
        == "twine upload {} {}".format(
            "", "".join(f' "dist/{pattern}"' for pattern in glob_patterns)
        )
    )

# Generated at 2022-06-21 21:03:12.593005
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["dist/*"])

# Generated at 2022-06-21 21:03:14.022146
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist/", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:03:25.174423
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .mocks import MockCommand, test_run

    assert upload_to_pypi() == None

    # Check for token
    MockCommand.clear()
    os.environ["PYPI_TOKEN"] = "Test"
    test_run(
        "twine upload -u '__token__' -p 'Test' 'dist/test.whl' 'dist/test2.whl'",
        upload_to_pypi,
        raise_errors=True,
    )
    MockCommand.clear()
    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "Test"
    os.environ["PYPI_PASSWORD"] = "Test"

# Generated at 2022-06-21 21:03:33.642421
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    global config

    assert config == {}, "Config is empty"

    # Testing with a repository section in the config
    config["repository"] = "test_upload_to_pypi_repository"
    # Testing with a bad token
    os.environ["PYPI_TOKEN"] = "bad_token"
    test = False
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        test = True
    assert test, "ImproperConfigurationError not triggered for bad token"
    # Testing with a good token
    os.environ["PYPI_TOKEN"] = "pypi-good_token"
    # Testing with a username and password
    os.environ["PYPI_USERNAME"] = "good_user"

# Generated at 2022-06-21 21:03:38.033688
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockedFunction, MockedContext

    # Test for missing credentials
    with MockedFunction(
        "os.environ.get",
        return_value=None,
        side_effect_on_call=[
            "PYPI_TOKEN",
            None,
            None,
            "HOME",
            None,
            "HOME/to/.pypirc",
        ],
    ):
        with MockedContext(MockedFunction("os.path.isfile", return_value=False)):
            with MockedContext(MockedFunction("run")):
                try:
                    upload_to_pypi()
                    assert False
                except ImproperConfigurationError:
                    assert True

    # Test for API token

# Generated at 2022-06-21 21:03:42.922234
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    files = [
        os.path.join("dist", "semantic_release-13.0.0-py3-none-any.whl"),
        os.path.join("dist", "semantic_release-13.0.0.tar.gz"),
    ]
    for file in files:
        os.system(f"touch {file}")
    upload_to_pypi("dist")
    for file in files:
        os.system(f"rm {file}")

# Generated at 2022-06-21 21:03:48.655928
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test that the upload_to_pypi(), when called with a dummy path, and with the 
    credentials defined in the environment, does not raise an exception.
    """
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi("dist")
    assert True

# Generated at 2022-06-21 21:03:50.659232
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", False, glob_patterns=["*"])

# Generated at 2022-06-21 21:03:51.844782
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert False


# Generated at 2022-06-21 21:04:03.377983
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
    except ImportError:
        pytest.skip("Twine not installed")

    from unittest.mock import patch, Mock

    with patch("twine.commands.upload.upload") as mock_upload:
        upload_to_pypi()
        assert mock_upload.called

        mock_upload.reset_mock()

        os.environ["PYPI_USERNAME"] = "test_user"
        os.environ["PYPI_PASSWORD"] = "test_pass"

        with patch("twine.commands.upload.upload") as mock_upload:
            upload_to_pypi()
            assert mock_upload.called

# Generated at 2022-06-21 21:04:48.044320
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def get_env(key):
        return os.environ[key]
    setenv_map = {}
    for env_var in ["PYPI_TOKEN", "PYPI_USERNAME", "PYPI_PASSWORD", "HOME"]:
        if env_var in os.environ:
            setenv_map[env_var] = get_env(env_var)
        else:
            setenv_map[env_var] = ""
        os.environ[env_var] = setenv_map[env_var]

    # Test 1: Successfully uploads to pypi with a PYPI_TOKEN
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()

    # Test 2: Successfully uploads to pyp

# Generated at 2022-06-21 21:04:55.597320
# Unit test for function upload_to_pypi

# Generated at 2022-06-21 21:05:01.651873
# Unit test for function upload_to_pypi

# Generated at 2022-06-21 21:05:03.930412
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = "dist", skip_existing = True, glob_patterns = ["*"])

# Generated at 2022-06-21 21:05:04.811180
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:05:11.037617
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    message = "test"
    upload_to_pypi(path="path")
    assert logger.info.called_with(message)
    upload_to_pypi(path="path", glob_patterns=["glob"])
    assert logger.info.called_with(message)
    upload_to_pypi(path="path", skip_existing=True)
    assert logger.info.called_with(message)
    upload_to_pypi(path="path", skip_existing=True, glob_patterns=["glob"])
    assert logger.info.called_with(message)

# Generated at 2022-06-21 21:05:16.371130
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockContext
    from .context import Context

    with MockContext(Context):
        assert(config.get("dry_run", None) == False)
        upload_to_pypi()

# Generated at 2022-06-21 21:05:17.992769
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi()."""
    pass

# Generated at 2022-06-21 21:05:27.577561
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    # This test should fail because the credentials are not in the environment
    # variables
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True

    # This test should fail because the token does not start with 'pypi-'
    os.environ["PYPI_TOKEN"] = "wrong_token"
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True

    # This test should pass
    os.environ["PYPI_TOKEN"] = "pypi-test_token"
    try:
        upload_to_pypi()
        assert True
    except ImproperConfigurationError:
        assert False

# Generated at 2022-06-21 21:05:34.798013
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil

    from tempfile import mkdtemp
    from freezegun import freeze_time
    from semantic_release import post_release

    from . import mock_repo

    # Create a temporary directory
    temp_dir = mkdtemp()

# Generated at 2022-06-21 21:06:46.049031
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:06:48.397215
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for helper Pypi"""
    upload_to_pypi("../../dist/", False)

# Generated at 2022-06-21 21:06:49.321806
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:06:50.236085
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:07:01.198370
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    username = "test_username"
    password = "test_password"
    token = "test_token"
    repository = "test_repository"
    skip_existing = True
    glob_patterns = ["fake_pattern"]

    with open(os.path.join(path, glob_patterns[0]), "wb") as f:
        f.write(b"\x00\x00\x00\x00\x00\x00\x00\x00")

    import semantic_release.pypi.upload
    orig_run = semantic_release.pypi.upload.run


# Generated at 2022-06-21 21:07:02.536526
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", None, ["dist/*"])

# Generated at 2022-06-21 21:07:07.811969
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock

    assert os.environ.get("PYPI_TOKEN") is None
    assert os.environ.get("PYPI_USERNAME") is None
    assert os.environ.get("PYPI_PASSWORD") is None

    with mock.patch("invoke.run") as mocked_run:
        mocked_run.return_value = "mocked run"
        upload_to_pypi("dist", False, ["*"])
        assert mocked_run.called
        assert mocked_run.call_args[0] == (
            'twine upload  "dist/*"',
        )



# Generated at 2022-06-21 21:07:20.348573
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from pathlib import Path
    from glob import glob
    import pytest
    from distutils.temp_env import TempEnv
    from semantic_release.settings import get_config
    with TempEnv(cleanup=True):
        os.mkdir("dist")
        with open(Path(".semantic_release_test"), "w+"):
            pass
        with open(Path("dist/semantic_release_test"), "w+"):
            pass
        with open(Path("dist/semantic_release_test2"), "w+"):
            pass
        assert glob("dist/*") == ["dist/semantic_release_test", "dist/semantic_release_test2"]
        repository = "test_repository"

# Generated at 2022-06-21 21:07:21.319764
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-21 21:07:22.307426
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()