

# Generated at 2022-06-21 21:00:07.713420
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:00:18.508503
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert os.system("echo 'echo $(env | grep TWINE) $(ls -la dist)' > twine.sh && chmod +x twine.sh") == 0
    assert os.system("echo '{\"pypi\": {\"repository\": \"test\"}}' > semantic-release.conf") == 0
    os.environ["TWINE"] = "twine.sh"
    os.environ["PYPI_TOKEN"] = "pypi-test"
    os.environ["HOME"] = os.getcwd()
    assert os.system("echo 'echo TEST' > dist/test.txt") == 0
    assert os.system("touch dist/test2.txt") == 0

    upload_to_pypi()


# Generated at 2022-06-21 21:00:29.691129
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from semantic_release.settings import config
    from semantic_release.hvcs.git import parse_remote
    from semantic_release.hvcs.github import get_repo_fullname

    config.update(
        dict(
            repositories=[
                dict(
                    type="github",
                    url="https://github.com/user/repo",
                    token="token",
                    enterprise="enterprise",
                )
            ],
            repository=parse_remote("https://github.com/user/repo"),
        )
    )


# Generated at 2022-06-21 21:00:38.694439
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    env = {
        "HOME": "/home/semantic-release",
        "PYPI_USERNAME": "username",
        "PYPI_PASSWORD": "password"
    }
    dist = "dist"
    glob_patterns = ["*", "foo-bar"]
    # pylint: disable=protected-access
    expected_command = (
        "twine upload -u 'username' -p 'password' "
        "\"dist/foo-bar\" \"dist/foo-bar\""
    )
    run.assert_called_with(expected_command, env=env)
    # pylint: enable=protected-access

# Generated at 2022-06-21 21:00:40.721895
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="./dist", glob_patterns=["*"])

# Generated at 2022-06-21 21:00:49.191400
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from subprocess import run
    from .helpers import LoggedFunction
    from .helpers import mocked_run
    from unittest import mock

    with mock.patch("invoke.run", new=mocked_run) as mock_run:
        credentials_missing_error = "Missing credentials for uploading to PyPI"
        with mock.patch.dict(os.environ, {}, clear=True):
            try:
                LoggedFunction(logger)(upload_to_pypi).__wrapped__()
            except ImproperConfigurationError as  e:
                assert str(e) == credentials_missing_error
            else:
                assert False, "Should have raised an error"


# Generated at 2022-06-21 21:00:49.819709
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True == True

# Generated at 2022-06-21 21:00:57.538551
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = 'user'
    password = 'pass'
    repository = 'repo'
    token = 'pypi-token'
    tokens = [token, token[5:]]
    
    import os
    import logging
    from semantic_release.settings import config
    from .helpers import LoggedFunction
    from invoke import run

    def side_effect_run(*args, **kwargs):
        print(args[0])

    for token in tokens:
        print(token)
        os.environ['PYPI_TOKEN'] = token
        config.update({'repository': repository})

# Generated at 2022-06-21 21:01:04.349930
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with open("/tmp/fake_env", "w") as file:
        file.write(
            "export PYPI_TOKEN=pypi-1234567890\n"
            "export PYPI_USERNAME=pypi_username\n"
            "export PYPI_PASSWORD=pypi_password\n")
    os.environ.clear()
    os.environ["ENV_FILE"] = "/tmp/fake_env"
    os.environ["PYPI_TOKEN"] = "pypi-1234567890"
    os.environ["PYPI_USERNAME"] = "pypi_username"
    os.environ["PYPI_PASSWORD"] = "pypi_password"


# Generated at 2022-06-21 21:01:08.101685
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi(path=".cache/dist", glob_patterns=["*"])
    except Exception:
        print('test_upload_to_pypi: Pass')

# Generated at 2022-06-21 21:01:24.564414
# Unit test for function upload_to_pypi

# Generated at 2022-06-21 21:01:30.442296
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .context import in_directory

    with in_directory("tests"):
        from .context import change_dir

    with change_dir("tests"):
        import glob

        upload_to_pypi("dist")
        assert len(glob.glob("dist/semantic_release*")) == 0

# Generated at 2022-06-21 21:01:41.000328
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=redefined-outer-name
    """Test the upload_to_pypi function."""

    def mock_run(*args, **kwargs):
        """Mock for run function."""
        assert args[0] == "twine upload -u '__token__' -p 'pypi-test' -r 'test-repo' --skip-existing 'dist/file1' 'dist/file2'"
        return True

    with upload_to_pypi.using(run=mock_run):

        upload_to_pypi(
            path="dist",
            skip_existing=True,
            glob_patterns=["file1", "file2"],
        )

# Generated at 2022-06-21 21:01:48.984443
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # If we use this function in a unit test, we have to mock the system input
    # and output. We will only call the function, so we can skip the if block
    # that checks for a reactor to be present (which is not the case during a unit test).
    # In addition, we have to mock os.path.isfile to return `True`, otherwise,
    # the `if not (username or password) and ...` expression will fail.
    import mock
    from semantic_release.exceptions import ImproperConfigurationError


# Generated at 2022-06-21 21:01:59.969351
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """This test :
    * upload a file to pypi
    * retrieve uploaded file from pypi
    * verify the integrity of the file
    * delete the uploaded file
    """
    import urllib.request
    import zipfile
    import io
    import shutil

    # Download and unzip the package
    test_data_url = "https://github.com/sdpython/ensae_teaching_cs/archive/master.zip"
    test_data_file = "./ensae_teaching_cs-master.zip"
    urllib.request.urlretrieve(test_data_url, test_data_file)
    zf = zipfile.ZipFile(test_data_file, mode="r")

    # Get the name of the package to be uploaded

# Generated at 2022-06-21 21:02:11.884916
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    os.environ["PYPI_TOKEN"] = 1234
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    os.environ["PYPI_TOKEN"] = "pypi-1234"
    with mock.patch("invoke.run") as run:
        upload_to_pypi(path="foo")
        run.assert_called_with(
            'twine upload -u \'__token__\' -p \'pypi-1234\' "foo/*"'
        )

    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = "user1"

# Generated at 2022-06-21 21:02:22.615853
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """

    # pylint: disable=import-outside-toplevel
    from .test_helpers import mock_package
    from .test_helpers import mock_pypi_repo
    from .test_helpers import remove_module
    import semantic_release as sr


# Generated at 2022-06-21 21:02:25.057398
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.

    Create wheels, try uploading to PyPI
    """
    upload_to_pypi()

# Generated at 2022-06-21 21:02:27.239068
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-21 21:02:27.878487
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:02:44.757619
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # GIVEN
    os.environ["PYPI_TOKEN"] = "pypi-test_token"
    os.environ["PYPI_USERNAME"] = "test_user"
    os.environ["PYPI_PASSWORD"] = "test_password"

    # WHEN
    upload_to_pypi()

    # THEN
    assert '"dist/*" "dist/test.txt"' in run.calls[0].args[0]
    assert " -u '__token__' -p 'pypi-test_token' --skip-existing" in run.calls[0].args[0]

# Generated at 2022-06-21 21:02:46.543888
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test/test_artifact", skip_existing=True)

# Generated at 2022-06-21 21:02:54.139075
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi"""
    # Test with env vars and no glob patterns
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]

    # Test with env vars and glob patterns
    os.environ["PYPI_TOKEN"] = "pypi-token"
    os.environ["PYPI_USERNAME"] = "test_username"
    upload_to_pypi(glob_patterns=["pattern1/*", "pattern2", "pattern3*"])
    del os.environ["PYPI_TOKEN"]
    del os.environ["PYPI_USERNAME"]

# Generated at 2022-06-21 21:02:55.211820
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-21 21:02:58.234832
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"

# Generated at 2022-06-21 21:03:04.992566
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["a*"])
    upload_to_pypi(glob_patterns=["*"])
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(path="path")
    upload_to_pypi(glob_patterns=['"*"'])
    upload_to_pypi(glob_patterns=["'*'"])

# Generated at 2022-06-21 21:03:09.486386
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist",
        skip_existing=True,
        glob_patterns=[
            "semantic_release_test-1.2.3-py3-none-any.whl",
            "semantic_release_test-1.2.3-py3-none-any.tar.gz",
        ],
    )
    assert True

# Generated at 2022-06-21 21:03:16.834755
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore

    with patch("invoke.run") as prun:
        with patch.dict("os.environ", {"PYPI_TOKEN": "pypi-abc"}):
            upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
            prun.assert_called_once_with(
                "twine upload -u '__token__' -p 'pypi-abc'  'dist/'"
            )

    with patch("invoke.run") as prun:
        with patch.dict("os.environ", {"PYPI_USERNAME": "pypi", "PYPI_PASSWORD": "abc"}):
            upload_

# Generated at 2022-06-21 21:03:20.060673
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    upload_to_pypi(path = "dist",skip_existing = False, glob_patterns = None)

# Generated at 2022-06-21 21:03:21.336543
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = "dist", skip_existing = False, glob_patterns = None)

# Generated at 2022-06-21 21:03:43.208020
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # In the fullness of time, when the config is more robust, we will add a mock to the
    # configuration. However, it is currently a very simple struct, so this short-cut should
    # be sufficient.
    # pylint: disable=unused-variable
    from .. import config
    config.repository = "test-repository"
    upload_to_pypi.__wrapped__("/tmp", False, ["*"])
    upload_to_pypi.__wrapped__("/tmp", True, ["my_wheel.whl"])

# Generated at 2022-06-21 21:03:45.399952
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test/dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-21 21:03:57.355614
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from tempfile import mkdtemp

    from .helpers import get_post_release_version
    from .helpers import get_pre_release_version


    # create a test dir
    tmpdir = mkdtemp()
    pre_version = get_pre_release_version()
    post_version = get_post_release_version()
    os.makedirs(f"{tmpdir}/dist")

    # create a test version file in the test dir
    version_file = open(f"{tmpdir}/dist/version.txt", "w")
    version_file.write(f"{tmpdir}\n{pre_version}\n{post_version}\n")

    # try to upload the test version file and verify that it worked
    upload_to_pypi(path=tmpdir)
    version_file.close

# Generated at 2022-06-21 21:04:07.180532
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    global os
    global run
    from mock import patch
    from mock import MagicMock

    os = MagicMock()
    run = MagicMock()

    os.environ = {
        "PYPI_TOKEN": "pypi-1234",
    }

    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["*"],
    )

    os.environ = {
        "PYPI_USERNAME": "user",
        "PYPI_PASSWORD": "password",
    }

    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=["*"],
    )

    os.environ = {
        "PYPI_USERNAME": "user",
    }

    upload_to

# Generated at 2022-06-21 21:04:19.596484
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test if the function upload_to_pypi() can run normally.
    :return: None
    """
    # For testing this function, we need to run the function in an environment in which the
    # PYPI_USERNAME and PYPI_PASSWORD environment variables have been set.
    # To do this, we create an environment.
    # The environment variables can be set for the time the function is running.
    # Referenced "https://docs.python.org/3/library/os.html#os.environ"

    # Set temporary environment variables
    os.environ["PYPI_USERNAME"] = "PYPI_USERNAME"
    os.environ["PYPI_PASSWORD"] = "PYPI_PASSWORD"

    # Run the function: If there are no exceptions, the test

# Generated at 2022-06-21 21:04:21.740982
# Unit test for function upload_to_pypi

# Generated at 2022-06-21 21:04:23.128388
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function"""

    pass

# Generated at 2022-06-21 21:04:30.358600
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    print('Executing Unit test for function upload_to_pypi')

    from .test_helpers import invoke_with_exceptions


    mock_env = {
        "git_branch": "master",
        "git_tag": "v1.0.0",
        "git_diff": "",
        "PYPI_TOKEN": "pypi-12345678901234567890",
        "PYPI_USERNAME": "",
        "PYPI_PASSWORD": "",
    }


# Generated at 2022-06-21 21:04:36.606817
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi:
    """
    # Upload without user
    upload_to_pypi(skip_existing=True)

    # TODO: check that the file was not uploaded
    # with username and password
    # with username, password and repository
    # if token
    # if skip_existing=False


# Generated at 2022-06-21 21:04:37.660618
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-21 21:05:09.280657
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:05:10.193311
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == "None"

# Generated at 2022-06-21 21:05:15.486411
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for upload_to_pypi
    """
    import os
    import random
    import shutil
    import sys
    import tempfile
    import unittest

    class TestUploadToPyPI(unittest.TestCase):
        def setUp(self):
            self.pypi_token = os.environ["PYPI_TOKEN"]
            self.pypi_username = os.environ["PYPI_USERNAME"]
            self.pypi_password = os.environ["PYPI_PASSWORD"]
            self.pypi_repository = os.environ["PYPI_REPOSITORY"]

            self.tempdir = tempfile.mkdtemp()

# Generated at 2022-06-21 21:05:16.593565
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:05:26.442245
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test code for function upload_to_pypi"""
    # Arrange
    from unittest.mock import patch

    from .helpers import LoggedFunction, mock_context_manager
    context_manager = mock_context_manager()

    # Act
    with patch("invoke.run") as mock_run:
        with patch("os.path.isfile") as mock_isfile:
            with patch("os.environ", {}):
                upload_to_pypi()

    # Assert
    assert LoggedFunction.calls[0]["message"] == (
        "Attempting to upload to PyPI with Twine"
    )
    assert LoggedFunction.calls[0]["level"] == logging.DEBUG

# Generated at 2022-06-21 21:05:27.060605
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:05:29.015703
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi"""
    upload_to_pypi()

# Generated at 2022-06-21 21:05:30.854843
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: add integration tests for this function
    pass

# Generated at 2022-06-21 21:05:43.253465
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .contexts import temp_chdir
    import logging
    import shutil
    from unittest.mock import call
    from tempfile import TemporaryDirectory

    from .helpers import patch_logger
    from .helpers import assert_cmd_run

    with temp_chdir(), patch_logger(logger, ["info"]) as mock_logger:
        with TemporaryDirectory(prefix="semantic-release-test-") as td:
            assert os.getcwd() == td
            os.mkdir("release-test")
            os.mkdir("dist")
            open("dist/foo", "w").close()
            open("dist/bar", "w").close()

            upload_to_pypi(path=os.path.join(td, "dist"), glob_patterns=["foo*", "bar"])

# Generated at 2022-06-21 21:05:45.755654
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    #pylint: disable=no-value-for-parameter
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:06:54.222776
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path = 'dist', gloob_patterns = ['*'])
    assert True

# Generated at 2022-06-21 21:06:54.716409
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:07:01.522097
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from contextlib import contextmanager
    from mock import patch, mock_open
    from semantic_release.pypi import upload_to_pypi

    # Test that token is used
    with ensure_auth_file_is_ignored():
        with patch.dict(os.environ, {"PYPI_TOKEN": "pypi-1234567890"}):
            with patch(
                "semantic_release.config._get_repo_name", return_value="my_repo"
            ):
                with patch("invoke.run") as run:
                    upload_to_pypi()
                    run.assert_called_once_with(
                        "twine upload -u '__token__' -p '1234567890' "
                        "-r 'my_repo' 'dist/*'"
                    )

    # Test

# Generated at 2022-06-21 21:07:08.180418
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    mod_pypi = upload_to_pypi
    mod_pypi.run = mock_run
    os.environ["PYPI_TOKEN"] = "pypi-123"

    mod_pypi()
    assert mod_pypi.run.call_count == 1
    assert mod_pypi.run.call_args[0][0] == "twine upload -u '__token__' -p 'pypi-123' 'dist/*'"
    del os.environ["PYPI_TOKEN"]

    os.environ["PYPI_USERNAME"] = "test-user"
    os.environ["PYPI_PASSWORD"] = "test-password"
    mod_pypi()
    assert mod_pypi.run.call_count == 2
   

# Generated at 2022-06-21 21:07:20.741457
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Arrange
    config["repository"] = "pypi"
    glob_patterns = ["pattern1"]
    dist = "./dist"
    distpath = os.path.abspath(dist)
    twinepath = os.path.join(os.path.dirname(__file__), "..", "twine.py")
    filename = os.path.join(distpath, glob_patterns[0])
    open(filename, "a").close()
    args = " ".join([f" {distpath}/{file}" for file in glob_patterns])
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"

# Generated at 2022-06-21 21:07:30.469960
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-abcd"
    from unittest.mock import call
    from semantic_release.hvcs import BaseRepository
    from semantic_release.settings import config
    from semantic_release.upload_to_pypi import upload_to_pypi

# Generated at 2022-06-21 21:07:38.821668
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run

    glob_patterns = ["*"]
    dist = " ".join(
        ['"{}/{}"'.format("dist", glob_pattern.strip()) for glob_pattern in glob_patterns]
    )
    username_password = "-u 'username' -p 'password'"
    run_command = f"twine upload {username_password} {dist}"
    assert(run_command == "twine upload -u 'username' -p 'password' \"dist/*\"")
    mock_run.assert_called_with(run_command)



# Generated at 2022-06-21 21:07:39.432940
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:07:46.696471
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function by using mocked commands"""
    from pathlib import Path
    import shutil

    from invoke.exceptions import UnexpectedExit

    from ._mock_output import StartMockBehavior
    from .helpers import get_temp_dir

    def run_setup_py(python_version="3.7", path="dist"):
        import subprocess
        from invoke import run, Collection

        from semantic_release import versioning

        version = versioning.get_next_version()
        collection = Collection()
        collection.add_task(run.run, "setup.py sdist bdist_wheel")
        if python_version.startswith("3"):
            cmd = collection.get("setup.py sdist bdist_wheel")

# Generated at 2022-06-21 21:07:58.056377
# Unit test for function upload_to_pypi
def test_upload_to_pypi(): # pylint: disable=unused-variable,unused-argument,redefined-outer-name,redefined-builtin
    from .helpers import patch
    from .helpers import run_command

    from unittest import mock
    from semantic_release.plugins.pypi.upload_to_pypi import upload_to_pypi as upload

    with mock.patch("invoke.run") as mocked_run:
        upload()
    mocked_run.assert_called_once_with("twine upload  *")

    with mock.patch('os.environ.get') as mocked_env:
        mocked_env.return_value = "pypi-something"
        upload()
    mocked_run.assert_called_with("twine upload -u '__token__' -p 'pypi-something'  *")

