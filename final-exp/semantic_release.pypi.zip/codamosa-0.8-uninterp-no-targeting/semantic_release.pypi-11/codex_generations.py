

# Generated at 2022-06-21 21:00:12.426163
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def run_double(cmd):
        run.assert_called_with(cmd)
        run.reset_mock()
        return ""

    run.side_effect = run_double
    # Test basic
    upload_to_pypi("dist")
    run.assert_called_with("twine upload  dist/")
    run.reset_mock()
    # Test multiple patterns
    upload_to_pypi("dist", glob_patterns=["*.whl", "*.gz"])
    run.assert_called_with("twine upload  'dist/*.whl' 'dist/*.gz'")
    run.reset_mock()
    # Test with repo
    upload_to_pypi("dist", repository="myrepo")

# Generated at 2022-06-21 21:00:14.314516
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Sample function, not the actual test.
    """
    upload_to_pypi()

# Generated at 2022-06-21 21:00:23.314338
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Testing upload_to_pypi"""
    import textwrap

    from mock import patch, mock_open
    from invoke.exceptions import UnexpectedExit


# Generated at 2022-06-21 21:00:32.634956
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:

        # Upload one file to pypi
        from semantic_release.tests.invoke_tests.files.files_for_testing import create_files_for_testing
        from semantic_release.tests.invoke_tests import local_setup
        local_setup.setup_env()

        create_files_for_testing(1)
        upload_to_pypi(True)

        # Upload two files to pypi
        create_files_for_testing(2)
        upload_to_pypi(False)

    except ImportError:

        pass

# Generated at 2022-06-21 21:00:43.053140
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="path/to/dist") == "twine upload 'path/to/dist'", "Simple upload"
    assert upload_to_pypi(glob_patterns=["*.py"]) == "twine upload '*.py'", "Simple upload with glob"
    assert upload_to_pypi(glob_patterns=["x*.py","y*.py"]) == "twine upload 'x*.py' 'y*.py'", "Simple upload with glob"
    os.environ["PYPI_TOKEN"] = "pypi-abcdefghijklmnopqrstuvwxyz1234567890"

# Generated at 2022-06-21 21:00:44.296614
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:00:51.576600
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class MockedRoutine(object):
        def __init__(self):
            self.calls = []

        def __call__(self, *args, **kwargs):
            self.calls.append((args, kwargs))

    mocked_routine = MockedRoutine()

    import sys
    import builtins
    builtins.__import__ = lambda *args, **kwargs: sys
    sys.modules["invoke.runners.run"] = mocked_routine

    # pylint: disable=no-member
    from .helpers.upload_to_pypi import upload_to_pypi

    upload_to_pypi("dist", skip_existing=False)

# Generated at 2022-06-21 21:00:55.139598
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    result = upload_to_pypi(
        path="dist",
        skip_existing=False,
        glob_patterns=["*-py3-none-any.whl"]
    )
    assert result == None

# Generated at 2022-06-21 21:00:55.711329
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 != 1

# Generated at 2022-06-21 21:01:06.728092
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch
    from .context import Context

    context = Context()
    with patch("invoke.run", return_value=None) as run_mock:
        upload_to_pypi(path="dist", glob_patterns=["my_file"])

    run_mock.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-1234abcd' "
        '"dist/my_file"'
    )

    context.config["repository"] = "testpypi"
    with patch("invoke.run", return_value=None) as run_mock:
        upload_to_pypi(path="dist", glob_patterns=["my_file"])

    run_mock.assert_called_once_

# Generated at 2022-06-21 21:01:14.458959
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create a fake dist folder with a fake wheel
    fake_wheel = "fakewheel.tar.gz"
    fake_dist_folder = "dist"
    fake_wheel_path = "{}/{}".format(fake_dist_folder, fake_wheel)
    os.mkdir(fake_dist_folder)
    with open(fake_wheel_path, 'w+') as f:
        f.write("This is a fake wheel")

    # Set fake credentials
    os.environ['PYPI_USERNAME'] = "test"
    os.environ['PYPI_PASSWORD'] = "test123"

    upload_to_pypi(path=fake_dist_folder, skip_existing=False, glob_patterns=["*"])

    # Verify files were deleted
    assert not os.path.exists

# Generated at 2022-06-21 21:01:15.944348
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:01:16.547118
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO implement test
    pass

# Generated at 2022-06-21 21:01:18.707450
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:01:19.708671
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-21 21:01:22.327552
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi"""
    if not config.get("pypi", False):
        return
    upload_to_pypi(path=".")

# Generated at 2022-06-21 21:01:34.255247
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with invalid arguments
    invalid_args = [
        # Test with missing argument path
        {},
        # Test with missing parts in arg path
        {"path": "./missing-parts/"},
        # Test with missing argument username
        {"path": "./tests/missing-username",},
        # Test with missing argument password
        {"path": "./tests/missing-password",},
        # Test with missing argument pypi_token
        {"path": "./tests/missing-pypi_token",},
    ]
    for args in invalid_args:
        try:
            upload_to_pypi(**args)
        except ImproperConfigurationError:
            assert True
        except Exception as e:
            assert False, "upload_to_pypi should not raise this exception but %s" % e

    # Test with valid

# Generated at 2022-06-21 21:01:37.187133
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", glob_patterns=["*"])
    assert 1 == 1


# Generated at 2022-06-21 21:01:42.573729
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch('os.environ.get') as env:
        env.return_value = 'pypi-token'
        with patch('invoke.run') as mock_run:
            upload_to_pypi('path')
            mock_run.assert_called_once_with("twine upload -u '__token__' -p 'pypi-token' 'path/*'")

# Generated at 2022-06-21 21:01:43.529834
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:01:51.808390
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:01:53.225435
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-21 21:02:03.092335
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    import tempfile
    from unittest.mock import patch

    from .helpers import LoggedFunctionTestCase
    from .test_pypi_config import pypi_config_tests_fixture

    class TestUploadToPyPi(LoggedFunctionTestCase):
        def setUp(self):
            self.temp_folder = tempfile.mkdtemp()
            self.dest = os.path.join(self.temp_folder, "dist")
            os.mkdir(self.dest)
            os.mkdir(os.path.join(self.dest, "test_folder"))
            open(os.path.join(self.dest, "test_folder", "test_file"), "w").close()
            open(os.path.join(self.dest, "test_file"), "w").close()



# Generated at 2022-06-21 21:02:16.317366
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def _upload_setup(*args, **kwargs):
        pass

    def _twine_upload_setup(*args, **kwargs):
        pass

    def _twine_upload_run_setup(*args, **kwargs):
        return ""

    import invoke
    import pytest

    from semantic_release.hvcs.pypi import upload_to_pypi as _upload_to_pypi

    if not os.environ.get("PYPI_TOKEN"):
        pytest.skip("PyPI token needed")

    invoke.run = _upload_setup
    _upload_to_pypi()

    invoke.run = _twine_upload_setup
    _upload_to_pypi()

    invoke.run = _twine_upload_run_setup
    _upload_to_pyp

# Generated at 2022-06-21 21:02:25.264631
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Tests to make sure upload_to_pypi uploads packages.

    This test is only useful when run locally.
    """
    import tempfile
    from shutil import rmtree
    from os.path import join

    tmp = tempfile.mkdtemp(prefix="test-")

# Generated at 2022-06-21 21:02:30.457203
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Unit test for Twine upload
    import shutil
    from unittest.mock import patch
    from unittest import TestCase
    from tempfile import mkdtemp
    from pathlib import Path

    from .helpers import create_dummy_package_with_setup

    class TestUploadPypi(TestCase):

        def setUp(self):
            self.tmp_path = Path(mkdtemp())
            self.package_dir = create_dummy_package_with_setup(self.tmp_path, "test_pkg")
            self.dist_dir = self.package_dir / "dist"
            os.chdir(str(self.package_dir))

        def tearDown(self):
            shutil.rmtree(str(self.tmp_path))

# Generated at 2022-06-21 21:02:37.902598
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.environ["PYPI_TOKEN"] = "pypi-12345"
        upload_to_pypi(glob_patterns=["*"])
    except ImproperConfigurationError:
        raise AssertionError("Credential expected but did not get any")

    os.environ["PYPI_TOKEN"] = ""
    try:
        upload_to_pypi(glob_patterns=["*"])
    except ImproperConfigurationError:
        pass
    else:
        raise AssertionError("Credential expected but did not provide any")

# Generated at 2022-06-21 21:02:48.605010
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    from unittest.mock import patch, MagicMock
    from invoke import run

    def set_env_vars(env_dict):
        for env_var, value in env_dict.items():
            os.environ[env_var] = value

    def unset_env_vars(env_list):
        for env_var in env_list:
            del os.environ[env_var]

    # TODO: Create and tear down a temporary folder

    token = "pypi-1234567890qwertyuiopasdfghjklzxcvbnm"
    username = "testusername"
    password = "testpassword"
    dist = "dist"
    glob_patterns = ["*.whl", "*.tar.gz"]

    # Test with environment variables

# Generated at 2022-06-21 21:02:53.461712
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Check calling the function without passing a token
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        assert False, "Missing credentials not detected"

    # Check that passing a token without the correct prefix fails
    try:
        upload_to_pypi(token="abcd")
    except ImproperConfigurationError:
        pass
    else:
        assert False, "Incorrect token prefix not detected"

    # Any further test cases are not in the scope of the unit test

# Generated at 2022-06-21 21:03:05.466182
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = "1234"
    username = "username"
    password = "password"
    repository = "repository"
    setup_cfg_path = os.path.abspath(__file__).split('plugins')[0]
    setup_cfg = f'{setup_cfg_path}.pypirc'
    dist_path = os.path.abspath(__file__).split('plugins')[0]
    dist = f'{dist_path}dist'
    glob_pattern = ['*']

    # Case: no credentials provided
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass

    # Case: token provided
    try:
        upload_to_pypi(glob_patterns=glob_pattern)
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-21 21:03:24.885853
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test if upload_to_pypi uses proper twine command to upload wheel(s)"""
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:03:25.837020
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:03:26.445950
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:03:34.420407
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "foo"
    os.environ["PYPI_PASSWORD"] = "bar"
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    except Exception as e:
        print(e)
    finally:
        os.environ.pop("PYPI_USERNAME")
        os.environ.pop("PYPI_PASSWORD")

    os.environ["PYPI_TOKEN"] = "foo"
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    except Exception as e:
        print(e)
    finally:
        os.environ.pop("PYPI_TOKEN")


# Generated at 2022-06-21 21:03:42.552745
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import set_environment_variables
    from .helpers import remove_test_files
    import random
    import os
    import sys
    import uuid

    key_value = str(uuid.uuid4()).split('-')[0]
    key_value_pypi = f"pypi-{key_value}"
    value = "./test"
    os.environ["PYPI_USERNAME"] = key_value
    os.environ["PYPI_PASSWORD"] = key_value_pypi
    os.environ["PYPI_TOKEN"] = key_value_pypi

# Generated at 2022-06-21 21:03:43.660275
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 == 1

# Generated at 2022-06-21 21:03:50.659718
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # no args
    try:
        upload_to_pypi()
    except Exception as e:
        if str(e) != "Missing credentials for uploading to PyPI":
            raise Exception("expected Exception")
    # with args
    upload_to_pypi(
        path="dist",
        skip_existing=False,
        glob_patterns=["*.whl", "*.tar.gz"],
    )


test_upload_to_pypi()

# Generated at 2022-06-21 21:03:51.844811
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert "Not Implemented"

# Generated at 2022-06-21 21:03:53.396262
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == "Uploaded to PyPI"

# Generated at 2022-06-21 21:04:00.048036
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import twine
    from unittest.mock import patch, MagicMock

    twine_upload_mock = MagicMock()
    with patch.object(twine, 'upload', twine_upload_mock):
        upload_to_pypi()
    assert twine_upload_mock.call_count == 1
    assert twine_upload_mock.call_args[0] == ([],)

# Generated at 2022-06-21 21:04:42.601213
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # type: () -> None
    import io
    import json
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode
    from .helpers import get_env, setup_env
    from .tmpdir_helpers import create_files

    def api_request(data_dict):
        # type: (Dict[str, str]) -> Dict[str, str]
        request_data = json.dumps(data_dict).encode()
        request = Request(
            "https://upload.pypi.org/legacy/", data=request_data, method="POST"
        )
        request.add_header("Content-Type", "application/json")
        request.add_header(
            "Content-Length", len(request_data)
        )

# Generated at 2022-06-21 21:04:52.692251
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Upload to PyPI with an API token
    os.environ["PYPI_TOKEN"] = "pypi-abcdef3010101abcabc01010111010101010101"
    os.environ["HOME"] = "/"
    upload_to_pypi()

    # Upload to PyPI with API token in non-standard location
    os.environ["PYPI_TOKEN"] = "pypi-abcdef3010101abcabc01010111010101010101"
    os.environ["HOME"] = "/nonstandard/home/dir"
    upload_to_pypi()

    # Upload to PyPI with a username and password
    os.environ["PYPI_USERNAME"] = "username"

# Generated at 2022-06-21 21:04:54.989829
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:05:07.546554
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Tests the upload_to_pypi function with and without a glob pattern.
    """
    glob_pattern = config.get("upload_to_pypi_glob_pattern")
    expected_command_default = (
        "twine upload --skip-existing " "dist/wheel/wheel-file.whl dist/wheel/wheel-file2.whl"
    )
    actual_command_default = upload_to_pypi(
        skip_existing=True, path="dist/wheel", glob_patterns=glob_pattern
    )
    assert actual_command_default == expected_command_default

    expected_command_no_glob_pattern = f"twine upload --skip-existing {glob_pattern[0]}"
    actual_command_no_glob_pattern = upload_to_pypi

# Generated at 2022-06-21 21:05:08.383709
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:05:09.777633
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-21 21:05:22.602206
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Checks if the input is valid, throws an error otherwise
    def _check_input(path: str, skip_existing: bool, glob_patterns: List[str]):
        try:
            upload_to_pypi(path, skip_existing, glob_patterns)
        except ImproperConfigurationError:
            pass
        else:
            assert False

    # Checks if the input is valid, throws an error otherwise
    def _check_token_input():
        try:
            upload_to_pypi()
        except ImproperConfigurationError:
            pass
        else:
            assert False

    # Store original env variables to restore them after the test
    original_env = dict(os.environ)

    # Check for exception when no credentials are provided
    # No env variables set
    _check_token_input()
    # Only

# Generated at 2022-06-21 21:05:25.912139
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        path="dist", 
        glob_patterns=None
    )
    return

# Generated at 2022-06-21 21:05:33.781926
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from hypothesis import assume, given
    from hypothesis.strategies import booleans, text
    from hypothesis.extra.pytest import register_assert_rewrite

    import pytest
    from _pytest.monkeypatch import MonkeyPatch
    from unittest import mock

    register_assert_rewrite("semantic_release.hvcs.git.run")
    register_assert_rewrite("invoke.run")

    # Monkey patch invoke.run to check it was called properly
    patch = MonkeyPatch()
    patch.setattr(
        "invoke.run",
        mock.Mock(
            return_value=None,
        ),
    )
    # pylint: disable=unused-variable,redefined-outer-name

# Generated at 2022-06-21 21:05:36.523678
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    glob_patterns = ["*.whl"]
    upload_to_pypi(path, False, glob_patterns)

# Generated at 2022-06-21 21:06:53.546783
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    import os
    import tempfile

    from semantic_release.errors import ImproperConfigurationError

    with tempfile.TemporaryDirectory() as tmpdirname:
        with patch("os.environ", {**os.environ, "HOME": tmpdirname}):
            # Missing credentials
            with open(os.path.join(tmpdirname, ".pypirc"), 'w') as f:
                f.write("")

            try:
                upload_to_pypi()
            except ImproperConfigurationError:
                assert True
            else:
                assert False


# Generated at 2022-06-21 21:06:55.332376
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True, ["*"])

# Generated at 2022-06-21 21:07:01.804813
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test normal usage
    assert run("twine upload --help").ok is True
    assert run("twine upload --version").ok is True
    assert run("twine upload --repository-url test dist/test.txt").ok is True
    assert run("twine upload --non-interactive dist/test.txt").ok is True
    assert run("twine upload --skip-existing dist/test.txt").ok is True

    # Test env vars usage
    os.environ["HOME"] = "test"
    assert os.path.isfile(os.path.join(os.environ.get("HOME", ""), ".pypirc")) is False
    os.environ["PYPI_USERNAME"] = "test"
    assert run("twine upload --skip-existing dist/test.txt").ok is True
    os.en

# Generated at 2022-06-21 21:07:03.162043
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Need to actually test that twine upload happens
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:07:05.886819
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # When: Uploading to PyPI using an API token
    # Then: Upload should not fail
    upload_to_pypi(
        path=".",
        skip_existing=False,
        glob_patterns= ["semantic_release_testfile_172383.txt"],
    )

# Generated at 2022-06-21 21:07:18.966073
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test that a token is not required when a username and password are provided.
    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "pass"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]
    # Test that a username and password are not required when a token is provided.
    os.environ["PYPI_TOKEN"] = "pypi-abc"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]
    # Test that a token without the prefix "pypi-" fails.
    os.environ["PYPI_TOKEN"] = "abc"

# Generated at 2022-06-21 21:07:27.796831
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import mock
    from . import pypi

    pypi.run = mock.Mock()
    pypi.upload_to_pypi()
    pypi.run.assert_called_once_with(
        "twine upload *", hide="out", warn=True
    )
    pypi.run.reset_mock()
    pypi.upload_to_pypi(
        path="new_dist",
        skip_existing=True,
        glob_patterns=["glob_pattern"],
    )
    pypi.run.assert_called_once_with(
        "twine upload --skip-existing \"new_dist/glob_pattern\"", hide="out", warn=True
    )

# Generated at 2022-06-21 21:07:29.648684
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    upload_to_pypi()

# Generated at 2022-06-21 21:07:38.030067
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import pytest
    import shutil

    try:
        os.environ["PYPI_TOKEN"] = "pypi-test-token"
        os.mkdir("dist")
        with open("dist/test.txt", "w") as f:
            f.write("test")

        upload_to_pypi(path="dist")

        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi(path="dist")
    finally:
        shutil.rmtree("dist")
        del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-21 21:07:38.598371
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
  pass