

# Generated at 2022-06-21 21:00:10.007199
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:00:12.782095
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        config.get("repository")
    except AttributeError:
        config.repository = "pypitest"
    upload_to_pypi()

# Generated at 2022-06-21 21:00:17.924332
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Function upload_to_pypi creates correct Twine command."""
    from semantic_release.settings import build_config

    build_config("tests/fixtures/repos/tests/config.ini")
    upload_to_pypi("dist")

    cmd = "twine upload -u '__token__' -p 'pypi-token' 'dist/*'"
    assert run.calls[0].args == cmd

# Generated at 2022-06-21 21:00:19.544077
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test cases for function upload_to_pypi
    """
    # TODO: Add unit test

# Generated at 2022-06-21 21:00:21.647437
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=False, glob_patterns=[])

# Generated at 2022-06-21 21:00:23.405483
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""

    pass

# Generated at 2022-06-21 21:00:27.224794
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="tests/test_files/dist", glob_patterns = ["*"])

# Generated at 2022-06-21 21:00:31.780888
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def verify_upload_call(*args, **kwargs):
        assert "upload" in args[0]

    orig_run = run
    run = verify_upload_call

    upload_to_pypi(path="path", skip_existing=True, glob_patterns=["dummy"])

    run = orig_run

# Generated at 2022-06-21 21:00:33.354650
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
test_upload_to_pypi()

# Generated at 2022-06-21 21:00:37.517856
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*.tar.gz"])

# Generated at 2022-06-21 21:00:46.683268
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=['*.whl'])

# Generated at 2022-06-21 21:00:54.946627
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    from .helpers import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        # Creates 2 files on a TemporaryDirectory
        # and returns the full path to the directory
        dist = os.path.join(temp_dir, "dist")
        os.mkdir(dist)
        with open(os.path.join(dist, "sample-file.tar.gz"), "w+") as f:
            f.write("zip file")

        with open(os.path.join(dist, "sample-file.tar.whl"), "w+") as f:
            f.write("wheel file")

        upload_to_pypi(path=dist)

# Generated at 2022-06-21 21:01:00.572169
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # No parameters:
    upload_to_pypi()

    # Only path:
    upload_to_pypi(path="new_dist")

    # Only skip existing:
    upload_to_pypi(skip_existing=True)

    # Only glob_patterns:
    upload_to_pypi(glob_patterns=["*.txt"])

    # All parameters:
    upload_to_pypi(path="new_dist", skip_existing=True, glob_patterns=["*.txt"])

# Generated at 2022-06-21 21:01:12.585056
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    logging.getLogger().setLevel(logging.DEBUG)

    # Set environment variable
    os.environ["PYPI_TOKEN"] = "pypi-hash"
    pypi_class_args = {"skip_existing": "True", "glob_patterns": ["*.txt", "*.py"]}

    upload_to_pypi(**pypi_class_args)

    # Command will be run with:
    #   twine upload --skip-existing -u __token__ -p pypi-hash "dist/*.txt" "dist/*.py"
    assert run.called
    called_args = run.call_args[0][0]
    assert called_args.startswith(
        "twine upload --skip-existing -u __token__ -p pypi-hash "
    )

# Generated at 2022-06-21 21:01:21.591804
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch("invoke.run", return_value=None) as mock_run:
        upload_to_pypi(
            path="dist",
            glob_patterns=["file1", "file2"],
        )
        mock_run.assert_called_once_with(
            "twine upload "
            "-u '__token__' -p 'pypi-ABC123' "
            "--skip-existing "
            '"dist/file1" "dist/file2"'
        )

# Generated at 2022-06-21 21:01:23.349631
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    dist = "dist"
    upload_to_pypi(path=dist, skip_existing=False)

# Generated at 2022-06-21 21:01:27.325395
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with open(".pypirc", "w") as pypirc:
        pypirc.write(
            f"""[distutils]
index-servers =
    pypi

[pypi]
repository:{config.get('repository')}
username:{config.get('username')}
password:{config.get('password')}
"""
        )
    upload_to_pypi(path="dist")
    os.remove(".pypirc")

# Generated at 2022-06-21 21:01:40.510514
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test without any credentials
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        assert False

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        assert False
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Test with token
    token = "pypi-abcdefg"
    os.environ["PYPI_TOKEN"] = token

# Generated at 2022-06-21 21:01:46.895026
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(glob_patterns=["*"])
    upload_to_pypi(glob_patterns=["*.py"])
    upload_to_pypi(glob_patterns=["*.py", "*.json"])
    upload_to_pypi(skip_existing=False)
    upload_to_pypi(skip_existing=True)
    upload_to_pypi(path="dist")
    upload_to_pypi(path="random_path")

# Generated at 2022-06-21 21:01:47.521748
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-21 21:02:16.317549
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=unused-argument
    def mock_run(command: str):
        """Mock function for invoke.run.
        """
        assert "twine upload " in command
        assert " -u '' -p ''" in command
        assert " --skip-existing" not in command
        assert " -r 'repo'" in command
        assert '"dist/my-0.0.1-py3-none-any.whl"' in command
        assert '"dist/my-0.0.1.tar.gz"' in command

    run_orig = run

# Generated at 2022-06-21 21:02:25.237544
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import semantic_release
    import re
    import os
    import shutil
    import tempfile

    from semantic_release.settings import config
    from semantic_release.plugins.pypi.uploader import upload_to_pypi

    # Need to skip the test if this is a user without credentials
    if (
        not os.environ.get("PYPI_TOKEN", None)
        and not (
            os.environ.get("PYPI_USERNAME", None)
            and os.environ.get("PYPI_PASSWORD", None)
        )
    ):
        return

    # The test function contains two parts:
    # 1. It uploads the current package distribution on PyPI, and checks it was successful
    # 2. It removes the uploaded distribution from PyPI

    # Retrieve the current package version

# Generated at 2022-06-21 21:02:30.458808
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import Context

    context = Context(config={"repository": "random"})

    with context.task() as task:
        task.config["repository"] = "random"
        upload_to_pypi()
        context.run_mock.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-secret' -r 'random' 'dist/*'"
        )

    with context.task() as task:
        upload_to_pypi(repository="random")
        context.run_mock.assert_called_once_with(
            "twine upload -u '__token__' -p 'pypi-secret' -r 'random' 'dist/*'"
        )

    with context.task() as task:
        upload

# Generated at 2022-06-21 21:02:31.366747
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-21 21:02:36.925626
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    uploaded_files = []
    def mock_run(*args, **kwargs):
        nonlocal uploaded_files
        uploaded_files = [arg for arg in args[0].split(" ") if os.path.isfile(arg[1:-1])]
    run_orig = run
    try:
        run = mock_run
        upload_to_pypi(path="tests/test_files/dist")
    finally:
        run = run_orig

    assert uploaded_files == ['tests/test_files/dist/test-0.2.1-py2.py3-none-any.whl']

    uploaded_files = []

# Generated at 2022-06-21 21:02:37.591163
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 == 1

# Generated at 2022-06-21 21:02:48.325926
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    We test by creating a directory and some files to upload,
    then checking twine uses the correct parameters.
    """
    from pathlib import Path
    from unittest.mock import patch
    from invoke.runners import Result

    # Create dir to save files
    path = Path("test_dir") / "dir"
    if path.exists():
        path.rmdir()
    path.mkdir()
    path.joinpath("file1").touch()
    path.joinpath("file2").touch()
    path.joinpath("file3.py").touch()

    # Mock invoke.run
    class MockResult(Result):
        def __init__(self, command):
            self.command = command


# Generated at 2022-06-21 21:02:49.451124
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Mock out the Twine run method and verify output
    assert True

# Generated at 2022-06-21 21:02:55.910847
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import mock
    run_mock = mock.Mock()
    run_mock.return_value = {}
    with mock.patch("invoke.run", run_mock):
        upload_to_pypi()

    _, kwargs = run_mock.call_args
    assert kwargs["run"].startswith("twine upload --skip-existing")

    run_mock.reset_mock()

    with mock.patch("invoke.run", run_mock):
        upload_to_pypi(glob_patterns=["test-*.whl"])

    _, kwargs = run_mock.call_args
    assert kwargs["run"].startswith("twine upload --skip-existing")
    assert "--skip-existing" in kwargs["run"]

   

# Generated at 2022-06-21 21:03:07.416600
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import filecmp
    import io
    import tarfile
    import tempfile
    import zipfile

    def make_example_file(name):
        with open(name, "w") as example_file:
            example_file.write(name + "\n")

    def make_example_tarfile(path):
        t = tarfile.open(path, "w")
        t.add("test_upload_to_pypi.py", arcname="test_upload_to_pypi.py")
        t.close()

    def make_example_zipfile(path):
        z = zipfile.ZipFile(path, "w")
        z.write("test_upload_to_pypi.py")
        z.close()

    # Create an example file
    # Create an example directory
    # Create two example archives

# Generated at 2022-06-21 21:03:24.281615
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    _upload_to_pypi()


# Generated at 2022-06-21 21:03:31.609862
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if os.path.isdir("dist"):
        run("rm -rf dist")
    run("python setup.py sdist bdist_wheel")
    assert os.path.isdir("dist")
    run("touch dist/test.txt")
    assert os.path.isfile("dist/test.txt")
    PYPI_PASSWORD = os.getenv("PYPI_PASSWORD")
    os.environ["PYPI_PASSWORD"] = ""
    upload_to_pypi(glob_patterns=["*"])
    os.environ["PYPI_PASSWORD"] = PYPI_PASSWORD

# Generated at 2022-06-21 21:03:39.739939
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from pathlib import Path
    from contextlib import contextmanager
    from semantic_release.hvcs import (
        fetch_repository,
        get_vcs_client,
        get_version,
        push_changes,
        update_version,
    )

    @contextmanager
    def test_release():
        with tempfile.TemporaryDirectory() as temp_dir_name:
            repository = "https://github.com/relekang/test-repo"
            with fetch_repository(repository, temp_dir_name) as path:
                yield path

    with test_release() as path:
        vcs = get_vcs_client(path)
        version = get_version(vcs)
        update_version(vcs, str(version))

# Generated at 2022-06-21 21:03:40.637002
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # not sure how to do this
    pass

# Generated at 2022-06-21 21:03:41.743385
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert isinstance(upload_to_pypi(), None)

# Generated at 2022-06-21 21:03:50.341132
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    uploaded = False
    def mock_run(cmd, echo=True):
        nonlocal uploaded
        if "twine upload" in cmd:
            uploaded = True
    run = mock_run
    upload_to_pypi()
    assert(uploaded)
    uploaded = False
    upload_to_pypi(skip_existing=True)
    assert(uploaded)
    uploaded = False
    upload_to_pypi(glob_patterns=["*.whl"])
    assert(uploaded)

# Generated at 2022-06-21 21:03:58.868428
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["package1", "package2"])
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["package1", "package2"])

# Generated at 2022-06-21 21:04:08.156180
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # file token.py should be in the same folder as this file
    import token
    import platform
    import pkg_resources

    os.environ['PYPI_TOKEN'] = token.pypi_token
    os.environ['PYPI_USERNAME'] = token.pypi_username
    os.environ['PYPI_PASSWORD'] = token.pypi_password

    dist_dir = 'dist'

    python_version = platform.python_version()
    wheel_file = pkg_resources.resource_filename( __name__, 'logtest-0.1.1-py2.py3-none-any.whl' )

    wheel_file_name = wheel_file.split('/')[-1]

# Generated at 2022-06-21 21:04:08.783621
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:04:20.235966
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create some files to be uploaded
    os.makedirs("dist")
    os.makedirs("dist2")


    # Testing with API token
    os.environ["PYPI_TOKEN"] = "pypi-test-token"
    upload_to_pypi("dist", glob_patterns=["test1.whl", "test2.whl"])

    # Testing with username and password
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    upload_to_pypi("dist2", glob_patterns=["test1.whl", "test2.whl"])

# Generated at 2022-06-21 21:05:05.350500
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi.
    """

    # Define parameters
    path = "/tmp/path"
    skip_existing = True
    glob_patterns = ["*.whl"]
    token = "pypi-token"
    username = "__token__"
    password = token

    # Define expected Twine command
    twine_command = (
        f"twine upload -u '{username}' -p '{password}' --skip-existing"
        f' "dist/{glob_patterns[0]}"'
    )

    # Mock Twine call
    os.environ["PYPI_TOKEN"] = token
    from unittest.mock import patch


# Generated at 2022-06-21 21:05:07.768738
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:05:14.190443
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """

    from unittest.mock import patch

    from .helpers import LoggedFunction
    from .helpers import patch_environment, reset_environment
    from .helpers import patch_get_executable_path

    from .environment import (
        PYPI_TOKEN,
        PYPI_USERNAME,
        PYPI_PASSWORD,
        SEMANTIC_RELEASE_REPOSITORY,
        HOME,
    )


# Generated at 2022-06-21 21:05:23.370919
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # This starts a new process to run the code because the tests cannot be run as a normal module
    # due to the decorator that is applied to the function.
    # You can run your tests from the command line with:
    # python -m test.upload_to_pypi_test
    if __name__ == "__main__":
        print('The module is being run directly.')
        path = "dist"
        skip_existing = False
        glob_patterns = None
        upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)

# Generated at 2022-06-21 21:05:30.865085
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        run("mkdir test_dist")
        run("touch test_dist/test-wheel-1.whl")
        run("touch test_dist/test-wheel-2.whl")
        os.environ["PYPI_TOKEN"] = "pypi-FAKE_TOKEN"
        upload_to_pypi(path='test_dist', skip_existing=False, glob_patterns=['*'])
    finally:
        run("rm -rf test_dist")

# Generated at 2022-06-21 21:05:43.305611
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mockrun(cmd):
        assert cmd == 'twine upload -u "__token__" -p "pypi-mytoken" --skip-existing "dist/*"'
        return 1
    old_run = run
    run = mockrun
    to_pypi = os.environ.get("TO_PYPI", "")
    os.environ["TO_PYPI"] = "true"
    os.environ["PYPI_TOKEN"] = "pypi-mytoken"
    config["repository"] = "pypi"
    upload_to_pypi(str(Path(__file__).parent / 'dist'), True)
    os.environ["TO_PYPI"] = to_pypi

# Generated at 2022-06-21 21:05:44.337786
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:05:54.875030
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_token_run(command):
        assert command == (
            'twine upload -u \'__token__\' -p \'pypi-abcd\' '
            '"dist/package-name-1.2.3-py2.py3-none-any.whl"'
        )

    def mock_username_password_run(command):
        assert command == (
            'twine upload -u \'user\' -p \'password\' '
            '"dist/package-name-1.2.3-py2.py3-none-any.whl"'
        )

    def mock_pypirc_run(command):
        assert command == (
            'twine upload "dist/package-name-1.2.3-py2.py3-none-any.whl"'
        )

    # Test with

# Generated at 2022-06-21 21:05:55.816016
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-21 21:06:01.504278
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        run(f"rm -rf dist")
    except:
        pass
    try:
        run(f"mkdir dist")
    except:
        pass
    run(f"touch dist/file_a")
    run(f"touch dist/file_b")
    run(f"touch dist/file_c")
    try:
        os.environ['PYPI_TOKEN'] ='pypi-sample-token'
        upload_to_pypi(glob_patterns=["*"])
    except ImproperConfigurationError as e:
        pass

    os.environ['PYPI_TOKEN'] =''
    run(f"rm -rf dist")

# Generated at 2022-06-21 21:07:06.151820
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="./dist", skip_existing=False, glob_patterns=["./*"])

# Generated at 2022-06-21 21:07:15.427015
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # To run this test, uncomment the lines below.
    # Also you need to setup credentials.
    #
    # But don't do this if you don't know how to delete the packages uploaded.
    #
    # This test is not intended to run as part of a CI.

    # def test_function(c):
    #     upload_to_pypi()
    #
    # c.run("pytest tests/test_twine_upload.py -s", pty=True)
    pass

# Generated at 2022-06-21 21:07:21.794179
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    patch("invoke.run").start()
    upload_to_pypi(path="dist", skip_existing=False)
    upload_to_pypi(path="dist", skip_existing=True)
    upload_to_pypi(path="dist", skip_existing=False)
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["setup.py"])
    patch.stopall()

# Generated at 2022-06-21 21:07:29.592390
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command, warn=False):
        assert command == "twine upload --skip-existing 'dist/some_file'"
    
    def mock_environ(key, value=""):
        assert key == "PYPI_USERNAME"
        return "some_user"

    with patch.object(invoke, 'run', mock_run) as run:
        with patch.object(os, 'environ', mock_environ) as environ:
            upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["some_file"])
            assert environ.called
            assert run.called

# Generated at 2022-06-21 21:07:30.600452
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:07:31.755628
# Unit test for function upload_to_pypi

# Generated at 2022-06-21 21:07:42.084172
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function"""
    import pytest
    import shutil
    import tempfile

    # Define test values
    current_dir = os.path.dirname(os.path.realpath(__file__))
    wheel_file = os.path.join(current_dir, "test_wheel.whl")
    wheel_file_2 = os.path.join(current_dir, "test_wheel_2.whl")

    # Make sure the wheel file exists
    assert os.path.isfile(wheel_file), "Can't find wheel file for test_upload_to_pypi"

    # Make sure we can use a glob instead of a filename
    shutil.copyfile(wheel_file, wheel_file_2)

# Generated at 2022-06-21 21:07:43.541993
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test to ensure correct functioning of upload_to_pypi.
    """
    upload_to_pypi()

# Generated at 2022-06-21 21:07:45.247620
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:07:52.051886
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Function upload_to_pypi returns the right commands.
    """
    assert upload_to_pypi("dist", True) == "twine upload  --skip-existing "
    assert upload_to_pypi("dist") == "twine upload   "
    assert upload_to_pypi("dist", False, ["foo", "bar"]) == 'twine upload   "dist/foo" "dist/bar"'