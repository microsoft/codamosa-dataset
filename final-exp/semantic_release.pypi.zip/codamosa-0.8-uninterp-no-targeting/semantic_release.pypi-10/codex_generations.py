

# Generated at 2022-06-21 21:00:16.845680
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    import tempfile
    import shutil
    from semantic_release.uploaders import pypi

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    run.__globals__["_log"] = logger
    run.__globals__["echo"] = logger.info

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 21:00:25.415701
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import mock
    from semantic_release.settings import init_config
    from .helpers import dist
    from shutil import copytree, rmtree
    from tempfile import mkdtemp
    from glob import glob

    temp_dir = mkdtemp()
    dist_dir = os.path.join(temp_dir, "dist")

# Generated at 2022-06-21 21:00:26.018968
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:00:29.980326
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="/dist", skip_existing=True, glob_patterns=["*"])
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=['*'])

# Generated at 2022-06-21 21:00:32.403698
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="./tests/test-dist", glob_patterns=["*.whl"], skip_existing=True)

# Generated at 2022-06-21 21:00:42.941278
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch, MagicMock
    from unittest import TestCase
    from semantic_release import ImproperConfigurationError
    from semantic_release.settings import config, set_config_variable
    from .helpers import LoggedFunction

    os.environ["HOME"] = "/home"
    with TestCase.assertRaises(TestCase, ImproperConfigurationError):
        upload_to_pypi(glob_patterns=["*"])

    # Test with Twine 1.x, single file, no repository
    os.environ["PYPI_USERNAME"] = "test_user"
    os.environ["PYPI_PASSWORD"] = "test_password"
    run = MagicMock()

# Generated at 2022-06-21 21:00:48.857218
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import random

    os.environ['PYPI_USERNAME'] = 'test'
    os.environ['PYPI_PASSWORD'] = 'test'
    path = tempfile.mkdtemp()
    try:
        test_file = os.path.join(path, str(random.randint(1, 1000)))
        with open(test_file, 'w') as f:
            f.write('a')

        upload_to_pypi(path)
    finally:
        shutil.rmtree(path)

# Generated at 2022-06-21 21:00:49.904628
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:00:52.385571
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert (
        upload_to_pypi.__wrapped__(
            path="", skip_existing=False, glob_patterns=None
        )
        == None
    )

# Generated at 2022-06-21 21:00:53.995399
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:00:59.748714
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == "twine upload -u "

# Generated at 2022-06-21 21:01:02.543686
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-21 21:01:05.128042
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    assert upload_to_pypi() == True

# Generated at 2022-06-21 21:01:10.508273
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with open('dist_setup.py', 'w') as f:
        f.write("hello")

    try:
        upload_to_pypi('dist_setup.py')
    except Exception as e:
        if not username and not password:
            return
        else:
            raise e

    raise Exception("No exception thrown")

# Generated at 2022-06-21 21:01:11.785453
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True, ["*"])

# Generated at 2022-06-21 21:01:16.326076
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    import os

    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()
    os.environ['PYPI_USERNAME'] = 'PY_USERNAME'
    os.environ['PYPI_PASSWORD'] = 'PY_PASSWORD'
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi(skip_existing=True) # skip_existing is only valid for PyPI

# Generated at 2022-06-21 21:01:18.505164
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-1234"
    upload_to_pypi()

# Generated at 2022-06-21 21:01:26.879145
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Setup
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    token = ""
    username = ""
    password = ""
    home_dir = os.environ.get("HOME", "")
    package_name = "test_upload"

    ### Test 1: Missing credentials for uploading to PyPI should raise error
    ## test case: token is missing, username and password are missing, no .pypirc file found
    try:
        upload_to_pypi(path, skip_existing, glob_patterns) 
    except ImproperConfigurationError as e:
        assert "Missing credentials for uploading to PyPI" == str(e)
    else:
        assert False, "Missing credentials for uploading to PyPI, should raise error"

    ### Test 2: PyPI token should begin with pypi

# Generated at 2022-06-21 21:01:40.071505
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Set up test variables for this function.
    test_credentials = {
        'username': 'pypi-username',
        'password': 'pypi-password',
        'token': 'pypi-token',
        'token_start': 'pypi-',
        'bad_token': 'abcdef-token'
    }
    test_glob_patterns = ['dist/*.whl', 'dist/*.zip']

    # Get the values for variables that are being used in the function.
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")
    token = os.environ.get("PYPI_TOKEN")
    repository = config.get("repository", None)

    username_password = f

# Generated at 2022-06-21 21:01:47.209893
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import LoggedFunction
    from .helpers import logger

    global logger

    @LoggedFunction(logger)
    def fake_run(command):
        return command

    global run
    run = fake_run

    config["repository"] = "https://test.pypi.org/"
    os.environ["HOME"] = "/var/tmp"

    assert upload_to_pypi() == "twine upload -u '__token__' -p 'pypi-my_token' -r 'https://test.pypi.org/' 'dist/*'"

    os.environ["PYPI_TOKEN"] = "pypi-my_token"
    os.environ.pop("HOME")

# Generated at 2022-06-21 21:01:57.941704
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi(glob_patterns=['multiple_patterns/**/*.whl', '*.tar.gz'])
    except:
        return True

# Generated at 2022-06-21 21:01:59.318036
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert callable(upload_to_pypi)

# Generated at 2022-06-21 21:02:06.778154
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from invoke import MockContext
    from semantic_release.plugins.pypi_publish import upload_to_pypi

    with MockContext() as c:
        upload_to_pypi()
        c.run.assert_called_with(
            'twine upload -u \'__token__\' -p \'pypi-xxx\' "dist/*"'
        )

    with MockContext() as c:
        upload_to_pypi(glob_patterns=["dist/*.whl"])
        c.run.assert_called_with(
            'twine upload -u \'__token__\' -p \'pypi-xxx\' "dist/*.whl"'
        )

    with MockContext() as c:
        upload_to_pypi(repository="testpypi")
        c.run

# Generated at 2022-06-21 21:02:10.784990
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test to ensure that if neither username/password nor token is set, ImproperConfigurationError is raised
    """
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        assert True
        return
    assert False

# Generated at 2022-06-21 21:02:12.320139
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi.__wrapped__("dist", True)

# Generated at 2022-06-21 21:02:15.446290
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi."""
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()

# Generated at 2022-06-21 21:02:24.762054
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
    except ImportError:
        logger.error("twine is not installed. Skipping tests.")
        return

    # Check that it runs correctly.
    def run_mock(command):
        assert command == (
            'twine upload -u \'__token__\' -p \'pypi-1234\' --skip-existing -r \'pypi\' '
            '"dist/foo.whl" "dist/bar.whl" "dist/baz.whl"'
        )

    assert run_mock.__name__ == "run"

    upload_to_pypi(
        path="dist",
        skip_existing=True,
        glob_patterns=["foo.whl", "bar.whl", "baz.whl"],
    )

    # Check that environment variables

# Generated at 2022-06-21 21:02:32.501178
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        os.environ["PYPI_TOKEN"] = "aaabbb"
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        pass
    try:
        os.environ["PYPI_TOKEN"] = ""
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        pass
    try:
        os.environ["PYPI_TOKEN"] = "pypi-aaabbb"
        upload_to_pypi()
        assert False  # Will fail due to no .pypirc
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-21 21:02:33.431374
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist")

# Generated at 2022-06-21 21:02:44.643581
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert str(e) == "Missing credentials for uploading to PyPI"
    else:
        assert False and "Should have raised an ImproperConfigurationError"

    os.environ["PYPI_USERNAME"] = "admin"
    os.environ["PYPI_PASSWORD"] = "a password"
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        assert False and "Should not have raised an ImproperConfigurationError"
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    os.environ["PYPI_TOKEN"] = "pypi-apitoken"

# Generated at 2022-06-21 21:03:10.358712
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    
    import tempfile
    import shutil
    import os
    
    """Unit test for upload_to_pypi function
    """
    home_dir = os.path.expanduser("~")
    dot_pypirc = os.path.join(home_dir, ".pypirc")
    if os.path.isfile(dot_pypirc):
        shutil.copy2(dot_pypirc, os.path.join(tempfile.gettempdir(),'.pypirc'))
        os.remove(dot_pypirc)
    try:
        # No PYPI_TOKEN env variable. Should raise exception
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert "Missing credentials" in str(e)

# Generated at 2022-06-21 21:03:13.986838
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_patterns = ["*.tar.gz", "*.whl"]
    result = upload_to_pypi(glob_patterns=glob_patterns)
    assert result[0] == "twine upload  --skip-existing 'dist/*.tar.gz' 'dist/*.whl'"

# Generated at 2022-06-21 21:03:15.713891
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass  # Covered by integration tests

# Generated at 2022-06-21 21:03:25.720556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    '''
    :author: Alex Armento <alex.armento@keitaro.com>
    :version: 0.1 (20.02.2020)
    :desc: Test if upload_to_pypi function works
    '''
    import os
    import tempfile
    try:
        temp_dir = tempfile.mkdtemp()

        # Create source files for test
        source_file = os.path.join(temp_dir, 'test_upload.txt')
        with open(source_file, 'w') as f:
            f.write('Test file\n')

        result = upload_to_pypi(temp_dir, False, ['*.txt'])
    finally:
        # Remove temp files
        if os.path.exists(temp_dir):
            import shutil
            shut

# Generated at 2022-06-21 21:03:34.826264
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Get the current directory for later use
    current_dir = os.getcwd()
    # Create a temporary directory for testing the function
    os.makedirs('test_python_upload')
    os.chdir('test_python_upload')
    # Create an example package
    run('touch __init__.py')
    # Create an example distribution
    run('python setup.py sdist')
    # Create an example wheel
    run('python setup.py bdist_wheel')
    # Call the function we wish to test
    try:
        upload_to_pypi()
    except Exception as e:
        raise e
    # Change the directory back to where we started
    os.chdir(current_dir)
    # Delete the temporary directory
    os.system('rm -rf test_python_upload')

# Generated at 2022-06-21 21:03:43.085472
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi() function."""
    # Attempt to get an API token from environment
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
    else:
        username = "__token__"
        password = token

    repository = config.get("repository", None)
    repository_arg = f" -r '{repository}'" if repository else ""

    username_password = (
        f"-u '{username}' -p '{password}'" if username and password else ""
    )


# Generated at 2022-06-21 21:03:44.332908
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist")

# Generated at 2022-06-21 21:03:55.884804
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class MockRun(object):
        def __init__(self):
            self.called = False
        
        def __call__(self, command):
            self.called = True
            assert command.startswith("twine upload")
            
    run = MockRun()
    upload_to_pypi(path="path", skip_existing=False, glob_patterns=None, run=run)
    assert run.called
    
    run = MockRun()
    upload_to_pypi(path="path", skip_existing=False, glob_patterns=["*.whl"], run=run)
    assert run.called
    
    run = MockRun()
    upload_to_pypi(path="path", skip_existing=True, glob_patterns=None, run=run)
    assert run.called
    

# Generated at 2022-06-21 21:04:06.432966
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for PYPI_TOKEN
    os.environ["PYPI_TOKEN"] = "pypi-12345"
    config["repository"] = "pypi"
    assert run("echo 0").ok
    upload_to_pypi()
    output = run("echo $?", hide=True).stdout.strip()
    assert output == "0"

    # Test for PYPI_USERNAME and PYPI_PASSWORD
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = "pypi-user"
    os.environ["PYPI_PASSWORD"] = "pypi-password"
    config["repository"] = "pypi"
    assert run("echo 0").ok
    upload_

# Generated at 2022-06-21 21:04:09.243153
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    result = upload_to_pypi('dist',True,['*'])
    expected = 'twine upload -u __token__ -p pypi-aaaaa --skip-existing "dist/*"'
    assert result == expected

# Generated at 2022-06-21 21:04:44.396832
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist", glob_patterns=["*"]) == None


# Generated at 2022-06-21 21:04:52.617610
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Import assertion library
    import pytest
    
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi(path, skip_existing, glob_patterns)
    token = "pypi-32afc5058467e0b2dc2e75d8e9f72a76"
    os.environ[token] = "True"
    # TODO: Make this set up a dummy .pypirc
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-21 21:05:02.458085
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test that credentials are correctly parsed from env"""
    from unittest.mock import patch

    with patch.dict("os.environ", {"PYPI_TOKEN": "pypi-123"}):
        upload_to_pypi()

    with patch.dict("os.environ", {"PYPI_USERNAME": "username", "PYPI_PASSWORD": "pass"}):
        upload_to_pypi()


if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-21 21:05:10.812415
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockFunction

    # Test with minimum requirements (folder path and no repository specified)
    with MockFunction(run) as mock_run:
        upload_to_pypi('dist')
        mock_run.assert_called_once_with('twine upload "dist/*"')

    # Test with additional requirements (glob_patterns, username and password)
    with MockFunction(run) as mock_run:
        upload_to_pypi('dist', glob_patterns=['my-package-1.0.*'], username='usr', password='psswd')
        mock_run.assert_called_once_with('twine upload -u \'usr\' -p \'psswd\' "dist/my-package-1.0.*"')

    # Test with a repository specified

# Generated at 2022-06-21 21:05:23.763688
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from . import mock_invoke_run
    from . import mock_invoke_context

    ctx = mock_invoke_context.context(
        config={"repository": "test"},
        envdict={"PYPI_TOKEN": "pypi-123456789"},
        return_value=None,
    )
    upload_to_pypi(glob_patterns=["*"], ctx=ctx)
    ctx.run.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-123456789' -r 'test' 'dist/*'"
    )
    ctx.run.reset_mock()

    ctx = mock_invoke_context.context(
        config={}, envdict={}, return_value=None,
    )
   

# Generated at 2022-06-21 21:05:28.965373
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("", True) == [None]
    assert upload_to_pypi("", True, None) == [None]
    assert upload_to_pypi("", True, ["*"]) == [None]



# Generated at 2022-06-21 21:05:32.321046
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:05:33.798347
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-21 21:05:44.756878
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Ensure correct flags are sent to twine."""
    with patch("semantic_release.hvcs.git.run"):
        upload_to_pypi(path="path/")
    run.assert_called_once_with("twine upload -u '__token__' -p 'pypi-' 'path/*'")

    with patch("semantic_release.hvcs.git.run"):
        upload_to_pypi(path="path/", skip_existing=True)
    run.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-' --skip-existing 'path/*'"
    )


# Generated at 2022-06-21 21:05:45.566073
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:07:01.799089
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi
    """
    upload_to_pypi()
    upload_to_pypi(
        path="dist", skip_existing=False, glob_patterns=None
    )
    upload_to_pypi(
        path="dist", skip_existing=True, glob_patterns=["*"]
    )
    upload_to_pypi(
        path="dist", skip_existing=True, glob_patterns=["*whl", "*egg"]
    )

# Generated at 2022-06-21 21:07:05.461127
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist")
    assert upload_to_pypi("dist", True)
    assert upload_to_pypi("dist", True, "*")
    assert upload_to_pypi("dist", False, "*")
    assert upload_to_pypi("dist", False, "*", "")

# Generated at 2022-06-21 21:07:06.430408
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-21 21:07:08.532167
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist", False, ["*"]) == None

# Generated at 2022-06-21 21:07:20.989626
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    test_files = ["test_file1.txt", "test_file2.txt", "test_file3.txt"]
    with TemporaryDirectory() as test_dir:
      os.makedirs(os.path.join(test_dir, "dist"))
      for file in test_files:
        open(os.path.join(test_dir, "dist", file), "a").close()
      expected_call = f"twine upload  --skip-existing '{test_dir}/dist/*'"
      with mock.patch("invoke.run", create=True) as mock_run:
          upload_to_pypi(test_dir, True)
          assert mock_run.called
          assert mock_run.call_args[0][0] == expected_call


# Generated at 2022-06-21 21:07:23.080559
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-21 21:07:24.022701
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi

# Generated at 2022-06-21 21:07:25.617470
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # as this requires actual pypi credentials I cannot test this function
    return


# Generated at 2022-06-21 21:07:36.347312
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pkg_resources
    import io
    import os
    import tempfile
    import shutil
    import pytest

    logger.warning("Starting unit test for upload_to_pypi")

    # This is a very simple set of unit tests
    # PyPI doesn't allow uploading the same thing twice, so that's why we need to make a fake PyPI
    # We will just test that what we upload gets uploaded

    from twine import cli
    from twine.commands import upload

    class FakePypiCommand(cli.Command):
        """A fake command for testing.
        """

        def run(self):
            raise NotImplementedError

        def print_results(self, response, filename, show_response=True):
            if show_response:
                logger.warning(response)
            return response


# Generated at 2022-06-21 21:07:45.050528
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for upload_to_pypi"""
    import json
    import tempfile
    from pathlib import Path
    from pkg_resources import resource_string
    from unittest.mock import patch

    def _clean_up(*args, **kwargs):
        """Clean up any temporary files for tests"""
        for temp_file in temp_files:
            temp_file.close()
            Path(temp_file.name).unlink()

    temp_files = []
    temp_file = tempfile.NamedTemporaryFile(suffix=".json")
    temp_files.append(temp_file)
    temp_file.write(
        resource_string("semantic_release", "tests/test_files/test_package.json")
    )
    temp_file.flush()