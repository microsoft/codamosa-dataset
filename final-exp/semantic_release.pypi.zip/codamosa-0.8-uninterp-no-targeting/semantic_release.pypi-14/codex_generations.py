

# Generated at 2022-06-21 21:00:06.746958
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    ...

# Generated at 2022-06-21 21:00:08.523828
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Implement unit tests, missing functionality
    pass


# Generated at 2022-06-21 21:00:10.309758
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-21 21:00:11.356361
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist")

# Generated at 2022-06-21 21:00:19.916503
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test without API Token
    try:
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert "Missing credentials for uploading to PyPI" in str(e)

    # Test with API Token
    try:
        os.environ["PYPI_TOKEN"] = "pypi-Test-Token"
        upload_to_pypi()
    except ImproperConfigurationError as e:
        assert 'PyPI token should begin with "pypi-"' in str(e)

    # Test with API Token (valid)
    os.environ["PYPI_TOKEN"] = "pypi-Test-Token-valid"
    upload_to_pypi()

# Generated at 2022-06-21 21:00:21.499143
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass
# End unit test for function upload_to_pypi

# Generated at 2022-06-21 21:00:22.351408
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi()

# Generated at 2022-06-21 21:00:32.124157
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.hvcs import commit_message

    from .helpers import LoggedFunction, RegexMatch

    function = "semantic_release.hvcs.upload:upload_to_pypi"

    # Temporary dist directory
    dist_directory_path = "path/to/dist"

    # Upload with missing credentials is an error
    with LoggedFunction(logger, function) as log_file:
        try:
            upload_to_pypi(dist_directory_path)
        except ImproperConfigurationError:
            pass
        else:
            raise Exception("upload_to_pypi did not raise exception")

    log_file.seek(0)
    assert RegexMatch(
        "Could not find credentials for uploading to PyPI.", log_file.read()
    )

    # Upload with username/password is a success

# Generated at 2022-06-21 21:00:38.892326
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    with patch("invoke.run") as run_mock:
        with patch("os.environ") as environ:
            environ.get = {"PYPI_TOKEN": "pypi-asdf", "PYPI_USERNAME": "bob", "PYPI_PASSWORD": "1234"}.get
            upload_to_pypi("/test_upload")
            run_mock.assert_called_once_with("twine upload -u '__token__' -p 'pypi-asdf'  '*/test_upload/*'")


# Generated at 2022-06-21 21:00:40.894772
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    result = upload_to_pypi()
    assert result == "twine upload --skip-existing dist/*"

# Generated at 2022-06-21 21:00:47.116667
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import make_temp_egg

    make_temp_egg()

    upload_to_pypi(path=".")

# Generated at 2022-06-21 21:00:56.562628
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert os.environ.get("PYPI_TOKEN") == None
    assert os.environ.get("PYPI_USERNAME") == None
    assert os.environ.get("PYPI_PASSWORD") == None

    try:
        upload_to_pypi()
    except Exception:
        pass
    else:
        assert False
    
    try:
        os.environ['PYPI_TOKEN'] = 'pypi-token'
        upload_to_pypi()
    except Exception:
        assert False
    else:
        pass
    finally:
        os.environ.pop("PYPI_TOKEN")


# Generated at 2022-06-21 21:00:57.351336
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:01:04.242338
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    test_path = "tests/path"
    test_token = "test token"
    test_username = "test user"
    test_password = "test password"
    test_repository = "test repository"
    test_repository_arg = f" -r '{test_repository}'"
    test_skip_existing = True
    test_skip_existing_param = " --skip-existing"

    def run_mock(args, *args_to_ignore, **kwargs_to_ignore):
        if test_token:
            assert f"twine upload -u '__token__' -p '{test_token}'" in args

# Generated at 2022-06-21 21:01:14.450326
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    with patch("invoke.run") as mock:
        upload_to_pypi(path="path", skip_existing=False, glob_patterns=["*"])

        mock.assert_called_with(
            "twine upload -u '__token__' -p 'pypi-token'  \"path/*\""
        )

    with patch("invoke.run") as mock:
        upload_to_pypi(path="path", skip_existing=True, glob_patterns=["*"])

        mock.assert_called_with(
            "twine upload -u '__token__' -p 'pypi-token' --skip-existing \"path/*\""
        )


# Generated at 2022-06-21 21:01:15.941889
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:01:16.937262
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:01:20.398717
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    assert upload_to_pypi(path="../examples/custom_pypi", skip_existing=False, glob_patterns=["*"]) is None

# Generated at 2022-06-21 21:01:22.535177
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False
    upload_to_pypi(path, skip_existing)

# Generated at 2022-06-21 21:01:23.882171
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"


# Generated at 2022-06-21 21:01:43.287302
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from invoke import ctask as context
    from semantic_release.contrib.twine import upload_to_pypi

    @context.task
    def task(*args, **kwargs):
        paths = [
            "dist/package-0.0.0-py3-none-any.whl",
            "dist/package-1.0.0-py3-none-any.whl",
            "dist/package-2.0.0-py3-none-any.whl",
        ]
        for path in paths:
            open(path, "w").close()

        upload_to_pypi(
            path="dist", skip_existing=False, glob_patterns=["package*"]
        )

        for path in paths:
            os.remove(path)


# Generated at 2022-06-21 21:01:43.822802
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:01:45.302797
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test_dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:01:48.041456
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    os.environ["PYPI_TOKEN"] = "test_token"
    assert upload_to_pypi(skip_existing=True, glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:01:52.042624
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class Env:
        pass
    env = Env()
    env.username = "username"
    env.password = "password"
    env.repository = "test_repository"
    upload_to_pypi(skip_existing=True)

# Generated at 2022-06-21 21:02:02.215298
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    glob_patterns = ["pattern"]
    skip_existing = False

    path = os.path.join(os.getcwd(), "dist")

    try:
        # if the path does not exist, it will raise an error
        assert os.path.exists(path)
    except AssertionError:
        # create the directory
        os.makedirs(path)
    finally:
        # in this case, we are passing the default path and glob_patterns and skip_existing as False
        # so, there is no authentication token, which should raise an ImproperConfigurationError
        # with a message
        try:
            upload_to_pypi(path, skip_existing, glob_patterns)
        except ImproperConfigurationError as e:
            assert str(e) == "Missing credentials for uploading to PyPI"

        # now

# Generated at 2022-06-21 21:02:08.573828
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "this_is_a_fake_username"
    os.environ["PYPI_PASSWORD"] = "this_is_a_fake_password"
    path = "test-path"
    # make sure that the default config is True
    assert config["skip_existing"]
    upload_to_pypi(path)
    # This is a simple test; the goal is to assert that the expected command is invoked.
    # After all, the actual command is dead simple.
    command = "twine upload " \
              "-u 'this_is_a_fake_username' " \
              "-p 'this_is_a_fake_password' " \
              "--skip-existing " \
              '"test-path/*"'
    assert command in run.call_args

# Generated at 2022-06-21 21:02:20.340581
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    c = config
    c.update({"repository": "test-repository"})

    os.environ["PYPI_TOKEN"] = "pypi-test-token"

    glob_patterns = ["*"]
    upload_to_pypi(glob_patterns=glob_patterns)
    pypi_upload_message = (
        "twine upload -u '__token__' -p 'pypi-test-token' -r 'test-repository' "
        '"dist/{}"'.format(glob_patterns[0])
    )
    assert pypi_upload_message == run.calls[0].args

    del os.environ["PYPI_TOKEN"]


# Generated at 2022-06-21 21:02:29.690266
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Upload to PyPI is mocked when running this unit test to avoid actually pushing to PyPI."""
    import sys
    import mock
    sys.modules["invoke"] = mock.Mock()
    mock_run = mock.Mock()
    sys.modules["invoke"].run = mock_run

    upload_to_pypi()
    mock_run.assert_called_once_with("twine upload -u '__token__' -p 'pypi-12345' *")

    upload_to_pypi(skip_existing=True)
    mock_run.assert_called_with("twine upload -u '__token__' -p 'pypi-12345' --skip-existing *")

# Generated at 2022-06-21 21:02:31.179901
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:02:54.712712
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    package_name = "test_package"

    # Make a package
    run(f"python setup.py sdist bdist_wheel")

    # Create a fake conf file
    with open(".pypirc", "w") as f:
        f.write("[distutils]\n")
        f.write("index-servers =\n")
        f.write("    pypi\n")
        f.write("    local\n\n")
        f.write("[pypi]\n")
        f.write("repository: https://upload.pypi.org/legacy/\n")
        f.write("username: my_username\n")
        f.write("password: my_password\n\n")
        f.write("[local]\n")

# Generated at 2022-06-21 21:02:57.571892
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:03:08.066392
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def test_upload_to_pypi(path: str = "dist", skip_existing: bool = False, glob_patterns: List[str] = None):
        # Attempt to get an API token from environment
        token = os.environ.get("PYPI_TOKEN")
        username = None
        password = None
        if not token:
            # Look for a username and password instead
            username = os.environ.get("PYPI_USERNAME")
            password = os.environ.get("PYPI_PASSWORD")
            home_dir = os.environ.get("HOME", "")
            if not (username or password) and (
                not home_dir or not os.path.isfile(os.path.join(home_dir, ".pypirc"))
            ):
                raise ImproperConfigurationError

# Generated at 2022-06-21 21:03:16.046563
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class MockRun:
        def __init__(self):
            self.cmd = None

        def __call__(self, cmd):
            self.cmd = cmd

    mock_run = MockRun()

    glob_patterns = ['dist/oseti*.whl', 'dist/oseti*.tar.gz']

    orig_run = run
    run = mock_run


# Generated at 2022-06-21 21:03:25.841936
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypi_token = os.environ.get("PYPI_TOKEN")
    if not pypi_token:
        raise ImproperConfigurationError(
            "Missing credentials for uploading to PyPI"
        )

    test_pypi_token = os.environ.get("TESTPYPI_TOKEN")
    if not test_pypi_token:
        raise ImproperConfigurationError(
            "Missing credentials for uploading to TestPyPI"
        )

    pypi_repository_arg = f"-r pypi"
    testpypi_repository_arg = f"-r testpypi"

    pypi_token_arg = f"-u '__token__' -p '{pypi_token}'"

# Generated at 2022-06-21 21:03:28.389505
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the function upload_to_pypi
    """
    try:
        upload_to_pypi()
    except ImproperConfigurationError:  # pragma: no cover
        pass

# Generated at 2022-06-21 21:03:33.658443
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["HOME"] = "/"
    os.environ["PYPI_TOKEN"] = "pypi-test_token"
    upload_to_pypi(path=".", glob_patterns=["*", "*.txt", "**/*.txt"])
    upload_to_pypi(path=".", glob_patterns=["*", "*.txt", "**/*.txt"], skip_existing=True)

# Generated at 2022-06-21 21:03:38.050199
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import glob

    # Create fake wheel file
    user_header = "twine_upload_pypi"
    wheel_name = "fake_wheel-3.0.0-py2.py3-none-any.whl"
    wheel_path = os.path.join(user_header, wheel_name)
    with open(wheel_path, "w") as wheel:
        wheel.write("Content")

    # Set fake pypi token for tests
    os.environ["PYPI_TOKEN"] = "pypi-my_fake_token"

    # Test with PyPI token
    upload_to_pypi(user_header, skip_existing=True, glob_patterns=[wheel_name])

    # Test with username and password
    os.environ["PYPI_TOKEN"]

# Generated at 2022-06-21 21:03:40.962199
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    mock, repo, env = repo_env_mock()
    mock.patch.object(env, 'upload_to_pypi', return_value='Success')
    result = env.upload_to_pypi()
    assert result == 'Success'

# Generated at 2022-06-21 21:03:54.236548
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    expected_pass_cmd = "twine upload -u '__token__' -p 'pypi-xxx' --skip-existing 'dist/*'"
    expected_repository_cmd = "twine upload -u '__token__' -p 'pypi-xxx' -r 'https://test-repo' 'dist/*'"
    expected_no_token_cmd = "twine upload 'dist/*'"
    expected_no_token_repository_cmd = "twine upload -r 'https://test-repo' 'dist/*'"
    expected_username_password_cmd = "twine upload -u 'username' -p 'password' 'dist/*'"
    expected_username_password_repository_cmd = "twine upload -u 'username' -p 'password' -r 'https://test-repo' 'dist/*'"

# Generated at 2022-06-21 21:04:28.120725
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"

# Generated at 2022-06-21 21:04:40.308713
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    def mock_run(command, hide=True, warn=True, encoding=None, pty=True):
        """Mock run method."""
        assert command == "twine upload -u 'john' -p 'doe' dist/file.whl"

    run_obj = {'run': mock_run}

    # Mock self.run call
    run_mock = Mock()
    run_mock.attach_mock(mock_patch('run'), 'run')
    self.run.return_value = run_obj
    self.run.return_value.exited = 0
    self.run.return_value.stdout = ''
    self.run.return_value.stderr = ''

# Generated at 2022-06-21 21:04:50.348215
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    package = "sematic-release"

    test_utils.create_package(package)
    test_utils.build_package(package)

    # add the test data to the dist folder
    test_utils.add_test_data_to_dist(package)

    # Upload dist folder to test.pypi.org
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

    # remove test package
    test_utils.remove_test_packages()

    # install test package from test.pypi.org
    test_utils.install_test_package("test", package)

    # remove test package
    test_utils.remove_test_packages()

# Generated at 2022-06-21 21:05:02.953483
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    result = run("twine -h")

    # Ensure that a valid string is returned
    assert (
        'Usage: twine [OPTIONS] COMMAND [ARGS]...\n'
        "  Twine is a utility for interacting with PyPI.\n"
        "\n"
        "  This tool is a replacement for distutils' "
        "upload command that builds on top\n"
        "  of Requests, offers authentication for uploading via PyPI, "
        "and offers\n"
        "  more features for uploading to other index servers.\n"
        '\n"  Options:\n' in result.stdout
    )

# Generated at 2022-06-21 21:05:05.197318
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        return

# Generated at 2022-06-21 21:05:12.664651
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    import unittest
    import shutil
    import tempfile
    import zipfile

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.test_path = tempfile.mkdtemp()
            self.wheel_file_path = os.path.join(
                self.test_path, 'python-name-42.0.1-py3-none-any.whl'
            )

            import semantic_release
            import pathlib
            current_file = pathlib.Path(semantic_release.__file__).resolve()
            project_root = current_file.parents[2]

# Generated at 2022-06-21 21:05:15.810051
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:05:19.185910
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test that upload_to_pypi works as expected.
    """
    cmd_ret = run("which twine")
    assert cmd_ret.ok



# Generated at 2022-06-21 21:05:28.064569
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Setup test
    import tempfile
    import shutil
    import glob

    from contextlib import contextmanager

    @contextmanager
    def temp_directory():
        temp_dir = tempfile.mkdtemp()
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)


# Generated at 2022-06-21 21:05:30.637726
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test function upload_to_pypi"""
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["test"])

# Generated at 2022-06-21 21:06:44.083199
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # no credentials
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    try:
        upload_to_pypi()
        assert False, "Expected ImproperConfigurationError"
    except ImproperConfigurationError:
        pass

    # invalid PyPI token
    os.environ["PYPI_TOKEN"] = "foo"
    try:
        upload_to_pypi()
        assert False, "Expected ImproperConfigurationError"
    except ImproperConfigurationError:
        pass

    # valid PyPI token
    os.environ["PYPI_TOKEN"] = "pypi-foo"
    run = UploadPackageMock()
    upload_to_p

# Generated at 2022-06-21 21:06:46.317630
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*"])
    # This function does not return anything for now, so we cannot test for anything

# Generated at 2022-06-21 21:06:57.566669
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_invoke
    from .helpers import mock_run
    from .helpers import patch

    # Mock invoke run
    with patch("invoke.run", mock_invoke(mock_run, return_value="")):
        upload_to_pypi(glob_patterns=[""])
        mock_run.assert_called_with("twine upload *")

    # Mock invoke run
    with patch("invoke.run", mock_invoke(mock_run, return_value="")):
        upload_to_pypi(glob_patterns=["*.whl"])
        mock_run.assert_called_with("twine upload '*.whl'")

    # Mock invoke run
    with patch("invoke.run", mock_invoke(mock_run, return_value="")):
        upload

# Generated at 2022-06-21 21:06:58.187184
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:06:59.569358
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__doc__ is not None

# Generated at 2022-06-21 21:07:01.402002
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run = lambda x: print(x)
    run("twine upload --skip-existing 'dist/*'")

# Generated at 2022-06-21 21:07:02.361467
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() is None

# Generated at 2022-06-21 21:07:03.560494
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function"""
    upload_to_pypi()

# Generated at 2022-06-21 21:07:15.571432
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    from mock import patch, mock_open

    os.environ["PYPI_TOKEN"] = "pypi-asd"
    mock_env_path = "semantic_release.hvcs.pypi.os.environ"
    mock_run_path = "semantic_release.hvcs.pypi.run"
    with patch(mock_env_path) as mock_env:
        with patch(mock_run_path) as mock_run:
            mock_env.get.return_value = "pypi-asd"
            upload_to_pypi()
            mock_run.assert_called()

# Generated at 2022-06-21 21:07:20.684796
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from pathlib import Path
    from unittest import TestCase, mock
    from unittest.mock import patch

    class UploadToPyPITest(TestCase):
        test_file_content = "test_upload_to_pypi"
        test_file_name = "test_upload_to_pypi.txt"
        test_file_path = "dist/test_upload_to_pypi.txt"
        test_files_to_upload = ["test_file.txt"]
        test_files_uploaded = ["test_upload_to_pypi.txt"]
        test_pypi_username = "test"
        test_pypi_password = "test"

# Generated at 2022-06-21 21:10:03.962128
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from invoke import Context
    from tempfile import TemporaryDirectory

    from .helpers import mock_exists, mock_isfile, mock_listdir, mock_makedirs
    from .mocks import MockCwd, MockEnviron, MockRemove, MockRmtree, MockRun

    # TODO: Add tests for error cases
    # TODO: Add tests for non-standalone error cases
    with TemporaryDirectory() as td:
        with MockEnviron({"HOME": td}), MockCwd(td), MockListdir(td, ["file.txt"]):
            # No credentials
            with MockExists(td, False):
                try:
                    upload_to_pypi()
                    assert False
                except ImproperConfigurationError:
                    pass

            # Username & password