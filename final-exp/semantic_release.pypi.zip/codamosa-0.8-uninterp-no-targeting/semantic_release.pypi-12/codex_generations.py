

# Generated at 2022-06-21 21:00:08.735108
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test for function upload_to_pypi
    :return:
    """
    import tempfile
    import os
    import shutil
    import unittest
    import json
    import sys

    class TestUploadToPyPI(unittest.TestCase):
        """
        Test class that tests upload_to_pypi.
        """

        def test_upload_to_pypi(self):
            """
            Test that upload to pypi works.
            :return:
            """

# Generated at 2022-06-21 21:00:10.309712
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:00:20.073601
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Unit test for function upload_to_pypi
    import os
    import sys
    import unittest
    from contextlib import contextmanager
    from io import StringIO
    import tempfile
    import shutil

    class StringIOCatcher(object):
        def __init__(self):
            self.sio = StringIO()

        def start(self, *args, **kwargs):
            sys.stdout = self.sio
            sys.stderr = self.sio

        def stop(self, *args, **kwargs):
            sys.stdout = sys.__stdout__
            sys.stderr = sys.__stderr__

        @contextmanager
        def captured(self, *args, **kwargs):
            self.start(*args, **kwargs)

# Generated at 2022-06-21 21:00:29.691688
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import tmp_folder

    with tmp_folder() as dirname:
        for num in range(1, 4):
            os.mkdir(os.path.join(dirname, f"dist-{num}"))
            open(os.path.join(dirname, f"dist-{num}", "test-{num}.tar.gz"), "w").close()

        # Test default upload
        upload_to_pypi(dirname)

        # Test upload with multiple files and directories
        upload_to_pypi(dirname, glob_patterns=["dist-1/*", "dist-3/*"])

        # Test upload with multiple files and directories with exception

# Generated at 2022-06-21 21:00:30.936395
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:00:32.166750
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="test_dist", skip_existing=True)

# Generated at 2022-06-21 21:00:32.728565
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:00:35.383510
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:00:46.679581
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def assertUploads():
        run.assert_called_with(
            "twine upload -r '' --skip-existing 'dist/test.txt'"
        )
    run.return_value = ""
    upload_to_pypi("dist", True, ["  test.txt  "])
    assertUploads()
    os.environ["PYPI_TOKEN"] = "pypi-test_token"
    upload_to_pypi("dist", True, ["  test.txt  "])
    assertUploads()
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"

# Generated at 2022-06-21 21:00:49.551405
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="0.0.1", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:00:55.673000
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function
    """
    assert upload_to_pypi("dist",False,["*"]) == None

# Generated at 2022-06-21 21:00:58.373889
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypi_repository_url_format = "https://test.pypi.org/legacy/"
    assert upload_to_pypi(repository=pypi_repository_url_format) is None

# Generated at 2022-06-21 21:00:59.163477
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass


# Generated at 2022-06-21 21:01:11.355926
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    from pathlib import Path
    from unittest.mock import patch
    from .test_helpers import LoggedExecutionResult

    working_dir = Path(__file__).parent.joinpath("test_upload_to_pypi")
    if not working_dir.exists():
        working_dir.mkdir()
    else:
        shutil.rmtree(working_dir)
        working_dir.mkdir()

    path = working_dir.joinpath("dist")
    path.mkdir()
    empty_path = working_dir.joinpath("dist", "empty")
    empty_path.mkdir()
    file_path = working_dir.joinpath("dist", "test.txt")
    file_path.write_text("test")

    # No files

# Generated at 2022-06-21 21:01:23.704266
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from invoke import MockContext
    from semantic_release import InvokeContext

    class InvokeContextTest(InvokeContext):
        # Mock: Override defaults for testing
        def run(self, cmd, **kwargs):
            return self.ctx.run(cmd, **kwargs)

        def __init__(self, ctx: MockContext):
            self.ctx = ctx
    
    # 1. Test valid case with a token
    ctx = MockContext()
    ctx.config["run"].side_effect = lambda cmd, **kwargs: print(cmd, kwargs)
    os.environ["PYPI_TOKEN"] = "pypi-some-token"
    try:
        upload_to_pypi(InvokeContextTest(ctx))
        assert True
    except:
        assert False
    #

# Generated at 2022-06-21 21:01:28.097986
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    logger = logging.Logger('dist')
    glob_patterns = ["*"]
    skip_existing = True

    def run(args):
        return args

    assert run(f"twine upload -u '__token__' -p 'pypi-***' --skip-existing '{path}/*'")
    assert run(f"twine upload -u '***' -p '***' '{path}/*'")
    assert run(f"twine upload -u '__token__' -p 'pypi-***' '{path}/*'")

# Generated at 2022-06-21 21:01:31.966815
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function.
    """
    upload_to_pypi(path="dist/", glob_patterns=["*"])

# Generated at 2022-06-21 21:01:38.695079
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi_with_token = lambda *args, **kwargs : upload_to_pypi(
        os.environ.get("PYPI_TOKEN", ""), *args, **kwargs
    )
    upload_to_pypi_with_token.__name__ = "upload_to_pypi"
    upload_to_pypi_with_token()

# Generated at 2022-06-21 21:01:39.294669
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:01:40.316137
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:01:55.793357
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-u3pqw3jq3j"

    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*.whl"])
    # Remove the PYPI_TOKEN from environment
##    del os.environ["PYPI_TOKEN"]
##    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:01:59.450601
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Testing with only one instance of glob_patterns as a list of glob_patterns
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"]) == "twine upload dist/{*}"

# Generated at 2022-06-21 21:02:10.199943
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi by ensuring it raises an exception when missing a valid path or login credentials.
    :return:
    """
    import pytest

    with pytest.raises(ImproperConfigurationError) as error:
        upload_to_pypi(path="", skip_existing=True, glob_patterns="*")
    assert "Missing credentials" in str(error.value)

    with pytest.raises(ImproperConfigurationError) as error:
        upload_to_pypi(path=".", skip_existing=True, glob_patterns="*")
    assert "Missing credentials" in str(error.value)


# Generated at 2022-06-21 21:02:21.516151
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Tests for function upload_to_pypi"""
    from invoke import FakeConfig, UnexpectedExit, Result
    from .helpers import patch

    from .test_pypi_settings import pypi_settings
    from .test_helpers import get_test_config
    from .test_pypi_plugin import pypi_plugin_main
    def run(self, command, **kwargs):
        return Result()

    with patch("invoke.runners.Local.run", run), patch(
        "os.path.isfile", lambda path: True
    ), patch("os.environ", {}), patch("semantic_release.hvcs.mercurial.os.path.isdir", lambda path: False):
        pypi_plugin_main(get_test_config(pypi_settings))

# Generated at 2022-06-21 21:02:24.574878
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])


__all__ = ["upload_to_pypi"]

# Generated at 2022-06-21 21:02:33.717564
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from invoke import Context
    from invoke.exceptions import Exit
    from unittest import mock

    # Ensure that a token is used if found
    with mock.patch.dict(os.environ, {"PYPI_TOKEN": "whoop"}):
        ctx = Context()
        with mock.patch("invoke.run") as run_mock:
            ctx.invoke(upload_to_pypi)
            username_password = "-u '__token__' -p 'whoop'"
            repository_arg = ''
            skip_existing_param = ''
            dist = '"*"'
            run_mock.assert_called_once_with(f'twine upload {username_password}{repository_arg}{skip_existing_param} {dist}')

    # Ensure that a username and password are used if a token is not found

# Generated at 2022-06-21 21:02:35.953685
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    result = upload_to_pypi.__wrapped__()
    assert result is None

# Generated at 2022-06-21 21:02:47.175729
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test normal case
    config.repository = "test"
    os.environ['HOME'] = '/tmp'
    def run_mock(*args, **kwargs):
        if kwargs.get('warn') == True:
            warnings.warn(*args)
    with patch('semantic_release.uploaders.twine.warnings.warn') as warn_mock:
        with patch('semantic_release.uploaders.twine.run', new=run_mock) as run_mock:
            upload_to_pypi()
            assert run_mock.called
            assert "twine upload -u '__token__' -p 'pypi-mytoken' -r 'test' 'dist/*'" in "".join(map(str, run_mock.call_args))
            assert warn_m

# Generated at 2022-06-21 21:02:48.642009
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("tests/test_files")

# Generated at 2022-06-21 21:02:55.117347
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=unused-argument
    def mock_run(command):
        if not command.startswith("twine upload"):
            return False
        return True

    run = mock_run
    config["repository"] = "https://example.com"
    upload_to_pypi()
    del config["repository"]
    os.environ["PYPI_TOKEN"] = "pypi-12345asdfh"
    upload_to_pypi(path = "dist", glob_patterns = ["*"])
    os.environ["PYPI_TOKEN"] = "12345asdfh"
    upload_to_pypi(path = "dist", glob_patterns = ["*"])

# Generated at 2022-06-21 21:03:11.992432
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:03:12.463012
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:03:14.463048
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        assert upload_to_pypi("dist", ["**/*"])
    except Exception:
        assert upload_to_pypi("dist", ["**/*"])

# Generated at 2022-06-21 21:03:16.422470
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="", skip_existing=True, glob_patterns=[])

# Generated at 2022-06-21 21:03:17.699181
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True == True

# Generated at 2022-06-21 21:03:26.530038
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = os.environ.get("PYPI_TOKEN")
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")
    repository = os.environ.get("PYPI_REPOSITORY")

    if token:
        assert "__token__" in upload_to_pypi(skip_existing=False)
        assert "__token__" in upload_to_pypi(skip_existing=True)
        assert "__token__" in upload_to_pypi(skip_existing=False, glob_patterns=["*"])
        assert "__token__" in upload_to_pypi(skip_existing=True, glob_patterns=["*"])


# Generated at 2022-06-21 21:03:27.080253
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:03:30.494561
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test the whole function
    upload_to_pypi(
        # Test with a path
        'dist',
        # Test with skip_existing on
        True,
        # Test with custom glob patterns
        [
            'test',
            'test2'
        ]
    )

# Generated at 2022-06-21 21:03:31.314536
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # todo: create unit tests
    assert False

# Generated at 2022-06-21 21:03:38.741669
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import unittest
    import unittest.mock
    import sys

    class TestUploadToPyPI(unittest.TestCase):
        """Class to test the function upload_to_pypi."""

        def setUp(self):
            """Set up the test environment."""
            self.function = upload_to_pypi
            self.path = "dist"
            self.skip = False
            self.glob_pattern = ["*"]
            self.credentials = {
                "username": "",
                "password": "",
                "token": "",
            }


# Generated at 2022-06-21 21:04:15.715451
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from unittest.mock import patch

    with tempfile.TemporaryDirectory() as dist_dir:
        with patch("os.environ", {"HOME": dist_dir}):
            open(os.path.join(dist_dir, ".pypirc"), "w+").close()
            upload_to_pypi(dist_dir)

# Generated at 2022-06-21 21:04:17.325065
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:04:26.543021
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for proper output with token
    os.environ["PYPI_TOKEN"] = "pypi-some-token"
    test_output = upload_to_pypi("test/dist", False, ["*"])
    assert test_output.stdout == "Uploading distributions to https://upload.pypi.org/legacy/\nUploading test-0.0.0-py3-none-any.whl\n\n"
    assert test_output.stderr == ""
    assert test_output.exited == 0

    # Test for proper output with username and password
    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    test

# Generated at 2022-06-21 21:04:31.653870
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    from invoke import Context

    from .helpers import run as run_cmd

    class TestContext(Context):
        """Custom context for testing."""

    context = TestContext()
    assert 0 == run_cmd(context, upload_to_pypi, ["dist", "*"])

# Generated at 2022-06-21 21:04:32.543079
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", True)

# Generated at 2022-06-21 21:04:43.436137
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Dummy path with dummy file
    path = "./tests/dummy_dist"
    file = "dummy_file.txt"
    run(f"touch {path}/{file}")

    # Creation of context manager to mock both environment variables and the run function
    class ContextMock:
        def __enter__(self):
            self.skip_existing_param = " --skip-existing"
            self.dummy_token = "pypi-dummy-token"
            self.dummy_username = "__token__"
            self.dummy_password = f"{self.dummy_token}"
            self.dummy_repository = "release"
            self.dummy_repository_arg = f" -r '{self.dummy_repository}'"
            self.dummy_username

# Generated at 2022-06-21 21:04:44.390852
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi

# Generated at 2022-06-21 21:04:45.336861
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:04:47.849105
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Testing upload_to_pypi"""
    assert upload_to_pypi.__doc__

# Generated at 2022-06-21 21:04:54.489607
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with patch("invoke.run", return_value=None) as run_mock:
        upload_to_pypi(path="/tmp", glob_patterns=["*.whl"])
        run_mock.assert_any_call('twine upload "*.whl"')
        run_mock.reset_mock()
        upload_to_pypi(path="/tmp",
                       glob_patterns=["*.whl", "*.gz"],
                       skip_existing=True)
        run_mock.assert_any_call(
            'twine upload --skip-existing "*.whl" "*.gz"'
        )

# Generated at 2022-06-21 21:06:05.453962
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=False, glob_patterns=["*"])



# Generated at 2022-06-21 21:06:09.198128
# Unit test for function upload_to_pypi

# Generated at 2022-06-21 21:06:12.601313
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """upload_to_pypi should fail if username or password is missing"""
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        pass
    except:
        assert False

# Generated at 2022-06-21 21:06:15.559495
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["foo", "bar*"])

# Generated at 2022-06-21 21:06:26.087730
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import get_temp_directory, mocked_run
    from .helpers import mocked_env, TempDirectoryContext

    README_RST = """\
===================
sphinx-example-project
===================

This is a short description of the project.

"""


# Generated at 2022-06-21 21:06:29.252747
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == "No glob patterns provided, using '*' as glob pattern."
    assert upload_to_pypi(glob_patterns=["a", "b"]) == "Uploading a, b"

# Generated at 2022-06-21 21:06:38.165282
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypi_token = "pypi-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    os.environ["PYPI_TOKEN"] = pypi_token
    assert os.environ["PYPI_TOKEN"] == pypi_token
    # TODO: test the actual uploads to Pypi
    # os.environ["PYPI_USERNAME"] = "username"
    # os.environ["PYPI_PASSWORD"] = "password"
    # assert os.environ["PYPI_USERNAME"] == "username"
    # assert os.environ["PYPI_PASSWORD"] == "password"

# Generated at 2022-06-21 21:06:48.485304
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = os.environ.get("PYPI_TOKEN")
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")
    if token:
        os.environ["PYPI_TOKEN"] = "pypi-" + str(token)
    elif username and password:
        os.environ["PYPI_USERNAME"] = username
        os.environ["PYPI_PASSWORD"] = password
    else:
        raise ImproperConfigurationError("Missing credentials for uploading to PyPI")
    upload_to_pypi("dist", glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:06:56.037363
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Simple test for upload_to_pypi function."""
    def mock_run(command):
        """Mock the invoke run function."""
        return command
    try:
        old_run = run
        run = mock_run
        upload_to_pypi(
            path="pip/dist", skip_existing=True, glob_patterns=["semantic_release*"]
        )
        upload_to_pypi(
            path="pip/dist", skip_existing=True, glob_patterns=[]
        )
    finally:
        run = old_run

# Generated at 2022-06-21 21:07:02.180746
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    
    # Success
    try:
        upload_to_pypi(None, None, ["*"])
    except ImproperConfigurationError:
        assert 0

    # Missing credentials
    try:
        upload_to_pypi(None, None, ["*"])
    except ImproperConfigurationError:
        assert 1
        
# Test for function upload_to_pypi
test_upload_to_pypi()

# Generated at 2022-06-21 21:09:44.105350
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi."""
    from .helpers import mocks
    from semantic_release import upload

    mocks.run.side_effect = [None]

    config.set("repository", "pypi")

    upload.upload_to_pypi("dist", True)

    mocks.run.assert_called_with(
        "twine upload -u '__token__' -p 'pypi-secret' -r 'pypi' --skip-existing 'dist/*'"
    )

    mocks.reset_mocks()

    config.set("repository", None)

    upload.upload_to_pypi("dist", True)


# Generated at 2022-06-21 21:09:48.079212
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", glob_patterns=["*"])

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-21 21:09:55.449946
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .test_helpers import patch_open, patch_exists, patch_isfile, ConfigStore, patch_get

    path = os.path.join(os.path.sep, "path", "to", "dist")
    glob_patterns = ["*"]

    configStore = ConfigStore()
    pypi_token = "pypi-mytoken"
    username = "foo"
    password = "bar"

    configStore.set("repository", None)
    patch_open = patch_open(
        read_data='[pypi]\nusername = {}\npassword = {}'.format(username, password)
    )
    patch_exists = patch_exists(return_value=False)
    patch_isfile = patch_isfile(return_value=True)
    patch_get = patch