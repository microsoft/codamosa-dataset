

# Generated at 2022-06-21 21:00:16.366192
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    # Create files for testing upload
    os.mkdir("test_dist")
    open(os.path.join("test_dist", "test_package-1.0.0-py3-none-any.whl"), "a").close()

    # Test environment
    os.environ["HOME"] = "."
    open(".pypirc", "a").close()

    # Mock twine

# Generated at 2022-06-21 21:00:22.394099
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(cmd):
        assert (
            cmd
            == "twine upload -u '__token__' -p 'pypi-xxxxxxxxxxxxxxxxxxxxxxxxxxx' --skip-existing 'dist/*'"
        )

    path = "dist"
    project_name = "project-name"

    os.environ["PYPI_TOKEN"] = "pypi-xxxxxxxxxxxxxxxxxxxxxxxxxxx"

    run = mock_run

    upload_to_pypi(path, skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:00:33.090858
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_config, mock_run

    config.update(mock_config)

    path = "dist/path"
    glob_patterns = ["1", "2"]
    dist = '"dist/path/1" "dist/path/2"'
    username_password = "-u __token__ -p pypi-abc"
    repository_arg = ""
    skip_existing_param = ""

    mock_run.reset_mock()
    upload_to_pypi(path, False, glob_patterns)
    mock_run.assert_called_once_with(
        f"twine upload {username_password}{repository_arg}{skip_existing_param} {dist}"
    )

    mock_run.reset_mock()

# Generated at 2022-06-21 21:00:46.793025
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch, call

    with patch("invoke.run") as mock_run:
        upload_to_pypi()

    mock_run.assert_called_with('twine upload -u \'__token__\' -p \'\'')

    with patch("invoke.run") as mock_run:
        upload_to_pypi(skip_existing=True)

    mock_run.assert_called_with('twine upload -u \'__token__\' -p \'\' --skip-existing')

    with patch("invoke.run") as mock_run:
        upload_to_pypi(glob_patterns=["foo", "bar"])

    mock_run.assert_called_with('twine upload -u \'__token__\' -p \'\' "dist/foo" "dist/bar"')

# Generated at 2022-06-21 21:00:53.113918
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # pylint: disable=unused-argument, invalid-name
    def mock_run(*args, **kwargs):
        return True

    with mock.patch("invoke.run", mock_run):
        upload_to_pypi()
        # Test with environment variables
        os.environ["PYPI_TOKEN"] = "my-token"
        upload_to_pypi()
        del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-21 21:00:58.002183
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    dist = os.getcwd()
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")
    upload_to_pypi(path=dist, skip_existing=True, glob_patterns=["hello*"])
    assert run(
        "twine upload -u '{}' -p '{}' --skip-existing {}/hello*".format(
            username, password, dist
        )
    ).failed


__all__ = (
    "upload_to_pypi",
)

# Generated at 2022-06-21 21:01:04.608977
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    import os

    from unittest.mock import patch

    from .helpers import FakeFile

    username = "__token__"
    password = "12345"
    pypi_token = "pypi-12345"

    # test with token
    with patch('invoke.run') as mock_run:
        os.environ['PYPI_TOKEN'] = pypi_token
        with patch.object(os.path, 'isdir', return_value=True):
            upload_to_pypi(path='dist')
            mock_run.assert_called_once_with(
                f"twine upload -u '{username}' -p '{password}' 'dist/*'"
            )

    # test with user and password

# Generated at 2022-06-21 21:01:14.699955
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    from contextlib import contextmanager
    from mock import Mock

    @contextmanager
    def mock_environment(**env):
        """Mock the environment variables.
        """
        real_env = os.environ
        os.environ = real_env.copy()
        os.environ.update(env)
        try:
            yield
        finally:
            os.environ = real_env

    run = Mock(return_value=None)
    with mock_environment(PYPI_TOKEN="pypi-abc123"):
        upload_to_pypi(
            path="dist", skip_existing=False, glob_patterns=["*"]
        )

# Generated at 2022-06-21 21:01:25.191307
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil
    import tempfile
    from semantic_release.settings import config
    from semantic_release.settings import read_user_config


# Generated at 2022-06-21 21:01:37.966891
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test an upload IRL is probably not a good idea, so just check the cli command is correct
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    token = "pypi-abcdef1234567abcdef1234567abcdef1234567"

    # Test with token
    run.assert_called_once_with(
        f"twine upload -u '__token__' -p '{token}' 'dist/*'"
    )

    # Test with username/password
    username = "foo_bar_user"
    password = "s3cretpassword"
    run.assert_called_once_with(
        f"twine upload -u '{username}' -p '{password}' 'dist/*'"
    )

    # Test with repository

# Generated at 2022-06-21 21:01:47.136581
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_PASSWORD"] = "password"
    try:
        upload_to_pypi.__wrapped__("dist")
    except ImproperConfigurationError:
        assert True
    else:
        assert False
    os.environ["PYPI_USERNAME"] = "username"
    try:
        upload_to_pypi.__wrapped__("dist")
    except ImproperConfigurationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 21:01:57.343773
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .mocks import MockRun
    from mock import patch
    from semantic_release.settings import config
    config.update({"repository": "test-repo"})
    try:
        with patch("invoke.run", side_effect=MockRun) as mocked_run:
            upload_to_pypi(glob_patterns=["*", "*.txt", "*.rst"])
    except ImproperConfigurationError:
        pass
    mocked_run.assert_called_once_with(
        "twine upload -u '__token__' -p 'pypi-test' -r 'test-repo' 'dist/wheels/test-wheel' 'dist/wheels/test-wheel.txt' 'dist/wheels/test-wheel.rst'",
        warn=True,
    )

# Generated at 2022-06-21 21:02:00.812074
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    glob_patterns = ["file1", "file2"]
    assert upload_to_pypi(glob_patterns=glob_patterns) == "twine upload  \"dist/file1\" \"dist/file2\""

# Generated at 2022-06-21 21:02:01.654717
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-21 21:02:02.488136
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:02:03.570435
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == "Twine output"

# Generated at 2022-06-21 21:02:06.417714
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    assert True

# Generated at 2022-06-21 21:02:15.136905
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist")
    upload_to_pypi(path="dist", skip_existing=True)
    upload_to_pypi(path="dist", glob_patterns=["*.tar.gz"])
    upload_to_pypi(path="dist", glob_patterns=["*.tar.gz"], skip_existing=True)
    upload_to_pypi(path="dist", repository="testpypi")
    upload_to_pypi(path="dist", repository="testpypi", skip_existing=True)



# Generated at 2022-06-21 21:02:22.248654
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def get_token():
        return os.environ.get("PYPI_TOKEN", None)

    token = get_token()
    try:
        if token is None:
            os.environ["PYPI_TOKEN"] = "pypi-00000000000000000000000000000000"
            token = get_token()
        if token is None:
            raise ImproperConfigurationError("Missing credentials for uploading to PyPI")
        upload_to_pypi()
    finally:
        if token is None:
            del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-21 21:02:32.360491
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import mock
    import sys
    from semantic_release.exceptions import UploadToPypiError

    class Mock_invoke(object):
        class Mock_run(object):
            @staticmethod
            def __call__(command=None):
                if sys.version_info >= (3, 8, 0):
                    if command == r"twine upload  --skip-existing 'dist/my-wheel.whl'":
                        return 'Uploaded my-wheel.whl (version 0.1.0) to https://upload.pypi.org/legacy/'
                    else:
                        raise UploadToPypiError('Error message')

# Generated at 2022-06-21 21:02:41.827170
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:02:51.364244
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username = 'pypi-username'
    token = 'pypi-token'
    password = 'pypi-password'
    path = 'dist/test_upload_to_pypi'
    dist = 'dist/test_upload_to_pypi/test-*'
    repository = 'test_upload_to_pypi-repository'

    import os
    import shutil

    if not os.path.exists(path):
        os.makedirs(path)
        open(dist,'w').close()


# Generated at 2022-06-21 21:03:02.930876
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    import re
    import glob
    import json
    import os
    import tempfile
    import sys
    import pathlib
    import zipfile
    import tarfile
    import logging
    import unittest
    from unittest.mock import patch, mock_open, MagicMock
    from typing import List
    from datetime import datetime
    from contextlib import contextmanager
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from invoke import run, Context
    from semantic_release.version_service import get_next_version
    from semantic_release.vcs_helpers import get_commit_messages
    from semantic_release.changelog import _generate_changelog
    from semantic_release.settings import config, MANIFEST_PATTERNS

# Generated at 2022-06-21 21:03:04.127771
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:03:13.245801
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    with open('.travis.yml', 'w') as fout:
        fout.write('install:\n  - pip install twine\n')

# Generated at 2022-06-21 21:03:15.586810
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    raise NotImplementedError('Unit test not implemented')

# Generated at 2022-06-21 21:03:25.667985
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert "twine upload " == upload_to_pypi()[0:14]
    assert "twine upload -u '__token__' -p 'pypi-1234abcde' --skip-existing" == upload_to_pypi(
        skip_existing=True, token="pypi-1234abcde"
    )[0:55]
    assert "twine upload -u '__token__' -p 'pypi-1234abcde' " == upload_to_pypi(
        token="pypi-1234abcde"
    )[0:47]

# Generated at 2022-06-21 21:03:27.383819
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi."""
    upload_to_pypi()

# Generated at 2022-06-21 21:03:36.840395
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_run
    import pytest

    base_path = "/foo"
    filenames = ["bar.whl", "bar2.whl"]
    files = " ".join([f'"{base_path}/{filename}"' for filename in filenames])

    # Test without a PyPI token or username and password
    with pytest.raises(ImproperConfigurationError, match="Missing credentials"):
        upload_to_pypi(path=base_path, glob_patterns=filenames)

    # Test with a PyPI token, customer repository and skip_existing
    token = "pypi-TOKEN"
    username = "__token__"
    os.environ["PYPI_TOKEN"] = token
    repository = "custom_repository"

# Generated at 2022-06-21 21:03:39.245963
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ Unit test for function upload_to_pypi """
    uploads_pypi = upload_to_pypi()

# Generated at 2022-06-21 21:04:05.804388
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Must be able to upload with environment variables
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    # Should raise an error if neither are present
    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-21 21:04:07.336035
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(skip_existing=False, glob_patterns=None)

# Generated at 2022-06-21 21:04:08.933274
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    upload_to_pypi(skip_existing=True, glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:04:20.947093
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload_to_pypi with valid and invalid settings
    """
    # valid case with glob_patterns provided
    try:
        upload_to_pypi(
            path='tests/test_files', skip_existing=False, glob_patterns=["test_file"]
        )
        assert True
    except:
        assert False

    # valid case with glob_patterns provided
    try:
        upload_to_pypi(
            path='tests/test_files', skip_existing=False, glob_patterns=["*"]
        )
        assert True
    except:
        assert False

    # valid case with glob_patterns not provided

# Generated at 2022-06-21 21:04:27.142692
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "test"
    os.environ["PYPI_PASSWORD"] = "testpass"
    os.environ["PYPI_REPOSITORY"] = "testrepo"

    # create a test file to upload
    with open("test.test", "w") as f:
        f.write("test")
    os.environ["HOME"] = os.getcwd()

    upload_to_pypi(glob_patterns=["test.test"])
    os.unlink("test.test")

# Generated at 2022-06-21 21:04:32.406878
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test the upload_to_pypi function.
    """
    import os
    import shutil
    import tempfile

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    os.environ["HOME"] = tmp_dir
    # Create the .pypirc file
    _pypirc_file = open(os.path.join(tmp_dir, ".pypirc"), "w")
    _pypirc_file.write(
        """
[pypi]
username: pypi_username
password: pypi_password
"""
    )
    _pypirc_file.close()
    # Create a test package
    package_dir = os.path.join(tmp_dir, "sample_package")
    os.mkdir(package_dir)
    _setup_

# Generated at 2022-06-21 21:04:43.344219
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os, tempfile
    from zipfile import ZipFile
    from invoke.exceptions import UnexpectedExit

    # Avoid sending an actual upload request to PyPI
    os.environ["TWINE_REPOSITORY_URL"] = "http://example.com"

    # Skip test if "twine" is not available
    try:
        run("twine --version")
    except UnexpectedExit:
        pass

    # Create a temporary directory with a dummy zip file
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create dummy zip file
        with open(f"{tmpdir}/dummy.zip", "wb") as f:
            z = ZipFile(f, "w")
            z.writestr("dummy.txt", "dummy")
            z.close()
        # Upload file
        upload_to

# Generated at 2022-06-21 21:04:45.027421
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["semantic_release-*", "dist/*"])

# Generated at 2022-06-21 21:04:46.059462
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:04:47.748801
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:05:31.150066
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import contextlib
    import pathlib
    import tempfile
    import time
    import shutil
    import subprocess
    import sys
    import os

    @contextlib.contextmanager
    def temp_path(make_dir=False):
        with tempfile.TemporaryDirectory() as tmpdirname:
            if make_dir:
                tmpdirname = os.path.join(tmpdirname, "dist")
            os.mkdir(tmpdirname)
            yield pathlib.Path(tmpdirname)

    @contextlib.contextmanager
    def temp_file(file_name):
        with temp_path() as tmpdir:
            with open(os.path.join(tmpdir, file_name), "w") as file:
                yield file
    # Test for missing configuration

# Generated at 2022-06-21 21:05:32.323546
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:05:38.863291
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Verify that Twine gets called with the options in the function body."""
    glob_patterns = ["*.whl"]
    path = 'c:\\something\\'
    upload_to_pypi(path, True, glob_patterns)
    assert run.calls[-1].args[0] == f"twine upload  --skip-existing '{path}/{glob_patterns[0]}'"

# Generated at 2022-06-21 21:05:47.179001
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Python 3.6.0, Mac OS X 10.12.6
    """
    import os
    from invoke import run

    from .helpers import LoggedFunction

    logger = logging.getLogger(__name__)


# Generated at 2022-06-21 21:05:55.981062
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command):
        assert command == f"twine upload -u '{username}' -p '{password}'{repository_arg} {dist}"

    from unittest.mock import patch
    from semantic_release.settings import config

    repository = "repo"
    username = "username"
    password = "password"
    config["repository"] = repository

    repository_arg = f" -r '{repository}'"
    dist = "dist/*"

    with patch("invoke.run", mock_run):
        upload_to_pypi(path="dist", username=username, password=password)

# Generated at 2022-06-21 21:06:00.243022
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create a string to be returned from running a command
    expected_return = "test"

    # Create a function that fakes the return from invoker run
    def fake_run(*_):
        return expected_return

    # Mock the function 'run' from 'invoker' with the fake function created
    upload_to_pypi.__wrapped__.run = fake_run

    # Call the function
    result = upload_to_pypi()

    assert expected_return == result

# Generated at 2022-06-21 21:06:12.058786
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Expect exception if token missing
    try:
        upload_to_pypi()
        raise Exception("Error expected in upload_to_pypi_exception_token")
    except ImproperConfigurationError as ex:
        assert str(ex) == "Missing credentials for uploading to PyPI"

    # Expect exception if token missing 'pypi-'
    try:
        os.environ["PYPI_TOKEN"] = "does-not-begin-with-pypi-"
        upload_to_pypi()
        raise Exception("Error expected in upload_to_pypi_exception_token_pypi")
    except ImproperConfigurationError as ex:
        assert str(ex) == 'PyPI token should begin with "pypi-"'

    # Expect no exception if uploads path

# Generated at 2022-06-21 21:06:12.605328
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:06:15.516920
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with run.configuration(overrides={"run": {"echo": True}}):
        upload_to_pypi("path", glob_patterns=["file1", "file2"])

# Generated at 2022-06-21 21:06:26.051604
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_USERNAME"] = "test_user"
    os.environ["PYPI_PASSWORD"] = "test_password"
    upload_to_pypi()
    assert run.calls[0].args == "twine upload -u 'test_user' -p 'test_password'  'dist/*'"
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    os.environ["PYPI_TOKEN"] = "pypi-test_token"
    upload_to_pypi(skip_existing=True)
    assert run.calls[1].args == "twine upload -u '__token__' -p 'pypi-test_token' --skip-existing 'dist/*'"


# Generated at 2022-06-21 21:07:35.488379
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("path", True, ["a", "b"]) == ("twine upload -r 'a' --skip-existing 'path/a' 'path/b'")

# Generated at 2022-06-21 21:07:44.532518
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import Mock
    from unittest.mock import patch
    import pytest
    with patch('invoke.run', Mock()) as mock_method:
        with pytest.raises(ImproperConfigurationError) as err:
            upload_to_pypi()
        assert str(err.value) == 'Missing credentials for uploading to PyPI'
    with patch('invoke.run', Mock()) as mock_method:
        with pytest.raises(ImproperConfigurationError) as err:
            upload_to_pypi(token='pypi-')
        assert str(err.value) == 'PyPI token should begin with "pypi-"'
    with patch('invoke.run', Mock()) as mock_method:
        with pytest.raises(ImproperConfigurationError) as err:
            upload_to

# Generated at 2022-06-21 21:07:48.530575
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Creating a file to upload in the dist folder
    open('dist/test_upload.txt', 'a').close()
    # Calling the function
    upload_to_pypi()
    # Removing the file
    os.remove('dist/test_upload.txt')

# Generated at 2022-06-21 21:07:49.133678
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:07:52.343677
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi.logger = logger
    upload_to_pypi()

# Generated at 2022-06-21 21:08:00.593752
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from invoke.exceptions import Failure
    with pytest.raises(ImproperConfigurationError,
                       message="Missing credentials for uploading to PyPI"):
        upload_to_pypi()
    os.environ["PYPI_USERNAME"] = "username"
    with pytest.raises(ImproperConfigurationError,
                       message='PyPI token should begin with "pypi-"'):
        upload_to_pypi()
    os.environ["PYPI_TOKEN"] = "pypi-asdf"
    with pytest.raises(Failure):
        upload_to_pypi()


test_upload_to_pypi()

# Generated at 2022-06-21 21:08:07.606482
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from . import (
        TEST_UPLOAD_TO_PYPI_TOKEN,
        TEST_UPLOAD_TO_PYPI_USERNAME,
        TEST_UPLOAD_TO_PYPI_PASSWORD,
        TEST_UPLOAD_TO_PYPI_REPOSITORY,
    )

    # Set environment variables
    os.environ["PYPI_TOKEN"] = TEST_UPLOAD_TO_PYPI_TOKEN
    os.environ["PYPI_USERNAME"] = TEST_UPLOAD_TO_PYPI_USERNAME
    os.environ["PYPI_PASSWORD"] = TEST_UPLOAD_TO_PYPI_PASSWORD

    # Run function
    upload_to_pypi()

    # Reset environment variables
    del os

# Generated at 2022-06-21 21:08:09.611303
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO
    pass

# Generated at 2022-06-21 21:08:10.903045
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:08:13.805447
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    
    # call function upload_to_pypi
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])