

# Generated at 2022-06-21 21:00:08.476531
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-21 21:00:15.991890
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*", "**/*"])
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*", "**/*"])

# Generated at 2022-06-21 21:00:16.888297
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:00:25.452618
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi
    """
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 21:00:36.901127
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command, hide=None):
        if PYPI_TOKEN:
            assert command == f'twine upload -u \'__token__\' -p \'{PYPI_TOKEN}\' --skip-existing dist/b/c.py'
        else:
            assert command == f'twine upload -u \'{username}\' -p \'{password}\' -r \'{repository}\' --skip-existing dist/b/c.py'

    PYPI_TOKEN = "pypi-token"

    import os
    import sys
    import pytest
    from types import MethodType

    saved_os_environ = os.environ.copy()

    os.environ["PYPI_TOKEN"] = PYPI_TOKEN

    # Patch run function
    import invoke

# Generated at 2022-06-21 21:00:39.573924
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(path="dist", skip_existing=False, glob_patterns=("*","*.egg")) == None

# Generated at 2022-06-21 21:00:45.760576
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test upload to PyPI
    """
    try:
        # Test with a token
        os.environ["PYPI_TOKEN"] = "pypi-testtoken"
        # Test with a repository
        os.environ["PYPI_REPOSITORY"] = "testrepo"
        upload_to_pypi()
    finally:
        del os.environ["PYPI_TOKEN"]
        del os.environ["PYPI_REPOSITORY"]

# Generated at 2022-06-21 21:00:49.233119
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(
        os.path.join(os.path.dirname(__file__), "data"),
        skip_existing=False,
        glob_patterns=["*.whl"]
    )

# Generated at 2022-06-21 21:00:50.749967
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Automate test by creating folder with files and uploading with Twine
    assert True

# Generated at 2022-06-21 21:00:58.207688
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi."""
    from .helpers import mock_run
    import contextlib
    import sys

    dist_dir = "dist"
    upload_globs = ["*"]

    def run_twine(params, *args, **kwargs):
        repository_arg = "-r '{}'".format(config["repository"])
        expected_arg = "-u '__token__' -p 'pypi-{}' {} {} --skip-existing dist/*".format(
            config["auth"]["pypi"], repository_arg, skip_existing_arg
        )
        assert params == expected_arg

    @contextlib.contextmanager
    def mock_config_file(config):
        """Mock the configuration file to use for the test."""
        import tempfile
       

# Generated at 2022-06-21 21:01:04.493605
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass  # TODO: Need to figure out how to test this with Invoke, since we don't want to actually upload to PyPI

# Generated at 2022-06-21 21:01:14.631761
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Upload wheels to PyPI with Twine.

    Wheels must already be created and stored at the given path.

    Credentials are taken from either the environment variable
    ``PYPI_TOKEN``, or from ``PYPI_USERNAME`` and ``PYPI_PASSWORD``.

    :param path: Path to dist folder containing the files to upload.
    :param skip_existing: Continue uploading files if one already exists.
        (Only valid when uploading to PyPI. Other implementations may not support this.)
    :param glob_patterns: List of glob patterns to include in the upload (["*"] by default).
    """
    glob_patterns = ['*']
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None
    if not token:
        username = os.environ

# Generated at 2022-06-21 21:01:16.947780
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .mocks.invoke import MockContext
    from .mocks.twine import MockTwine

    with MockContext(MockTwine):
        upload_to_pypi()

# Generated at 2022-06-21 21:01:26.081968
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test upload with API token
    pypi_token_clear = os.environ.get("PYPI_TOKEN", None)
    os.environ["PYPI_TOKEN"] = "pypi-api_token"

    pypi_username_clear = os.environ.get("PYPI_USERNAME", None)
    pypi_password_clear = os.environ.get("PYPI_PASSWORD", None)
    os.environ["PYPI_USERNAME"] = os.environ["PYPI_PASSWORD"] = None

    def clear():
        if pypi_username_clear is None:
            os.environ.pop("PYPI_USERNAME", None)
        else:
            os.environ["PYPI_USERNAME"] = pypi_

# Generated at 2022-06-21 21:01:37.653963
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    The function upload_to_pypi should succeed provided the information is valid
    """
    os.environ["PYPI_TOKEN"] = "pypi-token"
    os.environ["PYPI_USERNAME"] = "token"
    os.environ["PYPI_PASSWORD"] = "pypi-token"
    upload_to_pypi()

    os.environ["PYPI_TOKEN"] = "pypi-token"
    os.environ["PYPI_USERNAME"] = "__token__"
    os.environ["PYPI_PASSWORD"] = "pypi-token"
    upload_to_pypi()

# Generated at 2022-06-21 21:01:39.874175
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-21 21:01:48.305983
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import LoggedFunction
    from semantic_release.settings import config
    from semantic_release.version_service.commit_history import get_last_release_from_history

    # skip this test on cloud CI as it requires PYPI_TOKEN
    if config('CI') == 'true' and config('CI_CLOUD') == 'true':
        return

    # skip this test on Actions CI as it requires PYPI_TOKEN
    if config('CI') == 'true' and config('CI_NAME') == 'GitHub Actions':
        return

    # Test if function can be called without parameters
    assert not upload_to_pypi.__wrapped__()

    # Test if function can be called with parameters (default)

# Generated at 2022-06-21 21:01:59.362517
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    # Unit test examples
    def test_upload_to_pypi_example1():
        run('echo "Hello world"')
    def test_upload_to_pypi_example2():
        run('echo "Hello world"')
    def test_upload_to_pypi_example3():
        run('echo "Hello world"')
    def test_upload_to_pypi_example4():
        run('echo "Hello world"')
    def test_upload_to_pypi_example5():
        run('echo "Hello world"')
    def test_upload_to_pypi_example6():
        run('echo "Hello world"')
    def test_upload_to_pypi_example7():
        run('echo "Hello world"')

# Generated at 2022-06-21 21:02:02.527890
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import subprocess
    with open(os.devnull, "w") as fnull:
        assert subprocess.call(
            ["twine", "upload", "--help"], stdout=fnull, stderr=fnull
        ) == 0

# Generated at 2022-06-21 21:02:04.833081
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass


# Generated at 2022-06-21 21:02:18.452336
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def fake_run(cmd: str) -> None:
        assert cmd == "twine upload -u 'some_user' -p 'some_password' 'some/path/*'"
        return 0

    upload_to_pypi(path="some/path", skip_existing=False, glob_patterns=["*"], run=fake_run)

# Generated at 2022-06-21 21:02:18.818569
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:02:26.916796
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with run.mock:
        upload_to_pypi(glob_patterns=["*"], skip_existing=False, path="foo")
        run.assert_called_once_with("twine upload  foo/'*'")
        
        run.reset_mock()

        upload_to_pypi(glob_patterns=["*"], skip_existing=True, path="foo")
        run.assert_called_once_with("twine upload  --skip-existing foo/'*'")
        
        run.reset_mock()

        upload_to_pypi(glob_patterns=["*"], skip_existing=True, path="foo", repository='bar')
        run.assert_called_once_with("twine upload  --skip-existing -r 'bar' foo/'*'")

# Generated at 2022-06-21 21:02:28.281630
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for every option of the function, including the error
    assert True

# Generated at 2022-06-21 21:02:35.666507
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import pytest
    from .helpers import temp_chdir
    from .helpers import create_temp_dir
    from .helpers import touch

    # Create a temporary directory to store the distribution files
    with temp_chdir(create_temp_dir()) as path:
        # Create dummy distribution files
        touch('dist/foo.whl')

        # Ensure that a FunctionException is thrown if no credentials are passed
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

        # Ensure that if no PyPI token is passed, an error is raised
        os.environ['PYPI_USERNAME'] = 'user'
        os.environ['PYPI_PASSWORD'] = 'pass'
        with pytest.raises(ImproperConfigurationError):
            upload_to_pypi()

# Generated at 2022-06-21 21:02:37.042896
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:02:39.204605
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run("mkdir dist")
    run("touch dist/test.txt")
    upload_to_pypi()

# Generated at 2022-06-21 21:02:39.768745
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert 1 == 1

# Generated at 2022-06-21 21:02:40.384247
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:02:49.374328
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Tests if upload_to_pypi invokes the correct command"""
    path = "dist"
    skip_existing = True
    glob_patterns = ["*"]

    def run_mock(
        cmd
    ):  # pylint: disable=unused-argument
        assert cmd.startswith("twine upload")
        assert "pypi-TestToken" in cmd
        assert "repository" in cmd
        assert cmd.endswith('"dist/*"')

    with patch("invoke.run", run_mock):
        upload_to_pypi(
            path=path, skip_existing=skip_existing, glob_patterns=glob_patterns
        )

# Generated at 2022-06-21 21:03:07.026486
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:03:15.407515
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mocked_run(cmd):
        assert cmd == (
            "twine upload -u '__token__' -p 'pypi-token' "
            '-r "test_repository" --skip-existing "./dist/dist_file_1" "./dist/dist_file_2"'
        )

    # Use environment variables
    os.environ["PYPI_TOKEN"] = "pypi-token"
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"


# Generated at 2022-06-21 21:03:17.699347
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:03:23.043327
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Check that function upload_to_pypi is working as expected"""

    # We check here that the function is working perfectly
    # in case we have the credentials set.
    if "PYPI_TOKEN" in os.environ or ("PYPI_USERNAME" in os.environ and "PYPI_PASSWORD" in os.environ):
        upload_to_pypi()

# Generated at 2022-06-21 21:03:25.745232
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ Test upload_to_pypi function.
    """
    upload_to_pypi(path="./dist", glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:03:31.389346
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .mock_invoke_run import MockInvokeRun

    mock_invoke_run = MockInvokeRun()

    glob_patterns = ["some_file", "some_other_file"]
    upload_to_pypi(path = "my-dist-path", skip_existing = True, glob_patterns = glob_patterns)

    assert mock_invoke_run.command == f'twine upload -u \'\' -p \'\' --skip-existing "my-dist-path/some_file" "my-dist-path/some_other_file"'

# Generated at 2022-06-21 21:03:32.720717
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() is None

# Generated at 2022-06-21 21:03:34.181854
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO
    pass

if __name__ == "__main__":
    test_upload_to_pypi()

# Generated at 2022-06-21 21:03:34.783374
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:03:43.022821
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import make_temp_folder, remove_temp_folder
    from pathlib import Path
    from subprocess import check_output
    import pytest
    import shutil
    import glob
    import re

    # Setup a temp project
    temp_folder = make_temp_folder()

    # Create a wheel file
    package_name = "hello"
    package_version = "0.0.2"
    wheel_filename = f"{package_name}-{package_version}-py3-none-any.whl"
    wheel_path = Path(f"{temp_folder}/dist/")
    wheel_path.mkdir(parents=True, exist_ok=True)
    wheel_file = wheel_path.joinpath(wheel_filename)
    wheel_file.touch()

    # Add the wheel to

# Generated at 2022-06-21 21:04:17.682654
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert "upload" in upload_to_pypi.__doc__

# Generated at 2022-06-21 21:04:19.777207
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-blahblah"
    upload_to_pypi()

# Generated at 2022-06-21 21:04:20.942197
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:04:23.331965
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit Test: upload_to_pypi
    """
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-21 21:04:23.844882
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:04:24.365627
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass # TODO

# Generated at 2022-06-21 21:04:24.977714
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:04:25.570626
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:04:37.805496
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function.
    """
    # Save the config before the test
    saved_config = config.copy()
    saved_env = os.environ.copy()

    # Test setup
    config["repository"] = "test_repo"
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"

    # Test run
    upload_to_pypi("test_path", True, ["test_glob_pattern_1", "test_glob_pattern_2"])

    # Test the written command

# Generated at 2022-06-21 21:04:38.593731
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi


# Generated at 2022-06-21 21:05:50.830319
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with pytest.raises(ImproperConfigurationError) as excinfo:
        upload_to_pypi()
    assert str(excinfo.value) == "Missing credentials for uploading to PyPI"
    with pytest.raises(ImproperConfigurationError) as excinfo:
        upload_to_pypi(
            path="dist", skip_existing=True, glob_patterns=["*"], token=1234
        )
    assert str(excinfo.value) == 'PyPI token should begin with "pypi-"'

# Generated at 2022-06-21 21:05:51.768586
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:06:00.189119
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # When credentials are provided in environment variables
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()

    # When credentials are provided in environment variables
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()

    # When credentials are provided in environment variables
    os.environ["PYPI_TOKEN"] = "pypi-token"
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()

    # When no credentials are provided

# Generated at 2022-06-21 21:06:12.019609
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert os.environ.get("PYPI_TOKEN") is None, "PYPI_TOKEN env variable exists - remove"
    assert os.environ.get("PYPI_USERNAME") is None, "PYPI_USERNAME env variable exists - remove"
    assert os.environ.get("PYPI_PASSWORD") is None, "PYPI_PASSWORD env variable exists - remove"
    assert os.environ.get("HOME") is None, "HOME env variable exists - remove"

    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    os.environ["PYPI_USERNAME"] = "fake_username"
    os.environ["PYPI_PASSWORD"] = "fake_password"


# Generated at 2022-06-21 21:06:12.553347
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:06:14.302599
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(glob_patterns=["*"]) == None

# Generated at 2022-06-21 21:06:14.964421
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    return

# Generated at 2022-06-21 21:06:15.868892
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi

# Generated at 2022-06-21 21:06:22.113304
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", False, glob_patterns=None)
    upload_to_pypi("dist", False, glob_patterns=["*"])
    upload_to_pypi("dist", True, glob_patterns=["*"])
    upload_to_pypi("dist", True, glob_patterns=None)

# Generated at 2022-06-21 21:06:27.080756
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    from .helpers import FakeReporter

    fake_reporter = FakeReporter()
    logger.addHandler(fake_reporter)

    upload_to_pypi(path="fake_path")

    assert "Twine will upload" in fake_reporter.messages["info"][0]

    upload_to_pypi(skip_existing=True)

    # Ensure that skip_existing is set.
    assert "twine upload" in fake_reporter.messages["info"][0]

# Generated at 2022-06-21 21:08:59.335004
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .test_settings import test_config
    from .helpers import MockLogger
    from .helpers import MockRun
    from .helpers import expect_log
    from .helpers import expect_run
    from .helpers import mock_run

    logger = MockLogger()
    config.update(test_config)
    do_mock_run = mock_run()

    # Happy path, with a PYPI_TOKEN
    with do_mock_run as run:
        os.environ['PYPI_TOKEN'] = 'pypi-1234567890abcdefg'
        upload_to_pypi('dist')

    expect_log(logger, "info", "Uploading wheel to PyPI.")

# Generated at 2022-06-21 21:09:06.334130
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_PASSWORD"] = "password"
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["GITHUB_REPO"] = "repo"
    try:
        upload_to_pypi()
    finally:
        del os.environ["PYPI_PASSWORD"]
        del os.environ["PYPI_USERNAME"]
        del os.environ["GITHUB_REPO"]

# Generated at 2022-06-21 21:09:06.924472
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:09:14.194044
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import glob
    import shutil
    import tempfile
    from unittest.mock import patch
    from unittest.mock import Mock
    from unittest.mock import sentinel
    from unittest.mock import call
    from os.path import exists
    from os.path import isdir
    from os.path import isfile

    def create_temp_files(files=['foo.zip', 'bar.zip'], dir='dist'):
        for file_ in files:
            open(os.path.join(temp_dir, dir, file_), 'a').close()

    def create_temp_dirs(dirs=['foobar']):
        for dir_ in dirs:
            os.mkdir(os.path.join(temp_dir, dir_))


# Generated at 2022-06-21 21:09:26.149945
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.tests import (
        make_config,
        mock_pypi_tokens,
        set_env,
        set_env_config_variables,
    )
    import sys

    import_flask_app()

    def make_env(environ, **kwargs):
        return set_env(os.environ, **environ)

    # No token or password
    with mock_pypi_tokens(["pypi-token"]), make_env({}):
        with make_config(set_env_config_variables(), override=False):
            with pytest.raises(ImproperConfigurationError):
                upload_to_pypi()

    # Missing username

# Generated at 2022-06-21 21:09:31.247346
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.

    Checks if the function upload_to_pypi has been tested.
    """
    try:
        assert(True)
        print("Unit test for function upload_to_pypi has been checked!")
    except AssertionError:
        print("Unit test for function upload_to_pypi has not been checked!")

# Generated at 2022-06-21 21:09:32.203566
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None

# Generated at 2022-06-21 21:09:35.390753
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        run("python setup.py wheel", hide="both")
    except (OSError, IOError):
        raise AssertionError("Cannot run python setup.py wheel")
    upload_to_pypi()

# Generated at 2022-06-21 21:09:36.242494
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    return True

# Generated at 2022-06-21 21:09:38.488625
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import make_upload_to_pypi_func

    make_upload_to_pypi_func(test_upload_to_pypi)()