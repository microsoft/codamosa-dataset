

# Generated at 2022-06-21 21:00:06.940806
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        upload_to_pypi(path="./dist", glob_patterns=["*"])
    except ValueError:
        upload_to_pypi(path="./dist", glob_patterns=["*"])

# Generated at 2022-06-21 21:00:16.366485
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if not os.path.exists("dist"):
        os.mkdir("dist")
    with open("dist/test.whl", "w+") as f:
        f.write("test")
    old_token = os.environ.get("PYPI_TOKEN", "test")
    try:
        os.environ["PYPI_TOKEN"] = "pypi-test"
        upload_to_pypi("dist", skip_existing=True)
        os.remove("dist/test.whl")
    finally:
        os.environ["PYPI_TOKEN"] = old_token

# Generated at 2022-06-21 21:00:24.995080
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockInvokeContext
    from .helpers import mock_invoke
    from .helpers import mock_os_environ

    with mock_invoke() as ctx:
        with mock_os_environ() as os_environ:
            os_environ.update({"PYPI_USERNAME": "test_user", "PYPI_PASSWORD": "test_password"})
            upload_to_pypi()
            assert ctx.run.call_args[0][0] == "twine upload -u 'test_user' -p 'test_password' *"

            os_environ.pop("PYPI_USERNAME")
            upload_to_pypi()
            assert ctx.run.call_args[0][0] == "twine upload *"

            os_environ

# Generated at 2022-06-21 21:00:35.325672
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import subprocess
    import sys
    import glob

    def check_files(*files):
        [open(f, "a").close() for f in files]

    def list_files():
        return [os.path.abspath(f) for f in glob.glob(os.path.join("dist", "*"))]

    current_dir = os.path.abspath(".")
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 21:00:43.680610
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert (
        upload_to_pypi.__doc__ == "Upload wheels to PyPI with Twine.\n\n    Wheels must already be created and stored at the given path.\n\n    Credentials are taken from either the environment variable\n    ``PYPI_TOKEN``, or from ``PYPI_USERNAME`` and ``PYPI_PASSWORD``.\n\n    :param path: Path to dist folder containing the files to upload.\n    :param skip_existing: Continue uploading files if one already exists.\n        (Only valid when uploading to PyPI. Other implementations may not support this.)\n    :param glob_patterns: List of glob patterns to include in the upload ([\"*\"] by default)."
    )

# Generated at 2022-06-21 21:00:46.679729
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for fail case
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        raise AssertionError(
            "Expected ImproperConfigurationError exception to be raised."
        )

# Generated at 2022-06-21 21:00:54.323735
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Test function upload_to_pypi
    """
    from invoke import MockContext
    from semantic_release.uploaders.helpers import LoggedFunction

    mock_logger = Mock()
    mock_context = MockContext()
    mock_context.run = Mock(return_value=MockContext())

    Uploader = LoggedFunction(mock_logger, upload_to_pypi)
    Uploader(mock_context)
    mock_logger.debug.assert_called_once()
    mock_logger.info.assert_called_once()

# Generated at 2022-06-21 21:00:55.101677
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:01:02.946409
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # This tests the above code, but must be invoked directly via pytest.
    # TODO: figure out how to make this an actual unit test.
    from .helpers import get_test_package_name
    from .helpers import get_test_package_version
    from .helpers import prepare_test_package_dist

    pypirc_file = os.path.expanduser("~/.pypirc")

# Generated at 2022-06-21 21:01:03.802987
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:01:16.483594
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Tests upload_to_pypi
    """
    def _get_env(var):
        if var in os.environ:
            return os.environ[var]
        else:
            return None

    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    os.environ["PYPI_TOKEN"] = "test_token"

    path = "dist_path"

    # NOTE: This function is only tested with the PyPI implementation
    # Will result in error message for non-PyPI implementations
    # but we keep the test for completeness

# Generated at 2022-06-21 21:01:18.260892
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """This is just a smoke test to exercise the function.
    """
    upload_to_pypi()

# Generated at 2022-06-21 21:01:22.094976
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    alternate_repo = os.environ.get("PYPI_REPOSITORY", "https://test.pypi.org")
    config["repository"] = alternate_repo

    upload_to_pypi("dist")

    del config["repository"]

# Generated at 2022-06-21 21:01:28.341147
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import patched_run

    skip_existing = False
    glob_patterns = None
    dist = "dist"
    path = "path"
    run_patch = patched_run()
    token = "token"
    username = "username"
    password = "password"
    repository = "repository"
    repository_arg = f" -r '{repository}'"
    username_password = f"-u '{username}' -p '{password}'"
    dist_string = f'"{path}/{dist}"'
    skip_existing_param = ""
    run_cmd = f"twine upload {username_password}{repository_arg}{skip_existing_param} {dist_string}"

    test_run_cmd = lambda: run_patch.called_once_with(run_cmd)


# Generated at 2022-06-21 21:01:29.090487
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("test", True, ["*"])

# Generated at 2022-06-21 21:01:37.321066
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""
    if os.environ.get("IN_TEST") is not None:
        return
    # Setup Testing
    os.environ["PYPI_USERNAME"] = "test"
    os.environ["PYPI_PASSWORD"] = "test"
    os.environ["HOME"] = ""
    os.environ["IN_TEST"] = "true"
    os.environ["PYPI_TOKEN"] = ""


    # No glob patterns - should fail
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        raise AssertionError("Missing arguments - should fail")

    # No piprc file - should fail

# Generated at 2022-06-21 21:01:46.899165
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Patch run because we don't want to actually upload anything
    orig_run = run
    run = lambda x: print(f"run {x}")
    # Test with defaults
    upload_to_pypi()
    # Test with valid values
    upload_to_pypi("some/path", True, ["foo", "bar"])
    # Test with token
    os.environ["PYPI_TOKEN"] = "pypi-foo"
    upload_to_pypi()
    # Test with username and password
    os.environ.pop("PYPI_TOKEN")
    os.environ["PYPI_USERNAME"] = "foo"
    os.environ["PYPI_PASSWORD"] = "bar"
    upload_to_pypi()
    # Restore run
    run

# Generated at 2022-06-21 21:01:50.096028
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """An example unit test that tests the upload_to_pypi function"""
    assert "something" == "something"

    assert "something" == "something"

    assert "something" == "something"

    assert "something" == "something"

# Generated at 2022-06-21 21:01:51.806929
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    upload_to_pypi()

# Generated at 2022-06-21 21:02:01.979221
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Test with minimal configuration
    config.load({
        "repository": "https://upload.pypi.org/legacy/",
        "pypi_token": "pypi-XXXXXX"
    })

    # Mock Twine calls
    class MockRun:
        def __init__(self, cmd):
            return
        
        def returncode(self):
            return 0

    run = MockRun

    # Call function
    upload_to_pypi()

    # Check command
    cmd = MockRun.__init__.__name__
    assert cmd == "__init__", f"Module '{cmd}' not included"
    cmd = MockRun.__init__.__globals__["__name__"]
    assert cmd == "invoke", f"Module '{cmd}' not included"
    cmd

# Generated at 2022-06-21 21:02:16.332489
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = os.environ.get("PYPI_TOKEN")
    if token:
        os.environ["PYPI_TOKEN"] = "test-token"
    else:
        token = os.environ.get("PYPI_PASSWORD")
        if token:
            os.environ["PYPI_USERNAME"] = "test-user"
            os.environ["PYPI_PASSWORD"] = "test-pass"
        else:
            os.environ["HOME"] = ""
    try:
        upload_to_pypi("/test/path")
    except ImproperConfigurationError:
        assert True
    else:
        assert False

    os.environ["HOME"] = "/test/home"

# Generated at 2022-06-21 21:02:17.999918
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(glob_patterns=["*"])

# Generated at 2022-06-21 21:02:20.094274
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:02:30.727061
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    from pathlib import Path
    from invoke.exceptions import UnexpectedExit
    from pyfakefs.fake_filesystem_unittest import Patcher
    import os
    import glob

    def _list_all_files(path: str):
        return sorted(list(Path(path).rglob("*")))

    def _set_up_files(temp_dir: str, glob_patterns: List[str]):
        """ Add files to be picked up by a twine upload.
            Create a temporary directory, and move into the temporary directory.
            Create the folders and files that should be picked up by twine.
            Return a list of files created.
            Return to the original working directory.
        """
        # Create temporary directory to run test in
        #

# Generated at 2022-06-21 21:02:32.871333
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: write a better unit test for function upload_to_pypi
    # See https://github.com/relekang/semantic-release-calver/issues/1
    pass

# Generated at 2022-06-21 21:02:35.865959
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()

# Generated at 2022-06-21 21:02:46.380724
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypi_env = {}
    pypi_kwargs = {}
    for key in os.environ.keys():
        if key.startswith("PYPI_"):
            pypi_env[key] = os.environ[key]
    try:
        os.environ["PYPI_TOKEN"] = "pypi-token"
        upload_to_pypi(**pypi_kwargs)
        assert run.call_args[0][0] == "twine upload -u \'__token__\' -p \'pypi-token\' \"*\""
    finally:
        for key in pypi_env:
            os.environ[key] = pypi_env[key]

# Generated at 2022-06-21 21:02:54.322584
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    class TestClass():
        def __init__(self):
            self.enabled = True
            self.repository = None
            self.name = "test_name"

        def __enter__(self):
            return self

        def __exit__(self, type, value, traceback):
            pass

    class Context():
        def __init__(self, config):
            self.config = config

        def __enter__(self):
            return self

        def __exit__(self, type, value, traceback):
            pass

    class Run():
        def __init__(self, command):
            pass

        def __enter__(self):
            return self

        def __exit__(self, type, value, traceback):
            pass

    test_config = TestClass()
    config.__dict__.clear()


# Generated at 2022-06-21 21:03:06.147290
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    # Unit test for upload_to_pypi()
    def mocked_run(cmd):
        cmd_str = " ".join(cmd.split(" ")[1:-1])
        params_str = cmd.split(" ")[-1]
        assert cmd_str == "twine upload -u __token__ -p 'pypi-ABC123' --skip-existing"
        assert params_str == '"dist/my_dist_name.whl" "dist/my_other_dist_name.whl"'

    import semantic_release.upload

    # Back up os.environ and pypi_config
    tmp_env = dict(os.environ)
    tmp_pypi_config = dict(config)

    # Set up the test environment

# Generated at 2022-06-21 21:03:14.840318
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function."""
    # Test try to upload without credentials
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        assert False

    # Test upload with username and password
    try:
        # Set some fake credentials
        os.environ["PYPI_USERNAME"] = "test"
        os.environ["PYPI_PASSWORD"] = "test"
        upload_to_pypi()
    except ImproperConfigurationError:
        assert False
    # Clean up fake credentials
    finally:
        del os.environ["PYPI_USERNAME"]
        os.environ["PYPI_PASSWORD"] = "test"
        del os.environ["PYPI_PASSWORD"]

    #

# Generated at 2022-06-21 21:03:31.123718
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:03:39.422241
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Verify that we raise ImproperConfigurationError when neither PYPI_PASSWORD nor PYPI_TOKEN are set
    os.environ["PYPI_USERNAME"] = "bob"
    os.environ["PYPI_PASSWORD"] = ""
    os.environ["PYPI_TOKEN"] = ""
    try:
        upload_to_pypi(path="dist", skip_existing=False)
    except ImproperConfigurationError:
        assert True
    os.environ["PYPI_PASSWORD"] = "password"
    os.environ["PYPI_TOKEN"] = ""
    upload_to_pypi(path="dist", skip_existing=False)
    assert True
    os.environ["PYPI_PASSWORD"] = ""

# Generated at 2022-06-21 21:03:40.288169
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() is None

# Generated at 2022-06-21 21:03:47.251703
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from invoke import Context
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    from .helpers import LoggedFunction

    with patch("os.environ",{"PYPI_TOKEN": "pypi-token"}):
        with TemporaryDirectory() as path:
            tmp_path = Path(path)
            tmp_path.mkdir()
            (tmp_path / "test.whl").touch()
            ctx = Context()
            upload_to_pypi(str(tmp_path))
            logged = LoggedFunction.last_logged
            assert logged == "Upload wheels to PyPI with Twine"
            assert "twine upload -u '__token__' -p 'pypi-token' '{}/test.whl'".format(tmp_path) in c

# Generated at 2022-06-21 21:03:48.765032
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path=".", skip_existing=False)

# Generated at 2022-06-21 21:03:49.434518
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:03:51.361519
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:03:52.122841
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:03:54.127719
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi.__name__ == "upload_to_pypi"

# Generated at 2022-06-21 21:03:55.784827
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    yeet = upload_to_pypi()
    assert yeet is None

# Generated at 2022-06-21 21:04:38.928617
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import shutil
    import os
    import filecmp
    from semantic_release.hvcs import get_hvcs
    import semantic_release.hvcs.github
    import semantic_release.hvcs.bitbucket
    import semantic_release.hvcs.gitlab
    import semantic_release.package_managers.pypi
    import semantic_release.package_managers.go
    import semantic_release.package_managers.npm
    import semantic_release.settings
    import semantic_release.history

    # Prepare temporary test directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)


# Generated at 2022-06-21 21:04:49.748305
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import subprocess
    import os
    import re

    ####################
    # Setup credentials to run integration tests
    # Create a Python package-template
    subprocess.run(['python', '-m', 'pip', 'install', '--upgrade', 'setuptools', 'wheel'])
    subprocess.run(['python', '-m', 'pip', 'install', '--upgrade', 'twine'])

    test_dir = 'pypi_test'
    os.makedirs(test_dir)
    os.chdir(test_dir)
    subprocess.run(['python', '-m', 'pip', 'install', 'cookiecutter'])
    cookiecutter_args = 'cookiecutter gh:ionelmc/cookiecutter-pylibrary'.split()
    cookiecutter_args

# Generated at 2022-06-21 21:05:04.996000
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    path = "dist"
    skip_existing = False

    glob_patterns = ["*"]
    if "WHL" not in glob_patterns:
        glob_patterns.append("*.whl")

    # Attempt to get an API token from environment
    token = os.environ.get("PYPI_TOKEN")
    username = ""
    password = ""
    if not token:
        # Look for a username and password instead
        username = os.environ.get("PYPI_USERNAME")
        password = os.environ.get("PYPI_PASSWORD")
        home_dir = os.environ.get("HOME", "")

# Generated at 2022-06-21 21:05:11.966564
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    class upload_to_pypi_mock:
        """ Mock run() class for unit testing.
        """

        called = False

        def __init__(self, command):
            self.called = True
            self.command = command

    def mockreturn(command):
        return upload_to_pypi_mock(command)

    # Good test with config file
    os.environ["HOME"] = os.getcwd()
    original_run = run
    run = mockreturn
    upload_to_pypi("dist", skip_existing=False)
    assert run.called == True
    run = original_run

    # Test bad username and password
    os.environ["HOME"] = os.getcwd()
    original_run = run
    run = mockreturn

# Generated at 2022-06-21 21:05:23.455690
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import shutil
    import os

    # Arrange
    shutil.rmtree("dist", ignore_errors=True)
    shutil.rmtree("build", ignore_errors=True)
    shutil.rmtree("temp_dist/", ignore_errors=True)
    run(f"python setup.py sdist bdist_wheel")
    token = os.environ.get("PYPI_TOKEN")
    os.environ['PYPI_TOKEN'] = 'pypi-test'

    # Act
    try:
        upload_to_pypi(path="dist")
    finally:
        os.environ['PYPI_TOKEN'] = token

# Generated at 2022-06-21 21:05:25.428556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi('dist') == None

# Generated at 2022-06-21 21:05:26.862101
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("path", skip_existing=True)

# Generated at 2022-06-21 21:05:28.671691
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=None)

# Generated at 2022-06-21 21:05:29.668431
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()



# Generated at 2022-06-21 21:05:30.853948
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-21 21:06:36.815886
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:06:38.943012
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""

    upload_to_pypi()

    upload_to_pypi(skip_existing = True)

# Generated at 2022-06-21 21:06:44.528937
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    from shutil import copyfileobj
    from semantic_release.services import get_pypi_package_name

    tempdir = tempfile.mkdtemp()
    os.environ["HOME"] = tempdir

# Generated at 2022-06-21 21:06:50.243433
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
        Make sure it raises an exception if we don't provide a token
    """
    import pytest
    from ..helpers import mocked_env

    with mocked_env(PYPI_USERNAME=None, PYPI_PASSWORD=None, PYPI_TOKEN=None):
        try:
            upload_to_pypi()
        except:
            pytest.raises(ImproperConfigurationError)

# Generated at 2022-06-21 21:06:59.569590
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Check error thrown
    os.unsetenv('PYPI_TOKEN')
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    # Check token from env
    os.environ['PYPI_TOKEN'] = 'pypi-test'
    upload_to_pypi()
    # Check username and password from env
    os.unsetenv('PYPI_TOKEN')
    os.environ['PYPI_USERNAME'] = 'test_user'
    os.environ['PYPI_PASSWORD'] = 'test_password'
    upload_to_pypi()

# Generated at 2022-06-21 21:07:04.192290
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi('tests/test_release/', skip_existing=False, glob_patterns=['test_release-0.1.2.tar.gz'])
    upload_to_pypi('tests/test_release/', skip_existing=False, glob_patterns=['test_release-0.1.2-py3-none-any.whl'])

# Generated at 2022-06-21 21:07:05.070765
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:07:10.605290
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    uri = "git@github.com:relekang/python-semantic-release.git"
    repo = {'uri': uri}
    config['repository'] = repo
    upload_to_pypi()

# Generated at 2022-06-21 21:07:15.717378
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", skip_existing=True)
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*.whl"])
    upload_to_pypi("dist", skip_existing=False, glob_patterns=["*.whl", "*.tar.gz"])

# Generated at 2022-06-21 21:07:20.814024
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Upload wheels to PyPI with Twine.

    Wheels must already be created and stored at the given path.

    Credentials are taken from either the environment variable
    ``PYPI_TOKEN``, or from ``PYPI_USERNAME`` and ``PYPI_PASSWORD``.

    Parameters
    ----------
    path: str = "dist",
    skip_existing: bool = False,
    glob_patterns: List[str] = None
    """
    path = "dist"
    skip_existing = False
    glob_patterns = None

    if not glob_patterns:
        glob_patterns = ["*"]

    # Attempt to get an API tok
    token = os.environ.get("PYPI_TOKEN")
    username = None
    password = None


# Generated at 2022-06-21 21:09:51.375364
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "test_token"

    path = "dist"
    skip_existing = True
    glob_patterns = ["*"]

    upload_to_pypi(path, skip_existing, [glob_patterns])

    del os.environ["PYPI_TOKEN"]

# Generated at 2022-06-21 21:09:53.979781
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    func = upload_to_pypi()
    assert str(func) == "uploading to PyPI..."

# Generated at 2022-06-21 21:09:55.889813
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*.whl"])

# Generated at 2022-06-21 21:09:57.655980
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi("dist") == "twine upload dist"