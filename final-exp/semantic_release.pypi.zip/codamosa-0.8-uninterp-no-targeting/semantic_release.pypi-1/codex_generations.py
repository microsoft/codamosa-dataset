

# Generated at 2022-06-21 21:00:20.114103
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit test for function upload_to_pypi
    """
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing, glob_patterns)
    path = "dist"
    skip_existing = False
    glob_patterns = ["docs"]
    upload_to_pypi(path, skip_existing, glob_patterns)
    path = "dist"
    skip_existing = True
    glob_patterns = ["docs"]
    upload_to_pypi(path, skip_existing, glob_patterns)
    path = "dist"
    skip_existing = True
    glob_patterns = ["*"]
    upload_to_pypi(path, skip_existing, glob_patterns)

# Generated at 2022-06-21 21:00:29.693719
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import tempfile
    import os
    from semantic_release.settings import config
    from semantic_release.hvcs import get_default_hvcs

    config.hvcs = get_default_hvcs()
    config.project_url = "https://github.com/relekang/python-semantic-release"
    config.project_name = "python-semantic-release"

    old_cwd = os.getcwd()
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)

# Generated at 2022-06-21 21:00:37.036583
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest import mock

    mock_run = mock.MagicMock()
    with mock.patch("invoke.run", new=mock_run):
        upload_to_pypi()
        assert mock_run.call_count == 1
        assert (
            mock_run.call_args.args[0]
            == "twine upload -u '__token__' -p 'pypi-abc' --skip-existing 'dist/*'"
        )

# Generated at 2022-06-21 21:00:37.618730
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:00:38.814963
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:00:48.098706
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    with patch('invoke.run') as mock_run:
        repo = "test_repo"
        token = "pypi-test_token"
        glob_patterns = ["*.whl"]
        username = "username"
        password = "password"
        dist = f'{glob_patterns[0].strip()}'

        upload_to_pypi(repository=repo, glob_patterns=glob_patterns,
                       skip_existing=True, path='dist')
        mock_run.assert_called_once_with(f"twine upload --skip-existing -r '{repo}' {dist}")

        mock_run.reset_mock()

# Generated at 2022-06-21 21:00:53.994872
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test if method upload_to_pypi uploads to Artifactory.

    It is not possible to upload to PyPI on unit test.
    Instead, we create an artifactory on the local server.
    """
    upload_to_pypi(
        path='unit_test/artifactory',
        filename='example-1.0.0-0.tar.gz',
        username='admin',
        password='password123',
        skip_existing=False,
    )

# Generated at 2022-06-21 21:01:01.902499
# Unit test for function upload_to_pypi
def test_upload_to_pypi():

    with open("semantic_release/tests/fixtures/sample_dist_package/twine_upload.log", "r") as f:
        sample_twine_upload = f.read()

    sample_glob_patterns = [
        "sphinxcontrib-apidoc-0.3.0-py3-none-any.whl",
        "sphinxcontrib-autoprogram-0.2.0-py3-none-any.whl"
    ]

    class run_mock:

        def __init__(self, to_be_run):
            self.to_be_run = to_be_run

        def __call__(self, *args, **kwargs):
            assert self.to_be_run in args
            self.to_be_run = ""
            return sample

# Generated at 2022-06-21 21:01:04.493484
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function ``upload_to_pypi``.
    """
    upload_to_pypi("test_dist_path")

# Generated at 2022-06-21 21:01:14.630458
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    import os
    import shutil

    def create_temp_dir():
        temp_dir = os.path.join(os.curdir, "test_temp")
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        os.mkdir(temp_dir)
        return temp_dir

    from invoke import mock
    import pytest

    temp_dir = create_temp_dir()
    os.mkdir(os.path.join(temp_dir, "dist"))

    test_valid_filename = "test-test-test-test"

    # No token or username/password
    with mock.patch.dict(
        os.environ, {"HOME": temp_dir}, clear=True
    ):

        with pytest.raises(ImproperConfigurationError):
            upload

# Generated at 2022-06-21 21:01:24.988507
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-aksdjaklsjd"
    os.environ["PYPI_USERNAME"] = "user"
    os.environ["PYPI_PASSWORD"] = "pass"

    os.environ["HOME"] = "home"
    os.environ["HOME"] = "home"
    path = "/path/to/wheels"

    upload_to_pypi(path)

# Generated at 2022-06-21 21:01:37.810528
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test to ensure that upload_to_pypi uses the correct values.

    This is not testing the return value, just that the correct call is made.
    For this reason, the function run is replaced by another function which
    records the arguments so they can be tested.
    """
    global run
    global arguments

    arguments = None

    def fake_run(to_run: str):
        """Tracks the arguments of the call to invoke.run
        """
        global arguments
        arguments = to_run

    run = fake_run

    upload_to_pypi()
    assert arguments == "twine upload  *"

    upload_to_pypi(path="my_path")
    assert arguments == 'twine upload  "my_path/*"'


# Generated at 2022-06-21 21:01:47.203077
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock, assert_called_once_with

    mocked_run = mock.patch("invoke.run").start()

    os.environ["PYPI_TOKEN"] = "pypi-1234567890"
    path = "dist"
    skip_existing = True
    glob_patterns = ["example-*.whl"]

    upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=glob_patterns)

    assert_called_once_with(
        mocked_run,
        "twine upload --skip-existing -u '__token__' -p 'pypi-1234567890' "
        '"dist/example-*.whl"',
    )

    del os.environ["PYPI_TOKEN"]


# Unit test

# Generated at 2022-06-21 21:01:57.509014
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Pass in empty string
    upload_to_pypi(glob_patterns=[""])
    # Pass in list with empty string
    upload_to_pypi(glob_patterns=[""])
    # Pass in random string
    upload_to_pypi(glob_patterns=["test"])
    # Pass in list with random string
    upload_to_pypi(glob_patterns=["test"])
    # Pass in list with empty string and random string
    upload_to_pypi(glob_patterns=["", "test"])
    # Pass in list with a few random strings
    upload_to_pypi(glob_patterns=["test1", "test2", "test3"])
    # Pass in a random string and a random string
    upload_

# Generated at 2022-06-21 21:01:58.513863
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # This function should not be tested
    pass

# Generated at 2022-06-21 21:01:59.883473
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:02:02.678173
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # TODO: Create unit tests for upload_to_pypi.
    #       The function is a pure wrapper of the `twine upload` command,
    #       so that function can be tested by running the actual command.
    pass

# Generated at 2022-06-21 21:02:04.024840
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Uploads to PyPI using the upload_to_pypi function."""
    assert True

# Generated at 2022-06-21 21:02:16.164022
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with (
        mock.patch("invoke.run")
    ) as mockrun, mock.patch("os.environ.get", autospec=True) as mockenv:
        mockenv.side_effect = lambda x: "mockenv" if x == "PYPI_TOKEN" else ""
        upload_to_pypi(
            path="mockpath", skip_existing=False, glob_patterns=["mockglob", "mockglob2"]
        )

        mockenv.assert_called_with("PYPI_TOKEN")
        mockrun.assert_called_with(
            'twine upload -u \'__token__\' -p \'mockenv\' "mockpath/mockglob" "mockpath/mockglob2"'
        )

# Generated at 2022-06-21 21:02:17.199711
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert None == upload_to_pypi()

# Generated at 2022-06-21 21:02:34.128576
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from unittest.mock import patch

    # Mock env variables
    for variable in ["HOME", "PYPI_USERNAME", "PYPI_PASSWORD", "PYPI_TOKEN"]:
        with patch.dict(
            "os.environ", {variable: None}, clear=True
        ), patch.object(
            run, "__call__"
        ) as mock_run:
            upload_to_pypi()

            mock_run.assert_called_with(
                "twine upload -u '' -p '' '' '' "
            )

    with patch.dict(
        "os.environ", {"PYPI_TOKEN": "pypi-testtoken"}, clear=True
    ), patch.object(
        run, "__call__"
    ) as mock_run:
        upload_

# Generated at 2022-06-21 21:02:35.673171
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:02:47.128534
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    output = upload_to_pypi(path="dist", skip_existing=False,
                            glob_patterns=['*'])
    assert output == f"twine upload  --skip-existing 'dist/*'"
    output = upload_to_pypi(path="dist", skip_existing=True,
                            glob_patterns=['*.whl'])
    assert output == f"twine upload  --skip-existing 'dist/*.whl'"
    output = upload_to_pypi(path="dist", skip_existing=True,
                            glob_patterns=['*.whl', '*'])
    assert output == f"twine upload  --skip-existing 'dist/*.whl' 'dist/*'"
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-21 21:02:54.765828
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ Test upload_to_pypi
    """
    from .helpers import invoke_mock
    from .helpers import set_mock_run
    import pytest

    run_mock = invoke_mock()
    set_mock_run(run_mock)
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()
    assert run_mock.called is False
    os.environ["PYPI_TOKEN"] = ""
    upload_to_pypi()
    assert run_mock.called is False

    os.environ["PYPI_TOKEN"] = "pypitoken"
    upload_to_pypi()
    assert run_mock.called is True


# Generated at 2022-06-21 21:02:57.627359
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("fakePath", skip_existing=True, glob_patterns=["dist/*"])

# Generated at 2022-06-21 21:02:58.345993
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:03:00.191322
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(skip_existing=True)

# Generated at 2022-06-21 21:03:02.128027
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='dist', skip_existing=False, glob_patterns=[])

# Generated at 2022-06-21 21:03:03.410771
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", glob_patterns=["*"])

# Generated at 2022-06-21 21:03:09.929044
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Get Config
    config_settings = config.get("config", "")
    config_settings.set("repository", "None")

    # Setup environment variables
    os.environ["PYPI_USERNAME"] = "example"
    os.environ["PYPI_PASSWORD"] = "example"

    # Define glob patterns
    glob_patterns = ["*"]

    try:
        upload_to_pypi("dist", glob_patterns=glob_patterns)
    except:
        pass

# Generated at 2022-06-21 21:03:35.291541
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    username, password, token = "user1", "Password1", "pypi-token"
    repository = "testrepository"

    path = "tests/test_files"

    run.return_value.return_code = 0 # pylint: disable=no-member
    # Test uploading with a username and password
    upload_to_pypi(path, skip_existing=True, glob_patterns=["*.txt"])
    run.assert_called_once_with(
        f"twine upload -u '{username}' -p '{password}' "
        f" --skip-existing '{path}/*.txt'"
    )
    # Reset run to start from a blank slate
    run.reset_mock()

    # Test uploading with an API token

# Generated at 2022-06-21 21:03:35.719797
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:03:43.992319
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from twine.commands import upload
    from .helpers import get_mock_version

    v = get_mock_version()
    upload = LoggedFunction(logger, upload)
    with v.env:
        v.assert_no_diff(
            upload_to_pypi(),
            upload(["dist/*"], repository_url="test"),
            cwd=".",
        )
        v.assert_no_diff(
            upload_to_pypi(repository="test"),
            upload(["dist/*"], repository_url="test"),
            cwd=".",
        )

# Generated at 2022-06-21 21:03:44.679066
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:03:46.718901
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path=".", glob_patterns=["*"], skip_existing=False)

# Generated at 2022-06-21 21:03:50.944472
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mocked_run

    mocked_run()
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        # This is the correct error
        pass
    else:
        # Else indicates that the error was not raised
        assert False

# Generated at 2022-06-21 21:03:52.119694
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()



# Generated at 2022-06-21 21:03:57.412894
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.hvcs import Commit
    from semantic_release.settings import config
    from semantic_release.errors import RemoteError

    from .pytest_helpers import get_mock_invoke, get_mock_repo
    from .fixtures import expected_files_dist
    from .assertions import assert_git_log, assert_git_checkout, assert_files_in_dir

    # Write .pypirc
    with open(".pypirc", "w") as f:
        f.write(
            "[distutils]\n"
            "[pypirc]\n"
            "pypi-test = True\n"
            "repository = https://test.pypi.org/legacy/"
            "\n"
        )

    # Clone mock repo

# Generated at 2022-06-21 21:03:57.934878
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()
    

# Generated at 2022-06-21 21:04:00.490745
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "izr6UZHa"
    upload_to_pypi()

# Generated at 2022-06-21 21:04:43.696123
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import mock_subprocess_check_output, mock_subprocess_Popen

    release_level = "major"
    package_name = "some-python-package"

    path = "path_to_dist"
    glob_patterns = ["*", "**/*", "**.whl", "*-*.whl"]
    skip_existing = True

    def mock_subprocess_Popen_wrapper(cmd, shell=True, env=None):
        assert cmd == f"twine upload -u '__token__' -p 'pypi-token' --skip-existing 'path_to_dist/*' 'path_to_dist/test.py'"
        return mock_subprocess_Popen
    mock_subprocess_Popen.wait = lambda: None


# Generated at 2022-06-21 21:04:53.494374
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Import here to keep tests from failing on import with missing environment variables
    from . import helpers
    from semantic_release.helpers import git
    from semantic_release.settings import config

    path = "dist"
    dist = "*.tar.gz *.whl"
    glob_patterns = dist.split(" ")
    skip_existing = True

    to_test = {}

    # Check if credentials are taken from token.
    token = "abcdef123456"
    to_test["token"] = token

    helpers.set_env("PYPI_TOKEN", token)
    upload_to_pypi(path, skip_existing, glob_patterns)


# Generated at 2022-06-21 21:04:55.461827
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:05:01.967209
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run("rm -rf dist/*.whl")
    run("python setup.py bdist_wheel --universal")
    config["repository"] = "test"
    config["repository_url"] = "http://localhost:8080"
    config["repository_name"] = "testrepo"
    config["repository_user"] = "testuser"
    upload_to_pypi()

# Generated at 2022-06-21 21:05:10.742665
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Since the upload command is third-party code, testing it isn't
    # straightforward. Just checking the arguments are passed correctly.
    from mock import patch
    from unittest.mock import Mock

    mock = Mock()
    with patch("invoke.run", new=mock):
        upload_to_pypi()
        mock.assert_called_with(
            "twine upload  --skip-existing 'dist/*'"
        )
        mock.reset_mock()

        upload_to_pypi(path="otherpath", skip_existing=True)
        mock.assert_called_with(
            "twine upload  --skip-existing 'otherpath/*'"
        )
        mock.reset_mock()


# Generated at 2022-06-21 21:05:21.157093
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-token"
    upload_to_pypi()
    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "username"
    os.environ["PYPI_PASSWORD"] = "password"
    upload_to_pypi()
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]
    print(upload_to_pypi())

# Generated at 2022-06-21 21:05:21.679429
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:05:26.380739
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Arrange
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    # Act
    upload_to_pypi(path, skip_existing, glob_patterns)
    # Assert
    assert True

# Generated at 2022-06-21 21:05:30.790844
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ Unit test for function upload_to_pypi
    """
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        assert True
    except Exception as e:
        assert False, f"Unexpected exception: {e}"
    else:
        assert False, "Did not detect expected exception"

# Generated at 2022-06-21 21:05:43.209071
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test with PYPI_TOKEN
    os.environ["PYPI_TOKEN"] = "pypi-12345678901234567890123456789012"
    upload_to_pypi()
    os.environ["PYPI_TOKEN"] = ""

    # Test with username and password
    os.environ["PYPI_USERNAME"] = "test_username"
    os.environ["PYPI_PASSWORD"] = "test_password"
    upload_to_pypi()
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""

    # Test with pypi repository
    config.set("repository", "test_repository")
    upload_to_pypi

# Generated at 2022-06-21 21:07:03.209274
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Testing for missing pypi token and username / password
    OsMock = Mock()
    OsMock.environ = {
        "PYPI_TOKEN": "",
        "PYPI_USERNAME": "",
        "PYPI_PASSWORD": "",
    }
    os.environ = OsMock.environ
    home_dir = "~"
    os.path.join(home_dir, ".pypirc")
    with pytest.raises(ImproperConfigurationError):
        upload_to_pypi()

    # Testing for an improperly formatted token (not starting with 'pypi-')
    skip_existing = True
    token = 'foo-bar'
    OsMock.environ = { "PYPI_TOKEN": token }
    os.environ = OsMock

# Generated at 2022-06-21 21:07:16.528117
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import logged_test_case
    from .helpers import mock_invoke
    from .helpers import TemporaryDirectory
    from .helpers import TemporaryHomeDirectory

    with logged_test_case(logger) as test_case:
        with mock_invoke(test_case) as invoke_mock:

            # If no token or username/password is provided,
            # an ImproperConfigurationError is raised
            with test_case.assertRaises(ImproperConfigurationError):
                upload_to_pypi(glob_patterns=["pattern"])

            # If the token begins with 'pypi',
            # the username is set to __token__ and the password is set to the token
            os.environ["PYPI_TOKEN"] = "pypi-token"

# Generated at 2022-06-21 21:07:18.963877
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi(skip_existing=False)
    assert upload_to_pypi(skip_existing=True)


# Generated at 2022-06-21 21:07:21.564434
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the upload_to_pypi function."""
    upload_to_pypi("dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:07:22.526118
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:07:23.896772
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("test_data/test_pkg/dist")

# Generated at 2022-06-21 21:07:34.366528
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Check failure when credentials are missing
    ImportError
    try:
        upload_to_pypi()
    except ImproperConfigurationError as err:
        assert err.message == "Missing credentials for uploading to PyPI"
    else:
        raise AssertionError

    # Check failure when token doesn't start with pypi-
    os.environ["PYPI_TOKEN"] = "foobar"
    try:
        upload_to_pypi()
    except ImproperConfigurationError as err:
        assert err.message == 'PyPI token should begin with "pypi-"'
    else:
        raise AssertionError
    del os.environ["PYPI_TOKEN"]

    # Verify that credentials and repository are passed to twine correctly
    os.environ["PYPI_USERNAME"] = "foo"

# Generated at 2022-06-21 21:07:43.766966
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        import twine
    except ImportError:
        raise SkipTest("twine is not installed")

    pkg = os.environ.get("PKG_NAME", "semantic_release")
    version = os.environ.get("PKG_VERSION", "0.12.0")
    twine_version = twine.__version__

    if twine_version > "1.12.0":
        upload = f"twine upload -r 'pypitest' -u '__token__' -p 'pypi-12345' './dist/{pkg}-{version}.tar.gz'"

# Generated at 2022-06-21 21:07:46.025272
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("tests", True, ["*"])

# Generated at 2022-06-21 21:07:47.908312
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi


upload_to_pypi.skip_existing = True