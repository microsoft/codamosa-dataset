

# Generated at 2022-06-21 21:00:02.982723
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from invoke import Context
    from .helpers import create_temporary_file

    with create_temporary_file() as f:
        c = Context(config={"run": {"echo": True}})
        upload_to_pypi(c, path=f.name, glob_patterns=["*"])

# Generated at 2022-06-21 21:00:07.372818
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mockrun(unused_param):
        return None
    old_run = run
    run = mockrun
    try:
        upload_to_pypi()
        upload_to_pypi(glob_patterns=["**/*"])
        upload_to_pypi(skip_existing=True)
        upload_to_pypi(glob_patterns=["**/*"], skip_existing=True)
    except Exception as e:
        print(e)
        assert False
    run = old_run

# Generated at 2022-06-21 21:00:09.300556
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi("dist", False, ["*"])

# Generated at 2022-06-21 21:00:13.438593
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="./test_dist")
    upload_to_pypi(path="./test_dist", skip_existing=True)
    upload_to_pypi(path="./test_dist", glob_patterns=["*.js"])

# Generated at 2022-06-21 21:00:22.520048
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi."""
    from .utils import FakeEnv, FakeRun

    upload_to_pypi_path = "dist"
    upload_to_pypi_skip_existing = False
    upload_to_pypi_glob_patterns = ["*"]
    token = os.environ["PYPI_TOKEN"]
    username = "__token__"
    password = os.environ["PYPI_TOKEN"]
    repository = "pypi"

    # Without credentials

# Generated at 2022-06-21 21:00:32.256853
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi.

    Test for function upload_to_pypi.
    """
    def _test():
        """_test function.
        """
        upload_to_pypi.logger = lambda _: None
        upload_to_pypi.logger.info = lambda _: None
        upload_to_pypi.logger.exception = lambda _: None

    env = {
        "PYPI_USERNAME": os.environ.get("PYPI_USERNAME"),
        "PYPI_PASSWORD": os.environ.get("PYPI_PASSWORD")
    }
    _test()
    run("python setup.py -q sdist bdist_wheel", env=env)
    upload_to_pypi("dist")
   

# Generated at 2022-06-21 21:00:36.069489
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    if os.environ.get("PYPI_TOKEN") == None:
        os.environ["PYPI_TOKEN"] = "test"

    upload_to_pypi()

    assert True

# Generated at 2022-06-21 21:00:37.832559
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:00:47.637217
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test to make sure Twine is called with correct parameters
    import mock
    with mock.patch("invoke.run") as mock_run:
        pypi_token = "pypi-abcdefg12345"
        pypi_username = "pyusername"
        pypi_password = "pypipassword"
        pypi_repository = "pypi_repository"
        dist = "dist"
        glob_patterns = ["*.whl"]
        # Test with PYPI_TOKEN
        upload_to_pypi(path=dist, glob_patterns=glob_patterns)

# Generated at 2022-06-21 21:00:56.639598
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    from .helpers import FunctionLogger
    import logging
    import os

    import pytest

    from ..version import get_next_version

    from semantic_release.settings import _set_config, load_config
    from semantic_release.settings import load_config_from_file, load_config_from_module

    # Restore default configuration
    _set_config(load_config())

    # Prepare logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Prepare environment

# Generated at 2022-06-21 21:01:05.607566
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:01:07.532567
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # WIP: TODO
    raise NotImplementedError()

# Generated at 2022-06-21 21:01:08.664117
# Unit test for function upload_to_pypi

# Generated at 2022-06-21 21:01:10.508204
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    run("python setup.py bdist_wheel")
    upload_to_pypi("dist", True)

# Generated at 2022-06-21 21:01:10.984559
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:01:19.145792
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Arrange
    username = "username"
    password = "password"
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"] = password

    # Act
    upload_to_pypi()

    # Assert
    assert run.called
    assert f'-u "{username}" -p "{password}"' in run.calls[0].args[0]



# Generated at 2022-06-21 21:01:20.248055
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:01:20.667200
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True

# Generated at 2022-06-21 21:01:25.325444
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Test for proper config
    os.environ["PYPI_USERNAME"] = "my_user"
    os.environ["PYPI_PASSWORD"] = "my_password"

    upload_to_pypi()

    # Test for improper config
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""

    try:
        upload_to_pypi()
        assert False
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-21 21:01:35.913331
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Args
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    
    # Mock
    run = Mock()

    # Run
    upload_to_pypi(path, skip_existing, glob_patterns)

    # Tests
    assert run.called
    assert len(run.call_args) == 2
    assert len(run.call_args[0]) == 1
    assert run.call_args[0][0] == f'twine upload -u \'__token__\' -p \'pypi-x\' "dist/*"'
    assert len(run.call_args[1]) == 0

# Generated at 2022-06-21 21:01:50.395899
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from semantic_release.__main__ import main
    from semantic_release.hvcs.git import Git
    from semantic_release.hvcs.gitlab import GitlabRepository
    from semantic_release.settings import Config
    from semantic_release.cli import parse_args
    from semantic_release.changelog import get_changelog_writer
    from semantic_release.version_compare import _compare_versions
    import os

    def mock_get_default_remote_url(*args, **kwargs):
        return "git@gitlab.com:sergiu-baluta/semantic-release-example.git"

    def mock_run_git_cmd(*args, **kwargs):
        return "2.1.3"


# Generated at 2022-06-21 21:01:52.934632
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi functionality."""
    upload_to_pypi(path="dist", skip_existing=True, glob_patterns=["*"])

# Generated at 2022-06-21 21:02:02.867986
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    repository = os.environ.get("TEST_PYPI_REPOSITORY")
    pypi_username = os.environ.get("TEST_PYPI_USERNAME")
    pypi_password = os.environ.get("TEST_PYPI_PASSWORD")
    skip_pypi_tests = os.environ.get("TEST_SKIP_PYPI")
    if repository and pypi_username and pypi_password:
        upload_to_pypi(
            path="temp_dist",
            skip_existing=False,
            glob_patterns=["*"],
        )
    elif not skip_pypi_tests:
        import pytest
        pytest.fail("Missing test pypi variables")
    else:
        import pytest
       

# Generated at 2022-06-21 21:02:16.269440
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test the basic upload_to_pypi function works.

    This does not actually upload any files, but that is covered by another unit test.
    """
    from .helpers import MockRun

    with MockRun(should_raise=False) as mr:
        # Raise an error if we're missing credentials.
        upload_to_pypi()

    assert mr.error_msg == "Missing credentials for uploading to PyPI", "Incorrect error message"
    assert mr.command is None, "A command should not have been run"

    # It should be okay if the PYPI_TOKEN is present.
    with MockRun(should_raise=False) as mr:
        os.environ["PYPI_TOKEN"] = "pypi-token"

# Generated at 2022-06-21 21:02:25.243505
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    from .helpers import MockedLogger
    from .helpers import MockedRun
    from .helpers import MockedEnviron

    # Mock logger
    logger.name = "Mocked"

    # Mock environment variables
    os.environ["PYPI_TOKEN"] = "pypi-token"
    os.environ["PYPI_USERNAME"] = "pypi-username"
    os.environ["PYPI_PASSWORD"] = "pypi-password"
    os.environ["HOME"] = "/home/dir"
    os.environ["PYPI_REPOSITORY"] = "pypi-repo"

    # Mock open paths
    fileMock = MockedRun()

# Generated at 2022-06-21 21:02:27.777994
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path='distrib', username='dummy', password='dummy', skip_existing=False, glob_patterns=['*.whl'])

# Generated at 2022-06-21 21:02:35.404390
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Mock methods
    os.environ["PYPI_TOKEN"] = "pypi-1234"
    config.set("repository", "test")

    run = lambda cmd: None

    upload_to_pypi(run=run)

    # Mock methods
    run = lambda cmd: None

    upload_to_pypi(run=run, skip_existing=True)

    # Mock methods
    run = lambda cmd: None

    upload_to_pypi(
        run=run, path="dist", glob_patterns=["*", "test.txt"], skip_existing=True
    )

    # Invalid token
    run = lambda cmd: None
    os.environ["PYPI_TOKEN"] = "pypi"

# Generated at 2022-06-21 21:02:47.080396
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    os.environ["PYPI_TOKEN"] = "pypi-foo"
    assert upload_to_pypi() == 0
    del os.environ["PYPI_TOKEN"]
    os.environ["PYPI_USERNAME"] = "foo"
    os.environ["PYPI_PASSWORD"] = "bar"
    assert upload_to_pypi() == 0
    del os.environ["PYPI_USERNAME"]
    del os.environ["PYPI_PASSWORD"]

    assert upload_to_pypi() > 0
    os.environ["PYPI_USERNAME"] = "foo"
    assert upload_to_pypi() > 0
    os.environ["PYPI_PASSWORD"] = "bar"
    assert upload_to

# Generated at 2022-06-21 21:02:48.256658
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    raise NotImplementedError

# Generated at 2022-06-21 21:02:52.658227
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    test_upload_to_pypi.called = False
    def mock_run(cmd):
        if cmd == 'twine upload  "dist/*"':
            test_upload_to_pypi.called = True
    try:
        old_run = run
        run = mock_run
        upload_to_pypi()
    finally:
        run = old_run
    assert test_upload_to_pypi.called

# Generated at 2022-06-21 21:03:13.546639
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def mock_run(command):
        assert command == 'twine upload -u "__token__" -p "pypi-abc123" --skip-existing "dist/foo" "dist/bar"'

    original_run = run
    run = mock_run
    try:
        upload_to_pypi(
            path="dist",
            skip_existing=True,
            glob_patterns=["foo", "bar"],
        )
    finally:
        run = original_run

# Generated at 2022-06-21 21:03:25.052831
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test for function upload_to_pypi.
    """
    assert os.getenv('TWINE_USERNAME') == "TWINE_USERNAME"
    assert os.getenv('TWINE_PASSWORD') == "TWINE_PASSWORD"
    assert os.getenv('PYPI_TOKEN') == "PYPI_TOKEN"
    assert os.getenv('PYPI_USERNAME') == "PYPI_USERNAME"
    assert os.getenv('PYPI_PASSWORD') == "PYPI_PASSWORD"

    run("python -m venv env")
    run("source env/bin/activate && pip install invoke")

    upload_to_pypi(path="dist", skip_existing=False, glob_patterns=["*"])

# Generated at 2022-06-21 21:03:27.155330
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """ Upload to pypi test 3

    :return:result
    """
    result = upload_to_pypi()
    #assert result ==

# Generated at 2022-06-21 21:03:34.183603
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    config.update(dict(repository="pypi_repo"))
    
    env = {
        "PYPI_USERNAME": "my_username",
        "PYPI_PASSWORD": "my_passwd",
    }

    with test.mock.patch("invoke.run", return_value="") as mocked_run:
        upload_to_pypi(
            path="dist",
            skip_existing=True,
            glob_patterns=["*"],
        )
        mocked_run.assert_called_once_with("""twine upload -u 'my_username' -p 'my_passwd' -r 'pypi_repo' --skip-existing 'dist/*'""")

# Generated at 2022-06-21 21:03:38.645688
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pypi_token = os.environ.get('PYPI_TOKEN', None)
    os.environ.pop('PYPI_TOKEN', None)

    error_raised = False
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        error_raised = True

    if pypi_token:
        os.environ['PYPI_TOKEN'] = pypi_token

    assert error_raised

# Generated at 2022-06-21 21:03:39.539558
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
  # ToDo: implement
  pass

# Generated at 2022-06-21 21:03:46.603072
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Create a function object for testing purpose
    test_upload_to_pypi = upload_to_pypi
    # Test 1: If the PYPI_TOKEN value is not defined in environment 
    # then ImproperConfigurationError should be raised
    try:
        # Set environment variable of PYPI_TOKEN to None (clears the environment variable)
        os.environ["PYPI_TOKEN"] = None
        # Test the upload_to_pypi method 
        test_upload_to_pypi("dist")
    except ImproperConfigurationError as e:
        # A correct output should show that the environment variable PYPI_TOKEN is missing
        assert e.args[0] == "Missing credentials for uploading to PyPI"
    # Test 2: If the PYPI_TOKEN value is not starting with '

# Generated at 2022-06-21 21:03:54.019076
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    mock_run = lambda cmd: True
    path = "my_dir"
    glob_patterns = ["*.whl"]

    upload_to_pypi(path, glob_patterns=glob_patterns, run=mock_run)
    expected_command = f"twine upload -u '__token__' -p 'pypi-token' \"my_dir/{glob_patterns[0].strip()}\""
    assert mock_run.call_args.args[0] == expected_command

# Generated at 2022-06-21 21:03:59.767620
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    expected_output = (
        "twine upload -u '__token__' -p 'pypi-token' --skip-existing foo/bar.whl"
    )

    output = upload_to_pypi(skip_existing=True, glob_patterns=["foo/bar.whl"])

    assert output == expected_output

# Generated at 2022-06-21 21:04:01.164011
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert upload_to_pypi() == None


# Generated at 2022-06-21 21:04:49.301618
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    def fake_run(command):
        assert command == 'twine upload -u usr -p pwd -r test_repository --skip-existing "dist/glob1" "dist/glob2"'

    glob_patterns = ["glob1", "glob2"]

    path = "dist"
    skip_existing = True
    username = "usr"
    password = "pwd"
    repository = "test_repository"

    config.set("repository", repository)
    os.environ["PYPI_USERNAME"] = username
    os.environ["PYPI_PASSWORD"] = password
    run.side_effect = fake_run

    upload_to_pypi(
        path, skip_existing=skip_existing, glob_patterns=glob_patterns
    )



# Generated at 2022-06-21 21:04:50.592884
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    assert True == upload_to_pypi.__wrapped__()

# Generated at 2022-06-21 21:05:05.401933
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    with open('./setup.py', 'r') as f:
        lines = f.readlines()
        f.close()
    with open('./setup.py', 'w') as f:
        for line in lines:
            f.write(line.replace('upload_to_pypi', '#upload_to_pypi'))
        f.close()
    from .helpers import LoggedFunction
    from .helpers import LoggedFunction
    from .helpers import LoggedFunction
    from invoke import run
    from .helpers import LoggedFunction
    from semantic_release.settings import config
    from .helpers import LoggedFunction
    from semantic_release import ImproperConfigurationError
    import os
    import os
    import os
    import os

    path = "dist"

    skip_existing = False


# Generated at 2022-06-21 21:05:11.423989
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # Import after the setting of the config so that the config is not overwritten
    # with the test config
    import semantic_release.settings as settings

    # Given
    os.environ["PYPI_USER"] = ""
    os.environ["PYPI_PW"] = ""
    os.environ["PYPI_REPOSITORY"] = ""

    # When
    upload_to_pypi()

    # Then
    assert settings.config["pypi"]["username"] == ""
    assert settings.config["pypi"]["password"] == ""
    assert settings.config["pypi"]["repository"] == ""

# Generated at 2022-06-21 21:05:24.327565
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi.
    """
    token = "pypi-123456789ABCDEF"
    username = "foo"
    password = "bar"
    repository = "foobar"
    path = "dist"
    skip_existing = True
    glob_pattern = "*.zip"
    
    run_patch = mock.patch("invoke.run")

    with mock.patch.dict("os.environ", {"PYPI_TOKEN": token}), run_patch as run:
        upload_to_pypi(path=path, skip_existing=skip_existing, glob_patterns=[glob_pattern])

# Generated at 2022-06-21 21:05:25.120326
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    pass

# Generated at 2022-06-21 21:05:33.454544
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Unit test for function upload_to_pypi"""
    class FakeRun:
        """Fake for run"""
        def __init__(self):
            # pylint: disable=invalid-name
            """Init for class FakeRun"""
            self.calls = []

        def __call__(self, command):
            """Call for class FakeRun"""
            self.calls.append(command)

    fake_run = FakeRun()
    glob_patterns = ["*.tar.gz"]

    upload_to_pypi(glob_patterns=glob_patterns)
    assert fake_run.calls[0] == "twine upload  '*.tar.gz'"

    upload_to_pypi(glob_patterns=glob_patterns, skip_existing=True)
    assert fake_run

# Generated at 2022-06-21 21:05:37.472413
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi(path="dist", glob_patterns=["*.whl"])
    upload_to_pypi(
        path="dist", skip_existing=True, glob_patterns=["*.whl"]
    )

# Generated at 2022-06-21 21:05:38.568557
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi()

# Generated at 2022-06-21 21:05:47.009150
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """test upload_to_pypi function"""

    # import invoke
    import invoke
    import pytest
    from mock import patch, Mock, call

    monkeypatch = patch.multiple(
        "semantic_release_monorepo.twine",
        run=Mock(return_value=None),
        logger=Mock(),
    )
    monkeypatch.start()


# Generated at 2022-06-21 21:07:01.733439
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # The file twine_upload.py is verified below to make sure it is uploaded properly
    # to the correct server. The credentials to the test server are specified in
    # the environment variables PYPI_USERNAME, PYPI_PASSWORD and PYPI_REPOSITORY for
    # a test server and the file .pypirc should not be present in the HOME directory
    os.environ["PYPI_USERNAME"] = "twine_upload"
    os.environ["PYPI_PASSWORD"] = "twine_upload"
    os.environ["PYPI_REPOSITORY"] = "https://test.pypi.org/legacy/"
    upload_to_pypi()

    # Use a repo specified by the variable repository in the settings
    # The variable repository in the current config file is set

# Generated at 2022-06-21 21:07:02.320894
# Unit test for function upload_to_pypi

# Generated at 2022-06-21 21:07:08.497097
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    Unit tests that the upload_to_pypi function behaves as expected
    """
    import invoke
    import mock
    from invoke.exceptions import Exit
    from mock import patch

    from .helpers import LoggedFunction
    from .test_releaser import update_version

    # Create a versioned file and version bump it
    with patch("builtins.input", return_value="minor"):
        update_version("minor")
    from .test_releaser import version

    # Prepare a mock twine upload call
    original_run = invoke.run
    mock_run = mock.MagicMock()
    invoke.run = mock_run

    # Call upload_to_pypi with a mock twine command
    upload_to_pypi(glob_patterns=["*"])
    mock_run

# Generated at 2022-06-21 21:07:20.986920
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # test for username and password
    os.environ["PYPI_TOKEN"] = ""
    os.environ["PYPI_USERNAME"] = "test_user"
    os.environ["PYPI_PASSWORD"] = "test_password"
    upload_to_pypi()

    # test for token
    os.environ["PYPI_TOKEN"] = "pypi-token"
    os.environ["PYPI_USERNAME"] = ""
    os.environ["PYPI_PASSWORD"] = ""
    upload_to_pypi()

    # test for missing credentials
    os.environ.pop("PYPI_TOKEN")
    os.environ.pop("PYPI_USERNAME")

# Generated at 2022-06-21 21:07:29.440408
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    try:
        # Simulate missing credentials
        del os.environ["PYPI_TOKEN"]
        del os.environ["PYPI_USERNAME"]
        del os.environ["PYPI_PASSWORD"]
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        assert False
    os.environ["PYPI_TOKEN"] = "pypi-abc123"
    upload_to_pypi()
    os.environ["PYPI_TOKEN"] = "abc123"
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        pass
    else:
        assert False

# Generated at 2022-06-21 21:07:37.318808
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    # given
    path = "dist"
    skip_existing = False
    glob_patterns = ["*"]
    username = "test_user"
    password = "test_password"

    # when
    upload_to_pypi(path, skip_existing, glob_patterns)

    # and
    os.environ['PYPI_USERNAME'] = username
    os.environ['PYPI_PASSWORD'] = password
    upload_to_pypi(path, skip_existing, glob_patterns)

    # then
    assert True == True

# Generated at 2022-06-21 21:07:40.892221
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """
    This unittest checks that the upload to pypi function raises an Exception when there are no credentials.
    :return:
    """
    try:
        upload_to_pypi()
    except ImproperConfigurationError:
        return
    raise Exception("Exception should have been raised")

# Generated at 2022-06-21 21:07:42.901531
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    upload_to_pypi('dist', skip_existing=False, glob_patterns=['somename.whl'])


# Generated at 2022-06-21 21:07:47.377052
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    token = os.environ.get("PYPI_TOKEN")
    username = os.environ.get("PYPI_USERNAME")
    password = os.environ.get("PYPI_PASSWORD")
    home_dir = os.environ.get("HOME", "")
    if not (username or password) and (
        not home_dir or not os.path.isfile(os.path.join(home_dir, ".pypirc"))
    ):
        raise ImproperConfigurationError("Missing credentials for uploading to PyPI")
    else:
        upload_to_pypi()

# Generated at 2022-06-21 21:07:49.177129
# Unit test for function upload_to_pypi
def test_upload_to_pypi():
    """Test upload_to_pypi function."""

    upload_to_pypi()