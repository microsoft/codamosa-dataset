

# Generated at 2022-06-23 14:59:03.491535
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import copy
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.vars import HostVarsVars
    from ansible.vars.manager import VariableManager

    # Override _find_host method to be able to provide its own
    # value for variable "group_names"
    class MyHostVars(HostVars):
        def _find_host(self, host_name):
            return self._inventory.get_host(host_name)

        def set_host_variable(self, host, varname, value):
            self._variable_manager.set_host_variable(host, varname, value)

    inventory = MyInventory()
    # set "group_names" variable to be able to compare it later

# Generated at 2022-06-23 14:59:14.842002
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible import inventory
    from ansible import variables
    from ansible.vars import VariableManager
    from ansible.parsing import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

    host_name = "test-host"
    varname = "test_var"
    varvalue = "test_value"
    varmanager = VariableManager()
    hostvars = HostVars(inventory.Inventory(host_list=[host_name]), varmanager, DataLoader())
    hostvars.set_host_variable(inventory.Host(host_name), varname, varvalue)
    result = hostvars.raw_get(host_name)

    assert result is not None
    assert result[varname] == varvalue

# Unit test

# Generated at 2022-06-23 14:59:20.459963
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    class VM(object):
        def __init__(self):
            self._hostvars = None

    vm = VM()
    hv = HostVars({}, vm, None)
    vm._hostvars = None
    hv.set_variable_manager(vm)
    assert(vm._hostvars is hv)

    vm._hostvars = 'foo'
    hv.set_variable_manager(vm)
    assert(vm._hostvars is 'foo')

# Generated at 2022-06-23 14:59:26.650571
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    for host in hostvars:
        assert host == 'localhost'

# Generated at 2022-06-23 14:59:29.345593
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({'a': 1, 'b': 2}, None)
    for key in hvv:
        assert key in ('a', 'b')

# Generated at 2022-06-23 14:59:39.243407
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class DummyVarsManager(VariableManager):
        def __init__(self, loader, inventory, cache=None):
            super(DummyVarsManager, self).__init__(loader, inventory)
            self._vars_cache = cache or dict()
        def get_vars(self, loader, path, entities):
            return self._vars_cache

    class DummyInventory(InventoryManager):
        def __init__(self, loader, variable_manager):
            super(DummyInventory, self).__init__(loader, variable_manager)


# Generated at 2022-06-23 14:59:45.933826
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import variable_manager_loader
    loader = DataLoader()
    variable_manager = variable_manager_loader.get('persistent_variable_manager', loader=loader, play=None)
    inventory = InventoryManager(loader, variable_manager)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_inventory(None)
    assert hostvars._inventory == None

# Generated at 2022-06-23 14:59:57.284704
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader)
    variable_manager = VariableManager(loader=loader)

    # Create new HostVars object by calling constructor
    hostvars1 = HostVars(inventory, variable_manager, loader)
    # Check that _variable_manager attribute of newly created HostVars object is
    # the same as passed variable_manager
    assert hostvars1._variable_manager.__dict__ is variable_manager.__dict__
    # Check that _hostvars attribute of passed variable_manager is the same as newly created HostVars object
    assert hostvars1.__dict__ is variable_manager._hostvars.__dict__

    #

# Generated at 2022-06-23 15:00:08.746579
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Tests for issue https://github.com/ansible/ansible/issues/13645
    hvv = HostVarsVars({'x': '{{y}}', 'y': 'z'}, None)
    assert hvv['x'] == 'z'
    hvv = HostVarsVars({'x': '{{y|d()}}', 'y': 'z'}, None)
    assert hvv['x'] == 'z'
    hvv = HostVarsVars({'x': '{{y|d("")}}', 'y': 'z'}, None)
    assert hvv['x'] == 'z'
    hvv = HostVarsVars({'x': '{{y|d("", True)}}', 'y': 'z'}, None)
    assert hvv['x'] == 'z'

# Unit test

# Generated at 2022-06-23 15:00:14.810083
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    hostvars_state = pickle.dumps(hostvars)
    hostvars = pickle.loads(hostvars_state)

    assert hostvars._loader is not None
    assert hostvars._variable_manager._loader is not None
    assert hostvars._variable_manager._hostvars is not None

# Generated at 2022-06-23 15:00:25.748949
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    inventory = InventoryManager(loader=loader, sources='')
    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')
    hostvars.set_host_facts(host, dict(foo='bar'))

    # Verify that variable is set
    assert 'foo' in variable_manager._fact_cache[host]
    # Verify that variable is exposed in hostvars
    assert 'foo' in hostvars.get(host)



# Generated at 2022-06-23 15:00:27.518923
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    data = {'foo': 'bar'}
    hvv = HostVarsVars(data, loader=None)
    assert len(data) == len(hvv)

# Generated at 2022-06-23 15:00:37.603889
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    """ HostVars.__setstate__ restores _loader and _hostvars attributes of VariableManager """

    # Mock the dependencies needed by HostVars
    mock_inventory = type('MockInventory', (object,), {})()
    mock_variable_manager = type('MockVariableManager', (object,), {})()
    mock_loader = type('MockLoader', (object,), {})()

    expected_loader = mock_loader
    expected_hostvars = HostVars(mock_inventory, mock_variable_manager, mock_loader)

    # Build a pickled HostVars object using __getstate__ method
    hostvars = HostVars(mock_inventory, mock_variable_manager, mock_loader)

    state = hostvars.__getstate__()

    # Create a fresh object and set its attributes using __

# Generated at 2022-06-23 15:00:47.546828
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert isinstance(hostvars, Mapping)
    assert hostvars
    assert len(hostvars) == 1
    assert list(hostvars) == ['localhost']
    # Make sure that HostVars works with inventory.get_host
    assert hostvars['localhost'] is hostvars['localhost']
    # Make sure that HostVars works with inventory.find_host
    assert hostvars['localhost'] is hostvars['localhost']


# Generated at 2022-06-23 15:00:57.784629
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name

    import unittest
    import copy

    import ansible.inventory
    import ansible.playbook
    import ansible.vars.manager
    import ansible.vars.hostvars

    class TestHostVars(unittest.TestCase):

        def setUp(self):
            self.hostvars = ansible.vars.hostvars.HostVars(
                ansible.inventory.Inventory(''),
                ansible.vars.manager.VariableManager(),
                ansible.playbook.Playbook.load('').get_loader())

        def test_set_host_facts(self):
            host = ansible.inventory.Host('localhost')
            self.hostvars.set_

# Generated at 2022-06-23 15:00:59.160997
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    assert len(HostVars({}, None, None)) == 0

# Generated at 2022-06-23 15:01:07.131835
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host
    from ansible.inventory.group import Group
    #import pytest

    hosts = [
        'example1',
        'example2'
    ]
    variables = {
        'foo': 'boo'
    }
    loader = DataLoader()
    inventory = Inventory(loader, VariableManager())
    for host in hosts:
        inventory.add_host(host, 'all')
    for host in inventory.hosts:
        host.set_variable('foo', 'boo')
    hostvars = HostVars(inventory, VariableManager(loader=loader, variables=variables), loader)

    #assert hostvars.__iter__() == inventory.hosts
   

# Generated at 2022-06-23 15:01:14.324007
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    inventory._set_variable_manager(variable_manager)

    hostvars = HostVars(inventory, variable_manager, loader)
    localhost = inventory.get_host('localhost')

    # Test variable with sensitive value
    variable_manager.set_nonpersistent_facts(localhost, {'foo': {'bar': 'baz'}})
    # Test variable with non-sensitive value

# Generated at 2022-06-23 15:01:25.242320
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # data to construct an instance of a class VariableManager
    vm_data = dict(
        start_at_task=None,
    )

    # data to construct an instance of a class Inventory
    inventory = dict(
        hosts=[],
        groups={},
        _hosts_cache={},
        _pattern_cache={},
        _vars_per_host={},
        _vars_per_group={},
    )

    # data to construct an instance of a class Host
    h_data = dict(
        name="test-host",
        port=22,
        _variables={},
        groups=[],
        _groups_composed_of=set(),
        _in_inventory=True,
        _variable_manager=None
    )

    # construct an instance of VariableManager    

# Generated at 2022-06-23 15:01:33.737959
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader)
    host = inventory.get_host('test_01')
    hostvars.set_nonpersistent_facts(host, dict(foo='test'))
    assert host.get_facts() == dict(foo='test')

# Generated at 2022-06-23 15:01:42.596940
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import OrderedDict

    loader = DataLoader()
    inventory = InventoryManager(loader, hosts='localhost')
    variable_manager = VariableManager(loader, inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    variable_manager.set_nonpersistent_facts({'a': 'b'})
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'ansible_python_interpreter', '/usr/bin/python3')
    variable_manager.set_host_variable(inventory.get_host('localhost'), 's', 'c')
   

# Generated at 2022-06-23 15:01:54.480252
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    # fake inventory
    inv = dict(hosts=['host1', 'host2'])
    # fake variables
    vars1 = {'a': 'b'}
    vars2 = {'c': 'd'}
    # mocking
    inventory = InventoryManager(loader=None, sources=inv)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.set_host_variable('host1', 'vars', vars1)
    variable_manager.set_host_variable('host2', 'vars', vars2)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    # final check

# Generated at 2022-06-23 15:02:03.105116
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars import VariableManager
    from ansible.inventory import Host

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(Host('host1'), {'host1_fact1': 'host1_value1'})
    variable_manager.set_nonpersistent_facts(None, {'localhost_fact1': 'localhost_value1'})

    assert variable_manager._nonpersistent_facts[Host('host1')]['host1_fact1'] == 'host1_value1'
    assert variable_manager._nonpersistent_facts[None]['localhost_fact1'] == 'localhost_value1'

# Generated at 2022-06-23 15:02:10.257371
# Unit test for constructor of class HostVars
def test_HostVars():
    inventory = dict()
    variable_manager = dict()
    loader = dict()

    hostvars = HostVars(inventory, variable_manager, loader)

    assert type(hostvars._inventory) is dict
    assert type(hostvars._variable_manager) is dict
    assert type(hostvars._loader) is dict

    assert type(hostvars) is HostVars

# Generated at 2022-06-23 15:02:21.660886
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    # Create inventory and variable manager
    loader = DataLoader()
    inventory = InventoryManager(loader, '/path/to/inventories/')
    variable_manager = VariableManager()

    # Create HostVars instance
    hostvars = HostVars(inventory, variable_manager, loader)

    # Set new variable manager and test attribute _hostvars
    new_variable_manager = VariableManager()
    hostvars.set_variable_manager(new_variable_manager)
    assert new_variable_manager._hostvars == hostvars
    assert new_variable_manager._hostvars is not variable_manager._hostv

# Generated at 2022-06-23 15:02:34.328616
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    class InventoryMock:
        def get_host(self, host_name):
            if host_name == 'host1':
                return HostMock1()
            elif host_name == 'host2':
                return HostMock2()
            else:
                return None

    class HostMock1:
        name = 'host1'

    class HostMock2:
        name = 'host2'

    class VariableManagerMock:
        def set_host_variable(self, host, varname, value):
            if host.name == 'host1':
                HostMock1.vars = {varname: value}
            elif host.name == 'host2':
                HostMock2.vars = {varname: value}
            else:
                assert False


# Generated at 2022-06-23 15:02:39.597210
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    h1 = HostVarsVars({'foo': 'bar'}, loader=None)
    assert len(h1) == 1

    h2 = HostVarsVars({'foo': 'bar', 'bar': 'baz'}, loader=None)
    assert len(h2) == 2

    h3 = HostVarsVars({}, loader=None)
    assert len(h3) == 0

# Generated at 2022-06-23 15:02:44.764693
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    import pytest
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    hv = HostVars(InventoryManager(inventory='localhost,'), VariableManager(), None)
    hv.set_host_variable(None, 'foo', 'bar')
    assert len(hv) == 1

# Generated at 2022-06-23 15:02:48.960818
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    inventory = MagicMock()
    inventory.get_host.return_value = None
    variable_manager = MagicMock()
    loader = MagicMock()

    hostvars = HostVars(inventory, variable_manager, loader)

    assert 'test_host' not in hostvars



# Generated at 2022-06-23 15:02:59.281472
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, None)

    host = inventory.get_host('localhost')
    assert hostvars.set_host_variable(host, 'foo', 'bar') == 'bar'
    assert hostvars['localhost']['foo'] == 'bar'

    # Try to set a nested var
    hostvars.set_host_variable(host, 'baz.foo', 'bar')
    assert hostvars['localhost']['baz']['foo'] == 'bar'

    # Set var again, this time with different value
    host

# Generated at 2022-06-23 15:03:05.836203
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    hostvars = HostVars(Inventory(), VariableManager(), None)
    hostvars_item = hostvars['localhost']
    assert isinstance(hostvars_item, HostVarsVars)
    assert hostvars_item.hostvars is hostvars


# Generated at 2022-06-23 15:03:13.769769
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = '''
    [group1]
    host1
    host2

    [group2]
    host3
    '''

    inventory_obj = loader.load(inventory)
    hv = HostVars(inventory_obj, None, loader)
    assert "host1" in hv

    # Note: dynamic inventory plugin is not used here

    # Change inventory.
    # Set _hosts attribute of inventory_obj to None so that all hosts
    # will be re-fetched from underlying inventory plugin.
    inventory_obj._hosts = None
    inventory = '''
    [group1]
    host1
    host2

    [group3]
    host4
    '''

# Generated at 2022-06-23 15:03:24.898848
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context

    play_context = context.CLIArgs()
    inventory = InventoryManager(loader=play_context.loader, sources=play_context.inventory)

    hostvars = HostVars(inventory, VariableManager(), play_context.loader)

    host = Host(name='localhost')
    hostvars.set_host_facts(host, {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'})

# Generated at 2022-06-23 15:03:36.210202
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    hv = HostVars(FakeInventory(), FakeVariableManager(), FakeLoader())
    hv.set_host_variable(host=None, varname='name', value='Joe')
    assert hv['localhost']['name'] == 'Joe'

    hv_state = hv.__getstate__()
    assert '_loader' in hv_state
    assert '_hostvars' in hv_state
    assert '_variable_manager' in hv_state
    assert hv_state['_loader'] == FakeLoader()
    assert hv_state['_hostvars'] is hv
    assert isinstance(hv_state['_variable_manager'], VariableManager)

    hv_new = HostVars(FakeInventory(), FakeVariableManager(), FakeLoader())


# Generated at 2022-06-23 15:03:40.892592
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    hostvars = HostVars({}, {}, {})
    hostvars['all'] = 'all'
    hostvars.set_host_variable({'name': 'all'}, 'new', 'variable')
    assert hostvars['all']['new'] == 'variable'
    assert hostvars['all']['new'] != hostvars['all']['new']

# Generated at 2022-06-23 15:03:50.606440
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Test function HostVars.__getitem__()
    '''

    # Test usage of __getitem__ on an undefined host
    try:
        # Instantiate a HostVars object and try to access an undefined host
        hv = HostVars({}, {}, {})
        var = hv.__getitem__('undefined_host')
    except KeyError:
        # KeyError exception is expected
        pass
    else:
        # KeyError exception is expected, but not raised
        raise AssertionError('HostVars object does not raise KeyError exception on undefined host')

    return None

# Generated at 2022-06-23 15:04:00.069188
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy

    # Create the objects to be deep-copied
    inventory = create_inventory_object()
    loader = create_loader_object()
    variable_manager = create_variable_manager_object(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create dict with HostVars inside
    foo = {}
    foo['bar'] = hostvars

    # Deepcopy and check that deepcopy(HostVars) is HostVars
    baz = deepcopy(foo)
    assert baz == foo
    assert baz['bar'] is hostvars



# Generated at 2022-06-23 15:04:03.285960
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = DummyLoader()
    data = dict(x=1, y=2, z=3)
    for key in HostVarsVars(data, loader):
        assert key in data

# Generated at 2022-06-23 15:04:13.041478
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from collections import namedtuple

    # Create a mock inventory
    class MockInventory:
        def __init__(self, hosts):
            self.hosts = hosts

        def get_host(self, host):
            for h in self.hosts:
                if host == h.name:
                    return h
            return None

    MockHost = namedtuple('MockHost', ['name', 'vars'])
    h1 = MockHost('first_host', {'a': 'b'})
    h2 = MockHost('second_host', {'a': 'B'})
    inventory = MockInventory([h1, h2])

    # Create a mock VariableManager
    class MockVariableManager:
        def __init__(self, vars):
            self.vars = vars


# Generated at 2022-06-23 15:04:15.936280
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    assert HostVars(Inventory(),
                    VariableManager(),
                    None).__iter__() is None

# Generated at 2022-06-23 15:04:23.974842
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    inventory.clear_pattern_cache()
    inventory.add_host(host='foo')
    inventory.add_host(host='bar')


# Generated at 2022-06-23 15:04:29.200444
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class FakeLoader:
        def get_basedir(self):
            return "/some/test/dir"

    hostvars = HostVarsVars({'foo': 'hello', 'bar': 'world'}, FakeLoader())
    assert repr(hostvars) == "{'foo': 'hello', 'bar': 'world'}"

# Generated at 2022-06-23 15:04:38.559469
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=None)
    var_mgr = VariableManager(loader=loader, inventory=inv)

    # Test that method raw_get does not expand variables
    inv.set_variable_manager(var_mgr)
    var_mgr.set_inventory(inv)
    hostvars = HostVars(inv, var_mgr, loader)
    inv.add_host('localhost', port=22, testvar=dict(hostvar='hostvalue'))

# Generated at 2022-06-23 15:04:40.535812
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    hvv = HostVarsVars({'foo': 1}, None)
    assert 'foo' in hvv
    assert 'bar' not in hvv

# Generated at 2022-06-23 15:04:44.913100
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.hostvars import HostVars

    hostvars = HostVars({})

    # Length of list equals the length of HostVars object
    result = len([host for host in hostvars])
    assert len(hostvars) == result

# Generated at 2022-06-23 15:04:51.514680
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager()

    hv = HostVars(inventory, variable_manager, loader=None)

    it = iter(hv)
    host = next(it)
    assert host == 'localhost'

# Generated at 2022-06-23 15:04:56.112958
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from mock import MagicMock

    hostvars = HostVars(None, None, None)
    variable_manager = MagicMock()
    hostvars.set_variable_manager(variable_manager)

    assert hostvars._variable_manager == variable_manager
    assert variable_manager._hostvars == hostvars

# Generated at 2022-06-23 15:05:02.133250
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    hostvarsvars = HostVarsVars({'foo': 'hello', 'bar': 'world'}, {})
    # Test method __getitem__()
    assert isinstance(hostvarsvars['foo'], AnsibleUndefined)
    # Test method __contains__()
    assert ('bar' in hostvarsvars)
    # Test method __iter__()
    assert (list(iter(hostvarsvars)) == ['foo', 'bar'])
    # Test method __len__()
    assert (len(hostvarsvars) == 2)
    # Test method __repr__()
    assert (repr(hostvarsvars) == "{'foo': Undefined, 'bar': Undefined}")

# Generated at 2022-06-23 15:05:09.404359
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    '''
    Test for method HostVarsVars.__repr__

    Make sure it works with a couple of different variables types, including
    ones that should be expanded as other variables and inventory entries.
    '''

    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    host = inventory.add_host('host_address')
    host.set_variable('host_vars', 'host var')
    host.set_variable('another_host_vars', 'another host var')
    inventory.set_variable_manager(VariableManager(loader=loader, inventory=inventory))


# Generated at 2022-06-23 15:05:17.907564
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    variables = dict(var1='value1', var2='value2', var3=dict(var4='foo'))

    templar = Templar(variables=variables, loader=loader)
    template_result = templar.template(variables, fail_on_undefined=True, static_vars=STATIC_VARS)

    host_vars_vars = HostVarsVars(variables, loader)

    assert host_vars_vars == template_result



# Generated at 2022-06-23 15:05:20.429223
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    hostvars_vars = HostVarsVars({'foo': '{{ bar }}', 'bar': 'baz'}, None)
    assert hostvars_vars['foo'] == 'baz'

# Generated at 2022-06-23 15:05:27.714962
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    # create a variable manager to hold the inventory and pass it to the hostvars object
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(inventory)

    # create a hostvars object to query
    hostvars = HostVars(inventory, variable_manager, loader)

    # create a host to query
    localhost = inventory.get_host('localhost')
   

# Generated at 2022-06-23 15:05:30.785387
# Unit test for constructor of class HostVars
def test_HostVars():
    loader = None
    variable_manager = None
    inventory = None
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars is not None

# Generated at 2022-06-23 15:05:42.334539
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,host1'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    for host_name in ['localhost', 'host1']:
        host = inventory.get_host(host_name)
        assert hostvars.get(host_name) == {}
        hostvars.set_host_variable(host=host, varname='foo', value=7)
        assert hostvars.get(host_name) == {'foo': 7}

# Generated at 2022-06-23 15:05:51.707397
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    host_vars_cache = HostVars(inventory=None,
                               variable_manager=variable_manager,
                               loader=loader)

    result = HostVarsVars({}, loader=loader)
    assert len(result) == 0

    result = HostVarsVars({'a': 1}, loader=loader)
    assert len(result) == 1

    result = HostVarsVars({'a': 1, 'b': 2}, loader=loader)
    assert len(result) == 2

    result = HostVarsVars({'a': {'b': 2}}, loader=loader)
    assert len(result) == 1

    result

# Generated at 2022-06-23 15:06:02.806199
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.errors import AnsibleError
    from ansible.inventory.host import Host

    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from units.mock.vars_plugins import MockVarsModule

    loader = DictDataLoader({})
    inventory = MockInventory(loader=loader, host_list=['somehost'])
    host = inventory.get_host('somehost')
    host.vars = dict(foo='bar')

    m = MockVarsModule()
    vars_manager = m.get_vars_manager()
    vars_manager.add_host_vars_loaders(host, loader=loader, vars_plugins=[])

    hostvars = HostVars(inventory, vars_manager, loader=loader)

   

# Generated at 2022-06-23 15:06:06.551115
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # TODO: replace with a proper unit test
    # HostVars.set_nonpersistent_facts() is called by
    # FactCache._set_fact_cache_internal() when a fact cache plugin is used.
    # In that case, tests for HostVars.set_nonpersistent_facts() are already
    # performed by test_fact_cache.py module.
    pass

# Generated at 2022-06-23 15:06:16.508686
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Python 3.2 doesn't allow to use mock in this case
    import sys
    if sys.version_info < (3, 3, 0):
        import unittest
        import unittest.mock as mock

        class TestHostVars(unittest.TestCase):
            ''' Test case for HostVars.__setstate__() method '''

            def test_setstate(self):
                # Create mock objects
                inventory = mock.MagicMock()
                loader = mock.MagicMock()
                variable_manager = mock.MagicMock()

                # Initialize class HostVars
                hostvars = HostVars(inventory, variable_manager, loader)

                # Create state

# Generated at 2022-06-23 15:06:26.202678
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    import copy
    import pprint

    class DummyVars(Mapping):

        def __init__(self, vars):
            self._vars = vars

        def __getitem__(self, var):
            return self._vars[var]

        def __contains__(self, var):
            return (var in self._vars)

        def __iter__(self):
            for var in self._vars.keys():
                yield var

        def __len__(self):
            return len(self._vars.keys())

        def __repr__(self):
            return repr(self._vars)

    vars = DummyVars(vars={'test_key': 'test_val'})
    hostvars = HostVarsVars(vars=vars, loader=None)

   

# Generated at 2022-06-23 15:06:36.201533
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    '''
    Unit test for method set_host_variable of class HostVars.
    '''
    # pylint: disable=no-name-in-module,import-error
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    # Create fake host and group instances
    host1 = Host('host1')
    group1 = Group('group1')
    group1.add_host(host1)

    # Create fake inventory
    class inventory:
        def __init__(self):
            # pylint: disable=attribute-defined-outside-init
            self._hosts = []
            self._groups = []

        @property
        def hosts(self):
            return self._hosts


# Generated at 2022-06-23 15:06:46.368131
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host, Group
    from ansible.inventory.manager import InventoryManager

    host = Host(name='foo', port=22)
    group = Group(name='group1')
    group.add_host(host)

    inventory = InventoryManager(loader=None, sources=[])
    inventory.add_group(group)

    vm = VariableManager(loader=None, inventory=inventory)
    vm.set_host_variable(host, 'foo', 'bar')

    hv = HostVars(inventory=inventory, variable_manager=vm, loader=None)

    import copy
    assert copy.deepcopy(hv['foo']).get('foo') == 'bar'

# Generated at 2022-06-23 15:06:53.541035
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.vars import VariableManager, HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    hv = HostVars(inventory, variable_manager, loader)

    assert 'localhost' in hv

# Generated at 2022-06-23 15:07:01.089138
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # prepare data for test
    test_inventory = Inventory()
    test_host = Host(name="test_host", inventory=test_inventory)
    test_group = Group(name="test_group", inventory=test_inventory)

    # prepare environment for test
    var_manager = VariableManager()
    host_vars = HostVars(inventory=None, variable_manager=var_manager, loader=DataLoader())

    # method set_inventory should

# Generated at 2022-06-23 15:07:12.013207
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=None, host=inventory.get_host('localhost'), include_hostvars=True))

    assert templar.template("{{ localhost is defined }}", fail_on_undefined=False, static_vars=STATIC_VARS) == 'True'

# Generated at 2022-06-23 15:07:18.719623
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hv = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hv.set_host_facts('localhost', { 'greeting': 'Hello' })

    assert hv.raw_get('localhost')['greeting'] == 'Hello'

# Generated at 2022-06-23 15:07:28.653136
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    hv = HostVars(None, variable_manager, loader)

    hvv = HostVarsVars({'foo': '{{ test }}'}, loader)
    hv._vars = {'test': 'bar'}

    assert hvv.__repr__() == 'bar'

    hvv = HostVarsVars({'foo': ['{{ test }}']}, loader)
    hv._vars = {'test': 'bar'}

    assert hvv.__repr__() == ['bar']

# Generated at 2022-06-23 15:07:37.029095
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(loader=DataLoader(), sources='localhost, ')
    inventory.add_host(host='localhost', group='ungrouped')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, DataLoader())
    variable_manager.set_host_variable('localhost', 'foo', "bar")

    assert hostvars.raw_get('localhost') == {
        'foo': 'bar'
    }

# Generated at 2022-06-23 15:07:42.504993
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    hostvars = HostVarsVars({'a': 'b'}, None)
    assert len(hostvars) == 1
    hostvars = HostVarsVars({}, None)
    assert len(hostvars) == 0
    hostvars = HostVarsVars(None, None)
    assert len(hostvars) == 0

# Generated at 2022-06-23 15:07:53.155588
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = DictDataLoader({})
    varmanager = VariableManager()

    variables = dict(a=1, b=dict(c=2), d=3)
    vars = HostVarsVars(variables, loader)

    # test HostVarsVars object
    assert list(vars.__iter__()) == ['a', 'b', 'd']

    # test hostvars view
    hostvars = HostVars(inventory=None, variable_manager=varmanager, loader=loader)
    hostvars.set_variable_manager(varmanager)

    varmanager.set_inventory(Inventory(loader=loader, variable_manager=varmanager))
    inventory_host = Host(name='test_host', variables=variables, port=2222)
    inventory_host.set_variable_manager(varmanager)

   

# Generated at 2022-06-23 15:08:00.131417
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    vm._vars_cache = { 'localhost': { 'myvar': '{{myval}}' } }
    vm._fact_cache = { 'localhost': { 'myval': 'myvalue' } }
    hv = HostVars(None, vm)

    assert hv['localhost']['myvar'] == 'myvalue'

# Generated at 2022-06-23 15:08:07.209362
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy

    from .vars_plugins.generator import VarsModule
    from .group import Group
    from .inventory import Inventory
    from .host import Host
    from .inventory_loader import InventoryLoader

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # Create a templar for variables' templates
    loader = InventoryLoader(None, variable_manager=None, loader=None)

    # Fake inventory
    group = Group(name='test_group')
    host = Host(name='test_host', groups=[group])
    inventory = Inventory(loader=loader, groups=[group])
    inventory.hosts = [host]

    # Create a hostvars object with the inventory

# Generated at 2022-06-23 15:08:15.439594
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    hostvars = HostVars(variables={}, loader=None)
    hostvars_vars = HostVarsVars({}, hostvars)
    assert hostvars_vars.__len__() == 0
    assert len(hostvars_vars) == 0
    hostvars_vars = HostVarsVars({'foo': 'bar'}, hostvars)
    assert hostvars_vars.__len__() == 1
    assert len(hostvars_vars) == 1



# Generated at 2022-06-23 15:08:17.001247
# Unit test for constructor of class HostVars
def test_HostVars():
    assert HostVars(1, 2, 3) is not None

# Generated at 2022-06-23 15:08:24.922779
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from io import StringIO
    inventory_file = StringIO()
    inventory_file.write(dedent('''
        [all]
        localhost
    '''))
    inventory_file.seek(0)
    loader = None
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=inventory_file)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"
    assert repr(hostvars) == repr(hostvars['localhost'])


# Generated at 2022-06-23 15:08:33.941933
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import ansible.plugins.loader as plugin_loader

    test_variables = {
        "a": 1,
        "foo": "bar",
        "b": 2,
    }

    hostvars_vars = HostVarsVars(test_variables, loader=plugin_loader)

    # To test __iter__ we need to collect all the items generated by __iter__
    # and compare them with the keys of test_variables.
    iter_variable_names = []
    for variable_name in hostvars_vars:
        iter_variable_names.append(variable_name)

    assert sorted(iter_variable_names) == sorted(test_variables.keys())

# Generated at 2022-06-23 15:08:45.921680
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    ans_vars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    host = Host(name='localhost')
    host.set_variable('ansible_ssh_private_key_file', '/tmp/ansible-key.pem')
    host.set_variable('ansible_ssh_host', '127.0.0.1')


# Generated at 2022-06-23 15:08:56.737153
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    inventory.hosts = {
        'host1': dict(name='host1'),
        'host2': dict(name='host2'),
    }

    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager._vars_persist = {
        'host1': dict(name='host1'),
        'host2': dict(name='host2')
    }

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    # Make sure the dict returned from __repr__ of HostVars is equal to
    # variable_manager._vars_persist