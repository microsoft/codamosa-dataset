

# Generated at 2022-06-23 14:59:03.491581
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import copy
    import os
    import sys
    import tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create a temporary directory to store the inventory and playbook.
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)

    # Create a simple inventory with one localhost host.
    with open('hosts', 'w+') as f:
        f.write('localhost ansible_connection=local')

    # Create dummy group and hostvars files.
    for filename in ['group_vars/all', 'host_vars/localhost']:
        open(filename, 'w+').close()

    # Create a dummy playbook and copy it to the temporary directory.

# Generated at 2022-06-23 14:59:08.301247
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    class FakeVariables(object):
        def __len__(self):
            return 5

    obj = HostVarsVars(FakeVariables(), None)
    length = len(obj)
    assert length == 5, length


# Generated at 2022-06-23 14:59:12.042247
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    hvvars = HostVarsVars({}, None)
    assert len(hvvars) == 0
    hvvars = HostVarsVars({'foo': 'bar'}, None)
    assert len(hvvars) == 1

# Generated at 2022-06-23 14:59:17.433022
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='tests/inventory_empty')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    res = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert set(iter(res)) == set(['localhost'])



# Generated at 2022-06-23 14:59:25.824494
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    import ansible.playbook.play

    # Create "vars_cache" and "variable_manager" instances
    play = ansible.playbook.play.Play()
    hostvars = HostVars(inventory=play.inventory,
                        variable_manager=play.variable_manager,
                        loader=play._loader)

    # hostvars does not have to be deepcopy because it is immutable
    # however we have to check that it works properly
    hostvars = copy.deepcopy(hostvars)
    assert isinstance(hostvars, HostVars)

# Generated at 2022-06-23 14:59:31.836595
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars = HostVars({}, {}, {})
    hostvars.set_variable_manager(None)

    hostvars.set_host_variable("test1", "test2", "test3")
    hostvars.set_host_variable("test1", "test4", "test5")

    # test iterator
    assert set(hostvars.get("test1")) == set(("test2", "test4"))


# Generated at 2022-06-23 14:59:40.866873
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():

    # mocks
    class MockVariableManager():
        def __init__(self):
            self._hostvars = None
            self._values = None

        def get_vars(self, host=None, include_hostvars=True):
            return self._values

        def set_host_variable(self, host, varname, value):
            pass

        def set_nonpersistent_facts(self, host, facts):
            pass

        def set_host_facts(self, host, facts):
            pass

    class MockHost():
        def __init__(self, name):
            self.name = name

    class MockInventory():
        def __init__(self, hosts):
            self._hosts = hosts
            self._variables = {}


# Generated at 2022-06-23 14:59:51.469028
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Host, Inventory
    from ansible.vars.manager import VariableManager

    variables = dict(hostvars=dict(host1=dict(ansible_facts=dict(facts1=dict(var1='value1', var2='value2')))))
    inventory = Inventory(host_list=['host1'], variable_manager=VariableManager(loader=None, variables=variables))
    hostvars = HostVars(inventory=inventory, variable_manager=inventory.get_variable_manager(), loader=None)
    host = Host(name='newhost')

    hostvars.set_host_facts(host, dict(facts2=dict(varA='valueA')))

    new_facts = hostvars.raw_get('newhost')['ansible_facts']

# Generated at 2022-06-23 14:59:55.770820
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    hostvars = HostVarsVars({'hostvars_key': 'hostvars_value'}, None)
    assert repr(hostvars) == "{'hostvars_key': 'hostvars_value'}"
    assert repr(hostvars) == repr(hostvars._vars)

# Generated at 2022-06-23 15:00:03.463993
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.plugins.loader import inventory_loader
    from ansible.vars import VariableManager
    vm = VariableManager()
    hostvars = HostVars(inventory_loader.get('localhost', vm), vm, None)
    hostvars.set_host_facts('localhost', {'fact1': 'value1'})

    # Check that fact is set
    assert hostvars['localhost'].get('fact1') == 'value1'

    # Check that fact is still set after nonpersistent fact is set
    hostvars.set_nonpersistent_facts('localhost', {'fact2': 'value2'})
    assert hostvars['localhost'].get('fact2') == 'value2'
    assert hostvars['localhost'].get('fact1') == 'value1'

    # Check that nonpersistent fact is not

# Generated at 2022-06-23 15:00:05.839614
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    variables = {'foo': 'bar'}
    hostvars = HostVarsVars(variables, None)
    assert 'foo' in hostvars

# Generated at 2022-06-23 15:00:09.700532
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    class FakeLoader:
        pass

    fake_loader = FakeLoader()

    vars = HostVarsVars({"var1":"value1"}, fake_loader)

    assert("var1" in vars)
    assert("var1" in vars)

# Generated at 2022-06-23 15:00:19.277485
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.errors import AnsibleError
    import ansible.inventory.host
    import ansible.inventory.manager
    import ansible.vars.manager

    inventory = ansible.inventory.manager.InventoryManager(loader=None, sources=None)
    variable_manager = ansible.vars.manager.VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    # set_inventory should not update the inventory when the supplied
    # inventory is equal to the current inventory
    hostvars.set_inventory(inventory)
    assert hostvars._inventory == inventory

    # set_inventory should update the inventory when the supplied
    # inventory is different from the current inventory

# Generated at 2022-06-23 15:00:20.746475
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # TODO: to be implemented
    pass


# Generated at 2022-06-23 15:00:30.440016
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    hostvars = HostVars(inventory, variable_manager, loader)
    host = inventory.get_host('localhost')
    hostvars.set_host_facts(host, {'foo': 'bar'})
    assert (hostvars['localhost']['foo'] == 'bar')

# Generated at 2022-06-23 15:00:40.793309
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)

    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)

    variable_manager.set_host_variable("test", "v1", "1")
    variable_manager.set_host_variable("test", "v2", "2")
    variable_manager.set_host_variable("test", "v3", "3")

    # Test simple variable
    variables = hostvars.raw_get("test")
    hostvars_vars = HostVarsVars(variables, loader)

# Generated at 2022-06-23 15:00:44.904907
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory

    iv = Inventory(":memory:")
    iv.parse_inventory()

    hv = HostVars(iv)
    assert not hv.__contains__("nonexistent")

    iv.add_host("new")
    assert hv.__contains__("new")


# Generated at 2022-06-23 15:00:54.862377
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class MockedVariableManager(object):
        def __init__(self):
            self._data = {'foo': 'baz'}
        def get_vars(self, host=None, include_hostvars=False):
            return self._data

    def test_unsafe_proxy(arg):
        assert isinstance(arg, UnsafeProxy)

    var_manager = MockedVariableManager()
    hostvars = HostVars(None, var_manager, None)
    hostvars.set_variable_manager(var_manager)

    foo = hostvars["example.com"]
    test_unsafe_proxy(foo)

# Generated at 2022-06-23 15:01:04.765530
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars import VariableManager
    v = VariableManager()

    from ansible.inventory import Inventory
    inv = Inventory("tests/inventory")

    from ansible.parsing.dataloader import DataLoader
    l = DataLoader()
    h = HostVars(inv, v, l)
    assert h.set_variable_manager
    assert h.set_inventory
    assert h.raw_get
    assert h.__setstate__
    assert h.__getitem__
    assert h.set_host_variable
    assert h.set_nonpersistent_facts
    assert h.set_host_facts
    assert h.__contains__
    assert h.__iter__
    assert h.__len__
    assert h.__repr__
    assert h.__deepcopy__
    assert h._loader

# Generated at 2022-06-23 15:01:13.783667
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    # VariableManager instance required to use HostVars
    variable_manager = VariableManager()

    # HostVars created with empty inventory
    hostvars = HostVars(None, variable_manager, None)

    # Create instance of Host class
    host = Host('localhost')

    # Set variables for "localhost" host
    hostvars.set_host_variable(host, 'foo', 'bar')
    hostvars.set_host_variable(host, 'bar', 'foo')

    hostvars['localhost']['foo'] == 'bar'
    hostvars['localhost']['bar'] == 'foo'

# Generated at 2022-06-23 15:01:24.715682
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os

    inventory_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'inventory')
    inventory_file = os.path.join(inventory_dir, 'host_vars_inventory')
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=[inventory_file])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 15:01:26.750922
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    hv = HostVarsVars({'abc': 1, 'bcd': 2}, None)
    assert len(hv) == 2



# Generated at 2022-06-23 15:01:35.807280
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.plugins import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestVariableManager(VariableManager):
        # Simulate a missing _hostvars and _loader attributes
        # of instance VariableManager after pickling.
        def __getstate__(self):
            state = super(TestVariableManager, self).__getstate__()
            state['_hostvars'] = None
            state['_loader'] = None
            return state

    inventory_file_path = './test/units/lib/ansible/test/test_vars_cache.yml'
    inventory = InventoryManager(loader=vars_loader, sources=[inventory_file_path])

# Generated at 2022-06-23 15:01:44.781118
# Unit test for constructor of class HostVars
def test_HostVars():
    class Inventory:
        def get_host(self, host_name):
            if host_name == 'somehost':
                return host_name
            return None

        def hosts(self):
            return [ 'somehost' ]

    class VariableManager:
        def get_vars(self, host=None, include_hostvars=True):
            if host == 'somehost':
                return { 'foo': 'foovalue', 'bar': 'barvalue' }
            return AnsibleUndefined()

    hv = HostVars(Inventory(), VariableManager(), loader=None)
    foo = hv['somehost']['foo']
    bar = hv['somehost']['bar']
    assert foo == 'foovalue'
    assert bar == 'barvalue'
    assert 'foo' in hv['somehost']


# Generated at 2022-06-23 15:01:56.157054
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def check_variable_manager(variable_manager):
        assert variable_manager._loader is loader
        assert variable_manager._hostvars is hostvars

    # create VariableManager instance
    loader = lambda *args, **kwargs: None
    inventory = InventoryManager(loader, 'localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # create HostVars instance
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    # call VariableManager.__setstate__ with dummy data to emulate serialization

# Generated at 2022-06-23 15:02:05.812176
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars import HostVars as vars_HostVars

    # We need to mock a couple of methods to test the main one
    class fake_VariableManager(object):
        def __init__(self):
            self._hostvars = None

        def __deepcopy__(self, memo):
            new_var_mgr = fake_VariableManager()
            new_var_mgr._hostvars = self._hostvars
            return new_var_mgr

    class fake_Inventory(object):
        def __init__(self):
            self._hosts = {'testhost': self}

        def __deepcopy__(self, memo):
            new_inventory = fake_Inventory()
            new_inventory._hosts = self._hosts
            return new_inventory

   

# Generated at 2022-06-23 15:02:16.256139
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # hostvarsvars instances are not pickable, so we have to test __repr__
    # directly
    import pickle
    import json
    import os

    basedir = os.path.dirname(os.path.abspath(__file__))
    srcdir = os.path.join(basedir, 'data')
    loader = AnsibleFileLoader(basedir=srcdir)

    fake_vars = {'a': '{{ b }}'}
    vars = HostVarsVars(fake_vars, loader=loader)

    repr_output = repr(vars)
    repr_dict = json.loads(repr_output)
    expected_dict = {'a': '{{ b }}'}
    assert repr_dict == expected_dict

    # Check that it is not pickable

# Generated at 2022-06-23 15:02:21.959734
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Create a new FakeInventory with a valid group
    group = 'valid_group'
    hosts = ['my_host']
    inventory = FakeInventory(hosts=hosts, groups=[group], loader=None)
    # Create a new HostVars with the inventory
    hostvars = HostVars(inventory=inventory, variable_manager=None, loader=None)
    # Check that __len__ method return the expected number of hosts
    assert len(hostvars) == len(hosts)


# Generated at 2022-06-23 15:02:31.353718
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    mapping = {'a': '{{b}}', 'b': '{{c}}', 'c': 'd'}
    assert repr(HostVarsVars(mapping, loader=None)) == repr(mapping)
    # check the deepness of templating
    mapping = {'a': '{{b}}', 'b': '{{c}}', 'c': '{{d}}', 'd': '{{e}}', 'e': 'f'}
    assert repr(HostVarsVars(mapping, loader=None)) == repr(mapping)

# Generated at 2022-06-23 15:02:36.622587
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    i = Inventory(host_list=['localhost', 'anotherhost'])
    hv = HostVars(inventory=i, variable_manager=VariableManager())

    assert(len(hv) == 2)

    i = Inventory(host_list=[])
    hv = HostVars(inventory=i, variable_manager=VariableManager())

    assert(len(hv) == 0)

# Generated at 2022-06-23 15:02:43.564197
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    hostvarsvars = HostVarsVars({'ansible_version': {'full': '2.0.0.2', 'major': 2, 'minor': 0, 'revision': 0, 'string': '2.0.0.2'}}, None)
    foo = repr(hostvarsvars)
    assert foo == "{'ansible_version': {'full': '2.0.0.2', 'major': 2, 'minor': 0, 'revision': 0, 'string': '2.0.0.2'}}"

# Generated at 2022-06-23 15:02:52.979026
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, None)

    host = inventory.get_host('localhost')

    assert not host.get_vars()

    # set nonpersistent facts
    hostvars.set_nonpersistent_facts(host, dict(a=1))
    assert host.get_vars()
    assert host.get_vars().get('a') == 1

    # re-run task, nonpersistent facts should not be overridden
    hostvars.set_nonpersistent_facts(host, dict(a=2))

# Generated at 2022-06-23 15:03:01.586754
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader_for_test = DictDataLoader({
        "some_file": "{% for item in items -%}\n{{ item }}\n{% endfor %}",
        "some_file_with_vars": "{{ some_var }}",
        "some_file_with_includes": "{% include 'some_include_file' %}",
    })
    variables_for_test = {"some_var": "some_val", "items": [1, 2, 3], "some_include_file": "foo {{ some_include_file_var }} bar"}
    host_vars_vars_for_test = HostVarsVars(variables_for_test, loader_for_test)

    assert str(host_vars_vars_for_test) == "[1, 2, 3]"

# Generated at 2022-06-23 15:03:11.812187
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager('localhost', loader=None)
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=None)
    variable_manager._hostvars = hostvars

    data = {
        'e': 'E',
        'f': 'F',
    }
    variable_manager.set_host_variable('localhost', 'data', data)

    hostvars_copy = copy.deepcopy(hostvars)
    assert hostvars_copy['localhost']['data']['e'] == 'E'
    assert hostvars_copy['localhost']['data']['f'] == 'F'

# Generated at 2022-06-23 15:03:21.618195
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Check that the entry in vars is only iterated once
    data = {'foo': 1, 'bar': 2, 'baz': 3}
    hostvarsvars = HostVarsVars(data, None)
    iterator = iter(hostvarsvars)
    assert next(iterator) == 'foo'
    assert next(iterator) == 'bar'
    assert next(iterator) == 'baz'
    try:
        next(iterator)
        # We should never reach this line
        raise Exception("Iterator of HostVarsVars was not used up")
    except StopIteration:
        pass

# Generated at 2022-06-23 15:03:30.477200
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import copy
    import ansible.constants as C
    import ansible.inventory
    import ansible.playbook
    import ansible.vars

    C.HOST_VARS_EXPOSE = True

    # Create inventory
    myhosts = ansible.inventory.Inventory(['localhost'])
    myhosts.get_host('localhost').vars = dict(ansible_connection='local', ansible_python_interpreter='/usr/bin/python2')

    # Create variable manager
    vars_manager = ansible.vars.VariableManager()
    vars_manager.set_inventory(myhosts)

    # Create loader
    loader = ansible.loader.DataLoader()

    # Create hostvars

# Generated at 2022-06-23 15:03:41.129066
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager

    loader = DummyLoader()
    variable_manager = DummyVariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)

    expected_hosts = {
        'host1': {
            'hostname': 'host1',
            'omit': 'omit1'
        },
        'host2': {
            'hostname': 'host2',
            'omit': 'omit2'
        },
        'host3': {
            'hostname': 'host3',
            'omit': 'omit3'
        }
    }

    # Create a hostvars (group variables with the same name are omitted)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-23 15:03:52.871619
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # imports
    from ansible.plugins import find_all_block_plugins

    class FakeInventory:
        def __init__(self):
            self.hosts = []

        def get_host(self, host_name):
            return self.hosts[host_name]

    class FakeHost:
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class FakeVariableManager:
        def __init__(self):
            self.loader = None
            self.hostvars = None

        def set_host_variable(self, host, varname, value):
            self.hostvars[host][varname] = value

        def set_nonpersistent_facts(self, host, facts):
            pass

    # creating objects
   

# Generated at 2022-06-23 15:04:02.215487
# Unit test for constructor of class HostVars
def test_HostVars():

    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    INVENTORY_DATA = [
        'host1',
        'host2',
        'host3',
        'host4',
        'host5'
    ]

    def _get_group(name, hosts):
        from ansible.inventory.group import Group
        return Group(name=name, hosts=hosts)

    groups = tuple([_get_group(name, []) for name in INVENTORY_DATA])

    inventory = Inventory(groups=groups)

    variable_manager = VariableManager()

    test_module = HostVars(inventory, variable_manager, None)

    for host_name in INVENTORY_DATA:
        assert host_name in test_module

# Generated at 2022-06-23 15:04:12.416658
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager([], variable_manager=variable_manager, loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars_normal = hostvars['localhost']
    hostvars_normal.get('some_key')
    hostvars_normal.get('other_key')

    host = Host('some_host')
    host.set_variable('some_key', 'some_value')
    host.set_variable('other_key', 'other_value')
    new

# Generated at 2022-06-23 15:04:22.811416
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.module_utils.common._collections_compat import Mapping
    # This is a special view of vars_cache, so vars_cache is the same as self._vars
    class MockVarsCache(Mapping):
        def __init__(self, data):
            self._data = data

        def __getitem__(self, key):
            return self._data[key]

        def __contains__(self, key):
            return key in self._data

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)

    # This is a mock class of class AnsibleLoader
    class MockAnsibleLoader(object):
        def __init__(self):
            self.path_exists_return_value = True

# Generated at 2022-06-23 15:04:32.064558
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = None
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    host = Host(name='myhost')
    inventory.add_host(host)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(host, 'foo', 'bar')
    assert hostvars.get(host)['foo'] == 'bar'

# Generated at 2022-06-23 15:04:41.627495
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader = None
    variables = {'hostvars_dict': {'foo': 'bar'}}
    hostvars = HostVarsVars(variables, loader)
    assert repr(hostvars) == repr({'foo': 'bar'})

    variables = {
        'hostvars_dict': {'foo': 'bar', 'baz': {'foobar': 'baz'}},
        'baz': {'foobar': 'baz'},
    }
    hostvars = HostVarsVars(variables, loader)
    assert repr(hostvars) == repr({'foo': 'bar', 'baz': {'foobar': 'baz'}, 'foobar': 'baz'})


# Generated at 2022-06-23 15:04:45.453860
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader, sources=['test/inventory/test_hostvars'])
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=dataloader)

    assert len(hostvars['localhost']) == 6

    assert len(hostvars['test1']) == 4
    assert len(hostvars['test2']) == 3
    assert len(hostvars['test1:test2']) == 3

# Generated at 2022-06-23 15:04:57.662126
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    data = {
        'ansible_facts': {
            'a1': 'a2',
            'b1': 'b2',
            'c': {'c1': 'c2', 'c3': 'c4'},
        },
        'a': 'a',
        'b': {'b1': 'b2', 'b3': 'b4'},
    }

    loader = DictDataLoader({})
    host = Mock()
    host.name = 'host_name'
    host.vars = data
    inventory = MockInventory({'host_name': host})
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)


# Generated at 2022-06-23 15:05:04.511499
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    class _Inventory(object):

        def __init__(self, data):
            self._data = data

        def get_host(self, name):
            return self._data.get(name)

        @property
        def hosts(self):
            return self._data.keys()

    class _VariableManager(object):

        def __init__(self, loader=None):
            self._loader = loader
            self._hostvars = None

    class _Loader(object):
        def __init__(self, basedir=None):
            self._basedir = basedir

    inventory = _Inventory(data={'example_host': {'var': 'var'}})
    loader = _Loader(basedir='/etc')
    variable_manager = _VariableManager(loader=loader)

# Generated at 2022-06-23 15:05:09.746528
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = AnsibleVariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    hostvars = HostVars(inventory, variable_manager, loader)
    assert list(hostvars) == ['localhost']

# Generated at 2022-06-23 15:05:20.076975
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # initialize HostVars with default values
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from io import StringIO

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='')

# Generated at 2022-06-23 15:05:27.086179
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # Make a VariableManager
    v = VariableManager()
    HOSTVARS = HostVars(inventory=Inventory(), variable_manager=v, loader=None)
    # Make a host
    from ansible.vars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    new_host = HostVarsVars({'foo': 'bar'}, loader=None)
    # Add it to the inventory
    HOSTVARS.set_host_variable(host=HostVarsVars(variables=new_host, loader=None),
                               varname='hostvars',
                               value=new_host)
    # Check that it can be found

# Generated at 2022-06-23 15:05:37.199068
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    host = inventory.get_host('localhost')
    hostvars.set_host_facts(host, {'a': 1})
    assert hostvars['localhost']['a'] == host.get_vars()['a']

# Generated at 2022-06-23 15:05:45.138362
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inv_path = './test/unit/inventory/host_vars'
    inventory = InventoryManager(loader=None, sources=[inv_path])

    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, None)

    assert 'vagrant' in hostvars
    assert 'localhost' not in hostvars
    assert 'not-vagrant' not in hostvars


# Generated at 2022-06-23 15:05:52.615287
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # Set up inventory
    inventory = get_inventory()
    inventory.set_variable("group_name", "group_name")

    # Create HostVars instance
    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Forcefully modify variable_manager to check whether
    # set_variable_manager will restore it
    variable_manager._hostvars = object()

    # Run tested method
    hostvars.set_variable_manager(variable_manager)

    # Check if variable_manager is restored
    assert variable_manager._hostvars == hostvars


# Generated at 2022-06-23 15:06:03.432808
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    # First create a variable manager manually to test the method
    from ansible import constants as C
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    # Create and add the custom inventory script to the variable manager
    from ansible.utils.test import get_custom_inventory
    script = get_custom_inventory()
    variable_manager.add_inventory(script)
    # Create a loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    # Now create the HostVars object
    hostvars = HostVars(variable_manager.get_inventory(), variable_manager, C.DEFAULT_LOADER_PLUGINS_PATH)
    hostvars.set_variable_manager(variable_manager)
    hostvars.set_loader(loader)

    #

# Generated at 2022-06-23 15:06:14.201106
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import pytest
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs

    # Initialize plugin loader
    add_all_plugin_dirs()

    # Create inventory
    inventory = InventoryManager([])

    inventory._set_hosts(["localhost", "127.0.0.1"])

    host = inventory.get_host("127.0.0.1")

    host.vars = {
        "var1": "value1",
        "var2": "value2"
    }

    # Create HostVars
    hostvars = HostVars(inventory, None, None)

    # Check that HostVars contains data
    assert len(hostvars) > 0

    # Check that __contains__ of HostVars returns True

# Generated at 2022-06-23 15:06:21.402925
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = 'ansible.parsing.dataloader.DataLoader'
    variables = {
        'foo': '1',
        'bar': '2',
        'baz': '3'
    }
    hostvarsvars = HostVarsVars(variables=variables, loader=loader)
    assert list(hostvarsvars) == ['foo', 'bar', 'baz']


# Generated at 2022-06-23 15:06:33.337179
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    """Tests method __getitem__ of class HostVarsVars"""
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)
    vars = { 'test_value': "foo" }
    hvv = HostVarsVars(variables=vars, loader=loader)
    assert hvv['test_value'] is vars['test_value']

    vars = { 'test_value': templar.template("{{ test_value }}", fail_on_undefined=True, static_vars=STATIC_VARS) }
    hvv = HostVarsVars(variables=vars, loader=loader)
    assert hvv['test_value'] is None

# Generated at 2022-06-23 15:06:38.139286
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    hostname = 'test_getitem'
    variables = {'name': 'myvarname', 'value': 'myvalue'}
    host_vars = HostVarsVars(variables, loader=None)
    assert host_vars[hostname] == variables[hostname]


# Generated at 2022-06-23 15:06:47.755454
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    host_name = 'foo'
    variable_manager = VarsManager()
    variable_manager.set_host_variable(host_name, 'bar', 'baz')
    variable_manager.set_host_variable(host_name, 'something', 'another')

    hostvars = HostVars(variable_manager, None)
    assert hostvars[host_name] == {'bar': 'baz', 'something': 'another'}

    # test that 'bar' is not in the result of __getitem__ if it is 'omit'
    variable_manager = VarsManager()

# Generated at 2022-06-23 15:06:58.598023
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = C.DEFAULT_LOADER
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    templar = Templar(variables=variable_manager.constants, loader=loader)
    templar._add_host_info(hostvars)

    # The following test is to confirm that HostVarsVars does not
    # consider static vars. If static vars were considered, the
    # following test would trigger an exception in Templar._add_host_

# Generated at 2022-06-23 15:07:10.132263
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Create a hostvars object
    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    hostvars = HostVars(inventory, variables, loader)

    # Make sure that repr for an empty hostvars object is equal to repr for
    # an empty dict
    assert repr(hostvars) == repr({})

    # Add a group with a single host
    group = inventory.add_group('group')
    host = inventory.add_host(host='host', group=group)

    # Set facts to the host

# Generated at 2022-06-23 15:07:20.023053
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    class AInventory(object):
        def __init__(self, host_list=['localhost', 'otherhost']):
            self._hosts = host_list

        def hosts(self):
            return self._hosts

        def get_host(self, host_name):
            if host_name in self._hosts:
                return host_name
            else:
                return None

    class AVariableManager(object):
        def __init__(self):
            pass

        def get_vars(self, host=None, include_hostvars=False):
            return {}

    class ALoader(object):
        def __init__(self):
            pass

    old_inventory = AInventory()
    hostvars = HostVars(old_inventory, AVariableManager(), loader=ALoader())
    new

# Generated at 2022-06-23 15:07:27.417355
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    hostvars = HostVars({'hoge': 'fuga'})
    # check iterator returned by HostVars.__iter__()
    assert next(iter(hostvars)) == 'hoge'

    hostvars = HostVars({'hoge': 'fuga', 'foo': 'bar'})
    # check iterator returned by HostVars.__iter__()
    assert sorted(iter(hostvars)) == ['foo', 'hoge']


# Generated at 2022-06-23 15:07:37.358655
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.reserved import Reserved
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    class HostVarsVars__repr__Test(PlaybookExecutor):

        def __init__(self, *args, **kwargs):

            self.task = None

            self.inventory = None
            self.loader = None
            self.variable_manager = None
            self.passwords = None

            self._tqm

# Generated at 2022-06-23 15:07:48.043515
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from copy import deepcopy
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host1 = inventory.add_host('host1')
    host2 = inventory.add_host('host2')
    variable_manager.set_host_variable(host1, 'ansible_host', '1.1.1.1')
    variable_manager.set_host_variable(host2, 'ansible_host', '2.2.2.2')

    # Test that deepcopy on hostvars does not raise an exception
    deep

# Generated at 2022-06-23 15:07:55.243632
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager

    vars_cache = {
        'host1': {
            'var1': 1,
        },
    }

    hostvars = HostVars(
        inventory=None,
        variable_manager=VariableManager(vars_cache=vars_cache),
        loader=None,
    )

    # Assert that HostVars._variable_manager._loader and HostVars._loader
    # are equal
    assert hostvars._loader is hostvars._variable_manager._loader

    # Assert that HostVars._variable_manager._hostvars and hostvars
    # are equal
    assert hostvars is hostvars._variable_manager._hostvars

    # Restore HostVars from pickled state

# Generated at 2022-06-23 15:08:04.881048
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # For testing, we'll use a simple inventory.
    test_host_name = "testhost"
    test_inventory = dict(
        hosts=[test_host_name],
        _meta=dict(hostvars=dict())
    )

    # We'll set a persistent fact for the test host.
    test_persistent_fact_name = "persistent_fact"
    test_persistent_fact = "known_in_advance"

    # We'll set a non-persistent fact for the test host.
    test_nonpersistent_fact_name = "nonpersistent_fact"
    test_nonpersistent_fact = "unknown_in_advance"

    # Setup the inventory, and add the persistent fact.
    test_host = Inventory(host_list=test_inventory['hosts'])

# Generated at 2022-06-23 15:08:12.886535
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import copy
    import pprint
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    hostvars = HostVars(
        inventory=Inventory(),
        variable_manager=VariableManager(),
        loader=None
    )

    hostvars.set_host_variable(
        host=None,
        varname='foo',
        value='bar'
    )

    state = hostvars.__getstate__()

    # Modify data and make sure it is restored after unpickling
    state['_variable_manager'] = None
    hostvars.__setstate__(state)

    assert hostvars._variable_manager is not None
    assert hostvars._variable_manager._hostvars is not None
    assert hostvars._variable_manager._hostvars is hostvars
   

# Generated at 2022-06-23 15:08:18.687710
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DictDataLoader({})
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=inventory.get_variable_manager())

    # Return empty dict when there is no host with the specified name
    assert hostvars.raw_get('does_not_exist') == {}

    # Return dict with hostvars of the host with the specified name
    inventory.add_host("localhost")
    hostvars.set_variable_manager(inventory.get_variable_manager())

# Generated at 2022-06-23 15:08:28.521251
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager

    inventory = FakeInventory()
    loader = FakeLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('host', 'var1', 123)
    assert hostvars.raw_get('host')['var1'] == 123

    assert hostvars['host']['var1'] == 123
    hostvars.set_host_variable('host', 'var1', 'def')
    assert hostvars['host']['var1'] == 'def'
    hostvars.set_host_variable('host', 'var1', '{{ abc }}')
    assert hostvars['host']['var1'] == 'def'


# Generated at 2022-06-23 15:08:35.512407
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Host, Inventory
    from ansible.vars import VariableManager

    host = Host(name='host')
    facts = {'fact1': 'value1', 'fact2': 'value2'}
    inventory = Inventory()
    inventory.add_host(host, 'group1')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager)
    hostvars.set_host_facts(host, facts)

    assert host.get_facts() == facts


# Generated at 2022-06-23 15:08:47.173946
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, 'localhost,')
    variable_manager = VariableManager(loader, inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert (hostvars._variable_manager == variable_manager)
    assert (variable_manager._hostvars == hostvars)
    assert (variable_manager._loader == loader)

    variable_manager._hostvars = None
    variable_manager._loader = None

    hostvars.set_variable_manager(variable_manager)

    assert (hostvars._variable_manager == variable_manager)

# Generated at 2022-06-23 15:08:55.532163
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    i = Inventory()
    h = i.get_host('localhost')
    h.set_variable('foo', 'bar')
    h = i.get_host('example.com')
    h.set_variable('foo', 'baz')

    hv = HostVars(i, VariableManager(), None)

    assert set(['localhost', 'example.com']) == set(hv)
