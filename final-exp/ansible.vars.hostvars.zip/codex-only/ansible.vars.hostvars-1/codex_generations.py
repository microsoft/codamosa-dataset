

# Generated at 2022-06-23 14:59:01.532280
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # HostVars._variable_manager['vars_plugins']['test_var_manager_unset'] = lambda x: {}
    # set_variable_manager(VariableManager())
    # set_inventory(Inventory(loader=None, variable_manager=_variable_manager, host_list=host_list))

    # _hostvars = HostVars(inventory=_inventory, variable_manager=_variable_manager, loader=_loader)

    pass

# Generated at 2022-06-23 14:59:08.643795
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from .vars_plugins import VarsModule
    inv = VarsModule()
    vm = VarsModule()
    loader = VarsModule()
    hv = HostVars(inv, vm, loader)
    assert hv._inventory is inv

    save_dict = hv.__getstate__()
    state = dict()
    state['_inventory'] = 'inv'
    state['_loader'] = 'loader'
    state['_variable_manager'] = 'vm'
    hv.__setstate__(state)
    assert hv._inventory is 'inv'
    assert hv._loader is loader
    assert hv._variable_manager is 'vm'
    assert vm._loader is 'loader'
    assert vm._hostvars is hv
    hv.__setstate__(save_dict)
    assert hv

# Generated at 2022-06-23 14:59:16.182758
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import jinja2

    loader = jinja2.Environment()

    variables = {
        'hello': 'world',
        'foo': 'bar',
    }

    hostvars = HostVarsVars(variables, loader=loader)

    assert hostvars['hello'] == 'world'
    assert hostvars['foo'] == 'bar'

    assert len(hostvars) == 2

    assert list(hostvars) == ['hello', 'foo']

    # dict()
    assert dict(hostvars) == variables

    # repr()
    assert repr(hostvars) == repr(variables)

    # in
    assert 'hello' in hostvars

# Generated at 2022-06-23 14:59:23.719838
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    """Ensure that HostVars.set_variable_manager works correctly"""
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    Playbook.setup_loader()
    variable_manager = VariableManager()
    context = PlayContext(variable_manager=variable_manager)
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=Playbook.loader)
    variable_manager2 = VariableManager()
    hostvars.set_variable_manager(variable_manager=variable_manager2)
    assert hostvars._variable_manager is variable_manager2
    assert variable_manager2._hostvars is hostvars

# Generated at 2022-06-23 14:59:34.065039
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader, 'NO_FILE')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    # Add a host to hostvars
    host = inventory.get_host('foo')
    if host is None:
        inventory.add_host(host='foo')
        host = inventory.get_host('foo')
    hostvars.set_host_variable(host=host, varname='testvar', value=25)
    # Get hostvars
    hv = hostvars['foo']
    # Check that the method

# Generated at 2022-06-23 14:59:38.441070
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    # Create instance of HostVars.
    hostvars = HostVars(
        inventory = None,
        loader = None,
        variable_manager = None
    )

    # Call __deepcopy__ method.
    hostvars_copy = copy.deepcopy(hostvars)

    # Test result.
    assert hostvars is hostvars_copy

# Generated at 2022-06-23 14:59:43.138252
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import pytest

    hostvars = HostVars(object, object, object)
    with pytest.raises(NotImplementedError) as excinfo:
        iter(hostvars)
    assert 'The __iter__ method of class HostVars must be overridden in ' \
        'a subclass' in str(excinfo)

# Generated at 2022-06-23 14:59:47.372567
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    # Isolate the test from the builtin variables' values
    loader = DictDataLoader({})
    variables = VariableManager(loader=loader)

    HostVarsVars({}, loader)

    assert HostVarsVars({'a': '{{b}},{{ c }}'}, loader)['a'] == ',', (
        "variable 'b' and 'c' are not defined, so their value should be an empty string"
    )

# Generated at 2022-06-23 14:59:49.209115
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Use attached ticket
    pass



# Generated at 2022-06-23 14:59:59.597746
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host

    host = Host('localhost')
    host.set_variable('var1', True)
    host.set_variable('var2', 1)
    host.set_variable('var3', "foo")

    host2 = Host('127.0.0.1')
    host2.set_variable('var1', False)
    host2.set_variable('var2', 2)
    host2.set_variable('var3', "bar")

    inventory = type("Inventory", (object,), {})
    inventory.hosts = [host, host2]

    variable_manager = type("VariableManager", (object,), {})
    variable_manager.add_host_variable = lambda a, b, c: None

    loader = type("Loader", (object,), {})

# Generated at 2022-06-23 15:00:10.888063
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import os
    import sys
    import json

    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import plugin_loader
    from ansible.vars.manager import VariableManager

    def load_plugins():
        ''' Loads most of available plugins '''


# Generated at 2022-06-23 15:00:18.211281
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(None, None)

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    hostvars = HostVars(inventory, variable_manager, loader)

    try:
        assert len(hostvars) == 0
    except AttributeError:
        raise AssertionError("HostVars object is iterable even though it contains no items")

# Generated at 2022-06-23 15:00:29.262465
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    # Ansible's module_utils.common._collections_compat.Mapping is not a
    # built-in type and it does not inherit from
    # builtins.frozendict.frozendict. Therefore the test raises an error
    # here and not in the tested method __getitem__.
    #
    # Error message:
    #     AttributeError: __deepcopy__
    #
    # See also issue #28236: https://github.com/ansible/ansible/issues/28236
    import copy
    import ansible.module_utils.common._collections_compat
    assert issubclass(ansible.module_utils.common._collections_compat.Mapping, copy.deepcopy)

    import os
    import ansible.constants
    from ansible.template import Templar

# Generated at 2022-06-23 15:00:34.957694
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars import VariableManager

    h1 = dict(a = 1)
    h2 = dict(b = 2)
    inv = dict(hosts = [ 'host1', 'host2'],
               vars = dict(hostvars = dict(host1 = h1,
                                           host2 = h2
                                          )
                          )
              )

    vm = VariableManager()
    vm.set_inventory(inv)
    hv = HostVars(inventory=vm._inventory, variable_manager=vm, loader=None)
    assert len(hv) == 2


# Generated at 2022-06-23 15:00:43.891577
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.manager import VariableManagerError
    from ansible.vars.hostvars import HostVars

    plugin_loader = get_all_plugin_loaders()

    inventory = InventoryManager(loader=plugin_loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=plugin_loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=plugin_loader)

# Generated at 2022-06-23 15:00:48.212295
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    inv = Inventory(loader=None, variable_manager=VariableManager(), host_list=[])

    # this should run without errors
    HostVars(inv, VariableManager(), None).set_inventory(inv)


# Generated at 2022-06-23 15:00:49.568082
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    assert HostVarsVars({}, None) is not None


# Generated at 2022-06-23 15:00:56.765535
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    host = Host()
    host.name = 'foo'
    host.vars['bar'] = 'baz'
    hostvars = HostVars(inventory=None, variable_manager=VariableManager(loader=loader), loader=loader)
    hostvars.set_variable_manager(VariableManager(loader=loader))
    hostvars._find_host = lambda x: host
    hostvars._vars = dict()
    hostvars._loader = DataLoader()


# Generated at 2022-06-23 15:01:05.651551
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.plugins.loader import add_all_plugin_dirs

    # Load plugins so we can use them in tests
    add_all_plugin_dirs()

    inventory = Inventory("")
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager._options = variable_manager.get_vars(loader=None, play=None)
    play_context = PlayContext(variable_manager=variable_manager)
    variable_manager.set_play_context(play_context)

    play = Play().load({}, variable_manager=variable_manager, loader=None)

    inventory.add_host

# Generated at 2022-06-23 15:01:07.171690
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    _len = len({'a': 1, 'b': 2})
    assert _len == 2


# Generated at 2022-06-23 15:01:14.346681
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Mock out the inventory, which is the source of truth for number of hosts.
    inventory = type('MockInventory', (), {'hosts': [1, 2, 3]})()

    # Mock out the variable manager, but allow the original methods through.
    mgr = type('MockVariableManager', (), {
        'get_vars': lambda self, host: None,
        'get_host_variables': lambda self, host: None,
        'extra_vars': {},
        'options': None,
        '_fact_cache': None,
        '_vars_cache': None,
        '_hostvars': None,
        '__getstate__': lambda self: {},
        '__setstate__': lambda self, state: None,
        '_loader': None,
    })()

    # Create a

# Generated at 2022-06-23 15:01:19.359593
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    hv = HostVars(inventory=Inventory(loader=None, host_list=['a', 'b']),
                  variable_manager=VariableManager(loader=None, inventory=None),
                  loader=None)
    assert [x for x in hv] == ['a', 'b']



# Generated at 2022-06-23 15:01:29.743948
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import sys
    import os
    import unittest
    # Load modules needed for the tests
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.abspath(__file__), '..', '..')))
    from ansible.inventory.manager import InventoryManager # noqa
    from ansible.playbook.play import Play # noqa
    from ansible.module_utils.common._collections_compat import Iterable # noqa
    from ansible.vars.manager import VariableManager # noqa
    from ansible.template import Templar # noqa

    class HostVarsTestCase(unittest.TestCase):
        def setUp(self):
            super(HostVarsTestCase, self).setUp()

            # Use inventory file for localhost
            inventory = Inventory

# Generated at 2022-06-23 15:01:40.208656
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm_args = dict(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 15:01:45.576162
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    hostvars = HostVarsVars({'key': '{{value}}'}, loader=loader)
    assert 'key' in hostvars
    assert 'value' in hostvars
    assert 'not_exist' not in hostvars

# Generated at 2022-06-23 15:01:56.844068
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager

    some_hosts = {
        'localhost': {
            'ansible_connection': 'local',
            'inventory_hostname': 'localhost',
        },
    }

    inv = inventory_loader.get('dynamic', some_hosts)
    var_manager = VariableManager(loader=None, inventory=inv)
    hv = HostVars(inventory=inv, variable_manager=var_manager, loader=None)

    # Create a copy of hv with pickle.
    # We need to do a copy because __getstate__ of var_manager will
    # clear _hostvars and _loader attributes of var_manager.
    import pickle

# Generated at 2022-06-23 15:02:06.046924
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy.linear import StrategyModule

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 15:02:16.256241
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import sys
    # VariableManager object is also tested here.
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def _find_host(inventory, host_name):
        # does not use inventory.hosts so it can create localhost on demand
        return inventory.get_host(host_name)

    class MockLoader():
        def __init__(self):
            pass
        def set_basedir(self, basedir):
            pass

    class MockOptions():
        def __init__(self):
            self._basedir = '.'
            self._inventory = 'fake'

    # Initialization
    mock_loader = MockLoader()
    mock_options = MockOptions()
    mock_inventory = InventoryManager(mock_loader, sources=mock_options._inventory)

   

# Generated at 2022-06-23 15:02:24.187996
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inv)
    play_context = PlayContext()
    hostvars = HostVars(inv, variable_manager, loader)

    host = inv.get_host('test_host')

    # Get the first host
    host0 = hostvars.raw_get(host)

    # == test for HostVars
    hostvars[host] == host0

# Generated at 2022-06-23 15:02:31.857779
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager()
    loader = Mock()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._inventory == inventory

    inventory = InventoryManager()
    hostvars.set_inventory(inventory)
    assert hostvars._inventory == inventory


# Generated at 2022-06-23 15:02:36.328433
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    variable_manager = DummyVariableManager()
    call_list = []
    variable_manager.set_vars_cache = lambda: call_list.append('set_vars_cache')
    hv = HostVars(DummyInventory(), variable_manager, DummyLoader())
    assert call_list == []
    hv.set_host_variable(DummyHost(), 'var', 'val')
    assert call_list == ['set_vars_cache']


# Generated at 2022-06-23 15:02:46.939922
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():

    loader = None

    variables = {
        "a": 1,
        "b": 2
    }

    hostvars_vars_obj = HostVarsVars(variables=variables, loader=loader)

    assert hostvars_vars_obj["a"] == 1
    assert hostvars_vars_obj["b"] == 2

    hostvars_vars_obj = HostVarsVars(variables=variables, loader=loader)

    assert "a" in hostvars_vars_obj
    assert "b" in hostvars_vars_obj

    assert len(hostvars_vars_obj) == 2

    assert "a" in hostvars_vars_obj
    assert "b" in hostvars_vars_obj


# Generated at 2022-06-23 15:02:54.652239
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.inventory.host import Host

    _loader = DataLoader()
    _inventory = InventoryManager(_loader)
    _variable_manager = VariableManager(_loader)
    hostname = "testhost"
    variables = dict(foo='bar', bam='baz', one='two')
    host = Host(hostname)
    hosts = [host]
    _inventory.add_group('testgroup')
    _inventory.add_host(hostname, group='testgroup')
    _inventory.set_variables(hostname, variables)

    hostvars = HostVars(_inventory, _variable_manager, _loader)

# Generated at 2022-06-23 15:03:02.195254
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = MockInventory([]);
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    assert repr(hostvars) == '{}'

    inventory = MockInventory(['localhost']);
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    assert repr(hostvars) == "{'localhost': {}}"

    inventory = MockInventory(['localhost']);
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    variable_manager.set_nonpersistent_facts(hostvars._find_host('localhost'), {'foo': 'bar'})

# Generated at 2022-06-23 15:03:08.649028
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.plugins.loader import add_all_plugin_dirs, find_plugin
    from ansible.inventory.manager import InventoryManager

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.facts import Facts
    import os

    # add all plugin directories to the path so that plugins can be found
    current_dir = os.path.dirname(os.path.realpath(__file__))
    add_all_plugin_dirs(
        [os.path.join(current_dir, '../../plugins'), os.path.join(current_dir, '../../contrib/inventory')],
        subdirs_only=True)

    # create the inventory, which uses the custom inventory plugin

# Generated at 2022-06-23 15:03:18.414721
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory=inventory)

    facts = {'shell': '/bin/foosh'}

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    inventory.add_host(host='testhost', group='ungrouped')
    host = inventory.get_host(host='testhost')
    hostvars.set_host_facts(host, facts)


# Generated at 2022-06-23 15:03:23.597080
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = None
    v = {'hostvars': {'foo': 'bar'}}
    v1 = HostVarsVars(v, loader)
    assert type(v1) == HostVarsVars
    assert v1['hostvars']['foo'] == 'bar'
    assert len(v1) == 1

# Generated at 2022-06-23 15:03:34.452399
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.cli import CLI
    import sys

    cli = CLI(sys.argv[1:])
    loader, inventory, variable_manager = cli.setup()

    # Create HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Store HostVars object
    hostvars_copy = hostvars.copy()
    state = hostvars_copy.__getstate__()

    # Recreate HostVars object from stored state
    hostvars = HostVars(None, None, None)
    hostvars.__setstate__(state)

    # Assert data of HostVars
    assert hostvars._inventory
    assert hostvars._loader
    assert hostvars._variable

# Generated at 2022-06-23 15:03:43.249141
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory, Host
    from ansible.vars.manager import VariableManager

    inv = Inventory(loader=None)
    inv.add_host(Host("example.com"))
    var_manager = VariableManager(loader=None, inventory=inv)
    var_manager.extra_vars = dict(foo="bar")
    hostvars = HostVars(inventory=inv, variable_manager=var_manager, loader=None)

    assert hostvars.raw_get("example.com").get("foo") == "bar"
    assert hostvars.raw_get("example.com").get("bar", "default") == "default"
    assert isinstance(hostvars.raw_get("nonexistent-host"), AnsibleUndefined)

# Generated at 2022-06-23 15:03:53.730453
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # TODO: move it out of here and into unit tests, probably to
    # test/units/inventory/test_hostvars.py
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.inventory.host import Host

    # Data structure used to test set_nonpersistent_facts method of class HostVars
    class TestData(object):
        all_hosts_orig = {}
        all_hosts_updated = {}
        host_vars = HostVars(inventory=None)

    # Create a test data object
    test_data = TestData()

    # Save original hosts and vars
    inventory = InventoryManager

# Generated at 2022-06-23 15:04:00.588547
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    class FakeVariableManager:
        def __init__(self):
            self._hostvars = None

    class FakeInventory:
        def __init__(self):
            self.hosts = []

        def get_host(self, host_name):
            return None

    class FakeLoader:
        pass

    hostvars = HostVars(FakeInventory(), FakeVariableManager(), FakeLoader())
    hostvars.set_variable_manager(FakeVariableManager())
    assert hostvars._variable_manager._hostvars == hostvars

# Generated at 2022-06-23 15:04:11.621982
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    def mock_template(data, faile_on_undefined=False, static_vars=None):
        return data

    variables = {"f_name": "foo", "b_name": "bar"}
    test_obj = HostVarsVars(variables, mock_template)
    result = test_obj.__getitem__("f_name")
    assert(result == "foo")
    result = test_obj.__contains__("b_name")
    assert(result == True)
    result = test_obj.__contains__("bar")
    assert(result == False)
    result = test_obj.__iter__()
    assert(result == variables.keys())
    result = test_obj.__len__()
    assert(result == len(variables.keys()))
    result = test_obj.__

# Generated at 2022-06-23 15:04:22.193734
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ hostvars["localhost"]["foo"] }}')))
        ]
    )

    # Create play with tasks
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    # Create inventory and pass to var manager


# Generated at 2022-06-23 15:04:24.908973
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = {'first_var': 'first_value', 'second_var': 'second_value'}
    loader = None
    host_vars_vars = HostVarsVars(variables, loader)

    assert len(host_vars_vars) == 2

# Generated at 2022-06-23 15:04:36.487910
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_mgr = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_mgr, loader)

    # create a set of hosts to iterate over
    host_names = ['host1', 'host2', 'host3']
    for name in host_names:
        host = inventory.add_host(name)
        host.set_variable('ansible_ssh_host', name)
    inventory.reconcile_inventory()

    # iterate and generate a set of host names
    result = set()

# Generated at 2022-06-23 15:04:43.456687
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(['localhost', '127.0.0.1'])
    inventory.hosts['localhost'].vars['var1'] = 1
    hostvars = HostVars(inventory, VariableManager(), None)

    repr_out = repr(hostvars)
    assert repr_out == "{'localhost': {}, '127.0.0.1': {'var1': 1}}"

# Generated at 2022-06-23 15:04:55.538855
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(hostvars) == 0

    inventory.add_host(host='host1')
    assert len(hostvars) == 1

    inventory.add_host(host='host2')
    assert len(hostvars) == 2

    inventory.add_host(host='host3')
    assert len(hostvars) == 3

    inventory.clear_pattern_cache()


# Generated at 2022-06-23 15:04:59.987886
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inv = InventoryManager(["localhost"])
    var = VariableManager(loader=None, host_list=inv.hosts)

    assert len(HostVars(inv, var, loader=None)) == 1



# Generated at 2022-06-23 15:05:06.425892
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.plugins.loader import variable_manager

    hostvars = HostVars(None, variable_manager, None)
    hostvars.set_nonpersistent_facts('host', {'foo': 'value'})

    assert hostvars._variable_manager._nonpersistent_facts['host']['foo'] == 'value'

# Generated at 2022-06-23 15:05:17.477211
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    class MockInventory:
        def __init__(self, hostvars):
            self._hostvars = hostvars
        def get_host(self, host_name):
            return self._hostvars.get(host_name)
        def get_hosts(self, pattern='all'):
            return self._hostvars.keys()

    class MockVariableManager:
        def __init__(self, vars_cache):
            self._vars_cache = vars_cache
        def _get_vars_from_file(self, host):
            return {}
        def get_vars(self, host, include_hostvars=True):
            return self._vars_cache.get(host, {})
        def set_host_variable(self, host, varname, value):
            self._vars

# Generated at 2022-06-23 15:05:25.429939
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Create a HostVars
    hosts = {'host1': {'a': 'A'}, 'host2': {'b': 'B'}}
    hostvars = {'host1': {'a': 'A', 'b': 'B'}, 'host2': {'a': 'A', 'b': 'B'}}
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=hosts)
    variable_manager = VariableManager(loader=loader, inventory=inv)

# Generated at 2022-06-23 15:05:37.771896
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import os
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import variable_manager_loader
    import pytest

    current_loader = DataLoader()
    hostvars = HostVars(inventory=InventoryManager(loader=current_loader, sources=[]), variable_manager=None, loader=current_loader)
    variable_manager = variable_manager_loader.get('vars', loader=current_loader, inventory=InventoryManager(loader=current_loader, sources=[]))
    variable_manager.set_loader(current_loader)
    variable_manager._extra_vars = dict(foo='bar')
    variable_manager._options_vars = dict()
    variable_manager

# Generated at 2022-06-23 15:05:38.390563
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert True

# Generated at 2022-06-23 15:05:49.115335
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    def test_hostvars_getitem(hostvars, host_name):
        '''
        :param hostvars: instance of HostVars
        :param host_name: host for which the data should be returned
        :return: return value of variable manager get_vars function
        '''
        host = hostvars._find_host(host_name)
        return hostvars._variable_manager.get_vars(host)

    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # expected vars of localhost

# Generated at 2022-06-23 15:05:55.989846
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Init
    data = {u'a': u'1', u'b': u'{{ a }}'}
    loader = None

    # Test
    host_vars_vars = HostVarsVars(data, loader)
    assert host_vars_vars[u'a'] == u'1'
    assert host_vars_vars[u'b'] == u'1'


# Generated at 2022-06-23 15:06:05.351349
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    vars_cache = {
        "localhost": {
            "a": 1,
            "b": 2
        },
        "otherhost": {
            "a": 3,
            "c": 4
        }
    }

    pb = Play()
    pb.vars_prompt = {}
    pb.become_prompt = {}

    variable_manager = VariableManager(pb)
    variable_manager.vars_cache = vars_cache

    HostVars(None, variable_manager, None)

    # Test that __contains__ returns False if hostname is absent in vars_cache
    assert 'nonexisting' not in vars_cache

# Generated at 2022-06-23 15:06:15.563315
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVarsVars

    # Create data loader
    dummy_loader = DataLoader()
    dummy_loader.set_basedir("/some/path")

    # Create inventory
    dummy_inventory = Inventory(loader=dummy_loader, variable_manager=VariableManager(), host_list="/dev/null")

    # Create HostVarsVars

# Generated at 2022-06-23 15:06:23.001643
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    # Test with an empty dict
    hvvars = HostVarsVars({}, loader=None)
    assert len(hvvars) == 0

    # Test with a dict of 5 elements
    hvvars = HostVarsVars({'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': 'value5'}, loader=None)
    assert len(hvvars) == 5


# Generated at 2022-06-23 15:06:33.993412
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # Create empty inventory
    import ansible.inventory
    inventory = ansible.inventory.Inventory()

    # Create empty variable manager
    import ansible.vars.manager
    variable_manager = ansible.vars.manager.VariableManager()

    # Create empty loader
    import ansible.parsing.dataloader
    loader = ansible.parsing.dataloader.DataLoader()

    # Create empty HostVars object
    hostvars = HostVars(inventory, variable_manager, loader)

    # Assign new inventory to object
    import copy
    new_inventory = copy.deepcopy(inventory)
    hostvars.set_inventory(new_inventory)

    # Check that hostvars._inventory is the same as new_inventory
    assert hostvars._inventory is new_inventory

    return True

# Generated at 2022-06-23 15:06:41.620456
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.plugins.loader import module_loader

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    test_inventory = ansible.inventory.Inventory(loader=DataLoader())
    test_inventory.add_host(ansible.inventory.Host("test_host1"))
    test_inventory.add_host(ansible.inventory.Host("test_host2"))
    test_loader = DataLoader()
    test_variable_manager = VariableManager(loader=test_loader, inventory=test_inventory)
    test_HostVars = HostVars(test_inventory, test_variable_manager, test_loader)



# Generated at 2022-06-23 15:06:49.760117
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    # test function HostVarsVars.__init__(variables, loader)
    # with None variables should raise TypeError
    variables = None
    loader = None
    try:
        hostvarsvars = HostVarsVars(variables, loader)
    except TypeError as e:
        err = str(e)
        assert err == "__init__() missing 1 required positional argument: " \
                      "'variables'", "hostvarsvars.__init__(None, None) " \
                      "raised TypeError: %s" % err
    else:
        raise AssertionError("HostVarsVars(None, None) should raise TypeError")

    # with not dict variables should raise TypeError
    variables = "foo"
    loader = None

# Generated at 2022-06-23 15:06:52.916443
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():

    hv_vars = HostVarsVars({'foo': 'bar'}, loader=None)
    assert len(hv_vars) == 1



# Generated at 2022-06-23 15:07:00.039200
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(host_list=[])
    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory=inventory,
                        variable_manager=variable_manager,
                        loader=loader)

    host = inventory.get_host('localhost')
    facts = dict(FACTS='ansible')
    hostvars.set_host_facts(host, facts)
    assert hostvars.get(host)['ansible_facts'] is facts

# Generated at 2022-06-23 15:07:09.323417
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    hostvars = {
        "foo": "bar",
        "baz": "{{ qux }}",
        "qux": "quux"
    }

    hostvars_vars = HostVarsVars(hostvars, loader=None)
    repr_hostvars_vars = repr(hostvars_vars)

    repr_hostvars_vars_expected = "{\'baz\': u\'quux\', \'foo\': u\'bar\', \'qux\': u\'quux\'}"
    assert repr_hostvars_vars == repr_hostvars_vars_expected

# Generated at 2022-06-23 15:07:16.550699
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)
    hostvars.set_nonpersistent_facts(host=inventory.get_host('localhost'),
                                     facts=dict(setup_cache=None, ansible_facts=dict()))

# Generated at 2022-06-23 15:07:28.226175
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def _init_variable_manager(loader):
        return VariableManager(loader=loader)

    f = {
        u'host01': {
            u'hosts': [u'host01'],
            u'vars': {
                u'hostvar01': u'host01_var01',
            }
        },
        u'host02': {
            u'hosts': [u'host02'],
            u'vars': {
                u'hostvar01': u'host02_var01',
            }
        }
    }

    inventory = InventoryManager(loader=DataLoader())
    inventory.add_group(u'g')

# Generated at 2022-06-23 15:07:37.829760
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory, Host
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, host_list=['foo.example.org'])
    host = inventory.get_host('foo.example.org')
    play_context = PlayContext(remote_addr='1.2.3.4')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_host_variable(host, 'foo', 'bar')
    variable_manager.set_host_variable(host, 'baz', 'bat')


# Generated at 2022-06-23 15:07:48.341219
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager

    vars_file_data = {
        'test': 'test',
        'test1': 'test1',
    }

    vars_file_name = 'test_file'
    vars_file = { vars_file_name: vars_file_data }

    inventory = DummyInventory(host_list=['test_host'])
    loader = DummyLoader(path_list=[])

    variable_manager = VariableManager(inventory=inventory, loader=loader, use_task_vars=False,
                                       vault_password=None, hostvars=None)
    variable_manager._hostvars = None

    variable_manager._vars_from_file = vars_file

# Generated at 2022-06-23 15:08:00.882900
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    hostvars = HostVars(inventory, variable_manager, loader)

    variable_manager.set_nonpersistent_facts(inventory.hosts, dict(key1="value"))
    assert variable_manager.get_vars(host=inventory.hosts)["key1"] == "value"
    variable_manager.set_nonpersistent_facts(inventory.hosts, dict(key1="value1", key2="value2"))

# Generated at 2022-06-23 15:08:10.912579
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode

    loader = DummyLoader()

    # deepcopy should work with HostVars as an ordinary python dict
    hv = HostVars(
        inventory=DummyInventory(hosts=["host.example.com"]),
        loader=loader,
        variable_manager=DummyVariableManager(loader=loader, variables={"foo": "bar"}),
    )

    hv_copy = copy.deepcopy(hv)
    assert hv is not hv_copy

    # deepcopy should work with HostVars as a value of other variables' dict

# Generated at 2022-06-23 15:08:13.573860
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    assert repr(hv) == repr({})

# Generated at 2022-06-23 15:08:22.175662
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # Arrange
    mock_inventory = Mock()
    mock_variable_manager = Mock()
    mock_loader = Mock()
    hostvars = HostVars(inventory=mock_inventory, variable_manager=mock_variable_manager, loader=mock_loader)
    host_name = "fake_host_name"

    # Act
    result = host_name in hostvars

    # Assert
    assert result == (mock_inventory.get_host.return_value is not None)
    mock_inventory.get_host.assert_called_once_with(host_name)


# Generated at 2022-06-23 15:08:30.969048
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    iter_results = []

    data = {'one': '1', 'two': 2, 'three': ['3a', '3b'], 'four': {'5': 5}}

    def load_config_data(path):
        return data

    loader = 'dummy'
    loader.load_config_data = load_config_data

    hostvars_vars = HostVarsVars(data, loader)

    for var in hostvars_vars:
        iter_results.append(var)

    assert iter_results == ['one', 'two', 'three', 'four']


# Generated at 2022-06-23 15:08:42.975975
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():

    variables = dict(
        host1=dict(a=1, b=2, c=3),
        host2=dict(a=4, b=5, c=6),
        host3=dict(a=7, b=8, c=9),
    )

    expected = dict(
        host1=dict(a=1, b=2, c=3),
        host2=dict(a=4, b=5, c=6),
        host3=dict(a=7, b=8, c=9),
    )

    from ansible.template import Templar
    templar = Templar(loader=None)
    actual = templar.template(variables, fail_on_undefined=False, static_vars=STATIC_VARS)


# Generated at 2022-06-23 15:08:51.358418
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    '''
    Make sure that method __setstate__ correctly restores the object state
    and saves the memory by not creating new object instances.
    '''
    # pylint: disable=protected-access

    # Prepare Mock objects
    mock_loader = _MockLoader()
    mock_inventory = _MockInventory(loader=mock_loader)
    mock_variable_manager = _MockVariableManager(loader=mock_loader)

    # Verify that mock loader and mock inventory are not used yet
    assert mock_inventory._used == 0
    assert mock_loader._used == 0

    # Create the object
    hostvars = HostVars(inventory=mock_inventory, variable_manager=mock_variable_manager, loader=mock_loader)

    # Verify that mock loader and mock inventory are used
    assert mock_inventory._used

# Generated at 2022-06-23 15:08:58.750744
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    """
    HostVars.__contains__

    We cannot test this without the inventory and variable_manager, so
    at least do something basic.
    """

    class Foo:
        def __init__(self):
            self.vars = {}

    host_vars = HostVars(foo, foo, foo)
    host_vars._find_host = lambda x: x == 'test'
    host_vars._variable_manager = Foo()

    assert 'test' in host_vars
    assert 'test2' not in host_vars