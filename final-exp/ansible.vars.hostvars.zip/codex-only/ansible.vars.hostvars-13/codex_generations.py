

# Generated at 2022-06-23 14:58:58.725597
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.parsing.vault import VaultLib
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(None)

# Generated at 2022-06-23 14:59:06.945214
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import sys
    if sys.version_info[0] >= 3:
        repr_result = "{\'test_int\': 3, \'test_float\': 3.2, \'test_list\': [1, 2, 3], " + \
                      "\'test_string\': \'ansible\', \'test_dict\': {u\'test_dict_key\': " + \
                      "\'test_dict_value\'}}"
    else:
        repr_result = "{'test_int': 3, 'test_float': 3.2, 'test_list': [1, 2, 3], " + \
                      "'test_string': 'ansible', 'test_dict': {'test_dict_key': " + \
                      "'test_dict_value'}}"

# Generated at 2022-06-23 14:59:15.046485
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = DictDataLoader({})
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hvv = HostVarsVars(hostvars['localhost'], loader)

    assert len(hvv) == len(hostvars['localhost'])
    assert isinstance(hvv[list(hvv)[0]], AnsibleUndefined)

# Generated at 2022-06-23 14:59:23.320666
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Host, Inventory
    from ansible.parsing.dataloader import DataLoader

    variables = dict(key1='value1')
    host = Host(name='testhost')
    host.set_variable('key1', variables['key1'])
    inventory = Inventory(loader=DataLoader())
    inventory.add_host(host)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
    hostvars_vars = hostvars['testhost']
    assert isinstance(hostvars_vars, HostVarsVars)
    assert hostvars_vars == variables

# Generated at 2022-06-23 14:59:33.688228
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import os
    import tempfile
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    fd, path = tempfile.mkstemp(prefix='ansible_test_inventory_')
    os.write(fd, b'[test_group]\nlocalhost')
    os.close(fd)
    inventory = Inventory(loader=None,  # to avoid loading from a config
                          variable_manager=None,  # to avoid looking for a config
                          host_list=path)
    inventory.parse_inventory(inventory)
    hostvars = HostVars(inventory, VariableManager(), None)

    assert hostvars._variable_manager is None
    hostvars.set_variable_manager(VariableManager())
    assert hostvars._variable_manager is not None

# Generated at 2022-06-23 14:59:35.428158
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    hostvars = HostVars({'foo': 'bar'})

    assert len(hostvars) == 1

    hostvars._inventory.hosts = []
    assert len(hostvars) == 0



# Generated at 2022-06-23 14:59:39.765871
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    variables = {
        "foo": "1",
        "bar": "2",
        "baz": "3"
    }
    x = HostVarsVars(variables, None)
    assert repr(x) == repr(variables)

# Generated at 2022-06-23 14:59:50.624830
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class FakeVariables(Mapping):
        def __init__(self, fake_vars):
            self._fake_vars = fake_vars
        def __getitem__(self, var):
            return self._fake_vars[var]
        def __contains__(self, var):
            return (var in self._fake_vars)
        def __iter__(self):
            for var in self._fake_vars.keys():
                yield var
        def __len__(self):
            return len(self._fake_vars.keys())

    class FakeLoader():
        pass

    fake_loader = FakeLoader()
    module_name = 'fake_module'
    fake_vars = {module_name: 'fake_module_value'}

# Generated at 2022-06-23 14:59:55.412936
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host_vars = HostVars(inventory, variable_manager, loader)

    # set variables for localhost
    localhost_vars = dict(a=1, b=2)
    localhost = inventory.add_host(name='localhost')
    for key, value in localhost_vars.items():
        variable_manager.set_host_variable(localhost, key, value)

    # make sure we see the same variables when we get them through the
    # HostVars view of vars_

# Generated at 2022-06-23 15:00:06.726653
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    inventory = InventoryManager(loader=DataLoader(), sources=["localhost"])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, variable_manager._loader)
    variable_manager._hostvars = hostvars
    variable_manager.set_host_variable("localhost", "ansible_connection", "local")
    variable_manager.set_host_variable("localhost", "ansible_python_interpreter", "/home/testuser/.pyenv/shims/python")
    variable_manager.set_host_variable("localhost", "ansible_check_mode", "True")
    variable

# Generated at 2022-06-23 15:00:14.358728
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    class FakeLoader():
        pass

    class FakeInventory():
        def __init__(self):
            self.hosts = []

        def get_host(self, host_name):
            if host_name in self.hosts:
                return host_name
            return None

        def add_host(self, host_name, groups=None):
            self.hosts.append(host_name)

    class FakeVaultLib(VaultLib):

        def __init__(self, password_files=None, passwords=None):
            super(FakeVaultLib, self).__init__(password_files=password_files, passwords=passwords)

       

# Generated at 2022-06-23 15:00:26.333395
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class MockInventory(object):
        hosts = []
        def get_host(self, host_name):
            return None
    inv = MockInventory()
    inv.hosts.extend(["host1", "host2"])
    class MockVariableManager(object):
        _loader = None
        _hostvars = None
        def set_host_variable(self, host, varname, value):
            pass
        def set_nonpersistent_facts(self, host, facts):
            pass
        def set_host_facts(self, host, facts):
            pass
        def get_vars(self, host=None, include_hostvars=True):
            return AnsibleUndefined()
    vm = MockVariableManager()
    hv = HostVars(inv, vm, None)

# Generated at 2022-06-23 15:00:34.534396
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # We don't need full-featured classes here
    class Loader:
        pass

    class VariableManager:
        def __init__(self, loader, inventory):
            self._loader = loader
            self._inventory = inventory
            self._hostvars = HostVars(inventory, self, loader)
            self._options_vars = dict()

        def get_vars(self, loader, host=None, include_hostvars=True):
            if host is not None:
                if include_hostvars:
                    return host.get_vars()
                else:
                    return dict()
            elif self._options_vars:
                return self._options_vars
            else:
                return dict()

    class Host:
        def __init__(self, name):
            self._name = name
            self._

# Generated at 2022-06-23 15:00:43.810516
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._loader = loader

    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    variable_manager.set_hostvars(hostvars)

    localhost = Host('localhost')
    inventory.add_host(localhost)

    variable_manager

# Generated at 2022-06-23 15:00:53.873749
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    class DummyLoader:
        pass
    loader = DummyLoader()
    vars = {'foo': 'time {{ ansible_date_time.date }}'}
    hostvars = HostVarsVars(vars, loader)
    assert repr(hostvars) == repr(vars)
    vars['foo'] = UnsafeProxy(vars['foo'], loader=loader)
    hostvars = HostVarsVars(vars, loader)
    assert repr(hostvars) == repr(vars)
    vars['foo'] = {'foo': 'time {{ ansible_date_time.date }}'}
    hostvars = HostVarsVars(vars, loader)

# Generated at 2022-06-23 15:00:55.693894
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({'foo':'bar'}, None)
    assert set(hvv) == set(['foo'])

# Generated at 2022-06-23 15:01:05.098961
# Unit test for method __contains__ of class HostVars

# Generated at 2022-06-23 15:01:13.682859
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import json
    import io
    import sys

    # class HostVarsVars contains another class Templar, which uses its
    # own static member 'logger'.  In the unit test, that static member
    # is set to None by default, so we have to assign a logger to it
    # to avoid the following error:
    #     AttributeError: 'NoneType' object has no attribute 'debug'
    import ansible.template
    ansible.template.Templar.logger = ansible.utils.string_functions.AnsibleLog(io.open(1, 'w', encoding='utf-8', errors='replace'))

    # create fake loader object so Templar object can be created
    # and _templar._loader can be assigned with the fake object

# Generated at 2022-06-23 15:01:17.829423
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    vars = {'a': 'b'}
    vv = HostVarsVars(vars, DataLoader())
    vm = VariableManager(loader=DataLoader())
    vm.set_vars(vv)

    assert repr(vv) == repr(vars)

    # vm.set_vars() overrides the vars, so vv and vm.get_vars() store
    # different vars' dicts.
    assert vm.get_vars() == vars
    assert vv._vars != vars
    # repr(vv) should still be repr(vars) because the vars' dict,
    # which repr() displays, is the same.

# Generated at 2022-06-23 15:01:28.169055
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    data_loader = DataLoader()
    inventory = InventoryManager(loader=data_loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, data_loader)

    host = inventory.get_host('localhost')

    hostvars.set_nonpersistent_facts(host, {'a': 1, 'b': 2, 'c': 3})
    hostvars.set_host_facts(host, {'c': 4, 'd': 5, 'e': 6})


# Generated at 2022-06-23 15:01:31.939336
# Unit test for constructor of class HostVars
def test_HostVars():
    # Note, we don't have all the parameters, but it should not actually try to look up anything
    hostvars = HostVars(None, None, None)
    assert hostvars


# Generated at 2022-06-23 15:01:41.330665
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    def assert_equals(obtained, expected):
        if obtained != expected:
            raise AssertionError("%s != %s" % (obtained, expected))

    import ansible.parsing.dataloader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = ansible.parsing.dataloader.DataLoader()
    path = './test_hostvars_repr/inventory'
    inventory = InventoryManager(loader=loader, sources=path)

    play = Play()
    play.connection = 'local'
    play.hosts = 'all'
    play.serial = 0

# Generated at 2022-06-23 15:01:53.378796
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import ansible.plugins.loader
    import copy
    import io
    import pickle
    import unittest
    from ansible import constants as C
    from ansible.plugins.loader import inventory_loader, vars_processor

    # Create fake vars cache
    vars_cache = {}

    def _fake_get_host_variables(host, include_hostvars=True, q=None):
        return vars_cache.get(host.name, {})

    def _fake_get_group_variables(group, q=None):
        return {}

    # Prepare fake inventory
    loader = ansible.plugins.loader.PluginLoader(
        'Inventory',
        C.DEFAULT_INVENTORY_PLUGIN_PATH,
        'ansible.plugins.inventory'
    )


# Generated at 2022-06-23 15:02:01.839794
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    inventory = Inventory(loader=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars is not deepcopy(hostvars)

    foo = dict(bar=42)
    host = inventory.add_host(host='42', group='example')
    host.vars['foo'] = hostvars

    hostvars.set_host_variable(host, 'foo', foo)
    assert hostvars is host.vars['foo']

    foo_copy = deepcopy(host.vars['foo'])
    assert foo_copy is not foo
    assert foo_copy == foo

# Generated at 2022-06-23 15:02:12.826118
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources=['/dev/null'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    hostvars['foo'] = {}
    hostvars['foo']['bar'] = 'baz'
    hostvars['foo']['boo'] = 'bam'
    hostvars['bab'] = 'bob'

    assert hostvars.get('foo')['bar'] == 'baz'
    assert hostvars.get('foo')['boo'] == 'bam'

# Generated at 2022-06-23 15:02:22.637182
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    class DummyLoader(object):
        def __init__(self):
            self._basedir = '/tmp'

    loader = DummyLoader()

    class DummyHost(object):
        def __init__(self):
            self.name = 'localhost'

    class DummyVariableManager(object):
        def __init__(self):
            self.host_vars = {}
            self.group_vars = {}

    host = DummyHost()
    variable_manager = DummyVariableManager()

    class DummyInventory(object):
        def __init__(self):
            self.hosts = []
            self.groups = {}
            self.vars_cache = {}
            self._vars_per_host = {}
            self.parser = None
            self.host_vars = variable_manager.host_v

# Generated at 2022-06-23 15:02:34.499150
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    loader = 'loader'
    inventory = 'inventory'
    hostvars = HostVars(inventory, None, loader)
    state = {'_loader': None, '_inventory': inventory, '_variable_manager': None}

    # Assign non-None values of loader and hostvars attributes
    hostvars.__setstate__(state)
    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

    # Assign None values of loader and hostvars attributes
    state['_loader'] = loader
    state['_hostvars'] = hostvars
    hostvars.__setstate__(state)
    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

# Generated at 2022-06-23 15:02:40.956274
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    hostvars = HostVars(inventory={'test': Host(name='test')}, variable_manager=VariableManager(), loader=DataLoader())
    result = hostvars['test']
    assert result, result

 # Unit test for method __getitem__ of class HostVarsVars, no error

# Generated at 2022-06-23 15:02:51.098748
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.playbook.play_context
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs()

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader())
    variable_manager._loader = DataLoader()
    variable_manager._hostvars = HostVars(inventory, variable_manager, DataLoader())
    variable_manager.extra_vars=dict()

    play_context = ansible.playbook.play_context.PlayContext()

    hostvars = HostVars(inventory, variable_manager, DataLoader())

   

# Generated at 2022-06-23 15:02:57.110282
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    inventory = mock.Mock()
    variable_manager = VariableManager()
    loader = mock.Mock()
    hostvars = HostVars(inventory, variable_manager, loader)
    variable_manager_new = VariableManager()
    hostvars.set_variable_manager(variable_manager_new)
    assert variable_manager_new is hostvars._variable_manager



# Generated at 2022-06-23 15:03:08.173800
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="tests/inventory")

    v = HostVars(inventory, variable_manager, loader)

    assert sorted(list(v['localhost'].keys())) == sorted(STATIC_VARS)

    # Change inventory results in v['localhost'] pointing to the new inventory's localhost
    inventory = InventoryManager(loader=loader, sources="tests/inventory")
    v.set_inventory(inventory)

    assert sorted(list(v['localhost'].keys())) == sorted(STATIC_VARS)

# Generated at 2022-06-23 15:03:16.678756
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    '''
    Returns an iterator over the variables names.
    '''
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data = dict(one=dict(two=dict(three=dict(four=42))))

    # Create the loader and the variable manager
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    # Create a hostvars object and assign the data
    hostvars = HostVars(None, variable_manager, loader)
    hostvars._variable_manager.set_host_variable(None, 'data', data)

    # Create the templar
    hostvars_vars = hostvars['localhost']

    # Verify the variables iterated

# Generated at 2022-06-23 15:03:26.939621
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Create some fake objects to simulate that they are created before
    # picking HostVars.
    fake_variable_manager = dict()
    fake_loader = dict()

    # Create initial HostVars and initialize it with fake objects
    # which will simulate the objects created before pickling.
    hv = HostVars(None, None, None)
    hv.set_variable_manager(fake_variable_manager)
    hv.set_loader(fake_loader)

    # Pick HostVars and create a copy from the pickle
    hv_pickle = pickle.dumps(hv)
    hv_copy = pickle.loads(hv_pickle)

    # Assign a host and a dict to the copy and call set_nonpersistent_facts
    fake_host = dict()

# Generated at 2022-06-23 15:03:38.056291
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    class Inventory:
        def __init__(self):
            self.hosts = ['localhost']

        def get_host(self, host):
            if host == 'localhost':
                return host

    class VariableManager:
        def __init__(self):
            self._vars_cache = {}

        def get_vars(self, host=None, include_hostvars=True):
            return {'ansible_version': 1}

        def set_host_variable(self, host, varname, value):
            self._vars_cache.setdefault(host, {})[varname] = value

    class Loader:
        def __init__(self, path):
            pass

        def load_from_file(self, path):
            return {'localhost': {'ansible_version': 1}}

    inv = Inventory

# Generated at 2022-06-23 15:03:44.100120
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    hostvars = HostVars(inventory, variable_manager, loader)

    def test_inv(inv):
        hostvars.set_inventory(inv)
        assert hostvars._inventory == inv

    # Try to set Inventory that is not passed to the constructor of HostVars
    test_inv(Inventory(loader=loader, variable_manager=variable_manager))

# Generated at 2022-06-23 15:03:45.187986
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # TODO: mock variables and loader so that we can test the method without
    # dependencies on inventory
    pass

# Generated at 2022-06-23 15:03:55.103865
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from collections import Mapping
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Make sure AnsibleUndefined is available
    import ansible.module_utils.common
    variable_manager = VariableManager()

    # Make sure HostVars is available
    hostvars = HostVars(inventory=InventoryManager("example/hosts.ini"), variable_manager=variable_manager, loader=DataLoader())
    hostvars.set_host_facts("localhost", {'fact1': "value"})

    host_vars_vars = HostVarsVars(hostvars["localhost"], loader=DataLoader())
    assert isinstance(host_vars_vars, Mapping)

# Generated at 2022-06-23 15:04:02.989628
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = None
    vars = {"foo": "bar"}
    variables = HostVarsVars(vars, loader)
    assert variables['foo'] == 'bar'
    assert len(variables) == 1
    assert 'foo' in variables

    vars = {"foo": "{{ bar }}"}
    variables = HostVarsVars(vars, loader)
    assert isinstance(variables['foo'], AnsibleUndefined)
    assert len(variables) == 1
    assert 'foo' in variables

    vars = {"foo": 3}
    variables = HostVarsVars(vars, loader)
    assert variables['foo'] == 3
    assert len(variables) == 1
    assert 'foo' in variables

# Generated at 2022-06-23 15:04:04.699475
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    obj = HostVarsVars({'a': 'b'}, None)
    obj.__contains__('a')

# Generated at 2022-06-23 15:04:11.435213
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(host_list=[])
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    hostvars = HostVars(inventory, variable_manager, loader)
    assert(isinstance(hostvars, HostVars))
    assert(isinstance(hostvars, Mapping))

# Generated at 2022-06-23 15:04:22.034157
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader, cache_loader, callback_loader, connection_loader, lookup_loader, strategy_loader, vars_loader, filter_loader

    inventory = InventoryManager(loader=DataLoader(), sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    # These tests confirm that the variables available to the templar
    # are

# Generated at 2022-06-23 15:04:31.425031
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    assert isinstance(hostvars._inventory, InventoryManager)
    assert isinstance(hostvars._loader, DataLoader)
    assert isinstance(hostvars._variable_manager, VariableManager)
    assert variable_manager._hostvars == hostvars

# Generated at 2022-06-23 15:04:41.269030
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    class Inventory:
        def __init__(self):
            self._hosts = []

        def get_host(self, host_name):
            return 'dummy'

        @property
        def hosts(self):
            return self._hosts

        @hosts.setter
        def hosts(self, value):
            self._hosts = value

    class VariableManager:
        def __init__(self):
            self._loader = None

        def get_vars(self, host=None, include_hostvars=True):
            return 'dummy'

        def set_host_variable(self, host, varname, value):
            return 'dummy'

        def set_nonpersistent_facts(self, host, facts):
            return 'dummy'


# Generated at 2022-06-23 15:04:48.370223
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    inventory = dict(
        hosts=dict(
            localhost=None,
            testhost=None,
        ),
        groups=dict(
            group1=dict(hosts=dict(testhost=None)),
            group2=dict(hosts=dict(testhost=None)),
        )
    )
    inventory = dict_to_unsorted_dict(inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-23 15:04:59.612702
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import copy
    import mock
    import sys
    import yaml
    from ansible.module_utils.common._collections_compat import Sequence

    # Size of block of test data
    TEST_DATA_BLOCK_SIZE = 1000

    # Number of blocks
    TEST_DATA_BLOCK_NUMBER = 100

    # Size of test data
    TEST_DATA_SIZE = TEST_DATA_BLOCK_SIZE * TEST_DATA_BLOCK_NUMBER

    # Test data
    test_data = []

    # Prepare test data
    for i in range(TEST_DATA_BLOCK_NUMBER):
        test_data.append({"key_%d" % i: "value_%d" % i})

    # We are going to pickle our test data,
    # however we must convert it to str to ensure that pickle works

# Generated at 2022-06-23 15:05:12.231176
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    class MockVars:
        def __init__(self):
            self.__dict__['foo'] = 'bar'

        def __getitem__(self, key):
            return self.__dict__[key]

        def __setitem__(self, key, value):
            self.__dict__[key] = value

        def __contains__(self, key):
            return (key in self.__dict__)

        def to_dict(self):
            return self.__dict__

        def __repr__(self):
            return repr(self.__dict__)

    class MockLoader:
        pass

    variables = MockVars()
    loader = MockLoader()

    vars = HostVarsVars(variables, loader)

    assert vars['foo'] == 'bar'


# Generated at 2022-06-23 15:05:22.698805
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    '''Unit test for method __getitem__ of class HostVarsVars.'''

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar

    class MyLoader(object):
        '''Mock for class ansible.template.loader.BaseLoader.'''

        def get_basedir(self, *args, **kwargs):
            '''Mock method.'''
            return None

    class MyTemplar(Templar, MutableMapping):
        '''Mock for class ansible.template.Templar. Thus all methods
        of class Templar and class MutableMapping are mocked.

        '''

        def __init__(self, *args, **kwargs):
            '''Mock method.'''
            pass


# Generated at 2022-06-23 15:05:32.811483
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    inventory = dict(
        group1=dict(
            hosts=dict(
                host1=dict(
                    ansible_connection='local',
                )
            )
        )
    )
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory=variable_manager.inventory, variable_manager=variable_manager, loader=loader)
    hostvarsvars = hostvars['host1']
    assert len(hostvarsvars) == 1

# Generated at 2022-06-23 15:05:39.461620
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
  host_vars = HostVars(inventory=None, variable_manager=None, loader=None)
  host_vars.set_variable_manager(variable_manager=None)
  host_vars.set_host_variable(host=None, varname="test_variable", value="test_value")
  variable_value = host_vars.raw_get(host_name="localhost")["test_variable"]
  assert variable_value == "test_value"

# Generated at 2022-06-23 15:05:50.049094
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # Test that a HostVars is initialized with an inventory,
    # and can be reset with a new inventory.
    try:
        from ansible.inventory.manager import InventoryManager
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.module_utils._text import to_bytes
    except:
        return True

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert len(hostvars) == 1
    assert hostvars['localhost'] is not None

    inventory = InventoryManager(loader=loader, sources='localhost,')
    hostvars.set

# Generated at 2022-06-23 15:05:58.819611
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Functions to mock
    def get_host(host_name):
        return {}

    def get_vars(host, include_hostvars):
        return {'foo': 'spam'}

    # Create object using mock functions
    inventory, variable_manager, loader = None, None, None
    obj = HostVars(inventory, variable_manager, loader)
    obj._find_host = get_host
    obj._variable_manager.get_vars = get_vars

    # Test
    assert obj['test_host'] == {'foo': 'spam'}


# Generated at 2022-06-23 15:06:05.816357
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():

    from ansible.inventory import Host, Inventory
    from ansible.vars.manager import VariableManager

    inventory = Inventory(hosts=[
        Host(name='host1'),
        Host(name='host2'),
        Host(name='host3'),
    ])
    vm = VariableManager(loader=None, inventory=inventory)
    hv = HostVars(inventory, vm, loader=None)

    assert len(hv) == 3



# Generated at 2022-06-23 15:06:11.561294
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import os
    import tempfile
    from ansible.inventory.manager import InventoryManager

    host_name = "localhost"
    host_vars = HostVars(None, None, None)

    assert host_name not in host_vars

    inventory_file_fd, inventory_file_path = tempfile.mkstemp()
    os.write(inventory_file_fd, """
[all]
%s
""" % host_name)
    os.close(inventory_file_fd)

    inventory_manager = InventoryManager(loader=None, sources=[inventory_file_path])
    host_vars.set_inventory(inventory_manager.get_inventory())

    assert host_name in host_vars

    os.remove(inventory_file_path)

    # Use list to get over "TypeError: iteration over non-sequence"

# Generated at 2022-06-23 15:06:21.362437
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    variable_manager = VariableManager()

    HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    variable_manager_2 = VariableManager()

    hostvars = variable_manager_2._hostvars
    hostvars.set_variable_manager(variable_manager_2)

    assert variable_manager_2._hostvars is hostvars


# Generated at 2022-06-23 15:06:33.336373
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
    # testing HostVars's methods
    assert hostvars.raw_get('localhost') == dict()
    assert 'localhost' in hostvars
    assert len(hostvars) == 0
    assert repr(hostvars) == "{}"

    # add host 'localhost' to inventory
    inventory.add_host(host='localhost')

    # get hostvars

# Generated at 2022-06-23 15:06:38.540563
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = DictDataLoader({})
    variables = {
        'item': 'test',
        'list': [],
        'dict': {},
    }
    hostvars_vars = HostVarsVars(variables, loader)
    assert list(hostvars_vars) == variables.keys()


# Generated at 2022-06-23 15:06:45.443344
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager._hostvars = None

    from ansible.inventory import Inventory
    inventory = Inventory()

    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_variable_manager(variable_manager)

    assert variable_manager._hostvars is hostvars



# Generated at 2022-06-23 15:06:57.213385
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    ''' VariableManager._loader and VariableManager._hostvars attributes
    are not preserved during pickle, they are set to None to save memory.

    Test that class HostVars restores those values during unpickle and
    check that they are restored correctly.
    '''

    import pickle

    class _Loader(object):
        pass

    loader = _Loader()
    vm = HostVars({}, _Loader())
    vm.__dict__['_loader'] = loader

    # pickle HostVars instance and unpack it
    vm_pickled = pickle.dumps(vm)
    vm_unpickled = pickle.loads(vm_pickled)

    # check that _loader and _hostvars are restored correctly
    assert vm_unpickled._variable_manager._loader == loader
    assert vm_unpickled._variable_manager._

# Generated at 2022-06-23 15:07:09.233599
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.plugins.loader import inventory_loader

    class FakeInventory(object):
        def __init__(self):
            self.hosts = [Host(name='localhost')]

        def get_host(self, name):
            if name == 'localhost':
                return self.hosts[0]
            return None

    class FakeLoader(object):
        def __init__(self):
            self.host_vars = {}

        def get_basedir(self, host):
            return '/some/basedir'

    variable_manager = VariableManager()
    inventory = FakeInventory()
    loader = FakeLoader()

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set

# Generated at 2022-06-23 15:07:18.096231
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    templar = Templar(loader=loader, variables=hostvars)
    result = templar.template('"{{ item }}"', fail_on_undefined=False, static_vars=STATIC_VARS)
    assert result == ['"localhost"']

# Generated at 2022-06-23 15:07:29.913587
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    class VariableManager:

        def __init__(self, loader, inv_data):
            self._loader = loader
            self._inventory = Inventory(loader=loader, variable_manager=self, host_list=inv_data)

    class PlaybookExecutor:

        def __init__(self, loader, variable_manager, inv_data):
            self._loader = loader
            self._variable_manager = variable_manager
            self._hostvars = HostVars(inventory=variable_manager._inventory, variable_manager=variable_manager,
                                      loader=loader)
            self.hostvars = self._hostvars
            self.inventory = variable_manager._inventory
            self.inventory._hosts_cache = inv_data

    class Host:

        def __init__(self, name):
            self.name = name


# Generated at 2022-06-23 15:07:39.008832
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    """
    Unit test for method __repr__ of class HostVarsVars
    """
    # Test with undefined variable
    v = dict(a='{{b}}', c='{{d}}')
    loader = TestLoader()
    hostvars_vars = HostVarsVars(v, loader=loader)
    assert repr(v) == repr(hostvars_vars)

    # Test with defined variable
    v = dict(a='{{b}}', b='foo', c='{{d}}')
    loader = TestLoader()
    hostvars_vars = HostVarsVars(v, loader=loader)
    assert repr(v) != repr(hostvars_vars)
    assert 'foo' in repr(hostvars_vars)


# Generated at 2022-06-23 15:07:43.458333
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    data = {
        "foo" : "Hello World",
        "foo2" : "{{ foo }}"
    }

    host_vars = HostVarsVars(data, None)
    assert host_vars["foo"] == "Hello World"
    assert host_vars["foo2"] == "Hello World"

# Generated at 2022-06-23 15:07:52.138972
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import inventory_loader, vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/test_hostvars_inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    hostvars = HostVars(inventory, variable_manager, loader)

    # Verify that hostvars contains host1
    assert('host1' in hostvars)

    # Verify that hostvars contains host2
    assert('host2' in hostvars)

#

# Generated at 2022-06-23 15:07:59.061971
# Unit test for constructor of class HostVars
def test_HostVars():
    inventory = 'h1\nh2'
    # Cannot instantiate VariableManager because it has abstract methods
    variable_manager = 'variable_manager'
    loader = 'loader'
    host_vars = HostVars(inventory, variable_manager, loader)
    assert host_vars._inventory == inventory
    assert host_vars._variable_manager == variable_manager
    assert host_vars._loader == loader

# Generated at 2022-06-23 15:08:03.176823
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    """
        AnsibleVariables contains
        AnsibleVariable does not contain
    """
    from ansible.vars.hostvars import AnsibleVariable
    from ansible.vars import HostVars
    assert 'AnsibleVariables' in HostVars
    assert AnsibleVariable('test', 'default') not in HostVars

# Generated at 2022-06-23 15:08:12.035273
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Initial state
    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

    # Pickle hostvars and unpickle it
    hostvars_unpickled = loader.load(loader.dump(hostvars))

    # Make sure that hostvars is restored
    assert hostvars_unpickled._variable_manager._loader is loader

# Generated at 2022-06-23 15:08:23.366228
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=["hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Two hosts will be added to the inventory
    host_list = [
        dict(
            name="foo",
            groups=[],
        ),
        dict(
            name="bar",
            groups=[],
        ),
    ]
    inv_manager.add_group("all")
    for host in host_list:
        inv_manager.add_host(host["name"])
        host_object = inv

# Generated at 2022-06-23 15:08:27.043789
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class Loader:
        pass

    class A:
        def __iter__(self):
            yield 'a'

    hostvars = HostVarsVars(A(), Loader())
    assert list(hostvars) == list(A())

# Generated at 2022-06-23 15:08:36.597876
# Unit test for constructor of class HostVars
def test_HostVars():
    def _MockInventory():
        _instance = None

        def __call__(cls):
            nonlocal _instance
            if _instance is None:
                _instance = cls()
            return _instance

        def get_host(self, host_name):
            h = host_name
            h.vars = {}
            return h

        def __getattr__(self, name):
            # XXX: return empty list to avoid crashes
            # This is not correct way to implement inventory!
            # But it's only temporary fix.
            if name in ('hosts', 'groups', 'get_group'):
                return []
            raise AttributeError

    def _MockVariableManager():
        _instance = None

        def __call__(cls):
            nonlocal _instance
            if _instance is None:
                _instance

# Generated at 2022-06-23 15:08:47.818822
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader, sources=['localhost,'])
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)

    test_host = inventory.get_host('localhost')

    hostvars = HostVars(inventory, variable_manager, dataloader)
    hostvars_vars = hostvars[test_host]


# Generated at 2022-06-23 15:08:52.381479
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import ansible.vars.hostvars
    import copy

    h1 = ansible.vars.hostvars.HostVars()
    h2 = copy.deepcopy(h1)

    assert h1 is h2



# Generated at 2022-06-23 15:08:57.428995
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # Test with empty inventory
    hv = HostVars(None, None, None)
    assert 'somehost' not in hv

    # Test with not empty inventory
    hv.set_inventory(MockInventory())
    hv.set_variable_manager(MockVariableManager())
    assert 'somehost' in hv
