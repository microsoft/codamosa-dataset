

# Generated at 2022-06-23 14:59:04.245973
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)

    # Make sure we don't have any undefined variables in any group vars
    for group in inventory.groups.values():
        wrap_var(group._vars)

    # Make sure we don't have any undefined variables in any host vars
    for host in inventory.hosts.values():
        wrap_var(host.get_vars())

    # OK, good to

# Generated at 2022-06-23 14:59:08.431903
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars = HostVars({'localhost': {'var': 'test'}}, None, None)
    host_vars_repr = host_vars.__repr__()
    assert isinstance(host_vars_repr, str)

# Generated at 2022-06-23 14:59:13.184658
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    variables = {
        'foo': 1,
        'bar': 2,
    }
    hostvars = HostVarsVars(variables, None)
    assert( 'foo' in hostvars )
    assert( 'bar' in hostvars )
    assert( 'baz' not in hostvars )

# Generated at 2022-06-23 14:59:22.715103
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import os
    import tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    # Create dummy inventory
    tmp_dir = tempfile.mkdtemp()

    inventory_path = os.path.join(tmp_dir, 'hosts')
    with open(inventory_path, 'w') as inventory_fd:
        inventory_fd.writelines(['[group1]\n', 'host1\n', 'host2\n'])

    inventory = InventoryManager(loader=None, sources=[inventory_path])
    variables = {}
    loader = None
    hostvars = HostVars(inventory=inventory, variable_manager=variables, loader=loader)
    assert 'host1' in hostvars
    assert hostvars['host1'] == {}
    assert 'host2'

# Generated at 2022-06-23 14:59:25.489956
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy

    hostvars = HostVars({}, {})
    hostvars_copy = copy.deepcopy(hostvars)

    assert hostvars is hostvars_copy

# Generated at 2022-06-23 14:59:28.598914
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    dummy_hostvars_vars = HostVarsVars({}, None)
    interface_iter = iter({})
    assert dummy_hostvars_vars.__iter__() == interface_iter


# Generated at 2022-06-23 14:59:38.603016
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # These two lines are needed in order to make method
    # __getitem__ of class HostVars work properly within
    # unit test.
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager._hostvars = None

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # Module DataLoader is not designed for unit testing.
    # This is not ideal but it does the trick.
    loader = DataLoader()

    # Fake inventory

# Generated at 2022-06-23 14:59:39.433512
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # Placeholder for method to test
    pass

# Generated at 2022-06-23 14:59:43.394112
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = {'foo1': 'bar1', 'foo2': 'bar2', 'foo3': 'bar3'}
    hostvarsvars = HostVarsVars(variables, '')
    assert len(hostvarsvars) == len(variables)


# Generated at 2022-06-23 14:59:47.477683
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert len(HostVarsVars({}, None)) == 0
    assert len(HostVarsVars({'foo': 'bar'}, None)) == 1
    assert len(HostVarsVars({'a': 1, 'b': 2, 'c': 3}, None)) == 3
    assert len(HostVarsVars({1: 'a', 2: 'b', 3: 'c'}, None)) == 3



# Generated at 2022-06-23 14:59:52.208951
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    hv = HostVars({'x': 'y'})
    assert hv['x'] == 'y'
    try:
        hv['z']
        assert False, 'should have raised KeyError'
    except KeyError:
        pass



# Generated at 2022-06-23 15:00:01.550935
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible import constants as C
    import ansible.plugins
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    #############################################################
    # Create an instance of HostVars and associated objects
    #############################################################
    C.HOST_KEY_CHECKING = False              # do not check host key
    C.DEFAULT_HOST_LIST = '/dev/null'        # do not use node list file
    loader = Data

# Generated at 2022-06-23 15:00:09.654473
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader, 'tests/inventory')
    variables = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variables, loader)
    hostvarsvars = HostVarsVars(hostvars['host'], loader)

    assert repr(hostvarsvars) == repr(hostvars['host'])

# Generated at 2022-06-23 15:00:19.247453
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    class MockInventory(object):
        def __init__(self, hostvars):
            self.hostvars = hostvars

        def get_host(self, hostname):
            if hostname in self.hostvars:
                return hostname
            return None

    class MockVariableManager(object):
        def __init__(self, hostvars):
            self.hostvars = hostvars

        def get_vars(self, host, include_hostvars=True):
            if not include_hostvars:
                return self.hostvars.get(host, {})

            hostvars = self.hostvars.get(host, {})
            hostvars.setdefault('ansible_host', host)
            return hostvars


# Generated at 2022-06-23 15:00:25.001856
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import pytest

    hostvars = { 'var1': 'value1', 'var2': 'value2', 'var3': 'value3' }
    hostvarsvars = HostVarsVars(variables=hostvars, loader=dict())

    assert sorted(hostvarsvars.__iter__()) == ['var1', 'var2', 'var3']

# Generated at 2022-06-23 15:00:33.575907
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    '''
    This is a basic test for method set_host_variable of class HostVars,
    to ensure this method can modify host variables without side-effects.
    '''

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create inventory, variable_manager and loader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Variables to be tested
    variable_name = 'test_variable'
    variable_value = 'test_value'
    variable_namespace = 'test_namespace'
    variable

# Generated at 2022-06-23 15:00:43.474217
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = dict(
        become=False,
        diff=False,
        new_vault_password_file=None,
        password=None,
        vault_password=None,
        force_handlers=False,
        flush_cache=None,
        remote_user='test',
        connection='local',
    )


# Generated at 2022-06-23 15:00:46.301308
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars()
    assert len(hostvars) == 0


# Generated at 2022-06-23 15:00:56.413632
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.parsing.dataloader import DataLoader

    # Create inventory with one host
    inventory = MagicMock()
    inventory.hosts = ['example']

    # Create variable manager
    variable_manager = MagicMock()
    variable_manager.get_vars.return_value = {'a': 'foo', 'b': 'bar'}

    # Create loader
    loader = DataLoader()

    # Create HostVars instance
    hostvars = HostVars(inventory, variable_manager, loader)

    # Verify that variable manager is not copied
    variable_manager_copy = deepcopy(variable_manager)
    assert variable_manager == variable_manager_copy

    # Verify that HostVars is not copied
    hostvars_copy = deepcopy(hostvars)
    assert host

# Generated at 2022-06-23 15:00:58.806518
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    assert("foo" in HostVarsVars({"foo": "bar"}, None))
    assert("bar" not in HostVarsVars({"foo": "bar"}, None))

# Generated at 2022-06-23 15:01:05.590157
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager()

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
    hostvars.set_variable_manager(None)
    assert hostvars._variable_manager is None

    hostvars.__setstate__({'_variable_manager': variable_manager})
    assert hostvars._variable_manager is not None

# Generated at 2022-06-23 15:01:14.821862
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    localhost = inventory.get_host('localhost')

    hostvars.set_host_variable(localhost, 'role_a', 'b')
    hostvars.set_host_variable(localhost, 'role_b', 'a')
    hostvars.set_host_variable(localhost, 'role_dict', {'a': 'b', 'c': 'd'})

# Generated at 2022-06-23 15:01:19.941165
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {
        'a': '1',
        'b': '{{a}}'
    }

    host_vars_vars = HostVarsVars(variables, loader=None)
    assert(host_vars_vars['a'] == '1')
    assert(host_vars_vars['b'] == '1')

# Generated at 2022-06-23 15:01:27.232968
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({
        "hosts": """
            localhost
        """,
        "group_vars/all": """
            a: 1
        """
    })

    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get("localhost") == {'a': 1}

# Generated at 2022-06-23 15:01:38.185005
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader, variable_manager, host_list=[])

    variable_manager._hostvars = HostVars(inventory, variable_manager, loader)
    variable_manager.set_nonpersistent_facts(None, dict(a=True))
    assert(variable_manager.get_vars(host=None, include_hostvars=False)['a'] is True)
    assert(variable_manager.get_vars(host=None, include_hostvars=True)['a'] is True)

    variable_manager._hostvars = HostVars(inventory, variable_manager, loader)
   

# Generated at 2022-06-23 15:01:44.916107
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    test_host1 = type('test_host1', (object, ), {
        'name': 'test_host1',
        'vars': {
            'foo': 'bar',
            'fuzz': 'buzz',
        },
    })()

    test_host2 = type('test_host2', (object, ), {
        'name': 'test_host2',
        'vars': {
            'foo': 'bar',
        },
    })()

    test_host3 = type('test_host3', (object, ), {
        'name': 'test_host3',
        'vars': {
            'foo': 'bar',
            'fuzz': 'buzz',
        },
    })()



# Generated at 2022-06-23 15:01:56.237946
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    # Create VariableManager to be stored
    variable_manager = VariableManager()
    variable_manager.add_default_vars()
    variable_manager.add_host_vars(host=None, hostvars=dict())
    variable_manager.add_host_vars(host='localhost', hostvars=dict())

    # Pickle the VariableManager
    import pickle
    pickled_data = pickle.dumps(variable_manager)

    # Load the VariableManager from pickled data
    unpickled_data = pickle.loads(pickled_data)

    # Initialize HostVars with the loaded object

# Generated at 2022-06-23 15:02:01.172569
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import json
    import yaml

    hvv = HostVarsVars(vars(json), loader=None)
    assert hvv['dumps'].__name__ == 'dumps'

    hvv = HostVarsVars(vars(yaml), loader=None)
    assert hvv['load'].__name__ == 'load'

# Generated at 2022-06-23 15:02:02.337118
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    hostvars = HostVarsVars({"key":"value"}, None)
    assert "key" in hostvars

# Generated at 2022-06-23 15:02:04.078714
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    assert "foo" not in HostVars(None, None, None)
    assert HostVars(None, None, None)["foo"] == AnsibleUndefined(name="hostvars['foo']")

# Generated at 2022-06-23 15:02:09.345883
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.compat.tests import mock
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    _inventory = mock.Mock()
    _loader = mock.Mock()
    _variable_manager = mock.Mock()
    _variable_manager.get_vars.return_value = {'foo': 'bar', 'hello': 'world'}

    hostvars = HostVars(_inventory, _variable_manager, _loader)
    foo = hostvars['localhost']
    assert isinstance(foo, Mapping)
    assert foo['foo'] == 'bar'
    assert foo['hello'] == 'world'

# Generated at 2022-06-23 15:02:18.297976
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text
    from ansible.parsing.vault import VaultLib
    import base64

    # Mocking modules
    from ansible.module_utils import basic
    from ansible.module_utils import six
    import ansible.module_utils.six.moves.builtins
    from units.mock.loader import DictDataLoader

    # Mocking classes
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host


# Generated at 2022-06-23 15:02:26.153065
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    # Note: Before this test case was added, method __len__ was not included
    #       in the list of methods tested in test case test_HostVarsVars
    #       of test file test_vars_cache.
    from unit.plugins.action.vars.test_vars_cache import TestVarsCache
    from ansible.plugins.loader import action_loader

    # Load the test case class and method
    test_case = TestVarsCache()
    test_case.setUp()
    test_hostvarsvars = test_case.test_HostVarsVars()

    # Create an instance of HostVarsVars
    variables = {'v1': {'v11': 'v12'}, 'v2': ['v21', 'v22']}
    loader = action_loader


# Generated at 2022-06-23 15:02:36.206560
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader
    from ansible.vars import VariableManager

    inv_data = """
    localhost ansible_connection=local ansible_python_interpreter=/usr/bin/python
    """

    hostvars = HostVars(InventoryManager(loader=inventory_loader, sources=inv_data), VariableManager(), None)
    hostvars.set_nonpersistent_facts('localhost', {'foo': 'bar', 'ansible_python_interpreter': '/bin/python'})
    hostvars.set_nonpersistent_facts('localhost', {'bar': 'baz'})

# Generated at 2022-06-23 15:02:44.670626
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager

    hv_loader = 'fake loader'
    hv_inventory = 'fake inventory'

    hv_vars = {
        'a': 1,
        'b': 2
    }

    hv = HostVars(hv_inventory, VariableManager(), hv_loader)

    # Create new VariableManager with defined _loader and _hostvars attributes
    # to test if they are updated.
    old_vm = VariableManager(loader=None, hostvars=None)
    new_vm = VariableManager(loader=old_vm._loader, hostvars=old_vm._hostvars)

    # Assert that _loader and _hostvars attributes of new_vm are different
    # from corresponding attributes of hv object.
    assert hv._variable_manager._loader is not new

# Generated at 2022-06-23 15:02:47.853868
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    loader = MockLoader()
    hostvars = HostVarsVars({'foo': 'bar'}, loader=loader)
    assert 'foo' in hostvars
    assert 'bar' not in hostvars



# Generated at 2022-06-23 15:02:58.068654
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.reserved import Reserved
    import json

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var1': "test_var1_value", 'test_var2': "test_var2_value"}
    variable_manager.set_inventory(inventory)
    variable_manager._fact_cache = {'a': 1, 'b': 2}
    variable_manager._vars_cache = {'a': 1, 'b': 2}
    variable_

# Generated at 2022-06-23 15:03:09.908241
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():

    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    class FakeInventory(object):
        def __init__(self):
            self.hosts = ['localhost', 'example_host']

        def get_host(self, host_name):
            if host_name in self.hosts:
                return host_name
            return None

    class FakeHost(object):
        def __init__(self):
            self.name = 'localhost'

    # Create fake inventory
    inventory = FakeInventory()

    # Create fake loader
    class FakeLoader(object):
        def __init__(self):
            self.variable_manager = VariableManager()

    loader = FakeLoader()

    # Create hostvars
    hostv

# Generated at 2022-06-23 15:03:14.780710
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = Inventory(host_list=[])
    variable_manager = VariableManager(loader=None)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    variables = {"foo": "bar"}
    variable_manager._vars_cache = {"host": variables}
    assert hostvars.raw_get("host") == variables

# Generated at 2022-06-23 15:03:23.180272
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inv_dict = {'group': {'hosts': ['host1', 'host2'], 'vars': {}}}
    test_inventory = InventoryManager(loader=None, sources=inv_dict)
    test_variable_manager = VariableManager(loader=None, inventory=test_inventory)
    hostvars = HostVars(inventory=test_inventory, variable_manager=test_variable_manager, loader=None)

    assert len(hostvars) == 2

# Generated at 2022-06-23 15:03:31.383978
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import DEFAULT_HASH_BEHAVIOUR

    loader = DictDataLoader({})

    variable_manager = VariableManager(loader=loader, play=Play(), inventory=InventoryManager(loader=loader, sources=[]))
    play_context = PlayContext(play=Play(), options=object(), variable_manager=variable_manager, loader=loader, passwords={})

# Generated at 2022-06-23 15:03:38.216343
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars

    inventory = Inventory.load_from_file('/dev/null')
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, None)
    assert set(hostvars.keys()).issubset(set(hostvars))

# Generated at 2022-06-23 15:03:44.857635
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=None)
    variable_manager = VariableManager(loader=None, inventory=None)
    variable_manager._fact_cache = dict(foo='bar', foo2='{{ foo }}')
    variable_manager._play_context = PlayContext()
    hvv = HostVarsVars(variable_manager._fact_cache, loader=None)

    assert repr(hvv) == "{'foo': 'bar', 'foo2': '{{ foo }}'}"
    assert repr(templar.template(hvv, fail_on_undefined=False, static_vars=STATIC_VARS)) == "{'foo': 'bar', 'foo2': 'bar'}"

# Generated at 2022-06-23 15:03:54.914504
# Unit test for constructor of class HostVars
def test_HostVars():
    # pylint: disable=too-many-locals
    '''
    Test HostVars dictionary
    '''

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Create inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host(name='localhost')

    # Create variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create HostVars
    my_hostvars = HostVars(inventory, variable_manager, loader)
    my_hostvars.set_host_variable(host, 'foo', 'bar')
    my_hostvars.set_nonpersistent_facts

# Generated at 2022-06-23 15:04:03.590237
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    # test1: simple dictionary, where self.__getitem__() must expand variables,
    #        to make sure that class HostVarsVars works right in this case.
    variables = {'a': 'start_{{b}}_end', 'b': 'begin_inside_end'}
    loader = None
    x = HostVarsVars(variables, loader)
    assert x['a'] == 'start_begin_inside_end_end'

    # test2: dictionary of dictionaries, where self.__getitem__() must expand variables,
    #        to make sure that this case is handled correctly.
    variables = {'a':
        {'b': 'start_{{c}}_end',
         'c': 'begin_inside_end'}
    }
    x = HostVarsVars(variables, loader)


# Generated at 2022-06-23 15:04:13.239001
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible import constants as C
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars


# Generated at 2022-06-23 15:04:23.437695
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    import json
    import textwrap
    from ansible.inventory import Host, Inventory

    # load modules to have access to _create_tmp_path()
    from ansible import constants
    from ansible.module_utils.basic import AnsibleModule

    # Set up facts file
    facts_file = AnsibleModule._create_tmp_path('hostvars_test_facts.json')

    # Set up inventory file
    inv_file = AnsibleModule._create_tmp_path('hostvars_test_inv.yml')
    with open(inv_file, 'w') as f:
        f.write(textwrap.dedent('''\
            all:
              children:
                group1:
                  hosts:
                    host1:
                      ansible_host: 127.0.0.1
            '''))

    # Set

# Generated at 2022-06-23 15:04:26.323358
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    class Loader(object):
        pass

    variable_manager = dict(foo='bar', bar='baz')
    hostvars = HostVarsVars(variable_manager, Loader())
    assert 'foo' in hostvars
    assert 'baz' not in hostvars

# Generated at 2022-06-23 15:04:37.499014
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import os
    import os.path
    import tempfile

    from ansible.inventory.manager import InventoryManager
    from ansible.cli import CLI

    options = CLI.base_parser(None, None).parse_args(['-i', os.devnull, '--list-hosts'])
    loader, inventory, variable_manager = InventoryManager(options).get_inventory_and_variable_manager()
    hostvars = HostVars(inventory, variable_manager, loader)

    # If the inventory object is not unset, set_inventory does nothing
    tmpdir = tempfile.mkdtemp()
    os.rmdir(tmpdir)
    inventory.root_dir = tmpdir
    hostvars.set_inventory(None)
    assert os.path.exists(tmpdir)

    # If the inventory object is unset,

# Generated at 2022-06-23 15:04:45.803810
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible import constants
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    constants.HOST_VARS_PERSISTENT_PATH = '/tmp/ansible_test_inventory'
    constants.HOST_VARS_PERSISTENT = True

    loader = DataLoader()
    inventory = InventoryManager(loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    host = Host('test-host')
    inventory.add_host(host)

    hostvars.set_nonpersistent_facts(host, {'key1': 'value1'})

# Generated at 2022-06-23 15:04:58.005334
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    data = {}
    inventory = Inventory(host_list=[])
    loader = None

    for method in ('set_variable_manager', 'set_inventory'):
        hv = HostVars(inventory, VariableManager, loader)

        # Make sure we have no VariableManager after initialization.
        assert hv._variable_manager._hostvars is None

        # Make sure that variable manager has attribute
        # _hostvars equals to host vars.
        hv.set_variable_manager(variable_manager=VariableManager(loader, variables=data))
        assert hv._variable_manager._hostvars is hv

        # Make sure that variable manager has attribute
        # _hostvars equals to host vars and we didn't lose
        # previously initialized

# Generated at 2022-06-23 15:05:04.754087
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import tempfile
    import shutil
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    ds = tempfile.mkdtemp()

# Generated at 2022-06-23 15:05:09.134709
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars import VariableManager

    vars = VariableManager()
    assert list(vars.hostvars) == []

    vars = VariableManager(host_vars={ 'localhost' : { 'a' : 1 } })
    assert list(vars.hostvars) == ['localhost']



# Generated at 2022-06-23 15:05:19.614473
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    class FakeVarsManager:
        def __init__(self, d):
            self._vars_cache = d

        def set_host_variable(self, host, varname, value):
            pass

        def set_nonpersistent_facts(self, host, facts):
            pass

        def get_vars(self, host=None, include_hostvars=True):
            return self._vars_cache[host]

    class FakeInventory:
        def __init__(self, d):
            self._d = d
            self.hosts = d.keys()

        def get_host(self, host_name):
            return self._d.get(host_name)

    class FakeHost:
        def __init__(self, name):
            self.name = name
            self.vars = {}

   

# Generated at 2022-06-23 15:05:24.054178
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    class A:
        ''' A class with __deepcopy__() method returning HostVars '''
        def __deepcopy__(self, memo):
            return hv
    a = A()
    b = deepcopy(a)
    assert a is hv
    assert b is hv

# Generated at 2022-06-23 15:05:36.647301
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # Create a fake inventory, variable manager and loader
    class Inventory():
        def __init__(self):
            self.hosts = {'host1': 1, 'host2': 2}

    class VariableManager():
        def __init__(self):
            self.vars_cache = {'host1': {'hostvars': {'host1hvar': 1, 'host1hvar2': 2}}}

    class Loader():
        def __init__(self, loader):
            self.loader = loader

    inventory = Inventory()
    variable_manager = VariableManager()
    loader = Loader(inventory)

    # Create an internal hostvars instance
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check the variables cache

# Generated at 2022-06-23 15:05:47.481403
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    play_context = PlayContext()
    inventory = InventoryManager(host_list=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    host_name = 'fakehost'
    hostvars = HostVars(inventory, variable_manager, None)
    hostvars.set_host_variable(host_name, 'foo', 'bar')
    hostvars.set_host_variable(host_name, 'nested', dict(a=1, b=AnsibleUnsafeText(u"{{ansible_managed}} {{foo}}")))

    host = variable

# Generated at 2022-06-23 15:05:53.375717
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import mock
    from ansible.playbook.play import Play

    variable_manager = mock.Mock()
    variable_manager.__contains__.side_effect = lambda x: x != "foo"
    loader = mock.Mock()

    # HostVars object
    hv = HostVars(mock.Mock(), variable_manager, loader)

    # Test __contains__ method for missing variable
    assert "foo" not in hv

    # Test __contains__ method for existing variable
    assert "bar" in hv
    variable_manager.__contains__.assert_called_with("bar")


# Generated at 2022-06-23 15:05:55.499861
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    try:
        hvars = HostVarsVars({}, None)
    except:
        assert False, 'Constructor of class HostVarsVars failed.'

# Generated at 2022-06-23 15:06:05.293887
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible import context

    variables = {'var1': 'value1', 'var2': 'value2'}
    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.set_inventory(inventory)
    variable_manager.set_host_variable('localhost', 'var3', 'value3')
    HostVars = HostVars(inventory, variable_manager, loader=None)
    assert HostVars['localhost'] == {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}


# Generated at 2022-06-23 15:06:15.480303
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # set values in inventory and variable_manager
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable('localhost', 'foo', 'inventory')
    hostvars.set_nonpersistent_facts('localhost', {'foo': 'nonpersistent', 'bar': 'baz'})
    hostvars.set_host_facts('localhost', {'foo': 'persistent', 'qux': 'quux'})

    # set value in

# Generated at 2022-06-23 15:06:19.925870
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # simulate __getstate__ in VariableManager
    state = {
        '_variable_manager__vars': {
            'hostvars': {'foo': {'bar': 'baz'}},
        }
    }
    # create actual object and simulate pickle.
    hv = HostVars(None, None, None)
    hv.__setstate__(state)
    # test that attribute hostvars is supported
    assert hv['foo']['bar'] == 'baz'

# Generated at 2022-06-23 15:06:29.494983
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():

    import copy
    import mock
    import sys

    from ansible.vars.manager import VariableManager

    # Create mock objects to replace real objects
    inventory = mock.Mock()
    loader = mock.Mock()
    variable_manager = VariableManager(loader=loader)

    # Create HostVars
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Setup attributes of mock objects
    inventory.hosts = ['test_host']
    variable_manager.get_vars.return_value = {'test_var': 'test_value'}

    # Make a deepcopy of hostvars
    hostvars_copy = copy.deepcopy(hostvars)

    # Check attributes of deepcopied object
    assert hostvars_copy._inventory is inventory
    assert host

# Generated at 2022-06-23 15:06:38.293619
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory_manager = InventoryManager(loader=DataLoader())
    inventory_manager.set_inventory(inventory=None)

    hostvars = HostVars(inventory_manager, VariableManager(loader=DataLoader()), loader=DataLoader())
    hostvars.set_host_facts("127.0.0.1", dict(foo="bar"))

    assert hostvars.get("127.0.0.1").get("foo") == "bar"

    # Can't set facts on non-existent host
    hostvars.set_host_facts("example.com", dict(foo="bar"))

# Generated at 2022-06-23 15:06:45.881905
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = dict(a=1, b=2, c=3, d=4)
    stub_loader = object
    hvv = HostVarsVars(variables, stub_loader)
    generator = hvv.__iter__()
    assert next(generator) == 'a'
    assert next(generator) == 'b'
    assert next(generator) == 'c'
    assert next(generator) == 'd'
    try:
        next(generator)
        assert False, "Expected StopIteration exception"
    except StopIteration:
        pass

# Generated at 2022-06-23 15:06:57.650028
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    dl = DataLoader()
    im = InventoryManager(dl, [])
    vm = VariableManager(loader=dl)
    hv = HostVars(inventory=im, variable_manager=vm)
    test_host = Host(name='test_host')
    vm.set_host_variable(test_host, 'test_var', 42)
    assert(hv['test_host']['test_var'] == 42)

    # Test that vm state was pickled correctly
    vm_pickled = vm.__getstate__()
   

# Generated at 2022-06-23 15:07:00.511626
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    v = HostVarsVars(dict(a='a'), loader=None)
    assert 'a' in v
    assert 'b' not in v



# Generated at 2022-06-23 15:07:11.651486
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory("")
    variable_manager = VariableManager()
    loader = DataLoader()

    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars.raw_get('localhost') is None

    host = inventory.add_host('localhost')
    assert hostvars.raw_get('localhost') is not None

    assert hostvars.raw_get('localhost') is hostvars.raw_get('127.0.0.1')
    assert hostvars.raw_get('localhost') is hostvars.raw_get('::1')

    hostvars.set_host_variable(host, 'foo', 'bar')
    assert host

# Generated at 2022-06-23 15:07:21.096191
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host1 = MockHost('host1')
    host2 = MockHost('host2')
    host3 = MockHost('host3')
    loader = MockLoader()
    inventory = MockInventory(host1, host2, host3)
    variable_manager = MockVariableManager(host1, host2, host3)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Store hostvars as an attribute in variable_manager.
    # In the case of task serialization, the variable_manager with its state
    # is stored in the serialized task.
    variable_manager._hostvars = hostvars

    variable_manager._hostvars = None
    variable_manager._loader = None
    variable_manager.reset_mock()

    # Test
    hostvars_state = hostvars.__get

# Generated at 2022-06-23 15:07:26.528172
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {'foo': 'bar', 'baz': 'quux'}
    loader = None
    foo = HostVarsVars(variables, loader)
    assert foo._vars == variables
    assert foo._loader == loader
    assert foo['foo'] == 'bar'
    assert foo['baz'] == 'quux'


# Generated at 2022-06-23 15:07:33.643894
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager

    # Setup a host, a variable manager and HostVars
    testhost = Host('testhost')
    vm = VariableManager()
    vm.set_host_variable(testhost, 'foo', 'bar')
    hv = HostVars(vm, DictDataLoader())

    import copy
    vm2 = copy.deepcopy(vm)
    assert vm2._hostvars is not hv
    assert vm2._hostvars['testhost']['foo'] == 'bar'

# Generated at 2022-06-23 15:07:41.588971
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {"variable1": "value1", "variable2": "value2"}
    loader = "fake_loader"
    host_vars_vars = HostVarsVars(variables, loader)

    assert len(host_vars_vars) == 2
    assert host_vars_vars["variable1"] == "value1"
    assert host_vars_vars["variable2"] == "value2"
    assert "variable1" in host_vars_vars
    assert "variable2" in host_vars_vars

# Generated at 2022-06-23 15:07:46.813107
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    variables = { 'foo': 'moo' }
    hostvars = HostVarsVars(variables, loader)
    assert 'foo' in hostvars
    assert 'moo' not in hostvars

# Generated at 2022-06-23 15:07:54.470555
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    # This test is for checking the method __getitem__ of class HostVars
    # We will create variable 'host_specific_var' of host 'host_one' and assign a variable 'test_var' a value '123'
    var_cache = {
        'hostvars': {'host_one': {'host_specific_var': 'test_var'}}
    }

    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    inventory.add_host('host_one')

    variable_manager.extra_vars = {'test_var': '123'}

    hostvars

# Generated at 2022-06-23 15:07:57.711979
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    hvv = HostVarsVars({'a':1, 'b':2, 'c':3}, None)
    assert len(hvv) == 3

# Generated at 2022-06-23 15:08:03.722077
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    # https://github.com/ansible/ansible/issues/61147
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variables = {'var1': '{{ hostvars[inventory_hostname][var2] }}', 'var2': 'val2'}
    hostvarsvars = HostVarsVars(variables, loader)
    assert 'var1' in hostvarsvars  # Regression test: no error is raised

# Generated at 2022-06-23 15:08:12.248254
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager, Host, HostPattern
    from ansible.inventory.group import Group

    inv = InventoryManager(loader=None, sources=[])
    h1 = Host(name='foobar1')
    h2 = Host(name='foobar2')
    g1 = Group(name='foo')
    g2 = Group(name='bar')
    g1.add_host(h1)
    g2.add_host(h2)
    inv.add_group(g1)
    inv.add_group(g2)


# Generated at 2022-06-23 15:08:14.807718
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create an instance of the HostVars class
    _HostVars = HostVars()
    # Check that the method __iter__ returns an iterable object
    assert hasattr(_HostVars.__iter__(), '__next__')


# Generated at 2022-06-23 15:08:25.408042
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    my_host = 'my_host'

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    hostvars._inventory.add_host(my_host)
    hostvars._inventory._hosts_cache[my_host] = hostvars._inventory.get_host(my_host)

    play_context = PlayContext()
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-23 15:08:35.661736
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    import ansible.plugins.loader
    # As of Ansible 2.5, basic methods of class loader.C in module
    # ansible.plugins.loader are no longer sufficient for testing
    # set_nonpersistent_facts of class HostVars. So we define test
    # class TestLoader that implements the methods of class loader.C
    # that the test requires.
    class TestLoader(object):
        def get_basedir(self, path):
            return '.'

    class TestVariableManager(object):
        def __init__(self):
            self._host_vars_files = {}

        def get_vars(self, host=None, include_hostvars=True):
            # Return test facts
            return {'ansible_distribution': 'Ubuntu', 'ansible_distribution_release': '16.04'}

# Generated at 2022-06-23 15:08:47.174157
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.plugins.loader import vars_loader

    # Create test data
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_manager = variable_manager.vars_manager
    hostvars = HostVars(inventory, variable_manager, loader)

    hostname = 'test-host'
    host = inventory.add_host(hostname)
    hostvars_raw = hostvars.raw_get(hostname)

    # Set

# Generated at 2022-06-23 15:08:58.953997
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    # Setup dummy inventory and variable manager
    host_vars = {'var1': 'foo', 'var2': '{{var1}}'}
    group_vars = {'var1': 'bar', 'var3': '{{var2}}'}
    host_vars2 = {'var1': 'baz'}
    group_vars2 = {'var1': 'qux', 'var2': 'foo'}

    loader = DataLoader()
    inventory = Inventory