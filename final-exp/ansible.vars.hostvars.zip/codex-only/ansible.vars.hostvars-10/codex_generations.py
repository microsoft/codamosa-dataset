

# Generated at 2022-06-23 14:58:59.979196
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["test/test_hostvars.yml"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host("localhost")

    assert 'somevar' in hostvars[host.name], "dict key 'somevar' not found in hostvars"

# Generated at 2022-06-23 14:59:05.047469
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    class MockInventory(object):
        def __init__(self):
            self.hosts = []
        def get_host(self, name):
            for host in self.hosts:
                if host.name == name:
                    return host
            return None
        def add_host(self, name):
            host = Host(name)
            self.hosts.append(host)
            return host

    class Host(object):
        def __init__(self, name):
            self.name = name

    class MockVariableManager(object):
        def __init__(self):
            self._loader = None
            self._hostvars = None
        def get_vars(self, host, include_hostvars):
            return {}
        def __getstate__(self):
            return {}

# Generated at 2022-06-23 14:59:14.910578
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    """ HostVars.__getitem__() does not interpret the vars """

    class MyHost:
        def __init__(self, name):
            self.name = name

    class MyVariableManager:
        def __init__(self, data, loader):
            self._loader = loader
            self._data = data
            self._hostvars = None

        def set_host_variable(self, host, varname, value):
            self._data[host.name][varname] = value

        def set_nonpersistent_facts(self, host, facts):
            self._data[host.name]['ansible_facts'] = facts

        def set_host_facts(self, host, facts):
            self._data[host.name]['ansible_facts'] = facts


# Generated at 2022-06-23 14:59:23.488277
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager,
                                 host_list='tests/inventory/host_vars_deepcopy_test')
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.get('localhost')

    import copy
    hostvars_copy = copy.deepcopy(hostvars)
    assert hostvars_copy._variable_manager._loader is not None
    assert hostvars_copy._variable_manager._hostvars is hostvars_copy
   

# Generated at 2022-06-23 14:59:32.230019
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory

    loader = DictDataLoader({})
    inventory = MockInventory(loader=loader)
    variable_manager = MockVariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Note that this is calling the actual method
    assert len(hostvars) == 0

    inventory._hosts['localhost'] = None
    assert len(hostvars) == 1

    inventory._hosts['otherhost'] = None
    assert len(hostvars) == 2



# Generated at 2022-06-23 14:59:41.075442
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources='')
    host = inventory.add_host('foohost')
    host.vars['foo'] = 'foo'

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert 'foo' in hostvars.get('foohost')

    host.vars = {'foo': 'bar'}
    assert 'foo' in hostvars.get('foohost')

    hostvars_copy = deepcopy(hostvars)
    assert 'foo' in hostvars_copy.get('foohost')

# Generated at 2022-06-23 14:59:44.512972
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert len(HostVarsVars({}, None)) == 0
    assert len(HostVarsVars({'foo': 'bar'}, None)) == 1
    assert len(HostVarsVars({'foo': 'bar', 'baz': 'qux'}, None)) == 2

# Generated at 2022-06-23 14:59:55.525860
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # We do not have a real inventory and real variable manager here, mock them
    class _Host:
        def __init__(self, host_name):
            self.name = host_name
        def get_name(self):
            return self.name

    class _Inventory:
        def __init__(self, _hosts):
            self._hosts = _hosts
            # method to satisfy interface
            def get_host(self, host_name):
                return host_name
        def __iter__(self):
            for host in self._hosts:
                yield host

    class _VariableManager:
        def __init__(self, _vars):
            self._vars = _vars
            # methods to satisfy interface
            def set_host_variable(self, host, var, val):
                pass

# Generated at 2022-06-23 15:00:06.827842
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars import include_vars
    from ansible.parsing.dataloader import DataLoader

    group1 = dict(
        hosts=['host1', 'host2'],
        vars=dict(
            group1_var1='group1_value1',
            group1_var2='group1_value2',
            group1_var3='group1_value3',
        )
    )

# Generated at 2022-06-23 15:00:14.401476
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    from ansible.compat.tests import unittest
    from ansible.module_utils.common._collections_compat import Mapping
    import os
    import sys

    # pylint: disable=unused-argument
    class MockLoader(object):

        def path_dwim(self, basedir, filename):
            return basedir + filename

        def load_from_file(self, filepath):
            return 'some_content'

    class MockFile(object):

        def __init__(self, pathname=None):
            self.pathname = pathname

        def isfile(self):
            return False

    class MockOs(object):

        def __init__(self):
            self.mock_file = MockFile()

        def path(self, pathname):
            self.mock_file.path

# Generated at 2022-06-23 15:00:26.332607
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    dummy_host = 'dummy_host'

    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    host = inventory.get_host(dummy_host)
    test_dict = {'test_key': 'test_val'}

    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    hostvars.set_host_variable(host, 'test_key', 'test_val')

    # assert that hostvars['dummy_host'] is equal to the test_dict

# Generated at 2022-06-23 15:00:31.337090
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    class MockInventory(object):
        def get_host(self, hostname):
            return hostname

    class MockVariableManager(object):
        def __init__(self, loader):
            self._loader = loader
            self._hostvars = None

        def get_vars(self, host=None, include_hostvars=True):
            return 'dummy'

        def set_host_variable(self, host, varname, value):
            pass

        def set_nonpersistent_facts(self, host, facts):
            pass

        def set_host_facts(self, host, facts):
            pass

    class MockLoader(object):
        def __init__(self):
            pass

        def get_basedir(self):
            return 'basedir'

    inventory = MockInventory()
    loader = Mock

# Generated at 2022-06-23 15:00:41.782629
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # To prevent importing the actual Ansible modules, mock the required
    # objects
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    ), loader=loader, variable_manager=VariableManager())


# Generated at 2022-06-23 15:00:51.479732
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.plugins import vars_plugins

    i = Inventory("")
    i.add_host(FakeHost("h1"))
    i.add_host(FakeHost("h2"))
    i.add_host(FakeHost("h3"))
    i.add_host(FakeHost("h4"))

    # Clear vars_plugins.__vars_plugins__, because in real Ansible it is
    # initialized automatically in ansible.plugins.__init__.
    vars_plugins.__get_vars_loader_class__.__vars_plugins__ = {}

    vm = VariableManager()

# Generated at 2022-06-23 15:01:01.924325
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    loader = context.CLIARGS.get('loader', None)
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # It should return 0 if there are no hosts
    assert len(hostvars) == 0

    # It should return 1 if there is one host
    inventory.hosts.add(u'anyhost')
    assert len(hostvars) == 1

   

# Generated at 2022-06-23 15:01:11.889171
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Assign a value to a host variable
    host = inventory.get_host('localhost')
    facts = dict(foo='bar')
    variable_manager.set_host_facts(host, facts)

    # Verify that the host variable was assigned
    assert 'foo' in hostvars['localhost']

    # Make a copy of hostvars
    hostvars_copy = copy.deepcopy(hostvars)

    # Verify that the host variable is present in the copy too

# Generated at 2022-06-23 15:01:22.382686
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    inventory = None
    loader = None
    variable_manager = None

    hostvars = HostVars(inventory, variable_manager, loader)
    assert(hostvars._loader is None)
    assert(hostvars._variable_manager._loader is None)
    assert(hostvars._variable_manager._hostvars is None)

    hostvars._loader = dict()
    hostvars._variable_manager._loader = dict()
    hostvars._variable_manager._hostvars = dict()
    assert(hostvars._loader is not None)
    assert(hostvars._variable_manager._loader is not None)
    assert(hostvars._variable_manager._hostvars is not None)

    hostvars.__setstate__(dict())
    assert(hostvars._loader is not None)

# Generated at 2022-06-23 15:01:31.744126
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    v = HostVarsVars({'a': '1', 'b': '2', 'c': '{{ d }}', 'd': '{{ a }}'}, None)
    assert(v == {'a': '1', 'b': '2', 'c': '1', 'd': '{{ a }}'})
    v = HostVarsVars({'a': '1', 'b': '2', 'c': '{{ d }}'}, None)
    assert(v == {'a': '1', 'b': '2', 'c': AnsibleUndefined()})
    v = HostVarsVars(dict(), None)
    assert(v == dict())

# Generated at 2022-06-23 15:01:32.746538
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    hv = HostVarsVars({}, None)

# Generated at 2022-06-23 15:01:36.609383
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager

    hostvars = HostVars(None, VariableManager(loader=None), loader=None)
    hostvars.__deepcopy__({})

    # Check that None is not returned
    assert hostvars is not None

# Generated at 2022-06-23 15:01:44.655928
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import unittest
    import mock

    class MockHost(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class MockInventory(object):
        def __init__(self):
            self._hosts = {}

        def add_host(self, host_name):
            self._hosts[host_name] = MockHost(host_name)

        def get_host(self, host_name):
            if host_name in self._hosts:
                return self._hosts[host_name]
            return None

        @property
        def hosts(self):
            return self._hosts.values()

    class MockVariableManager(object):
        def __init__(self):
            self._hostvars = {}

       

# Generated at 2022-06-23 15:01:51.834417
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create a simple variable (dictionary)
    foo = {'key': 'value'}

    # Create HostVarsVars
    hvv = HostVarsVars(foo, None)

    # Print HostVarsVars
    print(hvv)

if __name__ == '__main__':
    test_HostVarsVars___repr__()

# Generated at 2022-06-23 15:01:55.920042
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert len(HostVarsVars(dict(), None)) == 0
    assert len(HostVarsVars(dict(foo='foo'), None)) == 1
    assert len(HostVarsVars(dict(foo='foo', bar='bar'), None)) == 2


# Generated at 2022-06-23 15:02:02.089651
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    inventory.add_host(Host(name='fake_host'))
    hostvars = HostVars(inventory, variable_manager, loader)

    assert 'fake_host' in hostvars
    assert 'non_existing_host' not in hostvars

# Generated at 2022-06-23 15:02:13.200184
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.plugins import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    play_context = dict()
    play_context['port'] = 22

    # Test for normal scenarios

# Generated at 2022-06-23 15:02:18.973449
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    """Return an iterator object"""
    vars = {'hostvar_1': 'value_1', 'hostvar_2': 'value_2'}
    hvv = HostVarsVars(vars, None)
    res = []
    for k in hvv.__iter__():
        res.append(k)
    assert res == ['hostvar_1', 'hostvar_2']


# Generated at 2022-06-23 15:02:23.983559
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {'foo': 'bar'}
    loader = None
    hostvars = HostVarsVars(variables, loader)
    assert repr(hostvars) == repr(variables)

    variables = {'foo': '{{bar}}', 'bar': 'baz'}
    loader = None
    hostvars = HostVarsVars(variables, loader)
    assert repr(hostvars) == repr({'foo': 'baz', 'bar': 'baz'})

# Generated at 2022-06-23 15:02:32.852820
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    assert len(hostvars) == 1, \
        "Unexpected number of hosts in HostVars: {0}".format(str(len(hostvars)))

# Generated at 2022-06-23 15:02:36.695808
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    unittest.TestCase.assertEqual(
        unittest.TestCase(), HostVarsVars.__len__, HostVarsVars({'test': 'test'}, None), 1)


# Generated at 2022-06-23 15:02:47.369715
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    class DummyVariableManager(VariableManager):
        '''
        Dummy VariableManager class for unit testing of method
        __contains__ of class HostVarsVars.
        '''
        def __init__(self, *args, **kwargs):
            self._host_vars = {}
            self._nonpersistent_facts = {}
            self._vars_cache = {}

            # This attribute is needed to work properly in
            # AnsibleUndefined.__getattribute__
            self._templar = None

    # In Python2.6's Mapping, methods keys and values return iterators
    # instead of lists. We need to wrap them into lists so that we can
    # compare them with lists.

# Generated at 2022-06-23 15:02:57.421487
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    inv = Inventory("tests/inventory")
    vm = VariableManager(loader=DataLoader(), inventory=inv)
    # Remember, the inventory has a HostVars object assigned
    hv = inv.host_vars

    # First, check if the hostvars attribute is correctly set in the initial state
    assert hv._variable_manager._hostvars is not None
    assert hv._variable_manager._hostvars is hv

    # Then create a new variable manager, assigning it to the HostVars object
    new_vm = VariableManager(loader=DataLoader(), inventory=inv)
    hv.set_variable_manager(new_vm)

    # Check if the new variable manager has the new HostVars object assigned
    assert new_vm._hostvars is not None
    assert new_vm._hostvars is hv

    # And

# Generated at 2022-06-23 15:03:03.615780
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    '''
    Test for method set_variable_manager
    '''
    # A more complete test is done in test_VariableManager.test_set_hostvars
    hostvars = HostVars({}, None, None)
    var_mgr = object()
    hostvars.set_variable_manager(var_mgr)
    assert hostvars._variable_manager is var_mgr

# Generated at 2022-06-23 15:03:13.064216
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(variable_manager=variable_manager, loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)
    variable_manager.set_host_variable("localhost", "testvar", "testhostvarvalue")
    assert hostvars["localhost"].get("testvar") == "testhostvarvalue"
    variable_manager.remove_host_variable("localhost", "testvar")
    assert hostvars["localhost"].get("testvar") is None
    variable_manager.set_host_variable("localhost", "testvar", "testhostvarvalue")
    assert host

# Generated at 2022-06-23 15:03:21.182427
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Test when inventory is empty
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    vars = HostVars(inventory=inventory, variable_manager=None, loader=loader)
    assert len(vars) == 0

    # Test when inventory is not empty
    inventory._hosts_cache = {'host1': None, 'host2': None}
    assert len(vars) == 2



# Generated at 2022-06-23 15:03:30.179683
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # NOTE: All Unit tests for class HostVarsVars should be loaded before
    # loading class HostVars in order to mock the tested method of class
    # HostVarsVars within the mock of __len__.

    import sys
    import mock
    from ansible.template import Templar

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import text_type

    assert sys.version_info >= (2, 7)

    # Load the module under test
    HostVarsVars = sys.modules[__name__].HostVarsVars

    # Create a mock object for the class AnsibleUndefined and patch it
    # into the namespace of module ansible.template.


# Generated at 2022-06-23 15:03:34.556014
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = None
    variables = {'a': '1', 'b': '2', 'c': '3'}
    hostvarsvars = HostVarsVars(variables=variables, loader=loader)

    assert variables == hostvarsvars

# Generated at 2022-06-23 15:03:40.810517
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from units.mock.loader import DictDataLoader
    hvv = HostVarsVars({'a': 1}, loader=DictDataLoader({'hostvars': '{{ variable }}'}))
    assert(hvv.__contains__('a'))
    assert(hvv.__contains__('b') == False)


# Generated at 2022-06-23 15:03:45.487762
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible import context
    from ansible.parsing.dataloader import DataLoader

    context.CLIARGS = {}
    loader = DataLoader()
    inventory = InventoryManager(loader, sources="localhost")
    variable_manager = VariableManager(loader, inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(hostvars) == 1
    assert 'localhost' in hostvars
    assert hostvars['localhost'] == hostvars.get('localhost')
    assert isinstance(hostvars['localhost'], HostVarsVars)

# Generated at 2022-06-23 15:03:49.662284
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Inventory

    hv = HostVars(inventory=Inventory(loader=None), variable_manager=None, loader=None)
    hv.set_host_facts({}, {'foo': 'bar'})

# Generated at 2022-06-23 15:03:55.383611
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars.unsafe_proxy import wrap_var
    hv = HostVars({}, None, None)
    wrapped_hv = wrap_var(hv)
    deep_copied = deepcopy(wrapped_hv)
    assert wrapped_hv is deep_copied

# Generated at 2022-06-23 15:04:03.428882
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import ansible.vars.hostvars
    import ansible.vars.variable_manager

    # Temporary hostvars to get the state of the class HostVars
    hostvars = ansible.vars.hostvars.HostVars(
        inventory=None,
        variable_manager=ansible.vars.variable_manager.VariableManager(),
        loader=None)

    state = hostvars.__getstate__()

    # Empty hostvars to assign the previous state
    hostvars = ansible.vars.hostvars.HostVars(
        inventory=None,
        variable_manager=ansible.vars.variable_manager.VariableManager(),
        loader=None)

    hostvars.__setstate__(state)

# Generated at 2022-06-23 15:04:05.619213
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    h = HostVarsVars({'a': 1, 'b': 2}, None)
    assert len(h) == 2


# Generated at 2022-06-23 15:04:07.583490
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    pass

# Generated at 2022-06-23 15:04:15.043698
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

    hostvars = HostVars(inventory, variable_manager, loader)

    assert 'myhost' not in hostvars

    inventory.add_group('mygroup')
    inventory.add_host(host='myhost', group='mygroup')

    assert 'myhost' in hostvars

# Generated at 2022-06-23 15:04:24.674326
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Create some data to put in the dict
    dict_a = dict(a='1', b='2')
    dict_b = dict(c='3', d='4')
    dict_c = dict(e='5', f='6')

    # Create the dict and add the data
    hv = HostVars(dict())
    hv.set_host_variable('a', 'first', dict_a)
    hv.set_host_variable('b', 'first', dict_b)
    hv.set_host_variable('c', 'first', dict_c)

    # Arrange the expected output
    expected = dict()
    expected['a'] = dict_a
    expected['b'] = dict_b
    expected['c'] = dict_c

    # Test

# Generated at 2022-06-23 15:04:31.535129
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    '''
    This tests a fix for issue #19589, whereby HostVars.set_variable_manager
    fails to correctly set the _variable_manager, if the _variable_manager
    has already been pickled.
    '''

    import pickle
    import sys

    from ansible.vars import VariableManager

    # set up a VariableManager
    variable_manager = VariableManager()
    variable_manager._loader = 1
    variable_manager._hostvars = 1

    # pickle it, to simulate a pre-existing pickle
    variable_manager_pickle = pickle.dumps(variable_manager, protocol=2)

    # un-pickle it
    variable_manager = pickle.loads(variable_manager_pickle)

    # Now, let's set up the HostVars

# Generated at 2022-06-23 15:04:36.380137
# Unit test for constructor of class HostVars
def test_HostVars():
    if __name__ == '__main__':
        test_HostVars()
    else:
        from units.compat import unittest

        class TestHostVars(unittest.TestCase):
            def test_HostVars(self):
                from ansible.inventory import Inventory
                from ansible.vars import VariableManager
                from ansible.parsing.dataloader import DataLoader

                loader = DataLoader()
                inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
                hv = HostVars(inventory=inventory, variable_manager=VariableManager(loader=loader), loader=loader)

                hv.set_variable_manager(VariableManager(loader=loader))

# Generated at 2022-06-23 15:04:45.799126
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inv = InventoryManager(loader=DataLoader(), sources=["tests/inventory_file"])

    vars_manager = VariableManager(loader=DataLoader(), inventory=inv)
    hostvars = vars_manager._hostvars

    import copy
    copied_hostvars = copy.deepcopy(hostvars)

    assert hostvars is not copied_hostvars
    assert copied_hostvars._variable_manager is not hostvars._variable_manager
    assert copied_hostvars._loader is hostvars._loader

# Generated at 2022-06-23 15:04:49.699732
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    new_variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars.set_variable_manager(new_variable_manager)
    assert new_variable_manager._hostvars == hostvars

# Generated at 2022-06-23 15:05:00.238250
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    class MockHost():
        name = 'testhost'

    class MockInventory():
        host_list = []

        def get_host(self, host_name):
            return next(h for h in self.host_list if h.name == host_name)

        def add_host(self, new_host):
            self.host_list.append(new_host)

    class MockVariableManager():

        def __init__(self):
            self.host_facts = {}

        def set_host_facts(self, host, facts):
            self.host_facts[host.name] = facts

    m_inv = MockInventory()
    m_inv.add_host(MockHost())

    m_var_mgr = MockVariableManager()


# Generated at 2022-06-23 15:05:08.166609
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager, HostVars
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    inv.add_host(Host('test_host'))
    hostvars = HostVars(inv, variable_manager=VariableManager(loader=loader), loader=loader)
    list(hostvars)

# Generated at 2022-06-23 15:05:18.825814
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.template import Templar, AnsibleUndefined, hostvars

    loader = None
    templar = Templar(loader=loader, variables=None)
    var1 = 'ansible_all_ipv4_addresses'
    var2 = var1 + 's'
    var3 = 'foo'
    variables = {var1: u'192.168.1.1', var2: ['192.168.1.2', '192.168.1.3'], var3: u'bar'}
    host = 'localhost'
    hostvars = HostVarsVars(variables, loader=loader)

    assert isinstance(hostvars, HostVarsVars)
    assert isinstance(hostvars[var1], unicode)
    assert isinstance(hostvars[var2], list)

# Generated at 2022-06-23 15:05:26.567611
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import os
    from ansible.errors import AnsibleError

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory_manager = InventoryManager(loader=DataLoader())
    inventory_manager.add_host('localhost')
    inventory_manager.add_group('group')
    inventory_manager.add_child('group', 'localhost')
    inventory_manager._inventory._hosts_cache['otherhost'] = None

    hostvars = HostVars(inventory_manager, VariableManager(loader=DataLoader()), DataLoader())
    hostvars.set_host_variable('localhost', 'a', 1)
    hostvars.set_host_variable('localhost', 'b', 2)


# Generated at 2022-06-23 15:05:38.177139
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    manager = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=manager)
    hostvars = HostVars(inventory=manager, variable_manager=variable_manager, loader=None)

    assert variable_manager._hostvars == hostvars

    variable_manager = variable_manager.set_inventory(inventory=None)
    variable_manager = variable_manager.set_loader(loader=None)

    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    variable_manager = hostvars.set_variable_manager(variable_manager=variable_manager)

    assert variable_manager._loader is hostvars._loader
    assert variable_manager._hostv

# Generated at 2022-06-23 15:05:48.902182
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Create initial variables
    play_context = PlayContext()
    initial_vars = {
        'vault_password': VaultSecret('password'),
        'omit': [],
        'groups': {},
        'inventory_hostname_short': 'test',
        'inventory_hostname': 'test',
        'group_names': [],
        'role_names': [],
        'playbook_dir': '/test/dir',
        'play_hosts': [],
        'ansible_play_role_names': [],
        'ansible_role_names': [],
    }

    # Create HostVarsVars from

# Generated at 2022-06-23 15:05:54.288803
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Test for issue #16258
    hostvarsvars = HostVarsVars(variables={'foo': '{{ bar }}', 'bar': '{{ foo }}'}, loader={})
    assert hostvarsvars['foo'] == hostvarsvars['bar'] == "{ foo }}"

# Generated at 2022-06-23 15:06:04.517306
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.template import Templar
    templar = Templar()

    class fake_loader(object):
        def __init__(self, vars):
            self._vars = vars

        def get_basedir(self):
            return None

    class fake_host_variable_manager(object):
        def __init__(self, vars):
            self._vars = vars

        def get_vars(self, host, include_hostvars=True):
            return self._vars

    loader = fake_loader({'foo': 'bar'})
    variable_manager = fake_host_variable_manager({'foo': 'bar'})
    hostvars = HostVars(None, variable_manager, loader)
    assert hostvars['fake_host'] == {'foo': 'bar'}

# Unit

# Generated at 2022-06-23 15:06:07.780288
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = DictDataLoader({})
    x = HostVarsVars({'foo': 'bar'}, loader=loader)
    assert x.get('foo') == 'bar'


# Generated at 2022-06-23 15:06:15.717073
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    assert len(HostVarsVars(variables={}, loader=DataLoader())) == 0
    assert len(HostVarsVars(variables=dict(a=1, b=2), loader=DataLoader())) == 2

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(c=3)
    variable_manager.options_vars = dict(d=4)

    assert len(HostVarsVars(variables=variable_manager._get_vars(), loader=DataLoader())) == 4

# Generated at 2022-06-23 15:06:23.149070
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible import variables

    loader = DictDataLoader({})
    host_name = 'test'
    inventory = DictInventory({host_name: 'test_group'})
    variable_manager = variables.VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars[host_name] == hostvars.raw_get(host_name) == {}



# Generated at 2022-06-23 15:06:31.891752
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Set up inventory and variable manager
    loader = DataLoader()
    inventory = InventoryManager(loader, ['localhost'])

    # Set up HostVars
    hostvars = HostVars(inventory, loader)

    # Set up a new variable manager and replace the current one
    variable_manager = loader.set_variable_manager()
    hostvars.set_variable_manager(variable_manager)

    assert hostvars._variable_manager is variable_manager
    assert hostvars._variable_manager._hostvars is hostvars

# Generated at 2022-06-23 15:06:38.718682
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # testing when there are hosts
    assert len(HostVars(inventory=MockingInventory(list()), variable_manager=MockingVariableManager(), loader=MockingLoader())) == 0
    # testing when there are no hosts
    assert len(HostVars(inventory=MockingInventory(['localhost']), variable_manager=MockingVariableManager(), loader=MockingLoader())) == 1



# Generated at 2022-06-23 15:06:44.018706
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.vars.ini import VarsModule as iniVarsModule
    from ansible.plugins.vars.yaml import VarsModule as yamlVarsModule
    from ansible.plugins.vars.json import VarsModule as jsonVarsModule
    vars_man = VariableManager()
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=[])
    hostvars = HostVars(inv, vars_man, loader)

# Generated at 2022-06-23 15:06:55.562017
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars.hostvars import HostVars

    data = {'a': {'b': {'c': 3}}}
    hostvars = HostVars(data, None, None)
    assert data['a']['b']['c'] == 3

    data['a']['b']['c'] = 4
    assert data['a']['b']['c'] == 4

    data2 = deepcopy(data)
    assert data2['a']['b']['c'] == 4

    data['a']['b']['c'] = 5
    assert data['a']['b']['c'] == 5
    assert data2['a']['b']['c'] == 4

# Generated at 2022-06-23 15:07:08.493887
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.vvvv('TESTING __len__')

    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.task import Task

    from ansible.vars import VariableManager, HostVars
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    hostvars = HostVars(inventory, VariableManager(), loader)

    vars_ = {
        'greeting': 'Hello',
        'recipient': 'world',
    }

    hostvarsvars = HostVarsVars

# Generated at 2022-06-23 15:07:15.538224
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    mock_loader = MagicMock()
    mock_inventory = MagicMock()
    mock_host = Host(name='localhost', port=22)

    variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)
    variable_manager._hostvars = HostVars(mock_inventory, variable_manager, mock_loader)
    variable_manager.set_host_variable(mock_host, 'foo', 'bar')
    variable_manager.set_host_variable(mock_host, 'baz', 'froz')
    variable_manager.set_host_variable(mock_host, 'bar', 'baz')


# Generated at 2022-06-23 15:07:27.785396
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.template import Templar
    my_inventory = Inventory()
    variable_manager = VariableManager()
    variable_manager.set_inventory(my_inventory)
    variable_manager._loader = variable_manager.get_vars = variable_manager.get_host_vars = lambda: {}
    my_hostvars = HostVars(my_inventory, variable_manager, variable_manager._loader)
    # Verify that HostVars and VariableManager have the same inventory reference
    assert my_inventory is variable_manager._inventory is my_hostvars._inventory
    my_other_inventory = Inventory()
    # Verify that HostVars and VariableManager have the same inventory reference after set_inventory

# Generated at 2022-06-23 15:07:31.092776
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    hostvars.set_host_facts(host='foo', facts={'foo': 'bar'})



# Generated at 2022-06-23 15:07:35.055723
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    variables = {
        'a': 'b',
    }
    loader = 'dummy_loader'
    hostvar = HostVarsVars(variables, loader)
    assert repr(hostvar) == '{u\'a\': u\'b\'}'

# Generated at 2022-06-23 15:07:45.841854
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    variables = {
        "a": "b",
        "d": "e",
        "f": "g",
    }

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    hostvars.set_host_facts(inventory.get_host('localhost'), variables)
    assert hostvars['localhost']['a'] == 'b'
    assert hostvars['localhost']['d'] == 'e'
    assert hostvars['localhost']['f'] == 'g'


# Generated at 2022-06-23 15:07:53.834398
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import os
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=os.path.join(os.path.dirname(__file__), 'test_inventory.yml'))

    hostvars = HostVars(inventory, variable_manager, loader)

    assert 'test_inventory_test_group_test_subgroup_test_host_dns' in hostvars
    assert 'test_inventory_test_group_test_subgroup_test_host_dns_alias' in hostvars

# Generated at 2022-06-23 15:08:02.151734
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    inventory = Inventory(host_list=['localhost'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)
    facts = dict(fact1='value1')

    hostvars.set_nonpersistent_facts(inventory.get_host('localhost'), facts)
    assert variable_manager.get_vars(host=inventory.get_host('localhost'))['ansible_nonpersistent_fact'].fact1 == 'value1'

# Generated at 2022-06-23 15:08:11.751096
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from collections import namedtuple
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    FakeGroup = namedtuple('FakeGroup', ['vars'])
    FakeHost = namedtuple('FakeHost', ['vars', 'name'])

    # Create inventory
    i = Inventory(loader=None)
    # Add host
    i.add_group('my_group')
    i.add_host(FakeHost(vars={'some_var': 'foo'}, name='my_host'))
    i.get_group('my_group').add_host(i.get_host('my_host'))
    # Add group vars
    i.get_group('my_group').vars = {'some_group_var': 'bar'}
    # Add group with group_vars subdir

# Generated at 2022-06-23 15:08:21.902761
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    # Implementation
    class MockVariables(dict):
        # Implements method __iter__
        def __iter__(self):
            # Implement a mock
            for var in self.keys():
                yield var

    mock_variables = MockVariables(foo='foo', bar='bar')
    mock_loader = object()
    variables = HostVarsVars(mock_variables, mock_loader)

    # Test execution
    iterator = iter(variables)

    # Assertions
    assert 'foo' == next(iterator)
    assert 'bar' == next(iterator)
    try:
        next(iterator)
        raise AssertionError()
    except StopIteration:
        pass

# Generated at 2022-06-23 15:08:27.918880
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {'foo': 'bar'}
    loader = None

    hostvarsvars = HostVarsVars(variables=variables, loader=loader)
    assert len(hostvarsvars) == 1

    # Test __iter__.
    list_vars = []
    for var in hostvarsvars:
        list_vars.append(var)

    assert len(list_vars) == 1
    assert list_vars[0] == 'foo'



# Generated at 2022-06-23 15:08:31.914436
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars import VariableManager

    hostvars = HostVars(None, VariableManager())
    hostvars.set_host_facts(None, {'a': 'b'})
    assert hostvars.get('localhost')['a'] == 'b'

# Generated at 2022-06-23 15:08:36.494347
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(host_list=[])
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert repr(hostvars) == '{}'

# Generated at 2022-06-23 15:08:47.776266
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import sys
    import pickle

    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    from ansible.vars.unsafe_proxy import wrap_var

    # Create an empty inventory
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    manager = InventoryManager(loader=loader, sources=[])
    inventory = manager.inventory

    # Create a variable manager
    from ansible.vars import VariableManager

    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader)

    # Make sure it's wrapped properly
    assert isinstance(hostvars, wrap_var(hostvars))

    # Put some

# Generated at 2022-06-23 15:08:52.836211
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    variable_manager = object()
    loader = object()
    hostvars = HostVars(object(), variable_manager, loader)

    import copy
    hostvars_copy = copy.deepcopy(hostvars)

    assert hostvars is hostvars_copy

# Generated at 2022-06-23 15:09:01.763455
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create inventory
    loader = object()
    inventory = InventoryManager(loader=loader)

    # Create variable manager
    vars_manager = VariableManager(loader=loader, inventory=inventory)

    # Create host vars
    hostvars = HostVars(inventory=None, variable_manager=vars_manager, loader=None)

    # Set inventory to hostvars
    hostvars.set_inventory(inventory)

    # Check that inventory was set to hostvars
    assert(hostvars._inventory is inventory)

    # Set inventory to variable manager
    vars_manager.set_inventory(inventory)

    # Check that inventory was set to variable manager
    assert(vars_manager._inventory is inventory)