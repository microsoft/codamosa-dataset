

# Generated at 2022-06-23 14:59:04.434196
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    import os

    test_host = Host(name='testhost')
    test_host.set_variable('a',1)
    test_host.set_variable('b',2)
    test_host.set_variable('c',3)
    test_host.set_variable('d',4)

    host_list = [test_host]
    inventory = Inventory(loader=None, host_list=host_list)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    vars = HostVarsV

# Generated at 2022-06-23 14:59:07.436980
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-23 14:59:12.659316
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    variables = dict(foo=dict(a=1, b=2))
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    hostvars.set_host_variable('testhost', 'ansible_foo', 'testval')
    assert hostvars.raw_get('testhost')['ansible_foo'] == 'testval'

# Generated at 2022-06-23 14:59:19.727702
# Unit test for constructor of class HostVars
def test_HostVars():
    import mock

    inventory_mock = mock.Mock()
    loader_mock = mock.Mock()
    variable_manager_mock = mock.Mock()

    host_vars_object = HostVars(inventory_mock, variable_manager_mock, loader_mock)

    assert host_vars_object._inventory == inventory_mock
    assert host_vars_object._loader == loader_mock
    assert host_vars_object._variable_manager == variable_manager_mock



# Generated at 2022-06-23 14:59:30.614509
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.utils.shlex import shlex_split
    # Setup a mock inventory
    from ansible.inventory.manager import InventoryManager
    mock_loader = 'ansible_inventory'
    mock_hosts = [
        'server1',
        'server2',
        'server3',
    ]
    mock_inventory = InventoryManager(loader=mock_loader, sources=",".join(mock_hosts))
    mock_inventory.subset('all')

    # Setup a mock variable manager
    from ansible.vars.manager import VariableManager
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)

    # Initialize hostvars
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-23 14:59:35.919286
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # We need the data directory for testing, but the functions
    # related to the data directory are in the ansible.parsing.vault file.
    # To get the variables data directory without loading ansible.parsing.vault
    # we cheat by temporarily adding a value to the package namespace.
    # This is a hack that should be replaced by a refactor of the
    # ansible.parsing.vault module.
    import ansible.parsing.vault
    import os
    import sys
    import pytest

    data_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'vars')
    ansible.parsing.vault.__dict__['__ansible_test_data_dir'] = data_dir

# Generated at 2022-06-23 14:59:43.647795
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import unittest.mock as mock

    host_vars_obj = HostVars(None, None, None)

    # No host
    host_vars_obj._inventory.hosts = []

    assert len(list(host_vars_obj.__iter__())) == 0

    # Has one host
    host_1 = mock.Mock()
    host_vars_obj._inventory.hosts = [host_1, ]

    assert len(list(host_vars_obj.__iter__())) == 1

# Generated at 2022-06-23 14:59:45.575213
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.plugins.loader.vars.hostvars import HostVars
    from collections import Mapping
    assert(isinstance(HostVars, Mapping))

# Generated at 2022-06-23 14:59:56.923492
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data_loader = DataLoader()
    inventory_manager = InventoryManager(loader=data_loader, sources=['localhost,'])

    original_hostvars = HostVars(inventory=inventory_manager, loader=data_loader, variable_manager=VariableManager(loader=data_loader))
    assert 'localhost' in original_hostvars

    new_hostvars = copy.deepcopy(original_hostvars)
    new_hostvars.set_inventory(InventoryManager(loader=data_loader, sources=['localhost,']))
    assert new_hostvars['localhost'] == original_hostvars['localhost']

    # The original HostVars should not contain

# Generated at 2022-06-23 15:00:08.348691
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    test_loader = DictDataLoader({})
    test_vars = {
        'a': 'A',
        'b': 'B',
        'c': '{{a}}',
        'd': '{{b}}',
        'e': '{{c}}',
        'f': '{{d}}',
    }

    test_instance = HostVarsVars(variables=test_vars, loader=test_loader)

    test_result = {
        'a': 'A',
        'b': 'B',
        'c': 'A',
        'd': 'B',
        'e': 'A',
        'f': 'B',
    }

# Generated at 2022-06-23 15:00:14.825587
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import types
    import sys
    import copy


    if sys.version[0] >= '3':
        class R1(Mapping):
            def __init__(self):
                pass
            def __getitem__(self, key):
                raise KeyError
            def __contains__(self, key):
                return True
            def __iter__(self):
                return iter(())
            def __len__(self):
                return 0
            def __repr__(self):
                return '{}'
            def __deepcopy__(self, memo):
                return copy.copy(self)
    else:
        # Python 2 requires class has to inherit from object
        class R1(Mapping, object):
            def __init__(self):
                pass
            def __getitem__(self, key):
                raise

# Generated at 2022-06-23 15:00:21.650672
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.extra_vars = dict(foo='bar')
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'ansible_python_interpreter', '/bin/python3')
    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert hostvars['localhost']['ansible_python_interpreter'] == '/bin/python3'
    assert hostvars['localhost']['foo'] == 'bar'

# Generated at 2022-06-23 15:00:28.886285
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import copy

    # create templar
    templar = Templar({}, loader=None)
    # create a copy and backup the copy
    foo = copy.deepcopy(templar.available_variables['hostvars'])
    foo_backup = copy.deepcopy(foo)
    # add 'hostvars' to available_variables
    templar.available_variables['hostvars'] = {'a': 'A', 'b': '{{b}}'}

    # test HostVarsVars
    hostvarsvars = HostVarsVars(templar.available_variables['hostvars'], loader=None)

    assert hostvarsvars['a'] == 'A'

# Generated at 2022-06-23 15:00:33.783907
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    inventory = MockInventory(
        loader=loader,
        host_list=[
            'test_inventory',
            'test_inventory_ignore',
        ]
    )

    vars_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=vars_manager, loader=loader)

    assert hostvars.__contains__('test_inventory')
    assert not hostvars.__contains__('test_inventory_ignore')
    assert not hostvars.__contains__('test_inventory_not_exists')

# Generated at 2022-06-23 15:00:39.266183
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import pytest
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    hvv = HostVarsVars(variable_manager.get_vars(), None)
    assert sorted(list(hvv.keys())) == sorted(list(hvv.__iter__()))


# Generated at 2022-06-23 15:00:40.194174
# Unit test for constructor of class HostVars
def test_HostVars():
    assert HostVars()


# Generated at 2022-06-23 15:00:46.125184
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    class FakeVariableManager(object):
        def __init__(self):
            self.loader = None
            self.hostvars = None

        def __setstate__(self, state):
            self.__dict__.update(state)

    class FakeLoader():
        pass

    class FakeInventory():
        def __init__(self):
            self.hosts = []

        def get_host(self, host_name):
            for host in self.hosts:
                if host.name == host_name:
                    return host
            return None

        def set_host_variable(self, host, varname, value):
            self.__setattr__(varname, value)

    loader = FakeLoader()
    inventory = FakeInventory()
    variable_manager = FakeVariableManager()
    hostvars = HostVars

# Generated at 2022-06-23 15:00:52.697198
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import sys

    try:
        from collections import Mapping
    except ImportError:
        from collections.abc import Mapping

    class TestMapping(Mapping):
        def __getitem__(self, key):
            raise KeyError(key)
        def __iter__(self):
            return iter(())
        def __len__(self):
            return 0

    test_vars_cache = TestMapping()
    test_variable_manager = TestMapping()
    test_hostvars = HostVars(hostvars=test_vars_cache, variable_manager=test_variable_manager)

    # Test with vars_cache that raises KeyError
    host_name = 'does_not_exist'
    assert host_name not in test_hostvars

# Generated at 2022-06-23 15:01:03.103992
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    class Inventory(object):
        def __init__(self, hosts):
            self.hosts = hosts

        def get_host(self, host_name):
            for host in self.hosts:
                if host.name == host_name:
                    return host
            return None

    class Host(object):
        def __init__(self, name):
            self.name = name
            self.vars = {}

    class VariableManager(object):
        def __init__(self):
            self._hostvars = None
            self._loader = None

        def get_vars(self, host, include_hostvars=True):
            return host.vars

    hosts = [Host('localhost'), Host('another.host')]
    variable_manager = VariableManager()

# Generated at 2022-06-23 15:01:11.792167
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory, Host
    from ansible.vars import VariableManager

    inventory = Inventory(loader=None, variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager()

    a_host = Host(name='a_host')
    b_host = Host(name='b_host')
    c_host = Host(name='c_host')

    inventory.add_host(a_host)
    inventory.add_host(b_host)

    hv = HostVars(inventory, variable_manager, loader=None)

    assert a_host in hv
    assert b_host in hv
    assert c_host not in hv

# Generated at 2022-06-23 15:01:22.287835
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    '''
    Unit test for method set_host_facts of class HostVars.

    Function calls method set_host_facts of class HostVars and checks
    whether the values set by this method can be retrieved in various ways.
    '''
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host

    '''
    Create and populate VariableManager, Inventory and HostVars objects for
    testing purposes.
    '''
    variable_manager = VariableManager()
    inventory = Inventory(variable_manager=variable_manager)
    hostvars = HostVars(inventory, variable_manager, None)
    inventory.add_host(Host('localhost'))

    host = inventory.get_host('localhost')

# Generated at 2022-06-23 15:01:22.958948
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    assert True

# Generated at 2022-06-23 15:01:33.406060
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    loader = DataLoader()
    inv = Inventory(loader=loader, variable_manager=VariableManager())
    hv = HostVars(inv, VariableManager(), loader)

    inv.add_host('localhost')
    inv.add_host('remotehost')

    hv.set_host_variable('remotehost', 'var', 'testval')
    assert hv['remotehost']['var'] == 'testval'

    hv.set_host_variable('remotehost', 'var', 'testval2')
    assert hv['remotehost']['var'] == 'testval2'

# Generated at 2022-06-23 15:01:39.937314
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars.hostvars import HostVars
    # Create a HostVars object
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    # Create a dict that contains the HostVars object
    data = {'foo': hostvars}
    # Deepcopy the data dict
    copy = deepcopy(data)
    # Check that the copy dict contains a HostVars object
    assert(isinstance(copy['foo'], HostVars))

# Generated at 2022-06-23 15:01:46.854294
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    loader = None
    variable_manager = VariableManager()

    hvars = HostVars(inventory, variable_manager, loader)
    assert hvars._inventory == inventory

    hvars.set_inventory(None)
    assert hvars._inventory is None


# Generated at 2022-06-23 15:01:50.257992
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    hv = HostVars({}, VariableManager())
    hv.set_variable_manager(VariableManager())
    assert hv._variable_manager is not None

# Generated at 2022-06-23 15:01:59.561661
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader

    class TestVars(object):
        def __init__(self, **kwargs):
            self.vars = kwargs

        def __getitem__(self, item):
            return self.vars[item]

    loader = DataLoader()

    assert HostVarsVars(TestVars(x='key1'), loader)['x'] == 'key1'

    if PY3:
        assert HostVarsVars(TestVars(x='key2'), loader)['x'] == 'key2'
    else:
        assert HostVarsVars(TestVars(x=u'key2'), loader)['x'] == 'key2'

# Generated at 2022-06-23 15:02:07.793842
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # The followings are based on test_HostVarsVars___getitem__()
    # of test_HostVarsVars.py in Ansible 2.1.1.0

    # NoTemplar used for testing
    class NoTemplar:
        '''
        A mock class of class ansible.template.Templar.

        This class is needed because calling method __getitem__ of class
        HostVarsVars results in calling init method of class
        ansible.template.Templar.
        '''
        def __init__(self, variables, loader):
            pass

        def template(self, val, fail_on_undefined=False, static_vars=None):
            return val


# Generated at 2022-06-23 15:02:16.978630
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import copy

    # Test basic functionality
    hostvars_vars = HostVarsVars({'foo': 'bar'}, None)
    assert hostvars_vars['foo'] == 'bar'

    # Test the result is a copy of the original value
    foo = hostvars_vars['foo']
    foo = 'baz'
    assert foo != hostvars_vars['foo']

    # Test the returned value doesn't contain `self`
    hostvars_vars = HostVarsVars({'self': 'bar'}, None)
    assert 'self' not in hostvars_vars

    # Test the returned value is a deepcopy of the original value
    original_value = {'foo': 'bar'}

# Generated at 2022-06-23 15:02:20.751892
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    variable_manager = 'var_manager'
    hostvars = HostVars('inventory', variable_manager, 'loader')

    assert variable_manager._hostvars is hostvars
    assert variable_manager._loader is 'loader'


# Generated at 2022-06-23 15:02:27.719618
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    host1 = inventory.get_host('host1')
    host2 = inventory.get_host('host2')

    facts1 = dict(foo=1, bar=2)
    facts2 = dict(foo=2, bar=1)

    # set persistent and non-persistent facts for host1
    variable_manager.set_host_variable(host1, 'foo', 2)

# Generated at 2022-06-23 15:02:35.630950
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    host_vars = HostVars({'foo': 'bar'}, variable_manager=None, loader=loader)

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host_vars.set_inventory(inventory)
    host_vars.set_variable_manager(variable_manager)

    assert repr(host_vars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-23 15:02:46.120512
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager

    loader = "loader"
    variable_manager = VariableManager()
    hostvars = HostVars("inventory", variable_manager, loader)
    hostvars_state = hostvars.__getstate__()

    # Assert attribute _loader is not saved by __getstate__
    assert "loader" not in hostvars_state
    assert "_loader" not in hostvars_state

    # Assert attribute _hostvars is not saved by __getstate__
    assert "_hostvars" not in hostvars_state

    # Initialize second instance of HostVars with pickled data
    # of the first one and test method __setstate__
    hostvars2 = HostVars(None, None, None)

# Generated at 2022-06-23 15:02:56.748566
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.parsing.dataloader

    Inventory = ansible.inventory.manager.InventoryManager
    VariableManager = ansible.vars.manager.VariableManager
    DataLoader = ansible.parsing.dataloader.DataLoader

    inventory = Inventory(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())
    host = inventory.get_host('127.0.0.1')

    hostvars.set_host_variable(host, 'foo', 2)
    hostvars.set_host_variable(host, 'bar', 4)


# Generated at 2022-06-23 15:03:08.615914
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager

    inventory_manager = InventoryManager(loader=None, sources=None)
    inventory_manager.add_group("test_group")
    inventory_manager.add_host("test_host")
    inventory_manager.add_host("test_host2")

    variable_manager = VariableManager(loader=None, inventory=inventory_manager)
    variable_manager.set_host_variable("test_host", "var", "value")

    hostvars = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=None)

    data = {'var': 'value'}

    assert len(hostvars) == 3

# Generated at 2022-06-23 15:03:16.952322
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Use AnsibleModule to get ansible-specific imports and also
    # python-specific imports
    from ansible.module_utils.basic import AnsibleModule

    # Set up the module object
    module = AnsibleModule(
        argument_spec={},
    )

    # Some imports and functions used in the test
    from ansible.inventory.manager import InventoryManager
    from collections import namedtuple
    from io import StringIO

    def normalize_attrs(attrs):
        # Normalize attributes of a variable manager to improve
        # comparability of different tests.
        del attrs['_fact_cache']['_module_cache']
        del attrs['_fact_cache']['_memory']

# Generated at 2022-06-23 15:03:27.160903
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible.parsing.dataloader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    loader = ansible.parsing.dataloader.DataLoader()
    vars = HostVarsVars({ 'a': '{{ b }}' }, loader=loader)
    assert 'a' in vars
    assert vars['a'] == '{{ b }}'

    # check recursive templating
    assert 'b' not in vars
    vars = HostVarsVars({ 'a': '{{ b }}', 'b': '{{ c }}', 'c': '{{ d }}', 'd': 'ok' }, loader=loader)
    assert vars['a'] == 'ok'

    # invalid variables

# Generated at 2022-06-23 15:03:29.331141
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # obj = HostVars(inventory, variable_manager, loader)
    # assert len(obj) == 1
    return


# Generated at 2022-06-23 15:03:36.380831
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Find out where is the module consiting of HostVars class
    import inspect
    hostvars_module = inspect.getmodule(HostVars)

    # Create an instance of HostVars
    hostvars_class = getattr(hostvars_module, 'HostVars')
    hostvars = hostvars_class(inventory=None, variable_manager=None, loader=None)

    # Set state for our HostVars instance
    hostvars.__setstate__({})

# Generated at 2022-06-23 15:03:43.249058
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    class FakeItem:
        pass

    class FakeHost:
        def __init__(self, name):
            self.name = name
            self.vars = FakeItem()

    inventory = FakeItem()
    inventory.hosts = [FakeHost('fake1'), FakeHost('fake2')]
    vars_cache = {'fake1': {'var': 'value'}, 'fake2': {'var': 'value'}}

    hv = HostVars(inventory, vars_cache)

    assert repr(hv) == "{'fake1': {'var': 'value'}, 'fake2': {'var': 'value'}}"

# Generated at 2022-06-23 15:03:53.734832
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Ensure that _hostvars and _loader are set to None
    assert (variable_manager._hostvars is None)
    assert (variable_manager._loader is None)

    # Update the state of hostvars and ensure that _hostvars and _loader
    # are restored
    state = {}
    hostvars.__setstate__(state)
    assert (variable_manager._hostvars is hostvars)

# Generated at 2022-06-23 15:03:59.270069
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    variable_manager.vars_cache['test_host'] = 'test_var'
    loader = object()

    hostvars = HostVars(Inventory('host_list'), variable_manager, loader)

    assert 'test_host' in hostvars



# Generated at 2022-06-23 15:04:04.945850
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(["localhost ansible_connection=local"], variable_manager=VariableManager(), loader=DataLoader())
    hostvars = HostVars(inventory, variable_manager=VariableManager(), loader=DataLoader())

    assert hostvars is not None
    assert repr(hostvars['localhost']) == "{'ansible_connection': 'local', 'groups': ['all', 'ungrouped'], 'inventory_file': '', 'inventory_hostname': 'localhost', 'omit': '__omit_place_holder__'}"

# Generated at 2022-06-23 15:04:13.970415
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    class MyVariableManager(object):
        def __init__(self):
            self._hostvars = None
        def set_inventory(self, inventory):
            self._hostvars.set_inventory(inventory)

    class MyLoader(object):
        pass

    class MyInventory(object):
        def __init__(self):
            self._hosts = {}
        def get_host(self, host_name):
            return self._hosts.get(host_name)
        def __iter__(self):
            for host in self._hosts.values():
                yield host

    hostvars = HostVars(None, MyVariableManager(), MyLoader())
    vm = MyVariableManager()
    hostvars.set_variable_manager(vm)
    inventory = MyInventory()
    host = "testhost"
   

# Generated at 2022-06-23 15:04:23.853370
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.playbook.play_context import PlayContext

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    h = Host(name='h')
    hostvars = {'g': 'h'}
    h.set_vars(hostvars)

    g = Group(name='g')
    g.add_host(h)

    i = InventoryManager(loader=DataLoader())
    i.add_group(g)

    v = VariableManager(loader=DataLoader())
    v.set_inventory(i)



# Generated at 2022-06-23 15:04:30.941358
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.template import Templar
    class Loader:
        def get_basedir(self):
            pass

    class Variables:
        def __init__(self):
            self.foo = 'foo'

        def __repr__(self):
            return self.foo

    class TemplarTest(Templar):
        def __init__(self, variables):
            self.variables = variables

        def template(self, data, fail_on_undefined=True, static_vars=None, convert_bare=True, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined_vars=None):
            return data

        def __get_vars(self, fail_on_undefined=True, static_vars=None):
            return self.variables

    vars

# Generated at 2022-06-23 15:04:35.593327
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    host_vars = HostVars(InventoryManager(loader=DataLoader(), sources='localhost'),
                         VariableManager(loader=DataLoader(), sources=[]),
                         loader=DataLoader())
    assert host_vars.raw_get('localhost') == AnsibleUndefined(name="hostvars['localhost']"), "hostvars['localhost'] should be AnsibleUndefined"
    assert host_vars.raw_get('nohost') == AnsibleUndefined(name="hostvars['nohost']"), "hostvars['nohost'] should be AnsibleUndefined"

# Generated at 2022-06-23 15:04:44.969133
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import tempfile

    fake_loader = DataLoader()

    fp = tempfile.TemporaryFile()
    inv = Inventory(loader=fake_loader, variable_manager=VariableManager(), host_list=fp.name)
    inv.add_group('group1')
    inv.add_host(host='host1', group='group1')
    inv.add_host(host='host2', group='group1')

    hostvars = HostVars(inventory=inv, variable_manager=VariableManager(loader=fake_loader, inventory=inv))
    assert len(hostvars) == 3
    assert len(hostvars['host1']) == 0

# Generated at 2022-06-23 15:04:54.579874
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hv = HostVars(inventory, variable_manager, loader)
    host = hv._find_host('localhost')
    hv.set_host_variable(host, 'foo', 'bar')
    assert hv.raw_get('localhost')['foo'] == 'bar'

# Generated at 2022-06-23 15:05:03.190020
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # Setup
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    mock_loader = 'mock_loader'
    mock_inventory = Inventory(loader=mock_loader, host_list=[])
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)

    hostvars = HostVars(mock_inventory, mock_variable_manager, mock_loader)

    mock_host = 'mock_host'

    hostvars.set_host_facts(mock_host, {'foo': 'bar'})

    # Test
    assert mock_host in mock_variable_manager._fact_cache

    # Teardown
    del mock_variable_manager
    del mock_inventory
    del hostvars

# Generated at 2022-06-23 15:05:11.591135
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    class FakeInventory(object):

        def get_host(self, host_name):
            return AnsibleUndefined(name="hostvars['%s']" % host_name)

    class FakeVariableManager(object):

        def __init__(self):
            self._hostvars = None
            self._loader = None

        def get_vars(self, host=None, include_hostvars=False):
            return {"foo": "foo"}

    hv = HostVars(FakeInventory(), FakeVariableManager(), "")
    assert(hv.__contains__("foo") is False)

# Generated at 2022-06-23 15:05:19.577544
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Tests if __len__ works as expected. Otherwise, it will cause other tests to fail.
    from ansible import inventory
    from ansible.vars import VariableManager

    hosts_str = "localhost"
    group_str = "test:%s" % hosts_str

    inventory_param = inventory.Inventory(host_list=hosts_str)
    inventory_param.add_group(group_str)
    inventory_param.add_host(hosts_str)

    hostvars = HostVars(inventory_param, VariableManager(), None)

    assert len(hostvars) == 1



# Generated at 2022-06-23 15:05:26.415763
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Host, Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    host = Host(name="foobar", port=5678, variables={u"ansible_ssh_host": u"foo"}, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager=inventory.get_variable_manager(), loader=loader)
    hostvars.set_host_facts(host, {"somedata": "foo"})
    assert hostvars[host.name]["somedata"] == "foo"

# Generated at 2022-06-23 15:05:38.045703
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory()
    inventory.add_host('foo')
    inventory.add_host('bar')

    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Check that __iter__() works as expected:
    # - HostVars is iterable and returns an iterator
    # - The iterator returns host names only once
    # - The iterator iterates over all hosts in the inventory
    # - The iterator stops if there's no host in the inventory

    assert iter(hostvars) is iter(hostvars)
    assert list(hostvars) == ['foo', 'bar']
    assert list(hostvars) == ['foo', 'bar']

# Generated at 2022-06-23 15:05:42.270392
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    assert(len(HostVars(inventory, None, None)) == 1)

# Generated at 2022-06-23 15:05:51.677263
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader

    v = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader, v, host_list=[])
    hv = HostVars(inventory, v, loader)

    assert len(hv) == 0
    # Add a host to inventory
    host = inventory.get_host("localhost")
    assert len(hv) == 1
    # Add a second host to inventory
    host2 = inventory.get_host("localhost2")
    assert len(hv) == 2
    # Remove the first host from inventory
    inventory.remove_host(host)
    assert len(hv) == 1
    # Remove the second host from

# Generated at 2022-06-23 15:06:02.806424
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # We cannot import variable_manager here because this test fails for
    # Python older than 2.7.11.
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import UnsafeProxy as CurriedHostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import dbm
    import os
    import pickle

    def reloaded_HostVars(original_HostVars, pickle_string):
        new_HostVars = pickle.loads(pickle_string)
        new_HostVars.__setstate__(original_HostVars.__getstate__())
        return new_HostVars


# Generated at 2022-06-23 15:06:13.716590
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars.manager import VariableManager

    inventory = ['localhost']

    host_vars = HostVars(inventory,
                         variable_manager=VariableManager(),
                         loader=None)
    host = host_vars._find_host('localhost')
    host_vars.set_host_variable(host, 'test1', 'test2')
    assert host.vars['test1'] == 'test2'

    host_vars.set_host_facts(host, {'test3': 'test4'})
    assert host.vars['test3'] == 'test4'

    # From ansible.vars.manager
    host_vars.set_nonpersistent_facts(host, {'test5': 'test6'})
    assert host.vars['test5'] == 'test6'

# Generated at 2022-06-23 15:06:17.995872
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    vars = {
        "foo": "bar",
        "baz": "quux"
    }
    host_vars_vars = HostVarsVars(vars, None)
    len(host_vars_vars) == 2

# Generated at 2022-06-23 15:06:21.243410
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    hostvars = HostVars({}, variable_manager=None, loader=None)
    hostvars.set_inventory({})
    print("Successfully set inventory")



# Generated at 2022-06-23 15:06:33.254145
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    # create VariableManager
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    # create PlayContext
    play_context = PlayContext()
    play_context._vars_plugins = []
    play_context.network_os = None
    # create InventoryManager
    inventory = InventoryManager(loader=loader, sources='localhost,')
    # create HostVars
    hostvars = HostVars(inventory, variable_manager, loader)
    # verify it works with original InventoryManager object
    assert hostvars._inventory == inventory

# Generated at 2022-06-23 15:06:39.533344
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader, variable_manager, host_list=[])

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_inventory(inventory)

    assert isinstance(hostvars._inventory, InventoryManager)


# Generated at 2022-06-23 15:06:45.643497
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = {'var1': '1', 'var2': '{{ var1 }}', 'var3': '{{ var2 }}'}
    loader = DictDataLoader({""})
    test_obj = HostVarsVars(variables, loader)
    assert test_obj['var1'] == '1'
    assert test_obj['var2'] == '1'
    assert test_obj['var3'] == '1'



# Generated at 2022-06-23 15:06:57.430496
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    inventory = InventoryManager(loader=loader,
                                 sources=['tests/inventory'])

    hostvars = HostVars(inventory, variable_manager, loader)

    host = 'test_inventory_hostname'

    hostvars.set_nonpersistent_facts(host, {'foo': 'bar'})
    hostvars.set_nonpersistent_facts(host, {'baz': 'qux'})

    assert 'baz' in hostvars.raw_get(host)
    assert 'foo' in hostvars.raw_get(host)

# Generated at 2022-06-23 15:07:09.367746
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    v = {'hostvars': {'host1': {'var1': 'value1'}}}
    v2 = {'hostvars': {'host1': {'var1': '{{ var2 }}'}, 'host2': {'var2': 'value2'}}}

    # prevent any dependencies on current dir or cwd
    import os
    import tempfile
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)
    filename = os.path.join(tempdir, 'hosts')


# Generated at 2022-06-23 15:07:13.773528
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    empty_dict = {}
    non_empty_dict = {'k1': 1, 'k2': 2}

    assert 0 == len(HostVarsVars(empty_dict, None))
    assert 2 == len(HostVarsVars(non_empty_dict, None))



# Generated at 2022-06-23 15:07:22.756310
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible import constants as C

    class CEVR(Mapping):
        def __init__(self, data):
            self._data = data
        def __getitem__(self, var):
            return self._data[var]
        def __contains__(self, var):
            return var in self._data
        def __iter__(self):
            return self._data.__iter__()
        def __len__(self):
            return len(self._data)


# Generated at 2022-06-23 15:07:33.950169
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # Create empty inventory
    inventory_objects = {}

    # Create empty variable manager
    variable_manager_objects = {}

    # Create empty loader
    loader_objects = {}

    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    loader_objects['loader'] = loader

    inventory = Inventory(loader=loader, variable_manager=variable_manager_objects['variables'])
    inventory_objects['inventory'] = inventory

    variables = VariableManager(loader=loader, host_vars=host_vars_objects['hostvars'])
    variable_manager_objects['variables'] = variables


# Generated at 2022-06-23 15:07:42.506639
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Ideally, this unit test should mock all of the unittest's dependencies.
    #
    # However, the scope of the method __iter__ of class HostVars is narrow
    # enough to ensure that the unit test will actually test the method.
    inventory = MockInventory()
    variable_manager = MockVariableManager()
    hostvars = HostVars(inventory, variable_manager, self)

    inventory.set_hosts(['host1', 'host2'])

    assert set(hostvars) == set(['host1', 'host2'])


# Generated at 2022-06-23 15:07:51.461776
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os
    import yaml
    from collections import namedtuple
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable

    def TestCase(name, vars, expected_vars):
        return namedtuple('TestCase', ['name', 'vars', 'expected_vars']) \
            (name, vars, expected_vars)


# Generated at 2022-06-23 15:08:02.836644
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager

    class FakeVariableManager(object):

        def get_vars(self, *args, **kwargs):
            return {}

        def get_host_variables(self, *args, **kwargs):
            return {}

        def set_host_variable(self, *args, **kwargs):
            return True

        def set_nonpersistent_facts(self, *args, **kwargs):
            return True

        def set_host_facts(self, *args, **kwargs):
            return True

    class FakeInventory(InventoryManager):
        def __init__(self):
            super(FakeInventory, self).__init__(loader=None, sources=None)
            self.hosts = {}

# Generated at 2022-06-23 15:08:07.686542
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():

    # Create instance of class HostVarsVars
    vars = {'foo': '{{ bar }}', 'bar': 'baz'}
    host_vars_vars = HostVarsVars(vars, None)
    assert(host_vars_vars['foo'] == 'baz')

# Generated at 2022-06-23 15:08:19.278876
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext(variable_manager=variable_manager)

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args=''))
             ]
        )

   

# Generated at 2022-06-23 15:08:23.600255
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = {'foo': 1, 'bar': 2}
    loader = None
    host_vars_vars = HostVarsVars(variables, loader)
    length = len(host_vars_vars)
    assert(length == 2)


# Generated at 2022-06-23 15:08:33.855282
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__))
    base_dir = os.path.dirname(test_dir)
    inventory_path = os.path.join(base_dir, 'test/units/inventory/test_inventory_variables_deepcopy')

    inventory = Inventory(loader=None, variable_manager=VariableManager(), host_list=inventory_path)
    inventory.parse_inventory(inventory_path)
    host_vars = HostVars(inventory=inventory, variable_manager=inventory.get_variable_manager(), loader=None)
    host_vars.__setstate__(host_vars.__getstate__())

# Generated at 2022-06-23 15:08:45.825631
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 15:08:56.501461
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import os

    source = '''
all:
  hosts:
    localhost:
    web1:
    web2:
    web3:
    web4:
    web5:
  children:
    webservers:
      hosts:
        web1:
        web2:
        web3:
        web4:
        web5:
'''

    loader = DataLoader()
    inv = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    fd, path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')