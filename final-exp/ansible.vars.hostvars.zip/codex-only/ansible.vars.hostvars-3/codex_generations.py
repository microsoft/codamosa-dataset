

# Generated at 2022-06-23 14:59:03.238419
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class Host(object):
        def __init__(self, name):
            self.name = name

    # Create inventory
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    # Add host to inventory
    inventory.add_host(Host('myhost'), 'mygroup')
    # Create variable_manager
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    # Create hostvars
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
    # Create empty variable tree

# Generated at 2022-06-23 14:59:12.475755
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    loader = DataLoader()

    def get_host(self, name):
        return 'fake_host'

    Inventory.get_host = get_host
    inventory = Inventory(loader=loader, variable_manager=None)
    variable_manager = FakeVariableManager()

    hostvars = HostVars(inventory, variable_manager, loader)

    # HostVars contains all hosts in the inventory
    assert len(list(iter(hostvars))) == len(inventory.hosts)



# Generated at 2022-06-23 14:59:21.745454
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = None # No value is used here
    variables = {'foo': 'bar', 'a': 'b', 'baz.ansible_variable': 'test_value'}
    hostvars_vars = HostVarsVars(variables, loader)
    assert hostvars_vars['foo'] == 'bar'
    assert hostvars_vars['a'] == 'b'
    assert hostvars_vars['baz.ansible_variable'] == 'test_value'
    # Keys in the dict are not changed by the constructor
    assert 'baz.ansible_variable' in variables
    assert 'baz.ansible_variable' not in hostvars_vars
    assert 'baz' in hostvars_vars
    assert 'baz' not in variables

# Generated at 2022-06-23 14:59:24.071966
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    v = HostVars({'foo':'bar', 'baz':'qux'})
    assert len(v) == 2


# Generated at 2022-06-23 14:59:30.281106
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    class MockVariables():
        def __init__(self, variables):
            self._variables = variables

        def __getitem__(self, var):
            return self._variables[var]

    class MockLoader():
        def __init__(self):
            pass

    test_variable_mapping = {'test_foo': 'bar'}
    test_instance = HostVarsVars(test_variable_mapping, MockLoader())

    assert 'test_foo' in test_instance

# Generated at 2022-06-23 14:59:37.408473
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    hostvars = HostVars(InventoryManager(loader=DataLoader(), sources=''), VariableManager(loader=DataLoader(), inventory=None), DataLoader())
    hostvars_vars = HostVarsVars(dict(a='b'), DataLoader())
    assert(hostvars_vars.__contains__('a'))


# Generated at 2022-06-23 14:59:44.195165
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    my_inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    my_inventory.hosts.add(u'localhost')
    my_inventory.hosts.add(u'otherhost')

    my_var_manager = VariableManager(loader=DataLoader(), inventory=my_inventory)

    # test key that does not exist
    assert 'foo' not in my_var_manager.get_vars(my_inventory.get_host(u'localhost'))

# Generated at 2022-06-23 14:59:51.683516
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    play_context = PlayContext()

    # create a mock host
    host = MockHost()
    inventory.add_host(host)

    # create hostvars
    hv = HostVars(inventory, VariableManager(loader=loader), loader)

    hostvarsvars = hv['test_host']


# Generated at 2022-06-23 15:00:01.220017
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources=["localhost"])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ hostvars }}'))),
        ]
    )

# Generated at 2022-06-23 15:00:11.763516
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(loader=DataLoader())
    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    assert hostvars._variable_manager._hostvars == hostvars
    assert hostvars._loader is variable_manager._loader

    # Bypass __setstate__ by assigning to _hostvars directly
    variable_manager._hostvars = None

    variable_manager_2 = VariableManager()
    hostvars.set_variable_manager(variable_manager_2)
    assert variable_manager_2._hostvars is hostvars
    assert variable_manager_2._loader is hostvars._loader

# Generated at 2022-06-23 15:00:16.722575
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    # Initialize variables for constructor of class HostVarsVars
    variables = {'hostvars':'hostvars'}
    loader = 'loader'
    # Construct object of class HostVarsVars
    hostvars_vars = HostVarsVars(variables, loader)

# Generated at 2022-06-23 15:00:27.934221
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import get_all_plugin_loaders

    # Create Ansible variables.
    # These variables are used in unit test only.
    # All variables need to be replaced with more real variables.
    variable_manager = VariableManager()

# Generated at 2022-06-23 15:00:38.320834
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Host, Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars import AnsibleVars

    my_vars = AnsibleVars()
    loader = None
    inventory = Inventory(host_list=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info=my_vars)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    inventory.hosts.append(Host(name='host1', variables={'foo': 'bar'}))
    inventory.hosts.append(Host(name='host2', variables={'baz': 'qux'}))


# Generated at 2022-06-23 15:00:48.212282
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars # import here to avoid circular import

    host = '127.0.0.1'
    fact = 'test_HostVars_set_nonpersistent_facts'

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    hostobj = inventory.add_host(host)

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars.set_nonpersistent_facts(hostobj, { fact: 'success' })
   

# Generated at 2022-06-23 15:00:48.653511
# Unit test for constructor of class HostVars
def test_HostVars():
    pass

# Generated at 2022-06-23 15:00:56.384896
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    roles = [Role('test_role_name', None, None, None, loader=loader)]
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory, playcontext=PlayContext())
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test argument loader
    assert hostvars._loader == loader

    # Test argument variable_manager
    assert hostvars._variable_manager == variable_manager

    # Test argument inventory

# Generated at 2022-06-23 15:01:01.166904
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    # Class HostVarsVars is a proxy to a dict, therefore __len__
    # should return the length of that dict
    assert len(HostVarsVars({1: 1, 2: 2, 3: 3}, None)) == 3
    assert len(HostVarsVars({}, None)) == 0
    assert len(HostVarsVars({1: 1}, None)) == 1

# Generated at 2022-06-23 15:01:04.158889
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {
        'foo': 'bar',
        'baz': '{{ foo }}'
    }
    loader = 'loader'
    ans = HostVarsVars(variables, loader)
    assert ans['baz'] == 'bar'

# Generated at 2022-06-23 15:01:09.027115
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory import Host

    hostvars = HostVars({}, VariableManager())
    hostvars.set_host_variable(Host('host'), 'bar', 'bar')
    assert repr(hostvars) == "{'host': {'bar': 'bar'}}"

# Generated at 2022-06-23 15:01:19.512386
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.vars.hostvars
    import ansible.playbook.play
    import ansible.playbook.task

    # Initialize a fake inventory
    inventory = Inventory(host_list=[])
    inventory.add_host(ansible.inventory.host.Host('localhost'))
    inventory.add_host(ansible.inventory.host.Host('otherhost'))

    # Initialize a fake vars manager
    vars_manager = ansible.vars.manager.VariableManager()
    vars_manager.set_inventory(inventory)

    # Initialize a fake HostVars
    hostvars = ansible.vars.hostvars.HostVars(inventory, vars_manager)

   

# Generated at 2022-06-23 15:01:29.938451
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    '''
    Unit test for method __contains__ of class HostVars
    '''
    # Tested code
    class Inventory(object):
        def __init__(self, host_list):
            self._hosts = host_list

        def get_host(self, host_name):
            return self._hosts.get(host_name, None)

        def __contains__(self, host_name):
            return host_name in self._hosts

        def __iter__(self):
            for host in self._hosts:
                yield host

        @property
        def hosts(self):
            return self._hosts

    # Initialization
    class VariableManager(object):
        def __init__(self):
            self._hostvars = None


# Generated at 2022-06-23 15:01:40.401612
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.loader import DataLoader

    inv_file = """
    localhost ansible_connection=local
    """
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=inv_file)
    var_mgr = VariableManager(loader=loader, inventory=inv)

    hostvars = HostVars(inventory=inv, variable_manager=var_mgr, loader=loader)
    assert var_mgr._hostvars is hostvars

    var_mgr_updated = VariableManager(loader=loader, inventory=inv)
    hostvars.set_variable_manager(var_mgr_updated)
    assert var_mgr_updated._hostvars is hostvars

# Generated at 2022-06-23 15:01:52.345084
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.executor import module_common
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    def fact(name, args=None):
        return ansible.module_utils.facts.FactModule(name, args)

    loader = DataLoader()
    variable_manager = VariableManager()
    host_vars = HostVars(None, variable_manager, loader)

    context = PlayContext()
    context._connection = 'local'
    context._shell = None
    context._python_interpreter = 'python'

    host = Host(name='localhost')
    host.vars = {'ansible_connection': 'local', 'ansible_python_interpreter': 'python'}
    host

# Generated at 2022-06-23 15:02:01.221122
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible import errors
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def get_host(host_name):
        return None

    def get_hosts(pattern):
        return []

    loader = DataLoader()

    inventory_manager = InventoryManager(loader=loader, sources='')
    inventory_manager.hosts = {'localhost': get_host, 'get_hosts': get_hosts}

    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)
    variable_manager._hostvars = None

    hostvars = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=loader)

    # Given a nonexistent host name, __getitem

# Generated at 2022-06-23 15:02:03.732728
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    var_dict = {'var1': 'foo'}
    hostvars = HostVarsVars(var_dict, loader=None)
    assert 'var1' in hostvars
    assert 'var2' not in hostvars
    assert 'undefined_var' not in hostvars

# Generated at 2022-06-23 15:02:08.421882
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.errors import AnsibleError
    from ansible.inventory.host import Host
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    inventory = type('Inventory', (), { 'hosts': [ Host(name='host1'), Host(name='host2') ] })()
    playbook = Playbook()
    playbook.set_inventory(inventory)
    play = Play().load({}, playbook=playbook, variable_manager=VariableManager(), loader=None)
    hostvars = HostVars(inventory, play.variable_manager, play._loader)
    iter_hostvars = iter(hostvars)

# Generated at 2022-06-23 15:02:17.374064
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.module_utils.common._collections_compat import MutableMapping

    class Inventory(MutableMapping):
        def __init__(self, data=None):
            self._data = data or {}
        def __getitem__(self, key):
            return self._data[key]
        def __setitem__(self, key, val):
            self._data[key] = val
        def __delitem__(self, key):
            del self._data[key]
        def __iter__(self):
            return iter(self._data)
        def __len__(self):
            return len(self._data)

    class VariableManager(object):
        def __init__(self):
            self._hostvars = None


# Generated at 2022-06-23 15:02:24.844568
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    def set_host_variable(*args, **kwargs):
        pass

    def set_nonpersistent_facts(*args, **kwargs):
        pass

    def set_host_facts(*args, **kwargs):
        pass

    loader = DataLoader()
    templar = Templar(loader=loader)
    inventory = Mock()
    inventory.get_host = lambda name: Host(name)
    variable_manager = Mock()
    variable_manager.get_vars = lambda h=None, i=True: {'foo': 'bar'}
    variable_manager.set_host_variable = set_host_variable
    variable_manager.set_nonpersistent_facts = set_nonpersistent_facts
   

# Generated at 2022-06-23 15:02:28.957938
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = None
    variables = {'foo': 'bar', 'baz': 2}
    hostvarsvars = HostVarsVars(variables, loader)
    assert set(hostvarsvars) == set(['foo', 'baz'])

# Generated at 2022-06-23 15:02:37.560408
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    import ansible.vars.hostvars as hostvars
    class Inventory(object):
        def __init__(self):
            self.hosts = ['host1']
        def get_host(self, name):
            if name in self.hosts:
                return True
            else:
                return False
    class Loader(object):
        pass
    class VariableManager(object):
        def get_vars(self, host=None, include_hostvars=True):
            return {'var1': 'val1'}

    inventory = Inventory()
    loader = Loader()
    variable_manager = VariableManager()


# Generated at 2022-06-23 15:02:48.298912
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    '''
    Ensure the HostVars are correctly updated by set_host_facts method
    '''
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    test_host = Host('test_host')
    host_vars = HostVars({}, [test_host], VariableManager())
    host_vars.set_host_facts(test_host, {'test_var': 'test_value'})
    assert host_vars.get(test_host)['test_var'] == 'test_value'
    assert host_vars.get(test_host)['ansible_facts']['test_var'] == 'test_value'

# Generated at 2022-06-23 15:02:58.256782
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    my_host = set(['test_host'])
    invent = InventoryManager(loader=None, sources='')
    invent.add_group('test_group')
    invent.add_host(host='test_host', group='test_group')
    invent.reconcile_inventory()
    host_vars = HostVars(inventory=invent, variable_manager=VariableManager(), loader=None)
    host_vars.set_host_facts(host=invent.get_host('test_host'), facts={'test_fact': 'test'})
    assert host_vars.raw_get('test_host')['test_fact'] == 'test'

# Generated at 2022-06-23 15:03:07.984132
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    # Mocks
    class Inventory(object):
        def __init__(self):
            self.hosts = ['host1', 'host2']
    class VariableManager(object):
        def __init__(self):
            self._loader = 'loader1'
            self._hostvars = 'HostVars1'
    class Loader(object):
        pass
    loader1 = Loader()

    # Test
    hvars = HostVars(inventory=Inventory(),
                     variable_manager=VariableManager(),
                     loader=loader1)
    assert list(hvars) == ['host1', 'host2']

# Generated at 2022-06-23 15:03:09.906929
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    hvv = HostVarsVars({'foo': 'bar'}, None)
    assert 'foo' in hvv



# Generated at 2022-06-23 15:03:17.680298
# Unit test for constructor of class HostVars
def test_HostVars():
    import unittest2 as unittest

    class TestHostVars(unittest.TestCase):
        def setUp(self):
            class TestVariableManager(object):
                def __init__(self):
                    self._vars_cache = {'localhost': {'ansible_inventory_hostname': 'localhost'}}
                    self._hostvars = None

                def set_host_variable(self, host, varname, value):
                    pass

                def set_nonpersistent_facts(self, host, facts):
                    pass

                def set_host_facts(self, host, facts):
                    pass


# Generated at 2022-06-23 15:03:23.275285
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    '''
    Test method __contains__ of HostVarsVars.
    '''

    hvv = HostVarsVars({'a': 1, 'b': 2, 'c': 3}, None)

    assert 'a' in hvv
    assert 'b' in hvv
    assert 'c' in hvv

    assert 'd' not in hvv



# Generated at 2022-06-23 15:03:31.444337
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from io import BytesIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.plugins.loader import vars_loader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # setup
    fake_loader = vars_loader.VarsModule()
    variable_manager = VariableManager()
    variable_manager.set_loader(fake_loader)
    host = Host('testhost')
    host.vars['testvar'] = 'testvalue'
    group = Group('testgroup')
    group.add_host(host)

# Generated at 2022-06-23 15:03:40.036527
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())

    assert hostvars._loader == DataLoader()
    assert hostvars._inventory == inventory
    assert hostvars._variable_manager == variable_manager
    assert variable_manager._hostvars == hostvars



# Generated at 2022-06-23 15:03:45.415468
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    inventory_manager = InventoryManager(None, None)
    variable_manager = DummyClass()
    hostvars = HostVars(inventory_manager.inventory, variable_manager, None)
    assert hostvars.__repr__() == "{}"


# Generated at 2022-06-23 15:03:55.258929
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # setup some data
    data = dict(a=1, b=2, c=3)

    # make the object under test
    i = Inventory(loader=DataLoader())
    vm = VariableManager()
    vm.set_inventory(i)
    hv = HostVars(inventory=i, variable_manager=vm, loader=DataLoader())

    # add some vars
    hv._vars = data.copy()
    hv._vars.update(dict(dict(ansible_version='2.2.0.0')))

    # test when hostname is found
    assert hv['localhost'] == data

    # test when hostname is not found

# Generated at 2022-06-23 15:04:02.292996
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    # Create an empty inventory
    inventory = None


    # Create a VariableManager
    variable_manager = VariableManager()

    # Create a data loader
    loader = DataLoader()

    # Create HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create a host named "foo"
    hostvars.set_host_variable(Host("foo"), "a", "b")

    # Create repr()
    repr(hostvars)

# Generated at 2022-06-23 15:04:06.885026
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = None
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=['test'])
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars.set_host_variable(host=None, varname='test_varname', value='test_value')

    assert list(hostvars.raw_get('127.0.0.1')) == ['test_varname']
    assert list(HostVarsVars(hostvars.raw_get(None), loader=loader)) == ['test_varname']

# Generated at 2022-06-23 15:04:13.053915
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    # pylint: disable=unused-variable
    # pylint: disable=missing-docstring
    # pylint: disable=no-self-use
    # pylint: disable=too-few-public-methods
    # pylint: disable=too-many-instance-attributes

    v = HostVarsVars({'bar': 'baz'}, loader=None)
    assert 'bar' in v
    assert 'foo' not in v




# Generated at 2022-06-23 15:04:19.954108
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    class DummyLoader(object):
        pass

    variables = {
        'foo': 6,
        'bar': '{{ baz }}',
        'baz': 'baz_value',
        'qux': ['{{ mux }}', 1],
        'mux': 'mux_value',
    }
    loader = DummyLoader()
    hostvars_vars = HostVarsVars(variables, loader)
    assert len(hostvars_vars) == 5

# Generated at 2022-06-23 15:04:27.873432
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.dataloader import DataLoader

    hostvars = HostVars(inventory=None, variable_manager=None, loader=DataLoader())
    dict_var = dict(
        foo='bar',
        empty=None,
        val=False,
        num=42,
        list=[
            dict(
                nested=dict(
                    cherry='pie',
                ),
            ),
        ],
    )

    def expect_correct_string_repr(string):
        assert repr(hostvars) == ('{%r: <ansible.vars.hostvars.HostVarsVars object at '
                                  '0x%x>}' % (string, id(hostvars)))


# Generated at 2022-06-23 15:04:32.679957
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils import context_objects as co

    pb = Playbook.load('test/ansible/playbook/test_playbook_v2_variables.yml', variable_manager=VariableManager(), loader=DataLoader())

    i = pb.get_included_vars()
    h = HostVars(i, VariableManager(), DataLoader())

    len(h)
    len(h['localhost'])

# Generated at 2022-06-23 15:04:37.868460
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = None
    variable_manager = VariableManager()
    loader = DataLoader()
    hostvars = HostVars(inventory, variable_manager, loader)

    # check that hostvars.set_inventory does not fail
    hostvars.set_inventory(inventory)

# Generated at 2022-06-23 15:04:42.079958
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager

    v = VariableManager()
    h = HostVars(v)

    assert h._variable_manager is None

    h.set_variable_manager(v)
    assert h._variable_manager is v

    h.set_variable_manager(None)
    assert h._variable_manager is None



# Generated at 2022-06-23 15:04:54.007933
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    import configparser
    import os
    import unittest
    from ansible.module_utils.six.moves import StringIO

    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    TESTING = os.environ.get('TESTING') == 'True'

    def write_config_file(config_file, contents):
        old_umask = os.umask(0o077)
        with open(config_file, 'w+') as f:
            f.write(contents)
        os.umask(old_umask)


# Generated at 2022-06-23 15:04:56.961403
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():

    inventory = "test/inventory"
    variable_manager = "test/variable_manager"

    assert(variable_manager not in HostVarsVars(inventory, variable_manager))

# Generated at 2022-06-23 15:05:01.235607
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    inventory = Inventory(loader=None)
    variable_manager = VariableManager(loader=None)
    hostvars = HostVars(inventory, variable_manager, None)
    assert hostvars._inventory is inventory

    inventory2 = Inventory(loader=None)
    hostvars.set_inventory(inventory2)
    assert hostvars._inventory is inventory2

# Generated at 2022-06-23 15:05:05.016418
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert len(HostVarsVars(dict(a=1, b=2), None)) == 2
    assert len(HostVarsVars(dict(), None)) == 0



# Generated at 2022-06-23 15:05:08.192359
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources=["localhost"])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert "localhost" in hostvars

# Generated at 2022-06-23 15:05:14.255886
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy

    def check_deepcopy(a):
        # Check that the value returned by deepcopy is a new object that
        # contains the same keys and values as the original object 'a'.
        # We cannot use 'assert True == isinstance(b, type(a))', because
        # 'assert' expects a 'True' value and will raise an exception if
        # it is 'False', and running this function with Python 3 will
        # cause the test to fail because type(a) is 'HostVars' and type(b)
        # is 'HostVarsVars'.
        b = copy.deepcopy(a)
        for k in a.keys():
            assert a[k] == b[k]
        for k in b.keys():
            assert a[k] == b[k]
        assert a == b


# Generated at 2022-06-23 15:05:17.822446
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    vars = dict(a=1, b=2)
    vars_vars = HostVarsVars(vars, None)
    assert sorted(vars_vars) == ['a', 'b']


# Generated at 2022-06-23 15:05:22.817304
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    # Create instance of class HostVars
    inventory = Inventory(loader=None, variable_manager=VariableManager())
    hostvars = HostVars(inventory, variable_manager=VariableManager(), loader=None)

    # Deep-copy hostvars
    import copy
    copied_hostvars = copy.deepcopy(hostvars)
    assert copied_hostvars is not hostvars

# Generated at 2022-06-23 15:05:33.016818
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # HostVars should return the number of hosts in the inventory as length
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/inventory/unittests_hostvars/hostvars_inventory"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(hostvars) == 4, "HostVars.__len__() should return 4: number of hosts in the inventory"

# Generated at 2022-06-23 15:05:42.509520
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.playbook.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    inventory = Inventory("my_hosts")
    inventory.add_host(Host("example.com"))
    inventory.add_host(Host("example.net"))
    inventory.add_host(Host("example.org"))
    variable_manager = VariableManager(loader=DictDataLoader({}))
    hv = HostVars(inventory, variable_manager, loader=DictDataLoader({}))
    assert hv.__class__.__name__ == 'HostVars'


# Generated at 2022-06-23 15:05:47.333695
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class TestLoader:
        def __init__(self):
            self.template_cache = {}

    loader = TestLoader()
    variables = {
        'some variable': 'some value'
    }
    hostvarsvars = HostVarsVars(variables, loader=loader)
    repr(hostvarsvars)

# Generated at 2022-06-23 15:05:52.908771
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    # TODO: replace with mock
    import ansible.inventory.manager
    inv = ansible.inventory.manager.InventoryManager(host_list=[])
    inventory = inv.inventory
    vm = ansible.vars.manager.VariableManager(loader=None, inventory=inventory)
    hv = HostVars(inventory, vm, None)
    host = inventory.get_host('127.0.0.1')
    hv.set_host_variable(host, "foo", "bar")
    assert hv.get(host.name)["foo"] == "bar"

# Generated at 2022-06-23 15:05:58.965764
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager._vars_cache = {} # Override default empty dict
    variable_manager._vars_cache["localhost"] = {
        "foo": "bar",
        "baz": "qux"
    }

    hostvars = HostVars(None, variable_manager)
    assert len(hostvars) == 1



# Generated at 2022-06-23 15:06:02.217013
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    class Loader:
        pass
    loader = Loader()
    variables = {'var1': 'test', 'var2': 123}
    HostVarsVars(variables, loader)


# Generated at 2022-06-23 15:06:13.504018
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # Mock inventory
    class Inventory(object):
        def get_host(self, name):
            return None

        @property
        def hosts(self):
            return []

    # Mock variable manager
    class VariableManager(object):
        def get_host_variables(self, _host):
            return dict()

        def get_vars(self, _host, _include_hostvars):
            return dict()

        def set_host_variable(self, _host, _varname, _value):
            pass

        def set_nonpersistent_facts(self, _host, _facts):
            pass

        def set_host_facts(self, _host, _facts):
            pass

    # mock AnsibleModule
    class AnsibleModule():
        def fail_json(self, **kwargs):
            pass

   

# Generated at 2022-06-23 15:06:20.545221
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy

    # Create hostvars
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager._options_vars = {'foo': 'baz'}
    variable_manager._hostvars = HostVars(None, variable_manager, None)
    hostvars = HostVars(None, variable_manager, None)

    # Create variables to copy
    variables = {'foo': 'foo', 'bar': {'baz': 'baz', 'hostvars': hostvars}}

# Generated at 2022-06-23 15:06:32.407090
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    import copy
    import json

    import pytest

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    foo = "bar"
    variables = {"foo": foo}
    groups = []

    variable_manager = VariableManager()
    variable_manager.set_host_variable("host", variables)
    variable_manager.set_host_variable("host", "inventory_dir", "foo")

    inventory = Inventory(variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, variable_manager._loader)
    hostvars.set_variable_manager(variable_manager)
    hostvars.set_inventory(inventory)
    hostvars.set

# Generated at 2022-06-23 15:06:44.163392
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Inventory

    inventory = Inventory(loader=None, variable_manager=None)
    variable_manager = None
    loader = None

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_variable_manager(variable_manager)
    assert hostvars['not-existent-host'] == AnsibleUndefined(name="hostvars['not-existent-host']")

    inventory.hosts = [
        'localhost',
        'fake1.com',
        'fake2.com',
    ]
    variable_manager = None
    loader = None

    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars['localhost'] == {}
    assert hostvars['fake1.com'] == {}

# Generated at 2022-06-23 15:06:56.036636
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    hv = HostVarsVars({'a': '{{b}}', 'b': '2'}, loader)
    assert hv['a'] == '2'

    hv = HostVarsVars({'a': '{{b}}', 'b': '{{c}}', 'c': '3'}, loader)
    assert hv['a'] == '3'

    hv = HostVarsVars({'a': '{{b}}', 'b': '{{c}}', 'c': '{{d}}', 'd': '4'}, loader)
    assert hv['a'] == '4'


# Generated at 2022-06-23 15:07:09.035943
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class FakeInventory(object):
        def __init__(self, hosts):
            self.hosts = hosts
        def get_host(self, host):
            if host in self.hosts:
                return host
    class FakeVariableManager(object):
        def __init__(self, variables):
            self.variables = variables
            self._loader = None
            self._hostvars = None
    class FakeLoader(object):
        pass
    hostvars = HostVars(
        inventory=FakeInventory(['localhost', 'test_host']),
        variable_manager=FakeVariableManager({'test_host': {'test_var': 'test_value'}}),
        loader=FakeLoader(),
    )
    assert list(hostvars) == ['localhost', 'test_host']


# Generated at 2022-06-23 15:07:18.684486
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    # pylint: disable=unused-import
    # pylint: disable=import-error
    # pylint: disable=unused-variable
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils import plugin_docs
    from ansible.utils.vars import combine_vars
    # pylint: enable=unused-import
    # pylint: enable=import-error
    # pylint: enable=unused-variable

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._loader = loader

   

# Generated at 2022-06-23 15:07:23.638599
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({'a': 'A', 'b': 'B'}, None)
    hvv_it = iter(hvv)
    assert hvv_it is not None
    assert sorted(list(hvv_it)) == ['a', 'b']


# Generated at 2022-06-23 15:07:34.710697
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    import tempfile
    import os
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    with open(temp_path, 'w') as f:
        f.write("""
            [testgroup]
            local_server1
            local_server2
            local_server3
        """)

    inventory = InventoryManager(loader=None, sources=temp_path)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = None
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create iterator
    it = iter(hostvars)

    # Check number of values in iterator
    assert len(list(it)) == 3

# Generated at 2022-06-23 15:07:45.801106
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    import copy
    import json

    from ansible.vars.unsafe_proxy import wrap_var

    variables = {
        'foo': 1,
        'bar': wrap_var(2),
        'baz': wrap_var(3),
        'qux': {
            'quux': wrap_var(4),
            'corge': 5,
        },
    }

    loader = DictDataLoader({})
    hostvars = HostVarsVars(variables, loader)

    assert 'foo' in hostvars
    assert 'bar' in hostvars
    assert 'baz' in hostvars
    assert 'qux' in hostvars
    assert 'quux' not in hostvars
    assert 'corge' not in hostvars

    hostvars = copy.copy(hostvars)

# Generated at 2022-06-23 15:07:53.026073
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=inventory_loader(), sources=['tests/inventory/dynamic_inventory.py'])
    inventory._is_dynamic = True

    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test that the iterator gives back all hosts
    all_hosts = [host.get_name() for host in inventory.get_hosts()]
    assert set(all_hosts) == set(hostvars)

# Generated at 2022-06-23 15:08:04.005944
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    # Test case: verify that HostVarsVars.__iter__ works correctly on a dictionary
    obj = {'a': 0, 'b': 1}
    hvv = HostVarsVars(obj, None)
    result = []
    for key in hvv:
        result.append(key)
    expected = ['a', 'b']
    assert result == expected, \
        "HostVarsVars.__iter__ does not work correctly on a dictionary"

    # Test case: verify that HostVarsVars.__iter__ works correctly on an object
    class Obj:
        def __init__(self):
            self._variables = {'a': 0, 'b': 1}
        def __contains__(self, var):
            return (var in self._variables)
        def __len__(self):
            return

# Generated at 2022-06-23 15:08:11.484288
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    class my_inventory():
        def __init__(self):
            self.hosts = ['7a']
    class my_variable_manager():
        def __init__(self):
            self._hostvars = None
    class my_loader():
        pass

    inventory = my_inventory()
    variable_manager = my_variable_manager()
    loader = my_loader()
    host_vars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Set inventory and check that _hostvars of variable_manager is set properly
    host_vars.set_inventory(inventory)
    assert variable_manager._hostvars == host_vars

# Generated at 2022-06-23 15:08:23.056053
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    v_names = ['a', 'b', 'c']
    m_args = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
    }

    module = AnsibleModule(
        argument_spec=dict((name, dict(required=False, default=None, type='str')) for name in v_names),
        supports_check_mode=True,
    )

    loader = DataLoader()
    play_context = PlayContext()

    hvv = HostVarsVars(m_args, loader)
    assert len(hvv) == 3

# Unit

# Generated at 2022-06-23 15:08:27.303467
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert len(HostVarsVars({}, None)) == 0
    assert len(HostVarsVars({'foo': 'bar'}, None)) == 1
    assert len(HostVarsVars({'foo': 'bar', 'bar': 'baz'}, None)) == 2

# Generated at 2022-06-23 15:08:36.711062
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible.utils
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible import errors
    import tempfile

    loader = DataLoader()
    inventory = ansible.inventory.Inventory(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create temporary host file
    fd, test_file = tempfile.mkstemp()
    inventory.add_host(Host('localhost', groups=['local_group'], vars={'var1': 'value1', 'var2': 'value2'}))
    inventory.add_host

# Generated at 2022-06-23 15:08:47.945388
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_string = 'localhost ansible_connection=local,' + \
                 'test_inv_hostvar1=inv_hostvar,test_inv_groupvar1=inv_groupvar,test_inv_hostvar2=inv_hostvar2'
    inventory = InventoryManager(loader=loader, sources=inv_string)

    variables = VariableManager()

    # test: check that inventory attributes are assigned to an object
    hostvars = HostVars(inventory, variables, loader)
    assert type(hostvars) == HostVars
    assert hasattr(hostvars, '_inventory')

# Generated at 2022-06-23 15:08:59.366163
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import copy

    from ansible.vars import VariableManager
    from ansible.utils.display import Display

    display = Display()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=None)

    hostvars._vars = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
    }

    # Run __repr__
    result = repr(hostvars)

    # Check result
    expected = repr({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    if result != expected:
        display.error("repr(hostvars) returned %s instead of %s" % (result, expected))
       