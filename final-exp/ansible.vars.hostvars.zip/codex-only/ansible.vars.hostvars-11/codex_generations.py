

# Generated at 2022-06-23 14:59:03.491953
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    class MockInventory:

        def __init__(self):
            self.hosts = {}

        def add_host(self, host):
            self.hosts[host.name] = host

        def get_host(self, host_name):
            if host_name in self.hosts:
                return self.hosts[host_name]
            if host_name == 'localhost':
                from ansible.inventory.host import Host
                self.add_host(Host(name=host_name))
                return self.hosts[host_name]
            return None

        def get_hosts(self, pattern=None, ignore_limits=False, groups=None, inspecific_groups=False):
            for host in self.hosts.values():
                yield host


# Generated at 2022-06-23 14:59:14.804841
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    # Creating an inventory
    inventory = InventoryManager(loader=None, sources='')
    host1 = Host('localhost')
    host2 = Host('localhost')

    inventory.add_host(host1)
    inventory.add_host(host2)

    # Creating a variable manager
    variable_manager = DictData()
    variable_manager.set_inventory(inventory)

    # Creating a loader
    loader = DictData()

    # Creating a hostvars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Testing len
    assert len(hostvars) == 2

# Unit tests for method

# Generated at 2022-06-23 14:59:23.372034
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,test_HostVars.test_HostVars_set_nonpersistent_facts'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    host = inventory.get_host('localhost,test_HostVars.test_HostVars_set_nonpersistent_facts')

    facts = {"foo": "bar"}
    hostvars.set_nonpersistent_facts(host, facts)

    assert host.get_vars() == facts
    assert host.get_vars().get("foo") == "bar"

    hostvars

# Generated at 2022-06-23 14:59:28.057896
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    assert repr(HostVars(None, None, None)) == {}

    variables = {
        'item1':'{{ item1 }}',
        'item2':'{{ item2 }}',
        'item3':'{{ item3 }}',
    }

    assert repr(HostVarsVars(variables, None)) == variables.copy()

# Generated at 2022-06-23 14:59:30.801374
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():

    from ansible.inventory import Inventory, Host
    from ansible.vars import VariableManager

    inventory = Inventory()
    inventory.hosts = [Host('fake_host'), Host('fake_host_2')]

    variable_manager = VariableManager()

    host_vars = HostVars(inventory, variable_manager, None)

    assert len(host_vars) == 2

# Generated at 2022-06-23 14:59:37.749910
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test data
    test_data = ('one', 'two', 'three')

    # Expected results
    exp_results = ('one', 'two', 'three')

    # Test object
    host_vars = HostVars('test_inventory', 'test_variable_manager', 'test_loader')

    # Test results
    results = list()
    for result in host_vars:
        results.append(result)

    # Compare test results to expected results
    if results != exp_results:
        raise AssertionError



# Generated at 2022-06-23 14:59:47.977727
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    '''
    Make sure that HostVars doesn't rely on self._inventory attribute.
    This attribute is changed when performing the playbook import strategy.
    See test playbook import strategy.
    '''

    class Inventory(object):
        hosts = [u'localhost']
        vars = {}

        def __init__(self):
            self.hosts_cache = {
                u'localhost': u'localhost',
            }

        def get_host(self, host):
            return self.hosts_cache.get(host)

    class VariableManager():
        def __init__(self):
            self._vars_cache = {
                u'localhost': {u'foo': u'bar', },
            }


# Generated at 2022-06-23 14:59:58.538410
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import MutableMapping

    class Options():
        def __init__(self):
            self.inventory = None
            self.connection = 'local'
            self.module_path = []
            self.module_name = 'ping'
            self.forks = 10
            self.become = False
            self.become_method = None
            self.become_user = None
            self.check = False
            self.listhosts = None
            self.listtasks = None


# Generated at 2022-06-23 15:00:08.897612
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle

    class MockHostVars(HostVars):
        def __init__(self):
            self._loader = 'mock loader'
            self._variable_manager = 'mock variable manager'

    mock_hostvars = MockHostVars()
    hostvars_repr = repr(mock_hostvars)
    hostvars_repr_pickled = repr(pickle.loads(pickle.dumps(mock_hostvars)))

    assert hostvars_repr == hostvars_repr_pickled, ('Reprs of HostVars before '
                                                    'and after pickling shall be equal (but aren\'t)')

test_HostVars___setstate__()

# Generated at 2022-06-23 15:00:14.848644
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    loader = DictDataLoader({'host_vars/host1.yml': ''})
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    variable_manager = inventory._variable_manager
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{}"

    inventory.add_host(Host('host1'))

    assert repr(hostvars) == "{'host1': {}}"

    variable_manager.set_nonpersistent_facts(inventory.get_host('host1'), dict(foo='bar'))

    assert repr(hostvars) == "{'host1': {'foo': 'bar'}}"


# Generated at 2022-06-23 15:00:26.580686
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    i = InventoryManager(loader=None, sources=["inventory"])
    i.add_host(host='foo', port=2222)

    v = VariableManager()
    v.extra_vars = dict(key='value')
    v.options_vars = dict(key='ovar')

    h = HostVars(i, v, loader=None)

    result = h.raw_get('foo')
    assert list(result) == ['ansible_port', 'key', 'ansible_host']
    assert result.get('ansible_host') == 'foo'
    assert result.get('key') == 'ovar'
    assert result.get('ansible_port') == 2222



# Generated at 2022-06-23 15:00:31.593960
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars['localhost']['a'] = 'b'
    assert hostvars['localhost']['a'] == 'b'

    hostvars['localhost']['b'] = '{{a}}'
    assert hostvars['localhost']['b'] == 'b'

    hostvars['localhost']['c'] = '{{b}}'

# Generated at 2022-06-23 15:00:42.045235
# Unit test for constructor of class HostVars
def test_HostVars():

    def test_get_host(self, host_name):
        if host_name == 'fooname':
            return True
        return False

    class FakeLoader:
        pass

    class FakeVariableManager:
        def get_vars(self, host, include_hostvars):
            if include_hostvars:
                return {'fooname': 'barvalue'}
            return {}

        def set_host_variable(self, host, varname, value):
            pass

        def set_nonpersistent_facts(self, host, facts):
            pass

        def set_host_facts(self, host, facts):
            pass

        def __setstate__(self, state):
            self.__dict__.update(state)


# Generated at 2022-06-23 15:00:47.772807
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='tests/test_hostvars.ini')
    hostvars = HostVars(inventory=inventory, variable_manager=None, loader=None)

    for host in hostvars:
        assert repr(hostvars[host]) == repr(hostvars.raw_get(host))

# Generated at 2022-06-23 15:00:55.491570
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # __iter__() uses values from inventory, so we use a mock inventory
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager

    inv_manager = InventoryManager(loader=None, sources=[])
    inv_manager.hosts = {"127.0.0.1": Host("127.0.0.1"), "127.0.0.2": Host("127.0.0.2"), "127.0.0.3": Host("127.0.0.3")}

    hv = HostVars(inv_manager, None, None)

    output = set()
    for host in hv:
        output.add(host)

    assert output == set(["127.0.0.1", "127.0.0.2", "127.0.0.3"])



# Generated at 2022-06-23 15:01:03.060932
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # simulate self._inventory.hosts as list of three hosts
    inventory = {'hosts': ['host_a', 'host_b', 'host_c']}
    # simulate self._variable_manager.get_vars(host, include_hostvars=False)
    # as dict with a key 'foo', when hostname is "host_c"
    variable_manager = {'get_vars': {'host_c': {'foo': 'bar'}}}
    hostvars = HostVars(inventory, variable_manager, None)
    assert len(hostvars) == 3


# Generated at 2022-06-23 15:01:08.731665
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    class InventoryDict(object):
        def __init__(self, dict):
            self.dict = dict

        def get_host(self, hostname):
            if hostname not in self.dict:
                return None
            return self.dict[hostname]

    class Host(object):
        def __init__(self, name):
            self.name = name

    class PlayContextStub(PlayContext):
        def __init__(self, dict):
            self._dict = dict

        def __getattr__(self, attr):
            return self._

# Generated at 2022-06-23 15:01:11.569815
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    result = eval(HostVarsVars({"a": "b", "c": "d"}, None).__repr__())
    assert result == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-23 15:01:15.670106
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Setup
    foo = {}
    foo['bar'] = 'foo'
    loader = _make_dummy_loader()

    # Exercise
    obj = HostVarsVars(foo, loader)
    ret = obj['bar']

    # Verify
    assert ret == 'foo'


# Generated at 2022-06-23 15:01:23.579176
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    class FakeInventory:
        hosts = []
        host_patterns = {}

        def __init__(self):
            self.hosts = []
            self.host_patterns = {}

        def get_host(self, host_name):
            for host_object in self.hosts:
                if host_object.name == host_name:
                    return host_object

        def add_host(self, host_name):
            new_host = FakeHost(host_name)
            self.hosts.append(new_host)
            return new_host

    class FakeVariableManager:
        _vars = {}

        def __init__(self):
            self._vars = {}


# Generated at 2022-06-23 15:01:28.080027
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import ansible.template
    variables = {'foo': 'bar', 'stuff': ['a', 'b', 'c'], 'meh': '{{ foo }}'}
    loader = ansible.template.AnsibleTemplar(loader=ansible.parsing.dataloader.DataLoader())
    hostvars_vars = HostVarsVars(variables, loader=loader)
    assert hostvars_vars['foo'] == 'bar'
    assert hostvars_vars['stuff'] == ['a', 'b', 'c']
    assert hostvars_vars['meh'] == 'bar'

# Generated at 2022-06-23 15:01:38.915393
# Unit test for constructor of class HostVars
def test_HostVars():
    class Inventory(object):
        def __init__(self):
            self.hosts = ['foo', 'bar']
        def get_host(self, host_name):
            if host_name in self.hosts:
                return object()

    class VariableManager(object):
        def __init__(self):
            self._hostvars = None
        def set_host_variable(self, host, varname, value):
            pass
        def set_nonpersistent_facts(self, host, facts):
            pass
        def set_host_facts(self, host, facts):
            pass
        def get_vars(self, host=None, include_hostvars=True):
            if host is None:
                return dict()
            else:
                return {host: {host: 'hostxx'}}


# Generated at 2022-06-23 15:01:44.218981
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # Test with inventory equal to None
    (inventory, variable_manager) = setup()
    hostvars = HostVars(inventory, variable_manager, None)
    hostvars.set_inventory(None)
    assert hostvars._inventory == None

    # Test with inventory not equal to None
    (inventory, variable_manager) = setup()
    hostvars = HostVars(inventory, variable_manager, None)
    hostvars.set_inventory(inventory)
    assert hostvars._inventory != None



# Generated at 2022-06-23 15:01:55.695326
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVars
    from ansible.inventory.manager import InventoryManager

    loader = DummyLoader()
    variable_manager = VariableManager()
    variable_manager._loader = loader
    inventory_manager = InventoryManager(loader, variable_manager, host_list=['localhost'])
    inventory = inventory_manager.get_inventory_obj()

    # Before set_variable_manager, hostvars do not have attribute
    # _variable_manager
    hostvars = HostVars(inventory, variable_manager, loader)
    assert not hasattr(hostvars, '_variable_manager')

    # After set_variable_manager, hostvars have attribute
    # _variable_manager
    hostvars.set_variable_manager(variable_manager)

# Generated at 2022-06-23 15:02:05.485731
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    # Check if __setstate__ is properly assigning _loader and _hostvars
    # even if _loader is None and _hostvars is None in instance of
    # VariableManager passed as a state

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory_manager = InventoryManager(loader=None, sources=["localhost"])

    hostvars = HostVars(inventory_manager, VariableManager(loader=None, inventory=inventory_manager), loader=None)
    hostvars._variable_manager.unset_hostvars()

    assert hostvars._variable_manager._loader is None
    assert hostvars._variable_manager._hostvars is None

    # After __setstate__ assigning _loader and _hostvars should be
    # equal to the respective values in HostVars


# Generated at 2022-06-23 15:02:14.389689
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    h = Host(name='test_hostvars_set_nonpersistent_facts')
    hv = HostVars(variable_manager=variable_manager, loader=loader)
    hv.set_nonpersistent_facts(h, {'test_fact': 'test_fact'})
    assert hv[h] == {'test_fact': 'test_fact'}



# Generated at 2022-06-23 15:02:18.932678
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert len(HostVarsVars({'a': 1})) == 1, "__len__ method did not return the number of variables"
    assert len(HostVarsVars({})) == 0, "__len__ method did not return zero when passed empty dict"


# Generated at 2022-06-23 15:02:26.520035
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import copy
    import os
    import sys

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager

    # Create a test structure with a file named "inventory"
    # and some files and directories inside that.
    test_inventory = '''
localhost ansible_connection=local
'''
    os.mkdir('hostvars_set_variable_manager')
    os.chdir('hostvars_set_variable_manager')
    open('inventory', 'w').write(test_inventory)
    open('group_vars/all', 'w')
    open('group_vars/foo', 'w')
    os.mkdir('host_vars')
    os.chdir('host_vars')


# Generated at 2022-06-23 15:02:32.213827
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # Initialize a variable manager
    variable_manager = VariableManager()
    variable_manager._vars = {}
    variable_manager._vars['some_var'] = 'some_value'
    variable_manager._inventory = None

    # Create a HostVars object and set the variable manager for it
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=None)

    # Create a group and add it to the variable manager
    group = Group('group_name')
    variable_manager.add_group(group)

    # Add a host to the group
    host = Host('host_name')
    group.add_host(host)

    # Set

# Generated at 2022-06-23 15:02:43.645833
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    hosts = ['foo', 'bar']
    variables = {
        'foo': {'var': 'val'},
        'bar': {'var': 'val'},
        'baz': {'var': 'val'},
    }
    inventory = Inventory(host_list=hosts)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    for host in hosts:
        variable_manager.set_host_variable(host, "var", "val")

    # verifying __contains__ return True for all hosts defined in variable_manager
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)
    for host in hosts:
        assert host in hostvars
    # verifying __cont

# Generated at 2022-06-23 15:02:53.047624
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.module_utils.common._collections_compat import Mapping
    import os
    import tempfile
    import pytest
    from ansible.inventory.host import Host

    temppath = tempfile.mkdtemp(prefix='ansible_test_hostvars_temp')
    test_host = Host(name='test_host')

    # Create variables to set nonpersistent facts
    nonpersistent_facts = dict()

# Generated at 2022-06-23 15:03:01.586949
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader())

    hostvars = HostVars(inventory, variable_manager, DataLoader())
    hostvars['foo'] = dict(a=dict(b=dict(c='{{ d.e.f }}')))
    hostvars['bar'] = dict(d=dict(e=dict(f='bar')))

    assert repr(hostvars) == "{'foo': {'a': {'b': {'c': 'bar'}}}, 'bar': {'d': {'e': {'f': 'bar'}}}}"

# Generated at 2022-06-23 15:03:12.076710
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from collections import namedtuple

    fake_loader = namedtuple('fake_loader',
                             'get_basedir get_vars get_file_contents list_directory filter_loader')()

    fake_host = namedtuple('fake_host',
                           'name get_vars get_variable set_variable get_groups')(
                               'fake_host', {}, {}, {}, {})
    fake_group = namedtuple('fake_group',
                            'get_vars vars host_vars')({}, {}, {})
    fake_inventory = namedtuple('fake_inventory',
                                'get_group get_host host_vars_store all_group')(
                                    {}, {}, {}, {})


# Generated at 2022-06-23 15:03:21.813962
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    variable_manager = inventory.get_variable_manager()

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert(hostvars._inventory == inventory)
    assert(hostvars._loader == loader)
    assert(hostvars._variable_manager == variable_manager)

# Generated at 2022-06-23 15:03:23.364208
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    assert "__iter__" in dir(HostVars)



# Generated at 2022-06-23 15:03:31.496709
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Uncomment only if you need to debug the unit test
    #try:
    #    from ansible.playbook.play_context import PlayContext
    #    from ansible.plugins.loader import lookup_loader, filter_loader
    #    from ansible.template import Templar
    #    from ansible.vars.manager import VariableManager
    #except ImportError as e:
    #    print('\n- %s' % str(e))
    #    print('\n  Please install extra requirements using:')
    #    print('  $ pip install -r test-requirements.txt\n')
    #    raise

    # Import required modules
    from ansible.inventory import Inventory
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create the Ansible loader object
    loader = D

# Generated at 2022-06-23 15:03:35.677465
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    hostvars = HostVars(inventory, VariableManager(), loader)

    inventory.hosts.append("test_host")
    assert hostvars["test_host"] == {}

    inventory.hosts.append("other_test_host")
    assert hostvars["other_test_host"] == {}

# Generated at 2022-06-23 15:03:37.955571
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader = None
    variables = {'foo': 'hi<br>there'}
    d = HostVarsVars(variables, loader)
    assert str(d) == "{'foo': 'hi<br>there'}"

# Generated at 2022-06-23 15:03:43.833405
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # An empty dict
    empty_dict = {}
    empty_HostVarsVars = HostVarsVars(empty_dict, 'fake loader')
    assert [item for item in empty_HostVarsVars] == []

    # A non-empty dict
    not_empty_dict = {'a': 0, 'b': 1, 'c': 2}
    not_empty_HostVarsVars = HostVarsVars(not_empty_dict, 'fake loader')
    assert [item for item in not_empty_HostVarsVars] == not_empty_dict.keys()



# Generated at 2022-06-23 15:03:54.132476
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    host1 = Host('host1')
    host2 = Host('host2')
    hostvars = HostVars(inventory=None, variable_manager=VariableManager(), loader=None)

    hostvars.set_host_variable(host1, 'var', 'val')
    hostvars.set_host_variable(host2, 'var', 'val')

    # Deepcopy hostvars and change variables' values through the original
    # to ensure the new object is independent
    hostvars_copy = deepcopy(hostvars)
    hostvars.set_host_variable(host1, 'var', 'newval')
    host

# Generated at 2022-06-23 15:04:01.532453
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():

    class Inventory(object):

        def __getitem__(self, host_name):
            return host_name

    # test 1: set_inventory must set the value of self._inventory as its first argument
    inventory = Inventory()
    hostvars = HostVars(variable_manager=None, loader=None, inventory=inventory)
    hostvars.set_inventory('foo')
    assert hostvars._inventory == 'foo', 'set_inventory did not set the value'

    # test 2: set_inventory must return None
    assert hostvars.set_inventory('foo') is None, 'set_inventory did not return None'

# Generated at 2022-06-23 15:04:08.343254
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data = dict(foo=1, bar=2)
    hvv = HostVarsVars(data, loader=DataLoader())
    assert(len(hvv) == 2)
    assert(len(data.keys()) == 2)


# Generated at 2022-06-23 15:04:18.981730
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    # setup

    variable_manager = VariableManager()

    inventory = InventoryManager(loader=None, variable_manager=variable_manager, host_list='')
    variable_manager.set_inventory(inventory)

    inventory.hosts = [
        'host1',
        'host2',
        'host3',
        # 'nohost'
    ]

    hostvars = HostVars(inventory, variable_manager, loader=None)

    # testing updating variables for existing host

    hostvars.set_host_variable('host1', 'a', 'b')

    assert hostvars['host1']['a'] == 'b'

    # testing updating variables for non-existing host (should be created on demand)

    hostvars.set_host_variable('nohost', 'a', 'b')

    assert hostv

# Generated at 2022-06-23 15:04:24.516559
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {"key1": "value1"}
    variable_manager.options_vars = {"key2": "value2"}

    hostvars = HostVars(
        inventory=None,
        variable_manager=variable_manager,
        loader=None
    )

    assert(hostvars.raw_get("localhost") == {"key1": "value1", "key2": "value2"})

# Generated at 2022-06-23 15:04:36.094558
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')

    hostvars = HostVars(inventory, VariableManager(loader=DataLoader()), DataLoader())
    localhost = inventory.get_host('localhost')
    hostvars.set_nonpersistent_facts(localhost, {'foo': {'bar': 'baz'}})

    assert(hostvars.raw_get('localhost')['foo']['bar'] == 'baz')

    # make sure _load_vars doesn't overwrite the data
    hostvars.raw_get('localhost')

# Generated at 2022-06-23 15:04:39.207547
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    hostvars_vars = HostVarsVars({'bar': 'baz'}, None)
    assert 'bar' in hostvars_vars
    assert 'foo' not in hostvars_vars

# Generated at 2022-06-23 15:04:43.556856
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy

    h = HostVars(inventory=None, variable_manager=None, loader=None)
    # This creates a new object, not a reference
    h2 = copy.deepcopy(h)
    assert h is not h2
    # We need to implement the method so we can deepcopy
    # variables' dicts that contain HostVars.
    assert h is h2

# Generated at 2022-06-23 15:04:47.993426
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a=1)

    hostvars = HostVars()
    hostvars.set_variable_manager(variable_manager)
    assert 1 == hostvars['localhost']['a']

# Generated at 2022-06-23 15:04:54.527977
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    inventory = FakeInventory("hosts", ["host_a", "host_b"])
    hostvars = HostVars(inventory, FakeVariableManager(), FakeLoader())
    assert set(hostvars) == set(inventory.hosts)
    assert "host_a" in hostvars
    assert "host_b" in hostvars
    assert "nonexistent_host" not in hostvars


# Generated at 2022-06-23 15:05:00.590515
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(["localhost"])
    variable_manager = VariableManager(loader=None)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    variable_manager = VariableManager(loader=None)
    hostvars.set_variable_manager(variable_manager)
    assert variable_manager._hostvars is hostvars

# Generated at 2022-06-23 15:05:12.602212
# Unit test for constructor of class HostVars
def test_HostVars():
    class MyDict(dict):
        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
            super(MyDict, self).__init__(*args, **kwargs)

        def __getitem__(self, key):
            self._called_with = (key,)
            return super(MyDict, self).__getitem__(key)

    class Host:
        pass

    class VariableManager:
        def get_vars(self, host=None, include_hostvars=True):
            assert not include_hostvars
            assert isinstance(host, Host)
            return MyDict(self._host, self._hostvars)

    class Inventory:
        def __call__(self, *args, **kwargs):
            return self

# Generated at 2022-06-23 15:05:18.592184
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    loader = Mock()
    variables = {
        "foo": "bar",
        "baz": [
            "ban",
            "bat"
        ]
    }
    data = HostVarsVars(variables=variables, loader=loader)

    assert "bar" in data
    assert "foo" in data
    assert "ban" not in data
    assert "bat" not in data
    assert "baz" in data


# Generated at 2022-06-23 15:05:26.384990
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    import ansible.vars.manager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    variable_manager.set_inventory(inventory)
    inventory.clear_pattern_cache()

    host = inventory.get_host('localhost')
    variable_manager.set_host_variable(host=host, varname="ansible_connection", value="local")

    raw_local = hostvars.raw_get('localhost')
    assert isinstance(raw_local, Mapping)

# Generated at 2022-06-23 15:05:37.996959
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={
        'test_hostvar_var': 'test_hostvar_value',
        'test_redefined_var': 'test_redefined_value1',
        'test_redefined_var': 'test_redefined_value2',
    })

    hostvars_vars = HostVarsVars(templar.template({
        'test_hostvar_var': '{{test_hostvar_var}}',
        'test_undefined_var': '{{test_undefined_var}}',
        'test_redefined_var': '{{test_redefined_var}}',
    }), loader)

    assert hostvars_vars['test_hostvar_var'] == 'test_hostvar_value'

# Generated at 2022-06-23 15:05:46.067401
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    """
    When a host is not present in the inventory, HostVars.__getitem__
    should return an AnsibleUndefined object. AnsibleUndefined.__bool__
    should return False.
    """
    import ansible.playbook.play_context
    host_name = 'not_a_host_name'
    inventory = ansible.playbook.play_context.PlayContext(play=None).CLIARGS['inventory']
    if host_name not in inventory:
        assert not bool(HostVars(inventory, None)['not_a_host_name'])

# Generated at 2022-06-23 15:05:57.168749
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # We can not directly import here because of bootstrap issues
    # but we need the class to test against
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    # Add a test inventory
    inventory = InventoryManager(loader=loader, sources=['tests/lib/ansible/inventory/test_inventory/hosts'])

    # Add a test variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a test HostVars object

# Generated at 2022-06-23 15:06:06.141810
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():

    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = DummyVars()
    hostvars = HostVars(inventory, variable_manager, DataLoader())
    hostvars.set_inventory(None)
    assert(hostvars._inventory is None)

    new_inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    new_inventory._hosts['localhost'] = Host('localhost', new_inventory)
    hostvars.set_inventory(new_inventory)
    assert(hostvars._inventory is new_inventory)

# Generated at 2022-06-23 15:06:16.189091
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {
        'item1': {
            'foo': 'bar',
            'baz': ['quux', 'quuz', 'quuux'],
        },
        'item2': 'spam',
    }
    hostvars_vars = HostVarsVars(variables, loader=None)
    assert hostvars_vars['item1']['foo'] == 'bar'
    assert hostvars_vars['item2'] == 'spam'
    assert hostvars_vars['item1']['baz'] == ['quux', 'quuz', 'quuux']
    assert hostvars_vars['item1'] == {'foo': 'bar', 'baz': ['quux', 'quuz', 'quuux']}

# Generated at 2022-06-23 15:06:26.157978
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)

    vars_obj = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    vars_obj['localhost']['my_fact'] = 'my_value'

    host_vars_vars_obj = HostVarsVars(variables=vars_obj['localhost'], loader=loader)

    assert 'my_fact' in host_vars_vars_obj

    assert host_vars_vars

# Generated at 2022-06-23 15:06:36.159792
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager

    # Create test variables
    loader = None
    inventory = Group(name="all")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create object to test
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    host = Host(name="localhost", port=22)

    # Add variable to test
    variable_manager.set_nonpersistent_facts(host, dict(foo="bar"))

    # Test that variable foo was added by variable_manager
    assert hostvars.get(host) == dict(foo="bar")

    # Test that we override variable foo with variable_manager
    hostvars.set_host

# Generated at 2022-06-23 15:06:46.906938
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Setup
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.vars.manager
    import ansible.vars.hostvars
    import ansible.utils.unicode

    loader = ansible.parsing.dataloader.DataLoader()
    play = ansible.playbook.play.Play()
    play_context = ansible.playbook.play_context.PlayContext()
    ansible.vars.manager.VariableManager(loader, play, play_context)

    inventory = ansible.inventory.manager.InventoryManager(loader, play_context, host_list=['localhost'])

    # Test

# Generated at 2022-06-23 15:06:58.272378
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Test data (just simple dicts)
    inventory_data = {
        "_meta": {
            "hostvars": {
                "foo": {
                    "ansible_host": "127.0.0.1",
                    "ansible_port": 52318
                }
            }
        },
        "all": {
            "hosts": ["foo", "bar"],
            "vars": {
                "some_var": "value"
            }
        }
    }

    # Prepare inventory
    loader = FakeLoader()
    inventory = InventoryManager(loader=loader, sources=inventory_data)

    # Prepare variable_manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    #

# Generated at 2022-06-23 15:07:05.421645
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import copy

    fd = open("hostvarsvars.yaml", 'r')
    data = fd.read()
    fd.close()

    loader = DictDataLoader({})
    variables = AnsibleMapping.load(data, loader=loader)
    v = HostVarsVars(variables, loader=loader)
    # Test deepcopy
    v2 = copy.deepcopy(v)

    print(v)

# Generated at 2022-06-23 15:07:13.993590
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class MyLoader:
        pass

    class MyInventory(InventoryManager):
        pass

    loader = MyLoader()
    inventory = MyInventory()
    variable_manager = VariableManager()

    # variable_manager._loader and variable_manager._hostvars should be None
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Create HostVars
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._loader is loader
    assert hostvars._variable_manager is variable_manager
    assert hostvars._loader is variable_manager._loader
    assert hostvars._variable_manager._hostvars is hostvars

    # Change variable_

# Generated at 2022-06-23 15:07:22.949131
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=hosts)

    host_vars = HostVars(inventory=hosts, variable_manager=variable_manager, loader=loader)
    assert len(host_vars) == 0

    hosts.add_host(Host('example.org', variable_manager=variable_manager))
    hosts.add_host(Host('example.com', variable_manager=variable_manager))
    assert len(host_vars) == 2

    # Ensure we can count hosts with

# Generated at 2022-06-23 15:07:27.660253
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    class Host:
        name = 'localhost'

    class Inventory:
        def get_host(self, host_name):
            if host_name == Host.name:
                return Host

    def test_find_host(self, host_name):
        return self._inventory.get_host(host_name)

    inventory = Inventory()
    hv = HostVars(None, None, None)
    hv.set_inventory(inventory)
    assert hv._inventory is not None
    assert hv._inventory is inventory
    assert hv._find_host(host_name=Host.name) is Host

# Generated at 2022-06-23 15:07:33.601860
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    loader = DictDataLoader(dict())
    variables = dict()
    host_vars_vars = HostVarsVars(variables, loader)
    assert len(host_vars_vars) == 0
    variables = dict(foo=1)
    host_vars_vars = HostVarsVars(variables, loader)
    assert len(host_vars_vars) == 1

# Generated at 2022-06-23 15:07:44.688347
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    context = PlayContext()
    loader = DataLoader()
    templar = Templar(loader=loader)

    variables = {
        'hostvars': HostVars(None, None, loader),
        'foo': 'foo',
        'bar': 'bar'
    }

    raw_get_result = templar.template("{{ hostvars.localhost.foo }}", variables, convert_bare=True)
    assert raw_get_result == "foo"

    templar = Templar(loader=loader, variables=variables)
    hostvars_raw_get_result = templar.template("{{ hostvars.localhost.foo }}", variables, convert_bare=True)
    assert host

# Generated at 2022-06-23 15:07:53.069355
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    import copy
    import sys

    class VarManager:
        def __init__(self, hostvars):
            self.hostvars = hostvars
            self.extra_vars = dict()
            self.options = dict()

    loader = DataLoader()
    inventory = dict(
        hosts=dict(
            localhost=dict(ansible_connection='local')
        )
    )
    templar = Templar(loader=loader, variables=dict())
    variables = copy.deepcopy(inventory['hosts']['localhost'])
    variables.update(VarManager(HostVars(inventory, variables, loader)).extra_vars)
    print(variables)
    hostvarsvars = HostVarsVars(variables, loader)
   

# Generated at 2022-06-23 15:08:04.006077
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    loader = object()
    variables = object()
    templar = object()
    foo = object()

    hvv = HostVarsVars(variables, loader)

    # Test the function with a single var.
    hvv_getitem = hvv.__getitem__

    def Templar_init(self, variables=dict(), loader=None):
        assert self is templar
        assert variables is variables
        assert loader is loader

    def Templar_template(self, data, fail_on_undefined=False, static_vars=None):
        assert self is templar
        assert data is variables[var]
        assert fail_on_undefined is False
        assert static_vars is STATIC_VARS
        return foo


# Generated at 2022-06-23 15:08:07.645370
# Unit test for constructor of class HostVars
def test_HostVars():
    v = HostVarsVars({ "var1": "foo", "var2": "bar" }, None)
    assert v["var1"] == "foo"
    assert v["var2"] == "bar"
    assert len(v) == 2

# Generated at 2022-06-23 15:08:19.278653
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    '''Unit test for method __setstate__ of class HostVars

    Tested scenario:
        1. Create an instance of HostVars
        2. Set state of VariableManager to None
        3. Call __setstate__() method of HostVars
        4. Assert state of VariableManager
    '''
    inventory = None
    loader = None
    variable_manager = None
    hostvars = HostVars(inventory, variable_manager, loader)

    class DummyVariableManager:
        def __init__(self):
            self._loader = None
            self._hostvars = None

        def __getstate__(self):
            return None

        def __setstate__(self, state):
            self._loader = None
            self._hostvars = None

    hostvars._variable_manager = DummyVariableManager()



# Generated at 2022-06-23 15:08:26.217490
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # create mock of class Inventory
    inventory = create_autospec(spec=Inventory)
    # create mock of class VariableManager
    variable_manager = create_autospec(spec=VariableManager)
    # create mock of class DataLoader
    loader = create_autospec(spec=DataLoader)

    hostname = 'testhost'

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.__contains__(hostname)
    inventory.get_host.assert_called_once_with(hostname)

# Generated at 2022-06-23 15:08:31.184167
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=["localhost"])
    hostvars = HostVars(inventory, VariableManager(loader=None, inventory=inventory), None)

    new_variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars.set_variable_manager(new_variable_manager)

    # Variable Manager must have the new value for _hostvars
    assert new_variable_manager._hostvars == hostvars

# Generated at 2022-06-23 15:08:41.932728
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    localhost = "localhost"
    fakehost = "fakehost"

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])

    hostvars = HostVars(inventory, None, loader)
    # add localhost to inventory
    hostvars.raw_get(localhost)

    assert localhost in hostvars

    # HostVars must iter over all hosts in inventory
    assert set(hostvars) == set(inventory.hosts)

    # HostVars must not iter over hosts that are not in inventory
    assert fakehost not in hostvars



# Generated at 2022-06-23 15:08:45.888908
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources="localhost,")
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    if hostvars.raw_get('localhost') != {}:
        # This test should not fail unless you changed the method raw_get
        raise Exception("method HostVars.raw_get did not return {}"
                        " as expected")

# Generated at 2022-06-23 15:08:48.257394
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader = DictDataLoader()
    variables = {'x': 2}
    vars = HostVarsVars(variables, loader=loader)
    assert vars.__repr__() == "{'x': 2}"


# Generated at 2022-06-23 15:08:58.458201
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources=["localhost,"])
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    # Call method set_inventory
    new_inventory = InventoryManager(loader=DataLoader(), sources=["example.com,"])
    hostvars.set_inventory(new_inventory)

    # Validate the value of attribute _inventory
    assert hostvars._inventory is new_inventory
