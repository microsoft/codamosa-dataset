

# Generated at 2022-06-23 14:59:01.145750
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.template import Templar
    # This is basically a copy of a test in test_template.py
    templar = Templar({'var1': 'stuff'}, None)
    assert 'var1' in templar.template({}, fail_on_undefined=False, static_vars=STATIC_VARS)
    assert 'var2' not in templar.template({}, fail_on_undefined=False, static_vars=STATIC_VARS)
    assert 'var3' not in templar.template({}, fail_on_undefined=False, static_vars=STATIC_VARS)

# Generated at 2022-06-23 14:59:07.701718
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hv = HostVars(inventory=inventory, variable_manager=variable_manager)

    host = Host(name="localhost")

    hv.set_host_facts(host=host, facts={"somefact": "somevalue"})

    assert "somefact" in variable_manager.get_facts(host=host)

# Generated at 2022-06-23 14:59:15.644960
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    # Inventory manager and variable manager are needed for __repr__
    inventory_manager = InventoryManager("")
    variable_manager = VariableManager(loader=None, inventory=inventory_manager)

    hostvars = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=None)
    # __repr__ can not be called without hosts on inventory
    hostvars._inventory.hosts = [ 'foo']
    print(hostvars.__repr__())
    assert(hostvars.__repr__() == "({'foo': {}})")


# Generated at 2022-06-23 14:59:21.346256
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    foo = hostvars.raw_get('localhost')
    assert foo['inventory_hostname'] == 'localhost'

# Generated at 2022-06-23 14:59:29.630987
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    assert len(hostvars) == 0

    inventory.add_host(host='host1')
    inventory.add_host(host='host2')
    assert len(hostvars) == 2

# Generated at 2022-06-23 14:59:39.471557
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert isinstance(hostvars, Mapping)
    assert isinstance(hostvars, HostVars)
    assert isinstance(hostvars['localhost'], HostVarsVars)
    assert isinstance(hostvars['localhost'], Mapping)
    assert hostvars['localhost'] == hostvars['localhost']
    import copy
    assert copy.deepcopy(hostvars['localhost']) == host

# Generated at 2022-06-23 14:59:42.702345
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    hostvars_vars = HostVarsVars(dict(a=1, b=2, c=3), None)
    assert len(hostvars_vars) == 3



# Generated at 2022-06-23 14:59:47.563465
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.manager import VariableManager

    inventory = make_inventory()
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    # Test __iter__
    assert sorted(list(iter(hostvars))) == sorted(list(inventory.hosts))


# Generated at 2022-06-23 14:59:58.499594
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    inventory = MockInventory()
    loader = MockLoader()
    variable_manager = VariableManager(loader=loader)
    hv = HostVars(inventory, variable_manager, loader)

    # __setstate__ is called on instance after pickling
    assert hv._inventory is inventory
    assert hv._variable_manager is variable_manager
    assert hv._variable_manager._loader is loader
    assert hv._variable_manager._hostvars is hv

    state = hv.__getstate__()
    hv.__setstate__(state)

    # __setstate__ preserved values of attributes _inventory,
    # _variable_manager and _loader
    assert hv._inventory is inventory
    assert hv._variable_manager is variable

# Generated at 2022-06-23 15:00:09.974881
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # Create a VariableManager and add a couple of variables
    var_manager = VariableManager()
    var_manager.set_nonpersistent_facts(None, {
        'a': 1,
        'b': 2,
        'c': 3,
    })

    # Create an HostVars and add a host to the inventory of VariableManager
    hostvars = HostVars(inventory=var_manager._inventory, variable_manager=var_manager, loader=None)
    host = Host(name='test_host')
    var_manager._inventory.add_host(host)

    # Check if set_nonpersistent_facts() clears non-persistent facts

# Generated at 2022-06-23 15:00:17.794045
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    inv_host = Host('foo')
    inv_host.vars["bar"] = "baz"
    inventory = InventoryManager(loader=None, sources=None)
    inventory.hosts = [inv_host]
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager)
    hostvars.set_inventory(inventory)
    assert hostvars["foo"]["bar"] == "baz"

# Generated at 2022-06-23 15:00:28.910242
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    loader = _MockLoader()
    templar = Templar(loader=loader)

    # tests of basic functionality
    variables = {'foo': 'bar'}
    host_vars = HostVarsVars(variables, loader)
    assert host_vars['foo'] == 'bar'

    # tests of templating
    variables = {'foo': '{{ bar }}'}
    host_vars = HostVarsVars(variables, loader)
    assert host_vars['foo'] == 'baz'

    # tests of recursive templating
    variables = {'foo': {'bar': '{{ baz }}'}}
    host_vars = HostVarsVars(variables, loader)
    assert host_vars['foo']['bar'] == 'quux'

    # tests of recursive templ

# Generated at 2022-06-23 15:00:33.803203
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    for py_version in [2, 3]:
        # assert imports
        if py_version == 2:
            from collections import MutableMapping
            from StringIO import StringIO
        else:
            from collections.abc import MutableMapping
            from io import StringIO

        # assert VariableManager and HostVars
        variable_manager = MockVariableManager({'foo': 'foo'})
        hostvars = HostVars({'foo': 'foo'}, variable_manager, None)
        # assert deepcopy
        deepcopy(hostvars)

        # assert VariableManager and HostVarsVars
        variable_manager = MockVariableManager({'foo': 'foo'})
        hostvars = HostVarsVars({'foo': 'foo'}, None)
        # assert deepcopy
        deepcopy(hostvars)


# Generated at 2022-06-23 15:00:43.500882
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import pickle
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, variable_manager=variable_manager, sources=None)
    playbook = Playbook.load(playbook_path='../test/playbook.yml', variable_manager=variable_manager, loader=None)
    hostvars = HostVars(inventory, variable_manager, loader=None)

# Generated at 2022-06-23 15:00:53.602249
# Unit test for method __iter__ of class HostVarsVars

# Generated at 2022-06-23 15:00:59.162992
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Test for method __getitem__ of class HostVars
    '''
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    hv = HostVars(inventory=InventoryManager(),
                  variable_manager=VariableManager(),
                  loader=DataLoader())
    hv.set_host_variable(host=None, varname='foo', value='bar')
    assert hv['localhost']['foo'] == 'bar'
    assert hv.raw_get('localhost')['foo'] == 'bar'

# Generated at 2022-06-23 15:01:07.131547
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    host = 'dummy_host'
    varname = 'my_var'
    value = 'my_val'

    # Create an empty inventory and a variable manager with empty vars_cache
    # to test the case when the vars_cache is empty.
    inv = MagicMock()
    var_mgr = MagicMock()
    var_mgr._vars_cache = {}
    HostVars(inv, var_mgr).set_host_variable(host, varname, value)
    inv.get_host.assert_called_with(host)
    assert var_mgr._vars_cache['dummy_host']['my_var'] == 'my_val'

    # Create a variable manager with a non-empty vars_cache and use it to test
    # the case when the vars_cache is not

# Generated at 2022-06-23 15:01:10.161999
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars.hostvars import HostVars
    from mock import Mock
    inventory = Mock()
    variable_manager = Mock()
    loader = Mock()
    HostVars(inventory, variable_manager, loader)



# Generated at 2022-06-23 15:01:14.650622
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host

    inventory = Inventory(host_list=[])
    hostvars = HostVars(inventory, None, None)

    assert len(hostvars) == 0, "Length should be equal to zero"

    inventory.add_host(Host('hostname'))
    assert len(hostvars) == 1, "Length should be equal to one"

    inventory.add_host(Host('hostname2'))
    assert len(hostvars) == 2, "Length should be equal to two"

# Generated at 2022-06-23 15:01:25.576996
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import copy
    import json
    import os
    import random
    import string
    import tempfile

    from ansible.module_utils.common._collections_compat import Mapping

    from six import string_types
    from six import iteritems

    from ansible.plugins.loader import become_loader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # We need to deepcopy values of some variables that are of type HostVars,
    # so we create a variable manager that does not raise an exception
    # on such values.
    class MyVariableManager(VariableManager):
        def __deepcopy__(self, memo):
            return self

    def _get_random_string():
        length = random.randint(2, 15)

# Generated at 2022-06-23 15:01:35.530781
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    hosts = [
        Host('host1'),
        Host('host2')
    ]
    groups = [
        Group('group_a', hosts=hosts)
    ]

    inventory = MagicMock()
    inventory.hosts = hosts
    inventory.groups = groups
    inventory.get_host.side_effect = hosts.__getitem__

    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)

    hosts_vars = HostVars(inventory, variable_manager, loader)


# Generated at 2022-06-23 15:01:41.238592
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager

    hostvars = {"a": 1, "b": 2, "c": 3}
    hvv = HostVarsVars(hostvars, None)
    assert set(hostvars) == set(hvv)

    vars_manager = VariableManager()
    vars_manager._vars_cache, vars_manager._hostvars_opts = {}, {"a": 1, "b": 2, "c": 3}
    hvv = HostVarsVars(vars_manager, None)
    assert set(hostvars) == set(hvv)

# Generated at 2022-06-23 15:01:51.222123
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    hosts = [InventoryHost('localhost')]
    inventory = Inventory(hosts=hosts)
    loader = DataLoader()
    variable_manager = VariableManager()

    host_vars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    host_vars.set_nonpersistent_facts(hosts[0], {'foo': 'bar'})
    assert hosts[0].get_vars()['foo'] == 'bar'


# Generated at 2022-06-23 15:01:57.438202
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    variables = dict(a_dict='{"a_key":"a_value"}',
                     a_list='[1, 2]')
    loader = 'dummy'

    hostvarsvars = HostVarsVars(variables, loader)
    expected_repr = repr(dict(a_dict=dict(a_key='a_value'),
                              a_list=[1, 2]))
    assert hostvarsvars.__repr__() == expected_repr

# Generated at 2022-06-23 15:02:03.453717
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from copy import deepcopy
    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    hostvars.set_host_variable(host=inventory.get_host('localhost'), varname='foo', value='bar')
    deepcopy(hostvars)

# Generated at 2022-06-23 15:02:14.705276
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import unittest
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    vars_mgr = VariableManager(loader=loader)
    vars_mgr._vars_plugins.extend(vars_loader.all(class_only=True))
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    hostvars = HostVars(inventory, vars_mgr, loader)
    data = hostvars['localhost']


# Generated at 2022-06-23 15:02:24.295191
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    class _Loader(object):
        pass
    loader = _Loader()

    class _VariableManager(object):
        def __init__(self, loader):
            self._loader = loader

        def __getstate__(self):
            return {'_loader': None}

        def __setstate__(self, state):
            self.__dict__.update(state)

    variable_manager = _VariableManager(loader)

    class _Host(object):
        pass
    host = _Host()

    class _Inventory(object):
        def get_host(self, host_name):
            return host

    inventory = _Inventory()

    hostvars = HostVars(inventory, variable_manager, loader)

    state = hostvars.__getstate__()
    assert state.get('_variable_manager') is variable_manager

# Generated at 2022-06-23 15:02:26.520067
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    host = {'name': 'localhost'}
    facts = {'foo': 'bar'}
    hv = HostVars({}, None, None)
    hv._variable_manager = None
    hv.set_host_facts(host, facts)

# Generated at 2022-06-23 15:02:34.283697
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.hosts.append("host_1")
    assert "host_1" in hostvars
    assert "host_2" not in hostvars


# Generated at 2022-06-23 15:02:42.176524
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()

    # Create the inventory and use path to host file as source or hosts
    inventory = InventoryManager(loader=DataLoader(), sources=['/etc/ansible/hosts'])
    # variable manager takes care of merging all the different sources to give you a unifed view of variables available in each context
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    assert 'host_name' in hostvars

# Generated at 2022-06-23 15:02:50.413119
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    ''' HostVars has method __iter__() '''

    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.vars_cache = dict(
        host1=dict(foo=2, bar='baz', some='thing'),
        host2=dict(foo=False, bar='baz', some='thing'),
    )

    hostvars = HostVars(variable_manager=variable_manager)
    hosts = sorted(hostvars)
    assert len(hosts) == 2
    assert hosts[0] == 'host1'
    assert hosts[1] == 'host2'


# Generated at 2022-06-23 15:02:55.171363
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    inventory = MockInventory()

    hostvars = HostVars(inventory=inventory, variable_manager=None, loader=None)
    assert hostvars._inventory is inventory

    inventory2 = MockInventory()
    hostvars.set_inventory(inventory2)
    assert hostvars._inventory is inventory2


# Generated at 2022-06-23 15:03:02.411100
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():

    # Empty inventory and empty variable manager
    # Create HostVars object.
    # Test that 'localhost' is not in that object
    from ansible.inventory import BaseInventory
    from ansible.vars import VariableManager
    from ansible.template import Templar
    templar = Templar(loader=None)
    base_inventory = BaseInventory(templar=templar)
    variable_manager = VariableManager(loader=None, inventory=base_inventory)
    host_vars = HostVars(base_inventory, variable_manager, loader=None)
    assert 'localhost' not in host_vars

    # Empty inventory, variable manager with localhost
    # Create HostVars object.
    # Test that 'localhost' is in that object
    base_inventory = BaseInventory(templar=templar)
    variable_

# Generated at 2022-06-23 15:03:12.500790
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import wrap_var

    _loader = DataLoader()

    inventory = Inventory(_loader)
    inventory.hosts.append(Host('localhost'))

    variable_manager = VariableManager(loader=_loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, _loader)

    wrap_var(hostvars)
    wrap_var(hostvars._variable_manager._vars_cache)

    hostvars.raw_get('localhost')['foo'] = 'bar'

    assert hostvars['localhost']['foo'] == 'bar'
    assert hostvars.raw_get('localhost')['foo'] == 'bar'
    assert hostvars._variable_manager._vars_

# Generated at 2022-06-23 15:03:24.270916
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    '''
    Test HostVarsVars' __len__() method
    '''
    import sys
    import os

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import PY3

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar


    class DummyYAMLObject(AnsibleBaseYAMLObject):
        yaml_loader = None
        yaml_dumper = None
        yaml_tag = u'!DummyYAMLObject'

        @classmethod
        def to_yaml(cls, dumper, data):
            return d

# Generated at 2022-06-23 15:03:29.839917
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory("")
    inventory.hosts = {'172.0.0.2': None}
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert '172.0.0.2' in hostvars
    assert '172.0.0.3' not in hostvars



# Generated at 2022-06-23 15:03:40.616607
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import os

    hostvars_vars_obj = HostVarsVars({'foo': 'bar', 'baz':'{{ foo }}'}, loader=None)
    assert hostvars_vars_obj['foo'] == 'bar'
    assert hostvars_vars_obj['baz'] == 'bar'

    # fail_on_undefined=False in method HostVarsVars.__getitem__,
    # so missing variable is not raising an exception
    assert hostvars_vars_obj['ansible_version'] == AnsibleUndefined()

    # We can use static_vars as expected when using HostVarsVars
    hostvars_vars_obj = HostVarsVars({}, loader=None)

# Generated at 2022-06-23 15:03:52.699305
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import become_loader, connection_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    class OptionsModule(object):
        def __init__(self, connection='local'):
            self.connection = connection
            self.become = False
            self.become_method = None
            self.become_user = None

    become_loader.get('sudo')
    connection_loader.get(OptionsModule(connection='local').connection)

    inventory = InventoryManager('localhost,')
    host = inventory.get_host(inventory.hosts[0])
    play_context = {}

# Generated at 2022-06-23 15:04:00.189052
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host="test_host", varname="test_var", value="test_value")
    hostvars = HostVars(loader=None, inventory=None, variable_manager=variable_manager)
    hostvars.set_variable_manager(variable_manager)
    assert "test_var" in hostvars.raw_get("test_host")
    assert hostvars.raw_get("test_host")["test_var"] == "test_value"

# Generated at 2022-06-23 15:04:08.251733
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    inv = Inventory('/path/to/inventory')
    var_mgr = VariableManager(loader=None, inventory=inv)
    hostvars = HostVars(inventory=None, loader=None, variable_manager=var_mgr)
    assert hostvars._inventory is None
    hostvars.set_inventory(inv)
    assert hostvars._inventory is inv

# Generated at 2022-06-23 15:04:18.888494
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import ansible
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Dynamic inventory script expects a list of groups as input
    groups = [
        Group(name="testgroup1"),
        Group(name="testgroup2"),
    ]

    # Dynamic inventory script expects a list of hosts as input

# Generated at 2022-06-23 15:04:21.769244
# Unit test for constructor of class HostVars
def test_HostVars():
    hostvars = HostVars({'hostvars': {'somehost': {'key': 'value'}}}, None, None)
    assert hostvars['somehost']['key'] == 'value'

# Generated at 2022-06-23 15:04:29.179306
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    hostvars = HostVars(inventory, variable_manager, loader)

    global_vars = {'v1': 'global'}
    variable_manager.set_nonpersistent_facts(global_vars)

    host = inventory.get_host('localhost')
    host_vars = {'v1': 'host', 'v2': 'host'}
    hostvars.set_host_facts(host, host_vars)

    hostvars

# Generated at 2022-06-23 15:04:39.032456
# Unit test for constructor of class HostVars
def test_HostVars():

    # Get classes from ansible.module_utils.common
    # (file module_utils/common.py)
    from ansible.module_utils.common import load_platform_subclass

    # Get classes from ansible.vars.hostvars
    # (file vars/hostvars.py)
    from ansible.vars.hostvars import HostVars

    # Get class from ansible.inventory.manager
    # (file inventory/manager.py)
    from ansible.inventory.manager import InventoryManager

    # Get class from ansible.parsing.dataloader
    # (file parsing/dataloader.py)
    from ansible.parsing.dataloader import DataLoader
    # Get class from ansible.vars.manager
    # (file vars/manager.py)
   

# Generated at 2022-06-23 15:04:44.288332
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.plugins.loader import vars_loader

    variables = {'foo': 'bar', 'baz': 'buzz'}
    variables = wrap_var(variables)

    hostvars_vars = HostVarsVars(variables, vars_loader)

    assert repr(hostvars_vars) == "{'foo': 'bar', 'baz': 'buzz'}"

# Generated at 2022-06-23 15:04:56.466974
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    test_host = '127.0.0.1'

    # Create a mock play which creates a variable x = 1 and assigns a host to it
    play_source = dict(
        name = "Ansible Play 1",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='set_fact', args=dict(x='1'))),
            dict(action=dict(module='debug', args=dict(msg='{{x}}')))
        ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=False)

# Generated at 2022-06-23 15:05:01.004394
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(host_list='ansible/tests/inventory')
    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader=None)

    # hostvars should contain all hosts
    assert len(hostvars) == 3


# Generated at 2022-06-23 15:05:13.006070
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    mock_play_context = Mock()
    mock_play_context.only_tags = None
    mock_play_context.skip_tags = None
    mock_play_context.run_additional_tasks = None
    mock_play_context.port = None
    mock_play_context.connection = None
    mock_play_context.remote_user = None
    mock_play_context.password = None
    mock_play_context.private_key_file = None
    mock_play_context.timeout = 10
    mock_play_context.shell = None
    mock_play_context.verbosity = 3
    mock_play_context.check_mode = False
    mock_play_context.become = False
    mock_

# Generated at 2022-06-23 15:05:22.566114
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.vars.reserved import Reserved, DEFAULT_VAULT_ID_MATCH

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    host.vars = dict(var1='var1_host_value')
    inventory.hosts = dict(host=host)
    hostvars = HostVars(inventory, variable_manager, loader)
    var1_value = hostvars.raw_get(host.name)

# Generated at 2022-06-23 15:05:28.298164
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    inventory = Inventory("")
    loader = None
    variable_manager._loader = loader
    variable_manager._hostvars = None

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars._variable_manager._hostvars = None
    hostvars._variable_manager._loader = None
    hostvars.__setstate__(hostvars.__dict__)

    assert variable_manager._hostvars == hostvars
    assert variable_manager._loader == loader
    assert hostvars._variable_manager._hostvars == hostvars
    assert hostvars._variable_manager._loader == loader

# Generated at 2022-06-23 15:05:37.388760
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    inventory = None
    loader = None

    hostvars = HostVars(inventory, variable_manager, loader)

    # _hostvars is set by set_variable_manager
    assert variable_manager._hostvars is None

    variable_manager2 = VariableManager()
    hostvars.set_variable_manager(variable_manager2)
    assert variable_manager2._hostvars is hostvars

    # _hostvars is not updated for previous variable_manager instance
    assert variable_manager._hostvars is None

# Generated at 2022-06-23 15:05:44.541879
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    class Inventory(object):
        def __init__(self):
            self.hosts = []
        def get_host(self, h):
            self.hosts.append(h)
            return h

    h = HostVars(Inventory(), None, None)
    assert h._inventory.hosts == []
    assert h['test_host'] == h['test_host']
    assert h['test_host'] == h['test_host']
    assert h._inventory.hosts == ['test_host']*2

# Generated at 2022-06-23 15:05:52.938803
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])

    my_variable_manager = VariableManager(loader=DataLoader(), inventory=my_inventory)

    my_hostvars = HostVars(inventory=my_inventory, variable_manager=my_variable_manager, loader=DataLoader())

    hostvars_contains_test_data = {
        'test_contains_1': (
            'test_host_001',
            True,
        ),
        'test_contains_2': (
            'test_host_002',
            False,
        ),
    }


# Generated at 2022-06-23 15:05:56.605616
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = None
    variables = {'host_var': 'host_var'}
    hvv = HostVarsVars(variables, loader)
    keys = []
    for key in hvv.__iter__():
        keys.append(key)
    assert len(keys) == 1
    assert 'host_var' in keys


# Generated at 2022-06-23 15:06:00.022814
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    fake_vars = {'test': 'test'}
    assert len(HostVarsVars(variables=fake_vars, loader=None)) == 1

# Generated at 2022-06-23 15:06:10.370431
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    # Create a Mock object for inventory
    inventory = create_autospec(Mapping)

    # Create a Mock object for loader
    loader = create_autospec(Mapping)

    # Create a Mock object for variable_manager
    variable_manager = create_autospec(Mapping)

    # We create a HostVars object
    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=variable_manager)

    # We iterate the HostVars object, an the __iter__ method is called
    hostvars.__iter__()

    # We expect that the method __iter__ of the inventory has been called
    inventory.hosts.__iter__.assert_called_with()


# Generated at 2022-06-23 15:06:21.714757
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DictDataLoader({
        'foo': """---
a: b
""",
    })

    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='host_vars/')
    hostvars = HostVars(inventory, vars_manager, loader)

    templar = Templar(
        loader=loader,
        variables=hostvars,
        shared_loader_obj=loader,
    )
    templar.template("{{ hostvars['foo']['a'] }}")

    repr_hostvars = repr(hostvars)


# Generated at 2022-06-23 15:06:33.639828
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import os
    from collections import Iterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory_path = os.path.join(os.path.dirname(__file__), '../../inventory/test_inventory.yml')
    inventory = InventoryManager(loader=None, sources=[inventory_path])

    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    # test to make sure the class implements Iterator
    assert issubclass(type(hostvars.__iter__()), Iterator)

    # test the order of the values returned
    iter_return = hostvars.__iter__()
    assert(next(iter_return) == 'local')

# Generated at 2022-06-23 15:06:41.389250
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    '''
    This is a test for method __getitem__ of class HostVarsVars.
    '''
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six.moves import UserDict
    from ansible.vars import VariableManager

    test_loader = UserDict()

    test_data = dict(test_key='test_value')

    hostvars_vars = HostVarsVars(test_data, test_loader)

    # Test for isinstance so we can use the following syntax for assert:
    #    assert isinstance(hostvars_vars, Mapping)
    assert isinstance(hostvars_vars, Mapping)
    assert type(hostvars_vars) == HostVarsVars

# Generated at 2022-06-23 15:06:49.640508
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import pytest

    # fixture to create a dummy host
    @pytest.fixture()
    def new_host(mocker):
        inventory = mocker.Mock()
        host = mocker.Mock()
        host.get_name.return_value = 'localhost'
        host.vars = dict()

        inventory.get_host.return_value = host
        return host

    # setup a mocker for HostVars
    mocker = pytest.Mock()
    mocker.attach_mock(HostVars, 'HostVars')

    # patching AnsibleModule
    mocker.patch('ansible.module_utils.common.AnsibleModule')

    # patching AnsibleUndefined
    mocker.patch('ansible.template.AnsibleUndefined')

    # patching VariableManager
   

# Generated at 2022-06-23 15:06:57.473158
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Create an instance of HostVars
    hv = HostVars(inventory={'localhost': {'key1': 'value1', 'key2': 'value2'}}, variable_manager={'get': ''}, loader={'get': ''})

    # Assert that the return value contains all keys
    # Should be '{'localhost': {'key1': 'value1', 'key2': 'value2'}}'
    assert repr(hv) == '{' + repr(localhost={'key1': 'value1', 'key2': 'value2'}) + '}'

# Generated at 2022-06-23 15:07:09.410381
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    """
    Test for method __getitem__ of class HostVarsVars.
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_inventory(inventory)
    hostvars.set_variable_manager(variable_manager)

# Generated at 2022-06-23 15:07:19.180482
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.host_vars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible import context

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(None, variable_manager, loader)

    # Create inventory to test __getitem__
    inventory = InventoryManager(loader=loader, sources=None)
    host = inventory.get_host("127.0.0.1")
    variable_manager.set_nonpersistent_facts(host, dict(foo='bar'))

    # Test __getitem__ to see whether it returns correct value

# Generated at 2022-06-23 15:07:30.872124
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():

    from copy import deepcopy
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars.set_host_variable(inventory.get_host("127.0.0.1"), "foo", "bar")

    # If a specific bug is present in HostVars.__deepcopy__, the following line
    # will fail to execute and a TypeError exception will be raised
    deepcopy(hostvars)

# Generated at 2022-06-23 15:07:36.469099
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager('localhost,')
    variable_manager = dict()
    loader = dict()

    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')
    hostvars.set_nonpersistent_facts(host, dict(foo='bar'))

    assert hostvars['localhost']['foo'] == 'bar'

# Generated at 2022-06-23 15:07:47.496934
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    inventory = Inventory(loader=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, loader=None, variable_manager=variable_manager)

    # first test the method with a single HostVars
    # the result should be the same HostVars
    assert deepcopy(hostvars) is hostvars

    # second test the method with nested HostVars
    hostvars_nested = {'foo': hostvars}
    hostvars_nested_cp = deepcopy(hostvars_nested)
    # the deepcopy should have created a new variable
    assert hostvars_nested is not hostvars_nested_cp

# Generated at 2022-06-23 15:07:52.873326
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import jinja2

    try:
        hvars = HostVarsVars({'foo': '{{ ansible_version }}'}, loader=jinja2.DictLoader({}))
        assert not hvars['foo']
    except Exception:
        assert False, "HostVarsVars() raised ExceptionType unexpectedly!"


# Generated at 2022-06-23 15:07:57.763841
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    inventory = FakeInventory()
    loader = FakeLoader()
    variable_manager = FakeVariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)
    assert len(hostvars) == 3



# Generated at 2022-06-23 15:08:06.005828
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    # An inventory source that returns an empty group
    class FakeInventorySource(object):
        name = 'fake_inventory_source'
        host_name = 'fake_host_name'

        def __init__(self):
            self._group = FakeGroup()

        def get_groups_dict(self, refresh=False):
            return {'localhost': self._group}

        def get_groups(self, refresh=False):
            return [self._group]

    # A group that returns a host with a hard-coded name
    class FakeGroup(object):
        def __init__(self):
            self._host = FakeHost()

        def get_hosts(self, refresh=False):
            return [self._host]

    # A host that has a hard-coded name

# Generated at 2022-06-23 15:08:10.998443
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    inventory = None
    loader = None
    variable_manager = MagicMock()

    hv = HostVars(inventory, variable_manager, loader)
    hv.set_host_variable(None, "test_var", "test_val")

    variable_manager.set_host_variable.assert_called_with(None, "test_var", "test_val")



# Generated at 2022-06-23 15:08:20.141648
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class MockLoader():
        pass

    class MockVariableManager():
        pass

    class MockInventory():
        def __init__(self):
            self.hosts = ['host1', 'host2', 'host3']

    hostvars = HostVars(MockInventory(), MockVariableManager(), MockLoader())
    assert repr(HostVarsVars(hostvars['host1'], MockLoader())) == "None"
    assert repr(HostVarsVars(hostvars['host2'], MockLoader())) == "None"
    assert repr(HostVarsVars(hostvars['host3'], MockLoader())) == "None"

# Generated at 2022-06-23 15:08:23.902841
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    hvv = HostVarsVars({'a': 1, 'b': 2}, loader=None)
    assert len(hvv) == 2
    assert repr(hvv) == repr({'a': 1, 'b': 2})



# Generated at 2022-06-23 15:08:32.661926
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from pprint import pprint
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader,
        sources=['test/ansible/inventory/test_inventory.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    pprint(len(hostvars))


# Generated at 2022-06-23 15:08:40.777362
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars import VariableManager
    # arrange
    hv = HostVars(None,
                  variable_manager=VariableManager())
    hv._find_host = lambda host_name: host_name
    # act
    hv["test"] = {"a": 1, "b": 2}
    hv.set_host_variable("test", "a", 3)
    # assert
    assert hv["test"]["a"] == 3
    # cleanup
    del hv["test"]

# Generated at 2022-06-23 15:08:48.571461
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    hostvars = HostVars(inventory=InventoryManager(loader=DataLoader(), sources=""), variable_manager=VariableManager(loader=DataLoader()), loader=DataLoader())
    print(repr(HostVarsVars({"foo": "bar", "baz": 42, "hostvars": hostvars}, loader=DataLoader())))


# Generated at 2022-06-23 15:08:59.804722
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    host = Inventory().get_host('localhost')

    vars_manager = VariableManager()
    vars_manager._hostvars = HostVars(inventory=Inventory(), variable_manager=vars_manager, loader=DataLoader())
    non_persistent_facts = {'non_persistent_fact': 42}
    persistent_facts = {'persistent_fact': 42}
    vars_manager.set_nonpersistent_facts(host, non_persistent_facts)
    vars_manager.set_host_facts(host, persistent_facts)
    vars_manager.set_host