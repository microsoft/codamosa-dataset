

# Generated at 2022-06-23 14:59:03.739842
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from six import PY3
    from ansible.compat.six import iteritems
    from ansible.compat.tests import unittest

    if PY3:
        raise unittest.SkipTest('hostvars is not supported on Python 3')

    hosts = ["foobar.example.com", "somehost.example.com"]
    groups = [
        {"name": "ungrouped", "vars": {"foo": "one"}},
        {"name": "all", "vars": {"foo": "two"}},
        {"name": "special", "vars": {"special_var": "three"}}
    ]
    inventory = Inventory(hosts, groups)


# Generated at 2022-06-23 14:59:09.574905
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    context.CLIARGS = context.CLIARGS._replace(connection='local')
    hostvars = HostVars(inventory, variable_manager, loader)
    host = inventory.get_host('localhost')
    hostvars.set_host_facts(host, {'foo': 'bar'})
    assert 'foo' in hostvars.raw_get('localhost')


# Generated at 2022-06-23 14:59:18.512127
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    loader = None
    variable_manager = VariableManager()
    variable_manager._loader = loader
    variable_manager._hostvars = None
    variable_manager._inventory = None
    variable_manager._extra_vars = None
    variable_manager.set_inventory(Inventory(loader=loader))
    hostvars = HostVars(variable_manager.inventory, variable_manager, loader)
    assert hostvars._variable_manager != variable_manager
    assert hostvars._variable_manager._loader != loader
    assert hostvars._variable_manager._hostvars != hostvars
    hostvars.set_variable_manager(variable_manager)
    assert hostvars._variable_manager == variable_manager
    assert hostvars._variable_manager

# Generated at 2022-06-23 14:59:29.573132
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    # Create hostvars. We cannot use real objects here so we create
    # minimal mock objects that are enough to satisfy our tests.
    #
    # Note that some hostvars' methods are not actually used
    # (set_host_variable, set_host_facts). Anyway we have to mock them
    # because they are called during deepcopy.
    class HostVars(object):
        def __init__(self, variables, loader):
            self._variable_manager = variables
            self._loader = loader

        def __deepcopy__(self, memo):
            return self

        def set_variable_manager(self, variables):
            self._variable_manager = variables

        def set_inventory(self, inventory):
            pass

        def set_host_variable(self, host, varname, value):
            pass


# Generated at 2022-06-23 14:59:39.433331
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    variables = dict(
        ansible_version=1,
        ansible_play_hosts=2,
        ansible_dependent_role_names=3,
        ansible_play_role_names=4,
        ansible_role_names=5,
        inventory_hostname='i h',
        inventory_hostname_short='i hs',
        inventory_file='i f',
        inventory_dir='i d',
        groups=6,
        group_names=7,
        omit=8,
        playbook_dir='p d',
        play_hosts='p h',
        role_names=9,
        ungrouped=10,
    )
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)
    assert 'ansible_version' in hostvars

# Generated at 2022-06-23 14:59:50.273869
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Create temporary inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader,
                                 sources=C.LOCALHOST_INVENTORY_PATH)

    # Create variables manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create HostVars
    hostvars = HostVars(inventory=inventory,
                        variable_manager=variable_manager,
                        loader=loader)

    # Create test host
    host_name = 'localhost'
    host = inventory.get_host(host_name)

    # Create test variables
    fact_name = 'test_fact_name'

# Generated at 2022-06-23 15:00:00.275717
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/hostvars.py'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = Host('localhost')
    assert 'ansible_play_role_names' not in hostvars

    # add a hostvar to playvars
    hostvars.set_host_variable(host, 'ansible_play_role_names', C.DEFAULT_HOST_LIST)
    # add

# Generated at 2022-06-23 15:00:10.520772
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    inv = InventoryManager(loader=None, sources='localhost')
    host = inv.get_host('localhost')
    vars_mgr = VariableManager(loader=None, inventory=inv)
    vars_mgr._fact_cache = {'localhost': dict()}
    hostvars = HostVars(inv, vars_mgr, loader=None)
    hostvars.set_nonpersistent_facts(host, dict(a=1, b=2))
    assert vars_mgr._fact_cache['localhost'] == dict(a=1, b=2)



# Generated at 2022-06-23 15:00:19.349022
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.template import Templar
    from ansible.inventory import Inventory
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager

    # Create VariableManager to store variables
    variable_manager = VariableManager()
    variable_manager._vault = VaultLib('AES256', 'ansible', 'password')

    # Define inventory
    inventory = Inventory(loader=None)
    inventory.add_host('localhost')
    inventory.set_variable('localhost', 'key1', 'value1')
    variable_manager.set_inventory(inventory)

    # Define inventory variables
    variable_manager._vars_cache['localhost'] = 'value2'

    # Create HostVars
    hostvars = HostVars(inventory, variable_manager, None)
    hostvars._variable_manager

# Generated at 2022-06-23 15:00:24.137761
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # prepare mocks
    loader = None
    variable_manager = None
    inventory = None

    # test set_variable_manager works fine when it is called with previous
    # value of _variable_manager to None
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._variable_manager is None
    hostvars.set_variable_manager(variable_manager)
    assert hostvars._variable_manager == variable_manager

# Generated at 2022-06-23 15:00:33.541523
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import copy

    class Loader(object):

        def __init__(self):
            self._template_cache = dict()

        def get(self, path):
            return path

        def template(self, template, **kwargs):
            return self._template_cache[template]

        def cache_template(self, template, data):
            self._template_cache[template] = data

    loader = Loader()
    loader.cache_template('foo', 'bar')

    vars = dict()
    vars['foo'] = 'foo'
    vars['bar'] = 'bar'
    vars['baz'] = 'baz'
    vars['qux'] = 'qux'

    hvv = HostVarsVars(vars, loader)


# Generated at 2022-06-23 15:00:42.153417
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()

    inventory = Inventory(loader, variable_manager)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars._inventory is not None

    inventory_new = Inventory(loader, variable_manager)
    hostvars.set_inventory(inventory_new)

    assert hostvars._inventory is not None
    assert hostvars._inventory is not inventory
    assert hostvars._inventory is inventory_new

# Generated at 2022-06-23 15:00:46.353397
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    vars = dict(foo='bar', bar='baz')
    hostvarsvars = HostVarsVars(vars, None)
    assert "foo" in hostvarsvars
    assert "bar" in hostvarsvars
    assert "baz" not in hostvarsvars

# Generated at 2022-06-23 15:00:56.463261
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.utils.vars import combine_vars

    inv_name = 'test_inventory'
    host_name = 'localhost'
    var_name = 'foo'
    var_value = 'bar'

    inv = Inventory(loader=None, variable_manager=None, host_list=None)
    inv.set_variable(inv_name, inv_name)

    host = Host(name=host_name)
    host.set_variable(var_name, var_name)
    inv.add_host(host, inv_name)

    vm = VariableManager()
    vm.set_inventory(inv)

    vc = combine_vars(loader=None, variables=vm.get_vars(host=host))
    assert host_name in vc

# Generated at 2022-06-23 15:01:05.435733
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible import inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = inventory.Inventory(loader=loader, host_list=[])
    inv_vars = inventory.InventoryVariable('hostvars', {}, {}, {}, inv=inv)
    inv.set_variable_manager(VariableManager(loader=loader, inventory=inv))
    inv.set_host_variable('fake_host1', 'foo', 1)
    inv.set_host_variable('fake_host2', 'foo', 1)
    inv.set_host_variable('fake_host3', 'foo', 1)
    inv.add_host(inventory.Host('fake_host1', inv_vars=inv_vars))
    inv

# Generated at 2022-06-23 15:01:13.125040
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, ['./tests/inventory'])
    variable_manager = VariableManager()

    for host in inventory.get_hosts():
        variable_manager.set_host_variable(host, 'foo', 'bar')

    hostvars = HostVars(inventory, variable_manager, loader)

    # Make sure a single host is returned and has the correct value
    assert hostvars['localhost'] == {'foo': 'bar'}


# Generated at 2022-06-23 15:01:23.935708
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, 'localhost')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_user = None
    play_context.become_method = 'enable'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'cisco'
   

# Generated at 2022-06-23 15:01:29.578667
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import iteritems

    # test setup
    loader = DataLoader()
    inventory = loader.load('')
    inventory.hosts = dict((h.name, h) for h in [Host(name='localhost')])
    inventory.groups = dict((g.name, g) for g in [Group(name='test_group')])
    host = inventory.hosts['localhost']
    group = inventory.groups

# Generated at 2022-06-23 15:01:38.047765
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from unittest import TestCase

    # Variables dict has no key 'var_name'.
    variables = {}
    loader = None
    hvv = HostVarsVars(variables, loader)

    TestCase.assertFalse(hvv.__contains__('var_name'))

    # Variables dict has key 'var_name' with value 'var_value'.
    variables = {'var_name': 'var_value'}
    hvv = HostVarsVars(variables, loader)

    TestCase.assertTrue(hvv.__contains__('var_name'))



# Generated at 2022-06-23 15:01:44.850603
# Unit test for constructor of class HostVars
def test_HostVars():
    import unittest
    import mock

    class AnsibleVariableManagerTest(unittest.TestCase):
        def setUp(self):
            def _load_plugins():
                return ()
            mock_load_plugins = mock.Mock(side_effect=_load_plugins)
            mock_load_plugins.__name__ = 'load_plugins'
            self.old_load_plugins = ansible.plugins.loader.load_plugins
            ansible.plugins.loader.load_plugins = mock_load_plugins

        def tearDown(self):
            ansible.plugins.loader.load_plugins = self.old_load_plugins

        @mock.patch('ansible.utils.vars.combine_vars')
        def test_hostvars_constructor(self, mock_combine_vars):
            mock_inventory

# Generated at 2022-06-23 15:01:56.195910
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible import constants
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import os

    constants.HOST_KEY_CHECKING = False
    context = PlayContext()
    context._set_inventory(Inventory(loader=os.getcwd()))
    context._set_loader('/opt/ansible/ansible-2.8.7/lib/ansible/plugins/test_loader.py')
    context._set_variable_manager(VariableManager())

    hostvars = HostVars(context.inventory, context.variable_manager, context.loader)
    hostvars.set_host_variable(Inventory(loader=os.getcwd()).get_host('all'), 'foo', 'bar')


# Generated at 2022-06-23 15:02:05.881313
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.variable_manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    foo = {'foo': 'bar'}
    hostvars.set_host_variable(host=inventory.get_host('localhost'), varname='foo', value=foo)

    assert(isinstance(hostvars['localhost']['foo'], HostVarsVars))
    assert(hostvars['localhost']['foo'] == {'foo': 'bar'})


# Generated at 2022-06-23 15:02:15.696721
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variables = {
        'key': 'value',
        'key2': {'key3': 'value3'},
        'key4': ['value4'],
        '__static_vars__': {'static_vars': 'yes'},
        '__omit_vars__': ['key'],
    }
    host_vars_vars = HostVarsVars(variables, loader)
    repr_value = repr(host_vars_vars)
    assert repr_value == "{'key2': {'key3': 'value3'}, 'key4': ['value4'], 'static_vars': 'yes'}"

# Generated at 2022-06-23 15:02:20.912385
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hh = HostVarsVars({}, None)

    hh._vars = {'a': 123, 'b': 456, 'c': 789}
    keys = []
    for k in hh:
        keys.append(k)

    assert set(keys) == {'a', 'b', 'c'}


# Generated at 2022-06-23 15:02:27.845293
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Required to initialize the class
    def _get_host_vars(host, vault_password=None):
        assert host.name == "host1"
        return {
            "foo": "bar",
            "password": "hunter2"
        }
    inventory = type('inventory', (), {'get_host': lambda x,y: type('host', (), {'get_vars': _get_host_vars})})()
    variable_manager = type('variable_manager', (), {'get_vars': lambda self, x: {}})()
    loader = type('loader', (), {'get_basedir': lambda x: '', 'path_dwim': lambda x: ''})()
    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-23 15:02:32.632990
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():

    variables = {'var_name': 'value'}
    hostvars = HostVarsVars(variables, loader=None)

    assert 'var_name' in hostvars, '__contains__ check failed'
    assert 'var_name_missing' not in hostvars, '__contains__ check failed'


# Generated at 2022-06-23 15:02:38.418308
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    import copy
    loader = None
    hostvars_vars = HostVarsVars({'foo': 'bar'}, loader)
    assert len(hostvars_vars) == 1

    legacy_hostvars_vars = copy.deepcopy(hostvars_vars)
    assert len(legacy_hostvars_vars) == 1



# Generated at 2022-06-23 15:02:49.136604
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Create an instance of VariableManagerStub instead of AnsibleVariableManager because
    # AnsibleVariableManager and its parent AnsibleBaseVars load data from some files
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManagerStub
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    inventory = InventoryManager(loader=DataLoader(), sources=['./test/test_hostvars_inventory.ini'])
    variable_manager = VariableManagerStub(inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    host = inventory.get_host('host1')

    # Test set_nonpersistent_facts

# Generated at 2022-06-23 15:02:59.444290
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import become_loader, module_loader, vars_loader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()

    # Mock
    inventory = InventoryManager(loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info=Play().DEFAULT_VERSION)
    become_loader.get = lambda *x, **y: None
    module_loader.get = lambda *x, **y: None
    vars_loader.get = lambda *x, **y: None

    # Test
    hostvars = HostVars(inventory, variable_manager, loader)
    hostv

# Generated at 2022-06-23 15:03:08.350012
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.group import Group

    # test empty
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    assert len(hv) == 0

    # test 3 items
    g = Group(inventory=None, name='foo')
    g.add_host('bar')
    g.add_host('baz')
    g.add_host('qux')
    hv = HostVars(inventory=g, variable_manager=None, loader=None)
    assert len(hv) == 3


# Generated at 2022-06-23 15:03:08.882790
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    pass

# Generated at 2022-06-23 15:03:17.193184
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing import vault
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    sample_inventory = '''
    localhost ansible_connection=local
    host1
    host2
    '''

    class VarsModule():
        ''' A empty class for testing __repr__ method of class HostVars '''

    mgr = InventoryManager(loader=None, sources=sample_inventory)
    mgr.parse_sources()
    vault_secrets = vault.VaultSecret(password_files=None)
    variable_manager = VariableManager(loader=None, inventory=mgr)
    vars_module = VarsModule()
    context = PlayContext()

# Generated at 2022-06-23 15:03:27.441725
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    '''
    Function that tests the correctness of the __deepcopy__ function of class HostVars.
    '''

    # setup
    import copy
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    Inventory = namedtuple('Inventory', ['hosts'])
    Host = namedtuple('Host', ['name', 'vars'])
    variables = {'test': 'value'}
    host = Host(name='test_host', vars=variables)

    # execute
    inventory = Inventory(hosts=[host])
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 15:03:35.726672
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['localhost,'])
    hostvars = HostVars(inventory, variable_manager, loader=loader)

    # Test for invalid host
    assert 'foo' not in hostvars

    # Test for valid host
    assert 'localhost' in hostvars


# Generated at 2022-06-23 15:03:36.933935
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # ...
    return True

# Generated at 2022-06-23 15:03:42.080022
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    inventory = InventoryManager()
    variable_manager = VariableManager()
    loader = DataLoader()
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)
    new_inventory = InventoryManager()
    hostvars.set_inventory(new_inventory)
    assert hostvars._inventory == new_inventory
    assert variable_manager._inventory == new_inventory


# Generated at 2022-06-23 15:03:53.193113
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import ansible.vars.hostvars_vars
    import ansible.vars.hostvars
    import ansible.template.template
    import ansible.template.templar
    import ansible.vars.variable_manager
    import ansible.parsing.yaml.objects
    import ansible.playbook.includer
    import ansible.utils.vars
    import ansible.inventory.host
    import ansible.inventory.manager
    import ansible.inventory.group
    import ansible.utils.unsafe_proxy
    import ansible.vars.unsafe_proxy

    host = ansible.inventory.host.Host("localhost")
    host.vars = ansible.vars.hostvars.HostVars(host, ansible.vars.variable_manager.VariableManager())
   

# Generated at 2022-06-23 15:04:02.663463
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory("tests/inventory")
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, None)
    host = inventory.get_host("testhost")

    facts = {"test": "testing"}
    hostvars.set_nonpersistent_facts(host, facts)

    assert variable_manager._fact_cache[host.name]['test'] == "testing"
    assert variable_manager.get_vars(host=host)['test'] == "testing"

    # test that ansible_facts are now set to a dict
    assert variable_manager.get_vars(host=host)['ansible_facts'] == {'test': 'testing'}

# Generated at 2022-06-23 15:04:11.581564
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost', '127.0.0.1'])
    variable_manager = VariableManager(loader=DataLoader())

    hostvars = HostVars(inventory, variable_manager, DataLoader())

    assert variable_manager._hostvars == hostvars

    variable_manager = VariableManager(loader=DataLoader())

    hostvars.set_variable_manager(variable_manager)

    assert variable_manager._hostvars == hostvars

# Generated at 2022-06-23 15:04:22.153498
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = Inventory(loader=loader, host_list=["127.0.0.1"])
    play = Play().load({},loader=loader, variable_manager=VariableManager(),
                       host_list=inventory.list_hosts())
    hv = HostVars(inventory, play.variable_manager, play._loader)
    host = hv._find_host("127.0.0.1")
    hv.set_nonpersistent_facts(host, dict(fact_one="foo", fact_two="bar"))

# Generated at 2022-06-23 15:04:25.858029
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    loader = DictDataLoader({'vars': {'foo': 'bar', 'a': 'b'}})

    variables = { 'x': 'y', 'vars': HostVarsVars({ 'foo': 'bar', 'a': 'b' }, loader) }

    templar = Templar(variables=variables, loader=loader)

    assert 'vars' in variables

# Generated at 2022-06-23 15:04:37.456284
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import os
    import sys
    import ansible.utils.plugin_docs as plugin_docs

    # Append path to module_utils directory to import the mock
    # AnsibleModule
    if os.path.exists(os.path.join(os.path.dirname(__file__),
                                   os.pardir, 'module_utils')):
        sys.path.append(os.path.join(os.path.dirname(__file__),
                                     os.pardir, 'module_utils'))
    from ansible.module_utils.common.collections import ImmutableDict

    module_data = {
        'params': {
            'platform': 'foo',
            'other': 'value',
        },
    }
    sys.modules['ansible'] = ImmutableDict(module_data)

    host

# Generated at 2022-06-23 15:04:40.156493
# Unit test for constructor of class HostVars
def test_HostVars():
    inventory = None
    variable_manager = None
    loader = None
    obj = HostVars(inventory, variable_manager, loader)

    assert isinstance(obj, HostVars)



# Generated at 2022-06-23 15:04:52.519874
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play  # FIXME: do not use internal type

    # Initialize hostvars.
    inventory = InventoryManager(None, 'localhost,')
    host = inventory.get_host('localhost')
    variables = dict(ansible_host='127.0.0.1', ansible_connection='local')
    loader = '<TEST_LOADER>'
    hostvars = HostVars(inventory=inventory, variable_manager=host.vars, loader=loader)
    hostvars.set_host_variable(host=host, varname='test_var', value='test_value')
    assert hostvars.raw_get('localhost') == variables

    # Dump __dict__ of hostvars.
    pickle_data = hostv

# Generated at 2022-06-23 15:04:59.246234
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    hostvars = HostVars(inventory=inventory, variable_manager=None, loader=loader)

    for host in inventory.hosts:
        assert 'hostvars["%s"]' % host.name != AnsibleUndefined("hostvars['%s']" % host.name)

        hostvars = HostVars(inventory=inventory, variable_manager=VariableManager(loader=loader, inventory=inventory), loader=loader)

        assert host.name in hostvars



# Generated at 2022-06-23 15:05:10.140631
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    inventory = FakeInventory()
    variable_manager = FakeVariableManager()

    host_vars = HostVars(inventory=inventory,
                         variable_manager=variable_manager,
                         loader=None)

    host = FakeHost()
    host.name = 'samplehost'
    fact = 'samplefact'

    host_vars.set_nonpersistent_facts(host, {fact: None})

    # Check that fact is set in HostVars and that it is not persisted
    assert host.get_vars() is not None
    assert fact in host.get_vars()
    assert host_vars._variable_manager._nonpersistent_fact_values == {}


# Generated at 2022-06-23 15:05:20.380842
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a key that is in host variables
    hostvars._vars = {'foo': 'bar'}
    hostvarsvars = HostVarsVars(hostvars._vars, loader)
    assert(hostvarsvars.__contains__('foo'))

    # Test with a key that is not in host variables
    hostvars._vars = {'foo': 'bar'}
    hostvarsvars

# Generated at 2022-06-23 15:05:23.344929
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    '''
    Test __len__ method of HostVarsVars class.
    '''
    hostvars_vars = HostVarsVars({'foo':'bar'}, None)
    assert len(hostvars_vars) == 1

# Generated at 2022-06-23 15:05:35.819856
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    hostvars = HostVars(inv_manager, variable_manager, loader)
    hostvars.set_host_variable(inv_manager.get_host('localhost'), 'x', 'foo')

    templar = Templar(loader=loader)

# Generated at 2022-06-23 15:05:41.133751
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.inventory.host import Host
    host = Host('test_host')

    from ansible.vars.hostvars import HostVarsVars
    host_vars_vars = HostVarsVars({'a': 1}, None)
    assert 'a' in host_vars_vars
    assert 'b' not in host_vars_vars

# Generated at 2022-06-23 15:05:51.160463
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook import Playbook

    inventory = InventoryManager(loader=None, sources='./test/ansible/inventory')
    playbook = Playbook.load('test/ansible/playbook.yml', loader=None, inventory=inventory)
    variable_manager = playbook.get_variable_manager()
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=playbook._loader)
    inventory.set_variable_manager(variable_manager)

    # Create a new variable manager
    variable_manager = VariableManager(loader=playbook._loader, inventory=inventory)
    # Set it as the new variable manager
    hostvars.set_variable_manager(variable_manager)
    #

# Generated at 2022-06-23 15:05:59.683149
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inv_d = """
        [mahost]
        foo ansible_ssh_host=192.168.0.5
        bar
        [mygroup]
        foo
        [baz]
        ugh
        """
    inv_f = loader.load_from_file(inv_d)
    inventory = InventoryManager(loader=loader, sources='localhost,')
    vars_manager = VariableManager(loader=loader, inventory=inventory, version_info=inventory._get_hosts_and_groups_and_defaults()[2])
    hostvars = HostVars(inventory, vars_manager, loader)

# Generated at 2022-06-23 15:06:11.220493
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    from ansible.inventory import Host, Group
    from ansible.vars.manager import VariableManager

    hosts = [Host(name="host1"), Host(name="host2"), Host(name="host3")]
    groups = [Group(name="group1"), Group(name="group2"), Group(name="group3")]
    for host in hosts:
        for group in groups:
            group.add_host(host)
    inventory = {}
    inventory["_meta"] = {"hostvars": {}}
    for host in hosts:
        inventory["_meta"]["hostvars"][host.get_name()] = {}
    for group in groups:
        inventory[group.get_name()] = {"hosts": [host.name for host in group.get_hosts()]}

    # test on HostVars
   

# Generated at 2022-06-23 15:06:21.942914
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from unit.mock.loader import DictDataLoader
    from unit.mock.inventory import MockInventory
    from ansible.vars import VariableManager

    vars_manager = VariableManager()
    inventory = MockInventory(vars_manager, loader=DictDataLoader({}))
    vars_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, loader=DictDataLoader({}), variable_manager=vars_manager)

    # test empty inventory
    assert len(hostvars) == 0

    inventory._hosts_cache = [1]
    assert len(hostvars) == 1

    inventory._hosts_cache = [1, 2, 3]
    assert len(hostvars) == 3


# Generated at 2022-06-23 15:06:26.262664
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    hostvars = {'foo': 'bar'}
    m = HostVarsVars(hostvars, None)
    assert(m['foo'] == 'bar')

# Generated at 2022-06-23 15:06:27.585774
# Unit test for constructor of class HostVars
def test_HostVars():
    hv = HostVars(None, None, None)
    assert hv is not None

# Generated at 2022-06-23 15:06:36.779337
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader, [])
    variable_manager = VariableManager(loader, inventory)
    hostvars = HostVars(InventoryManager(loader, []), variable_manager, loader)

    host = inventory.get_host('testhost1')
    assert host is not None

    hostvars.set_host_facts(host, DistributionFactCollector().collect(host))
    assert hostvars.get('testhost1') is not None

# Generated at 2022-06-23 15:06:42.975994
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import unittest
    import tempfile
    import shutil

    # This is how we can mock objects in Python 2 and Python 3
    try:
        from unittest.mock import patch, MagicMock
    except ImportError:
        from mock import patch, MagicMock

    from ansible.vars.manager import VariableManager

    # Prepare a temporary directory for testing
    temp_path = tempfile.mkdtemp()

    # Monkey patch get temp directory
    def mocked_mkdtemp():
        return temp_path

    def mocked_open_if_exists(x, y):
        # Return a fake file handle
        return MagicMock(spec=file)


# Generated at 2022-06-23 15:06:52.916396
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(host_list=[])
    variable_manager = VariableManager(loader=DataLoader())
    play_context = Play()

    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    host = inventory.get_host("localhost")

    facts = {}
    hostvars.set_host_facts(host, facts)
    assert variable_manager._fact_cache[host.name] == facts
    assert host.vars == facts

# Generated at 2022-06-23 15:06:59.384233
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import types
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variables = {
        'a': 'b',
        'c': 'd'
    }
    hostvarsvars = HostVarsVars(variables, loader)
    assert isinstance(hostvarsvars.__iter__(), types.GeneratorType)
    assert sorted(hostvarsvars.__iter__()) == ['a','c']
    VariableManager._hostvars = None

# Generated at 2022-06-23 15:07:06.968154
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=None)
    inventory.hosts = {'ahost': object()}
    hostvars = HostVars(inventory, None, loader)

    assert hostvars._loader is loader

    hostvars.__setstate__({'_loader': None})

    assert hostvars._loader is loader

# Generated at 2022-06-23 15:07:14.830863
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    class Inventory(object):
        def __init__(self, hosts=None):
            self.hosts = hosts or []

        def hosts(self):
            return self.hosts

        def get_host(self, host_name):
            for host in self.hosts:
                if host.name == host_name:
                    return host
            return None

        def contains_name(self, host_name):
            return self.get_host(host_name) is not None

        def get_variables(self, host, include_hostvars=True):
            if include_hostvars:
                hostvars = host.get_vars()
                if hostvars:
                    return hostvars
            return {}

    class Host(object):
        def __init__(self, name, vars={}):
            self

# Generated at 2022-06-23 15:07:19.521441
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    loader = 'dummy'
    variables = dict(foo='bar')

    # Regular case
    hostvarsvars = HostVarsVars(loader=loader, variables=variables)
    assert 'foo' in hostvarsvars

    # Exception
    hostvarsvars = HostVarsVars(loader=loader, variables={})
    assert 'foo' not in hostvarsvars

# Generated at 2022-06-23 15:07:31.287869
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    from ansible.inventory.manager import InventoryManager

    inventory_manager = InventoryManager("")
    hosts = [
        "localhost ansible_connection=local",
        "[group1]",
        "localhost",
        "[group2]",
        "localhost"
    ]

    inventory_manager.add_group("group1")
    inventory_manager.add_group("group2")

    inventory_manager.add_host(host="localhost")
    inventory_manager.reconcile_inventory()

    inventory_manager.hosts["localhost"].set_variable("foo", "bar")

    host_vars = HostVars(inventory_manager, None, None)
    host_vars.set_variable_manager(None)
    host_vars.set_inventory(inventory_manager)

    host_vars_copy

# Generated at 2022-06-23 15:07:36.203236
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert HostVarsVars({}, None).__len__() == 0
    assert HostVarsVars({'variable_1': 'value_1'}, None).__len__() == 1
    assert HostVarsVars({'variable_1': 'value_1', 'variable_2': 'value_2'}, None).__len__() == 2


# Generated at 2022-06-23 15:07:47.329366
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(loader=None, variable_manager=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    inventory_host = inventory.get_host('localhost')
    assert inventory_host is not None
    hostvars.set_host_facts(inventory_host, dict(foo='foo'))

    assert hostvars.get(inventory_host.name)['foo'] == 'foo'

    # test if facts are not persistent
    hostvars.set_nonpersistent_facts(inventory_host, dict(bar='bar'))

# Generated at 2022-06-23 15:07:59.988207
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Inventory, Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Setup inventory
    inventory = Inventory(host_list=[])
    inventory.get_hosts('testhost')
    inventory.set_variable('testhost', 'hostvar', 'hostvar')
    inventory.set_variable('testhost', 'hostvar2', 'hostvar2')
    inventory.set_variable('testhost', 'nested.foo1', 'bar')
    inventory.set_variable('testhost', 'nested.foo2', 'foobar')

    # Setup VariableManager
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.extra_vars = {'extravar': 'extravar'}


# Generated at 2022-06-23 15:08:07.136618
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(host_list=[])
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=None)

    myhost = inventory.get_host('myhost')
    hostvars.set_host_variable(host=myhost, varname='ansible_distribution', value='Fedora')
    hostvars.set_host_variable(host=myhost, varname='ansible_distribution_release', value='21')
    hostvars.set_host_variable(host=myhost, varname='ansible_distribution_version', value='21')

# Generated at 2022-06-23 15:08:18.725735
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    hosts_vars = {
        'host1': 'var1',
        'host2': 'var2',
        'host3': 'var3',
        'host4': 'var4',
    }

    loader = DataLoader()
    inventory_manager = InventoryManager(loader)
    variable_manager = VariableManager(loader=loader)

    hostvars = HostVars(inventory_manager, variable_manager, loader)
    hostvars._vars_cache = hosts_vars
    hostvars.set_host_variable('host1', 'ansible_foo', 'bar')


# Generated at 2022-06-23 15:08:28.553253
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    from ansible.playbook.play import Play

    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [],
        tasks = [],
        vars = {},
        post_tasks = [],
        handlers = []))

    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar(loader=None)
    variable_manager = VariableManager()
    variable_manager.set_inventory(play.hosts)
    variable_manager.set_playbook_basedir("./")

    from ansible.inventory.host import Host
    host = Host(name="localhost")

    hostvars = HostVars(play.hosts, variable_manager, templar)


# Generated at 2022-06-23 15:08:32.471240
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    hvv = HostVarsVars({"a": 1, "b": 2}, loader=None)
    assert len(hvv) == 2


# Generated at 2022-06-23 15:08:38.886198
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():

    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variables = {'foo': 'bar', 'baz': '{{foo}}'}

    hostvars_vars = HostVarsVars(variables, loader=loader)
    assert repr(hostvars_vars) == {'baz': 'bar', 'foo': 'bar'}

# Generated at 2022-06-23 15:08:49.118756
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Overall, this is a test of the behavior of HostVarsVars when it is used
    # in a dictionary that is multi-homed via __missing__.  This is not done
    # directly, but rather via the __contains__/__getitem__ methods in a
    # subclass of HostVarsVars.  The subclass is used for more easily
    # controlling the order of __contains__/__getitem__ calls.

    # set up inventory and variable manager for HostVars
    inventory = InventoryManager(loader=None, sources='localhost,')
    host = inventory.get_host(name='localhost')
    variable_manager = VariableManager(loader=None, host_list=[host])

# Generated at 2022-06-23 15:08:57.341132
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    inventory = InventoryManager(['localhost,'])
    play_context = PlayContext()

    hostvars = HostVars(inventory, play_context.variable_manager, play_context.loader)
    assert hostvars._inventory == inventory

    inventory = InventoryManager(['localhost,'])
    hostvars.set_inventory(inventory)
    assert hostvars._inventory == inventory
    assert play_context.variable_manager._hostvars == hostvars