

# Generated at 2022-06-23 14:59:03.533177
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    # Preparing test environment
    # FIXME: This is a temporary solution to run tests properly
    try:
        import ansible.plugins
    except ImportError:
        import os
        import sys
        test_dir = os.path.dirname(os.path.abspath(__file__))
        src_dir = os.path.normpath(os.path.join(test_dir, '..', '..', '..'))
        sys.path.append(src_dir)
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(None)
    inventory.host_list = ['host1', 'host2', 'host3']
    variable_manager = VariableManager(loader=None, inventory=inventory)

# Generated at 2022-06-23 14:59:06.915560
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # Prepare data required to call set_variable_manager
    # loader has to be set to avoid exception raised in __getstate__
    loader = None

    # Execute code to be tested
    hv = HostVars(None, None, loader)
    hv.set_variable_manager(None)

    # Assert results
    assert hv._variable_manager._hostvars is not None



# Generated at 2022-06-23 14:59:16.041620
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources="")
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    host = inventory.get_host("localhost")
    hostvars.set_nonpersistent_facts(host, {"key1": "value1"})
    hostvars.set_nonpersistent_facts(host, {"key2": "value2"})
    hostvars.set_nonpersistent_facts(host, {"key3": "value3"})

    assert (host.vars == {"key1": "value1", "key2": "value2", "key3": "value3"})

# Generated at 2022-06-23 14:59:24.199491
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="../../test/inventory")
    variable_manager.set_inventory(inventory)
    host = inventory.get_host('bogus_hostname')

    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ hostvars }}')))
         ]
    )


# Generated at 2022-06-23 14:59:29.351183
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def test_data():
        return {
            'foo': 'bar',
            'baz': ['a', 'b', 'c'],
            'text': AnsibleUnsafeText(u'abc'),
            'unicode': u'abc',
        }

    variables = test_data()
    var = HostVarsVars(variables, None)

    for key, value in variables.items():
        assert var[key] == value



# Generated at 2022-06-23 14:59:39.243140
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import os

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class FakeAnsibleModule:
        def __init__(self):
            self.params = {}

    module = FakeAnsibleModule()
    current_dir = os.path.dirname(os.path.realpath(__file__))
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=current_dir + '/hosts')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    foo = hostvars['testhost']
    print(foo)

# Generated at 2022-06-23 14:59:46.960423
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv)
    host_vars_view = HostVars(inventory=inv, variable_manager=variable_manager, loader=loader)
    assert host_vars_view.raw_get('localhost') == {'ansible_connection': 'local'}

# Generated at 2022-06-23 14:59:51.167830
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    hvv = HostVarsVars({'a': '{{b}}c'}, loader='loader')
    assert str(hvv.__getitem__('a')) == 'AnsibleUndefinedc'

# Generated at 2022-06-23 15:00:00.876048
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    class Inventory2:
        def __init__(self):
            self.hosts = []
            self.get_hosts = self.get_hosts_by_patterns

        def get_hosts_by_patterns(self, patterns, ignore_rest=True):
            return self.hosts

        def get_host(self, hostname):
            return hostname

    inventory = Inventory2()
    hostvars = HostVars(inventory, variable_manager, loader)

    class Host:
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-23 15:00:11.731303
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import combine_vars

    inventory = Group("all")
    loader = DataLoader()

    host1vars = {"foo1": "bar1", "hostvars": {"host1": {"foo2": "bar2"}}}
    host1 = Host("host1", inventory=inventory, variables=host1vars)
    host2vars = {"foo3": "bar3", "hostvars": {"host2": {"foo4": "bar4"}}}
    host2 = Host("host2", inventory=inventory, variables=host2vars)
    inventory.add_host(host1)


# Generated at 2022-06-23 15:00:19.832897
# Unit test for constructor of class HostVars
def test_HostVars():
    # testing __init__():
    # create an instance of HostVars with: a loader, an inventory, and a variable manager
    inventory = "Ansible Inventory"
    variable_manager = "Ansible Variable Manager"
    loader = "Ansible Loader"
    hostvars = HostVars(inventory, variable_manager, loader)

    # inventory and variable manager should be set
    assert hostvars._loader == loader
    assert hostvars._inventory == inventory
    assert hostvars._variable_manager == variable_manager


# Generated at 2022-06-23 15:00:26.572213
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    hostvars = HostVars(inventory, variable_manager, loader)

    if 'localhost' in hostvars:
        print("Test passed!")
    else:
        raise Exception("Test failed!")

if __name__ == '__main__':
    test_HostVars___contains__()

# Generated at 2022-06-23 15:00:32.789045
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVarsVars

    hostvars = { "a": 1, "b": 2 }
    unsafe_proxy = UnsafeProxy(hostvars)

    hvv = HostVarsVars(hostvars, None)
    assert list(iter(hvv)) == list(hostvars.keys())

    hvv = HostVarsVars(unsafe_proxy, None)
    assert list(iter(hvv)) == list(unsafe_proxy.keys())

# Generated at 2022-06-23 15:00:42.943220
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    inventory_data = {'_meta': {'hostvars': {'fake_host1': {'test_var': 'some_value'},
                                             'fake_host2': {'test_var': 'some_other_value'}}}}

    inventory = InventoryManager(loader=DataLoader(), sources=inventory_data)
    play_context = Play()
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())


# Generated at 2022-06-23 15:00:52.527133
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible import context
    from ansible.vars import VariableManager

    inventory = context.CLIARGS['inventory']
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, None)

    host = hostvars._find_host('localhost')
    assert host is not None

    fake_fact = dict(arg1='a1', arg2='a2')
    hostvars.set_nonpersistent_facts(host, fake_fact)
    host_vars = hostvars._variable_manager.get_vars(host)

    assert isinstance(host_vars, dict)
    assert host_vars['arg1'] == 'a1'
    assert host_vars['arg2'] == 'a2'

# Generated at 2022-06-23 15:00:55.128036
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert len(HostVarsVars({'a': 1}, None)) == 1
    assert len(HostVarsVars({'a': 1, 'b': 2, 'c': 3}, None)) == 3

# Generated at 2022-06-23 15:01:04.879200
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # create mock for loader, inventories and hosts
    loader = Mock()
    inventory = Mock()
    inventory.hosts = ['host1', 'host2']
    host_1 = Mock()
    host_1.get_vars.return_value = {'a': 1, 'b': 2, 'c': 3}
    host_2 = Mock()
    host_2.get_vars.return_value = {'a': 1, 'b': 2, 'c': 3}
    # create mock for variable manager
    variable_manager = Mock()
    variable_manager._loader = loader
    variable_manager._hostvars = HostVars(inventory, variable_manager, loader)
    # create HostVars
    hostvars = HostVars(inventory, variable_manager, loader)
    # test of __contains__ method


# Generated at 2022-06-23 15:01:13.216040
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create a mock inventory and set a variable on it
    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.set_host_variable('localhost', 'foo', 'bar')
    # Create an instance of HostVars from inventory
    hv = HostVars(inventory, variable_manager, loader=None)
    # Test __len__ method
    assert len(hv) == 1
    # Remove the host from inventory and test __len__ method again
    del inventory.hosts['localhost']
    assert len(hv) == 0

# Generated at 2022-06-23 15:01:13.836021
# Unit test for constructor of class HostVars
def test_HostVars():
    assert True

# Generated at 2022-06-23 15:01:15.573937
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    assert iter(HostVarsVars({'ansible': 'host'}, loader=None)) == iter(['ansible'])

# Generated at 2022-06-23 15:01:23.550905
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    class TestInventory(object):
        def __init__(self):
            self.hosts = ['host1', 'host2']
        def get_host(self, name):
            if name in self.hosts:
                return name
            return None

    class TestVariableManager(object):
        def __init__(self):
            self._vars = dict(host1=dict(k1='v1', k2='v2'), host2=dict(k1='v1', k2='v2'))
        def get_vars(self, host=None, include_hostvars=False):
            if host is None:
                return {}

# Generated at 2022-06-23 15:01:29.271788
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():

    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    from units.mock.loader import DictDataLoader

    # Patch Ansible loader
    loader = DictDataLoader({})
    loader.set_basedir('.')
    loader._vault = None

    # Define an inventory with two hosts with different vars
    target_host_first = 'test1.example.org'
    target_host_second = 'test2.example.org'
    inventory = Inventory(loader, vault_password='None')
    host1 = inventory.get_host(target_host_first)
    host1.set_variable('version', '1.0')
    host2 = inventory.get_host(target_host_second)

# Generated at 2022-06-23 15:01:38.547875
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    fake_host = Host(name='fake_host')
    variable_manager.set_host_variable(fake_host, 'fake_var', 'fake_value')
    variable_manager.set_host_variable(fake_host, 'dict_var', dict(a=1, b=2))
    assert variable_manager.get_host_vars(fake_host)['fake_var'] == 'fake_value'
    assert variable_manager.get_host_vars(fake_host)['dict_var'] == dict(a=1, b=2)

# Generated at 2022-06-23 15:01:42.395420
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    vars_ = {'foo': 'bar', 'x': '{{ y }}'}
    loader = DictDataLoader({})
    hostvars = HostVars({}, None, loader)
    hostvarsvars = HostVarsVars(vars_, loader)
    assert repr(hostvarsvars) == repr(vars_)

# Generated at 2022-06-23 15:01:47.118129
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = None
    loader = None
    variabes_manager = None

    hostvars = HostVars(inventory, variabes_manager, loader)

    # Checking with None as host
    res = hostvars.raw_get(None)
    assert res == {}

# Generated at 2022-06-23 15:01:51.731123
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {'a': 'A', 'b': 'B', 'c': 'C'}
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)

    assert sorted(list(hostvarsvars)) == ['a', 'b', 'c']



# Generated at 2022-06-23 15:02:00.829506
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import os
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')

    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory=inventory, loader=None, variable_manager=variable_manager)

    host_name = 'localhost'

    host = hostvars._find_host(host_name)
    assert host is not None

    facts = {
        'a': 1,
    }

    hostvars.set_host_facts(host, facts)

    localhost_vars = hostvars.raw_get(host_name)

    assert localhost_vars['ansible_facts'] == {'a': 1}



# Generated at 2022-06-23 15:02:08.540150
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    import json

    # Fill the hosts of the inventory with data
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    inventory.hosts.append(
        'localhost'
    )
    hostvars = HostVars(inventory=inventory,
                        variable_manager=VariableManager(loader=DataLoader()),
                        loader=DataLoader())
    hostvars.set_inventory(inventory)

    # Assure that `set_inventory` has been changed the hostvars
    assert len(hostvars.keys()) > 0

# Generated at 2022-06-23 15:02:17.438813
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.utils.vars import combine_vars

    # Create some variables to put into vars_cache
    vars_count = 2
    vars_dict = dict(('var{0}'.format(index), 'value{0}'.format(index)) for index in range(vars_count))

    # Create an inventory and two hosts there
    inventory = Inventory(loader=lambda: None)
    host1 = 'host1'
    host2 = 'host2'
    host1_vars = combine_vars(vars_dict)
    host2_vars = combine_vars(vars_dict)
    inventory.add_host(host1)

# Generated at 2022-06-23 15:02:24.870998
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    class VariableManager:
        def __init__(self):
            self._hostvars = self._loader = None

    loader = object()
    inventory = object()

    vars_cache = dict(a=1, b=2, c=3)
    host = object()

    vm = VariableManager()
    hv = HostVars(inventory, vm, loader)
    hv.set_variable_manager(vm)
    hv.set_inventory(inventory)
    hv._variable_manager.set_nonpersistent_facts(host, vars_cache)
    hv._inventory.hosts = [host, ]

    hv_ = hv.__getstate__()
    assert hv_ == dict(_inventory=inventory, _loader=loader, _variable_manager=vm)


# Generated at 2022-06-23 15:02:30.921237
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    inventory = mock.MagicMock()

    host = Host(name='test')

    inventory.get_host.return_value = host

    loader = mock.MagicMock()

    vars_manager = VariableManager()
    vars_manager.add_group_vars(Group(name='all'), {'key': 'group_value'})
    vars_manager.add_host_vars(host, {'key': 'host_value'})

    hostvars = HostVars(inventory, vars_manager, loader)

    hostvars.set_nonpersistent_facts(host, {'key': 'nonpersistent_value'})


# Generated at 2022-06-23 15:02:35.158174
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    data = {
        'var1': 'string',
        'var2': 123,
        'var3': [1, 2, 3],
        'var4': {'key': 'value'}
    }

    assert list(HostVarsVars(data, None)) == ['var1', 'var2', 'var3', 'var4']

# Generated at 2022-06-23 15:02:43.563848
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # setup
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory=inventory, loader=DataLoader(), variable_manager=variable_manager)

    host1 = inventory.get_host('localhost')

    # test
    hostvars[host1] == UnsafeProxy({'hostvars': {}})

# Generated at 2022-06-23 15:02:52.978714
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import pytest

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=loader)

    new_variable_manager = VariableManager()

    # HostVars should be assigned in old variable_manager and
    # new variable_manager
    hostvars.set_variable_manager(new_variable_manager)
    assert variable_manager._hostvars is hostvars
    assert new_variable_manager._hostvars is hostvars

    # When assigning new variable_manager, hostvars should be
    # initialized if not assigned before

# Generated at 2022-06-23 15:02:57.712857
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{foo}}')))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    hostvars = HostV

# Generated at 2022-06-23 15:03:07.406516
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    import ansible.playbook.play
    import ansible.plugins.loader
    import ansible.template.vars
    import copy

    var_manager = ansible.template.vars.VariableManager()
    loader = ansible.plugins.loader.PluginLoader()
    hostvars = HostVars(play=ansible.playbook.play.Play(), variable_manager=var_manager, loader=loader)
    hostvars.set_host_variable(host=None, varname='foo', value='bar')

    variables = hostvars[None]
    assert 'foo' in variables



# Generated at 2022-06-23 15:03:16.251314
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    from ansible.module_utils.facts import FactCache
    from ansible import constants as C
    from ansible.vars import VariableManager

    # create a fact cache object
    fact_cache = FactCache()

    # create a variable manager object
    variable_manager = VariableManager(loader=None, inventory=None)

    # create a hostvars object
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=None)

    # create a host object
    host =  type('',(object,),{})()
    # set some attributes for the host object
    host.name = 'testhost'

# Generated at 2022-06-23 15:03:19.496991
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():

    from ansible.template import Templar

    hvv = HostVarsVars(dict(a=1, b=2), Templar(dict()))
    assert len(hvv) == 2



# Generated at 2022-06-23 15:03:29.302454
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory import Inventory
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    inventory = Inventory(loader=vars_loader, host_list=['localhost'])
    variable_manager = VariableManager(loader=vars_loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=vars_loader)

    host = inventory.get_host('localhost')
    facts = {'test': 'test'}
    hostvars.set_host_facts(host, facts)

    host_facts = variable_manager.get_vars(host=host).get('ansible_local')
    assert host_facts is not None

# Generated at 2022-06-23 15:03:35.990626
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert 'inventory_dir' in hostvars.raw_get('localhost')

# Generated at 2022-06-23 15:03:44.100131
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    """
    Test for method __iter__ of class HostVarsVars
    """

    class TempType(Mapping):

        def __getitem__(self, var):
            return self.hostvars[var]

        def __contains__(self, var):
            return (var in self.hostvars)

        def __iter__(self):
            return self.hostvars.keys()

        def __len__(self):
            return len(self.hostvars.keys())

        def __repr__(self):
            return repr(self.hostvars)

    import tempfile
    filename = tempfile.mktemp()
    with open(filename, 'w') as fd:
        fd.write(u"[local]\nlocalhost ansible_connection=local\n")

# Generated at 2022-06-23 15:03:54.302979
# Unit test for method __getitem__ of class HostVarsVars

# Generated at 2022-06-23 15:04:03.310682
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import os
    import shutil

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory_dir = os.path.join(os.path.dirname(__file__), 'inventory')
    inventory_file = os.path.join(inventory_dir, 'hosts')

    shutil.rmtree(inventory_dir, ignore_errors=True)
    os.makedirs(inventory_dir)

    with open(inventory_file, 'w') as file:
        file.write("""
[test]
localhost

[test:vars]
hostvars_test: hello
""")

    inventory = InventoryManager(loader=None, sources=inventory_file)

    variable_manager = VariableManager(loader=None, inventory=inventory)

    host = inventory.get_

# Generated at 2022-06-23 15:04:13.071469
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import copy
    import ansible.inventory.host
    import ansible.template
    import ansible.vars.hostvars
    import ansible.vars.unsafe_proxy

    my_host_name = 'my_host_name'
    my_host = ansible.inventory.host.Host(my_host_name)
    my_host_vars = ansible.template.Templar(loader=None, variables=dict())
    my_host_vars.set_available_variables({'inventory_hostname': my_host_name})
    my_host_vars.set_available_variables({'inventory_hostname_short': my_host_name})

# Generated at 2022-06-23 15:04:19.954100
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = DictDataLoader({'foo': 'bar'})
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars['localhost'] == {'foo': 'bar'}



# Generated at 2022-06-23 15:04:26.681157
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    import os
    import sys
    import types

    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    vm = VariableManager()
    hv = HostVars(Inventory(loader=None, variable_manager=vm), variable_manager=vm, loader=None)

    # save original values
    orig_vm_loader = vm._loader
    orig_vm_hostvars = vm._hostvars
    orig_hv_variable_manager = hv._variable_manager
    orig_hv_loader = hv._loader

    # create fake methods
    def_name = sys._getframe().f_code.co_name
    vm_setstate = types.MethodType(lambda *args: None, vm, type(vm))

# Generated at 2022-06-23 15:04:37.543490
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # Mock hostvars (class HostVars)
    class HostVarsMock(Mapping):
        """
        Mocked class HostVars with only implemented method __contains__
        to test method HostVars.__contains__
        """
        def __contains__(self, host_name):
            return True
    # Create hostvars mock
    hostvars = HostVarsMock()
    # Mock host
    class HostMock:
        def __init__(self, name):
            self.name = name
    # Create host mock
    host = HostMock('ansible.domain.com')
    # Mock variable_manager (class VariableManager)

# Generated at 2022-06-23 15:04:44.253299
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import copy
    import pytest

    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import to_unsafe_dict, to_unsafe_var

    inventory = FakeInventory()
    loader = FakeLoader()
    variable_manager = VariableManager(loader=loader)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_copy = copy.deepcopy(hostvars)

    assert set(hostvars) == set(hostvars_copy)
    assert len(hostvars) == 3



# Generated at 2022-06-23 15:04:53.389713
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variables = {'a': 1, 'b': 2, 'c': 3}
    hostvars_vars = HostVarsVars(variables, loader)

    assert len(hostvars_vars) == 3

    # After HostVarsVars class is initialized, variables can not be changed.
    # So the len of HostVarsVars remains the same.
    variables['d'] = 4
    assert len(hostvars_vars) == 3


# Generated at 2022-06-23 15:05:00.072613
# Unit test for constructor of class HostVars
def test_HostVars():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Get a loader and variable manager for testing
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    # Set up the inventory manager with some data
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

    # Check that we can create a HostVars object
    HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-23 15:05:07.126918
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), host_list=inventory.get_hosts())

    # create groups
    new_group = inventory.add_group('test_group')
    new_host = inventory.add_host(host='test_host', group=new_group)
    new_vars = {'test_var': 'test_value'}
    new_host.set_variable('test_var', 'test_value')

    hostvars = HostVars(inventory, variable_manager, DataLoader())

    # test values
    assert hostvars.raw_get

# Generated at 2022-06-23 15:05:18.073028
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    class FakeHost:
        def __init__(self, host_name, vars):
            self.name = host_name
            self.vars = vars

    class FakeVariableManager:
        def __init__(self):
            self.host_grandparent = FakeHost('grandparent', {})
            self.host_parent = FakeHost('parent', {})
            self.host_child = FakeHost('child', {})
            self.hosts = {'grandparent': self.host_grandparent,
                          'parent': self.host_parent,
                          'child': self.host_child}

        def set_host_variable(self, host, varname, value):
            self.hosts[host.name].vars[varname] = value


# Generated at 2022-06-23 15:05:25.739332
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from collections import namedtuple
    from copy import deepcopy
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    # Create fake variables' dict
    fake_vars = {}
    # Create fake loader
    fake_loader = DataLoader()
    # Create fake variable manager
    fake_variable_manager = VariableManager()
    # Create fake inventory
    fake_inventory = namedtuple('Inventory', ['_loader', '_variable_manager'])
    # Create fake play
    fake_play = Play()
    # Create fake task
    fake_task = Task()
    # Create fake host

# Generated at 2022-06-23 15:05:29.900541
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    variables = dict(foo='bar')
    loader = AnsibleLoader()
    hostvars = HostVarsVars(variables, loader)

    assert 'foo' in hostvars
    assert 'bar' not in hostvars

# Generated at 2022-06-23 15:05:41.227331
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy

    class Inventory:
        def __init__(self):
            self.hosts = ['localhost']

        def get_host(self, host_name):
            return host_name

    inventory = Inventory()
    hostvars = HostVars(inventory, None, None)

    dict_with_hostvars = {}
    dict_with_hostvars['hostvars'] = hostvars
    dict_with_hostvars['hostvars_dict'] = dict(hostvars)

    dict_copy = copy.deepcopy(dict_with_hostvars)

    assert dict_with_hostvars == dict_copy

    # Since hostvars are not copied, they will be still pointing to the
    # same object

# Generated at 2022-06-23 15:05:51.160106
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():

    class Inventory(object):
        def __init__(self, hosts=None):
            self._hosts = {}
            self.get_host = self._hosts.get
            self.hosts = hosts or []
        def add_host(self, host):
            if not isinstance(host, Host):
                raise Exception("Unexpected host type")
            self._hosts[host.name] = host
        def set_hosts(self, hosts):
            for host in self._hosts.keys():
                self._hosts[host] = None
                del self._hosts[host]
            for host in hosts:
                self._hosts[host.name] = host
    class Host(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-23 15:05:53.086107
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    assert repr(HostVars(None, None, None)) == {}



# Generated at 2022-06-23 15:06:03.657035
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    ## Test __repr__ with dynamic variables
    # Prepare an example
    example_vars = {
        'ansible_host': 'host-host-host',
        'inventory_hostname': 'host-host-host',
        'inventory_hostname_short': 'host-host-host'
    }
    # Prepare a HostVarsVars instance
    vars = HostVarsVars(example_vars,FakeLoader())
    # Test __repr__
    assert vars.__repr__() == "{\'ansible_host\': \'host-host-host\', \'inventory_hostname\': \'host-host-host\', \'inventory_hostname_short\': \'host-host-host\'}"
    # Test __repr__ with undefined variables
    # Note: fail_on_undefined=True & static

# Generated at 2022-06-23 15:06:09.372469
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():

    # Try to get lenght of empty dictionary
    test_obj = HostVarsVars({}, None)
    assert len(test_obj) == 0

    # Try to get lenght of dictionary with one element
    test_obj = HostVarsVars({'foo': 'bar'}, None)
    assert len(test_obj) == 1


# Generated at 2022-06-23 15:06:12.096508
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    inv = Inventory("")
    loader = DictDataLoader({"vars": {"boo": "bar"}})
    vm = VariableManager(loader=loader)
    vm.extra_vars = {"baa": "zee"}
    hv = HostVars(inv, vm, loader)

    assert hv.__iter__() == iter(())

# Generated at 2022-06-23 15:06:21.442867
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = dict(
        hosts=[
            dict(name='foo.example.org', variables=dict(a='b')),
            dict(name='localhost', variables=dict(a='c')),
        ],
        groups=[
            dict(name='all'),
            dict(name='local', hosts=['localhost']),
        ],
    )
    hv = HostVars(inventory, None, None)
    assert repr(hv) == "{'foo.example.org': {u'a': u'b'}, 'localhost': {u'a': u'c'}}"


# Unit tests for methods __getitem__ and __setitem__
# of class HostVars

# Generated at 2022-06-23 15:06:32.452688
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    class Host:
        name = 'localhost'
        vars = {}

    host = Host()
    hostvars.set_host_variable(host=host, varname='foo', value='bar')

    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-23 15:06:40.785851
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import jinja2
    loader = jinja2.DictLoader({'test': "{{ var }} {{ var }}"})

    v = {'var': 1, 'test': '{{ var }}'}
    hostvars = HostVarsVars(v, loader)
    res = hostvars.__getitem__('test')
    assert res == "1 1"
    assert v['test'] == "{{ var }}"

    # Test for jinja2 undefined behavior
    v = {'var': 1}
    hostvars = HostVarsVars(v, loader)


# Generated at 2022-06-23 15:06:41.672242
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
  return True



# Generated at 2022-06-23 15:06:47.291309
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    # Note that HostVars is immutable and __deepcopy__ is not called by deepcopy().
    # This test ensures that __deepcopy__ does not raise any exception.
    from copy import deepcopy
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    i = Inventory("foobar")
    v = VariableManager()
    h = HostVars(i, v, loader=None)
    deepcopy(h)


# Generated at 2022-06-23 15:06:52.548594
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars = HostVars({}, None, None)
    hostvars['foo'] = {'bar': {'baz': 'qux'}}
    hostvars_vars = hostvars['foo']
    assert sorted(list(hostvars_vars)) == sorted(['bar'])



# Generated at 2022-06-23 15:07:00.069293
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader = None
    # Empty variables, empty output
    variables = {}
    hvv = HostVarsVars(variables, loader)
    assert repr(hvv) == "{}"
    # No template-able variables, same variables
    variables = {'hosts': {'foo': 'bar'}}
    hvv = HostVarsVars(variables, loader)
    assert repr(hvv) == repr(variables)
    # With template-able variables, all variables are replaced.
    variables = {'hosts': {'foo': '{{ bar }}'}}
    hvv = HostVarsVars(variables, loader)
    assert repr(hvv) == "{'hosts': {'foo': u''}}"

# Generated at 2022-06-23 15:07:03.589722
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    hostvars = HostVars()
    if len(hostvars) != 0:
        raise AssertionError('Method __len__ of class HostVars does not work correctly')

# Generated at 2022-06-23 15:07:05.366480
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    assert len(HostVars(None, None, None)) == 0



# Generated at 2022-06-23 15:07:09.666073
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    # Construct HostVarsVars using dict
    hostvarsvars = HostVarsVars({'foo': '{{ bar }}'}, None)
    assert isinstance(hostvarsvars, HostVarsVars)
    assert isinstance(hostvarsvars, Mapping)


# Generated at 2022-06-23 15:07:13.130605
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    variables = {
        'foo': 'bar'
    }

    hostvarsvars = HostVarsVars(variables, None)
    assert repr(hostvarsvars) == repr(variables)

# Generated at 2022-06-23 15:07:19.076350
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources="localhost,")
    variable_manager = VariableManager(loader=loader, inventory=inv)

    hv = HostVars(inventory=inv, variable_manager=variable_manager, loader=loader)
    assert len(hv) == 1



# Generated at 2022-06-23 15:07:30.772866
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    play = Play().load({}, variable_manager=inventory.variable_manager, loader=loader)
    hostvars = HostVars(inventory, play.variable_manager, loader)
    assert len(hostvars) == 0

    inventory.add_host('localhost')
    assert len(hostvars) == 1

    inventory.add_host('foo')
    assert hostvars.get('foo') is None
    assert len(hostvars) == 2


# Generated at 2022-06-23 15:07:39.774477
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    v1 = { 'foo': 'bar', 'deep': { 'nested': { 'var': 'baz' } } }
    h = HostVarsVars(v1, None)
    assert v1['foo'] == 'bar'
    assert v1['deep']['nested']['var'] == 'baz'
    assert h['foo'] == 'bar'
    assert h['deep']['nested']['var'] == 'baz'
    assert isinstance(h['deep'], UnsafeProxy)
    assert isinstance(h['deep']['nested'], UnsafeProxy)
    assert isinstance(h['deep']['nested']['var'], UnsafeProxy)

    # Issue 15010: HostVarsVars

# Generated at 2022-06-23 15:07:49.481702
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import ansible.playbook.play
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.constants as C

    inventory = ansible.inventory.manager.InventoryManager(loader=None, sources=C.DEFAULT_HOST_LIST)

    hostvars = HostVars(inventory=inventory, variable_manager=None, loader=None)

    play_context = ansible.playbook.play.PlayContext()
    play_context.remote_addr = 'unittest_remote_addr'
    play_context.remote_user = 'unittest_remote_user'
    play_context.connection = 'unittest_connection'

    vars_manager = ansible.vars.manager.VariableManager(loader=None, inventory=inventory)


# Generated at 2022-06-23 15:08:01.110217
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list="localhost")
    vars_cache = HostVars(inventory=inventory, variable_manager=VariableManager(), loader=loader)

    # Test for a variable which does not belong to the host
    variable_name = "test_variable"
    assert variable_name not in vars_cache["localhost"]

    # Add variable to the host
    vars_cache.set_host_variable(vars_cache._find_host("localhost"), variable_name, "test_value")
    assert variable_name in vars_cache["localhost"]

# Generated at 2022-06-23 15:08:10.909923
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    loader = inventory_loader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=["non-existent-host"])
    variable_manager = inventory.get_variable_manager()

    # Test if method __repr__ behaves correctly if a variable is not defined.
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_vars = hostvars["non-existent-host"]
    assert repr(hostvars_vars) == "{}"

    # Test if method __repr__ behaves correctly if a variable is defined.

# Generated at 2022-06-23 15:08:15.701922
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = dict(foo='bar')
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)

    assert hostvarsvars['foo'] == variables['foo']  # pass
    assert hostvarsvars['bar'] == variables['bar']  # fail

# Generated at 2022-06-23 15:08:25.447045
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create an object representing a host
    host = InventoryManager(loader=DataLoader()).get_host("localhost")

    # Create an object representing variables of the host
    variables = VariableManager(loader=DataLoader()).get_vars(host=host)

    # Test __iter__ method of the HostVarsVars class
    hostvars_vars = HostVarsVars(variables, loader=DataLoader())

    # Test that __iter__ method works as expected
    assert sorted(hostvars_vars) == sorted(hostvars_vars.__iter__())

# Generated at 2022-06-23 15:08:35.357366
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    vars_to_template = {
        'var1': '{{ value1 }}',
        'var2': '{{ value2 }}',
        'var3': '{{ value3 }}',
    }
    variables = {
        'value1': 'some_value',
        'value2': 'some_other_value',
    }
    hostvars_vars = HostVarsVars(vars_to_template, loader=None)
    data = dict((key, hostvars_vars[key]) for key in hostvars_vars)
    assert data == {
        'var1': 'some_value',
        'var2': 'some_other_value',
        'var3': AnsibleUndefined(name="hostvars['value3']"),
    }

# Generated at 2022-06-23 15:08:47.130546
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    class Inventory(object):
        def __init__(self, hosts):
            self._hosts = hosts

        def get_host(self, name):
            if name in self._hosts:
                return self
            return None

        def run(self, connection, module_name, module_args, task_vars, tmp=None):
            return self._hosts[self._hosts.keys()[0]]

    inventory = Inventory({'host1': {}})
    loader = 'loader'

    variable_manager = 'variable_manager'
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars._variable_manager = None
    assert hostvars._variable_manager is None

    hostvars.set_variable_manager(variable_manager)
    assert hostvars._variable_manager == variable_

# Generated at 2022-06-23 15:08:58.914830
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins import vars_loader
    from ansible.vars.manager import VariableManager

    class VarsModule(vars_loader.VarsModule):
        def get_vars(self, loader, path, entities, cache=True):
            results = {}
            for entity in entities:
                results[entity.name] = {'foo': 'bar'}
            return results

    inventory = InventoryManager(loader=None, sources=[])
    inventory.set_variable_manager(VariableManager(loader=None, inventory=inventory))
    host = inventory.get_host("localhost")

    # Add VarsModule to vars_loader
    vars_loader.add('vars_plugin', VarsModule)
    # Create instance of HostVars with VarsModule as loader
   