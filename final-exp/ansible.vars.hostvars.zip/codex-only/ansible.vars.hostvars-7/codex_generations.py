

# Generated at 2022-06-23 14:59:03.778221
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    class MockLoader(MutableMapping):
        def __init__(self, hostvars):
            self.hostvars = hostvars

        def __getitem__(self, key):
            return self.hostvars

        def __setitem__(self, key, value):
            self.hostvars = value

        def __delitem__(self, key):
            del self.hostvars

        def __iter__(self):
            return iter(self.hostvars)

        def __len__(self):
            return len(self.hostvars)

    class MockInventoryHost:
        def __init__(self, hostvars):
            self.vars = hostvars


# Generated at 2022-06-23 14:59:08.964930
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    import pickle

    # Skip test if AnsibleUndefined is not present
    try:
        AnsibleUndefined
    except NameError:
        raise unittest.SkipTest()

    # Skip test if AnsibleUndefined is not a class
    if not inspect.isclass(AnsibleUndefined):
        raise unittest.SkipTest()

    # Skip test if AnsibleUndefined does not support dict protocol
    # (both __setitem__ and __getitem__ methods)
    if not isinstance(AnsibleUndefined(), Mapping):
        raise unittest.SkipTest()

    # Skip test if AnsibleUndefined does not support pickle protocol
    if not hasattr(AnsibleUndefined(), "__getstate__"):
        raise unittest.SkipTest()

# Generated at 2022-06-23 14:59:17.781117
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.compat.tests import unittest
    from ansible.inventory.host import Host

    class TestVariableManager(object):
        _hostvars = None

        def get_vars(self, host, include_hostvars=False):
            return {'hostvars': 1}

        def set_host_variable(self, host, varname, value):
            return {}

        def set_nonpersistent_facts(self, host, facts):
            return {}

        def set_host_facts(self, host, facts):
            return {}

    class TestInventory(object):
        hosts = [Host('example'), Host('invalid')]

        def get_host(self, name):
            if name == 'invalid':
                return None
            return Host(name)


# Generated at 2022-06-23 14:59:29.019754
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create arguments for class HostVars
    inventory = None
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create instance of class HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars._variable_manager is variable_manager
    assert variable_manager._hostvars is hostvars

    # Create new instance of VariableManager
    variable_manager = VariableManager()

    # Assign new instance to hostvars._variable_manager
    hostvars.set_variable_manager(variable_manager)

    assert hostvars._variable_manager is variable_manager
    assert variable_manager._hostvars is hostvars


# Generated at 2022-06-23 14:59:38.962954
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import copy

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class AnsibleInventory():
        def __init__(self, options, loader):
            self._variables = {}

        def get_host(self, host):
            if host in self._variables:
                return AnsibleHost(host, self)
            else:
                return None

        def set_host_variable(self, host, varname, value):
            if host not in self._variables:
                return None

            self._variables[host][varname] = value

        def set_host_facts(self, host, facts):
            if host not in self._variables:
                return None

            self._variables[host]['ansible_facts'] = facts


# Generated at 2022-06-23 14:59:47.977084
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    inventory._hosts_cache = [Host(name="host1", port=None), Host(name="host2", port=None)]
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)
    assert set(hostvars) == set(inventory.hosts)

    for host in hostvars:
        assert host in inventory.hosts
        assert host in hostvars

# Generated at 2022-06-23 14:59:58.543137
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    """
    The method __contains__ returns 'True' when a host name is in the inventory
    and 'False' when a host name is not in the inventory.
    """
    import copy
    import pickle

    from ansible.inventory.manager import InventoryManager

    # Create a HostVars object and make sure 'localhost' is in the cache.
    inventory = InventoryManager(loader=None, sources=None)
    hostvars = HostVars(inventory=inventory, variable_manager=None, loader=None)
    assert 'localhost' in hostvars
    assert 'unknown' not in hostvars

    # Create a copy of the HostVars object and make sure 'localhost' is in
    # the cache of the copy as well.
    hostvars_copy = copy.copy(hostvars)
    assert 'localhost' in hostvars

# Generated at 2022-06-23 15:00:10.017316
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        'roles/foo/vars/bar.yml': 'foo: "bar"',
        'roles/foo/vars/baz.yml': 'foo: "baz"',
    })

    inventory = wrap_in_list(
        [
            {'name': 'localhost'},
            {'name': 'otherhost', 'vars': {'foo': 'baz'}},
        ]
    )

    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(inventory)

   

# Generated at 2022-06-23 15:00:19.349385
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Create an empty inventory
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(None, None)

    # Create a VariableManager without setting a loader
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()

    # Create the HostVars class
    from ansible.vars.host_vars import HostVars
    hostvars = HostVars(inventory, variable_manager, None)

    # Set facts for localhost
    facts = {'foo': 'bar'}
    host = inventory.get_host(host_name='localhost')

    # Set the localhost facts
    hostvars.set_nonpersistent_facts(host, facts)

    # Check if the host facts were saved
    assert hostvars.raw_get('localhost')['foo'] == 'bar'



# Generated at 2022-06-23 15:00:27.775077
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert "localhost" in hostvars

    hostvars_localhost = hostvars['localhost']
    hostvars_not_exist = hostvars['test_host']

    assert not isinstance(hostvars_localhost, AnsibleUndefined)
    assert isinstance(hostvars_not_exist, AnsibleUndefined)


# Generated at 2022-06-23 15:00:35.332506
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import json
    from ansible.parsing.dataloader import DataLoader

    # test data
    _vars = {}
    _vars["hosts"] = "localhost"
    _vars["log_path"] = "/var/log/ansible.log"

    # Loader setup
    loader = DataLoader()

    # Create instance
    hostvars_vars = HostVarsVars(_vars, loader)

    # Test __getitem__
    print(hostvars_vars["hosts"])
    print(hostvars_vars["log_path"])

    # Test __contains__
    print("hosts" in hostvars_vars)
    print("log_path" in hostvars_vars)

    # Test __iter__

# Generated at 2022-06-23 15:00:44.023271
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    Inventory = None
    VariableManger = None
    Loader = None
    def raw_get(self, host_name):
        if Inventory is not None:
            # dummy implementation of get_host
            if host_name in self._inventory.hosts:
                return None

        # load real implementation of raw_get
        from ansible.playbook.play_context import HostVars
        return HostVars.raw_get(self, host_name)

    HostVars.raw_get = raw_get

    from ansible.playbook.play_context import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory import Inventory
    from ansible.constants import mk_

# Generated at 2022-06-23 15:00:51.903335
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.add_host('localhost')
    hostvars.set_host_facts('localhost', {'fact1': 1})

    assert 'localhost' in hostvars
    assert 'non_existent_host' not in hostvars

# Generated at 2022-06-23 15:00:59.092466
# Unit test for constructor of class HostVars
def test_HostVars():
    import jinja2
    import sys

    try:
        from ansible.inventory.manager import InventoryManager
        from ansible.vars import VariableManager
    except ImportError:
        # ansible < 2.0
        from ansible import inventory
        from ansible import variables as VariableManager

    vars_manager = VariableManager()
    loader = jinja2.PackageLoader('ansible', 'templates')

    inventory_manager = InventoryManager(loader=loader, sources='localhost,')

    # testing __getstate__ and __setstate__
    host_vars_instance = HostVars(inventory_manager, vars_manager, loader)
    state = host_vars_instance.__getstate__()
    host_vars_instance2 = HostVars(None, None, None)

# Generated at 2022-06-23 15:01:07.106663
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def _populate_host_vars(host_vars):
        host_vars.set_host_facts('test_host', {'test_fact': 'test'})

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    var_mgr = VariableManager(loader=loader, inventory=inventory)

    host_vars = var_mgr.get_vars(host=inventory.get_host('test_host'))
    _populate_host_vars(host_vars)

# Generated at 2022-06-23 15:01:15.106080
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    inventory = InventoryManager(loader, variable_manager=VariableManager())
    variable_manager = inventory.get_variable_manager()
    hostvars = HostVars(inventory, variable_manager, loader)

    test_hostname = 'test01'
    host = inventory.get_host(test_hostname)

    hostvars.set_host_facts(host, dict(a=dict(b=123)))

    vars = hostvars.raw_get(test_hostname)
    assert vars['a']['b'] == 123

# Generated at 2022-06-23 15:01:19.082277
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    assert len(HostVars({})) == 0
    assert len(HostVars({'host_1': {}})) == 1
    assert len(HostVars({'host_1': {}, 'host_2': {}})) == 2

# Generated at 2022-06-23 15:01:27.150847
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # test_1
    # empty host vars
    hv = HostVars(inventory = None, variable_manager = None, loader = None)
    assert hv.__len__() == 0

    # test_2
    # host vars with one host
    hv = HostVars({'localhost': {}}, None, None)
    assert hv.__len__() == 1

    # test_3
    # host vars with two hosts
    hv = HostVars({'localhost': {}, 'otherhost': {}}, None, None)
    assert hv.__len__() == 2


# Generated at 2022-06-23 15:01:34.764090
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager("")
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, None)

    host = inventory.get_host("host1")
    hostvars.set_host_variable(host, "foo", "bar")

    data = hostvars.raw_get("host1")
    assert data == {"foo": "bar"}

    data = hostvars["host1"]
    assert data == {"foo": "bar"}

# Generated at 2022-06-23 15:01:43.283049
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy

    # Create a deepcopy of vars_cache, and make sure all HostVars
    # instances are same in the original one and in the copy

# Generated at 2022-06-23 15:01:54.930628
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    host = Host('testhost')
    host.set_variable('ansible_nonpersistent_test', 0)
    host.set_variable('ansible_persistent_test', 0)

    group = Group('testgroup')
    group.add_host(host)

    inventory = InventoryManager([group])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # create playbook
    pb = Playbook.load('', variable_manager=variable_manager, loader=None)

# Generated at 2022-06-23 15:02:05.211006
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

    variables = {'hostvars': {'testhost': {'foo': 'bar'}}}
    variable_manager = VariableManager(loader=loader, inventory=inventory, variables=variables)

    hostvars = HostVars(inventory=inventory,
                        variable_manager=variable_manager,
                        loader=loader)

    # Set hostvars of localhost manually
    localhost = Host(name='localhost',
                     port=None,
                     variables={'ansible_connection': 'local'})
    hostvars.set

# Generated at 2022-06-23 15:02:16.156970
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    class FakeVM(object):
        def __init__(self):
            pass
        def __setstate__(self, state):
            pass
    class FakeInventory(object):
        def __init__(self):
            pass
        def get_host(self, host_name):
            if host_name == 'foo':
                return 'foo'
        def set_variable_manager(self, variable_manager):
            self.variable_manager = variable_manager
    class FakeLoader(object):
        pass


    hostvars = HostVars(FakeInventory(), FakeVM(), FakeLoader())

    vm = FakeVM()
    vm._hostvars = None
    vm._loader = None
    hostvars.set_variable_manager(vm)

    assert vm._hostvars == hostvars
    assert vm._loader == Fake

# Generated at 2022-06-23 15:02:25.151459
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # Create object VariableManager
    var_man = VariableManager()

    # Create object Host and add it to inventory
    host = Host(name='test')
    inventory = Inventory()
    inventory.add_host(host)

    # Create object HostVars
    hostvars = HostVars(inventory, var_man, None)

    # Set value of hostfacts
    # This value should be shared across all playbooks
    hostfacts = dict(ansible_distribution='Fedora', ansible_distribution_version='21')
    hostvars.set_host_facts(host, hostfacts)

    # Get value of hostfacts from var_man
    hostfacts_var_man = var_man.get_vars(host=host)['ansible_facts']

    assert hostfacts == hostfacts_var_man

# Generated at 2022-06-23 15:02:31.122568
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins import vars_loader, filter_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Collect a set of hosts to be used in tests.
    hosts = []
    hosts.append(Host("localhost", dict(foo='bar')))
    hosts.append(Host("127.0.0.1", dict(bar='baz')))

    # Setup inventory.
    inventory = InventoryManager(loader=None, sources='localhost, 127.0.0.1')
    for host in hosts:
        inventory.add_host(host)

    # Setup variable manager.

# Generated at 2022-06-23 15:02:35.927185
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    inventory = None
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variables = {'foo': 'bar'}
    hostvarsvars = HostVarsVars(variables, loader)
    assert hostvarsvars['foo'] == 'bar'

# Generated at 2022-06-23 15:02:44.504868
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import Distribution

    class Host:
        def __init__(self, name):
            self.name = name

    class MockDistribution(Distribution):
        def __init__(self, *args, **kwargs):
            super(MockDistribution, self).__init__(*args, **kwargs)
            self.distribution = 'CentOS'
            self.distribution_major_version = '7'
            self.distribution_release = '7.1.1503'
            self.distribution_version = '7.1.1503'

    data_loader = DataLoader()
   

# Generated at 2022-06-23 15:02:51.328068
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    inventory.set_variable("example_host", "example_variable", "example_value")

    hostvars = HostVars(inventory, VariableManager(loader=loader), loader=loader)

    assert hostvars.raw_get("example_host")["example_variable"] == "example_value"

# Generated at 2022-06-23 15:02:56.838508
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)

    groups = dict(all=dict(hosts=['group_1_host', 'group_2_host']))
    inventory.add_group('group_1', hosts=['group_1_host'])
    inventory.add_group('group_2', hosts=['group_2_host'])
    inventory.add_group('ungrouped', hosts=['ungrouped_host'])

    inventory.set_variable('group_1_host', 'group_variable', 'group_1')

# Generated at 2022-06-23 15:03:08.615068
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import sys
    if sys.version_info[0] < 3:
        assert str(HostVarsVars({'a': 'b'}, None)) == "{u'a': u'b'}"
    else:
        assert str(HostVarsVars({'a': 'b'}, None)) == "{'a': 'b'}"

    if sys.version_info[0] < 3:
        assert str(HostVarsVars({'a': 123}, None)) == "{u'a': 123}"
    else:
        assert str(HostVarsVars({'a': 123}, None)) == "{'a': 123}"

    if sys.version_info[0] < 3:
        assert str(HostVarsVars({u'a': 'b'}, None)) == "{u'a': u'b'}"

# Generated at 2022-06-23 15:03:16.334572
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import ansible.constants as C
    from ansible.plugins.loader import inventory_loader
    from ansible.vars import variable_manager

    inventory = inventory_loader.get('host_list', C.DEFAULT_HOST_LIST)
    variables = variable_manager.VariableManager(inventory=inventory)

    assert isinstance(variables.get_vars()['hostvars'], HostVars)

    hostvars_vars = variables.get_vars()['hostvars']['localhost']
    assert isinstance(hostvars_vars, HostVarsVars)

    assert hostvars_vars['ansible_play_hosts'] == [inventory.localhost.name]

# Generated at 2022-06-23 15:03:18.775406
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {
        "var1": "Hello",
        "var2": "World",
    }
    data = HostVarsVars(variables, None)
    assert len(data) == 2
    assert "var1" in data
    assert "var2" in data

# Generated at 2022-06-23 15:03:24.634548
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    import ansible.vars.unsafe_proxy
    hostvars_vars = HostVarsVars({'key': 'value'}, None)

    assert 'key' in hostvars_vars.keys()
    assert not 'foo' in hostvars_vars.keys()

    assert 'key' in hostvars_vars
    assert not 'foo' in hostvars_vars

# Generated at 2022-06-23 15:03:32.248209
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    foo = {}
    foo['a'] = '1'
    foo['b'] = '2'
    foo['c'] = '3'
    bar = {}
    bar['x'] = '4'
    bar['y'] = '5'
    bar['z'] = '6'
    foo['bar'] = bar
    foo['str_bar'] = '{{ bar }}' # Expected to be replaced by a string-converted version of the dictionary bar
    foo['is_bar_undefined'] = 'bar is {{ bar | ternary("defined", "undefined") }}'

    templar = Templar(variables=foo, loader=None)
    # Test that if a host variable is an inner dictionary, it is templated

# Generated at 2022-06-23 15:03:38.074151
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    class MockLoader(object):
        def __init__(self):
            pass

        def get_basedir(self):
            return '.'

    class MockVariableManager(object):
        def __init__(self):
            pass

        def get_vars(self, host=None, include_hostvars=True):
            return {'a': 'b'}

        def get_vars_valid_on(self):
            return None

        def set_host_variable(self, host, varname, value):
            pass

        def set_host_facts(self, host, facts):
            pass

        def set_nonpersistent_facts(self, host, facts):
            pass

        def set_inventory(self, inventory):
            pass


# Generated at 2022-06-23 15:03:42.972326
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.utils.display import Display
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.loader import DataLoader

    my_display = Display()
    my_vault = VaultLib(my_display)
    my_loader = DataLoader()

    my_inventory = dict()
    my_inventory['all'] = dict()
    my_inventory['all']['vars'] = dict()
    my_inventory['all']['vars']['foo'] = 'bar'
    my_inventory['all']['hosts'] = dict()
    my_inventory['all']['hosts']['localhost'] = dict()

    my_host_vars = HostVars(my_inventory, None, my_loader)

    # 'foo' has not been templated, so

# Generated at 2022-06-23 15:03:53.507630
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    my_vars = dict(
        foo="bar",
        test=dict(
            bar="{{ foo }}",
            foo="{{ test.bar }}"
        )
    )
    templar = Templar(variables=my_vars)
    vars_manager = VariableManager()
    vars_manager.extra_vars = my_vars
    vars_manager._fact_cache = {}, {}
    expanded_vars = HostVarsVars(my_vars, templar._loader)

    expected = dict(
        foo="bar",
        test=dict(
            bar="bar",
            foo="{{ test.bar }}"
        )
    )
    assert repr(expanded_vars) == repr

# Generated at 2022-06-23 15:04:02.824440
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from collections import MutableMapping

    class MutableDict(MutableMapping):
        def __init__(self, items=None):
            self._d = {}
            if items:
                self.update(dict(items))

        def __getitem__(self, key):
            return self._d[key]

        def __setitem__(self, key, value):
            self._d[key] = value

        def __delitem__(self, key):
            del self._d[key]

        def __iter__(self):
            return iter(self._d)

        def __len__(self):
            return len(self._d)

        def __repr__(self):
            return '%r' % self._d

    def test_repr(hostvars, loader):
        hv = Host

# Generated at 2022-06-23 15:04:05.715598
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = {'a': 1, 'b': 2, 'c': 3}
    hostVarsVars = HostVarsVars(variables, None)
    assert len(hostVarsVars) == 3

# Generated at 2022-06-23 15:04:12.156199
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    import ansible.inventory
    import ansible.vars.manager
    h = ansible.inventory.host.Host(name='foohost')
    ivm = ansible.vars.manager.VariableManager()
    hv = HostVars(ivm.inventory, ivm, loader=None)
    hv.set_host_variable(h, 'foo', 'bar')
    assert ivm.get_vars(host=h)['foo'] == 'bar'



# Generated at 2022-06-23 15:04:22.619284
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Verify that HostVars object supports iterating over its entities.
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        def __init__(self):
            super(TestCallbackModule, self).__init__()
            self.__events = dict()

        def on_any(self, *args, **kwargs):
            self.__events[(args, kwargs)] = True


# Generated at 2022-06-23 15:04:33.418461
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    temp_loader = DataLoader()
    variable_manager = VariableManager(loader=temp_loader)
    variable_manager.set_inventory(InventoryManager(loader=temp_loader, sources=[]))
    hostvars = variable_manager.get_vars(host=None, include_hostvars=True)
    hostvars.setdefault('localhost', {})['test'] = 'foo'

    state = hostvars.__getstate__()

    new_hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    new_hostvars.__setstate__(state)

    assert new_hostvars._

# Generated at 2022-06-23 15:04:43.740741
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class Inventory:
        def __init__(self):
            self.hosts = ['localhost', 'example.org']
            self.vars = {'example.org': {'a': 1}, 'all': {'b': 2}}

        def get_host(self, name):
            if name not in self.hosts:
                return None

            class Host:
                def __init__(self, name, vars):
                    self.name = name
                    self.vars = vars

                def get_vars(self):
                    return self.vars

            return Host(name, self.vars.get(name, {}))


# Generated at 2022-06-23 15:04:54.885176
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # Pickle of such HostVarsVars object is not possible due to
    # reference to Templar and related objects
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    hvv = HostVarsVars(variables={'some': '{{ an_ansible_variable }}'}, loader=DataLoader())
    hvv._vars['an_ansible_variable'] = 'value'
    hvv.templar = Templar(loader=DataLoader(), variables={})
    hvv.templar.available_variables = dict(variable_manager=VariableManager(loader=DataLoader()))
    assert repr(hvv) == "{u'some': u'value'}"

# Generated at 2022-06-23 15:05:03.595020
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    # pylint: disable=protected-access

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var

    templar = Templar({}, {})
    hvv = HostVarsVars({}, {})
    hvv._templar = templar

    # Variables that must resolve to True
    variables = {
        "a": wrap_var(1),
        "b": wrap_var('foo'),
        "c": wrap_var([1, 2, 3]),
        "d": wrap_var({1: 2}),
        "e": wrap_var(True),
    }
    for var, var_value in variables.items():
        hvv._vars = {var: var_value}
        assert var in hvv

    # Variables that must resolve to False

# Generated at 2022-06-23 15:05:15.110424
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Initialize required objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-23 15:05:21.882171
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = dict(foo = 'bar', baz = 'qux')
    hvv = HostVarsVars(variables, loader=None)
    assert hvv['foo'] == 'bar'
    assert hvv['baz'] == 'qux'
    assert 'foo' in hvv
    assert 'baz' in hvv
    assert 'abc' not in hvv
    assert len(hvv) == 2
    assert sorted(list(hvv)) == ['baz', 'foo']
    assert repr(hvv) == "{'baz': 'qux', 'foo': 'bar'}"

# Generated at 2022-06-23 15:05:25.937715
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    # Arrange
    variables = {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}
    hostvars = HostVarsVars(variables, loader=None)
    expected = 3

    # Act
    actual = len(hostvars)

    # Assert
    assert actual == expected


# Generated at 2022-06-23 15:05:37.860778
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    # Create an empty inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Create a host and add it to the inventory
    host = Host('myhost')
    host.set_variable('foo', 42)
    inventory.add_host(host)

    # Assert method __repr__ of class HostVars
    assert repr(hostvars) == "{'myhost': {'foo': 42}}"

# Generated at 2022-06-23 15:05:48.638232
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import ansible.vars.hostvars
    import ansible.template
    import ansible.playbook.play
    import ansible.playbook.included_file
    import ansible.playbook.task_include
    import ansible.playbook.role
    import ansible.parsing.yaml.objects


# Generated at 2022-06-23 15:06:00.387271
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=None)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars_state = {
        '_inventory': inventory,
        '_loader': loader,
        '_variable_manager': variable_manager,
    }

    hostvars.__setstate__(hostvars_state)

    assert hostvars._loader is loader
    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is host

# Generated at 2022-06-23 15:06:11.915032
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import jinja2
    from ansible import context

    variables = dict(
        var1 = dict(
            var11 = 11,
            var12 = 12
        ),
        var2 = dict(
            var21 = 21,
            var22 = 22
        ),
    )
    loader = jinja2.Environment()
    hostvars = HostVarsVars(variables, loader)

    context.CLIARGS = {'vault_password_file': None}
    assert(hostvars['var1']['var11'] == 11)
    assert(hostvars['var1']['var12'] == 12)
    assert(hostvars['var2']['var21'] == 21)
    assert(hostvars['var2']['var22'] == 22)

# Generated at 2022-06-23 15:06:22.965225
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = Inventory(loader=loader)
    inv._get_host_vars = lambda host: {}
    inv.hosts = []
    inv._hosts_cache = {}
    h1 = Host("h1")
    h2 = Host("h2")
    h3 = Host("h3")
    h4 = Host("h4")
    inv.hosts = [h1, h3]
    inv._hosts_cache = {'h1': h1, 'h3': h3}

    # The inventory only contains h1 and h3, so this should cause h2 and h4

# Generated at 2022-06-23 15:06:33.993257
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import yaml

    class DummyLoader:
        pass

    loader = DummyLoader()
    variables = yaml.load("""
    groups:
      - first:
        - one
        - two
      - second:
        - three
        - four
    group_names:
      - first
      - second
    hosts:
      localhost:
        name: localhost
        ansible_host: 127.0.0.1
        ansible_connection: local
        first_vars:
          - one
          - two
        second_vars:
          - three
          - four
    groups['second']:
      - three
      - four
    ansible_play_hosts:
      - localhost
      - 127.0.0.1
    """)

# Generated at 2022-06-23 15:06:41.595109
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, host_list=['localhost'])
    variable_manager = VariableManager(loader=loader)

    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')
    variable_manager.set_host_variable(host, 'a', 1)
    data = hostvars.raw_get('localhost')

    assert data['a'] == 1, "hostvars.raw_get returned incorrect value"

    inventory = Inventory(loader=loader, host_list=[])
    hostvars.set_inventory(inventory)

# Generated at 2022-06-23 15:06:48.264856
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import find_plugin_filters
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost ansible_connection=local")
    templar = Templar(loader=loader, variables=dict(), shared_loader_obj=find_plugin_filters)
    hv = HostVars(inventory, templar, loader)
    assert hv.__len__() == 1


# Generated at 2022-06-23 15:06:58.952428
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    inventories = InventoryManager(loader=loader, variable_manager=variable_manager, sources=None)
    variable_manager.set_inventory(inventories)
    context = PlayContext()
    variable_manager.set_play_context(context)

    variable_manager.extra_vars = dict()
    variable_manager.extra_vars['asd'] = dict()
    variable_manager.extra_vars['asd']['qwe'] = 'host1'

# Generated at 2022-06-23 15:07:10.421394
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import copy
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory_manager = InventoryManager(host_list=["host1"])
    play_context = PlayContext()
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)
    hostvars = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=DataLoader())
    repr_hostvars = repr(hostvars)
    assert repr_hostvars == "{'host1': {}}"
    hostvars2 = copy.deepcopy(hostvars)
    assert repr(hostvars2) == repr_hostvars

# Generated at 2022-06-23 15:07:14.253711
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    vars = HostVarsVars({'foo_1': 'bar_1'}, loader=None)
    assert 'foo_1' in vars
    assert 'foo_2' not in vars


# Generated at 2022-06-23 15:07:23.133047
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # These are not part of a real module_utils,
    # they are only needed for mocking.
    class Fake_VariableManager:
        def get_vars(self, host=None, include_hostvars=False):
            if include_hostvars:
                return 'hostvars'
            else:
                return 'vars'

    class Fake_Host:
        def __init__(self, host_name):
            self._name = host_name

        def get_name(self):
            return self._name

    class Fake_Inventory:
        def get_host(self, host_name):
            if host_name == 'test_host':
                host = Fake_Host('test_host')
                return host
            else:
                return None

    class Fake_Loader:
        pass

    inventory = Fake_In

# Generated at 2022-06-23 15:07:29.170426
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    foo_host_var = dict(receipt="foo_host_var")
    bar_host_var = dict(receipt="bar_host_var")
    baz_host_var = dict(receipt="baz_host_var")

    # Create test inventory
    hosts = ['foo', 'bar', 'baz']
    inventory = InventoryManager(host_list=hosts)

    # Create test host 'foo' with one host variable
    host = inventory.get_host('foo')
    host.vars = foo_host_var

    # Create test host 'bar' with two host variables
    host = inventory.get_host('bar')
    host.vars = bar

# Generated at 2022-06-23 15:07:33.754435
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Mock a HostVars object
    hostvars = HostVars(None, None, None)

    # This test could fail if len(hostvars) returns a nonzero value and the
    # __len__ method of hostsvars is not implemented.
    assert len(hostvars) == 0

# Generated at 2022-06-23 15:07:45.031484
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import ansible.inventory.manager
    import ansible.playbook.play
    import ansible.plugins.loader as plugin_loader

    # Create a test inventory without hosts
    inventory = ansible.inventory.manager.InventoryManager(
        ansible.plugins.loader.inventory_loader,
        sources="localhost",
    )

    # Create a test play with an empty vars section
    play = ansible.playbook.play.Play()
    play.vars = dict()
    play.vars["host_var"] = "host_var_value"
    play._variable_manager = ansible.playbook.play.VariableManager()

    # Create a HostVar object
    hostvars = HostVars(inventory=inventory, variable_manager=play._variable_manager, loader=None)

    # Function get_host should not return any host

# Generated at 2022-06-23 15:07:53.262226
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        foo = 'bar'
    )
    variable_manager._fact_cache = dict(
        test_fact = 'test_fact_value'
    )
    play_context = PlayContext()
    loader = DataLoader()
    inventory = Inventory(loader, variable_manager, play_context)
    inventory.add_host(Host('test_hostname'))
    hostvars_vars = HostVarsVars(dict(
        test_variable = '{{ test_fact }}'
    ), loader=loader)
    print (hostvars_vars['test_variable'])

# Generated at 2022-06-23 15:08:02.023940
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = None
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # set inventory
    new_inventory = InventoryManager(loader=loader, sources=[])
    hostvars.set_inventory(new_inventory)

    # check inventory
    assert hostvars._inventory == new_inventory

# Generated at 2022-06-23 15:08:10.669447
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # The following test uses a dict of AnsibleUndefined values.
    # It is important to verify that the constructor of HostVarsVars
    # does not trigger evaluation of variables, because eventually
    # AnsibleUndefined values are authenticated and replaced by their
    # underlying value.
    vars = {
        'foo': AnsibleUndefined('foo'),
        'bar': AnsibleUndefined('bar')
    }

    hvv = HostVarsVars(vars, loader)
    assert hvv['foo'] is AnsibleUndefined('foo')
    assert hvv['bar'] is AnsibleUndefined('bar')

# Generated at 2022-06-23 15:08:22.122719
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible import constants
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping

    class FakeHost(MutableMapping):
        def __init__(self, hostvars):
            self._hostvars = hostvars

        def __delitem__(self, key):
            del self._hostvars[key]

        def __getitem__(self, key):
            try:
                return self._hostvars[key]
            except KeyError as e:
                raise AnsibleUndefined(name=str(e))


# Generated at 2022-06-23 15:08:30.532167
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.parsing import DataLoader

    loader = DataLoader()

    # First case: Inventoy contains hosts
    inventory = Inventory(loader=loader, host_list=['host1', 'host2'])
    hv = HostVars(inventory, None, loader)
    assert len(hv) == 2

    # Second case: Inventory does not contain hosts
    inventory = Inventory(loader=loader, host_list=[])
    hv = HostVars(inventory, None, loader)
    assert len(hv) == 0


# Generated at 2022-06-23 15:08:32.728619
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.host import Host

    vars = HostVars({Host(name='localhost'): {}},
                    variable_manager=None,
                    loader=None)
    assert 'localhost' in vars
    assert 'localhost2' not in vars


# Generated at 2022-06-23 15:08:44.819499
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    '''
    HostVars._variable_manager.set_nonpersistent_facts should properly assign
    nonpersistent_facts to their respective host.
    '''
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources='localhost,')
    host_vars = HostVars(inventory_manager, VariableManager(loader=loader), loader=loader)
    host_vars.set_nonpersistent_facts('localhost', {'a': 'b'})

    localhost_group = inventory_manager.get_group('localhost')

# Generated at 2022-06-23 15:08:52.198569
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    class TestInventory(object):
        def get_host(self, host):
            return host

    class TestVariableManager(VariableManager):
        def get_vars(self, host=None, include_hostvars=True):
            return {'test_var': 'test_val'}

    class TestAnsibleUndefined(object):
        def __init__(self, name):
            self.name = name

    hostvars = HostVars(TestInventory(), TestVariableManager(), None)
    assert hostvars.raw_get('localhost') == {'test_var': 'test_val'}
    assert hostvars.raw_get('non-existent-host') == TestAnsibleUndefined

# Generated at 2022-06-23 15:09:01.429224
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from collections import Mapping
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class Dummy(Mapping):
        def __getitem__(self, key):
            return 'blah'

        def __iter__(self):
            return iter(['foo'])

        def __len__(self):
            return 1
