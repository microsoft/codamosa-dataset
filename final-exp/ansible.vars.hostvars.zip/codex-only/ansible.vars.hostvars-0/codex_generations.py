

# Generated at 2022-06-23 14:59:03.739891
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from contextlib import contextmanager

    def _fake_loader(*args, **kwargs):
        return None

    @contextmanager
    def _fake_variable_manager_ctx(*args, **kwargs):
        yield VariableManager

    @contextmanager
    def _fake_inventory_ctx(*args, **kwargs):
        yield None

    @contextmanager
    def _fake_host_ctx(*args, **kwargs):
        yield None

    @contextmanager
    def _fake_host_vars_ctx(*args, **kwargs):
        yield None

    @contextmanager
    def _fake_loader_ctx(*args, **kwargs):
        yield None


# Generated at 2022-06-23 14:59:06.626100
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # TODO: implement unit test
    assert True


# Generated at 2022-06-23 14:59:15.801307
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import pickle
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play


    class HostMock:
        def __init__(self, name):
            self.name = name
            self.vars = dict(foo=42)


    class InventoryMock:
        def __init__(self, hosts):
            self._hosts_cache = hosts
            self.hosts = hosts.values()

        def get_host(self, hostname):
            return self._hosts_cache.get(hostname)


    class PlayMock:
        def __init__(self, inventory, loader, variable_manager):
            self.hosts = inventory.hosts


# Generated at 2022-06-23 14:59:24.132108
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    host = Host('127.0.0.1')
    hostvars = HostVars(inventory=inventory, variable_manager=VariableManager(loader=loader), loader=loader)
    hostvars.set_host_variable(host=host, varname='foo', value='foo_value')
    assert(hostvars.raw_get('127.0.0.1').get('foo') == 'foo_value')

# Generated at 2022-06-23 14:59:30.947363
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible import constants
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'], vault_password=None)
    inventory.clear_pattern_cache()

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = 'localhost'
    group = 'ungrouped'

    assert 'localhost' in hostvars
    assert group in inventory.groups
    assert group in hostvars

    assert host in inventory.hosts
    assert host in inventory.groups
    assert host in inventory.groups[group].hosts
    assert group

# Generated at 2022-06-23 14:59:40.283500
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager

    class FakeInventory():
        def __init__(self):
            self.hosts = ('host1', 'host2')

    class FakeHost():
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class FakeVariableManager():
        def __init__(self):
            self._vars_cache = {'host1': {'a': 1}, 'host2': {'b': 2}}

        def get_vars(self, host, include_hostvars=False):
            if host.get_name() not in ('host1', 'host2'):
                return {}
            if include_hostvars:
                return self._vars_cache[host.get_name()]


# Generated at 2022-06-23 14:59:46.836556
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import copy
    import pytest

    h = HostVars({'localhost': {'foo': 'bar'}})
    assert 'localhost' in h

    h = HostVars(inventory_hostname='localhost')
    assert 'localhost' in h

    h = HostVars({'localhost': {'foo': 'bar'}})
    h['localhost']._vars['inventory_hostname'] = 'localhost'
    h['localhost']._extra_vars = {}
    assert 'inventory_hostname' in h['localhost']



# Generated at 2022-06-23 14:59:51.815469
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    assert len(HostVars({}, {}, {})) == 0
    assert len(HostVars({'a': {}}, {}, {})) == 1
    assert len(HostVars({'a': {}, 'b': {}}, {}, {})) == 2


# Generated at 2022-06-23 15:00:00.808368
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Initialize variables and inventory
    vars_dict = {'a': 1, 'b': 2, 'c': 3}
    variables = VariableManager(loader=DataLoader(), host_vars={'localhost': vars_dict}, group_vars={})
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variables.set_inventory(inventory)

    vars_obj = variables.get_vars(host='localhost', include_hostvars=True)
    for var in vars_obj:
        assert var in vars_dict

# Generated at 2022-06-23 15:00:04.030248
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    vars = dict(a="A", b="{{a}}")
    hvv = HostVarsVars(vars, loader=None)
    assert hvv['b'] == 'A'

# Generated at 2022-06-23 15:00:13.119721
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(variable_manager=variable_manager, loader=loader)
    host = Host(name='localhost')
    hostvars.set_variable_manager(variable_manager)
    variable_manager.set_host_variable(host=host, varname='x', value='1')
    assert 'localhost' in hostvars
    assert '127.0.0.1' in hostvars
    variable_manager.set_host_variable(host=host, varname='x', value='2')
    assert 'localhost' in hostvars

# Generated at 2022-06-23 15:00:22.794151
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    test_vars = {
        'a': '1',
        'b': 2,
        'c': '{{ a }}',
        'd': {
            'e': '{{ b }}'
        }
    }

    loader = DictDataLoader({})
    variables = HostVarsVars(test_vars, loader=loader)
    for var in variables:
        print(var, '=', variables[var])

    # Prints:
    # a = 1
    # b = 2
    # c = 1
    # d = e = 2



# Generated at 2022-06-23 15:00:26.187840
# Unit test for constructor of class HostVars
def test_HostVars():
    hostvars = HostVars(
        inventory=dict(),
        variable_manager=dict(),
        loader=None
    )
    assert hostvars is not None

# Generated at 2022-06-23 15:00:34.419805
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class FakeVaultSecret:
        def __init__(self, secret):
            self.secret = secret

    hvv = HostVarsVars(
        {
            'foo': 'bar',
            'baz': '{{ 1 }}',
            'secret': FakeVaultSecret('shh'),
            'list': [
                1,
                2,
                3,
                FakeVaultSecret('secret'),
            ],
            'dict': {
                'foo': FakeVaultSecret('secret'),
                'bar': 'baz',
                'baz': 'foo',
            },
            'dict2': {
                'foo': 'bar',
                'bar': {
                    'baz': FakeVaultSecret('secret'),
                },
            },
        },
        loader=None
    )

    assert repr(hvv)

# Generated at 2022-06-23 15:00:41.627190
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager

    inventory_data = """
    localhost
    """
    mock_loader = MockLoader()
    mock_inventory = InventoryManager(loader=mock_loader, sources=inventory_data, vault_password='pass')
    mock_variable_manager = MockVariableManager()
    hostvars = HostVars(inventory=mock_inventory,
                        variable_manager=mock_variable_manager,
                        loader=mock_loader)
    assert 'localhost' in hostvars


# Generated at 2022-06-23 15:00:51.094008
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader, hosts='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    hostvars = HostVars(inventory, variable_manager, loader)


# Generated at 2022-06-23 15:00:57.524332
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar

    variables = OrderedDict([('key1','value1'),('key2','value2')])
    loader = None
    hostvarsvars = HostVarsVars(variables,loader)
    assert 'key1' in hostvarsvars
    assert 'key3' not in hostvarsvars



# Generated at 2022-06-23 15:01:00.168728
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory import Inventory
    inventory = Inventory()
    hostvars = HostVars(inventory)
    assert hostvars._variable_manager._hostvars is hostvars


# Generated at 2022-06-23 15:01:05.977018
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    loader = None
    variable_manager = None
    inventory = None

    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._variable_manager is variable_manager
    assert hostvars._variable_manager._hostvars is hostvars

    new_variable_manager = None
    hostvars.set_variable_manager(new_variable_manager)
    assert hostvars._variable_manager is new_variable_manager
    assert hostvars._variable_manager._hostvars is hostvars

# Generated at 2022-06-23 15:01:08.132050
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    assert 'foo' in HostVarsVars({'foo': 'bar'}, loader=None)
    assert 'foo' not in HostVarsVars({}, loader=None)

# Generated at 2022-06-23 15:01:15.155582
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Host, Inventory
    from ansible.vars import VariableManager

    iv = Inventory(loader=None)
    iv.hosts = dict(all=Host(name='all'))

    vm = VariableManager(loader=None, inventory=iv)
    hv = HostVars(iv, vm, loader=None)

    host = iv.get_host('all')
    hv.set_host_facts(host, dict(test_fact='test_fact_value'))

    assert 'test_fact' in vm.get_vars(host=host)

# Generated at 2022-06-23 15:01:26.087759
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = None
    var_manager = None
    inventory = None
    hostvars = HostVars(inventory, var_manager, loader)
    host_name = 'test'
    hostvars.set_host_variable(host_name, 'foo', 'bar')
    hostvars.set_host_variable(host_name, 'bar', 'baz')
    hostvars.set_host_variable(host_name, 'ansible_foo', {'a': 'b', 'c': 'd'})
    hostvars.set_nonpersistent_facts(host_name, {'foo': 'bar'})
    hostvars.set_host_facts(host_name, {'fact': 'bar'})

# Generated at 2022-06-23 15:01:32.210384
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    class FakeLoader: pass
    variables = {'testvar2': 'testvalue2'}
    loader = FakeLoader()
    hostvarsvars = HostVarsVars(variables, loader)
    assert hostvarsvars.__contains__('testvar2')
    assert not hostvarsvars.__contains__('invalidvar')



# Generated at 2022-06-23 15:01:41.515621
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()

    variable_manager._fact_cache = {"1.1.1.1": {'ansible_ssh_host': '1.1.1.1', 'ansible_ssh_port': 22}}
    variable_manager.set_host_variable(host="foo", varname="my_host", value="1.1.1.1")
    variable_manager.set_host_variable(host="foo", varname="remote_user", value="root")
    variable_manager.set_host_variable(host="foo", varname="inventory_hostname", value="foo")

    inventory = []
    compiler = None

    t = Task()
    t

# Generated at 2022-06-23 15:01:51.986500
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    class FakeLoader:
        def __init__(self, variables):
            self._vars = variables

        def load_from_file(self, filename):
            # This method is not used in HostVarsVars' constructor and
            # it's only needed to create an instance of FakeLoader
            return

        def get_basedir(self):
            # This method is not used in HostVarsVars' constructor and
            # it's only needed to create an instance of FakeLoader
            return

    vars = {'var': 'value'}

    hvv = HostVarsVars(vars, loader=FakeLoader(vars))
    assert hvv.get('var') == 'value'

# Generated at 2022-06-23 15:01:57.058702
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    tested_host_vars = HostVars(inventory=None, variable_manager=None, loader=None)

    tested_host_vars.set_host_variable(host="test_host", varname="test_var", value="test_value")
    assert tested_host_vars.raw_get("test_host")["test_var"] == "test_value"

# Generated at 2022-06-23 15:02:00.290789
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    assert len(HostVars({}, {}, {})) == 0
    assert len(HostVars({'localhost': None}, {}, {})) == 1
    assert len(HostVars({'localhost': None, 'otherhost': None}, {}, {})) == 2

# Generated at 2022-06-23 15:02:08.228731
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variables = dict(
        foo=dict(
            bar='baz',
            bar_default='{{ bar_default | default(7, true) }}',
            bar_default_key='{{ bar_default_key | default(8, true) }}',
            bar_default_key2='{{ bar_default_key2 | default(9, true) }}',
            bar_complex='{{ bar_complex | default({ complex: bar_complex_content }, true) }}',
            bar_complex_content=dict(
                baz='qux'
            )
        )
    )

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

# Generated at 2022-06-23 15:02:17.244696
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    '''
    Verify that nonpersistent facts are not remembered across
    different instances of AnsibleVariableManager, but are remembered
    when we re-use the same variable manager.
    '''
    from ansible.module_utils.common._collections_compat import Callable, Iterable, Mapping, MutableMapping
    from ansible.vars.ansible_vars import AnsibleVars
    from ansible.vars.manager import VariableManager

    class FakeHost:
        pass

    class FakeInventory:
        def __init__(self):
            self.hosts = {'host1': FakeHost()}
            self.vars = []

        def get_host(self, hostname):
            return self.hosts[hostname]


# Generated at 2022-06-23 15:02:25.755162
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os.path
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    host_vars = HostVars(inventory, variable_manager=None, loader=None)

    # No host in inventory
    localhost = Host()
    localhost.name = 'localhost'
    host_vars.set_inventory(inventory)

    assert host_vars.raw_get('localhost')['ansible_python_interpreter'] == sys.executable

    inventory.hosts = []
    result = host_vars.raw_get('localhost')
    assert result.get('ansible_python_interpreter') is None

    # Host in inventory, but no facts and variables


# Generated at 2022-06-23 15:02:35.930164
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from collections import Iterable

    class MockLoader:
        pass

    class MockInventory:
        def get_host(self, host_name):
            return host_name

    class MockVariableManager:
        def __init__(self, loader):
            self._loader = loader
            self._hostvars = None
            self._fact_cache = {}

        def get_vars(self, host=None, include_hostvars=True):
            return self._fact_cache

        def set_host_variable(self, host, varname, value):
            self._fact_cache[host][varname] = value

        def set_nonpersistent_facts(self, host, facts):
            self._fact_cache[host] = facts

# Generated at 2022-06-23 15:02:38.050629
# Unit test for constructor of class HostVars
def test_HostVars():
    hostvars = HostVars({}, {}, None)
    assert hostvars is not None


# Generated at 2022-06-23 15:02:45.304814
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    from ansible import constants
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager


# Generated at 2022-06-23 15:02:47.221201
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = {}
    loader = None

    return HostVarsVars(variables, loader).__len__()

# Generated at 2022-06-23 15:02:53.652140
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._variable_manager == variable_manager

    new_variable_manager = VariableManager(loader=loader)
    hostvars.set_variable_manager(new_variable_manager)
    assert hostvars._variable_manager == new_variable_manager

# Generated at 2022-06-23 15:03:01.947601
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible import constants as C
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    hostvars = HostVars(inv_manager, variable_manager, loader)
    hostvars_vars = HostVarsVars({'foo': '{{ inventory_hostname }}/{{ inventory_hostname_short }}/{{ ansible_version }}'}, loader)

    # inventory_hostname
    C.DEFAULT_HOST_LIST = ['localhost']
    assert hostvars_vars['foo'] == 'localhost/localhost/' + C

# Generated at 2022-06-23 15:03:07.561301
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({'foo': 'bar', 'baz': 'qux'}, 'loader')

    assert set(iter(hvv)) == set(iter(hvv._vars))
    assert set(iter(hvv)) == {'foo', 'baz'}



# Generated at 2022-06-23 15:03:16.279189
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    path_to_host_file = 'hosts_file.txt'

    inventory = InventoryManager(loader=DataLoader(), sources=path_to_host_file)
    inventory.add_host(Host('host1'))
    inventory.add_host(Host('host2'))

    # create a sample hostvars with two hosts
    hostvars = HostVars(inventory=inventory, loader=None, variable_manager=VariableManager())

    # create a sample data to update the hostvars
    new_hostvars1 = {'var1': 'value1'}

# Generated at 2022-06-23 15:03:21.959257
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    # Test with valid existed 'hostvars'
    hvv = HostVarsVars({'hostname': 'host'}, None)
    assert ('hostname' in hvv)
    assert ('hostvars' in hvv)

    # Test with non-existed 'hostvars'
    assert ('non_existed_hostvars' not in hvv)


# Generated at 2022-06-23 15:03:30.179601
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    vm = FakeVariableManager()
    hv = HostVars(None, vm, None)
    hv.set_inventory(FakeInventory())

    expected = dict(foo=42, bar=dict(baz=1))
    vm.add_host_vars(FakeHost('test_host'), expected)
    actual = hv.raw_get('test_host')
    assert actual == expected

    # Test fallback to dict()
    expected = dict()
    actual = hv.raw_get('unknown_host')
    assert actual == expected

    # Test AnsibleUndefined
    vm.clear()
    actual = hv.raw_get('test_host')
    assert isinstance(actual, AnsibleUndefined)


# Generated at 2022-06-23 15:03:37.439321
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='./test/hosts')
    hostvars = HostVars(inventory, VariableManager(loader=None), loader=None)

    host_names = []
    for host_name in hostvars:
        host_names.append(host_name)
    assert host_names == ['localhost', 'otherhost']

# Generated at 2022-06-23 15:03:42.780710
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=VariableManager(loader=loader))
    assert isinstance(hostvars, Mapping)

# Generated at 2022-06-23 15:03:53.353627
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    ''' Test if HostVarsVars.__contains__() works properly '''
    import copy

    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager

    ansible_play_hosts = ['localhost', 'test_host']
    ansible_dependent_role_names = ['test_dependency_role']
    ansible_play_role_names = ['test_role']
    ansible_role_names = ['test_role']
    inventory_hostname = 'localhost'
    inventory_hostname_short = 'localhos'

# Generated at 2022-06-23 15:04:02.697098
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Method __repr__ of class HostVars calls super(Mapping, self).__repr__(),
    # but super() tries accessing self.__thisclass__, which is not set in unit tests
    # because a unit test does not inherit from HostVars. Hence, this helper
    # function is used to call __repr__ of HostVars.
    def HostVars_repr(HostVars):
        return HostVars.__repr__()

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = loader.load_from_file('../../test/files/host_vars/host_vars')
    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-23 15:04:09.453202
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins import vars_loader

    inventory = InventoryManager(loader=vars_loader)
    hostvars = HostVars(inventory=inventory, variable_manager=vars_loader._variable_manager, loader=vars_loader)
    if hostvars.raw_get('localhost') is not None:
        raise Exception('hostvars["localhost"] is not None')

# Generated at 2022-06-23 15:04:20.416484
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create mock inventory
    hosts = [Host(name='server01'), Host(name='server02')]
    example_inventory = InventoryManager(Loader=DataLoader(), sources='')
    example_inventory.add_group('test_group')
    for host in hosts:
        example_inventory.add_host(host)

    # Create mock variable manager
    var_manager = VariableManager(loader=DataLoader(), inventory=example_inventory)
    var_manager.set_host_variable(hosts[0], 'foo', 'bar')

# Generated at 2022-06-23 15:04:28.219634
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    import json

    loader = DataLoader()

    # Inventory
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    inventory.add_host(host='localhost')
    inventory._vars_per_group['local_group']['foo'] = wrap_var('bar')

    # Host variables
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader=loader)

# Generated at 2022-06-23 15:04:35.404284
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    class MockInventory(object):
        def __init__(self, host_names):
            self.host_names = host_names
        def hosts(self):
            return self.host_names
        def get_host(self, host_name):
            return host_name if host_name in self.host_names else None

    class MockVariableManager(object):
        def __init__(self):
            self._hostvars = None

    # Test simple case: all host names present in the new inventory
    inventory = MockInventory(['host1', 'host2'])
    variable_manager = MockVariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=None)
    inventory2 = MockInventory(['host2', 'host1'])
    hostvars.set_inventory(inventory2)


# Generated at 2022-06-23 15:04:44.969792
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    # Prepare test data
    class Inventory:
        def __init__(self, host_list):
            self.hosts = host_list
         
        def get_host(self, name):
            return name
     
    class VariableManager:
        def __init__(self, host_vars):
            self._hostvars = host_vars
            
        def get_vars(self, host, include_hostvars=False):
            return self._hostvars[host]
            
        def set_host_variable(self, host, varname, value):
            self._hostvars[host][varname] = value
            
        def set_nonpersistent_facts(self, host, facts):
            host_vars = self._hostvars[host]

# Generated at 2022-06-23 15:04:57.308371
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    class inventory:
        def __init__(self, loader):
            self._loader = loader

        def get_host(self, host_name):
            return HostVarsHost(host_name, self._loader)

    class HostVarsHost:
        def __init__(self, host_name, loader):
            self.name = host_name
            self._loader = loader

        def get_vars(self):
            return self._loader.load_from_file("")

    class Loader:
        @staticmethod
        def load_from_file(path):
            return dict(foo="bar")

    a_inventory = inventory(Loader())

    host_vars = HostVars(a_inventory, None, None)
    host_vars.set_inventory(a_inventory)


# Generated at 2022-06-23 15:05:04.205532
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars import VariableManager
    from copy import deepcopy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = {
        "all": {"hosts": ["testhost1", "testhost2"]}
    }
    variable_manager = VariableManager()
    hostvars = HostVars(loader=loader, inventory=inventory, variable_manager=variable_manager)
    # Set host var "foo" to "bar" on host "testhost1".
    hostvars.set_host_variable("testhost1", "foo", "bar")
    # Add host "testhost1" to inventory.
    inventory["all"]["hosts"].append("testhost1")
    # Create new hostvars object to update its internal cache.
    new_hostvars

# Generated at 2022-06-23 15:05:15.424501
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import ansible
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    localhost = Host(name="localhost")
    variable_manager.set_host_variable(localhost, 'inventory_file', '/foo')
    variable_manager.set_host_variable(localhost, 'inventory_dir', '/bar')
    variable_manager.set_host_

# Generated at 2022-06-23 15:05:23.823325
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    import mock
    from ansible.vars import VariableManager

    # Create mock inventory and loader
    inventory = mock.MagicMock(spec=['hosts'])
    loader = mock.MagicMock(spec=['load_basedir'])

    # Create hostvars object
    variable_manager = VariableManager()
    variable_manager.get_vars = mock.MagicMock(spec=['host', 'inclde_hostvars'])
    variable_manager.get_vars.return_value = {'var1': 'var1_value', 'var2': 'var2_value'}
    hostvars = HostVars(inventory, variable_manager, loader)

    # Get repr of hostvars
    repr_hostvars = repr(hostvars)

    # Compare repr_hostvars with the expected value
   

# Generated at 2022-06-23 15:05:36.617274
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import copy
    import os
    import sys
    import sysconfig
    curpath = os.path.dirname(os.path.abspath(__file__))
    modulepath = os.path.normpath(os.path.join(curpath, os.path.pardir, os.path.pardir))
    sys.path.insert(0, modulepath)

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-23 15:05:42.872338
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    # __iter__ method should return an iterator, each element of which
    # is an instance of Host object
    from ansible.inventory import Inventory
    from ansible.vars.hostvars import HostVars

    inv = Inventory('hosts')
    assert inv.hosts, "empty inventory"

    hostvars = HostVars(inventory=inv)
    for host in hostvars:
        assert isinstance(host, dict)

# Generated at 2022-06-23 15:05:47.422684
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_variable_manager(variable_manager)
    assert hostvars._variable_manager is variable_manager
    assert hostvars._variable_manager._hostvars is hostvars

# Generated at 2022-06-23 15:05:54.198088
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # 0. Create inventory
    data = """
[group1]
localhost

[group2]
localhost ansible_ssh_port=2222 ansible_ssh_host=127.0.0.1
"""

    loader = DataLoader()
    inventory = Inventory(loader, data)

    # 1. Create HostVars
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)

    # 2. Test __iter__ method
    # The expected result is a set of unique group and host names
    expected = {u'localhost', u'group1', u'group2'}
    assert(set(hostvars) == expected)



# Generated at 2022-06-23 15:06:03.555586
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    host_vars = HostVars(inventory=Inventory(host_list=[]), variable_manager=VariableManager(), loader=None)
    assert isinstance(host_vars, HostVars)
    assert list(host_vars) == []

    host_vars = HostVars(inventory=Inventory(host_list=[{'hostname': 'host1'}]), variable_manager=VariableManager(), loader=None)
    assert isinstance(host_vars, HostVars)
    assert list(host_vars) == ['host1']

# Generated at 2022-06-23 15:06:12.579110
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # fake inventory
    inv_objs = {
        "localhost": {
            "name": "localhost",
            "vars": {"foo": "bar"},
        }
    }
    inventory = FakeInventory(inv_objs)
    # fake variable manager
    variable_manager = FakeVariableManager()
    # fake loader
    loader = FakeLoader()
    # fake hostvars
    hostvars = HostVars(inventory, variable_manager, loader)

    assert "localhost" in hostvars
    assert "127.0.0.1" in hostvars
    assert "non-existent-host" not in hostvars


# Generated at 2022-06-23 15:06:20.055527
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars.hostvars import HostVarsVars
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None)
    result = HostVarsVars({'x':'{{y}}', 'y':'{{z}}', 'z':'foo'}, loader)
    assert result['x'] == 'foo'
    result = HostVarsVars({'x':'{{y}}', 'y':'foo'}, loader)
    assert result['x'] == 'foo'
    result = HostVarsVars({'x':'{{y}}'}, loader)
    assert result['x'] == ''

# Generated at 2022-06-23 15:06:26.229993
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=vars_manager)

    hostvars = HostVars(inventory, vars_manager, loader)

    inventory.add_host('test')
    hostvars.set_host_variable(inventory.get_host('test'), 'foo', 'bar')

    assert 'foo' in hostvars['test']

# Generated at 2022-06-23 15:06:33.065356
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=inventory_loader, sources='localhost')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager,
                        loader=None)

    for host in hostvars:
        assert host.name == 'localhost'



# Generated at 2022-06-23 15:06:37.959270
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager

    loader = None
    hostvars = HostVars(None, None, loader)
    hostvars.set_inventory(InventoryManager(loader=loader, sources=''))
    hostvars.set_variable_manager(None)
    assert len(hostvars) == 0
    assert hostvars.raw_get("localhost") is AnsibleUndefined



# Generated at 2022-06-23 15:06:47.630055
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.parsing.vault import VaultLib
    inventory = MockInventory()
    vault_secret = VaultSecret('secret')
    loader = MockLoader()
    vault_password = VaultPassword('password', loader=loader, path='my_path')
    vault_lib = VaultLib([vault_password], [])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars._variable_manager = MagicMock()

# Generated at 2022-06-23 15:06:49.537602
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # hosts = get_hosts(loader)
    assert True

# Generated at 2022-06-23 15:06:57.388486
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'ansible_group_priority', 42)
    assert hostvars.get('localhost').get('ansible_group_priority', None) == 42

# Generated at 2022-06-23 15:07:06.033411
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Prepare test data
    host = "test_host"
    facts = {"facts": "test_facts"}

    # Create instance of HostVars and VariableManager
    hv = HostVars({}, {})
    vm = VariableManager()

    # Set link between HostVars and VariableManager
    hv.set_variable_manager(vm)

    # Set non persistent facts
    hv.set_nonpersistent_facts(host, facts)

    # Check fact
    assert vm._fact_cache[host].nonpersistent == facts



# Generated at 2022-06-23 15:07:14.330243
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    '''
    Verify that set_inventory of HostVars works as expected.
    '''
    import copy
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a simple inventory
    inventory = InventoryManager(loader=DataLoader(), sources='')
    host = Host(name='test.example.com')
    inventory._hosts_cache['test.example.com'] = host
    inventory.add_host(host, 'all')

    # Create a simple hostvars
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())

# Generated at 2022-06-23 15:07:23.158708
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Fake the _get_hosts_from_pattern method of class InventoryManager
    class FakeInventoryManager(object):
        def _get_hosts_from_pattern(self, pattern):
            if pattern == "host1":
                return [FakeHost("host1")]
            elif pattern == "all":
                return [FakeHost("host1"), FakeHost("host2"), FakeHost("host3")]

        def get_host(self, hostname):
            if hostname == "host1":
                return FakeHost("host1")

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

        def get_vars(self):
            if self.name == "host1":
                return {'var1': 'val1'}


# Generated at 2022-06-23 15:07:27.435527
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    v = VariableManager()
    i = Host(name='foo')
    v.set_host_variable(i, 'bar', 'baz')

    h = HostVars(None, v, None)
    assert h.raw_get(i) == {'bar': 'baz'}

    assert 'bar' in h.raw_get('foo')
    assert 'baz' == h.raw_get('foo')['bar']



# Generated at 2022-06-23 15:07:33.935014
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    import os
    import tempfile

    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    if os.path.exists('/tmp/ansible_test_inventory'):
        os.unlink('/tmp/ansible_test_inventory')

    fd, invpath = tempfile.mkstemp(prefix='ansible_test_inventory_')

    with os.fdopen(fd, 'w') as f:
        f.write("""
[test]
localhost ansible_port=1234 ansible_host=127.0.0.1
""")


# Generated at 2022-06-23 15:07:36.134065
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    assert('ANSIBLE_VERSION' in HostVars({'ANSIBLE_VERSION': '1.2.3.4'}, None, None))


# Generated at 2022-06-23 15:07:45.888048
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    '''
    Test that set_host_facts allows setting facts for hosts that are not
    explicitly in the inventory.
    '''
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    hostvars = HostVars(inventory, VariableManager(loader=None, inventory=inventory), loader=None)
    host = Host(name="dummy")
    hostvars.set_host_facts(host, dict(test_fact='foobar'))

    assert hostvars['dummy']['test_fact'] == 'foobar'

# Generated at 2022-06-23 15:07:57.855252
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy

    class Inventory1(object):
        def __init__(self):
            self.hosts = ["localhost"]

        def get_host(self, hostname):
            return hostname

    class Inventory2(object):
        def __init__(self):
            self.hosts = ["localhost"]

        def get_host(self, hostname):
            return hostname

    class Loader1(object):
        pass

    class Loader2(object):
        pass

    class VariableManager1(object):
        def __init__(self):
            self._loader = Loader1()
            self._hostvars = HostVars(Inventory1(), self, self._loader)

    class VariableManager2(object):
        def __init__(self):
            self._loader = Loader2()
            self

# Generated at 2022-06-23 15:08:06.061173
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    my_host = Host(name='my_host')
    hv = HostVars(inventory=InventoryManager(loader=DataLoader(), sources=''),
                  variable_manager=VariableManager(loader=DataLoader(), sources=''),
                  loader=DataLoader())

    # HostVars instance returns "hostvars['my_host']" when key 'my_host' is not in cache
    assert repr(hv['my_host']) == "AnsibleUndefined(name='hostvars['my_host']')"

# Generated at 2022-06-23 15:08:16.950579
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars.manager import VariableManager

    inventory = MockInventory(hosts_count=2)
    loader = MockLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    host0 = inventory.hosts[0]
    host1 = inventory.hosts[1]

    hostvars.set_host_variable(host0, "test0", "value0")
    assert hostvars.raw_get(host0.name)['test0'] == "value0"

    hostvars.set_host_variable(host1, "test1", "value1")
    assert hostvars.raw_get(host1.name)['test1'] == "value1"

    assert hostvars.raw_get

# Generated at 2022-06-23 15:08:23.310269
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, None)
    vars_manager = VariableManager(loader, inventory)
    hostvars = HostVars(inventory, vars_manager, loader)
    assert len(hostvars) == 0

# Generated at 2022-06-23 15:08:33.897303
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars.hostvars import HostVars
    from copy import deepcopy
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class FakeInventory(object):
        hosts = [1, 2]

    class FakeVariableManager(object):
        def __init__(self):
            self.hostvars = None

    class FakeLoader:
        pass

    fake_loader = FakeLoader()
    fake_inventory = FakeInventory()
    fake_variable_manager = FakeVariableManager()

    hostvars = HostVars(fake_inventory, fake_variable_manager, fake_loader)

    with patch.object(fake_variable_manager, 'get_vars') as fake_get_vars:
        fake_get_vars.return_value

# Generated at 2022-06-23 15:08:45.474448
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    class InventoryVar(Inventory):
        def __init__(self):
            self.hosts = ["host1", "host2", "host3"]

    class VariableManagerVar(VariableManager):
        def __init__(self):
            self.vars_cache = {}

        def get_vars(self, host=None, include_hostvars=True, include_delegate_to=True):
            return {}

    inventory_var = InventoryVar()
    variable_manager_var = VariableManagerVar()
    hostvars_var = HostVars(inventory=inventory_var, variable_manager=variable_manager_var, loader=None)
    assert len(hostvars_var) == 3

# Generated at 2022-06-23 15:08:52.526919
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({
        u'foo': u'{{ bar }}',
        u'bar': u'baz'
    })
    variables = {
        u'foo': u'{{ bar }}',
        u'bar': u'baz'
    }
    encrypted_vars = {
        u'encrypted': AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes('secret text'), password=to_bytes('secret'))
    }
    vault_secrets = VaultLib({'password': 'secret'})
   

# Generated at 2022-06-23 15:09:01.623217
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    import sys

    class StubLoader(object):
        def __init__(self, *args, **kwargs):
            pass

    loader = StubLoader()
    variables = {'foo': 'bar'}
    host_vars_vars = HostVarsVars(variables, loader)
    assert len(host_vars_vars) == 1, 'Expected len of HostVarsVars to equal 1, not ' + str(len(host_vars_vars))
    variables = {'foo': 'bar', 'bar': 'baz'}
    host_vars_vars = HostVarsVars(variables, loader)