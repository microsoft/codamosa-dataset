

# Generated at 2022-06-23 14:59:03.277064
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    HostVars.set_variable_manager(variable_manager)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    copied_hostvars = deepcopy(hostvars)

    assert hostvars == copied_hostvars, \
        'deepcopy of HostVars should preserve the content'

# Generated at 2022-06-23 14:59:13.271695
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    import os
    import sys
    hvv = HostVarsVars({'playbook_dir': 'playbook_dir', 'inventory_hostname': 'inventory_hostname'}, None)
    assert('playbook_dir' not in hvv)
    assert('inventory_hostname' not in hvv)
    hvv = HostVarsVars({}, None)
    assert('playbook_dir' not in hvv)
    assert('inventory_hostname' not in hvv)

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-23 14:59:22.715193
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():

    # Create a mock inventory that contains a single host with name 'example_host'
    mock_inv = _MockInventory(('example_host', ))

    # Create a mock variable manager that returns a single variable
    # named 'example_variable' whenever the variable manager is called
    mock_var_manager = _MockVariableManager({
        'ansible_kernel': 'Linux',
    })

    # Create a mock loader
    mock_loader = _MockLoader()

    # Create a HostVars instance using the mock inventory and variable manager
    hostvars = HostVars(inventory=mock_inv, variable_manager=mock_var_manager, loader=mock_loader)

    # Assert that hostvars contains our host, 'example_host'
    assert('example_host' in hostvars)

    # Assert that host

# Generated at 2022-06-23 14:59:32.230108
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    fake_loader = "fake_loader"

    hosts = ['host1', 'host2']
    hostvars = {'host1': 'host1_var',
                'host2': 'host2_var'}

    inventory = Inventory(loader=None, variable_manager=None, host_list=hosts, host_vars=hostvars)
    variable_manager = VariableManager(loader=fake_loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, fake_loader)
    for host in hostvars:
        assert host in hosts, "Host %s does not exist in source list" % host



# Generated at 2022-06-23 14:59:37.417153
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    mock_inventory = type('MockInventory', (object,), {'get_host': lambda _, __: True})
    mock_inventory = mock_inventory()
    mock_loader = type('MockLoader', (object,), {'path_dwim': lambda _, __: True})
    mock_loader = mock_loader()
    mock_variable_manager = type('MockVariableManager', (object,), {'set_host_facts': lambda _, __, ___: True})
    mock_variable_manager = mock_variable_manager()

    mock_hostvars = HostVars(inventory=mock_inventory, variable_manager=mock_variable_manager, loader=mock_loader)
    mock_hostvars.set_host_facts('host_name', 'host_facts')


# Generated at 2022-06-23 14:59:43.266506
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    hvv = HostVarsVars({'test': '{{'}, None)
    assert repr(hvv) == "{'test': '{{'}"
    hvv = HostVarsVars({'test': AnsibleUnsafeText('{{')}, None)
    assert repr(hvv) == "{'test': '{{'}"

# Generated at 2022-06-23 14:59:50.569728
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os

    def test_func(hv, h):
        hv.set_inventory(i)

    # Create inventory
    loader = DataLoader()
    inv_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'test', 'units', 'inventory')
    i = InventoryManager(loader=loader, sources=[inv_path])

    # Create play context
    pc = PlayContext()

    # Create variable manager

# Generated at 2022-06-23 15:00:00.458217
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import sys
    if sys.version_info < (2, 7):
        return
    ansible_play_hosts = ['host1', 'host2', 'host3']
    ungrouped = []
    hostvars = {'host1': {'foo': 2}, 'host2': {}, 'host3': {'foo': 4}}
    inventory_dir = '/dir'
    inventory_file = '/dir/file'
    inventory_hostname_short = 'local'
    groups = {'group1': {'hosts': ['host1', 'host2'], 'vars': {'g_var': 1}}}
    host = 'localhost'
    hostvars[host] = {}
    hosts = [host]
    inventory = {}

# Generated at 2022-06-23 15:00:10.645093
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    import os
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[os.path.dirname(__file__) + '/host_vars_vars/hosts'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(variable_manager=variable_manager, loader=None, inventory=inventory)

    assert '1.1.1.1' in hostvars
    assert '1.1.1.2' in hostvars
    assert '1.1.1.3' not in hostvars
    assert 'foo' not in hostvars

# Generated at 2022-06-23 15:00:19.373405
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from io import StringIO

    test_data = StringIO('''
[test_group]
test_host ansible_user=test_user
''')
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=[test_data])
    var_manager = VariableManager(loader=loader, inventory=inv)
    
    hostvars = HostVars(inventory=inv, variable_manager=var_manager, loader=loader)
    assert str(hostvars) == "{'test_host': {'ansible_user': 'test_user'}}"

# Test unittest
if __name__ == '__main__':
    import sys

# Generated at 2022-06-23 15:00:22.504576
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    hvv = HostVarsVars({"y": 123}, None)
    if hvv['y'] != 123:
        raise AssertionError("test_HostVarsVars(): HostVarsVars not working")

# Generated at 2022-06-23 15:00:32.444104
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # 1) Prepare variables and related attributes prior to setting facts
    from ansible.inventory import Host
    from ansible.vars.option_manager import OptionManager
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # 1.1) Prepare inventory
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    host = inventory.get_host('localhost')

    # 1.2) Prepare variable_manager including its attributes
    option_manager = OptionManager()
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory, options=option_manager)
    variable_manager._fact_cache = dict()
    variable_manager._nonpersistent_fact_cache = dict()
    variable_manager._dependency_

# Generated at 2022-06-23 15:00:37.603979
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {'foo': 'foo', 'bar': 'bar'}
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)
    for var in hostvarsvars:
        assert var in variables
    assert var == 'bar'


# Generated at 2022-06-23 15:00:44.996253
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    hostvars.set_host_variable('localhost', 'ansible_app_setting_foo', 'bar')
    assert hostvars.raw_get('localhost')['ansible_app_setting_foo'] == 'bar'
    hostvars.set_host_variable('localhost', 'ansible_app_setting_bar', 3)
    assert hostvars.raw_get('localhost')['ansible_app_setting_bar'] == 3

# Generated at 2022-06-23 15:00:54.936725
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    host_name = 'localhost'

# Generated at 2022-06-23 15:01:01.118047
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(host_list='tests/inventory')
    variable_manager = VariableManager()
    HostVars(inventory, variable_manager, loader=None)
    hostvars = variable_manager._hostvars

    assert len(hostvars) == 4
    assert len(hostvars['foobar01']) != 0


# Generated at 2022-06-23 15:01:07.982433
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars as TestHostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import become_loader, module_loader

    hosts = {'localhost': host, '127.0.0.1': host}
    groups = [Group('group1', hosts=['localhost']), Group('all', hosts=['127.0.0.1'])]
    inventory = MagicMock(spec=Inventory)
    inventory.get_host.side_effect = lambda x: hosts[x]

# Generated at 2022-06-23 15:01:15.713908
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class FakeLoader():
        def __init__(self):
            pass
        def load_from_file(self, filename):
            pass

    variables = {
        "var1": "value1",
        "var2": "value2"
    }
    loader = FakeLoader()
    hostvarsvars = HostVarsVars(variables, loader)

    # To check if HostVarsVars holds a copy of data from the original dictionary
    variables["var1"] = "value_changed"

    assert hostvarsvars.__repr__() == "{'var1': 'value1', 'var2': 'value2'}"

# Generated at 2022-06-23 15:01:23.381677
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    vm = VariableManager()
    loader = None
    hostvars = HostVars(inventory=None, variable_manager=vm, loader=loader)
    with pytest.raises(AttributeError):
        # Before calling __setstate__, _loader and _hostvars are None
        hostvars._variable_manager._loader
    with pytest.raises(AttributeError):
        hostvars._variable_manager._hostvars
    hostvars.__setstate__({'_inventory': None, '_loader': loader,
                           '_variable_manager': vm})
    assert hostvars._loader == loader
    assert hostvars._variable_manager._hostvars == hostvars
    assert hostvars._variable_manager._loader == loader

# Generated at 2022-06-23 15:01:34.781084
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    hosts = [Host('machine1', port=22)]
    inventory = InventoryManager(loader=DataLoader(), sources='')
    inventory.add_group('test_group')
    inventory.add_host(host='machine1', group='test_group')
    inventory.get_host('machine1').set_variable('ansible_ssh_port', 22)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    host_vars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())


# Generated at 2022-06-23 15:01:35.792707
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # TODO write tests for HostVars
    assert False

# Generated at 2022-06-23 15:01:44.171943
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    class FakeInventory:
        def __init__(self):
            self.host_list = []
        def get_host(self, name):
            for host in self.host_list:
                if host.name == name:
                    return host
            return None
        def add_host(self, host):
            self.host_list.append(host)

    class FakeHost:
        def __init__(self, name, vars=None):
            self.name = name
            self.vars = vars or {}

    class FakeVariableManager:
        def __init__(self):
            self.host_variables = {}

        def set_host_variable(self, host, varname, value):
            self.host_variables.setdefault(host, {})[varname] = value


# Generated at 2022-06-23 15:01:55.644935
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.loader.manager import LoaderManager
    from io import StringIO
    import yaml

    inv_data = """
    all:
        hosts:
            localhost:
            thedude:
    """

    var_data = """
    ---
    ansible_foo:
        bah: "{{ ansible_host }}"
        nope: something
    """

    inv_stream = StringIO(inv_data)
    var_stream = StringIO(var_data)

    inventory = InventoryManager(loader=LoaderManager(), sources=inv_stream)
    variable_manager = VariableManager(loader=LoaderManager(), inventory=inventory)
    variable_manager.extra_vars = yaml.safe_load(var_stream)

# Generated at 2022-06-23 15:02:05.443685
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible import constants
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class FakeOptions(object):
        module_path = constants.DEFAULT_MODULE_PATH
        connection = 'smart'
        forks = 5
        become = None
        become_method = None
        become_user = None
        check = False
        remote_user = 'root'
        private_key_file = None
        listhosts=False
        listtasks=False
        listtags=False
        syntax=False
        diff=False
        host_key_checking=False
        verbosity=False


# Generated at 2022-06-23 15:02:16.157059
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():

    class VariableManager:
        def get_vars(self, host=None, include_hostvars=True):
            return {}

    class Host:
        pass

    host1 = Host()
    host2 = Host()

    vm = VariableManager()
    hv = HostVars(None, vm, None)
    hv.set_variable_manager(vm)

    # When called first time, get_vars() should return empty dictionary
    assert hv.raw_get(host1) == {}

    # Add some variables to host1
    vm.set_host_variable(host1, 'var1', 'val1')
    vm.set_host_variable(host1, 'var2', 'val2')

    # Variables should not be associated with host2
    assert hv.raw_get(host2) == {}



# Generated at 2022-06-23 15:02:25.151978
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    class FakeHost():

        def __init__(self):
            self.vars = {}

    class FakeInventory():

        def __init__(self):
            self.hosts = []

        def get_host(self, hostname):
            for host in self.hosts:
                if host.name == hostname:
                    return host
            return None

        def add_host(self, host, group=None):
            self.hosts.append(host)

    # Test 1: host is new and has no facts
    fake_host1 = FakeHost()
    fake_host1.name = 'host1'
    fake_host1.vars = {}

    fake_inventory = FakeInventory()
    fake_inventory.add_host(fake_host1)


# Generated at 2022-06-23 15:02:35.556101
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # Create an immutable HostVars object
    variable_manager = VariableManager()
    inventory = Inventory()
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Put HostVars to variables' dict
    variables = {'hostvars': hostvars}
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'test_var', variables)

    # Make a deepcopy of variables' dict
    result = variable_manager.get_vars(host=inventory.get_host('localhost'))['test_var']
    assert(type(result) is dict)
    result = result['hostvars']
    assert(type(result) is HostVars)

# Generated at 2022-06-23 15:02:46.024488
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/units/inventory/test_inventory.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    hostvars.set_host_facts(
        host=inventory.get_host('test_one'),
        facts={}
    ) 

    hostvars.set_host_facts(
        host=inventory.get_host('test_three'),
        facts={'foo': 1, 'bar': 2}
    )

   

# Generated at 2022-06-23 15:02:54.171917
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    data = { 'foo': 'a {{ a }}', 'a': 'b' }

    loader = DictDataLoader({'group_vars/group_1': '',
                             'host_vars/host_1': ''})
    inventory = InventoryManager(loader=loader, sources=['group_vars/group_1', 'host_vars/host_1'])
    host = inventory.add_host(host='host_1')
    inventory.add_group('group_1')
    inventory.add_child('group_1', host)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars._variable_manager

# Generated at 2022-06-23 15:03:02.149425
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Test the case where host_name is a string with a valid host name
    # Note: There is no way to set 'localhost' in inventory.
    #       So, we can't test that here.
    vars_cache = {'foo': {'bar': 'baz'}}
    inventory = FakeInventory()
    inventory.get_host_vars.return_value = vars_cache
    host_name = "dummy host name"
    loader = FakeLoader()

    hostvars = HostVars(inventory, FakeVariableManager(), loader)
    vars = hostvars[host_name]

    assert vars == {'foo': {'bar': 'baz'}}

    # Test the case where host_name is empty string
    host_name = ""
    # Here, test HostVars.__getitem__.


# Generated at 2022-06-23 15:03:05.338823
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    inventory = Inventory(host_list=[])
    host = Host('foo')
    inventory.add_host(host)
    variable_manager = VariableManager()
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager)
    assert 'foo' in hostvars
    assert 'bar' not in hostvars


# Generated at 2022-06-23 15:03:10.981386
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    hostvars = HostVars(inventory, VariableManager(), loader)

    new_inventory = Inventory(loader=loader, variable_manager=VariableManager())
    hostvars.set_inventory(new_inventory)

    assert hostvars._inventory is new_inventory

# Generated at 2022-06-23 15:03:18.113807
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/hostvars_raw_get'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert hostvars.raw_get('localhost') == {}

    assert hostvars.raw_get('first') == {
        'var1': 'value1',
        'var2': 'value2',
    }


# Generated at 2022-06-23 15:03:22.345789
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    v = VariableManager()
    i = Inventory(v)
    hv = HostVars(i, v)

    hv['foo'] = {}
    assert 'foo' in list(hv)

# Generated at 2022-06-23 15:03:30.929498
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Ensure attributes _loader and _hostvars of VariableManager have
    # default value None.
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Preserve state of hostvars and restore it with method __setstate__.
    saved_state = hostvars.__getstate__()
    hostvars.__setstate__(saved_state)

    # Ensure attributes

# Generated at 2022-06-23 15:03:34.496407
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    variables = dict(Foo='bar')
    hostvars = HostVarsVars(variables, None)
    assert dict(Foo='bar') == hostvars

# Generated at 2022-06-23 15:03:39.777712
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    class MockLoader:

        def __init__(self):
            pass

        def get_basedir(self):
            pass

    mock_loader = MockLoader()
    variables = {'foo': 'bar'}
    hostvars_vars = HostVarsVars(variables, mock_loader)
    assert 'foo' in hostvars_vars
    assert 'bar' not in hostvars_vars

# Generated at 2022-06-23 15:03:46.590807
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, None)
    assert repr(hostvars) == "{'localhost': {'groups': [u'ungrouped']}}"

# Generated at 2022-06-23 15:03:55.259132
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    host_group = 'all'
    host_vars = {'foo': 'bar'}

    inventory = InventoryManager(loader=DataLoader(), sources='')
    inventory.add_group(host_group)
    inventory.add_host(hostvars=host_vars, name='localhost', groups=[host_group])

    variable_manager = VariableManager()

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
    hostvars.raw_get('localhost') == {'foo': 'bar'}

# Generated at 2022-06-23 15:04:03.772331
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars.manager import VariableManager, HostVarsObject
    import copy

    inv = dict(
        inventory_hostname='foo',
        all=dict(vars=dict(foo='bar')),
        foo=dict(vars=dict(a='b'))
    )

    variable_manager = VariableManager(host_vars_objects=[HostVarsObject(name='inventory', vars=inv)], use_task_vars=False)
    loader = 'fake_loader'

    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)

    hostvars_copy = copy.deepcopy(hostvars)

    assert hostvars_copy._inventory is None
    assert hostvars_copy._loader == loader
    assert hostvars_copy._variable_manager

# Generated at 2022-06-23 15:04:08.430528
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    loader = None
    vars = { 'a': '1', 'b': '{{ a }}' }
    hvv = HostVarsVars(vars, loader)
    assert hvv['b'] == '1'


# Generated at 2022-06-23 15:04:19.119881
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader())
    inventory.add_host('foo')
    inventory.add_host('bar')

    play_context = {}
    play_source = dict(name="Ansible Play", hosts='localhost')
    play = Play.load(play_source, variable_manager=VariableManager(loader=DataLoader()), loader=DataLoader())
    tqm = None
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager._hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
   

# Generated at 2022-06-23 15:04:26.221766
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    fake_loader = DictDataLoader({'host_vars/hostname': "{'foo': 'bar'}"})
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

    hostvars = HostVars(fake_inventory, fake_variable_manager, fake_loader)
    assert hostvars.raw_get('hostname') == {'foo': 'bar'}
    assert hostvars['hostname'] == {'foo': 'bar'}


# Generated at 2022-06-23 15:04:36.356283
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    variables = {'foo': 1, 'bar': 2}
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._vars_cache = {
        'hostvars': {
            'localhost': variables
        }
    }
    variable_manager._hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)
    vars = HostVarsVars(variables, loader)

    assert 'foo' in vars
    assert 'bar' in vars
    assert 'nonexistent' not in vars

# Generated at 2022-06-23 15:04:44.413287
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    host = inventory.get_host("localhost")
    variables = VariableManager(loader=None, inventory=inventory)
    variables.set_known_hosts(inventory.get_hosts())
    hostvars = HostVars(inventory, variables, loader=None)

    # Variable which exists
    assert "inventory_hostname" in hostvars[host]

    # Variable which does not exist
    assert "doesnotexist" not in hostvars[host]

# Generated at 2022-06-23 15:04:56.621008
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    hostvars = HostVars(None, VariableManager(), DataLoader())
    hostvars.set_variable_manager(VariableManager())

    # test __repr__ of variables with none value
    variables = {"var1": None, "var2": None, "var3": "value"}
    host_name = "test"
    hostvars.set_host_variable(host_name, "vars", variables)
    assert hostvars.__repr__() == {host_name: variables}

    # test __repr__ of variables with undefined value
    variables = {"var1": AnsibleUndefined(), "var2": AnsibleUndefined(), "var3": "value"}
    host_name = "test"


# Generated at 2022-06-23 15:04:59.923937
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {'foo': 1, 'bar': 2}
    loader = None

    host_vars_vars = HostVarsVars(variables, loader)

    assert hasattr(host_vars_vars, '__iter__')

    assert list(host_vars_vars) == ['foo', 'bar']



# Generated at 2022-06-23 15:05:12.282540
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    import copy
    import sys

    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var

    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    host_vars = HostVars(
        InventoryManager(
            loader=None,
            sources=['localhost,']
        ),
        variable_manager=VariableManager(
            loader=None,
            inventory=InventoryManager(
                loader=None,
                sources=['localhost,']
            )
        ),
        loader=None
    )


# Generated at 2022-06-23 15:05:15.526162
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    with pytest.raises(AnsibleError, match='requires at least one argument'):
        HostVarsVars.__contains__()


# Generated at 2022-06-23 15:05:23.823323
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import json
    import ast
    import os
    from ansible.inventory.manager import InventoryManager

    # Simple inventory for testing
    INVENTORY = ast.literal_eval('''
    {
        "_meta" : {
            "hostvars" : {
                "foo" : { "a" : 1 },
            }
        },
        "all" : {
            "hosts" : [ "foo", "bar" ]
        },
        "ungrouped" : {
            "hosts" : [ "baz" ]
        }
    }
    ''')

    inventory = InventoryManager(loader=None, sources=json.dumps(INVENTORY))
    variable_manager = VariableManager(loader=None)

    hostvars = HostVars(inventory, variable_manager, loader=None)
   

# Generated at 2022-06-23 15:05:30.938458
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    ''' Unit test for method __contains__ of class HostVarsVars '''
    from ansible.module_utils.common.collections import ImmutableDict
    hv = HostVarsVars(variables=ImmutableDict(), loader=None)
    assert 'foo' not in hv
    try:
        hv['foo']
    except KeyError:
        pass
    else:
        assert False

# Generated at 2022-06-23 15:05:42.456926
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    class Inventory(object):
        def __init__(self, hostvars_cache):
            self._hostvars_cache = hostvars_cache

        @property
        def hosts(self):
            return self._hostvars_cache.keys()

        def get_host(self, host_name):
            if host_name in self._hostvars_cache:
                # This is a mock object, we do not need to create a deepcopy
                return host_name
            return None

    class VariableManager(object):
        def __init__(self, hostvars_cache):
            self._hostvars_cache = hostvars_cache

        def get_vars(self, host=None, include_hostvars=True):
            return self._hostvars_cache[host].copy()


# Generated at 2022-06-23 15:05:47.498991
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import HostsLoader
    from ansible.vars.manager import VariableManager
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)

    inventory_manager = InventoryManager(host_list=[], loader=HostsLoader(), variable_manager=VariableManager())
    variable_manager = VariableManager()
    variable_manager._hostvars = hostvars
    host_name = 'test_host'
    host_name_2 = 'test_host_2'
    inventory_manager.add_host(host_name)
    inventory_manager.add_host(host_name_2)

    hostvars.set_inventory(inventory_manager)

    assert hostvars.raw_get(host_name) == AnsibleUnd

# Generated at 2022-06-23 15:05:56.778610
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='localhost,')
    vm = VariableManager()

    hostvars1 = HostVars(inventory=inventory, variable_manager=vm, loader=loader)
    assert 'localhost' in hostvars1

    inventory = InventoryManager(loader=loader, sources='remote,')
    hostvars1.set_inventory(inventory)
    assert 'remote' in hostvars1
    assert 'localhost' in hostvars1



# Generated at 2022-06-23 15:06:08.748083
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    class FakeVariableManager:
        def __init__(self):
            self.vars_cache = {}
            self._hostvars = None
            self._loader = None

        def get_vars(self, host=None, include_hostvars=True):
            return {"foo": "bar"}

        def get_host_vars(self, host):
            return {"foo": "bar"}

    class FakeLoader:
        pass

    class FakeInventory:
        def __init__(self):
            self.hosts = ["localhost"]

        def get_host(self, name):
            if name == "localhost":
                return None
            return None

    loader = FakeLoader()
    variable_manager = FakeVariableManager()
    inventory = FakeInventory()
    hv = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-23 15:06:13.503323
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    inventory = InventoryManager(loader, [], [])
    variable_manager = VariableManager(loader, inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert 'localhost' in hostvars

# Generated at 2022-06-23 15:06:17.195332
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    assert hv.raw_get('localhost') == AnsibleUndefined(name="hostvars['localhost']")

# Generated at 2022-06-23 15:06:25.392047
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class MockLoader(object):
        def __init__(self):
            self.templates = dict()

    class MockInventory(object):
        def __init__(self):
            self.hosts = dict()

    mock_loader = MockLoader()
    mock_inventory = MockInventory()
    mock_variable_manager = dict()

    hostvars = HostVars(mock_inventory, mock_variable_manager, mock_loader)
    hostvars_vars = HostVarsVars(dict(a=1, b=2), mock_loader)

    assert set(hostvars_vars.__iter__()) == set(['a', 'b'])


# Generated at 2022-06-23 15:06:29.377907
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    hostvars = HostVars(inventory, loader=loader)
    repr(hostvars)

# Generated at 2022-06-23 15:06:38.755304
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from ansible.vars.manager import VariableManager

    host_names = ['test_host', 'localhost']
    vars_per_host = {
        'test_host': dict(a='A', b='B'),
        'localhost': dict(a='a', b='b'),
    }
    vars_cache = dict((h, vars_per_host[h]) for h in host_names)

    inventory = MockInventory(host_names)
    variable_manager = VariableManager(loader=DictDataLoader(vars_cache), inventory=inventory)
    host_vars = HostVars(inventory, variable_manager, DictDataLoader(vars_cache))


# Generated at 2022-06-23 15:06:48.116901
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    data = {
        'localhost': {
            'foo': 'bar',
        },
    }

    inventory = DummyInventory(data)
    loader = DummyLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    localhost = inventory.get_host('localhost')

    # Check the basic case
    hostvars.set_host_variable(localhost, 'foo', 'baz')
    assert hostvars.raw_get('localhost').get('foo') == 'baz'

    # Check that set_host_variable can create a new host
    new_host = inventory.get_host('new_host')
    hostvars.set_host_variable(new_host, 'foo', 'baz')
    assert hostvars.raw

# Generated at 2022-06-23 15:06:58.865339
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    import sys
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager

    hostvars = dict(HOST1=dict(VAR1='value1'), HOST2=dict(VAR2='value2'))

    # Create an inventory for two hosts
    inventory = InventoryManager()
    for hname, hvars in hostvars.items():
        host = Host(hname)
        for varname, value in hvars.items():
            host.set_variable(varname, value)
        inventory.add_host(host)

    # Create HostVars
    from ansible.vars.manager import VariableManager
    # VariableManager.__init__ uses set_hostvars method to assign
    # variables' dicts to hostvars

# Generated at 2022-06-23 15:07:07.254738
# Unit test for constructor of class HostVars
def test_HostVars():
    '''
    >>> hv = HostVars(None, None)
    >>> hv.__contains__(None)
    False
    >>> hv.__getitem__(None)
    {}
    >>> hv.__iter__()
    <generator object __iter__ at 0x7f8b2f82a2b0>
    >>> hv.__len__()
    0
    '''
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:07:13.160718
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import ansible.playbook.play_context
    from ansible.vars.hostvars import HostVarsVars

    hostvars = HostVarsVars(
        {
            'k1': 'v1',
            'k2': 'v2',
        },
        loader=None,
    )
    exp_keys = set(['k1', 'k2'])
    assert isinstance(hostvars, HostVarsVars)
    assert exp_keys == set(hostvars)



# Generated at 2022-06-23 15:07:17.602943
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    test_dict = { 'foo' : '{{ my_var }}', 'bar' : 'my_value', 'my_var' : 'my_value'}
    # _loader is required by Templat.template
    loader = 'some value'
    result = HostVarsVars(test_dict, loader)
    assert result['foo'] == result['bar']

# Generated at 2022-06-23 15:07:29.285391
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    class LocalInventory(InventoryManager):
        def __init__(self):
            InventoryManager.__init__(self, loader=loader)
            self.hosts = []

    data = '''
        [local]
        localhost
        [local:vars]
        ansible_connection=local
        '''
    inventory_manager = LocalInventory()
    inventory_manager.parse_sources(data)
    variable_manager.set_inventory(inventory_manager)

    hostvars = Host

# Generated at 2022-06-23 15:07:38.913012
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inv_source = '''
    localhost ansible_connection=local
    '''
    inv = InventoryManager(loader=None, sources=inv_source)
    vars_mgr = VariableManager(loader=None, inventory=inv)
    hostvars = HostVars(inventory=inv, variable_manager=vars_mgr, loader=None)

    vars_mgr.set_host_variable(host=inv.hosts['localhost'], varname='foo', value='bar')
    hostvars_dict = hostvars.__getstate__()

    # Set _loader and _hostvars attributes to None to simulate unpickling
    vars_mgr._loader = None
    vars_mgr._host

# Generated at 2022-06-23 15:07:48.798416
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.reserved import Reserved
    from ansible.vars import VariableManager

    reserved = Reserved()
    variable_manager = VariableManager(loader=None)

    host1 = reserved.Host('host1', variable_manager=variable_manager)
    host2 = reserved.Host('host2', variable_manager=variable_manager)

    hostvars = HostVars({'foo': host1}, variable_manager, loader=None)

    variable_manager.get_vars(host=host1)['foo'] = 'bar'

    assert variable_manager.set_host_variable(host1, 'foo', 'bar') is True
    assert 'foo' in hostvars['host1']

    # If the variable is not defined within the scope,
    # AnsibleUndefined will be returned

# Generated at 2022-06-23 15:08:01.064539
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import os
    import shutil

    from ansible.compat.tests import unittest
    from ansible.errors import AnsibleParserError
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    class TestHostVars(unittest.TestCase):
        def setUp(self):
            self.inventory_file = 'hostvars-test-hosts'
            self.hostvars_file = 'hostvars-test-hostvars.yml'
            _inventory_hosts = """\
host1
host2
host3
"""


# Generated at 2022-06-23 15:08:10.910237
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    """
    Test __repr__ method for HostVarsVars
    """
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    class FakeHost:
        name = 'fake_host'

    fake_host = FakeHost()
    variable_manager = VariableManager()
    source = 'file'
    loader = DataLoader()
    hostvars = HostVars(InventoryManager(loader=loader, sources=source), variable_manager, loader)
    hostvars.set_host_variable(fake_host, 'var_1', 'var_1_value')

# Generated at 2022-06-23 15:08:22.381612
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import os
    import sys
    import unittest
    import shutil
    from io import BytesIO

    from jinja2.exceptions import UndefinedError

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import _get_group_vars

    class TestHostVarsSetHostFacts(unittest.TestCase):

        def setUp(self):

            # Create a temporary directory
            os.makedirs('./test/')

        def tearDown(self):

            # Remove the directory after the test
            shutil.rmtree('./test/')


# Generated at 2022-06-23 15:08:33.332137
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Test for case when there are no variables in HostVarsVars object
    hvv_obj = HostVarsVars(variables={}, loader=None)
    assert len(hvv_obj) == 0

    # Test for case when there are variables in HostVarsVars object and
    # the value of that variables is a string
    hvv_obj = HostVarsVars(variables={"var": "val"}, loader=None)
    assert len(hvv_obj) == 1

    # Test for case when there are variables in HostVarsVars object and
    # the value of that variables is a list

# Generated at 2022-06-23 15:08:38.097908
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    hostvarsvars = HostVarsVars(
        {'inventory_hostname': 'localhost', 'foo': '{{ inventory_hostname }}'},
        None)
    assert repr(hostvarsvars) == "{'inventory_hostname': 'localhost', 'foo': 'localhost'}"

# Generated at 2022-06-23 15:08:48.614172
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Create inventory and set host
    inventory = Inventory(loader=DataLoader())
    host = inventory.add_host(host='test_host')

    # Create variable manager
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager._options = {'verbosity': 0}
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    # Set value in hostvars and check if it was set
    hostvars.set_host_variable(host, 'test_variable', 'test_value')
    assert 'test_variable' in hostvars[host]
    assert hostvars[host]['test_variable']

# Generated at 2022-06-23 15:08:57.900805
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost,')
    # This is a test to make sure that we can initialize HostVarsVars
    # which is returned in the __getitem__ of HostVars
    hvv = HostVarsVars({'foo': 'bar'}, loader)
    assert hvv['foo'] == 'bar'