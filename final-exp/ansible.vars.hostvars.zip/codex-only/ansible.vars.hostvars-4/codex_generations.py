

# Generated at 2022-06-23 14:59:03.407134
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play().load({}, variable_manager=variable_manager, loader=loader)

    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars._variable_manager._loader = None
    hostvars._variable_manager._hostvars = None

    state = {"_inventory": inventory,
             "_loader": loader,
             "_variable_manager": pickle.dumps(variable_manager)}

    host

# Generated at 2022-06-23 14:59:06.212223
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    pass


# Generated at 2022-06-23 14:59:15.478074
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = dict(host_specific_var='host_specific_var_value')
    variable_manager.options_vars = dict(host_specific_var='options_vars_value')
    play_context = PlayContext()
    vars_plugins = vars_loader.all(play_context)
    variable_manager.set_v

# Generated at 2022-06-23 14:59:23.381880
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars({}, loader, variable_manager)

    hostvars_vars = HostVarsVars(dict(a=1, b=2), loader)

    assert hostvars_vars['a'] == 1
    assert hostvars_vars['b'] == 2

    assert 'a' in hostvars_vars
    assert 'b' in hostvars_vars

    assert len(hostvars_vars) == 2

    assert list(hostvars_vars) == ['a', 'b']

# Generated at 2022-06-23 14:59:27.290602
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    assert len(HostVars(inventory=None, variable_manager=None, loader=None)) == 0
    assert len(HostVars(inventory='inventory', variable_manager=None, loader=None)) == 0
    assert len(HostVars(inventory=None, variable_manager='variable_manager', loader=None)) == 0
    assert len(HostVars(inventory=None, variable_manager=None, loader='loader')) == 0

# Generated at 2022-06-23 14:59:33.066302
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inv_data = '''
        localhost ansible_connection=local
        foo
        bar ansible_ssh_host=127.0.0.1 ansible_ssh_port=222

        [group1]
        foo
        [group2]
        bar
        [group3:children]
        group1
        group2
        [group4:vars]
        ansible_ssh_host=127.0.0.1
    '''
    # Set up the inventory
    inventory = InventoryManager(loader=None, sources=inv_data)
    variable_manager = VariableManager()

    host_vars_cache = HostVars(inventory, variable_manager, None)

    # Verify that the HostVars uses the inventory from the

# Generated at 2022-06-23 14:59:40.866333
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    inventory = FakeInventory()
    inventory.get_host = lambda x: FakeHost(x)
    variable_manager = FakeVariableManager()
    loader = FakeLoader()
    hostvars = HostVars(inventory, variable_manager, loader)

    # Inventory is empty, so __iter__() returns no hosts
    assert list(hostvars.__iter__()) == []

    # Add hosts to inventory, so __iter__() returns them
    inventory.hosts = {FakeHost('h1'), FakeHost('h2'), FakeHost('h3')}
    assert list(hostvars.__iter__()) == [FakeHost('h1'), FakeHost('h2'), FakeHost('h3')]


# Generated at 2022-06-23 14:59:46.656350
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import deepcopy

    class MockVariableManager(object):
        def __init__(self):
            self._vars_per_host = {}

        def get_vars(self, host=None, include_hostvars=True):
            if host is None:
                raise ValueError('host cannot be None')
            if host not in self._vars_per_host:
                self._vars_per_host[host] = {}
            return self._vars_per_host[host]

        def set_host_variable(self, host, varname, value):
            self._vars_per_host[host][varname] = value

        def set_nonpersistent_facts(self, host, facts):
            self._vars_per_host[host]['ansible_facts'] = facts


# Generated at 2022-06-23 14:59:54.364868
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.ini import InventoryParser
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    host_list = InventoryParser(loader=loader, sources=['tests/inventory/hosts_alt'])
    variable_manager = VariableManager(loader=loader)

    hostvars = HostVars(host_list, variable_manager, loader)
    for host in hostvars:
        assert(hostvars[host])

# Generated at 2022-06-23 15:00:02.803479
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    inventory = object()
    variable_manager = object()
    loader = object()
    hv = HostVars(inventory, variable_manager, loader)

    v = object()
    assert hv._loader == loader
    assert hv._variable_manager == variable_manager
    assert hv._inventory == inventory
    assert hv['local'] == AnsibleUndefined(name="hostvars['local']")
    assert hv.raw_get('local') == AnsibleUndefined(name="hostvars['local']")
    hv._find_host = lambda hostname: v
    hv._variable_manager.get_vars = lambda host, include_hostvars: v
    assert hv['local'] == v
    assert hv.raw_get('local') == v

# Generated at 2022-06-23 15:00:12.552478
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    data = {
        'foo': 'baz',
        'a': {
            'b': [1, 'foo', {'c': 3}]
        }
    }
    item = HostVarsVars(data, None)

    # nesting
    assert 'b' in item['a']
    assert 'foo' in item['a']['b']
    assert 'c' in item['a']['b'][2]

    # key existence
    assert 'foo' in item
    assert 'a' in item
    assert 'b' in item['a']
    assert 'c' in item['a']['b'][2]
    assert 'd' not in item
    assert 'e' not in item['a']
    assert 'f' not in item['a']['b'][2]

    # types

# Generated at 2022-06-23 15:00:23.167447
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    host = Host('test')
    hostvars = HostVars({host: {'foo': {'bar': 'baz'}}}, None, None)
    copy_hostvars = deepcopy(hostvars)

    assert id(hostvars) != id(copy_hostvars)
    assert id(hostvars[host]) != id(copy_hostvars[host])
    assert id(hostvars[host]['foo']) != id(copy_hostvars[host]['foo'])
    assert hostvars[host]['foo'] == copy_hostvars[host]['foo']

# Generated at 2022-06-23 15:00:32.655103
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    fake_loader = FakeLoader()
    variable_manager = VariableManager(loader=fake_loader)
    inventory = FakeInventory()
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=fake_loader)
    host = FakeHost()
    facts = {'fact1': 'value1', 'fact2': 'value2'}
    hostvars.set_host_facts(host, facts)

    assert hostvars.raw_get(host.name)['fact1'] == 'value1'
    assert hostvars.raw_get(host.name)['fact2'] == 'value2'


# Generated at 2022-06-23 15:00:42.876513
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import yaml

    def _hostvars(hostvars, hostname, value):
        foo = hostvars._find_host(hostname)
        hostvars.set_host_variable(foo, 'my_var_1', value)

    def _vars(hostvars, hostname):
        play = Play().load({}, variable_manager=hostvars._variable_manager, loader=hostvars._loader)

# Generated at 2022-06-23 15:00:52.488835
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    host = Host(name='fake')
    inventory = InventoryManager(loader=inventory_loader, sources='localhost,')
    inventory.add_host(host)
    inventory.subset("fake")
    loader = DataLoader()
    display = Display()
    templar = Templar(loader=loader, variables={})  # unused
    variable_manager = VariableManager(loader=loader, inventory=inventory, cache=None, cache_lock=None)


# Generated at 2022-06-23 15:00:55.689113
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars.hostvars import HostVars
    from copy import deepcopy

    hostvars = HostVars({}, {}, {})

    deepcopy(hostvars)

# Generated at 2022-06-23 15:01:05.099036
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    loader = DummyLoader()
    inventory = Inventory(loader=loader)
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)

    variables = dict(test='test', foo='bar')
    variable_manager.set_variable_manager(loader, variables)

    host = inventory.get_host('localhost')
    variable_manager.set_nonpersistent_facts(host, dict(test='foo'))
    variable_manager.set_host_facts(host, dict(test='bar'))
    variable_manager.set_host_variable(host, 'test', 'baz')
    variable_manager.set_host_variable(host, 'ansible_foo', 'bar')

    # The value

# Generated at 2022-06-23 15:01:13.682378
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager._hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    host = Host(name="localhost")

    variable_manager.set_host_variable(host=host, varname="ansible_version", value="123")
    variable_manager.set_host_variable(host=host, varname="ansible_version_tmp", value="tmp")

    hostvars = variable_manager._hostv

# Generated at 2022-06-23 15:01:21.952037
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    loader = DictDataLoader({})
    variables = dict(
        foo='bar',
        bar='{{ foo }}',
        repeated_var='{{ repeated_var }}',
    )

    class FakeConfig:
        def __init__(self):
            self.error_on_undefined_vars = False

    config = FakeConfig()

    hostvars_vars = HostVarsVars(variables, loader)
    assert hostvars_vars['foo'] == 'bar'
    assert hostvars_vars['bar'] == 'bar'
    assert hostvars_vars['repeated_var'] == '{{ repeated_var }}'



# Generated at 2022-06-23 15:01:26.460884
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    vars = dict(foo='bar', bar='baz')

    obj = HostVarsVars(vars, loader='dummy')

    vars_keys = set(vars.keys())
    for var in obj:
        vars_keys.remove(var)

    assert len(vars_keys) == 0

# Generated at 2022-06-23 15:01:37.479266
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    import ansible.vars.hostvars


# Generated at 2022-06-23 15:01:43.453016
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    inventory.set_variable("localhost", "testvar", "testvalue")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert 'localhost' in hostvars

# Generated at 2022-06-23 15:01:54.930459
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class TestInventory(Inventory):
        def get_hosts(self, pattern='all'):
            return ["host1", "host2"]

    vars1 = dict(var1='a', var2='b')
    vars2 = dict(var1='c', var2='d')

    inventory = TestInventory()
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.set_host_variable("host1", "vars1", vars1)
    variable_manager.set_host_variable("host2", "vars2", vars2)

    loader = None
    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-23 15:02:00.719552
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    loader = None
    variable_manager = None
    inventory = None
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_inventory(inventory)
    hostvars.set_variable_manager(variable_manager)
    hostvars._find_host = lambda x: None
    assert 'ansible_kernel' in hostvars['localhost']

# Generated at 2022-06-23 15:02:05.704991
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    im = InventoryManager(loader=None, sources=[])
    vm = VariableManager(loader=None, inventory=im)

    hv = HostVars(inventory=None, loader=None, variable_manager=vm)
    # Now check that hv contains an inventory and that inventory is not None
    assert hv._inventory is not None

# Generated at 2022-06-23 15:02:16.223043
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import json

    class MyInventory():
        hosts = ['localhost']
        def get_host(self, host_name):
            return host_name

    class MyVariableManager():
        _hostvars = None
        _loader = None
        def get_vars(self, host, include_hostvars):
            return {'a': {'b': {'c': 1}}, 'd': 'e'}

    hostvars = HostVars(MyInventory(), MyVariableManager(), None)
    hostvars._variable_manager._hostvars = hostvars

    # json.loads(repr(hostvars)) must return the same thing as json.loads('{"localhost": {"a": {"b": {"c": 1}}, "d": "e

# Generated at 2022-06-23 15:02:25.151710
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible import constants as C

    C.HOST_VARS_DIR="./test/units/utils/vars_dir"

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create the inventory, which contains estgru1 and estgru2
    inventory_manager = InventoryManager(loader=C.DEFAULT_LOADER, sources=["./test/units/utils/hosts"])

    # Create the variable manager, which contains the variables for the host estgru1
    variable_manager = VariableManager(loader=C.DEFAULT_LOADER, inventory=inventory_manager)

    # The method __contains__ must return a True since estgru1 is a host in our inventory
    hostvars = HostVars(inventory_manager, variable_manager, C.DEFAULT_LOADER)

# Generated at 2022-06-23 15:02:35.557172
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Create some dummy data
    hosts = dict(
        host1=dict(
            vars1=dict(
                k1='v1',
                k2='v2',
            ),
        ),
        host2=dict(
            vars2=dict(
                k3='v3',
                k4='v4',
            ),
        ),
    )
    # Setup mocks
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    m_inventory = InventoryManager(loader=DataLoader(), sources='')
    m_inventory.hosts = hosts
    loader = None # No need for the loader, we will not use the templating engine

# Generated at 2022-06-23 15:02:36.077899
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    pass

# Generated at 2022-06-23 15:02:44.601880
# Unit test for constructor of class HostVarsVars

# Generated at 2022-06-23 15:02:49.517844
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    play = Play()
    hosts = ['localhost']
    play.hosts = hosts

    inventory = play.set_variable_manager(InventoryManager(hosts))

    hostvars = HostVars(inventory, None)

    assert len(hostvars) is len(hosts)

# Generated at 2022-06-23 15:02:54.001863
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    inventory = None
    loader = None

    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._variable_manager is variable_manager

    new_variable_manager = VariableManager()
    hostvars.set_variable_manager(new_variable_manager)
    assert hostvars._variable_manager is new_variable_manager



# Generated at 2022-06-23 15:02:59.601513
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    """Test for HostVarsVars()."""
    class mock_loader:
        pass
    vars = {'foo': 1, 'bar': 2}
    hvv = HostVarsVars(vars, loader=mock_loader())
    foo = False
    bar = False
    for key in hvv:
        if key == 'foo':
            foo = True
        if key == 'bar':
            bar = True
    assert foo and bar


# Generated at 2022-06-23 15:03:10.418991
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():

    class FakeInventory(object):

        def __init__(self):
            self.hosts = ["host1", "host2", "host3"]

        def get_host(self, host_name):
            if host_name in self.hosts:
                return "host_object"

    class FakeVariableManager(object):

        def __init__(self):
            self._hostvars = "hostvars"

    class FakeLoader(object):

        def __init__(self):
            self.all_vars = dict()

    loader = FakeLoader()
    inventory = FakeInventory()
    variable_manager = FakeVariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)
    assert(len(hostvars) == 3)


# Generated at 2022-06-23 15:03:17.866161
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import ansible.template

    class MyVars(dict):
        pass

    class MyLoader:
        def __init__(self, data):
            self._data = data

        def get_basedir(self, path):
            return "/"

        def load_from_file(self, path):
            return self._data

    data = {
        'version': 2,
        'localhost': {
            'inventory_hostname': 'localhost'
        }
    }

    loader = MyLoader(data)
    inventory = ansible.template.Inventory(loader)
    variable_manager = ansible.template.VariableManager(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvarsvars = hostvars['localhost']

# Generated at 2022-06-23 15:03:26.614726
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    hvv = HostVarsVars(
        variables={ 'test':'{{test}}' },
        loader=DataLoader()
    )

    vm = VariableManager()
    vm.set_loader(hvv._loader)
    vm._hostvars = HostVars(
        inventory=None,
        loader=hvv._loader,
        variable_manager=vm
    )

    hvv._vars['hostvars'] = vm
    assert repr(hvv) == "{'test': {'hostvars': {}}}"

# Generated at 2022-06-23 15:03:28.988140
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Fails if exception is raised
    h = HostVars(None, None, None)
    len(h)


# Generated at 2022-06-23 15:03:39.909032
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    hosts_data = """
        [group1]
        localhost
        [group2]
        localhost
        [group1:vars]
        foo=bar

        [group2:vars]
        baz=qux
    """
    inventory_obj = Inventory(loader=None, host_list=hosts_data)
    variable_manager_obj = VariableManager(loader=None, inventory=inventory_obj)

    hostvars_obj = HostVars(inventory=inventory_obj, variable_manager=variable_manager_obj, loader=None)
    hostvars_obj.set_inventory(inventory=inventory_obj)

    # The variable manager should be updated after the inventory is set
    assert variable_manager_obj.inventory == inventory

# Generated at 2022-06-23 15:03:51.851542
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    host1 = Host('host1')
    host2 = Host('host2')

    loader = DataLoader()
    inventory_dict = {'_meta': {'hostvars': {'host1': {'foo': 'bar'}}},
                      'local': {'hosts': ['host2']},
                      'ungrouped': {'hosts': ['host1']}}
    inventory = Inventory(loader=loader, variables=inventory_dict)

    hostvars = HostVars(inventory=inventory)

    assert('host1' in hostvars)

    # If host2 is not in inventory yet, it will be created on demand.
    assert('host2' in hostvars)

    # __getitem__ is not

# Generated at 2022-06-23 15:04:02.141454
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.plugins.loader import vars_loader, add_directory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create mock inventory
    inventory = InventoryManager(loader=DataLoader())
    host = Host('host1', 'host1')
    inventory._hosts['host1'] = host
    inventory._inventory = inventory

    # Create mock variables manager with empty hostvars. We will test if
    # variables manager restores hostvars with correct values
    variable_manager = VariableManager(loader=DataLoader())
    variable_manager._

# Generated at 2022-06-23 15:04:12.422176
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    vars = {}
    loader = None
    # Test when vars is not a dict
    try:
        hvv = HostVarsVars(vars, loader)
    except TypeError:
        pass
    except:
        raise AssertionError("Expected a TypeError exception")
    else:
        raise AssertionError("Expected a TypeError exception")
    # Test when loader is not a BaseLoader object
    vars = {'foo': 'bar'}
    try:
        hvv = HostVarsVars(vars, loader)
    except TypeError:
        pass
    except:
        raise AssertionError("Expected a TypeError exception")
    else:
        raise AssertionError("Expected a TypeError exception")
    # Test when both vars and loader are valid
    loader = 1
   

# Generated at 2022-06-23 15:04:14.440853
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
   hostvars = HostVars(None, None, None)
   assert repr(hostvars) == "{}"

# Generated at 2022-06-23 15:04:18.459794
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = dict(foo="{{bar}}", bar="c")
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)
    assert hostvarsvars['foo'] == 'c'



# Generated at 2022-06-23 15:04:26.745547
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.module_utils._text import to_text

    # create a Host on demand
    host = Host(name='localhost')
    host.get_vars = lambda: dict(foo='bar')

    # create a HostVars object
    data_loader = DataLoader()
    inventory_manager = InventoryManager(loader=data_loader, sources='')
    variable_manager = VariableManager(loader=data_loader, inventory=inventory_manager, cache=None)

# Generated at 2022-06-23 15:04:37.548743
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create loader
    loader = DataLoader()

    # Create inventory
    hostvars_inventory = dict(
        all=dict(
            children=dict(),
            vars=dict()),
        localhost=dict(
            ansible_host='127.0.0.1',
            ansible_port=22,
            ansible_user='root'))
    host = Host(name='localhost')
    inventory = loader.load(hostvars_inventory)
    inventory.add_host(host)

    # Create HostVars
    hostvars = HostVars(inventory, loader=loader)

    # Create VariableManager
    variable_manager = VariableManager

# Generated at 2022-06-23 15:04:45.832794
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inv = Inventory(host_list=[])
    vars_manager = VariableManager()
    loader = 'ansible.parsing.dataloader.DataLoader'
    hostvars = HostVars(inv, vars_manager, loader)
    inv_hostvars = inv.get_host('hostname').get_vars()

    assert(hostvars == inv_hostvars)

    inv2 = Inventory(host_list=[])
    vars_manager2 = VariableManager()
    loader2 = 'ansible.parsing.dataloader.DataLoader'
    hostvars2 = HostVars(inv2, vars_manager2, loader2)

    hostvars2.set_inventory(inv)

# Generated at 2022-06-23 15:04:51.230423
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Patching a method of a class inside a function is required so the patching
    # is undone after the function has been executed.
    with patch.object(HostVars, '_find_host') as patched_find_host:
        class Host:
            def __init__(self, name):
                self.name = name

        patched_find_host.side_effect = lambda host_name: Host(host_name)
        hv = HostVars(None, None, None)

        hv.set_host_variable(Host('host1'), 'variable1', 'value_1')
        hv.set_host_variable(Host('host1'), 'variable2', 'value_2')
        hv.set_host_variable(Host('host2'), 'variable1', 'value_1')
        hv.set_host_

# Generated at 2022-06-23 15:04:58.761475
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    tmp = {'a': '1',
           'b': '2',
           'c': '{{a}}',
           'd': '{{c}}',
           'e': '{{ d }}',
           'f': '{{ missing }}'}
    test = HostVarsVars(tmp, loader=None)
    assert repr(test) == "{'a': '1', 'b': '2', 'c': '1', 'd': '1', 'e': '1', 'f': '{{ missing }}'}"


# Generated at 2022-06-23 15:05:07.235102
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    hv = HostVars('', VariableManager(loader=DataLoader()), DataLoader())
    # if string representation of HostVars has some '\n'
    # it means that there is some potentially complex values
    # that were not correctly converted to string
    assert len(hv.__repr__().split('\n')) == 2

# Generated at 2022-06-23 15:05:18.158491
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create a deep copy of HostVars
    hostvars_copy = deepcopy(hostvars)

    inventory.add_group('group')
    inventory.add_host(host='localhost', group='group')

    assert hostvars_copy['localhost'] is not None

    # Make sure hostvars and hostvars_copy point to the same
    # inventory and variable_manager
    assert hostvars._

# Generated at 2022-06-23 15:05:25.799277
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    # Prepare objects for test
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test calling __contains__ for host that does not exist
    hostvars = HostVars(inventory, variable_manager, loader)
    host_name = 'example.net'
    assert (host_name not in hostvars)
    assert (host_name not in hostvars)

    # Test calling __contains__ for host that exists

# Generated at 2022-06-23 15:05:37.861282
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    class FakeInventory():
        def __init__(self):
            hosts = []
            hosts.append(FakeHost())

            self.hosts = hosts
            self.get_host = self.hosts.__getitem__

    class FakeHost():
        def __init__(self):
            self.vars = {}

    class FakeVariableManager():
        def __init__(self):
            self._vars_cache = {}

        def get_vars(self, host, include_hostvars):
            return self._vars_cache

        def set_nonpersistent_facts(self, host, facts):
            self._vars_cache[host] = facts

    class FakeLoader():
        pass

    loader = FakeLoader()
    inventory = FakeInventory()
    variable_manager = FakeVariableManager()
    hostvars

# Generated at 2022-06-23 15:05:48.638232
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    class MockVarsManager:
        def get_vars(self, host, include_hostvars):
            return {host.name: 'hostvars'}

    class MockInventory:
        def __init__(self):
            self.hosts = [MockHost('localhost')]

        def get_host(self, hostname):
            for host in self.hosts:
                if host.name == hostname:
                    return host
            return None

        def add_host(self, host):
            self.hosts.append(host)

    class MockHost:
        def __init__(self, name):
            self.name = name
            self.vars = {}

    class MockLoader:
        def __init__(self):
            self.vars_manager = MockVarsManager()

    inventory = MockIn

# Generated at 2022-06-23 15:06:00.386623
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    import copy

    facts = {
        'ansible_os_family': 'RedHat',
        'ansible_distribution': 'Fedora',
    }

    h = Host('test')
    vm = VariableManager()
    hv = HostVars(inventory=None, variable_manager=vm, loader=None)
    hv.set_nonpersistent_facts(host=h, facts=facts)

    # Test that facts were copied
    test_facts = hv.raw_get('test')['ansible_facts']
    assert test_facts == facts
    assert test_facts is not facts

    # Test that facts can be updated

# Generated at 2022-06-23 15:06:11.915770
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins import vars_loader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    test_hosts = ["host1", "host2"]
    test_hostvars = dict(host1=dict(a='a1', b='b1', c='a1'), host2=dict(a='a2', b='b2', c='a2'))

    def my_host_vars_loader(self, *args, **kwargs):
        return test_hostvars

    test_loader

# Generated at 2022-06-23 15:06:19.062168
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory     = None
    variable_manager = None
    loader        = DataLoader()

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert hostvars._variable_manager is None

    variable_manager = VariableManager()
    hostvars.set_variable_manager(variable_manager)

    assert hostvars._variable_manager is not None

# Generated at 2022-06-23 15:06:29.102321
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import jinja2
    from ansible.template import Templar, AnsibleUndefined
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean

    def test_constructor():

        variables = {
            'hostgroups': {'server01': ['group01', 'group02'], 'server02': ['group02', 'group03']},
            'group_names': {'server01': ['group01', 'group02'], 'server02': ['group02', 'group03']},
        }

        # test without fail_on_undefined
        data = HostVarsVars(variables, loader=jinja2.DictLoader({}))
        assert(data['hostgroups'] == variables['hostgroups'])

        # Check

# Generated at 2022-06-23 15:06:38.621018
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar

    class MockLoader:
        pass

    class MockVars(ImmutableDict, Mapping):

        def __init__(self, variables, templar):
            self._variables = variables
            self._templar = templar

        def __getitem__(self, key):
            if key in self._variables:
                return self._templar.template(self._variables[key], fail_on_undefined=False, static_vars=STATIC_VARS)
            raise KeyError('Element %s does not exist' % (key))


# Generated at 2022-06-23 15:06:47.562656
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host_vars = HostVars(inventory, variable_manager, loader)

    # Setup facts
    facts = dict(setup_hostname='setuphostname')

    # Setup variable
    variable = 'setup_hostname'

    # Setup host
    host = inventory.get_host("localhost")

    # Set facts for host
    host_vars.set_host_facts(host, facts)

    # Check that variable was set
    assert variable in host_vars.raw_get("localhost")

# Generated at 2022-06-23 15:06:58.530479
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    import json
    import os
    import sys

    from ansible.compat import json
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.vars.manager import VariableManager

    inventory_path = os.path.join(os.path.dirname(__file__), '..', '..', 'inventory')
    inventory_dirs = [inventory_path]
    inventory_dirs.append(os.path.join(inventory_path, 'host_vars'))


# Generated at 2022-06-23 15:07:10.090233
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    inventory = Inventory(loader, host_list=[])

    hosts = inventory.get_hosts()
    host = hosts[0]

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_host_variable(host, "v1", "value1")
    variable_manager.set_host_variable(host, "v2", { "v3": "value3" })

    vars = HostVars(inventory, variable_manager, loader)
    assert vars.raw_get(host.name) == variable_manager.get_vars(host, include_hostvars=False)

# Generated at 2022-06-23 15:07:19.973096
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # pylint: disable=unused-import
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    C.HOST_KEY_CHECKING = False
    var_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    hostvars = HostVars(inventory, var_manager, loader)
    inventory = InventoryManager(loader=loader, sources=["localhost,"])

    # Assert that the inventory is different before and after calling set_inventory
    assert hostvars._inventory != inventory
    hostvars.set_inventory(inventory)

# Generated at 2022-06-23 15:07:31.593269
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()

    inv_dict = {
        "all": {
            "hosts": ["test"],
            "vars": {
                "test": "inventory_test"
            }
        },
        "test": {
            "vars": {
                "test": "host_test"
            }
        }
    }
    inventory = InventoryManager(loader=loader, sources=inv_dict)

    variable_

# Generated at 2022-06-23 15:07:40.193924
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    pickle_data = hostvars.__getstate__()
    restored_hostvars = HostVars()
    restored_hostvars.__setstate__(pickle_data)
    assert restored_hostvars._inventory is None
    assert restored_hostvars._loader is None
    assert restored_hostvars._variable_manager._loader is loader
    assert restored_hostvars._variable_manager._host

# Generated at 2022-06-23 15:07:46.813435
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader = None
    variables = {
        "var1": "str1",
        "var2": 2,
        "var3": {
            "var4": "str4",
            "var5": 5,
        },
        "var6": [1, 2, 3],
    }
    test1 = HostVarsVars(variables, loader)
    test2 = HostVarsVars.__repr__(test1)
    assert test2 == str(variables)

# Generated at 2022-06-23 15:07:57.610817
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Unpickled HostVars objects have attributes _loader and _inventory
    # set to None. Create a new inventory and loader to keep the pickling
    # behavior. Note -- do not use the functions defined in Ansible, as
    # they will change the object being pickled, and maybe elements
    # that should be copied.
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    hv = HostVars(inventory=InventoryManager(loader=DataLoader(), sources=None),
                  variable_manager=None,
                  loader=DataLoader())
    for host in hv:
        assert host is None



# Generated at 2022-06-23 15:08:01.376447
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = {'a': '{{ x }}', 'x': 'test'}
    loader = MockLoader()
    hvv = HostVarsVars(variables=variables, loader=loader)
    assert hvv['a'] == 'test'


# Generated at 2022-06-23 15:08:05.938493
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    host_vars = {'foo': [1, 2, 3]}

    host_vars_vars = HostVarsVars(host_vars, None)

    assert repr(host_vars) == repr(host_vars_vars)

# Generated at 2022-06-23 15:08:13.714606
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host

    inventory = Inventory(loader=None, variable_manager=VariableManager(), host_list=[])
    inventory.add_host(Host('127.0.0.1'))
    inventory.add_host(Host('127.0.0.2'))
    hostvars = HostVars(inventory, VariableManager(), loader=None)
    # HostVars is immutable so we create a dict that contains HostVars
    data = dict(foo=42, bar=hostvars)
    # Test the method
    data_copy = deepcopy(data)
    # Test if immutable object was copied
    assert data_copy is not data
    assert data_copy['bar'] is data['bar']


# Generated at 2022-06-23 15:08:24.589126
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # HostVars uses private access to the inventory, so this test mocks inventory
    # using a simple class that wraps a dictionary.
    class Inventory:

        def __init__(self):
            self.hosts = {}

        def add_host(self, host_name):
            self.hosts[host_name] = Host(host_name)

        def get_host(self, host_name):
            return self.hosts.get(host_name)
    #
    # The mocked host class simply stores host facts.
    #
    class Host:

        def __init__(self, name):
            self.name = name
            self._vars = {}

        def set_variable(self, name, value):
            self._vars[name] = value

        def get_vars(self):
            return self._v

# Generated at 2022-06-23 15:08:28.876801
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # hostvars for a host not in the inventory must return an AnsibleUndefined
    # instance
    hostvars = HostVars(None, None, None)
    foo = hostvars['myhost']
    assert isinstance(foo, AnsibleUndefined)



# Generated at 2022-06-23 15:08:30.561780
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = object
    variables = {'foo': 'bar'}
    test_obj = HostVarsVars(variables, loader)
    assert 'bar' == test_obj['foo']

# Generated at 2022-06-23 15:08:35.918239
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.vars.hostvars import HostVarsVars
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils._text import to_native

    # Is `ansible_play_hosts` defined in HostVars?
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

# Generated at 2022-06-23 15:08:41.984352
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():

    class FakeLoader():
        '''Fake class to make unit tests work'''

        def __init__(self):
            pass

    class FakeInventory():
        '''Fake class to make unit tests work'''

        def __init__(self):
            pass

    x = HostVarsVars({'y': 1}, FakeLoader())
    assert len(x) == 1



# Generated at 2022-06-23 15:08:50.906538
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inv_source = """
    [all]
    localhost ansible_connection=local
    [web]
    www1
    www2
    """
    inv_manager = InventoryManager(loader=None, sources=inv_source)

    # initialize variables
    var_manager = VariableManager(loader=None, inventory=inv_manager)

    # construct HostVars object
    hostvars = HostVars(inv_manager, var_manager, None)

    # Test case 1: set a variable for a given host
    host = inv_manager.get_host('localhost')
    hostvars.set_host_variable(host, 'newvar', 'newvar_value')

# Generated at 2022-06-23 15:08:59.105952
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = Inventory(loader, [], host_list=['localhost'], vault_passwords=['secret'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    hostvars = HostVars(inv, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 5)

    assert hostvars.get('localhost').get('foo') == 5
