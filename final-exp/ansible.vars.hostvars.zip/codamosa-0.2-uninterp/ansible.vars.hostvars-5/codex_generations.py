

# Generated at 2022-06-22 17:00:22.448559
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that raw_get returns the same value as __getitem__
    # for a host that exists in the inventory
    host_name = 'localhost'
    assert hostvars.raw_get(host_name) == hostvars[host_name]

    # Test that raw_get returns the same value as __getitem__
    # for a host that does not exist in the inventory

# Generated at 2022-06-22 17:00:28.071670
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:00:32.163301
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars.raw_get('localhost') == {'foo': 'bar'}

# Generated at 2022-06-22 17:00:37.958051
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestHostVarsVars(unittest.TestCase):

        def setUp(self):
            self.loader = None
            self.variable_manager = VariableManager()
            self.hostvars = HostVars(self.variable_manager, self.loader)

        def test_getitem_with_undefined_variable(self):
            self.variable_manager.set_host_variable(None, 'foo', 'bar')
            self.assertEqual(self.hostvars['localhost']['foo'], 'bar')

# Generated at 2022-06-22 17:00:44.926232
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 17:00:55.304316
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 17:01:04.435441
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = Host(name='localhost')
    host.vars = dict(foo='bar')
    inventory.add_host(host)

    assert hostvars.raw_get('localhost') == dict(foo='bar')

# Generated at 2022-06-22 17:01:11.059266
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert repr(hostvars) == "{'localhost': {}}"


# Generated at 2022-06-22 17:01:17.105702
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:01:23.883586
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that raw_get returns the same value as __getitem__
    # when the host is in the inventory
    host = inventory.get_host('localhost')
    assert hostvars.raw_get('localhost') == hostvars['localhost']

    # Test that raw_get returns the same value as __getitem__
    # when the host is not in the inventory

# Generated at 2022-06-22 17:01:37.976421
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars['localhost'] == {}
    assert hostvars['localhost'] == hostvars.raw_get('localhost')

    hostvars.set_host_variable(host=inventory.get_host('localhost'), varname='foo', value='bar')

    assert hostvars['localhost'] == {'foo': 'bar'}
    assert hostvars['localhost'] != hostvars.raw_get('localhost')


# Generated at 2022-06-22 17:01:44.488264
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined if host is not found
    assert isinstance(hostvars['non_existent_host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars for existing host
    assert isinstance(hostvars['localhost'], HostVarsVars)

# Generated at 2022-06-22 17:01:48.930372
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-22 17:01:55.045186
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(None, variable_manager, loader)

    # Assert that _loader and _hostvars attributes of VariableManager
    # are not set.
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Assert that __setstate__ method of HostVars sets _loader and
    # _hostvars attributes of VariableManager.
    hostvars.__setstate__({})
    assert variable_manager._loader is loader
    assert variable_manager._hostvars is hostvars

# Generated at 2022-06-22 17:02:03.945780
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check that _loader and _hostvars attributes of VariableManager are
    # not set.
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Check that _loader and _hostvars attributes of VariableManager are
    # set after unpickling.
    hostvars.__setstate__(hostvars.__getstate__())
    assert variable_manager._loader is loader

# Generated at 2022-06-22 17:02:08.479821
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Assign _loader and _hostvars attributes to VariableManager
    # to make sure they are not preserved after pickling.
    variable_manager._loader = loader
    variable_manager._hostvars = hostvars

    # Pickle and unpickle HostVars object.
    import pickle
    hostvars_unpickled = pickle.loads(pickle.dumps(hostvars))

    # Check that _loader and

# Generated at 2022-06-22 17:02:14.409586
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # test for host that is not in inventory
    assert hostvars.raw_get('test') is AnsibleUndefined

    # test for host that is in inventory
    assert hostvars.raw_get('localhost') == {'ansible_connection': 'local'}

# Generated at 2022-06-22 17:02:24.724192
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    hostvars.set_host_variable('localhost', 'baz', 'qux')
    hostvars.set_host_variable('localhost', 'nested', {'foo': 'bar'})
    hostvars.set_host_variable('localhost', 'list', ['foo', 'bar'])
    hostvars.set

# Generated at 2022-06-22 17:02:36.057763
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-22 17:02:46.450917
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)

    hostvars = HostVars(None, variable_manager, loader)
    hostvars.set_host_variable(None, 'foo', 'bar')
    hostvars.set_host_variable(None, 'baz', 'qux')

    hostvars_vars = HostVarsVars(hostvars, loader)
    assert hostvars_vars['foo'] == 'bar'
    assert hostvars_vars['baz'] == 'qux'

# Generated at 2022-06-22 17:03:01.262231
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_hostname }}')))
        ]
    )
    play

# Generated at 2022-06-22 17:03:08.924392
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert list(hostvars) == ['localhost']



# Generated at 2022-06-22 17:03:15.110239
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test for host that does not exist
    assert hostvars.raw_get('non_existent_host') == AnsibleUndefined(name="hostvars['non_existent_host']")

    # Test for host that exists
    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 17:03:26.070147
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = Play()

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable('localhost', 'foo', 'bar')
    hostvars.set_host_variable('localhost', 'baz', 'qux')

    hostvars_vars = hostvars['localhost']

    assert set

# Generated at 2022-06-22 17:03:34.072655
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:03:42.666509
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

    inventory.add_host('testhost')
    assert hostvars['testhost'] == {'inventory_hostname': 'testhost', 'inventory_hostname_short': 'testhost'}


# Generated at 2022-06-22 17:03:53.072842
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    hostvars.set_host_variable('localhost', 'baz', 'qux')

    hostvars_vars = hostvars['localhost']
    assert isinstance(hostvars_vars, HostVarsVars)

    # Check that Host

# Generated at 2022-06-22 17:03:59.646506
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'baz', 'qux')

    hostvars_vars = hostvars['localhost']

    assert set(hostvars_vars) == set(['foo', 'baz'])

# Generated at 2022-06-22 17:04:07.012667
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:04:12.266200
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:04:32.116665
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined for non-existent host
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars for localhost
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that HostVars returns HostVarsVars for localhost

# Generated at 2022-06-22 17:04:37.437538
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:04:45.743359
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_version }}')))
        ]
    )

# Generated at 2022-06-22 17:04:54.091747
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:04:59.758761
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert repr(hostvars) == "{'localhost': {}}"

    variable_manager.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')

    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-22 17:05:07.004216
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == []

    inventory.add_host('localhost')
    assert list(hostvars) == ['localhost']

    inventory.add_host('localhost2')
    assert list(hostvars) == ['localhost', 'localhost2']

# Generated at 2022-06-22 17:05:16.521129
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(list(hostvars)) == 1
    assert list(hostvars)[0].name == 'localhost'

# Generated at 2022-06-22 17:05:22.278724
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:05:27.612372
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test with a host that does not exist
    assert hostvars.raw_get('foo') == AnsibleUndefined(name="hostvars['foo']")

    # Test with a host that exists
    inventory.add_host(host='foo')
    assert hostvars.raw_get('foo') == {}

# Generated at 2022-06-22 17:05:34.953639
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create inventory, variable_manager and loader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test __getitem__
    assert hostvars['localhost'] == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 17:05:52.677366
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

    hostvars.set_host_variable('localhost', 'foo', 'baz')
    assert hostvars['localhost']['foo'] == 'baz'

    hostvars.set_host_variable('localhost', 'foo', 'bar')

# Generated at 2022-06-22 17:05:59.119636
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']


# Generated at 2022-06-22 17:06:09.380221
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}
    assert isinstance(hostvars['localhost'], HostVarsVars)

    variable_manager.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost'] == {'foo': 'bar'}

    variable_manager.set_host_variable('localhost', 'bar', 'baz')

# Generated at 2022-06-22 17:06:17.913812
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost'}

# Generated at 2022-06-22 17:06:25.719894
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # test with a host that exists
    hostvars['localhost']
    # test with a host that does not exist
    hostvars['non-existent-host']

# Generated at 2022-06-22 17:06:33.045126
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

    inventory.add_host('testhost')
    assert list(hostvars) == ['localhost', 'testhost']

    inventory.add_host('testhost2')
    assert list(hostvars) == ['localhost', 'testhost', 'testhost2']

    inventory.remove_host('testhost')

# Generated at 2022-06-22 17:06:41.598721
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    hostvars = HostVars(inventory=inv_manager, variable_manager=variable_manager, loader=loader)

    # test that hostvars['localhost'] returns a HostVarsVars object
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # test that hostvars['localhost'] returns a HostVarsVars object
    # with the same content as variable_manager.get_vars(host=host)
    host = inv

# Generated at 2022-06-22 17:06:50.697514
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:07:01.762319
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that the hostvars of localhost are returned

# Generated at 2022-06-22 17:07:09.990561
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(hostvars) == 1
    assert 'localhost' in hostvars
    assert 'localhost' in hostvars._inventory.hosts
    assert 'localhost' in hostvars._inventory.get_hosts()
    assert 'localhost' in hostvars._inventory.get_hosts(pattern='localhost')
    assert 'localhost' in hostvars._inventory.get_hosts(pattern='all')


# Generated at 2022-06-22 17:07:32.272292
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:07:36.810074
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:07:47.375079
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that raw_get returns the same value as __getitem__
    # when the host is present in inventory
    host_name = 'localhost'
    hostvars.set_host_variable(host_name, 'foo', 'bar')
    assert hostvars.raw_get(host_name) == {'foo': 'bar'}

# Generated at 2022-06-22 17:07:56.953078
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    assert hostvars['localhost']['inventory_hostname'] == 'localhost'
    assert hostvars['localhost']['inventory_hostname_short'] == 'localhost'
    assert hostvars['localhost']['groups'] == ['ungrouped']
    assert hostvars['localhost']['group_names'] == ['ungrouped']

# Generated at 2022-06-22 17:08:05.071041
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_

# Generated at 2022-06-22 17:08:13.037051
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = Host(name='localhost')
    variable_manager.set_host_variable(host, 'foo', 'bar')
    variable_manager.set_host_variable(host, 'baz', 'qux')


# Generated at 2022-06-22 17:08:18.154602
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-22 17:08:25.755928
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:08:37.362803
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    # even if the host is not in the inventory
    assert isinstance(hostvars['foo'], HostVarsVars)

# Generated at 2022-06-22 17:08:42.025402
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:09:21.807947
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:09:31.662534
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:09:41.581179
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = Host(name='localhost')
    host.vars = {'foo': 'bar'}
    inventory.add_host(host)

    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-22 17:09:46.842186
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    # even if the host is not in the inventory

# Generated at 2022-06-22 17:09:57.379603
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that hostvars['localhost']['ansible_facts'] returns a dict
    assert isinstance(hostvars['localhost']['ansible_facts'], dict)

    # Test that hostvars['localhost']['ansible_facts'

# Generated at 2022-06-22 17:10:01.056311
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test that hostvars.raw_get('localhost') returns the same value as
    # variable_manager.get_vars(host=inventory.get_host('localhost'), include_hostvars=False)
    assert hostvars.raw_get('localhost') == variable_manager.get_vars(host=inventory.get_host('localhost'), include_hostvars=False)