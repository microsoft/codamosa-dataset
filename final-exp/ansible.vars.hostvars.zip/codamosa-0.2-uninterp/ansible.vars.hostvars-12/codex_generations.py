

# Generated at 2022-06-22 16:59:43.143748
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_vars = hostvars['localhost']

    assert set(hostvars_vars) == set(hostvars_vars.keys())

# Generated at 2022-06-22 16:59:56.078075
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader)

    host = inventory.get_host('localhost')
    hostvars.set_host_variable(host, 'foo', 'bar')

    assert 'foo' in hostvars['localhost']
    assert 'foo' in hostvars.raw_get('localhost')
    assert 'foo' in hostvars.raw_get('localhost').keys()
    assert 'foo' in hostvars['localhost'].keys()
    assert 'foo' in list(hostvars['localhost'])


# Generated at 2022-06-22 17:00:01.044272
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined for non-existent host
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars for existing host
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that HostVars returns HostVarsVars for existing host

# Generated at 2022-06-22 17:00:09.530857
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

    hostvars.set_host_variable('localhost', 'foo', 'baz')
    assert hostvars['localhost']['foo'] == 'baz'

    hostvars.set_host_variable('localhost', 'foo', '{{ bar }}')


# Generated at 2022-06-22 17:00:19.363360
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')

    hostvars_vars = hostvars['localhost']
    assert 'foo' in hostvars_vars
    assert 'bar' == hostvars_vars['foo']

# Generated at 2022-06-22 17:00:27.788887
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{foo}} {{bar}}')))
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None
   

# Generated at 2022-06-22 17:00:34.907715
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Group('all')
    inventory.add_host(Host('localhost'))
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:00:39.764917
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:00:47.329403
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test if the method returns the correct value
    assert hostvars['localhost'] == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

    # Test if the method returns an AnsibleUndefined object if the host does not exist
    assert isinstance(hostvars['non_existent_host'], AnsibleUndefined)

# Generated at 2022-06-22 17:00:52.194195
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class TestCallback(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self.host_ok

# Generated at 2022-06-22 17:01:03.489118
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars.raw_get('localhost')['foo'] == 'bar'

# Generated at 2022-06-22 17:01:13.666571
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Assert that _loader and _hostvars attributes of VariableManager are
    # None before calling __setstate__
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Call __setstate__

# Generated at 2022-06-22 17:01:18.870211
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader)

    hostvars_vars = hostvars['localhost']
    assert set(hostvars_vars) == set(hostvars_vars.keys())

# Generated at 2022-06-22 17:01:22.295268
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:01:30.746194
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.add_host(host='test')
    variable_manager.set_host_variable(host=inventory.get_host('test'), varname='foo', value='bar')

    assert repr(hostvars) == "{'test': {'foo': 'bar'}}"

# Generated at 2022-06-22 17:01:41.992253
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(None, variable_manager, loader)
    hostvars.set_variable_manager(variable_manager)

    hostvars.set_host_variable(None, 'foo', 'bar')
    hostvars.set_host_variable(None, 'baz', '{{ foo }}')
    hostvars.set_host_variable(None, 'qux', '{{ baz }}')

    assert hostvars['localhost']['foo'] == 'bar'
    assert hostvars['localhost']['baz'] == 'bar'
    assert hostvars['localhost']['qux'] == 'bar'

# Generated at 2022-06-22 17:01:47.512284
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:01:52.552266
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:02:00.790682
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:02:07.900358
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:02:24.613267
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check that _loader and _hostvars attributes are not set
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Call __setstate__ with state that contains _loader and _hostvars attributes
    state = {'_inventory': inventory, '_loader': loader, '_variable_manager': variable_manager}
    hostvars.__setstate__(state)

    # Check that

# Generated at 2022-06-22 17:02:36.015934
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with empty inventory
    assert list(hostvars) == []

    # Test with non-empty inventory
    inventory.add_host('localhost')
    assert list(hostvars) == ['localhost']

    # Test with non-empty inventory and non-empty variables
    inventory.set_variable('localhost', 'foo', 'bar')
    assert list

# Generated at 2022-06-22 17:02:43.074429
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:02:53.260300
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a host that exists
    host = Host(name='localhost')
    host.vars = {'foo': 'bar'}
    inventory.add_host(host)
    assert hostvars.raw_get

# Generated at 2022-06-22 17:03:03.306810
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a host that does not exist
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test with a host that exists
    assert isinstance(hostvars['localhost'], HostVarsVars)
    assert isinstance

# Generated at 2022-06-22 17:03:13.153813
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)


# Generated at 2022-06-22 17:03:24.863689
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    hostvars = HostVars(inventory=inv_manager, variable_manager=variable_manager, loader=loader)

    hostvars.set_host_variable(host=inv_manager.get_host('localhost'), varname='foo', value='bar')
    hostvars.set_host_variable(host=inv_manager.get_host('localhost'), varname='baz', value='qux')

    hostvars_vars = hostvars.get('localhost')

# Generated at 2022-06-22 17:03:30.743126
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Assign _loader and _hostvars attributes to VariableManager
    variable_manager._loader = loader
    variable_manager._hostvars = hostvars

    # Pickle HostVars and unpickle it
    import pickle
    hostvars_pickled = pickle.dumps(hostvars)
    hostvars_unpickled = pickle.loads(hostvars_pickled)

    #

# Generated at 2022-06-22 17:03:39.159133
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test if the iterator of HostVars is working properly
    assert len(list(hostvars)) == 1
    assert list(hostvars)[0].name == 'localhost'

# Generated at 2022-06-22 17:03:43.299951
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}

# Generated at 2022-06-22 17:04:04.833839
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check that _loader and _hostvars attributes of VariableManager
    # are not set.
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Set state of hostvars.
    hostvars.__setstate__(hostvars.__getstate__())

    # Check that _loader and _hostvars attributes of VariableManager
    # are set.
    assert variable

# Generated at 2022-06-22 17:04:13.537164
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

    hostvars.set_host_variable('localhost', 'foo', '{{ bar }}')
    hostvars.set_host_variable('localhost', 'bar', 'baz')
    assert hostvars['localhost']['foo'] == 'baz'



# Generated at 2022-06-22 17:04:20.385017
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:04:31.286404
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test for host that does not exist
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")

    # Test for host that exists

# Generated at 2022-06-22 17:04:36.966744
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test for undefined variable
    assert hostvars['localhost']['undefined_var'] == AnsibleUndefined(name="hostvars['localhost']['undefined_var']")

    # Test for defined variable
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'defined_var', 'defined_value')
    assert hostvars['localhost']['defined_var'] == 'defined_value'

    # Test for undefined variable in a defined variable
    variable_manager.set

# Generated at 2022-06-22 17:04:45.165251
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars.raw_get returns the same value as
    # variable_manager.get_vars(host=host, include_hostvars=False)
    host = inventory.get_host('localhost')
    assert hostvars.raw_get('localhost') == variable_manager.get_vars(host=host, include_hostvars=False)

# Generated at 2022-06-22 17:04:56.150885
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)


# Generated at 2022-06-22 17:05:01.250217
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:05:08.433410
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined when host is not found
    assert isinstance(hostvars['non-existing-host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars when host is found
    assert isinstance(hostvars['localhost'], HostVarsVars)


# Generated at 2022-06-22 17:05:18.979312
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    class TestCallback(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self.host_ok = {}
            self.host_unreachable = {}
            self.host_failed = {}


# Generated at 2022-06-22 17:05:41.638405
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert len(list(hostvars)) == 1
    assert list(hostvars)[0] == 'localhost'

# Generated at 2022-06-22 17:05:45.267816
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:05:54.997641
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    # even if the host is not in the inventory
    assert isinstance(hostvars['non-existent-host'], HostVarsVars)

    # Test that hostv

# Generated at 2022-06-22 17:06:06.715126
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-22 17:06:11.686588
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:06:16.056306
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('localhost') == {}
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")

# Generated at 2022-06-22 17:06:22.248468
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a host that exists
    host = Host(name='localhost')
    hostvars.set_host_variable(host, 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

    # Test with a host that does not exist

# Generated at 2022-06-22 17:06:33.094952
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_env.HOME }}')))
        ]
    )

# Generated at 2022-06-22 17:06:38.093367
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test that raw_get returns AnsibleUndefined if host is not found
    assert isinstance(hostvars.raw_get('localhost'), AnsibleUndefined)

    # Test that raw_get returns a dict if host is found
    inventory.add_host(host='localhost')
    assert isinstance(hostvars.raw_get('localhost'), dict)

# Generated at 2022-06-22 17:06:44.750410
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import os
    import json

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-22 17:07:28.477987
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{myvar}}')))
        ]
    )

# Generated at 2022-06-22 17:07:36.604042
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-22 17:07:44.258986
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(None, variable_manager, loader)
    hostvars.set_host_variable(None, 'foo', 'bar')
    hostvars.set_host_variable(None, 'baz', 'qux')
    hostvars_vars = hostvars['localhost']
    assert set(hostvars_vars) == set(['foo', 'baz'])

# Generated at 2022-06-22 17:07:54.108595
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'baz', 'qux')

    hostvars_vars = hostvars['localhost']
    assert sorted(list(hostvars_vars)) == ['baz', 'foo']

# Generated at 2022-06-22 17:08:03.416699
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    assert hostvars.raw_get('localhost')['foo'] == 'bar'

    # Pickle and unpickle hostvars
    hostvars_pickled = pickle.dumps(hostvars)
    hostvars_unpickled = pickle.loads(hostvars_pickled)

    #

# Generated at 2022-06-22 17:08:12.984700
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    add_all_plugin_dirs()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-22 17:08:18.095958
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    add_all_plugin_dirs()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = Play().set_loader(loader)
    play_context.variable_manager = variable_manager

# Generated at 2022-06-22 17:08:27.100240
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    hostvars.set_host_variable('localhost', 'baz', 'qux')

    hostvars_vars = hostvars['localhost']
    assert set(hostvars_vars) == set(['foo', 'baz'])

# Generated at 2022-06-22 17:08:35.571917
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:08:43.261830
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a host that is not in the inventory
    assert hostvars['foo'] == AnsibleUndefined(name="hostvars['foo']")

    # Test with a host that is in the inventory
    assert hostvars['localhost'] == {}

    # Test with a host that is in the inventory and has variables