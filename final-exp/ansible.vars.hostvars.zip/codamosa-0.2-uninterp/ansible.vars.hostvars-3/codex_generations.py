

# Generated at 2022-06-22 17:00:09.808671
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a host that exists
    host_name = 'localhost'
    hostvars[host_name]
    assert hostvars[host_name] == hostvars.raw_get(host_name)

    # Test with a host that does not exist
    host_name = 'non-existent-host'

# Generated at 2022-06-22 17:00:18.079876
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:00:26.760809
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._variable_manager is variable_manager

    new_variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars.set_variable_manager(new_variable_manager)
    assert hostvars._variable_manager is new_variable_manager
    assert new_variable_manager._hostvars is hostvars

# Generated at 2022-06-22 17:00:37.879459
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')
    hostvars.set_nonpersistent_facts(host, {'foo': 'bar'})
    assert hostvars.raw_get('localhost')['foo'] == 'bar'

    hostvars.set_nonpersistent_facts(host, {'foo': 'baz'})

# Generated at 2022-06-22 17:00:46.353303
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with empty hostvars
    assert repr(hostvars) == "{}"

    # Test with non-empty hostvars
    inventory.hosts.append('localhost')
    variable_manager.set_host_variable('localhost', 'foo', 'bar')
    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-22 17:00:56.063883
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')
    hostvars.set_host_variable(host, 'foo', 'bar')
    assert hostvars.get(host.name).get('foo') == 'bar'

# Generated at 2022-06-22 17:01:05.076545
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test for undefined host
    assert isinstance(hostvars['undefined_host'], AnsibleUndefined)

    # Test for defined host
    assert isinstance(hostvars['localhost'], HostVarsVars)
    assert hostvars['localhost']['inventory_hostname'] == 'localhost'

# Generated at 2022-06-22 17:01:13.826199
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars['localhost'] is not undefined
    assert hostvars.raw_get('localhost') is not AnsibleUndefined

    # Test that hostvars['localhost'] is undefined
    assert hostvars.raw_get('non-existent-host') is AnsibleUndefined

# Generated at 2022-06-22 17:01:19.136866
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(hostvars) == 1
    assert len(hostvars) == len(inventory.hosts)

# Generated at 2022-06-22 17:01:23.168956
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')
    variable_manager.set_host_variable(host, 'foo', 'bar')

    assert hostvars.raw_get('localhost') == {'foo': 'bar'}

# Generated at 2022-06-22 17:01:43.649012
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test that raw_get returns AnsibleUndefined for non-existent host
    assert isinstance(hostvars.raw_get('non-existent'), AnsibleUndefined)

    # Test that raw_get returns dict for localhost
    assert isinstance(hostvars.raw_get('localhost'), dict)

    # Test that raw_get returns dict for localhost
    assert isinstance(hostvars.raw_get('localhost'), dict)

    # Test that raw_get returns dict for localhost

# Generated at 2022-06-22 17:01:51.549307
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import combine_vars

    add_all_plugin_dirs()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-22 17:02:02.870405
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-22 17:02:11.447153
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    hostvars = HostVars(inventory=inv, variable_manager=variable_manager, loader=loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:02:22.205362
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:02:27.879928
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

# Generated at 2022-06-22 17:02:33.997940
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']


# Generated at 2022-06-22 17:02:40.979321
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a host that exists
    hostvars['localhost']

    # Test with a host that does not exist
    try:
        hostvars['foo']
    except KeyError as e:
        assert e.args[0] == "hostvars['foo']"
    else:
        assert False, "KeyError not raised"

# Generated at 2022-06-22 17:02:50.577989
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    hostvars.set_host_variable('localhost', 'baz', 'qux')

    hostvars_vars = hostvars['localhost']
    assert hostvars_vars['foo'] == 'bar'
    assert hostvars_vars['baz'] == 'qux'

# Generated at 2022-06-22 17:02:56.484834
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined if host is not found
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars for existing host
    assert isinstance(hostvars['localhost'], HostVarsVars)

# Generated at 2022-06-22 17:03:22.287232
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    variable_manager = VariableManager(loader=loader)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'baz', 'qux')

    # Pickle hostvars and unpickle it
    import pickle
    hostvars_pickled = pickle.dumps(hostvars)
    hostvars_unpickled = pickle.loads

# Generated at 2022-06-22 17:03:29.320013
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that raw_get returns the same value as __getitem__
    # for a host that is in the inventory
    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars.raw_get('localhost') == hostvars['localhost']

    # Test that raw_get returns the same value as __getitem__
    # for a host that is not in the inventory
   

# Generated at 2022-06-22 17:03:38.071781
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:03:42.131062
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

# Generated at 2022-06-22 17:03:52.912829
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_env.HOME }}')))
        ]
    )

# Generated at 2022-06-22 17:03:59.588796
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}
    assert hostvars['localhost']['inventory_hostname'] == 'localhost'
    assert hostvars['localhost']['inventory_hostname_short'] == 'localhost'
    assert hostvars['localhost']['groups'] == []
    assert hostvars['localhost']['group_names'] == []
    assert hostvars['localhost']['omit']

# Generated at 2022-06-22 17:04:10.668024
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = Play().set_loader(loader)
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable('localhost', 'foo', 'bar')

    assert hostvars['localhost']['foo'] == 'bar'
   

# Generated at 2022-06-22 17:04:16.298526
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a host that exists
    host = inventory.get_host('localhost')
    variable_manager.set_host_variable(host, 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

    # Test with a host that does not exist

# Generated at 2022-06-22 17:04:27.593118
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {'inventory_hostname': 'localhost',
                                     'inventory_hostname_short': 'localhost'}

    assert hostvars['localhost']['inventory_hostname'] == 'localhost'
    assert hostvars['localhost']['inventory_hostname_short'] == 'localhost'

    assert hostvars['localhost']['inventory_hostname'] == 'localhost'
   

# Generated at 2022-06-22 17:04:39.367484
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host

    class TestCallback(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self.host_ok = {}
            self.host_unreachable = {}
            self.host_failed = {}


# Generated at 2022-06-22 17:04:54.014988
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 17:05:03.073167
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host("localhost")
    hostvars.set_host_variable(host, "foo", "bar")
    hostvars.set_host_variable(host, "baz", "qux")

    hostvars_vars = hostvars["localhost"]
    assert len(hostvars_vars) == 2
    assert "foo" in hostvars_vars
    assert "baz" in hostv

# Generated at 2022-06-22 17:05:10.639296
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars.raw_get('localhost')['foo'] == 'bar'

# Generated at 2022-06-22 17:05:19.847086
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # test for host that does not exist
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")

    # test for localhost
    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

    # test for host that exists
   

# Generated at 2022-06-22 17:05:27.478861
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'baz', 'qux')
    hostvars_vars = HostVarsVars(hostvars['localhost'], loader)

# Generated at 2022-06-22 17:05:37.138731
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        def v2_runner_on_ok(self, result, **kwargs):
            host = result._host
            print(json.dumps({host.name: result._result}, indent=4))

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-22 17:05:43.889850
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

    inventory.add_host('otherhost')
    assert list(hostvars) == ['localhost', 'otherhost']

# Generated at 2022-06-22 17:05:54.886308
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVarsVars
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import os

    # Create a fake inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    host = Host(name='localhost')
    inventory.add_host(host)

    # Create a fake variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a fake hostvars

# Generated at 2022-06-22 17:06:06.621381
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check that _loader and _hostvars attributes of VariableManager are
    # None before calling __setstate__
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Call __setstate__
    hostvars.__setstate__({'_inventory': inventory,
                           '_loader': loader,
                           '_variable_manager': variable_manager})

    # Check that

# Generated at 2022-06-22 17:06:11.079965
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']



# Generated at 2022-06-22 17:06:37.813231
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test case 1: hostvars['localhost']
    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars.raw_get('localhost') == {'foo': 'bar'}

    # Test case 2: hostvars['localhost']['foo']
    assert hostvars.raw_get('localhost')['foo'] == 'bar'

    # Test case 3: hostvars['localhost']['foo']['bar']
    hostvars.set_host_

# Generated at 2022-06-22 17:06:44.507776
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Pickle and unpickle hostvars
    hostvars_pickled = pickle.dumps(hostvars)
    hostvars_unpickled = pickle.loads(hostvars_pickled)

    # Check that unpickled hostvars has the same attributes as original
    assert hostvars._inventory == hostvars_unpickled._inventory
    assert hostvars._loader == hostvars_unpickled._

# Generated at 2022-06-22 17:06:50.555057
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:07:01.603304
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar

    loader = DataLoader()
    add_all_plugin_dirs()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = Play().set_loader(loader)
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostv

# Generated at 2022-06-22 17:07:09.876985
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # test with a host that exists
    hostvars_localhost = hostvars.raw_get('localhost')
    assert hostvars_localhost['inventory_hostname'] == 'localhost'

    # test with a host that does not exist
    hostvars_foobar = hostvars.raw_get('foobar')
    assert isinstance(hostvars_foobar, AnsibleUndefined)
    assert hostv

# Generated at 2022-06-22 17:07:19.865511
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert 'localhost' in hostvars
    assert 'localhost' in hostvars._inventory.hosts
    assert 'localhost' in hostvars._inventory.get_hosts()
    assert 'localhost' in hostvars._inventory.get_hosts(pattern='localhost')
    assert 'localhost' in hostvars._inventory

# Generated at 2022-06-22 17:07:30.561024
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_env.HOME }}')))
        ]
    )

# Generated at 2022-06-22 17:07:37.970986
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}

    variable_manager.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    assert hostvars['localhost'] == {'foo': 'bar'}

    variable_manager.set_host_variable(inventory.get_host('localhost'), 'foo', 'baz')

# Generated at 2022-06-22 17:07:43.775509
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:07:49.963508
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:08:30.452110
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined for non-existent host
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars for existing host
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that HostVars returns HostVarsVars for existing host

# Generated at 2022-06-22 17:08:40.646783
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns the same value as VariableManager.get_vars()
    # when the value is not a dictionary
    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

    # Test that HostVars returns the same value as VariableManager.get_vars()
    # when the value is a dictionary
    host

# Generated at 2022-06-22 17:08:46.206199
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test for host that does not exist
    assert hostvars.raw_get('localhost') == AnsibleUndefined(name="hostvars['localhost']")

    # Test for host that exists
    inventory.add_host(Host('localhost'))
    assert hostvars.raw_get('localhost')

# Generated at 2022-06-22 17:08:55.412973
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars['localhost'] returns a HostVarsVars instance
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that hostvars['localhost'] returns a HostVarsVars instance
    # even if the host is not in the inventory
    assert isinstance(hostvars['non-existent-host'], HostVarsVars)

    # Test that hostv

# Generated at 2022-06-22 17:09:06.322491
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}
    assert hostvars['localhost']['inventory_hostname'] == 'localhost'
    assert hostvars['localhost']['inventory_hostname_short'] == 'localhost'
    assert hostvars['localhost']['groups'] == ['ungrouped']
    assert hostvars['localhost']['group_names'] == ['ungrouped']
    assert hostvars

# Generated at 2022-06-22 17:09:10.665251
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:09:20.439238
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars.raw_get('localhost') == {}
    assert hostvars.raw_get('non-existent') == AnsibleUndefined(name="hostvars['non-existent']")

    variable_manager.set_nonpersistent_facts(inventory.get_host('localhost'), {'foo': 'bar'})
    assert hostvars.raw_get('localhost') == {'foo': 'bar'}


# Generated at 2022-06-22 17:09:30.274046
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:09:38.033554
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:09:44.802858
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test with a host that exists in the inventory
    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars.raw_get('localhost')['foo'] == 'bar'

    # Test with a host that does not exist in the inventory
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")