

# Generated at 2022-06-22 17:00:04.101733
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']


# Generated at 2022-06-22 17:00:08.013276
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:00:16.290747
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:00:25.991479
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-22 17:00:30.286319
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = Host(name='localhost')
    host.set_variable('ansible_ssh_host', '127.0.0.1')
    host.set_variable('ansible_ssh_port', '22')
    host.set_variable('ansible_ssh_user', 'root')

# Generated at 2022-06-22 17:00:36.811322
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_vars = hostvars['localhost']

    assert set(hostvars_vars) == set(hostvars_vars.keys())

# Generated at 2022-06-22 17:00:45.797264
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader)

    assert repr(hostvars) == '{}'

    inventory.add_host(host='test_host')
    assert repr(hostvars) == "{'test_host': {}}"

    inventory.set_variable(host='test_host', var='test_var', value='test_value')
    assert repr(hostvars) == "{'test_host': {'test_var': 'test_value'}}"

# Generated at 2022-06-22 17:00:57.054331
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined when host is not found
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns a dict when host is found
    assert isinstance(hostvars['localhost'], dict)

    # Test that HostVars returns a dict with expected keys

# Generated at 2022-06-22 17:01:00.739581
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:01:07.062946
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = Play()
    play_context._variable_manager = variable_manager
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_facts(inventory.get_host('localhost'), {'ansible_os_family': 'RedHat'})
    hostvars.set_

# Generated at 2022-06-22 17:01:18.573184
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

    inventory.add_host(host='localhost', group='ungrouped')
    assert repr(hostvars) == "{'localhost': {}}"

    inventory.set_variable(host='localhost', varname='foo', value='bar')
    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-22 17:01:23.492818
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Check that hostvars.raw_get('localhost') returns the same value as
    # hostvars['localhost']
    assert hostvars.raw_get('localhost') == hostvars['localhost']

# Generated at 2022-06-22 17:01:31.288686
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert len(list(hostvars)) == 1
    assert list(hostvars)[0].name == 'localhost'


# Generated at 2022-06-22 17:01:38.765982
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:01:45.637852
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that raw_get returns the same value as __getitem__
    # when the host is in the inventory
    host_name = 'localhost'
    hostvars.set_host_variable(inventory.get_host(host_name), 'foo', 'bar')
    assert hostvars.raw_get(host_name) == hostvars[host_name]

    # Test that raw_get returns the same

# Generated at 2022-06-22 17:01:49.478619
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:01:56.119200
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    import os
    import sys
    import json


# Generated at 2022-06-22 17:02:05.755309
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Test for a host that does not exist
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")

    # Test for a host that exists
    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 17:02:12.786241
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test for host that does not exist
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")

    # Test for host that exists
    inventory.add_host(Host(name='localhost'))
    assert hostv

# Generated at 2022-06-22 17:02:24.419296
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = Host(name='localhost')
    host.vars = {'foo': 'bar'}
    inventory.add_host(host)

    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-22 17:02:33.970173
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that raw_get returns the same data as __getitem__
    # when hostvars are not templated.
    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars.raw_get('localhost')['foo'] == 'bar'
    assert hostvars['localhost']['foo'] == 'bar'

    # Test that raw_get returns the same data

# Generated at 2022-06-22 17:02:41.394815
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost'}
    assert hostvars.raw_get('localhost') == hostvars.raw_get('127.0.0.1')
    assert hostvars.raw_get('localhost') == hostvars.raw_get('::1')
    assert hostvars.raw_get('localhost') == hostvars.raw

# Generated at 2022-06-22 17:02:48.237986
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

# Generated at 2022-06-22 17:02:57.821634
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:03:04.502309
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:03:13.497142
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Test __iter__
    assert list(hostvars) == ['localhost']

    # Test __len__
    assert len(hostvars) == 1

    # Test __contains__
    assert 'localhost' in hostvars
    assert '127.0.0.1' not in hostvars

    # Test __getitem__

# Generated at 2022-06-22 17:03:25.090066
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'
    assert hostvars.raw_get('localhost')['foo'] == 'bar'

    hostvars.set_host_variable('localhost', 'foo', 'baz')
    assert hostvars['localhost']['foo'] == 'baz'

# Generated at 2022-06-22 17:03:35.097681
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check that _loader and _hostvars attributes of VariableManager are
    # not set before calling __setstate__
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Call __setstate__
    hostvars.__setstate__({'_inventory': inventory, '_loader': loader, '_variable_manager': variable_manager})

    # Check that _loader and _host

# Generated at 2022-06-22 17:03:43.272246
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars._variable_manager._loader = None
    hostvars._variable_manager._hostvars = None

    hostvars.__setstate__({
        '_inventory': inventory,
        '_loader': loader,
        '_variable_manager': variable_manager,
    })

    assert hostvars._variable_manager._loader == loader
    assert hostvars._variable_manager._hostvars == hostv

# Generated at 2022-06-22 17:03:50.500198
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:04:06.892273
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ test_var }}')))
         ]
    )

# Generated at 2022-06-22 17:04:11.103239
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Create a HostVarsVars object
    variables = {'a': 1, 'b': 2, 'c': 3}
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)

    # Check that the iterator returns the expected values
    assert set(hostvarsvars) == set(variables)

# Generated at 2022-06-22 17:04:19.491919
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']


# Generated at 2022-06-22 17:04:29.303942
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test that HostVars returns AnsibleUndefined for non-existent host
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars for existing host
    assert isinstance(hostvars['localhost'], HostVarsVars)

# Generated at 2022-06-22 17:04:40.426650
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_hostname }}')))
        ]
    )

# Generated at 2022-06-22 17:04:50.483608
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert len(list(hostvars)) == 1
    assert list(hostvars)[0] == 'localhost'

# Generated at 2022-06-22 17:04:56.183788
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert len(list(hostvars)) == 1
    assert list(hostvars)[0] == 'localhost'

# Generated at 2022-06-22 17:05:03.743006
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'baz', 'qux')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'quux', 'quuz')


# Generated at 2022-06-22 17:05:11.279489
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')

    assert hostvars.raw_get('localhost')['foo'] == 'bar'

# Generated at 2022-06-22 17:05:18.723083
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'groups': {'all': ['localhost']}, 'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:05:37.140935
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}
    assert hostvars['localhost']['inventory_hostname'] == 'localhost'
    assert hostvars['localhost']['inventory_hostname_short'] == 'localhost'
    assert hostvars['localhost']['groups'] == ['all']
    assert hostvars['localhost']['group_names'] == ['all']

# Generated at 2022-06-22 17:05:44.180148
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 17:05:50.536709
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:05:56.742728
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars['localhost'] == {}

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost'] == {'foo': 'bar'}

    hostvars.set_host_variable('localhost', 'baz', 'qux')
    assert hostvars['localhost'] == {'foo': 'bar', 'baz': 'qux'}

    hostvars.set_host_variable('localhost', 'foo', 'quux')

# Generated at 2022-06-22 17:06:08.099922
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{hostvars[inventory_hostname]["foo"]}}')))
        ]
    )

# Generated at 2022-06-22 17:06:12.628283
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 17:06:17.721607
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test for host that does not exist
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")

    # Test for host that exists
    host = inventory.get_host('localhost')
    assert hostvars.raw_get('localhost') == variable_manager.get_vars(host=host, include_hostvars=False)

# Generated at 2022-06-22 17:06:28.078693
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check that _loader and _hostvars attributes of VariableManager are
    # not set.
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Check that __setstate__ method of HostVars sets _loader and _hostvars
    # attributes of VariableManager.
    hostvars.__setstate__(hostvars.__dict__)
    assert variable_manager._

# Generated at 2022-06-22 17:06:37.484731
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = Host(name='localhost')
    host.set_variable('foo', 'bar')
    inventory.add_host(host)

    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-22 17:06:44.349999
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

    hostvars.set_host_variable('localhost', 'foo', '{{ bar }}')
    hostvars.set_host_variable('localhost', 'bar', 'baz')
    assert hostvars['localhost']['foo'] == 'baz'



# Generated at 2022-06-22 17:07:04.494683
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test case: hostvars['localhost']
    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

    # Test case: hostvars['localhost']['foo']
    assert hostvars['localhost']['foo'] == 'bar'

    # Test case: hostvars['localhost']['foo']['bar']

# Generated at 2022-06-22 17:07:11.310833
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined if host is not found
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns a HostVarsVars object
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that HostVars returns a HostVarsVars object that contains
    # the hostvars for the host
   

# Generated at 2022-06-22 17:07:17.212178
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    hostvars = HostVars(inventory, VariableManager(loader=None), loader=None)
    assert repr(hostvars) == "{}"

    inventory.add_host(host='testhost')
    assert repr(hostvars) == "{'testhost': {}}"

# Generated at 2022-06-22 17:07:24.652275
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:07:31.001076
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:07:38.229035
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    # that contains the same variables as variable_manager.get_vars()
    assert hostvars['localhost'] == variable_manager.get_vars()

# Generated at 2022-06-22 17:07:48.360006
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')

    # Pickle and unpickle hostvars to simulate serialization
    # and deserialization of hostvars.
    import pickle
    hostvars = pickle.loads(pickle.dumps(hostvars))

    # Check that hostvars has been correctly restored
    assert hostvars.raw_get

# Generated at 2022-06-22 17:07:58.177607
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert repr(hostvars) == "{'localhost': {}}"

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-22 17:08:05.744837
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    hostvars.set_host_variable('localhost', 'baz', 'qux')

    hostvars_vars = hostvars['localhost']

    assert hostvars_vars['foo'] == 'bar'
    assert hostvars_vars['baz'] == 'qux'

# Generated at 2022-06-22 17:08:14.819261
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = Play()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(), play_context=play_context)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable('localhost', 'foo', 'bar')

# Generated at 2022-06-22 17:08:40.965648
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        def v2_runner_on_ok(self, result, **kwargs):
            host = result._host
            print(result._result)

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-22 17:08:51.771865
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('localhost') == {
        'inventory_hostname': 'localhost',
        'inventory_hostname_short': 'localhost',
        'groups': {'ungrouped': True},
        'group_names': ['ungrouped'],
        'omit': '__omit_place_holder__123',
    }


# Generated at 2022-06-22 17:08:55.886989
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:09:04.499938
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:09:12.942981
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars.raw_get returns AnsibleUndefined when host is not found
    host_name = 'non_existent_host'
    assert hostvars.raw_get(host_name) == AnsibleUndefined(name="hostvars['%s']" % host_name)

    # Test that hostvars.raw_get returns a dict when host is found
    host_name = 'localhost'

# Generated at 2022-06-22 17:09:23.079732
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = Host(name='localhost')
    host.vars = {'foo': 'bar'}
    inventory.add_host(host)

    assert hostvars['localhost']['foo'] == 'bar'
    assert hostvars['localhost']['inventory_hostname'] == 'localhost'

# Generated at 2022-06-22 17:09:29.731124
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Assert that _loader and _hostvars attributes of VariableManager
    # are not set.
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Assert that _loader and _hostvars attributes of VariableManager
    # are set after __setstate__ call.
    hostvars.__setstate__(hostvars.__getstate__())
    assert variable_manager

# Generated at 2022-06-22 17:09:41.793436
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test for host that does not exist
    host_name = 'host_that_does_not_exist'
    assert host_name not in hostvars
    assert hostvars.raw_get(host_name) == AnsibleUndefined(name="hostvars['%s']" % host_name)
    assert hostvars[host_name] == AnsibleUndefined(name="hostvars['%s']" % host_name)

    # Test for host that exists
    host_name = 'localhost'

# Generated at 2022-06-22 17:09:46.635429
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined when host is not found
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars for existing host
    assert isinstance(hostvars['localhost'], HostVarsVars)
