

# Generated at 2022-06-22 17:00:06.375836
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:00:11.396003
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}
    assert hostvars['localhost']['inventory_hostname'] == 'localhost'
    assert hostvars['localhost']['inventory_hostname_short'] == 'localhost'
    assert hostvars['localhost']['groups'] == ['ungrouped']
    assert hostvars['localhost']['group_names'] == ['ungrouped']
    assert hostvars

# Generated at 2022-06-22 17:00:20.141715
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test for host that does not exist
    assert isinstance(hostvars.raw_get('non-existent-host'), AnsibleUndefined)

    # Test for host that exists
    assert isinstance(hostvars.raw_get('localhost'), Mapping)

# Generated at 2022-06-22 17:00:23.016202
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

# Generated at 2022-06-22 17:00:29.666160
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'baz', 'qux')

    hostvars_vars = hostvars['localhost']
    assert len(hostvars_vars) == 2
    assert 'foo' in hostvars_vars

# Generated at 2022-06-22 17:00:38.941859
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Create a copy of hostvars and set _loader and _hostvars to None
    # to simulate the state of VariableManager after pickling.
    hostvars_copy = hostvars.__deepcopy__(memo={})
    hostvars_copy._variable_manager._loader = None
    hostvars_copy._variable_manager._hostvars = None

    # Restore the state of hostvars_copy and check if

# Generated at 2022-06-22 17:00:47.193177
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Assign _loader and _hostvars attributes to variable_manager
    variable_manager._loader = loader
    variable_manager._hostvars = hostvars

    # Pickle and unpickle hostvars
    hostvars_pickled = pickle.dumps(hostvars)
    hostvars_unpickled = pickle.loads(hostvars_pickled)

    # Check that _loader and _host

# Generated at 2022-06-22 17:00:55.125455
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:01:05.244496
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        def v2_runner_on_ok(self, result, **kwargs):
            host = result._host
            print(host.name)

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-22 17:01:14.132652
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)

    hostvars.set_host_variable(host=None, varname='foo', value='bar')
    hostvars.set_host_variable(host=None, varname='baz', value='{{ foo }}')

    assert hostvars.raw_get(host_name=None) == {'foo': 'bar', 'baz': '{{ foo }}'}
    assert hostvars[None] == {'foo': 'bar', 'baz': 'bar'}

# Generated at 2022-06-22 17:01:31.057908
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-22 17:01:42.237166
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-22 17:01:48.849896
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(list(hostvars)) == 1
    assert list(hostvars)[0].name == 'localhost'

# Generated at 2022-06-22 17:01:55.696748
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

    # Pickle and unpickle hostvars to simulate serialization and deserialization
    # of hostvars in multiprocessing.
    import pickle
    hostvars_pickled = pickle.dumps(hostvars)
    hostvars_unpickled = pick

# Generated at 2022-06-22 17:02:01.834414
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:02:11.072412
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:02:24.543667
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-22 17:02:35.250387
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that HostVars returns AnsibleUndefined for non-existent host
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars for existing host
    assert isinstance(hostvars['localhost'], HostVarsVars)



# Generated at 2022-06-22 17:02:42.025812
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='Hello World')))
             ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=DataLoader())

# Generated at 2022-06-22 17:02:52.379318
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}
    assert hostvars['localhost']['inventory_hostname'] == 'localhost'
    assert hostvars['localhost']['inventory_hostname_short'] == 'localhost'
    assert hostvars['localhost']['groups'] == ['all']
    assert hostvars['localhost']['group_names'] == ['all']

# Generated at 2022-06-22 17:03:06.510383
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that raw_get returns the same value as __getitem__
    # when the host is in the inventory
    hostvars['localhost'] = 'foo'
    assert hostvars.raw_get('localhost') == 'foo'

    # Test that raw_get returns the same value as __getitem__
    # when the host is not in the inventory
    assert hostvars.raw_get('foo') == Ans

# Generated at 2022-06-22 17:03:14.317459
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test for host that does not exist
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")

    # Test for localhost

# Generated at 2022-06-22 17:03:19.953761
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:03:28.119400
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

    inventory.add_host(host='localhost', group='ungrouped')
    assert repr(hostvars) == "{'localhost': {}}"

    inventory.set_variable(host='localhost', varname='foo', value='bar')
    assert repr(hostvars) == "{'localhost': {'foo': 'bar'}}"

# Generated at 2022-06-22 17:03:35.362209
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:03:41.917547
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 17:03:47.944429
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:03:53.940525
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:03:59.341772
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:04:09.675325
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    hostvars.set_host_variable('localhost', 'baz', 'qux')

    hostvars_vars = hostvars['localhost']

    assert set(hostvars_vars) == set(['foo', 'baz'])

# Generated at 2022-06-22 17:04:22.119173
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_version }}')))
        ]
    )

# Generated at 2022-06-22 17:04:31.183458
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader)

    # Test with a host that does not exist
    assert hostvars.raw_get('foobar') == AnsibleUndefined(name="hostvars['foobar']")

    # Test with a host that exists
    inventory.add_host(host='foobar')
    assert hostvars.raw_get('foobar') == {}

# Generated at 2022-06-22 17:04:39.942040
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')

    hostvars_vars = hostvars['localhost']
    assert(list(hostvars_vars) == ['foo'])

# Generated at 2022-06-22 17:04:54.288341
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('localhost') == {
        'inventory_hostname': 'localhost',
        'inventory_hostname_short': 'localhost',
        'groups': {'ungrouped': True},
        'omit': '__omit_place_holder__1234567890',
    }

# Generated at 2022-06-22 17:05:03.619510
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test if hostvars['localhost'] returns a HostVarsVars object
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test if hostvars['localhost'] returns a HostVarsVars object
    # with the same variables as the original hostvars['localhost']
    assert hostvars['localhost'] == hostvars['localhost']

    # Test if hostvars['localhost

# Generated at 2022-06-22 17:05:11.662007
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')

    hostvars_vars = hostvars['localhost']
    assert list(hostvars_vars) == ['foo']

# Generated at 2022-06-22 17:05:19.932404
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)


# Generated at 2022-06-22 17:05:25.740218
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(list(hostvars)) == 1
    assert list(hostvars)[0] == 'localhost'

# Generated at 2022-06-22 17:05:37.087544
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'baz', 'qux')

    hostvars_vars = hostvars.get('localhost')
    assert set(hostvars_vars) == set(['foo', 'baz'])

# Generated at 2022-06-22 17:05:40.850737
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:05:57.119549
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test for host that does not exist
    assert hostvars['non_existent_host'] == AnsibleUndefined(name="hostvars['non_existent_host']")

    # Test for host that exists
    assert hostvars['localhost'] == HostVarsVars(variable_manager.get_vars(host=inventory.get_host('localhost'), include_hostvars=False), loader)

# Generated at 2022-06-22 17:06:03.722974
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:06:11.941184
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars_vars = hostvars['localhost']
    assert isinstance(hostvars_vars, HostVarsVars)

    # Check that __iter__ returns an iterator
    assert hasattr(hostvars_vars.__iter__(), '__next__')

    # Check that __iter__ returns an iterator over the keys of the variables' dict

# Generated at 2022-06-22 17:06:17.205330
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that raw_get returns the same value as __getitem__
    # for the localhost
    hostvars_raw_get = hostvars.raw_get('localhost')
    hostvars_getitem = hostvars['localhost']
    assert hostvars_raw_get == hostvars_getitem

    # Test that raw_get returns the same value as __getitem__
    # for the non

# Generated at 2022-06-22 17:06:22.533881
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:06:30.969272
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars.raw_get('localhost') == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")

# Generated at 2022-06-22 17:06:38.173798
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:06:43.193895
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert 'localhost' in hostvars
    assert 'localhost' in list(hostvars)

# Generated at 2022-06-22 17:06:51.805180
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}}"

# Generated at 2022-06-22 17:06:59.100078
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 17:07:41.840851
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a host that exists in the inventory
    host = Host(name='localhost')
    host.vars = {'foo': 'bar'}
    inventory.add_host(host)
    assert hostvars.raw_get('localhost') == {'foo': 'bar'}

    #

# Generated at 2022-06-22 17:07:51.787187
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars.raw_get('localhost') == {}
    assert hostvars.raw_get('localhost') is not hostvars.raw_get('localhost')

    variable_manager.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    assert hostvars.raw_get('localhost') == {'foo': 'bar'}
    assert hostvars.raw_get('localhost') is not hostvars.raw_get('localhost')

# Generated at 2022-06-22 17:07:56.969274
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:08:05.098366
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_env.HOME }}')))
        ]
    )

# Generated at 2022-06-22 17:08:09.885548
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = Host(name='localhost')
    host.set_variable('foo', 'bar')
    inventory.add_host(host)

    assert hostvars.raw_get('localhost') == {'foo': 'bar'}

# Generated at 2022-06-22 17:08:19.805301
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Assign some values to attributes of hostvars
    hostvars._inventory = 'inventory'
    hostvars._loader = 'loader'
    hostvars._variable_manager = 'variable_manager'

    # Call __setstate__ to restore attributes of hostvars
    hostvars.__setstate__({'_inventory': 'inventory', '_loader': 'loader', '_variable_manager': 'variable_manager'})



# Generated at 2022-06-22 17:08:27.156830
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test with undefined host
    assert isinstance(hostvars['undefined_host'], AnsibleUndefined)

    # Test with defined host
    inventory.add_host(host='defined_host')
    assert isinstance(hostvars['defined_host'], HostVarsVars)

# Generated at 2022-06-22 17:08:33.992262
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())

    # Test that HostVars returns AnsibleUndefined if host is not found
    assert isinstance(hostvars['non-existent-host'], AnsibleUndefined)

    # Test that HostVars returns HostVarsVars for existing host
    assert isinstance(hostvars['localhost'], HostVarsVars)



# Generated at 2022-06-22 17:08:42.409258
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = Play()

    hostvars = HostVars(inventory, variable_manager, loader)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    assert isinstance(hostvars['localhost'], HostVarsVars)

    # Test that hostvars['localhost'] returns a HostVarsVars object
    # even if the host is

# Generated at 2022-06-22 17:08:52.712767
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create inventory, variable_manager and loader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Set variables for localhost
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')

    # Test raw_get
    assert hostvars.raw_get('localhost') == {'foo': 'bar'}

# Generated at 2022-06-22 17:09:37.997930
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 17:09:45.152294
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with empty inventory
    assert list(hostvars) == []

    # Test with non-empty inventory
    inventory.add_host(Host('localhost'))
    assert list(hostvars) == ['localhost']

    # Test with non-empty inventory and non-localhost host
    inventory.add

# Generated at 2022-06-22 17:09:56.225033
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Test that HostVars.__getitem__ returns AnsibleUndefined if host is not found
    assert isinstance(hostvars['localhost'], AnsibleUndefined)

    # Test that HostVars.__getitem__ returns HostVarsVars if host is found
    inventory.add_host(host='localhost')
    assert isinstance(hostvars['localhost'], HostVarsVars)