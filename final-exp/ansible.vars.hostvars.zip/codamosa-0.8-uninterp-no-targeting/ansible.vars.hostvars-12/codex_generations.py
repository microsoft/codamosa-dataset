

# Generated at 2022-06-21 09:27:40.144523
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    host_vars = HostVars(InventoryManager(loader=DataLoader(), sources=''),
                         VariableManager(),
                         DataLoader())

    host_vars._variable_manager.clear_facts()
    assert host_vars._variable_manager.get_facts() == {}

    host_vars.set_host_facts({}, {'foo': 'bar'})
    assert host_vars._variable_manager.get_facts() == {'foo': 'bar'}

    host_vars._variable_manager.clear_facts()
    assert host_vars._variable_manager.get_facts() == {}

# Generated at 2022-06-21 09:27:52.389282
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # Patch classes
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    class InventoryStub(Inventory):
        def __init__(self):
            # do no deepcopy _hosts to avoid infinite recursion
            hosts_property = Inventory.__dict__['hosts']
            inventory_deepcopy_copy_method(self, hosts_property)
            self._hosts = {}

    class VariableManagerStub(VariableManager):
        def __init__(self, loader, inventory):
            self._loader = loader
            self._hostvars = None
            self._inventory = inventory

        def get_vars(self, host, include_hostvars=True):
            hostvars = self._

# Generated at 2022-06-21 09:28:02.302673
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    # Setup the inventory
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader,
                                 variable_manager=variable_manager,
                                 host_list='localhost,')
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'baz', [1, 2, 3])

# Generated at 2022-06-21 09:28:13.122919
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    def mock_template(value, fail_on_undefined=True, static_vars=None):
        return value

    hostvars = HostVarsVars({'foo': 'bar'}, None)
    assert hostvars.__getitem__('foo') == 'bar'
    hostvars._vars = {'foo': {'bar': 'baz'}}
    assert hostvars.__getitem__('foo') == {'bar': 'baz'}

    hostvars._vars = {'foo': '{{bar}}'}
    # should use template() here
    hostvars._loader = None
    hostvars._templar = None
    assert hostvars.__getitem__('foo') == '{{bar}}'

    hostvars._vars = {'foo': '{{bar}}'}

# Generated at 2022-06-21 09:28:21.189905
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.hashes import InventoryHashes
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, sources='localhost,')
    hashed_inventory = InventoryHashes(inventory)

    hostvars = HostVars(hashed_inventory, None, loader)
    assert list(hostvars) == ["127.0.0.1"]


# Generated at 2022-06-21 09:28:30.374648
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import pickle
    import collections
    import random

    # Create random variables
    temp_vars = {}
    for i in xrange(10):
        temp_vars[i] = random.random()

    # Build a dict of (host, variables) to deepcopy
    vars_dict = {}
    for i in xrange(100):
        temp_hv = HostVars(None, None, None)
        temp_hv.set_host_variable(None, None, temp_vars)
        vars_dict[str(i)] = temp_hv

    # Deepcopy dict
    vars_dict2 = copy.deepcopy(vars_dict)

    # Check that dicts are not the same objects
    assert vars_dict != vars_dict2

    # Check that dicts have the same content


# Generated at 2022-06-21 09:28:41.464137
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    # Create a fake Host object
    class HostStub:
        def __init__(self, name):
            self.name = name

    host = HostStub("foo")

    # Create a fake Inventory object
    inventory = type("InventoryStub", (object,), {})
    inventory.hosts = {'foo': host}

    # Create a fake VariableManager object
    variable_manager = type("VariableManagerStub", (object,), {})

    # Create a HostVars object
    hostvars = HostVars(inventory, variable_manager, type("LoaderStub", (object,), {}))

    # HostVars should be empty at the moment
    assert dict(hostvars) == {}

    # Set a variable through the set_host_facts method

# Generated at 2022-06-21 09:28:48.312391
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    invent = InventoryManager(loader=None, sources='')
    vars_mgr = VariableManager(loader=None, inventory=invent)
    test_play = Play().load({
        'name': 'test_play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': []
    }, variable_manager=vars_mgr, loader=None)
    hostvars = HostVars(invent, vars_mgr, loader=None)

    # Check that calling __iter__ on empty inventory yields no host
    invent.hosts = []
    assert list(hostvars) == []

    # Check that calling __

# Generated at 2022-06-21 09:28:56.365022
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    class A():
        def __init__(self, a):
            self.a = a
        def __iter__(self):
            return self.a.__iter__()

    variables = A((1, 2, 3))
    loader = object()
    hvv = HostVarsVars(variables, loader)

    assert 1 in hvv
    assert 2 in hvv
    assert 3 in hvv
    assert 4 not in hvv



# Generated at 2022-06-21 09:29:02.105715
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create Mock objects
    class VariableManager:
        def __init__(self):
            self.host_vars_files = dict()
            self.group_vars_files = dict()
            self.vars_plugins = list()
            self.host_vars = dict()
            self.group_vars = dict()
            self.extra_vars = dict()
            self.set_host_variable = MagicMock()

    class Host:
        def __init__(self, name):
            self.name = name
            self.vars = dict()

    class Inventory:
        def __init__(self):
            self.hosts_cache = dict()
            self.groups_list = list()


# Generated at 2022-06-21 09:29:10.343582
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    hostvars = HostVars(inventory, inventory.get_variable_manager(), loader=DataLoader())
    hostvars.__repr__()



# Generated at 2022-06-21 09:29:21.936487
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory,
                        variable_manager=variable_manager,
                        loader=loader)

    host_vars = combine_vars(
        hostvars.raw_get("localhost"),
        hostvars.raw_get("foo")
    )

# Generated at 2022-06-21 09:29:30.976916
# Unit test for method __len__ of class HostVarsVars

# Generated at 2022-06-21 09:29:39.604449
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inv_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/plugins/inventory'
    local_loader = DataLoader()
    local_inventory = InventoryManager(loader=local_loader, sources=inv_dir)
    local_inventory.parse_sources()
    local_vars = HostVars(local_inventory, variables=None, loader=local_loader)
    assert len(local_vars) == 3

# Generated at 2022-06-21 09:29:48.012383
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.plugins import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVars

    variable_manager = VariableManager()
    variable_manager._loader = vars_loader
    variable_manager._hostvars = None
    inventory = InventoryManager(loader=None, sources=[], variable_manager=variable_manager)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert variable_manager._loader == hostvars._loader
    assert variable_manager._hostvars is None

    hostvars.set_variable_manager(variable_manager)
    assert variable_manager._hostvars == hostvars

# Generated at 2022-06-21 09:29:58.590853
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    # The code below creates a class that mimics a dictionary. The
    # dictionary is built without any particular order.
    # Note -- this is a Mapping, not a MutableMapping
    class mydict(Mapping):
        def __init__(self, a, b, c):
            self._mykeys = [a, b, c]
            self._myvalues = [a, b, c]

        def __getitem__(self, key):
            return self._myvalues[self._mykeys.index(key)]

        def __iter__(self):
            for var in self._mykeys:
                yield var

        def __len__(self):
            return len(self._mykeys)

    # Create mydict object
    mydictVar = mydict('aaa', 'bbb', 'ccc')

    # Create HostVars

# Generated at 2022-06-21 09:30:08.545314
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy

    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(variable_manager=variable_manager, loader=None, inventory=inventory)

    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')

    hostvars_copy = deepcopy(hostvars)
    assert len(hostvars) == len(hostvars_copy)

    foo = hostvars_copy.raw_get('localhost')['foo']
    assert foo == 'bar'

# Generated at 2022-06-21 09:30:21.520467
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import os
    import tempfile
    import shutil
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVars

    class TestHostVars(unittest.TestCase):

        def setUp(self):
            self._dir = tempfile.mkdtemp()
            self._inventory_path = os.path.join(self._dir, 'hosts')
            self._loader = DataLoader()

            self._hostvars = HostVars(inventory=None, variable_manager=None, loader=self._loader)

        def tearDown(self):
            shutil.rmtree(self._dir)


# Generated at 2022-06-21 09:30:30.120357
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars is not None

    import copy
    newhostvars = copy.deepcopy(hostvars)

    assert newhostvars is not None
    assert newhostvars is not hostvars
    assert newhostvars._inventory is not None
    assert newhostvars._inventory is not hostvars._inventory
    assert newhostvars._variable_manager is not None
    assert newhostvars._variable_manager is not hostvars._variable_manager


# Generated at 2022-06-21 09:30:41.573258
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    data = {'foo': 'bar'}
    hostvars.set_host_variable(host='foo', varname='hostvars', value=HostVarsVars(data, loader))
    assert hostvars['foo']['foo'] == 'bar'

    data = {'bar': {'foo': 'bar'}}

# Generated at 2022-06-21 09:30:47.102623
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    pass

# Generated at 2022-06-21 09:30:54.029046
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from collections import Iterable
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.plugins import vars as vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    inventory = Inventory(loader=DataLoader())

    host1 = inventory.add_host(host='host1')
    host2 = inventory.add_host(host='host2')

    variable_manager = VariableManager(loader=vars_loader, inventory=inventory)

    play = Play().load({}, variable_manager=variable_manager, loader=DataLoader())

    host_vars = HostVars(inventory, variable_manager, DataLoader())

    assert isinstance(host_vars, Iterable)


# Generated at 2022-06-21 09:31:05.358467
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Instantiate HostVars and set state
    h = HostVars(None, None, None)
    h.__setstate__({'_inventory': None, '_loader': None, '_variable_manager': None})
    assert h._loader == None
    assert h._inventory == None
    assert h._variable_manager == None

    # Instantiate VariableManager and set state
    v = VariableManager()
    v.__setstate__({'_data': {'foo': 'bar'}})
    assert v._data == {'foo': 'bar'}

    # Instantiate HostVars, set state, set VariableManager and set state
    h = HostVars(None, None, None)
    h.__setstate__({'_inventory': None, '_loader': None, '_variable_manager': v})
    v.__

# Generated at 2022-06-21 09:31:15.012012
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())

    # Should return empty list because inventory is empty
    assert list(hostvars) == []

    # Update inventory to contain one host
    inventory.hosts = ['localhost']

    # Should return host name
    assert list(hostvars) == ['localhost']


# Generated at 2022-06-21 09:31:22.323615
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    """
    :return: None
    """
    # test case 1 - log_host_file_entries is None

# Generated at 2022-06-21 09:31:27.975452
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import copy
    import os
    import sys
    import tempfile

    from ansible.errors import AnsibleError
    from ansible.inventory import Inventory
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    # Prepare a fake inventory and get a mapping of hostvars
    class FakeOptions(Mapping):
        def __getitem__(self, key):
            ''' Since the options object is a mapping, we get the value from attributes '''
            return getattr(self, key)


# Generated at 2022-06-21 09:31:40.400186
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    MyInventory = InventoryManager(loader=None, sources='')
    MyInventory.hosts = {}
    MyHost1 = Host(name="test1")
    MyHost2 = Host(name="test2")
    MyInventory.hosts = dict()
    MyInventory.hosts.update({"test1": MyHost1})
    MyInventory.hosts.update({"test2": MyHost2})
    play_context = PlayContext()
    MyVariableManager = VariableManager(loader=None, inventory=MyInventory, version_info=play_context.version_info)

# Generated at 2022-06-21 09:31:49.376109
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # Fixtures
    inventory = '''
localhost ansible_connection=local
host1
host2
'''

    loader = DictDataLoader({
        "inventory": InventoryData.load(inventory, "", "")
    })

    inventory = InventoryManager(loader=loader, sources=['inventory'])
    facts_cache = inventory.get_facts()

    # Test HostVars.set_host_facts()
    hv = HostVars(inventory=inventory, variable_manager=None, loader=loader)

    # host1
    host1 = hv._find_host("host1")
    hv.set_host_facts(host=host1, facts=dict(myfact1="myvalue1"))
    assert facts_cache.get("host1", {}).get("myfact1") == "myvalue1"

    # host

# Generated at 2022-06-21 09:32:01.605442
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import ansible.playbook.play
    import ansible.playbook.task

    class MyVariableManager(object):

        def __init__(self):
            self._vars = dict()

        def get_vars(self, host=None, include_hostvars=True):
            if host:
                return self._vars.get(host)
            else:
                return {}

        def set_host_variable(self, host, varname, value):
            self._vars[host] = {varname: value}

        def set_host_facts(self, host, facts):
            self._vars[host] = {'ansible_local': facts}

    class MyInventory(object):

        def __init__(self):
            self.hosts = {"new_host": object()}


# Generated at 2022-06-21 09:32:12.979765
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager, HostVarsVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=("tests/vars/test_hostvars.yml",))
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    hv = HostVars(inventory, variable_manager, loader)

    variable_manager.set_host_variable('test01', 'test_attr', 'test01')

# Generated at 2022-06-21 09:32:28.994078
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    class Inventory:
        hosts = {'host1', 'host2'}

    inventory = Inventory()
    hostvars = HostVars(inventory=inventory,
                        variable_manager=None,
                        loader=None)
    assert len(hostvars) == len(inventory.hosts)


# Generated at 2022-06-21 09:32:40.278620
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    class FakeInventory():
        def __init__(self):
            self.hostvars = {'test_host': 'test_host_value'}

    class FakeVariableManager():
        def __init__(self, hostvars):
            self._loader = None
            self._hostvars = hostvars

        def get_vars(self, host, include_hostvars):
            return self._hostvars

        def __getstate__(self):
            return {}

        def __setstate__(self, state):
            self.__dict__.update(state)

    inventory = FakeInventory()
    variable_manager = FakeVariableManager(inventory.hostvars)
    hostvars = HostVars(inventory, variable_manager, 'fake_loader')

    # test_hostvars holds _loader and _hostv

# Generated at 2022-06-21 09:32:50.078245
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    # Create some test data
    data = dict(
        inventory_hostname = 'example.org',
        ansible_ssh_host = 'example.org',
        ansible_ssh_user = 'root',
        play_hosts = [
            'example.org'
        ],
        groups = dict(
            group1 = [
                'example.org',
            ]
        ),
        ansible_play_hosts = [
            'example.org'
        ],
        group_names = [
            'group1'
        ]
    )

    # Create dummy instances of required classes
    class Inventory(object):
        def __init__(self, data):
            self.hosts = data['play_hosts']
            self.groups = data['groups']


# Generated at 2022-06-21 09:32:59.638289
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    vars_ = {'foo': 'bar'}
    hostvarsvars = HostVarsVars(variables=vars_.copy(), loader=None)
    # check that the iterator was created
    assert iter(hostvarsvars) is not None
    # check that it has one element
    assert len(list(iter(hostvarsvars))) == 1
    # check that the element is the key that we set in vars_
    assert list(iter(hostvarsvars))[0] == list(vars_.keys())[0]


# Generated at 2022-06-21 09:33:12.380585
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import json

    def run_test(test_data):
        variables = test_data['input']['variables']
        class DummyLoader(object):
            def __init__(self):
                self.tests = test_data
            def get_basedir(self):
                return '/path/to/ansible/root'
            def path_dwim(self, possible_path):
                return self.tests['input']['basedir_files'].get(possible_path, None)
        loader = DummyLoader()
        vars = HostVarsVars(variables, loader)

        output = {}
        for var in vars:
            output[var] = vars[var]
        want = json.loads(test_data['want'])
        assert output == want

    # test load_file no_

# Generated at 2022-06-21 09:33:18.065483
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    """
    Make sure a repr of HostVars does not mutate the values
    """
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    host = inventory.get_host('localhost')
    variable_manager.set_host_variable(host, 'somevar', 'someval')
    assert repr(hostvars) == "{'localhost': {'somevar': 'someval'}}"
    assert hostv

# Generated at 2022-06-21 09:33:26.157691
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Attribute _loader should be set by __setstate__
    assert(hostvars._loader is not None)

    # Attribute _hostvars should be set by __setstate__
    assert(hostvars._variable_manager._hostvars is not None)

# Generated at 2022-06-21 09:33:36.829731
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import MutableMapping

    class FakeHost(MutableMapping):
        def __init__(self, name, vars=None):
            self._name = name
            if vars is None:
                self._vars = dict()
            else:
                self._vars = vars

        def set_variable(self, key, value):
            self._vars[key] = value

        def get_name(self):
            return self._name

        def get_vars(self):
            return self._vars



# Generated at 2022-06-21 09:33:39.792514
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    # Test for constructor of class HostVarsVars with an empty dict
    hvv = HostVarsVars({}, loader=None)
    return hvv

# Generated at 2022-06-21 09:33:47.232206
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-21 09:34:17.254750
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    hosts = [Host(name='foo'), Host(name='bar')]
    inventory = InventoryManager(hosts=hosts)
    vars_cache = {}
    variable_manager = VariableManager(vars_cache)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert 'foo' in hostvars
    assert 'bar' in hostvars
    assert 'baz' not in hostvars
    assert 'localhost' in hostvars



# Generated at 2022-06-21 09:34:28.693452
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory import Inventory

    inventory = Inventory()
    backup_loader = AnsibleUndefined('backup_loader')
    backup_variable_manager = AnsibleUndefined('backup_variable_manager')

    hostvars = HostVars(inventory=inventory,
                        loader=backup_loader,
                        variable_manager=backup_variable_manager)

    assert hostvars._inventory == inventory
    assert hostvars._loader == backup_loader
    assert hostvars._variable_manager == backup_variable_manager
    assert hostvars._variable_manager._hostvars == hostvars
    assert hostvars._variable_manager._loader == hostvars._loader

    assert 'ansible_version' in STATIC_VARS
    assert 'ansible_play_hosts' in STATIC_VARS

# Generated at 2022-06-21 09:34:37.147540
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = None
    variable_manager = VariableManager(loader=loader)
    variable_manager._fact_cache = dict(foo='bar')
    variable_manager._fact_cache['faa'] = dict(foo='bar', baz='faz')
    changes = None
    variable_manager._fact_cache['faa']['changes'] = changes
    variable_manager._internal_cache = dict()
    internal_cache = dict(foo='bar')
    variable_manager._internal_cache['faa'] = internal_cache
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['localhost,'])

# Generated at 2022-06-21 09:34:50.813201
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    host = Host(name='localhost')
    inventory.add_host(host)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
    assert len(hostvars) == 1
    assert hostvars['localhost'] is not None

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    hostvars.set_inventory(inventory)
    assert len(hostvars) == 0

# Generated at 2022-06-21 09:34:59.657076
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from units.mock.loader import DictDataLoader

    class Foo():
        def __init__(self, var):
            self.var = var

    vars = {'foo': Foo({'x': 1, 'y': 2})}
    loader = DictDataLoader(dict())

    res = []
    for k in HostVarsVars(vars, loader):
        res.append(k)
    assert res == ['foo']

    res = []
    for k in HostVarsVars(vars, loader)['foo'].var:
        res.append(k)
    assert res == ['x', 'y']

# Generated at 2022-06-21 09:35:04.031402
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(hostvars) == 1

    hostvars._inventory.hosts.pop()
    assert len(hostvars) == 0

# Generated at 2022-06-21 09:35:15.324399
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import sys
    import os
    import json
    import ansible.plugins.loader
    import ansible.plugins.inventory
    import ansible.vars
    import ansible.constants

    ansible.plugins.loader.add_directory(os.path.join(os.path.dirname(__file__), '../test/inventory/'))
    inventory_loader = ansible.plugins.loader.inventory_loader
    inventory = ansible.inventory.Inventory(inventory_loader, None)
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.VariableManager(loader, inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    inventory.set_host_variable('hosts', 'myhostvar', 'myhostval')
    inventory

# Generated at 2022-06-21 09:35:18.629250
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = dict(foo='bar')
    loader = 'AnsibleLoader'
    hostvars = HostVarsVars(variables=variables, loader=loader)
    assert hostvars['foo'] == 'bar'

# Generated at 2022-06-21 09:35:23.389530
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    data = dict(foo='bar', baz=dict(foobar='baz'))
    loader = DictDataLoader({})
    assert set(HostVarsVars(data, loader)) == set(['foo', 'baz'])



# Generated at 2022-06-21 09:35:28.694421
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    loader = Mock(Mock())

    vars = HostVarsVars({'foo': 'bar', 'baz': 'qux'}, loader)
    for i in vars:
        pass

    assert vars._vars == {'foo': 'bar', 'baz': 'qux'}
    assert vars._loader == loader

# Generated at 2022-06-21 09:36:28.370567
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    '''
    Unit test to validate that HostVarsVars.__getitem__ performs templating
    before returning items. HostVarsVars.__getitem__ is used when processing
    variables and is the most common way of accessing variables.

    Example::

      inventory_hostname_short: "{{ inventory_hostname | regex_replace('^(?:.*?)[^a-zA-Z0-9]', '') }}"
    '''

    from ansible.plugins.loader import filter_loader
    for f in filter_loader.all():
        filter_loader.add(f, filter_loader.get(f, class_only=True))

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-21 09:36:36.019465
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_vars = hostvars['localhost']

    # Test whether hostvars_vars is a Mapping and an Iterable
    assert isinstance(hostvars_vars, Mapping)
    assert hasattr(hostvars_vars, '__iter__')

    # Test whether it is

# Generated at 2022-06-21 09:36:46.034884
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    host = Host(name="localhost")
    inventory.add_host(host)
    play = Play().load(dict(hosts=['localhost'], vars=dict(var='value')), loader=DataLoader(), variable_manager=VariableManager())
    hostvars = HostVars(inventory, variable_manager=play.get_variable_manager(), loader=play._loader)
    repr(hostvars)

# Generated at 2022-06-21 09:36:52.937517
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    from ansible.template import Templar
    from ansible.module_utils.six import StringIO
    from ansible.errors import AnsibleUndefinedVariable

    templar = Templar(loader=None)
    fh = StringIO("""
    #!/usr/bin/python
    print("{{lookup('pipe','echo hello world')}}")
    """)
    variables = dict()
    variables['var'] = HostVarsVars(dict(lookup=templar.do_lookup_run), loader=None)

    templar = Templar(loader=None)
    new_vars = HostVarsVars(variables, loader=None)
    templar.template("{{var.lookup('pipe','echo hello world')}}", new_vars, fh, None, None)

    contents = fh.getvalue

# Generated at 2022-06-21 09:37:04.195969
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager('/etc/ansible/hosts')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, None)
    len_hostvars = len(hostvars)

    hosts = HostVarsVars(hostvars, None)
    len_hosts = len(hosts)

    if len_hostvars != len_hosts:
        assert False, "FAILED: len(HostVarsVars) != len(HostVars)"


# Generated at 2022-06-21 09:37:11.054079
# Unit test for constructor of class HostVars
def test_HostVars():
    import os
    import sys
    import ansible.utils
    import ansible.constants as C
    import ansible.inventory
    import ansible.vars
    import ansible.playbook.play

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser

    p = InventoryParser(filename=os.path.join(os.path.dirname(__file__), '../tests/inventory'))
    i = ansible.inventory.Inventory(loader=p)
    i.subset('all')
    h = Host(name='foobar')
    i.add_host(h)
    g = Group(name='foobargroup')
    i.add_group(g)
    g.add_host(h)