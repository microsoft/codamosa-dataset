

# Generated at 2022-06-21 09:27:32.941685
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import MutableMapping

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = Play().set_loader(loader).set_variable_manager(variable_manager)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert isinstance(hostvars.raw_get('localhost'), MutableMapping)

# Generated at 2022-06-21 09:27:36.691155
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():

    class FakeVars(dict):
        def __repr__(self):
            return "FAKE REPR"

    variables = FakeVars()
    variables['foo'] = 'bar'
    variables['baz'] = 'quz'

    loader = FakeVars()
    loader['foo'] = 'bar'
    loader['baz'] = 'quz'

    hostvars = HostVarsVars(variables, loader)
    assert repr(hostvars) == "FAKE REPR"

# Generated at 2022-06-21 09:27:46.671714
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory('inventory_dir')

    variables = {}
    loader = None
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')

    facts = {'ansible_python_version': '2.7.5', 'ansible_architecture': 'x86_64'}

    hostvars.set_host_facts(host, facts)

    assert variables['ansible_python_version'] == facts['ansible_python_version']
    assert variables['ansible_architecture'] == facts['ansible_architecture']

# Generated at 2022-06-21 09:27:48.314575
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():

    class FakeLoader():
        pass

    variables = {
        'key1': 'value1',
        'key2': 'value2',
    }

    hvv = HostVarsVars(variables, FakeLoader())

    expected = "{'key1': 'value1', 'key2': 'value2'}"
    assert expected == repr(hvv)

# Generated at 2022-06-21 09:27:58.457906
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Host
    from ansible.vars import VariableManager

    mock_loader = "mock_loader"
    mock_inventory = "mock_inventory"
    mock_variable_manager = VariableManager(loader=mock_loader)
    mock_host = Host("mock_host")

    # Test for KeyError on unknown host
    h = HostVars(mock_inventory, mock_variable_manager, mock_loader)
    h.set_host_variable(mock_host, "a", "A")
    assert h.raw_get(mock_host) == {"a": "A"}
    assert h.raw_get("unknown_host") == AnsibleUndefined(name="hostvars['unknown_host']")

# Generated at 2022-06-21 09:28:05.704193
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    # Create fake inventory
    # It is necessary to disable cache because it is not initialized properly
    class FakeInventory(object):
        def __init__(self):
            self.hosts = {}
            self.cache = False

        def get_host(self, host_name):
            return self.hosts[host_name]

    from ansible import constants
    from ansible.vars.manager import VariableManager
    from ansible.vars.host_variable import HostVariable
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # Create fake loader
    class FakeLoader(object):
        pass

    inventory = FakeInventory()

# Generated at 2022-06-21 09:28:16.122135
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    case_data = [
        {
            'input_data': {'foo': 'bar'},
            'input_var': 'foo',
            'expected_return_value': True,
        },
        {
            'input_data': {'foo': 'bar'},
            'input_var': 'baz',
            'expected_return_value': False,
        },
        {
            'input_data': {'foo': 'bar'},
            'input_var': 'foobar',
            'expected_return_value': False,
        },
    ]
    for case in case_data:
        actual_return_value = HostVarsVars(case['input_data'], None).__contains__(case['input_var'])
        assert actual_return_value is case['expected_return_value']

# Generated at 2022-06-21 09:28:20.532802
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    inventory = Inventory(loader=DataLoader(), variable_manager=variable_manager, host_list='localhost')
    hostvars = HostVars(inventory, variable_manager=variable_manager, loader=DataLoader())
    hostvars._inventory = None
    hostvars.set_inventory(inventory)
    assert hostvars._inventory == inventory


# Generated at 2022-06-21 09:28:29.944794
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    import ansible.playbook.included_file

    class DummyLoader(object):
        pass

    class DummyVariableManager(object):
        def __init__(self):
            self._hostvars = HostVars(None, self, DummyLoader())
            self._loader = DummyLoader()

    class DummyInventory(object):
        def __init__(self, hosts=None):
            if hosts:
                self._hosts = hosts
            else:
                self._hosts = {'host1': None, 'host2': None}

        def get_host(self, host_name):
            return self._hosts.get(host_name)

        def _hosts_cache(self):
            return self._hosts

    class DummyHost(object):
        pass


# Generated at 2022-06-21 09:28:41.240975
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import copy
    from ansible.playbook import Playbook
    from ansible.vars import VariableManager

    path = './test_hostvars.yml'
    pb = Playbook.load(path, variable_manager=VariableManager(), loader=None)
    hosts = pb.get_hosts()
    hv = HostVars(hosts, VariableManager(), loader=pb._loader)
    hv.set_variable_manager(VariableManager())

    def hv_contains(host):
        return hv.__contains__(host)

    test_host_test1 = hv_contains('test1')
    test_host_test2 = hv_contains('test2')
    test_host_test3 = hv_contains('test3')
    test_host_test4 = hv

# Generated at 2022-06-21 09:28:54.924667
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VariableManager

    loader = None
    variables = {}
    hostvars = HostVarsVars(variables=variables, loader=loader)

    # test 1
    variables = dict(a='a')
    hostvars = HostVarsVars(variables=variables, loader=loader)
    assert len(hostvars) == 1

    # test 2
    variables = dict(a='a', b='b')
    hostvars = HostVarsVars(variables=variables, loader=loader)
    assert len(hostvars) == 2

    # test 3
    variables = dict(a='a', b='b', c='c')

# Generated at 2022-06-21 09:29:00.875680
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.inventory.manager import InventoryManager

    inv_path = '../../inventory'
    manager = InventoryManager(loader=None, sources=[inv_path])
    hostvars = HostVars(manager, None, None)

    for host in hostvars:
        for var in hostvars[host]:
            print(var)


# Generated at 2022-06-21 09:29:11.600531
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    '''
    Make sure set_host_facts updates facts, but not hostvars.
    '''
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    host1 = Host('host1')

    inventory = InventoryManager(['localhost'])
    inventory.add_host(host1)
    inventory.clear_pattern_cache()

    var_mgr = VariableManager(loader=None, inventory=inventory, version_info=dict(git_commit='TEST'))

    hostvars = HostVars(inventory, var_mgr, loader=None)

    var_mgr.set_host_variable(host1, 'foo', 'bar')

# Generated at 2022-06-21 09:29:16.409073
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():

    orig_inventory = object()
    new_inventory = object()

    hv = HostVars(orig_inventory, None, None)
    assert hv._inventory is orig_inventory

    hv.set_inventory(new_inventory)
    assert hv._inventory is new_inventory

# Generated at 2022-06-21 09:29:25.347269
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # pylint: disable=unused-variable
    from ansible.plugins.loader import connection_loader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.path import unfrackpath
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    vault_password = 'secret'
    loader = None
    variable_manager = None
    inventory = None
    hostvars = None

    unfrackpath_orig = unfrackpath
    @staticmethod
    def unfrackpath_custom(path, follow=True):
        if path.endswith('local'):
            return path
        return unfrackpath_orig(path, follow)


# Generated at 2022-06-21 09:29:36.668957
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    import ansible.inventory.host
    from ansible.vars.manager import VariableManager

    inventory = ansible.inventory.Inventory()
    variables = dict(foo='bar')
    localhost = ansible.inventory.host.Host(name='localhost')
    localhost.set_variable('foo', 'bar')
    inventory.add_host(localhost)
    variable_manager = VariableManager(loader=None, inventory=inventory, cache=variables)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    hostvars.set_variable_manager(variable_manager)

    # Copy the original object and make sure that the copy is equal to
    # the original
    hostvars_copy = copy.deepcopy(hostvars)
    assert hostvars == hostvars_copy

# Generated at 2022-06-21 09:29:41.702096
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    play = Play().load({
        'hosts': 'localhost',
        'tasks': [{'debug': {'msg': '{{ ansible_processor_cores }}'}}],
    }, variable_manager=None, loader=None)

    inventory = InventoryManager(loader=None, sources='localhost')
    inventory.add_play(play)

    tc = HostVars(inventory=inventory, variable_manager=None, loader=None)

    assert 'localhost' in tc

# Generated at 2022-06-21 09:29:46.957599
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert hasattr(hostvars, "__len__")
    assert len(hostvars) == 1


# Generated at 2022-06-21 09:29:57.958674
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    import json
    import os
    import sys

    testinventory = os.path.join(os.path.dirname(__file__), '..', 'inventory')
    inv_file = os.path.join(testinventory, 'hosts')

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[inv_file])

# Generated at 2022-06-21 09:30:07.460941
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import variable_manager_loader

    host = Host(name='test_host')
    inventory = InventoryManager(hosts=[host])
    variable_manager = variable_manager_loader.get('variable_manager')
    variable_manager.set_inventory(inventory)
    play = Play().load({}, variable_manager=variable_manager, loader=None)
    assert deepcopy(play._variable_manager.hostvars) == play._variable_manager.hostvars

# Generated at 2022-06-21 09:30:16.170662
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():

    class MockInventory():

        def get_host(host_name):
            return None

        hosts = []

    mock_inv = MockInventory()
    mock_vm = HostVars(mock_inv, None, None)

    assert 'localhost' not in mock_vm
    assert 1 not in mock_vm


# Generated at 2022-06-21 09:30:26.898638
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    vars = {
        'ansible_distribution': 'Fedora',
        'ansible_os_family': 'RedHat',
        'ansible_distribution_major_version': 22
    }

    loader = DataLoader()
    inventory = [Host(name='localhost', vars=vars)]

    hv = HostVars(inventory, VariableManager(loader=loader), loader)
    hv['localhost']
    assert vars['ansible_distribution'] == hv['localhost']['ansible_distribution']
    assert vars['ansible_os_family'] == hv

# Generated at 2022-06-21 09:30:34.841151
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.base import Base
    from copy import deepcopy

    inventory = Inventory('/tmp/foo')
    variable_manager = VariableManager(loader=Base(), inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, Base())

    playbook = Play()
    playbook.vars_prompt = []
    playbook.roles = [Role()]

    playbook_copy = deepcopy(playbook)

    assert playbook_copy.vars_prompt == []
    assert playbook_copy.roles == [Role()]

    playbook.vars_prompt = ['foo']

# Generated at 2022-06-21 09:30:47.138137
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # Create inventory
    inv_host = Host(name="testhost")
    inventory = InventoryManager(hosts=[inv_host])

    # Create HostVars
    vars_host = Host(name="testhost", inventory=inventory)
    variable_manager = VariableManager(hostvars=[vars_host], loader=None)
    loader = None
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create expected hostvars
    hostvars_expected = {}
    hostvars_expected[vars_host] = {}
    hostvars_expected[vars_host]["inventory_hostname"] = "testhost"

    # Create hostv

# Generated at 2022-06-21 09:30:49.180793
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.plugins.loader import vars_loader

    loader = vars_loader.VarsModule()
    variables = {'foo': 'bar', 'baz': 'you are {{ foo }}'}

    v = HostVarsVars(variables, loader)
    assert 'you are bar' in repr(v)

# Generated at 2022-06-21 09:31:02.103804
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    # we need an inventory object to create hostvars object
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    data_loader = DataLoader()
    inventory = Inventory(loader=data_loader, variable_manager=None, host_list='tests/inventory')

    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)

    # create hostvars for all hosts in inventory
    hostvars = HostVars(inventory, variable_manager, data_loader)

    # test assign of hostvars to variable_manager
    assert hostvars._variable_manager == variable_manager
    assert variable_manager._hostvars == hostvars

    # test assign of loader to variable_manager

# Generated at 2022-06-21 09:31:08.147898
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # We need to create an inventory and variable manager for a test
    # because HostVars requires them both.
    inventory = InventoryManager(host_list=[('localhost', dict(a=1, b=2)), ('foo', dict(c=3))])
    variable_manager = VariableManager()

    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars.__contains__('localhost')
    assert not hostvars.__contains__('local')


# Generated at 2022-06-21 09:31:17.891397
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():

    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    group = Group('all')
    group.vars = {'hoge': 'piyo', 'hogehoge': 'piyopiyo'}
    host = Host('host1')
    host.vars = {'hoge': 'foo', 'hogehoge': 'foofoo'}
    host.groups = [group]

    variable_manager = VariableManager()
    variable_manager.add_group_vars(group, group.vars)

# Generated at 2022-06-21 09:31:20.672894
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    variables = {'myvar': 'myvalue'}
    hostvars = HostVars(None, None, None)

    data = {'myvar': hostvars}
    data = copy.deepcopy(data)

    assert data['myvar'] is hostvars

# Generated at 2022-06-21 09:31:28.248822
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    def _load_inventory(path):
        loader = DataLoader()
        inventory = InventoryManager(loader=loader, sources=path)
        return inventory

    inventory = _load_inventory("../../tests/inventory")
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # the previous inventory doesn't have any host
    assert(len(hostvars) == 0)

    new_inventory = _load_inventory("../../tests/inventory/dynamic_inventory.py")
    hostvars.set_inventory(new_inventory)

    # the new inventory has one host
    assert(len(hostvars) == 1)

# Generated at 2022-06-21 09:31:52.088562
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.add_host('test1.example.com')

    hostvars.set_host_facts(host, {'foo': 'bar'})
    assert hostvars[host.name]['foo'] == 'bar'

    hostvars.set_host_facts(host, {'baz': 'buz'})
    assert hostvars[host.name]['baz'] == 'buz'


# Generated at 2022-06-21 09:31:58.520492
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    hostvars = HostVars(InventoryManager(loader=loader), VariableManager(loader=loader), loader=loader)
    assert 'test' in hostvars
    assert 'test' in hostvars['test']

# Generated at 2022-06-21 09:32:07.423991
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.template import Templar
    from ansible.module_utils.six import PY2

    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])

    templar = Templar(loader=loader, variables={'omit_token': 'OMITTED'})
    if PY2:
        templar._available_variables = frozenset()
    else:
        templar._available_variables = frozenset()

    var = {'foo': 'bar'}
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader)
    hostvars._variable

# Generated at 2022-06-21 09:32:16.970709
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy

    from ansible.vars.manager import VariableManager
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    loader_mock = mock.MagicMock()
    inventory_mock = mock.MagicMock()

    variable_manager = VariableManager(loader=loader_mock, inventory=inventory_mock, use_task_vars=False)
    variable_manager.set_host_variable('host1', 'foo', 'bar')
    variable_manager.set_host_variable('host1', 'foo_complex', {'a': 1, 'b': AnsibleUnsafeText(b'c')})
    variable_manager.get_vars(host=inventory_mock.get_host.return_value, include_hostvars=True)

    hostvars = HostVars

# Generated at 2022-06-21 09:32:29.097048
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager

    old_loader = None
    old_hostvars = None

# Generated at 2022-06-21 09:32:40.369905
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inv_data = b'''
     localhost ansible_connection=local ansible_python_interpreter="/usr/bin/env python"
    '''
    inventory = InventoryManager(loader=loader, sources=b'localhost,' + inv_data)
    variables = wrap_var(dict(ansible_python_interpreter='/usr/bin/env python'))
    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info=dict(ANSIBLE_VERSION=dict(full='2.6.0')))

# Generated at 2022-06-21 09:32:43.651636
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    data = {'a': 1, 'b': 2, 'c': {'x': 'y'}}
    test_dict = HostVarsVars(data, loader=None)
    assert data == test_dict

# Generated at 2022-06-21 09:32:44.503467
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({'a': 1, 'b': 2}, None)
    assert set(hvv) == set('ab')

# Generated at 2022-06-21 09:32:52.331863
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    def _get_hostvars():
        loader = DataLoader()
        inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
        mgr = dict()
        for host in inventory.get_hosts():
            mgr[host.name] = dict(subset_0={"k1": "1", "k2": "2", "k3": "3"})

        return HostVars(inventory, mgr, loader)

    hv = _get_hostvars()
    assert len(hv) == 1
    for host in hv:
        assert len(hv[host]) == 1

# Generated at 2022-06-21 09:33:02.990987
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.plugins.loader import filter_loader, module_loader
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    # hosts as dict
    hosts = {
        "localhost": {
            "host_name": "localhost",
            "ansible_connection": "local",
            "gather_facts": "no",
            "test_variable": "success",
        }
    }

    # Static variables

# Generated at 2022-06-21 09:33:25.608846
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.config.manager import ConfigManager
    from ansible.inventory import Inventory
    from ansible.template import Templar
    config_manager = ConfigManager()
    loader = config_manager.loader
    inventory = Inventory(loader=loader, host_list=[])
    variable_manager = config_manager.get_variable_manager()

    # test with variables is a dict
    host = inventory.add_host('testhost')
    variables = dict(ansible_host='testhost')
    templar = Templar(loader=loader)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars.set_host_variable(host=host, varname='ansible_host', value=variables)
    hostvar = hostvars['testhost']

# Generated at 2022-06-21 09:33:34.677049
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    import copy
    hostvars_copy = copy.deepcopy(hostvars)

    assert hostvars == hostvars_copy

# Generated at 2022-06-21 09:33:42.543121
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    hosts = [Host("test1")]
    # Method set_nonpersistent_facts expects Host instance, not Hostname
    hosts[0].name = "test1.example.com"
    facts = {"foo": 123, "bar": 456}

    hv = HostVars(inventory=None, variable_manager=VariableManager(loader=None))
    hv.set_nonpersistent_facts(hosts[0], facts)
    assert hv.raw_get("test1.example.com") == facts

# Generated at 2022-06-21 09:33:49.294451
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    hostvars_vars = HostVarsVars({'key1': 'val1', 'key2': 'val2'}, DataLoader())
    assert len(hostvars_vars) == 2
    hostvars_vars = HostVarsVars({'key1': 'val1', 'key2': 'val2'}, DataLoader())
    assert len(hostvars_vars) == 2

# Generated at 2022-06-21 09:34:01.352349
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy

    # Do not use real inventory or variable manager because we do not care
    # about the contents, but need to have something to pass to the
    # constructor.
    fake_inv = {}
    fake_vm = {}

    hv = HostVars(fake_inv, fake_vm, None)

    hv.set_host_variable("foo", "bar", "baz")

    # Copy variables dict of 'foo' so we can modify it and check
    # that the original was not modified.
    foo_vars = copy.deepcopy(hv.get("foo"))
    foo_vars["foo_updated"] = "updated"

    assert "foo_updated" not in hv.get("foo")

    # Now check the same but with variables dict of the whole HostVars object.
    hv_vars = copy

# Generated at 2022-06-21 09:34:05.004609
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager

    h = HostVars(None, VariableManager())
    h.set_variable_manager(VariableManager())

# Generated at 2022-06-21 09:34:16.400473
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = DummyInventory(loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader, variable_manager)

    hv = HostVars(inventory, variable_manager, loader)
    play_context = PlayContext(variable_manager=variable_manager)

    # Verify that HostVars is deepcopied and its values are not
    # deepcopied. It happened because variables' dicts that contain
    # HostVars were deepcopied in method __deepcopy__ of VariableManager.
    # This bug

# Generated at 2022-06-21 09:34:22.979157
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import os
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class Loader():
        def __init__(self):
            pass

        def list_templates(self):
            return []

        def get_basedir(self, name):
            return os.getcwd()

    hostvars = HostVars(
        InventoryManager(
            loader=Loader(),
            host_list=os.path.join(os.getcwd(), 'tests/inventory')),
        VariableManager(
            loader=Loader()),
        Loader())

    assert 'foo' in hostvars
    assert 'bar' in hostvars

    # test that the templating engine is run, when the variable is a string

# Generated at 2022-06-21 09:34:34.044556
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import os
    import pickle
    import tempfile
    import shutil

    def create_VariableManager(loader):
        from ansible.playbook.play_context import PlayContext
        from ansible.vars import VariableManager

        play_context = PlayContext()
        variable_manager = VariableManager(loader=loader, play_context=play_context)
        return variable_manager

    def create_Loader(cwd):
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager

        loader = DataLoader()
        loader.set_basedir(cwd)
        return loader

    def create_Inventory(loader, variable_manager):
        from ansible.inventory.manager import InventoryManager

        inventory = InventoryManager(loader=loader, sources=['localhost,'])
        variable

# Generated at 2022-06-21 09:34:47.303681
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    import os
    import tempfile

    loader = DataLoader()
    tmpdir = tempfile.mkdtemp()

    inventory = """
    [all:vars]
    foo=1
    """

    filename = os.path.join(tmpdir, 'test_HostVars_set_host_variable')
    open(filename, 'w').write(inventory)


# Generated at 2022-06-21 09:35:31.774904
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.inventory.host import Host

    host = Host()
    host.set_variable('foo', 'bar')
    hostvars_vars = HostVarsVars(host.vars, None)

    assert len(hostvars_vars) == 1

# Generated at 2022-06-21 09:35:39.960510
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # pylint: disable=unused-variable
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    # prepare inventory and variable manager for test
    inv = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inv)

    # reserve public attribute _hostvars of variable manager
    # to avoid side effect on other test cases
    _hostvars = variable_manager._hostvars

    # get HostVars object
    hostvars = variable_manager._hostvars

    # prepare host object
    localhost = inv.get_host('localhost')

    # set up expected results
    expected_hostvars = dict(foo='bar')
    expected_hostvars_template = dict(foo='{{ foo }}')

    # Remove

# Generated at 2022-06-21 09:35:49.585916
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Test data
    inventory_path = './test/unit/inventory'
    host = 'localhost'
    hostvars_template = 'hostvars[\'%s\']' % host
    hostvars_key = 'hostvars[\'%s\']' % host
    filename = 'test_inventory_%s.yml' % host

    # Initialize objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=inventory_path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create instance of class HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-21 09:35:57.832810
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    import unittest
    import mock

    class Test_HostVarsVars(unittest.TestCase):

        def setUp(self):
            class MockAnsibleLoader:
                def __init__(self, variable_manager):
                    self.vm = variable_manager
            # mock _loader and _variable_manager attributes
            self.mock_loader = MockAnsibleLoader(mock.Mock())
            self.mock_variable_manager = mock.Mock()
            self.mock_variable_manager.get_vars.return_value = {'var1': 'var1_value', 'var2': 'var2_value'}
            self.mock_variable_manager._loader = self.mock_loader

# Generated at 2022-06-21 09:36:04.147324
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.plugins.loader import plugin_loader

    variables = {
        "foo": "bar",
        "baz": "{{ foo }}",
        "qux": "{{ baz }}",
    }
    loader = plugin_loader.PluginLoader()
    hostvars_vars = HostVarsVars(variables, loader)

    assert hostvars_vars['foo'] == variables['foo']
    assert hostvars_vars['qux'] == variables['qux']

# Generated at 2022-06-21 09:36:11.304908
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.hostvars import HostVars
    import ansible.vars.hostvars
    import mock

    # module Inventory
    def get_host(self, name):
        if name == 'localhost':
            return 'localhost'
        else:
            return None
    # end of module Inventory

    with mock.patch('ansible.vars.hostvars.Inventory.get_host', get_host):
        # create object of Inventory class
        inv = ansible.vars.hostvars.Inventory()

        # create object of VariableManager class
        varman = ansible.vars.hostvars.VariableManager()

        # create object of HostVars class
        hostvars = HostVars(inv, varman, None)

# Generated at 2022-06-21 09:36:21.125959
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 09:36:29.209507
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = 'fake loader'
    variable_manager = VariableManager()
    variable_manager._loader = loader
    inventory = InventoryManager(loader=loader, sources=())

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.__setstate__(hostvars.__getstate__())

    assert hostvars._variable_manager._loader == loader
    assert hostvars._variable_manager._hostvars == hostvars

# Generated at 2022-06-21 09:36:36.456664
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    i = iter(hostvars)
    assert isinstance(i, type(iter([])))

    assert isinstance(hostvars, Mapping)
    assert hasattr(hostvars, '__iter__')

    assert isinstance(hostvars, HostVars)
    assert hasattr(hostvars, '_inventory')
    assert hasattr(hostvars, '_loader')

# Generated at 2022-06-21 09:36:45.914569
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
   from ansible.inventory import Inventory
   from ansible.plugins.loader import plugins
   from ansible.vars import VariableManager

   inventory = Inventory(loader=plugins.v2_loader)
   inventory.clear_pattern_cache()
   variable_manager = VariableManager(loader=plugins.v2_loader)
   variable_manager.extra_vars = {'test': 'value'}
   hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=plugins.v2_loader)
   hostvars.set_nonpersistent_facts(host=None, facts={'test': 'value'})
   assert hostvars.raw_get(host_name='localhost')['test'] == 'value'