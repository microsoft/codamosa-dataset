

# Generated at 2022-06-21 09:27:24.036739
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    v = HostVarsVars(dict(a=1, b=2, c=3), None)
    assert len(v) == 3



# Generated at 2022-06-21 09:27:35.639758
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    '''
    The __repr__ method of class HostVarsVars uses the __getitem__ method to
    expand the variables, and writes the result to a string.
    '''
    def test_func1(var1):
        return var1 + "bar"
    test_func1.expects_file_args = False
    test_func1.__annotations__ = {"return": str}

    class FakeLoader:
        tests = {'test_func1': test_func1}

    variables = {"var1": "foo_",
                 "var2": test_func1,
                 "var3": ['a', 1, None, "var1"]}
    host_vars_vars = HostVarsVars(variables, FakeLoader())

# Generated at 2022-06-21 09:27:43.196246
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    path = 'inventory.yml'

    inventory = InventoryManager(loader=None, sources=path)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    inventory.set_variable_manager(variable_manager)

    assert isinstance(inventory, InventoryManager)

    path2 = 'inventory2.yml'

    inventory2 = InventoryManager(loader=None, sources=path2)
    variable_manager2 = VariableManager(loader=None, inventory=inventory2)

    inventory2.set_variable_manager(variable_manager2)

    assert isinstance(inventory2, InventoryManager)


# Generated at 2022-06-21 09:27:55.254358
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # pylint: disable=unused-variable

    # This is a very simple unit test, which checks if a set_variable_manager
    # method of class HostVars works as expected.

    # Create a loader
    loader = DictDataLoader({
        'group_vars/all': '',
        'group_vars/ungrouped': '',
        'host_vars/localhost': '',
    })

    # Create the inventory
    inventory = Inventory(loader=loader, host_list=[])
    host = inventory.get_host(name='localhost')
    # Create a variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # Create a hostvars object
    hostvars = HostVars(inventory, variable_manager, loader)
    assert variable_manager._hostvars is host

# Generated at 2022-06-21 09:28:04.004430
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():

    import ansible.inventory.manager

    # Create an empty inventory
    inventory = ansible.inventory.manager.InventoryManager(loader=None, sources=None)

    # Create an empty variable manager
    variable_manager = ansible.vars.manager.VariableManager()

    # Create an empty loader
    loader = ansible.parsing.dataloader.DataLoader()

    # Create HostVars object
    host_vars = HostVars(inventory, variable_manager, loader)

    # Create new inventory
    inventory2 = ansible.inventory.manager.InventoryManager(loader=None, sources=None)

    # Set inventory
    host_vars.set_inventory(inventory2)

    # Check if inventory has been set
    if host_vars._inventory != inventory2:
        raise AssertionError()

    # Check

# Generated at 2022-06-21 09:28:09.745793
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import copy
    hvv = HostVarsVars(
        variables={'foo': '{{ bar }}', 'bar': 'baz', 'che': '{{ alt }}', 'alt': 'qux'},
        loader=None
    )
    assert copy.deepcopy(list(hvv)) == ['foo', 'bar', 'che', 'alt']


# Generated at 2022-06-21 09:28:18.207542
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    class MockDict(MutableMapping):
        def __init__(self):
            self.data = {}

        def __getitem__(self, key):
            return self.data[key]

        def __setitem__(self, key, value):
            self.data[key] = value

        def __delitem__(self, key):
            del self.data[key]



# Generated at 2022-06-21 09:28:28.191317
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import ansible.loader
    import ansible.variable_manager
    loader = ansible.loader.DataLoader()
    variable_manager = ansible.variable_manager.VariableManager(loader=loader)

    foo = {
        'bar': '{{ baz }}',
        'baz': 'baz'
    }
    variables = HostVarsVars(foo, loader=loader)

    # foo is not changed after __repr__
    first = str(variables)
    assert(first == "{'baz': 'baz', 'bar': '{{ baz }}'}")
    second = str(variables)
    assert(second == first)

    # bar will be changed after __repr__
    assert(first != "{'baz': 'baz', 'bar': 'baz'}")
    foo['baz']

# Generated at 2022-06-21 09:28:36.227054
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    from ansible.plugins.loader import vars_loader

    class DummyLoader:
        def __init__(self):
            pass

    dummy_loader = DummyLoader()
    variables = {
        'foo': '{{ bar }}',
        'bar': 'baz',
    }
    hostvarsvars = HostVarsVars(variables=variables, loader=dummy_loader)
    assert hostvarsvars['foo'] == 'baz'

# Generated at 2022-06-21 09:28:39.356705
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {
        'var1': 'foo',
        'var2': 'bar',
    }
    hostvarsvars = HostVarsVars(variables, None)
    assert set(hostvarsvars) == set(variables)

# Generated at 2022-06-21 09:28:46.251870
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({'a': 1, 'b': 2}, loader=None)
    assert sorted(list(hvv.__iter__())) == ['a', 'b']


# Generated at 2022-06-21 09:28:54.510151
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # Mock up the inventory as used in ansible-playbook
    class Inventory(object):
        def __init__(self):
            self.hosts = [ 'foo', 'bar' ]

        def get_host(self, host_name):
            if host_name in self.hosts:
                return host_name
            else:
                return None

    class VariableManager(object):
        def __init__(self):
            self._loader = None
            self._hostvars = None

        def get_vars(self, host=None, include_hostvars=True):
            if host is None:
                return {}
            else:
                return {'ansible_%s' % host: True}


# Generated at 2022-06-21 09:29:07.165903
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor import playbook_executor

    class Options():
        connection = 'local'
        module_path = None
        forks = 10
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        verbosity = 3

    class PlayContext():
        def __init__(self):
            self.network_os = 'ios'
            self.remote_addr = None
            self.remote_user = 'remote_user'
            self.password = None
            self.port = None
            self.private_key_

# Generated at 2022-06-21 09:29:14.728626
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    var_manager = VariableManager()
    hostvars = HostVars(inventory=None, variable_manager=var_manager, loader=None)
    host_name = 'test_host'
    host = Host(host_name)
    fact_name = 'ansible_foo'
    fact_value = 'bar'
    facts = { fact_name: fact_value }

    # Check fact 'ansible_foo' is not set yet
    assert fact_name not in hostvars.raw_get(host_name)

    # Set non-persistent facts
    hostvars.set_nonpersistent_facts(host, facts)

    # Check fact 'ansible_foo' is set

# Generated at 2022-06-21 09:29:21.178645
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.hostvars import HostVars
    input_hostvars = {'host1': {'hostvars': {'foo': 'bar'}}}
    HostVars = HostVars(None, None, None)
    assert repr(HostVars) == repr(input_hostvars)


# Generated at 2022-06-21 09:29:28.413305
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from io  import BytesIO
    import pickle

    # Create instance of HostVars
    hv = HostVars({'localhost': {'ansible_connection': 'local'}}, None, None)

    # Serialize instance of HostVars to BytesIO
    bio = BytesIO()
    pickle.dump(hv, bio)

    # Deserialize instance of HostVars from BytesIO
    bio.seek(0)
    hv = pickle.load(bio)

    # Check that __setstate__ is called
    assert hv._variable_manager._hostvars is hv, "__setstate__ is not called"

# Generated at 2022-06-21 09:29:38.307312
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from mock import Mock, patch
    hostvars = HostVars(Mock(), Mock(), Mock())
    inventory = Mock()
    vm = Mock()
    vm._hostvars = hostvars
    inventory.hosts = [Mock(), Mock()]
    # Test when the variable manager holds a reference to the old inventory
    inventory.hosts[0].vars = {'a': 'b'}
    inventory.hosts[0].host_name = 'host 1'
    inventory.hosts[1].vars = {'a': 'c'}
    inventory.hosts[1].host_name = 'host 2'

    vm.get_vars.side_effect = lambda host: host.vars
    hostvars.set_variable_manager(vm)


# Generated at 2022-06-21 09:29:46.306378
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import copy

    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    hostvars = HostVars(None, VariableManager(), None)
    host = Host(name='localhost')
    hostvars.set_host_facts(host, {'myvar': 'myvalue'})

    first_run = copy.deepcopy(hostvars.raw_get('localhost'))
    second_run = copy.deepcopy(hostvars.raw_get('localhost'))

    # Facts should be available for all subsequent runs
    assert first_run['myvar'] == 'myvalue'
    assert second_run['myvar'] == 'myvalue'

# Generated at 2022-06-21 09:29:49.047496
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    loader = None
    v = {}
    hostvars_vars = HostVarsVars(v, loader)
    assert 'hostvars_vars_test__contains__' in hostvars_vars



# Generated at 2022-06-21 09:29:58.884136
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible import cli
    from ansible.cli import CLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=('localhost,'))
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # add variable
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')

    # get variable
    assert hostvars['localhost']['foo'] == 'bar'

    inventory.add_host(host=CLI.get_host_option(), group='testgroup')
    hostvars.set

# Generated at 2022-06-21 09:30:10.882381
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    host_vars = HostVars({}, None)
    assert not host_vars.__contains__('localhost')
    assert not host_vars.__contains__('not_localhost')
    # the following test will succeed only if the
    # inventory is empty
    host = 'localhos'
    assert host_vars.__contains__(host)

# Generated at 2022-06-21 09:30:23.151015
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = None

    # Initialize HostVars with initial value of _variable_manager
    hostvars = HostVars(inventory=[], variable_manager=variable_manager, loader=loader)

    # Assign new instance of variable manager to _variable_manager
    variable_manager2 = VariableManager()
    hostvars.set_variable_manager(variable_manager2)

    # Check that _variable_manager has been updated in hostvars
    assert hostvars._variable_manager == variable_manager2
    assert hostvars._variable_manager is not variable_manager

    # Check that _hostvars has been updated in variable_manager
    assert variable_manager2._hostvars is hostvars

# Generated at 2022-06-21 09:30:27.695595
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory import Inventory
    inventory = Inventory(loader=None)

    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=None)

    inventory_test = Inventory(loader=None)
    hostvars.set_inventory(inventory_test)

    assert hostvars._inventory == inventory_test

# Generated at 2022-06-21 09:30:35.313236
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Prepare objects required to initialize HostVars object
    class InventoryMock(object):
        def get_host(self, host_name):
            return None

    class LoaderMock(object):
        def __init__(self):
            self._loaded_files = []

        def set_basedir(self, basedir):
            pass

        def set_collection_playbook_paths(self, collection_playbook_paths):
            pass

        def add_dynamic_module(self, path, name, mod_args, mod_kwargs):
            pass

        def add_cache(self, path, mod_name, mod_args, mod_kwargs, module_vars=None):
            pass

        def module_cache_terminated(self, path=None, name=None):
            return False


# Generated at 2022-06-21 09:30:47.769596
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.module_utils.common._collections_compat import Mapping

    class MockVariableManager(object):
        def __init__(self, vars):
            self._vars = vars
            # These attributes are needed for methods __getstate__ and __setstate__
            self._loader = None
            self._hostvars = None

        def get_vars(self, host=None, include_hostvars=True):
            return self._vars

        def set_host_variable(self, host, varname, value):
            pass

        def set_nonpersistent_facts(self, host, facts):
            pass

        def set_host_facts(self, host, facts):
            pass

    class MockInventory(object):
        def __init__(self):
            self.hosts = ['localhost']

# Generated at 2022-06-21 09:30:54.210072
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.template import Templar
    # Prepare data
    inventory = Inventory(loader=None)
    host1 = inventory.get_host("host1")
    host2 = inventory.get_host("host2")
    # hostvars example from documentation

# Generated at 2022-06-21 09:31:03.622392
# Unit test for constructor of class HostVars
def test_HostVars():
    import ansible.inventory
    import ansible.parsing.dataloader
    import ansible.vars.manager

    loader = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.Inventory(loader)
    variable_manager = ansible.vars.manager.VariableManager(loader)

    vars_cache = HostVars(inventory, variable_manager, loader)

    assert vars_cache._inventory == inventory
    assert vars_cache._loader == loader
    assert vars_cache._variable_manager == variable_manager
    assert variable_manager._hostvars == vars_cache

# Generated at 2022-06-21 09:31:13.126165
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    data = {'a': '{{b}}', 'b': 'c'}
    loader = 'loader'
    hostvars_vars = HostVarsVars(data, loader)
    assert len(hostvars_vars) == 2

    assert 'c' in hostvars_vars
    assert hostvars_vars['a'] == 'c'

    assert 'b' in hostvars_vars
    assert hostvars_vars['b'] == 'c'

    assert hostvars_vars.__repr__() == '{\'a\': \'c\', \'b\': \'c\'}'



# Generated at 2022-06-21 09:31:21.138397
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Variables
    variables = dict(a=dict(b="c", d=[dict(a=1, b=2), dict(c=3, d=4)]))
    loader = None

    # Init HostVarsVars
    host_vars_vars = HostVarsVars(variables, loader)

    # Check method __getitem__ of class HostVarsVars
    # Case1: var = a
    var = 'a'
    result = host_vars_vars[var]
    assert(result == variables[var])

    # Case2: var = a.b
    var = 'a.b'
    result = host_vars_vars[var]
    assert(result == variables['a']['b'])

    # Case3: var = a.d.[0].a
    var

# Generated at 2022-06-21 09:31:27.704125
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    inventory = Group('test_group')
    loader = 'loader'
    variable_manager = VariableManager(loader=loader)
    host = Host('test_host')
    inventory.add_host(host)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert not isinstance(repr(hostvars), AnsibleUndefined)

# Generated at 2022-06-21 09:31:50.266608
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostname = 'test_host'
    test_inventory = InventoryManager(loader=loader, sources='')
    test_inventory.add_host(hostname)
    hostvars.set_inventory(test_inventory)
    assert test_inventory.list_hosts()[0] == hostname



# Generated at 2022-06-21 09:32:01.967079
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))

    hostvars = HostVars(inventory, inventory.get_variable_manager(), loader)
    assert repr(hostvars) == '{}'

    inventory.add_host(host='testhost', group='testgroup')
    assert repr(hostvars) == "{'testhost': AnsibleUndefined(name='hostvars[''testhost'']')}"

    inventory.set_variable(host='testhost', var='testvar', value=1)

# Generated at 2022-06-21 09:32:08.102546
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    """
    >>> import copy
    >>> hv = HostVars(None, None, None)
    >>> hv['example.com'] = {'foo': 42, 'bar': [1, 2]}
    >>> copy.deepcopy({'foo': hv['example.com']['foo']})
    {'foo': 42}
    """
    pass

# Generated at 2022-06-21 09:32:14.181025
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    class loader:
        def __init__(self):
            pass
        def get_basedir(self):
            return "/tmp/ansible1"
        def load_from_file(self, filename, cache=False, unsafe=False, show_content=True, show_filename=True, cleanup=True):
            return ""

    hvv = HostVarsVars(variables={"foo": "Foo"}, loader=loader())
    assert hvv["foo"] == "Foo"

# Generated at 2022-06-21 09:32:20.292159
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # Password is templated, so test to make sure it is redacted
    # with many spaces so that it is not shown in error messages.
    data = {
        "foo": "bar",
        "password": "12345678",
    }
    variables = HostVarsVars(data, loader=None)
    assert repr(variables) == "{'foo': 'bar', 'password': '************'}"

# Generated at 2022-06-21 09:32:32.906734
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.playbook.hosts import Host
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, sources=None)
    host = Host(name='localhost')
    host.set_variable('ansible_ssh_host', '127.0.0.1')
    host.set_variable('ansible_ssh_port', 2222)
    host.set_variable('ansible_ssh_user', 'vagrant')
    host.set_variable('ansible_ssh_pass', 'vagrant')
    host.set_variable('ansible_connection', 'ssh')
    inventory.add_host(host)

    hostvars = HostVars(inventory, variable_manager, None)


# Generated at 2022-06-21 09:32:43.651244
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    hv = HostVars(None, vm, None)

    vm.set_host_variable(None, 'foo', 'bar')
    hv.set_nonpersistent_facts(None, {'foo': 'baz'})
    assert vm.get_vars(include_hostvars=False)['foo'] == 'baz'

    vm = VariableManager()
    hv = HostVars(None, vm, None)

    vm.set_host_variable(None, 'foo', 'bar')
    vm.set_nonpersistent_facts(None, {'foo': 'baz'})
    assert vm.get_vars(include_hostvars=False)

# Generated at 2022-06-21 09:32:52.024165
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    """
    Unit test for method __contains__ of class HostVars

    This test needs to mock the _find_host method.
    """
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader())

    # The HostVars object will call _find_host on requests for host variables.
    # We replace that method with one that returns a mock host
    def mock_find_host(self, hostname):
        class MockHost:
            def __init__(self):
                self.get_vars = {}
        return MockHost()



# Generated at 2022-06-21 09:33:02.925820
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Create data required to build HostVars object
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create HostVars object
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check the initial state of object
    assert variable_manager._hostvars == hostvars
    assert variable_manager._loader == loader

    # Change the state of object
    variable_manager._hostvars = None
    variable_manager._loader = None

    # Pickle and unpickle the object
    state = hostvars.__getstate__

# Generated at 2022-06-21 09:33:13.769843
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    import ansible.inventory.host
    import ansible.inventory

    def __init__(self):
        ansible.inventory.Host
        pass

    host1 = ansible.inventory.host.Host()
    host2 = ansible.inventory.host.Host()
    host1.name = 'Host1Name'
    host2.name = 'Host2Name'
    hostvars = HostVars(None, None, None)
    hostvars._inventory = ansible.inventory
    hostvars._inventory.hosts = [host1, host2]
    hostvars_len = len(hostvars)
    assert(hostvars_len == 2)

# Generated at 2022-06-21 09:33:44.384476
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    inventory = dict()
    loader = dict()
    variable_manager = dict()
    hostvars = HostVars(inventory, variable_manager, loader)
    del variable_manager
    del inventory
    del loader

    # Since we do not use inventory and loader any more, we can verify that
    # their attributes _inventory and _loader are cleared by __setstate__.
    # For example, inventory.hosts can not be accessed anymore.
    assert hostvars._inventory is None
    assert hostvars._loader is None
    assert hostvars._variable_manager is not None

# Generated at 2022-06-21 09:33:51.051159
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import Sequence

    assert issubclass(HostVars, Mapping)

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, None)

    hostvars = HostVars(inventory, variable_manager, loader)
    assert repr(hostvars) == repr({})

    inventory.add_host(host='localhost')
    assert repr(hostvars) == repr({'localhost': {}})


# Generated at 2022-06-21 09:34:02.310776
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # The only purpose of implementing __repr__ for HostVarsVars is to
    # correctly represent ansible.vars.hostvars. This test is just to
    # ensure the implementation is correct.

    from ansible.vars import VariableManager


# Generated at 2022-06-21 09:34:09.248025
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager

    inventory_manager = InventoryManager(loader=None, sources=['localhost,'])
    loader = None
    variable_manager = None
    host_vars = HostVars(inventory_manager, variable_manager, loader)

    assert len(host_vars) == 1
    assert 'localhost' in host_vars



# Generated at 2022-06-21 09:34:19.380943
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders

    inventory = None
    variable_manager = None

    # This call is to make sure all the plugin loaders are loaded.
    # Without it, the main plugin loader is not loaded, and plugin
    # loaders are loaded lazily, which means they will not be
    # registered with the plugin manager.
    get_all_plugin_loaders()

    # Create loader, since we are not running through Ansible code
    # that normally creates it
    loader = DataLoader()

    # Requirement for utils.plugins.get_all_plugin_loaders
    setattr(loader, '_basedir', '.')

    # Create variable manager, since we are not running through Ansible code
    # that normally creates it

# Generated at 2022-06-21 09:34:27.721041
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert 'localhost' in hostvars
    assert 'some_remote_host' not in hostvars


# Generated at 2022-06-21 09:34:34.228907
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inv = Inventory(DataLoader())
    inv.add_host(host='foo')
    inv.add_host(host='bar')

    vm = VariableManager(inventory=inv)
    hv = HostVars(inv, vm, DataLoader())

    assert len(hv) == 2, "Failed __len__ test for HostVars"


# Generated at 2022-06-21 09:34:35.905289
# Unit test for constructor of class HostVars
def test_HostVars():
    assert isinstance(HostVars(None, None, None), HostVars)

# Generated at 2022-06-21 09:34:49.135577
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import sys
    import os
    import collections

    sys.path.insert(0, os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'lib'))

    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager

    sys.path.pop(0)

    class MockInventory:
        def __init__(self, host_list):
            self._hosts = host_list

        def hosts(self):
            return self._hosts

    class MockLoader:
        def __init__(self, vars_list):
            self._hostvars_list = vars_list


# Generated at 2022-06-21 09:34:56.156751
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory

    hostvars = HostVars(Inventory(loader=None, variable_manager=VariableManager(loader=None, inventory=Inventory(loader=None, variable_manager=None))), variable_manager=VariableManager(loader=None, inventory=Inventory(loader=None, variable_manager=None)), loader=None)

    assert len(hostvars) == 0

# Generated at 2022-06-21 09:35:53.876199
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Host
    from ansible.vars.manager import VariableManager

    host_names = ['localhost']
    raw_get_ref = HostVars.raw_get

    def raw_get_mock(self, host_name):
        host_names.remove(host_name)
        return {host_name: 'value'}

    HostVars.raw_get = raw_get_mock
    inventory = MagicMock()
    inventory.get_host.side_effect = lambda host_name: Host(host_name)
    variable_manager = VariableManager()
    host_vars = HostVars(inventory, variable_manager, None)

    assert 'localhost' in host_vars.keys()

    inventory.get_host.assert_called_with('localhost')

# Generated at 2022-06-21 09:36:01.909280
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import os
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping

    class DummyModule(object):
        pass

    class DummyInventoryPlugin(object):
        def verify_file(self, path):
            return True

        def parse(self, inventory, loader, path, cache=True):
            return inventory

    loader = DataLoader()
    # inventory_manager sets the vars_plugins to be the same for all
    # inventory_manager without any way to configure them.
    # https://github.com/ansible/ansible/issues/46258

# Generated at 2022-06-21 09:36:09.366540
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import ansible.constants as C

    def get_hostvars(host, hostvars):
        return hostvars[host.name]

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 09:36:14.327430
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    dataloader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(None, variable_manager, dataloader)

    # let's create another VariableManager
    variable_manager2 = VariableManager()

    # change the variable manager of hostvars
    hostvars.set_variable_manager(variable_manager2)

    # hostvars should have a pointer to variable_manager2
    assert hostvars._variable_manager is variable_manager2, 'Unable to change variable manager'
    assert hostvars._variable_manager._hostvars is hostvars, \
        'Unable to change variable manager, the hostvars pointer has not been changed'

# Generated at 2022-06-21 09:36:17.549880
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = dict(foo=1, bar=2)
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)
    assert len(hostvarsvars) == 2



# Generated at 2022-06-21 09:36:28.197111
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import find_inventory_plugin
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    inventory = InventoryManager(loader=None, sources=None)

    # Add a host to the inventory
    inventory.add_host(host="test_host_1")
    assert "test_host_1" in inventory.hosts

    plugin = find_inventory_plugin("test")
    assert "test_host_1" in plugin.get_hosts(inventory, "test_host_1")

    variable_manager = VariableManager(loader=None, inventory=inventory, version_info=Reserved())
    assert "test_host_1" in variable_manager.hostvars

    return True


# Generated at 2022-06-21 09:36:30.201490
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    hv = HostVars({'foo': 'bar'})
    assert repr(hv) == "{'foo': {'foo': 'bar'}}"

# Generated at 2022-06-21 09:36:34.026768
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    hostvars = HostVars(
        inventory=Inventory(host_list=[]),
        variable_manager=VariableManager(host_list=[]),
        loader=None,
    )

    import copy
    assert copy.deepcopy(hostvars) is hostvars

# Generated at 2022-06-21 09:36:45.230023
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os

    hostvars_test_dir = os.path.dirname(os.path.realpath(__file__))
    hostvars_test_data = os.path.join(hostvars_test_dir, "../../../test/unit/vars/data")
    inventory_fname = os.path.join(hostvars_test_data, "hostvars_inventory")
    loader = DataLoader()
    targets = InventoryManager(loader=loader, sources=[inventory_fname])
    variable_manager = VariableManager(loader=loader, inventory=targets)

# Generated at 2022-06-21 09:36:46.357357
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager

    h = HostVars(None, VariableManager(), None)
    h.set_variable_manager(None)