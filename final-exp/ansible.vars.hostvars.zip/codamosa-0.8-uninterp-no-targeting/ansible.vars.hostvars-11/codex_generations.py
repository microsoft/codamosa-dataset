

# Generated at 2022-06-21 09:27:29.951115
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    hostvars = HostVars(inv_manager, variable_manager, loader)

    host = inv_manager.get_host('localhost')
    hostvars.set_host_variable(host, 'a', '1')
    assert hostvars[host.name]['a'] == '1'



# Generated at 2022-06-21 09:27:39.845663
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    inventory = dict(
        hosts = dict(
            test_host = dict(
                ansible_connection = "local"
            )
        ),
        vars = dict(
            test_var = "test_var"
        )
    )

    variable_manager = dict(
    )

    loader = dict(
    )

    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_facts(host="test_host", facts={"foobar": "barbaz"})

    # Verify that setting facts works
    assert hostvars['test_host']['foobar'] == "barbaz" and hostvars['test_host']['test_var'] == "test_var"

if __name__ == "__main__":
    test_HostVars_set

# Generated at 2022-06-21 09:27:47.756939
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    myhosts = InventoryManager(loader=loader, sources=['localhost,'])
    myvars = VariableManager(loader=loader, inventory=myhosts)
    hv = HostVars(inventory=myhosts, variable_manager=myvars, loader=loader)
    assert len(hv) == 2

# Generated at 2022-06-21 09:27:58.916731
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # 1.
    vars = HostVarsVars({'a_var': 'a_value'}, None)
    assert repr(vars) == "{'a_var': 'a_value'}"

    # 2.
    vars = HostVarsVars({'a_var': '{{a_value}}'}, None)
    assert repr(vars) == "{'a_var': '{{a_value}}'}"

    # 3.
    vars = HostVarsVars({'a_var': '{{a_value}}'}, None)
    assert repr(vars) == "{'a_var': '{{a_value}}'}"

    # 4.
    vars = HostVarsVars({'a_var': '{{a_value}}'}, None)

# Generated at 2022-06-21 09:28:05.965623
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 09:28:12.189230
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variables = VariableManager()
    variables.set_nonpersistent_facts({
        'foo': 'bar',
    })
    vars = HostVarsVars(variables, loader)
    assert vars['foo'] == 'bar'



# Generated at 2022-06-21 09:28:19.507714
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.compat.tests import unittest
    from ansible.vars.manager import VariableManager

    class Host:
        name = "localhost"

    class Inventory:
        hosts = [Host()]

    class Loader:
        pass

    # pass empty dict as self._variable_manager._fact_cache, so we will
    # not try to read the facts from file
    v = VariableManager(loader=Loader(), inventory=Inventory())
    h = HostVars(inventory=Inventory(), loader=Loader(), variable_manager=v)
    # when we create HostVars object it has no _inventory, so check that
    # we cannot iterate over it
    with unittest.TestCase().assertRaises(AttributeError):
        iter(h)
    h.set_inventory(Inventory())

    # pass empty dict as

# Generated at 2022-06-21 09:28:26.894364
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader, sources=['localhost,'])
    vars_mgr = VariableManager(loader=loader, inventory=inv_mgr)

    hostvars = HostVars(inv_mgr, vars_mgr, loader)
    for i in hostvars:
        assert isinstance(i, str) or isinstance(i, unicode)

# Generated at 2022-06-21 09:28:33.580359
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    # original variables
    foo = dict(
        a=1,
        b=2,
        c=3,
    )

    # derived variables
    bar = dict(
        b=3,
        d=4,
        e=5,
    )

    # host variables
    hostvars = dict(
        x=7,
        y=8,
        z=9,
    )

    # inventory variables
    inv_var = dict(
        o="apple",
        p="peach",
        q="quince",
    )

    inventory = '''
        [test]
        test1 hostvars=%s inv_var=%s
        test2 hostvars=%s inv_var=%s
    ''' % (hostvars, inv_var, bar, inv_var)


# Generated at 2022-06-21 09:28:43.537459
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Make mock variable_manager
    variable_manager = type('Mock', (object,), {})()
    variable_manager._loader = None
    variable_manager._hostvars = None

    # Make mock hostvars
    hostvars = HostVars(None, variable_manager, None)
    hostvars._loader = 'foo'

    # Perform pickling of HostVars object and unpickling
    hostvars_pickled = pickle.dumps(hostvars)
    hostvars_unpickled = pickle.loads(hostvars_pickled)

    # Test that loader and hostvars attributes are properly restored via
    # __setstate__
    assert hostvars_unpickled._loader == 'foo'
    assert hostvars_unpickled._variable_manager._loader == 'foo'

# Generated at 2022-06-21 09:28:54.509394
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources="localhost")
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager._vars_cache = {'localhost': {}}
    variable_manager._vars_cache['localhost']['var1'] = 'var1'
    variable_manager._vars_cache['localhost']['var2'] = 'var2'
    play_context = Play()
    variable_manager._set_play_context(play_context)

    hostvars = HostVars(inventory, variable_manager, DataLoader())

# Generated at 2022-06-21 09:29:07.166805
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars.manager import VariableManager
    class FakeInventory(object):
        pass
    class FakeHost(object):
        pass
    class FakeVarsCollection(object):
        def set_host_variable(self, host, varname, value):
            self.set_host_variable_called = True
            self.host = host
            self.varname = varname
            self.value = value
    #
    inventory = FakeInventory()
    host = FakeHost()
    vars_collection = FakeVarsCollection()
    vars_manager = VariableManager(loader=None, inventory=inventory, version_info=(1, 11, 0))
    vars_manager.vars_cache = vars_collection

# Generated at 2022-06-21 09:29:14.729223
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    class FakeVariableManager():
        def __getstate__(self):
            return {}
        def __setstate__(self, state):
            pass

    class FakeLoader():
        pass

    class FakeInventory():
        def get_host(self, host_name):
            pass

    fake_state = {
        '_inventory': FakeInventory(),
        '_loader': FakeLoader(),
        '_variable_manager': FakeVariableManager()
    }

    hv = HostVars(FakeInventory(), FakeVariableManager(), FakeLoader())
    hv.__setstate__(fake_state)

    assert hv._inventory == fake_state['_inventory']
    assert hv._loader == fake_state['_loader']
    assert hv._variable_manager._loader == fake_state['_loader']
    assert hv._variable_

# Generated at 2022-06-21 09:29:26.611736
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    import pickle
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars({}, variable_manager, loader)

    # __setstate__ should be able to restore _variable_manager
    hostvars_pickled = pickle.dumps(hostvars)
    variable_manager_pickled = pickle.dumps(variable_manager)

    variable_manager_restored = pickle.loads(variable_manager_pickled)
    hostvars_restored = pickle.loads(hostvars_pickled)

    # Make sure _loader and _hostvars are correctly restored
    assert variable_manager_restored._loader == loader
    assert variable_manager_restored._

# Generated at 2022-06-21 09:29:37.651438
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars import VariableManager
    import os
    import tempfile
    import shutil
    import yaml
    import json

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a host file
    host_filename = os.path.join(tmpdir, "hosts")
    with open(host_filename, "w") as f:
        f.write("""
[group1]
host1 ansible_ssh_port=2222
host2
[group2]
host3
host4
""")

    # Create a group_vars file
    group_vars_filename = os.path.join(tmpdir, "group_vars")

# Generated at 2022-06-21 09:29:40.867377
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    hostvars = HostVars(inv_manager, variable_manager, loader)

    host = inv_manager.get_host('localhost')
    hostvars.set_host_facts(host, dict())

    assert hostvars.raw_get('localhost') == dict()



# Generated at 2022-06-21 09:29:49.494735
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.variable_manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # set_host_facts method should set variable ansible_facts
    hostvars.set_host_facts('abc.io', dict(foo='bar'))
    assert hostvars.raw_get('abc.io')['ansible_facts'] == dict(foo='bar')

    # set_host_facts method should overwrite previous ansible_facts

# Generated at 2022-06-21 09:29:59.054377
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # TODO: Move this test to test_vars.py when the test framework is ready.
    import unittest
    from ansible.vars import VariableManager
    class TestInventory(object):
        def __init__(self):
            self.hosts = ['host1', 'host2']
        def get_host(self, host_name):
            if host_name in self.hosts:
                return True
            return None
    class TestHostVars(unittest.TestCase):
        def test___len__(self):
            inventory = TestInventory()
            hostvars = HostVars(inventory, VariableManager(), None)
            self.assertEqual(len(hostvars), len(inventory.hosts))
    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-21 09:30:10.235875
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 09:30:23.061090
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    task = Task()
    play_context = PlayContext()
    task.set_play_context(play_context)

    hostvars = HostVars({'foo': 'bar'}, task.variable_manager, task._loader)
    state = hostvars.__getstate__()

    hostvars.set_variable_manager(task.variable_manager)

    # The code below is needed to simulate that HostVars.__setstate__
    # is called from unpickled VariableManager.
    #
    # The method __setstate__ of the class VariableManager does not
    # set attribute _hostvars because class HostVars contains
    # values of attributes _loader and _hostvars already. If
    # _loader

# Generated at 2022-06-21 09:30:32.365529
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import ansible.parsing.dataloader
    loader = ansible.parsing.dataloader.DataLoader()
    variables = dict(a=5, b=10, c=dict(x=1, y=2, z=3))
    hostvars_vars = HostVarsVars(variables, loader)
    result = sorted(list(hostvars_vars))
    assert result == ['a', 'b', 'c']


# Generated at 2022-06-21 09:30:44.596448
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.template import Templar
    from ansible.module_utils.six import PY3
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    if not PY3:
        # Note -- this module is not needed for Python 3.
        from ansible.module_utils.six import iteritems
    else:
        # This is Python 3, so just define a fake iteritems function.
        def iteritems(obj):
            return obj.items()

    # Create an empty inventory manager with no data sources.
    im = InventoryManager(loader=None, sources='')
    im.set_playbook_basedir('/tmp')

    # Create a variable manager.
    vm = VariableManager(loader=None, inventory=im)

    # Create a hostvars object.

# Generated at 2022-06-21 09:30:52.926349
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.errors import AnsibleParserError
    from ansible.inventory.loader import InventoryLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.playbook import PlayBook
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display


# Generated at 2022-06-21 09:31:04.603591
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    class TestLoader:
        pass

    variables = {
        'test_var1': 'test_val1',
        'test_var2': 'test_val2',
        'test_var3': 'test_val3',
    }

    loader = TestLoader()

    hostvars_vars = HostVarsVars(variables, loader)

    # Test exact lookup
    assert hostvars_vars['test_var1'] == 'test_val1'
    assert hostvars_vars['test_var2'] == 'test_val2'
    assert hostvars_vars['test_var3'] == 'test_val3'

    # Test template expansion
    variables['test_var4'] = 1
    variables['test_var5'] = 5

# Generated at 2022-06-21 09:31:15.585854
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():

    class Inventory(object):

        def __init__(self, loader, variable_manager):
            self.hosts = []
            self.loader = loader
            self.variable_manager = variable_manager

        def get_host(self, hostname):
            return hostname in self.hosts and Host(hostname) or None

    class Host(object):

        def __init__(self, hostname):
            self.name = hostname

    class VariableManager(object):

        def __init__(self, loader):
            self._loader = loader
            self._vars_cache = {}

        def get_vars(self, host=None, include_hostvars=True):
            if host is None:
                return {}

# Generated at 2022-06-21 09:31:17.643670
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars = HostVarsVars({'foo': 'bar', 'baz': 'qux'}, None)
    assert sorted(hostvars) == ['baz', 'foo']

# Generated at 2022-06-21 09:31:23.752163
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    import ansible.vars.hostvars
    reload(ansible.vars.hostvars)
    from ansible.vars.hostvars import HostVarsVars
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    context = PlayContext()
    context._ds = { 'hostvars': {}, 'vars': {} }
    vars = {'foo': 'bar', 'x': 'y'}
    hvvars = HostVarsVars(vars, loader)
    # When
    actual = len(hvvars)
    # Then
    assert actual == 2


# Generated at 2022-06-21 09:31:31.968639
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    variables = dict(a=1, b="{{a}}", c="{{ansible_host}}")
    loader = DataLoader()
    var_mgr = VariableManager()
    var_mgr.set_loader(loader)
    var_mgr.set_inventory(None)
    var_mgr.set_globals(variables)
    var_vars = HostVarsVars(variables, loader=loader)
    assert var_vars['a'] == '1'
    assert var_vars['b'] == '1'
    assert var_vars['c'] == '{{ansible_host}}'

# Generated at 2022-06-21 09:31:44.581549
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager
    import ansible.inventory
    import ansible.playbook
    import copy

    # prepare inventory
    inventory = ansible.inventory.Inventory(host_list=[])
    inventory.add_host(ansible.inventory.Host(name='localhost'))

    # prepare variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # create hostvars
    hostvars = HostVars(inventory, variable_manager, None)
    variable_manager._hostvars = hostvars

    # set variable in variable manager
    variable_manager.extra_vars = dict(
        first_var='value1',
        second_var=dict(
            third_var='value3',
            fourth_var='value4'
        )
    )

    # get variable

# Generated at 2022-06-21 09:31:56.356008
# Unit test for constructor of class HostVars
def test_HostVars():

    # Constructor of HostVars should raise a RuntimeError
    # if inventory is None
    from ansible.inventory.manager import InventoryManager
    try:
        hostvars = HostVars(None, None)
        assert False, "Constructor of HostVars should have raised a RuntimeError"
    except RuntimeError:
        pass

    # Constructor of HostVars should raise a RuntimeError
    # if variable_manager is None
    inventory = InventoryManager(loader=None, sources=[])
    try:
        hostvars = HostVars(inventory, None)
        assert False, "Constructor of HostVars should have raised a RuntimeError"
    except RuntimeError:
        pass

    # Constructor of HostVars should succeed
    # if inventory and variable_manager are not None
    from ansible.vars.manager import VariableManager
   

# Generated at 2022-06-21 09:32:07.752355
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    hostvars_vars = HostVarsVars({'a': '1', 'b': '2'}, None)
    assert hostvars_vars['a'] == '1'
    assert hostvars_vars['b'] == '2'
    assert 'a' in hostvars_vars
    assert 'b' in hostvars_vars
    assert len(hostvars_vars.keys()) == 2
    assert list(hostvars_vars.keys()) == ['a', 'b']
    assert repr(hostvars_vars) == "{'a': '1', 'b': '2'}"


# Generated at 2022-06-21 09:32:14.542927
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=[])
    context = PlayContext()

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.__contains__("test")



# Generated at 2022-06-21 09:32:21.649366
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.variables.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    # Test the case when all requested hosts exist
    inventory.add_host(host='localhost')
    assert hostvars.raw_get('localhost') is not None
    assert hostvars.raw_get('localhost') == {}

    # Test the case when requested host does not exist
    # HostVars.raw_get returns AnsibleUndefined
    assert isinstance(hostvars.raw_get('unknown-host'), AnsibleUndefined)

# Generated at 2022-06-21 09:32:34.082932
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    inventory = InventoryManager(loader=None, sources=None)
    inventory.hosts = dict(
        remote1=Host(name="remote1"),
        remote2=Host(name="remote2"),
        remote3=Host(name="remote3"),
    )
    inv_hostvars = inventory.get_host(hostname="remote1").vars
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    hv.set_inventory(inventory)
    hv_hostvars = hv.raw_get(host_name="remote1")
    assert(inv_hostvars is hv_hostvars)

    assert('foo' in hv_hostvars)

# Generated at 2022-06-21 09:32:37.910094
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    inventory = MockInventory()
    loader = MockLoader()
    variable_manager = MockVariableManager()

    hv = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    assert len(hv) == 2



# Generated at 2022-06-21 09:32:42.449420
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    foo_loader = None
    foo_variables = {
        'foo': 'foo',
        'bar': 'bar'
    }
    foo_HostVarsVars = HostVarsVars(variables=foo_variables, loader=foo_loader)
    assert len(foo_HostVarsVars) == 2

# Generated at 2022-06-21 09:32:50.386647
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory import Host
    from ansible.vars.manager import VariableManager

    hv = HostVars({}, None)

    h = Host('testhost', {})
    facts = dict(ansible_os_family='Debian')
    hv.set_nonpersistent_facts(h, facts)
    assert h.get_vars() == facts

    hv._variable_manager = VariableManager({}, {})
    h = Host('testhost', {})
    facts = dict(ansible_os_family='Debian')
    hv.set_nonpersistent_facts(h, facts)
    assert h.get_vars() == facts


# Generated at 2022-06-21 09:32:59.260154
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    hosts = 'hosts'
    passwords = None
    inventory = InventoryManager(loader=None, sources=hosts)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, None)

    assert ('localhost' in hostvars) is False
    inventory.add_host('localhost')
    assert ('localhost' in hostvars) is True


# Generated at 2022-06-21 09:33:04.740269
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    loader = None
    variables = {'foo': 'bar'}
    host_vars_vars = HostVarsVars(variables=variables, loader=loader)
    assert 'foo' in host_vars_vars
    assert 'bar' not in host_vars_vars

# Generated at 2022-06-21 09:33:11.339165
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inv = Inventory(loader=None, variable_manager=VariableManager(), host_list=[])
    vars_manager = VariableManager(loader=None, inventory=inv)
    hostvars = HostVars(inventory=inv, variable_manager=vars_manager, loader=None)
    assert hostvars.get('foo') == 'bar'

# Generated at 2022-06-21 09:33:27.009166
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager

    # Make sure that VariableManager._hostvars attribute is preserved after unpickling
    hostvars = HostVars(None, VariableManager())

    hostvars.__setstate__(hostvars.__getstate__())

    assert hostvars._variable_manager._hostvars is hostvars

# Generated at 2022-06-21 09:33:38.641880
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    class FakeVars(MutableMapping):
        def __init__(self):
            self._data = {
                'a': '1',
                'b': '2',
                'c': '3',
            }

        def __getitem__(self, key):
            return self._data[key]

        def __setitem__(self, key, value):
            self._data[key] = value

        def __delitem__(self, key):
            del self._data[key]

        def __contains__(self, key):
            return key in self._data

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)

        def __repr__(self):
            return repr(self._data)


# Generated at 2022-06-21 09:33:46.557417
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'key', 'value')


# Generated at 2022-06-21 09:33:54.533359
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():

    from ansible.variables import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))

    hostvars = HostVars(inventory, variable_manager=inventory._variable_manager, loader=loader)

    import copy

    h = copy.deepcopy(hostvars)
    assert isinstance(h, HostVars)

# Generated at 2022-06-21 09:34:04.397617
# Unit test for constructor of class HostVars
def test_HostVars():

    # Example of inventory
    hosts = [
        'fake_inventory_name1',
        'fake_inventory_name2',
    ]

    # Example of variables for constructor of VariableManager
    variable_manager_vars = {
        'fake_variable_manager_name1': 1,
        'fake_variable_manager_name2': 2,
    }

    # Example of loader for constructor of VariableManager
    loader = 'fake_loader'

    # Example of variable_manager
    variable_manager = 'fake_variable_manager'

    # Example of ansible_version
    ansible_version = 'fake_version'

    # Example of inventory
    inventory = 'fake_inventory'

    # Initializing HostVars
    host_vars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-21 09:34:06.042900
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert len(HostVarsVars({'foo': 1}, None)) == 1

# Generated at 2022-06-21 09:34:17.379308
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    hosts_txt = '''
    [test_group]
    localhost ansible_host=127.0.0.1
    '''

    vars_txt = '''
    foo=foovalue
    bar=barvalue
    '''

    inventory = InventoryManager(loader=DataLoader(), sources=hosts_txt)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {'foo': 'foovalue', 'bar': 'barvalue'}
    # Create HostVars

# Generated at 2022-06-21 09:34:28.738940
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle
    from ansible.inventory.host import Host


# Generated at 2022-06-21 09:34:37.177756
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    class DummyInventory(object):
        hosts = {
            "all": {
                "hosts": {
                    "hostname": {
                        "vars": {
                            "var1": "value1"
                        }
                    }
                },
                "vars": {
                    "var2": "value2"
                }
            }
        }

        groups = {
            "ungrouped": {
                "hosts": {
                    "hostname"
                }
            }
        }


# Generated at 2022-06-21 09:34:39.253449
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # !!! Need to implement
    pass


# Generated at 2022-06-21 09:35:20.827341
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    class Host(object):
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    class Inventory(object):
        def __init__(self):
            self._hosts = dict()

        def add_host(self, host):
            self._hosts[host.get_name()] = host

        def get_host(self, host_name):
            return self._hosts.get(host_name, None)

        def __iter__(self):
            for host in self._hosts.values():
                yield host

        def __len__(self):
            return len(self._hosts)

    class HostVarsVariables(object):
        def __init__(self, host_name):
            self._host_name = host_name

# Generated at 2022-06-21 09:35:32.669654
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os

    inventory = InventoryManager(loader=DataLoader(), sources=os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_inventory_manager'))
    hosts = inventory.list_hosts()
    host = 'localhost'
    assert hosts[0] == host
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-21 09:35:40.064558
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # We cannot import these modules because of mutual imports.
    # So just create an empty object for them.
    inventory = object
    variable_manager = object
    loader = object
    hostvars = HostVars(inventory, variable_manager, loader)
    vm = hostvars._variable_manager

    # Assert that hostvars was assigned to the _hostvars of the current
    # variable manager.
    assert vm._hostvars is hostvars

    # Create a new variable manager.
    vm = object
    hostvars.set_variable_manager(vm)

    # Assert that hostvars was assigned to the _hostvars attribute of the new
    # variable manager.
    assert vm._hostvars is hostvars

# Generated at 2022-06-21 09:35:46.988134
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_path = 'tests/unit/inventory'
    inventory = InventoryManager(loader=loader, sources=inv_path)

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-21 09:35:54.013729
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, host_list=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars.set_host_facts("foohost", {"foo": "bar"})

    assert hostvars.raw_get("foohost")["foo"] == "bar"


# Generated at 2022-06-21 09:36:02.039281
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader

    input_variables = dict(
        x=dict(y='z'),
        foo='{{x}}',
        bar='1',
        baz='{{x.y}}',
    )
    expected_output_variables = dict(
        x=dict(y='z'),
        foo='x',
        bar='1',
        baz='z',
    )

    var = HostVarsVars(input_variables, loader=DataLoader())
    actual_output_variables = dict(
        x=var['x'],
        foo=var['foo'],
        bar=var['bar'],
        baz=var['baz'],
    )
    assert actual_output_variables == expected_output_variables


# Unit test

# Generated at 2022-06-21 09:36:09.487556
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import variable_manager as var_manager_loader
    from ansible.vars.manager import VariableManager

    class InventoryManagerStub(InventoryManager):
        hosts = [Host('localhost'), Host('localhost')]

    inventory = InventoryManagerStub()

    variable_manager = VariableManager()
    variable_manager_module = var_manager_loader.get('vars_plugins.yaml', variable_manager)
    if variable_manager_module:
        variable_manager.add_variable_manager(variable_manager_module)

    context = PlayContext()
    context._inventory = inventory
    context._variable_manager = variable_manager
    context._variable_

# Generated at 2022-06-21 09:36:19.451482
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    im = InventoryManager('localhost')
    dl = DataLoader()
    vms = VariableManager(loader=dl, inventory=im)
    hv = HostVars(im, vms, dl)

    assert len(hv) == 1

    im = InventoryManager(os.path.join(os.path.dirname(__file__), 'ansible_hosts'))
    dl = DataLoader()
    vms = VariableManager(loader=dl, inventory=im)
    hv = HostVars(im, vms, dl)

    assert len(hv) == 5



# Generated at 2022-06-21 09:36:29.774424
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    host_one = Host('localhost')
    host_two = Host('testhost')
    group = Group('testgroup')
    group.add_host(host_one)
    group.add_host(host_two)

    variable_manager = VariableManager([])
    variable_manager.add_group(group)
    variable_manager._vars_per_group[group]['vars'] = { 'foo': True } # pylint: disable=protected-access
    variable_manager._vars_per_host[host_one]['vars'] = { 'bar': [ { 'baz': True } ] } # pylint: disable=protected-access

# Generated at 2022-06-21 09:36:40.291349
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # empty HostVars gives empty dictionary
    assert repr(HostVars(None, None, None)) == '{}'

    class Host:
        name = 'foo'

    class HostVarsVars:
        def __init__(self, value):
            self._vars = value

        def __repr__(self):
            return repr(self._vars)

    class Inventory:
        def __init__(self, host):
            self.hosts = [host]
            self._hosts_patterns = []

        def get_host(self, pattern):
            if pattern == self.hosts[0].name:
                return self.hosts[0]

        def list_hosts(self, pattern):
            return self.hosts
