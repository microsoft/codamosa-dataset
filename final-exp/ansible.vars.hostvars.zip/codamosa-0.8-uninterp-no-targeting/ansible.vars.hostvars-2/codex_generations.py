

# Generated at 2022-06-21 09:27:26.795775
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class Inventory(InventoryManager):
        def __init__(self, loader, sources=None):
            pass

        def get_host(self, host_name):
            return None

        def get_hosts(self, pattern="all"):
            if pattern == 'all':
                return []
            else:
                return None

    inventory = Inventory(DataLoader())
    vars_manager = VariableManager(loader=DataLoader(), inventory=inventory, host_vars=None, group_vars=None, main=None)
    hostvars = HostVars(inventory=vars_manager.inventory, variable_manager=vars_manager, loader=DataLoader())

# Generated at 2022-06-21 09:27:28.920339
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    assert "undefined" in HostVarsVars({'foo': '{{ "undefined" }}'}, loader=None)
    assert "undefined" not in HostVarsVars({'foo': '{{ "undefined" if false_var }}'}, loader=None)

# Generated at 2022-06-21 09:27:34.837881
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    test_dict = {
        'a': 'b',
        'aa': '{{a}}b',
        'aaa': '{{aaa}}',
        'b': '{{c}}',
        'c': '{{b}}'
    }
    hostvarsvars = HostVarsVars(test_dict, loader=None)
    assert repr(hostvarsvars) == repr(test_dict)

# Generated at 2022-06-21 09:27:42.838214
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    role = dict(
        name='test_role',
        tasks=dict(main={'include': 'test'}),
        defaults=dict(main={'var': 1}))
    block = dict(name='test', block=dict(main={'var': 2}))
    task = dict(name='test', var=3, include=dict(include_vars='test'))

# Generated at 2022-06-21 09:27:54.948793
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # Create fake HostVars and Inventory objects
    class FakeHostVars(HostVars):
        def __init__(self):
            self.fake_inventory = None

        def set_inventory(self, inventory):
            self.fake_inventory = inventory

    class FakeInventory:
        def __init__(self):
            self.fake_variable_manager = FakeVariableManager()

    class FakeVariableManager:
        def __init__(self):
            self.fake_hostvars = None

        def set_hostvars(self, hostvars):
            self.fake_hostvars = hostvars

    # Test inventory and variable manager assignment
    fake_hostvars = FakeHostVars()
    fake_inventory = FakeInventory()
    fake_hostvars.set_inventory(fake_inventory)
    assert fake_host

# Generated at 2022-06-21 09:28:03.797538
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 09:28:13.857729
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class Inventory(object):
        def __init__(self, host, hosts):
            self.host = host
            self.hosts = hosts

        def get_host(self, host):
            return self.host

    class VariableManager(object):
        def __init__(self, variables):
            self.variables = variables

        def get_vars(self, host, include_hostvars):
            return self.variables

    host_name = 'some_host'
    host = object()
    hosts = []
    variables = {}
    loader = object()
    vars_ = HostVars(Inventory(host, hosts), VariableManager(variables), loader)

    assert list(vars_) == hosts



# Generated at 2022-06-21 09:28:24.159710
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = '''
[test_group]
test_host ansible_ssh_host=127.0.0.1
'''
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugins
    loader = DataLoader()

    inventory_manager = InventoryManager(loader=loader, sources=inventory)
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)
    vars_cache = HostVars(inventory_manager, variable_manager, loader)

    assert repr(vars_cache) == "{'127.0.0.1': {}}"

# Generated at 2022-06-21 09:28:28.820244
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    inventory = Inventory("tests/inventory/core_dynamic_inventory.py")
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, None)
    assert repr(hostvars) != ''

# Generated at 2022-06-21 09:28:40.395083
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    test_host_data = dict(ansible_facts=dict(facts_var='facts_var'))

    # Create a mock inventory, host, and variable_manager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    host = Host(name='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create the HostVars object and set facts to a variable
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars.set_host_facts

# Generated at 2022-06-21 09:28:52.822692
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    hostvarsvars = HostVarsVars({}, None)
    assert isinstance(repr(hostvarsvars), str)

    hostvarsvars = HostVarsVars({'foo': 'bar'}, None)
    assert isinstance(repr(hostvarsvars), str)

    hostvarsvars = HostVarsVars({'foo': 'bar', 'baz': [1, 2, 3]}, None)
    assert isinstance(repr(hostvarsvars), str)

    hostvarsvars = HostVarsVars({'foo': 'bar', 'baz': [1, 2, 3], 'quux': {'a': 1, 'b': 2}}, None)
    assert isinstance(repr(hostvarsvars), str)

    hostvarsvars = Host

# Generated at 2022-06-21 09:29:05.895727
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVarsVars


# Generated at 2022-06-21 09:29:15.923606
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    loader = 'dummy'
    inventory = 'dummy'

    # FIXME: dirty hack to initialize hostvars
    _variable_manager = 'dummy'
    HostVars(_inventory=inventory,
             _variable_manager=_variable_manager,
             _loader=loader)

    # Create new instance with correct methods and attributes
    h = HostVars(_inventory=inventory,
                 _variable_manager=_variable_manager,
                 _loader=loader)

    # Create state with incorrect methods and attributes
    state = {'_variable_manager': _variable_manager,
             '_loader': loader,
             '_inventory': inventory}

    h.__setstate__(state)

    # Ensure that all attributes are set properly
    assert h._variable_manager._loader == loader
    assert h._variable_manager._hostvars == h

# Generated at 2022-06-21 09:29:25.095509
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.module_utils.common._collections_compat import Mapping

    import pytest
    from ansible.module_utils.six import PY3

    # We can not test method raw_get directly since it is protected
    # by name mangling, therefore test it indirectly using a class
    # that inherits from HostVars and exposes the method.
    class HostVarsMockup():
        def raw_get(self, host_name):
            return super(HostVarsMockup, self).raw_get(host_name)

    # Create instance of HostVarsMockup. The constructor of HostVars
    # will be called implicitly.
    hvm = HostVarsMockup()

    # This is how HostVars.raw_get is used
    data = hvm.raw_get('localhost')

   

# Generated at 2022-06-21 09:29:35.000754
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager('localhost,')
    variable_manager = DummyVariableManager()

    # test with empty var cache
    hostvars = HostVars(inventory=inventory,
                        variable_manager=variable_manager,
                        loader=None)

    # test with empty hostvars
    assert hostvars.raw_get('localhost') == {}

    # test with existing hostvars
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    assert hostvars.raw_get('localhost') == {'foo': 'bar'}



# Generated at 2022-06-21 09:29:37.702248
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    assert HostVarsVars({"foo": "bar"}).__contains__("foo")
    assert not HostVarsVars({}).__contains__("foo")

# Generated at 2022-06-21 09:29:40.353986
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert len(hostvars) == 1
    assert 'localhost' in hostvars
    assert hostvars['localhost'] == {}


# Generated at 2022-06-21 09:29:47.411146
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # method __getitem__ should return a value of variable var
    # that is expanded by templating engine

    # define variable var
    # it is a variable with a reference to a variable that is defined
    # in the same dict
    variable = dict(var='{{ var2 }}', var2='foo')

    # define host_name
    host_name = 'localhost'

    # define inventory
    # it is a dict that contains a single host
    inventory = dict(hosts=dict(host_name=dict()))

    # define variable_manager
    variable_manager = dict()

    # define loader
    loader = dict()

    # create HostVars passing variable, inventory, variable_manager and loader
    hostvars = HostVars(variable_manager, loader, inventory)

    # set variable var for host host_name
    hostv

# Generated at 2022-06-21 09:29:53.963555
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.parsing.dataloader import DataLoader

    variables = {}
    loader = DataLoader()
    hostvarsvars = HostVarsVars(variables, loader)
    assert isinstance(hostvarsvars, HostVarsVars)
    assert isinstance(hostvarsvars._vars, dict)
    assert isinstance(hostvarsvars._loader, DataLoader)

# Generated at 2022-06-21 09:30:01.392415
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.parsing.dataloader import DataLoader

    # Construct VariableManager and HostVars
    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)

    # Construct Host with hostvars
    host = Host()
    host.name = 'localhost'
    variables = {'var_a': 'a', 'var_b': 'b'}
    variable_manager.set_nonpersistent_facts(host=host, facts=variables)
    hostvars.set_variable_manager(variable_manager)

    # Check that variables are in hostfacts and hostvars
    assert(variables == host.vars)

# Generated at 2022-06-21 09:30:22.869761
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

    host = Host(name='localhost')
    inventory.add_host(host)

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    test_facts = dict(
        anansi=dict(
            spiders=2000
        )
    )

    # set test facts
    hostvars.set_nonpersistent_facts(host, test_facts)

    # get facts from host_vars
    assert hostv

# Generated at 2022-06-21 09:30:32.276741
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    # Create an inventory
    inventory = FakeInventory()
    inventory.add_host(FakeHost('host_1'))

    # Create a variable manager
    variable_manager = FakeVariableManager(inventory)

    # Create a loader
    loader = FakeLoader()

    # Create a hostvars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create a variable
    variable = hostvars['host_1']

    # Deepcopy the variable
    shallow_copy = copy.copy(variable)
    deepcopy = copy.deepcopy(variable)

    # The deepcopy of HostVarsVars should be equal to the original
    assert deepcopy == variable

    # The copy of HostVarsVars should be equal to the original
    assert shallow_copy == variable



# Generated at 2022-06-21 09:30:44.457291
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.playbook.play import Play

    from ansible.vars import HostVarsVars
    import ansible.constants as C

    # Create inventory and get localhost
    my_inventory = InventoryManager(loader=C.DEFAULT_LOADER, sources=['localhost,'])
    host = my_inventory.get_host('localhost')
    assert host

    # Create dummy variables
    variables = dict(
        ansible_ssh_host = "host.example.com",
        ansible_ssh_port = "2222",
    )

    # Create VariableManager

# Generated at 2022-06-21 09:30:49.518005
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    # Basic case
    variables = dict(a=0)
    vars = HostVarsVars(variables, loader=None)
    assert 'a' in vars

    # Test for the case where variable is absent
    variables = dict()
    vars = HostVarsVars(variables, loader=None)
    assert 'a' not in vars



# Generated at 2022-06-21 09:31:02.309018
# Unit test for constructor of class HostVars
def test_HostVars():

    import collections
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import ansible.template
    import ansible.vars.unsafe_proxy
    import ansible.vars.manager

    from ansible.module_utils.facts import default_collectors

    ansible.module_utils.facts.collectors.extend(default_collectors)

    module_loader = ansible.parsing.dataloader.DataLoader()
    variables = ansible.vars.manager.VariableManager(loader=module_loader)
    inventory = ansible.inventory.Inventory(loader=module_loader)
    inventory.add_host(host=ansible.inventory.Host(name='hostname'))

# Generated at 2022-06-21 09:31:09.764172
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    hostvars = {
        'foo': 'bar',
        'baz': '{{ hostvars }}',
    }
    hostvars_vars = HostVarsVars(hostvars, loader=None)

    foo = hostvars_vars['foo']
    baz = hostvars_vars['baz']

    assert foo == 'bar'
    assert isinstance(baz, AnsibleUndefined)


# Generated at 2022-06-21 09:31:18.894183
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Setup the class under test
    loader = DataLoader()

    inventory = InventoryManager('localhost,')
    inventory.subset('all')

    inventory.add_host('localhost')

    # variables defined in inventory
    inventory.set_variable('localhost', 'foo', '1')

    # variables defined in vars_cache
    variables = {'bar': 2}

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = variables
    hv = HostVars(inventory, variable_manager, loader)

    # Test
    host_vars = hv['localhost']

    # Verify
    assert host_

# Generated at 2022-06-21 09:31:29.456493
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from io import StringIO
    import sys
    import tempfile
    import pickle
    import copy

    vars = { 'item1': '{{ item2 }}', 'item2': 'value', 'item3': '{{ item4 }}', 'item4': 'value' }

    vars_vars = HostVarsVars(vars, loader=None)
    assert vars_vars['item1'] == 'value'
    assert vars_vars['item3'] == 'value'

    # Test that VariableManager.__getstate__ and VariableManager.__setstate__
    # not preserve _loader and _hostvars attributes and HostVars.

# Generated at 2022-06-21 09:31:35.791891
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    # Define variables for dynamic inventory script
    variable_manager.set_nonpersistent_facts({'datacenter': 'us-west'})
    variable_manager.set_host_variable('127.0.0.1', 'ansible_connection', 'local')

    # Define variables for hosts
    variable_manager.set_host_variable('127.0.0.1', 'datacenter', 'us-east')
    variable_manager.set_host_variable('127.0.0.1', 'ansible_host', '127.0.0.1')


# Generated at 2022-06-21 09:31:47.238680
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    inventory = Inventory(loader=None, variable_manager=VariableManager())
    inventory.set_variable_manager(variable_manager=VariableManager())
    hostvars = HostVars(inventory, loader=None)
    hostvars.set_inventory(inventory)

    host = inventory.get_host('localhost')
    hostvars.set_nonpersistent_facts(host, dict(foo='bar'))

    hostvars.set_variable_manager(VariableManager())

    # Ensure that the nonpersistent facts are not restored during
    # unpickling, so that hostvars can contain facts for hosts, which
    # are not present in the inventory.
    import cPickle

# Generated at 2022-06-21 09:32:00.872364
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    test_data = {
        "test_string": "test_value",
        "test_list": [1, 2, 3, 4, 5],
        "test_dict": {
            "key1": "val1",
            "key2": "val2",
            "key3": "val3",
            "key4": "val4",
            "key5": "val5",
        },
    }

    hostvars_vars = HostVarsVars(test_data, None)
    assert len(hostvars_vars) == len(test_data)

# Generated at 2022-06-21 09:32:04.994150
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    import ansible.module_utils.common._collections_compat

    HostVarsVars_obj = HostVarsVars(ansible.module_utils.common._collections_compat.Mapping(), None)
    ret = HostVarsVars_obj.__contains__('foo')

    assert_equal(ret, False)


# Generated at 2022-06-21 09:32:15.689084
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import pytest
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=None)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert variable_manager.get_vars(inventory.get_host('localhost'))['inventory_hostname'] == 'localhost'

    with pytest.raises(RuntimeError):
        variable_manager.set_inventory(None)

    hostvars.set_inventory(None)

    with pytest.raises(AttributeError):
        variable_manager.get_vars(inventory.get_host('localhost'))['inventory_hostname']

    hostvars.set_inventory(inventory)

# Generated at 2022-06-21 09:32:21.097336
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = None
    inventory = InventoryManager(loader=loader, sources=['test/integration/inventory'])
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=vars_manager, loader=loader)

    len_expected = 3
    len_output = len(hostvars)
    assert len_expected == len_output, 'len(HostVars) is %s, should be %s' % (len_output, len_expected)

# Generated at 2022-06-21 09:32:32.401436
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=[])
    hostvars = HostVars(inventory, variable_manager, loader)

    assert not hostvars.raw_get('localhost').get('ansible_facts')
    hostvars.set_host_facts(inventory.get_host('localhost'), {'foo': 'bar'})
    assert hostvars.raw_get('localhost').get('ansible_facts') == {'foo': 'bar'}

# Generated at 2022-06-21 09:32:37.076351
# Unit test for constructor of class HostVars
def test_HostVars():
    assert len(HostVars({'a':'b'}, None, None)) == 1
    assert list(HostVars({'a':'b'}, None, None)) == ['a']
    assert 'a' in HostVars({'a':'b'}, None, None)
    assert 'b' in HostVars({'a':'b'}, None, None)

# Generated at 2022-06-21 09:32:48.061019
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager

    inventory = FakeInventory()
    inventory.set_variable("test_host", "foo", "bar")
    fake_variable_manager = FakeVariableManager(inventory)

    hostvars = HostVars(inventory, fake_variable_manager, loader=None)
    assert "test_host" in hostvars
    assert hostvars.get("test_host")["foo"] == "bar"

    new_inventory = FakeInventory()
    new_inventory.set_variable("test_host", "foo", "new_bar")
    new_fake_variable_manager = FakeVariableManager(new_inventory)

    hostvars.set_variable_manager(new_fake_variable_manager)
    assert "test_host" in hostvars
    assert hostvars.get("test_host")

# Generated at 2022-06-21 09:33:00.543890
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import ansible.variables
    import ansible.template.safe_eval
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()

    inventory_manager = InventoryManager(loader=loader, sources=["localhost"])

    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)
    variable_manager.set_inventory(inventory_manager)

    hostvars = HostVars(inventory_manager, variable_manager, loader)

    inventory_manager.hosts['localhost'].set_variable('var1', 10)
    inventory_manager.hosts['localhost'].set_variable('var2', 5)

    variables = hostvars.raw_get

# Generated at 2022-06-21 09:33:12.423599
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    host1 = Host(name='host1')
    host2 = Host(name='host2')
    inventory = Inventory(loader=DataLoader())
    inventory.add_host(host1)
    inventory.add_host(host2)

    hv = HostVars(inventory=inventory, variable_manager=VariableManager(), loader=DataLoader())

    hv_iter = list(hv)

    assert hv_iter[0] == host1
    assert hv_iter[1] == host2

# Generated at 2022-06-21 09:33:19.112300
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources='localhost,')

    vm = HostVars(hosts, loader=loader)
    vm.set_host_facts(hosts.get_host('localhost'), {'foo': 'bar'})

    assert vm['localhost']['foo'] == 'bar'

# Generated at 2022-06-21 09:33:39.534849
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create HostVars object without inventory
    vars_ = VariableManager()
    loader = DataLoader()
    inventory = None
    hostvars = HostVars(inventory, vars_, loader)

    # Set inventory, then get hostvars
    host_name = 'localhost'
    hostvars.set_inventory(Inventory(loader=loader))
    actual = hostvars.get(host_name, {})

    # Check if hostvars contains the host defined in inventory
    assert host_name in actual
    assert isinstance(actual, HostVarsVars)

# Generated at 2022-06-21 09:33:43.320907
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class FakeLoader:
        def get_basedir(self):
            return 'fake_dir'
    hostvars = HostVarsVars({'foo': "{{bar}}", 'bar': "baz"}, loader=FakeLoader())
    assert repr(hostvars) == "{'foo': 'baz', 'bar': 'baz'}"

# Generated at 2022-06-21 09:33:47.160476
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = {'foo':'a','bar':'b','baz':'c','qux':'d'}
    hvv = HostVarsVars(variables, loader=None)
    assert(len(hvv) == len(variables))

# Generated at 2022-06-21 09:33:59.605103
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=('localhost,'))
    inventory.add_host(Host('other_host'))

    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    play._variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}


# Generated at 2022-06-21 09:34:06.714944
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a variable manager and inventory manager
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory_manager)

    # Create a hostvars object and set a variable
    hostvars = HostVars(inventory_manager, variable_manager, loader)
    hostvars.set_nonpersistent_facts('localhost', dict(a='a'))

    # Assert the variable has been set
    assert hostvars['localhost'] == dict(a='a')

    # Create a new variable manager and check the variable has not been set


# Generated at 2022-06-21 09:34:15.688635
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=["localhost"])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    assert hostvars.raw_get("localhost") is not AnsibleUndefined
    assert hostvars.get("localhost") is not AnsibleUndefined
    assert "localhost" in hostvars

# Generated at 2022-06-21 09:34:26.033220
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    loader = None
    inventory = Inventory(loader=loader, host_list=['localhost'])
    inventory.set_variable(host='localhost', varname='ansible_version', value=2.0)

    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=VariableManager(loader=loader, inventory=inventory))

    # Now try to get a variable from localhost.
    localhost_vars = hostvars.raw_get('localhost')
    assert localhost_vars['ansible_version'] == 2.0
    assert isinstance(localhost_vars, dict)

    localhost_vars = hostvars.raw_get('foohost')
    assert isinstance(localhost_vars, AnsibleUndefined)

# Generated at 2022-06-21 09:34:35.523278
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var

    host = Host('test')
    variable_manager = VariableManager(loader=None, inventory=None)
    host_vars = HostVars(inventory=None, variable_manager=variable_manager, loader=None)
    host_vars.set_nonpersistent_facts(host, dict(persistent=True))
    host_vars.set_nonpersistent_facts(host, wrap_var(dict(nonpersistent=True)))
    host_vars.set_nonpersistent_facts(host, dict(nonpersistent=True, persistent=False))

    assert dict(persistent=True, nonpersistent=True, persistent_override=False) == host_v

# Generated at 2022-06-21 09:34:48.783848
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import connection_loader

    # init loader, inventory, variable_manager and required classes
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader)

    # create host "foo"
    host = inventory.add_host("foo")
    # create variable "foo" with value "bar"
    variable_manager.set_host_variable(host, "foo", "bar")

    # create mock task using the variable manager

# Generated at 2022-06-21 09:35:00.405470
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class Inventory(object):
        def __init__(self):
            self.hosts = ['host0']
            self.groups = {}
            self.dep_links = {}
            self.vars = {}
        def get_host(self, host_name):
            if host_name in self.hosts:
                return InventoryHost(host_name, self)
            return None
        def add_host(self, host_name, groups=None, vars=None):
            if host_name not in self.hosts:
                self.hosts.append(host_name)
            return InventoryHost(host_name, self)
        def add_group(self, group_name, vars):
            if group_name not in self.groups:
                self.groups[group_name] = []

# Generated at 2022-06-21 09:35:31.596908
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()
    # Create a dummy inventory
    inventory = InventoryManager(loader=loader, sources=None)
    inventory.hosts = ["localhost"]

    # Initialize a HostVars object with our dummy inventory
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert "localhost" in hostvars

# Generated at 2022-06-21 09:35:39.855219
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible import errors, inventory

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    # create inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])

    # create variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create hostvars
    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=variable_manager)

    # get localhost
    host = hostvars._find_host("localhost")

    # set host_variable

# Generated at 2022-06-21 09:35:46.879400
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVarsVars

    data_loader = DataLoader()
    inventory = Inventory(loader=data_loader, variable_manager=VariableManager(loader=data_loader))
    hostvars = HostVarsVars({'foo':'bar'}, loader=data_loader)

    assert 'foo' in hostvars

# Generated at 2022-06-21 09:35:54.779037
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    import ansible.plugins
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")

    h = inventory.hosts['localhost']
    v = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=v, loader=loader)

    # Vars are empty before set_nonpersistent_facts is called
    assert 'foo' not in hostvars['localhost']
    assert 'bar' not in hostvars['localhost']

    hostvars.set_nonpersistent_facts(host=h, facts={'foo': 'foo', 'bar': 'bar'})



# Generated at 2022-06-21 09:36:00.889179
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    variables = { 'a': '{{b}}', 'b': 'c' }
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variables)
    with templar.set_temporary_context(StaticVars(variables, STATIC_VARS)):
        foo = templar.template(variables, fail_on_undefined=False)
    assert repr(foo) == '{\'a\': \'c\', \'b\': \'c\'}'

# Generated at 2022-06-21 09:36:08.645113
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.unsafe_proxy import wrap_var
    variables = {'a': 1, 'b': "{{a}}", 'c': [1, 2, 3], 'd': {'foo': '{{a}}'}}
    wrapped_variables = {var: wrap_var(val) for var, val in variables.items()}
    loader = DictDataLoader({})
    hvv = HostVarsVars(variables, loader)
    assert(hvv['a'] == 1)
    assert(hvv['b'] == 1)
    assert(hvv['c'] == [1, 2, 3])
    assert(hvv['d'] == {'foo': 1})

    hvv = HostVarsVars(wrapped_variables, loader)

# Generated at 2022-06-21 09:36:16.142938
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    variable_manager = dict()
    variable_manager.update({'_loader': None, '_hostvars': None})
    loader = dict()

    hostvars = HostVars(None, variable_manager, loader)
    hostvars.__setstate__({'_loader': loader, '_variable_manager': variable_manager})

    # Verify that methods __setstate__ and __getstate__ of VariableManager
    # do not preserve _loader and _hostvars attributes.
    assert variable_manager == {'_loader': None, '_hostvars': None}

# Generated at 2022-06-21 09:36:24.124130
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    hostvars = HostVars(inventory=inventory, variable_manager=VariableManager(loader=loader), loader=loader)
    assert len(hostvars) == 1
    inventory.add_host('127.0.0.1')
    assert len(hostvars) == 2


# Generated at 2022-06-21 09:36:33.455888
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    hosts = ['host1', 'host2']
    hostvars = {'host1': {'foo': 'bar'}, 'host2': {'spam': 'eggs'}}

    inventory = Inventory()
    for host in hosts:
        inventory.add_host(host)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Test if fetching hostvars from an undefined host returns AnsibleUndefined
    hv = HostVars(inventory, variable_manager, loader=None)
    host_name = 'undefined_host'
    data = hv.raw_get(host_name)
    assert isinstance(data, AnsibleUndefined), "HostVars should return AnsibleUndefined for a non existent host"

# Generated at 2022-06-21 09:36:44.695753
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # test with inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['tests/inventory/host_vars_test.yml'])
    inventory.subset('ungrouped')

    # test with variable_manager
    variable_manager = VariableManager(loader=DataLoader())
    variable_manager.set_inventory(inventory)
    variable_manager.set_host_variable(inventory.get_host('ungrouped'), 'foo', 'bar')
    variable_manager.set_host_variable(inventory.get_host('ungrouped'), 'foo_dict', {'key1': 1, 'key2': 2})

    hostvars = HostVars