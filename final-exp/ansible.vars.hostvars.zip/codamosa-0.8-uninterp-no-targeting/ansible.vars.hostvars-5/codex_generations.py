

# Generated at 2022-06-21 09:27:19.935314
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    test_vars = {'foo': 'bar'}
    hostvarsvars = HostVarsVars(test_vars, "some loader")
    assert len(hostvarsvars) == 1


# Generated at 2022-06-21 09:27:30.633647
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inv_contents = {
        'group_1': {
            'hosts': ['localhost', '127.0.0.1']
        },
    }

    inventory = InventoryManager(loader=DataLoader(), sources=inv_contents)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    assert sorted(hostvars) == ['127.0.0.1', 'localhost']

# Generated at 2022-06-21 09:27:40.292740
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVars

    hostvars = HostVars(None, VariableManager())
    host = 'host1'
    facts = {'a': 1, 'b': 2}

    # set hostvars to {'host1': {'a': 1, 'b': 2}}
    hostvars[host] = facts

    # set_nonpersistent_facts({'a': 'aa'}) => {'host1': {'a': 'aa', 'b': 2}}
    hostvars.set_nonpersistent_facts(host, {'a': 'aa'})
    assert hostvars[host] == {'a': 'aa', 'b': 2}

    # set_nonpersistent_facts({'c': 'cc'}) => {'

# Generated at 2022-06-21 09:27:52.738603
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory=inventory, loader=DataLoader(), variable_manager=variable_manager)

    group = inventory.add_group('test_group')

    host = inventory.add_host(host='test_host', group=group)
    host.set_variable('test_var', 'test_value')
    host.set_variable('test_var2', 'test_value2')

    # Host test_host should be present in hostvars

# Generated at 2022-06-21 09:28:02.488042
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    hostvars = HostVars(inventory, variable_manager, loader)

    variable_manager.set_nonpersistent_facts(inventory.get_host('localhost'), {'foo': 'bar'})
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'baz', 'qux')
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'ansible_python_interpreter', '/usr/bin/python3')
    variable_manager.set_host

# Generated at 2022-06-21 09:28:13.301073
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.playbook.inventory.host import Host
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import UnsafeVaultSecret

    hv = HostVars(None, None, None)

    host = Host(name="localhost")
    host.set_variable("var1", AnsibleUnsafeText("var1"))
    host.set_variable("var2", "var2")
    host.set_variable("var3", VaultSecret("vault secret1"))

# Generated at 2022-06-21 09:28:17.353698
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars.manager import VariableManager

    hv = HostVars(None, VariableManager(), None)
    assert(hv == hv.__deepcopy__({}))

# Generated at 2022-06-21 09:28:27.488693
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    import sys
    import os
    import inspect

    # Ansible provides a module called ansible.module_utils.basic which
    # contains a function called AnsibleModule. We will use it to create a
    # fake Ansible module object.
    basic = sys.modules['ansible.module_utils.basic']
    if not basic:
        raise Exception("Module ansible.module_utils.basic not found")

    AnsibleModule = basic.AnsibleModule

    # Create a fake module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
        bypass_checks = False,
    )

    # Create an Ansible playbook object
    playbook = module.params['playbook'] = type('AnsiblePlaybook', (object,), {})()

# Generated at 2022-06-21 09:28:38.805434
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    ''' Verify that method set_host_variable sets the requested value in the hostvars
    dictionary.

    :returns: Nothing.
    '''

    def _verify_host_variable(host, hostvars, varname, value):
        ''' Verifies if the requested value is set in the hostvars dictionary.

        :arg host: Contains the host we are trying to validate.
        :arg hostvars: This is the hostvars dictionary provided by the HostVars
            instance.
        :arg varname: Name of the action plugin variable wanted to be validated.
        :arg value: Value of the action plugin variable wanted to be validated.
        :returns: Nothing.
        '''
        assert hostvars[host][varname] == value

    from ansible.vars.manager import VariableManager

# Generated at 2022-06-21 09:28:46.402115
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Create a mock inventory, with 2 hosts
    inventory = type('MockInventory', (object,), {'hosts': [1, 2]})()

    # Create a mock loader
    loader = type('MockLoader', (object,), {})()

    # Create a mock variable manager, with one hostvar
    vars = {"localhost": "value"}
    var_manager = type('MockVariableManager', (object,), {'_hostvars': vars})()

    # Create a HostVars object, using the mock objects
    hostvars = HostVars(inventory, var_manager, loader)

    # Assert that we have 2 hosts, and not more
    assert len(hostvars) == 2

test_HostVars___len__()

# Generated at 2022-06-21 09:29:05.882699
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle

    # Mock for class Inventory
    class test_Inventory():

        hosts = {'host1': 'host1'}

        def get_host(self, host_name):
            if host_name in self.hosts:
                return host_name
            else:
                return None

    # Mock for class DataLoader
    class test_DataLoader():
        pass

    # Mock for class VariableManager
    class test_VariableManager():

        def __init__(self):
            self._hostvars = None
            self._loader = None
            self.get_vars = None

        def __setstate__(self, state):
            self.__dict__.update(state)
            self._hostvars = None
            self._loader = None

        def __getstate__(self):
            state = self.__

# Generated at 2022-06-21 09:29:14.195587
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.vars.manager import VariableManagerVars

    # Create a variable manager required for get_vars call
    variable_manager = VariableManager()
    variable_manager.hostvars = {'host': dict()}

    # Create a temporary inventory
    inventory = Inventory(loader=None, variable_manager=variable_manager)
    inventory.add_host(host=inventory.get_host('host'), group='group')

    # Set hostvars attribute of the variable manager modified by HostVars
    # to a different value
    variable_manager.hostvars = {'host': dict()}
    hostvars = HostVars(inventory, variable_manager, loader=None)
    # Assert that calling set_variable_manager updates the hostvars

# Generated at 2022-06-21 09:29:24.488027
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    '''
    For set_inventory, hostvars.yml and group_vars/all are loaded again.
    Check such vars get overwritten.
    '''
    import os
    import tempfile
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    hostvars_path = os.path.join(tempfile.mkdtemp(), 'hostvars.yml')
    with open(hostvars_path, 'w') as f:
        f.write('host1:\n')
        f.write('  var1: value1_1\n')
        f.write('  var2: value2_1\n')
        f.write('host2:\n')
        f.write('  var1: value1_2\n')
        f.write

# Generated at 2022-06-21 09:29:36.295249
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    fake_inventory = [
        {"hostname": "foo", "vars": {'a': 1, 'b': 2}},
        {"hostname": "foobar", "vars": {'a': 1, 'b': 2}},
        {"hostname": "bar", "vars": {'a': 1, 'b': 2}},
    ]

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=fake_inventory)
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    hostvars = HostVars(inv_manager, variable_manager, loader=loader)


# Generated at 2022-06-21 09:29:44.547566
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    class MockLoader(object):
        pass

    class MockTemplar(object):
        def __init__(self):
            self.fail_on_undefined = False

        def template(self, data, fail_on_undefined=False, static_vars=None):
            return data

    loader = MockLoader()
    variables = {"foo": "bar", "baz": "boo"}
    templar = MockTemplar()
    host_vars_vars = HostVarsVars(variables, loader)

    # Test available variable
    assert "foo" in host_vars_vars

    # Test non-existing variable
    assert "non-existing" not in host_vars_vars

# Generated at 2022-06-21 09:29:49.393378
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.plugins.loader import vars_loader

    inventory = InventoryManager(["localhost"], None, vault_password="dummy")
    variable_manager = VariableManager(loader=vars_loader)
    loader = 'dummy'
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars is not None

# Generated at 2022-06-21 09:29:55.080229
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    vars = UnsafeProxy({'var1': 1,
                        'var2': 'var2',
                        'var3': ['{{ var2 }}', '{{ var1 }}'],
                        'var4': [['{{ var1 }}'], [['{{ var2 }}']]]
                       })
    HostVarsVars(vars, None)

# Generated at 2022-06-21 09:30:01.587964
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={'hello': 'world'})
    inventory = Inventory(loader=loader, host_list=[])
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader)
    host = Host('test_host')
    assert hostvars[host] == {}
    host.set_variable('hello', 'world')
    inventory.add_host(host)
    assert hostvars[host] == {'hello': 'world'}
    assert hostvars.raw_get(host) == {'hello': 'world'}
    assert str(hostvars) == "HostVars({'test_host': {'hello': 'world'}})"

# Generated at 2022-06-21 09:30:13.340093
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.plugins import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create a VariableManager instance for unit tests
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    # Add vars plugin defined in example file to variable manager
    variable_manager.extra_vars = vars_loader.add_directory(loader, './filter_plugins/vars_plugins')
    variable_manager.construct_vars(host=None, include_hostvars=False)

    # Create an instance of HostVars class
    inventory = None
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    host = 'localhost'

# Generated at 2022-06-21 09:30:20.390894
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    var_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=var_manager, loader=loader)
    hostvars._inventory.hosts.append('myhost')
    myhost = hostvars._find_host('myhost')
    hostvars._variable_manager._hostvars[myhost._name] = dict()
    hostvars._variable_manager._hostvars[myhost._name]['foo'] = 'bar'

# Generated at 2022-06-21 09:30:35.671318
# Unit test for constructor of class HostVars
def test_HostVars():
    assert(HostVars(None, None, None))


# Generated at 2022-06-21 09:30:43.205581
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars import VariableManager, HostVars
    from ansible.inventory import Inventory

    foo = Inventory(host_list=[])
    hv = HostVars(inventory=foo, variable_manager=VariableManager(), loader=None)
    try:
        hv.set_nonpersistent_facts('localhost', dict())
    except Exception as e:
        assert False, 'Unexpected exception: {0}'.format(e)

# Generated at 2022-06-21 09:30:51.797209
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager

    from ansible.config.manager import ConfigManager
    from ansible.plugin.loader import shared_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    config_manager = ConfigManager()
    plugin_loader = shared_loader
    variable_manager = VariableManager()

    loader = DataLoader(config_manager=config_manager)

    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert 'jumper' in hostvars


# Generated at 2022-06-21 09:31:03.455794
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    fake_play = Play.load({
        'name': 'fake',
        'hosts': 'fake-host',
        'gather_facts': 'no'
    }, variable_manager=VariableManager(), loader=None)
    fake_play._variable_manager.set_nonpersistent_facts(
        fake_play.hosts[0],
        dict(local_facts=dict(foo='baz', bar='lol'))
    )

# Generated at 2022-06-21 09:31:09.765123
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = dict(foo='bar', baz='qux')
    hostvars_vars = HostVarsVars(variables, loader=None)
    vars_it = iter(hostvars_vars)
    vars_set = set(vars_it)
    assert vars_set == set(('foo', 'baz'))


# Generated at 2022-06-21 09:31:18.925305
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    varsmanager = VariableManager(None, loader)
    hostvars = HostVars({}, varsmanager)

    assert 'host' not in varsmanager._vars_cache
    hostvars.set_host_variable('host', 'a', 'b')
    assert varsmanager._vars_cache['host']['a'] == 'b'

    hostvars.set_host_variable('host', 'a', 'c')
    assert varsmanager._vars_cache['host']['a'] == 'c'
    assert varsmanager._vars_cache['host']['a'] != 'b'


# Generated at 2022-06-21 09:31:29.458124
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, [])
    variable_manager = VariableManager(loader, inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')

    hostvars.set_nonpersistent_facts(host, dict(foo=42))

    assert hostvars['localhost']['foo'] == 42
    assert hostvars.raw_get('localhost')['foo'] == 42

    assert hostvars['localhost']['ansible_facts']['foo'] == 42

# Generated at 2022-06-21 09:31:41.936616
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.plugins.loader import InventoryLoader
    # Patch InventoryLoader.get_inventory_sources to return something we can use
    # as an inventory source.
    def mock_get_inventory_sources(self, path):
        return [
            ("dummy_inventory", "localhost ansible_connection=local"),
        ]
    InventoryLoader.get_inventory_sources = mock_get_inventory_sources
    from ansible.inventory import Inventory

    # Generate a dummy inventory
    inventory_loader = InventoryLoader()
    inventory = Inventory(loader=inventory_loader, variable_manager={})
    inventory.hosts = [
        'host1',
        'host2',
        'host3',
    ]
    # Generate a dummy variable manager.

# Generated at 2022-06-21 09:31:48.903013
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    my_inventory = InventoryManager(loader=None, sources='localhost,')
    my_variable_manager = VariableManager(loader=None, inventory=my_inventory)
    hostvars = HostVars(my_inventory, my_variable_manager, loader=None)

    assert 'localhost' in hostvars
    assert '127.0.0.1' not in hostvars

# Generated at 2022-06-21 09:31:57.245230
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Create a variable with some values
    variables = { 'foo': 'bar', 'baz': 'qux', 'rolename': 'test_role' }

    # Create an instance of HostVarsVars and check if the variable
    # is correctly expanded
    my_instance = HostVarsVars(variables, None)
    assert my_instance['foo'] == 'bar'
    assert my_instance['baz'] == 'qux'
    assert my_instance['rolename'] == 'test_role'

# Generated at 2022-06-21 09:32:13.433363
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    host = Host('localhost')

    inventory = InventoryManager('n/a', None, loader=None, sources=None)
    inventory.hosts = [host]

    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)
    hostvars.set_host_facts(host, dict(foo=dict(bar=42)))
    assert hostvars['localhost'].get('foo').get('bar') == 42

if __name__ == '__main__':
    test_HostVars_set_host_facts()

# Generated at 2022-06-21 09:32:21.049989
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)

    ''' Create three hosts with different facts '''
    h1 = inventory.add_host('host1')
    h1.set_variable('ansible_host', 'host1')
    f1 = dict(ip='1.2.3.4')
    h1.set_variable('ansible_facts', f1)

    h2 = inventory.add_host('host2')
    h2.set_variable('ansible_host', 'host2')
    f2 = dict(ip='5.6.7.8')

# Generated at 2022-06-21 09:32:33.551368
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import copy
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['127.0.0.1'])

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = {'foo': 'bar'}

    hostvars = HostVars(inventory, variable_manager, loader)
    assert '127.0.0.1' in hostvars
    assert '127.0.0.2' not in hostvars

    # Test if hostvars working properly after being pickled
    hostvars_copy = copy.deepcopy(hostvars)

# Generated at 2022-06-21 09:32:44.391436
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    inventory = _init_inventory()
    variables = _init_variables()
    loader = _init_loader()

    class TestHostVars(HostVars):
        '''A subclass of HostVars with overridden `_find_host` method
        that returns a Host object if host with the name is found,
        None otherwise.
        '''
        def _find_host(self, host_name):
            return (
                next((host for host in inventory.hosts if host.name == host_name), None)
            )

    hostvars = TestHostVars(inventory, variables, loader)

    # test that all hosts from inventory are found in hostvars
    assert all(host.name in hostvars for host in inventory.hosts)
    # test that names of all hosts from inventory can
    # be used as keys to

# Generated at 2022-06-21 09:32:50.708205
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import ansible.parsing.dataloader
    import ansible.vars.manager
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    hostvars = HostVars(None, variable_manager, loader)
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(loader, variable_manager, host_list=[])
    hostvars.set_inventory(inventory)
    assert hostvars._inventory is inventory
    assert variable_manager._inventory is inventory

# Generated at 2022-06-21 09:32:54.664191
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    hvv = HostVarsVars(dict(foo=1, bar=2), None)
    assert hvv['foo'] == 1
    assert hvv['bar'] == 2

# Generated at 2022-06-21 09:33:03.511672
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    path = "test/test_hostvars.yml"
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[path])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    inventory_path = "test/test_host.yml"
    inventory = InventoryManager(loader=loader, sources=[inventory_path])
    hostvars.set_inventory(inventory)
    assert hostvars._inventory.hosts[0].name == "testhost"

# Generated at 2022-06-21 09:33:11.847177
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = {'x': '1', 'y': '2'}
    mocked_loader = type('MockLoader', (), {'get_basedir': lambda self: '', 'path_dwim': lambda self, path: path})
    host_vars_vars = HostVarsVars(variables, mocked_loader)
    # The length should be 2, but not 0
    assert len(host_vars_vars) == 2 and len(host_vars_vars) != 0


# Generated at 2022-06-21 09:33:23.305942
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager

    class FakeInvenory:
        hosts = []

        def __init__(self, *args, **kwargs):
            pass

        def get_host(self, host_name):
            return None

    class FakeLoader:
        def __init__(self, *args, **kwargs):
            pass

    inventory = FakeInvenory()
    loader = FakeLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory=inventory,
                        variable_manager=variable_manager,
                        loader=loader)

    state = {
        '_inventory': inventory,
        '_loader': loader,
        '_variable_manager': variable_manager
    }

    hostvars.__setstate__(state)

    assert hostvars

# Generated at 2022-06-21 09:33:34.883016
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from copy import deepcopy

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    host = 'localhost'
    hostvars.set_host_variable(host, 'foo', 'bar')
    hostvars.set_host_variable(host, 'var', hostvars)
    assert 'foo' in hostvars.raw_get(host)
    assert 'var' in hostvars.raw_get(host)

# Generated at 2022-06-21 09:33:46.337924
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    hvv = HostVarsVars({'a': 'A'}, loader=None)
    assert hvv['a'] == 'A'



# Generated at 2022-06-21 09:33:54.635172
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = VariableManager(loader=loader)
    variables.set_nonpersistent_facts(dict(random="name"))
    variables["foo"] = "bar"
    variables["template"] = "{{ foo }}"

    hostvars = HostVarsVars(variables, loader)
    assert hostvars.__repr__() == "{'foo': 'bar', 'template': 'bar', 'random': 'name'}"

# Generated at 2022-06-21 09:34:02.336458
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources='')
    _HostVars = HostVars(inventory, variable_manager, loader)

    assert isinstance(_HostVars['localhost'], HostVarsVars)
    assert len(_HostVars) == 0
    assert list(_HostVars) == []
    assert 'localhost' not in _HostVars


# Generated at 2022-06-21 09:34:14.917662
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    inventory.set_play_context(play_context)
    inventory.add_host(host=Host('localhost', variables={'test_key': 'test_value'}))

    hostvars = HostVars(inventory, variable_manager, loader)

   

# Generated at 2022-06-21 09:34:22.380661
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestInventory(Inventory):
        def __init__(self, loader, variable_manager):
            self.loader = loader
            self.variable_manager = variable_manager
            super(TestInventory, self).__init__(loader, variable_manager)

        def add_host(self, host):
            super(TestInventory, self).add_host(host)
            self.variable_manager.set_nonpersistent_facts(self.get_host(host), self.get_host(host).get_vars())

    class TestHost:
        def __init__(self, name):
            self.name = name
            self.vars = {}

       

# Generated at 2022-06-21 09:34:23.017847
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert True

# Generated at 2022-06-21 09:34:32.065688
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variable_manager = DummyVariableManager()
    variable_manager.set_nonpersistent_facts("localhost", {"ansible_python_interpreter": "/usr/bin/python"})
    variable_manager.set_host_variable("localhost", "testvar", "testval")
    loader = DummyLoader()

    hostvars = HostVars(loader=loader, variable_manager=variable_manager, inventory=DummyInventory())["localhost"]
    assert hostvars["testvar"] == "testval"
    assert hostvars["ansible_python_interpreter"] == "/usr/bin/python"



# Generated at 2022-06-21 09:34:38.472373
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    inventory = InventoryManager(['localhost'])
    variable_manager = VariableManager(loader=None)
    variable_manager._inventory = inventory
    hostvars = HostVars(inventory, variable_manager, loader=None)
    variable_manager.set_host_variable('localhost', 'foo', 'bar')
    host = inventory.get_host('localhost')
    hostvars.set_host_facts(host, {'test': 'test'})
    assert variable_manager.get_vars(host=host)['foo'] == 'bar'
    assert variable_manager.get_vars(host=host)['test'] == 'test'


# Generated at 2022-06-21 09:34:47.204532
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing import DataLoader

    vars_manager = VariableManager()

    hostvars = HostVars(Inventory(loader=DataLoader()), vars_manager, DataLoader())
    assert vars_manager._loader is None

    # Simulate serialization for pickle
    state = hostvars.__getstate__()
    hostvars.__setstate__(state)

    assert vars_manager._loader is hostvars._loader

# Generated at 2022-06-21 09:34:56.156040
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)
    hostvarsvars = hostvars['localhost']

    # Test if an existing variable is found
    assert 'ansible_version' in hostvarsvars

    # Test if an non-existing variable is not found
    assert 'foobar' not in hostvarsvars

# Generated at 2022-06-21 09:35:19.959811
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    import ansible.inventory.manager

    inventory = ansible.inventory.manager.InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    for host in inventory.hosts:
        variable_manager.set_host_variable(host, "var", "value")

    assert repr(hostvars).startswith('{')
    assert repr(hostvars).endswith('}')
    for host in inventory.hosts:
        assert repr(hostvars).contains(host.name)
        assert repr(hostvars).contains('{var: value}')


# Generated at 2022-06-21 09:35:32.126901
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    class DummyVarManager(object):
        def __init__(self, loader):
            self._vars = {'a': 1, 'b': 2, 'c': 3}
            self._loader = loader

        def get_vars(self, play=None, include_hostvars=True, include_delegate_to=True):
            return self._vars

    dvm = DummyVarManager(loader)
    variables = HostVars(None, dvm, loader)
    hostvars = variables.raw_get("foo")

    assert len(hostvars) == 3
    assert len(hostvars["a"]) == 3
    assert len(hostvars["b"]) == 3

# Generated at 2022-06-21 09:35:40.163390
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    inventory = Inventory("")
    host = inventory.get_host("test_host")
    variable_manager = VariableManager()

    # Test host variables
    hostvars = HostVars(inventory, variable_manager, "")
    hostvars.set_host_variable(host, "test_host_variable", "host_variable_value")
    assert hostvars.raw_get("test_host")["test_host_variable"] == "host_variable_value"

    # Test non-persistent facts
    hostvars.set_nonpersistent_facts(host, {"test_host_non_persistent_fact": "non_persistent_fact_value"})

# Generated at 2022-06-21 09:35:48.025690
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():  # pylint: disable=no-self-use
    hv = HostVars({}, None, None)

    vm = hv._variable_manager
    vm._loader = None
    vm._hostvars = None

    hv.__setstate__({'_inventory': {}})

    assert vm._loader is not None
    assert vm._hostvars is not None

    class MyLoader(object):
        pass

    hv._loader = MyLoader()
    hv.__setstate__({'_inventory': {}, '_variable_manager': vm})

    assert vm._loader is not None
    assert isinstance(vm._loader, MyLoader)
    assert vm._hostvars == hv

# Generated at 2022-06-21 09:35:56.010528
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    import ansible.template

    # Dummy variables and functions
    def _loader(filename):
        return filename

    def _variables(host, include_hostvars=False):
        return {'hostvars': 'abc'}

    def _get_host(name):
        return 'host'

    hv = HostVars(Inventory(loader=_loader), VariableManager(loader=_loader), loader=_loader)

    # Proper initialization of HostVars instance
    assert hv._inventory == Inventory(loader=_loader)
    assert hv._loader == _loader
    assert isinstance(hv._variable_manager, VariableManager)
    assert hv._variable_manager._loader == _loader
    assert hv._variable_manager._

# Generated at 2022-06-21 09:36:05.296052
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Construct the value that the method __repr__ will return
    ansible_version = '2.0'
    out = {'localhost': {'ansible_version': ansible_version, 'inventory_hostname': 'localhost'}}
    # Construct the HostVars object and call the method __repr__
    inventory = AnsibleFakeInventory()
    variable_manager = AnsibleFakeVariableManager()
    loader = AnsibleFakeLoader()
    hostvars = HostVars(inventory, variable_manager, loader)
    result = hostvars.__repr__()
    # Check that the result of the method __repr__ is equal to the value
    # constructed previously
    assert result == out


# Generated at 2022-06-21 09:36:11.884843
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-21 09:36:14.870723
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    data = {'a': 'foo'}
    vars = HostVarsVars(variables=data, loader=None)
    assert('a' in vars)

# Generated at 2022-06-21 09:36:23.393502
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # create a fake inventory
    from ansible.inventory.host import Host
    test_host = Host(name='test_host')
    test_host.set_variable('foo', 'test')

    # create fake variables
    test_variables = dict(foo='first')

    # create fake loader
    from ansible.parsing.dataloader import DataLoader
    test_loader = DataLoader()

    # create fake play context
    test_play_context = PlayContext()

    # create fake task
    test_task = Task()

    # create fake variable manager

# Generated at 2022-06-21 09:36:32.870732
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import wrap_var

    test_data = {'foo': 'bar', 'baz': {'one': 'two', 'three': 'four'}}

    inventory_path = './test/unit/inventory.ini'
    inventory = InventoryManager(loader=DataLoader(), sources=inventory_path)
    host = inventory.hosts.get('localhost')

    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-21 09:37:08.406851
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import variable_manager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    host = InventoryManager(loader=loader, sources='localhost,').get_host(u'localhost')
    variable_manager.set_host_variable(host, u'foo', u'bar')
    hostvars = HostVars(InventoryManager(loader=loader, sources='localhost,'), variable_manager, loader)
    hostvars.set_variable_manager(variable_manager)

    # check that variable is correctly templated
    assert hostvars[u'localhost'][u'foo'] == u'bar'
   