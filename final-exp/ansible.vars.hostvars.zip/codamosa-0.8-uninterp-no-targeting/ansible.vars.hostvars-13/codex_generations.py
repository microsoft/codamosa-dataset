

# Generated at 2022-06-21 09:27:34.278555
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    '''
    Unit test for method set_nonpersistent_facts of class HostVars
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    # Create a dummy host and group,
    # add the host to the group and then the group to the inventory
    host = 'host1'
    group = 'group1'
    host_obj = InventoryManager.Host(host)
    group_obj = InventoryManager.Group(group)
    group_obj.add_host(host_obj)
    groups = [group_obj]
    hosts = [host_obj]
    inventory = InventoryManager(loader=None, sources=['localhost'])
    inventory.groups = groups
    inventory.hosts = hosts

    # Obtain the variable manager and set some persistent variables for the

# Generated at 2022-06-21 09:27:36.944900
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    vars = HostVarsVars({'foo': '{{ bar }}', 'bar': 'baz'}, None)
    assert vars['foo'] == 'baz'



# Generated at 2022-06-21 09:27:42.891835
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    hostvars = HostVars(None, VariableManager(), DataLoader())
    hostvars._inventory = None
    hostvars._loader = None
    hostvars._variable_manager = None
    host = Host('127.0.0.1')
    host.set_variable('ansible_foo', 'bar')
    hostvars.set_host_variable(host, 'ansible_bar', 'foo')
    assert len(hostvars) == 1

# Generated at 2022-06-21 09:27:55.007507
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    ''' Ansible module for testing complex return arguments '''

    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import callback_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'inventory_hostname': 'localhost',
        'inventory_hostname_short': 'localhost',
        'group_names': ['ungrouped'],
        'groups': {
            'ungrouped': ['localhost'],
            }
    }


# Generated at 2022-06-21 09:28:02.867618
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    vars_manager = VariableManager()
    hostvars = HostVars(None, vars_manager, loader)
    vars = {'var1': 'value1'}
    vars_manager.set_host_variable('host1', 'hostvars', vars)

    # Verify that hostvars has been set after calling set_variable_manager
    assert (hostvars.raw_get('host1') == vars)
    assert (hostvars.get('host1') == vars)

# Generated at 2022-06-21 09:28:13.429871
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    """
    The method returns a string representation of the object. If a variable
    is a string it doesn't need to be changed, but if it is a collection
    (list or dict) it has to be converted to a string to be used in
    a string representation.

    These tests check that string variables have been properly converted
    and that variables of type list and dict have been properly
    converted.
    """

    # Variables that are a string don't need conversion
    variables = {
        'string': 'test'
    }

    loader = 'test'
    hostvarsvars = HostVarsVars(variables, loader)
    assert repr(hostvarsvars) == "{'string': 'test'}"

    # Variables that are a list or dict need conversion

# Generated at 2022-06-21 09:28:23.668411
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager([], None)
    host = inventory.get_host('localhost')
    host.vars = {'foo': 'bar'}
    host.set_variable('bar', 'foo')
    hostvars = HostVars(inventory, VariableManager(loader=None), None)

    assert len(list(hostvars)) > 0
    assert len(list(hostvars.keys())) > 0
    assert len(list(hostvars.values())) > 0
    assert len(list(hostvars.items())) > 0



# Generated at 2022-06-21 09:28:30.830663
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    class DummyInventory:
        def __init__(self):
            self.hosts = ['foo', 'bar', 'baz']

    class DummyVariableManager:
        def __init__(self):
            self._vars_cache = {
                'foo': {'a': '1', 'b': '2', 'c': '3'},
                'bar': {'d': '4', 'e': '5', 'f': '6'},
                'baz': {'g': '7', 'h': '8', 'i': '9'},
                }

    class DummyLoader:
        pass

    vars = HostVars(inventory=DummyInventory(), variable_manager=DummyVariableManager(), loader=DummyLoader())

# Generated at 2022-06-21 09:28:41.545442
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    vars_manager = VariableManager()
    inventory_manager = InventoryManager()
    inventory = inventory_manager.get_inventory_from_source('localhost,')
    inventory_manager._inventory = inventory
    vars_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, vars_manager, None)

    host = inventory.get_host('localhost')

    # Set a nonpersistent fact
    hostvars.set_nonpersistent_facts(host, {'test_fact': 'value'})

    # `get_vars` should contain this fact
    assert hostvars.raw_get('localhost')['test_fact'] == 'value'

    # This fact should not persist in memory between runs
   

# Generated at 2022-06-21 09:28:46.342231
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader

    host_vars = HostVars(inventory=None, loader=DataLoader(), variable_manager=None)

    # Pass an invalid hostname, assert that we get back an AnsibleUndefined
    assert isinstance(host_vars['bad_hostname'], AnsibleUndefined)

    # Check that the undefined value has the correct name field
    assert host_vars['bad_hostname'].name == "hostvars['bad_hostname']"

# Generated at 2022-06-21 09:29:04.543337
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from collections import namedtuple
    import ansible.vars.hostvars
    import ansible.vars.manager

    PyClass = namedtuple('PyClass', ['value'])

    # The following code snippet tests for the fact that `set_nonpersistent_facts` method
    # of `HostVars` class first calls the same method of `VariableManager` class of
    # corresponding instance, and then clears the cache by calling `clear_facts_cache`
    # method of the instance.
    instance = ansible.vars.hostvars.HostVars(None, None, None)
    instance_vars_manager = ansible.vars.manager.VariableManager()

    def mock_clear_facts_cache(self):
        self.value = 1


# Generated at 2022-06-21 09:29:11.454247
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)

    assert 'foo' not in hostvars['localhost']

    foo = hostvars.set_host_variable(host=None, varname='foo', value='bar')

    assert 'foo' in hostvars['localhost']


# Generated at 2022-06-21 09:29:22.679316
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():

    class InventoryFake():

        def __init__(self, hosts=None):
            self.hosts = hosts if hosts else {}

        def get_host(self, host_name):
            return self.hosts[host_name]


    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars

    hosts = {
        'host1': {'vars': {'var1': 'value1'}},
        'host2': {'vars': {'var2': 'value2'}},
        'host3': {'vars': {'var3': 'value3'}}
    }

    inventory = InventoryFake(hosts)
    variable_manager = VariableManager()
    loader = None # not used


# Generated at 2022-06-21 09:29:28.378978
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import ansible.module_utils.common._collections_compat
    # Instantiate variables
    variables = {'a': '1', 'b': '2'}
    # Instantiate loader
    loader = ansible.module_utils.common._collections_compat.ModuleLoader()
    # Instantiate HostVarsVars
    hostvars_vars = HostVarsVars(variables, loader)
    # Test __getitem__
    assert hostvars_vars['a'] == '1'

# Generated at 2022-06-21 09:29:32.378958
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {'a': 'b'}
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)

    assert repr(hostvarsvars) == repr({'a': 'b'})

# Generated at 2022-06-21 09:29:42.980911
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    # DataLoader object is used to load internal data, such as facts or
    # vars plugins.
    loader = DataLoader()
    # create the variable manager, which will be shared throughout
    # the code, ensuring a consistent view of global variables
    variable_manager = VariableManager()
    # Set the variable manager to the data loader
    loader.set_variable_manager(variable_manager)
    # create the inventory, which can be used to filter any subset of
    # hosts for a play
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=["localhost,"])
    variable_manager.set_inventory(inventory)
    #create HostVars

# Generated at 2022-06-21 09:29:46.259415
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    loader = Mock()
    variables = {'test': 'value'}
    templar = Templar(variables=variables, loader=loader)
    host_vars_vars = HostVarsVars({'test': templar.template('value')}, loader)
    assert len(host_vars_vars) == 1


# Generated at 2022-06-21 09:29:51.683350
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():

    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(loader=None, variable_manager=VariableManager())
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=None)

    inventory.get_host('foo')
    inventory.get_host('bar')
    inventory.get_host('baz')

    assert 'foo' in hostvars
    assert 'bar' in hostvars
    assert 'baz' in hostvars
    assert 'invalidhost' not in hostvars

# Generated at 2022-06-21 09:29:58.396432
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(host_list=[])
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._inventory is inventory
    assert hostvars._variable_manager is variable_manager
    assert hostvars._loader is loader
    assert variable_manager._hostvars is hostvars


# Generated at 2022-06-21 09:30:09.743506
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible.plugins.loader as plugin_loader
    import ansible.vars.unsafe_proxy as unsafe_proxy
    from ansible.vars import VariableManager

    class DictLikeUnsafeProxy(unsafe_proxy.UnsafeProxy):
        def __init__(self, safe_object):
            self._safe_object = safe_object

        def __getitem__(self, key):
            if key not in self._safe_object:
                return 42
            return super(DictLikeUnsafeProxy, self).__getitem__(key)

    class DictLikeInfiniteRecursionUnsafeProxy(unsafe_proxy.UnsafeProxy):
        def __init__(self, safe_object):
            self._safe_object = safe_object


# Generated at 2022-06-21 09:30:18.498317
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    p = dict(a="2", b=[3,4,5], c="{{a}}{{b[0]}}")
    v = HostVarsVars(p, None)
    assert(repr(v) == repr({'a': 2, 'b': [3, 4, 5], 'c': 23}))



# Generated at 2022-06-21 09:30:26.552787
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    class TestLoader:
        vars = dict(hostvars=dict(localhost=dict(foo='123', bar='456')), foo='abc')

        def get_vars(self, *args, **kwargs):
            return self.vars

        def get_basedir(self, *args, **kwargs):
            return '.'

    loader = TestLoader()
    vars = dict(var='{{ hostvars[\"localhost\"][\"foo\"] }} {{ foo }}')
    hostvars = HostVarsVars(vars, loader=loader)
    assert hostvars['var'] == '123 abc'

# Generated at 2022-06-21 09:30:29.195517
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    vars = {'a': 'A', 'b': 'B', 'c': 'C'}
    assert set(HostVarsVars(vars, None)) == set(vars)


# Generated at 2022-06-21 09:30:34.784926
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_context = PlayContext()

    hostvars = HostVars(inventory, variable_manager, DataLoader())

    assert len(hostvars) == 1

    # Test if method __len__ works with empty inventory
    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())


# Generated at 2022-06-21 09:30:40.919010
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = dict(a=dict(b='{{abc}}', c="{{'a' in abc}}"), abc='foo')
    hostvars = HostVarsVars(variables, None)
    assert hostvars['a'] == dict(b='foo', c=True)
    assert hostvars['abc'] == 'foo'


# Generated at 2022-06-21 09:30:48.929752
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = FakeInventory()
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_nonpersistent_facts(inventory.get_host("testhost"), dict(foo="bar"))

    # assert
    assert variable_manager.get_nonpersistent_facts(inventory.get_host("testhost")) == dict(foo="bar")


# Generated at 2022-06-21 09:31:01.796141
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var

    foo_loader = object()
    foo_variable_manager = wrap_var(VariableManager())
    foo_variable_manager._loader = foo_loader
    foo_hostvars = wrap_var(HostVars(inventory=None,
                                     variable_manager=foo_variable_manager,
                                     loader=foo_loader))
    foo_variable_manager._hostvars = foo_hostvars

    foo_state = foo_hostvars.__getstate__()
    foo_state["_loader"] = None
    foo_state["_variable_manager"].__setstate__({"_loader": None, "_hostvars": None})



# Generated at 2022-06-21 09:31:06.990101
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    hostvars = HostVars(inventory, VariableManager(), loader)

    from ansible.inventory.host import Host
    h = Host('test')
    hostvars._inventory.add_host(h)

    assert 'test' in hostvars



# Generated at 2022-06-21 09:31:17.082159
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    '''
    Tests HostVars.__len__() with these conditions:
    - len(hv) returns 0 if len(hv._inventory) == 0
    - len(hv) returns len(hv._inventory) if len(hv._inventory) > 0
    '''

    # Test defaults
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    assert len(hv) == 0

    # Test with a non-empty inventory
    class Inventory(object):
        hosts = ['foo', 'bar', 'baz']

        def get_host(self, host_name):
            return host_name in self.hosts

    hv = HostVars(inventory=Inventory(), variable_manager=None, loader=None)
    assert len(hv) == 3


# Unit

# Generated at 2022-06-21 09:31:23.848285
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # need a playbook to setup self._loader backrefs
    pb = Playbook().load('fake', 'localhost', DataLoader(), variable_manager=VariableManager())

    loader = pb._loader
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    hosts = ["fakehost1", "fakehost2"]

# Generated at 2022-06-21 09:31:26.805458
# Unit test for constructor of class HostVars
def test_HostVars():
    assert True

# Generated at 2022-06-21 09:31:39.267942
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='''
        dbserver ansible_host=1.1.1.1
        webserver ansible_host=2.2.2.2
    ''')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    web_host = inventory.get_host("webserver")

# Generated at 2022-06-21 09:31:43.891092
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars.hostvars import HostVars
    from copy import deepcopy

    inventory = Mock()
    loader = Mock()
    variable_manager = Mock()
    hostvars = HostVars(inventory, variable_manager, loader)

    variables = {'hostvars': hostvars}
    deepcopy(variables)

# Generated at 2022-06-21 09:31:51.472440
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    '''
    Test that nonpersistent facts are indeed not saved.
    '''

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager()

    # Initialize HostVars
    host_vars = HostVars(inventory, variable_manager, loader)
    host_vars.set_variable_manager(variable_manager)

    # Add a host
    host = inventory.add_host(host='testhost')
    host_vars.set_host_facts(host, {'test_fact': 'test_fact_value'})

    # Add a nonpersistent fact and check that it

# Generated at 2022-06-21 09:31:54.773114
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.module_utils.common._collections_compat import NamedTuple

    def test_template(string, vars, fail_on_undefined=True, static_vars=None):
        return string

    loader = NamedTuple(path_exists=lambda _: False)
    vars = {'foo': 'baz', 'bar': '{{foo}}'}
    hvv = HostVarsVars(vars, loader)
    assert hvv['bar'] == vars['bar'] # noqa

# Generated at 2022-06-21 09:32:05.106824
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.facts.facts import Facts
    from ansible.vars import VariableManager

    class FakeHost(Mapping):
        def __init__(self, name):
            self.name = name

        def __getitem__(self, var):
            if var == 'ansible_facts':
                return 'fake-facts'

    class FakeInventory(Mapping):
        def __init__(self, hosts):
            self.hosts = hosts

        def __getitem__(self, var):
            return self.hosts

    # test when facts includes ansible_facts
    host = FakeHost('test-host')
    hostvars = HostVars(FakeInventory([host]), VariableManager())
    hostvars.set

# Generated at 2022-06-21 09:32:11.451995
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Variable 'inventory' is a variable of class HostVars.
    # As '__len__' does not use attribure 'inventory.hosts' to get the length of an object
    # the test verifies that '__len__' is still functional in the case of a
    # dummy inventory which does not have the attribute 'hosts'.
    inventory = 'AnsibleInventoryDummyWithoutHosts'
    variable_manager = 'AnsibleVariableManagerDummy'
    loader = 'AnsibleLoaderDummy'
    hv = HostVars(inventory, variable_manager, loader)

    assert hasattr(hv, '__len__')
    assert callable(getattr(hv, '__len__', None))
    assert hv.__len__() == 0


# Generated at 2022-06-21 09:32:14.688623
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars import VariableManager

    class MockLoader:
        pass

    vm = VariableManager()
    hvv = HostVarsVars(variables={'foo': 'bar'}, loader=MockLoader())
    assert 'foo' in hvv

# Generated at 2022-06-21 09:32:26.310021
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inv = [
        'localhost ansible_connection=local',
        'local2 something_else=bar',
        'local3',
    ]

    loader = DataLoader()
    loader.set_vault_password('dummy')

    inventory = InventoryManager(loader=loader, sources=inv)

    hv = HostVars(inventory, None, loader)

    assert 'local3' in hv                           # host local3 exists in inventory
    assert 'local3' in hv._inventory.hosts          # host local3 exists in inventory.hosts
    assert 'local3' not in inventory._hosts_cache   # host local3 does not exist in _hosts_cache

# Generated at 2022-06-21 09:32:37.911308
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.parsing.dataloader import DataLoader

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])

    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello world!')))
            ]
    )

    play = Play.load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 09:32:51.407175
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # Some global initialization
    import sys
    import os
    sys.path.insert(0, os.path.abspath('..'))
    from ansible.inventory import Inventory
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Init inventory and variables
    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=vars_manager, host_list='tests/inventory')

    # This is how we usually get hostvars, so let's do it here too
    vars_manager.set_inventory(inventory)
    vars_manager.extra_vars = dict()

    # Create our HostVars
   

# Generated at 2022-06-21 09:33:00.670408
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    assert variable_manager._hostvars == hostvars

    new_variable_manager = VariableManager()
    hostvars.set_variable_manager(new_variable_manager)

    assert new_variable_manager._hostvars == hostvars

# Generated at 2022-06-21 09:33:07.314761
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3
        }
    }

    loader = None
    hostvars_vars = HostVarsVars(variables, loader)
    assert list(hostvars_vars.__iter__()) == ['a', 'b', 'c']


# Generated at 2022-06-21 09:33:19.595906
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    def init_variable_manager():
        inventory = Inventory(loader=loader,
                              host_list=[])
        variable_manager = VariableManager(loader=loader, inventory=inventory)
        return variable_manager

    variable_manager = init_variable_manager()

    hostvars = HostVars(inventory=variable_manager._inventory,
                        variable_manager=variable_manager._variable_manager,
                        loader=variable_manager._loader)

    rep = hostvars.__repr__()
    assert rep == repr({})

    variable_manager = init_variable_manager()

    data = {u'foo': u'bar'}

    variable

# Generated at 2022-06-21 09:33:27.513375
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    class HostVarsMock(HostVars):
        # Mocking __contains__ method to stub behavior of get_host method and
        # ansible.utils.unsafe_proxy.AnsibleUnsafeText when it was used as:
        #     hostvars[host.name] = hostvars[host.name].copy()
        def __contains__(self, host_name):
            return host_name == 'localhost'

        def __getitem__(self, host_name):
            data = super(HostVarsMock, self).__getitem__(host_name)

# Generated at 2022-06-21 09:33:38.785179
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Arrange
    from ansible.playbook.play import Play

    from ansible.vars import VariableManager

    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleUndefinedVariable

    from ansible.cli.playbook import PlaybookCLI

    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.template import Templar
    from ansible.plugins.loader import add_all_plugin_dirs

    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    from ansible.vars import VariableManager



# Generated at 2022-06-21 09:33:49.150241
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = dict()
    play_source = dict(
        name="test play",
        hosts='localhost',
        gather_facts='no',
        tasks=[],
    )
    play = Play.load(play_source, variable_manager=variable_manager, loader=loader)
    host = inventory.get_host('localhost')

    variable_manager.set_host_variable(host, 'foo', 'bar')
    variable_manager

# Generated at 2022-06-21 09:34:01.226307
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars import VariableManager
    from ansible.inventory import Host, Inventory
    from ansible.playbook.play_context import PlayContext

    # Create fake inventory
    inventory = Inventory(host_list=[])
    inventory.add_host(Host(name="localhost"))

    # Create fake variable manager
    variable_manager = VariableManager(loader=None)
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = dict(test_result=0)

    # Create fake play context
    play_context = PlayContext()

    # Generate a valid module argument spec

# Generated at 2022-06-21 09:34:09.986597
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {'host1': {'var1': 'value1'}}}

    loader = DataLoader()

    hostvars = HostVars(None, variable_manager, loader)

    assert repr(hostvars) == "{'host1': {'var1': 'value1'}}"

# Generated at 2022-06-21 09:34:16.265094
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    hostvars = HostVars(Inventory(loader=None, variable_manager=variable_manager, host_list=[u'localhost']),
                        variable_manager=variable_manager, loader=None)

    assert len(hostvars) == 1



# Generated at 2022-06-21 09:34:35.278027
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.plugins import get_all_plugin_loaders
    from ansible.plugins.loader import PluginLoader

    # Create vars_cache where the only value is HostVars.
    # Use variable manager that has the same loader as the HostVars
    # object which is created during ansible-playbook execution.
    variable_manager = PluginLoader('VariableManager', 'ansible.vars.manager', get_all_plugin_loaders()).all().pop()
    loader = variable_manager._loader
    vars_cache = { 'hostvars' : HostVars({}, variable_manager, loader) }
    # vars_cache is a simple mapping, therefore a deepcopy is enough.
    vars_cache_copy = vars_cache.copy()

    # Test that HostVars implement __deepcopy__ and thus
    # their

# Generated at 2022-06-21 09:34:48.287155
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    inventory = mock.Mock()
    variable_manager = mock.Mock()
    loader = mock.Mock()

    hostvars = HostVars(inventory, variable_manager, loader)

    # When host is not in _inventory.hosts, host.set_variable is not called.
    hostvars.set_host_variable(None, 'foo', 'bar')
    assert variable_manager.set_host_variable.called is False

    # When host is in _inventory.hosts, host.set_variable is called once.
    host = mock.Mock()
    host.get_name.return_value = 'local'
    inventory.hosts = [host]
    hostvars.set_host_variable(host, 'foo', 'bar')
    assert variable_manager.set_host_variable.called is True
   

# Generated at 2022-06-21 09:34:59.703556
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    inventory.add_host(host='example.com')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_facts('example.com', {'foo': 'bar'})
    assert hostvars.raw_get('example.com')['foo'] == 'bar'
    assert hostvars.raw_get('example.com')['ansible_facts'] == {'foo': 'bar'}

# Generated at 2022-06-21 09:35:07.034337
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    '''
    Unit test for method set_host_variable of class HostVars
    '''
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    host = inventory.get_host('localhost')
    variables = VariableManager(loader=DataLoader(), host_list=[host.name])
    hostvars = HostVars(inventory, variables)

    hostvars.set_host_variable(host, 'x', 1)
    assert type(hostvars[host.name]) == HostVarsVars
    assert hostvars[host.name]['x'] == 1


# Generated at 2022-06-21 09:35:16.103532
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    class DummyLoader:
        def __init__(self, variables):
            self._vars = variables
        def get_basedir(self, path):
            return 'foo'
        def get_vars(self, path):
            return self._vars

    variables = dict(a='b')
    loader = DummyLoader(variables)
    v = HostVarsVars(variables, loader)
    assert(v.__contains__('a'))
    assert(not v.__contains__('b'))

# Generated at 2022-06-21 09:35:23.746725
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'other_host,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # First set a non-persistent fact for localhost
    localhost = inventory.hosts['localhost']
    hostvars.set_nonpersistent_facts(localhost, { 'foo': 'bar' })
    assert localhost.vars['foo'] == 'bar'
    assert localhost.all_vars['foo'] == 'bar'

# Generated at 2022-06-21 09:35:35.688433
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(host=inventory.get_host('localhost'), varname='test', value='value')
    assert hostvars['localhost']['test'] == 'value'

# Generated at 2022-06-21 09:35:45.104422
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.hostvars import HostVars, HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # the new view of hostvars we are testing
    hv = HostVarsVars({'a': AnsibleUnsafeText('{{ b }}'), 'b': 'hello', 'c': 12}, loader=None)

    # variables should be templated as needed
    assert hv['a'] == 'hello'

    # non-strings should be returned as-is
    assert hv['c'] == 12

    # HostVars should be immutable, and thus not be changed by the templating
    assert hv._vars['a'] is not 'hello'
    assert hv._vars['a'] == '{{ b }}'

# Generated at 2022-06-21 09:35:50.724731
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = DictDataLoader({
        "group_vars/all": "foo: 1"
    })
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    variables = inventory.get_group_variables()
    hostvars = HostVarsVars(variables, loader)

    assert hostvars['foo'] == 1
    assert 'foo' in hostvars
    assert 'bar' not in hostvars
    assert len(hostvars) == 1

# Generated at 2022-06-21 09:36:01.148213
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager

    # Create a simple inventory of two hosts and a group
    hosts = [
        'alpha',
        'beta',
    ]
    vars_alpha = {
        'var_alpha': 'value_alpha',
    }
    vars_beta = {
        'var_beta': 'value_beta',
    }
    groups = [
        'group_one:alpha:beta',
        'group_two:alpha',
    ]
    hosts_vars = {}
    for host in hosts:
        hosts_vars[host] = []
    hosts_vars['alpha'] = vars_alpha
    hosts_vars['beta'] = vars_beta

# Generated at 2022-06-21 09:36:30.267047
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # In absence of inventory limit hosts are iterated in insertion order.
    inventory = FakeInventory()
    hosts = ['localhost', 'otherhost']
    for host in hosts:
        inventory.add_host(host)
    hostvars = HostVars(inventory, FakeVariableManager(), FakeLoader())
    assert [host for host in hostvars] == hosts

    # In presence of inventory limit hosts are iterated in inventory ordering.
    inventory = FakeInventory(pattern='all')
    inventory.add_host('otherhost')
    inventory.add_host('localhost')
    hostvars = HostVars(inventory, FakeVariableManager(), FakeLoader())
    assert [host for host in hostvars] == hosts


# Generated at 2022-06-21 09:36:40.998339
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['inventories/sample'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Test accessing hostvars of a host which is not in inventory and not localhost
    # If a host is not in inventory, __getitem__ should return an AnsibleUndefined object.
    host_name = 'non_exist_host'
    hostvars_of_non_exist_host = hostvars[host_name]

# Generated at 2022-06-21 09:36:46.134451
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    host_vars = HostVars(InventoryManager(loader=DataLoader(), sources=[]),
                         VariableManager(loader=DataLoader()),
                         DataLoader())

    pickled_host_vars = pickle.dumps(host_vars)
    unpickled_host_vars = pickle.loads(pickled_host_vars)

    # Test whether attributes of the unpickled objects are not None
    assert unpickled_host_vars._inventory is not None
    assert unpickled_host_vars._loader is not None
    assert unpickled_host_vars._variable_manager is not None

# Generated at 2022-06-21 09:36:53.024953
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import pprint
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory

    iv = Inventory('localhost,')
    mv = VariableManager()
    hv = HostVars(inventory=iv, variable_manager=mv, loader=None)
    hv._vars = {'a': '{{ b }}'}
    hv._vars['b'] = 'hello'
    assert repr(hv) == "{'localhost': {'a': 'hello', 'b': 'hello'}}"
    pprint.pprint(hv) # Makes sure pprint does not raise exception.

    del hv._vars['b']
    hv._vars['b'] = AnsibleUndefined(name='b')

# Generated at 2022-06-21 09:37:05.638176
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    import ansible.vars
    import ansible.variables
    import ansible.inventory
    import ansible.parsing.dataloader

    loader = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.Inventory(loader=loader,
                                            host_list=[])
    variable_manager = ansible.variables.VariableManager(loader=loader,
                                                         inventory=inventory)
    hostvars = ansible.vars.HostVars(inventory=inventory,
                                     variable_manager=variable_manager,
                                     loader=loader)

    group = ansible.inventory.Group(name="group")

# Generated at 2022-06-21 09:37:17.340829
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleOptionsError, AnsibleUndefinedVariable
    from ansible.plugins.loader import vars_loader
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.six import string_types

    variable_manager = VariableManager()
    variable_manager.add_loader(vars_loader)
    host = variable_manager.get_vars(host=None)
    host_name = 'localhost'
    variable_manager.set_host_variable(host_name, "var_a", "var_a")

    hostvars = HostVarsVars(host, loader=None)

    # test if variable exists in the hostvars mapping