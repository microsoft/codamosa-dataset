

# Generated at 2022-06-21 09:27:27.750607
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert HostVarsVars({'a': 1, 'b': 2, 'c': 3}, None).__len__() == 3


# Generated at 2022-06-21 09:27:38.394771
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    def patch(args, _1, _2):
        return args

    def assert_repr_invariant(vars_dict):
        inv = InventoryManager([], loader=loader)
        vars_manager = VariableManager(loader=loader, inventory=inv)
        vars_manager.set_host_variable(host, 'vars', vars_dict)
        hostvars = HostVars(inventory=inv, variable_manager=vars_manager, loader=loader)
        assert_repr_content(hostvars, vars_dict)


# Generated at 2022-06-21 09:27:50.316411
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    class TestInventory(object):
        def __init__(self):
            self.hosts = []

        def get_host(self, host_name):
            class TestHost(object):
                def __init__(self, host_name):
                    self.name = host_name
                    self.vars = {'ansible_version': 1.2}
            if host_name in self.hosts:
                return TestHost(host_name)
            return None

    class TestVariableManager(object):
        def __init__(self):
            self.vars_cache = {'hostvars': {'host1': {'hostvar': 'host1'}, 'host2': {'hostvar': 'host2'}}}


# Generated at 2022-06-21 09:27:53.553333
# Unit test for constructor of class HostVars

# Generated at 2022-06-21 09:28:03.014166
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    base_hostvars = dict(
        ansible_connection='local', 
        ansible_host='127.0.0.1',
        ansible_user='user1',
        ansible_port=22,
        ansible_ssh_private_key_file='../key',
        ansible_ssh_common_args=''
        )

    # create the inventory, and populate it with hosts/groups/vars
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    host = inventory.get_host('localhost')

    # create the variable manager, which will be shared throughout
    # the code, ensuring a consistent view of global variables


# Generated at 2022-06-21 09:28:06.048330
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class FakeLoader:
        pass

    expected = {
        'key1': 1,
        'key2': 2
    }
    output = HostVarsVars(expected, FakeLoader())
    assert repr(output) == repr(expected)

# Generated at 2022-06-21 09:28:16.316645
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from unittest import TestCase
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class HostVarsTest(HostVars):
        def __init__(self, inventory, variable_manager, loader, hostvars):
            super(HostVarsTest, self).__init__(inventory, variable_manager, loader)
            self._hostvars = hostvars

    class TestHostVars(TestCase):
        def test__deepcopy__(self):
            from copy import deepcopy
            loader = None
            inventory = None
            hostvars = 'foo'
            variable_manager = UnsafeProxy({'_loader': loader, '_hostvars': hostvars})
            hostvars = HostVarsTest(inventory, variable_manager, loader, hostvars)
            new_hostvars = deepcopy

# Generated at 2022-06-21 09:28:25.295695
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    my_inventory = InventoryManager(loader=DataLoader(), sources='localhost,')

    variable_manager = VariableManager(loader=DataLoader(), inventory=my_inventory)

    hv = HostVarsVars({'test_string': '{"test": "{{test_string}}"}'}, my_inventory._loader)

    assert hv['test_string'] == '{"test": {"test": "{{test_string}}"}}'

    assert hv['test_string'] == {"test": {"test": "{{test_string}}"}}

# Generated at 2022-06-21 09:28:32.810693
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Create inventory with a single host
    from ansible.inventory import Inventory
    hosts_vars = {
        'myhost': {
            'ansible_persistent_facts': {
                'foo': 'bar',
            },
            'ansible_nonpersistent_facts': {
            },
            'ansible_local': {
                'x': 'y',
            },
        },
        '_meta': {
            'hostvars': {
                'myhost': {
                    'ansible_persistent_facts': {
                        'foo': 'bar',
                    },
                    'ansible_nonpersistent_facts': {
                    },
                    'ansible_local': {
                        'x': 'y',
                    },
                },
            },
        },
    }

# Generated at 2022-06-21 09:28:40.933342
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # create dummy inventory, variable_manager and loader
    inventory = type('DummyInventory', (), {'hosts': [1, 2]})()
    variable_manager = type('DummyVariableManager', (), {})()
    loader = type('DummyLoader', (), {})()

    # Test with empty hosts
    assert list(HostVars(inventory, variable_manager, loader).__iter__()) == []

    # Test with hosts
    inventory.hosts = [1, 2]
    assert list(HostVars(inventory, variable_manager, loader).__iter__()) == [1, 2]


# Generated at 2022-06-21 09:28:53.038973
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    inventory = InventoryManager(loader=C.DEFAULT_LOADER, sources=['localhost,'])
    variable_manager = VariableManager(loader=C.DEFAULT_LOADER, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=C.DEFAULT_LOADER)

    hostvars.set_host_variable(inventory.get_host('localhost'), 'test_var', 'test_value')
    assert hostvars['localhost']['test_var'] == 'test_value'
    hostvars.set_host_variable(inventory.get_host('localhost'), 'test_var', 'test_value2')

# Generated at 2022-06-21 09:29:05.936113
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.plugins.loader import inventory_loader

    display = Display()

    source = """
    one
    two
    """

    ds = inventory_loader.get('yaml_list', loader=DataLoader())
    inventory = InventoryManager(loader=ds, display=display, sources=[source])
    v = VariableManager(loader=ds, inventory=inventory)
    h = HostVars(inventory, v, ds)

    target_host = inventory.get_host('one')

    # Set nonpersistent facts for target host

# Generated at 2022-06-21 09:29:15.978395
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create necessary objects required by set_host_variable
    inventory = Inventory(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager._vars_cache = {'_ansible_start_task': True}
    variable_manager._vars_per_host = {}
    variable_manager._vars_per_group = {}
    variable_manager._extra_vars = {}

    # Create HostVars object to be tested
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    # Create dummy host
    host = inventory.get_host('localhost')

# Generated at 2022-06-21 09:29:25.124281
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    vars_cache = {}
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory={}, variable_manager=variable_manager, loader=loader)

    # Assign some random value to attribute _hostvars.
    # It will be unset by __setstate__
    hostvars._hostvars = 'not empty'
    pickled_hostvars = pickle.dumps(hostvars)
    hostvars_unpickled = pickle.loads(pickled_hostvars)

    assert hostvars_unpickled._hostvars is hostvars_unpickled._variable_manager._hostv

# Generated at 2022-06-21 09:29:36.554881
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    vars = dict(a=1, b=2, c=wrap_var(AnsibleUnsafeText('{{foo}}')))
    with patch('ansible.template.Templar') as mock_templar:
        templar_instance = MagicMock()
        templar_instance.template.return_value = {'a': 1, 'b': 2, 'c': wrap_var(AnsibleUnsafeText('bar'))}
        mock_templar.return_value = templar_instance
        hvv = Host

# Generated at 2022-06-21 09:29:42.416379
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variables = {'hostvars': {'host1': {'foo': 'bar'}}}
    inventory = InventoryManager(loader=DataLoader(), sources="localhost")
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory, version_info=dict(git_commit='...'))
    loader = DataLoader()
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_vars = hostvars.get('localhost')
    assert repr(hostvars_vars) == "{'foo': 'bar'}"

# Generated at 2022-06-21 09:29:48.718457
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import os
    import sys
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.template
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hostvars_test_inventory')
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources=inv_path)
    variable_manager = ansible.vars.manager.VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(hostvars._find_host('local'), 'foo', 'bar')
    state = hostv

# Generated at 2022-06-21 09:29:58.847105
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Initialization
    host_vars_data = {}
    host_vars_data_orig = {}
    hosts_data = {}
    hosts_data_orig = {}
    facts_data = {}
    facts_data_orig = {}
    inventory = type('', (object,), {
        'get_host': lambda self, host_name: hosts_data.get(host_name, None),
    })()

# Generated at 2022-06-21 09:30:10.047301
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    for ansible_version in [ "1.9.4", "stable-1.8" ]:
        from units.mock.loader import DictDataLoader
        from units.mock.inventory import Host, Inventory

        def add_variable(host, varname, value):
            host.vars[varname] = value

        loader = DictDataLoader({})
        inventory = Inventory(loader)
        inventory.add_host(Host("testhost", None))

        variable_manager = VariableManager(loader=loader, inventory=inventory)
        variable_manager.extra_vars = dict(ansible_version=ansible_version)

        hostvars = HostVars(inventory, variable_manager, loader)

        # test several different ways that a host can be created
        # dynamically in the inventory by checking if the host
        # can be

# Generated at 2022-06-21 09:30:23.013679
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Unit test for method __getitem__ of class HostVars
    '''

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'foo': 'bar'}

    hostvars = HostVars(variable_manager=variable_manager, loader=loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')

    foo = hostvars['localhost']
    assert foo['foo'] == 'bar'

    # Test registered variables
    hostvars.set_host_variable('localhost', 'ansible_host', 'example.com')
    hostvars.set_

# Generated at 2022-06-21 09:30:34.339956
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=None, sources=[])
    inventory.add_host(Host('h1'))
    inventory.add_host(Host('h2'))

    hostvars = HostVars(inventory, None, None)
    assert('h1' in hostvars)
    assert('h2' in hostvars)

    # Try to trigger an error by using vars cache one more time
    # after it has been destroyed
    hostvars_cache = hostvars._variable_manager._vars_cache
    del hostvars

    inventory.add_host(Host('h3'))
    hostvars_cache.set_inventory(inventory)

    assert('h1' in hostvars_cache)

# Generated at 2022-06-21 09:30:42.360468
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class FakeLoader(object):
        def __init__(self):
            self.template_paths = []

    loader = FakeLoader()

    vars_ = {'ansible_connection': 'test',
             'ansible_ssh_port': 9999,
             'ansible_python_interpreter': 'test'}
    hostvars_vars = HostVarsVars(vars_, loader=loader)

    assert 'ansible_connection' in hostvars_vars

# Generated at 2022-06-21 09:30:51.763725
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    loader = lambda *args: None
    variables = {'test': ['a', 'b', 'c']}
    assert HostVarsVars(variables, loader)['test'] == ['a', 'b', 'c']

    variables = {'test': ['a', 'b', 'c'], 'foo': '{{ bar }}', 'bar': '{{ test[0] }}'}
    hostvarsvars = HostVarsVars(variables, loader)
    assert hostvarsvars['test'] == ['a', 'b', 'c']
    assert hostvarsvars['foo'] == hostvarsvars['bar'] == 'a'


# Generated at 2022-06-21 09:31:03.466345
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    ansible_all_hosts_inventory='[all]' \
                           '\nlocalhost ansible_connection=local,' \
                               '\nansible_ssh_user=mobaxterm,' \
                               '\nansible_host=127.0.0.1,' \
                               '\nansible_ssh_pass=xxxxxxxx,' \
                               '\nansible_port=8022'
    # write to a temporary file, which Ansible inventory loader supports.
    with open('test_inventory', 'w') as f:
        f.write(ansible_all_hosts_inventory)

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()

# Generated at 2022-06-21 09:31:14.887693
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestInventory(InventoryManager):

        def __init__(self, loader, sources=None):
            super(TestInventory, self).__init__(loader=loader, sources=sources)
            self.hosts['test'] = "test"

    inventory = TestInventory(loader=DataLoader(), sources=[])
    vars_manager = VariableManager(loader=inventory._loader)
    hostvars = HostVars(inventory=inventory, variable_manager=vars_manager, loader=inventory._loader)

    hostvars.set_host_variable('test', 'test_variable', 'test_value')


# Generated at 2022-06-21 09:31:22.233464
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(
        loader=None,
        sources=[
            "localhost ansible_connection=local",
            "other ansible_connection=local ansible_foo=bar",
        ]
    )

    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Raw get should not expand variables in hostvars
    assert hostvars.raw_get("localhost")["ansible_foo"] == "hostvars.ansible_foo"
    assert hostvars.raw_get("other")["ansible_foo"] == "bar"

    # Get should expand variables in hostvars

# Generated at 2022-06-21 09:31:24.367628
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    inventory = Inventory("")
    inventory.add_group(group='nogroup')
    hostvars = HostVars(inventory, None, None)
    assert len(hostvars) == 1

# Generated at 2022-06-21 09:31:35.298218
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    loader = None
    inventory = Inventory(loader=loader)
    inventory.hosts = dict((host, 1) for host in ['test1','test2','test3'])
    variable_manager = VariableManager(loader=loader)

    hv = HostVars(inventory, variable_manager, loader)

    for host in inventory.hosts:
        hv.set_nonpersistent_facts(host, dict((fact, True) for fact in ['fact1','fact2','fact3']))

    for host in inventory.hosts:
        # Check that set_nonpersistent_facts method is adding values to host.vars dictionary
        assert len(variable_manager.get_vars(host=host, include_hostvars=False)) == 3
        #

# Generated at 2022-06-21 09:31:45.230727
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    hosts = [h for h in hostvars]
    assert hosts == []

    host = inventory.get_host('localhost')
    hosts = [h for h in hostvars]
    assert hosts == [host]

# Generated at 2022-06-21 09:31:56.930941
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    vars_cache = {}
    facts_cache = {}
    inventory = None
    variable_manager = VariableManager(loader=loader, inventory=inventory, vars_cache=vars_cache, facts_cache=facts_cache)

    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars_copied = deepcopy(hostvars)

    assert hostvars.setdefault is hostvars_copied.setdefault
    assert hostvars.get is hostvars_copied.get
    assert hostvars.__repr__ is hostvars_copied.__repr__
    assert hostvars.__str__ is hostvars_copied.__str__

# Generated at 2022-06-21 09:32:20.252930
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inv = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    vars_manager = VariableManager(loader=DataLoader())

    hostvars = HostVars(inv, vars_manager, DataLoader())
    hostvars.set_inventory(None)
    assert hostvars._inventory is None

    hostvars.set_inventory(inv)
    assert hostvars._inventory == inv

# Generated at 2022-06-21 09:32:29.237189
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class Inventory(object):
        def __init__(self):
            self.hosts = ['foo', 'bar']

    class VariableManager(object):
        def __init__(self):
            self.vars_cache = {'foo':'bar', 'blammo':'blazz'}

    class Loader(object):
        def __init__(self):
            pass

    hv = HostVars(Inventory(), VariableManager(), Loader())
    for host in hv:
        assert host in ['foo', 'bar']
        assert host in hv

# Generated at 2022-06-21 09:32:40.523138
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    from ansible.inventory.host import Host

    loader = None # We do not need real loader
    inventory = None # We do not need real inventory

    variable_manager = AnsibleVariableManager(loader=loader)
    variables = variable_manager.get_vars(host=Host(name='host1'), include_hostvars=False)
    assert isinstance(variables, dict)

    hostvars_vars = HostVarsVars(variables, loader=loader)
    assert isinstance(hostvars_vars, HostVarsVars)

    hostvars = HostVars(inventory, variable_manager, loader)
    assert isinstance(hostvars, HostVars)

    assert hostvars_vars is copy.deepcopy(hostvars_vars)
    assert hostvars is copy.deep

# Generated at 2022-06-21 09:32:45.039860
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    inventory = {}
    variables = dict(a='a')
    variable_manager = FakeVariableManager(variables=variables)
    loader = FakeLoader()
    hostvars = HostVars(inventory, variable_manager, loader)
    hv = hostvars['foo']
    assert hv == variables


# Generated at 2022-06-21 09:32:56.969183
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import vars as vars_loader
    from ansible.parsing.vars import VariableManager as OldVariableManager

    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader, sources=['tests/test_data/test_vars_inventory'])
    host = inventory.get_host(u'localhost')

    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=dataloader)

    # Check that host 'example.com' is not in HostVars before
    # adding it to inventory
    assert u'example.com' not in host

# Generated at 2022-06-21 09:33:05.136649
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = DictDataLoader({'foo.yaml': '{"a": 1}\n'})
    inventory = InventoryManager(loader=loader)
    host = Host('host1')
    variables = {'a': 1, 'vars': {'b': 2}, 'hostvars': {'host1': {'c': 3}}}
    variable_manager = VariableManager(loader=loader, variables=variables)
    variable_manager.set_host_variable(host=host, varname='d', value=4)
    inventory.add_host(host)

# Generated at 2022-06-21 09:33:17.116979
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import ansible
    from ansible import constants as C
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)

    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['localhost,'])

    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 09:33:21.126367
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    hostvars_vars = HostVarsVars({
        "var": "value"
    }, None)

    # It should return the raw value
    assert hostvars_vars["var"] == "value"

# Generated at 2022-06-21 09:33:29.150816
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    loader = object
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(None, variable_manager, loader)

    new_variable_manager = VariableManager(loader=loader)
    hostvars.set_variable_manager(new_variable_manager)

    assert hostvars._variable_manager is new_variable_manager
    assert new_variable_manager._loader is loader
    assert new_variable_manager._hostvars is hostvars

# Generated at 2022-06-21 09:33:40.210947
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    class Fake_Host(object):
        def __init__(self, name):
            self.name = name

    class Fake_Group(object):
        def __init__(self, name, hosts=None):
            self.name = name
            if hosts is None:
                self.hosts = []
            else:
                self.hosts = hosts

    class Fake_Inventory(object):
        def __init__(self, hosts, groups):
            self.hosts = hosts
            self.groups = groups
            self.host_cache = {}

        def get_host(self, hostname):
            if hostname in self.host_cache:
                return self.host_cache[hostname]

# Generated at 2022-06-21 09:34:10.673205
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    ''' HostVarsVars.__iter__()'''
    vars_data = {'a': '1', 'b': '2'}
    check_vars = HostVarsVars(vars_data, loader=None)
    assert set(check_vars) == set(vars_data), "HostVarsVars.__iter__()"
    assert set(check_vars._vars) == set(vars_data), "HostVarsVars.__iter__()"

# Generated at 2022-06-21 09:34:11.745249
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    assert len(HostVarsVars({'a': 1, 'b': 2}, None)) == 2

# Generated at 2022-06-21 09:34:20.768445
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.host import Host
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # Create an empty inventory
    loader = DataLoader()
    vault_lib = VaultLib(loader=loader)
    loader.set_vault_secrets(vault_lib.secrets)
    inventory = InventoryManager(loader=loader, sources='')
    inventory.set_variable_manager(VariableManager(loader=loader, inventory=inventory, vault_secrets=vault_lib.secrets))

    # Create a group
    group = inventory.add_

# Generated at 2022-06-21 09:34:32.157908
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import tempfile

    # Create necessary objects
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=[])
    inventory.add_group('not_localhost')
    inventory.add_group('localhost')
    inventory.add_host(host=inventory.localhost)
    inventory.add_host(host=inventory.get_host('not_localhost'))

    (fd, path) = tempfile.mkstemp()

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    loader.set_basedir(path)

    from ansible.vars.manager import VariableManager

    variables = VariableManager(loader=loader, inventory=inventory)

    # Test

# Generated at 2022-06-21 09:34:44.704649
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # Use a fake inventory
    from ansible.inventory.manager import InventoryManager
    from io import BytesIO
    inv = InventoryManager(
        loader=None,
        sources=[BytesIO(b"[all]\nlocalhost ansible_connection=local")]
    )
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inv)
    hostvars = HostVars(inv, variable_manager, loader)

    # set a fake fact
    host = inv.get_host("localhost")
    hostvars.set_host_facts(host, {"foo": "bar"})
    assert hostvars.get("localhost", {}).get("foo", None) == "bar"

# Generated at 2022-06-21 09:34:47.496306
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import pytest
    hostvars = HostVarsVars(dict(a=1,b=2), loader=None)
    assert len(tuple(hostvars)) == 2

# Generated at 2022-06-21 09:34:59.474209
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play

    class TestTaskQueueManager(TaskQueueManager):

        def _initialize_processes(self, num):
            pass

    loader = DataLoader()
    variable_manager = VariableManager()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.add_host(host='localhost')
    # create the variable before testing __repr__ method
    hostvars['localhost']['foo'] = 1

# Generated at 2022-06-21 09:35:05.298663
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader, 'localhost')
    host = inventory.get_host('localhost')
    vm = VariableManager(loader=loader, inventory=inventory)

    hvv = HostVarsVars(vm.get_vars(host=host), loader=loader)
    assert hvv['inventory_hostname'] == 'localhost'
    assert hvv['inventory_hostname_short'] == 'localhost'
    assert hvv['ansible_version'] != ''

# Generated at 2022-06-21 09:35:17.070640
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    inventory.add_group('group1')
    host1 = inventory.add_host(name='host1', group='group1')
    hostvars = HostVars(inventory, VariableManager(), loader)
    hostvars.set_nonpersistent_facts(host1, {'group2': 'host1'})

# Generated at 2022-06-21 09:35:24.114012
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import sys
    import os
    from mock import patch
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    class MyArgs(object):
        module_path = None
        forks = 100
        become = False
        become_method = None
        become_user = None
        check = False
        extra_vars = [u'ansible_user=vagrant']
        syntax = False
        start_at_task = None
        verbosity = 0



# Generated at 2022-06-21 09:35:55.327132
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Check if the templating engine expands variables.
    class Loader:
        def __init__(self):
            pass

        def get_basedir(self, host):
            return ''

        def load_from_file(self, path):
            return ''

    loader = Loader()

    class Host:
        name = 'test_host'

    test_vars = {'var1': 'value1', 'var2': 'value2', 'var3': '{{var1}}', 'var4': '{{nested.var3}}'}
    current_host = Host()
    class VariableManager:
        def __init__(self):
            self.host_vars_patterns = [test_vars]
            self.extra_vars = dict()


# Generated at 2022-06-21 09:36:03.184347
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    # Hostvars is empty if inventory has no hosts
    assert not hostvars.raw_get('test_host')

    # Add a host to the inventory
    inventory.add_host('test_host')

    # Hostvars is not empty if the host is in the inventory
    assert hostvars.raw_get('test_host') is not None

    # The host is available even if it was not loaded from the inventory
    inventory.remove_host('test_host')
    assert hostvars

# Generated at 2022-06-21 09:36:08.518712
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory

    vars_manager = DummyVariableManager()
    loader = DummyLoader()
    hostvars = HostVars(Inventory(loader=loader), vars_manager, loader)

    for host in hostvars:
        pass

    assert len(hostvars) == 3
    assert list(hostvars)[0] == 'host0'
    assert list(hostvars)[1] == 'host1'
    assert list(hostvars)[2] == 'host2'



# Generated at 2022-06-21 09:36:11.713634
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.hostvars import HostVarsVars

    hostvarsvars = HostVarsVars({'a': 'a'}, loader=None)
    assert 'a' in hostvarsvars
    assert 'b' not in hostvarsvars

# Generated at 2022-06-21 09:36:17.637920
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.playbook.play_context import PlayContext

    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    inventory = dict(foo='bar')
    hostvars._inventory = inventory

    play_context = PlayContext()
    hostvars._variable_manager = play_context.variable_manager

    assert repr(hostvars) == repr(inventory)

# Generated at 2022-06-21 09:36:27.234374
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars.hostvars import HostVarsVars
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Test data
    variables = {'a': 1, 'b': 2, 'c': 3}
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Temporary fix the random order of dict
    variables = dict(sorted(variables.items()))

    # Init HostVarsVars
    hostvars_vars = HostVarsVars(variables, loader)

    assert len(hostvars_vars) == len(variables)
    assert len(hostvars_vars) == 3

# Generated at 2022-06-21 09:36:35.425697
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import os
    import tempfile
    import yaml
    import shutil
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary inventory file
    fichier_ini = os.path.join(tmp_dir, "ansible_hosts")
    with open(fichier_ini, "w") as f:
        f.write("""\
[group1]
localhost ansible_port=22 ansible_host=127.0.0.1
[group2]
testserver.example.com
""")

    # Create the Ansible inventory

# Generated at 2022-06-21 09:36:38.485622
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    class FakeHostVars(HostVars):
        def __init__(self, *args, **kwargs):
            super(FakeHostVars, self).__init__(*args, **kwargs)
            self._variable_manager = None

    h = FakeHostVars(inventory=None, variable_manager=None, loader=None)

    h.set_variable_manager(object())
    assert h._variable_manager is not None

    h.set_variable_manager(None)
    assert h._variable_manager is None

# Generated at 2022-06-21 09:36:43.432860
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    inventory = 'test'
    variable_manager = 'variable_manager'
    loader = 'loader'
    hostvars = HostVars(inventory, variable_manager, loader)
    new_inventory = 'new_inventory'
    hostvars.set_inventory(new_inventory)
    assert new_inventory == hostvars._inventory


# Generated at 2022-06-21 09:36:51.470974
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy
    import ansible.vars.hostvars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    group = Group(name='group')
    group.add_host(Host(name='host1'))
    group.add_host(Host(name='host2'))

    inventory = ansible.inventory.Inventory([group])