

# Generated at 2022-06-21 09:27:35.874505
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    loader = DataLoader()
    variable_manager = VariableManager()

    kwargs = {
        'loader': loader,
        'variable_manager': variable_manager,
        'inventory': Inventory(loader=loader, variable_manager=variable_manager),
        }

    assert HostVars(**kwargs)

# Generated at 2022-06-21 09:27:42.974527
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    variable_manager = VariableManager()
    inventory = Inventory()
    hostvars = HostVars(inventory, variable_manager, None)
    host = inventory.get_host('localhost')
    hostvars.set_host_variable(host, 'ansible_distribution', 'Fedora')
    if hostvars.raw_get('localhost').get('ansible_distribution') == 'Fedora':
        print('SUCCESS: ansible_distribution is set to %s' % hostvars['localhost']['ansible_distribution'])
    else:
        print('FAILED: ansible_distribution should be set to Fedora')

# Generated at 2022-06-21 09:27:55.047798
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os
    import sys

    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    class Options(object):
        def __init__(self):
            self.connection = 'smart'
            self.module_path = None
            self.forks = 5
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.diff = False
            self.syntax = None
            self.sudo = True
            self.sudo_user = 'root'
            self.private_key_file = None
            self.listhosts

# Generated at 2022-06-21 09:28:04.365994
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # See [1] for the reason why we use MagicMock rather than
    # direct inheritance of Mock, which was used in the original unit
    # test.
    #
    # [1]: http://stackoverflow.com/a/38991586/3573389
    import mock
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.utils.vars import HostVars, HostVarsVars

    # We need to mock methods of class HostVarsVars because after
    # successful execution of its method __repr__ object variables
    # (self._vars) may be modified and we need the object in the original
    # state.
    class HostVarsVarsMock(HostVarsVars, mock.MagicMock):
        pass

# Generated at 2022-06-21 09:28:15.036199
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    hosts_list = ["host1", "host2", "host3"]
    variable_manager = VariableManager()
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=hosts_list)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    original_facts = {'foo': 'foo_value'}
    host = inventory.get_host("host1")
    hostvars.set_nonpersistent_facts(host, original_facts)

    # Check that facts were set nonpersistently
    facts = hostvars.raw_get("host1")
    assert facts['foo'] == original_facts['foo']

    # Check that facts are not persistent and are not stored in the variable

# Generated at 2022-06-21 09:28:25.213642
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    inventory = FakeInventory()
    inventory.add_group('foo')
    inventory.add_group('bar')
    inventory.add_host(Host(name='localhost'))
    inventory.add_host(Host(name='127.0.0.1'))

    variable_manager = FakeVariableManager()
    loader = FakeLoader()

    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(list(hostvars)) == 4

    for i in hostvars:
        assert i in [Host(name='localhost'), Host(name='127.0.0.1'),
                     Group('foo'), Group('bar')]


# Generated at 2022-06-21 09:28:31.393201
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    vars = dict(a=1, b=2)
    variable_manager = VariableManager()
    variable_manager.set_host_variable('example.com', 'foo', vars)
    hostvars = HostVars(variable_manager=variable_manager, inventory=None, loader=None)
    resolved_vars = hostvars['example.com']
    assert resolved_vars.__contains__('a') is True
    assert resolved_vars.__contains__('c') is False

# Generated at 2022-06-21 09:28:32.658689
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert False, "unimplemented"

# Generated at 2022-06-21 09:28:42.889819
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from copy import deepcopy

    inv_data = """
    [all]
    localhost ansible_connection=local
    """
    vars_data = {'foo': 'bar'}

    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader, sources=inv_data)
    var_mgr = VariableManager(loader=loader, inventory=inv_mgr)
    hostvars = HostVars(inv_mgr, var_mgr, loader)

    # Check deepcopying of HostVars instance
    hostvars_deepcopy = deepcopy(hostvars)
    assert hostvars is not hostvars_deep

# Generated at 2022-06-21 09:28:52.750896
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=[])
    hostvars_original = HostVars(inventory, variable_manager, loader)

    variable_manager.set_nonpersistent_facts(None, {'foo': 'bar'})
    variable_manager.set_nonpersistent_facts(inventory.get_host(None), {'foo': 'bar'})
    variable_manager.set_host_

# Generated at 2022-06-21 09:29:07.599130
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create an inventory that contains a host with custom hostvars
    inventory = Inventory(loader=None, host_list=['localhost'])
    inventory.hosts['localhost'].vars['var1'] = 'value1'
    inventory.hosts['localhost'].vars['var2'] = 'value2'
    inventory.hosts['localhost'].vars['var3'] = 'value3'

    # Create an instance of the HostVars class
    hostvars = HostVars(inventory=inventory, variable_manager=VariableManager(loader=None), loader=None)

    # Check that the iterator returns expected data
    hostvars_iter = iter(hostvars)
    assert 'localhost' in hostvars_iter

# Generated at 2022-06-21 09:29:14.988736
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    loader = DictDataLoader({'foo': 'bar'})
    inventory = BaseInventory(loader=loader)
    host = inventory.get_host('localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=variable_manager)

    # Set hostvars state into the same way variables' __getstate__ does

# Generated at 2022-06-21 09:29:24.679196
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import os
    import sys
    import tempfile
    sys.path.insert(0, os.path.abspath('../..'))
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import vars_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.errors import AnsibleError

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop


# Generated at 2022-06-21 09:29:34.095006
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inv = InventoryManager(loader=DataLoader(), sources=[])
    host1 = inv.add_host('myhost1')
    host2 = inv.add_host('myhost2')
    vm = VariableManager(loader=DataLoader())
    hv = HostVars(inventory=inv, variable_manager=vm, loader=DataLoader())
    assert list(hv) == [host1, host2]

# Generated at 2022-06-21 09:29:41.931166
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Inventory
    inventory = Inventory()
    inventory.add_host('fakehost')
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager(loader=None)
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    hostvars.set_host_facts('fakehost', {'ansible_os_family': 'Debian'})
    assert hostvars.get('fakehost').get('ansible_os_family') == 'Debian'


# Generated at 2022-06-21 09:29:46.390635
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    import ansible.inventory
    import ansible.vars.variable_manager

    i = ansible.inventory.Inventory("test/unittest_inventory")
    v = ansible.vars.variable_manager.VariableManager()
    h = HostVars(i, v, None)
    assert len(h) == len(i.hosts)



# Generated at 2022-06-21 09:29:52.637752
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    variables = {
        'var1': 'var1 value',
        'var2': '{{ test_var }}',
        'var3': '{{ var2 }}',
    }
    with pytest.raises(AnsibleUndefinedVariable):
        out = HostVarsVars(variables, None)
        out['var2']

# Generated at 2022-06-21 09:30:02.337232
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    vars_cache = {
        'all': {
            'a': 1,
            'b': 2,
            'c': {
                'd': 3,
                'e': {
                    'f': 4
                }
            }
        }
    }
    hostvars = HostVarsVars(vars_cache, loader=None)
    assert 'a' in hostvars
    assert 'b' in hostvars
    assert 'c' in hostvars
    assert 'c.d' in hostvars
    assert 'c.e' in hostvars
    assert 'c.e.f' in hostvars
    assert 'g' not in hostvars



# Generated at 2022-06-21 09:30:05.708284
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {
        'test1': 'test1',
    }
    loader = object()
    vars = HostVarsVars(variables, loader)
    # TODO: add asserts here

# Generated at 2022-06-21 09:30:08.432532
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    from ansible.vars.manager import VariableManager
    vm = VariableManager()
    hv.set_variable_manager(vm)
    assert vm._loader is hv._loader
    assert vm._hostvars is hv


# Generated at 2022-06-21 09:30:26.861804
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    # A class that behaves as a subset of methods and attributes of class AnsibleInventory
    # AnsibleInventory is a subclass of AnsibleCollectionInventory

    class InventoryAnsibleInventory(object):

        class InventoryHost(object):

            def __init__(self, name):
                self.name = name

        class AnsibleCollectionInventory(object):

            def __init__(self, host_list):
                self._vars_per_host = dict(
                    (h, {'inventory_hostname': h}) for h in host_list)

            def get_host(self, host):
                return self.InventoryHost(host)

            def get_host_variables(self, host):
                return self._vars_per_host.get(host.name, {})

        class VariableManager(object):

            _loader

# Generated at 2022-06-21 09:30:34.755137
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import copy

    hostvars = HostVars(None, None, None)
    hostvars.__setstate__({'_inventory': {'hosts': []}})
    assert hostvars._inventory is not None

    # If _loader is None, assign it
    hostvars.__setstate__({'_variable_manager': {'_loader': None}})
    assert hostvars._variable_manager._loader == hostvars._loader

    # If _hostvars is None, assign it
    hostvars.__setstate__({'_variable_manager': {'_hostvars': None}})
    assert hostvars._variable_manager._hostvars == hostvars

    # If _loader and _hostvars are not None, do nothing
    hostvars_copy = copy.deepcopy(hostvars)

# Generated at 2022-06-21 09:30:36.887445
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader = None
    variables = {'test': 'ok'}
    HostVarsVars(variables, loader)

# Generated at 2022-06-21 09:30:48.924499
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # Test set_inventory when variable_manager._hostvars is HostVars
    module_utils_path = os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils')
    loader = DataLoader()
    variable_manager = VariableManager(loader)
    inventory = Inventory(
        loader=loader,
        variable_manager=variable_manager,
        host_list=['test_host_1', 'test_host_2']
    )

    hostvars = HostVars(inventory, variable_manager, loader)
    assert variable_manager._hostvars is hostvars

    inventory2 = Inventory(
        loader=loader,
        variable_manager=variable_manager,
        host_list=['test_host_2', 'test_host_3']
    )
    hostv

# Generated at 2022-06-21 09:31:01.740594
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVarsObject
    from ansible.parsing.dataloader import DataLoader

    class fake_inventory(object):
        pass

    class fake_loader(object):
        pass

    class fake_host(object):
        pass

    inventory = fake_inventory()
    loader = fake_loader()
    host = fake_host()

    c = PlayContext()

    v = VariableManager(loader, inventory=inventory)

    h = HostVarsObject(inventory, v, loader)

    assert v._loader is None
    assert v._hostvars is None

    # Emulates data persistence with pickle
    test_data = h.__getstate__()

    # Emulates data

# Generated at 2022-06-21 09:31:08.734246
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import copy
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class AttrDict(dict):
        def __init__(self, *args, **kwargs):
            super(AttrDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 09:31:12.043010
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = dict(key1='value1', key2='value2')
    loader = None
    hvv = HostVarsVars(variables, loader)
    assert(hvv['key1'] == 'value1')

# Generated at 2022-06-21 09:31:20.569859
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Create mock inventory
    inventory = MagicMock()
    inventory.hosts = ['testhost']
    get_host_mock = Mock()
    get_host_mock.return_value = 'testhost'
    inventory.get_host = get_host_mock

    # Create mock loader
    loader = MagicMock()

    # Create mock host
    host = MagicMock()

    # Create mock variables
    variables = MagicMock()

    # Create mock VariableManager
    variable_manager = MagicMock()
    variable_manager._hostvars = None
    variable_manager._loader = None
    variable_manager.get_vars.return_value = variables
    variable_manager.get_vars.__name__ = 'get_vars'

    # Create HostVars object
    host_vars = HostV

# Generated at 2022-06-21 09:31:24.763244
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader

    variables = {'foo': 'bar', 'asdf': AnsibleUnsafeText('asdf')}
    loader = DataLoader()
    host_vars_vars = HostVarsVars(variables, loader)
    assert repr(host_vars_vars) == "{u'asdf': 'asdf', u'foo': u'bar'}"

# Generated at 2022-06-21 09:31:32.874742
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import pickle
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    # Create a test inventory and get a Host from it
    test_inventory = InventoryManager(
        loader=None,
        sources=['[all]\nlocalhost ansible_connection=local'])
    host = test_inventory.get_host('localhost')

    #

# Generated at 2022-06-21 09:31:55.124933
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    '''
    This is a unit test for method HostVars.set_inventory.
    '''
    from ansible.inventory import Inventory
    inv = Inventory(host_list=[])
    hv = HostVars(inv, [], [])
    new_inv = Inventory(host_list=[])
    hv.set_inventory(new_inv)
    assert hv._inventory == new_inv

# Generated at 2022-06-21 09:32:05.325080
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager

    test_inventory = [
        "localhost ansible_connection=local",
        "testhost ansible_host=8.8.8.8"
    ]

    inventory_manager = InventoryManager(loader=None, sources=test_inventory)
    variable_manager = VariableManager(loader=None, inventory=inventory_manager)
    hostvars = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=None)

    # __contains__ method returns false because host 'testhost' is not present in inventory
    assert 'testhost' not in hostvars

    # Add 'testhost' to inventory
    inventory_manager

# Generated at 2022-06-21 09:32:11.607426
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    hostvars = HostVars({}, VariableManager(), None)
    hostname = 'test_host'
    facts = {'ansible_facts': {'test_fact': 'test_value'}}
    hostvars.set_nonpersistent_facts(hostname, facts)

    assert(hostvars.raw_get(hostname)['ansible_facts']['test_fact'] == 'test_value')
    assert(hostvars.raw_get(hostname)['test_fact'] == 'test_value')
    assert('test_fact' in hostvars.raw_get(hostname))
    assert('test_fact' in hostvars.raw_get(hostname)['ansible_facts'])

# Generated at 2022-06-21 09:32:19.940807
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    x = HostVarsVars({'foo': 10}, None)
    assert repr(x) == repr({'foo': 10})
    x = HostVarsVars({'foo': '{{ bar }}'}, None)
    assert repr(x) == repr({'foo': '{{ bar }}'})
    x = HostVarsVars({'foo': '{{ bar }}', 'bar': 10}, None)
    assert repr(x) == repr({'foo': 10, 'bar': 10})
    x = HostVarsVars({'foo': '{{ bar }}', 'bar': '{{ baz }}', 'baz': 10}, None)
    assert repr(x) == repr({'foo': 10, 'bar': 10, 'baz': 10})

# Generated at 2022-06-21 09:32:24.757705
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    import pytest

    class VariablesMock():
        def get(self, key):
            return None

        def __len__(self):
            return 0

    variables = VariablesMock()
    vars = HostVarsVars(variables=variables, loader=None)

    assert len(vars) == 0

# Generated at 2022-06-21 09:32:36.329108
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager

    # Setup the class under test and the objects it depends on
    loader = FakeLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = FakeInventory()
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Setup a fake host
    host = Host(name='test_host')
    inventory.add_host(host)

    # Setup data to send to the class under test and the answer we expect to get back
    facts = {'fact1': 1, 'fact2': 'b'}
    expected = dict(facts)

    # Excercise the class under test.
    # The set_nonpersistent_

# Generated at 2022-06-21 09:32:42.076196
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.plugins import vars_loader
    inventory = FakeInventory()
    loader = FakeLoader()
    fake_vars_cache = FakeVariableManager(loader)
    host_vars = HostVars(inventory, fake_vars_cache, loader)
    assert host_vars.__len__() == len(inventory.hosts)


# Generated at 2022-06-21 09:32:51.164781
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert len(hostvars) == 1
    hostvars.set_host_variable(inventory.get_host('localhost'), 'a', 1)
    assert len(hostvars) == 1
    hostvars.set_host_variable(inventory.get_host('localhost'), 'b', 2)
    inventory.add_host(host='testhost')

# Generated at 2022-06-21 09:32:56.496095
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    data = dict(
        a=1,
        b=2,
        c=3,
    )
    vars = HostVarsVars(data, loader=None)
    assert sorted(list(vars)) == sorted(list(data))

# Generated at 2022-06-21 09:33:01.924427
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    input_dict = {'a': 'A', 'b': 'B', 'c': 'C'}
    host_vars = HostVarsVars(input_dict, loader)

    # Note the method return number of elements in dictionary, not the
    # number of characters of its elements.
    assert len(input_dict) == len(host_vars)

# Generated at 2022-06-21 09:33:25.608380
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader = None
    hostvars = {
        'foo': 'bar',
        'baz': '{{ foo }}',
        'bar': "{{ '{{' }} foo }}",
        'qux': {
            'quux': 'corge',
            'grault': '{{ garply }}',
            'waldo': '{{ qux.quux }}',
        }
    }
    hvv = HostVarsVars(hostvars, loader)
    # explain() is a convenience method from python's pprint module
    # which produces a printable representation of a dictionary
    # with indented key:value pairs.
    assert pprint.pformat(hvv) != pprint.pformat(hostvars)

# Generated at 2022-06-21 09:33:36.329779
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    host_name = "test_host"
    var_name = "test_var"
    var_value = "test_value"

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host(host_name)
    assert(host is not None)

    hostvars.set_host_variable(host, var_name, var_value)
    assert(var_name in hostvars[host_name])

# Generated at 2022-06-21 09:33:47.704430
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class AnsibleHostMock:
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    inventory = InventoryManager(loader=None, sources=[])
    host = AnsibleHostMock('test_host')
    hostvars = HostVars(inventory=inventory, variable_manager=VariableManager(loader=None, inventory=inventory), loader=None)
    hostvars.set_host_facts(host, {'foo': 'bar'})
    assert hostvars['test_host']['foo'] == 'bar'
    hostvars.set_host_facts(host, {'foo': 'baz'})

# Generated at 2022-06-21 09:33:53.811978
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    global_vars = dict(
        a_number=42,
        a_boolean=True,
        a_string="Foo",
        an_array=["Bar", "Zar"],
        a_null=None,
        a_dictionary=dict(
            another_number=43
        )
    )
    HostVarsVars(global_vars, None)

# Generated at 2022-06-21 09:33:58.602199
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle

    with open('test_hostvars.pickle', 'rb') as f:
        hostvars = pickle.load(f)

    assert hostvars._variable_manager._loader is not None
    assert hostvars._variable_manager._hostvars is not None

# Generated at 2022-06-21 09:34:06.189788
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # Patching class VariableManager
    from ansible.vars.manager import VariableManager, VariableManagerError

    _original_VariableManager__init__ = VariableManager.__init__
    _original_VariableManager__getstate__ = VariableManager.__getstate__

    @staticmethod
    def _variable_manager__init__(self, inventory=None, *args, **kwargs):
        _original_VariableManager__init__(self, inventory=inventory, *args, **kwargs)
        self._test_inventory = inventory
        self._test_args = args
        self._test_kwargs = kwargs

    @staticmethod
    def _variable_manager__getstate__(self):
        d = _original_VariableManager__getstate__(self)
        d['_variable_manager__test_inventory'] = self._test_inventory
       

# Generated at 2022-06-21 09:34:12.553459
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = DummyLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    assert set(hostvars) == set(inventory.hosts)

# Generated at 2022-06-21 09:34:21.248884
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    def load_data():
        return dict(
            inventory=dict(
                host_list=[
                    'localhost',
                    'host1',
                    'host2'
                ],
                hosts=dict(
                    localhost=dict(ansible_connection='local'),
                    host1=dict(ansible_connection='ssh'),
                    host2=dict(ansible_connection='ssh')
                )
            )
        )

    data = load_data()
    inventory = InventoryManager(loader=None, sources=None, **data.get('inventory', {}))
    hostvars = HostVars(inventory=inventory, variable_manager=VariableManager(), loader=None)
    result = [host for host in hostvars]

# Generated at 2022-06-21 09:34:31.117998
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inv = InventoryManager(loader=loader)
    var_manager = VariableManager(loader=loader, inventory=inv)
    hostvars = HostVars(inventory=inv, variable_manager=var_manager, loader=loader)
    var_manager_new = VariableManager(loader=loader, inventory=inv)
    hostvars.set_variable_manager(var_manager_new)
    assert hostvars._variable_manager is var_manager_new


# Generated at 2022-06-21 09:34:38.370511
# Unit test for constructor of class HostVars
def test_HostVars():
    loader = DictDataLoader({
        'hosts': '''
[web]
www1
www2

[db]
db1
db2
''',
        'group_vars/web': '''
---
http_port: 80
''',
        'group_vars/db': '''
---
db_port: 3306
'''
    })
    inventory = Inventory(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert 'http_port' in hostvars['www1']
    assert 'http_port' in hostvars['www2']
    assert 'db_port' not in hostvars['www1']

# Generated at 2022-06-21 09:35:03.867099
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import pytest

    # Create minimal stubs of AnsibleModule and AnsibleLoader
    class Module(object):
        def __init__(self, *args, **kwargs):
            self.params = {}

    class Inventory(object):
        def __init__(self, *args, **kwargs):
            self.groups = set()
            self.hosts = {
                'localhost': 'localhost',
                'otherhost': 'otherhost'
            }

        def get_host(self, host):
            return self.hosts.get(host)

        def list_hosts(self):
            for host in self.hosts:
                yield host

    class Loader(object):
        def __init__(self, *args, **kwargs):
            self.vars_plugins = {}

    # Create object instance
    module

# Generated at 2022-06-21 09:35:15.009239
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources="")
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_nonpersistent_facts(inventory.get_host("127.0.0.1"), {'a': '1'})
    hostvars.set_nonpersistent_facts(inventory.get_host("127.0.0.2"), {'b': '2'})
    # verify we find variables in hostvars for hosts in inventory

# Generated at 2022-06-21 09:35:21.995538
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars.set_inventory(inventory=inventory)
    assert hostvars._inventory == inventory


# Generated at 2022-06-21 09:35:33.777234
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_hostvars.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 09:35:40.424397
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['tests/inventory'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())

    assert {
        'test_host': {
            'test_var': 'test_value',
            'test_dict': {'test_key': 'test_value'},
            'test_list': ['test_value', 'test_value2']
        }
    } == hostvars['test_host']

# Generated at 2022-06-21 09:35:45.398672
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    from ansible.inventory.host import Host

    h = Host(name='localhost')
    h.set_variable('ansible_foo', 'bar')

    hvv = HostVarsVars(h.vars, loader=None)

    assert hvv['ansible_foo'] == 'bar'

# Generated at 2022-06-21 09:35:53.542815
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.plugins.loader import loader as plugin_loader
    import ansible.constants

    # initialize variables
    host_name = 'test_host'
    loader = plugin_loader
    variables = {'var1': '{{ "templatized" }}',
                 'var2': 'plain'}
    ansible_version = ansible.constants.__version__
    ansible_play_hosts = ['test_host']
    ansible_dependent_role_names = None
    ansible_play_role_names = ['test_role']
    ansible_role_names = ['test_role']
    inventory_hostname = 'test_host'
    inventory_hostname_short = 'test_host'
    inventory_file = '/tmp/ansible/test/test_hosts'

# Generated at 2022-06-21 09:36:03.675858
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import ansible.parsing.dataloader
    import ansible.vars.manager

    fake_variable_manager = ansible.vars.manager.VariableManager()
    fake_loader = ansible.parsing.dataloader.DataLoader()
    fake_hostvars = HostVars(None, fake_variable_manager, fake_loader)

    fake_host = 'fake host'
    fake_variable = 'fake variable'
    fake_value = 'fake value'
    fake_hostvars._variable_manager.set_host_variable(fake_host, fake_variable, fake_value)

    assert fake_hostvars.__repr__() == "{'fake host': {'fake variable': 'fake value'}}"


# Generated at 2022-06-21 09:36:10.026218
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = FakeInventory()
    inventory.loader = loader
    host = Host(name='foohost')
    inventory.add_host(host)
    variable_manager = FakeVariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_copy = deepcopy(hostvars)

    assert hostvars_copy._inventory is hostvars._inventory
    assert hostvars_copy._loader is hostvars._loader
    assert hostvars_copy._variable_manager is hostvars._variable_manager



# Generated at 2022-06-21 09:36:15.913752
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    loader = 'dummy_loader'
    variables = {
        'var1': '1',
        'var2': '2',
        'var3': '3',
    }
    host_vars_vars = HostVarsVars(variables, loader)

    assert (len(variables) == len(host_vars_vars))


# Generated at 2022-06-21 09:37:00.587205
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Test HostVars.__getitem__() method.

    Tests that the HostVars.__getitem__() method returns a HostVarsVars object
    containing the same variables as in the original dictionary.

    Actual use of the method is tested in test_HostVarsVars___getitem__() method.
    '''
    from ansible import variables as v
    from ansible.plugins.loader import vars_loader

    variables = dict(a=1, b=2, c=3)

    inventory_data = '''
localhost ansible_connection=local
'''

    loader = vars_loader.VarsModule(vars_files=[])
    variable_manager = v.VariableManager(vars_files=[])
    loader.set_vars(variable_manager, variables)

    inventory = v.Inventory

# Generated at 2022-06-21 09:37:05.482992
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    myhost1 = Host(name='host1')
    myhost2 = Host(name='host2')

    variable_manager = VariableManager()
    variable_manager.set_host_variable(myhost1, 'hello', 'world')
    variable_manager.set_host_variable(myhost2, 'foo', 'bar')

    loader = DataLoader()

    vars_vars = HostVarsVars(variable_manager.get_vars(myhost2), loader=loader)

    assert repr(vars_vars) == '{\'hello\': \'world\', \'foo\': \'bar\'}'

# Generated at 2022-06-21 09:37:17.214843
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    expected_results = {
        'dict': {'a': {'b': {'c': 'd'}}},
        'hostvars': combine_vars(dict(), {'a': {'b': {'c': 'd'}}}),
    }

    hvv = HostVarsVars(dict(), loader=None)
    templar = Templar(variables=expected_results, loader=None)

    assert repr(hvv.__repr__()) == repr(expected_results['dict'])
    assert repr(hvv.__repr__()) == templar.template(expected_results['hostvars'], fail_on_undefined=False, static_vars=STATIC_VARS)