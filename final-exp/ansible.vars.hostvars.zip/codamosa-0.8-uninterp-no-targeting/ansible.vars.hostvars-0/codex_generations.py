

# Generated at 2022-06-21 09:27:32.886250
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = lambda x: x
    host = Host(name='test')
    inventory = InventoryManager(loader=loader)
    inventory.add_host(host=host)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Scenario 1: lookup variable 'foo'
    hostvars_vars = HostVarsVars(variables={'foo': 'bar'}, loader=loader)
    assert hostvars_vars['foo'] == 'bar'

    # Scenario 2: lookup variable 'foo' which has undefined value
    hostvars_vars = HostVarsVars(variables={'foo': AnsibleUndefined('foo')}, loader=loader)

# Generated at 2022-06-21 09:27:37.831170
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    import ansible.utils.vars as vars
    hv = HostVars(inventory=Inventory(), variable_manager=VariableManager())
    hv.set_inventory(Inventory())
    hv.set_inventory(vars.Defaults.hostvars_inventory)

# Generated at 2022-06-21 09:27:49.934892
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class MockInventory(object):
        def __init__(self, hosts=None):
            self.hosts = hosts

    data_loader = DataLoader()
    variable_manager = VariableManager(loader=data_loader)
    hostvars = HostVars(None, variable_manager, data_loader)

    inventory1 = MockInventory(hosts=["host1", "host2", "host3"])
    inventory2 = MockInventory(hosts=["host1", "host2"])
    inventory3 = MockInventory(hosts=[])

    hostvars.set_inventory(inventory1)
    assert hostvars._inventory == inventory1



# Generated at 2022-06-21 09:28:00.404998
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import copy
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    host_vars_orig = {
        'example.org': {
            'database': 'debops-example'
        },
        'example.net': {
            'database': 'debops-production'
        }
    }
    host_vars = copy.deepcopy(host_vars_orig)

    host_facts = {
        'example.org': {
            'database': 'debops-developed'
        }
    }

    inventory = InventoryManager(loader=DataLoader())
    inventory.add_host(host='example.org', group='desktop')

# Generated at 2022-06-21 09:28:05.529247
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    variable_manager.set_loader(loader)

    host = Host('localhost')
    variable_manager._vars_cache[host] = {"foo": "bar"}
    variable_manager.get_vars(host=host)

    data = HostVars(inventory, variable_manager, loader)

    assert data.__contains__("localhost") == True

# Generated at 2022-06-21 09:28:16.081205
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, play_context=PlayContext(), inventory=InventoryManager(loader=loader, sources=[C.DEFAULT_HOST_LIST]))
    inventory_manager = InventoryManager(loader=loader, sources=['localhost,'])
    host_name = 'server.example.com'
    host = Host(name=host_name)
    inventory_manager._inventory.add_host(host, group=None)

# Generated at 2022-06-21 09:28:19.712760
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    vars_ = {'foo': 'bar'}
    assert len(HostVarsVars(vars_)) == 1

    vars_ = {}
    assert len(HostVarsVars(vars_)) == 0



# Generated at 2022-06-21 09:28:21.648460
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    assert set(HostVars(None, None, None).__iter__()) == set()


# Generated at 2022-06-21 09:28:30.684353
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    import sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    class NullPlugin(object):
        ''' Plugin which does nothing. '''

        def get_option(self, *args, **kwargs):
            pass

        def set_options(self, *args, **kwargs):
            pass

    # Prepare a fake inventory with a single host which has empty vars
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/dev/null'])
    host = Host(name='fake_host')
    inv_manager.add_host(host, group='fake_group')

# Generated at 2022-06-21 09:28:35.408547
# Unit test for constructor of class HostVars

# Generated at 2022-06-21 09:28:44.386585
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    inv_host = Host('hostname')
    inv_host.set_variable('foo', 'value')

    inventory = InventoryManager()
    inventory.add_host(inv_host)

    host_vars = HostVars(inventory, None, None)

    assert 'hostname' in host_vars
    assert 'not_existing_host' not in host_vars



# Generated at 2022-06-21 09:28:51.620201
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    inv = Inventory(host_list=[])
    from ansible.vars import VariableManager
    vm = VariableManager(loader=None, inventory=inv)
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    hv = HostVars(inventory=inv, variable_manager=vm, loader=loader)
    assert len(hv) == 0

    inv = Inventory(host_list=['localhost'])
    hv = HostVars(inventory=inv, variable_manager=vm, loader=loader)
    assert len(hv) == 1

# Generated at 2022-06-21 09:28:54.819062
# Unit test for constructor of class HostVars
def test_HostVars():
    vars_cache = dict()
    vars = HostVars(vars_cache)
    assert isinstance(vars, HostVars)

# Generated at 2022-06-21 09:29:07.398504
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # 'inventory_file' is used as a variable in tests
    class DummyInventory():
        def __init__(self):
            self.hosts = []
            self.groups = {}

        def get_host(self, host_name):
            if host_name in ['int_host', 'stg_host']:
                return 'host'
            else:
                return None

    class DummyVariables():
        def __init__(self):
            self.vars = {'inventory_file': 'int'}

    # Create an instance of HostVars and check that HostVarsVars
    # is returned
    hv = HostVars(inventory=DummyInventory(), variable_manager=DummyVariables(), loader=None)
    assert isinstance(hv['int_host'], HostVarsVars)


# Generated at 2022-06-21 09:29:13.868698
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = None
    variables = {
        'host_name': 'host1',
        'ansible_host': 'host1',
        'ansible_port': '123',
    }
    hvv = HostVarsVars(variables, loader)
    assert 'host_name' in hvv
    assert 'ansible_host' in hvv
    assert 'ansible_port' in hvv
    assert len(hvv) == 3
    assert hvv['host_name'] == 'host1'
    assert hvv['ansible_host'] == 'host1'
    assert hvv['ansible_port'] == 123

# Generated at 2022-06-21 09:29:23.163699
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    import pytest
    from ansible.inventory.manager import InventoryManager

    vm = InventoryManager(loader=None, sources='localhost,')
    hv = HostVars(inventory=vm, variable_manager=vm.get_variable_manager(), loader=None)
    hv.set_host_variable(vm.get_host('localhost'), 'foo', 'bar')

    assert hv['localhost']['foo'] == 'bar'

    # Variable with name 'ansible_version' is a static var and should not be set
    with pytest.raises(Exception):
        hv.set_host_variable(vm.get_host('localhost'), 'ansible_version', '42')

# Generated at 2022-06-21 09:29:29.454556
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.constants import DEFAULTS
    import os

    loader = DataLoader()
    inventory = Inventory(loader, "")
    variable_manager = VariableManager(loader, inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set('foo', {"bar": " baz "})
    loaded_hostvars = hostvars.get('foo')

    assert 'baz' == loaded_hostvars['bar']

# Generated at 2022-06-21 09:29:38.899532
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    '''
    Check that __iter__ method iterates over all hosts.
    '''
    # pylint: disable=protected-access
    from ansible.inventory import Inventory
    import ansible.parsing.dataloader
    from ansible.vars.manager import VariableManager

    inventory = Inventory(
        host_list=[
            'myhost01',
            'myhost02',
        ]
    )
    variable_manager = VariableManager()
    hostvars = HostVars(
        inventory,
        variable_manager,
        ansible.parsing.dataloader.DataLoader()
    )
    iter_hostvars = iter(hostvars)
    hostvars_hosts = list(hostvars)

    assert len(hostvars) > 0

# Generated at 2022-06-21 09:29:41.094534
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    test = HostVarsVars({'var1': 1}, None)
    assert repr(test) == "{'var1': 1}"

# Generated at 2022-06-21 09:29:49.731259
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from .vars_cache import VarsCache
    from .vars_manager import VariableManager

    inv = dict(
        test_host=dict(
            a=dict(b="a.b"),
            x=5,
        ),
        test_host2=dict(
            a=dict(b="a.b"),
            x=5,
        ),
    )

    vars_cache = VarsCache()
    vars_manager = VariableManager(vars_cache=vars_cache)

    hostvars = HostVars(inventory=inv, variable_manager=vars_manager, loader=None)
    hostvars_vars = hostvars.get("test_host")

    # Test that the __getitem__ method of HostVarsVars
    # returns values after rendering the Jinja2 template

# Generated at 2022-06-21 09:30:05.432108
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    variable_manager = VariableManager()

    host = Host(name='test')
    host.vars = dict(a='hello', b=dict(c='world'))
    host.groups = [Group(name='g1')]
    host.groups[0].vars = dict(a='goodbye')  # group vars will override host vars

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    inventory.add_host(host)


# Generated at 2022-06-21 09:30:10.477325
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Create HostVars
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory, VariableManager, loader)

    # Create host "foo" in inventory
    inventory.add_host('foo')
    localhost = inventory.get_host('foo')

    # Check that "hostvars['foo']" returns an empty dict
    assert hostvars['foo'] == {}

    # Check that "hostvars['foo']['bar']" raises a KeyError
    try:
        hostvars['foo']['bar']
        assert False
    except KeyError:
        pass

# Generated at 2022-06-21 09:30:20.129528
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader(dict())
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.set_variable_manager(variable_manager) is None
    assert hostvars.set_inventory(inventory) is None



# Generated at 2022-06-21 09:30:29.184341
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping
    import os

    invm = InventoryManager([os.path.join(os.path.dirname(__file__), '../../../test/unit/inventory')],
                            loader=None,
                            sources=['localhost', 'examples'])
    varm = VariableManager()

    invm.set_variable_manager(varm)
    varm.set_inventory(invm)

    hostvars = HostVars(inventory=invm, variable_manager=varm, loader=None)
    host = invm.get_host(host_name='localhost')
    facts = dict(foo='bar', baz='quux')
   

# Generated at 2022-06-21 09:30:36.220034
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import load_extra_vars

    extra_vars = {'foo': 'foo', 'bar': 'bar'}
    options = load_extra_vars(load_extra_vars(None, extra_vars), extra_vars)
    context = PlayContext(options)
    loader = DataLoader()
    inventory = InventoryManager(loader, context.options.inventory)
    var_manager = VariableManager(context=context, loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, var_manager, loader)

# Generated at 2022-06-21 09:30:47.770922
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager()
    variable_manager = VariableManager(inventory=inventory)
    hostvars = HostVars(inventory, variable_manager)

    variable_manager.set_host_variable('host1', 'foo', 'bar')

    hostvars.set_host_facts('host1', dict(a='variable_manager'))
    assert variable_manager.get_vars(host='host1')['a'] == 'variable_manager'

    hostvars.set_host_facts('host1', dict(a='hostvars'))
    assert variable_manager.get_vars(host='host1')['a'] == 'hostvars'

# Generated at 2022-06-21 09:30:48.510337
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # TODO: implement this unit test
    pass


# Generated at 2022-06-21 09:31:00.615226
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import unittest

    class MockHost:
        def __init__(self, name, vars):
            self.name = name
            self.vars = vars

        def get_vars(self):
            return self.vars

    class MockInventory:
        def __init__(self):
            self.hosts = []

        def add_host(self, host):
            self.hosts.append(host)

        def get_host(self, host_name):
            for host in self.hosts:
                if host.name == host_name:
                    return host
            return None

    class MockVariableManager:
        def get_vars(self, host=None, include_hostvars=True):
            if host is None:
                return dict()
            else:
                return host.get_v

# Generated at 2022-06-21 09:31:06.600029
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    import ansible.variables

    inventory_manager = InventoryManager(loader=None, sources=None)

    variable_manager = ansible.variables.VariableManager()

    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=None)

    hostvars.set_inventory(inventory_manager)

    assert hostvars._inventory == inventory_manager

# Generated at 2022-06-21 09:31:13.209051
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    _variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, _variable_manager, loader)
    assert hostvars._variable_manager == _variable_manager

    _variable_manager = VariableManager(loader=loader)
    hostvars.set_variable_manager(_variable_manager)
    assert hostvars._variable_manager == _variable_manager


# Generated at 2022-06-21 09:31:23.585941
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves.configparser as configparser

    import ansible.playbook.play
    play = ansible.playbook.play.Play().load({
        "hosts": "all",
        "gather_facts": "no",
        "tasks": [
            {"debug": {"msg": "{{ var }}"}}
        ]})
    host = ansible.inventory.host.Host('localhost')
    loader = ansible.parsing.dataloader.DataLoader()
    play.set_loader(loader)

# Generated at 2022-06-21 09:31:32.343320
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create VariableManager and HostVars
    dl = DataLoader()
    im = InventoryManager(loader=dl)
    vm = VariableManager(loader=dl, inventory=im)
    hv = HostVars(inventory=im, loader=dl, variable_manager=vm)

    # Create new instance of VariableManager
    vm2 = VariableManager(loader=dl, inventory=im)

    # Method _loader of vm2 is not initialized
    assert vm2._loader is None

    # Method _hostvars of vm2 is None
    assert vm2._hostvars is None

    # Invoke method set_variable_manager(vm2)
    hv.set_variable

# Generated at 2022-06-21 09:31:44.842044
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create inventory
    localhost = dict(host_name='localhost', groups=['ungrouped'])
    inventory = InventoryManager(hosts_list=[localhost])

    # Create play context
    play_context = PlayContext()
    play_context.inventory = inventory

    # Create play
    play = Play()
    play._variable_manager = VariableManager()
    play._variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 09:31:56.826623
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    host_name = 'myhost'
    host = inventory.add_host(host_name)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    assert 'foo' not in hostvars[host]

    # set_host_variable() adds new variables
    hostvars.set_host_variable(host, 'foo', 'bar')
    assert 'foo' in hostvars[host]
    assert hostvars[host]['foo'] == 'bar'

    # set_

# Generated at 2022-06-21 09:32:03.875757
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    host = Host(name='testhost')
    group = Group('testgroup')
    group.add_host(host)

    inventory = [group]

    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager)

    assert list(iter(hostvars)) == [host]
    assert list(hostvars.__iter__()) == [host]



# Generated at 2022-06-21 09:32:15.434221
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    host_vars = {
        'inventory_hostname': 'web01',
        'inventory_hostname_short': 'web1',
    }

    variable_manager = VariableManager(loader=None)

# Generated at 2022-06-21 09:32:26.692781
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    from ansible.playbook.play_context import PlayContext

    from ansible.errors import AnsibleParserError

    p1 = Play()
    i1 = InventoryManager(loader=DataLoader())

# Generated at 2022-06-21 09:32:32.298241
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars import VariableManager

    v = VariableManager()
    assert v._hostvars is None

    h = HostVars(None, v, None)

    assert h._variable_manager == v
    assert h._inventory is None
    assert h._loader is None

    assert v._hostvars == h

# Generated at 2022-06-21 09:32:42.817329
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class MockInventory():
        def __init__(self, hosts_data, groups_data):
            self._hosts = hosts_data
            self._groups = groups_data

        def hosts(self, pattern=None):
            return self._hosts

        def groups(self, pattern=None):
            return self._groups

        def get_host(self, host_name):
            return self._hosts.get(host_name)

    class MockHost():
        def __init__(self, name):
            self.name = name
            self.vars = {'a': 1, 'b': 2}

        def get_vars(self):
            return self.vars


# Generated at 2022-06-21 09:32:50.387737
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    hostvars = HostVars({}, {}, {})

    state = dict(
        _inventory={'a': 'b'},
        _loader={'c': 'd'},
        _variable_manager=dict(
            _loader=None,
            _hostvars=None,
        )
    )
    hostvars.__setstate__(state)

    # _variable_manager._loader and _variable_manager._hostvars must
    # be assigned
    assert(hostvars._variable_manager._loader == hostvars._loader)
    assert(hostvars._variable_manager._hostvars == hostvars)

# Generated at 2022-06-21 09:33:05.054208
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    fake_loader = DataLoader()

    fake_inventory = InventoryManager(loader=fake_loader, sources=["127.0.0.1"])

    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

    # Create an instance of HostVars using a fake inventory and a fake variable_manager
    hostvars = HostVars(inventory=fake_inventory, variable_manager=fake_variable_manager, loader=fake_loader)

    hosts = [ h for h in hostvars ]

    assert len(hosts) == 1
    assert "127.0.0.1" in hosts

# Generated at 2022-06-21 09:33:10.835078
# Unit test for constructor of class HostVars
def test_HostVars():
    # constructor
    test_obj = HostVars(
        inventory = 'inventory',
        variable_manager = 'variable_manager',
        loader = 'loader'
    )
    assert test_obj._inventory == 'inventory'
    assert test_obj._loader == 'loader'
    assert test_obj._variable_manager == 'variable_manager'

# Generated at 2022-06-21 09:33:17.311902
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # pylint: disable=import-error
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    hostvars = HostVars(inventory=Inventory(loader=DataLoader(), variable_manager=VariableManager()),
                        variable_manager=VariableManager(), loader=DataLoader())

    assert hostvars._variable_manager is not None
    assert hostvars._variable_manager._hostvars is not None
    assert hostvars._variable_manager._hostvars is hostvars

    # The _hostvars attribute of the VariableManager is not pickled,
    # therefore it is None after unpickling. Set it to the correct
    # value to check the correctness of the __setstate__ method.
    hostvars._variable_manager._

# Generated at 2022-06-21 09:33:26.596241
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    foo = Host('example.com')
    bar = Group('group')
    baz = Group('ungrouped')

    vm = VariableManager()
    vm.set_host_variable(foo, 'foo', 'This is foo')
    vm.set_host_variable(bar, 'bar', 'This is bar')
    vm.set_host_variable(bar, 'dfoo', 'This is {{ foo }}')
    vm.set_host_variable(bar, 'dbar', 'This is {{ bar }}')

    hv = HostVars(inventory=None, variable_manager=vm, loader=None)
    hv.set_inventory(inventory=None)

    assert hv._find

# Generated at 2022-06-21 09:33:37.262952
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    from ansible.errors import AnsibleError
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    inventory = Inventory(DataLoader())

    for host in ['host0', 'host1']:
        inventory.add_host(host=Host(name=host), group='ungrouped')

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars['foo'] = 'bar'
    variable_manager.extra_vars['answer'] = 42

# Generated at 2022-06-21 09:33:44.091719
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(loader=None, variable_manager=VariableManager(loader=None), host_list=[])

    host = inventory.add_host(host='test')

    hostvars = HostVars(inventory, VariableManager(loader=None), loader=None)

    hostvars.set_nonpersistent_facts(host, {'fact': 'value'})

    assert host.get_vars()['fact'] == 'value'



# Generated at 2022-06-21 09:33:50.983055
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    # Prepare a fake inventory.
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])

    # Prepare a fake variable.
    var = {
        'x': 'b',
        'y': {
            'z': 'c',
        },
    }

    variables = VariableManager()
    variables.set_host_variable(
        inventory.get_host('example.org'),
        'foo',
        var)

    # Create the HostVarsVars
    vars = HostVarsVars(var, loader)

    assert set(vars) == set(var)
    assert 'x'

# Generated at 2022-06-21 09:34:01.311203
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    def __contains__(self, var):
        return False # set false to test truthy cases

    HostVarsVars.__contains__ = __contains__

    hostvarsvars = HostVarsVars({'a': 1, 'b': 2, 'c': 3, 'd': 4}, None)
    assert 'a' in hostvarsvars
    assert 'b' in hostvarsvars
    assert 'c' in hostvarsvars
    assert 'd' in hostvarsvars
    try:
        assert 'e' in hostvarsvars
    except NameError:
        pass # exception is expected

    del HostVarsVars.__contains__


# Generated at 2022-06-21 09:34:13.518381
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    my_hostvars = HostVars(inventory=InventoryManager(''), variable_manager=VariableManager(), loader=None)
    assert my_hostvars.raw_get('localhost') == {}
    my_hostvars.set_nonpersistent_facts('localhost', {'foo': 'bar'})
    assert my_hostvars.raw_get('localhost') == {'foo': 'bar'}
    my_hostvars.set_nonpersistent_facts('localhost', {'baz': 'qux'})
    assert my_hostvars.raw_get('localhost') == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-21 09:34:21.712499
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # mock inventory
    inventory = type('Inventory', (), {'hosts': {'test_host': 'test_host'}})()

    # mock variable manager
    variable_manager = type('VariableManager', (), {'_loader': 'loader',
                                                    '_hostvars': None,
                                                    '_nonpersistent_facts': {'test_host': {'ansible_os_family': 'Linux'}},
                                                    'get_vars': lambda x, y: {'test_var': '{{ ansible_os_family }}'}})()

    # mock loader
    loader = type('DataLoader', (), {'__getitem__': lambda x, y: {}, 'all_vars': {}})()
    loader._loader = loader

    # create HostVars object
    hostvars = HostV

# Generated at 2022-06-21 09:34:45.573424
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import copyreg
    copyreg.pickle(HostVars, HostVars.__getstate__, HostVars.__setstate__)

# Generated at 2022-06-21 09:34:57.568923
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Make sure the method of class HostVars works as expected
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    myvars = dict(foo = "bar")
    myinventory = InventoryManager(None)
    myinventory.add_host(host="example.com", vars = myvars, port=22)

    myhostvars = HostVars(myinventory, VariableManager(loader=None, inventory=myinventory), loader=None)

    # Test with a valid host name
    assert myhostvars["example.com"]["foo"] == "bar"

    # Test with an invalid host name

# Generated at 2022-06-21 09:35:05.963296
# Unit test for constructor of class HostVars
def test_HostVars():
    import sys
    import os

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=os.path.abspath("../test/test_load_inventory/test_inventory"))
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._loader = loader
    variable_manager._inventory = inventory
    variable_manager.set_inventory(inventory)
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = { "test": "variable" }

# Generated at 2022-06-21 09:35:18.078747
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=["test/units/vars/hostvars_inventory.ini"])
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
    assert hostvars['localhost']['hostvar1'] == 'Works!'
    assert hostvars['localhost']['hostvar2'] == 'It does too'
    assert hostvars['localhost']['hostvar3'] == "Ok, it's perfect now"

# Generated at 2022-06-21 09:35:25.507307
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    variables = VariableManager()
    loader = None
    hostvars = HostVars(Inventory(loader, variable_manager=variables), variables, loader)
    # The following statement should run without exceptions.
    # It should not change underlying _inventory reference.
    hostvars.set_inventory(Inventory(loader, variable_manager=variables))
    assert hostvars._inventory is not None

# Generated at 2022-06-21 09:35:36.874419
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible import constants as C
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='example')
    variable_manager.set_host_variable(host, 'foo', 'bar')

# Generated at 2022-06-21 09:35:46.405653
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    import os
    import tempfile
    import yaml
    import sys

    # Write variables to a temporary file
    fd, yaml_file = tempfile.mkstemp()
    with open(yaml_file, 'w') as f:
        f.write(yaml.dump({'foo': 'bar', 'flavor': '{{ flavor }}'}))
    os.close(fd)

    # Setup the AnsibleModule instance
    module = AnsibleModule(argument_spec={})
    module._name = 'ansible.module_utils.basic.AnsibleModule'
    module._ansible_version = '2.0'

# Generated at 2022-06-21 09:35:49.313645
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    i = Inventory(host_list=[])
    vm = VariableManager()
    HostVars(i, vm, loader=None)

# Generated at 2022-06-21 09:35:57.028961
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from six import StringIO

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    input = StringIO(u"[host]\nhost1\nhost2\nhost3\nhost4")
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[input])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=variable_manager)
    hostvars_iterator = iter(hostvars)
    assert hasattr(hostvars_iterator, 'next')
    host1 = hostvars_iterator.next()
    host2 = hostvars_iterator.next()
    host

# Generated at 2022-06-21 09:36:04.045454
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.requiremenst import RoleRequirement

    hosts = [
        'foobar'
    ]

    inventory = Inventory(loader=DataLoader(), host_list=hosts)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, DataLoader())

    assert len(hostvars) == 1


# Generated at 2022-06-21 09:36:52.199581
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    # Test to make sure we don't hit a KeyError when looking for a non-existent
    # variable name in __contains__.  We want it to return False in that case,
    # rather than fail with a KeyError.
    # Also test to make sure we don't run a variable through the Jinja2 templater
    # to figure out if it exists.  We should only check the contents of the
    # _vars dict.  If we run variables through the templater, then "bad"
    # variables that contain Jinja2 constructs will cause __contains__ to fail.
    variables = dict(a = 1, b = 2, c = 3)
    loader = None
    hostvars_vars = HostVarsVars(variables, loader)
    assert("a" in hostvars_vars)

# Generated at 2022-06-21 09:37:02.035707
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    loader = DataLoader()
    hostvarsvars = HostVarsVars({'foo': '{{bar}}', 'bar': 'baz'}, loader=loader)
    assert('foo' in hostvarsvars)
    assert('bar' in hostvarsvars)
    assert('baz' not in hostvarsvars)
    assert('nonexistentvariable' not in hostvarsvars)

# Generated at 2022-06-21 09:37:06.091859
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    inv = {}
    variable_manager = {}
    loader = {}
    hostvars = HostVars(inv, variable_manager, loader)

    inv2 = {}
    hostvars.set_inventory(inv2)
    assert hostvars._inventory == inv2

# Generated at 2022-06-21 09:37:17.465708
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    inv = InventoryManager(loader=None, sources='./test/unit/examples/hostvars/hosts')
    inv.parse_inventory(cache=False)
    vars_cache = {}
    variable_manager = VariableManager(loader=None, inventory=inv, version_info=CLI.version_info(gitinfo=False))
    variable_manager.set_inventory(inv)
    variable_manager.set_vars(vars_cache)
    hostvars = HostVars(inventory=inv, variable_manager=variable_manager, loader=None)
    assert 'foo' in hostvars
    assert 'some_host' in hostvars
    vars_cache['foo'] = 10
    assert 'foo' in hostvars