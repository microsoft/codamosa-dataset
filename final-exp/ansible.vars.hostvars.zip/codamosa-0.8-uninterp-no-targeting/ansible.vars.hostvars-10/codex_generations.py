

# Generated at 2022-06-21 09:27:35.341459
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    import unittest
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class TestInventory(InventoryManager):

        def __init__(self):
            self.hosts = []

        def add_host(self, hostname):
            self._hosts.append(hostname)

        def get_host(self, hostname):
            for host in self.hosts:
                if host.name == hostname:
                    return host
            return None

    class TestHost(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-21 09:27:45.327448
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    import os
    import tempfile
    import yaml

    # Create temporary hosts file
    (fd, hosts_path) = tempfile.mkstemp()
    fh = os.fdopen(fd, 'w')
    fh.write("localhost ansible_connection=local\n")
    fh.close()

    # Create a temporary directory to store role dependencies
    dependency_dir = tempfile.mkdtemp()

    # Create temporary vars.yml file

# Generated at 2022-06-21 09:27:55.447570
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    hostvars = HostVars( inventory=InventoryManager(hosts=[], sources=''),
                         variable_manager=VariableManager(loader=None, inventory=None),
                         loader=None)
    assert (list(hostvars) == [])

    hostvars = HostVars( inventory=InventoryManager(hosts=[Host(name='foo')], sources=''),
                         variable_manager=VariableManager(loader=None, inventory=None),
                         loader=None)
    assert (list(hostvars) == ['foo'])

# Generated at 2022-06-21 09:28:04.114506
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():

    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory=inventory, loader=None, variable_manager=variable_manager)

    test_host = Host(name="test_host")
    test_host.set_variable("ansible_hostname", "test_host_name")
    test_host.set_variable("ansible_network_os", "test_host_network_os")
    test_host.set_variable("test_host_variable", "test_host_variable_value")

    hostvars.set_host_facts(host=test_host, facts={"test_host_fact_variable": "test_host_fact_variable_value"})



# Generated at 2022-06-21 09:28:07.297585
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    vm = HostVarsVars({'test': '{{ foo }}', 'foo': 'foo'}, loader=None)
    assert vm['test'] == 'foo'

# Generated at 2022-06-21 09:28:11.378789
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.template import Templar
    templar = Templar()
    hvv = HostVarsVars({'a': {'b': '{{b}}'}, 'b': 'hello'}, templar)
    assert hvv['a']['b'] == 'hello'

# Generated at 2022-06-21 09:28:19.033143
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.inventory import InventoryModule
    from ansible.plugins.cache import FactCache
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=get_all_plugin_loaders(), sources=None)

    localhost = Host("127.0.0.1")
    localhost.set_variable("ansible_connection", "local")
    localhost.set_variable("ansible_python_interpreter", "/usr/bin/python")

    inventory.hosts["127.0.0.1"] = localhost
    inventory.cache = FactCache(inventory=inventory, expire=0)
    inventory.clear_pattern_

# Generated at 2022-06-21 09:28:28.885035
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.include import RoleInclude
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create variables and inventory
    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-21 09:28:32.900961
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = {'foo': 'bar', 'bar': 'baz'}
    hvv = HostVarsVars(variables, loader=None)
    assert len(hvv) == 2


# Generated at 2022-06-21 09:28:43.054254
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible import playbook
    from io import StringIO

    inventory = InventoryManager(loader=playbook.get_loader(), sources=StringIO(u'''
    g1:
     hosts:
      h1:
    g2:
     hosts:
      h2:
      h3:
    '''))

    variable_manager = VariableManager(loader=playbook.get_loader(), inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, playbook.get_loader())

    assert "localhost" in hostvars
    assert "g1" in hostvars
    assert "h1" in hostvars
    assert "g2" in hostvars
    assert "h2" in hostvars


# Generated at 2022-06-21 09:28:56.312692
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'otherhost,'])
    vm = inventory._variable_manager
    hv = HostVars(inventory=inventory, variable_manager=vm, loader=loader)
    hvv = HostVarsVars(variables=hv['localhost'], loader=loader)
    assert 'localhost' == hvv['inventory_hostname']

# Generated at 2022-06-21 09:29:02.068377
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.callbacks import AggregateStats
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    aggregate_stats = AggregateStats()
    play_context = PlayContext()
    play = Play()
    play._play_context = play_context
    play.domain = "test_HostVars___iter__"

    group = Group(name="test_HostVars___iter__", play=play)
    hosts = [Host(name='localhost')]
    inventory = group.get_implicit_all_group(hosts)

# Generated at 2022-06-21 09:29:10.550840
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars.raw_get('test_host') == {}
    hostvars.set_host_variable('test_host', 'ansible_test', 'value')
    assert hostvars.raw_get('test_host') == {'ansible_test': 'value'}



# Generated at 2022-06-21 09:29:22.086702
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    line = "localhost ansible_python_interpreter=/usr/bin/python3"
    inventory = InventoryManager(host_list=None)
    play_context = PlayContext()
    play_context._set_inventory(inventory)
    inventory.add_host(line)

    host = inventory.get_host(line)

    loader = 'dummy_loader'
    play = Play().load({}, loader, play_context)
    play._variable_manager = 'dummy_variable_manager'

    # Create object of HostVars
    hostvars = HostVars(inventory, play._variable_manager, loader)

    # Set hostvars.variable._loader and host

# Generated at 2022-06-21 09:29:31.132499
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=DataLoader(), sources=None)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.set_inventory(inventory)

    host = Host(name='foo')
    inventory.add_host(host)

    hostvars = HostVars(inventory, variable_manager=variable_manager, loader=DataLoader())

    # Without setting facts, we should get empty result
    assert(hostvars.get(host) == {})

    # Set facts and then verify we get it back

# Generated at 2022-06-21 09:29:42.061412
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    # Setup for test
    #   Create fake inventory
    #   Create fake inventory_cache
    #   Create fake variables
    #   Create hostvars object
    #   Create fake host object
    #   Add host to inventory
    #   Create fake variables and add them to cache
    #   Perform test
    v_data = {'foo': 'bar'}
    v_data_all = combine_vars(v_data)
    loader = DataLoader()

# Generated at 2022-06-21 09:29:48.564507
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # Create a host which is not in the inventory and check that
    # HostVars.__contains__() returns false
    class Inventory:
        def get_host(self, name):
            if name == 'foobar':
                class Host:
                    def __init__(self):
                        self.name = 'foobar'
                        self.vars = {}
                return Host()
            else:
                return None
    inventory = Inventory()
    class VariableManager:
        def __init__(self):
            self._hostvars = None
            self._host = None
            self._loader = None
            self._extra_vars = None
            self._options_vars = None
            self._inventory = None
            self._fact_cache = None
            self._whitelist_facts = None

# Generated at 2022-06-21 09:29:52.636273
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({'foo': 'bar', 'baz': 'qux'}, loader=None)
    assert set(hvv) == set(['foo', 'baz'])

# Generated at 2022-06-21 09:29:57.426641
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    foo = HostVarsVars({'a': 'b'}, None)
    assert foo.__repr__() == "{u'a': u'b'}"

    foo = HostVarsVars({'a': {'b': {'c': 'd'}}}, None)
    assert foo.__repr__() == "{u'a': {u'b': {u'c': u'd'}}}"

# Generated at 2022-06-21 09:30:09.077299
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    import copy

    class HostVarsSubclass(HostVars):
        def __init__(self):
            self._dict = {}

        def __getitem__(self, key):
            return self._dict[key]

        def __contains__(self, key):
            return key in self._dict

        def __iter__(self):
            return iter(self._dict)

        def __len__(self):
            return len(self._dict)

        def __deepcopy__(self, memo):
            return HostVarsSubclass()

    class VariableManagerMock(object):
        '''Mock for VariableManager class'''
        _hostvars = HostVarsSubclass()


# Generated at 2022-06-21 09:30:13.937906
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
	hostvars = HostVars({'foo': 'bar'}, {}, {})
	for host in hostvars:
		print ("Host: '%s'" % (host))


# Generated at 2022-06-21 09:30:20.826746
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    # This test is necessary to cover the following code:
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/vars/hostvars.py#L134-L138
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({'yml': {'inventory': {'hosts.yml': '''
all:
  hosts:
    host1:
   '''}}})
    inventory1 = InventoryManager(loader=loader, sources='yml/inventory/hosts.yml')
    variable_manager = VariableManager(loader)
    hostvars = HostVars(inventory1, variable_manager, loader)


# Generated at 2022-06-21 09:30:30.623819
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a loader (loads inventory source)
    loader = DataLoader()

    # Create a play context (will be used by variable manager)
    play_context = PlayContext()

    # Create an inventory
    inventory = InventoryManager(loader, sources=['tests/inventory/unittest_inventory.yaml'])

    # Create a hostvars object
    hostvars = HostVars(inventory, variable_manager, loader)

    # Set host facts variable for the localhost
    hosts = [inventory.get_host('localhost')]


# Generated at 2022-06-21 09:30:42.104164
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.module_utils.common._collections_compat import Mapping, MutableSequence
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    class FakeOptions(object):
        connection = 'local'
        module_path = None
        forks = 10
        become = None
        become_method = None
        become_user = None
        verbosity = 3
        check = False
        diff = False

    class FakeCLI(object):
        options = FakeOptions()
        stdin = None
        args = ['localhost']

    class FakePlay(object):
        variable_manager = None
        hosts = ['localhost']
        name = 'fake_play'
        based

# Generated at 2022-06-21 09:30:51.650325
# Unit test for constructor of class HostVars
def test_HostVars():
  # 1. Create an empty class
  class EmptyClass:
    pass

  # 2. Create a dummy loader to pass to HostVars
  class DummyLoader:
    pass

  # 3. Create a dummy inventory to pass to HostVars
  class DummyInventory:
    def __init__(self):
      pass

    def get_host(self, host_name):
      return None

  # 4. Create a dummy VariableManager to pass to HostVars
  class VariableManager:
    def __init__(self):
      pass

  class DummyVarsManager (VariableManager):
    pass

  # 5. Create a HostVars object
  DummyVarsManager.loader = DummyLoader()
  DummyVarsManager.hostvars = HostVars(DummyInventory(), DummyVarsManager(), DummyLoader())

# Generated at 2022-06-21 09:31:02.358674
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    myinv = InventoryManager(loader=DataLoader(), sources='localhost,')
    fact_cache = dict()
    variable_manager = VariableManager(loader=DataLoader(), inventory=myinv, fact_cache=fact_cache)
    hostvars = HostVars(myinv, variable_manager, DataLoader())
    result = hostvars.raw_get('localhost')
    assert 'localhost' in result
    assert result['localhost']['ansible_facts']['default_ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-21 09:31:11.404294
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    inventory = Inventory(host_list=[])
    host1 = inventory.add_host("127.0.0.1")
    host2 = inventory.add_host("127.0.0.2")

    hv = HostVars(inventory, VariableManager(), loader=None)

    host_name = "127.0.0.1"
    hv.set_host_variable(host1, host_name, host_name)

    assert hv[host_name] == host1.name

# Generated at 2022-06-21 09:31:19.759901
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()

    group_vars = {'foo': 'bar'}
    host_vars = {
        '127.0.0.1': {'ansible_ssh_host': '127.0.0.1'},
        'example.org': {'ansible_ssh_host': '192.168.0.1'},
        'example.com': {'ansible_ssh_host': '192.168.0.2'},
    }
    extra_vars = {'extra': 'var'}

# Generated at 2022-06-21 09:31:29.846073
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    inv = InventoryManager(loader=None, sources='localhost,')
    inv_host = Host(name='localhost')
    inv_group = Group('ungrouped')
    inv_group.add_host(inv_host)
    inv.add_group(inv_group)
    inv.set_variable_manager(VariableManager())

    pb = Play.load(dict(
        hosts=['localhost'],
        vars={'test': {'key': 'value'}}),
        variable_manager=inv.get_variable_manager(),
        loader=None,
    )


# Generated at 2022-06-21 09:31:42.251729
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import unittest
    import pickle
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class TestHostVars(unittest.TestCase):
        def test_method_set_variable_manager(self):
            variable_manager = VariableManager()
            loader = DataLoader()
            inventory = InventoryManager(
                loader=loader,
                sources='localhost,'
            )
            hostvars = HostVars(inventory, variable_manager, loader)
            variable_manager_new = VariableManager()
            hostvars.set_variable_manager(variable_manager_new)
            pickled_data = pickle.dumps(variable_manager_new)

# Generated at 2022-06-21 09:32:00.473040
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    variable_manager = VariableManager()
    loader = variable_manager._loader
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['localhost,']))
    hostvars = HostVars(variable_manager.inventory, variable_manager, loader)
    new_hostvars = deepcopy(hostvars)
    assert id(hostvars) != id(new_hostvars)
    assert hostvars is not new_hostvars
    assert id(hostvars._variable_manager) == id(new_hostvars._variable_manager)
    assert id(hostvars._loader) == id(new_hostvars._loader)
    assert id(hostvars._inventory)

# Generated at 2022-06-21 09:32:08.553173
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    def _mock_inventory():
        return MockInventory()

    def _mock_variable_manager():
        return MockVariableManager()

    def _mock_loader():
        return MockLoader()

    # mocks
    class MockVariableManager():
        class MockHost():
            name = 'localhost'
            vars={
                'var1': 'value1',
                'var2': 'value2',
                'var3': '{{ var1 }}',
                'var4': '{{ var2 }}',
                'var51': '{{ var3 }}',
                'var52': '{{ var4 }}',
                'var61': '{{ var3 }}',
                'var62': '{{ var4 }}',
                'var71': '{{ var4 }}',
                'var72': '{{ var3 }}'
            }

       

# Generated at 2022-06-21 09:32:14.497688
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(loader=None, variable_manager=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)
    hostvars[('foo', 'bar')] = 'baz'

    assert hostvars.raw_get(('foo', 'bar')) is not None

# Generated at 2022-06-21 09:32:26.201551
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    '''
    Ensure that method __getitem__ of class HostVarsVars does not fail.
    '''
    from ansible.plugins.loader import vars_loader

    # Ensure that a var can be retrieved from a HostVarsVars instance
    variables = {
        'foo': 'bar'
    }
    host_vars_vars = HostVarsVars(variables, loader=vars_loader)
    assert host_vars_vars['foo'] == 'bar'

    # Ensure that a var value is expanded when retrieved
    variables = {
        'foo': '{{ bar }}',
        'bar': '{{ baz }}',
        'baz': 'fuu',
    }
    host_vars_vars = HostVarsVars(variables, loader=vars_loader)
    assert host

# Generated at 2022-06-21 09:32:36.329793
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars(InventoryManager(loader=DataLoader()), VariableManager(loader=DataLoader()), DataLoader())

    # test case 1
    # host defined in inventory
    data = hostvars.raw_get('localhost')
    assert isinstance(data, dict)

    # test case 2
    # host not defined in inventory
    data = hostvars.raw_get('testhost')
    assert isinstance(data, AnsibleUndefined)

# Generated at 2022-06-21 09:32:39.381810
# Unit test for constructor of class HostVars
def test_HostVars():
    # Import needed modules
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create components needed by constructor
    inventory = InventoryManager(loader=DataLoader(), sources='localhost')
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create class instance
    hostvars = HostVars(inventory, variable_manager, loader)

    # Verify components are stored in __dict__
    assert hostvars._inventory is inventory
    assert hostvars._loader is loader
    assert hostvars._variable_manager is variable_manager



# Generated at 2022-06-21 09:32:49.153880
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    inv = Inventory(loader=None)
    inv.set_variable('localhost', 'ansible_connection', 'local')
    var_manager = VariableManager(loader=None, inventory=inv)
    hostvars = HostVars(inventory=inv, variable_manager=var_manager, loader=None)
    hostvars.set_host_facts('localhost', dict(remote_user='root'))

    import copy
    hostvars_copy = copy.deepcopy(hostvars)
    remote_user_fact_copy = hostvars_copy['localhost']['ansible_facts']['remote_user']
    assert 'root' == remote_user_fact_copy


# Generated at 2022-06-21 09:33:01.434984
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({})
    inv = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    vars_cache = HostVars(inv, variable_manager, loader)

    # The variable 'foo' is not defined in variable manager, so the
    # templated result should be empty string.
    vars_cache.set_host_variable('localhost', 'bar', dict(foo='bar'))
    foo = vars_cache['localhost']

    # The variable 'foo' is not defined, so the iterator should not
    # yield it
    assert not any('foo' in v for v in foo)

    # The variable 'bar' is defined and contains

# Generated at 2022-06-21 09:33:13.673037
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import group_loader
    from ansible.vars.manager import VariableManager

    group_loader.add_directory('./lib/ansible/plugins/inventory')
    group_loader.add_directory('./lib/ansible/plugins/vars')
    loader = group_loader
    host_vars = HostVars(inventory=InventoryManager(loader=loader, sources=None), variable_manager=VariableManager(loader=loader))
    host_vars_obj = host_vars._find_host('localhost')

    assert 'localhost' in host_vars
    assert host_vars_obj in host_vars
    assert 1 == len(host_vars)



# Generated at 2022-06-21 09:33:15.193923
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    assert len(HostVars(None, None, None)) == 0

# Generated at 2022-06-21 09:33:44.620260
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    inventory = InventoryManager(loader=DataLoader(),
                                 sources=[{'key': 'value'}])
    variable_manager = VariableManager(loader=DataLoader(),
                                       inventory=inventory)

    config = {}
    inventory.parse_sources(config)
    host = inventory.get_host("test_hostname")
    host.set_variable("foo", "bar")
    inventory._cache["test_hostname"] = host

    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    assert len(hostvars) == 1



# Generated at 2022-06-21 09:33:48.040581
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader = object()
    variables = dict(
        test1='{{a}}',
        test2='{{b}}',
        test3='{{c}}',
        test4=42,
        test5=list(),
        test6=dict(),
        test7=True,
        test8=42.0,
        test9=0,
    )

    assert repr(HostVarsVars(variables, loader)) == repr(variables)


# Generated at 2022-06-21 09:33:56.303792
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=vars_manager)
    hostvars = HostVars(inventory, vars_manager, loader)
    repr_hostvars = repr(hostvars)
    assert "localhost" in repr_hostvars
    assert "ansible_ssh_host" in repr_hostvars

# Generated at 2022-06-21 09:34:05.378932
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os

    current_dir = os.path.dirname(os.path.realpath(__file__))
    inventory_path = os.path.join(current_dir, 'hostvars.inventory')

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=inventory_path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    host = inventory.get_host("test01")

    # Set the initial host facts for test01

# Generated at 2022-06-21 09:34:13.246739
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import os
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    basedir = os.path.join(os.path.dirname(__file__), 'test-data')
    inventory = InventoryManager(loader=DataLoader(), sources=[os.path.join(basedir, 'hosts')])

    hostvars = HostVars(inventory, None, None)

    assert 'testhost' in hostvars
    assert 'non-existent' not in hostvars

# Generated at 2022-06-21 09:34:17.765665
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():

    from ansible.vars import VariableManager

    class FakeInventory(object):
        def __init__(self):
            self.hosts = ['localhost']

    class FakeLoader(object):
        def __init__(self):
            pass

    # VariableManager is not copyable, so we can't use it as argument of deepcopy.
    # To test method set_variable_manager of class HostVars, we use __getstate__
    # and __setstate__ methods to simulate pickling and unpickling of HostVars
    # instance. During unpickling, HostVars.__setstate__ calls
    # VariableManager.__setstate__ and VariableManager.__setstate__ calls
    # HostVars.set_variable_manager.

    inventory = FakeInventory()
    loader = FakeLoader()

# Generated at 2022-06-21 09:34:22.452751
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = 'ansible.parsing.dataloader.DataLoader'
    variables = {'var1': 'ansible_version', 'var2': 'ansible_user'}
    host_vars_vars = HostVarsVars(variables, loader)
    print(host_vars_vars)

# Generated at 2022-06-21 09:34:33.614601
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = AnsibleMock()
    inventory.hosts = ['localhost']
    loader = AnsibleMock()
    templar = Templar(loader=loader, variables={'a': 0, 'b': 1})
    loader.get_basedir.return_value = '/var/tmp'
    loader.path_dwim.return_value = '/var/tmp/'

    # HostVars takes a variable manager, but we don't use it
    variable_manager = AnsibleMock()
    variable_manager.hostvars = None
    variable_manager.get_vars.return_value = {'a': 0, 'b': 1}
    hv = HostVars(inventory, variable_manager, loader)


# Generated at 2022-06-21 09:34:40.015659
# Unit test for constructor of class HostVars
def test_HostVars():
    '''
    Unit test for constructor of class HostVars
    '''
    # Constructor of class HostVars requires 3 argments that are
    # inventory, variable_manager, loader.
    try:
        hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    except TypeError:
        pass


# Generated at 2022-06-21 09:34:41.530025
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    class test_loader(object):
        pass
    vars = {}
    hvv = HostVarsVars(vars, test_loader())
    assert isinstance(hvv, HostVarsVars)
    assert len(hvv) == 0

# Generated at 2022-06-21 09:35:37.463424
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    host1 = Host(name='host1')
    host1.vars['test_var'] = 'test_value'

    variable_manager = VariableManager(loader=loader)

    hostvars = HostVars(variable_manager=variable_manager, loader=loader, inventory=None)
    hostvars.set_host_variable(host1, 'test_var', 'updated_value')

    assert hostvars.raw_get(host1.name)['test_var'] == 'updated_value'

# Generated at 2022-06-21 09:35:39.546804
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class FakeLoader:
        def get_basedir(self):
            pass
    loader = FakeLoader()
    HostVarsVars({}, loader)

# Generated at 2022-06-21 09:35:44.060981
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    vm = VariableManager()
    vm.extra_vars = dict(
        foo='foo',
    )

# Generated at 2022-06-21 09:35:52.368174
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars import VariableManager
    variables = {'var1': 1, 'var2': 'a'}
    templar = Templar(variables=variables, loader=None)
    test_variables = HostVarsVars(variables, templar)
    # Test that we get out what we put in
    assert len(test_variables) == len(variables)
    assert len(test_variables.keys()) == len(variables)
    assert len(test_variables.values()) == len(variables)
    assert len(test_variables.items()) == len(variables)
    # Test that we get the same values as the values of the initial dict
    assert test_variables['var1'] == variables['var1']

# Generated at 2022-06-21 09:35:58.093076
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    # Create inventory
    inventory = InventoryManager(loader=None, sources='localhost,')

    # Create variable manager
    variable_manager = VariableManager()

    # Create HostVars
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Change inventory
    hostvars.set_inventory(InventoryManager(loader=None, sources='localhost,'))

    # Check if inventory was changed
    assert hostvars._inventory != inventory

# Generated at 2022-06-21 09:36:04.160488
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import ansible.parsing.dataloader
    import ansible.inventory.host
    import ansible.vars.manager

    loader = ansible.parsing.dataloader.DataLoader()
    host = ansible.inventory.host.Host(name='localhost')
    variables = ansible.vars.manager.VariableManager()

    hostvars = HostVars(None, variables, loader)
    hostvars.set_host_facts(host, dict(ansible_lsb=dict(major_release='12')))

    assert hostvars.raw_get('localhost')['ansible_lsb']['major_release'] == '12'

# Generated at 2022-06-21 09:36:05.933988
# Unit test for constructor of class HostVars
def test_HostVars():

    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)

    assert hostvars.__class__.__name__ == 'HostVars'

# Generated at 2022-06-21 09:36:08.622991
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({'foo': 'bar'}, None)
    assert 'foo' in hvv
    assert 'bar' in hvv
    assert 'baz' not in hvv

    for var in hvv:
        assert var in ['foo']


# Generated at 2022-06-21 09:36:17.287001
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    host_vars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    host_name = 'test'

    # Returns false if host_name does not exist in inventory
    assert host_name not in host_vars

    inventory.add_host(host_name)

    # Returns true if host_name exists in inventory
    assert host_name in host_vars

# Generated at 2022-06-21 09:36:27.839579
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import os
    from ansible.parsing.dataloader import DataLoader

    class TestVariableManager:
        def __init__(self):
            self._vars_cache = {}
            self._fact_cache = {}
            self._nonpersistent_fact_cache = {}

        def set_host_variable(self, host, varname, value):
            pass

        def set_nonpersistent_facts(self, host, facts):
            pass

        def set_host_facts(self, host, facts):
            pass

        def get_vars(self, loader, path, entities, cache=True, post_validate=True,
                     include_hostvars=True, template_vars=None,
                     add_group_vars=True, add_host_vars=True):
            return {}
