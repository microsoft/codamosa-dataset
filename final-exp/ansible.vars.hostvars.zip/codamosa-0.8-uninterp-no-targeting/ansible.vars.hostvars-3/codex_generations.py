

# Generated at 2022-06-21 09:27:33.331687
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    hostvars = HostVars(inventory, VariableManager(), DataLoader())

    host = inventory.get_host("localhost")
    facts = {"fact1": "val1", "fact2": "val2"}
    hostvars.set_host_facts(host, facts)

    assert hostvars.get(host).get("ansible_facts") == facts


# Generated at 2022-06-21 09:27:37.831319
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory

    pb = Playbook.load('test/test_playbook.yml', variable_manager=None, loader=None)
    inventory = Inventory.load(pb.inventory)

    HostVars(inventory, variable_manager=None, loader=None)

# Generated at 2022-06-21 09:27:46.672270
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    paths = [ '/etc/ansible/hosts' ]
    inventory = InventoryManager(loader=loader, sources=paths)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert sorted(hostvars) == ['all', 'centos7', 'client', 'client1', 'client2', 'localhost']

# Generated at 2022-06-21 09:27:51.231499
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {'test1': 'test2'}
    loader = 'loader'

    hostvarsvars = HostVarsVars(variables, loader)

    assert hostvarsvars._vars is variables
    assert hostvarsvars._loader is loader

# Generated at 2022-06-21 09:28:01.449114
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import sys
    import pickle
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestHostVars(unittest.TestCase):

        def setUp(self):
            self.variable_manager = VariableManager()
            self.loader = DataLoader()
            self.inventory = InventoryManager(loader=self.loader, sources='localhost,')
            self.variable_manager.set_inventory(self.inventory)
            self.hostvars = HostVars(inventory=self.inventory, variable_manager=self.variable_manager, loader=self.loader)



# Generated at 2022-06-21 09:28:11.581485
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    class MockHost:
        def __init__(self, name, vars):
            self._name = name
            self._vars = vars

    class MockVariableManager:
        _loader = None
        _hostvars = None

        def get_vars(self, host=None, include_hostvars=True):
            return host._vars

    class MockInventory:
        def get_host(self, host_name):
            for host in self.hosts:
                if host._name == host_name:
                    return host
            return None

        def get_hosts(self, pattern="all"):
            return self.hosts

    def _assert_equals(lhs, rhs):
        assert lhs == rhs

    # Test case 1: simple variable expansion

# Generated at 2022-06-21 09:28:19.479596
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import ansible.inventory
    import ansible.vars.manager
    import ansible.template.template

    inventory = ansible.inventory.Inventory(host_list=['localhost'])
    variable_manager = ansible.vars.manager.VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    assert hostvars
    for host in hostvars:
        assert host == 'localhost'


# Generated at 2022-06-21 09:28:29.204723
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import copy

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    vars_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 09:28:40.713498
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    """
    Check if __getitem__ is returning the right value
    """

    import ansible.module_utils.common._collections_compat

    class FakeLoader(object):

        class FakeVars:
            def __init__(self, value):
                self.value = value

            @property
            def foo(self):
                return self.value

        class FakeUndefined:
            pass

        def __init__(self):
            self.vars = self.FakeVars(42)
            self.undefined = self.FakeUndefined()

    class FakeDict(ansible.module_utils.common._collections_compat.MutableMapping):

        def __init__(self):
            self.data = {'foo': 'bar'}


# Generated at 2022-06-21 09:28:47.902900
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = [
        'all:',
        '  children:',
        '    test:',
        '      hosts:'
        '        test.example.org:',
    ]

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Note: __getstate__ method of VariableManager is not implemented
    #       so the state is the same as variables' dict.
    state = {'_inventory': inventory, '_loader': loader,
             '_variable_manager': variable_manager.get_vars(),
             '_host': 'test.example.org'}

    hostvars.__setstate__

# Generated at 2022-06-21 09:29:00.464793
# Unit test for constructor of class HostVars
def test_HostVars():
    ''' make sure we can create a HostVars instance '''

    import ansible.plugins
    my_inv = ansible.plugins.InventoryModule()
    my_vars = ansible.plugins.VarsModule()
    my_loader = ansible.plugins.ModuleLoader()

    my_vars.set_inventory(my_inv)
    HostVars(inventory=my_inv, variable_manager=my_vars, loader=my_loader)


# Generated at 2022-06-21 09:29:07.307996
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # Tests that HostVars.__contains__() returns False
    # for hosts that are absent in the inventory.
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager("")
    variable_manager = DummyVariableManager()
    loader = DummyLoader()

    hostvars = HostVars(inventory, variable_manager, loader)

    assert (not "non-existent_host" in hostvars)



# Generated at 2022-06-21 09:29:14.772673
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    variable_manager = dict()
    variable_manager['_hostvars'] = dict()
    variable_manager['_hostvars']['host1'] = {
        'foo': 'bar',
        'bar': 'baz',
    }
    variable_manager['_hostvars']['host2'] = {
        'baz': 'baz',
        'foo': 'bar',
    }
    variable_manager['_hostvars']['host3'] = {
        'foo': 'bar',
        'bar': 'baz',
    }
    inventory = dict()
    inventory['hosts'] = list()
    inventory['hosts'].append('host1')
    inventory['hosts'].append('host2')
    inventory['hosts'].append('host3')
    loader = dict()

   

# Generated at 2022-06-21 09:29:25.042500
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars.manager import VariableManager
    hostvars2 = HostVarsVars({"varname": "foo"}, None)
    assert isinstance(hostvars2,HostVarsVars)
    assert hostvars2.__contains__("varname")
    assert len(hostvars2) == 1
    assert hostvars2.__getitem__("varname") == "foo"
    assert hostvars2.keys() == [ "varname" ]
    hostvars = HostVars(None, VariableManager(), None)
    assert hostvars.__contains__("foo") is False

# Generated at 2022-06-21 09:29:36.518979
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # NOTE: This unit test relies on internal implementation details of HostVars
    #       and might be broken by refactoring.

    import os

    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    from ansible.module_utils._text import to_bytes

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.vars.manager import VariableManager

    def assert_contains(hostvars, hostname):
        # __contains__() returns a bool, not None or anything else.
        assert hostvars.__contains__(hostname), "HostVars contains the host '%s'" % hostname


# Generated at 2022-06-21 09:29:44.411946
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Mock class variable_manager
    variable_manager = AnsibleVars()
    variable_manager.hostvars = HostVars()

    # Mock class host
    class Host():
        name = 'fake'
        vars = {}

    host = Host()
    vars = {
        'ansible_cpu_cores': 2,
        'ansible_cpu_threads_per_core': 3,
        'ansible_processor_vcpus': 6,
        'ansible_processor_count': 6,
    }
    variable_manager.set_nonpersistent_facts(host, vars)

    assert variable_manager.hostvars[host.name] == vars

# Generated at 2022-06-21 09:29:51.207143
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    hostvars = HostVars(None, variable_manager, loader)

    hostvars.set_nonpersistent_facts("localhost", {"nonpersistent_fact": "abc123"})
    assert("abc123" == hostvars.raw_get("localhost")["nonpersistent_fact"])

    nonpersistent_facts = hostvars.raw_get("localhost")["nonpersistent_facts"]
    assert("abc123" == nonpersistent_facts["nonpersistent_fact"])

# Generated at 2022-06-21 09:29:55.123980
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = { 'foo': 'bar' }
    loader = 'the loader'

    hostvars_vars = HostVarsVars(variables, loader)

    assert(hostvars_vars._vars is variables)
    assert(hostvars_vars._loader is loader)

# Generated at 2022-06-21 09:30:01.940138
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # Create a HostVars object
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)

    # Check if template will be used correctly.
    # It should return same value without changes if value is AnsibleUnrredefined or boolean.
    for val in [AnsibleUndefined(), False, True]:
        hostvars._vars_cache = {'test_host': {'test_var': val}}
        assert hostvars.raw_get('test_host') == {'test_var': val}

    # Check if the values will be changed by the templating engine.
    # It should return the changed value.
    # Create a fake host.

# Generated at 2022-06-21 09:30:02.759470
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    pass

# Generated at 2022-06-21 09:30:08.740909
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    hostvars = HostVars(AnsibleMapping(), None, None)
    assert isinstance(hostvars, Mapping)



# Generated at 2022-06-21 09:30:21.621448
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.template import Templar
    from ansible.vars.vars_cache import VarsCache

    test_data = {}

    v = VarsCache()
    v.set_host_variable('h1', 'x1', 'x1')
    v.set_host_variable('h1', 'x2', 'x2')
    v.set_host_variable('h1', 'x3', 'x3')
    v.set_host_variable('h1', 'x4', 'x4')
    v.set_host_variable('h1', 'x5', 'x5')
    v.set_host_variable('h2', 'x1', 'x1')
    v.set_host_variable('h2', 'x2', 'x2')

# Generated at 2022-06-21 09:30:30.188941
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    class FakeVariableManager:
        def __init__(self, hostvars):
            self._hostvars = hostvars

        def set_nonpersistent_facts(self, host, facts):
            self._hostvars.set_nonpersistent_facts(host, facts)

    class FakeLoader:
        pass

    class FakeInventory:
        def __init__(self, hosts_list):
            self.hosts = hosts_list

    class FakeHost:
        def __init__(self, name):
            self.name = name

    hosts_list = [FakeHost('first'), FakeHost('second')]
    loader = FakeLoader()
    inventory = FakeInventory(hosts_list)
    variable_manager = FakeVariableManager(HostVars(inventory, None, loader))

# Generated at 2022-06-21 09:30:41.573528
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import copy
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def test_get_variable(self, name):
        # this is a mock method to return variables
        if name == 'fact_foo':
            return 'fact_value'
        elif name == 'bar':
            return 'baz'
        else:
            return None

    class TestHost(object):
        # override the get_variable function
        get_variable = test_get_variable
        name = 'test_host'

    def test_find_host(self, host_name):
        if host_name == 'test_host':
            return TestHost()
        else:
            return None


# Generated at 2022-06-21 09:30:51.352614
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from collections import Iterable

    loader = DataLoader()
    host_list = ['localhost', 'other_host']
    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 09:31:03.370841
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')
    hostvars.set_host_variable(host, 'foo', 'bar')

    assert 'foo' in hostvars[host.name]
    assert hostvars[host.name]['foo'] == 'bar'

    # set different value for the same variable on different host
    host = inventory.get_host('127.0.0.1')
    hostvars

# Generated at 2022-06-21 09:31:14.725298
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.plugins.loader import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars import Targetable
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable

    class DummyInventory(object):

        def __init__(self):
            self._hosts = []

        def add_host(self, host):
            self._hosts.append(host)

        def get_host(self, name):
            if name == 'example.com':
                class Host(Targetable):
                    def __init__(self, name):
                        self.name = name
                        self.vars = {'foo': 'foo_value'}
                return Host(name)

# Generated at 2022-06-21 09:31:22.084980
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list='/dev/null')
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    variable_manager._fact_cache['localhost'] = dict(foo='bar')

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    # HostVars should return an empty dict when host_name does not match any host in inventory
    assert dict() == hostvars.raw_get('foo')

    # HostVars should return the value of _fact_cache for

# Generated at 2022-06-21 09:31:27.808582
# Unit test for constructor of class HostVars
def test_HostVars():
    import sys, cPickle
    from ansible.inventory.manager import InventoryManager

    loader = cPickle.loads(cPickle.dumps(InventoryManager()._loader, cPickle.HIGHEST_PROTOCOL))
    variable_manager = cPickle.loads(cPickle.dumps(InventoryManager()._variable_manager, cPickle.HIGHEST_PROTOCOL))
    inventory = cPickle.loads(cPickle.dumps(InventoryManager().inventory, cPickle.HIGHEST_PROTOCOL))
    hostvars = HostVars(inventory, variable_manager, loader)

    if sys.version_info >= (3, 0):
        assert len(hostvars) == 0
        assert 'foo' not in hostvars

# Generated at 2022-06-21 09:31:34.662897
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    inventory_manager = InventoryManager(loader=DataLoader())
    inventory_manager.add_host('test')
    variable_manager = VariableManager(loader=DataLoader())
    hostvars = HostVars(inventory_manager, variable_manager, DataLoader())
    test = hostvars._find_host('test')
    assert test is not None

    # Replace inventory instance
    inventory_manager = InventoryManager(loader=DataLoader())
    hostvars.set_inventory(inventory_manager)
    test = hostvars._find_host('test')
    assert test is None

# Generated at 2022-06-21 09:31:49.519248
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():

    import ansible.constants
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    ansible.constants.HOST_KEY_CHECKING = False
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_vars_instance = hostvars["localhost"]
    assert "vars" in hostvars_vars_instance

# Generated at 2022-06-21 09:32:01.651708
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    class Vars(MutableMapping):

        def __init__(self):
            self._data = {}

        def __delitem__(self, key):
            del self._data[key]

        def __getitem__(self, key):
            return self._data[key]

        def __setitem__(self, key, value):
            self._data[key] = value

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)

    class Loader(object):
        def __init__(self):
            self._templates = {}

        def add_template(self, path, data):
            self._templates[path] = data

# Generated at 2022-06-21 09:32:03.960021
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars = HostVarsVars(dict(a=10, b=20), None)
    assert list(hostvars) == ['a', 'b']


# Generated at 2022-06-21 09:32:10.996668
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    inventory = Inventory(loader=None, variable_manager=VariableManager(loader=None, inventory=None))
    inventory.hosts = {'host1': ''}
    hvv = HostVarsVars(inventory, variables={'foo': '{{bar}}', 'bar': 'baz'}, loader=None)
    assert 'bar' in hvv

# Generated at 2022-06-21 09:32:21.710324
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Create test data
    my_host1 = 'my_host1'
    my_host2 = 'my_host2'
    my_host3 = 'my_host3'
    my_host4 = 'my_host4'
    my_host5 = 'my_host5'
    my_host6 = 'my_host6'

    my_host1_vars = {"key1": "value1", "key2": "value2"}
    my_host2_vars = {"key3": "value3", "key4": "value4"}
    my_host3_vars = {"key3": "value3", "key4": "value4"}


# Generated at 2022-06-21 09:32:33.314297
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    host = Host("foo")
    inventory.add_host(host)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    hostvars.set_nonpersistent_facts(host, {'foo': 'bar'})

    assert host.get_vars() == {'foo': 'bar'}

# Generated at 2022-06-21 09:32:44.132855
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    t = Templar(loader=loader)

    inventory = InventoryManager(loader=loader, sources=["127.0.0.1"])
    variable_manager = inventory._variable_manager
    variable_manager._loader = loader
    variable_manager._tqm = None
    variable_manager._inventory = inventory
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = wrap_var(dict())
    variable_manager._fact_cache = dict()
    variable_manager._nonpersistent

# Generated at 2022-06-21 09:32:48.145317
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory()
    variable_manager = VariableManager()

    h = HostVars(inventory, variable_manager, loader=None)

    # Check repr if no hosts in inventory
    assert repr(h) == '{}'

# Generated at 2022-06-21 09:33:00.627902
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = dict(a=['a_val_1', 'a_val_2'],
                     b=dict(c='b_c_val', d=['b_d_val']),
                     e=dict(f=['a_val_1', 'a_val_2']))
    hostvars = HostVarsVars(variables, None)
    assert hostvars['a'] == ['a_val_1', 'a_val_2']
    assert hostvars['b'] == {'c': 'b_c_val', 'd': ['b_d_val']}
    assert hostvars['b']['c'] == 'b_c_val'
    assert hostvars['b']['d'] == ['b_d_val']

# Generated at 2022-06-21 09:33:12.142336
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'var': '{{var}}'})
    hostvars = HostVars({'var': 'value'}, variable_manager=None, loader=None)
    hostvars['localhost'] = templar.template({'var': 'value'}, fail_on_undefined=False,
                                             static_vars=STATIC_VARS)
    assert hostvars.raw_get('localhost') == {'var': 'value'}
    assert hostvars['localhost'] == {'var': 'value'}
    assert isinstance(hostvars['localhost'], HostVarsVars)



# Generated at 2022-06-21 09:33:27.456956
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import sys
    import os

    class FakeLoader(object):
        def get_basedir(self):
            return os.path.abspath('/no/such/base/dir')

    class FakeOptions(object):
        def __init__(self, connection='smart', module_path=None, forks=5, become=None, become_method=None, become_user=None, check=False, diff=False):
            self.connection = connection
            self.module_path = module_path
            self.forks = forks
            self.become = become
            self.become_method = become_method
            self.become_user = become_user
            self.check = check
            self.diff = diff

    class FakeInventory(object):
        def __init__(self):
            self.hosts = set()

# Generated at 2022-06-21 09:33:38.785496
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    class Host():
        name = None

        def __init__(self, name):
            self.name = name

    class Inventory():
        def __init__(self, hosts):
            self.hosts = hosts

        def get_host(self, host_name):
            for host in self.hosts:
                if host.name == host_name:
                    return host

    class VariableManager():
        def __init__(self, vars):
            self._vars = vars

        def get_vars(self, host=None, include_hostvars=False):
            return self._vars

    def _loader(path):
        return "/path/to/%s" % path

    h1 = Host('h1')
    h2 = Host('h2')


# Generated at 2022-06-21 09:33:48.659610
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    loader = Mock()
    inventory = Mock()
    play_context = PlayContext()
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    cache = HostVars(inventory, variable_manager, loader)

    # Put cache into pickleable state to be able to test __setstate__ method
    cache._variable_manager = None
    cache._loader = None

    cache.__setstate__(cache.__dict__)

    assert cache._loader is loader
    assert cache._variable_manager._loader is loader
    assert cache._variable_manager._hostvars is cache
    assert cache._variable_manager.inventory is inventory

# Generated at 2022-06-21 09:34:00.928423
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    hostvarsvars_obj = HostVarsVars({"a": "A", "b": "{{ c }}"}, None)
    assert dict(hostvarsvars_obj) == {'a': 'A', 'b': AnsibleUndefined()}

    hostvarsvars_obj = HostVarsVars({"a": "A", "c": "C", "b": "{{ c }}"}, None)
    assert dict(hostvarsvars_obj) == {'a': 'A', 'b': 'C', 'c': 'C'}

    hostvarsvars_obj = HostVarsVars({"a": "A", "c": "C"}, None)
    assert dict(hostvarsvars_obj) == {'a': 'A', 'c': 'C'}

# Generated at 2022-06-21 09:34:13.628478
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    data = dict(a='{{ foo }}', b=30, c='c')
    vars = HostVarsVars(data, loader=DataLoader())
    assert vars.__repr__() == "{u'a': u'{{ foo }}', u'c': 'c', u'b': 30}"

    data = dict(a='1{{ foo }}2', b=30, c='c')
    vars = HostVarsVars(data, loader=DataLoader())

# Generated at 2022-06-21 09:34:20.424736
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    variable_manager2 = VariableManager(loader=None, inventory=inventory)
    variable_manager2._hostvars = None
    hostvars.set_variable_manager(variable_manager2)
    assert variable_manager2._hostvars is hostvars
    assert variable_manager._hostvars is None

# Generated at 2022-06-21 09:34:22.202299
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    a = HostVars({}, variable_manager=None, loader=None)
    assert len(a) == 0

# Generated at 2022-06-21 09:34:27.769324
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    vars_data = {'foo': None, 'bar': 'something'}
    vars_obj = HostVarsVars(vars_data, None)

    assert vars_obj.__contains__('foo')
    assert vars_obj.__contains__('bar')
    assert not vars_obj.__contains__('baz')

# Generated at 2022-06-21 09:34:36.544706
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    vars_dict = dict(
        key1 = dict(key2 = "val"),
        key3 = dict(key4 = dict(key5 = "val"))
    )

    hostvars = HostVars(None, None, None)
    assert hostvars.raw_get(None) != vars_dict
    hostvars.__init__(None, None, None)
    assert hostvars.raw_get(None) == vars_dict

    hostvarsvars = hostvars.__getitem__(None)
    assert hostvarsvars.__getitem__("key1") == dict(key2 = "val")
    assert hostvarsvars.__getitem__("key3") == dict(key4 = dict(key5 = "val"))

    hostvarsvars_key1 = hostv

# Generated at 2022-06-21 09:34:49.840505
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    host = Host('localhost')
    inventory = Inventory()
    inventory.add_host(host)
    variable_manager = VariableManager(loader=None, host_vars=None, group_vars=None)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    hostvars.set_host_variable(host, 'foo', 'bar')
    hostvars.set_host_variable(host, 'baz', 'qux')
    copied = copy.deepcopy(hostvars)
    for host in hostvars:
        assert host in copied
        assert copied.get(host).get('foo') == 'bar'

# Generated at 2022-06-21 09:35:33.401884
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    host = inventory.get_host("example.com")
    assert not host.get_vars()
    hostvars.set_host_facts(host, {'foo': 42})
    assert host.get_vars() == {'foo': 42}
    hostvars.set_nonpersistent_facts(host, {'bar': 43})
    assert host.get_vars() == {'foo': 42, 'bar': 43}

# Generated at 2022-06-21 09:35:40.803698
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # Case 1.1: class HostVarsVars.__contains__() with undefined variable
    hostvars = HostVarsVars({'a': 1, 'b': 2, 'c': 3}, DataLoader())
    assert hostvars.__contains__('a')

    # Case 1.2: class HostVarsVars.__contains__() with defined variable
    assert not hostvars.__contains__('z')

    # Case 2.1: class HostVars.__contains__() with existing host
    inventory

# Generated at 2022-06-21 09:35:50.387936
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    '''
    Check that the method _set_inventory of class HostVars calls
    VariableManager.set_inventory
    '''
    import os
    import sys
    import unittest

    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader
    from ansible.utils.vars import combine_vars

    class MockVariableManager:
        def __init__(self):
            self.inventory = None
            self.vars_cache = {}

        def set_inventory(self, inv):
            self.inventory = inv

        def get_vars(self, host=None, include_hostvars=True):
            vars = combine_vars(self.inventory.get_host(host).get_vars())


# Generated at 2022-06-21 09:35:53.096186
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    '''
    Test for method __deepcopy__ of class HostVars
    '''
    import copy

    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    copy.deepcopy(hostvars)

# Generated at 2022-06-21 09:36:03.533567
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    def test(test_data, expected_results):
        variable_manager = VariableManager()
        loader = DataLoader()

        inventory = InventoryManager(loader=loader)
        variable_manager.set_inventory(inventory)

        play_source = dict(
            name="Ansible Play",
            hosts='localhost',
            gather_facts='no',
            tasks=[
                dict(action=dict(module='vars', args=test_data)),
            ]
        )

# Generated at 2022-06-21 09:36:07.796234
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hostvars = HostVars(InventoryManager(loader=loader, sources=[]), VariableManager(loader=loader), loader=loader)
    assert repr(hostvars) == '{}'

# Generated at 2022-06-21 09:36:09.151017
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars_vars = HostVarsVars(
        variables={'a': 1, 'b': 2}, loader='loader')
    assert set(hostvars_vars.__iter__()) == set(['a', 'b'])

# Generated at 2022-06-21 09:36:19.292691
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from io import StringIO
    import ansible.constants as C

    C.HOST_KEY_CHECKING = False

    # setup the inventory
    inventory = Inventory(loader=None, variable_manager=VariableManager(), host_list=None)
    host_1 = inventory.add_host(host="localhost")
    host_1.vars = {"foo": 1}

    # need to set basedir or _get_host_variables will fail
    pb_dir = "/tmp"
    inventory.set_playbook_basedir(pb_dir)
    loader = 'not sure what this is used for'

    # create

# Generated at 2022-06-21 09:36:29.603406
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible.plugins.loader as plugin_loader

    # Create fake classes to create a HostVars instance
    class FakeInventory:
        hosts = ['localhost']
        def get_host(self, name):
            return name

    class FakeVariableManager:
        def get_vars(self, *args, **kwargs):
            return {}

    class FakeLoader:
        def load_from_file(self):
            # This method is not used by HostVars
            pass

    # Instantiate HostVars
    var_mgr = FakeVariableManager()
    var_mgr._loader = None
    var_mgr._hostvars = None
    host_vars = HostVars(FakeInventory(), var_mgr, FakeLoader())
    host_vars._variable_manager = var_mgr

    # Call method __

# Generated at 2022-06-21 09:36:39.054677
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    vm = VariableManager()
    hv = HostVars(inventory=None, variable_manager=vm, loader=None)
    assert hv._variable_manager == vm
    assert hv._variable_manager._loader is None
    assert hv._variable_manager._hostvars is None

    vm.__setstate__(state={})
    assert vm._loader is None
    assert vm._hostvars is None

    state = {'_inventory': None, '_loader': object(), '_variable_manager': vm}
    hv.__setstate__(state)
    assert hv._variable_manager == vm
    assert hv._variable_manager._loader == state['_loader']
    assert hv._variable_manager._hostvars == hv



# Generated at 2022-06-21 09:37:15.326320
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # HostVarsVars omits variables that cannot be templated, this test
    # ensures that the output is consistent across Python 2 and 3
    hostvars = HostVarsVars({'a': '{{ b }}'}, loader=None)
    assert repr(hostvars) == "HostVarsVars({'a': u''})"