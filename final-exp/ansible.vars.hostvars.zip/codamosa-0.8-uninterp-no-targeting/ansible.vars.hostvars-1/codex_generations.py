

# Generated at 2022-06-21 09:27:28.846799
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import platform
    import copy
    import unittest
    import sys
    import os
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.plugins.loader import add_all_plugin_dirs

    # We need to load plugins to have the 'groups' lookup work
    add_all_plugin_dirs()


# Generated at 2022-06-21 09:27:38.562475
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    """
    This is a unit test for method __len__ of class
    ansible.vars.hostvars.HostVars.

    This unit test checks if HostVars.__len__() returns
    the correct number of items.
    """
    from ansible.inventory import Inventory

    # Initialize an empty inventory
    inv = Inventory(host_list=[])

    # Initialize an empty HostVars object
    hv = HostVars(inv, {}, {})

    # Create a list of hosts
    hosts = ['first', 'second', 'third']

    # Populate inventory
    inv.add_host(hosts)

    assert len(inv.hosts) == len(hosts) == len(hv)



# Generated at 2022-06-21 09:27:50.511902
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # Create a variable manager without _loader and _hostvars attributes
    variable_manager = AnsibleVariableManager()
    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    # Create a loader and a hostvars
    loader = DictDataLoader({})
    hostvars = HostVars(None, variable_manager, loader)

    # Set the variable manager to hostvars
    hostvars.set_variable_manager(variable_manager)

    # Now the variable manager has _loader and _hostvars attributes
    assert variable_manager._loader is not None
    assert variable_manager._hostvars is not None

    # The attributes are the same objects as in hostvars
    assert variable_manager._loader is loader
    assert variable_manager._hostvars is hostvars

# Generated at 2022-06-21 09:28:00.910886
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create inventory
    loader = DataLoader()
    inv_manager = InventoryManager(loader, None)
    inv_manager.host_vars['localhost'] = {'foo': 'foo'}

    # Create variable manager
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Create hostvars
    hostvars = HostVars(inventory=inv_manager, loader=loader, variable_manager=variable_manager)

    # Set nonpersistent facts
    host = 'localhost'

# Generated at 2022-06-21 09:28:09.135398
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory("")
    host = inventory.get_host("localhost")
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, None)
    hostvars.set_host_variable(host, "hello", "world")

    # Check that the variable has been added
    assert(hostvars[host.name]["hello"] == "world")

    # Check that the variable is not redefined if set twice
    hostvars.set_host_variable(host, "hello", "different world")
    assert(hostvars[host.name]["hello"] == "world")

# Generated at 2022-06-21 09:28:12.337821
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert repr(hostvars) == "{'localhost': {}}"


# Generated at 2022-06-21 09:28:15.595816
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    hostvarsvars = HostVarsVars({"foo":"bar"}, None)
    result = ("foo" in hostvarsvars)
    assert(result == True)

# Generated at 2022-06-21 09:28:24.155589
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    group = Group('some_group', loader=loader)

    h1 = Host('some_host', groups=[group])
    h2 = Host('another_host', groups=[group])
    inventory = [h1, h2]

    hostvars = HostVars(inventory, VariableManager(loader=loader), loader)

    assert list(hostvars) == inventory

# Generated at 2022-06-21 09:28:32.131362
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # 1. Create instances of classes that are not pickleable.
    #    They can be passed to constructor of HostVars only as an argument.
    #    In this test we use empty instances.
    inventory = object()
    loader = object()
    variable_manager = object()

    # 2. Create instance of HostVars using the instances from previous step.
    #    We are going to pickle and unpickle this object.
    hostvars = HostVars(inventory, variable_manager, loader)

    # 3. Pickle and unpickle the object
    import pickle
    hostvars_pickled = pickle.dumps(hostvars)
    hostvars_restored = pickle.loads(hostvars_pickled)

    assert hostvars._loader is hostvars_restored._loader
    assert hostvars._

# Generated at 2022-06-21 09:28:42.154526
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    # Test when variables is an empty dict
    variables = {}
    loader = None
    hostvars_vars_object = HostVarsVars(variables, loader)
    assert len(hostvars_vars_object) == 0

    # Test when variables is not an empty dict
    templar = Templar(loader=loader, variables=variables)
    variables = {
        'hostvars': {
            'name1': templar.template({'first_key': 'first_value'}),
            'name2': templar.template({'second_key': 'second_value'})
        }
    }
    hostvars_vars_object = HostVarsVars(variables, loader)
    assert len(hostvars_vars_object) == 2

# Generated at 2022-06-21 09:28:47.481226
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    result = dict(HostVarsVars({'a': 1}, loader=None))
    assert result == {'a': 1}, result



# Generated at 2022-06-21 09:28:54.946792
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.constants import DEFAULT_HOST_LIST

    # Generate a temporary inventory file
    fake_inv = """
[ungrouped]
test_host_1 ansible_host=test_host_1 ansible_port=22
test_host_2 ansible_host=test_host_2 ansible_port=22
test_host_3 ansible_host=test_host_3 ansible_port=22
    """
    fd, inv_path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write(fake_inv)


# Generated at 2022-06-21 09:28:58.936243
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager

    host_vars = HostVars(variable_manager=VariableManager())
    result = repr(host_vars)
    assert result == '{}'



# Generated at 2022-06-21 09:29:10.302426
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    def templar_template(data, variables, fail_on_undefined=False, static_vars=STATIC_VARS):
        templar = Templar(variables=variables, loader=None)
        return templar.template(data, fail_on_undefined=fail_on_undefined, static_vars=static_vars)

    # Test type conversion (see https://github.com/ansible/ansible/issues/18063)
    def test_type_conversion(data, variables, expected):
        actual = templar_template(data, variables)
        assert actual == expected

    variables = dict(test_int=-1)
    test_type_conversion(dict(test=1.1), variables, '1.1')

# Generated at 2022-06-21 09:29:13.979845
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    HostVarsVars({"a": 1}, None)["a"] == 1
    HostVarsVars({}, None)["not_exists"] == AnsibleUndefined(name="hostvars['not_exists]")


# Generated at 2022-06-21 09:29:20.408176
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory, version_info=None)
    hostvars = HostVars(inventory, variable_manager, None)
    copy.deepcopy(hostvars)

# Generated at 2022-06-21 09:29:25.748461
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, sources="/dev/null")

    assert HostVars(inventory, "a", loader)._inventory == inventory
    assert HostVars(inventory, "b",  loader)._loader == loader



# Generated at 2022-06-21 09:29:36.889214
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    variable_manager = VariableManager()
    variable_manager._fact_cache['localhost'] = {
        'foo': 1,
        'bar': 2,
    }

    ctx = PlayContext()
    ctx.vars_cache = {
        'localhost': {
            "foo": 1
        },
        'testhost': {
            "bar": 2
        }
    }
    ctx.inventory = object()

    hostvars = HostVars(ctx.inventory, variable_manager, None)
    hostvars.set_variable_manager(variable_manager)

    assert(len(hostvars) == 2)

# Generated at 2022-06-21 09:29:38.430024
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    """
    Call method set_inventory of class HostVars with different
    parameters and check if it works correctly.
    """
    import ansible.inventory
    import ansible.vars
    import ansible.template
    impo

# Generated at 2022-06-21 09:29:47.774105
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    hosts = [Host(name='localhost'), Host(name='localhost')]
    group = Group(name='test_group')
    group.hosts = hosts
    inventory.groups = [group]
    variable_manager.set_inventory(inventory)

    host_vars = HostVars(inventory, variable_manager, loader)
    host_vars_vars = host_vars[hosts[0].name]


# Generated at 2022-06-21 09:29:59.277143
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import ansible.constants as C

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])

    inventory.add_host("host_a")
    inventory.add_host("host_b")

    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ my_fact }}')))
        ]

    )

# Generated at 2022-06-21 09:30:01.939574
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    hostvarsvars = HostVarsVars({'foo': 'bar'}, None)
    assert len(hostvarsvars) == 1
    assert hostvarsvars == {'foo': 'bar'}

    hostvarsvars = HostVarsVars({}, None)
    assert len(hostvarsvars) == 0
    assert hostvarsvars == {}

# Generated at 2022-06-21 09:30:09.432923
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    ''' test __iter__ method of class HostVars '''

    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    inventory = Inventory(loader=None)
    inventory.add_host(Host(name='foo'))
    variable_manager = VariableManager(loader=None)

    hostvars = HostVars(inventory, variable_manager, loader=None)
    hosts = sorted(h for h in hostvars)

    assert hosts == [ 'foo' ]

# Generated at 2022-06-21 09:30:22.279181
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    class FakeVariableManager(object):

        def __init__(self, host, varname, value):
            self._hostname = host
            self._varname = varname
            self._value = value
            self._hostvars = None

        def get_vars(self, host=None, include_hostvars=True):
            if include_hostvars:
                if self._hostvars is None:
                    raise Exception("HostVars is not set")
            return {self._varname: self._value}

        def set_host_variable(self, host, varname, value):
            if self._hostname != host or self._varname != varname:
                raise Exception("Wrong arguments passed to set_host_variable")
            self._value = value


# Generated at 2022-06-21 09:30:30.608692
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class InventoryDummy(object):
        def __init__(self, hostvars):
            self.hostvars = hostvars

        def get_host(self, host_name):
            return self.hostvars.get(host_name)

    class VariableManagerDummy(object):
        def get_vars(self, host=None, include_hostvars=True):
            assert host
            assert include_hostvars is False
            return host


# Generated at 2022-06-21 09:30:36.567468
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from .variable_manager import VariableManager
    vars = VariableManager()
    hostvars = HostVars(None, vars, None)

    vars._loader = None
    vars._hostvars = None
    hostvars._variable_manager = vars
    hostvars.setstate({'_variable_manager': vars, '_loader': 'loader'})
    assert vars._loader == 'loader'
    assert vars._hostvars == hostvars

# Generated at 2022-06-21 09:30:46.985406
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from copy import deepcopy
    loader = DataLoader()
    inventory = InventoryManager(loader, [], [])
    inventory.add_host('dummy')
    variable_manager = VariableManager()
    variable_manager.get_vars(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hv = hostvars.get('dummy')
    assert hv
    hv1 = deepcopy(hv)
    assert hv1

# Generated at 2022-06-21 09:30:53.795734
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible import inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = inventory.Inventory(loader=loader, variable_manager=VariableManager(loader=loader))

    group = inventory.Group('testgroup')
    group.add_host(inventory.Host(name='testhost'))
    inv.add_group(group)

    hosts = HostVars(inv, VariableManager(loader=loader), loader)
    assert len(hosts) == 1

    inv = inventory.Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hosts = HostVars(inv, VariableManager(loader=loader), loader)
    assert len(hosts) == 0

# Generated at 2022-06-21 09:31:00.614026
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    variables = {'key': 'value'}
    loader = None

    host_vars_vars = HostVarsVars(variables, loader)
    assert host_vars_vars['key'] == 'value'

    host_vars_vars = HostVarsVars({'key': '{{foo}}'}, loader)
    assert isinstance(host_vars_vars['key'], AnsibleUndefined)

# Generated at 2022-06-21 09:31:05.048862
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy

    loader = DictDataLoader({})
    variables = VariableManager(loader=loader)
    inventory = Inventory(loader=loader, variable_manager=variables, host_list=[])
    hostvars = HostVars(inventory, variables, loader)

    deepcopy(hostvars)

# Generated at 2022-06-21 09:31:17.215339
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=hosts)
    hostvars = HostVars(inventory=hosts, variable_manager=variable_manager, loader=loader)
    host = hosts.get_host('localhost')

    test_fact = 'test_fact'
    test_fact_value = 'test_fact_value'
    hostvars.set_nonpersistent_facts(host, {test_fact: test_fact_value})

    assert hostvars[host.name][test_fact] == test_fact_value

    # Now

# Generated at 2022-06-21 09:31:20.029690
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager
    hv = HostVars(None, None, None)
    varsm = VariableManager(None, None)
    hv.set_variable_manager(varsm)
    assert hv._variable_manager == varsm

# Generated at 2022-06-21 09:31:27.568655
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class AnsibleHost:
        def __init__(self, name):
            self.name = name
            self.vars = {}

        def get_name(self):
            return self.name

        def get_vars(self):
            return self.vars

        def set_variable(self, name, value):
            self.vars[name] = value

    class AnsibleInventory:
        def __init__(self):
            self.hosts = []
            self.groups = []
            self.patterns = []


# Generated at 2022-06-21 09:31:34.918306
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible import constants
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,',])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    templar = Templar(loader=loader, variables=variable_manager.get_vars())
    hostname = templar.template('{{ inventory_hostname }}')


# Generated at 2022-06-21 09:31:46.623983
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import json
    import sys
    import tempfile
    import yaml

    # Create temporary directory.
    temp_dir_path = tempfile.mkdtemp()

    # Create temporary file to save values of variables.
    # The file is in a YAML format.
    file_path = tempfile.mkstemp(dir=temp_dir_path, suffix='.yml')[1]

    # Create temporary loader.
    from ansible.parsing.dataloader import DataLoader
    temp_loader = DataLoader()

    # Create a temporary variables.
    temp_vars = {'test_var': 'test val'}

    # Create a temporary HostVarsVars.
    temp_hostvarsvars = HostVarsVars(variables=temp_vars, loader=temp_loader)

    # Create

# Generated at 2022-06-21 09:31:54.207694
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()

    hostvars = HostVars(None, variable_manager, None)
    assert not hostvars.raw_get('localhost')

    nonpersistent_facts = {'foo': 'bar'}
    hostvars.set_nonpersistent_facts('localhost', nonpersistent_facts)
    assert hostvars.raw_get('localhost') == nonpersistent_facts

# Generated at 2022-06-21 09:32:01.652344
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory_manager = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory_manager)
    hostvars = HostVars(inventory_manager, variable_manager, loader=None)
    assert hostvars.__deepcopy__({}) == hostvars
    assert deepcopy(hostvars) == hostvars



# Generated at 2022-06-21 09:32:13.072251
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible import constants as C
    C.HOST_KEY_CHECKING = False
    import ansible.inventory
    import ansible.playbook.play
    import ansible.vars.manager

    inventory = ansible.inventory.Inventory(['localhost'])
    play_ds = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = []
    )
    play = ansible.playbook.play.Play().load(play_ds, variable_manager=ansible.vars.manager.VariableManager(), loader=ansible.loader.DataLoader())
    # test HostVars with default VariableManager
    hostvars = HostVars(inventory=inventory, variable_manager=play.variable_manager, loader=play._loader)

# Generated at 2022-06-21 09:32:14.415333
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    vars = HostVarsVars({'a':1}, None)

# Generated at 2022-06-21 09:32:21.553558
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    class MockLoader(object):
        pass

    class MockInventory(object):
        def __init__(self):
            self.hosts = ['host1', 'host2']

        def get_host(self, h):
            if h in self.hosts:
                return h

    class MockVariableManager(object):
        def __init__(self):
            self._vars_cache = {'host1': 'foo', 'host2': 'bar'}

        def get_vars(self, host=None, include_hostvars=True):
            return self._vars_cache.get(host, {})

    inventory = MockInventory()
    inventory.hosts = ['host1', 'host2']
    loader = MockLoader()
    variable_manager = MockVariableManager()

# Generated at 2022-06-21 09:32:28.431292
# Unit test for constructor of class HostVars
def test_HostVars():
    hv = HostVars({}, None, None)
    assert isinstance(hv, Mapping)

# Generated at 2022-06-21 09:32:39.583825
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    """
    HostVars class defines method set_inventory that
    updates self._inventory with new inventory object.
    """
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    test_loader = DataLoader()
    test_inventory = InventoryManager(loader=test_loader, sources='localhost,')
    test_variable_manager = VariableManager(loader=test_loader, inventory=test_inventory)

    # Construct a HostVars object with inventory, variable_manager and loader
    hostvars = HostVars(inventory=test_inventory, variable_manager=test_variable_manager, loader=test_loader)

    # Create a new InventoryManager object

# Generated at 2022-06-21 09:32:43.152341
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping

    inventory = InventoryManager("localhost,", loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader())

    class MockVariableManager(MutableMapping):
        def __init__(self):
            # A dict mock with pre-defined data.
            self._data = dict(top_level="bar", sub_level=dict(foo="bar"))

        def __getitem__(self, item):
            return self._data[item]

        def __setitem__(self, key, value):
            self._data[key] = value


# Generated at 2022-06-21 09:32:45.767625
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    # Does not implement an actual test, just returns an informative message
    # when the method is called.
    return "HostVarsVars: method __contains__ is not tested"

# Generated at 2022-06-21 09:32:52.776971
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    INVENTORY = """
    [webservers]
    host1 ansible_var=1
    host2 ansible_var=2
    """

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=INVENTORY)
    vm = VariableManager(loader=loader, inventory=inv)
    hv = HostVars(inventory=inv, variable_manager=vm, loader=loader)

    assert vm.get_vars(host=inv.get_host('host1')) == {'ansible_var': 1}

# Generated at 2022-06-21 09:33:00.157268
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    assert 'foo' in HostVarsVars({'foo': 'bar'}, None)
    assert 'foo' not in HostVarsVars({}, None)

    var = HostVarsVars({'foo': '{{ var }}'}, None)
    assert 'foo' not in var
    var._vars['var'] = 'bar'
    assert 'foo' in var

    var._vars['var'] = ['foo', 'bar']
    assert 'foo' not in var

# Generated at 2022-06-21 09:33:12.925515
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager
    hosts = []
    inventory = FakeInventory(hosts)
    loader = FakeLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostname = "test-set-variable-manager"
    dict_name = "VariableManager"
    var_name = "loader"
    var_value = "fake"
    hosts.append(hostname)
    host = inventory.get_host(hostname)
    setattr(variable_manager, dict_name, {host: {var_name: var_value}})
    assert getattr(getattr(hostvars, dict_name)[host], var_name) == var_value

    # Test case when set_variable_manager is called
    new

# Generated at 2022-06-21 09:33:24.059539
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars._loader == loader
    assert hostvars._inventory == inventory
    assert hostvars._variable_manager == variable_manager

    assert variable_manager._loader == loader
    assert variable_manager._hostvars == hostvars

    # _loader and _hostvars attributes are not persisted by VariableManager
    state = hostvars.__getstate__()
    hostvars.__setstate__(state)

# Generated at 2022-06-21 09:33:35.088728
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.host import Host

    host_name = 'test_host'
    host_vars = {'var_name': 'var_value'}
    expected_host_vars = {'var_name': 'var_value', 'inventory_hostname': 'test_host'}

    class FakeInventory(object):
        def __init__(self, host_name, host_vars):
            self.host_name = host_name
            self.host_vars = host_vars

        def get_host(self, host_name):
            if host_name == self.host_name:
                return Host(host_name)
            else:
                return None

    class FakeVariableManager(object):
        def __init__(self, host_name, host_vars):
            self.host_

# Generated at 2022-06-21 09:33:46.471253
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import ansible.template.template
    import ansible.templar
    import ansible.vars.variable_manager
    import ansible.vars.unsafe_proxy

    # We need to use actual instances, not mocks
    loader = ansible.template.template.AnsibleBaseTemplar(loader=None)
    templar = ansible.templar.Templar(loader=loader)
    variable_manager = ansible.vars.variable_manager.VariableManager()

    # This raises exception if developer broke this constructor
    HostVarsVars(dict(), loader)

    # This raises TypeError if developer broke this constructor
    HostVarsVars(ansible.vars.unsafe_proxy.UnsafeProxy(dict()), loader)

    # This raises exception if developer broke this constructor
    HostVarsVars

# Generated at 2022-06-21 09:34:06.126258
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(loader=DataLoader())
    host = inventory.get_host("foobar")
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    assert hostvars.raw_get("foobar") == {}
    hostvars.set_host_variable(host, 'var_foo', "foo")
    assert hostvars.raw_get("foobar") == dict(var_foo="foo")
    hostvars.set_host_variable(host, 'var_bar', "bar")

# Generated at 2022-06-21 09:34:17.489867
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    host1 = inventory.add_host("server.example.com")
    host1.vars = {'foo': 'bar'}
    host2 = inventory.add_host("localhost")
    host2.vars = {'foo': 'bar'}

    play = Play()
    play.hosts = "all"

    hostvars = HostVars(inventory=inventory, variable_manager=play.get_variable_manager(), loader=DataLoader())

    assert "localhost" in hostvars
    assert "server.example.com" in host

# Generated at 2022-06-21 09:34:23.260904
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    # Test with vars empty
    hostvars_vars = HostVarsVars({}, None)
    assert len(hostvars_vars) == 0

    # Test with vars having two elements
    hostvars_vars = HostVarsVars({'test': 'bar', 'test2': 'bar2'}, None)
    assert len(hostvars_vars) == 2

# Generated at 2022-06-21 09:34:31.486992
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader_mock = object()
    vars = {'a': 'b', 'c': 'd'}
    hostvar_vars = HostVarsVars(vars, loader_mock)
    assert repr(hostvar_vars) == repr(vars)
    vars = {'a': '{{ b }}', 'b': '{{ c }}', 'c': 'd'}
    hostvar_vars = HostVarsVars(vars, loader_mock)
    assert repr(hostvar_vars) == repr(vars)

# Generated at 2022-06-21 09:34:33.127290
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    h = HostVarsVars({'a': 1, 'b': 2}, None)
    assert len(h) == 2

# Generated at 2022-06-21 09:34:37.552032
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    variables = {'var': 'value'}
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)

    assert 'var' in hostvarsvars
    assert not 'var_x' in hostvarsvars


# Generated at 2022-06-21 09:34:39.585516
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # TODO: write this test
    return True

# Generated at 2022-06-21 09:34:45.630656
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():

    test_data = {
        'aaa': 'bbb',
        'aaa2': 'bbb2',
        'aaa4': 'bbb4',
        'aaa3': 'bbb3'
    }
    sut = HostVarsVars(test_data, None)

    assert len(test_data) == len(sut)

# Generated at 2022-06-21 09:34:53.633190
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    v = HostVarsVars({'x': 'y'}, loader)
    assert 'x' in v
    assert v['x'] == 'y'

# Generated at 2022-06-21 09:35:03.793332
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import yaml

    loader = DataLoader()
    inventory_path_one = os.path.join(os.path.dirname(__file__),"../files/hosts_inventory_set_inventory")
    inventory_one = InventoryManager(loader=loader, sources=inventory_path_one)
    inventory_path_two = os.path.join(os.path.dirname(__file__),"../files/hosts_inventory_test_set_inventory")
    inventory_two = InventoryManager(loader=loader, sources=inventory_path_two)
    variable_manager = VariableManager(loader=loader, inventory=inventory_one)

    # Replace "

# Generated at 2022-06-21 09:35:35.644573
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    '''Testing HostVarsVars' method __getitem__'''

    variables = dict(
        name1='value1',
        name2='value2',
        name3='value3',
    )
    hostvarsvars = HostVarsVars(variables, None)
    assert len(hostvarsvars) == 3
    assert hostvarsvars['name1'] == 'value1'
    assert hostvarsvars['name2'] == 'value2'
    assert hostvarsvars['name3'] == 'value3'
    try:
        hostvarsvars['unknown']
    except KeyError as err:
        assert str(err) == "'unknown'"
    else:
        assert False, 'KeyError not raised'

    # Test __getitem__ with different set of test values

# Generated at 2022-06-21 09:35:45.076623
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({})
    inventory = '''
    all:
        hosts:
            localhost:
    '''
    inventory = inventory.strip()
    loader.set_basedir('/tmp')
    inventory = loader.load(inventory, 'hosts')
    vars = {'myvar': 'myval'}
    vm = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, vm, loader)
    # set facts for localhost
    hostvars.set_nonpersistent_facts(inventory.get_host('localhost'), vars)
    # check if hostvars contains myvar
    assert 'myvar' in hostvars['localhost']
    # check if hostvars['localhost']['myvar

# Generated at 2022-06-21 09:35:49.353892
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # the method __iter__ should return an iterator
    # containing all the keys of the variable's dict
    test_dict = {"key1": "value1", "key2": "value2"}
    test_object = HostVarsVars(test_dict, None)
    assert sorted(list(test_object)) == sorted(test_dict.keys())



# Generated at 2022-06-21 09:35:57.072653
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    import sys
    import os
    import json
    import copy

    inventory_file_path = os.path.dirname(__file__) + "/../../../plugins/inventory/tests/test_inventories/exec_echo_inventory.py"
    assert (os.path.isfile(inventory_file_path))

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=inventory_file_path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-21 09:36:06.814842
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VarsModule
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret

    loader = DataLoader()
    vault_secrets = [('secret', VaultSecret('password'))]
    vault = VaultLib(vault_secrets)
    variable_manager = VariableManager(loader=loader, vault_secrets=vault_secrets)
    hostvars = HostVars(inventory=Inventory(loader=loader, vault_secrets=vault_secrets),
                        variable_manager=variable_manager,
                        loader=loader)

   

# Generated at 2022-06-21 09:36:12.820566
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import ansible.utils.vars as vars
    import ansible.inventory.host as host
    import ansible.inventory.group as group
    import ansible.inventory.manager as manager

    inventory = manager.InventoryManager(loader=None, sources=None)
    host1 = host.Host('host1')
    host2 = host.Host('host2')
    group1 = group.Group('group1')
    group1.add_host(host1)
    group1.add_host(host2)

    variable_manager = vars.VariableManager(loader=None, inventory=inventory)
    variable_manager._fact_cache = dict((h.name, {}) for h in inventory.hosts)

    assert variable_manager.get_vars(host=host1) == {}
    assert variable_manager.get_vars

# Generated at 2022-06-21 09:36:22.350611
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from copy import deepcopy

    hosts = ['localhost', 'example.com']
    hostvars = HostVars({}, {}, {})
    for hostname in hosts:
        host = Host(name=hostname)
        host.vars = {'foo': 42, 'bar': {'baz': 2}}
        hostvars[hostname] = host.get_vars()

    # We verify variables' dicts of the original hostvars and of a deepcopied
    # instance of hostvars are identical. We cannot use assertEqual, because
    # HostVars are not comparable.
    variables = dict(hostvars)
    hostvars_deepcopied = deepcopy(hostvars)
    variables

# Generated at 2022-06-21 09:36:30.030568
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    new_variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars.set_variable_manager(new_variable_manager)

    assert hostvars._variable_manager == new_variable_manager
    assert new_variable_manager._hostvars == hostvars

# Generated at 2022-06-21 09:36:40.701835
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager

    display = Display()
    add_all_plugin_dirs()
    display.verbosity = 2

    inventory_obj = Inventory("tests/inventory_file", loader=None, variable_manager=None)
    variable_manager_obj = VariableManager(loader=None, inventory=inventory_obj)

    host_vars_obj = HostVars(inventory=inventory_obj, variable_manager=variable_manager_obj, loader=None)

    assert isinstance(host_vars_obj, HostVars)

    assert list(host_vars_obj) == list(inventory_obj.hosts)

# Generated at 2022-06-21 09:36:42.996829
# Unit test for method __contains__ of class HostVarsVars
def test_HostVarsVars___contains__():
    assert "ansible_somthing_else" not in HostVarsVars({"ansible_somthing": "foo"}, lambda: None)