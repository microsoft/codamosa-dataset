

# Generated at 2022-06-21 09:27:25.183333
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='/dev/null')
    variable_manager = VariableManager()
    variables = {'test_var': 'ansible'}

    host_vars = HostVars(inventory, variable_manager, loader)
    host_vars.raw_get('localhost')
    localhost = HostVarsVars(variables, loader)

    assert variables == localhost

# Generated at 2022-06-21 09:27:30.693930
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    class Inventory(object):
        class Host(object):
            name = 'test_host'

            def get_vars(self):
                return {}

        def __init__(self):
            self.hosts = [self.Host()]

    hv = HostVars(Inventory(), None, None)
    assert len(hv) == 1

# Generated at 2022-06-21 09:27:32.633383
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    assert hasattr(HostVars, '__iter__')
    assert callable(HostVars.__iter__)

# Generated at 2022-06-21 09:27:40.473409
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader


    variable_manager = VariableManager()
    loader = DataLoader()

    group = Group('all')
    host = Host('localhost')
    group.add_host(host)

    hostvars = HostVars(group, variable_manager, loader)

    group.add_child_group(group)
    hostvars.set_host_variable(host, 'ansible_connection', 'local')

    assert hostvars.get('localhost')['ansible_connection'] == 'local'

# Generated at 2022-06-21 09:27:52.731581
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.variable_manager import VariableManager
    import ansible.inventory
    import ansible.playbook
    from ansible.playbook.play_context import PlayContext

    test_hosts = [
        'a',
        'b',
        'c',
    ]

    class TestInventory(ansible.inventory.Inventory):
        def __init__(self, loader, variable_manager, host_list=None):
            self._loader = loader
            hosts = {}
            groups = {}

            # create localhost
            localhost = ansible.inventory.Host(name='localhost', port=None)
            hosts["localhost"] = localhost
            groups['localhost'] = ansible.inventory.Group(name='localhost')
            groups['localhost'].add_host(localhost)


# Generated at 2022-06-21 09:28:02.487463
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleParserError
    from ansible.inventory.host import Host
    loader = DictDataLoader()
    inventory = InventoryManager(loader=loader)
    host = Host("example.com")
    inventory._hosts["example.com"] = host
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars
    state = hostvars.__getstate__()
    hostvars.__setstate__(state)
    assert hostvars._variable_manager._loader is loader
    assert host

# Generated at 2022-06-21 09:28:10.490849
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    # HostVarsVars is immutable, so we can skip deepcopying
    def not_called(*args, **kwargs):
        assert False, "Should not be called"

    import copy
    copy.deepcopy = not_called

    ansible_facts = dict(foo=['bar'])
    vars = dict(ansible_facts=ansible_facts)
    hostvars = HostVarsVars(vars, None)
    assert str(hostvars) == '''{'ansible_facts': {'foo': ['bar']}}'''

# Generated at 2022-06-21 09:28:22.160030
# Unit test for constructor of class HostVars
def test_HostVars():
    import ansible
    import sys
    import os

    class TestInventory(object):
        def __init__(self, test_host_vars):
            self.test_host_vars = test_host_vars

        def get_host(self, host_name):
            if host_name in self.test_host_vars:
                return host_name
            else:
                return None

        def hosts(self):
            return self.test_host_vars.keys()

    class TestVariableManager(object):
        def __init__(self, variables):
            self.variables = variables

        def get_vars(self, host=None, include_hostvars=True):
            if host is None:
                return self.variables
            elif host in self.variables:
                return self.vari

# Generated at 2022-06-21 09:28:25.249798
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = dict(foo='bar', test='{{ foo }}')
    loader = None
    obj = HostVarsVars(variables, loader)
    assert obj['test'] == 'bar'


# Generated at 2022-06-21 09:28:32.779908
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    inventory = Inventory(host_list=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    hostvars._inventory.add_host('localhost')

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    hostvars.set_host_variable('localhost', 'dict', dict(a=1, b=2))
    hostvars.set_host_variable('localhost', 'list', ['a', 'b', 'c'])

    hvv = hostvars.get('localhost')
    assert isinstance(hvv, HostVarsVars)

# Generated at 2022-06-21 09:28:44.308285
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    import copy
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()

    play = Play()
    play.hosts = '/dummy/inventory'

    inventory = InventoryManager(loader=loader, sources=[play.hosts])
    inventory.add_group('dummy_group')
    inventory_sources = inventory._inventory.sources(inventory)

# Generated at 2022-06-21 09:28:53.323466
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import pytest
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host

    # Create inventory with single two hosts
    host1 = Host(name='host1')
    host2 = Host(name='host2')
    inventory = InventoryManager(loader=DataLoader(), sources='')
    inventory.add_group('group1')
    inventory.add_host(host=host1, group='group1')
    inventory.add_host(host=host2, group='group1')

    # Create variable manager and

# Generated at 2022-06-21 09:29:06.196336
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import os
    import inspect
    import ansible.parsing.dataloader as dataloader
    import ansible.vars.hostvars as hostvars
    import ansible.vars.manager as varmanager

    loader = dataloader.DataLoader()
    variable_manager = varmanager.VariableManager()

    # __setstate__ has three parameters: self, state and
    # state_keys = ('_inventory', '_loader', '_variable_manager').
    # The '_loader' and '_variable_manager' are not preserved in
    # method __getstate__ of class VariableManager, and therefore
    # they must be defined before unpickling and passed to
    # __setstate__ as part of state.
    loader_name = '_loader'

# Generated at 2022-06-21 09:29:14.272174
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    # Test that set_host_variable() can actually set data in a hostvar
    # and that it is saved in _hostvars_cache.
    inventory = Inventory(loader=loader,
                          host_list=[
                              'test-inventory-set-host-variable-1',
                              'test-inventory-set-host-variable-2'
                          ])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    if not isinstance(hostvars, Mapping):
        raise AssertionError("hostvars instance is not a Mapping")



# Generated at 2022-06-21 09:29:24.488498
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    import os
    import unittest
    import json
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestHostVarsMethods(unittest.TestCase):
        loader = DataLoader()
        hostvars = HostVars(InventoryManager(loader=loader, sources=[]), VariableManager(), loader)
        variable_manager = VariableManager()
        hostvars.set_variable_manager(variable_manager)

        def test_set_variable_manager(self):
            self.assertEqual(self.hostvars._variable_manager, self.variable_manager)
           

# Generated at 2022-06-21 09:29:26.973079
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    assert callable(HostVarsVars.__iter__)



# Generated at 2022-06-21 09:29:35.813467
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():

    class VariableManager():
        def __init__(self):
            self._loader = self
            self._hostvars = self

    my_variable_manager = VariableManager()

    inventory = {}
    hostvars = HostVars(inventory, my_variable_manager, my_variable_manager)

    new_variable_manager = VariableManager()
    hostvars.set_variable_manager(new_variable_manager)

    assert my_variable_manager._loader is None
    assert my_variable_manager._hostvars is None

    assert new_variable_manager._loader is hostvars
    assert new_variable_manager._hostvars is hostvars

# Generated at 2022-06-21 09:29:45.418386
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.host import Host

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._loader = loader

    def add_host(hostname):
        # Create host on demand
        if hostname not in variable_manager._hostvars:
            variable_manager._hostvars[hostname] = Host(name=hostname)

    class Inventory(InventoryManager):
        def __init__(self):
            pass

# Generated at 2022-06-21 09:29:52.866146
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    inventory = Inventory(host_list=['localhost'])
    inventory.reconcile_inventory()
    play_source = dict(
        name = "Ad-hoc",
        hosts = "localhost",
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='ping', args=''))
        ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=False)
    tqm = None

# Generated at 2022-06-21 09:30:00.617265
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    import pytest
    from ansible.plugins.inventory import InMemoryInventory
    from ansible.vars import VariableManager
    from ansible import context

    inv = InMemoryInventory()
    inv.add_host("foobar")
    inv.add_group("all")
    inv.add_child("all", "foobar")

    v = VariableManager()
    v.add_host_variable("foobar", "foo", "bar")

    h = HostVars(inv, v, context.CLIARGS['variable_manager']._loader)

    assert 'foobar' in h

    assert 'asdf' not in h

    assert 'foobar' in h.raw_get('foobar')
    assert 'asdf' not in h.raw_get('foobar')

# Generated at 2022-06-21 09:30:09.247182
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class TestUndefined(object):
        def __repr__(self):
            return 'TEST'
    test_object = {'my_var': TestUndefined()}
    host_vars = HostVarsVars(test_object, None)
    assert repr(host_vars) == repr(test_object)


# Generated at 2022-06-21 09:30:22.065099
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    # Create the inventory, loader and variable_manager objects
    inventory = InventoryManager("")
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    # Create the inventory
    host_1 = Host("my_host_1")
    host_2 = Host("my_host_2")

    inventory._hosts = []
    inventory.add_host(host_1)
    inventory.add_host(host_2)

    # Create the hostvars object
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test special variables


# Generated at 2022-06-21 09:30:29.933512
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])

    hostvars = HostVars(inventory, variable_manager, loader)

    variable_manager.set_host_variable(inventory.hosts['localhost'], 'foo', 'bar')
    variable_manager.set_nonpersistent_facts(inventory.hosts['localhost'], {'bar': 'foo'})

    assert hostvars['localhost']['foo'] == 'bar'
    assert hostvars['localhost']['bar'] == 'foo'

# Generated at 2022-06-21 09:30:33.726449
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import json
    hostvars = HostVars(None, None, None)
    hostvars._inventory = DictInventory({'local': DictHost({"foo": "bar"})})
    result = json.loads(repr(hostvars))
    assert result == {"local": {"foo": "bar"}}



# Generated at 2022-06-21 09:30:46.274815
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    import os
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Setup the inventory
    loader = None
    inv_path = os.path.join(os.path.dirname(__file__), 'hostvars_sample_inventory')
    inventory = InventoryManager(loader=loader, sources=[inv_path])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create an instance of HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Use method __len__
    hosts_number = len(hostvars)

    # Check result
    expected_value = 4
    assert hosts_number == expected_value
    print("length of hostvars == %s" % hosts_number)



# Generated at 2022-06-21 09:30:53.677879
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle
    from ansible.inventory import Inventory
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import uuid
    selfName = 'HostVarsTest__setstate__'
    tempName = str(uuid.uuid4())
    instance = HostVars(inventory=Inventory(loader=None, variable_manager=None), variable_manager=VariableManager())
    setattr(instance, selfName, tempName)
    pickleString = pickle.dumps(instance)
    instance = pickle.loads(pickleString)
    assert hasattr(instance, selfName)
    assert getattr(instance, selfName) == tempName

# Generated at 2022-06-21 09:31:05.123021
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create a fake inventory
    inventory = InventoryManager('')

# Generated at 2022-06-21 09:31:12.116951
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = MockLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host_vars = HostVars(inventory, variable_manager, loader)
    assert host_vars._variable_manager._loader is loader
    assert host_vars._variable_manager._hostvars is host_vars

    # test an existing variable manager
    variable_manager2 = VariableManager(loader=loader, inventory=inventory)
    host_vars.set_variable_manager(variable_manager2)
    assert host_vars._variable_manager._loader is loader
    assert host_vars._variable_manager._hostvars is host_vars

    # test

# Generated at 2022-06-21 09:31:16.295749
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    class MyHostVarsVars(HostVarsVars):
        def __init__(self):
            self._vars = [1, 2, 3]
            self._loader = None

    hostvarsvars = MyHostVarsVars()
    assert len(hostvarsvars) == 3

# Generated at 2022-06-21 09:31:20.134068
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Setup
    inventory = MagicMock()
    variable_manager = MagicMock()
    loader = MagicMock()
    hostvars = HostVars(inventory, variable_manager, loader)
    inventory.hosts = [ MagicMock() for i in range(0, 7) ]

    # Verify
    assert len(hostvars) == 7


# Generated at 2022-06-21 09:31:43.189740
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    host = inventory.hosts['localhost']
    hostvars.set_nonpersistent_facts(host, dict(foo='bar'))
    assert variable_manager.get_vars(host) == {'foo': 'bar'}
    variable_manager.clear_facts(host)
    # Ensure iterator returns the same result as a dict

# Generated at 2022-06-21 09:31:51.066047
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    localhost = Host('localhost')
    localhost.vars['foo'] = "bar"
    group = Group('all')
    group.add_host(localhost)
    inventory.add_group(group)
    variable_manager.set_inventory(inventory)

    host_vars = HostVars(inventory, variable_manager, loader)
    assert set(host_vars) == set(['localhost'])
    assert host

# Generated at 2022-06-21 09:32:02.674675
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    hostvars = HostVars(inventory, VariableManager(loader=loader, inventory=inventory), loader=loader)

    host = Host('testhost')

    hostvars.set_host_variable(host, 'foo', 'bar')
    hostvars.set_host_variable(host, 'baz', 'qux')

    assert hostvars.raw_get(host.name)['foo'] == 'bar'
    assert hostvars.raw_get(host.name)['baz'] == 'qux'

    hostv

# Generated at 2022-06-21 09:32:14.773689
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    groups = InventoryManager(loader=loader, sources=['localhost,']).groups
    localhost = groups['localhost'].get_host('localhost')

    variable_manager = VariableManager(loader=loader, inventory=groups)
    hostvars = HostVars(groups, variable_manager, loader)

    hostvars.set_nonpersistent_facts(localhost, {'answer': 42})
    assert hostvars.raw_get('localhost') == {'answer': 42}

    variable_manager.set_nonpersistent_facts(localhost, {'answer': 84})
    assert variable_manager.get_

# Generated at 2022-06-21 09:32:26.306927
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.inventory.host import Host
    from ansible.vars.reserved import Reserved
    from ansible.vars.hostvars import HostVars
    from ansible.vars.vars_cache import VarsCache
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    cache = VarsCache()

    variable_manager = VariableManager()
    variable_manager._cache = cache
    variable_manager._loader = loader

    hostvars = HostVars(None, variable_manager, loader)
    host = Host('foohost')
    hostvars.set_host_variable(host, 'foo', 'bar')

    # Make sure that when we try to expand a variable that is not present in the hostvars,

# Generated at 2022-06-21 09:32:37.910855
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class Dummy(object):
        def __init__(self, vars):
            self.vars = vars

    class Dummy2(object):
        def __init__(self, vars):
            self.vars = vars

    v1 = Dummy({'var1': '${var2}', 'var2': 'val'})
    v2 = Dummy2({'var1': '${var2}', 'var2': 'val'})

    hv = HostVarsVars(v1.vars, v2)
    assert repr(hv) == "{'var1': 'val', 'var2': 'val'}"

    v1.vars['var2'] = '${var3}'
    hv = HostVarsVars(v1.vars, v2)

# Generated at 2022-06-21 09:32:48.394879
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os
    import sys
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    class TestHostVarsRawGet(unittest.TestCase):
        def setUp(self):
            fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures')
            # we need the correct cwd to find the inventory file
            cwd = os.path.join(fixtures_path, 'test_hostvars')
            os.chdir(cwd)
            self.loader = DataLoader()
            self.variable_manager = VariableManager()

# Generated at 2022-06-21 09:33:00.800531
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    source = '''
        [group1]
        host1
        host2

        [group2]
        host3
    '''

    inventory = InventoryManager(loader=None, sources=source)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    assert hostvars.__contains__('host1') is True
    assert hostvars.__contains__('host4') is False

    # test that __contains__ creates localhost on demand
    assert hostvars.__contains__('localhost') is True
    assert inventory.get_host('localhost') is not None

# Generated at 2022-06-21 09:33:11.896265
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data = dict(
        plugin='yaml',
        host_list='hosts',
        vault_password='vault_pass',
    )
    loader = DataLoader()
    inventory = InventoryManager(loader, data)
    var_manager = VariableManager(loader, inventory)
    hostvars = HostVars(inventory, var_manager, loader)

    # __len__ should return the number of hosts in the inventory
    assert len(hostvars) == len(inventory.hosts)


# Generated at 2022-06-21 09:33:23.340750
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inv = Inventory(loader=None, variable_manager=VariableManager(), host_list=[])
    var_mgr = VariableManager()
    hostvars = HostVars(inventory=inv, variable_manager=var_mgr, loader=None)

    # Host from inventory not using templating
    h1 = inv.get_host('h1')
    var_mgr.set_host_variable(h1, 'var1', '{{ foo }}')
    var_mgr.set_host_variable(h1, 'foo', 'bar')
    assert hostvars.raw_get('h1')['var1'] == '{{ foo }}'
    assert hostvars.raw_get('h1')['foo'] == 'bar'

    # host

# Generated at 2022-06-21 09:33:59.742820
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='localhost,')

    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(hostvars)==2
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'foo', 'bah')
    assert len(hostvars)==2
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'bar', 'baz')
    assert len(hostvars)==2

# Generated at 2022-06-21 09:34:06.740934
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    class InventoryStub():
        def __init__(self):
            self.hosts = HostsStub()

        def get_host(self, host_name):
            return self.hosts.get(host_name)

    class HostsStub():
        def __init__(self):
            self.hosts = {}

        def get(self, host_name, fail_if_not_found=True):
            if host_name in self.hosts:
                return host_name
            else:
                return None

    class VariableManagerStub():
        def __init__(self, inventory):
            self._inventory = inventory
            self._hostvars = None

        def set_inventory(self, inventory):
            self._inventory = inventory


# Generated at 2022-06-21 09:34:17.999209
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    host_list = ['test']
    inventory = Inventory(loader=loader, host_list=host_list)

    variables = {'ansible_ssh_user': 'test_ssh_user',
                 'ansible_ssh_pass': 'test_ssh_pass',
                 'inventory_hostname': 'test'}
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = variables
    hostvars = HostVars(inventory=inventory,
                        loader=loader,
                        variable_manager=variable_manager)


# Generated at 2022-06-21 09:34:29.678231
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Test HostVars defined in ansible.vars.hostvars.HostVars class
    class TestHostVars(HostVars):

        def __init__(self):
            pass

        def raw_get(self, host_name):
            return dict()

    host_vars = TestHostVars()
    host_vars['localhost']

    # Test class HostVarsVars defined in the same class
    class TestVariableManager(object):

        def __init__(self):
            # Variables for host localhost
            self._vars_per_host = dict(
                localhost=dict(
                    var1='Value 1',
                    var2='Value 2'
                )
            )


# Generated at 2022-06-21 09:34:37.627109
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = variable_manager.get_inventory(loader=loader)

    variables = variable_manager.get_vars(host=Host(name="hostname", port=22), include_hostvars=False)

    hv = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    host_name = 'hostname'
    data = hv.raw_get(host_name)
    assert variables == data

    # Unit test for __getitem__ method of class HostVars
    host_name = 'hostname'
    data = hv[host_name]
    assert variables

# Generated at 2022-06-21 09:34:51.197796
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import pickle
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create host variable
    variable_manager.set_host_variable(inventory.localhost, 'foo', 'bar')

    # Create hostvars
    hostvars = HostVars(inventory, variable_manager, None)

    # Make sure a variable was created
    assert 'localhost' in hostvars

    # Create a copy of hostvars
    copy = pickle.loads(pickle.dumps(hostvars))

    # Make sure hostvars is the same
    assert hostvars == copy
    # Make sure hostvars is not referenced
    assert hostvars is not copy

# Generated at 2022-06-21 09:35:01.895347
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    import sys
    import os
    import tempfile

    # We need to create a fake ansible.parsing.dataloader.DataLoader
    # because its instance is created at ansible.inventory.manager.InventoryManager
    # constructor.
    #
    # The actual code is not executed because __getitem__ uses only
    # attributes: _loader.get_basedir(), _loader._inventory, _loader._vault_password
    #
    # ansible.parsing.dataloader.DataLoader.get_basedir() returns a directory of
    # the inventory file. We use a temporary directory for the purpose.
    #
    # ansible.parsing.dataloader.DataLoader._inventory is an instance of
    # ansible.parsing.dataloader.inventory.InventoryLoader, which is not

# Generated at 2022-06-21 09:35:08.186777
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    inventory = variable_manager.inventory
    variable_manager.set_inventory(inventory)
    inventory.add_group(Group('g1'))
    inventory.add_group(Group('g2'))
    inventory.get_groups_dict()['g1'].add_host(Host('a1'))
    inventory.get_groups_dict()['g1'].add_host(Host('a2'))
    inventory.get_groups_dict()['g1'].add_host(Host('a3'))
    inventory.get_groups_dict()['g2'].add

# Generated at 2022-06-21 09:35:18.035404
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    data = [{'hostvars': {'testhost': {'foo': 'bar'}}}]

    group = InventoryManager(loader=DataLoader(), sources=data)
    variable_manager = VariableManager(loader=DataLoader(), inventory=group)

    hostvars = HostVars(inventory=group, variable_manager=variable_manager, loader=variable_manager._loader)

    assert len(hostvars['testhost']) == 1

# Generated at 2022-06-21 09:35:22.091904
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = DictDataLoader({'foo': 'bar'})
    variables = dict(a='aaa', b='bbb', c='{{ foo }}', d='ddd')
    hostvars_vars = HostVarsVars(variables, loader=loader)
    assert sorted(list(hostvars_vars)) == sorted(variables.keys())



# Generated at 2022-06-21 09:36:54.820790
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    inventory_manager = InventoryManager(loader=DataLoader(), sources=["localhost ansible_connection=local"])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)
    variable_manager.extra_vars = dict(my_var = 'foo')
    hostvars = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=DataLoader())
    assert hostvars['localhost'] == dict(my_var='foo')

    assert 'ansible_connection' in hostvars['localhost']
    assert 'my_var' in hostvars['localhost']

# Generated at 2022-06-21 09:37:06.166676
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.vars.hostvars import HostVars

    def copy_mock_inventory(inventory, memo):
        """
        Mock copy.deepcopy() function for the inventory.
        """
        if inventory not in memo:
            memo[inventory] = inventory

        return memo[inventory]

    def copy_mock_variable_manager(variable_manager, memo):
        """
        Mock copy.deepcopy() function for the variable_manager.
        """
        if variable_manager not in memo:
            memo[variable_manager] = variable_manager

        return memo[variable_manager]

    # Instantiate a HostVars object
    inventory = object()
    variable_manager = object()
    loader = object()
    host_vars = HostVars(inventory, variable_manager, loader)

   

# Generated at 2022-06-21 09:37:17.497183
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(
        loader=None,
        sources=("localhost,"),
    )

    variable_manager = VariableManager(
        loader=None,
        inventory=inventory,
    )

    play_context = PlayContext()
    play_context._hostvars = HostVars(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=None,
    )
