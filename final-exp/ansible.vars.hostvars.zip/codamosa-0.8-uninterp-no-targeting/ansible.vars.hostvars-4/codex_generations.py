

# Generated at 2022-06-21 09:27:32.576959
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from copy import deepcopy
    inv = Inventory(host_list=[])
    vm = VariableManager(loader=None, inventory=inv)
    hv = HostVars(inventory=inv, variable_manager=vm, loader=None)

    assert isinstance(hv, HostVars)
    assert hv is deepcopy(hv)

# Generated at 2022-06-21 09:27:41.480482
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    loader = {}
    variables = {}
    hv = HostVarsVars(variables, loader)
    assert hv.__repr__() == '{}'

    variables = {
        'var1': 'value1',
        'var2': 'value2',
    }
    hv = HostVarsVars(variables, loader)
    assert hv.__repr__() == "{'var1': 'value1', 'var2': 'value2'}"

    variables = {
        'var1': '{{ var3 }}',
        'var2': '{{ var4 }}',
        'var3': 'value3',
        'var4': 'value4',
    }
    hv = HostVarsVars(variables, loader)

# Generated at 2022-06-21 09:27:46.520657
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Create HostVarsVars instance
    host_vars_vars = HostVarsVars({'foo': 'bar'}, loader=loader)

    items = 0
    for var in host_vars_vars:
        items += 1

    assert items == 1

# Generated at 2022-06-21 09:27:55.047214
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    variable_manager._hostvars = None
    loader = DataLoader()
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)
    new_variable_manager = VariableManager()
    hostvars.set_variable_manager(new_variable_manager)
    assert hostvars._variable_manager is new_variable_manager
    assert new_variable_manager._hostvars is hostvars

# Generated at 2022-06-21 09:27:59.744297
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = MagicMock()
    inventory.hosts = ["127.0.0.1"]
    variables = MagicMock()
    variables.get_vars.return_value = {"foo": "bar"}
    loader = MagicMock()
    h = HostVars(inventory, variables, loader)
    print(repr(h))
    assert repr(h) == "{'127.0.0.1': {'foo': 'bar'}}"

# Generated at 2022-06-21 09:28:06.265063
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    """This test is validating that HostVars are iterable on hosts.
    In this particular case, the inventory contains
    only the localhost and the target host"""

    class Inventory:

        def __init__(self):

            self.hosts = []
            self.hosts.append("localhost")
            self.hosts.append("target_host")

    class VariableManager:

        def __init__(self):
            self._hostvars = None

        def get_vars(self, host=None, include_hostvars=True):

            return {'ansible_ssh_host': '192.168.0.1'}

    class Loader:
        pass

    inventory = Inventory()
    variable_manager = VariableManager()
    loader = Loader()

# Generated at 2022-06-21 09:28:16.316687
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    import sys
    import os
    import tempfile
    import yaml
    import ansible.cli.adhoc

    # Create a temporary inventory file
    (fd, inv_file_path) = tempfile.mkstemp()
    os.write(fd, '[test_group]\nlocalhost\n')
    os.close(fd)

    # Construct ansible options
    options = ansible.cli.adhoc.AdHocCLI()
    options.inventory = inv_file_path
    options.host_list = None
    options.module_name = None
    options.module_args = None
    options.forks = 0
    options.listhosts = False
    options.subset = None
    options.verbosity = 0

    # Create an adhoc cli runner
    cli = ansible.cli.adh

# Generated at 2022-06-21 09:28:26.718944
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create host object
    host_name = 'test-inventory-host'
    host_data = {'vars': {'var1': 'foo'}}
    host_obj = Host(name=host_name, port=22, variables=host_data)

    # create inventory test data
    variable_manager._inventory.hosts = [host_obj]

    # get hostvars

# Generated at 2022-06-21 09:28:31.970183
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import pickle

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=None)
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{a}} b {{c}} {{d}}'))),
        ]
    ), variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 09:28:42.356364
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import ansible.parsing.dataloader
    import ansible.vars
    import copy

    data = dict(
        inventory=None,
        loader=ansible.parsing.dataloader.DataLoader(),
        variable_manager=ansible.vars.VariableManager(),
    )
    hostvars = HostVars(**data)
    hostvars_dump = copy.dumps(hostvars)
    hostvars_restored = copy.loads(hostvars_dump)
    assert hostvars_restored._inventory == hostvars._inventory
    assert hostvars_restored._loader == hostvars._loader
    assert hostvars_restored._variable_manager == hostvars._variable_manager
    assert hostvars_restored._variable_manager._loader == hostvars._loader

# Generated at 2022-06-21 09:28:52.600202
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader())
    inventory.add_host('name_host', 'group_host')
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, DataLoader())

    assert isinstance(hostvars.raw_get('name_host'), dict)
    assert isinstance(hostvars.raw_get('name_other'), AnsibleUndefined)


# Generated at 2022-06-21 09:29:00.620746
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    assert hostvars.raw_get(host_name='localhost') == hostvars['localhost']



# Generated at 2022-06-21 09:29:11.380407
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    import ansible
    # Create HostVars
    loader = ansible.vars.loader.Loader()
    inventory = ansible.inventory.Inventory(loader=loader)
    vars_manager = ansible.vars.manager.VariableManager(loader=loader, inventory=inventory)
    variables = {'foo': 'bar'}
    hostvars = HostVars(inventory, vars_manager, loader)
    varname = 'hostvars'
    hostname = '127.0.0.1'
    host = inventory.get_host(hostname)
    vars_manager.set_host_variable(host, varname, variables)
    # Test
    copied_vars_manager = deepcopy(vars_manager)
    copied_variables = copied_vars_manager.get_

# Generated at 2022-06-21 09:29:22.605245
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible import constants as C
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class MockInventory:
        def __init__(self):
            self.hosts = []
            self.groups = {}

        def get_host(self, name):
            self.hosts.append(name)
            return host

        def add_group(self, name):
            self.groups[name] = Group(name)

        def add_host(self, name):
            self.hosts.append(name)

        def add_child(self, host, group):
            self.groups[group].add_child(host)
            host.add_group(self.groups[group])

        def get_groups_dict(self):
            return self.groups


# Generated at 2022-06-21 09:29:31.572701
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    variable_manager = VariableManager()
    loader = variable_manager._loader
    variable_manager._options, variable_manager._args = variable_manager._play_prereqs(PlayContext())
    variable_manager.get_vars(loader=loader, play=PlayContext(), all_vars=dict())

    inventory = variable_manager._inventory
    host_name = 'localhost'
    host = Host(name=host_name)
    inventory.add_host(host)
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    host

# Generated at 2022-06-21 09:29:41.182911
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    host_name = 'localhost'

    expected = AnsibleUndefined(name="hostvars['%s']" % host_name)
    result = hostvars.raw_get(host_name)

    assert result == expected

# Generated at 2022-06-21 09:29:43.579803
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {'var1': 'foo', 'var2': 'bar'}
    loader = None

    result = HostVarsVars(variables, loader)

    assert sorted(result.__iter__()) == sorted(variables.keys())
    assert sorted(list(result)) == sorted(variables.keys())


# Generated at 2022-06-21 09:29:51.596395
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.variables import VariableManager
    from ansible.vars import VariableManager

    vm_state = dict(
        _vars=dict(
            role_names=['role_name'],
            ansible_host='192.0.2.1',
            foo='bar',
            role_name=dict(
                variable_name='variable_value',
            ),
        ),
        _fact_cache=dict(),
        _host_memory=dict(),
        _nonpersistent_fact_cache=dict(role_name=dict(
            variable_name='variable_value'
        )),
        _options=dict(),
        _play=Play(),
    )


# Generated at 2022-06-21 09:30:00.215815
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inv = Inventory(loader=None, variable_manager=None, host_list=[])
    hv = HostVars(inv, VariableManager(), loader=None)

    group1 = inv.add_group('group1')
    host1 = inv.get_host('host1')
    host2 = inv.get_host('host2')
    hv.set_host_variable(host1, 'test_host_var1', 1)
    hv.set_host_variable(host2, 'test_host_var2', 2)

    # Check that variables are set correctly
    assert hv[host1]['test_host_var1'] == 1
    assert hv[host2]['test_host_var2'] == 2

    # Check

# Generated at 2022-06-21 09:30:11.370950
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])

    def add_inventory_entry(name, var1='', var2=''):
        host = Host(name=name)
        host.vars = {'var1': var1, 'var2': var2}
        host.groups = []
        host.reverse = {}
        inventory.add_host(host)

    def add_inventory_group(name, var1='', var2=''):
        group = Group(name=name)

# Generated at 2022-06-21 09:30:25.540495
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle
    # Create a pair of classes that are not serializable.
    class NonSerializableObjectA:
        pass
    class NonSerializableObjectB:
        pass
    # Create a hostvars object.
    hostvars = HostVars(
        inventory=NonSerializableObjectA(),
        variable_manager=NonSerializableObjectB(),
        loader=NonSerializableObjectA()
    )
    # Pickle the hostvars object.
    hostvars_bytes = pickle.dumps(hostvars)
    # Unpickle the hostvars object to recreate it.
    hostvars_copy = pickle.loads(hostvars_bytes)
    # Assert that all attributes are the same.

# Generated at 2022-06-21 09:30:32.752315
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    """
    This test (test_HostVars___len__) is used to check if method __len__
    works properly.
    """

    from ansible.plugins.vars import HostVars as AnsibleHostVars
    from ansible.plugins import vars as ansible_vars
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    import inspect
    import os

    test_files_dir = os.path.join(
        os.path.dirname(
            inspect.getfile(AnsibleHostVars)
        ),
        '../tests/test_files'
    )
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager._hostvars = None

# Generated at 2022-06-21 09:30:45.158136
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()  # Mock object

    class InventoryHost(object):
        def __init__(self, name, vars):
            self.name = name
            self.vars = vars

    class Inventory(object):
        def __init__(self, hosts):
            self.hosts = hosts

        def get_host(self, hostname):
            if hostname == 'localhost':
                return InventoryHost('localhost', {'ansible_play_hosts': 'localhost'})
            else:
                return None

    inventory = Inventory(['localhost'])

    class VariableManager(object):
        def __init__(self, loader, variables):
            self._loader = loader
            self._variables = variables
            self._hostvars = None

       

# Generated at 2022-06-21 09:30:53.204130
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import os

    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    host_name = 'localhost'
    inventory_file = os.path.join('test', 'unit', 'data', 'hostvars', 'inventory.yml')
    host_vars_file = os.path.join('test', 'unit', 'data', 'hostvars', 'host_vars', host_name + '.yml')

    loader = FakeLoader(paths=[os.path.dirname(inventory_file), os.path.dirname(host_vars_file)])
    inventory = InventoryManager(loader=loader, sources=[inventory_file])

# Generated at 2022-06-21 09:30:58.578961
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    vars_cache = {'foo': {'bar': 'baz'}}
    loader = None
    inventory = None
    variable_manager = None
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._vars_cache == vars_cache
    hostvars.__repr__()


# Generated at 2022-06-21 09:31:07.524781
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    class Dummy(object):
        pass

    loader = Dummy()
    inventory = Dummy()
    variable_manager = VariableManager()

    h = HostVars(inventory, variable_manager, loader)

    assert h._loader is loader
    assert h._inventory is inventory
    assert h._variable_manager is variable_manager

    assert variable_manager._hostvars is h
    assert variable_manager._loader is loader

    # Create new instance of HostVars with __setstate__ method
    h = HostVars.__new__(HostVars)

    h.__setstate__({'_inventory': inventory,
                    '_loader': loader,
                    '_variable_manager': variable_manager})

    assert h._loader is loader
   

# Generated at 2022-06-21 09:31:17.473714
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    hostvars = HostVars(
        inventory = InventoryManager(
            loader=DataLoader(),
            sources='localhost,'
        ),
        variable_manager = VariableManager(
            loader=DataLoader(),
        )
    )
    hostvars['foo'] = 5 # will create 'foo' variable in variable_manager
    variable_manager_vars = hostvars._variable_manager.get_vars()

    # Check if variable 'foo' is stored in variable_manager
    assert 'foo' in variable_manager_vars

    # Check if variable 'foo' is stored in variable_manager

# Generated at 2022-06-21 09:31:24.367479
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
    hostvars.set_variable_manager(variable_manager)
    hostvars.set_inventory(inventory)
    new_value = 'foo_bar'
    var_name = 'foo'

# Generated at 2022-06-21 09:31:32.602781
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from copy import deepcopy
    from os.path import abspath, dirname, join

    INVENTORY_PATH = join(dirname(abspath(__file__)), 'inventory', 'test_hostvars_deepcopy.yml')
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=INVENTORY_PATH)
    hostvars = HostVars(inventory=inventory, variable_manager=VariableManager(), loader=DataLoader())
    hostvars_copy = deepcopy(hostvars)

    assert hostvars_copy

    assert hostvars_copy is not hostvars

# Generated at 2022-06-21 09:31:42.901150
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variable_manager = VariableManager(loader=DataLoader())
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    assert hostvars._inventory == inventory

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    hostvars.set_inventory(inventory)
    assert hostvars._inventory == inventory



# Generated at 2022-06-21 09:32:00.913165
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager

    # Create instance of HostVars.
    inventory = None
    variable_manager = VariableManager(loader=None)
    loader = None
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create state to assign to hostvars.
    state = {
        '_loader': loader,
        '_variable_manager': variable_manager,
        '_inventory': inventory,
    }

    # Assign state to hostvars.
    hostvars.__setstate__(state)

    # Check if values of _loader and _hostvars attributes are restored.
    assert hostvars._loader is loader
    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

# Generated at 2022-06-21 09:32:07.847511
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    ''' Unit test for method __len__ of class HostVarsVars '''
    from ansible.vars.hostvars import HostVarsVars
    from unittest import mock
    from ansible.vars.hostvars import __len__
    import sys
    from ansible.vars.hostvars import __len__
    from ansible.vars.hostvars import __dict__

    variables = {"A": "B"}
    mock_loader = mock.Mock()
    hostvars_vars = HostVarsVars(variables, mock_loader)
    assert hostvars_vars.__len__() == len(variables)

# Generated at 2022-06-21 09:32:17.326265
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def check_values_are_templated(dict1, dict2):
        # Check that all items in dict2 were templated (self._vars are
        # included in items' values).
        for k, v in dict1.items():
            dict2_v = dict2[k]
            if isinstance(v, dict):
                check_values_are_templated(v, dict2_v)
            else:
                assert isinstance(dict2_v, AnsibleUndefined)
                assert dict2_v.name == v


# Generated at 2022-06-21 09:32:29.552156
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    h = HostVars(inventory=Inventory(), variable_manager=VariableManager(), loader=DataLoader())
    assert h._variable_manager._loader is h._loader

    assert h._variable_manager._hostvars is h

    play = Play()
    variable_manager = play.get_variable_manager()

    assert variable_manager._loader is h._loader
    assert variable_manager._hostvars is None

    h.set_variable_manager(variable_manager)
    assert variable_manager._hostvars is h
    h_state = h.__getstate__()
    h.__setstate__(h_state)
   

# Generated at 2022-06-21 09:32:40.369877
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = dict()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    context = PlayContext(loader=loader, variable_manager=variable_manager, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    variable_manager2 = VariableManager(loader=loader, inventory=inventory, play_context=context)

    variable_manager2._hostvars = None
    hostvars.set_variable_manager(variable_manager2)

    assert variable_manager2._hostvars == hostvars

# Generated at 2022-06-21 09:32:50.112027
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import copy
    import collections
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    loader = 'loader'
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader)
    play_context = PlayContext()
    play = Play.load(dict(), variable_manager=variable_manager, loader=loader)
    play._prepare_implicit_variables()
    play_context._setup_implicit_variables(play)
    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-21 09:33:01.925843
# Unit test for constructor of class HostVars
def test_HostVars():
    class Foo(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    foo = Foo(1, 2, 3, a='a', b='b', c='c')

    class Bar(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def get_host(self, host_name):
            return foo

    bar = Bar(1, 2, 3, a='a', b='b', c='c')

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dataloader = DataLoader()

    variable_manager = VariableManager()

# Generated at 2022-06-21 09:33:09.159617
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.vars import VariableManager
    vm = VariableManager()
    hostvars = HostVars(inventory=None, variable_manager=vm, loader=None)
    hostvars.set_host_facts(host=None, facts={'foo': 'bar'})
    vm._nonpersistent_facts['localhost'] = {'foo': 'bar'}

# Generated at 2022-06-21 09:33:12.679428
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVarsVars
    vars = VariableManager()
    hvar = HostVarsVars({'var1': '1'}, loader=None)
    assert len(hvar) == 1


# Generated at 2022-06-21 09:33:23.341001
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():

    class DummyLoader:
        pass

    d = {'a': 1, 'b': 2, 'c': 3}
    h = HostVarsVars(d, DummyLoader())

    assert h == d

    # test special method __getitem__
    assert h['a'] == 1 and h['b'] == 2 and h['c'] == 3

    # test method __iter__ and __contains__
    assert 'a' in h and 'b' in h and 'c' in h
    for k in h:
        assert k in list(d.keys())

    # test method __len__
    assert len(h) == len(d)

    # test method __repr__
    assert str(h) == str(d)

# Generated at 2022-06-21 09:33:42.392369
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    """Tests that method __len__ of class HostVarsVars returns a correct number of dictionary keys.
    """
    vars = {'foo': 'bar', 'bar': 'baz'}
    host_vars_vars = HostVarsVars(vars, loader=None)
    assert len(vars) == len(host_vars_vars)

# Generated at 2022-06-21 09:33:50.624055
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host_names = [ 'all', 'test_host', 'test_host2' ]

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,localhost2'])

    inventory.clear_pattern_cache()
    inventory.parse_inventory(host_names)

    for h in host_names:
        host = inventory.get_host(h)
        if h == 'all':
            assert host.name == 'all'
            assert host.vars['ansible_all_hosts'] == [ 'localhost', 'localhost2' ]
        elif h == 'test_host':
            assert host.name == 'localhost'

# Generated at 2022-06-21 09:34:00.304485
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    import copy

    class FakeVarsManager:
        def __init__(self, hostvars):
            self._hostvars = hostvars

    hostvars = HostVars({}, {}, {})
    deepcopy_of_hostvars = copy.deepcopy(hostvars)

    fake_vars_manager = FakeVarsManager(hostvars)
    deepcopy_of_vars_manager = copy.deepcopy(fake_vars_manager)

    # This assertion fails if __deepcopy__ method is not implemented
    assert deepcopy_of_hostvars is deepcopy_of_vars_manager._hostvars

# Generated at 2022-06-21 09:34:01.033819
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    pass

# Generated at 2022-06-21 09:34:09.345649
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = None
    variables = dict(
        foo='foo',
        bar=dict(
            d=dict(
                e='{{ foo }}',
                f='f',
                g='{{ e }}',
            )
        )
    )
    vars = HostVarsVars(variables, loader)
    assert vars['bar']['d']['e'] == 'foo'
    assert vars['bar']['d']['g'] == 'foo'

# Generated at 2022-06-21 09:34:18.583175
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    vars = dict(a={'a':'A', 'b':'A1{z}'}, b={'a':'B', 'b':'B1{z}'}, z='Z')
    hostvarsvars = HostVarsVars(vars, loader)
    assert repr(hostvarsvars) == "{'a': {'a': 'A', 'b': 'A1Z'}, 'b': {'a': 'B', 'b': 'B1Z'}, 'z': 'Z'}"

# Generated at 2022-06-21 09:34:30.633715
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    """
    Unit test for method __len__ of class HostVars
    """
    import ansible.inventory.manager
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role

    # Setup
    inventory = ansible.inventory.manager.InventoryManager(loader=None, sources='localhost,')
    variable_manager = ansible.vars.manager.VariableManager(loader=ansible.parsing.dataloader.DataLoader())
    connection = ansible.runner.connection.Connection(None)
    play_context = ansible.playbook.play.PlayContext()
    play_context.network_os = 'ios'


# Generated at 2022-06-21 09:34:38.107462
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible import constants as C

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    hostvars = HostVars(inventory=inv_manager, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 09:34:51.332904
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    import copy
    from ansible.vars.manager import VariableManager

    # initialize object HostVars
    hostvars = HostVars(inventory=None,
                        variable_manager=VariableManager(loader=None),
                        loader=None)

    # set variables in VariableManager
    hostvars.set_host_variable(host="testhost",
                               varname="var1",
                               value="value1")
    hostvars.set_nonpersistent_facts(host="testhost",
                                     facts={"fact1": "value1"})
    hostvars.set_host_facts(host="testhost",
                            facts={"fact2": "value2"})

    # check if VariableManager is updated

# Generated at 2022-06-21 09:35:02.020907
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    class AnsibleVars:
        bar = 'bar_value'

    class AnsibleVars2:
        bar = 'bar_value2'

    class Loader:
        def get_basedir(self):
            return 'ansible'

        def load_from_file(self, file, cache=False):
            if file == 'playbooks/bar':
                return AnsibleVars
            else:
                return AnsibleVars2

    class Runner:
        def loader(self):
            return Loader()

    class Inventory:
        def get_host(self, host_name):
            class Host:
                name = 'foo'

            return Host()

    hostvars = HostVars(Inventory(), Runner().loader(), Runner().loader())
    repr = hostvars['foo'].__repr__()
    assert repr

# Generated at 2022-06-21 09:35:35.098842
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    data = {'name': 'Bob', 'age': 123}
    variables = UnsafeProxy(data)

    hostvarsvars = HostVarsVars(variables, loader=None)

    assert hostvarsvars.__repr__() == repr(data)

# Generated at 2022-06-21 09:35:44.530694
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars.manager import VariableManager

    class MockInventory():
        def __init__(self, host_list):
            self._hosts_cache = list(host_list)

        def get_host(self, hostname):
            for host in self._hosts_cache:
                if hostname == host.name:
                    return host
            return None

        @property
        def hosts(self):
            return self._hosts_cache

    class MockVariableManager():
        def __init__(self):
            self._loader = None
            self._hostvars = None

    class MockHost():
        def __init__(self, name):
            self.name = name

    inventory = MockInventory(host_list=[MockHost(name) for name in ['host1', 'host2']])
    variable

# Generated at 2022-06-21 09:35:48.738221
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.parsing.dataloader import DataLoader
    inventory = AnsibleInventory(loader=DataLoader(), variable_manager=VariableManager())
    hostvars = HostVars(inventory, VariableManager(), loader=DataLoader())
    assert len(hostvars) == 0

    inventory.add_host('host')
    assert len(hostvars) == 1



# Generated at 2022-06-21 09:35:57.035017
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import yaml
    from ansible.template import Templar
    class FakeLoader():
        def load(self, *args):
            pass
    class FakeVars():
        def __init__(self, data):
            self.data = data
        def __getitem__(self, key):
            return self.data[key]
    loader = FakeLoader()
    templar = Templar(loader=loader)

    # Define variables
    variables = FakeVars(data={})
    variables['ansible_host'] = 'foo'

    # Test variable from 'hostvars.ansible_host'
    foo = HostVarsVars(variables, loader)
    assert foo['ansible_host'] == 'foo'

    # Test variable from 'hostvars.all.ansible_host'
    variables['ansible_host']

# Generated at 2022-06-21 09:36:04.511065
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from copy import deepcopy
    from ansible.playbook.play_context import PlayContext

    inventory = FakeInventory(
        FakeHost(name='foo'),
        FakeHost(name='bar'),
    )
    variable_manager = FakeVariableManager(inventory)
    loader = FakeLoader()
    hostvars = HostVars(inventory, variable_manager, loader)
    deepcopy(hostvars)

    # Make sure that variable_manager has a reference to hostvars
    assert variable_manager._hostvars is hostvars



# Generated at 2022-06-21 09:36:11.311507
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # In this unit test we want to check that __getitem__ returns the
    # same result as what we get from running the same thing through
    # the actual templating engine.
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create mock objects for arguments of __init__
    variables = {'foo': 'bar'}
    loader = None

    # Create variable_manager and set its loader attribute
    variable_manager = VariableManager()
    variable_manager._loader = loader

    hostvars = HostVarsVars(variables, loader)

    # Perform the actual test:
    templar = Templar(loader=loader, variables=variables)
    assert hostvars['foo'] == templar.template('{{foo}}')

# Generated at 2022-06-21 09:36:14.678794
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    data = {"mydict" : {"key1" : "value1", "key2" : "value2"}}
    c = HostVarsVars(data, None)
    assert len(c) == 1

# Generated at 2022-06-21 09:36:23.298422
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.constants import DEFAULT_HASH_BEHAVIOUR
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.set_loader(loader)

    hostvars = HostVars({}, variable_manager, loader)

    foo_host = variable_manager.add_host('foo')
    bar_host = variable_manager.add_host('bar')

    variable_manager.set_host_variable(foo_host, 'mess', 'Hello World!')
    variable_manager.set_host_variable(foo_host, 'list', [1, 2, 3])


# Generated at 2022-06-21 09:36:32.787834
# Unit test for constructor of class HostVars
def test_HostVars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # create a basic var manager
    variable_manager = VariableManager()
    loader = DataLoader()

    # create an inventory with two hosts, both with a generic 'n' var
    # and a host-specific 'm' var
    inventory = FakeInventory(host_list=['host1', 'host2'], group_list=[])
    inventory.set_variable('host1', 'm', 'host1_m')
    inventory.set_variable('host2', 'm', 'host2_m')
    inventory.set_variable('all', 'n', 'all_n')

    # make sure the var manager is using this inventory
    variable_manager.set_inventory(inventory)

    # use that var manager to create the

# Generated at 2022-06-21 09:36:42.011090
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    inventory_manager = InventoryManager(loader=loader)

    hostvars = HostVars(inventory_manager, None, loader)
    host = inventory_manager.add_host('localhost')
    hostvars.set_host_variable(host, 'foo', 'bar')
    assert hostvars['localhost']['foo'] == 'bar'

    hostvars.set_host_variable(host, 'foo', 'blah')
    assert hostvars['localhost']['foo'] == 'blah'
