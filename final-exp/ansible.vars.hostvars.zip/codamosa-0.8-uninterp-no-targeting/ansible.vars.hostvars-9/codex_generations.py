

# Generated at 2022-06-21 09:27:31.020037
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inv_src = (
        '[group1]\n'
        'localhost ansible_ssh_user=local\n'
        'localhost ansible_ssh_port=2222\n'
        'localhost0 ansible_connection=local\n'
        'localhost1 ansible_connection=local\n'
        'localhost2 ansible_connection=local\n'
        'localhost2 ansible_ssh_port=2222'
    )
    inv_path = '/etc/ansible/hosts'
    inv_manager = InventoryManager(loader=None, sources=inv_src)
    vm = VariableManager(loader=None, inventory=inv_manager)

# Generated at 2022-06-21 09:27:32.935774
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():

    hostvars = HostVars({'foo': 'bar'})

    assert len(hostvars) == 1

# Generated at 2022-06-21 09:27:39.540006
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():

    from ansible.vars.manager import VariableManager
    from ansible.playbook.included_file import IncludedFile

    variable_manager = VariableManager()
    variable_manager._loader = 'loader'
    variable_manager._hostvars = None

    HostVars(None, variable_manager, 'loader').set_variable_manager(variable_manager)

    assert variable_manager._hostvars is not None
    assert variable_manager._hostvars._loader == 'loader'
    assert isinstance(variable_manager._loader, IncludedFile)

# Generated at 2022-06-21 09:27:51.686448
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars.unsafe_proxy import UnsafeProxy
    hostvars_for_unit_test = {
        'local': {'key1': 'value1'},
        'alpha': {'key2': 'value2'},
        'beta': {'key3': 'value3'}
    }
    loader_for_unit_test = DataLoader()

# Generated at 2022-06-21 09:28:01.159217
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.plugins.loader import inventory_loader
    from ansible.vars import VariableManager

    fake_loader = FakeDataLoader()
    fake_inventory = inventory_loader.get('fake_inventory', loader=fake_loader)
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

    hostvars = HostVars(fake_inventory, fake_variable_manager, fake_loader)

    hosts = [
        'fake_inventory_hostname',
        'fake_inventory_hostname_0',
        'fake_inventory_hostname_1',
        'fake_inventory_hostname_2',
    ]

    assert len(hostvars) == len(hosts)


# Generated at 2022-06-21 09:28:10.966164
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    '''Test HostVars.set_host_facts for setting and clearing host facts'''
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host('localhost')
    assert host is not None

    # check if host facts are empty
    host_facts = hostvars.get_host_facts(host)
    assert host_facts is None

    # set host facts

# Generated at 2022-06-21 09:28:22.666192
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    '''
    hostvars = {"x": "{{ y }}"}
    host = Host(name="localhost")
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars[host.name] returns {'x': AnsibleUndefined}
    '''
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])

    host = Host(name="localhost")
    inventory.add_host(host)

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._vars_cache = {"y": "Hello"}
    hostv

# Generated at 2022-06-21 09:28:25.340778
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    loader = None
    variables = {'myvar': 'myval'}
    result = HostVarsVars(variables, loader)
    assert result['myvar'] == 'myval'

# Generated at 2022-06-21 09:28:32.828654
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    hostvars = HostVars(inventory, variable_manager, loader)

    # test localhost
    assert 'localhost' in hostvars
    assert hostvars['localhost'] is not None
    assert hostvars['localhost'] == hostvars['localhost']
    assert len(hostvars['localhost']) > 0
    # Test accessing arbitrary localhost variables
    assert hostvars['localhost']['inventory_hostname'] == 'localhost'
    # Test accessing

# Generated at 2022-06-21 09:28:34.300870
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    variables = {'a':1, 'b':2, 'c':3}
    loader = None
    hvv = HostVarsVars(variables, loader)
    assert len(hvv) == len(variables)

# Generated at 2022-06-21 09:28:46.225323
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create inventory, loader and variable manager
    inventory = InventoryManager(loader=DataLoader(), sources=['tests/inventory'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # Create hostvars
    hostvars = HostVars(inventory, variable_manager, loader=variable_manager._loader)

    # Test
    assert hostvars['localhost'] == {'ansible_connection': 'local', 'inventory_hostname': 'localhost'}
    assert hostvars['127.0.0.1'] == {'ansible_connection': 'local', 'inventory_hostname': '127.0.0.1'}


#

# Generated at 2022-06-21 09:28:54.509911
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import copy
    import sys

    try:
        from ansible.vars import VariableManager
    except ImportError:
        # Ansible < 2.0
        pass

    try:
        from ansible.vars.hostvars import HostVars
        from ansible.parsing.dataloader import DataLoader
        from ansible.inventory.manager import InventoryManager
        from ansible.utils.vars import combine_vars
    except ImportError as e:
        # Ansible < 2.4
        sys.path.append(str(AnsibleCollectionConfig.results_dir / 'ansible/ansible'))
        from vars import VariableManager
        from hostvars import HostVars
        from ansible.parsing.dataloader import DataLoader
        from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-21 09:29:07.167132
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import os
    import tempfile
    import pickle

    _, tmp_file = tempfile.mkstemp()

    host_vars_vars_instance = HostVarsVars(
        {'test_var': '{{ test_var2 }}', 'test_var2': '{{ test_var3 }}', 'test_var3': 'var3_value'},
        loader=None
    )

    with open(tmp_file, 'wb') as f:
        retval = pickle.dump(host_vars_vars_instance, f)

    # Load the pickled value back but with static variables
    with open(tmp_file, 'rb') as f:
        host_vars_vars_instance = pickle.load(f)

    # Remove the temporary file
    os.remove(tmp_file)



# Generated at 2022-06-21 09:29:10.384892
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars_vars = HostVarsVars({'a': 1, 'b': 2, 'c': 3}, loader=None)
    assert set(hostvars_vars.__iter__()) == set(['a', 'b', 'c'])

# Generated at 2022-06-21 09:29:21.975118
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # Construct a minimal, valid inventory.
    inventory = type('MockInventory', (object,), {})()
    inventory.hosts = [Host(name='host1'), Host(name='host2')]
    inventory.get_host = inventory.hosts.__getitem__

    # Construct an empty variable manager.
    variables = dict(foo=1, bar=2)
    variable_manager = VariableManager(loader=None, inventory=inventory, variables=variables)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    # Initialize expected values.
    expected = 2

    # Do the actual test.
    result = len(hostvars)
    assert expected == result

# Generated at 2022-06-21 09:29:26.424324
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory_manager = InventoryManager(None, [])
    variable_manager = VariableManager(inventory_manager=inventory_manager)
    inventory_manager.get_host('localhost')

    hostvars = HostVars(inventory_manager, variable_manager, None)

    assert 'localhost' in hostvars

    assert 'some_host' not in hostvars

    inventory_manager.add_host(host='some_host')
    assert 'some_host' in hostvars



# Generated at 2022-06-21 09:29:37.613851
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six.moves import copyreg as copyreg

    # Register recursion-free pickling function for class HostVars.
    # We could use standard pickling without registering custom
    # function, however it would be inefficient due to the use of
    # recursion.
    def pickle_copyreg_HostVars(host_vars):
        return (HostVars,
                (host_vars._inventory,
                 host_vars._variable_manager,
                 host_vars._loader))
    copyreg.pickle(HostVars, pickle_copyreg_HostVars)

    # Register recursion-free pickling function for class HostVarsVars.

# Generated at 2022-06-21 09:29:46.990835
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.inventory import Host, Inventory

    # Create inventory, host and variable manager
    InventoryManager(loader=DataLoader(), sources='')
    host = Host(name='localhost')
    variable_manager = VariableManager(loader=DataLoader(), inventory=Inventory(loader=DataLoader()))

    # Create HostVars object with inventory, variable manager and loader
    hostvars = HostVars(variable_manager=variable_manager, loader=DataLoader(), inventory=Inventory(loader=DataLoader()))

    # Set facts in hostvars cache

# Generated at 2022-06-21 09:29:52.727978
# Unit test for constructor of class HostVars
def test_HostVars():
    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    inventory = Inventory(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert isinstance(hostvars, Mapping)
    assert isinstance(hostvars, HostVars)

# Generated at 2022-06-21 09:29:57.837254
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    hostvars = HostVars(
        inventory=None,
        variable_manager=None,
        loader=None,
    )
    hostvars.set_inventory({
        'example.com': {
            'hosts': [Host(name='example.com')],
            'vars': {}
        }
    })
    assert list(hostvars) == ['example.com']


# Generated at 2022-06-21 09:30:12.939717
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import wrap_var
    import ansible.constants as C

    # create a complex variables dict with multiple references to each other
    # to be sure that templating is done correctly
    vars1 = wrap_var(C.DEFAULT_HOST_VARIABLE_INTERPOLATION, 'hostvars.hostvars')
    vars2 = wrap_var(C.DEFAULT_HOST_VARIABLE_INTERPOLATION, 'hostvars.vars')
    variables = wrap_var(C.DEFAULT_GROUP_VARIABLE_INTERPOLATION, {'hostvars':vars1, 'vars':vars2})
   

# Generated at 2022-06-21 09:30:24.643778
# Unit test for constructor of class HostVarsVars
def test_HostVarsVars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template.vars import hostvars_from_inventory

    test_vars = {
        'foo': 'bar',
        'baz_1': 'qux_1',
        'baz_2': 'qux_2',
    }

    variable_manager = VariableManager(HostVarsVars(test_vars, loader=None))

    assert test_vars == variable_manager._hostvars.raw_get('localhost')

    # Get missing item
    assert 'bar' == variable_manager._hostvars['localhost']['foo']

    # Get item with different name

# Generated at 2022-06-21 09:30:33.350049
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    import ansible.loader
    import ansible.vars
    import ansible.parsing.dataloader

    loader = ansible.loader.DataLoader()
    variable_manager = ansible.vars.VariableManager()
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    hostvars = HostVars(inventory, variable_manager, loader)
    hvarsvars = HostVarsVars(hostvars['localhost'], loader)

    assert repr(hvarsvars) == "{'omit': 'nope', 'ansible_version': {'full': '2.5.5', 'major': 2, 'minor': 5, 'revision': 5, 'string': '2.5.5'}}"


# Generated at 2022-06-21 09:30:42.955631
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    # GIVEN
    inventory = mock.Mock()
    variable_manager = mock.Mock()
    loader = mock.Mock()
    host_vars = HostVars(inventory, variable_manager, loader)

    # WHEN
    host_name = 'some_host'
    host_vars.__contains__(host_name)

    # THEN
    inventory.get_host.assert_called_once_with(host_name)
    variable_manager.assert_not_called()
    loader.assert_not_called()


# Generated at 2022-06-21 09:30:52.093826
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # Mocking class Host
    from ansible.inventory.host import Host

    class MockHost(Host):
        def __init__(self):
            self.name = 'test_host'

    # Mocking class VariableManager
    class MockVariableManager:
        def __init__(self):
            self._fact_cache = {}

        def set_host_facts(self, host, facts):
            self._fact_cache[host.name] = facts

        @property
        def fact_cache(self):
            return self._fact_cache

    # Mocking class Inventory
    class MockInventory:
        def __init__(self):
            self.hosts = []

        def add_host(self, host):
            self.hosts.append(host)

    class MockLoader:
        def __init__(self):
            pass

# Generated at 2022-06-21 09:30:56.407814
# Unit test for constructor of class HostVars
def test_HostVars():
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    assert hv._inventory is None
    assert hv._loader is None
    assert hv._variable_manager is None
    assert hv == {}


# Generated at 2022-06-21 09:31:06.565429
# Unit test for constructor of class HostVarsVars

# Generated at 2022-06-21 09:31:15.936620
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['tests/inventory/test_hostvars'])
    vars_manager = VariableManager(loader=loader, inventory=inv)
    hostvars = HostVars(inventory=inv, loader=loader, variable_manager=vars_manager)

    assert hostvars.__contains__('host-1')
    assert not hostvars.__contains__('non-existing-host')



# Generated at 2022-06-21 09:31:23.241121
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # Create inventory
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class Inventory(InventoryManager):
        pass

    inventory = Inventory(loader=DataLoader(), sources='')
    inventory.hosts = set(['host1', 'host2'])

    # Create variables
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    class MockTemplar(Templar):

        def __init__(self):
            self._data = {'host1': {'foo': 'bar'}, 'host2': {'foo': 'baz'}}
            self.loader = None


# Generated at 2022-06-21 09:31:31.933178
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Create a new VariableManager object with no loader and no hostvars
    variable_manager_new = VariableManager()

    # Call set_variable_manager, loader and hostvars should be set in variable_manager_new object
    hostvars.set_variable_manager(variable_manager_new)

    assert variable_manager_new._loader == loader
    assert variable_manager_new._hostvars

# Generated at 2022-06-21 09:31:54.617771
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    from ansible.vars import VariableManager
    from ansible.plugins.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    # Create an inventory
    inventory = InventoryManager(loader=None, sources=[])
    localhost = Host(name='localhost')
    inventory.add_host(localhost)
    all_group = Group(name='all')
    inventory.add_group(all_group)

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {}

    # Create a play

# Generated at 2022-06-21 09:32:03.069938
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.playbook.play import Play
    import copy

    play = Play().load({}, variable_manager={}, loader=dict())
    host = play.get_variable_manager().add_host(None, 'localhost')
    vars = HostVars(play._variable_manager, play._loader)
    vars.set_nonpersistent_facts(host, {'key': 'value'})

    assert host.get_vars()['key'] == 'value'

    new_host = copy.deepcopy(host)
    assert 'key' not in new_host.get_vars()

# Generated at 2022-06-21 09:32:15.347848
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVarsVars

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['dummy.com'])
    host = Host(name='dummy.com')
    inventory.add_host(host)
    variables = {'bar': 'baz'}
    host_vars = HostVars(inventory, VariableManager(loader=loader), loader=loader)
    host_vars.set_host_variable(host, 'foo', 'bar')
    host_v

# Generated at 2022-06-21 09:32:26.504072
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    class TestInventory(object):

        def __init__(self, hosts=None):
            self._hosts = hosts

        def get_host(self, host_name):
            for host in self._hosts:
                if host.name == host_name:
                    return host
            return None

        @property
        def hosts(self):
            return self._hosts

    class TestHost(object):

        def __init__(self, name, vars):
            self.name = name
            self.vars = vars

    class TestVars(dict):

        def __init__(self, data):
            super(TestVars, self).__init__(data)
            # Mock that the dict is not modified by another module
            self.popitem = dict.popitem
            self.setdefault = dict.setdefault



# Generated at 2022-06-21 09:32:38.212692
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()
    from ansible.vars.manager import VariableManager
    vm = VariableManager()
    from ansible.inventory.manager import InventoryManager
    im = InventoryManager()

    hv = HostVars(im, vm, dl)
    hv._loader = dl
    hv._inventory = im
    hv._variable_manager = vm

    class Host:
        def __init__(self, hostname):
            self.name = hostname
        def get_name(self):
            return self.name
        def __repr__(self):
            return self.name

    vm.set_host_variable(Host('host1'), 'foo', 'foo_from_hostvars')

    hv.set_nonpersistent

# Generated at 2022-06-21 09:32:48.638987
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    from ansible.vars.hostvars import HostVarsVars
    import collections
    import pytest

    cls_obj = HostVarsVars(variables={'a': 1, 'b': 2}, loader=None)

    # Test: Check if the result of __len__ is an integer
    assert isinstance(len(cls_obj), int)

    # Test: Check if the result of __len__ is equal to len(cls_obj._vars.keys())
    assert len(cls_obj) == len(cls_obj._vars.keys())

    # Test: Check if the result of __len__ is equal to len(cls_obj._vars)
    assert len(cls_obj) == len(cls_obj._vars)

    # Test: Check if the result of __len__ is

# Generated at 2022-06-21 09:32:52.708193
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    data = {'ansible_distribution': 'CentOS'}
    variables =  HostVarsVars(data, loader=None)

    for var in variables:
        assert(var == 'ansible_distribution')

# Generated at 2022-06-21 09:33:03.180370
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    '''
    The method raw_get of class HostVars should return
    a Python data structure with variables defined in
    the inventory file.
    '''
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import os

    # Load ansible.cfg
    loader = DataLoader()
    # For unit test, we should set ANSIBLE_CONFIG environment variable to the
    # default value of ANSIBLE_CONFIG in ansible.cfg.
    if 'ANSIBLE_CONFIG' not in os.environ:
        os.environ['ANSIBLE_CONFIG'] = '/etc/ansible/ansible.cfg'
    config = loader.load_from_file(os.environ['ANSIBLE_CONFIG'])
   

# Generated at 2022-06-21 09:33:07.272793
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    test_data = {'foo': 1, 'bar': 2}
    hostvarsvars = HostVarsVars(test_data, None)
    assert len(hostvarsvars) == 2



# Generated at 2022-06-21 09:33:19.555150
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # _loader and _hostvars attributes of VariableManager must be ignored
    # in __setstate__ and restored in __setstate__ of HostVars
    vm = VariableManager()
    vc = HostVars(inventory=Inventory(),
                    variable_manager=vm,
                    loader=DictDataLoader())

    vm_pickled = pickle.dumps(vm)
    vm_copy = pickle.loads(vm_pickled)

    vc_pickled = pickle.dumps(vc)
    vc_copy = pickle.loads(vc_pickled)

    assert (vm_copy._loader is None and vm_copy._hostvars is None)
    assert vc_copy._variable_manager == vm_copy
    assert vc_copy._variable_manager._loader == vc_copy._loader
    assert vc

# Generated at 2022-06-21 09:33:42.653138
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    # host1 is not in any groups
    host1 = InventoryManager('localhost ansible_connection=local', loader=DataLoader()).get_host('localhost')
    # host2 is in group group1
    host2 = InventoryManager('127.0.0.1 ansible_connection=local group1', loader=DataLoader()).get_host('127.0.0.1')
    # host3 is not in any groups
    host3 = InventoryManager('127.0.0.2 ansible_connection=local', loader=DataLoader()).get_host('127.0.0.2')
   

# Generated at 2022-06-21 09:33:50.091344
# Unit test for method __len__ of class HostVarsVars
def test_HostVarsVars___len__():
    # Setup ---------------------------------------

    # Example vars
    class ExampleVars(Mapping):
        def __getitem__(self, var):
            return "this is %s" % var

        def __contains__(self, var):
            return True

        def __iter__(self):
            for var in ["a", "b", "c"]:
                yield var

    class AnsibleModuleMock:
        def __init__(self):
            self.params = {}

    vars = ExampleVars()
    hostvars_vars = HostVarsVars(vars, AnsibleModuleMock())

    # Test -----------------------------------------
    assert len(hostvars_vars) == 3

# Generated at 2022-06-21 09:34:00.531178
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    ansible_loader = DataLoader()
    my_vars_manager = VariableManager()
    my_inventory = InventoryManager(loader=ansible_loader, sources=['/etc/ansible/hosts'])
    my_hostvars = HostVars(inventory=my_inventory, variable_manager=my_vars_manager, loader=ansible_loader)
    assert len(my_hostvars) > 0
    assert len(my_hostvars) == len([x for x in my_hostvars])


# Generated at 2022-06-21 09:34:13.201050
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    inventory = [
        'host1 name=host1 group1=g1_1 group2=g2_1 group3=g3_1',
        'host2 name=host2 group1=g1_2 group2=g2_2 group3=g3_2',
        '''
        host3 name=host3 group1=g1_3 group2=g2_3
        host4 name=host4 group1=g1_4 group2=g2_4
        ''',
    ]
    inventory = FakeInventory(inventory)
    variable_manager = FakeVariableManager()
    loader = FakeLoader()
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_inventory(inventory)
    assert hostvars._inventory == inventory
    assert len(hostvars) == 3

# Generated at 2022-06-21 09:34:21.581249
# Unit test for method __repr__ of class HostVarsVars
def test_HostVarsVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import modules_clean

    vars_dict = {
        'httpd_port': '{{ httpd_port_var }}',
        'httpd_port_var': '8080',
    }
    variable_manager = VariableManager(loader=None)
    variable_manager._extra_vars = {'httpd_port': '{{ httpd_port_var }}', 'httpd_port_var': '8080'}
    variable_manager._vars_cache = {'localhost': variables}
    for host in ('localhost'):
        internal_host_vars = HostVarsVars(variable_manager._vars_cache[host], loader=None)
        variable_manager._hostvars[host] = internal_host_vars



# Generated at 2022-06-21 09:34:32.955797
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars import AnsibleVars

    class C(AnsibleVars):
        def __init__(self, d):
            self.data = d

        def __getitem__(self, key):
            return self.data[key]

        def __iter__(self):
            return iter(self.data)

        def __contains__(self, key):
            return key in self.data

        def copy(self):
            return C(self.data.copy())

        def __len__(self):
            return len(self.data)

    loader = DataLoader()
    variable

# Generated at 2022-06-21 09:34:45.940345
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    hostvars = dict()
    hosts = dict()
    hostvars['host_one'] = dict()
    hostvars['host_one']['foo'] = 'bar'
    hostvars['host_one']['test'] = 'test'
    hosts['host_one'] = dict()
    loader = None
    inventory = HostVars(hostvars, hosts, loader)

    new_facts = dict()
    new_facts['baz'] = 'qux'
    new_facts['test'] = 'pass'
    inventory.set_nonpersistent_facts('host_one', new_facts)
    assert inventory['host_one']['foo'] == 'bar'
    assert inventory['host_one']['test'] == 'test'

# Generated at 2022-06-21 09:34:55.779426
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    variable_manager = VariableManager()
    hosts = [Host('a'), Host('b'), Host('c')]
    variable_manager._hostvars = {'a': dict(b='c'), 'b': dict(b='c')}

    hostvars = HostVars(hosts, variable_manager, loader='dontcare')
    assert set(hostvars) == set(['a', 'b', 'c'])



# Generated at 2022-06-21 09:35:04.037027
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    # Create mocks of needed classes.
    # Use objects with different IDs to check object identity
    loader = object()
    host = object()
    hosts = object()
    inventory = object()
    variable_manager = object()
    templar = object()

    # Create copy of class HostVars
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_copy = copy.deepcopy(hostvars)

    # Check if the references to loader and variable_manager of new HostVars
    # are identical to those of the original instance
    assert hostvars_copy._loader is loader
    assert hostvars_copy._variable_manager is variable_manager

# Generated at 2022-06-21 09:35:15.508775
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    '''
    Make sure we don't get an AnsibleUndefined error on iteration.
    '''
    import os
    import json
    from collections import namedtuple

    class FakeHost:
        def __init__(self, name):
            self.name = name
            self.vars = dict(a="b")

    VariableManager = namedtuple(
        'VariableManager', ['_fact_cache', '_vars'],
    )  # pylint: disable=invalid-name
    Inventory = namedtuple(
        'Inventory', ['_hosts', '_vars'],
    )  # pylint: disable=invalid-name


# Generated at 2022-06-21 09:36:03.847086
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    # get the module
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBoxFactCollector
    from ansible.module_utils.facts.virtual.lspci import LspciFactCollector

    # instantiate dist facts collector
    distro_obj = DistributionFactCollector()

    # instantiate virtual-related facts collectors
    virtual_obj = VirtualBoxFactCollector(distro_obj.sysname)
    pci_obj = LspciFactCollector(distro_obj.sysname)

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import playbook_executor

    loader = DataLoader

# Generated at 2022-06-21 09:36:11.048669
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    '''
    This test verifies that HostVars is deepcopyable.
    Note that HostVars is immutable, so this test is verifying a code path
    in __deepcopy__ method.
    '''
    import copy
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    def test_HostVars_in_vars_dict(data):
        variables = VariableManager(loader=DataLoader())
        variables.update_inventory(host_list=[])

        hostvars = variables._hostvars
        data['test'] = hostvars
        copy.deepcopy(data)

    # Test simple dict
    test_HostVars_in_vars_dict({})

    # Test nested dicts
    test_

# Generated at 2022-06-21 09:36:21.050610
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from copy import deepcopy

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=['tests/inventory/test_all_group_vars'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_copy = deepcopy(hostvars)

    assert hostvars is not hostvars_copy
    assert hostvars._inventory is hostvars_copy._inventory
    assert hostvars._variable_manager is hostvars_copy._variable_manager
    assert hostvars._loader is hostvars_copy._loader

# Generated at 2022-06-21 09:36:31.205211
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    mock_loader = DataLoader()
    mock_inventory = Inventory(loader=mock_loader)

    variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)

    hostvars = HostVars(mock_inventory, variable_manager, mock_loader)

    # Create a host and make sure it is connected to variable_manager
    localhost = mock_inventory.get_host('localhost')
    assert variable_manager.get_vars(host=localhost) is not None
    assert variable_manager._host_vars_plugins.names() != []

    # Set a variable with hostvars

# Generated at 2022-06-21 09:36:42.283400
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():

    class Inventory():

        def __init__(self, loader=None, variable_manager=None):
            self._loader = loader
            self._variable_manager = variable_manager

        def set_variable_manager(self, variable_manager):
            self._variable_manager = variable_manager

        def get_host(self, host):
            h = type('Host', (object,), {})()
            h.name = host
            return h

        @property
        def hosts(self):
            return ['host1', 'host2']


    class VariableManager():

        def __init__(self, loader=None):
            self._loader = loader
            self._hostvars = None

        def get_vars(self, host=None, include_hostvars=True):
            return dict(ansible_os_family='RedHat')

# Generated at 2022-06-21 09:36:50.487039
# Unit test for method set_inventory of class HostVars
def test_HostVars_set_inventory():
    """
    We can not directly unittest method set_inventory of class HostVars because this
    class contains a cyclic reference to VariableManager. However we can test it by
    checking if the result of get_hostvars method of VariableManager is the same
    object as the HostVars object.
    """

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class VariableManager2(VariableManager):

        # VariableManager2 will be used as a test stand for VariableManager
        # because VariableManager is not a new-style class
        def __init__(self):
            pass

        def get_hostvars(self, host):
            return (id(self._hostvars), id(host))

    variable_manager2 = VariableManager2()
    variable_manager2._hostvars = None
    variable_

# Generated at 2022-06-21 09:36:56.136050
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    # This unit test can be improved if we test with a real
    # Host instance, but we have no idea how to do it.
    # So we just verify that the method is not raising exceptions
    # and variables are being updated as expected.

    loader = object()
    variable_manager = object()
    inventory = object()
    hostvars = HostVars(inventory, variable_manager, loader)

    host = object()
    facts = {'fact1': 'value1', 'fact2': 'value2'}

    hostvars.set_host_facts(host, facts)

    # Do not call methods of class HostVars because it is not
    # important. Just verify that the host has been updated by
    # the method.
    # Note that the following does not work:
    #   assert host.vars['fact1'] == '

# Generated at 2022-06-21 09:37:01.743788
# Unit test for method __contains__ of class HostVars
def test_HostVars___contains__():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    vars_manager = HostVars(inventory, loader)

    assert "127.0.0.1" in vars_manager

# Generated at 2022-06-21 09:37:09.903239
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Creating fake inventory hosts
    class Host(object):
        def __init__(self, name='', vars={}):
            self.name = name
            self.vars = vars
    fake_hosts = [Host('localhost', dict(localhost_test='localhost_test_value')),
                  Host('remotehost', dict(remotehost_test='remotehost_test_value'))]
    # Creating fake inventory and assigning hosts
    class Inventory(object):
        def __init__(self):
            self.hosts = []
        def __iter__(self):
            return self.hosts.__iter__()
        get_host = lambda self, host_name: next((host for host in self.hosts if host.name == host_name), None)
    fake_inventory = Inventory()