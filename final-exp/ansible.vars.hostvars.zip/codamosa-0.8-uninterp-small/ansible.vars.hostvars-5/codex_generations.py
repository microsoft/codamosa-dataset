

# Generated at 2022-06-25 14:05:27.252964
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = 'm'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)

    # Spoof a changed hostvars object
    host_vars_0._loader = dict_0

    # assertEquals(obj1, obj2)



# Generated at 2022-06-25 14:05:31.726402
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    try:
        str_0 = 'asdf'
        dict_0 = {}
        host_vars_0 = HostVars(str_0, dict_0, dict_0)
        print(host_vars_0['asdf'])
    except:
        print('HostVars::__getitem__ raised Exception')


# Generated at 2022-06-25 14:05:35.266230
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars_0 = HostVars()
    try:
        assert repr(host_vars_0) is not None
    except AssertionError as e:
        raise AssertionError(str(e))


# Generated at 2022-06-25 14:05:39.539541
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    state = {}
    host_vars_0.__setstate__(state)


# Generated at 2022-06-25 14:05:47.402844
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    dict_1 = {}
    loader_0 = {}
    ansible_1 = {}
    variable_manager_0 = {}
    variable_manager_0 = {}
    variable_manager_0._loader = loader_0
    variable_manager_0._hostvars = None
    variable_manager_0._fact_cache = ansible_1
    dict_1['_variable_manager'] = variable_manager_0
    dict_1['_inventory'] = {}
    dict_1['_loader'] = loader_0
    host_vars_0 = HostVars('', '', '')
    host_vars_0.__setstate__(dict_1)
    str_0 = '='
    str_1 = ''
    dict_0 = {}
    dict_0['a'] = str_1

# Generated at 2022-06-25 14:05:50.829552
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    assert repr(host_vars_0) == "{}"


# Generated at 2022-06-25 14:05:53.637521
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    state_0 = {}
    HostVars.__setstate__(state_0)


# Generated at 2022-06-25 14:05:55.239493
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    HostVarsVars.__iter__()


# Generated at 2022-06-25 14:05:59.901823
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    str_0 = 'W'
    dict_0 = {}
    host_vars_vars_0 = HostVarsVars(str_0, dict_0)
    str_1 = 'x'
    str_0 = host_vars_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 14:06:05.223408
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    str_1 = 'fridolf_'
    dict_1 = host_vars_0.raw_get(str_1)
    return dict_1

test_case_0()

test_HostVars_raw_get()

# Generated at 2022-06-25 14:06:22.439874
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    dest_0 = set()
    var_0 = 'localhost'
    var_1 = {'host_1': 'host_1', 'host_2': 'host_2'}
    var_2 = {'group_1': 'group_1', 'group_2': 'group_2'}
    inventory = Inventory(loader=None, variable_manager=None, host_list=None)
    inventory.add_host(var_0)
    for hostn in var_1.keys():
        inventory.add_host(hostn)
        inventory.get_host(hostn).set_variable('ansible_host', var_1[hostn])

# Generated at 2022-06-25 14:06:30.914193
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    var_0 = {}
    var_0['var_1'] = 'what'

    var_2 = HostVarsVars(var_0, 'loader_3')
    var_4 = {}
    for var_5 in var_2:
        var_4[var_5] = var_2[var_5]

    assert var_4 == {'var_1': 'what'}

    var_1 = 'what'
    var_6 = var_1 in var_2

    assert var_6 == True
    assert len(var_2) == 1
    assert repr(var_2) == "{'var_1': 'what'}"


# Generated at 2022-06-25 14:06:33.211118
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    for index in range(10):
        var_0 = {}
        var_0 = HostVars(var_0)
        var_0.__iter__()


# Generated at 2022-06-25 14:06:37.418365
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
  inventory = {}
  variable_manager = {}
  loader = {}
  hostvars = HostVars(inventory, variable_manager, loader)
  host_name = "test_case_0"
  result = hostvars.raw_get(host_name)
  assert result == {}, "Incorrect HostVars_raw_get result"


# Generated at 2022-06-25 14:06:38.357556
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    assert test_case_0() == {}


# Generated at 2022-06-25 14:06:40.352418
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    hostvars = HostVars(None, None, None)
    hostvars.__setstate__({})


# Generated at 2022-06-25 14:06:44.557942
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Create an instance of class HostVars with dummy arguments
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    # Try to restore the state of HostVars by calling method __setstate__
    # with a dummy state
    hv.__setstate__(state={'_key': '_value'})


# Generated at 2022-06-25 14:06:46.832647
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    ansible.hostvars.hostvars.HostVars.raw_get(hostvars, 'test_host')

# Generated at 2022-06-25 14:06:50.417169
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    hv_state = {'_inventory': {}, '_loader': {}, '_variable_manager': {}}

    hv = HostVars()
    hv.__setstate__(hv_state)

    assert hv._inventory == hv_state['_inventory']
    assert hv._loader == hv_state['_loader']
    assert hv._variable_manager == hv_state['_variable_manager']

# Generated at 2022-06-25 14:06:55.143915
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    hostvars = HostVars(None, None, None)
    state_0 = {'_inventory': '_inventory_0', '_loader': '_loader_0', '_variable_manager': '_variable_manager_0'}
    hostvars.__setstate__(state_0)



# Generated at 2022-06-25 14:07:03.075455
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    test_case_0()


# Generated at 2022-06-25 14:07:03.877922
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = {}



# Generated at 2022-06-25 14:07:07.937991
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = []
    var_1 = test_case_0()
    var_2 = HostVars(var_0,var_1,var_1)
    var_3 = var_2.__iter__()



# Generated at 2022-06-25 14:07:08.944902
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    test_case_0()


# Generated at 2022-06-25 14:07:11.922647
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = HostVars
    host_name = None
    foo = var_0.raw_get(host_name)
    assert foo is not AnsibleUndefined


# Generated at 2022-06-25 14:07:23.183068
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    var_13 = {}
    var_14 = {}
    var_15 = {}
    var_16 = {}
    var_17 = {}
    var_18 = {}
    var_19 = {}
    var_20 = {}
    var_21 = {}
    var_22 = {}
    var_23 = {}
    var_24 = {}
    var_25 = {}
    var_26 = {}
    var_27 = {}
    var_28 = {}
    var_

# Generated at 2022-06-25 14:07:24.977319
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = {}
    assert set(var_0) == set()
    assert len(var_0) == 0


# Generated at 2022-06-25 14:07:33.226084
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    var_0 = var_0 # type: Dict[str, Any]

    # Constraint check for variable 'var_0'
    # Verify that type of argument is dictionary
    if not isinstance(var_0, dict):
        raise AssertionError("Argument type mismatch for argument 'var_0'. Expected 'dict'. Got '%s'." % (type(var_0)))

    # Call method __getitem__ of class HostVars with args (var_0)
    HostVars.__getitem__(var_0)



# Generated at 2022-06-25 14:07:43.139686
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = HostVars(None, None, None)
    var_0._find_host = lambda x: b'case_0'
    var_0._variable_manager = VariableManager()
    ret0 = var_0.raw_get(b'localhost')
    assert ret0 == b'case_0'

    var_1 = HostVars(None, None, None)
    var_1._find_host = lambda x: b'case_1'
    var_1._variable_manager = VariableManager()
    ret1 = var_1.raw_get(b'localhost')
    assert ret1 == b'case_1'

    var_2 = HostVars(None, None, None)
    var_2._find_host = lambda x: b'case_2'
    var_2._variable_manager = Variable

# Generated at 2022-06-25 14:07:46.199585
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Setup test
    var_0 = {}
    var_1 = HostVars(var_0)
    # Test method
    data = var_1.raw_get(var_0)
    assert var_1._hostvars == data


# Generated at 2022-06-25 14:07:54.667846
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    var_1 = None
    # function call on line 48
    var_0 = test_case_0()
    # assert statements on line 48
    try:
        assert (var_0 == var_1)
    except AssertionError as e:
        raise AssertionError(str(e) + format(var_0))



# Generated at 2022-06-25 14:07:57.544448
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    out = {}
    for host in self._inventory.hosts:
        out[host] = self.get(host)
    return repr(out)


# Generated at 2022-06-25 14:07:59.913530
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = HostVars()
    assert var_0.__getitem__(self, var_0).__class__ is AnsibleUndefined


# Generated at 2022-06-25 14:08:03.598190
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = None
    variable_manager = None
    loader = None
    hostvars = HostVars(inventory, variable_manager, loader)
    assert isinstance(hostvars.raw_get(host_name=None), dict) == True


# Generated at 2022-06-25 14:08:05.547015
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = {}
    test_obj = HostVars(var_0)
    var_1 = test_obj.__iter__()
    assert len(var_1) == 0


# Generated at 2022-06-25 14:08:15.578648
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = {}
    var_0['test_inventory'] = MockInventoryManager()
    var_0['variable_manager'] = MockVariableManager()
    var_0['loader'] = MockLoader()
    var_0['hostvars'] = HostVars(var_0['test_inventory'], var_0['variable_manager'], var_0['loader'])
    var_0['test_host1'] = MockHost(name='test_host1')
    var_0['test_host2'] = MockHost(name='test_host2')
    result = list(var_0['hostvars'])
    assert (var_0['test_host1'] in result and var_0['test_host2'] in result)


# Generated at 2022-06-25 14:08:16.469574
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {}


# Generated at 2022-06-25 14:08:17.958138
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {}
    # var_0 = HostVars
    return var_0


# Generated at 2022-06-25 14:08:22.142153
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    log('Calling test_HostVarsVars___iter__()')
    test_case_0()
    test_case_0()
    log('Test case 0 finished')

if __name__ == '__main__':
    test_HostVarsVars___iter__()

# Generated at 2022-06-25 14:08:24.465336
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    assert 'foo' in var_0
    assert list(var_0) == ['foo']


# Generated at 2022-06-25 14:08:34.460533
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = None
    HostVars(var_0, var_0, var_0)

# Generated at 2022-06-25 14:08:36.085142
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    for var_1 in HostVarsVars(var_0, ):
        var_0 = var_1

# Generated at 2022-06-25 14:08:43.447984
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # This test case returns a dict with two keys:
    # foo1: value1
    # foo2: value2
    #
    # The value of foo2 is:
    # foo1: value1
    # foo2: value2
    #
    # HostVars_raw_get has a lot of nested dicts, and the point is that we
    # need to get all of them.
    var_0 = {}
    var_0["foo2"] = var_0
    var_0["foo1"] = "value1"
    var_0["foo2"]["foo2"] = "value2"
    var_0["foo2"]["foo1"] = var_0["foo1"]
    expected_0 = var_0
    hv_0 = HostVars(None, None, None)
    # '

# Generated at 2022-06-25 14:08:44.800489
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    var_0 = HostVarsVars()
    assert (var_0.__iter__() == [])

# Generated at 2022-06-25 14:08:46.268902
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    hv = HostVars(var_0)
    repr(hv)


# Generated at 2022-06-25 14:08:49.291017
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    test_case_0()
    instance = HostVars()
    class_ = instance.__class__
    result = hasattr(class_, "__setstate__")
    assert result is True


# Generated at 2022-06-25 14:08:51.260967
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_1 = HostVars(None, None, None)
    print(var_1.__repr__())


# Generated at 2022-06-25 14:08:54.363015
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    h = HostVars({'a': 1, 'b': 2})
    result_1 = h['a']
    result_2 = h['b']
    assert result_1 == 1
    assert result_2 == 2


# Generated at 2022-06-25 14:09:05.204859
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    global vars_cache
    vars_cache = {}
    #Test 1
    var_0 = {}
    hostvars = HostVars(var_0)
    hostvars['foo'] = 'bar'
    #Test 2
    var_0 = {}
    hostvars = HostVars(var_0)
    hostvars['foo'] = 'toast'
    hostvars[host.get_name()] = 'myhost'
    hostvars['foo'] = 'bar'
    #Test 3
    var_0 = {}
    hostvars = HostVars(var_0)
    hostvars['foo'] = 'toast'
    hostvars[host.get_name()] = 'myhost'
    hostvars['foo'] = 'bar'
    hostvars.raw_get

# Generated at 2022-06-25 14:09:06.113753
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    test_case_0()


# Generated at 2022-06-25 14:09:19.103166
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    failure_exception = None
    try:
        test_case_0()
    except Exception as e:
        failure_exception = e
    assert failure_exception is None, '__iter__ of HostVars produced an exception: '+str(failure_exception)


# Generated at 2022-06-25 14:09:20.692146
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    test_case_0()



# Generated at 2022-06-25 14:09:21.931036
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Test each of the following statements individually
    pass

# Generated at 2022-06-25 14:09:30.307789
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    def __getitem__(self, host_name):
        host = self._find_host(host_name)
        if host is None:
            return AnsibleUndefined(name="hostvars[%s]" % host_name)
        return self._variable_manager.get_vars(host=host, include_hostvars=False)

    def __setstate__(self, state):
        self.__dict__.update(state)

        # Methods __getstate__ and __setstate__ of VariableManager do not
        # preserve _loader and _hostvars attributes to improve pickle
        # performance and memory utilization. Since HostVars holds values
        # of those attributes already, assign them if needed.
        if self._variable_manager._loader is None:
            self._variable_manager._loader = self._loader


# Generated at 2022-06-25 14:09:32.469349
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    assert callable(HostVarsVars.__iter__)
    assert hasattr(HostVarsVars, '__iter__')
    assert isinstance(HostVarsVars.__iter__, types.MethodType)

# Generated at 2022-06-25 14:09:36.413446
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = {}
    var_1 = HostVars(var_0)
    test_case_0()
    assert var_1.__repr__() == '{}'


# Generated at 2022-06-25 14:09:46.539162
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    loader_0 = DictDataLoader()
    hostvars_0 = HostVars(loader_0, var_0)
    def test_HostVars___getitem__0():
        input = "inventory_hostname"
        actual = hostvars_0[input]
        expected = AnsibleUndefined()
        assert actual == expected, "'hostvars[inventory_hostname]' should be AnsibleUndefined but was %s" % actual
    def test_HostVars___getitem__1():
        input = "inventory_hostname_short"
        actual = hostvars_0[input]
        expected = AnsibleUndefined()
        assert actual == expected, "'hostvars[inventory_hostname_short]' should be AnsibleUndefined but was %s" % actual

# Generated at 2022-06-25 14:09:48.788209
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    var_1 = HostVars(None, None, None)
    HostVars(var_0, var_0, var_0)
    return var_1

# Generated at 2022-06-25 14:09:56.168956
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # setup var_0
    var_0 = {}

    # run test_0
    t0_HostVars = HostVars(var_0,var_0,var_0)
    host_name = 'test_case_0'
    result = t0_HostVars.__getitem__(host_name)
    expected_result = None

    if result != expected_result:
        raise Exception("in test_0 of HostVars.__getitem__, Expected result was '%s' but got '%s'\n" % (expected_result, result))

    # cleanup test_0 vars
    del var_0
    del host_name
    del result
    del expected_result
    del t0_HostVars


# Generated at 2022-06-25 14:09:59.057510
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = {}

    # Expected Value
    expected = {}

    assert HostVars._HostVars__raw_get("", var_0) == expected


# Generated at 2022-06-25 14:10:10.057139
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    host_vars_0.__getitem__('W')


# Generated at 2022-06-25 14:10:15.410115
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Test with invalid parameter
    try:
        str_0 = ""
        dict_0 = {}
        host_vars_0 = HostVars(str_0, dict_0, dict_0)
        host_vars_0.__repr__()
    except Exception as e:
        print("Exception caught:\n" + str(e))
    else:
        raise RuntimeError("Expected exception but no exception was raised")


# Generated at 2022-06-25 14:10:21.074070
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = 'co-operation'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    iter_0 = host_vars_0.__iter__()
    assert(str(iter_0) == '<iterator object at 0x000001F5C9D036C8>')


# Generated at 2022-06-25 14:10:25.184798
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_name = 'localhost'
    data = host_vars.raw_get(host_name)
    assert(data == 'ansible')
    data = host_vars.raw_get('not_localhost')
    assert(data == 'None')


# Generated at 2022-06-25 14:10:28.084838
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'W'
    dict_0 = {}
    host_vars_vars_0 = HostVarsVars(dict_0, str_0)
    iter_0 = host_vars_vars_0.__iter__()
    try:
        list_0 = list(iter_0)
    except StopIteration:
        pass


# Generated at 2022-06-25 14:10:29.901422
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_1 = HostVars()
    for i in host_vars_1:
        pass


# Generated at 2022-06-25 14:10:32.272602
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVarsVars(str_0, dict_0)
    host_vars_0.__iter__()


# Generated at 2022-06-25 14:10:35.141773
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = 'wH'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    for host in host_vars_0:
        print(host)

test_case_0()
test_HostVars___iter__()

# Generated at 2022-06-25 14:10:38.141762
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'G'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    repr_0 = host_vars_0.__repr__()
    assert repr_0 is not None


# Generated at 2022-06-25 14:10:45.589081
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = '!0J4&o*h=a@Z}[+sCXOxJT~h?x'
    str_1 = '^'
    dict_0 = {}
    str_2 = ''
    host_vars_0 = HostVars(str_0, dict_0, str_1)
    ansible_undefined_0 = host_vars_0.raw_get(str_2)
    assert (ansible_undefined_0 is not None)


# Generated at 2022-06-25 14:11:03.850576
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '<H\x89\x91\xa0g?\xbe'

# Generated at 2022-06-25 14:11:09.489862
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_1 = 'W'
    dict_1 = {}
    host_vars_1 = HostVars(str_1, dict_1, dict_1)
    str_2 = 'q'
    host_vars_2 = host_vars_1.raw_get(str_2)


# Generated at 2022-06-25 14:11:17.688226
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    dict_0 = {}
    dict_1 = {}
    hv_0 = HostVars(dict_0, dict_0, dict_1)
    hv_1 = HostVars(dict_0, dict_0, dict_1)
    hv_2 = HostVars(dict_0, dict_0, dict_0)
    hv_3 = HostVars(dict_1, dict_0, dict_0)
    hv_4 = HostVars(dict_0, dict_1, dict_0)
    hv_5 = HostVars(dict_0, dict_0, dict_0)
    hv_6 = HostVars(dict_0, dict_0, dict_0)
    hv_7 = HostVars(dict_0, dict_0, dict_1)
   

# Generated at 2022-06-25 14:11:24.606521
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '<'

# Generated at 2022-06-25 14:11:29.093197
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = '.'
    dict_0 = {}
    var_0 = HostVars(str_0, dict_0, dict_0)
    temp_0 = var_0.__iter__()
    var_0.__iter__()
    # temp_0.__next__()


# Generated at 2022-06-25 14:11:34.748783
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    vars_manager = VariableManager()
    hosts = ['localhost']
    vars_manager._hostvars = {}
    vars_manager.add_host_vars(host=hosts[0], host_vars={'var': 'value'})
    hosts_iter = vars_manager._hostvars.__iter__()
    try:
        hosts_iter.__next__()
    except StopIteration:
        pass


# Generated at 2022-06-25 14:11:41.161541
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # get the method to test
    str_0 = 'g'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    int_0 = 1
    dict_1 = {}
    dict_1['state'] = int_0
    # host_vars_0.__setstate__(dict_1)
    try:
        assert host_vars_0._variable_manager._hostvars == host_vars_0
    except AssertionError:
        raise AssertionError('host_vars_0._variable_manager._hostvars != host_vars_0')
    try:
        assert host_vars_0._variable_manager._loader == host_vars_0._loader
    except AssertionError:
        raise Ass

# Generated at 2022-06-25 14:11:49.817651
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Init object
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)

    # Test function
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    str_1 = 'h'
    dict_1 = {}
    host_vars_1 = HostVars(str_1, dict_1, dict_1)
    host_vars_1.__getitem__(str_0)



# Generated at 2022-06-25 14:11:57.344359
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'localhost'
    dict_0 = {'ping_0': {'tags': {'structure': 'lQ65d', 'systemctl': 's'}}, 'ping_4': {'tags': {'structure': 'aOC6i', 'systemctl': 's'}}, 'ping_1': {'tags': {'structure': 'lQ65d', 'systemctl': 's'}}, 'ping_2': {'tags': {'structure': 'lQ65d', 'systemctl': 's'}}, 'ping_3': {'tags': {'structure': 'lQ65d', 'systemctl': 's'}}}

# Generated at 2022-06-25 14:12:04.631563
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = '^_M'
    str_1 = ';3tF*Omr'
    str_2 = '+'
    str_3 = '8Qlyf"<'
    str_4 = '-s0sF+'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, str_1, str_2)
    assert host_vars_0.raw_get(str_3) is AnsibleUndefined
    assert host_vars_0.raw_get(str_4) is AnsibleUndefined


# Generated at 2022-06-25 14:12:26.187380
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    assert True == True


# Generated at 2022-06-25 14:12:29.114327
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'WZ'
    dict_0 = {}
    host_vars_0 = HostVars(dict_0, dict_0, dict_0)
    host_vars_1 = host_vars_0[str_0]


# Generated at 2022-06-25 14:12:35.265979
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    param_0 = 'ansible_host'
    str_0 = 'inventory_hostname'
    param_1 = 'ansible_hosts'
    dict_0 = {}
    dict_0[str_0] = str_0
    dict_0[param_1] = str_0
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    str_1 = str_0
    str_2 = 'localhost'
    str_3 = str_1
    param_2 = host_vars_0.raw_get(str_2)
    assert param_2.pop(param_0) == str_3


# Generated at 2022-06-25 14:12:38.910161
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'V'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    # There is no variable str_0, so the method should return an AnsibleUndefined value
    ansible_undefined_0 = host_vars_0.raw_get(str_0)
    assert(ansible_undefined_0.__str__() == "hostvars['V']")


# Generated at 2022-06-25 14:12:42.957318
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    set_trace()
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    str_1 = '.'
    str_2 = '&'
    vars = host_vars_0[str_1]
    result = vars[str_2]
    assert result == None



# Generated at 2022-06-25 14:12:45.672636
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    str_1 = ''
    assert host_vars_0.raw_get(str_1) == 'undefined'


# Generated at 2022-06-25 14:12:48.732156
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '@@'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    str_1 = 'psb4zDZ'
    value_0 = host_vars_0[str_1]


# Generated at 2022-06-25 14:12:56.098920
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Variable for test case
    str_0 = '3MYu'
    str_1 = 'host_0'
    str_2 = 'I-'
    int_0 = 9383
    str_3 = 'I'
    str_4 = '1'
    str_5 = 'A'
    str_6 = 'T_F'
    str_7 = '/'
    str_8 = 'C'
    str_9 = 'B'
    str_10 = 'g'
    str_11 = 'D'
    str_12 = '-'
    dict_0 = {}
    dict_1 = {}
    str_13 = 'S_F'
    str_14 = 'inventory_host'
    str_15 = '9'

    # Setup
    str_0 = '3MYu'
    dict_

# Generated at 2022-06-25 14:12:58.502202
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = HostVars('X9', 'S^', '~')
    str_0 = 'dV'
    ansible_undefined_0 = host_vars_0.raw_get(str_0)


# Generated at 2022-06-25 14:12:59.304868
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    test_case_0()

# Generated at 2022-06-25 14:13:47.976439
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    for expected, actual in zip(host_vars_0, host_vars_0.__iter__()):
        assert actual == expected


# Generated at 2022-06-25 14:13:52.032134
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    result = None
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    isinstance(host_vars_0, [].__class__)
    result = host_vars_0.__iter__()
    assert result == "<generator object iter at 0x10c3dea50>"

# Generated at 2022-06-25 14:13:55.695286
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = '3Fo?:'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    assert_equal(list(host_vars_0), list({'6!', 'YdN_', '-AL78', 'W:', '', 'F=!G'}))


# Generated at 2022-06-25 14:13:58.624597
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
  str_0 = 'q'
  dict_0 = {}
  host_vars_0 = HostVars(str_0, dict_0, dict_0)
  assert host_vars_0.__repr__() == '{}'


# Generated at 2022-06-25 14:14:02.336583
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '<'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    str_1 = '1'
    test_result = host_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 14:14:05.309584
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = 'W'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    host_vars_0.__setstate__(dict_0)


# Generated at 2022-06-25 14:14:14.244365
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    dict_0 = {}
    dict_1 = {'role1': ['a'], 'role2': ['c']}
    dict_2 = {'role1': ['a'], 'role2': ['c']}
    dict_3 = {'role2': ['c'], 'role1': ['a']}
    dict_4 = {'list': [[1, 2, 3]], 'tuple': [(1, 2, 3)], 'dict': [{'a': 'a'}], 'str': ['str'], 'int': [1], 'bool': [True]}
    dict_5 = {'list': [[1, 2, 3]], 'tuple': [(1, 2, 3)], 'dict': [{'a': 'a'}], 'str': ['str'], 'int': [1], 'bool': [True]}

# Generated at 2022-06-25 14:14:18.724434
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'u%'
    dict_0 = {}
    host_vars_0 = HostVars(str_0, dict_0, dict_0)
    str_1 = '9'
    with pytest.raises(TypeError):
        host_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 14:14:25.979287
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
        str_0 = '''
'''
        str_1 = str_0
        str_2 = str_0
        dict_0 = {}
        dict_1 = dict_0
        host_vars_0 = HostVars(str_1, dict_0, dict_1)
        str_3 = '\''
        str_4 = ' '
        str_5 = ')'
        str_6 = ' '
        str_7 = ','
        str_8 = ' '
        str_9 = '{'
        str_10 = '}'
        str_11 = '\''
        str_12 = ' '
        str_13 = ']'
        str_14 = '.'
        str_15 = '.'
        str_16 = ' '
        str_17 = '\''
        str_18

# Generated at 2022-06-25 14:14:29.328848
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_name_0 = None
    host_vars_0 = None
    try:
        host_vars_0 = HostVars(host_name=host_name_0)
        host_vars_0[host_name_0]
    except:
        pass
    finally:
        if host_vars_0:
            host_vars_0.__exit__()
