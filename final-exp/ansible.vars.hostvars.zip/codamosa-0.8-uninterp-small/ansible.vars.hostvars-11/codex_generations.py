

# Generated at 2022-06-25 14:05:35.575428
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    print('Testing __iter__')
    str_0 = ''
    float_0 = -462.119756360734
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    # Testing __iter__
    host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:05:39.491553
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_name = ''
    host_vars_0 = HostVars(host_name, host_name, host_name)
    try:
        host_vars_0['utf-8']
    except:
        pass


# Generated at 2022-06-25 14:05:43.388612
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = str('')
    float_0 = float(-462.119756360734)
    host_vars_0 = HostVars(str_0, str_0, float_0)
    str_1 = str('')
    host_vars_0.__setstate__(str_1)


# Generated at 2022-06-25 14:05:46.393628
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = ''
    float_0 = -462.119756360734
    host_vars_vars_0 = HostVarsVars(str_0, float_0)


# Generated at 2022-06-25 14:05:53.428554
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    array_0 = ['iZMq3^D', 'ZYB', 'jd1v', '9HW', 'jn', 'z', 'cw']
    float_0 = -5.20892E+22
    int_0 = -90
    str_0 = 'V'
    host_vars_0 = HostVars(array_0, float_0, str_0)
    host_vars_0.raw_get(int_0)


# Generated at 2022-06-25 14:05:55.916232
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = host_vars_vars_0.raw_get(int_0)


# Generated at 2022-06-25 14:06:02.628935
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = ''
    float_0 = 0.7416955713157241
    str_1 = ''
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    templar_0 = Templar(str_1, float_0)
    str_2 = repr(templar_0.template(str_1, False, STATIC_VARS))
    assert str_2 == repr(host_vars_vars_0)


# Generated at 2022-06-25 14:06:08.427519
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = 'qc%^I?C]c%]0DfR|;p@VEs'
    str_1 = 'wY>|^t/8/tW%c'
    float_0 = -976.8492364961414
    host_vars_0 = HostVars(str_0, str_1, float_0)
    host_vars_0.__setstate__(str_1)


# Generated at 2022-06-25 14:06:14.385080
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = ''
    float_0 = -462.119756360734
    inventory_0 = Inventory(str_0, False, False)
    hostvars_0 = HostVars(inventory_0, None, None)
    ternary_operator_0 = hostvars_0

    test_choice_0 = []
    if ternary_operator_0 is None:
        test_choice_0.append(str_0)
    else:
        test_choice_0.append(float_0)

    hostvars_0.__setstate__(test_choice_0)


# Generated at 2022-06-25 14:06:23.856780
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    
    host_vars_0 = HostVars(str_0, float_0, host_vars_vars_0)
    str_0 = 'mR:.51d'
    int_0 = 1
    str_1 = 'Wf5'
    float_1 = -33
    float_2 = -8476.7
    int_1 = 0
    str_2 = ''
    int_2 = 1
    str_3 = '6v)'
    str_4 = '>I[zJ'
    str_5 = 'a{:+'
    list_0 = [str_3, str_1, str_4, str_0]
    str_6 = '*_Mt.et'
    str_7 = 'T['
    str_8 = ',H$'
    str_

# Generated at 2022-06-25 14:06:46.743216
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = 1620
    host_vars_vars_0 = HostVarsVars(int_0, int_0)


# Generated at 2022-06-25 14:06:53.386290
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Unit test for method __setstate__ of class HostVars
    #
    # Not testable because HostVars holds references to the inventory,
    # variable_manager, loader and templar, thus requiring some additional
    # refactoring to make the method testable.
    # TODO: Refactor HostVars as part of issue #26632

    pass


# Generated at 2022-06-25 14:06:56.957110
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    for test_case in (test_case_0, ):
        test_case()

if __name__ == '__main__':
    for test_case in (test_case_0, ):
        test_case()

# Generated at 2022-06-25 14:07:00.924926
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    aClass = HostVars(None, None, None)

    # Call method __getitem__ with invalid data
    try:
        aClass.__getitem__(None)
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError")


# Generated at 2022-06-25 14:07:03.890237
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    str_0 = '5'
    try:
        host_vars_vars_0[str_0]
    except NameError:
        pass


# Generated at 2022-06-25 14:07:13.966432
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    inventory = None
    variable_manager = None
    loader = None
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    # This should raise an exception due to inventory is None
    try:
        host_vars_0["s"]
    except:
        assert True
    else:
        assert False
    inventory = None
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    # This should not raise an exception
    try:
        host_vars_0["s"]
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 14:07:19.575208
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    # Check that KeyError exception is raised by __iter__
    # when mapping doesn't have the key
    host_vars_0 = HostVars(int_0, int_0, int_0)
    with pytest.raises(KeyError) as excinfo:
        host_vars_0.__iter__()
    assert excinfo.value.args[0] == int_0


# Generated at 2022-06-25 14:07:22.918415
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    for host_vars in host_vars_vars_0:
        pass


# Generated at 2022-06-25 14:07:28.605714
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    for test_num in range(1):

        if test_num == 0:
            # Test case 0
            int_0 = -1177
            host_vars_vars_0 = HostVarsVars(int_0, int_0)
            result_0 = host_vars_vars_0.__iter__()
            assert result_0 == None


# Generated at 2022-06-25 14:07:33.601713
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    try:
        host_vars_vars_0.__getitem__(']BfwC#SjX')
    except KeyError as e:
        pass
    else:
        assert False


# Generated at 2022-06-25 14:07:53.311237
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)


# Generated at 2022-06-25 14:07:58.944143
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = -1177
    host_vars_0 = HostVars(int_0, int_0, int_0)
    assert repr(host_vars_0) == '{}'
    assert repr(host_vars_0) == '{}'
    assert repr(host_vars_0) == '{}'


# Generated at 2022-06-25 14:08:06.988235
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = -1177
    host_vars_0 = HostVars(int_0, int_0, int_0)
    host_vars_0.__setstate__((int_0, int_0, int_0))
    int_1 = 1153
    str_0 = "item"
    str_1 = "item"
    host_vars_0.set_nonpersistent_facts(str_0, str_1)
    host_vars_0.set_host_variable(str_0, str_1, int_1)
    host_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 14:08:15.796978
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Set the expected value for the variable foo
    foo = 42

    # The value to be tested for the variable bar
    bar = foo

    # Check it
    if foo == bar:
        print("The test for foo has passed correctly")
    else:
        print("The test for foo has failed")

    # Set the expected value for the variable baz
    baz = 9001

    # The value to be tested for the variable qux
    qux = baz

    # Check it
    if baz == qux:
        print("The test for baz has passed correctly")
    else:
        print("The test for baz has failed")

# Generated at 2022-06-25 14:08:17.291542
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    # Call method
    host_vars_0 = HostVars(int_0, int_0, int_0)

    host_vars_0.__setstate__


# Generated at 2022-06-25 14:08:20.610804
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 77
    int_1 = -1
    int_2 = -99

    host_vars_0 = HostVars(int_0, int_1, int_2)
    temp_var_0 = host_vars_0.__repr__()
    assert temp_var_0


# Generated at 2022-06-25 14:08:21.235985
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    pass

# Generated at 2022-06-25 14:08:29.500771
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

	# Setup
	host_vars_0 = HostVars(int_0, int_0)
	foo_0 = host_vars_0.raw_get(int_0)

	# Execution
	host_vars_vars_0 = HostVarsVars(int_0, int_0)
	foo_0 = host_vars_vars_0.raw_get(int_0)

	# Verification

	# Cleanup
	del host_vars_vars_0
	del host_vars_0


# Generated at 2022-06-25 14:08:39.104927
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = -2274
    int_1 = -1085
    int_2 = 3
    int_3 = -376
    int_4 = 84
    float_0 = -4.8245972
    host_0 = Group()
    group_0 = Group()
    group_0.name = 'confluent'
    group_1 = Group()
    group_1.name = int_1
    group_2 = Group()
    group_2.name = 'confluent'
    group_3 = Group()
    group_3.name = int_2
    group_4 = Group()
    group_4.name = int_3
    group_5 = Group()
    group_5.name = int_4
    group_6 = Group()
    group_6.name = -11.9
    group

# Generated at 2022-06-25 14:08:40.245279
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars_vars_0 = HostVarsVars(1343, -1530)


# Generated at 2022-06-25 14:09:14.885216
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = -1177
    HostVars_0 = HostVars(int_0, int_0, int_0)
    for var_0 in HostVars_0:
        pass


# Generated at 2022-06-25 14:09:23.617411
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = -1177
    tmp_0 = -2030
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    host_vars_0 = HostVars(int_0, tmp_0, int_0)
    host_vars_0.set_variable_manager(tmp_0)
    host_vars_0.set_inventory(int_0)
    host_vars_0.__getitem__(int_0)
    host_vars_vars_0.__getitem__(int_0)


# Generated at 2022-06-25 14:09:31.516829
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    generator_0 = host_vars_vars_0.__iter__()
    assert_equal(isinstance(generator_0, types.GeneratorType), True)
    assert_equal(next(generator_0), 656)
    assert_equal(next(generator_0), 25)
    assert_equal(next(generator_0), 1789)
    assert_equal(next(generator_0), 2077)
    assert_equal(next(generator_0), 889)
    assert_equal(next(generator_0), 69)
    assert_equal(next(generator_0), 717)

# Generated at 2022-06-25 14:09:42.173711
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    HostVarsVars.__getitem__(host_vars_vars_0, int_0)


    # Test with an undefined host name
    int_0 = -1177
    host_vars_0 = HostVars(int_0, int_0, int_0)
    AnsibleUndefined.__str__(HostVars.raw_get(host_vars_0, int_0))

    # Test with a defined host name
    int_0 = -1177
    host_vars_1 = HostVars(int_0, int_0, int_0)

# Generated at 2022-06-25 14:09:46.500233
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    host_vars_0 = HostVars(int_0, int_0, int_0)
    host_vars_0.__setstate__(int_0)


# Generated at 2022-06-25 14:09:50.340137
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test for __iter__ method
    #atmfjstc-HostVars_8
    int_0 = -3019
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:09:52.660671
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 7604
    host_vars_0 = HostVars(int_0, int_0, int_0)
    host_vars_0.__iter__()


# Generated at 2022-06-25 14:09:59.191288
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = -1596
    host_vars_vars_0 = HostVarsVars(int_0, str_0)
    templar_0 = Templar(host_vars_vars_0, loader_0)
    int_1 = len(host_vars_vars_0)
    str_1 = repr(host_vars_vars_0)
    list_0 = list(host_vars_vars_0)
    int_2 = len(list_0)
    str_2 = repr(list_0)
    list_1 = list(list_0)
    int_3 = len(list_1)
    str_3 = repr(list_1)
    list_2 = list(list_1)
    int_4 = len(list_2)
    str

# Generated at 2022-06-25 14:10:00.734051
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Test for __iter__ of class HostVarsVars
    test_case_0()


# Generated at 2022-06-25 14:10:09.936522
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = -1035
    host_vars_0 = HostVars(int_0, int_0, int_0)
    str_0 = '!'
    host_name = '.'
    str_1 = '.'
    bool_0 = bool()
    bool_0 = isinstance(str_1, str)
    bool_0 = host_name is str_1
    bool_1 = bool()
    bool_1 = host_name != host_name
    if bool_0 and bool_1:
        str_1 = str()
        str_1 = host_name.replace(str_0, str_1)
    bool_0 = bool()
    bool_0 = isinstance(str_0, str)
    bool_0 = bool_0 and bool_1
    bool_1 = bool()
   

# Generated at 2022-06-25 14:11:27.462255
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_vars_0 = HostVars(int(), int(), int())
    var_0 = host_vars_vars_0.raw_get(str())
    assert var_0 == AnsibleUndefined(name="hostvars['str()']")


# Generated at 2022-06-25 14:11:36.219123
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    int_0 = -1213
    int_0 = -1267
    int_1 = -1005
    tuple_0 = (int_1, int_0, int_0, int_1)
    tuple_0 = (int_1, int_1, int_1, int_1)
    int_2 = -1098
    int_3 = -1219
    int_4 = -1172
    tuple_1 = (int_4, int_4, int_1, int_2)
    tuple_2 = (int_3, int_1, int_3, int_3)
    tuple_3 = (int_3, int_0, int_0, int_1)
    tuple_4 = (int_2, int_2, int_0, int_1)

# Generated at 2022-06-25 14:11:39.350918
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = -1177
    int_1 = 1859438006
    hostvars_0 = HostVars(int_0, int_1, int_0)
    test_case_0()


# Generated at 2022-06-25 14:11:48.403784
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    #### Tests for method __getitem__ ####
    # Mock class for Templar
    class Templar():

        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def template(self, *args, **kwargs):
            if ('fail_on_undefined' in kwargs.keys()):
                return (args[0], kwargs['fail_on_undefined'], kwargs['static_vars'])
            else:
                return (args[0], kwargs)

    # Instantiate a HostVarsVars object
    test_case_0()


# Generated at 2022-06-25 14:11:52.363516
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    host_vars_0 = HostVars(int_0, int_0, int_0)
    host_vars_vars_0 = host_vars_0.__getitem__(int_0)
    assert isinstance(host_vars_vars_0, HostVarsVars)


# Generated at 2022-06-25 14:11:54.826253
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = -1177
    host_vars_0 = HostVars(int_0, int_0, int_0)
    assert "" == host_vars_0.__repr__()


# Generated at 2022-06-25 14:11:55.859904
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Some tests of that method are implemented in the tasks.
    pass


# Generated at 2022-06-25 14:11:58.909375
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = -211241417
    loader = get_test_loader()
    inventory = get_test_inventory(loader)
    variable_manager = VariableManager(loader)
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    test_case_0(host_vars_0)

# Generated at 2022-06-25 14:12:02.240486
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory_0 = object()
    int_0 = -1191
    loader_0 = object()
    host_vars_0 = HostVars(inventory_0, int_0, loader_0)
    str_0 = str(host_vars_0)
    assert str_0 == "{"


# Generated at 2022-06-25 14:12:11.189396
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    # Create the object
    inventory_0 = InventoryManager(loader=None, sources=['127.0.0.1,1.2.3.4'])
    variables = VariableManager(loader=None, inventory=inventory_0)
    host_vars_0 = HostVars(inventory_0, variables, int_0)

    str_0 = '127.0.0.1'
    host_vars_0.raw_get(str_0)

    # Test exception raised
    with pytest.raises(AnsibleUndefined) as excinfo:
        str_1 = '1.2.3.4'
        host_vars_0.raw_get(str_1)
        assert excinfo.val == AnsibleUndefined


# Generated at 2022-06-25 14:13:41.170211
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = -126
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    assert list(host_vars_vars_0) == [int_0, int_0]
    assert host_vars_vars_0._loader == int_0
    assert host_vars_vars_0._vars == int_0

    int_1 = -18
    host_vars_vars_0 = HostVarsVars(int_1, int_1)
    assert list(host_vars_vars_0) == [int_1, int_1]
    assert host_vars_vars_0._loader == int_1
    assert host_vars_vars_0._vars == int_1

    int_2 = -12

# Generated at 2022-06-25 14:13:44.154781
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    assert host_vars_vars_0.__repr__() == str(int_0)


# Generated at 2022-06-25 14:13:49.014208
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars(int(), int(), int())
    int_0 = -1177
    # TODO: find a way to initialize these mock attributes
    #host_vars_0._inventory = MagicMock()
    #host_vars_0._loader = MagicMock()
    #host_vars_0._variable_manager = MagicMock()

    host_vars_0.__setstate__(int_0)


# Generated at 2022-06-25 14:13:56.633260
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    host_vars_vars_0.__setstate__(int_0)

    host_vars_vars_0.__setstate__(int_0)

    host_vars_vars_0.__setstate__(int_0)

    host_vars_vars_0.__setstate__(int_0)

    host_vars_vars_0.__setstate__(int_0)

    host_vars_vars_0.__setstate__(int_0)

    host_vars_vars_0.__setstate__(int_0)


# Generated at 2022-06-25 14:14:00.765048
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = -1177
    int_1 = -1177
    host_vars = HostVars(int_0, int_0, int_1)
    int_2 = -1177
    host_vars_vars_0 = host_vars.raw_get(int_2)
    del host_vars


# Generated at 2022-06-25 14:14:04.302967
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = -1177
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    boolean_0 = host_vars_vars_0.__iter__()
    assert_equal(host_vars_vars_0, int_0)
    assert_true(boolean_0)


# Generated at 2022-06-25 14:14:06.271791
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = -1177
    host_vars_vars_0 = HostVars(int_0, int_0, int_0)


# Generated at 2022-06-25 14:14:12.841521
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = -318
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    host_vars_0 = HostVars(int_0, int_0, int_0)
    var_0 = host_vars_0.__iter__()
    str_0 = var_0.__iter__()
    assert not (str_0 == str_0)
    assert host_vars_vars_0 == host_vars_vars_0


# Generated at 2022-06-25 14:14:15.366839
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = -1177
    host_vars_0 = HostVars(int_0, int_0, int_0)
    host_vars_0.__iter__()


# Generated at 2022-06-25 14:14:17.764171
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = -701715766
    print(HostVars(int_0, int_0, int_0).__repr__())
