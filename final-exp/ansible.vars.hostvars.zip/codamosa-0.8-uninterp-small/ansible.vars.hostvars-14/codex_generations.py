

# Generated at 2022-06-25 14:05:42.091109
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    float_0 = 0.0011889092194900607
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    with pytest.raises(NotImplementedError):
        for _ in host_vars_vars_0:
            pass


# Generated at 2022-06-25 14:05:45.325615
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test case data
    host_vars_0 = HostVars(test_case_0, test_case_0, test_case_0)

    for var in host_vars_0:
        pass

    # AssertionError: 'foo'
    # AssertionError: 'bar'


# Generated at 2022-06-25 14:05:48.745578
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    try:
        host_vars_0 = HostVars(float_0, float_0, float_0)
        var_0 = host_vars_0.__getitem__(float_0)
        assert var_0 == float_0
    except TypeError:
        raise TypeError('Method `__getitem__` of class `HostVars` accepts 1 arguments, but the given one is 0')


# Generated at 2022-06-25 14:06:00.186009
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 1.7040445681772183
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    host_vars_0 = HostVars(float_0, float_0, float_0)

# Generated at 2022-06-25 14:06:04.391761
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    host_vars_vars_0 = HostVarsVars(1.7040445681772183, 1.7040445681772183)
    assert list(host_vars_vars_0.__iter__()) == [1.7040445681772183]


# Generated at 2022-06-25 14:06:06.473784
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # TODO: This code does not work.
    # assert repr(HostVars) == "???", "Test case failed."

    pass


# Generated at 2022-06-25 14:06:09.989540
# Unit test for method raw_get of class HostVars

# Generated at 2022-06-25 14:06:14.726619
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    float_0 = 1.7040445681772183
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    str_0 = repr(host_vars_vars_0)
    str_0 = repr(host_vars_vars_0)

# Generated at 2022-06-25 14:06:19.670526
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    host_vars_0 = HostVarsVars(float_0, float_0)

    # try something
    try:
        host_vars_0.__getitem__(float_0)
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 14:06:26.177707
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    float_0 = 2.217547897e-322
    float_1 = 3.63826184683e-310
    float_2 = 2.510864897e-322
    float_3 = 2.0765692272e-308
    float_4 = 1.15993125e-322
    float_5 = 2.633244857e-322
    float_6 = 2.6003897e-322
    float_7 = 2.791506144e-308
    float_8 = 3.7579386184e-310
    float_9 = 2.5318944e-322
    float_10 = 1.827522112e-308
    float_11 = 2.8191304e-322
    float_12 = 2.771061312e-308
    float

# Generated at 2022-06-25 14:06:35.344639
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars_0 = HostVars()
    host_vars_0.__repr__()
    assert True


# Generated at 2022-06-25 14:06:39.426895
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    float_0 = 1.7040445681772183
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    for host_item_1 in host_vars_vars_0:
        assert isinstance(host_item_1, unicode)


# Generated at 2022-06-25 14:06:43.968326
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = dict(
        all=dict(
            children=dict(
                localhost=dict(
                    vars=dict(
                        ansible_connection='local',
                    ),
                ),
                other_host=dict(
                    vars=dict(
                        foo='bar'
                    ),
                ),
            ),
            vars=dict(
                ansible_python_interpreter='/usr/bin/python',
            ),
        ),
        localhost=dict(
            vars=dict(
                ansible_connection='local',
            ),
        ),
    )
    variable_manager = VariableManager

# Generated at 2022-06-25 14:06:45.311893
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host = HostVars(float(), float(), float())
    host.__iter__()


# Generated at 2022-06-25 14:06:55.665725
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    float_0 = 1.2278642430109246
    host_vars_0 = HostVars(float_0, float_0, float_0)
    string_0 = 'hostvars[\'localhost\']'
    ansible_undefined_0 = AnsibleUndefined(string_0)
    assert (host_vars_0.raw_get(string_0) == ansible_undefined_0)
    string_0 = 'hostvars[\'localhost\']'
    ansible_undefined_0 = AnsibleUndefined(string_0)
    assert (host_vars_0.__getitem__(string_0) == ansible_undefined_0)


# Generated at 2022-06-25 14:06:59.252454
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    float_0 = 1.7040445681772183
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    host_vars_vars_0.__setstate__(float_0)

# Generated at 2022-06-25 14:07:07.047118
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    float_0 = 1.7040445681772183
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    str_0 = str()
    int_0 = int()
    func_0 = test_HostVarsVars___iter__
    tuple_0 = (str_0, int_0, func_0)
    str_1 = str()
    dict_0 = dict()
    str_2 = str()
    set_0 = set()
    complex_0 = complex()
    str_3 = str()
    dict_1 = dict()
    dict_1[float_0] = complex_0
    dict_1[str_0] = str_1
    dict_1[tuple_0] = str_2
    dict_2 = dict()


# Generated at 2022-06-25 14:07:11.742679
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    float_0 = 0.754111314776975
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    #
    # run HostVarsVars.__iter__
    host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:07:15.276319
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    host_vars_vars_0 = HostVarsVars(5, 1.5)
    for foo in host_vars_vars_0:
        pass


# Generated at 2022-06-25 14:07:19.905027
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    float_0 = 1.2501051450781294
    host_vars_0 = HostVars(float_0, float_0, float_0)
    unicode_0 = u'python_k'
    host_vars_0.raw_get(unicode_0)


# Generated at 2022-06-25 14:07:29.010932
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    inventory_0 = HostVars(None, None, None)
    list_0 = list(inventory_0)
    assert len(list_0) == 0



# Generated at 2022-06-25 14:07:31.659988
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    float_0 = 1.7040445681772183
    assert HostVars(float_0, float_0).raw_get(float_0) is None


# Generated at 2022-06-25 14:07:36.141801
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    foo = HostVars(None, None, None)
    # Create an instance of a Mapping
    host_vars_vars_0 = HostVarsVars(foo, foo)
    # Create an instance of a Mapping
    host_vars_vars_1 = HostVarsVars(foo, host_vars_vars_0)

# Generated at 2022-06-25 14:07:39.083693
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    float_0 = 1.7040445681772183
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    assert host_vars_vars_0.__repr__() == float_0

# Generated at 2022-06-25 14:07:44.809757
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory_0 = [1, 'inventory', 'inventory']
    variable_manager_0 = [1, 'variable_manager', 'variable_manager']
    loader_0 = 'loader'
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    str_0 = 'localhost'
    result = host_vars_0.raw_get(str_0)
    assert result == {}


# Generated at 2022-06-25 14:07:50.129506
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 1.2308375644534541
    host_vars_0 = HostVars(float_0, float_0, float_0)
    float_1 = 0
    assert_equal(host_vars_0.__getitem__(float_0), host_vars_vars_0)


# Generated at 2022-06-25 14:07:55.716181
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    float_0 = 2.4040348218775295
    int_0 = 5
    host_vars_vars_0 = HostVarsVars(float_0, int_0)
    int_1 = 0
    while int_1 <= int_0:
        host_vars_vars_0.__getitem__(float_0)
        int_1 = int_1 + 1
    test_case_0()


# Generated at 2022-06-25 14:07:57.674064
# Unit test for method __repr__ of class HostVars

# Generated at 2022-06-25 14:08:01.119166
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 1.9134626145048763
    host_vars_0 = HostVars(float_0, float_0, float_0)
    host_vars_0.__getitem__("string_1")


# Generated at 2022-06-25 14:08:01.710725
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_case_0()


# Generated at 2022-06-25 14:08:16.303148
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars(float_0, float_0, 0)
    state = host_vars_0.__getstate__()
    host_vars_0.__setstate__(state)


# Generated at 2022-06-25 14:08:18.111288
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    foo_0 = HostVarsVars
    len_0 = len(foo_0)
    assert len_0 == 0


# Generated at 2022-06-25 14:08:20.543597
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    float_0 = 1.6472512755463128
    host_vars_0 = HostVars(float_0, float_0, float_0)
    assert repr(host_vars_0) == repr({})


# Generated at 2022-06-25 14:08:21.808565
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # FIXME: implement test_case_1
    raise NotImplementedError()


# Generated at 2022-06-25 14:08:26.779255
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 1.7040445681772183
    host_vars_vars_0 = HostVarsVars(float_0, float_0)

    assert host_vars_vars_0.__getitem__(float_0)



# Generated at 2022-06-25 14:08:29.984918
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    float_0 = 1.0835871438645003
    host_vars_0 = HostVars(float_0, float_0, float_0)
    try:
        pass
    except:
        raise RuntimeError('Test failed')


# Generated at 2022-06-25 14:08:34.915452
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    float_0 = 1.7113606586901706
    str_0 = '['
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    str_1 = str(host_vars_vars_0)
    assert str_0 == str_1


# Generated at 2022-06-25 14:08:38.152786
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    float_0 = 1.7040445681772183
    host_vars_0 = HostVars(float_0, float_0, float_0)

    ret_val_0 = host_vars_0.__iter__()



# Generated at 2022-06-25 14:08:40.129209
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 1.7040445681772183
    host_vars_vars_0 = HostVarsVars(float_0, float_0)


# Generated at 2022-06-25 14:08:44.449873
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Using this code will not raise the expected exception
    # host_vars_0 = HostVars(host_vars_vars_0, float_0)
    # float_0 = 1.7040445681772183
    # host_vars_vars_0 = HostVarsVars(float_0, float_0)
    # host_vars_0.__setstate__(float_0)
    # Make sure the following code raises the expected exception
    pass


# Generated at 2022-06-25 14:09:11.125240
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 1.198474242912382
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    int_0 = 0
    assert host_vars_vars_0[int_0] == float_0

# Generated at 2022-06-25 14:09:20.524090
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 0.0671645665484
    float_1 = -0.380197662166
    host_vars_vars = HostVarsVars(float_0, float_1)
    # AssertionError: expected AnsibleUndefined() got {'level': 1, 'foo': u'bar', 'answer': 42}
    assert host_vars_vars.__getitem__('level') == {'level': 1, 'foo': 'bar', 'answer': 42}

    host_vars_vars.__getitem__('level') == {'level': 1, 'foo': 'bar', 'answer': 42}



# Generated at 2022-06-25 14:09:27.063736
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.hostvars import HostVars
    host_vars_0 = HostVars()
    str_0 = repr(host_vars_0)

if __name__ == "__main__":
    templar = Templar()
    templar._loader = None
    foo2 = templar.template("{{ hostvars['be-centos7-01']['ansible_default_ipv4']['address'] }}", fail_on_undefined=False)
    print(foo2)

# Generated at 2022-06-25 14:09:29.365879
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Coding style test for __iter__
    obj = HostVars(None, None, None)
    obj.__iter__()
    obj = HostVars(None, None, None)


# Generated at 2022-06-25 14:09:32.010170
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    float_0 = 1.3448292505252416
    host_vars_0 = HostVars(
        float_0,
        float_0,
        float_0
    )

    for i in host_vars_0:
        print(i)


# Generated at 2022-06-25 14:09:37.031713
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 1.7040445681772183
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    assert_equal(host_vars_vars_0[float_0], 1.7040445681772183)


# Generated at 2022-06-25 14:09:41.879153
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    float_0 = 1.070789963231671
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    str_0 = repr(host_vars_vars_0)
    assert str_0 == "1.070789963231671"


# Generated at 2022-06-25 14:09:45.309272
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 1.7040445681772183
    host_vars_0 = HostVars(float_0, float_0, float_0)
    for host_name in range(10):
        host_vars_0.get(0.0)


# Generated at 2022-06-25 14:09:53.646216
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 7.851412
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    assert type(host_vars_vars_0) == HostVarsVars
    assert host_vars_vars_0.__getitem__({'telnet': 'start_prompt', 'isapi': 'allow', 'unittest': 'unittest', 'enable': 'Tr', 'nocompile': 'True', 'raw': 'False', 'inject': 'True', 'include': 'False', 'biosversion': 'True', 'access_level': 'w', 'unit': 'unit'}) == 7.851412

# Generated at 2022-06-25 14:09:56.846808
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 0.7390626794255397
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    str_0 = '^>YFus<h*|'
    assert host_vars_vars_0[str_0] == float_0


# Generated at 2022-06-25 14:10:54.604955
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    float_0 = 1.7040445681772183
    host_vars_0 = HostVars(float_0, float_0, float_0)
    str_0 = "]~m6[fU!_m3KVrv5\"W:5R$@5>BgHN<C{Kk`Nlgdi),D]"
    assert host_vars_0.raw_get(str_0) == float_0



# Generated at 2022-06-25 14:11:00.072456
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    inventory_0 = InventoryManager(loader=None, sources='')
    variable_manager_0 = VariableManager(loader=None, inventory=inventory_0)

    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader=None)
    host_vars_0._inventory = inventory_0
    host_vars_0._loader = None
    host_vars_0._variable_manager = variable_manager_0

    host_vars_0.__setstate__(host_vars_0.__dict__)


# Generated at 2022-06-25 14:11:03.035260
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 1.7040445681772183
    host_vars_0 = HostVarsVars(float_0, float_0)
    assert isinstance(host_vars_0, Mapping) is True
    assert repr(host_vars_0) == repr(float_0)


# Generated at 2022-06-25 14:11:09.437570
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    float_0 = 0.9382207493128703
    host_vars_0 = HostVars(None, float_0, float_0)
    str_0 = host_vars_0.raw_get('*')
    assert str_0 == None, "host_vars_0.raw_get('*') == None"

test_HostVars_raw_get()

# Generated at 2022-06-25 14:11:13.439982
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    float_0 = 1.7040445681772183
    host_vars_0 = HostVars(True, float_0, float_0)

    # Now try to access to HostVars, it should not raise any exception
    try:
        host_vars_0.raw_get(float_0)
    except KeyError:
        pass



# Generated at 2022-06-25 14:11:20.520408
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    float_0 = 1.5672286241056512
    host_vars_vars_0 = HostVarsVars(float_0, float_0)
    templar_0 = Templar(host_vars_vars_0._vars, host_vars_vars_0._loader)
    templar_0.template(host_vars_vars_0._vars, False, STATIC_VARS)
    templar_0.template(host_vars_vars_0._vars, False, STATIC_VARS)
    templar_0.template(host_vars_vars_0._vars, False, STATIC_VARS)

# Generated at 2022-06-25 14:11:23.468289
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    float_0 = 1.8354445681772182
    host_vars_0 = HostVars(None, float_0, float_0)
    host_vars_0.raw_get(float_0)


# Generated at 2022-06-25 14:11:26.834978
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Example usage:
    #
    #    host_vars = HostVars()
    #    result = host_vars.raw_get()
    #
    pass


# Generated at 2022-06-25 14:11:35.710211
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    dict_0 = dict()
    dict_0['host_name_0'] = dict_0
    dict_0['host_name_1'] = dict_0

    host_vars_0 = HostVars(dict_0, dict_0, dict_0)
    host_vars_0.__getitem__('var_name_1')

    dict_0['host_name_0'] = dict_0
    host_vars_0 = HostVars(dict_0, dict_0, dict_0)
    host_vars_0.__getitem__('host_name_0')

    host_vars_0 = HostVars(dict_0, dict_0, dict_0)
    host_vars_0.__getitem__('var_name_0')


# Generated at 2022-06-25 14:11:39.581762
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    print("Testing __repr__ of HostVars")
    float_0 = 1.166988557785518
    host_vars_0 = HostVars(float_0, float_0, float_0)
    print(host_vars_0.__repr__())
