

# Generated at 2022-06-25 14:05:34.063484
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    dict_0 = {}
    int_0 = 3
    host_vars_vars_0 = HostVarsVars(dict_0, int_0)
    dict_1 = {}
    dict_1['test_key'] = 'test_value'
    assert 'test_key' in host_vars_vars_0


# Generated at 2022-06-25 14:05:38.304160
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Set up objects
    dict_0 = {}
    int_0 = 3
    host_vars_vars_0 = HostVarsVars(dict_0, int_0)
    assert repr(host_vars_vars_0) == "{}"

# Generated at 2022-06-25 14:05:41.596694
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    dict_0 = {}
    int_0 = 3
    host_vars_0 = HostVarsVars(dict_0, int_0)
    host_vars_1 = copy.deepcopy(host_vars_0)

# Generated at 2022-06-25 14:05:45.763962
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hv = HostVars(None, None, None)
    assert hv.raw_get('foo') is AnsibleUndefined

    # check that _find_host did not return None
    def find_host(h):
        return {'foo': 1}

    hv._find_host = find_host

    ret = hv.raw_get('foo')
    assert ret == {'foo': 1}

# Generated at 2022-06-25 14:05:49.909195
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    dict_0 = {}
    int_0 = 3
    host_vars_vars_0 = HostVarsVars(dict_0, int_0)
    list_0 = []
    assert host_vars_vars_0.__iter__() == (list_0)


# Generated at 2022-06-25 14:05:56.537268
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    dict_0 = {}
    int_0 = 3
    host_vars_0 = HostVars(dict_0, int_0, int_0)
    try:
        host_vars_0.__setstate__(int_0)
    except:
        print(str('')+' Exception is caught')
    host_vars_0.__setstate__(dict_0)


# Generated at 2022-06-25 14:05:59.576755
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    dict_0 = {}
    int_0 = 3
    host_vars_vars_0 = HostVarsVars(dict_0, int_0)
    assert 1 == 1


# Generated at 2022-06-25 14:06:01.929123
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    s = {}
    x = HostVarsVars(s, 3)
    v = x['hoge']


# Generated at 2022-06-25 14:06:06.608010
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    dict_0 = {}
    int_0 = 3
    host_vars_vars_0 = HostVarsVars(dict_0, int_0)


# Generated at 2022-06-25 14:06:10.803491
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    dict_0 = {}
    int_0 = 3
    host_vars_vars_0 = HostVarsVars(dict_0, int_0)
    repr_str = host_vars_vars_0.__repr__()
    # test returns valid repr
    assert repr_str == "{}"


# Generated at 2022-06-25 14:06:28.073315
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    data_0 = dict()
    int_0 = 42
    str_0 = "quux"
    loader_0 = DataLoader()
    host_vars_vars_0 = HostVarsVars(data_0, loader_0)
    ret_0 = host_vars_vars_0.__iter__()
    data_0[str_0] = int_0
    ret_1 = ret_0.__iter__()
    assert ret_1 == ret_1


# Generated at 2022-06-25 14:06:31.816412
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars(int(), int())
    setstate_tuple_0 = (int(), int(), int(), int(), int(),)
    host_vars_0.__setstate__(setstate_tuple_0)


# Generated at 2022-06-25 14:06:38.192342
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    int_1 = 99
    class object_0(object):
        int_0 = 42
        def __init__(self, testCase):
            self.int_0 = 42
            self.int_1 = 99
            self.int_2 = 16
            self.int_3 = 5
            self.int_4 = 23
            self.int_5 = 9
            self.int_6 = 44
            self.int_7 = 48
            self.int_8 = 25
            self.int_9 = 49
            self.int_10 = 30
            self.int_11 = 39
            self.int_12 = 24
            self.int_13 = 28
            self.int_14 = 37
            self.int_15 = 18
            self.int_16 = 3
            self.int

# Generated at 2022-06-25 14:06:41.939589
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    # Setup
    host_vars_0 = HostVars(int(), int(), int())
    exception = None

    # Test
    try:
        host_vars_0.__repr__()
    except Exception as err:
        exception = err

    # Verify
    assert exception is None



# Generated at 2022-06-25 14:06:51.420427
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    tuple_0 = ()
    str_0 = str()
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()

# Generated at 2022-06-25 14:06:53.861355
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars(None, None, None)
    x = iter(host_vars_0)


# Generated at 2022-06-25 14:06:59.336472
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    list_0 = list()
    for var in host_vars_0.__iter__():
        list_0.append(var)
    assert len(list_0) == 0
    assert list_0 == []


# Generated at 2022-06-25 14:07:03.306868
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # SETUP
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    expected_0 = []

    # TEST
    actual_0 = list(iter(host_vars_vars_0))

    # VERIFY
    assert actual_0 == expected_0


# Generated at 2022-06-25 14:07:07.635097
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    string_0 = "hostvars"
    int_1 = host_vars_0.__getitem__(string_0)


# Generated at 2022-06-25 14:07:14.274255
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    # Call function '__iter__' of class 'HostVarsVars'
    try:
        HostVarsVars.__iter__(host_vars_vars_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 14:07:22.095433
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)

# Generated at 2022-06-25 14:07:27.761506
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    int_0 = 42
    hostvars_0 = HostVars(int_0, int_0, int_0)
    state = {'__dict__': {'_inventory': int_0,
                         '_loader': int_0,
                         '_variable_manager': int_0},
             '__weakref__': None}
    hostvars_0.__setstate__(state)


# Generated at 2022-06-25 14:07:31.669605
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    str_0 = 'r:~'
    dict_0 = host_vars_0.raw_get(str_0)


# Generated at 2022-06-25 14:07:36.105454
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 0
    int_1 = 1
    str_0 = "a"
    str_1 = "b"
    bool_0 = True
    bool_1 = False
    list_0 = [int_1, int_0]
    host_vars_vars_0 = HostVarsVars(list_0, int_0)
    None
    assert list_0 == [int_1, int_0]
    assert host_vars_vars_0 == [int_1, int_0]


# Generated at 2022-06-25 14:07:40.496215
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = None
    variable_manager = None
    loader = None
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    host_name = None
    result = host_vars_0.raw_get(host_name)
    assert result is None


# Generated at 2022-06-25 14:07:43.139305
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    input_data_0 = 42
    assert test_case_0() == (input_data_0, input_data_0, input_data_0, input_data_0)


# Generated at 2022-06-25 14:07:47.944445
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    try:
        next(host_vars_vars_0.__iter__())
    except StopIteration:
        pass


# Generated at 2022-06-25 14:07:48.928268
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_case_0()

# Generated at 2022-06-25 14:07:53.393384
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    var_0 = test_HostVars___getitem__.var_0
    host_vars_vars_0 = host_vars_0[var_0]

    # Unit test for method __contains__ of class HostVars

# Generated at 2022-06-25 14:08:03.942863
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    int_1 = 42
    int_2 = 0
    str_0 = 'int_2'
    str_1 = None
    str_2 = 'str_1'
    str_3 = None
    str_4 = 'str_3'
    str_5 = None
    str_6 = 'str_5'
    str_7 = None
    return_value_0 = host_vars_0.raw_get(int_1)

    assert (return_value_0 == AnsibleUndefined("hostvars['%s']" % (int_1)))
    return_value_1 = host_vars_0.raw_get(str_0)


# Generated at 2022-06-25 14:08:15.045822
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_1 = 42
    int_2 = 42
    str_3 = 'hostvars[\''
    str_4 = '\']'
    hv = HostVars('hostvars[\'')
    result = hv['\']']
    assert type(result) == AnsibleUndefined
    assert result.name == str_3 + str_4


# Generated at 2022-06-25 14:08:20.599289
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_2 = 3
    int_3 = 3
    int_4 = 3
    int_5 = 3
    str_6 = 'ansible_version'
    str_7 = 'ansible_play_hosts'
    str_8 = 'ansible_dependent_role_names'
    str_9 = 'ansible_play_role_names'
    str_10 = 'ansible_role_names'
    str_11 = 'inventory_hostname'
    str_12 = 'inventory_hostname_short'
    str_13 = 'inventory_file'
    str_14 = 'inventory_dir'
    str_15 = 'groups'
    str_16 = 'group_names'
    str_17 = 'omit'
    str_18 = 'playbook_dir'

# Generated at 2022-06-25 14:08:22.332540
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Check that the __setstate__ method exists and that it is available for use
    m = HostVars.__setstate__
    assert callable(m)


# Generated at 2022-06-25 14:08:31.530031
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    test_case_0()
    test_HostVars = HostVars('2jVR0', 'xfY2v', 'wU6Qb')
    assert test_HostVars.raw_get('pZUYT') == AnsibleUndefined('sMYm8')
    assert test_HostVars.raw_get('1F6UJ') == AnsibleUndefined('gfNwW')
    assert test_HostVars.raw_get('0z8Cj') == 'cqZJ5'
    assert test_HostVars.raw_get('uV7lg') == AnsibleUndefined('Y4WeG')
    assert test_HostVars.raw_get('F0Ihr') == AnsibleUndefined('Z1YkI')

# Generated at 2022-06-25 14:08:32.931198
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42
    set_trace()


# Generated at 2022-06-25 14:08:37.724893
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    print(test_case_0.__doc__)
    
    hostvars = HostVars(inventory_hostname_short='Ansible', inventory_hostname='localhost')
    A = str(hostvars.raw_get('localhost'))
    print(A)
    
if __name__ == '__main__':
    for test in [test_HostVars_raw_get]:
        test()

# Generated at 2022-06-25 14:08:44.629831
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    int_0 = 42
    dict_1 = { }
    dict_2 = {
        '_loader': None,
        '_inventory': None,
        '_variable_manager': None,
    }
    dict_3 = {
        '_variable_manager': dict_2,
    }
    dict_4 = {
        '_loader': None,
        '_hostvars': None,
    }
    dict_5 = {
        'variable_manager': dict_4,
    }
    dict_6 = {
        'variable_manager': dict_5,
    }
    dict_7 = {
        '_loader': int_0,
        '_hostvars': int_0,
    }

# Generated at 2022-06-25 14:08:46.488617
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    hv = HostVars("int_0")
    assert int_0 == hv["int_0"]


# Generated at 2022-06-25 14:08:49.495712
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    foo = {}
    test_case_0()
    obj = HostVarsVars(foo, None)
    iterator = obj.__iter__()
    assert iterator is not None, "__iter__ returned None."



# Generated at 2022-06-25 14:08:54.325345
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Parametrize and initialize
    inventory = None
    variable_manager = None
    loader = None
    state = {'_inventory': inventory, '_loader': loader, '_variable_manager': variable_manager}
    hostvars_0 = HostVars(inventory, variable_manager, loader)

    # Test the method
    hostvars_0.__setstate__(state)


# Generated at 2022-06-25 14:09:07.656762
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    test_case_0()

# Generated at 2022-06-25 14:09:17.844479
# Unit test for method raw_get of class HostVars

# Generated at 2022-06-25 14:09:19.060976
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    assert HostVars.__iter__() is not None


# Generated at 2022-06-25 14:09:24.352538
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    obj_0 = None
    obj_1 = HostVars(obj_0, obj_0, obj_0)
    obj_1.set_variable_manager(obj_0)
    var_3 = test_case_0()
    var_1 = obj_1.raw_get(var_3)


# Generated at 2022-06-25 14:09:28.997410
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    # Creating an instance of Mapping
    inventory = mock.Mock()
    variable_manager = mock.Mock()
    loader = mock.Mock()
    hostvars_0 = HostVars(inventory, variable_manager, loader)

    # Calling method
    hostvars_0.raw_get(mock.sentinel.host_name)

    # Assertions
    assert not hasattr(hostvars_0, "")


# Generated at 2022-06-25 14:09:35.097018
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    loader = None
    hostvars = None
    #
    # Workaround for missing __dict__ attribute when pickling instance of
    # class templar.AnsibleUndefined.
    #
    undef_0 = AnsibleUndefined(name="hostvars['undef_0']")
    undef_0.__dict__ = {'name': "hostvars['undef_0']"}
    #
    # If 'loader' is None, then __setstate__ should set it to 'self._loader'.
    #
    loader_0 = None

# Generated at 2022-06-25 14:09:36.880668
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42


# Generated at 2022-06-25 14:09:38.736285
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    i = HostVars()
    i.__setstate__(test_case_0)


# Generated at 2022-06-25 14:09:45.606305
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    hostvars_vars = HostVars({'0': 1}, variable_manager=None, loader=None)
    # Call method __setstate__() of class HostVars.
    test_case_0()
    print('HostVars: __setstate__')
    print('Argument(s): HostVars')
    print('Return value: None\n')
    print('HostVars: __getitem__')
    print('Argument(s): HostVars')
    print('Return value: HostVarsVars\n')

# Generated at 2022-06-25 14:09:53.783711
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    int_0 = 42
    str_0 = "abc"
    int_1 = 20
    list_0 = [int_0, int_1, str_0]
    int_2 = 23
    str_1 = "efg"
    list_1 = [int_2, str_1]

    int_3 = 1
    int_4 = 2

    dict_0 = {"key_0": int_3,
              "key_1": int_4,
              "key_2": list_1,
              "key_3": list_0}

    obj_0 = HostVars(dict_0, int_0)
    str_2 = "key_1"
    assert obj_0.raw_get(str_2) == 1
    return



# Generated at 2022-06-25 14:10:26.930077
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Implementation details
    #
    # Currently, we're testing the memory usage in a very simple form.
    # This can be updated in the future when we add more complex logic
    # to the classes.
    itr = HostVarsVars.__iter__(test_case_0)
    assert itr is not None
    assert itr.__class__.__name__ == 'generator'


# Generated at 2022-06-25 14:10:32.736376
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    #
    # Example:
    #
    
    #
    # ----- Injecting mocks and initializing test environment -----
    #
    int_0 = 42
    test_case_0()
    #
    # ----- Perform the task -----
    #
    # Test case 0:
    #
    # ----- Perform the tests -----
    #
    # The following code block will generate errors.
    #
    int_0 = 42
    #
    # ----- Cleanup -----
    #
    # The following code block will generate errors.
    #
    int_0 = 42
    #


# Generated at 2022-06-25 14:10:34.639216
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    model0 = HostVarsVars()
    # execution
    int_0 = 0
    for i in model0:
        int_0 += 1
    assert int_0 == 0


# Generated at 2022-06-25 14:10:36.985231
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    my_hostvars = HostVars()
    result_actual = my_hostvars.__iter__()
    result_expected= __name__
    assert result_actual == result_expected, "Test with the test case failed"


# Generated at 2022-06-25 14:10:46.960645
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    int_0 = 42
    int_1 = 42
    str_0 = 'k9eW@mvSQ%f'
    str_1 = 'k9eW@mvSQ%f'
    dict_0 = dict()
    dict_0[str_0] = int_0
    dict_1 = dict()
    dict_1[str_1] = int_1
    dict_2 = dict()
    dict_2[str_0] = int_1
    dict_3 = dict()
    dict_3[str_1] = int_0
    dict_4 = dict()
    dict_4[str_0] = dict_1
    dict_5 = dict()
    dict_5[str_0] = dict_3
    dict_5[str_1] = dict_2
   

# Generated at 2022-06-25 14:10:49.540473
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # setup
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    # assertion
    assert repr(hv).__eq__('{}')


# Generated at 2022-06-25 14:10:53.206455
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    var_0 = host_vars_0.raw_get(str_0)
    if var_0 != false:
        test_case_0()


# Generated at 2022-06-25 14:10:53.996571
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = 42


# Generated at 2022-06-25 14:10:54.873008
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42


# Generated at 2022-06-25 14:10:56.255877
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    assert repr(HostVars()) == '<HostVarsVars>'


# Generated at 2022-06-25 14:11:34.101313
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = 42


# Generated at 2022-06-25 14:11:35.322554
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # returns ansible.vars.variable_manager.HostVarsVars
    pass


# Generated at 2022-06-25 14:11:39.351178
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    # Testing code
    class A:
        pass

    a = A()
    a._loader = None
    a._variable_manager = None
    a._inventory = None
    a.raw_get = test_case_0
    a.__iter__()

    # Deletion
    del a
    del int_0


# Generated at 2022-06-25 14:11:40.435672
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42


# Generated at 2022-06-25 14:11:44.976178
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    param_0 = 'localhost'
    param_1 = test_case_0()
    param_1.set_inventory(param_0)
    assert param_1['localhost'] == {}

# Generated at 2022-06-25 14:11:46.317546
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    #@TODO: Implement this test
    pass


# Generated at 2022-06-25 14:11:48.712424
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 42
    int_1 = 42
    assert 42 == int_0
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 14:11:51.682015
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_vars_0 = HostVars()
    str_0 = host_vars_0['foo']
    int_0 = id(host_vars_0)


# Generated at 2022-06-25 14:11:52.856322
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = 42
    test_case_0()


# Generated at 2022-06-25 14:11:53.822969
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = 42
    test_case_0()


# Generated at 2022-06-25 14:12:10.347225
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    inventory_0 = {}
    loader_0 = {}
    variable_manager_0 = VariableManager(inventory_0, loader_0)
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    host_name_0 = int_0
    value_0 = host_vars_0.raw_get(host_name_0)


# Generated at 2022-06-25 14:12:12.470227
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Get the value
    data = host_vars_vars_0.__getitem__(0)
    # Assert the data
    assert data == 0


# Generated at 2022-06-25 14:12:13.506561
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    test_case_0()

# Generated at 2022-06-25 14:12:14.184945
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    pass

# Generated at 2022-06-25 14:12:15.327579
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # TODO: Add more tests
    pass


# Generated at 2022-06-25 14:12:18.185508
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    int_1 = 42
    assert host_vars_0.raw_get(int_1) == 42


# Generated at 2022-06-25 14:12:21.120656
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    host_vars_vars_0 = host_vars_0.__getitem__(int_0)


# Generated at 2022-06-25 14:12:25.167391
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    int_1 = 42
    host_vars_0 = HostVars(int_0, int_0, int_1)
    int_2 = 42
    for int_3 in host_vars_0:
        assert False


# Generated at 2022-06-25 14:12:32.881892
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    #self._raw_get()
    host_vars_0 = HostVars(int_0, int_0, int_0)
    int_1 = 42
    str_0 = str(int_1)
    #self._raw_get(str_0)
    host_vars_0 = HostVars(str_0, str_0, str_0)
    #self._raw_get(str_0)
    host_vars_0 = HostVars(str_0, str_0, str_0)
    #self._raw_get(str_0)
    host_vars_0 = HostVars(str_0, str_0, str_0)
    #self._raw_get(str_0)

# Generated at 2022-06-25 14:12:36.090797
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    assert_equal(host_vars_vars_0.__getitem__(int_0), int_0, "host_vars_vars_0.__getitem__(int_0) returned unexpected value")


# Generated at 2022-06-25 14:13:07.872435
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    result = next(iter(host_vars_vars_0))
    assert result is None


# Generated at 2022-06-25 14:13:12.526752
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    for i in host_vars_0:
        pass
    i = None


# Generated at 2022-06-25 14:13:17.151103
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    str_0 = 'foo'
    var_0 = host_vars_vars_0.__getitem__(str_0)
    assert var_0 == 42

test_cases = [
    # Unit test for method __getitem__ of class HostVars
    (test_HostVars___getitem__, None),
]

# Generated at 2022-06-25 14:13:19.868748
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    assert MakeItIterable(host_vars_vars_0)


# Generated at 2022-06-25 14:13:26.557519
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import random
    import re
    import sys

    # Test execution with method raw_get of class HostVars
    # Test case setup
    import ansible
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    hosts = [
        'some.random.host'
    ]
    inventory = Inventory(hosts)
    int_0 = 42
    setattr(ansible, "all", int_0)
    setattr(ansible, "ansible_play_role_names", int_0)
    setattr(ansible, "ansible_play_hosts", int_0)
    setattr(ansible, "is_sorted", int_0)
    setattr(ansible, "in_vault", int_0)

# Generated at 2022-06-25 14:13:27.195851
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    test_case_0()

# Generated at 2022-06-25 14:13:34.513875
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    str_0 = "host"
    int_2 = host_vars_0.raw_get(str_0)

    # AssertionError is raised if int_2 is not equal to unde
    mo_assertion_error = AssertionError()
    mo_assertion_error.__cause__ = None
    raise mo_assertion_error

    int_1 = host_vars_0.raw_get("foobar")

    # AssertionError is raised if int_1 is not equal to unde
    mo_assertion_error = AssertionError()
    mo_assertion_error.__cause__ = None
    raise mo_assertion_error


# Generated at 2022-06-25 14:13:37.240147
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    repr_ret_1 = repr(host_vars_vars_0)
    assert repr_ret_1 == '42'

# Generated at 2022-06-25 14:13:45.978913
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'foo'
    str_1 = 'bar'
    list_0 = []
    list_0.append(str_0)
    ansible_module_0 = AnsibleModule(argument_spec=dict())
    ansible_module_0.get_bin_path('magic', required=False, opt_dirs=None)
    ansible_module_0.check_mode = False
    ansible_module_0.no_log = False
    InventoryManager(loader=None, sources=list_0)
    inventory = InventoryManager(loader=None, sources=list_0)
    class_0 = TestCase
    var_0 = VariableManager()
    var_1 = InventoryManager(loader=None, sources=list_0)
    # FIXME: possible bug (not used)?
    var_0.add_

# Generated at 2022-06-25 14:13:48.239080
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_name = 42
    class_0 = HostVars(int_0, int_0, int_0)
    class_0.raw_get(host_name)


# Generated at 2022-06-25 14:14:49.253471
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 42
    host_vars_0 = HostVars(int_0, int_0, int_0)
    for elem in host_vars_0:
        assert elem is not None


# Generated at 2022-06-25 14:14:57.840648
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
    # Python 3.6.4.final.0, this crashes with a TypeError:
    # TypeError: __repr__ returned non-string (type int)
    # This appears to be a regression in CPython 3.6.4, which
    # was introduced between 3.6.3 and 3.6.4.  The following
    # demonstration shows it's a regression:
    #
    #   $ python3.6 -c 'print(42)'
    #      42
    #   $ python3.6 -c 'print(__builtins__.repr(42))'
    #      42
    #   $ python3.6.3 -c 'print(__builtins__.repr(

# Generated at 2022-06-25 14:15:00.436815
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Test with first argument = None
    # Should raise a TypeError
    args = (None,)
    with pytest.raises(TypeError):
        repr(HostVars(*args))


# Generated at 2022-06-25 14:15:03.416141
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 42
    str_0 = 'Cpq8k?W@5w'
    host_vars_0 = HostVars(int_0, int_0, int_0)
    host_vars_0.raw_get(str_0)



# Generated at 2022-06-25 14:15:07.726208
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # int_0
    # variables_0
    # loader_0
    # host_name_0
    # host_vars_0
    # result_0
    #
    # Do not use inventory.hosts so it can create localhost on demand
    host_0 = HostVarsVars(variables_0, loader_0)

    #
    #
    #
    # if host is None:
    #     return AnsibleUndefined(name="hostvars['%s']" % host_name)

    pass

# Generated at 2022-06-25 14:15:11.014055
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory_0 = "inventory"
    inventory_1 = None
    hostvars_0 = HostVars(inventory_0, inventory_1)
    str_1 = "inventory_hostname"
    str_1 = hostvars_0.raw_get(str_1)
    assert(str_1 is not None)


# Generated at 2022-06-25 14:15:12.789449
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 42
    host_vars_vars_0 = HostVarsVars(int_0, int_0)
