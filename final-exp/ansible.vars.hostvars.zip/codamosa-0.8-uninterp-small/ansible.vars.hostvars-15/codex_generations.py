

# Generated at 2022-06-25 14:05:32.487044
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Tests that __iter__ works correctly
    int_0 = 575
    float_0 = 559.69
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:05:39.636833
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    try:
        host_vars_vars_0.__iter__()
        assert False # Expected exception: AttributeError
    except AttributeError as e:
        assert str(e).startswith('__iter__')

    # This method is not implemented.
    #raise NotImplementedError



# Generated at 2022-06-25 14:05:47.425991
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 734
    float_0 = 713.807
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    int_1 = 684
    float_1 = 236.771
    host_vars_vars_1 = HostVarsVars(int_1, float_1)
    int_2 = 787
    float_2 = 786.009
    host_vars_vars_2 = HostVarsVars(int_2, float_2)
    int_3 = 889
    float_3 = 500.961
    host_vars_vars_3 = HostVarsVars(int_3, float_3)
    list_0 = []

# Generated at 2022-06-25 14:05:58.881303
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    int_0 = 566
    str_0 = 'lY;N=+j4IUf?7J'
    str_1 = 'TQS+=3wqI:2}!_;BVC'
    str_2 = '9)yz6]0b6J}U7sI'
    float_0 = 467.84
    int_1 = 545
    str_3 = 'S2Q?svN[d:b}C%=N(`P&#/x_XB/t'
    str_4 = '8Z*W_!v'
    int_2 = 90
    str_5 = '{TeM%:'
    str_6 = 'W5PDR*v$Y;kL'
    float_1 = 594.2
    int_3 = 84


# Generated at 2022-06-25 14:06:04.943165
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    inventory = AnsibleInventory(loader=None, variable_manager=None, host_list=None)
    variable_manager = VariableManager()
    loader = DataLoader()
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    assert host_vars_0._loader == loader and host_vars_0._variable_manager._loader == loader and host_vars_0._variable_manager._hostvars == host_vars_0


# Generated at 2022-06-25 14:06:12.842793
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    inventory = AnsibleInventoryManager()
    inventory.variable_manager = VariableManager()
    inventory.loader = DataLoader()
    host_vars_0 = HostVars(inventory, inventory.variable_manager, inventory.loader)
    name_0 = 'test_name_0'
    host_vars_0._find_host = MagicMock(name='_find_host', return_value=inventory.hosts)
    host_vars_0.raw_get = MagicMock(name='raw_get', return_value=inventory.hosts)
    var_0 = host_vars_0.__getitem__(name_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 14:06:18.098047
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Testing initialization
    inventory = int()
    variable_manager = int()
    loader = int()
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    host_name = str()

    # Testing __call__
    host_vars_0.raw_get(host_name)


# Generated at 2022-06-25 14:06:19.444901
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Test case #0
    test_case_0()


# Generated at 2022-06-25 14:06:25.032479
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 55
    float_0 = 936.85
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    int_1 = 812
    float_1 = 550.851
    config_memory_0 = dict()
    config_memory_0[int_1] = float_1
    host_vars_vars_1 = HostVarsVars(config_memory_0, float_0)
    str_0 = host_vars_vars_0.__getitem__(host_vars_vars_1)


# Generated at 2022-06-25 14:06:29.591862
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Init the vars
    int_0 = 12
    float_0 = 275.903
    # Init the HostVars object
    host_vars_0 = HostVars(int_0, float_0)
    # Assert the __iter__ method is callable
    assert callable(host_vars_0.__iter__)


# Generated at 2022-06-25 14:06:38.117432
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = HostVars(inventory=None, variable_manager=None, loader=None)
    var_1 = var_0.raw_get('foo')
    assert var_1 == AnsibleUndefined(name="hostvars['foo']")


# Generated at 2022-06-25 14:06:40.873175
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    vars = {'a': 0, 'b': 1}
    result = HostVarsVars(vars, var_0)
    for var in result:
        print(var)


# Generated at 2022-06-25 14:06:48.562965
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    variable_manager = None
    loader = variable_manager
    inventory = None
    host_name = 'host_name'
    host = inventory
    varname = 'varname'
    value = 'value'
    facts = 'facts'
    hv = HostVars(inventory, variable_manager, loader)
    hv.set_variable_manager(variable_manager)
    hv.set_inventory(inventory)
    hv._loader = loader
    hv._variable_manager = variable_manager
    hv._find_host(host_name)
    hv.raw_get(host_name)
    hv.__setstate__({'_inventory': inventory, '_loader': loader, '_variable_manager': variable_manager, '_find_host': '_find_host'})
    hv.set_

# Generated at 2022-06-25 14:06:50.124098
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    test_case_0()


# Generated at 2022-06-25 14:06:53.337023
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    h = HostVars(var_0, var_0, var_0)
    item = "item"
    value = h.get(item)
    assert value is not None


# Generated at 2022-06-25 14:06:53.971123
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = None

# Generated at 2022-06-25 14:06:55.247224
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    test_case_0()

# Generated at 2022-06-25 14:06:59.252531
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    var_0 = HostVars(inventory=None, variable_manager=None, loader=None)
    var_1 = copy.deepcopy(var_0)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 14:07:02.976492
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    result = test_case_0().__iter__()
    assert type(result) == type(iter((1, 2))), 'expected %s, got %s' % (type(iter((1, 2))), type(result))

# Generated at 2022-06-25 14:07:04.504931
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # TODO: setstate must accept the state passed as a parameter
    assert False


# Generated at 2022-06-25 14:07:13.665082
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    test_case_0()

# Generated at 2022-06-25 14:07:17.462088
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 472
    float_0 = 627.566
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:07:18.642316
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_case_0()


# Generated at 2022-06-25 14:07:22.958967
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 583
    float_0 = 473.146
    host_vars_0 = HostVars(int_0, float_0)
    var_0 = host_vars_0.__repr__()
    assert var_0 == '583'


# Generated at 2022-06-25 14:07:28.272580
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    str_0 = host_vars_vars_0.__getitem__('test')
    assert str_0 == 'test'


# Generated at 2022-06-25 14:07:31.709952
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Create an instance of HostVars
    host_vars_0 = HostVars()
    int_0 = 581
    host_vars_vars_0 = host_vars_0.raw_get(int_0)


# Generated at 2022-06-25 14:07:36.190363
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__repr__()


test_case_0()
#test_HostVars___getitem__()

# Generated at 2022-06-25 14:07:43.347102
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Setup: create a HostVars
    inventory = Host()
    variable_manager = Mock()
    loader = Mock()
    host_vars_0 = HostVars(inventory, variable_manager, loader)

    # Exercise: call the method with some args
    host_vars_0.__getitem__(host)

    # Verify: check that the expected result is returned
    args, kwargs = variable_manager.method_calls[0]
    assert args == ('get_vars', host, 'include_hostvars', False)


# Generated at 2022-06-25 14:07:44.802837
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # FIXME: Implement test
    pass


# Generated at 2022-06-25 14:07:50.129520
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 413
    float_0 = 934.051
    host_vars_vars_0 = HostVars(int_0, float_0, float_0)
    host_name_0 = 758
    host_vars_vars_0.raw_get(host_name_0)


# Generated at 2022-06-25 14:07:58.416744
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 109
    float_0 = 947.799
    host_vars_0 = HostVars(int_0, float_0)
    host_vars_0.__repr__()


# Generated at 2022-06-25 14:08:04.729504
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test by creating an object of each class of that module
    host_vars_0 = HostVars(int_0, float_0, int_0)
    # The __iter__ method of the class HostVars should return a value for which
    # the following call would be valid.
    # var_0 = host_vars_0.__iter__()
    # Make a call to the __iter__() method from the class HostVars
    host_vars_0.__iter__()


# Generated at 2022-06-25 14:08:13.032332
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    str_0 = host_vars_0.raw_get('y')
    assert str_0 == AnsibleUndefined(name="hostvars['y']")


# Generated at 2022-06-25 14:08:15.454737
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__repr__()

# Generated at 2022-06-25 14:08:18.070380
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 3
    float_0 = 876.3
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    host_name_0 = host_vars_vars_0.__getitem__(int_0)
    print(host_name_0)


# Generated at 2022-06-25 14:08:21.807424
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    int_0 = 485
    float_0 = 636.932
    host_vars_0 = HostVars(int_0, float_0)
    class_0 = type(host_vars_0)
    class_1 = type(host_vars_0)
    host_vars_0.__setstate__(class_0, class_1)


# Generated at 2022-06-25 14:08:27.172180
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 642
    float_0 = 626.758
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__getitem__(int_0)


# Generated at 2022-06-25 14:08:30.400504
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # set up objects
    int_0 = 123
    float_0 = 12.3
    host_vars_0 = HostVars(int_0, float_0)
    # get result
    var_0 = host_vars_0.__repr__()
    #assert result
    

# Generated at 2022-06-25 14:08:34.633687
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:08:36.624576
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__repr__()



# Generated at 2022-06-25 14:08:50.677470
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 897
    float_0 = 54.35
    host_vars_0 = HostVars(int_0, float_0, int_0)
    var_0 = host_vars_0.__iter__()


# Generated at 2022-06-25 14:08:54.089188
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = -102
    float_0 = -87.719
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    for var_0 in host_vars_vars_0:
        pass

# Generated at 2022-06-25 14:09:03.451329
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 3329
    float_0 = 385.174
    host_vars_vars_0 = HostVarsVars(int_0, float_0)

    str_0 = 'kX9+'
    str_1 = '8=;.g'

    dict_0 = dict()
    dict_0[str_1] = list()
    dict_0[str_0] = list()
    dict_0[str_1].append(host_vars_vars_0)

    for elem_0 in dict_0[str_1]:
        dict_0[str_0].append(elem_0)


# Generated at 2022-06-25 14:09:05.802017
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    my_host = HostVars(inventory=None, variable_manager=None, loader=None).raw_get(host_name=None)
    assert my_host == None

# Generated at 2022-06-25 14:09:12.265832
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    """
    Unit test for method of class HostVars: __setstate__
    """
    int_0 = 28176382803730983483540942275233756877508051103431065953842749705974753621
    int_1 = 2645337
    str_0 = '<script>alert("XSS1")</script>'
    host_vars_vars_0 = HostVarsVars(int_0, int_1)
    host_vars_0 = HostVars(int_0, str_0, host_vars_vars_0)
    state = host_vars_0.__getstate__()
    host_vars_0.__setstate__(state)
    str_1 = '|alert("XSS1")<script>|'


# Generated at 2022-06-25 14:09:16.726148
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 853
    float_0 = 287.27
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:09:26.788686
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 876
    float_0 = 471.741
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__getitem__(int_0)
    var_1 = host_vars_vars_0.__getitem__(float_0)
    var_2 = host_vars_vars_0.__getitem__(float_0)
    var_3 = host_vars_vars_0.__getitem__(int_0)
    var_4 = host_vars_vars_0.__getitem__(None)
    var_5 = host_vars_vars_0.__getitem__('efd988e')

# Unit test

# Generated at 2022-06-25 14:09:29.384474
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 617
    float_0 = 823.226
    host_vars_0 = HostVars(int_0, float_0)
    var_0 = host_vars_0.__repr__()


# Generated at 2022-06-25 14:09:32.041577
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 857
    float_0 = 551.838
    host_vars_0 = HostVars(int_0, float_0, int_0)
    var_0 = host_vars_0.__repr__()


# Generated at 2022-06-25 14:09:36.672251
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__repr__()


# Generated at 2022-06-25 14:10:08.271245
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Set up test variables
    int_0 = 173
    float_0 = 127.649
    host_vars_0 = HostVars(int_0, float_0)
    # Call method __repr__ of class HostVars, and store the result in var_0
    var_0 = host_vars_0.__repr__()
    # Check if result is correct
    if var_0 == 173:
        return 'unit test succeeded'
    else:
        return 'unit test failed'


# Generated at 2022-06-25 14:10:15.309958
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__iter__()
    # assert that the counted value is equal to the return value of __iter__
    var_1 = type(host_vars_vars_0)
    var_2 = var_1.__len__(host_vars_vars_0)
    var_3 = var_1.__len__(var_0)
    assert var_2 == var_3


# Generated at 2022-06-25 14:10:19.413361
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 846
    float_0 = 863.945
    host_vars_0 = HostVars(int_0, float_0)
    var_0 = host_vars_0.raw_get(var_0)


# Generated at 2022-06-25 14:10:29.454534
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 758
    float_0 = 776.891
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    int_0 = 375
    float_0 = 397.193
    int_1 = 779
    float_1 = 779.561
    str_0 = 'str'
    int_2 = 407
    float_2 = 416.927
    str_1 = 'str'
    int_3 = 246
    float_3 = 239.595
    int_4 = 671
    float_4 = 626.847

# Generated at 2022-06-25 14:10:31.322156
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 256
    float_0 = 0.3848
    host_vars_0 = HostVars(int_0, float_0)
    out_4 = host_vars_0.__repr__()



# Generated at 2022-06-25 14:10:33.075130
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    inventory = None
    variable_manager = None
    loader = None
    # host_vars_0 = HostVars(inventory, variable_manager, loader)
    # var_0 = host_vars_0.__getitem__()



# Generated at 2022-06-25 14:10:35.018724
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    host_vars_vars_0.__iter__()
    print('Unit Test Case Passed')


# Generated at 2022-06-25 14:10:38.037194
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 807
    float_0 = 43.637
    host_vars_0 = HostVars(int_0, float_0)
    var_0 = host_vars_0.__iter__()
    try:
        assert var_0 is iter([])
    except AssertionError as e:
        raise(AssertionError(e.message))



# Generated at 2022-06-25 14:10:42.672387
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    host_vars_vars_0.__getitem__("r")


# Generated at 2022-06-25 14:10:46.254707
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 69
    float_0 = 962.869
    host_vars_0 = HostVars(int_0, float_0)
    var_0 = host_vars_0.raw_get(int_0)


# Generated at 2022-06-25 14:11:38.772448
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__getitem__()


# Generated at 2022-06-25 14:11:43.843164
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__repr__()


# Generated at 2022-06-25 14:11:52.930086
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    set_0 = set({'69': '69'})
    str_0 = str('nst')
    str_1 = str('d1')
    str_2 = str('oh')
    tuple_0 = (str_0, str_1, str_2)
    list_0 = list(tuple_0)
    tuple_1 = (str_0, list_0)
    list_1 = list(tuple_1)
    str_3 = str('7')
    str_4 = str('u/')
    str_5 = str("n'o")
    str_6 = str("-h")
    tuple_2 = (str_3, str_4, str_5, str_6)
    list_2 = list(tuple_2)

# Generated at 2022-06-25 14:11:55.544296
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 846
    float_0 = 863.945
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    result = host_vars_vars_0.__iter__()
    assert result is not None


# Generated at 2022-06-25 14:11:59.097977
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 89
    float_0 = 8.7
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:12:03.103205
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 155
    float_0 = 898.847
    char_0 = '\\'
    host_vars_0 = HostVars(int_0, float_0, char_0)
    int_1 = 12
    str_0 = host_vars_0.raw_get(int_1)


# Generated at 2022-06-25 14:12:12.106120
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    #Ansible uses AnsibleUndefined as a return type for undefined scope items
    assert HostVars(inventory_manager=None, variable_manager=None, loader=None).raw_get(host_name='dummy_host_name') == AnsibleUndefined
    #Ansible uses AnsibleUndefined as a return type for undefined scope items
    assert HostVars(inventory_manager=None, variable_manager=None, loader=None).raw_get(host_name='dummy_host_name') == AnsibleUndefined

    HostVars(inventory_manager=None, variable_manager=None, loader=None).set_inventory(inventory=None)
    assert HostVars(inventory_manager=None, variable_manager=None, loader=None).raw_get(host_name=None) == AnsibleUndefined

# Generated at 2022-06-25 14:12:14.664628
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 205
    float_0 = 742.075
    host_vars_vars_0 = HostVarsVars(int_0, float_0)
    var_0 = host_vars_vars_0.__repr__()


# Generated at 2022-06-25 14:12:18.150076
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 111
    float_0 = 0.815
    host_vars_0 = HostVars(int_0, float_0, float_0)
    str_0 = "excelfs"
    host_vars_vars_0 = host_vars_0.raw_get(str_0)


# Generated at 2022-06-25 14:12:26.114052
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # CUT begin
    int_0 = 846
    float_0 = 863.945
    ansible_version = '1.0'
    ansible_play_hosts = ['host0', 'host1', 'host2', 'host3', 'host4', 'host5', 'host6', 'host7', 'host8', 'host9']
    ansible_dependent_role_names = ['ansible_dependent_role_names_0']
    ansible_play_role_names = ['ansible_play_role_names_0']
    ansible_role_names = ['ansible_role_names_0', 'ansible_role_names_1', 'ansible_role_names_2']
    inventory_hostname = 'inventory_hostname_0'

# Generated at 2022-06-25 14:14:33.122850
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    ansible_undefined_0 = module_0.AnsibleUndefined()
    host_vars_0 = HostVars(ansible_undefined_0, ansible_undefined_0, ansible_undefined_0)
    var_0 = host_vars_0.__repr__()


# Generated at 2022-06-25 14:14:38.314421
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    ansible_undefined_0 = module_0.AnsibleUndefined()
    host_vars_0 = HostVars(ansible_undefined_0, ansible_undefined_0, ansible_undefined_0)
    host_vars_vars_0 = HostVarsVars(dict(), ansible_undefined_0)
    assert host_vars_0.__getitem__(host_vars_vars_0) == host_vars_vars_0


# Generated at 2022-06-25 14:14:41.830711
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    ansible_undefined_0 = module_0.AnsibleUndefined()
    host_vars_0 = HostVars(ansible_undefined_0, ansible_undefined_0, ansible_undefined_0)
    string_0 = "localhost"
    test_case_0(host_vars_0[string_0])


# Generated at 2022-06-25 14:14:45.319726
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    ansible_undefined_0 = module_0.AnsibleUndefined()
    host_vars_0 = HostVars(ansible_undefined_0, ansible_undefined_0, ansible_undefined_0)
    dict_0 = {}
    var_0 = host_vars_0.__setstate__(dict_0)


# Generated at 2022-06-25 14:14:50.310939
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    ansible_undefined_0 = AnsibleUndefined()
    host_vars_0 = HostVars(ansible_undefined_0, ansible_undefined_0, ansible_undefined_0)
    out_0 = {}
    dict_0 = {}
    var_0 = host_vars_0.__setstate__(dict_0)
    out_0 = host_vars_0.__repr__()


# Generated at 2022-06-25 14:14:55.249445
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    ansible_undefined_0 = module_0.AnsibleUndefined()
    host_vars_0 = HostVars(ansible_undefined_0, ansible_undefined_0, ansible_undefined_0)
    iter_0 = host_vars_0.__iter__()
    
    next_0 = iter_0.__next__()
    try:
        next_1 = iter_0.__next__()
    except StopIteration:
        pass


# Generated at 2022-06-25 14:15:01.223147
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    ansible_undefined_0 = module_0.AnsibleUndefined()
    host_vars_0 = HostVars(ansible_undefined_0, ansible_undefined_0, ansible_undefined_0)
    string_0 = "foo"
    var_0 = host_vars_0.raw_get(string_0)
    assert isinstance(var_0, module_0.AnsibleUndefined)


# Generated at 2022-06-25 14:15:05.606478
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    dict_0 = {}
    class_0 = HostVars(dict_0, dict_0, dict_0)
    ansible_undefined_0 = module_0.AnsibleUndefined()
    dict_1 = {'_loader': ansible_undefined_0}
    var_0 = class_0.__setstate__(dict_1)

if __name__ == "__main__":
    import test
    test.test(__file__, ['--verbose'])

# Generated at 2022-06-25 14:15:09.154334
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    ansible_undefined_0 = module_0.AnsibleUndefined()
    host_vars_0 = HostVars(ansible_undefined_0, ansible_undefined_0, ansible_undefined_0)
    var_0 = host_vars_0.__getitem__(ansible_undefined_0)


# Generated at 2022-06-25 14:15:13.234333
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    ansible_undefined_0 = module_0.AnsibleUndefined()
    host_vars_0 = HostVars(ansible_undefined_0, ansible_undefined_0, ansible_undefined_0)
    foo_0 = host_vars_0.__iter__()
    assert isinstance(foo_0, collections.Iterable) == True
