

# Generated at 2022-06-25 14:05:36.866495
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = "foobar"
    str_1 = "hostvars['%s']"
    var_0 = host_vars_0.raw_get(str_0)
    var_1 = str_1 % str_0
    assert var_0.name == var_1
    bool_1 = False
    host_vars_1 = HostVars(bool_1, tuple_0, tuple_0)
    var_2 = host_vars_1.raw_get(str_0)
    assert var_2.name == var_1


# Generated at 2022-06-25 14:05:41.678828
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    __tracebackhide__ = True
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = ''
    obj_0 = host_vars_0.raw_get(str_0)
    assert obj_0 is not None


# Generated at 2022-06-25 14:05:44.407169
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    tuple_0 = ()
    bool_0 = True
    host_vars_0 = HostVars(tuple_0, tuple_0, tuple_0)
    str_0 = "this is a string"
    assert host_vars_0[str_0] == AnsibleUndefined()


# Generated at 2022-06-25 14:05:47.856210
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    value = host_vars_0.__repr__()
    assert (value == "{}")


# Generated at 2022-06-25 14:05:54.825485
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    instance = host_vars_0.__iter__()
    try:
        assert(isinstance(instance, type) and issubclass(instance, bool_0))
    except AssertionError as e:
        raise AssertionError(e)


# Generated at 2022-06-25 14:06:00.278730
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_1 = True
    tuple_1 = ()
    dict_0 = dict()
    list_12 = list()
    host_vars_1 = HostVars(bool_1, tuple_1, list_12)
    try:
        assert repr(host_vars_1) == repr(dict_0)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 14:06:01.623005
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # TODO: implement the assertion
    assert True


# Generated at 2022-06-25 14:06:06.063662
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = False
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_1 = '_aZdh6DzU6'
    dict_1 = host_vars_0.raw_get(str_1)


# Generated at 2022-06-25 14:06:09.596950
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    assert not isinstance(iter(host_vars_0), (list, tuple))


# Generated at 2022-06-25 14:06:11.831539
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)


# Generated at 2022-06-25 14:06:19.029125
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    for item_0 in host_vars_0:
        print('{}'.format(item_0))


# Generated at 2022-06-25 14:06:23.555717
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(tuple_0, tuple_0, tuple_0)
    set_0 = set()
    for str_0 in host_vars_0:
        set_0.add(str_0)
    bool_1 = len(host_vars_0) == len(set_0)
    assert bool_1 == bool_0


# Generated at 2022-06-25 14:06:27.804481
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = "c5b5V0m0{*^<"
    foo_0 = host_vars_0[str_0]


# Generated at 2022-06-25 14:06:32.244474
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    result_gen = host_vars_0.__iter__()
    result_gen.__init__()
    assert result_gen.__init__() is None


# Generated at 2022-06-25 14:06:35.393359
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    value_0 = host_vars_0.__iter__()
    assert value_0 is not None


# Generated at 2022-06-25 14:06:38.419118
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    repr_0 = repr
    tuple_0 = ()
    host_vars_0 = HostVars(tuple_0, tuple_0, tuple_0)
    assert repr_0(host_vars_0) == "{}"


# Generated at 2022-06-25 14:06:42.146244
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = str()
    str_1 = str(host_vars_0)
    assert str_0 == str_1


# Generated at 2022-06-25 14:06:44.316394
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    data = {'foo': 'bar'}
    obj = HostVarsVars(data, None)
    assert list(iter(obj)) == ['foo']


# Generated at 2022-06-25 14:06:47.230087
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
        bool_0 = True
        tuple_0 = ()
        host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
        out = host_vars_0.__repr__()

        assert(out == "{}")

# Generated at 2022-06-25 14:06:53.223005
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    unicode_0 = host_vars_0['localhost']
    list_0 = list(unicode_0)
    assert list_0 == []

# Generated at 2022-06-25 14:07:00.290736
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_1 = True
    tuple_1 = ()
    host_vars_1 = HostVars(bool_1, tuple_1, tuple_1)
    str_1 = host_vars_1.__getitem__()
    return str_1

# Generated at 2022-06-25 14:07:03.209942
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    assert isinstance(host_vars_0['foo'], (AnsibleUndefined,))


# Generated at 2022-06-25 14:07:07.888510
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # param 0: str
    # param 1: str
    # param 2: str
    host_vars_0 = HostVars(dict(), dict(), dict())
    foo = host_vars_0.__getitem__('value0', 'value1', 'value2')


# Generated at 2022-06-25 14:07:14.572244
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    bool_0 = True
    dict_0 = dict()
    host_vars_0 = HostVars(bool_0, dict_0, dict_0)
    dict_1 = dict()
    dict_1['foo'] = 'bar'
    host_vars_0.__setstate__(dict_1)
    host_vars_0.__setstate__(dict_0)


# Generated at 2022-06-25 14:07:20.411868
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Case 0
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = "zV"
    __retval_0 = host_vars_0[str_0]
    assert __retval_0 == AnsibleUndefined(name="hostvars['zV']")


# Generated at 2022-06-25 14:07:26.662059
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_1 = '!v@8wH%7]yNe\\'
    dict_1 = host_vars_0.raw_get(str_1)
    dict_2 = host_vars_0[str_1]
    assert(dict_1 is dict_2)


# Generated at 2022-06-25 14:07:30.549257
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = "U"
    var_0 = host_vars_0[str_0]


# Generated at 2022-06-25 14:07:37.029163
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    tuple_1 = ()
    module_0 = AnsibleModule(argument_spec={})
    # 'data': 'foo', 'ansible_connection': 'local', 'ansible_ssh_host': '127.0.0.1', 'ansible_ssh_user': 'vagrant'}
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_1)
    assert not host_vars_0['data']

# Generated at 2022-06-25 14:07:41.384963
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(tuple_0, tuple_0, tuple_0)
    str_0 = str()
    assert str_0 == host_vars_0.__repr__()


# Generated at 2022-06-25 14:07:45.235818
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = 'foobar'
    assert isinstance(host_vars_0.raw_get(str_0), AnsibleUndefined)


# Generated at 2022-06-25 14:07:53.042997
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)

    host_vars_0.__iter__()


# Generated at 2022-06-25 14:08:02.869924
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False
    dict_1 = dict()
    dict_1['inventory_hostname'] = 'localhost'
    dict_2 = dict()
    dict_2['hostname'] = 'localhost'
    dict_3 = dict()
    dict_3['_meta'] = dict_2
    dict_4 = dict()
    dict_4['localhost'] = dict_1
    dict_4['_meta'] = dict_2
    tuple_0 = (dict_4, dict_3)
    str_0 = 'localhost'

    host_vars_0 = HostVars(tuple_0, tuple_0, tuple_0)
    assert str_0 in dict(host_vars_0)


# Generated at 2022-06-25 14:08:06.752909
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    tuple_0 = ()
    tuple_1 = (1, 2, 3, 4)
    tuple_2 = ()
    host_vars_0 = HostVars(tuple_0, tuple_1, tuple_2)
    host_vars_0.__setstate__(tuple_2)


# Generated at 2022-06-25 14:08:07.818285
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    test_case_0()

# Generated at 2022-06-25 14:08:12.941462
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = '''localhost'''
    dict_0 = host_vars_0.raw_get(str_0)


# Generated at 2022-06-25 14:08:15.665008
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    '''test_HostVarsVars___getitem___0'''
    test_case_0()

# vim: syntax=python:expandtab:shiftwidth=4:softtabstop=4

# Generated at 2022-06-25 14:08:19.043812
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    bool_1 = host_vars_0.__getitem__('foo')
    assert bool_1 is False


# Generated at 2022-06-25 14:08:23.266008
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    value_0 = host_vars_0.raw_get(None)


# Generated at 2022-06-25 14:08:28.197478
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    assert repr(host_vars_0) == "{'foo': 'bar'}"


# Generated at 2022-06-25 14:08:37.767448
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    # AssertionError: <ansible_version, ansible_play_hosts, ansible_dependent_role_names, ansible_play_role_names, ansible_role_names, inventory_hostname, inventory_hostname_short, inventory_file, inventory_dir, groups, group_names, omit, playbook_dir, play_hosts, role_names, ungrouped> != <ansible_version, ansible_play_hosts, ansible_dependent_role_names, ansible_play_role_names, ansible_role_names, inventory_hostname, inventory_hostname_short, inventory_file, inventory_dir, groups, group_names, omit, playbook

# Generated at 2022-06-25 14:08:52.519876
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    host_name_0 = 'localhost'
    test_0 = host_vars_0.raw_get(host_name_0)
    assert test_0 == {}, "Expected {}, but got {}".format({}, test_0)


# Generated at 2022-06-25 14:08:56.172423
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    repr_ret_1 = repr(host_vars_0)
    assert repr_ret_1 == '{}'


# Generated at 2022-06-25 14:08:59.629931
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    state_0 = {}
    host_vars_0 = HostVars(mock.MagicMock(), mock.MagicMock(), mock.MagicMock())
    host_vars_0.__setstate__(state_0)


# Generated at 2022-06-25 14:09:07.158632
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = "J\x9ewU\xad\x8d\xc1\xb1\"\x1a\xdc\xef\xa4\x9e\x86\x8e"
    with pytest.raises(AnsibleUndefined):
        host_vars_0.__getitem__(str_0)



# Generated at 2022-06-25 14:09:09.924970
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = False
    tuple_0 = ()
    class_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = 'G'
    str_1 = class_0.raw_get(str_0)


# Generated at 2022-06-25 14:09:13.413153
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    string_0 = host_vars_0['string_0']


# Generated at 2022-06-25 14:09:24.307460
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    # Test the case where the expected result is True
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    for iter0 in host_vars_0:
        pass

    # Test the case where the expected result is True
    tuple_0 = ()
    host_vars_0 = HostVars(None, tuple_0, tuple_0)
    for iter0 in host_vars_0:
        pass

    # Test the case where the expected result is True
    host_vars_0 = HostVars(None, None, {})
    for iter0 in host_vars_0:
        pass

    # Test the case where the expected result is True

# Generated at 2022-06-25 14:09:27.487076
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = host_vars_0.__repr__()
    assert str_0 == "{}"


# Generated at 2022-06-25 14:09:34.579617
# Unit test for method __repr__ of class HostVars

# Generated at 2022-06-25 14:09:39.489138
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    assert ((repr(host_vars_0)) == (repr({})))
    

# Generated at 2022-06-25 14:10:07.006165
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = "0"
    ansible_undefined_0 = AnsibleUndefined(str_0)
    result = host_vars_0.raw_get(str_0)
    assert(repr(result) == repr(ansible_undefined_0))
    assert(result == ansible_undefined_0)
    assert(str(result) == str(ansible_undefined_0))


# Generated at 2022-06-25 14:10:10.731972
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    exception_0 = False
    exception_0 = True
    try:
        for host_name in host_vars_0:
            pass
    except Exception:
        exception_0 = False

    assert exception_0


# Generated at 2022-06-25 14:10:15.928880
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    def side_effect_0(hostname_0):
        yield hostname_0
    result = host_vars_0.__iter__()
    assert type(result) == type(side_effect_0)


# Generated at 2022-06-25 14:10:20.847328
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = 'bin'
    assert host_vars_0[str_0] == '/usr/bin'


# Generated at 2022-06-25 14:10:28.692700
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    with pytest.raises(KeyError):
        host_vars_0.__getitem__('str_0')
    with pytest.raises(KeyError):
        host_vars_0.__getitem__(tuple_0)
    with pytest.raises(KeyError):
        host_vars_0.__getitem__(512)
    with pytest.raises(KeyError):
        host_vars_0.__getitem__('str_1')

# Generated at 2022-06-25 14:10:31.144087
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    assert isinstance(host_vars_0, HostVars) == True
    assert tuple(host_vars_0) == ()


# Generated at 2022-06-25 14:10:33.484296
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    print('Test for HostVars::raw_get')
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    tuple_0 = ()
    assert tuple_0 == host_vars_0.raw_get(())


# Generated at 2022-06-25 14:10:39.640413
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    tuple_1 = (1,)
    tuple_2 = (2,)
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_1)
    str_0 = host_vars_0.__iter__()
    str_1 = host_vars_0.__iter__()
    assert str_0 == str_1
    str_1 = host_vars_0.__iter__()
    assert str_0 == str_1
    str_1 = host_vars_0.__iter__()
    assert str_0 == str_1
    str_1 = host_vars_0.__iter__()
    assert str_0 == str_1
    str_1 = host_vars_0.__iter__()


# Generated at 2022-06-25 14:10:44.544989
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    assert len(list(host_vars_0.__iter__())) == 0


# Generated at 2022-06-25 14:10:49.832693
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory_0 = Inventory(loader=None, variable_manager=None, host_list=None)
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager(loader=loader_0, inventory=inventory_0)
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    result = host_vars_0.raw_get('127.0.0.1')
    assert result is not None


# Generated at 2022-06-25 14:11:39.499327
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    assert host_vars_0.__repr__() == "{}"


# Generated at 2022-06-25 14:11:50.241526
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = '''
    [main]
    localhost ansible_connection=local

    [other]
    localhost

    [ungrouped]
    localhost
    '''

    loader = DictDataLoader({
        "hostvars": { 
            "localhost": {
                "foo": "bar",
                "baz": "{{ foo }}",
            }
        }
    })
    host_vars = HostVars(inventory, loader=loader)

    assert host_vars.raw_get("localhost")['baz'] == "{{ foo }}"
    assert host_vars.raw_get("localhost")['foo'] == "bar"
    assert host_vars.raw_get("notlocalhost") == AnsibleUndefined()



# Generated at 2022-06-25 14:11:53.121103
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    for key in host_vars_0:
        pass


# Generated at 2022-06-25 14:11:59.122884
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = False
    str_1 = 'local'
    tuple_0 = ()
    str_0 = 'localhost'
    host_vars_1 = HostVars(bool_0, str_1, tuple_0)
    result_1 = host_vars_1[str_0]
    assert result_1 == AnsibleUndefined(name="hostvars['localhost']")
    bool_1 = True
    host_vars_2 = HostVars(bool_1, str_0, tuple_0)
    result_2 = host_vars_2[str_1]
    assert result_2 == AnsibleUndefined(name="hostvars['local']")


# Generated at 2022-06-25 14:12:02.794252
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    str_0 = ""
    ansible_undefined_0 = host_vars_0.raw_get(str_0)


# Generated at 2022-06-25 14:12:07.880018
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    temp_0 = host_vars_0.raw_get('nginx')
    assert temp_0 is AnsibleUndefined
    assert temp_0 == AnsibleUndefined(name="hostvars['nginx']")


# Generated at 2022-06-25 14:12:11.450147
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    return_value_0 = host_vars_0.__repr__()
    assert return_value_0 == "{}"


# Generated at 2022-06-25 14:12:17.034541
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    host_name_0 = "lsxhrzpkpnmf.com"
    var_0 = host_vars_0.__getitem__(host_name_0)
    assert var_0 is None, "expected:<%s> but was:<%s>" % (None, var_0)


# Generated at 2022-06-25 14:12:19.546556
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    tuple_0 = ()
    host_vars_0 = HostVars(bool_0, tuple_0, tuple_0)
    host_vars_0.__repr__()


# Generated at 2022-06-25 14:12:23.079746
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    temp_0 = True
    tuple_0 = ()
    tuple_1 = ()
    host_vars_0 = HostVars(temp_0, tuple_0, tuple_1)
    repr_0 = host_vars_0.__repr__()
    assert repr_0 is not None
