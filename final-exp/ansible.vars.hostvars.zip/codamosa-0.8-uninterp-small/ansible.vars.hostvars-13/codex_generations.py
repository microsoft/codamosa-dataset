

# Generated at 2022-06-25 14:05:39.441572
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)


# Generated at 2022-06-25 14:05:44.518904
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    print ( "TEST: test_HostVars___repr__")
    inventory_0 = FakeInventory()
    variable_manager_0 = FakeVariableManager()
    loader_0 = FakeLoader()
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    ret_val_0 = host_vars_0.__repr__()
    exp_ret_val_0 = False
    assert ret_val_0 == exp_ret_val_0, "motivation test case 0 failed"


# Generated at 2022-06-25 14:05:55.556964
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    host_name_0 = b'\xba\xfd\xef\x1a\xe3\xf4\xe4\x81\x90\x91\x80\x84\xdd\xe4\xee\xf9\x98\xc4\x75\x81\xec\xca\x84\x97\xc4\xfc\xf9\x86\x7f\x0e\xab\xe3\xfc'
    var_0 = host_vars_0.raw_get(host_name_0)
    assert isinstance(var_0, AnsibleUndefined)

#

# Generated at 2022-06-25 14:05:58.272662
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_vars_0 = HostVars()
    int_0 = host_vars_0.__getitem__(0)
    print(int_0)


# Generated at 2022-06-25 14:06:02.585391
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars(int(), int(), int())
    bytes_0 = b'\xea\xe8k\xa2\xdc'
    str_0 = str(bytes_0)
    print(list(host_vars_0)[:])


# Generated at 2022-06-25 14:06:11.825404
# Unit test for method __getitem__ of class HostVars

# Generated at 2022-06-25 14:06:12.613353
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert True


# Generated at 2022-06-25 14:06:14.989180
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # create an instance of the class
    class_instance = HostVars()
    # assert the __iter__ method is present
    assert class_instance.__iter__()


# Generated at 2022-06-25 14:06:18.463321
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    target = HostVars(None, None, None)
    res = target.__iter__()
    assert '__iter__ method works' == '__iter__ method works'


# Generated at 2022-06-25 14:06:25.438018
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    assert repr(host_vars_vars_0) == repr(BytesIO(b'\xcf\xb7\xa0\x18'))
    assert repr(host_vars_0) == repr(dict(zip(list(BytesIO(b'\xcf\xb7\xa0\x18')), [host_vars_vars_0] * len(list(BytesIO(b'\xcf\xb7\xa0\x18'))))))


# Generated at 2022-06-25 14:06:34.804219
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    setattr(host_vars_vars_0, '_hostvars', host_vars_vars_0)
    setattr(host_vars_vars_0, '_loader', host_vars_vars_0)
    host_vars_vars_0.__setstate__(host_vars_vars_0)
    assert True


# Generated at 2022-06-25 14:06:41.595882
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Create instance of HostVarsVars
    host_vars_vars_0 = HostVarsVars(float('nan'), b'\x00')
    # Create instance of HostVars
    host_vars_0 = HostVars(host_vars_vars_0, host_vars_vars_0, host_vars_vars_0)
    host_vars_0.__getitem__(float('nan'))
    # Verify Exception is raised
    with pytest.raises(KeyError):
        host_vars_0[float('nan')]


# Generated at 2022-06-25 14:06:45.648428
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x0b'
    host_vars_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    # FIXME:Iteration through a non-iterable object is not currently supported
    # for k in host_vars_vars_0:
    #     pass
    return


# Generated at 2022-06-25 14:06:57.637173
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Mock the inventory
    mock_host_0 = create_autospec(Host, instance=True)
    mock_inventory_0 = create_autospec(Inventory, instance=True)
    mock_inventory_0.get_host.return_value = mock_host_0

    # Mock the variable manager
    mock_variable_manager_0 = create_autospec(VariableManager, instance=True)
    mock_variable_manager_0.get_vars.return_value = mock_variable_manager_0._hostvars

    # Mock the loader
    mock_loader_0 = create_autospec(DataLoader, instance=True)

    host_vars_0 = HostVars(mock_inventory_0, mock_variable_manager_0, mock_loader_0)

# Generated at 2022-06-25 14:07:02.633107
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    str_0 = host_vars_vars_0['\xcf\xb7\xa0\x18']
    str_1 = host_vars_vars_0['\xcf\xb7\xa0\x18']



# Generated at 2022-06-25 14:07:05.048642
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars(0, 0, 0)
    try:
        for i0 in host_vars_0:
            pass
    except:
        print('Uncaught exception')


# Generated at 2022-06-25 14:07:17.318880
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    dict_0 = dict()
    variables_0 = dict_0
    loader_0 = bytes_0
    host_vars_0 = HostVars(variables_0, variables_0, loader_0)
    dict_0 = dict()
    dict_1 = dict()
    str_0 = str()
    str_1 = str(dict_1)
    dict_1[str_0] = str_1
    dict_0[str_0] = dict_1
    str_2 = str()
    str_3 = str()
    dict_0[str_2] = str_3
    str_4 = str

# Generated at 2022-06-25 14:07:22.957664
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    stream = BytesIO()
    host_vars_0 = HostVars(stream, stream, stream)
    host_vars_0_dict = host_vars_0
    exceptions_0 = pickle.PicklingError()
    try:
        pickle.dump(host_vars_0, stream)
    except exceptions_0:
        pass
    else:
        assert False

# Generated at 2022-06-25 14:07:27.401365
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    int_0 = host_vars_vars_0[0]


# Generated at 2022-06-25 14:07:34.769819
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # First, create an object of the class HostVars
    tmp_inventory = dict()
    tmp_variable_manager = dict()
    tmp_loader = dict()
    host_vars_0 = HostVars(tmp_inventory, tmp_variable_manager, tmp_loader)

    # Second, test the method raw_get
    tmp_host_name = dict() # TODO - write real unit test
    actual_out_0 = host_vars_0.raw_get(tmp_host_name)
    assert isinstance(actual_out_0, AnsibleUndefined)


# Generated at 2022-06-25 14:07:48.479907
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars()

# Generated at 2022-06-25 14:07:55.749845
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    dict_0 = {}
    dict_1 = {}
    dict_1['stdout_lines'] = ['test']
    inventory_hostname_0 = 'test'
    dict_0[inventory_hostname_0] = dict_1
    templar_0 = Templar(dict_0)
    for (inventory_hostname_0, dict_0) in templar_0.items():
        vars_0 = dict_0
    host_vars_0 = HostVars(templar_0, templar_0)
    list_0 = []
    for inventory_hostname_1 in host_vars_0:
        list_0.append(inventory_hostname_1)


# Generated at 2022-06-25 14:07:56.433627
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    pass


# Generated at 2022-06-25 14:08:06.058901
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    inventory = None
    variable_manager = None
    loader = None
    host_vars = HostVars(inventory, variable_manager, loader)
    inventory = '\x96\x0b\x15'

# Generated at 2022-06-25 14:08:07.999895
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    foo = AnsibleUndefined
    HostVars(foo, foo, foo)



# Generated at 2022-06-25 14:08:16.633633
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    # set up test
    host_vars_0 = HostVars(host_vars_vars_0, host_vars_vars_0, host_vars_vars_0)
    test_host_name_0 = 'i5x,x5N[+@q3!Ie:a'
    # unit test
    assert host_vars_0[test_host_name_0] is not None


# Generated at 2022-06-25 14:08:21.145503
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'h\xb6]\xf6\xa4\xcd'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    host_vars_0 = HostVars(host_vars_vars_0, bytes_0, bytes_0)
    object_0 = host_vars_0.__iter__()
    assert (isinstance(object_0, list))


# Generated at 2022-06-25 14:08:31.036614
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    '''
    Unit test for method __setstate__ of class HostVars
    '''

    host_vars_0 = HostVars(None, None, None)
    host_vars_1 = HostVars(None, None, None)
    host_vars_2 = HostVars(None, None, None)
    host_vars_3 = HostVars(None, None, None)
    host_vars_4 = HostVars(None, None, None)
    host_vars_5 = HostVars(None, None, None)
    host_vars_6 = HostVars(None, None, None)
    host_vars_7 = HostVars(None, None, None)
    host_vars_8 = HostVars(None, None, None)
    host_vars

# Generated at 2022-06-25 14:08:36.259858
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xff\xae\xa1\x9e'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    host_vars_0 = HostVars(bytes_0, bytes_0)
    host_vars_vars_0 = host_vars_0[bytes_0]


# Generated at 2022-06-25 14:08:38.245599
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    result = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:08:59.024631
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    instance = HostVarsVars(None)
    # No-op function, test if it runs without errors
    instance.__setstate__()

# Generated at 2022-06-25 14:09:04.140757
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)

    host_vars_vars_0.__setstate__(host_vars_vars_0)


# Generated at 2022-06-25 14:09:09.490379
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    bytes_1 = b'\xdb\xae\xb7\x16'
    str_0 = host_vars_0.__repr__()
    assert str_0 == '{}'



# Generated at 2022-06-25 14:09:19.572984
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Test case 0
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    str_0 = host_vars_0.raw_get(bytes_0)
    assert not hasattr(str_0, '__iter__')
    #assert len(str_0) == 0 and str_0 == ()

    # Test case 1
    bytes_1 = b'\xf6\x90\x08\x9a\xb8'
    host_vars_1 = HostVars(bytes_1, bytes_1, bytes_1)
    str_1 = host_vars_1.raw_get(bytes_1)
    assert not hasattr(str_1, '__iter__')

# Generated at 2022-06-25 14:09:27.374593
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars_vars_0 = HostVarsVars(eval("'./.ansible/tmp/ansible-tmp-1601262874.8248894-197451415585460/'"), eval("'./.ansible/tmp/ansible-tmp-1601262874.8248894-197451415585460/'"), eval("'./.ansible/tmp/ansible-tmp-1601262874.8248894-197451415585460/'"))
    host_vars_vars_0.__repr__()
    assert True


# Generated at 2022-06-25 14:09:32.567919
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    str_0 = host_vars_0[bytes_0]
    assert len(str_0) == 4
    assert str_0 == host_vars_vars_0


# Generated at 2022-06-25 14:09:39.312963
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    int_0 = host_vars_0.__getitem__(bytes_0)
    assert int_0 is not AnsibleUndefined
    assert int_0 is not None
    assert len(int_0) is not 0


# Generated at 2022-06-25 14:09:48.666250
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\xb9\xa6\xa2iw\xb2\x80\xbe\x97\xbe\xbe'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    assert repr(host_vars_0) == "{b'\\xb9\\xa6\\xa2iw\\xb2\\x80\\xbe\\x97\\xbe\\xbe': {b'\\xb9\\xa6\\xa2iw\\xb2\\x80\\xbe\\x97\\xbe\\xbe': AnsibleUndefined(name='hostvars[b\\xb9\\xa6\\xa2iw\\xb2\\x80\\xbe\\x97\\xbe\\xbe]')}}"


# Generated at 2022-06-25 14:09:50.971445
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars(None, None, None)
    for item_0 in host_vars_0:
        return


# Generated at 2022-06-25 14:09:53.559581
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars_target = 'The HostVars representation'
    host_vars_var_0 = HostVars()
    host_vars_var_0.__repr__() == host_vars_target


# Generated at 2022-06-25 14:10:19.155154
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_vars_vars_0 = HostVars(None, None)
    str_0 = host_vars_vars_0['']
    print(str_0)


# Generated at 2022-06-25 14:10:29.262112
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
  bytes_0 = b'\x7fU\x97\xf7'
  bytes_1 = b'\x00\x01\x00\x00\x00\x03\x00\x00\x00\x04\x00\x00\x07\x08\x00\x09'
  str_0 = 'D)a'
  str_1 = 'u\x00\x00\x00\x00'
  str_2 = '2'
  str_3 = '|'
  str_4 = '\x08'
  bytes_2 = b'\x1b\xfdw\xc8'

# Generated at 2022-06-25 14:10:31.558233
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    str_0 = repr(host_vars_0)

# unit test for method __contains__ of class HostVars

# Generated at 2022-06-25 14:10:36.203291
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    long_0 = long()
    long_1 = long()
    long_2 = long()
    long_3 = long()
    long_4 = long()
    long_5 = long()
    long_6 = long()
    long_7 = long()
    long_8 = long()
    long_9 = long()
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()


# Generated at 2022-06-25 14:10:39.067474
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    loader = DictDataLoader({})
    host_vars_vars_0 = HostVars(None, None, loader)
    host_vars_vars_0.__setstate__({'_inventory': {}, '_loader': {}, '_variable_manager': {}})


# Generated at 2022-06-25 14:10:44.840972
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    result = host_vars_vars_0.__iter__()
    assert isinstance(result, type(iter([])))


# Generated at 2022-06-25 14:10:49.119359
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)

    # Test with a valid argument
    assert host_vars_vars_0.__repr__() == "b'\\xcf\\xb7\\xa0\\x18'"


# Generated at 2022-06-25 14:10:51.338793
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = HostVars(1, 1, 1)
    host_vars_0.raw_get(1)

# Generated at 2022-06-25 14:10:55.160010
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    host_vars_vars_0 = host_vars_0.raw_get(bytes_0)
    assert isinstance(host_vars_vars_0, HostVarsVars)

# Generated at 2022-06-25 14:10:59.199212
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Test for case 0
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    condition = repr(host_vars_vars_0) == "b'\xcf\xb7\xa0\x18'"
    assert condition


# Generated at 2022-06-25 14:11:58.850204
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xa7'
    bytes_1 = b'B'
    host_vars_0 = HostVars(bytes_0, bytes_1, bytes_0)
    host_vars_0.__getitem__(b'\x0f\x12\x03')
    host_vars_0.__getitem__(b'\xe6\x0e\\B\x05\xaa')
    host_vars_0.__getitem__(b'\x15\xee')
    host_vars_0.__getitem__(b'\x0f\x12\x03')
    host_vars_0.__getitem__(b'\xe6\x0e\\B\x05\xaa')
    host_vars_0.__getitem

# Generated at 2022-06-25 14:12:00.459386
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    try:
        host_vars_0 = HostVars(None, None, None)
        host_vars_0.__iter__()
    except TypeError:
        pass


# Generated at 2022-06-25 14:12:01.563901
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    assert 0 == HostVars.__repr__.__self__



# Generated at 2022-06-25 14:12:11.151484
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Case 0:
    # This is a weird test case for developer to see how __getitem__ works.

    # first, let's try to get one variable:
    data = {'foo': 'bar'}
    host_vars_vars_0 = HostVarsVars(data, AnsibleUndefined)
    result = host_vars_vars_0['foo']  # this will finish the __getitem__ method of class HostVarsVars
    assert result == 'bar'  # well, we expect that the result should be 'bar'

    # Second, let's see how the method __getitem__ of class HostVarsVars works:
    data = {'a': 'b'}
    host_vars_vars_1 = HostVarsVars(data, AnsibleUndefined)
    # The first thing __

# Generated at 2022-06-25 14:12:12.981811
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Test for method __getitem__ of class HostVars
    assert True # TODO: implement your test here


# Generated at 2022-06-25 14:12:15.405555
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars_0 = HostVars(None, None, None)
    assert type(host_vars_0.__repr__()) is str


# Generated at 2022-06-25 14:12:23.342731
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\xf2B\x0c\x01\x02'
    bytes_1 = b'\xb1\xef'
    dict_0 = dict()
    dict_1 = dict()
    dict_0[bytes_0] = dict_1
    bytes_2 = b'\xeb\xe6\xb3\xb2'
    dict_1[bytes_2] = bytes_2
    dict_1['\x02'] = bytes_0
    bytes_3 = b'\xda\x8d\xaa\x9c9\x14\x8e'
    bytes_4 = b'\xb0\xf4'
    dict_1['\x04'] = bytes_4
    dict_1['\x05'] = bytes_4

# Generated at 2022-06-25 14:12:31.216587
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    loader_0 = DataLoader()
    variable_manager_0 = VariableManager(loader=loader_0)

    hostvars_0 = HostVars(dict(), variable_manager_0, loader_0)
    hostvars_1 = HostVars(dict(), variable_manager_0, loader_0)
    hostvars_1.__setstate__(hostvars_0)

    # assert hostvars_1._variable_manager._hostvars == hostvars_0
    assert hostvars_1._variable_manager._hostvars == hostvars_1

    # assert var_name == 'VARS'
    var_name = 'VARS'
    # assert var_name in hostvars_1
    assert hostvars_1._variable_manager.extra_vars == 'VARS'
    assert hostv

# Generated at 2022-06-25 14:12:33.604771
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x05\x00\x06\x00'
    host_vars = HostVars(bytes_0, bytes_0, bytes_0)
    obj = host_vars.__iter__()



# Generated at 2022-06-25 14:12:37.011052
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Initialize
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    str_0 = 's\x0f\x1e\x8a'

    # Test method
    key = str_0
    host_vars_0.__getitem__(key)


# Generated at 2022-06-25 14:14:49.580497
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    print(test_case_0.__doc__)
    try:
        test_case_0()
    except Exception as err:
        import sys
        print("FAIL: test_case_0()")
        print(err)
        print(traceback.print_exc())
        sys.exit(1)

    print('PASS: test_case_0()')

# Local variables:
# mode: python
# End:

# Generated at 2022-06-25 14:14:54.418386
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    integer_0 = host_vars_0.raw_get(s)
    host_vars_vars_0 = HostVarsVars(bytes_0, bytes_0)
    integer_1 = host_vars_vars_0.raw_get(host_vars_0)


# Generated at 2022-06-25 14:15:01.288511
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\xb9\xa0\x1d\x1b'
    bytes_1 = b'\x8b\xa9\x80\x0b\x8e'
    testcase_0 = test_case_0()

    # Test case 1
    testcase_1 = str()
    host_vars_vars_0 = HostVars(testcase_0, bytes_0, bytes_0)
    host_vars_vars_1 = host_vars_vars_0[testcase_0]


# Generated at 2022-06-25 14:15:07.288707
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars(None, None, None)
    setstate_0 = {'_inventory': None, '_loader': None, '_variable_manager': None}
    with patch.object(VariableManager, '__setstate__', return_value=None) as mock:
        host_vars_0.__setstate__(setstate_0)
        host_vars_0._variable_manager.__setstate__.assert_called_once_with(setstate_0)
        assert host_vars_0._inventory is None
        assert host_vars_0._loader is None
        assert host_vars_0._variable_manager is None


# Generated at 2022-06-25 14:15:11.818377
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    dict_0 = {'a' : False, 'b' : True, 'c' : 'foo', 'd' : 1, 'e' : 'bar'}
    host_vars_0 = HostVars(dict_0, dict_0, dict_0)
    assert (repr(host_vars_0) == "{'a': False, 'b': True, 'c': 'foo', 'd': 1, 'e': 'bar'}")


# Generated at 2022-06-25 14:15:16.132492
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\xcf\xb7\xa0\x18'
    host_vars_0 = HostVars(bytes_0, bytes_0, bytes_0)
    try:
        host_vars_0.__repr__()
    except NameError as exception_0:
        if exception_0.args == (b'inventory_hostname',):
            assert True
        else:
            assert False
    else:
        assert False
