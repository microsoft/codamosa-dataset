

# Generated at 2022-06-25 14:05:38.403621
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "7D>>QtyH<CZmZ'Li"
    float_0 = -1818.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    str_1 = "7D>>QtyH<CZmZ'Li"
    float_1 = -1818.0
    host_vars_vars_1 = HostVarsVars(str_1, float_1)
    with pytest.raises(TypeError):
        host_vars_vars_0.__iter__()



# Generated at 2022-06-25 14:05:43.585328
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = "7D>>QtyH<CZmZ'Li"
    float_0 = -1818.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)

    result = host_vars_vars_0
    # ansible.module_utils.common.Mapping.__repr__
    assert result == "7D>>QtyH<CZmZ'Li"

# Generated at 2022-06-25 14:05:50.386065
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = "}\n\t\\"
    float_1 = -2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_1)
    str_1 = "E1nV"
    float_2 = -1689.0
    host_vars_vars_1 = HostVarsVars(str_1, float_2)
    host_vars_0 = HostVars(host_vars_vars_0, host_vars_vars_1)


# Generated at 2022-06-25 14:05:56.225832
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "7D>>QtyH<CZmZ'Li"
    float_0 = -1818.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    # assert len(host_vars_vars_0) == 0


# Generated at 2022-06-25 14:06:03.278196
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    host_vars_vars_3 = HostVars(host, loader, variable_manager)
    host_0 = False
    dict_0 = dict()
    dict_1 = dict()
 
    # Unit test for method set_nonpersistent_facts of class HostVars
    str_1 = "7D>>QtyH<CZmZ'Li"
    float_1 = -1818.0
    host_vars_vars_1 = HostVarsVars(str_1, float_1)


# Generated at 2022-06-25 14:06:08.702220
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Instance of class HostVars with arbitrary state
    host_vars_0 = HostVars(None, None, None)
    # Instance of class Host with arbitrary state
    host_0 = Host()
    # Examples for input parameter 'arg_0'
    facts_0 = {}
    # Invoke method
    host_vars_0.set_nonpersistent_facts(host_0, facts_0)


# Generated at 2022-06-25 14:06:10.342091
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = "7D>>QtyH<CZmZ'Li"
    float_0 = -1818.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)


# Generated at 2022-06-25 14:06:21.260321
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = invert('nukh_wzm8')
    bool_0 = (str_0 == 'Hp?/1')
    dict_0 = dict()
    dict_0[-84.23] = list(set(['y', 'z', chr(97), 'z', 'y', 'y', 'z']))
    dict_0[-253.0] = list([chr(98)])
    dict_0[5] = list([chr(97)])
    dict_0[-223.78] = list([chr(98)])
    dict_0[-136.0] = list([chr(98)])
    dict_0[-154.37] = list(set(['z', 'y', chr(97), 'y', 'z']))
    dict_0

# Generated at 2022-06-25 14:06:31.189306
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    str_0 = 'JY00{'
    int_0 = 805793332
    int_1 = 927670045
    dict_0 = {
        '@xn=;': '1_5',
        '#C3o@}p': 'Ty:bR[X%(N]',
        'mz;': -228.0,
        'XP<]M': 'P$YaYXQ*1}',
        ',': '%lZV&2O4l',
        'T?(:': 86.0,
        'D': -0.7601635858802083,
        'i': 21.2,
        'fY': 'Kq3~',
        '8jK': '!>|,5'
    }
    host_vars_0

# Generated at 2022-06-25 14:06:35.012786
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
  str_0 = "7D>>QtyH<CZmZ'Li"
  float_0 = -1818.0
  host_vars_vars_0 = HostVarsVars(str_0, float_0)
  assert host_vars_vars_0.__getitem__() == host_vars_vars_0, "__getitem__ of HostVars returned unexpected result"


# Generated at 2022-06-25 14:06:41.471963
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars_0 = HostVars(str_0, str_0, str_0)
    assert isinstance(host_vars_0.__repr__(), str)
    assert not isinstance(host_vars_0.__repr__(), int)


# Generated at 2022-06-25 14:06:44.634896
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    var_0 = len("7D>QtyHZmZ'Li")
    host_vars_0 = HostVars(str_0, str_0, var_0)
    host_vars_0.__setstate__(var_0)


# Generated at 2022-06-25 14:06:51.796666
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    # If a hostvars variable uses a variable that is not set
    # (maybe a typo or something), this will cause an error to happen
    # and the variable won't be set at all.  This is good, it lets the
    # user know that something is likely wrong.
    # However, repr() calls __getitem__ and this will cause the code
    # to die, preventing a repr from working, and this causes problems
    # with unit tests

    test_case_0()

# Generated at 2022-06-25 14:07:02.081576
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = u'C|Kj$~\u039aL\u039a,vv\r:rGva"\\5\u03b7\u03b9\u03b3\u03ba\u03af\u03bd\u03b1\u03c2\u03c9\u03c3 '
    str_1 = "t/\u039a\u03a2\u039b"
    str_2 = "Zd"
    str_3 = "5"
    str_4 = u'\u03a4\u03cc?'
    str_5 = "e\\U"
    str_6 = '\u03c1'
    dum_0 = "O"

# Generated at 2022-06-25 14:07:12.066138
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    itr_0 = iter(str_0)
    var_0 = next(itr_0)
    str_1 = "'C=zKx8I"
    var_1 = next(itr_0)
    str_2 = "s3q[@pP~>|&T6U_R6U=d6U@7D>QtyHZmZ'Li[@pP~>|&T6U_R6U=d6U@'C=zKx8I"
    var_2 = next(itr_0)
    str_3 = "[@pP~>|&T6U_R6U=d6U@"
    var_3 = next(itr_0)
    return


# Generated at 2022-06-25 14:07:16.035113
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)


# Generated at 2022-06-25 14:07:25.122442
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    HostVarsCpy_0 = HostVars(str(4), str(4), str(4))
    HostVarsCpy_1 = HostVars(str(4), str(4), str(4))
    str_0 = "7D>QtyHZmZ'Li"
    HostVarsVars_0 = HostVarsVars(str_0, str_0)
    HostVarsVars_1 = HostVarsVars(str_0, str_0)
    HostVarsVars_0 = HostVarsVars(str_0, str_0)
    HostVarsVars_0 = HostVarsVars(str_0, str_0)
    HostVarsVars_1 = HostVarsVars(str_0, str_0)
    HostVarsVars_0

# Generated at 2022-06-25 14:07:32.515767
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = "&'p!h;v:"
    # Create instance of class HostVars with arguments _loader=var_0, inventory=var_0, variable_manager=var_0
    obj_0 = HostVars(var_0, var_0, var_0)
    # Call method __getitem__ with argument "!p.&:%S"
    obj_0.__getitem__("!p.&:%S")


# Generated at 2022-06-25 14:07:33.513577
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    assert False


# Generated at 2022-06-25 14:07:37.141951
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    assert hasattr(host_vars_vars_0, '__iter__')



# Generated at 2022-06-25 14:07:48.447215
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "e'i@b=l,/T^a"
    dict_0 = dict()
    dict_1 = dict()
    dict_0['d'] = dict_1
    dict_0['b'] = dict_1
    dict_0['e'] = dict_1
    dict_0['a'] = dict_1
    dict_0['c'] = dict_1
    dict_1['a'] = dict_0
    dict_1['f'] = dict_0
    dict_1['e'] = dict_0
    dict_1['d'] = dict_0
    dict_1['c'] = dict_0
    dict_1['b'] = dict_0
    dict_0['a'] = dict_1
    dict_0['f'] = dict_1
    dict_0['e']

# Generated at 2022-06-25 14:07:51.402937
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)


# Generated at 2022-06-25 14:08:01.775431
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Test for method __getitem__ of class HostVars (line 109)

    # Test for method __getitem__ of class HostVars (line 113)

    # Assigning a Call to a Name (line 113):

    # Call to HostVarsVars(...): (line 113)
    # Processing the call arguments (line 113)
    # Getting the type of 'str' (line 113)
    str_1 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 113, 24), 'str', False)
    # Getting the type of 'str' (line 113)
    str_2 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 113, 29), 'str', False)
    # Processing the call

# Generated at 2022-06-25 14:08:05.465129
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "7D>QtyHZmZ'Li"
    str_1 = "7D>QtyHZmZ'Li"
    str_2 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_1)
    foo_0 = host_vars_vars_0.__iter__()
    assert foo_0 is not None


# Generated at 2022-06-25 14:08:10.217382
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = None
    host_vars_0 = HostVars(str_0, str_0, str_0)
    str_1 = "b'vmkp\\?x"
    str_2 = host_vars_0[str_1]


# Generated at 2022-06-25 14:08:19.258100
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_vars_0 = HostVarsVars("MyKWBVwc%!W", str_0)
    host_vars_vars_1 = HostVarsVars(str_0, str_0)
    host_vars_0 = HostVars(host_vars_vars_1, host_vars_vars_0, host_vars_vars_1)
    assert isinstance(host_vars_0, Mapping)
    assert isinstance(host_vars_0, HostVars)
    for i in range(0, 100):
        host_vars_vars_0.set(host_vars_vars_0, host_vars_vars_0)

# Generated at 2022-06-25 14:08:24.465378
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    host_vars_vars_0.__repr__()


# Generated at 2022-06-25 14:08:29.667854
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = "T"
    dict_0 = dict()
    dict_0[str_0] = str_0
    host_vars_0 = HostVars(dict_0, dict_0, dict_0)
    host_vars_0.__repr__()
    host_vars_0.__repr__()


# Generated at 2022-06-25 14:08:39.270750
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = HostVars(None, None, None)
    str_0 = "a[Wjc''8wv>P"
    host_vars_0 = HostVars(str_0, str_0, str_0)
    str_1 = "7D>QtyHZmZ'Li"
    host_vars_0 = HostVars(str_1, str_1, str_0)
    str_2 = "J<MV7Q,CFl<u"
    host_vars_0 = HostVars(str_2, str_2, str_2)
    str_3 = "z1GwC`]n"
    host_vars_0 = HostVars(str_3, str_3, str_2)

# Generated at 2022-06-25 14:08:42.660438
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_1 = "7D>QtyHZmZ'Li"
    host_vars_0 = HostVars(str_1, str_1, str_1)
    str_2 = "/'D>pT`"
    host_vars_0.__setstate__(str_2)

# Generated at 2022-06-25 14:08:49.905896
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    try:
        test_case_0()
    except Exception as ex:
        return False

    return True

# Generated at 2022-06-25 14:08:53.456216
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "6nj"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    assert_equal(list(host_vars_vars_0.__iter__()), [])


# Generated at 2022-06-25 14:09:04.231925
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    ansible_0 = ansible = 0
    loader_0 = ansible.loader = 0
    str_1 = "QwZf|>%OG}on`"
    host_0 = loader_0.get_host_vars(str_1)
    variable_manager_0 = VariableManager(loader=loader_0, hosts=0)
    variable_manager_0._hostvars = host_vars_0
    variable_manager_0._loader = loader_0
    host_vars_0._loader = loader_0
    host_vars_0._variable_manager = variable_manager_0
    host_vars_0

# Generated at 2022-06-25 14:09:05.845648
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    host_vars_vars_0 = HostVarsVars(str(), str())


# Generated at 2022-06-25 14:09:12.287747
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    str_1 = "7D>QtyHZmZ'Li"
    host_vars_vars_1 = HostVarsVars(str_1, str_1)
    str_2 = "7D>QtyHZmZ'Li"
    host_vars_vars_2 = HostVarsVars(str_2, str_2)
    str_3 = "7D>QtyHZmZ'Li"
    host_vars_vars_3 = HostVarsVars(str_3, str_3)
    str_4 = "7D>QtyHZmZ'Li"


# Generated at 2022-06-25 14:09:17.488744
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    try:
        x = iter(host_vars_vars_0)
    except:
        fail("HostVarsVars iterator failed")



# Generated at 2022-06-25 14:09:27.450774
# Unit test for method __iter__ of class HostVarsVars

# Generated at 2022-06-25 14:09:30.274796
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "Jd:ZfI++[@!%c]{Va?M<XJ3"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    host_vars_vars_0.__iter__()

# Generated at 2022-06-25 14:09:32.723728
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Create object of class HostVars with argument list
    test_HostVars = HostVars(str(), str(), str())

    # Test method __repr__
    test_HostVars.__repr__()


# Generated at 2022-06-25 14:09:36.518415
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars(str_0, str_0, str_0)

    host_vars_0.__setstate__(str_0)


# Generated at 2022-06-25 14:09:48.087623
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import __main__
    __main__.test_case_0()


# Generated at 2022-06-25 14:09:52.660174
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = 'MkW$Xvz0K_xP'
    float_0 = 3.0
    host_vars_0 = HostVars(float_0, float_0, float_0)
    host_vars_0.__setstate__(str_0)
    assert repr(host_vars_0) == 'HostVars(3.0, 3.0, 3.0)'


# Generated at 2022-06-25 14:09:55.558918
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = "PRC%c"
    # Todo: Need to implement HostVars
    #host_vars_0 = HostVars(str_0, str_0, str_0)
    #host_vars_0.__repr__()


# Generated at 2022-06-25 14:09:58.893990
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '<lambda>'
    setattr(test_case_0, '__loader__', str_0)
    host_vars_vars_0 = HostVarsVars(str_0, str_0)


# Generated at 2022-06-25 14:10:03.252655
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    str_1 = host_vars_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 14:10:07.735339
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    try:
        assert "uQWBL"
        str_0 = "7D>QtyHZmZ'Li"
        host_vars_vars_0 = HostVarsVars(str_0, str_0)
    except AssertionError as ae:
        raise
    except Exception as e:
        raise AssertionError(str(e))


# Generated at 2022-06-25 14:10:11.304598
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    try:
        for i in host_vars_vars_0:
            pass
    except StopIteration:
        pass


# Generated at 2022-06-25 14:10:21.776489
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    __tracebackhide__ = True

    str_0 = "V]U$#jfB=h/v)q.|W8rn!;rN{_^Dv"
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}


# Generated at 2022-06-25 14:10:24.374794
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "SGs*T@,aE.yH"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    for var in host_vars_vars_0:
        print(var)


# Generated at 2022-06-25 14:10:27.717342
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:10:51.806665
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    param0 = HostVars()
    iter_retval0 = param0.__iter__()



# Generated at 2022-06-25 14:10:55.269469
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "F7hZU,DN{Q7V0v!"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    count_0 = 0
    for _ in host_vars_vars_0:
        count_0 += 1
    assert count_0 > 0


# Generated at 2022-06-25 14:11:02.249163
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    str_1 = "2[|iZf.RX'YV7"
    str_2 = "v-8LtbW;~:1n"
    str_3 = "X!Wm5r5ej(96y{v"
    str_4 = "0<9+S{;H|K0t"
    str_5 = "4{J&`(`aK+1O"
    str_6 = "oJ&\\[!_w-p{W"
    str_7 = "J7VUvX8Wl7VU"

# Generated at 2022-06-25 14:11:08.228040
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    for _i in range(10):
        str_0 = "7D>QtyHZmZ'Li"
        host_vars_vars_0 = HostVarsVars(str_0, str_0)
    pass;

# Testing code
if __name__ == "__main__":
    test_HostVars___getitem__();

# Generated at 2022-06-25 14:11:16.629228
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = Inventory(loader=DataLoader())
    inventory.clear_pattern_cache()
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    # Verify repr output with a simple test case
    set_item = {'ansible_all_ipv4_addresses': ['10.11.22.33'], 'ansible_all_ipv6_addresses': ['fe80::4001:aff:fe8a:2']}
    set_loader = DataLoader()
    set_variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    # Create an object of HostVars class
    firstObj = HostVars(inventory, variable_manager, set_loader)
    firstObj.set_host_variable('localhost', 'hostvars', set_item)
    # Parses the ansible_all

# Generated at 2022-06-25 14:11:18.788781
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = "9[;&Hhl5d5]z"
    host_vars_vars_0 = HostVarsVars(str_0, "7D>QtyHZmZ'Li")


# Generated at 2022-06-25 14:11:23.613093
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = "7D>QtyHZmZ'Li"
    dict_0 = {
        str_0: str_0,
    }
    host_vars_0 = HostVars(str_0, str_0, str_0)
    host_vars_0.__dict__.update(dict_0)
    dict_1 = {
        str_0: str_0,
    }
    host_vars_0.__setstate__(dict_1)


# Generated at 2022-06-25 14:11:29.696724
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_0 = HostVars(str_0, str_0, str_0)
    #assert len(host_vars_0.keys()) == 4
    #assert len(host_vars_0.values()) == 4
    print(host_vars_0.keys())
    print(host_vars_0.values())


# Generated at 2022-06-25 14:11:33.480342
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = "X"
    str_1 = "Z"
    host_vars_0 = HostVars(str_0, str_1, str_1)
    str_2 = "`o&F"
    assert host_vars_0[str_2] is not None


# Generated at 2022-06-25 14:11:36.136625
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "zhnRb)C?[;<1"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    for arg_0 in host_vars_vars_0:
        pass


# Generated at 2022-06-25 14:13:15.127838
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'LOAD_CALLBACK_PLUGINS'
    host_vars_vars_0 = HostVarsVars(str_0, str_0)


# Generated at 2022-06-25 14:13:20.333821
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = """\n        2L:Rv@X!',l\n        """
    str_1 = "Z(Jc3!1,''!\n        \n          "
    host_vars_vars_0 = HostVarsVars(str_0, str_1)
    int_0 = len(host_vars_vars_0)
    assert int_0 == 2, "Return value of __iter__: %s" % int_0


# Generated at 2022-06-25 14:13:26.945369
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars_0 = HostVars("U5)6UJI0p<>", "", "kK@C{l(#")

# Generated at 2022-06-25 14:13:29.671227
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    # __iter__ not implemented; succeeded if reached this line
    assert True


# Generated at 2022-06-25 14:13:34.796952
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'rW_!vk{bF(@'
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    str_1 = '=.E5I5Y5y5'
    host_vars_0 = HostVars(str_1, str_1, str_1)
    str_2 = 'd}l>zC;R@'
    host_vars_0.set_variable_manager(str_2)
    str_3 = '6o'
    host_vars_0.set_host_variable(str_1, str_1, str_3)
    str_4 = "'"
    host_vars_0.set_nonpersistent_facts(str_1, str_3)
    host_vars

# Generated at 2022-06-25 14:13:37.769213
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = './ansible_module_os_setup.py'
    host_vars_0 = HostVars(str_0, str_0, str_0)
    assert isinstance(host_vars_0.raw_get(str_0), AnsibleUndefined)


# Generated at 2022-06-25 14:13:46.502368
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = '/var/lib/awx/projects/_6/checkouts'
    var_0 = dict()
    str_1 = "7D>QtyHZmZ'Li"
    host_vars_vars_0 = HostVarsVars(str_1, str_0)
    str_2 = 'host'
    int_0 = 0
    var_0[str_2] = int_0
    str_3 = 'inventory_hostname'
    str_4 = 'localhost'
    var_0[str_3] = str_4
    str_5 = 'inventory_hostname_short'
    str_6 = 'localhost'
    var_0[str_5] = str_6
    str_7 = 'group_names'
    list_0 = list()
    list_1

# Generated at 2022-06-25 14:13:54.194901
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = None
    HostVars_0 = HostVars(str_0, str_0, str_0)
    str_1 = "9Xo\x3c\x6d\x6a_\x64\x6b\x6f\x75\x61\x77\x63\x6b\x6f\x6f\x6c\x6e\x6d"
    assert HostVars_0.raw_get(str_1) == None
    str_2 = "e`\x78\x6a\x6f\x6d\x6f\x6b\x6b\x61\x6d\x6f\x6b\x6f\x6c\x6e\x6d"
    assert HostVars_0.raw_

# Generated at 2022-06-25 14:13:56.354511
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_3 = 'KWn9OrDv1C'
    str_4 = '4b4'
    assert str_4 == host_vars_vars_0.raw_get(str_3)

# Generated at 2022-06-25 14:14:00.066626
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = "z=s(a0s-,s~c%lTt60i "
    int_0 = -97
    host_vars_0 = HostVars(str_0, str_0, str_0)
    host_vars_0.raw_get(int_0)