

# Generated at 2022-06-25 14:05:37.626303
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False
    str_0 = 'w<e=0'
    int_0 = 1
    host_vars_0 = HostVars(int_0, str_0, bool_0)
    assert isinstance(host_vars_0.__iter__(), types.GeneratorType)


# Generated at 2022-06-25 14:05:46.209122
# Unit test for method __repr__ of class HostVars

# Generated at 2022-06-25 14:05:49.763319
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = '#\x1a\x16\t\x0f\x18\x0b\x03\x1c%\x1a\x1c\x1d\x1a\x0b9?\x1e'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    result = host_vars_0.__iter__()


# Generated at 2022-06-25 14:05:57.262715
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '/B\\\x0cE\x1f\x14\x1f\x1fcX\x0c\x02\x0b\x02\x8fS'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = host_vars_0.__repr__()
    assert isinstance(str_1, str)


# Generated at 2022-06-25 14:06:02.019709
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    iter_0 = host_vars_0.__iter__()


# Generated at 2022-06-25 14:06:06.696415
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = 'Xq@z\x1cW`C8P\t'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    for host_vars_1 in host_vars_0:
        print(host_vars_1)


# Generated at 2022-06-25 14:06:12.128629
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_1 = '|'
    bool_1 = False
    host_vars_1 = HostVars(str_1, str_1, bool_1)
    str_0 = 'wyi;I|xR\x0bB\\5`5'
    # Test initializer: call
    data_0 = host_vars_1.raw_get(str_0)
    assert isinstance(data_0, AnsibleUndefined)


# Generated at 2022-06-25 14:06:22.406539
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    str_0 = '{'
    int_0 = 0
    str_1 = ','
    str_2 = '}{'
    '''
    :return: 
    '''
    # str_0 = '{'
    # int_0 = 0
    # str_1 = ','
    # str_2 = '}{'
    # bool_0 = True
    str_3 = '@P~/<\x0cAA-c;O@?Y;l'
    host_vars_0 = HostVars(str_3, str_3, bool_0)
    # str_4 = '@P~/<\x0cAA-c;O@?Y;l'
    # str_5 = '{'
    # str_6 = ','
   

# Generated at 2022-06-25 14:06:28.072792
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'Jl\x1b\x05\x10\x12\x06\r\r\x15\x1d\x0b\n\x1f'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    result = repr(host_vars_0)
    assert result == '{}'


# Generated at 2022-06-25 14:06:32.878180
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'I~\x12[O;b\x0cUv@8x'
    str_1 = '|G\x0cq_4\x0bA]s+I\x01'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_1, bool_0)


# Generated at 2022-06-25 14:06:40.276567
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = 'GFb7?~&D\\+5%V*'
    assert host_vars_0.raw_get(str_1) == AnsibleUndefined


# Generated at 2022-06-25 14:06:44.793654
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = '/#Lp\x19U6&\x7f%c.\nF\tt'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    result = host_vars_0.__iter__()
    assert result == True, "HostVars.__iter__() did not return True"


# Generated at 2022-06-25 14:06:56.704492
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '\x0cAA\x1c\x0b'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = '?\\~=J><\x1a'
    str_2 = '\x1d\x0f\x1c;\x08\x0c\x17\x1bW\x11\x0eU\x0f?T\x1d\x1f'
    str_3 = '\x1b\'\x1aL\x14\x08\x15\x0c\x1dTS\x1e\x0c\x19\x08\x1a\x00\x19\x0b'

# Generated at 2022-06-25 14:06:57.722877
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    assert True


# Generated at 2022-06-25 14:06:58.784687
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    assert False


# Generated at 2022-06-25 14:07:02.879685
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = ',\nC\x1f(<\n'
    bool_0 = False
    obj_0 = HostVars(str_0, str_0, bool_0)
    func_0 = getattr(obj_0, 'get')
    obj_0 = func_0('%c')
    assert callable(obj_0)


# Generated at 2022-06-25 14:07:11.644244
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

  # Arguments
  arg_0 = {
      '_loader': False,
      '_inventory': ':2\x041\x02\x00',
      '_variable_manager': '\x104\x01K\x00\x85\x03cnumpy.core.multiarray\nscalar\np0\n(cnumpy\nV_typestr\np1\n(S\'"i8"\np2\ntp3\nb.',
  }

  # Call
  host_vars_0 = HostVars(None, None, None)
  host_vars_0.__setstate__(arg_0)

# Generated at 2022-06-25 14:07:23.036528
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'K~Bb+<-g\x1ej1GehD}R'
    bool_0 = True
    str_0 = 'r:r-W8\x0fI7\x0c_zBxV'
    dict_0 = {}
    dict_0['6E<|]RD\x7f=.\x1e\x06\x1e'] = str_0
    dict_0[''] = str_0
    dict_0['%\x1bT(|s\x7fY<P><\x01\x0c'] = str_0
    host_vars_0 = HostVars(dict_0, str_0, bool_0)
    dict_0 = {}

# Generated at 2022-06-25 14:07:25.135338
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    host_vars_0 = HostVars(str(), str(), False)
    #print host_vars_0.__getitem__()


# Generated at 2022-06-25 14:07:36.382022
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'ODpa}'
    int_0 = -8
    str_1 = 'Gn\x1f'
    str_2 = 'cV/'
    str_3 = 'U4'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_1, bool_0)
    host_vars_vars_0 = host_vars_0[str_2]
    str_4 = 'FQ'
    float_0 = 5.76211506136e-10
    bool_1 = True
    str_5 = "a"
    str_6 = "b"
    str_7 = 'o~H'
    str_8 = "c"
    str_9 = "d"
    str_10 = 'D'
    str

# Generated at 2022-06-25 14:07:48.004882
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = '\x1d\x1b\n\x04\x10\x0c\x1b\x1b\x1b\x06\x1b\x1b\x0b\t\x1b\x1b\x1b\x05\x0b\x1b\x1b\x1b\x1b\x1a\x0b\x1a\x1b\x0b\x1b'
    bool_0 = True

# Generated at 2022-06-25 14:07:53.564719
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Test data (from old test_case_0)
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    # Action
    result = repr(host_vars_0)
    # Compare result with expected value
    assert result == '{}'



# Generated at 2022-06-25 14:07:59.542866
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '\x1c\x06~\x1b8\x0c0-\x18f\x11?x8\x0b'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    assert host_vars_0.__repr__() == '{}'


# Generated at 2022-06-25 14:08:05.181796
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = '@P~/<\nAA-c;O@?Y;l'
    host_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 14:08:13.164807
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '~NAh,\x1b8N\x1fv(k\x06'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    assert repr(host_vars_0) == "{'~NAh,\\x1b8N\\x1fv(k\\x06': <HostVarsVars '~NAh,\\x1b8N\\x1fv(k\\x06'>}"



# Generated at 2022-06-25 14:08:18.149567
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    str_1 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    host_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 14:08:19.251155
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    pass  # TODO: Write this test



# Generated at 2022-06-25 14:08:26.383581
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    ansible_undefined_0 = host_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 14:08:30.859349
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = True
    str_1 = '~#v)\x7f\x1c\x10ZR'
    try:
        host_vars_0 = HostVars(str_0, bool_0, str_1)
    except NameError as exc_0:
        print(exc_0)


# Generated at 2022-06-25 14:08:36.896153
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Setup
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)

    # Call function to test
    result = host_vars_0.raw_get(str_0)
    #print(result)
    # Verify the results
    assert result is not None


# Generated at 2022-06-25 14:08:50.904985
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = ''
    bool_0 = False
    float_0 = 3.2
    int_0 = -15
    host_vars_0 = HostVars(str_0, float_0, bool_0)
    str_1 = ''
    bool_1 = True
    int_1 = 100
    dict_0 = {str_0: int_1}

# Generated at 2022-06-25 14:08:54.633212
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    var_0 = host_vars_0.raw_get('O@?Y;l')


# Generated at 2022-06-25 14:09:05.502438
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    int_0 = 0
    str_0 = str(int_0)
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = str(int_0)
    assert host_vars_0._find_host(str_1) is not None
    assert host_vars_0.raw_get(str_1) is not None
    assert host_vars_0.__getitem__(str_1) is not None
    assert bool(host_vars_0.__contains__(str_1))
    assert host_vars_0.__iter__() is not None
    assert isinstance(host_vars_0.__len__(), int)

# Generated at 2022-06-25 14:09:09.455410
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Load a test case
    test_case = test_cases[0]

    # Bind parameters
    host_vars = HostVars(**test_case[0])

    # Execute the method
    actual = host_vars.raw_get(**test_case[1])

    # Validate the results
    assert(actual == test_case[2])


# Generated at 2022-06-25 14:09:17.802540
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = '~'
    str_1 = 'N\x08\x05\x07\x13A\x1a\x1f\x1a\x1f\x03\x0f\x1a\x1f\x05\x07\x13A\x1a\x1f\x1a\x1f'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_1, bool_0)
    str_2 = '~'
    assert host_vars_0.raw_get(str_2) == AnsibleUndefined()


# Generated at 2022-06-25 14:09:25.804516
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '\x0c'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = '(\x1f-\x0e\\\x13n\x1c\x18\x04\x0b\x0c\x0bW8a\x1a3Z\x1e!\x11\n\n\x10t\x02\x128\n\x1d\n'
    host_vars_0._find_host(str_1)


# Generated at 2022-06-25 14:09:33.002984
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = '\x0f\x16\x0cAB,\x19\x01:\x05&F\x08'
    str_1 = '"\x05\x1d\x04\x0e\x1c\x00\x1f\x0f\x0e\x1b\x0b\x1f\x1c\x0e\x00\x1a\x1f\x0b\x0b\x1c'
    str_2 = '\x0f\x16\x0cAB,\x19\x01:\x05&F\x08'
    str_3 = '\x0f\x16\x0cAB,\x19\x01:\x05&F\x08'
    dict_0 = dict()
   

# Generated at 2022-06-25 14:09:44.139823
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    # Set up mock objects
    dict_0 = dict()
    dict_1 = dict()
    variable_manager_0 = VariableManager(dict_0)
    variable_manager_1 = VariableManager(dict_1)
    variable_manager_0._hostvars = None
    variable_manager_0._loader = None
    dict_2 = dict()
    dict_2['_hostvars'] = variable_manager_1
    dict_2['_loader'] = variable_manager_1
    variable_manager_0.__dict__ = dict_2
    loader_0 = None

    # Call the method

# Generated at 2022-06-25 14:09:47.664244
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = '~XzI:H#GqDC\x0b2}'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    host_vars_0


# Generated at 2022-06-25 14:09:55.558550
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '+Lf\x1c\x0f\x1c\x0bk@\x14|>\x0f\x1b\x1e]v'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    try:
        host_vars_0.__repr__()
    except UnboundLocalError:
        pass
    except Exception:
        raise AssertionError
    else:
        raise AssertionError
        raise AssertionError
    str_0 = '\x1c4m\x1c\x1d\x1c\x14\x05\x14\x14\x14\x1f\x1c\x1f\x1c\x17'


# Generated at 2022-06-25 14:10:14.587202
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b'
    bool_0 = True

# Generated at 2022-06-25 14:10:25.626252
# Unit test for method __iter__ of class HostVars

# Generated at 2022-06-25 14:10:30.701514
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = 'F~\x1fA-\x7f\x1b'
    int_0 = host_vars_0[str_1]
    assert int_0 == 2


# Generated at 2022-06-25 14:10:35.037126
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '{;\x11s\x1c'
    bool_0 = False
    str_1 = '\x0e\x0f{|\x14'
    host_vars_0 = HostVars(str_0, str_1, bool_0)
    int_0 = len(host_vars_0)
    assert int_0 == len(host_vars_0)
    assert int_0 == len(host_vars_0)
    assert int_0 == len(host_vars_0)


# Generated at 2022-06-25 14:10:37.883688
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'NOYEp'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    assert repr(host_vars_0) == "{'NOYEp': HostVarsVars({'NOYEp': 'NOYEp'}, loader=True)}"


# Generated at 2022-06-25 14:10:48.023139
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    variable_manager = '=z|]jx\x0e\x0e\x1a'
    str_0 = 'localhost'
    str_1 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_1, variable_manager, bool_0)
    host_vars_0.set_variable_manager(variable_manager)
    host_vars_0.set_inventory(str_1)
    # ValueError
    try:
        host_vars_0.set_variable_manager(str_0)
    except ValueError:
        pass
    host_name = str_0

# Generated at 2022-06-25 14:10:52.630235
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '~%c<\x0cA;\x08\x0f\x00'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    # test passing by value
    assert repr(HostVars('localhost', 'localhost', False))
    return str_0


# Generated at 2022-06-25 14:11:00.170314
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = 'Y\x19V\x10'
    int_0 = 100
    float_0 = 404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040

# Generated at 2022-06-25 14:11:10.076257
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = '\x1c.c\x19\x15\rv\x04=\x19\x1d_X\x03\t'
    str_1 = '\x1a\x1c\x19\x0e\x1f\x02'
    str_2 = '\x00\x0b\x0f\x06\x1c\x07\x19+\x16'
    str_3 = '\x11\x0b\x1b\x00\x06\x1c\x07\x19+\x16'
    str_4 = '\x1c.c\x19\x15\rv\x04=\x19\x1d_X\x03\t'

# Generated at 2022-06-25 14:11:18.179846
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'JO\x18\x02\x0e'
    bool_0 = False
    str_0 = '{-\x0e\x19\x1a\x1cT\x1d\x0c\x1b\n\x04\x1aZ\x1c\n\x12\x1b:Q\x1c\x0e\x02;\x1a\x1d\x0c\x1b\x19\x18\x1e'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = '&\x0c\x1dK\x12\x0c\x05\nK\x1c'

# Generated at 2022-06-25 14:11:52.362949
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'tnaY'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = '^e&[u{LQz'
    bool_1 = False
    str_2 = '|>r0'
    bool_2 = False
    int_0 = 0
    str_3 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_3 = False
    str_4 = '^e&[u{LQz'
    bool_4 = False
    str_5 = '|>r0'
    bool_5 = False
    int_1 = 0
    data_0 = host_vars_0.raw_get(str_1)
   

# Generated at 2022-06-25 14:11:55.377190
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = '$s<QT)q.%n#n'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = '!Gw\xc4\x03$5'
    assert_equal(host_vars_0.raw_get(str_1), 'A value.')


# Generated at 2022-06-25 14:11:59.671108
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '<\x0cAA-c;O@?\x7f\x15/|'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    if len(host_vars_0) != 0:
        raise RuntimeError()



# Generated at 2022-06-25 14:12:03.037981
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'w/'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    host_vars_0.raw_get('xl267+')


# Generated at 2022-06-25 14:12:12.106086
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'tE}(%&;^\x0e`S\x18Fz\x15-I\x14'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)

# Generated at 2022-06-25 14:12:15.783410
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'x?O<+X\x0c\\'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    repr_0 = host_vars_0.__repr__()



# Generated at 2022-06-25 14:12:19.793771
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = 'hi'
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    host_vars_1 = host_vars_0.raw_get(var_0)


# Generated at 2022-06-25 14:12:23.930294
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    bool_1 = host_vars_0.__contains__('Y1D')
    assert not bool_1


# Generated at 2022-06-25 14:12:31.808112
# Unit test for method __getitem__ of class HostVars

# Generated at 2022-06-25 14:12:35.111963
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '@P~/<\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    result = host_vars_0.__repr__()
    assert  result is not None


# Generated at 2022-06-25 14:13:38.336766
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'T\x1e\x11\x14a\x1a'
    bool_0 = True
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = '::'
    host_vars_0.raw_get(str_1)
    str_2 = 'h\x1e\x16\x1fk'
    host_vars_0.raw_get(str_2)


# Generated at 2022-06-25 14:13:46.909187
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '*\x0c}`'
    bool_0 = True
    list_0 = [bool_0, str_0]
    list_1 = [str_0, 'V\xf2\x1c\x83\xdf\x14\xaa', '#\xc9\xeb\x94\xb2', '\x06\xbd\x8eY\x0f\xa5A\x1a\xc8']
    list_2 = [bool_0, str_0]
    float_0 = 25.9888024233008

# Generated at 2022-06-25 14:13:48.854354
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = HostVars('', '', True)
    assert isinstance(host_vars_0.raw_get(''), AnsibleUndefined)


# Generated at 2022-06-25 14:13:53.069956
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = '</\x0cAA-c;O@?Y;l'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    host_name_0 = 'a'
    str_1 = host_vars_0.raw_get(host_name_0)
    # TODO: check the result


# Generated at 2022-06-25 14:13:58.556888
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'f;9\x0c[\x0c\x0c\x0c\x0c'
    int_0 = 0
    bool_0 = False
    host_vars_0 = HostVars(str_0, int_0, bool_0)
    str_1 = '\x7f'
    var_0 = host_vars_0[str_1]
    # Return type should be a HostVarsVars object
    assert(isinstance(var_0, HostVarsVars))


# Generated at 2022-06-25 14:13:59.694796
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    pass


# Generated at 2022-06-25 14:14:03.771679
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '#D4P4\x17fF\x1cE\x1b\x1dE'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = '\x17\x15\x01'
    int_0 = host_vars_0[str_1]


# Generated at 2022-06-25 14:14:08.374348
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = ')KZoQ^M5BDa\x1dK\x1c\x1a'
    str_1 = '\x0c\x16\x1f\x1c\x12\x17\x1a\x0e'
    host_vars_0 = HostVars(str_0, str_1, False)


# Generated at 2022-06-25 14:14:15.842010
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = '=\x1a\x18Y|\x1a9\x1a\x0b\x16\x19\x0f\x18\x0f\x1b'
    bool_0 = False
    host_vars_0 = HostVars(str_0, str_0, bool_0)
    str_1 = '\x06\x04\r\r\r\r\r\r\r\r\r\r'
    value_0 = host_vars_0.raw_get(str_1)
    assert value_0 is False


# Generated at 2022-06-25 14:14:21.291833
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = '~f'
    str_1 = '\'\x13`\x7f/'
    bool_0 = True

    # Declaration of a HostVars object
    host_vars_0 = HostVars(str_0, str_1, bool_0)

    # Call to raw_get of the class
    result = host_vars_0.raw_get(str_0)
