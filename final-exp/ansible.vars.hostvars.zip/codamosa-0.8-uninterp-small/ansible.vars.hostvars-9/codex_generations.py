

# Generated at 2022-06-25 14:05:41.971352
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = None
    str_0 = "^<L#"
    host_vars_0 = HostVars(bytes_0, bytes_0, str_0)
    try:
        bool_0 = isinstance(host_vars_0, Mapping)
        if bool_0:
            print('\x1b[6;30;42m' + 'Test Successful' + '\x1b[0m')
        else:
            print('\x1b[5;30;41m' + 'Test Failed' + '\x1b[0m')
    except:
        print('\x1b[5;30;41m' + 'Test Failed' + '\x1b[0m')

if __name__ == '__main__':
    test_case_0()
    test_

# Generated at 2022-06-25 14:05:50.434700
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = None
    str_0 = 'm0?P;lB@TM>{\t*jm'
    host_vars_vars_0 = HostVarsVars(bytes_0, str_0)
    host_name = host_vars_vars_0
    print(host_vars_vars_0.__contains__(host_name))
    # NotImplementedError:
    # print(host_vars_vars_0 == host_vars_vars_0)
    print(host_vars_vars_0.__iter__())
    # NotImplementedError:
    # print(host_vars_vars_0 == host_vars_vars_0)
    print(host_vars_vars_0.__len__())
   

# Generated at 2022-06-25 14:05:55.444891
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = None
    str_0 = 'e[4ZgVJZa6'
    host_vars_0 = HostVars(bytes_0, str_0)
    host_vars_1 = iter(host_vars_0)


# Generated at 2022-06-25 14:05:59.715475
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bytes_0 = None
    str_0 = '+?;<J&w*k_yM(oO+d,#'
    host_vars_vars_0 = HostVarsVars(bytes_0, str_0)
    # Nothing to test here


# Generated at 2022-06-25 14:06:09.468256
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bytes_0 = None
    str_0 = '<Xy)E8|fkx`M$`h5>'
    host_vars_vars_0 = HostVarsVars(bytes_0, str_0)
    def function_1(param_0):
        host_vars_vars_0.__setitem__(param_0, '')
        host_vars_vars_0.__len__()
        return host_vars_vars_0

    itr_0 = host_vars_vars_0.__iter__()

# Generated at 2022-06-25 14:06:11.946676
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = None
    str_0 = 'YzJ\n-mV\t'
    host_vars_0 = HostVars(bytes_0, str_0, None)
    str_1 = 'fh\'J'
    assert host_vars_0.raw_get(str_1) == AnsibleUndefined(name="hostvars['fh'J']")


# Generated at 2022-06-25 14:06:14.437069
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    temp_HV = HostVars(None, None, None)
    host_vars_vars_0 = temp_HV.__iter__()

# Generated at 2022-06-25 14:06:20.832474
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = None
    str_0 = 'm0?P;lB@TM>{\t*jm'
    host_vars_0 = HostVars(bytes_0, str_0, str_0)
    str_1 = '=JH~>!z:63V#|c8Wk'
    bytes_1 = host_vars_0.raw_get(str_1)


# Generated at 2022-06-25 14:06:28.245794
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = None
    str_0 = 'm0?P;lB@TM>{\t*jm'
    host_vars_vars_0 = HostVarsVars(bytes_0, str_0)

    # Construct object of class HostVars with argument variables
    # and test if the object is properly instantiated
    host_vars_0 = HostVars(host_vars_vars_0, host_vars_vars_0, host_vars_vars_0)
    assert isinstance(host_vars_0, HostVars)

# Generated at 2022-06-25 14:06:31.946964
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = None
    str_0 = '9kJjR'
    host_vars_0 = HostVars(bytes_0, str_0, str_0)
    assert len(list(host_vars_0.__iter__())) > 0


# Generated at 2022-06-25 14:06:36.360312
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'e[ZgV)Za'
    host_vars_0 = HostVars(str_0, str_0)
    str_1 = host_vars_0.__repr__()
    assert isinstance(str_1, basestring)

# Generated at 2022-06-25 14:06:39.109701
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = HostVars()
    test_0 = host_vars_0.raw_get('test_0')

test_case_0()
test_HostVars_raw_get()

# Generated at 2022-06-25 14:06:40.012189
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    a=HostVars
    a()
    assert True == True


# Generated at 2022-06-25 14:06:45.760285
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = 'u}B>?N7'
    str_1 = 'n-PH/'
    str_2 = ':5ZgF5r3'
    host_vars_0 = HostVars(str_0, str_1, str_2)
    host_vars__iter__0 = host_vars_0.__iter__()
    assert len(host_vars__iter__0) == 0 and isinstance(host_vars__iter__0, types.GeneratorType)


# Generated at 2022-06-25 14:06:49.491874
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'e[ZgV)Za'
    host_vars_vars_0 = HostVarsVars(str_0, str_0)


# Generated at 2022-06-25 14:06:50.867949
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    for _ in HostVarsVars(str(), Templar):
        pass


# Generated at 2022-06-25 14:06:57.541617
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'z`4f4'
    dict_0 = dict(zip(string.ascii_letters, itertools.repeat(1)))
    str_1 = 'uYgV2f|$u'
    host_vars_vars_0 = HostVarsVars(dict_0, str_1)
    for var_0 in host_vars_vars_0:
        assert False


# Generated at 2022-06-25 14:07:05.068822
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '%PCGdH[@Y'
    str_1 = 'Z\x1a7\x1d\x14\x16\x00\t\x18Y9\x14\x05\x13\x10\x06\\\x1f\x1cA\x1f\x03'
    str_2 = '[Z\x1b\x105c'
    host_vars_0 = HostVars(str_0, str_1)
    host_vars_0.set_variable_manager(str_2)
    str_3 = 'QZ*\x1b@\x1f'
    str_4 = '!k7\x1a5d\x1c'

# Generated at 2022-06-25 14:07:15.375193
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    data_1 = '<kYwV/q'
    vars_1 = 'fN`R]uP'
    loader_1 = 'y/(^a%t'
    host_vars_0 = HostVars(data_1, vars_1, loader_1)
    host_vars_vars_1 = HostVarsVars(vars_1, loader_1)
    host_vars_0["ansible_check_mode"] = host_vars_vars_1
    assert host_vars_0["ansible_check_mode"] == host_vars_vars_1



# Generated at 2022-06-25 14:07:17.929878
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = 'I&}Gx;dD'
    host_vars_0 = HostVars(str_0, str_0)


# Generated at 2022-06-25 14:07:23.905837
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    ret_0 = host_vars_0.__repr__()
    return ret_0 == '{}'


# Generated at 2022-06-25 14:07:35.018750
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None

    var_4 = AnsibleUndefined()

    var_0 = HostVars(var_4, var_4, var_4)

    var_1 = var_0.raw_get(var_4)


# Generated at 2022-06-25 14:07:37.774836
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    for element in host_vars_0:
        print(element)


# Generated at 2022-06-25 14:07:41.514813
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = HostVars(None, None, None)
    new_object_0 = var_0.__getitem__('foo')
    assert isinstance(new_object_0, AnsibleUndefined)


# Generated at 2022-06-25 14:07:44.405457
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    data = host_vars_0.__getitem__("localhost")
    assert data is None


# Generated at 2022-06-25 14:07:51.610368
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    set_tmp_ansible_loaded("0")
    var_1 = AnsibleUndefined(name="var_1")
    var_2 = AnsibleUndefined(name="var_2")
    var_3 = AnsibleUndefined(name="var_3")
    var_4 = AnsibleUndefined(name="var_4")
    var_5 = AnsibleUndefined(name="var_5")
    var_6 = AnsibleUndefined(name="var_6")
    var_7 = AnsibleUndefined(name="var_7")
    var_8 = AnsibleUndefined(name="var_8")
    var_9 = AnsibleUndefined(name="var_9")
    var_10 = AnsibleUndefined(name="var_10")
    var_11 = AnsibleUndefined(name="var_11")

# Generated at 2022-06-25 14:07:55.714239
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_1 = None
    var_2 = None
    var_3 = None
    host_vars_1 = HostVars(var_1, var_1, var_1)
    assert not hasattr(host_vars_1, "__iter__")


# Generated at 2022-06-25 14:07:59.106417
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Pass 1
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    try:
        if host_vars_0["localhost"] is not AnsibleUndefined:
            raise Exception('AssertionError')
        # The expected exception was raised
    except Exception:
        pass
    else:
        # The expected exception was not raised
        assert False, "Exception not raised"


# Generated at 2022-06-25 14:08:02.446221
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    expected = {}
    actual = repr(host_vars_0)
    assert expected == actual


# Generated at 2022-06-25 14:08:06.347867
# Unit test for method __iter__ of class HostVars

# Generated at 2022-06-25 14:08:13.368815
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    tmp = HostVarsVars(None, None)
    assert iter(tmp) == tmp.__iter__()


# Generated at 2022-06-25 14:08:18.940168
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    __setstate__ = getattr(HostVars, '__setstate__', None)
    testcase_0_state = {}
    testcase_0_self = HostVars()

    # Call method __setstate__
    # AssertionError: __setstate__(self, state) takes exactly 2 arguments (3 given)
    try:
        __setstate__(testcase_0_self, testcase_0_state, 0)
    except TypeError:
        pass


# Generated at 2022-06-25 14:08:23.388715
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    host_name_0 = 'ansible_play_hosts'
    host_name_1 = 'ansible_version'
    host_name_2 = 'ansible_host_vars'
    for host_name in [host_name_0, host_name_1, host_name_2]:
        host_vars_0.raw_get(host_name)


# Generated at 2022-06-25 14:08:27.573360
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create an instance of HostVars
    host_vars_1 = HostVars()
    for result in host_vars_1.__iter__():
        assert isinstance(result, )


# Generated at 2022-06-25 14:08:33.138721
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    var_0 = 'host_vars_0'
    foo = Inventory(var_0)
    bar = VariableManager()
    assert foo is not None, "foo is None"
    assert bar is not None, "bar is None"
    host_vars_0 = HostVars(foo, bar, var_0)
    assert host_vars_0 is not None, "host_vars_0 is None"

    # Test with var_0 = None
    foo = host_vars_0.raw_get(var_0)
    assert foo is not None, "foo is None"

    # Test with var_0 = 'foo'
    var_0 = 'foo'

# Generated at 2022-06-25 14:08:35.451841
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    var_1 = None
    host_vars_0.set_variable_manager(var_1)
    var_2 = None
    host_vars_0.set_inventory(var_2)


# Generated at 2022-06-25 14:08:41.139492
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_1 = 'test_ansible_version'
    var_2 = 'test_ansible_play_hosts'
    var_3 = 'test_ansible_dependent_role_names'
    var_4 = 'test_ansible_play_role_names'
    var_5 = 'test_ansible_role_names'
    var_6 = 'test_inventory_hostname'
    var_7 = 'test_inventory_hostname_short'
    var_8 = 'test_inventory_file'
    var_9 = 'test_inventory_dir'
    var_10 = 'test_groups'
    var_11 = 'test_group_names'
    var_12 = 'test_omit'
    var_13 = 'test_playbook_dir'

# Generated at 2022-06-25 14:08:50.234993
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 14:08:59.801540
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # assume
    inventory_0 = None
    variable_manager_0 = None
    loader_0 = None
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    inventory_1 = None
    variable_manager_1 = None
    loader_1 = None
    host_vars_1 = HostVars(inventory_1, variable_manager_1, loader_1)
    ansible_play_hosts_0 = None
    inventory_hostname_0 = None
    inventory_hostname_short_0 = None
    inventory_file_0 = None
    inventory_dir_0 = None
    groups_0 = None
    group_names_0 = None
    omit_0 = None
    playbook_dir_0 = None
    play_hosts_0 = None


# Generated at 2022-06-25 14:09:03.829888
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    var_1 = host_vars_0.__iter__()


# Generated at 2022-06-25 14:09:31.077636
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_1 = {}
    host_vars_1 = HostVars(var_1, var_1, var_1)
    try:
        repr(host_vars_1)
    except Exception:
        assert False, "Unable to get repr for HostVars"



# Generated at 2022-06-25 14:09:34.034811
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    foo_0 = HostVarsVars('O+1#uV8W\'g!=vL', 'o^bj5+V1W/A')
    assert foo_0['yo`Xz_weo0\x0c+pLE4Pk'] == 'O+1#uV8W\'g!=vL'


# Generated at 2022-06-25 14:09:43.267429
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    var_2 = None
    host_vars_0._inventory = var_2
    var_3 = None
    host_vars_0._variable_manager = var_3
    var_4 = None
    host_vars_0._loader = var_4
    var_5 = None
    host_vars_0._hostvars = var_5
    var_6 = host_vars_0.__iter__()
    assert var_6 == iter(var_2.hosts)


# Generated at 2022-06-25 14:09:50.534856
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {'ansible_version': '2.2.2.0',
                 'inventory_file': '/Users/eivindsvendsen/Documents/ansible/ansible/inventory/development',
                 'inventory_dir': '/Users/eivindsvendsen/Documents/ansible/ansible/inventory',
                 'playbook_dir': '/Users/eivindsvendsen/Documents/ansible/ansible'}
    loader = None
    host_vars_vars_0 = HostVarsVars(variables, loader)
    for var in host_vars_vars_0:
        pass


# Generated at 2022-06-25 14:09:53.285028
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    '''Test method __repr__ of class HostVars'''

    var_0 = HostVars(var_0, var_0, var_0)
    repr_0 = repr(var_0)
    assert repr_0 is not None


# Generated at 2022-06-25 14:09:56.108280
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    temp = []
    for host in host_vars_0:
        temp.append(host)
    assert len(set(host_vars_0) - set(temp)) == 0
    # Make sure no exceptions are thrown
    assert True


# Generated at 2022-06-25 14:10:06.462069
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = None
    var_1 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    print(host_vars_0)
    print(repr(host_vars_0))
    print(repr(var_0))


if __name__ == '__main__':
    import inspect, os, sys
    from collections import namedtuple

    def usage():
        caller = inspect.getouterframes(inspect.currentframe())[1][3]
        print('Usage: %s [-h|--help]\n\t%s <test-case-id>' % (caller, caller))

    argv = sys.argv


# Generated at 2022-06-25 14:10:08.801563
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_1 = None
    host_vars_1 = HostVars(var_1, var_1, var_1)
    assert repr(host_vars_1) == '{}'


# Generated at 2022-06-25 14:10:12.270311
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    var_0 = {'foo': '{{ bar }}'}

    # Test good case
    test_0 = HostVarsVars(var_0, var_0)

    for iter_0 in test_0:
        assert iter_0

    # Test exceptions
    with pytest.raises(TypeError):
        test_0 = HostVarsVars(var_0, var_0)
        iter(test_0)


# Generated at 2022-06-25 14:10:16.894436
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    var_1 = None
    var_2 = None
    var_3 = None
    host_vars_1 = HostVars(var_1, var_1, var_1)
    expected_1 = None
    actual_1 = host_vars_1.__setstate__(var_2)
    assert(expected_1 == actual_1)



# Generated at 2022-06-25 14:11:01.443005
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    var_1 = [
        '1',
        '2',
        '3',
        '4',
        '5'
    ]
    var_1 = host_vars_0._HostVars__iter__()
    for var_2 in var_1:
        print(var_2)


# Generated at 2022-06-25 14:11:05.645916
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Case 0
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    host_name_0 = 'localhost'
    result_0 = host_vars_0.raw_get(host_name_0)
    assert result_0 is not None


# Generated at 2022-06-25 14:11:11.236521
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    """
    Represents the HostVars object as a string.
    """
    inventory_0 = None
    variable_manager_0 = None
    loader_0 = None
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    assert isinstance(host_vars_0.__repr__(), str)


# Generated at 2022-06-25 14:11:19.059348
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = None
    var_1 = None
    var_2 = None
    host_vars_0 = HostVars(var_0, var_1, var_2)
    var_3 = None
    var_4 = None
    var_5 = None
    host_vars_1 = HostVars(var_3, var_4, var_5)
    var_6 = None
    var_7 = None
    var_8 = None
    host_vars_2 = HostVars(var_6, var_7, var_8)
    var_9 = None
    var_10 = None
    var_11 = None
    host_vars_3 = HostVars(var_9, var_10, var_11)

# Generated at 2022-06-25 14:11:22.672003
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = None
    var_1 = None
    var_2 = { }
    host_vars_0 = HostVars(var_0, var_1, var_2)
    assert(host_vars_0.__getitem__(var_0) == AnsibleUndefined(name=var_1))



# Generated at 2022-06-25 14:11:26.836826
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Create an instance of the HostVars class.
    foo = HostVars(var_0, var_0, var_0)

    # Call the test case method.
    try:
        foo.raw_get()
    except Exception as e:
        print(traceback.format_exc())

# Generated at 2022-06-25 14:11:30.407732
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    var_1 = 'i'
    var_2 = host_vars_0.__getitem__(var_1)


# Generated at 2022-06-25 14:11:32.600010
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hvars = HostVars(None, None, None)
    hvars.raw_get(None, None, None)

# Generated at 2022-06-25 14:11:39.605948
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    var_1 = None
    host_vars_0.set_variable_manager(var_1)
    var_2 = None
    host_vars_0.set_inventory(var_2)
    var_3 = None
    host_vars_0.set_host_variable(var_3, var_1, var_0)
    var_4 = None
    var_5 = None
    host_vars_0.set_nonpersistent_facts(var_4, var_5)
    var_6 = None
    var_7 = None
    host_vars_0.set_host_facts(var_6, var_7)

    # Testing that method __iter

# Generated at 2022-06-25 14:11:45.819058
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Setup test environment
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)

    # Invoke method
    returned = str(host_vars_0)

    # Verify the results
    assert (isinstance(returned, str))


# Generated at 2022-06-25 14:13:26.090053
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    class dummy_type_0(object):
        @staticmethod
        def get_host(self_0):
            return list()

        @staticmethod
        def hosts():
            return list()
    var_0 = None
    var_1 = dummy_type_0
    host_vars_0 = HostVars(var_0, var_0, var_0)
    host_vars_0._inventory = var_1
    host_vars_0.__iter__()


# Generated at 2022-06-25 14:13:28.256604
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = None
    var_1 = 'foo'
    host_vars_0 = HostVars(var_0, var_0, var_0)
    assert host_vars_0.__getitem__(var_1) == 'foo'


# Generated at 2022-06-25 14:13:30.854420
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    s = host_vars_0.__repr__()


# Generated at 2022-06-25 14:13:35.591950
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    result = host_vars_0.__iter__()
    assert isinstance(result, type(iter([])))
    var_1 = None
    host_vars_1 = HostVars(var_1, var_1, var_1)
    result = host_vars_1.__iter__()
    assert isinstance(result, type(iter([])))


# Generated at 2022-06-25 14:13:43.941983
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = {}
    var_0['host_0'] = {}
    var_1 = {}
    var_2 = {}
    var_2['host_0'] = var_0['host_0']
    var_2['host_0']['test'] = 'test'
    var_2['host_1'] = {}
    var_2['host_1']['test'] = 'test'
    var_3 = {}
    var_3['host_1'] = var_2['host_1']
    var_4 = {}
    var_4['host_0'] = var_0['host_0']
    var_4['host_1'] = var_2['host_1']
    var_5 = {}
    var_5['host_1'] = var_3['host_1']
    var

# Generated at 2022-06-25 14:13:51.897490
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Constructor HostVars takes three arguments
    # In the constructor HostVars, argument inventory to HostVars is assigned None
    inventory_1 = None

    # In the constructor HostVars, argument variable_manager to HostVars is assigned None
    variable_manager_1 = None

    # In the constructor HostVars, argument loader to HostVars is assigned None
    loader_1 = None

    # Calling the constructor HostVars with arguments inventory_1, variable_manager_1, loader_1
    host_vars_1 = HostVars(inventory_1, variable_manager_1, loader_1)

    # Getting the type of 'host_vars_1' (line 136)
    host_vars_1_type_1 = type(host_vars_1)
    # Assigning a type to the variable 'assert_1'

# Generated at 2022-06-25 14:13:53.948868
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = HostVars(var_0, var_0, var_0)
    for value_0 in var_0:
        assert value_0 is not None


# Generated at 2022-06-25 14:13:57.122613
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    try:
        result = host_vars_0.__repr__()
    except:
        raise Exception("Raised exception while calling __repr__ on HostVars")

    assert result is not None


# Generated at 2022-06-25 14:13:58.413666
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    {hostvars[host]|default(omit)}


# Generated at 2022-06-25 14:14:02.190112
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_1 = None
    host_vars_1 = HostVars(var_1, var_1, var_1)
    expected_result = []

    actual_result = list(host_vars_1.__iter__())

    assert actual_result == expected_result
