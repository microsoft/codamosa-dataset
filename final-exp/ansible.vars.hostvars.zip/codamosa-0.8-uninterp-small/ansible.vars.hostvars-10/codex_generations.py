

# Generated at 2022-06-25 14:05:32.618288
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    float_0 = 3619.967
    host_vars_0 = HostVars(bool_0, float_0, float_0)
    var_0 = host_vars_0.raw_get(bool_0)
    assert var_0 == float_0


# Generated at 2022-06-25 14:05:42.807140
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    str_0 = '^a@.h~-%&'
    str_1 = 'P]{*iOmB0m#'
    set_2 = set()
    set_2.add(float())
    set_2.add(None)
    set_2.add(float())
    set_2.add(bool_0)
    set_2.add(str_0)
    bool_1 = False
    host_vars_0 = HostVars(str_1, set_2, str_0)
    host_vars_0.raw_get(set_2)
    host_vars_0.__setstate__(bool_1)
    host_vars_0.set_variable_manager(set_2)

# Generated at 2022-06-25 14:05:45.569332
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__repr__()


# Generated at 2022-06-25 14:05:49.317131
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    host_vars_vars_0.__setstate__(bool_0)


# Generated at 2022-06-25 14:05:54.304611
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:05:58.223043
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_0 = HostVars(float_0, bool_0, bool_0)
    var_0 = host_vars_0.raw_get(bool_0)



# Generated at 2022-06-25 14:06:04.342118
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    bool_1 = bool_0
    float_0 = 2569.1233
    float_1 = float_0
    float_2 = float_1
    float_3 = float_0
    float_4 = float_0
    host_vars_vars_0 = HostVarsVars(float_4, bool_0)
    for var_0 in host_vars_vars_0:
        print(var_0)



# Generated at 2022-06-25 14:06:09.378015
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__getitem__(bool_0)
    assert var_0 == float_0, 'return value expected to be {}'.format(float_0)


# Generated at 2022-06-25 14:06:11.251563
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False
    float_0 = 3.0
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:06:13.236794
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    # Simple test of iterating HostVars object
    hostvars = HostVars()

    for var in hostvars:
        assert type(var) == str


# Generated at 2022-06-25 14:06:22.093994
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars()
    host_vars_0.clear()
    host_vars_0 = HostVars()
    assert (iter(host_vars_0))


# Generated at 2022-06-25 14:06:23.386105
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    pass


# Generated at 2022-06-25 14:06:26.603110
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    # Setup test case
    host_vars_0 = HostVars()
    host_name_0 = "'"

    # Invoke method
    result_0 = host_vars_0.raw_get(host_name_0)



# Generated at 2022-06-25 14:06:31.772566
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    host_vars_0 = HostVarsVars({'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}, None)
    var_0 = []
    for var_1 in host_vars_0:
        var_0.append(var_1)
    assert var_0 == ['var1', 'var2', 'var3']


# Generated at 2022-06-25 14:06:38.745223
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    variables = {'ansible_host': 'hostname', 'foo': '{{ bar }}'}
    host_vars = HostVars(variables)

    host_vars['ansible_host'] == 'hostname'
    host_vars['foo'] == AnsibleUndefined(name="hostvars['foo']")

    variables = {'ansible_host': 'hostname', 'foo': '{{ bar }}', 'bar': 'bar'}
    host_vars = HostVars(variables)

    host_vars['ansible_host'] == 'hostname'
    host_vars['foo'] == 'bar'


# Generated at 2022-06-25 14:06:43.139380
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Reinitializing from scratch is a good way of testing __setstate__ because
    # it will have all attributes unset.
    host_vars_0 = HostVars()
    host_vars_0._variable_manager._loader = 'bar'
    host_vars_0._variable_manager._hostvars = 'foo'
    host_vars_setstate = host_vars_0.__getstate__()
    host_vars_1 = HostVars()
    host_vars_1.__setstate__(host_vars_setstate)
    pass

# Generated at 2022-06-25 14:06:47.468076
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # HostVars is not abstract so we can initialize it
    host_vars = HostVars()
    assert host_vars is not None

    # __setstate__ requires 'state' parameter
    # This test will fail because it is required
    # (We could mock it but it's not necessary)
    try:
        host_vars.__setstate__()
        raise AssertionError()
    except TypeError:
        pass

    # Set required 'state' parameter
    host_vars.__setstate__({'a': 1})

    # Check if it worked
    assert host_vars.__dict__ == {'a': 1}

# Generated at 2022-06-25 14:06:51.052775
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # test HostVars class
    host_vars = HostVars()
    # test __iter__ method
    host_vars.__iter__()

# Generated at 2022-06-25 14:07:01.631157
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # No Linting
    fake_loader = FakeLoader()
    fake_loader_constructor = None

    fake_variable_manager = FakeVariableManager(loader=fake_loader, loader_constructor=fake_loader_constructor)

    fake_inventory = FakeInventory(variable_manager=fake_variable_manager)

    host_vars_2 = HostVars(inventory=fake_inventory, variable_manager=fake_variable_manager, loader=fake_loader)

    localhost = host_vars_2.get('localhost')

    assert localhost['ansible_facts']['ansible_os_family'] == 'Debian'
    assert localhost['ansible_facts']['ansible_machine'] == 'x86_64'

# Generated at 2022-06-25 14:07:11.596357
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    hv_attr_names = set(['_loader', '_inventory', '_variable_manager'])

    new_hv = HostVars()

    # Init pickled HostVars for further testing
    pickled_hv = new_hv.__getstate__()

    # Verify that pickling of HostVars does not preserve loader and
    # hostvars attributes of VariableManager
    assert hv_attr_names == set(pickled_hv.keys())

    # Verify that loader and hostvars attributes of VariableManager are
    # restored on unpickling
    new_hv.__setstate__(pickled_hv)
    assert new_hv._loader == new_hv._variable_manager._loader
    assert new_hv._hostvars == new_hv._variable_manager._hostvars

# Generated at 2022-06-25 14:07:20.411917
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 3.741
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    # No type inference for this method
    # test start
    # test end
    if var_0 != None: raise Exception('AssertionError')


# Generated at 2022-06-25 14:07:27.003307
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # set up
    bool_0 = True
    float_0 = 2253.1102

# Generated at 2022-06-25 14:07:31.710585
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__getitem__(bool_0)
    assert 0.02 < var_0

test_case_0()

# Generated at 2022-06-25 14:07:33.957850
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 647.1411
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:07:38.177876
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    float_0 = 815.6
    str_0 = '{'
    host_vars_0 = HostVars(str_0, bool_0, float_0)
    host_0 = host_vars_0.__getitem__(str_0)
    assert host_0 is None


# Generated at 2022-06-25 14:07:43.636733
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_0 = HostVars(bool_0, float_0, float_0)
    host_vars_0.set_variable_manager(float_0)
    host_vars_0.set_inventory(float_0)
    var_0 = host_vars_0.raw_get(float_0)

# Generated at 2022-06-25 14:07:47.353426
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = False
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    str_0 = host_vars_0.__repr__()


# Generated at 2022-06-25 14:07:52.176943
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    float_0 = 1201.3582
    str_0 = "sBhKk"
    host_vars_vars_0 = HostVarsVars(float_0, str_0)
    next_0 = host_vars_vars_0.__iter__()
    next_1 = next_0.__next__()
    del next_0


# Generated at 2022-06-25 14:07:53.036367
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_case_0()


# Generated at 2022-06-25 14:07:57.632012
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    str_0 = host_vars_vars_0.__repr__()

# Generated at 2022-06-25 14:08:10.903320
# Unit test for method __setstate__ of class HostVars

# Generated at 2022-06-25 14:08:15.310998
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Setup
    host_vars = HostVars()
    key = 'key'

    # Invocation
    try:
        host_vars.__getitem__(key)
    except Exception as e:
        # Verification
        assert(e.__class__.__name__ == 'NameError')


# Generated at 2022-06-25 14:08:17.718284
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    float_0 = 9561.68
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__getitem__(bool_0)


# Generated at 2022-06-25 14:08:20.222610
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # TODO: add other tests
    bool_0 = True
    float_0 = 2253.1102
    host_vars_0 = HostVars(bool_0, float_0, float_0)
    var_0 = host_vars_0.__getitem__(bool_0)
    assert var_0 > 0


# Generated at 2022-06-25 14:08:22.609167
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    hv = HostVars()
    hv.__setstate__({'test': 'test'})
    assert hv.test == 'test'

# Generated at 2022-06-25 14:08:27.921444
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = None
    variable_manager = None
    loader = None
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    host_name_0 = 'regex_0'
    host_vars_0.raw_get(host_name_0)


# Generated at 2022-06-25 14:08:30.833144
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory, variable_manager, loader = init_values()
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    name_0 = 'my_name'
    var_0 = host_vars_0.raw_get(name_0)



# Generated at 2022-06-25 14:08:37.559882
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    float_0 = 6128.3248
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    print(host_vars_vars_0.__contains__(bool_0))
    print(host_vars_vars_0.__getitem__(bool_0))
    print(host_vars_vars_0.__len__())
    print(host_vars_vars_0.__repr__())


# Generated at 2022-06-25 14:08:39.727337
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 2243.6808
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    # TODO: implement your test here
    raise TypeError("Test case not implemented")


# Generated at 2022-06-25 14:08:43.008925
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:08:59.263092
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Set up objects
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    # Test __iter__
    assert isinstance(host_vars_vars_0.__iter__(), type(iter([])))


# Generated at 2022-06-25 14:09:04.010827
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = HostVars(bool_0, float_0, dict_0)
    host_name_0 = '127.0.0.1'
    host_vars_0.raw_get(host_name_0)


# Generated at 2022-06-25 14:09:11.365637
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    int_0 = 0
    list_0 = [False, False, False, False, True]
    list_1 = [bool_0, bool_0, bool_0, bool_0]
    set_0 = {list_0, bool_0}
    str_0 = 'X'
    str_1 = 'q>mV'
    str_2 = 'D<e$u'
    tuple_0 = (True, True, False)
    x = {str_1: str_0, list_1: int_0, list_0: str_1, tuple_0: int_0, set_0: bool_0, str_2: list_1}

    txt = 'test_case_0'

    if txt:
        f = open('test.txt', 'w')

# Generated at 2022-06-25 14:09:16.894873
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    host_vars_0 = HostVars(host_vars_vars_0, float_0, bool_0)
    host_vars_0.__iter__()


# Generated at 2022-06-25 14:09:20.958738
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    float_0 = -8.097
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0[bool_0]


# Generated at 2022-06-25 14:09:22.198712
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    pass


# Generated at 2022-06-25 14:09:26.378594
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    int_0 = 28258
    float_0 = 2253.1102
    host_vars_0 = HostVars(bool_0, int_0, float_0)
    var_0 = host_vars_0.raw_get(bool_0)
    assert float_0 == var_0


# Generated at 2022-06-25 14:09:29.563047
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    res_0 = host_vars_vars_0.__iter__().next()
    print(res_0)


# Generated at 2022-06-25 14:09:35.456455
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    file_name_0 = 'ansible/inventory/group_vars/test_group.yaml'
    group_vars_0 = {u'group_var': u'value'}
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager(loader_0=loader_0)
    variable_manager_0.set_group_vars(u'group_name', group_vars_0)
    variable_manager_0.set_group_vars_files(u'group_name', [file_name_0])
    inventory_0 = Inventory(loader_0=loader_0, variable_manager_0=variable_manager_0)
    inventory_0.set_variable_manager(variable_manager_0)
    inventory_0.add_host(u'test_host')
    host_v

# Generated at 2022-06-25 14:09:38.202877
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars()
    __iter__ = host_vars_0.__iter__()


# Generated at 2022-06-25 14:10:04.132114
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    try:
        host_vars_vars_0.__iter__()
    except Exception as err:
        bool_0 = False
    assert bool_0


# Generated at 2022-06-25 14:10:09.034024
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_0 = HostVars(bool_0, float_0, bool_0)
    var_0 = host_vars_0._find_host(float_0)
    var_1 = host_vars_0.__getitem__(bool_0)
    var_2 = host_vars_0.raw_get(float_0)

# Generated at 2022-06-25 14:10:11.126244
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # TODO: setup test values, check types and invocation of HostVars.__getitem__()
    var_0 = HostVars.__getitem__()
    print(var_0)

# Generated at 2022-06-25 14:10:14.588791
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__repr__()


# Generated at 2022-06-25 14:10:19.060301
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__iter__()
    assert var_0 == True


# Generated at 2022-06-25 14:10:23.715392
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    str_0 = host_vars_vars_0.__repr__()


# Generated at 2022-06-25 14:10:26.139626
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__getitem__(bool_0)


# Generated at 2022-06-25 14:10:29.642271
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    try:
        host_vars_vars_0.__iter__()
    except Exception:
        assert False


# Generated at 2022-06-25 14:10:32.329499
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__getitem__(bool_0)
    # This is not a true unit test, it must be manually checked if it's working


# Generated at 2022-06-25 14:10:35.207909
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    try:
        HostVars.test_case_0()
    except NameError:
        import sys
        print("test_case_0() missing from HostVars")
        print("Traceback: %s" % sys.exc_info()[2])
        return 1
    else:
        return 0


# Generated at 2022-06-25 14:11:27.916405
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Test with normal dictionary, inventory_hostname_short, and group
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVars()
    var_0 = host_vars_vars_0.raw_get(bool_0)

# Generated at 2022-06-25 14:11:29.253854
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_case_0()

# Generated at 2022-06-25 14:11:32.719183
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    float_0 = 7465.9542
    host_vars_0 = HostVars(bool_0, float_0, float_0)
    var_0 = host_vars_0.__getitem__(bool_0)


# Generated at 2022-06-25 14:11:35.329264
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    host_vars_vars_0 = HostVarsVars(None, None)
    iter_0 = host_vars_vars_0.__iter__()
    for element in iter_0:
        pass



# Generated at 2022-06-25 14:11:38.673234
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_1 = 'hostvars'
    dict_0 = dict([('hostname', 'ansible_connection'), ('localhost', 'local'), ('ansible_connection', 'local')])
    bool_0 = True
    host_vars_0 = HostVars(dict_0, bool_0)
    host_vars_0.raw_get(str_1)


# Generated at 2022-06-25 14:11:40.925871
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 469.008
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    for i in host_vars_vars_0:
        print("foo")


# Generated at 2022-06-25 14:11:45.662766
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = HostVars()
    host_name_0 = 'cbhsynif5'
    var_0 = host_vars_0.raw_get(host_name_0)


# Generated at 2022-06-25 14:11:47.506671
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars = HostVars(bool_0, float_0)
    var_0 = host_vars.__getitem__(bool_0)


# Generated at 2022-06-25 14:11:51.019100
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    """
    raw_get()
    """
    host_vars_0 = HostVars(bool_0, float_0)
    var_0 = host_vars_0.raw_get(bool_0)
    assert var_0 == bool_0



# Generated at 2022-06-25 14:11:53.774542
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    float_0 = 3.359
    host_vars_0 = HostVars(bool_0, float_0, float_0)
    var_0 = host_vars_0.raw_get(bool_0)

# Generated at 2022-06-25 14:13:52.031563
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = True
    host_vars_0 = HostVars(bool_0, bool_0)
    var_0 = host_vars_0.__getitem__(bool_0)


# Generated at 2022-06-25 14:13:59.974642
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    float_0 = 2253.1102
    dict_0 = dict()
    dict_1 = dict()
    dict_1['foo'] = dict()
    dict_1['foo']['bar'] = 'test'
    dict_1['foo']['baz'] = 'test'
    dict_1['foo']['fizz'] = 'test'
    dict_0['test'] = dict_1
    dict_0['test'] = dict_1
    dict_0['test'] = dict_1
    dict_1 = dict()
    dict_1['foo'] = dict()
    dict_1['foo']['bar'] = 'test'
    dict_1['foo']['baz'] = 'test'
    dict_1['foo']['fizz'] = 'test'

# Generated at 2022-06-25 14:14:03.012383
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_3 = False
    float_3 = 4694.6935
    host_vars_vars_3 = HostVarsVars(bool_3, float_3)
    var_3 = host_vars_vars_3.__iter__()


# Generated at 2022-06-25 14:14:12.649517
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    float_0 = 1110.3283
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__getitem__(bool_0)
    tup_0 = (var_0, host_vars_vars_0)
    var_1 = HostVars(*tup_0).raw_get(var_0)
    bool_1 = True
    bool_2 = host_vars_vars_0.__contains__(bool_1)
    bool_3 = True
    bool_4 = bool_3 is bool_2
    bool_5 = False
    bool_6 = bool_5 is bool_4
    bool_7 = True
    bool_8 = bool

# Generated at 2022-06-25 14:14:18.441151
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    bool_1 = False
    float_1 = 91.0
    host_vars_vars_1 = HostVars(bool_1, float_1, host_vars_vars_0)
    var_2 = host_vars_vars_1.raw_get(bool_0)

# Generated at 2022-06-25 14:14:21.291462
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    float_0 = 2253.1102
    host_vars_0 = HostVars(bool_0, float_0, float_0)
    host_vars_0.__iter__()


# Generated at 2022-06-25 14:14:24.482279
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 1163.5201
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    # No error: assertion "PyList_Check(value)" failed
    host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:14:26.187425
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    missing_host = 'foo'
    host_vars = HostVars(None, None, None)
    assert host_vars.raw_get(missing_host) is AnsibleUndefined

# Generated at 2022-06-25 14:14:28.452292
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    float_0 = 2510.2305
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:14:30.509939
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False
    float_0 = 114.0805
    host_vars_vars_0 = HostVarsVars(bool_0, float_0)
    var_0 = host_vars_vars_0.__iter__()