

# Generated at 2022-06-25 14:05:35.094198
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)


# Generated at 2022-06-25 14:05:39.389240
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Call function __iter__
    try:
        result = HostVars.__iter__()
    except Exception as e:
        print('FAIL: test_HostVars___iter__()')
        print('Exception: ' + str(e))


# Generated at 2022-06-25 14:05:47.306097
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars(str_0, float_0, str_0)
    dict_0 = dict()
    dict_0['ansible_version'] = 2.0
    dict_0['ansible_play_hosts'] = 2.0
    dict_0['ansible_dependent_role_names'] = 2.0
    dict_0['ansible_play_role_names'] = 2.0
    dict_0['ansible_role_names'] = 2.0
    dict_0['inventory_hostname'] = 2.0
    dict_0['inventory_hostname_short'] = 2.0
    dict_0['inventory_file'] = 2.0
    dict_0['inventory_dir'] = 2.0
    dict_0['groups'] = 2.0

# Generated at 2022-06-25 14:05:51.493837
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'gq3q,iHlF-K'
    host_vars_0 = HostVars(str_0, str_0, str_0)
    str_1 = repr(host_vars_0)
    assert str_1 == str_0


# Generated at 2022-06-25 14:06:03.047832
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    raw_0 = {'obj_0': 'array_0', 'obj_1': 'array_1', 'obj_2': 'array_2'}
    host_vars_0 = HostVars(raw_0)
    raw_1 = host_vars_0.__iter__()
    raw_1[0] = 'array_3'
    raw_1[1] = 'array_3'
    raw_1[2] = 'array_3'
    raw_1[3] = 'array_3'
    raw_1[4] = 'array_3'
    raw_1[5] = 'array_3'
    raw_1[6] = 'array_3'
    raw_1[7] = 'array_3'
    raw_1[8] = 'array_3'
   

# Generated at 2022-06-25 14:06:08.477574
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = 'k`=s}s'
    float_0 = 2.4898127678297817e-07
    hostvars_0 = HostVars(str_0, float_0, str_0)
    str_1 = 'env10'
    tuple_0 = (str_1, str_1)
    hostvars_0.__setstate__(tuple_0)


# Generated at 2022-06-25 14:06:11.360957
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    str_1 = 'D2Fq4,zwG<yTZ'
    float_1 = 2.0
    assert host_vars_vars_0.__getitem__(str_1) == float_1


# Generated at 2022-06-25 14:06:20.146850
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    try:
        str_0 = '{z*r)@PZ.N5w7b'
        float_0 = 3.0
        host_vars_0 = HostVars(str_0, float_0, float_0)
        str_1 = 'g[v=e;]$D.[I.i`'
        float_1 = 3.0
        host_vars_0.raw_get(str_1, float_1)
    except Exception as exception_0:
        print(exception_0)
    else:
        print('Unhandled exception')


# Generated at 2022-06-25 14:06:26.383543
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    int_0 = 0
    while (int_0 < len(host_vars_vars_0)) :
        int_0 += 1


# Generated at 2022-06-25 14:06:31.551393
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    for var in host_vars_vars_0:
        ret = host_vars_vars_0.__contains__(var)


# Generated at 2022-06-25 14:06:35.651905
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    test_var_0 = HostVars()
    assert test_var_0 is not None
    var_0 = test_var_0.raw_get(host_name="host_name_0")
    assert var_0 is not None


# Generated at 2022-06-25 14:06:38.699444
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.module_utils.six import PY3
    if PY3:
        return
    # Calling method __setstate__ of class HostVars with argument var_0
    result = test_case_0()
    assert result is None

# Generated at 2022-06-25 14:06:39.646556
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    pass


# Generated at 2022-06-25 14:06:43.259088
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = HostVars(inventory=None, variable_manager=None, loader=None)
    var_1 = None
    var_2 = var_0.raw_get(host_name=var_1)
    assert(isinstance(var_2, AnsibleUndefined))


# Generated at 2022-06-25 14:06:45.798123
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    var_0 = HostVars(inventory, variable_manager, loader)
    var_0.__iter__()


# Generated at 2022-06-25 14:06:57.862990
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = dict()
    var_0['ansible_playbook_python'] = '/usr/bin/python3'
    var_0['ansible_connection'] = 'local'
    var_0['gather_subset'] = [
        'all',
    ]
    var_0['ansible_version'] = {
        'full': '2.9.2',
        'major': 2,
        'minor': 9,
        'revision': 2,
        'string': '2.9.2',
    }
    var_0['playbook_dir'] = '/home/val/ansible-starter/'
    var_0['ansible_python_interpreter'] = '/usr/bin/python3'
    var_0['ansible_host'] = 'localhost'

# Generated at 2022-06-25 14:07:05.222893
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = test_case_0()
    temp_0 = None
    temp_1 = temp_0
    temp_2 = None
    temp_2 = HostVars(temp_1, temp_0, temp_0)
    temp_3 = None
    temp_3 = temp_2.raw_get(temp_3)
    temp_4 = None
    temp_4 = temp_2.raw_get(temp_4)
    temp_5 = None
    temp_5 = temp_2.raw_get(temp_5)
    temp_6 = None
    temp_6 = temp_2.raw_get(temp_6)
    temp_7 = None
    temp_7 = temp_2.raw_get(temp_7)
    temp_8 = None
    temp_8 = temp_2.raw

# Generated at 2022-06-25 14:07:08.699513
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hostvars = HostVarsVars(var_0, var_0)
    result = hostvars.raw_get(var_0)
    assert result is not None

# Generated at 2022-06-25 14:07:20.611040
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Test case with an empty variable manager
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    result = hv.raw_get(host_name=None)
    assert isinstance(result, AnsibleUndefined)

    # Test case with an HostVars containing a variable manager containing the
    #    '_variables' attribute set to a dict containing the '_play_context'
    #    attribute set to a dict containing the 'host_name' attribute set to
    #    'test_host_name'
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    var_0 = dict()
    var_0['_play_context'] = dict()

# Generated at 2022-06-25 14:07:23.577263
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    print('Test method __repr__ of class HostVars')
    # Set up parameters
    inventory = dict()
    variable_manager = dict()

    # Call method __repr__
    HostVars(inventory, variable_manager)

# Generated at 2022-06-25 14:07:36.473055
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    float_0 = float('nan')
    float_1 = float('inf')
    float_2 = float('-inf')
    bool_0 = bool('Cw1wv=@n>')
    str_0 = '`H^<f0%&WDg{hZ'
    str_1 = '&`D)`:9E19YKjN'
    str_2 = '5ZF{[-*Ew,Oc'
    int_0 = 709375464
    str_3 = 'D2Fq4,zwG<yTZ'
    str_4 = '*K5f-k'
    bool_1 = bool('MZPn4Kt.2')
    dict_0 = dict()
    str_5 = 'J)W&N8'
    str_

# Generated at 2022-06-25 14:07:42.930824
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    print()
    print('METHOD __repr__')
    print('################')
    
    # Test 1
    host_vars_0 = HostVars(host)
    print(host_vars_0)
    
    # Test 2
    host_vars_1 = HostVars(host)
    print(host_vars_1)
    
    # Test 3
    host_vars_2 = HostVars(host)
    print(host_vars_2)


# Generated at 2022-06-25 14:07:48.071012
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:07:52.424369
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    for value in host_vars_vars_0:
        print(value)


# Generated at 2022-06-25 14:07:58.727038
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'rD<r'
    float_0 = -17.995927461113898
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    __tracebackhide__ = True # Hide traceback for pytest
    try:
        host_vars_vars_0.__iter__()
        assert False
    except:
        assert True


# Generated at 2022-06-25 14:08:07.988934
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    inventory = 'yj`:.|1Y'
    host_vars_0 = HostVars(inventory, STATIC_VARS, 'y.X:a:f')
    inventory = 'JWZ#z6Uw'
    inventory = {'hostname': 'localhost'}
    host_vars_1 = HostVars(inventory, STATIC_VARS, 'y.X:a:f')
    # Verify: HostVars.__setstate__({'_inventory': inventory, '_variable_manager': VariableManager(), '_loader': 'y.X:a:f'}) == host_vars_1
    assert host_vars_1.__setstate__({'_inventory': inventory, '_variable_manager': VariableManager(), '_loader': 'y.X:a:f'})
    # Verify:

# Generated at 2022-06-25 14:08:11.959252
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    host_vars_0 = HostVars()
    str_0 = ':pF8A}'

    host_vars_0.__setstate__(str_0)
    assert True


# Generated at 2022-06-25 14:08:16.513160
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = '0'
    float_0 = 3.0
    host_vars_0 = HostVars(str_0, float_0, float_0)
    str_1 = 'wzOv$\x7fzH0Z7'
    foo_0 = host_vars_0.__getitem__(str_1)



# Generated at 2022-06-25 14:08:17.361650
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    assert 1 == 0


# Generated at 2022-06-25 14:08:18.352764
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # create instance of class with params
    # perform test
    assert True # TODO: implement your test here


# Generated at 2022-06-25 14:08:28.153001
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    raw_get_0 = HostVars(None, None, None)
    raw_get_1 = raw_get_0.raw_get(str_0)

# Unit tests for class HostVarsVars


# Generated at 2022-06-25 14:08:33.103392
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.host import Host
    host_name = 'example.com'
    facts = { 'not': 'persistent' }
    h = Host(host_name)
    hv = HostVars({ host_name: h })
    hv.set_nonpersistent_facts(h, facts)
    assert facts == hv.raw_get(host_name)

# Generated at 2022-06-25 14:08:41.309927
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # get HostVars test object
    # input parameter
    class Inventory(): 
        def __init__(self):
            self._hosts = {}
    host_name = 'test_host_name'

    class VariableManager():
        def __init__(self): 
            self._vars_cache = {}
            self._hostvars = {}
            self._nonpersistent_facts_cache = {}
            self._vars_plugins = {}
            self._host_vars_plugins = {}
            self._fact_cache = {}
            self._extra_vars = {}
            self._options_vars = {}
            self._host_specific_extra_vars = {}
            self._task_specific_extra_vars = {}
            self._extra_vars_files = []
            self._play = {}
            self._

# Generated at 2022-06-25 14:08:45.039364
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    for var in host_vars_vars_0:
        pass


# Generated at 2022-06-25 14:08:50.274811
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'WKH8%GW,y<'
    host_vars_vars_0 = HostVarsVars(str_0, str_0)
    host_vars_0 = HostVars(str_0, str_0, str_0)
    assert host_vars_0.__repr__() == host_vars_vars_0.__repr__()


# Generated at 2022-06-25 14:08:59.887749
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '7D:ZkdYj7q#;'
    str_1 = 'fKjR7'
    str_2 = 'bU6/Y'
    str_3 = '<Cxwv'
    str_4 = '=jW>z8Z*|'
    float_0 = 4.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    host_vars_vars_0.__repr__()
    host_var_0 = HostVars(str_1, str_2, str_3)
    host_var_0.__repr__()
    host_var_0_1 = HostVars(str_4, str_2, str_3)
    host_var_0.__

# Generated at 2022-06-25 14:09:09.641664
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    str_1 = '+{=k eT'
    host_vars_0 = HostVars(str_1, host_vars_vars_0, host_vars_vars_0)
    str_2 = '8UfWk'
    host_vars_1 = host_vars_0[str_2]

if __name__ == "__main__":
    import sys
    import argparse
    from ansible.utils.display import Display
    from ansible.utils import module_docs
    from ansible.utils import code
    from itertools import im

# Generated at 2022-06-25 14:09:13.412953
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_vars_0 = HostVars('jNxC?z', float(), float())
    float_0 = 3.0
    for str_0 in host_vars_vars_0:
        float_0 = float_0


# Generated at 2022-06-25 14:09:16.454859
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    float_0 = float('nan')
    float_1 = float('NAN')
    host_vars_0 = HostVars(float_0, float_1)


# Generated at 2022-06-25 14:09:24.179417
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # This test is here to provide 100% coverage on HostVars, not to test
    # the functionality of this method.
    str_0 = 'r*h-Vf'
    float_0 = 2.0
    loader_0 = 0.0
    host_vars_0 = HostVars(str_0, float_0, loader_0)
    host_vars_0.raw_get(str_0)
    host_vars_0.get(str_0)
    host_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 14:09:37.187795
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = None
    variable_manager = None
    loader = None
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    out = repr(host_vars_0)


# Generated at 2022-06-25 14:09:40.856272
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)


# Generated at 2022-06-25 14:09:50.031400
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    int_0 = 0
    str_0 = '~\x1f\x08\x00\x18\x00\x00\n'
    dict_0 = dict()
    dict_1 = dict()
    str_1 = '\xfa\xd5\x1b\x0c'
    dict_2 = dict()
    dict_1[str_1] = dict_2
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_5[str_1] = int_0
    dict_4[str_1] = dict_5
    dict_3[str_1] = dict_4
    dict_1[str_0] = dict_3

# Generated at 2022-06-25 14:09:57.466464
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    templar = Templar(variables=str_0, loader=float_0)
    dict_0 = dict()

    # Try templating a variable (setting a local variable)
    str_1 = 'xI,{J#;l'
    str_2 = '!9UUnM6U,Yn+BD'
    dict_0[str_1] = str_2
    str_3 = 'o#zfBp@'
    dict_0[str_3] = dict_0
    str_4 = 'T]L$'
    dict_0[str_4] = dict_0
    str_5 = ';WA'

# Generated at 2022-06-25 14:10:00.616111
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    int_0 = 0
    str_0 = 'hOS5d/08'
    host_vars_vars_0 = HostVars.__getitem__(int_0, str_0)


# Generated at 2022-06-25 14:10:08.526233
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    print( '=== START ===')
    str_0 = 'ZMhf$m.*x&mu^'
    float_0 = 0.968
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    str_1 = '&5P69bqYd]<8'
    float_1 = 0.054
    host_vars_vars_1 = HostVarsVars(str_1, float_1)

    host_vars_vars_1.__iter__()
    #assert host_vars_vars_0.__iter__() == ''


# Generated at 2022-06-25 14:10:12.571835
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    i = 0
    for x in host_vars_vars_0:
        i += 1
    assert i == 1


# Generated at 2022-06-25 14:10:23.715274
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    float_0 = 5.0
    str_0 = 'D2Fq4,zwG<yTZ'
    str_1 = 'XB?3#d;Y#au&k'
    str_2 = 'oj'
    str_3 = 'jX)pZz**:0-B'
    str_4 = '}yelf2Wr^Hb8'
    float_1 = 4.0
    # Create an instance of class HostVars with arguments self, float_0, float_1, float_0, float_0 and key-word arguments hostvars_0=str_0, loader_0=str_1

# Generated at 2022-06-25 14:10:31.922937
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    str_0 = '#mwBik+kR5J'
    str_1 = '+9]nDnS8,v'
    str_2 = '=@'
    list_0 = ['\\', str_2, str_2]
    list_1 = ['\\']
    list_2 = [str_1]
    list_3 = [str_1, str_0]
    list_4 = ['']
    dict_0 = dict()
    dict_0['\\'] = 'z\'R'
    dict_0[''] = '\'F*(+)'
    dict_0[str_0] = '\\r\\r'
    dict_0['h,!C:n[n#s'] = 'Bk9_E\''

# Generated at 2022-06-25 14:10:38.064673
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    int_0 = -43
    str_1 = 'n<e?{'
    int_1 = -71
    str_2 = '9}_'
    double_0 = -0.0125
    int_2 = -80
    str_3 = '9}_'
    int_3 = -80
    str_4 = '9}_'
    int_4 = -80
    str_5 = '9}_'
    int_5 = -80
    str_6 = '9}_'
    str_7 = '9}_'

# Generated at 2022-06-25 14:11:14.852296
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '<|8Wn,#'
    str_1 = 'JX>1"k*=7|uw'
    str_2 = 'r'
    float_0 = 0.0
    str_3 = ",**<p"
    list_0 = ['6F2h?', str_3, 'Nl=']
    float_1 = 4.0
    list_1 = ['6F2h?', str_3, 'Nl=']
    str_4 = '|[Vjw~'
    str_5 = 'r'
    float_2 = 4.0
    str_6 = "~B,39"
    str_7 = "~B,39"
    str_8 = "~B,39"
    str_9 = "~B,39"
    str

# Generated at 2022-06-25 14:11:18.424174
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'X}p:gZ?M'
    float_0 = 6.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    try:
        next(iter(host_vars_vars_0))
    except StopIteration as exception_0:
        pass


# Generated at 2022-06-25 14:11:25.182955
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    ansible_undefined_0 = AnsibleUndefined(None)
    # Input:
    # state = {'_variable_manager': {'_fact_cache': {'somehost': {'ansible_os_family': 'RedHat'}}}, '_inventory': {'_hosts_patterns': ['localhost'], '_hosts_list': [{'_group_names': ['ungrouped', 'all'], '_name': 'localhost', '_vars': {}, '_groups': [], '_aliases': ['127.0.0.1', '::1'], '_hosts': [], '_options': {'ansible_connection': None, 'ansible_host': 'localhost', 'ansible_port': None}}]}}

# Generated at 2022-06-25 14:11:33.286392
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    dict_0 = dict(a='Z3}Pp$D<;I:Fkr]0', b=7.0)
    dict_1 = dict(a='Z3}Pp$D<;I:Fkr]0', b=7.0)
    dict_2 = dict(a='Z3}Pp$D<;I:Fkr]0', b=7.0)
    m = HostVars(str_0, float_0, dict_0)
    for host in m:
        pass


# Generated at 2022-06-25 14:11:36.899746
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = 'y.t'
    float_0 = 4.0
    host_vars_vars_1 = HostVarsVars(str_0, float_0)
    int_0 = 0
    for key in host_vars_vars_1:
        int_0 += 1
    assert int_0 == 1


# Generated at 2022-06-25 14:11:42.099675
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    inventory = None
    variable_manager = None
    loader = None
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    repr_0 = repr(host_vars_0)

    # TODO function test_HostVars___repr__ not implemented
    assert repr_0 == 0



# Generated at 2022-06-25 14:11:52.124247
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    class Host:
        def __init__(self, name):
            self.name = name

    class HostVars_0(HostVars):
        def __init__(self, str_0, float_0):
            self._inventory = str_0
            self._loader = float_0
            self._variable_manager = str_0

    float_0 = 2.0
    host_vars_0 = HostVars_0('foo', float_0)
    str_0 = 'D2Fq4,zwG<yTZ'
    int_0 = 1
    str_1 = 'bar'
    int_1 = 6
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    host_vars_vars_0[str_0]
   

# Generated at 2022-06-25 14:11:58.552901
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variables = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variables, loader)
    print(hostvars.raw_get('localhost'))

if __name__ == '__main__':
    # Unit test for method raw_get of class HostVars
    test_HostVars_raw_get()

# Generated at 2022-06-25 14:12:02.118069
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    inventory = None
    variable_manager = None
    loader = None
    host_vars_0 = HostVars( inventory,  variable_manager,  loader)

    host_name = 'D2Fq4,zwG<yTZ'
    assert type(host_vars_0[host_name]) == AnsibleUndefined


# Generated at 2022-06-25 14:12:03.662960
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    test_case_0()


# Generated at 2022-06-25 14:13:07.969904
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = '4huH=&uV3Zq'
    float_0 = 3.0
    host_vars_0 = HostVars(str_0, float_0, float_0)
    str_1 = '+NQ&Oyh-8Tv'
    str_2 = '#'
    str_3 = 'I^:'

    # Test case with an expected exception
    with pytest.raises(Exception) as excinfo:
        host_vars_0.raw_get(str_1)
    the_exception = excinfo.value
    assert str(the_exception) == str_2

    # Test case with an expected exception
    with pytest.raises(Exception) as excinfo:
        host_vars_0.raw_get(str_3)
    the

# Generated at 2022-06-25 14:13:12.606632
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)


# Generated at 2022-06-25 14:13:17.953232
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'vU'
    str_1 = '6~C'
    float_0 = 4.8
    str_2 = '%s' % float_0
    host_vars_0 = HostVars(str_2, float_0, str_1)
    str_3 = "hostvars['%s']" % str_0
    assert (host_vars_0.raw_get(str_0) is AnsibleUndefined(name=str_3))


# Generated at 2022-06-25 14:13:21.904653
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = 'Etd:Si(b=W;f.G'
    float_0 = 9.9
    host_vars_0 = HostVars(str_0, float_0, float_0)

    try:
        host_vars_0.__setstate__(None)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 14:13:27.759541
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Tests the __getitem__ function of HostVars with the following cases:
    #   host_name -> return AnsibleUndefined
    #   host_name -> return AnsibleUndefined
    #   host_name -> return data
    str_0 = 'asd'
    float_0 = 4.5
    # Case 1
    str_1 = 'asd'
    float_1 = 3.5
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    # Case 2
    str_2 = 'as'
    float_2 = 3.0
    host_vars_vars_1 = HostVarsVars(str_0, float_0)
    # Case 3
    str_3 = 'as'
    float_3 = 4.5
    host_

# Generated at 2022-06-25 14:13:29.635813
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_vars_0 = HostVarsVars()
    # TODO: Add your test here


# Generated at 2022-06-25 14:13:33.702031
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    float_0 = 2.0
    str_0 = 'D2Fq4,zwG<yTZ'
    dict_0 = {}
    host_vars_0 = HostVars(dict_0, str_0, float_0)
    str_1 = host_vars_0.__getitem__(str_0)
    assert str_1 is not None


# Generated at 2022-06-25 14:13:41.675889
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    str_0 = 'dA5>5F5Xwi|%&8*>VGK'
    str_1 = 'c,$sr=F3h6|*iX)\x0b}\x0b\x10'
    str_2 = 'pC'
    str_3 = '!5a5F5Xwi|%&8*>VGK'
    str_4 = ',$sr=F3h6|*iX)\x0b}\x0b\x10'
    str_5 = 'C'
    host_vars_0 = HostVars(str_0, str_1, str_2)
    assert host_vars_0.raw_get(str_3) == str_4
    assert host_vars_0.raw_get(str_5) == str_2

# Generated at 2022-06-25 14:13:47.243001
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    str_0 = 'F7I$_O6C'
    float_0 = 9.0
    host_vars_vars_0 = HostVarsVars(str_0, float_0)
    for arg_2 in host_vars_vars_0:
        str_1 = 'B`%8(iW{hv~'
        float_1 = 2.0
        host_vars_vars_1 = HostVarsVars(str_1, float_1)
    test_case_0()


# Generated at 2022-06-25 14:13:50.810724
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'D2Fq4,zwG<yTZ'
    float_0 = 2.0
    host_vars_0 = HostVars(str_0, float_0)
    try:
        host_vars_0.__repr__()
    except:
        raise Exception('AssertionError: 1 != 0')
