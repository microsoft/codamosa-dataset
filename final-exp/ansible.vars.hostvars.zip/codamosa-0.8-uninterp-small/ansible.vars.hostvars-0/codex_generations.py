

# Generated at 2022-06-25 14:05:38.499566
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    str_0 = "5uV=z]_B^n[Qng>|"
    float_0 = -45.687966
    bool_0 = True
    host_vars_0 = HostVars(str_0, float_0, bool_0)
    str_1 = "kV"
    float_1 = 0.3
    bool_1 = False
    host_vars_1 = HostVars(str_1, float_1, bool_1)
    host_vars_0.set_variable_manager(host_vars_1)


# Generated at 2022-06-25 14:05:45.728712
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "Sx22F`"
    str_1 = "Qc4X"
    list_0 = ["y", "D", "CQ1m"]
    list_1 = [str_0, str_1]
    float_0 = -5807.1
    int_0 = 1250
    bool_0 = False
    host_vars_0 = HostVars(list_0, list_1, float_0, int_0, bool_0)
    assert isinstance(host_vars_0, HostVars)
    for i_0 in range(0, 100):
        host_vars_0.__iter__()


# Generated at 2022-06-25 14:05:54.672109
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = 'asDhBiWdO5N5'
    float_0 = -15348.63667
    int_0 = 15166
    host_vars_0 = HostVars(str_0, float_0, int_0)
    dict_0 = {}
    dict_0['foo'] = host_vars_0
    dict_0['bar'] = host_vars_0
    dict_0['baz'] = host_vars_0
    host_vars_0.__setstate__(dict_0)
    return dict_0


# Generated at 2022-06-25 14:06:04.855114
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = "wO#"
    float_0 = -2854.829
    bool_0 = True
    host_vars_0 = HostVars(str_0, float_0, bool_0)
    str_1 = "zb*/"
    float_1 = 3011.767
    bool_1 = True
    host_vars_0.__setstate__(str_1, float_1, bool_1)
    str_2 = "^6d8T"
    float_2 = 4243.26
    bool_2 = True
    host_vars_0.__setstate__(str_2, float_2, bool_2)
    str_3 = "E!t"
    float_3 = -4776.976
    bool_3 = True
    host_vars

# Generated at 2022-06-25 14:06:11.862632
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "|J&z+]5"
    float_0 = 16078.9646
    bool_0 = True
    host_vars_0 = HostVars(str_0, float_0, bool_0)
    host_vars_vars_0 = HostVarsVars(host_vars_0, host_vars_0, host_vars_0)
    assert str_0 == str(host_vars_0)
    assert float_0 == float(host_vars_0)
    assert bool_0 == bool(host_vars_0)


# Generated at 2022-06-25 14:06:21.558682
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
        # Assert if a callable is passed, to check if it raises an exception
        try:
                # If the callable raises an exception, the test will succeed...
                HostVars.__setstate__(test_case_0)
        except:
                # ... otherwise it will fail
                assert 0

if __name__ == '__main__':
    test_case_0()
    '''
    # Create a protected object instance
    protected_instance = HostVars()

    # Test method
    protected_instance.__setstate__(test_case_0)

    # Test method __getitem__ of class HostVars
    protected_instance.__getitem__()
    '''

# Generated at 2022-06-25 14:06:29.456147
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    str_0 = "Q1_)vx$oSK*7]u"
    float_0 = -1542.6866
    bool_0 = True
    host_vars_0 = HostVars(str_0, float_0, bool_0)
    str_1 = "RXJ}x;+2I"
    str_2 = "py3,]J!I$+%c(y"
    float_1 = 2525.68
    bool_1 = True
    host_vars_0.set_variable_manager(str_1, str_2, float_1, bool_1)


# Generated at 2022-06-25 14:06:34.410356
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = "6'Cw*nW(V8"
    float_0 = -2605.53988
    bool_0 = True
    host_vars_0 = HostVars(str_0, float_0, bool_0)
    actual = host_vars_0.__repr__()
    assert actual == '{}', 'actual: {actual}'


# Generated at 2022-06-25 14:06:38.699751
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    str_0 = "$hHy0"
    float_0 = -87.87
    bool_0 = True
    host_vars_0 = HostVars(str_0, float_0, bool_0)
    for value_0 in host_vars_0:
        # Call assert*() method, if needed
        assert value_0 is not None


# Generated at 2022-06-25 14:06:43.298976
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    str_0 = ">9EkoE']Vmh}H"
    float_0 = -2475.04014
    bool_0 = True
    host_vars_0 = HostVars(str_0, float_0, bool_0)
    str_1 = "~S-0EHM"
    float_1 = 4106.864785
    bool_1 = True
    host_vars_1 = HostVars(str_1, float_1, bool_1)
    host_vars_1.__setstate__(host_vars_0)


# Generated at 2022-06-25 14:07:01.668796
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x81n'
    bool_0 = False
    host_vars_0 = HostVars(bytes_0, bytes_0, bool_0)
    def side_effect_0(arg_0):
        str_0 = 'tes\u053c\x01G}|\ueafe\x8b-\x13v\x9b\x1c\x83\x05\x99'
        tuple_0 = (str_0,)
        print(tuple_0)


# Generated at 2022-06-25 14:07:04.415951
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x81n'
    bool_0 = False
    host_vars_0 = HostVars(bytes_0, bytes_0, bool_0)
    assert host_vars_0.__iter__() != None


# Generated at 2022-06-25 14:07:16.591810
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle
    bytes_0 = b'\x81n'
    bool_0 = False
    host_vars_0 = HostVars(bytes_0, bytes_0, bool_0)

    class TestHostVars:
        def __getstate__(self):
            return (1, 2, 3)

        def __setstate__(self, state):
            pass

    testhostvars_0 = TestHostVars()
    data_0 = pickle.dumps(testhostvars_0)
    data_1 = pickle.loads(data_0)
    assert data_1 is not None

# Generated at 2022-06-25 14:07:21.643885
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = b'\x81n'
    loader = b'\x81n'
    host_vars_vars_0 = HostVarsVars(variables, loader)
    enumerate_0 = enumerate(host_vars_vars_0)
    assert enumerate_0 is not None


# Generated at 2022-06-25 14:07:28.379195
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    var_0 = 'test_HostVars___setstate__: val_0'
    var_1 = 'test_HostVars___setstate__: val_1'
    bytes_0 = b'\x81n'
    bool_0 = False
    host_vars_0 = HostVars(bytes_0, bytes_0, bool_0)
    dict_0 = dict({var_0: var_1})
    host_vars_0.__setstate__(dict_0)


# Generated at 2022-06-25 14:07:31.829319
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x81n'
    bool_0 = False
    host_vars_0 = HostVars(None, bytes_0, bool_0)
    for i in host_vars_0:
        i

# Generated at 2022-06-25 14:07:36.660381
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\xe8\x10\xcb\x1d\x1f\xee\x19_'
    bool_0 = False
    host_vars_0 = HostVars(bytes_0, bytes_0, bool_0)
    for x_0 in host_vars_0:
        print(x_0)


# Generated at 2022-06-25 14:07:42.080775
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_name_0 = b'\x81n'
    host_vars_0 = HostVars(var_name_0, var_name_0, False)
    var_name_0 = b'\x81n'
    var_value_0 = host_vars_0.raw_get(var_name_0)
    print(var_value_0)


# Generated at 2022-06-25 14:07:48.155032
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x81n'
    bool_0 = False
    host_vars_0 = HostVars(bytes_0, bytes_0, bool_0)
    bool_1 = False
    str_0 = host_vars_0.__getitem__(bool_1)
    assert(str_0 == 'AnsibleUndefined object has no attribute vars')


# Generated at 2022-06-25 14:07:54.175348
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\xff\xa3\x80\x8e\xb3\x1f\x84\xff\x87'
    bool_0 = True
    host_vars_0 = HostVars(bytes_0, bytes_0, bool_0)
    str_0 = '\x1f\xf2\x83\x81\x8b\x9b\x1f\xc7\x83'
    host_vars_0.raw_get(str_0)


# Generated at 2022-06-25 14:08:05.319103
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False
    list_0 = [dict_0, dict_1]
    dict_0 = {}
    dict_1 = {}
    host_vars_0 = HostVars(list_0, dict_0, dict_1)
    var_0 = host_vars_0.__iter__()
    if not isinstance(var_0, types.GeneratorType):
        raise Exception("Wrong type for return value of HostVars.__iter__ method")


# Generated at 2022-06-25 14:08:14.779573
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = False
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    int_0 = 0
    str_0 = 'wC|~J\u001f'
    str_1 = '{!p}'.format(int_0)
    str_2 = 'fP/E|'
    str_3 = '%s_%s_%s_%s' % (str_0, str_1, str_1, str_2)
    assert type(host_vars_0.__repr__()) is str
    assert host_vars_0.__repr__() == str_3


# Generated at 2022-06-25 14:08:15.709302
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    test_case_0()


# Generated at 2022-06-25 14:08:17.780000
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_vars_0 = HostVars(None, None, None)
    bool_0 = False
    ansible_undefined_1 = host_vars_0['host_vars']
    assert isinstance(ansible_undefined_1, AnsibleUndefined)


# Generated at 2022-06-25 14:08:29.115668
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    print('Test HostVars::__repr__')
    ansible_module_utils_common__collections_compat_mapping = Mapping()
    ansible_module_utils_common__collections_compat_Mapping = type(ansible_module_utils_common__collections_compat_mapping)
    ansible_template_templar = Templar(ansible_module_utils_common__collections_compat_mapping, ansible_module_utils_common__collections_compat_Mapping)
    ansible_template_AnsibleUndefined = type(ansible_template_templar)

# Generated at 2022-06-25 14:08:37.884821
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    manager = HostVars(None, None, None)
    manager._variable_manager = "dummy"
    manager._inventory = "dummy"
    manager._loader = "dummy"

    manager._variable_manager._loader = None
    manager._variable_manager._hostvars = None

    manager_state = {'_loader': "dummy", '_inventory': "dummy",
                     '_variable_manager': manager._variable_manager,
                     '__dict__': {'_loader': "dummy"}}
    manager.__setstate__(manager_state)

    assert manager._variable_manager._loader is manager._loader
    assert manager._variable_manager._hostvars is manager


# Generated at 2022-06-25 14:08:45.375890
# Unit test for method __setstate__ of class HostVars

# Generated at 2022-06-25 14:08:47.204079
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_vars_0 = HostVars(None, None, None)
    str_0 = host_vars_0.get("localhost")

# Generated at 2022-06-25 14:08:52.276244
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False
    host_vars_vars_0 = HostVarsVars(bool_0, bool_0)
    host_vars_0 = HostVars(host_vars_vars_0, host_vars_vars_0, host_vars_vars_0)
    for result in host_vars_0:
        pass


# Generated at 2022-06-25 14:08:55.488304
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = False
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    host_vars_0_repr_return_value = host_vars_0.__repr__()



# Generated at 2022-06-25 14:09:08.386539
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    # Setup test data
    bool_0 = False
    host_vars_vars_0 = HostVarsVars(bool_0, bool_0)
    # Exercise SUT
    for host_vars_vars_1 in host_vars_vars_0:
        pass


# Generated at 2022-06-25 14:09:11.125017
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False
    host_vars_vars_0 = HostVarsVars(bool_0, bool_0)
    for num in host_vars_vars_0:
        print(num)


# Generated at 2022-06-25 14:09:20.524942
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = False
    host_vars_vars_0 = HostVarsVars(bool_0, bool_0)
    str_0 = 'I'
    str_1 = ''
    str_2 = ' '
    host_vars_vars_1 = {str_0: bool_0, str_1: bool_0, str_2: bool_0}
    set_0 = {str_0, str_1, str_2}

    # Verify that the method iterates over items in the mapping object
    # passed to __init__ method
    assert set_0 == set(host_vars_vars_0)


# Generated at 2022-06-25 14:09:23.622335
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = False
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    host_vars_0.__repr__()


# Generated at 2022-06-25 14:09:25.684995
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    bool_0 = False
    host_vars_vars_0 = HostVarsVars(bool_0, bool_0)
    # TODO: implement your test here


# Generated at 2022-06-25 14:09:29.116149
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    bool_0 = False
    testcase_0_hostvars_0 = HostVars(bool_0, bool_0, bool_0)
    dict_0 = {'a': 1, 'b': 2}
    testcase_0_hostvars_0.__setstate__(dict_0)


# Generated at 2022-06-25 14:09:32.284050
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = False
    host_vars_vars_0 = HostVarsVars(bool_0, bool_0)
    try:
        host_vars_vars_0.__repr__()
    except:
        print('Exception: host_vars_vars_0.__repr__()')


# Generated at 2022-06-25 14:09:34.486021
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    raw_get_0 = HostVars.raw_get
    raw_get_0(False, False)


# Generated at 2022-06-25 14:09:37.785029
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    test_case_0()


# Generated at 2022-06-25 14:09:41.000236
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = False
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    str_0 = repr(host_vars_0)


# Generated at 2022-06-25 14:09:53.750964
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    try:
        hv = HostVars("inventory", "variable_manager", "loader")
    except:
        print("Exception thrown in HostVars")
        test_case_0()



# Generated at 2022-06-25 14:09:59.760490
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    variable_manager_0 = None #Unknown variable type at test_case_1
    variable_manager_1 = None #Unknown variable type at test_case_1
    inventory_0 = None #Unknown variable type at test_case_1
    inventory_1 = None #Unknown variable type at test_case_1
    loader_0 = None #Unknown variable type at test_case_1
    loader_1 = None #Unknown variable type at test_case_1
    hostvars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    hostvars_1 = HostVars(inventory_1, variable_manager_1, loader_1)
    assert hostvars_0._variable_manager_0 == hostvars_1._variable_manager_1



# Generated at 2022-06-25 14:10:05.946360
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # setup
    global bool_0
    inventory = test_case_0()
    variable_manager = test_case_0()
    loader = test_case_0()
    host_vars = HostVars(inventory, variable_manager, loader)
    state = test_case_0()

    # execution
    host_vars.__setstate__(state)

    # assertion
    assert bool_0
    # cleanup
    host_vars = None


# Generated at 2022-06-25 14:10:07.923219
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_case_0()

# Main function
if __name__ == '__main__':
    test_HostVars___getitem__()

# Generated at 2022-06-25 14:10:10.708925
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Create an instance of HostVars
    test_case_0()
    # We expect an error as we cannot create an instance of HostVars
    # instance of HostVars

if __name__ == "__main__":
    test_HostVars___repr__()

# Generated at 2022-06-25 14:10:15.551801
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # FIXME - maybe we should remove this method
    # if we can not use it for unit test
    print("HostVars[__getitem__]: ", end="")

    bool_1 = True
    bool_1 = False
    assert bool_1 == bool_0, "assertion 'bool_1 == bool_0' failed"
    print("pass")


# Generated at 2022-06-25 14:10:23.305490
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    """Test for __setstate__ of class HostVars"""
    # Define test data
    state_0 = dict()

    # Define expected cfg parameters
    expected_0 = dict()

    # Mock an instance of the class HostVars
    mock_instance = HostVars(inventory=None, variable_manager=None, loader=None)
    mock_instance.__setstate__(state=state_0)

    # Verify the expected configuration is as defined
    assert mock_instance._hostvars == expected_0

# Generated at 2022-06-25 14:10:28.043405
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False

    # First, create an instance of the class.
    obj = HostVars()

    # Now, call the __iter__ method of this class.
    obj.__iter__()

    # __iter__() of HostVars is not implemented yet.
    # So, if we get here, something is wrong.
    bool_0 = True

    assert not bool_0


# Generated at 2022-06-25 14:10:34.565783
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    assert method_return_value(
        HostVars.__getitem__,
        'HostVars',
        (
            'AnsibleUndefined',
            'str'
        ),
        (
            AnsibleUndefined,
            str
        ),
        (
            AnsibleUndefined(name='HostVars[\'AnsibleUndefined\']'),
            'Abcdefghi'
        )
    ) == (
        AnsibleUndefined(name='HostVars[\'AnsibleUndefined\']'),
        HostVarsVars(
            {
                'Abcdefghi': 'Abcdefghi'
            },
            None
        )
    )


# Generated at 2022-06-25 14:10:36.348667
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostVarsVars_0 = HostVarsVars(hash(obj0_0), loader_0)
    for int_0 in hostVarsVars_0:
        print(int_0)


# Generated at 2022-06-25 14:10:51.687485
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # create object
    HostVars_instance = HostVars()
    # get a result
    HostVars_result_obj = HostVars_instance.raw_get('hostname')
    # compare
    assert HostVars_result_obj == None


# Generated at 2022-06-25 14:10:52.235808
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    assert True

# Generated at 2022-06-25 14:10:53.313313
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_case_0()

test_HostVars___getitem__()

# Generated at 2022-06-25 14:10:55.340467
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    hostvars = HostVars()

    assert isinstance(hostvars.__iter__(), types.GeneratorType), "__iter__: Return is not a generator."

# Generated at 2022-06-25 14:10:56.437363
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    hv = HostVars()
    assert hv.__repr__() is not None

# Generated at 2022-06-25 14:10:59.598821
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    obj = HostVars(inventory = None, variable_manager = None, loader = None)
    state = dict()
    state['_inventory'] = None
    state['_loader'] = None
    state['_variable_manager'] = None

    obj.__setstate__(state)


# Generated at 2022-06-25 14:11:01.763794
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    """
    Test case to verify __repr__ method without asserting anything

    """
    # Arrange
    bool_0 = False

    # Act
    test_case_0()

    # Assert
    assert True == bool_0


# Generated at 2022-06-25 14:11:02.503816
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    test_case_0()


# Generated at 2022-06-25 14:11:03.447337
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert (test_case_0())


# Generated at 2022-06-25 14:11:08.392012
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    test_HostVarsVars = HostVarsVars(__loader, __loader)

    # Invoking a method
    result = test_HostVarsVars.test_case_0()
    assert None is result


# Generated at 2022-06-25 14:11:26.251318
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    host_vars_vars_0 = HostVarsVars(dict(), dict())
    host_vars_0 = HostVars(host_vars_vars_0, host_vars_vars_0, host_vars_vars_0)

    host_vars_0.__iter__()



# Generated at 2022-06-25 14:11:35.268155
# Unit test for method raw_get of class HostVars

# Generated at 2022-06-25 14:11:46.359500
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Templating engines are not needed so let's use simple
    # callables instead.
    def template(data, fail_on_undefined=False, static_vars=None):
        return data

    def find_file(data, ignore_missing=None):
        return None

    # Dummy variables.
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    set_0 = set()
    list_0 = []
    str_0 = ''
    bool_0 = False

    # Initialization of the loader.
    loader_0 = DictDataLoader({'': dict_0, '/a/b/c': dict_1, 'foo': dict_2})

    # Some basic variables.
    variables_0 = {'foo': 'bar', 'baz': 'qux'}

    #

# Generated at 2022-06-25 14:11:48.129819
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = 'pF/G*8@'
    str_1 = 'r$'
    test_case_0()


# Generated at 2022-06-25 14:11:53.570576
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = None
    variable_manager = None
    loader = None
    host_vars = HostVars(inventory, variable_manager, loader)
    # Test for method raw_get of class HostVars
    bool_0 = False
    bool_0 = True
    string_0 = 'bVJVrgF+r^r'
    host_name = 'An5$5=I&!-D'
    host_vars.raw_get(host_name)


# Generated at 2022-06-25 14:11:54.910704
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bool_0 = False
    host_vars_vars_0 = HostVarsVars(bool_0, bool_0)


# Generated at 2022-06-25 14:11:56.379114
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars()
    host_vars_0.__setstate__(None)

# Generated at 2022-06-25 14:11:59.606445
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    setstate_0 = host_vars_0.__setstate__(dict_0)
    assert setstate_0 == None


# Generated at 2022-06-25 14:12:04.164085
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False
    int_0 = 0
    set_0 = set()
    list_0 = list()
    dict_0 = dict()
    host_vars_0 = HostVars(list_0, dict_0, list_0)
    for host in host_vars_0:
        pass


# Generated at 2022-06-25 14:12:06.766101
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    assert True == host_vars_0.__repr__()


# Generated at 2022-06-25 14:12:39.948978
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bool_0 = False
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    inventory_0 = Inventory(loader=loader_0, variable_manager=variable_manager_0, host_list=None)
    # Possibly exception: TypeError
    try:
        host_vars_0 = HostVars(inventory=inventory_0, variable_manager=variable_manager_0, loader=loader_0)
        host_vars_0.raw_get(bool_0)
    except:
        import sys
        import traceback
        exc_info = sys.exc_info()
        traceback.print_exception(*exc_info)
        raise
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 14:12:40.986987
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Method __setstate__ can not be tested, as it is a class method.
    pass


# Generated at 2022-06-25 14:12:47.948941
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = False
    int_0 = 0
    float_0 = 0.0
    len_0 = len
    dict_0 = dict()
    dict_1 = dict()
    int_1 = 0
    str_0 = str()
    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = (int_1, str_0)
    tuple_3 = (tuple_2,)
    variable_manager_0 = VariableManager(dict_0, dict_1)
    loader_0 = DataLoader()
    inventory_0 = Inventory(loader_0, variable_manager_0, tuple_0)
    variable_manager_0._hostvars = HostVars(inventory_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 14:12:51.339414
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Get the method to be tested
    method = HostVarsVars.__iter__
    # Build the arguments to be passed to the method
    args = ()
    # Build the keyword arguments to be passed to the method
    kwargs = {}
    # Execute the method with the given arguments
    result = method(*args, **kwargs)


# Generated at 2022-06-25 14:12:58.537785
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Testing that the behavior is as expected
    bool_0 = False
    bool_1 = True
    int_0 = 0
    int_1 = 1

    # Testing that the behavior is as expected
    host_vars_vars_0 = HostVarsVars(bool_0, bool_0)

    # Testing that the behavior is as expected
    load_from_file_0 = load_from_file()

    host_vars_0 = HostVars(load_from_file_0, load_from_file_0, load_from_file_0)

    # Testing that the behavior is as expected
    set_variable_manager_0 = set_variable_manager(load_from_file_0)

    host_vars_0.set_variable_manager(set_variable_manager_0)

    # Testing that the

# Generated at 2022-06-25 14:13:01.149436
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    assert(host_vars_0.raw_get(bool_0) == AnsibleUndefined(name="hostvars['False']"))


# Generated at 2022-06-25 14:13:07.969766
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    loader_0 = MagicMock()
    inventory_0 = MagicMock()
    inventory_0.hosts = {}
    variable_manager_0 = MagicMock()
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    host_vars_vars__0 = MagicMock()
    host_vars_vars__0.__getitem__ = MagicMock(name='__getitem__')
    host_name_0 = 'host_name_0'
    host_vars_0[host_name_0] = host_vars_vars__0


# Generated at 2022-06-25 14:13:11.609390
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test with and without argument
    host_vars_0 = HostVars()
    host_vars_0.__iter__()


# Generated at 2022-06-25 14:13:16.709511
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_0 = "test_HostVars___getitem__"
    host_vars_0 = HostVars(None, None, None)
    host_vars_vars_0 = host_vars_0[host_0]
    # Validate that if host_name is not found in inventory, an
    # AnsibleUndefined value is returned
    if (str('AnsibleUndefined') not in str(host_vars_vars_0)):
        raise AssertionError()


# Generated at 2022-06-25 14:13:24.301036
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test the use of this method
    # Test expected exceptions
    # Test return type
    # Test normal behaviour
    
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    
    
    
    
    
    
    
    
    
    
    
    
    object_0.hosts = [object_4, object_2, object_3]
    object_1.hosts = [object_4, object_1, object_0]
    object_2.hosts = [object_4, object_1, object_3]
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-25 14:14:52.037356
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = False
    host_vars_vars_0 = HostVarsVars(bool_0, bool_0)
    for i in host_vars_vars_0:
        pass


# Generated at 2022-06-25 14:14:55.055300
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = None
    variable_manager = None
    loader = None
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    host_name = None
    host_vars_0.raw_get(host_name)



# Generated at 2022-06-25 14:15:03.945881
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = bool
    dict_0 = dict
    host_vars_0 = HostVars(bool_0, bool_0, bool_0)
    str_0 = "\x00\x00\x00\x00\x00\x00\x00\x00"
    str_1 = str_0
    bool_1 = bool_0
    str_2 = str_0
    int_0 = int
    str_3 = str_0
    int_1 = int_0
    str_4 = str_0
    bool_2 = bool_0
    str_5 = str_0
    int_2 = int_0
    str_6 = str_0
    bool_3 = bool_0
    str_7 = str_0
    int_3 = int_0

# Generated at 2022-06-25 14:15:11.304046
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import random

    # Setup test data
    random_int_0 = random.randint(0, 100)
    random_list_0 = list()
    random_list_1 = list()
    for random_index_0 in range(0, random_int_0):
        random_dict_0 = dict()
        random_dict_0['key'] = random_index_0
        random_dict_0['value'] = random_index_0
        random_list_1.append(random_dict_0)
    random_list_0.append(random_list_1)
    random_dict_1 = dict()
    random_dict_1['key'] = random_int_0
    random_dict_1['value'] = random_int_0
    random_list_0.append(random_dict_1)
   

# Generated at 2022-06-25 14:15:19.265358
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    bool_0 = False
    dict_0 = dict()
    dict_0['skip_tags'] = 'filled'
    dict_0['role_names'] = 'filled'
    dict_0['my_roles'] = 'filled'
    dict_0['omit'] = 'filled'
    dict_0['playbook_dir'] = 'filled'
    dict_0['play_hosts_all'] = 'filled'
    dict_0['play_hosts'] = 'filled'
    dict_0['groups'] = 'filled'
    dict_0['hostvars'] = 'filled'
    dict_0['group_names'] = 'filled'
    dict_0['play_hosts_count'] = 'filled'
    dict_0['play_hosts_reversed'] = 'filled'

# Generated at 2022-06-25 14:15:21.823376
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # unit test for __iter__ of HostVars
    foo = None
    ret = HostVars.__iter__(foo)
    assert(ret == None)
