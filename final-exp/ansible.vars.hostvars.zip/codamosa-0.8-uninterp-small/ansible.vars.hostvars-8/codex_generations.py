

# Generated at 2022-06-25 14:05:33.793411
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    int_0 = 10
    tuple_0 = ()
    str_0 = 'z'
    str_1 = '5d0x'
    host_vars_vars_0 = HostVarsVars(tuple_0, str_0)
    host_vars_0 = HostVars(int_0, host_vars_vars_0, str_1)
    host_vars_0.set_nonpersistent_facts(int_0, tuple_0)
    assert host_vars_0._inventory == 10
    assert host_vars_0._loader == '5d0x'
    assert host_vars_0._variable_manager._loader == '5d0x'
    assert host_vars_0._variable_manager._hostvars == host_vars_0
    assert host_

# Generated at 2022-06-25 14:05:39.211314
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    tuple_0 = ()
    str_0 = 'B?78!_'
    host_vars_vars_0 = HostVarsVars(tuple_0, str_0)
    assert host_vars_vars_0._vars == tuple_0
    assert host_vars_vars_0._loader == str_0


# Generated at 2022-06-25 14:05:45.590488
# Unit test for method __deepcopy__ of class HostVars
def test_HostVars___deepcopy__():
    # Imports
    from copy import deepcopy
    from ansible.vars import VariableManager

    tuple_0 = ()
    variable_manager_0 = VariableManager()
    variable_manager_0._loader = variable_manager_0
    variable_manager_0._hostvars = variable_manager_0
    str_0 = 'QEe&vgn\now6ZB'
    host_vars_0 = HostVars(tuple_0, variable_manager_0, str_0)
    host_vars_0 = deepcopy(host_vars_0)


# Generated at 2022-06-25 14:05:50.573583
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    tuple_0 = ()
    str_0 = 'ojH[a\x0bF\x00M^\x7f'
    host_vars_vars_0 = HostVarsVars(tuple_0, str_0)
    tuple_1 = host_vars_vars_0.__getitem__(str_0)



# Generated at 2022-06-25 14:05:55.551275
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    tuple_0 = ()
    str_0 = 'h0E0tQNkM'
    host_vars_0 = HostVars(tuple_0, tuple_0, str_0)
    for _ in host_vars_0:
        pass


# Generated at 2022-06-25 14:06:00.244094
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    tuple_0 = ()
    str_0 = '!_\n/'
    host_vars_vars_0 = HostVarsVars(tuple_0, str_0)
    with pytest.raises(KeyError):
        host_vars_vars_0.__getitem__('!_\n/')


# Generated at 2022-06-25 14:06:09.947754
# Unit test for method __setstate__ of class HostVars

# Generated at 2022-06-25 14:06:21.185365
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    tuple_0 = (1, 'jQ@WF')
    dict_0 = dict(__getitem__=tuple_0, __contains__=tuple_0, __iter__=tuple_0, __len__=tuple_0)
    str_0 = 'K*DyLb'
    dict_1 = dict(__getitem__=str_0, __contains__=str_0, __iter__=str_0, __len__=str_0)
    dict_2 = dict(__getstate__=dict_1, __setstate__=dict_0)
    dict_3 = dict(__getstate__=dict_0, __setstate__=dict_1)
    # Create a new instance of class HostVars using the given dicts

# Generated at 2022-06-25 14:06:31.137199
# Unit test for method set_nonpersistent_facts of class HostVars
def test_HostVars_set_nonpersistent_facts():
    # Return value of method
    tuple_0 = ()
    str_0 = '<'
    str_1 = '>'
    str_2 = '%sQEe&vgn\now6ZB%s' % (str_0, str_1,)
    list_0 = [str_2]
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['QEe&vgn\now6ZB'] = list_0
    dict_1['host_name'] = dict_2
    dict_3 = dict()
    dict_3['hostvars'] = dict_1
    dict_0['vars'] = dict_3
    host_vars_0 = HostVars(tuple_0, tuple_0, str_0)
    host

# Generated at 2022-06-25 14:06:39.556599
# Unit test for method set_inventory of class HostVars

# Generated at 2022-06-25 14:06:51.420871
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    state_0 = dict()
    # Invoke the method
    HostVars.__setstate__(state_0)


# Generated at 2022-06-25 14:06:54.660465
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hostvars = HostVars(var_0, var_0, var_0)
    host_name = (str_0)
    assert hostvars.raw_get(host_name) == None


# Generated at 2022-06-25 14:06:56.086144
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert True



# Generated at 2022-06-25 14:06:58.307319
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    obj = HostVars(var_0, str_0)
    dict = obj.__repr__()
    assert dict is not None

# Generated at 2022-06-25 14:07:01.134057
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    var_0 = ()
    str_0 = 'QEe&vgn\now6ZB'

    var_1 = HostVarsVars(var_0, str_0)

    var_2 = var_1.__iter__()
    assert isinstance(var_2, type(map(None, None))) == True
    assert len(list(var_2)) == 0


# Generated at 2022-06-25 14:07:04.188898
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    data_0 = HostVars(var_0, var_0, var_0)
    data_0 = data_0.__repr__()
    data_1 = len(str_0)
    data_2 = str_0[0:data_1]
    assert data_0 != data_1


# Generated at 2022-06-25 14:07:16.339177
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # This tests the case where host_name == 'localhost'
    # Initializing argument 'inventory'
    inventory_arg_0 = mock_Inventory()
    # Initializing argument 'variable_manager'
    variable_manager_arg_0 = mock_VariableManager()
    # Initializing argument 'loader'
    loader_arg_0 = mock_DataLoader()
    # Calling constructor with arguments
    test_obj_0 = HostVars(inventory=inventory_arg_0, variable_manager=variable_manager_arg_0, loader=loader_arg_0)
    # Getting the type of 'test_obj_0' (line 73)
    test_obj_0_type = type(test_obj_0)
    assert test_obj_0_type == HostVars
    # Getting the type of 'test_obj_0' (line 73)

# Generated at 2022-06-25 14:07:25.279976
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = ()
    str_0 = 'QEe&vgn\now6ZB'
    var_1 = ()
    var_1 = ()
    var_2 = ()
    var_2 = ()
    var_3 = ()
    var_3 = ()
    var_4 = ()
    var_4 = ()
    var_5 = ()
    var_5 = ()
    var_6 = ()
    var_6 = ()
    var_7 = ()
    var_7 = ()
    var_8 = ()
    var_8 = ()
    var_9 = ()
    var_9 = ()
    var_10 = ()
    var_10 = ()
    var_11 = ()
    var_11 = ()
    for i in range(10):
        var_19 = ()
        var_

# Generated at 2022-06-25 14:07:29.270618
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import random
    import string

    for _ in range(0, 10):
        tmp = HostVarsVars(var_0, str_0)
        assert tmp[random.choice(string.printable)] is not None

# Generated at 2022-06-25 14:07:32.369640
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = ()
    str_0 = 'QEe&vgn\now6ZB'
    assert test_case_0() == 'QEe&vgn\now6ZB'

# Generated at 2022-06-25 14:07:44.253110
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    bytes_0 = b'\x0b\xf2'
    str_0 = '\x0c\r'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = '\t/n'

# Generated at 2022-06-25 14:07:52.588217
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = 'Y\tE5\tb.w,\x0b8L\t\x0bYo3\t\x0c\x0c\x0c'
    assert host_vars_0.__getitem__(str_1) == b'\x0b\xf2'


# Generated at 2022-06-25 14:08:00.350760
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    def test_HostVarsVars__iter__(self, var):
        return next(self._vars, var)

    test_HostVarsVars___iter__.__dict__.__setitem__('stypy_localization', UiLocalization(('cases', 'HostVarsVars.__iter__', 'line_1', 'HostVars'), {'var': UiLocalization({'cases': 'HostVarsVars._vars', 'module': 'HostVars'})}, 'HostVarsVars.__iter__'))


# Generated at 2022-06-25 14:08:09.196719
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    int_0 = 0x000000006677e35a
    dict_0 = {}; dict_0[str_0] = int_0
    host_vars_0.set_host_facts('Y\xc1D)', dict_0)
    dict_1 = dict_0
    dict_1.update(dict_0)
    dict_1.update(dict_0)
    dict_2 = dict_1
    dict_2.update(dict_1)
    dict_2.update(dict_1)
    dict_3

# Generated at 2022-06-25 14:08:16.754798
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = '#\x04\x07\x11\x0e\x0f'
    result = host_vars_0.raw_get(str_1)
    assert result == b'\x12\x11\x0b\x15\t'


# Generated at 2022-06-25 14:08:19.946397
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    assert str_0 == host_vars_0['a-9?a\x0c\rd>`6XB\t/nl']

# Generated at 2022-06-25 14:08:28.415210
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    int_0 = 4
    host_vars_0 = HostVars(bytes_0, str_0, int_0)
    int_0 = 0
    int_1 = 0
    for host in host_vars_0:
        int_0 += 1
        int_1 += 1
    assert int_0 == int_1


# Generated at 2022-06-25 14:08:38.002518
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    str_1 = '%c'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    host_name_0 = str_1 % (len('T`+z{0Vh|>r') - len('\x0c\n'))
    var_0 = host_vars_0.raw_get(host_name_0)
    if (var_0 is AnsibleUndefined):
        raise AssertionError
    bytes_1 = b'\xd3'
    str_2 = ''
    int_0 = -20443

# Generated at 2022-06-25 14:08:42.328183
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = 't~'
    var_0 = host_vars_0.raw_get(str_1)
    assert var_0 is AnsibleUndefined()


# Generated at 2022-06-25 14:08:51.222282
# Unit test for method __getitem__ of class HostVars

# Generated at 2022-06-25 14:09:05.374053
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)

    host_vars_0___iter___0 = host_vars_0.__iter__()

    # Test for __iter__ implementation of class HostVars
    assert isinstance(host_vars_0___iter___0, list)


# Generated at 2022-06-25 14:09:10.951709
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\x0b\xf2'
    str_1 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_1, bytes_0)
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    ansible_undefined_0 = host_vars_0.raw_get(str_0)
    # assert not isinstance(ansible_undefined_0, AnsibleUndefined)


# Generated at 2022-06-25 14:09:11.912328
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    assert False


# Generated at 2022-06-25 14:09:23.000031
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    str_0 = '\x00\x00'
    str_1 = '\\r\r'
    str_2 = '\x00\x00'
    str_3 = '0c%\x00\x00'
    str_4 = '0c%\x00\x00'
    str_5 = '0c%\x00\x00'
    str_6 = '0c%\x00\x00'
    str_7 = '0c%\x00\x00'
    str_8 = '0c%\x00\x00'
    str_9 = '0c%\x00\x00'
    str_10 = '0c%\x00\x00'
    str_11 = '0c%\x00\x00'

# Generated at 2022-06-25 14:09:26.459944
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # host_vars_0 is an instance of HostVars
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)

    # __iter__ of HostVars
    host_vars_0.__iter__()


# Generated at 2022-06-25 14:09:33.400597
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_1 = host_vars_0.__getitem__(str_1)
    bytes_1 = b'\x0b\xf2'
    bytes_2 = b'\x0b\xf2'
    assert (host_vars_1 == bytes_1)
    assert (host_vars_0 == bytes_2)


# Generated at 2022-06-25 14:09:38.999802
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x0b\xfc'
    str_0 = 'hq'
    bytes_1 = b'\x0b\xfb'
    host_vars_1 = HostVars(bytes_0, str_0, bytes_1)
    host_vars_1.__iter__()

# Generated at 2022-06-25 14:09:44.052444
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_vars_0 = HostVarsVars(bytes_0, str_0)
    int_0 = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:09:46.194069
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # TODO: add test for this method
    assert True == True, "Test for method __setstate__ of class HostVars not implemented"


# Generated at 2022-06-25 14:09:52.179634
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)

    str_1 = 's=b2\\\t\r\t\n\t\r9l\x0b\x0c\x0e\n'
    str_1 = host_vars_0.raw_get(str_1)



# Generated at 2022-06-25 14:10:10.236091
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x7f\x15'

# Generated at 2022-06-25 14:10:20.712522
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    bytes_0 = b'=M5'
    str_0 = 'wda`E^\x0b\x18z6\x15\x0e\x0c\x17\n\x0f\x17\x18\x1a\x1d\x15\x01'

# Generated at 2022-06-25 14:10:25.894695
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    host_vars_0.__setstate__(bytes_0)


# Generated at 2022-06-25 14:10:31.167215
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Setup test case
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)

    # Call the method
    # The returned value should be a generator
    result = host_vars_0.__iter__()
    assert isinstance(result, types.GeneratorType)



# Generated at 2022-06-25 14:10:34.607836
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = '@y5'
    host_vars_0.raw_get(str_1)


# Generated at 2022-06-25 14:10:40.306258
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    for t in range(20):
        # Test with numeric type
        assert isinstance(HostVars.__getitem__(32), (int, float, complex)), "HostVars.__getitem__(32) is not an instance of (int, float, complex)"
        # Test with string type
        assert isinstance(HostVars.__getitem__('^]\x03\x98\xc7\x17\xa1'), str), "HostVars.__getitem__('^]\x03\x98\xc7\x17\xa1') is not an instance of str"


# Generated at 2022-06-25 14:10:46.961271
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_vars_0 = HostVarsVars(bytes_0, str_0)
    for val in host_vars_vars_0:
        # verify that the values are correct
        print(val)


# Generated at 2022-06-25 14:10:51.524508
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    for i in host_vars_0:
        assert i


# Generated at 2022-06-25 14:10:59.129180
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = '\x00\r\x00"\x00\x00\x00\x00\x00\x00\x00'
    str_2 = 'b'
    str_3 = 'b'
    host_vars_0.set_inventory(str_2)
    str_4 = 'localhost'
    var_0 = host_vars_0.raw_get(str_4)

# Generated at 2022-06-25 14:11:01.943750
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'!\x12'
    str_0 = 'rJ'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    assert isinstance(host_vars_0.__iter__(), type(iter([])))


# Generated at 2022-06-25 14:11:46.905774
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x0b\xf2'
    str_0 = '#'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = 'Y"{\\o0'
    host_vars_1 = host_vars_0
    assert host_vars_0[str_1] == host_vars_1[str_1]


# Generated at 2022-06-25 14:11:52.439327
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    try:
        host_vars_0.__repr__()
    except NameError as exc_0:
        assert str(exc_0) == 'HostVars'


# Generated at 2022-06-25 14:11:59.247901
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    arg_0 = HostVars.__new__(HostVars)
    arg_0.set_variable_manager = MagicMock(name='set_variable_manager')
    arg_0.set_variable_manager.return_value = None
    arg_1 = 'b'
    arg_0.set_inventory = MagicMock(name='set_inventory')
    arg_0.set_inventory.return_value = None
    arg_2 = 'b'
    test_obj = HostVars(arg_0, arg_1, arg_2)
    host_name = 'b'

# Generated at 2022-06-25 14:12:05.853728
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables_0 = {'e': 'x', 'c': '', 'a': 'b', 'b': 'd', 'd': 'c'}
    test0_0 = HostVarsVars(variables_0, bytes_0)
    str_0 = test0_0['e']
    str_1 = test0_0['b']
    str_2 = test0_0['d']
    str_3 = test0_0['c']
    str_4 = test0_0['a']


# Generated at 2022-06-25 14:12:14.536007
# Unit test for method __iter__ of class HostVars

# Generated at 2022-06-25 14:12:22.454633
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'd\xa6\x82c\x97\x04\x90\xdc\xbc\xfe\xa3%\xc3\x8b\xaa\x9e\x0c\xc8\xbb\x04\xd7\x94\x19\x06\xa2\xbe\xbe\xf8\xee'

# Generated at 2022-06-25 14:12:28.039476
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x07\x15\x19\xff\xe3\x9b'
    str_0 = 'aG*s\x11'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    bytes_1 = b'\x1e\x9f\xe1^\xb7\x0e\xcb'
    str_1 = '\x1b\x1d'
    int_0 = host_vars_0.__iter__(bytes_1, str_1)



# Generated at 2022-06-25 14:12:32.282376
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = '0d6?'
    var_0 = host_vars_0.raw_get(str_1)

# Generated at 2022-06-25 14:12:35.785804
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'

    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = 'z'

    print(host_vars_0[str_1])


# Generated at 2022-06-25 14:12:39.464071
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    inventory_0 = Mock(**{'get_host.return_value': None})
    variable_manager_0 = Mock()
    loader_0 = Mock()
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    host_vars_0.set_variable_manager(variable_manager_0)
    host_name_0 = 'fn8>47R1'
    host_vars_0.__getitem__(host_name_0)

# Generated at 2022-06-25 14:13:35.314050
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    assert repr(host_vars_0) == repr(dict())


# Generated at 2022-06-25 14:13:43.506288
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = '9t*'
    dict_10 = dict()
    dict_10['x'] = 'x'
    dict_10['y'] = 'y'
    dict_10['z'] = 'z'
    dict_10['0'] = '0'
    dict_10['1'] = '1'
    dict_10['2'] = '2'
    dict_10['3'] = '3'
    dict_10['4'] = '4'
    dict_10['5'] = '5'
    dict_

# Generated at 2022-06-25 14:13:51.154012
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'!\xfb\xd5\x94\xa5y\x1b\xab\x18.\x0e\xb8'
    str_0 = ':S\x03\xc8TV\xad*\x9f\x97\xe2\x8d\xca\x89\xe3\xc3\xd0\x9a'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    bytes_0 = b'\x9a]j\x8d\x81\x1e\xcf\xe3\xe8\x9e\x9a'

# Generated at 2022-06-25 14:13:56.057455
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\xf2\x0c'
    str_0 = '\xfe\xee\xaf\x0b\x0b\x11\x8f'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    exception = None
    try:
        host_vars_0.__repr__()
    except Exception as exception:
        pass
    assert exception is not None


# Generated at 2022-06-25 14:14:02.874407
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    for host_name_0 in (b'\x0b\xf2', str_0, bytes_0, 'a-9?a\x0c\rd>`6XB\t/nl', ):
        host_vars_0._find_host(host_name_0)
        host_vars_0[host_name_0]


# Generated at 2022-06-25 14:14:07.917718
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    iterator = host_vars_0.__iter__()
    assert iterator.__class__ is iter


# Generated at 2022-06-25 14:14:13.866755
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_1 = b'\x10\x06K\x14\x03'
    str_1 = '`\tf2\x0c\x1d<\x18'
    host_vars_1 = HostVars(bytes_1, str_1, bytes_1)
    str_2 = '\x7f\x1bZV\x1c\xf1\t\x18'
    result = host_vars_1.__getitem__(str_2)


# Generated at 2022-06-25 14:14:22.730728
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    bytes_0 = b'V\xeb{\x11`\xc3\x93\xa7'
    str_0 = 'Y)\t\x93\x1dF\xce\xb0'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    str_1 = '8\x0b\x0b\xa6\xa1\x9a\xeb\xac\xbf\xef\xc8'
    bytes_1 = b'\xce\xe2\x9d\xb2\x0c\x93\x1a\x1b\xf7\x9e\xe5\xd9\\\x83\x0f\xb3\x7f\x1d\x0f\xb5'

# Generated at 2022-06-25 14:14:25.522159
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
    # No output



# Generated at 2022-06-25 14:14:28.164700
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bytes_0 = b'\x0b\xf2'
    str_0 = 'a-9?a\x0c\rd>`6XB\t/nl'
    host_vars_0 = HostVars(bytes_0, str_0, bytes_0)
