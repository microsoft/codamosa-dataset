

# Generated at 2022-06-25 14:05:35.751128
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Setup
    host_vars_0 = HostVars(None, None, None)

    # Testing
    host_vars_0.__repr__()

    # Teardown


# Generated at 2022-06-25 14:05:40.740811
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    str_0 = "!p"
    result = host_vars_0.raw_get(str_0)
    assert (result._name == "hostvars['!p']")


# Generated at 2022-06-25 14:05:48.152290
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    # From Ansible docs:
    #
    # Returns a copy of the current vars in the inventory.
    # This is a safer version of vars() that returns an object
    # that cannot be modified to prevent changes to the underlying
    # variables.
    #

    # TEST CASE: HostVars object is constucted with empty variables' set.
    #
    # Input parameters:
    #     set_0 -- [in] variables' set.
    #
    # Expected result:
    #     Should return empty dict.
    #

    set_0 = set()
    host_vars_0 = HostVars(set_0, set_0, set_0)
    assert not host_vars_0


    # TEST CASE: HostVars object is constucted with empty variables' set.
    #
    # Input

# Generated at 2022-06-25 14:05:56.019317
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # This test case assumes that the following variables are defined
    # (most probably in test_inventory.py):
    #   inv_obj
    #   vm_obj
    hv = HostVars(inv_obj, vm_obj, vm_obj.loader)

    host_0 = Host('host_0')
    variables = vm_obj.get_vars(host=host_0, include_hostvars=False)

    # The following line should not fail
    hv.raw_get(host_0._name)

# Generated at 2022-06-25 14:06:06.064036
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    def check_find_host(host_name_0, find_host_ret_0):
        class Mock_find_host:
            def __init__(self, find_host_ret_0):
                self.find_host_ret_0 = find_host_ret_0
                self.count = 0

            def __call__(self, host_name_0, *args, **kwargs):
                if self.count < self.find_host_ret_0.__len__():
                    ret = self.find_host_ret_0[self.count]
                    self.count += 1
                    return ret
                assert False

        mock_find_host_0 = Mock_find_host(find_host_ret_0)


# Generated at 2022-06-25 14:06:14.076706
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = None
    variable_manager = None
    loader = None
    set_0 = None
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    tests = [
        {
            'host_name': 'nodexyz',
            'expected': AnsibleUndefined(name="hostvars['nodexyz']")
        },
        {
            'host_name': 'localhost',
            'expected': AnsibleUndefined(name="hostvars['localhost']")
        },
    ]
    for test in tests:
        host_name = test['host_name']
        expected = test['expected']
        actual = host_vars_0.raw_get(host_name)
        assert expected == actual


# Generated at 2022-06-25 14:06:19.029045
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = None
    variable_manager = None
    loader = None
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    host_name_0 = None
    assert host_vars_0.raw_get(host_name_0) is None


# Generated at 2022-06-25 14:06:21.031173
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hv = HostVars(set_0, set_0, set_0)
    hv.raw_get(str_0)


# Generated at 2022-06-25 14:06:22.110237
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    pass


# Generated at 2022-06-25 14:06:25.706384
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    string_0 = host_vars_0.__getitem__(string_0)


# Generated at 2022-06-25 14:06:36.896733
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    inventory_0 = __new__(MagicMock(spec=InventoryManager))
    variable_manager_0 = __new__(MagicMock(spec=VariableManager))
    loader_0 = __new__(MagicMock(spec=DataLoader))
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    host_name_0 = __new__(MagicMock(spec=unicode))
    host_name_0.__repr__.return_value = 'foo'
    variable_manager_0.get_vars.return_value = {}
    result_0 = host_vars_0.__getitem__(host_name_0)
    assert result_0 == {}


# Generated at 2022-06-25 14:06:39.284411
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_vars_0.__iter__();


# Generated at 2022-06-25 14:06:47.418730
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    try:
        set_0 = {'inventory_file': '/ansible/playbooks/inventory', 'inventory_dir': '/ansible/playbooks', 'groups': {'group_names': ['gce_us-central1-a', 'gce_us-central1-f', 'gce_us-central1-b', 'gce_us-central1-c', 'gce_us-central1-d']}, 'playbook_dir': '/ansible/playbooks', 'role_names': [], 'ungrouped': {'hosts': ['127.0.0.1'], 'vars': {}}}
        host_vars_0 = HostVars(set_0, set_0, set_0)
        str_0 = host_vars_0.__repr__()
    except:
        pass
   

# Generated at 2022-06-25 14:06:55.193780
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    str_0 = None
    result_bool = None
    try:
        result_bool = (host_vars_0.raw_get(str_0) is AnsibleUndefined)
    except NameError as err:
        result_bool = False

    assert (result_bool)


# Generated at 2022-06-25 14:06:58.913121
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_name_0 = None
    host_vars_0.raw_get(host_name_0)


# Generated at 2022-06-25 14:07:02.399056
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    #Example 1
    set_0 = None
    host_vars_vars_0 = HostVarsVars(set_0, set_0)
    assert(host_vars_vars_0[0] == AnsibleUndefined(name="hostvars['%s']"%0))


# Generated at 2022-06-25 14:07:05.113838
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    vars_cache_0 = None
    inventory_0 = None
    variable_manager_0 = None
    loader_0 = None
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    r = repr(host_vars_0)
    assert r == '{}'



# Generated at 2022-06-25 14:07:15.834025
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = None
    dict_0 = dict()
    dict_0['hostvars'] = dict()
    str_0 = 'hostvars[\'127.0.0.1\']'
    dict_0['hostvars']['127.0.0.1'] = AnsibleUndefined(set_0, str_0)
    host_vars_0 = HostVars(dict_0, dict_0, dict_0)
    str_1 = '127.0.0.1'
    dict_1 = host_vars_0.raw_get(str_1)
    assert not isinstance(dict_1, AnsibleUndefined)


# Generated at 2022-06-25 14:07:21.692206
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test with no exception raised
    set_0 = set(['test_string_0', 'test_string_1', 'test_string_2',
                 'test_string_3', 'test_string_4'])
    host_vars_0 = HostVars(set_0, set_0, set_0)
    for x in host_vars_0:
        pass


# Generated at 2022-06-25 14:07:24.542701
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # set up object
    o = HostVars(None, None, None)
    # call the method
    ret = o.raw_get('foo')
    # should just return the string "foo"
    if not ret == 'foo':
        raise Exception()



# Generated at 2022-06-25 14:07:33.601624
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    set_0 = None
    host_vars_vars_0 = HostVarsVars(set_0, set_0)
    # Check return type
    assert isinstance(host_vars_vars_0.__getitem__(set_0), object)


# Generated at 2022-06-25 14:07:40.732584
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    try:
        inventory_0 = None
        variable_manager_0 = None
        host_vars_0 = HostVars(inventory_0, variable_manager_0, None)
        host_name_0 = None
        hostvars_0_0 = host_vars_0[host_name_0]
        assert False
    except Exception as e:
        str_0 = str(e)
        assert str_0 == "AnsibleUndefined: One or more undefined variables: 'hostvars['']'", str_0


# Generated at 2022-06-25 14:07:41.994133
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    for host in self._inventory.hosts:
        yield host



# Generated at 2022-06-25 14:07:45.465529
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    temp_list = list(host_vars_0)
    temp_bool = isinstance(temp_list, list)
    assert temp_bool


# Generated at 2022-06-25 14:07:49.236403
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    str_0 = host_vars_0.__getitem__('localhost')


# Generated at 2022-06-25 14:07:52.465501
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_name_0 = None
    host_vars_0.raw_get(host_name_0)

# Generated at 2022-06-25 14:07:57.719274
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    str_0 = None
    # The next line causes an exception.
    try:
        host_vars_0.raw_get(str_0)
    except:
        pass


# Generated at 2022-06-25 14:08:04.334613
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_vars_0 = HostVars(None, None, None)
    str_0 = host_vars_0.raw_get(str_1)
    boolean_0 = isinstance(str_0, AnsibleUndefined)
    assert boolean_0

    host_vars_vars_1 = HostVarsVars(host_vars_vars_0, host_vars_vars_0)
    boolean_0 = isinstance(host_vars_vars_1, Mapping)
    assert boolean_0


# Generated at 2022-06-25 14:08:07.321681
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    (set_1, result_2) = host_vars_0.__iter__()


# Generated at 2022-06-25 14:08:12.427787
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # host_vars_0 = HostVars(set_0, set_0, set_0)
    host_vars_0 = HostVars(set(), set(), set())
    assert isinstance(host_vars_0['set_1'], AnsibleUndefined)


# Generated at 2022-06-25 14:08:25.425469
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_name_0 = None
    var_0 = host_vars_0.raw_get(host_name_0)


# Generated at 2022-06-25 14:08:28.984331
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_name = ''
    precomputed_0 = host_vars_0.raw_get(host_name)
    print(precomputed_0)


if __name__ == '__main__':
    test_case_0()
    test_HostVars_raw_get()

# Generated at 2022-06-25 14:08:34.280581
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_vars_0.__repr__()
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_vars_0.__repr__()


# Generated at 2022-06-25 14:08:35.539819
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_vars_vars_0 = HostVars({}, '', '')
    host_vars_vars_0.get()


# Generated at 2022-06-25 14:08:39.579144
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_name_0 = None
    var_0 = host_vars_0.raw_get(host_name_0)
    var_1 = host_vars_0[host_name_0]


# Generated at 2022-06-25 14:08:46.055473
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    m = None
    variable_manager_0 = VariableManager(loader=m, inventory=m)
    loader_0 = DataLoader()
    inventory_0 = Inventory(loader=loader_0, variable_manager=variable_manager_0, host_list=[])
    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    host_0 = Host('localhost')
    inventory_0._hosts_cache[host_0.name] = host_0
    variable_manager_0.set_nonpersistent_facts(host_0, {})
    variable_manager_0._nonpersistent_fact_cache[host_0.name] = {}
    variable_manager_0.set_host_variable(host_0, 'foo', 'bar')
    variable_manager_0._fact_

# Generated at 2022-06-25 14:08:48.227027
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_vars_0 = HostVars(set_0, set_0, set_0)
    str_0 = host_vars_0.__getitem__(str_0)
    assert str_0.name == "hostvars['localhost']"


# Generated at 2022-06-25 14:08:51.793350
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    str_0 = host_vars_0.__getitem__('localhost')
    assert str_0 is not None


# Generated at 2022-06-25 14:09:02.409522
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    host_0 = Host('localhost')
    set_0 = {'arbitrary': 'test'}
    HostVars.set_host_variable(host_0, 'foo', set_0)
    inventory_0 = {'localhost': host_0}
    set_1 = 'arbitrary'
    set_2 = str
    loader_0 = None
    from ansible.vars.manager import VariableManager
    variable_manager_0 = VariableManager(host_vars=None, loader=loader_0, inventory=inventory_0)
    HostVars.set_variable_manager(host_0, variable_manager_0)
    host_vars_

# Generated at 2022-06-25 14:09:10.514660
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Test for correct type of param set_0
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    # Test for correct type of param set_1
    set_1 = None
    host_vars_0 = HostVars(set_1, set_1, set_1)
    # Test for correct type of param set_2
    set_2 = None
    host_vars_0 = HostVars(set_2, set_2, set_2)
    # Test for correct type of param set_3
    set_3 = None
    host_vars_0 = HostVars(set_3, set_3, set_3)
    # Test for correct type of param set_4
    set_4 = None
    host_v

# Generated at 2022-06-25 14:09:52.000718
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    set_0 = {}
    set_1 = None
    host_vars_vars_0 = HostVarsVars(set_0, set_1)
    int_0 = len(host_vars_vars_0)
    for x_1 in host_vars_vars_0:
        pass


# Generated at 2022-06-25 14:09:55.319423
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Constructs an instance of class HostVars
    host_vars_0 = HostVars(set_0, set_0, set_0)

    # Constructs an instance of class HostVars for the argument host_vars_0.raw_get
    host_vars_0.raw_get(set_0)


# Generated at 2022-06-25 14:10:00.867019
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = set()
    item_0 = set_0
    item_1 = set_0
    item_2 = set_0
    dict_0 = dict(a=item_0, b=item_1, c=item_2)
    host_vars_vars_0 = HostVarsVars(dict_0, set_0)
    var_0 = host_vars_vars_0.raw_get(item_0)


# Generated at 2022-06-25 14:10:08.491157
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    set_1 = {}
    host_vars_0.__setstate__(set_1)
    set_2 = {
        '_variable_manager': '''
            ''',
        '_loader': '''
            ''',
        '_inventory': {
            0: '''
                ''',
            1: '''
                ''',
        },
    }
    host_vars_0.__setstate__(set_2)


# Generated at 2022-06-25 14:10:09.745866
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    s = set()
    HostVars.__setstate__(s, s)


# Generated at 2022-06-25 14:10:11.772000
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    my_host = None
    hv = HostVars(my_host, my_host, my_host)
    d = dict()
    hv.__setstate__(d)
    assert hv._inventory == my_host


# Generated at 2022-06-25 14:10:16.103768
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    str_0 = 'test_value_0'
    dict_0 = {'test_key_0': str_0}
    host_vars_0.__setstate__(dict_0)


# Generated at 2022-06-25 14:10:21.028383
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_name_0 = None
    assert isinstance(host_vars_0.raw_get(host_name_0), AnsibleUndefined) == True


# Generated at 2022-06-25 14:10:27.223915
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    set_0 = None
    host_vars_vars_0 = HostVarsVars(set_0, set_0)
    host_vars_0 = HostVars(set_0, set_0, set_0)
    # Test exception raise of not implemented method
    with pytest.raises(NotImplementedError) as excinfo:
        host_vars_0.__repr__()
    assert 'Not implemented' in str(excinfo.value)

# Generated at 2022-06-25 14:10:29.102213
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    repr_0 = HostVars.__repr__()
    assert isinstance(repr_0, str)


# Generated at 2022-06-25 14:11:27.633860
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    # Setup test vars
    host_vars_mock = HostVars(None, None, None)
    host_name_mock = 'some name'
    expected = None
    obj = host_vars_mock.raw_get(host_name_mock)

    assert obj == expected


# Generated at 2022-06-25 14:11:30.835891
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    assert isinstance(host_vars_0.__iter__(), object)


# Generated at 2022-06-25 14:11:36.251470
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # build parameters
    ansible_playbook_python = None

    # initialize the object
    host_vars_0 = HostVars(ansible_playbook_python, ansible_playbook_python, ansible_playbook_python)

    # build input parameters
    host_name_0 = None

    # call the method
    result = host_vars_0.__getitem__(host_name_0)

    # verify the result
    assert(result == ansible_playbook_python)


# Generated at 2022-06-25 14:11:40.040741
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    inventory = None
    variable_manager = None
    loader = None
    host_vars = HostVars(
        inventory, variable_manager, loader)
    # Ensures the correctness of the return value
    assert isinstance(host_vars.__iter__(), type(iter([])))


# Generated at 2022-06-25 14:11:47.469183
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Test with any valid inputs
    # Test with any valid inputs
    # Test when host_name = None
    # Test when host_name = 0
    # Test when host_name = ''
    # Test when host_name = []
    # Test when host_name = {}
    # Test when host_name = ()
    # Test when host_name = []
    # Test when host_name = {}
    # Test when host_name = ()
    pass

# Generated at 2022-06-25 14:11:51.675767
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    set_0 = {
        'foo': 'bar'
    }
    host_vars_0 = HostVars(set_0, set_0, set_0)
    repr_ret_0 = repr(host_vars_0)
    assert repr_ret_0 == "{'foo': 'bar'}"



# Generated at 2022-06-25 14:11:53.865619
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Initialize HostVars 1
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)

    # Evaluate 'repr(host_vars_0)'
    result = repr(host_vars_0)
    assert result is None


# Generated at 2022-06-25 14:12:00.280280
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    set_0 = dict()
    set_0['foo'] = set_0
    set_0['bar'] = set_0
    set_1 = None
    set_2 = None
    host_vars_vars_0 = HostVarsVars(set_1, set_2)
    host_vars_vars_1 = HostVarsVars(set_0, set_2)
    host_vars_vars_2 = host_vars_vars_1
    assert repr(host_vars_vars_0) == "{'bar': {...}, 'foo': {...}}"

    # Test del a
    del set_0['foo']
    host_vars_vars_2 = host_vars_vars_1
    del set_0['bar']
    host_vars

# Generated at 2022-06-25 14:12:03.071799
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    set_1 = host_vars_0.__iter__()


# Generated at 2022-06-25 14:12:06.537448
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    result = host_vars_0.__iter__()
    assert True


# Generated at 2022-06-25 14:14:19.119606
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Get new instance and apply test
    host_vars_0 = HostVars(set_0, set_0, set_0)
    host_vars_0.__setstate__(set_0)


# Generated at 2022-06-25 14:14:22.731459
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Make sure the results of __repr__ are valid
    assert '__repr__' in dir(HostVars)
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    assert host_vars_0.__repr__() is not None


# Generated at 2022-06-25 14:14:28.798445
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Unit test for method __getitem__ of class HostVars.
    #
    # This test case checks the correctness of method __getitem__ of class
    # HostVars when the value in vars_cache is available but the value
    # is not in inventory.
    #
    # This case is designed to cover the following statements:
    #       if host is None:
    #           return AnsibleUndefined(name="hostvars['%s']" % host_name)
    #
    test_host_vars_vars_0 = 'test_host_vars_vars_0'

    # Setup test data
    loader = None

    # Expected result (default result = None)
    expected_host_vars_vars_0 = test_host_vars_vars_0

    # Perform the test
   

# Generated at 2022-06-25 14:14:34.947419
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars = HostVars(set_0, set_0, set_0)
    host_name = set_0
    host_vars._find_host = lambda host_name: host_name
    host_vars.get = lambda host_name: host_name
    host_vars._variable_manager = host_vars
    host_vars._variable_manager.get_vars = lambda host, include_hostvars: {}
    host_vars._variable_manager.get_host_vars = lambda host: {}
    test_example = host_name
    result = host_vars.raw_get(host_name)
    assert result == test_example

# Generated at 2022-06-25 14:14:35.845164
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    assert True


# Generated at 2022-06-25 14:14:38.674577
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create and initialize an object
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)
    for host in host_vars_0:
        pass


# Generated at 2022-06-25 14:14:41.529262
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # initialize vars
    set_0 = None
    host_vars_0 = HostVars(set_0, set_0, set_0)

    # run test
    result = host_vars_0.__iter__()

    # assert
    assert(result is not None)


# Generated at 2022-06-25 14:14:49.446202
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    set_0 = {}
    test_Host_0 = None
    variable_manager_0 = VariableManager(set_0, set_0, set_0)
    variable_manager_0.vars_cache = {test_Host_0: set_0}
    loader_0 = DataLoader()
    templar_0 = Templar(variable_manager_0.vars, loader_0)
    host_vars_vars_0 = HostVarsVars(set_0, loader_0)
    inventory_0 = Inventory(loader=loader_0, variable_manager=variable_manager_0, host_list=set_0)
    host_0 = Host(name=set_0, port=set_0)
    inventory_0.hosts = {host_0: host_0}

# Generated at 2022-06-25 14:14:58.069802
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Variable 'inventory' initialization
    inventory = None

    # Variable 'variable_manager' initialization
    variable_manager = None

    # Variable 'loader' initialization
    loader = None

    # Test function
    host_vars_0 = HostVars(inventory, variable_manager, loader)
    set_0 = None
    host_name_0 = set_0
    answer_0 = (host_vars_0.raw_get(host_name_0))[host_name_0]
    # Test function
    assert answer_0 is None, "Test failed"
    host_vars_1 = HostVars(inventory, variable_manager, loader)
    set_1 = None
    host_name_1 = set_1

# Generated at 2022-06-25 14:15:00.865718
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    HostVars(__builtins__.__dict__['None'], __builtins__.__dict__['None'], __builtins__.__dict__['None']).__getitem__('host_name')
