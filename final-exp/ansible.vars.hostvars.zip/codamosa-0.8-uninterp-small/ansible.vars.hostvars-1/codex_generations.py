

# Generated at 2022-06-25 14:05:32.998278
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_1 = True
    int_1 = -2147483649
    host_vars_vars_0 = HostVarsVars(bool_1, int_1)
    host_vars_0 = HostVars(host_vars_vars_0, 0)
    host_vars_vars_1 = HostVarsVars(host_vars_0, 0)
    assert 'dict' in str(host_vars_vars_1)


# Generated at 2022-06-25 14:05:37.674691
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    int_0 = -4238
    host_vars_vars_0 = HostVarsVars(bool_0, int_0)
    rep = host_vars_vars_0.__repr__()
    assert rep == "False"


# Generated at 2022-06-25 14:05:40.342461
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = host_vars_vars_0.__repr__()
    assert bool_0 == "__main__.HostVarsVars"


# Generated at 2022-06-25 14:05:41.247861
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_case_0()


# Generated at 2022-06-25 14:05:43.890310
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    bool_0 = True
    int_0 = -4238
    host_vars_vars_0 = HostVarsVars(bool_0, int_0)
    assert host_vars_vars_0.__repr__() == "True"


# Generated at 2022-06-25 14:05:47.243133
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test function call
    b_0 = True
    i_0 = -2812
    h_v_v_0 = HostVarsVars(b_0, i_0)
    h_v_v_0.__iter__()


# Generated at 2022-06-25 14:05:51.448242
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    # Testing condition if type(formatted_var) is not list, so type(var) is dict
    host_vars_vars_0 = HostVarsVars({}, {})
    assert_equal(list(host_vars_vars_0.__iter__()), [])


# Generated at 2022-06-25 14:05:55.723078
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    hostvars_0 = HostVars(bool_0, int_0, int_1)
    result = hostvars_0.__iter__()
    assert result == expected


# Generated at 2022-06-25 14:05:59.622486
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    bool_0 = True
    int_0 = -4238
    host_vars_vars_0 = HostVarsVars(bool_0, int_0)
    result = host_vars_vars_0.__iter__()


# Generated at 2022-06-25 14:06:03.479678
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    bool_0 = True
    int_0 = -4238
    host_vars_0 = HostVars(bool_0, int_0, bool_0)
    int_1 = len(host_vars_0)
    assert int_1 > -1


# Generated at 2022-06-25 14:06:08.052806
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0)
    string = repr(host_vars_0)


# Generated at 2022-06-25 14:06:08.665259
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert False

# Generated at 2022-06-25 14:06:11.940458
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    hostvars = HostVars()
    hostvars.__dict__.update({
        '_inventory': None,
        '_loader': None,
        '_variable_manager': None
    })
    hostvars.__setstate__(hostvars.__dict__)

# Generated at 2022-06-25 14:06:22.405974
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Init inventory
    inventory = []
    inventory.append({"hostname": 'host-0', "vars": {'var-0': 'var-0'}})
    inventory.append({"hostname": 'host-1', "vars": {'var-1': 'var-1'}})
    inventory.append({"hostname": 'host-2', "vars": {'var-2': 'var-2'}})
    inventory.append({"hostname": 'host-3', "vars": {'var-3': 'var-3'}})

    inventory_0 = {"all": {"hosts": inventory}}
    var_0 = {}

    # Init hostvars
    hostvars = HostVars(inventory_0, var_0, var_0)

    # Test case where host is existing
   

# Generated at 2022-06-25 14:06:31.946975
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVarsVars

    assert hasattr(HostVarsVars, '__getitem__')
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    var_1 = 'foo'
    host_vars_vars_1 = HostVarsVars(var_0, var_0)
    host_vars_vars_1[var_1] = 'bar'
    var_2 = {}
    var_2['foo'] = 'bar'

    assert host_vars_vars_0 == var_2
    assert host_vars_vars_1 == var_2


# Generated at 2022-06-25 14:06:38.296171
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {'var_0_0': 'value_0_0'}
    var_1 = {'var_1_0': 'value_1_0'}
    var_2 = {}
    var_3 = {'var_3_0': 'value_3_0'}
    var_4 = {'var_4_0': 'value_4_0', 'var_4_1': 'value_4_1'}
    var_5 = {}
    var_6 = {}
    var_7 = {'var_7_0': 'value_7_0', 'var_7_1': 'value_7_1'}
    var_8 = {'var_8_0': 'value_8_0'}

# Generated at 2022-06-25 14:06:39.600213
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Run test case 0
    test_case_0()


# Generated at 2022-06-25 14:06:40.530429
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # TODO
    pass


# Generated at 2022-06-25 14:06:41.274994
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # This test fails for now, until the method for this class has been implemented.
    assert False


# Generated at 2022-06-25 14:06:42.765989
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars({}, None, None)
    for host in host_vars_0:
        assert True


# Generated at 2022-06-25 14:06:48.253170
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    var_0 = {}
    var_0['foo'] = 'bar'
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    bar = host_vars_vars_0.__getitem__('foo')
    assert (bar == 'bar')
# END test_HostVarsVars___getitem__


# Generated at 2022-06-25 14:06:50.080699
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    pass


# Generated at 2022-06-25 14:06:51.099373
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Fix me: Add test cases
    return

# Generated at 2022-06-25 14:06:55.455102
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {'name': 'foo'}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    assert_equal(host_vars_vars_0[u'name'], 'foo')


# Generated at 2022-06-25 14:07:01.781938
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    host_vars_0 = HostVars(var_0, var_0, var_0)
    try:
        assert repr(host_vars_0) == var_0
    except Exception as ex:
        print(ex)

if __name__ == "__main__":
    test_case_0()
    test_HostVars___repr__()

# Generated at 2022-06-25 14:07:04.056842
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    # Method __iter__ of class HostVarsVars is not implemented
    

# Generated at 2022-06-25 14:07:16.186578
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)

    var_1 = {}
    host_vars_vars_1 = HostVarsVars(var_1, var_1)

    var_2 = {}
    host_vars_vars_2 = HostVarsVars(var_2, var_2)

    # Ensures results are always the same
    assert id(host_vars_vars_0.raw_get("value_0")) == id(var_0), "'value_0' of raw_get of HostVarsVars() is not equal to var_0"

# Generated at 2022-06-25 14:07:17.546601
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = HostVars()
    for v in var_0:
        pass

# Generated at 2022-06-25 14:07:22.476441
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    '''
    Hostvars:
    '''
    # Unit test for method __repr__ of class HostVarsVars
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    assert host_vars_vars_0.__repr__() == "{}"

# Generated at 2022-06-25 14:07:23.208264
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    pass


# Generated at 2022-06-25 14:07:37.141640
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Note -- this is a Mapping, not a MutableMapping
    class HostVars(Mapping):
        ''' A special view of vars_cache that adds values from the inventory when needed. '''

        def __init__(self, inventory, variable_manager, loader):
            self._inventory = inventory
            self._loader = loader
            self._variable_manager = variable_manager
            variable_manager._hostvars = self

        def set_variable_manager(self, variable_manager):
            self._variable_manager = variable_manager
            variable_manager._hostvars = self

        def set_inventory(self, inventory):
            self._inventory = inventory

        def _find_host(self, host_name):
            # does not use inventory.hosts so it can create localhost on demand
            return self._inventory.get_host

# Generated at 2022-06-25 14:07:39.003303
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)



# Generated at 2022-06-25 14:07:45.042819
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    var_1 = 'a'
    var_0[var_1] = ''
    x = host_vars_vars_0[var_1]
    var_2 = 'c'
    var_0[var_2] = 'b'
    x = host_vars_vars_0[var_2]


# Generated at 2022-06-25 14:07:49.104057
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    state_0 = {}
    host_vars_0.__setstate__(state_0)


# Generated at 2022-06-25 14:07:56.862304
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping
    var_0 = Mapping()
    var_0['inventory_dir'] = '/etc/ansible'
    var_0['inventory_dir1'] = '/etc/ansible'
    var_0['inventory_dir2'] = '/etc/ansible'
    var_0['inventory_dir3'] = '/etc/ansible'
    var_0['inventory_dir4'] = '/etc/ansible'
    var_0['inventory_dir5'] = '/etc/ansible'
    var_0['inventory_dir6'] = '/etc/ansible'
    var_0['inventory_dir7'] = '/etc/ansible'
    var_0['inventory_dir8'] = '/etc/ansible'
    var_0

# Generated at 2022-06-25 14:08:01.074731
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    try:
        var_0 = {}
        host_vars_0 = HostVars(var_0, var_0, var_0)
        for item_0 in host_vars_0:
            pass
    except Exception as e_0:
        print(str(e_0))
    finally:
        pass


# Generated at 2022-06-25 14:08:09.701277
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    # Assign var_1 (type Dict)
    var_1 = {}
    # var_1 is a dict: mockup it with a dummy value
    var_1['key_1'] = 1
    # Assign var_2 (type Dict)
    var_2 = {}
    # var_2 is a dict: mockup it with a dummy value
    var_2['key_2'] = 2

    # get length of var_1
    size_of_var_1 = len(var_1.keys())

    # get length of var_2
    size_of_var_2 = len(var_2.keys())

    # test __iter__ method
    host_vars_

# Generated at 2022-06-25 14:08:11.651579
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    dict_0 = {}
    host_vars_0.__setstate__(dict_0)

# Generated at 2022-06-25 14:08:15.536238
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    var_1 = {}
    host_vars_vars_1 = HostVarsVars(var_1, var_1)
    try:
        next(host_vars_vars_1.__iter__())
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 14:08:16.841631
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hostvars = HostVars(None, None, None)
    hostvars.raw_get('localhost')


# Generated at 2022-06-25 14:08:35.182375
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_1 = {}
    # No hostvars in var_1
    host_vars_vars_1 = HostVarsVars(var_1, var_1)
    assert host_vars_vars_1.raw_get(var_1) == AnsibleUndefined(name="hostvars['localhost']")


# Generated at 2022-06-25 14:08:42.004825
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # unit testing hostvars
    var_0 = {}
    var_1 = {}
    host_vars_0 = HostVars(var_0, var_1, var_1)
    for host_vars_0_key in host_vars_0:
        if host_vars_0_key in host_vars_0:
            continue
        raise AssertionError()
    for var_1_key in var_1:
        if var_1_key in var_1:
            continue
        raise AssertionError()
    for var_1_key in var_1:
        if var_1_key in var_1:
            continue
        raise AssertionError()


# Generated at 2022-06-25 14:08:47.043892
# Unit test for method __iter__ of class HostVars

# Generated at 2022-06-25 14:08:56.511258
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    var_1 = {}
    var_1['ansible_connection'] = 'local'
    host_1 = 'localhost'

    var_2 = {}
    var_2['ansible_connection'] = 'remote'
    host_2 = 'remote'

    inventory_1 = InventoryManager("")
    variable_manager_1 = VariableManager()
    hostvars_1 = HostVars(inventory_1, variable_manager_1, var_1)

    inventory_1.add_host(host_1)
    inventory_1.add_host(host_2)
    variable_manager_1.set_host_variable(host_1, 'var_0', var_1)
    variable_manager_1.set_host

# Generated at 2022-06-25 14:08:59.216202
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    print(HostVars(None, None, None).__repr__())
    assert HostVars(None, None, None).__repr__() == '{}'

# Generated at 2022-06-25 14:09:03.966359
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    inventory = MagicMock()
    variable_manager = MagicMock()
    loader = MagicMock()
    obj = HostVars(inventory, variable_manager, loader)
    state = dict()
    obj.__setstate__(state)


# Generated at 2022-06-25 14:09:06.627064
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    assert host_vars_vars_0[0] is not None

# Generated at 2022-06-25 14:09:16.371199
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    var_0 = {}
    var_1 = {}
    var_1['1'] = 1
    h_0 = 0
    h_1 = 1
    inventory_mock_0 = InventoryMock({h_0: var_0, h_1: var_1})
    var_2 = {}
    variable_manager_mock_0 = VariableManagerMock(inventory_mock_0, var_2)
    var_3 = {}
    loader_mock_0 = LoaderMock(var_3)
    hv_0 = HostVars(inventory_mock_0, variable_manager_mock_0, loader_mock_0)
    it_0 = hv_0.__iter__()

# Generated at 2022-06-25 14:09:22.508487
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    try:
        # Make sure no exception is raised on instantiation
        host_vars_0 = HostVars()
    except:
        assert False

    # Exercise __repr__
    host_vars___repr__result_0 = repr(host_vars_0)

    # Make sure __repr__ returns a string of the correct type
    assert type(host_vars___repr__result_0) == str


# Generated at 2022-06-25 14:09:25.680486
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    try:
        host_vars = HostVars({})
        assert False, "no exception was raised"
    except Exception as e:
        print(e)
        assert True, "exception was raised"



# Generated at 2022-06-25 14:09:43.351154
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    host_vars_0 = HostVars({}, {}, {})
    for var in host_vars_0:
        var

# Generated at 2022-06-25 14:09:48.005673
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    vars_cache_0 = {}
    inventory_0 = Inventory()
    variable_manager_0 = VariableManager(loader=None, inventory=inventory_0, version_info=Mock())
    hostvars_0 = HostVars(inventory_0, variable_manager_0, None)
    assert hostvars_0.__iter__() == inventory_0.hosts



# Generated at 2022-06-25 14:09:51.434725
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    var_0 = host_vars_0.__getitem__("")
    assert isinstance(var_0, HostVarsVars)


# Generated at 2022-06-25 14:09:53.830781
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    var_1 = None
    host_vars_0[var_1]


# Generated at 2022-06-25 14:09:56.093023
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    host_vars_0.raw_get(var_0)


# Generated at 2022-06-25 14:09:58.647089
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    try:
        var_0 = {}
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 14:10:08.233363
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.host_vars import HostVars

    # Create an instance of class HostVars and assign state dict to it
    instance = HostVars((), (), ())
    instance_state = {"_inventory": (), "_loader": (), "_variable_manager": ()}
    instance.__setstate__(instance_state)
    assert instance._inventory == ()

    # Create an instance of class HostVars and assign state dict to it
    # which has few extra key/value pairs.
    instance = HostVars((), (), ())
    instance_state = {"_inventory": (), "_loader": (), "_variable_manager": (), "foo": "bar"}
    instance.__setstate__(instance_state)
    assert instance._inventory == ()

    # Create an instance of class HostVars and assign state dict to it
    # which has no _

# Generated at 2022-06-25 14:10:10.235492
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    iter_var = HostVars({"a":1}, {"b":2}, {"c":3})
    assert type(iter(iter_var)) is type(iter([]))


# Generated at 2022-06-25 14:10:20.713483
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_name = 'localhost'

    data_0 = {}

    class Obj(object):
        pass

    loader_0 = Obj()
    loader_0.get_basedir = lambda: '.'

    class Obj(object):
        pass

    get_vars_0 = Obj()
    get_vars_0.side_effect = lambda host, include_hostvars: data_0

    class Obj(object):
        pass

    variable_manager_0 = Obj()
    variable_manager_0.get_vars = get_vars_0

    class Obj(object):
        pass

    inventory_0 = Obj()
    inventory_0.get_host = lambda host_name: None

    host_vars_0 = HostVars(inventory_0, variable_manager_0, loader_0)
    host_v

# Generated at 2022-06-25 14:10:24.120452
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    my_host_vars = HostVars(None, None, None)
    data = my_host_vars.raw_get('foo')
    assert isinstance(data, AnsibleUndefined)

# Generated at 2022-06-25 14:11:02.248627
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = {}
    var_1 = []
    var_2 = None
    host_vars_0 = HostVars(var_0, var_0, var_0)
    try:
        host_vars_0.__repr__()
    except TypeError:
        print("Raised expected TypeError")


# Generated at 2022-06-25 14:11:07.046986
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Assert that repr(host_vars) returns a string
    var_0 = {}
    host_vars_0 = HostVars({}, var_0, var_0)
    assert isinstance(repr(host_vars_0), str)
    assert True


# Generated at 2022-06-25 14:11:09.951249
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    host_vars_vars_1 = HostVars()
    assert host_vars_vars_1.raw_get() == ()


# Generated at 2022-06-25 14:11:12.394850
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    str_0 = repr(host_vars_0)


# Generated at 2022-06-25 14:11:18.979745
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    var_0 = {}
    val_0 = iter(var_0)
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    result_0 = host_vars_vars_0.__iter__()
    assert result_0.__class__ == val_0.__class__
    assert result_0.__next__().__class__ == val_0.__next__().__class__
    assert result_0.__next__().__class__ == val_0.__next__().__class__
    assert result_0.__next__().__class__ == val_0.__next__().__class__


# Generated at 2022-06-25 14:11:19.656554
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    pass


# Generated at 2022-06-25 14:11:27.133465
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Initializing argument 'inventory'
    inventory_0 = {}

    # Initializing argument 'variable_manager'
    variable_manager_0 = None

    # Initializing argument 'loader'
    loader_0 = None

    # Call to __init__(...)
    # Processing the call keyword arguments (line 523)
    # Getting the type of 'inventory_0' (line 523)
    inventory_0_type = type(inventory_0)
    keyword_arg_types = []
    keyword_arg_values = []
    for m_name, m_value in pytest.config.option.kargs:
        if m_name in keyword_arg_types:
            continue
        try:
            keyword_arg_type = getattr(inventory_0_type, m_name)
        except (KeyError, AttributeError):
            continue

# Generated at 2022-06-25 14:11:29.787802
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    host_vars_0 = HostVars(None, None, None)
    host_vars_0.raw_get("host_name_0")



# Generated at 2022-06-25 14:11:33.895458
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    host_vars_0 = HostVars({  }, {  }, {})
    assert 'repr' in dir(host_vars_0)
    # TODO: we need a better way to test __repr__()
    #assert host_vars_0.__repr__() == '{}'
    assert True


# Generated at 2022-06-25 14:11:36.957399
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    assert isinstance(host_vars_0, HostVars)
    obj_0 = {}
    host_vars_0.__setstate__(obj_0)


# Generated at 2022-06-25 14:13:45.699954
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Set up mock inventory and variable manager
    inv = MockInventory()
    var_mgr = MockVariableManager()
    # Instantiate HostVars
    hostvars = HostVars(inv, var_mgr, var_0)
    # Add a host
    h1 = MockHost(inv, "h1")
    inv.hosts.append(h1)
    # Use __getitem__ to get host vars
    result = hostvars["h1"]
    # Get host vars with VariableManager
    expected = var_mgr.get_vars(host=h1, include_hostvars=False)
    # Compare the results
    assert result == expected


# Generated at 2022-06-25 14:13:53.321279
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test for method __iter__(self)
    # Unit test for method __iter__ of class HostVars
    var_1 = {}
    host_vars_vars_1 = HostVarsVars(var_1, var_1)
    from ansible.parsing.yaml.objects import AnsibleUnicode
    unicode_str_1 = AnsibleUnicode('c.o.m')
    unicode_str_2 = AnsibleUnicode('a.c.om')
    unicode_str_3 = AnsibleUnicode('d.c.om')
    tuple_1 = (
        unicode_str_2,
        unicode_str_3,
    )
    var_1['foo'] = unicode_str_1
    var_1['bar'] = tuple_1
   

# Generated at 2022-06-25 14:14:01.443861
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    var_0 = {}
    var_1 = AnsibleUndefined(name="hostvars['test']")

    host_vars_0 = HostVars(None, None, None)
    host_vars_0._find_host = lambda x: None

    host_vars_1 = HostVars(None, None, None)
    host_vars_1._find_host = lambda x: None
    host_vars_1._loader = var_0

    host_vars_2 = HostVars(None, None, None)
    host_vars_2._find_host = lambda x: None
    host_vars_2._loader = var_0

    host_vars_3 = HostVars(None, None, None)
    host_vars_3._find_host = lambda x: None


# Generated at 2022-06-25 14:14:04.284513
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    var_1 = 0
    var_1 = host_vars_0[var_1]
    assert isinstance(var_1, HostVarsVars)


# Generated at 2022-06-25 14:14:08.869202
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)
    var_1 = {}
    host_vars_0 = HostVars(var_1, var_1, var_1)
    key = {}
    var_2 = host_vars_0.__getitem__(key)
    assert var_2 == host_vars_vars_0


# Generated at 2022-06-25 14:14:12.841953
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    host_vars_0 = HostVars(var_0, var_0, var_0)
    host_vars_0.__setstate__(var_0)
    assert isinstance(host_vars_0, HostVars)


# Generated at 2022-06-25 14:14:15.681277
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    var_0 = {}
    host_vars_vars_0 = HostVarsVars(var_0, var_0)

    assert repr(host_vars_vars_0) == "{}"


# Generated at 2022-06-25 14:14:24.193569
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.config.manager import ConfigManager
    import ansible.constants as C
    import io

    inventory_0_0 = u'all:\n  children:\n    ungrouped:\n      hosts:\n        server.example.com:\n        other.example.com:\n          ansible_ssh_host: 10.0.0.1\n    foo:\n      hosts:\n        localhost:\n    bar:\n      hosts:\n        localhost:\n'
    config_0_0 = ConfigManager(['ansible.cfg'])

# Generated at 2022-06-25 14:14:24.887021
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # FIXME
    pass


# Generated at 2022-06-25 14:14:27.080936
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    var_0 = {}
    host_vars_0 = HostVars(var_0, var_0, var_0)
    host_vars_1 = host_vars_0.__getitem__('key_0')
