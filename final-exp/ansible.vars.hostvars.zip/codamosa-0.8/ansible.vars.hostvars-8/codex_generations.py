

# Generated at 2022-06-22 14:33:02.693224
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    # Create an empty inventory
    loader = DataLoader()
    inventory = InventoryManager(loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create an instance for HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create a Play with a host but without variable
    playbook_hosts = ['localhost']
    play = Play().load(dict(hosts=playbook_hosts), variable_manager=variable_manager, loader=loader)

    # Create an host localhost
    inventory.add_host(host='localhost')
    inventory.add_group

# Generated at 2022-06-22 14:33:12.984466
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.utils.vars import merge_hash

    dl = DataLoader()
    inv = Inventory(loader=dl, variable_manager=VariableManager(), host_list='tests/inventory/unversioned_hostvars')
    var_mgr = VariableManager()
    var_mgr.set_inventory(inv)
    hostvars = HostVars(inventory=inv, variable_manager=var_mgr, loader=dl)
    host = inv.get_host("test1")
    variables = var_mgr.get_vars(host=host)
    test_data = hostvars.raw_get("test1")

# Generated at 2022-06-22 14:33:22.708248
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import collections
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create inventory
    sources = ','.join(['localhost,' + os.path.join(os.path.dirname(__file__), 'host_vars', 'host_vars_files', 'host_vars_file1.yml'),
                         os.path.join(os.path.dirname(__file__), 'host_vars', 'host_vars_files', 'host_vars_file2.yml')])
    inventory = InventoryManager(sources=sources)

    # Create variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    # Create AnsibleHostVarsVars instance and run raw_get
    hostvars = Host

# Generated at 2022-06-22 14:33:27.171990
# Unit test for method set_variable_manager of class HostVars
def test_HostVars_set_variable_manager():
    from ansible.vars import VariableManager
    my_vm = VariableManager()
    my_vm._loader = None
    my_vm._hostvars = None

    my_hv = HostVars(None, my_vm, None)
    my_vm._hostvars = None
    my_vm._loader = None
    assert my_vm._hostvars == None
    assert my_vm._loader == None
    my_hv.set_variable_manager(my_vm)
    assert my_vm._hostvars == my_hv
    assert my_vm._loader == my_hv._loader

# Generated at 2022-06-22 14:33:36.988011
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    loader = 'loader'
    inventory = 'inventory'
    vars_manager = VariableManager()

    hostvars = HostVars(inventory, vars_manager, loader)

    hostvars._find_host = lambda name: 'host' if name == 'host_name' else None
    vars_manager.get_vars = lambda host, include_hostvars: {'a': 1, 'b': 2} if host == 'host' else dict()

    assert hostvars['host_name'] == {'a': 1, 'b': 2}

    assert hostvars['non_existing_host_name'] == AnsibleUndefined(name="hostvars['non_existing_host_name']")



# Generated at 2022-06-22 14:33:43.774184
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    def create_mock_inventory(name=None):
        class MockInventory():
            def __init__(self, name=None):
                self.name = name
                self.hosts = []

            def add_host(self, host):
                self.hosts.append(host)

            def get_host(self, name):
                # this method is required by HostVars to do not use
                # inventory.hosts so it can create localhost on demand
                return self.hosts[0] if name == self.hosts[0]['name'] else None

        mock_inventory = MockInventory(name)
        mock_inventory.add_host({'name': "host1", 'hostname': 'host1', 'vars': {'var1': 'val1'}})
        return mock_inventory


# Generated at 2022-06-22 14:33:51.447424
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=None)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    inventory.hosts = ['a', 'b', 'c']

    assert all(host in hostvars for host in inventory.hosts)


# Generated at 2022-06-22 14:33:55.786325
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Inventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # Create inventory and add new group, host and variables
    inventory = Inventory(loader=None)

    group = Group('test_group')
    inventory.add_group(group)

    host = Host('test_host')
    group.add_host(host)

    group.set_variable('test_group_var', 'test_group_var_value')
    host.set_variable('test_host_var', 'test_host_var_value')
    host.set_variable('test_var', 'test_var_value')

    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create HostVars
    hostv

# Generated at 2022-06-22 14:34:06.201391
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    hostvars = HostVars(inventory=Inventory(loader=DataLoader()),
                        variable_manager=VariableManager(loader=DataLoader()),
                        loader=DataLoader())

    # Default state of the variable_manager should include no _loader and
    # no _hostvars attributes being preserved.
    assert hostvars._variable_manager._loader is hostvars._loader
    assert hostvars._variable_manager._hostvars is hostvars

    # Reset hostvars variable manager to default state to force _loader and
    # _hostvars attributes to be None.
    hostvars._variable_manager = VariableManager(loader=DataLoader())
    assert hostvars._variable_

# Generated at 2022-06-22 14:34:13.085323
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    host_vars = {'a': 1, 'b': 2, 'c': 3}
    host_vars_vars = HostVarsVars(host_vars, None)
    l = list(host_vars_vars)
    assert (len(l) == len(host_vars))
    for var in host_vars.keys():
        assert (var in l)

# Generated at 2022-06-22 14:34:26.407438
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    hostvars = HostVars(inventory=InventoryManager(host_list=['1.2.3.4', '5.6.7.8']),
                        variable_manager=VariableManager(),
                        loader=None)
    assert set(hostvars) == set(['1.2.3.4', '5.6.7.8'])

# Generated at 2022-06-22 14:34:34.829968
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    data = {}
    data['ansible_version'] = {
        'full': '1.8.2',
        'major': 1,
        'minor': 8,
        'revision': 2,
        'string': '1.8.2'
    }
    data['ansible_play_hosts'] = {
        'foo': '1.8.2',
        'bar': '4.4.4'
    }
    vars = HostVarsVars(data, None)
    assert vars['ansible_play_hosts'] == {'foo': '1.8.2', 'bar': '4.4.4'}

# Generated at 2022-06-22 14:34:40.820065
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    # Setup
    variables = {'var1': {'var2': 'value1'}}
    variable_manager = VariableManager(loader=None, inventory=None)
    variable_manager.set_host_variable('host1', 'var1', variables['var1'])

    # Test
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=None)
    repr_ret = repr(hostvars)
    repr_expected = repr({'host1': {'var2': 'value1'}})

    assert repr_ret == repr_expected

# Generated at 2022-06-22 14:34:47.844849
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    allgroup = Group('all')
    host = Host(name='localhost')
    allgroup.add_host(host)
    inventory.add_group(allgroup)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-22 14:34:57.658523
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.inventory
    import ansible.playbook.play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variable_manager, host_list=['all'])
    playbook = ansible.playbook.play.Play()
    variable_manager.set_inventory(inventory)

    hv = HostVars(inventory, variable_manager, loader)
    host = inventory.get_host('localhost')
    variable_manager.set_host_variable(host, 'foo', 'bar')
    assert hv.raw_get('localhost')['foo'] == 'bar'

# Generated at 2022-06-22 14:35:05.238108
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import copy

    hostvars = HostVars(None, None, None, {})
    hostvars._loader = object()
    hostvars._variable_manager._loader = None
    hostvars._variable_manager._hostvars = None
    hostvars2 = copy.deepcopy(hostvars)

    assert hostvars._loader is hostvars2._loader
    assert hostvars2._variable_manager._loader is hostvars._loader
    assert hostvars2._variable_manager._hostvars is hostvars2

# Generated at 2022-06-22 14:35:13.288999
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host

    loader = None

    vars_manager = VariableManager()
    inventory = Inventory(loader, hosts=[Host(name='host1'), Host(name='host2')])

    hostvars = HostVars(inventory, vars_manager, loader)

    # Test that __iter__ returns all hosts
    host_names = [host.name for host in hostvars]
    assert host_names == ['host1', 'host2']


# Generated at 2022-06-22 14:35:23.302313
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    vars_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory("localhost", vars_manager=vars_manager, loader=loader)
    inventory.set_variable("localhost", "foo", 1)

    # Call __init__ to initialize attributes of HostVars
    hostvars = HostVars(inventory, vars_manager, loader)

    # Get some variable
    hostvars["localhost"]

    # Call __setstate__ with some mocked data. We don't care about
    # value, just need to check that the function does not raise an
    # exception.

# Generated at 2022-06-22 14:35:24.392755
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    pass


# Generated at 2022-06-22 14:35:31.689307
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    loader = object()
    inventory = Inventory("", loader)
    hosts = [inventory.hosts.add("host%d" % i) for i in range(3)]
    manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=manager, loader=loader)

    # set initial host variables
    hostvars.set_host_variable(hosts[0], "v0", "value0")
    hostvars.set_host_variable(hosts[1], "v1", "value1")
    hostvars.set_host_variable(hosts[2], "v2", "value2")

    # set hostvars variables
    hostvars.set_

# Generated at 2022-06-22 14:35:47.615511
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Define data for testing
    hosts = dict()
    hosts['host1'] = dict()
    hosts['host1']['vars'] = dict()
    hosts['host1']['vars']['ansible_connection'] = 'local'
    hosts['host1']['vars']['var1'] = '{{foo}}'
    hosts['host1']['vars']['var2'] = 'default'
    hosts['host1']['vars']['var3'] = '{{foo}}'
    hosts['host1']['vars']['var4'] = '{{bar}}'
    hosts['host1']['vars']['var5'] = '#{{foo}}#'
    hosts['host2'] = dict()

# Generated at 2022-06-22 14:35:50.552944
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert HostVars({'foo': 'value', 'bar': None}).raw_get('foo') == 'value'
    assert HostVars({'foo': 'value', 'bar': None}).raw_get('bar') is None

# Generated at 2022-06-22 14:35:57.111124
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create a mock inventory, that can be used to generate HostVars instance
    inventory = FakeInventory()
    # Create a mock loader
    loader = FakeLoader()
    # Create a mock variable_manager
    variable_manager = FakeVariableManager()
    # Create HostVars instance, to be tested
    hostvars = HostVars(inventory, variable_manager, loader)
    # Iterate over the HostVars instance
    for host in hostvars:
        assert(isinstance(host, str))


# Generated at 2022-06-22 14:36:01.999131
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    loader = DictDataLoader({})
    variables = dict(
        var1='value1',
        var2='value2'
    )
    obj = HostVarsVars(variables, loader)

    assert obj['var1'] == 'value1'
    assert obj['var2'] == 'value2'


# Generated at 2022-06-22 14:36:11.289575
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class FakeHost:
        def __init__(self, name):
            self.name = name

    class FakeInventory:
        def __init__(self):
            self.hosts = [FakeHost("one"), FakeHost("two")]

        def get_host(self, host_name):
            for host in self.hosts:
                if host.name == host_name:
                    return host
            return None

    class FakeVariableManager:
        def get_vars(self, host, include_hostvars):
            if host.name == "one":
                return {"name": "one", "color": "red", "var1": 1}
            else:
                return {"name": "two", "color": "blue", "var1": 2}

    class FakeLoader:
        pass

    fake_inventory = FakeInventory

# Generated at 2022-06-22 14:36:13.867591
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = DictDataLoader({})
    variables = {'foo': 'bar'}
    hvv = HostVarsVars(loader=loader, variables=variables)
    assert list(hvv.__iter__()) == ['foo']

# Generated at 2022-06-22 14:36:26.215950
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # The code below should be executed only in unit tests
    from ansible.module_utils._text import to_text

    class TestLoader:
        '''
        Test loader that returns provided path as content of all files.
        '''
        path = ''

        def __init__(self, path):
            self.path = path

        def get_source(self, environment, template):
            return to_text("template: " + self.path)

    loader = TestLoader("/path/to/templates")
    variables = dict(name="Bob", age=20, height=160.5, is_adult=True)
    host_vars_vars = HostVarsVars(variables, loader)

    for var in host_vars_vars:
        assert(var in variables)


# Generated at 2022-06-22 14:36:29.197102
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = dict(foo='bar', baz='{{ foo }}')
    loader = None
    hostvars = HostVarsVars(variables, loader)
    assert hostvars['baz'] == 'bar'

# Generated at 2022-06-22 14:36:36.136350
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible import errors
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    hv = HostVars(InventoryManager(loader=None), vm, None)

    # validate lookup of nonexistent host
    invalid_host = "invalid_host"
    try:
        hv.raw_get(invalid_host)
    except errors.AnsibleError as e:
        assert "not defined in inventory" in e.args[0]
    else:
        assert False, "AnsibleError was not raised"

    # validate lookup of localhost
    localhost = "localhost"
    data = hv.raw_get(localhost)
    assert isinstance(data, dict)
    assert data["inventory_hostname"] == localhost
    assert data

# Generated at 2022-06-22 14:36:43.986807
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    obj = HostVars({})
    assert repr(obj) == "{}"

    obj = HostVars({"host1": {"foo": "bar"}})
    assert repr(obj) == "{'host1': {u'foo': u'bar'}}"

    obj = HostVars({"host1": {"foo": "bar"}, "host2": ["foo", "bar"]})
    assert repr(obj) == "{'host1': {u'foo': u'bar'}, 'host2': [u'foo', u'bar']}"

# Generated at 2022-06-22 14:37:02.854521
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    inventory.hosts = ['host1', 'host2']
    variable_manager = DummyVars()
    variable_manager.vars = {
        'host1': {'var1': 'value1'},
        'host2': {'var2': 'value2'},
    }
    vars = HostVars(inventory, variable_manager, None)
    assert repr(vars) == "{'host1': {'var1': 'value1'}, 'host2': {'var2': 'value2'}}"


# Generated at 2022-06-22 14:37:09.991867
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # The module_utils_common/test/unit/test_var_cache.py is the unit test
    # that tests the _raw_get method.
    # Note that the method raw_get of class HostVars is not an instance
    # method and we cannot mock the self.
    # However, we need to make the function _find_host visible to test
    # the function raw_get. We can either modify the source code to remove
    # the underscore prefix of _find_host or we can expose _find_host via
    # the property of class HostVars such as raw_get, variables and inventory.
    pass

# Generated at 2022-06-22 14:37:21.399722
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import os
    import tempfile
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({
        'inventory': """
*/var: value
*a/var2: value2
""",
        'vars.yaml': '''
---
hostvars:
  inventory_hostname_dummy:
    var1: hostvars_var_1
    var2:
      var3: value3
'''
    })
    hostvars = HostVars({}, {}, loader)



# Generated at 2022-06-22 14:37:27.078113
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVarsVars

    hostvars = HostVars(None, VariableManager(loader=None, vault_secrets=['vault.txt']), None)
    hostvars.set_variable_manager(VariableManager(loader=None, vault_secrets=['vault.txt']))

    variables = VaultLib(None).decrypt({
        'var_one': 'Hello',
        'var_two': 'World'
    })
    hostvars._variable_manager._vars_cache[PlayContext().remote_addr]['vars'] = variables
    hostvars_vars = HostVars

# Generated at 2022-06-22 14:37:34.513755
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader, ':memory:')

    inventory.add_host(host='localhost')
    inventory.add_host(host='other')

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hosts = list(hostvars)

    assert len(hosts) == 2
    assert 'localhost' in hosts
    assert 'other' in hosts


# Generated at 2022-06-22 14:37:38.486636
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = dict(var1 = 1, var2 = 2)
    host_vars_vars = HostVarsVars(variables, loader=None)
    assert list(host_vars_vars) == variables.keys()

# Generated at 2022-06-22 14:37:47.158282
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = C.DEFAULT_LOADER
    hostvars = HostVars(Inventory(loader), variable_manager, loader)
    hostvars.set_host_variable('localhost', 'a', 'b')

    hostvarsvars = HostVarsVars(hostvars['localhost'], loader)
    assert 'a' in hostvarsvars
    assert list(hostvarsvars) == ['a']

# Generated at 2022-06-22 14:37:52.667126
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = None
    vars = {"a": 1, "b": 2, "c": 3}
    h1 = HostVarsVars(variables=vars, loader=loader)
    mylist = []
    for var in h1:
        mylist.append(var)
    assert(mylist == ["a", "b", "c"])

# Generated at 2022-06-22 14:38:02.993280
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import mock
    import ansible.inventory as inv
    import ansible.module_utils.common._collections_compat as cc
    import ansible.vars.hostvars as hv

    localhost = inv.Host('localhost')
    loader_run = mock.MagicMock()
    loader_run.get_real_file.return_value = '/path/to/real_file.yml'
    loader_mock = mock.MagicMock(
        spec=hv.AnsibleTemplateLoader,
        spec_set=True,
        run_file=loader_run,
    )

# Generated at 2022-06-22 14:38:09.716960
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    loader = MockLoader()
    inventory = MockInventory()
    variables = MockVarsCache()
    variable_manager = MockVariableManager(inventory=inventory, loader=loader, variables=variables)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars['host1']
    assert inventory.hosts == ['host1']

    hostvars['host2']
    assert inventory.hosts == ['host1', 'host2']


# Generated at 2022-06-22 14:38:49.655141
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    # create the inventory and feed it with hosts, groups, and vars
    inventory = InventoryManager(loader=None, sources=[])
    inventory.hosts.append(inventory.create_host('host1'))
    inventory.hosts.append(inventory.create_host('host2'))
    inventory.groups.append(inventory.create_group('group1'))
    inventory.groups.append(inventory.create_group('group2'))
    inventory.groups.append(inventory.create_group('all'))
    inventory.get_group('group1').add_host(inventory.get_host('host1'))
    inventory.get_group('group2').add_host(inventory.get_host('host2'))
    inventory.get

# Generated at 2022-06-22 14:38:58.358709
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create InventoryManager with dummy inventory
    host_list = [
        'host_1',
        'host_2',
        'not_existing_host'
    ]
    inventory = InventoryManager(loader=None, sources=host_list)

    # Create VariableManager with dummy index_vars and internal_vars
    index_vars = {
        'index_var_1': 'value_1',
        'index_var_2': 'value_2'
    }

# Generated at 2022-06-22 14:39:09.117846
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import unittest
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestHostVars(unittest.TestCase):
        inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=[])
        hostvars = HostVars(inventory, VariableManager(), DataLoader())

        def test__iter__(self):
            for host in self.hostvars:
                pass

    suite = unittest.TestLoader().loadTestsFromTestCase(TestHostVars)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-22 14:39:20.948122
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class MockVariableManager(object):
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self, host=None, include_hostvars=True):
            return self.vars

    class MockInventory(object):
        def __init__(self, vars):
            self.vars = vars

        def get_host(self, host_name):
            return 'Mock_Host'

    class MockHost(object):
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self):
            return self.vars

    class MockLoader(object):
        def __init__(self):
            pass

        def get_basedir(self):
            return 'Mock_basedir'

    #

# Generated at 2022-06-22 14:39:24.776870
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    hv = HostVars()
    for host in hv:
        if type(host) != Host:
            raise AssertionError("HostVars.__iter__ returned non-Host object: %r" % host)


# Generated at 2022-06-22 14:39:32.601698
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Setup
    inventory = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, ansible.constants.DEFAULT_LOADER)

    host1 = ansible.inventory.host.Host(name="host1")
    host2 = ansible.inventory.host.Host(name="host2")

    group = ansible.inventory.group.Group(name='group')
    group.add_host(host1)
    group.add_host(host2)

    inventory.add_group(group)

    # Test
    hostnames = list(hostvars)

    # Assertion
    assert hostnames == ["host1", "host2"]

# Generated at 2022-06-22 14:39:41.618758
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Verify that AnsibleUndefined is returned when a host is not found
    def _find_host(host_name):
        host = None
        return host

    variables = {'ansible_ssh_host': 'localhost'}
    inventory = MagicMock()
    loader = None
    variable_manager = MagicMock()
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars._find_host = _find_host
    hostvars._variable_manager.get_vars.return_value = variables
    result = hostvars.raw_get('foo_host')
    assert isinstance(result, AnsibleUndefined)
    assert result.name == "hostvars['foo_host']"
    # Verify that the variables are returned
    host = MagicMock()
    result = hostvars

# Generated at 2022-06-22 14:39:54.474211
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager

    # Dummy inventory does not need to behave exactly like the real
    # one. Inventory is provided to HostVars in method __init__. It is
    # ensured that HostVars can access it from there.
    class Inventory(object):
        def __init__(self, store):
            self.store = store

        def __iter__(self):
            for host in self.store:
                yield host

        def __len__(self):
            return len(self.store)

        def get_host(self, host_name):
            if host_name in self.store:
                return host_name
            return None

    # Given a dictionary of variables, first use the VariableManager to
    # get the variables. Then, create a HostVars with the same variables
    # and an Inventory

# Generated at 2022-06-22 14:40:03.139150
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    collection = HostVars(inventory=Inventory(host_list=[]),
                          variable_manager=VariableManager(),
                          loader=None)

    collection_iterator = iter(collection)
    assert collection_iterator is iter(collection_iterator)
    assert iter(collection_iterator) is iter(collection_iterator)
    assert iter(collection_iterator) is iter(collection_iterator)

    for host in collection_iterator:
        assert False



# Generated at 2022-06-22 14:40:13.001068
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # If a VariableManager has undefined _loader attribute, HostVars method __setstate__ should
    # assign it the value of corresponding attribute.
    class MockLoader:
        pass

    class MockVariableManager:
        def __init__(self):
            self._loader = None
            self._hostvars = None

    loader = MockLoader()
    variable_manager = MockVariableManager()
    hostvars = HostVars(None, variable_manager, loader)

    assert variable_manager._loader is loader
    assert variable_manager._hostvars is hostvars

    hostvars._loader = None

    hostvars.__setstate__({})

    assert variable_manager._loader is loader
    assert variable_manager._hostvars is hostvars

# Generated at 2022-06-22 14:40:57.270563
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    vars_loader.add_directory(inventory, 'lib/ansible/plugins/vars')
    host = inventory.get_host('localhost')

    # Set some variables for the localhost
    variable_manager.set_host_variable(host, "myvar1", "myval1")

# Generated at 2022-06-22 14:41:08.056653
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader, host_list=['localhost']))
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    variable_manager._hostvars = None
    variable_manager._loader = None
    variable_manager.set_nonpersistent_facts(inventory.get_host('localhost'), {u'localhost': {u'a': u'hello', u'b': u'world'}})

# Generated at 2022-06-22 14:41:20.434173
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager

    loader = None
    inventory = Group()
    inventory.hosts = [Host('foobar'), Host('foobaz')]
    variable_manager = VariableManager()
    variable_manager.set_host_variable('foobar', 'barvar', 'barvalue')
    variable_manager.set_host_variable('foobaz', 'bazvar', 'bazvalue')

    hostvars = HostVars(inventory, variable_manager, loader)
    assert isinstance(hostvars, Mapping)

    for host in hostvars:
        assert isinstance(hostvars[host], HostVarsVars)

    # hostvars.keys()
    assert sorted(hostvars.keys())

# Generated at 2022-06-22 14:41:24.125064
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=None)
    host = inventory.add_host('localhost')
    host.set_variable('foo', 'bar')

    hostvars = HostVars(inventory, None, None)
    assert hostvars.raw_get('localhost') == dict(foo='bar')

# Generated at 2022-06-22 14:41:34.863688
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class Dict(Mapping):
        def __init__(self, *args, **kwargs):
            self.the_dict = dict(*args, **kwargs)

        def __getitem__(self, key):
            return self.the_dict[key]

        def __iter__(self):
            return iter(self.the_dict)

        def __len__(self):
            return len(self.the_dict)

    class LoaderMock(object):
        def get_basedir(self):
            return '/tmp/ansible'

    class InventoryMock(object):
        def __init__(self):
            self.hosts_by_name = {}

        def get_host(self, host_name):
            return self.hosts_by_name.get(host_name)


# Generated at 2022-06-22 14:41:45.568062
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader

    class Inventory():
        def __getitem__(self, hostname):
            return {'hostname': hostname,
                    'vars': {'hostvar': 'hostvarvalue'}}

        def __contains__(self, hostname):
            return True

    class VariableManager():
        def __init__(self):
            self.vars_cache = {'globalvar': 'globalvarvalue'}
            self._hostvars = None

        @property
        def hostvars(self):
            return self._hostvars

    class Loader():
        pass

    inventory = Inventory()
    variable_manager = VariableManager()
    loader = Loader()

    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-22 14:41:51.371105
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os
    import random
    import tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    # Init play vars
    play_vars = dict()
    play_vars['host1_var'] = "host1_value"
    play_vars['host2_var'] = "host2_value"

    # Init host vars
    host_vars = dict()
    host_vars['host1'] = dict()
    host_vars['host1']['host1_var'] = "host1_value_defined"

# Generated at 2022-06-22 14:42:02.198577
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Ensure HostVars.__getitem__ is working
    '''
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleUndefinedVariable

    loader = DataLoader()
    hostvars = HostVars(InventoryManager(loader=loader, sources=[]), VariableManager(loader=loader), loader)
    hostname = 'test_host'
    host = Host(name=hostname)

    # find an undefiend hostname

# Generated at 2022-06-22 14:42:13.876546
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Create a fake loader
    class FakeLoader(object):
        def get_basedir(self):
            return "/path/to/playbook"

    loader = FakeLoader()

    # Create a fake variable manager
    class FakeVariableManager(object):
        def get_vars(self, loader=None, play=None, host=None, task=None, include_hostvars=True):
            vars = dict(
                redhat=True,
                ansible_distribution='RedHat',
            )

# Generated at 2022-06-22 14:42:26.172295
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.add_host(Host("foo"))
    inventory.add_host(Host("bar"))
    inventory.add_host(Host("baz"))

    variable_manager.set_host_variable("foo", "test", "foo")
    variable_manager.set_host_variable("bar", "test", "bar")
    variable_manager.set_host_variable("baz", "test", "baz")

    assert repr