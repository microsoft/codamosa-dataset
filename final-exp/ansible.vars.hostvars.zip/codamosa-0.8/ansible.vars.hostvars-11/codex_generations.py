

# Generated at 2022-06-22 14:32:58.734444
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    class FakeInventory():
        pass

    class FakeVariableManager():
        def get_vars(self, host=None, include_hostvars=False):
            return {'foo_key': 'foo_value', 'bar_key': 'bar_value'}

    inventory = FakeInventory()
    variable_manager = FakeVariableManager()
    loader = None
    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars.raw_get('fake_host') == {'foo_key': 'foo_value', 'bar_key': 'bar_value'}



# Generated at 2022-06-22 14:33:10.291688
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    # Initialize inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)

    # Fetch group vars for host 'host1'
    group_vars = inventory.get_group_vars('all')
    group_vars_pre = {
        'empty_var': "",
        'xyz_var': "xyz",
        'def_var': "def",
    }

    # Add host 'host1' to inventory
    host1 = {
        'hostname': 'host1',
        'groups': 'all',
    }

# Generated at 2022-06-22 14:33:20.756803
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    class FakeLoader():
        def __init__(self):
            self._basedir = ''

    class FakeInventory():

        def __init__(self):
            self._hosts_cache = {}

        def get_host(self, host_name):
            if host_name not in self._hosts_cache:
                self._hosts_cache[host_name] = None
            return self._hosts_cache[host_name]

    class FakeVariableManager():

        def __init__(self):
            self._hostvars = {}

        def get_vars(self, host=None, include_hostvars=True):
            if host.name not in self._hostvars:
                self._hostvars[host.name] = dict(foo='bar')
            return self._hostvars[host.name]



# Generated at 2022-06-22 14:33:25.941493
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # HostVarsVars is a dictionary with a list of templated variables,
    # when iterated, it should not return the templated values.
    host_vars_vars = HostVarsVars(
        {
            'k1': '{{ k1 }}',
            'k2': '{{ k2 }}',
        },
        None
    )

    assert sorted(host_vars_vars) == [
        'k1',
        'k2'
    ]

# Generated at 2022-06-22 14:33:33.709044
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create an inventory
    inventory = AnsibleInventory(loader, variable_manager, host_list)
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create a dict from hostvars (for checking if __iter__ returns the same hosts)
    hostvars_dict = dict(hostvars)

    # Check if __iter__ returns the same hosts as in the inventory
    for host in hostvars:
        assert host.name in hostvars_dict


# Generated at 2022-06-22 14:33:37.926372
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class Inventory:
        def __init__(self):
            self.hosts = ['foo']

    class VariableMgr:
        def __init__(self):
            self._hostvars = {}

    hv = HostVars(Inventory(), VariableMgr(), None)
    assert(list(hv) == ['foo'])

# Generated at 2022-06-22 14:33:42.983035
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # In order to test behavior of HostVars.raw_get() we need to create
    # a mock class for it, because HostVars depends on several variables
    # that are hard to instantiate in unit tests.
    class HostVarsMock(HostVars):

        def __init__(self):
            self._hostvars = {}
            self._hostvars['localhost'] = self._hostvars['127.0.0.1'] = {
                'variable1': 'localhost',
                'variable2': 42,
                'variable3': [1, 2, 3],
                'variable4': { 'list' : [1, 2, 3], 'int' : 42, 'str' : 'localhost' },
            }


# Generated at 2022-06-22 14:33:53.295989
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import os

    inventory = InventoryManager(loader=C.DEFAULT_LOADER, sources=C.DEFAULT_HOST_LIST)
    inventory.subset("test_host")
    inventory.extra_vars = {}

    variable_manager = VariableManager(loader=C.DEFAULT_LOADER, inventory=inventory)

    vars_cache = HostVars(inventory, variable_manager, C.DEFAULT_LOADER)
    foo = vars_cache.get("test_host")


# Generated at 2022-06-22 14:34:04.875088
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import yaml

    # Test data

# Generated at 2022-06-22 14:34:11.619358
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.config.manager import ConfigManager
    config = ConfigManager('')._config

    loader_ = config.get_loader()
    variables = {'host1': 'one', 'host2': 'two'}
    hostvars_vars = HostVarsVars(variables, loader=loader_)
    assert set(hostvars_vars) == set(variables)

# Generated at 2022-06-22 14:34:22.267810
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.variables import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars

    output = dict(failed=False)
    loader = DataLoader()
    options = dict(connection='local', module_path=None, forks=100, become=None,
                   become_method=None, become_user=None, check=False, diff=False)
    variable_manager = VariableManager(loader=loader)
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    play_context = PlayContext()

    host_vars = HostVars(inv_manager, variable_manager, loader)

    inventory_name

# Generated at 2022-06-22 14:34:33.365021
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(host_list=[])
    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test case 1: Return data without running it through
    # the templating engine when hostname is found in inventory
    host_one = Host(name='one')
    inventory.add_host(host_one)
    hostvars.set_nonpersistent_facts(host_one, dict(foo='bar'))
    raw_data = hostvars.raw_get("one")
    assert "foo" in raw_data.keys()


# Generated at 2022-06-22 14:34:38.558657
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    import logging
    logging.basicConfig()

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    import ansible.inventory.manager
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources=None)

    hostvars = HostVars(inventory, variable_manager, loader)

    for host in hostvars:
        assert host

# Generated at 2022-06-22 14:34:46.881517
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible
    # Setup
    class Host(object):
        def __init__(self, name):
            self.name = name
    class Group(object):
        def __init__(self, name):
            self.name = name
            self.hosts = []
        def __iter__(self):
            for host in self.hosts:
                yield host
    class HostVarsVars2(object):
        def __init__(self, variables):
            self._vars = variables
    class Inventory(object):
        def __init__(self):
            self.hosts = []
            self.groups = {}
        def add_host(self, host, group_name=None):
            self.hosts.append(host)

# Generated at 2022-06-22 14:34:49.323698
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    # TODO: Add suitable test data. ansible/ansible#32135

    pass


# Generated at 2022-06-22 14:34:58.056234
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = []
    class Inventory():
        def get_host(self, name):
            if name == 'localhost' and not self.get_host(name):
                return Host('localhost')
        def get_hosts(self, pattern=None):
            if pattern is None:
                return inventory
            else:
                matched_hosts = []
                for host in inventory:
                    if pattern.match(host.name):
                        matched_hosts.append(host)
                return matched_hosts
        def get_groups(self, groupname=None):
            if groupname is None:
                return inventory
            else:
                matched_groups = []
                for group in inventory:
                    if groupname == group.name:
                        matched_groups.append(group)
                return matched_groups

# Generated at 2022-06-22 14:35:09.108501
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Ensure the correct values are returned after applying the templating engine.
    '''
    import collections

    # The first test doesn't use AnsibleUndefined
    loader = None
    variables = {'var1': 'value1', 'var2': 'value2'}
    hostvars_vars = HostVarsVars(variables, loader)
    assert hostvars_vars['var1'] == 'value1'
    assert hostvars_vars['var2'] == 'value2'

    # Now test with an AnsibleUndefined
    # Ensure that AnsibleUndefined is cast to a string, but only when
    # is the value of the hostvars_vars dict.
    inventory = collections.Mapping()
    variable_manager = collections.Mapping()

# Generated at 2022-06-22 14:35:19.440153
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    import sys

    class Host(object):
        def __init__(self, name):
            self.name = name
    class Inventory(object):
        def __init__(self, hosts=None):
            self.hosts = hosts or []
            self.vars = {}
        def get_host(self, host_name):
            for host in self.hosts:
                if host.name == host_name:
                    return host
            return None

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-22 14:35:24.573535
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.vars.manager import VariableManager

    vars_manager = VariableManager(loader=None)

    # Initialize HostVars with VariableManager
    hostvars = HostVars(inventory=None, loader=None, variable_manager=vars_manager)
    assert hostvars._variable_manager._loader == hostvars._loader
    assert hostvars._variable_manager._hostvars == hostvars

    # Now set state of the VariableManager to None
    # This can happen when un-pickling the vars_manager
    vars_manager._loader = None
    vars_manager._hostvars = None

    # Initialize HostVars with VariableManager again
    # This calls __setstate__ and should assign _loader and _hostvars to
    # the VariableManager as well as to HostVars
    hostv

# Generated at 2022-06-22 14:35:31.824092
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible.constants
    from ansible.vars.manager import VariableManager

    # Use in-memory inventory and fact cache
    fact_cache = {}
    inventory = ansible.inventory.Inventory(loader=ansible.parsing.dataloader.DataLoader())
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory, fact_cache=fact_cache)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Use in-memory vault secrets
    ansible.constants.hash_password('secret')
    vault_secrets = {
        'vault_password': ansible.parsing.vault.VaultLib.hash_password('secret'),
    }

    # Create an in-memory

# Generated at 2022-06-22 14:35:54.067297
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    '''
    The method raw_get must not expand variables in a hostvars.
    '''
    from ansible.inventory import Host, Inventory
    from ansible.vars import VariableManager

    i = Inventory(host_list=[])
    localhost = Host(name='localhost')
    i.get_host(localhost.get_name())

    i.set_variable(localhost.get_name(), 'test_var', '{{ other_var }}')
    i.set_variable(localhost.get_name(), 'other_var', '{{ test_var }}')

    v = VariableManager()
    h = HostVars(i, v, loader=None)
    vars = h.raw_get('localhost')

    assert vars['test_var'] == '{{ other_var }}'

# Generated at 2022-06-22 14:36:04.065381
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    h = HostVars({'a':1}, None, None)
    h.raw_get('a')

    # create instance of HostVars with _loader and _hostvars attributes assigned
    h = HostVars({'a':1}, None, None)
    h._variable_manager._loader = h._loader
    h._variable_manager._hostvars = h

    h_state = h.__getstate__()
    h2 = HostVars({'a':1}, None, None)
    h2.__setstate__(h_state)

    # _loader and _hostvars are not None
    assert h2._loader is not None
    assert h2._variable_manager._loader is not None
    assert h2._variable_manager._hostvars is not None

# Generated at 2022-06-22 14:36:06.952768
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({'a':1, 'b':2, 'c':3}, 'dummy')
    assert set(iter(hvv)) == set(['a', 'b', 'c'])

# Generated at 2022-06-22 14:36:14.923407
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    class MockInventory(object):
        def __init__(self):
            self.hosts = ['localhost', '127.0.0.1']

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    inventory._inventory = MockInventory()
    variable_manager = VariableManager()

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    hostvars_list = list(hostvars)
    hostvars_list.sort()

    assert hostvars_list == ['127.0.0.1', 'localhost']


# Generated at 2022-06-22 14:36:26.866892
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play import Play

    inventory = Inventory(host_list=[])
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    host = inventory.get_host('localhost')
    variable_manager.set_host_variable(host, "role_var", "value")

    hostvars = HostVars(inventory, variable_manager, loader=None)

    # raw_get should return host variables without doing variable expansion.
    result = hostvars.raw_get('localhost')
    assert isinstance(result, dict)
    assert 'role_var' in result
    assert result['role_var'] == 'value'
    assert 'localhost' not in result
   

# Generated at 2022-06-22 14:36:35.145353
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import pytest
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    cache_dir = 'tests/units/vars/cache/'
    inventory_path = 'tests/units/vars/hosts'

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=inventory_path))
    variable_manager._fact_cache = {'host': {'foo': 'bar'}}
    variable_manager._vars_cache

# Generated at 2022-06-22 14:36:45.330749
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader)
    variable_manager._loader = loader # Try to reproduce the case from Ansible 2.6.0

    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)

    assert variable_manager._loader == loader
    assert variable_manager._hostvars == hostvars

    state = hostvars.__getstate__()
    hostvars.__setstate__(state)

    assert variable_manager._loader == loader
    assert variable_manager._hostvars == hostvars

# Generated at 2022-06-22 14:36:56.636486
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = DataLoader()
    paths = 'tests/inventory_hostvars_vars'
    inventory = InventoryManager(loader=loader, sources=paths)

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars_vars = HostVarsVars(hostvars["a"], loader)

    result = list(hostvars_vars)

    assert "contacts" in result
    assert "http_port" in result
    assert "databases" in result
    assert "database" in result
    assert "passwords" in result


# Generated at 2022-06-22 14:37:02.500768
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()

    hostvars = HostVars(None, variable_manager, None)

    variable_manager._loader = None
    variable_manager._hostvars = None

    hostvars.__setstate__(hostvars.__getstate__())

    assert variable_manager._loader is not None
    assert variable_manager._hostvars is not None

# Generated at 2022-06-22 14:37:11.422181
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible import variable_manager

    # Create inventory
    inventory = Inventory(host_list=['host1', 'host2'])

    # Create variable_manager and add variables to the variable_manager
    variable_manager = variable_manager.VariableManager()
    variable_manager.extra_vars={'var1': 'val1', 'var2': 'val2'}

    # Create loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # Create HostVars and call method __repr__
    hostvars = HostVars(inventory, variable_manager, loader)
    repr = hostvars.__repr__()

    # Verify results

# Generated at 2022-06-22 14:37:34.081246
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os

    class Inventory(InventoryManager):
        def __init__(self):
            self.hosts = ['localhost1', 'localhost2']
            self._vars_per_host = {}
            self._vars_per_group = {}

    loader = DataLoader()
    path = os.path.join(os.path.dirname(__file__), 'vars')
    loader.set_basedir(path)
    inv = Inventory()
    vm = VariableManager(loader=loader, inventory=inv)
    hv = HostVars(inv, vm, loader)

    # The method __iter__ should

# Generated at 2022-06-22 14:37:46.005099
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Test __iter__ of class HostVars by calling it with variable manager
    # that loads an example inventory with different host names.
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources="/etc/ansible/hosts")
    variable_manager = VariableManager(loader=loader, inventory=inv)
    hostvars = HostVars(inventory=inv, variable_manager=variable_manager, loader=loader)
    assert len(list(hostvars)) == len(inv.get_hosts())
    assert set(hostvars) == set(inv.get_hosts())


# Generated at 2022-06-22 14:37:52.027297
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    import os
    import json
    import yaml
    from ansible.inventory.manager import InventoryManager

    # Setup
    inventory_file = 'test/unit/module_utils/test_hostvars.inventory'
    data = {
        'inventory_file': inventory_file,
        'inventory_dir': os.path.dirname(inventory_file),
        'vars': {
            'hostvar1': 'hostvar1',
            'hostvar2': 'hostvar2',
        },
        'groups': {
            'group1': ['host1'],
            'group2': ['host1', 'host2'],
            'group3': ['host1', 'host2', 'host3'],
        },
    }

    # Act

# Generated at 2022-06-22 14:38:02.650447
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.module_utils.six import PY3
    from ansible.inventory import Inventory, Host

    # Construct an inventory
    inventory = Inventory(host_list=[])
    inventory.add_host(Host(name="foobar1"))
    inventory.add_host(Host(name="foobar2"))
    inventory.add_host(Host(name="foobar3"))

    # Construct a VariableManager
    from ansible.vars import VariableManager
    var_manager = VariableManager()

    # Set variables for each host
    hv_foobar1 = dict(foo=1, bar=1)
    var_manager.set_host_variable(inventory.get_host('foobar1'), "foo", hv_foobar1['foo'])

# Generated at 2022-06-22 14:38:05.641042
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.template import Templar

    raw_vars = {"a": "{{ b }}", "b": "{{ c }}", "c": 1}
    templar = Templar({}, convert_bare=False)

    hostvars = HostVars({}, {}, {})
    hostvars._variable_manager = templar

    assert eval(hostvars.__repr__()) == {None: {"a": 1, "b": 1, "c": 1}}

# Generated at 2022-06-22 14:38:17.152953
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import copy

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory import Inventory

    inventory = Inventory(loader=None, variable_manager=None, host_list=[])

    # create VariableManager with Loader and HostVars to pickle
    loader = _DummyLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=variable_manager)

    # pickle and restore vars_cache data
    pickled_data = copy.dumps(hostvars)
    unpickled_data = copy.loads(pickled_data)

    # unpickled hostvars should have updated VariableManager set
    assert unpickled_data._variable_manager._loader is not None

# Generated at 2022-06-22 14:38:23.256713
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager

    # instance of HostVars
    hostvars = HostVars(None, None, None)

    # call __setstate__ with a random state
    hostvars.__setstate__({
        '_inventory': 'foo',
        '_variable_manager': VariableManager(),
    })

# Generated at 2022-06-22 14:38:36.276036
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from pytest import raises

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    host = inventory.get_host('localhost')
    variables = {
        'apples': 'x',
        'oranges': '{{ apples }}'
    }
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._host_vars_plugins = []
    variable_manager._add_host_vars_from_inventory(host, variables)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-22 14:38:46.291581
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    import os

    class TestInventory(InventoryManager):
        def __init__(self):
            self.hosts = []

        def add_group(self, group_name):
            pass

        def set_variable(self, host, varname, value):
            pass

        def add_host(self, host_name, group=None, port=None):
            self.hosts.append(Host(host_name))

    inventory = TestInventory()
    loader = DataLoader()
    variable_manager = VariableManager(loader, inventory)

# Generated at 2022-06-22 14:38:56.237649
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    my_inventory = InventoryManager(loader=DataLoader(), sources=['tests/inventory'])
    my_vars = my_inventory.get_vars()
    my_vars['inventory_hostname'] = 'foobar'
    my_variable_manager = VariableManager(loader=DataLoader(), inventory=my_inventory)

    my_hostvars = HostVars(my_inventory, my_variable_manager, DataLoader())
    templar = Templar(loader=DataLoader())

# Generated at 2022-06-22 14:39:39.109382
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({})
    inv = InventoryManager(loader=loader)
    inv.add_host("localhost")
    inv.add_host("otherhost")
    inv.get_host("localhost").vars["bar"] = "baz"
    inv.get_host("otherhost").vars["foo"] = "bar"
    variable_manager = VariableManager(loader=loader, inventory=inv)
    variable_manager.set_inventory(inv)
    hostvars = HostVars(variable_manager=variable_manager, loader=loader, inventory=inv)


# Generated at 2022-06-22 14:39:50.947469
# Unit test for method __getitem__ of class HostVars

# Generated at 2022-06-22 14:39:57.436158
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.plugins.loader import variable_manager

    _hosts = variable_manager.hostvars['localhost']
    _list = list(_hosts)

    for _var in _list:
        if '.' in _var:  # Skip variables with a dot in it.
            continue

        if isinstance(_hosts[_var], AnsibleUndefined):
            print("%s: %r" % (_var, _hosts[_var]))
        else:
            print("%s: %s" % (_var, _hosts[_var]))


# Generated at 2022-06-22 14:40:10.045742
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    '''
    Test that HostVars.__iter__() returns an iterator over HostVars._inventory.hosts
    '''
    from ansible.inventory import Inventory
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(host_list=[])
    inventory._hosts_cache = ['host1', 'host2', 'host3']
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    templ

# Generated at 2022-06-22 14:40:15.214988
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    group = Group(loader=loader)
    group.add_host(group, 'test.example.com')
    vars_cache = {'test.example.com': 'test'}

    result = HostVars(inventory=group, variable_manager=None, loader=loader).__repr__()
    assert result == vars_cache


# Generated at 2022-06-22 14:40:26.816496
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory import Host, Group

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = DummyVariableManager()

    # Create localhost and dummy_group
    localhost = Host(name='localhost')
    inventory._inventory.add_host(localhost)
    dummy_group = Group(name='dummy_group')
    inventory._inventory.add_group(dummy_group)

    # Add localhost to dummy_group
    dummy_group.add_host(localhost)

    # Add vars to dummy_group
    dummy_group_vars = dict()
    dummy_group_vars['group_var'] = 'group_var_value'
    dummy_group.set_variable('group_var', 'group_var_value')
   

# Generated at 2022-06-22 14:40:37.494097
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleUndefinedVariable

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    context = PlayContext()
    context._vars_cache = {
        'localhost': {
            'hostvars_test': 'foo',
        }
    }

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_variable_manager(variable_manager)
    hostvars.set_inventory(inventory)

   

# Generated at 2022-06-22 14:40:47.759151
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # Temporary directories and files
    import tempfile
    import shutil
    import os
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 14:40:57.512913
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    inv = dict(all=dict(hosts=dict()))
    loader = None
    var_mgr = dict()
    hv = HostVars(inv, var_mgr, loader)

    # Case 01: host was found
    hostname = 'foo'
    var_mgr['bar'] = 'baz'
    inv['all']['hosts'][hostname] = hostname
    inv['all']['vars'] = dict(foo='bar')
    var_mgr[hostname] = dict(foo='bar')
    # call function
    foo = hv['foo']
    # test result
    assert isinstance(foo, HostVarsVars)
    assert foo['bar'] == 'baz'
    assert foo['foo'] == 'bar'

    # Case 02: host was not found
   

# Generated at 2022-06-22 14:41:01.289791
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    h = HostVars(inventory=None, variable_manager=None, loader=None)
    iter(h)


# Generated at 2022-06-22 14:41:47.151082
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    loader = Mock(name='mock_loader')
    inventory = Inventory(loader)
    variable_manager = VariableManager(loader)

    host1 = Mock(name='host1', spec=['name'])
    host1.name = 'host1'
    host2 = Mock(name='host2', spec=['name'])
    host2.name = 'host2'
    inventory.hosts = [host1, host2]

    # Create vars_cache
    variable_manager.get_vars(host=host1, include_hostvars=False)
    variable_manager.get_vars(host=host2, include_hostvars=False)

    # Create HostVars

# Generated at 2022-06-22 14:41:59.130006
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hostvars = HostVars(None, VariableManager(loader=loader), loader=loader)
    hostvars.__setstate__({ '_inventory': None, '_loader': loader, '_variable_manager': VariableManager() })

    assert hostvars._inventory is None
    assert hostvars._loader is loader
    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

    class FakeInventory():
        def __init__(self):
            self.hosts = ['localhost']
        def get_host(self, host_name):
            if host_name == 'localhost':
                return host_name

   

# Generated at 2022-06-22 14:42:10.959064
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create fake inventory for testing
    fake_host_name = 'fake_host'
    fake_hosts = [fake_host_name]
    fake_inventory = InventoryManager(loader=DataLoader(), sources=fake_hosts)
    fake_variable_manager = VariableManager(loader=DataLoader(), inventory=fake_inventory)

    # Create HostVars object
    host_vars = HostVars(inventory=fake_inventory,
                         variable_manager=fake_variable_manager,
                         loader=DataLoader())

    # Check that raw_get works for fake host

# Generated at 2022-06-22 14:42:23.030817
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager()
    vars = VariableManager()
    host_vars = HostVars(inventory, vars, None)

    host_1 = Host('localhost')
    host_2 = Host('localhost')

    assert hasattr(host_1, 'vars') is False
    assert hasattr(host_2, 'vars') is False

    host_1.vars['test_key'] = 'test_value'
    host_2.vars['test_key'] = 'test_value_2'

    inventory.add_host(host_1)
    inventory.add_host(host_2)

    hosts = []

# Generated at 2022-06-22 14:42:26.302063
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    h = HostVars({
        'foo': '$bar',
        'bar': 'baz'
    })

    print(h['foo'])
    # Output:
    #   baz



# Generated at 2022-06-22 14:42:35.915008
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_variable(inventory.get_host('ungrouped'), 'foo', 'bar')

    # test if can get hostvars in raw format
    host_name = 'ungrouped'
    raw_hostvars = hostvars.raw_get(host_name)
    assert('foo' in raw_hostvars)
    assert(raw_hostvars['foo'] == 'bar')

    # test if can

# Generated at 2022-06-22 14:42:46.848565
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, vars_manager, loader)

    # test an undefined host
    assert isinstance(hostvars.raw_get('unknown_host'), AnsibleUndefined)

    # test a defined host with a single value
    vars_manager.set_nonpersistent_facts(inventory.get_host('localhost'), {'ansible_all_ipv4_addresses': ['10.0.0.1']})