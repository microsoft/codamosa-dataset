

# Generated at 2022-06-22 14:33:00.338864
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    hosts_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_hosts')
    inventory = InventoryManager(loader=None, sources=hosts_path)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = dict(foo='bar')

    templar = Templar(variable_manager=variable_manager)
    variable_manager._hostvars = hostvars

    # test hostvars.get(host_name)

# Generated at 2022-06-22 14:33:11.675153
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import strategy_loader, module_loader
    from ansible.inventory.manager import InventoryManager

    # Set up basic classes
    pc = PlayContext()
    ldr = loader.DataLoader()
    strategy = strategy_loader.get('linear')
    strategy.set_loader(ldr)
    strategy.set_inventory(InventoryManager(loader=ldr, sources=['tests/inventory']))
    strategy.set_variable_manager(variable_manager.VariableManager(loader=ldr, inventory=strategy.inventory))
    tqm = TaskQueueManager(
        inventory=strategy.inventory,
        variable_manager=strategy.variable_manager,
        loader=ldr,
        options=pc,
        passwords={},
    )

    # Create

# Generated at 2022-06-22 14:33:21.365836
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    inventory = [
        {
            "name": "test_hostname",
            "groups": [
                "test_group1",
                "test_group2",
                "test_group3",
            ],
            "vars": {
                "test_var1": "test_value1",
                "test_var2": "test_value2",
                "test_var3": "test_value3",
            },
        },
        {
            "name": "test_hostname2",
            "groups": [
                "test_group4",
            ],
        }
    ]

    vars_manager = VariableManager(loader=None)
    loader = None
    hostvars = HostV

# Generated at 2022-06-22 14:33:28.999506
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle
    loader = None
    inventory = None

    def MethodPickleHostVars(original):
        pickled = pickle.dumps(original)
        unpickled = pickle.loads(pickled)
        return unpickled

    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)
    assert variable_manager._loader is not None
    assert variable_manager._hostvars is not None
    assert variable_manager._loader is hostvars._loader
    assert variable_manager._hostvars is hostvars

    # Set the pickled variable manager
    variable_manager_pickled = MethodPickleHostVars(variable_manager)
    hostvars.set_variable_manager(variable_manager_pickled)
   

# Generated at 2022-06-22 14:33:38.464339
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import ansible.utils.unsafe_proxy as unsafe_proxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    loader = DataLoader()
    vault_secrets = VaultLib(password_files=[], secrets=dict())
    inventory = InventoryManager(loader, variables=dict(), vault_secrets=vault_secrets)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host_vars = HostVars(inventory, variable_manager, loader)

    res = host_vars.__repr__()
    assert isinstance(res, str)


# Generated at 2022-06-22 14:33:44.790360
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    inventory = Inventory(host_list=[])

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    # Test repr of an empty HostVars
    hostvars = HostVars(inventory, variable_manager, variable_manager._loader)
    assert repr(hostvars) == '{}'

    # Test repr of a filled HostVars
    hostvars.set_variable_manager(variable_manager)

    inventory.add_host(host="dummy")
    variable_manager.set_nonpersistent_facts(
        inventory.get_host("dummy"),
        {"ansible_facts": {"test1": "value1"}},
    )


# Generated at 2022-06-22 14:33:49.981554
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    m = InventoryManager(loader='/usr/share/ansible_hosts')
    v = VariableManager(loader=m)
    h = HostVars(inventory=m, variable_manager=v, loader=m)

    print(repr(h))

# Generated at 2022-06-22 14:33:56.792422
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import ansible.plugins.loader
    import ansible.template
    import ansible.vars

    hv = HostVars({}, None, None)

    # This is needed because when HostVars is not pickled, the methods
    # __getstate__ and __setstate__ initialise the attributes
    # _loader and _hostvars to None.
    #
    # When assigning loader, load it from the plugins loader and not
    # ansible.loader.Loader, to avoid forcing the import of
    # ansible.loader.Loader and its dependencies.
    hv._loader = ansible.plugins.loader.get_loader_class()()

    assert hv._variable_manager._loader is None
    assert hv._variable_manager._hostvars is None

    hv.__setstate__({})

    # Verify _variable_manager

# Generated at 2022-06-22 14:34:06.514420
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import copy

    from ansible.errors import AnsibleAssertionError
    from ansible.template import Templar, TemplarException

    assert all(type(x) == str for x in Templar._MATCH_NONVAR)
    assert all(type(x) == str for x in Templar._MATCH_FIRST_VAR)

    variables = {'foo': 'bar', 'baz': 'qux'}

    loader = object()

    iterable = HostVarsVars(variables, loader)

    assert set(iterable) == set(variables.keys())
    assert len(set(iterable)) == len(set(variables.keys()))

    assert all(type(x) == str for x in iterable)

    variables_copy = copy.deepcopy(variables)

    assert variables == variables_copy

# Generated at 2022-06-22 14:34:18.163544
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Define a global and a local variable
    global_vars = dict(
        var_global='global',
    )

    hostvars = dict(
        var_to_expand='{{ var_global }}',
    )

    # Create necessary objects
    loader = DictDataLoader({
        'group_vars/all': YAMLLoader(None, dict(
            var_global='global',
        )).get_data(),
    })

    inventory = Inventory(loader=loader)
    inventory.add_host('localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create HostVars
    hv = HostVars(inventory, variable_manager, loader)

    # Test HostVars.__getitem__

# Generated at 2022-06-22 14:34:28.956352
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory, VariableManager(loader=loader), loader=loader)

    # Test empty HostVars
    assert hostvars['foo'] == {}, 'Empty HostVars did not return an empty dict.'

# Generated at 2022-06-22 14:34:33.946923
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    hv = HostVars({})

    assert hv._variable_manager._loader is not None
    assert hv._variable_manager._hostvars is hv

    hv.__setstate__({})

    assert hv._variable_manager._loader is hv._loader
    assert hv._variable_manager._hostvars is hv

# Generated at 2022-06-22 14:34:41.145139
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    class Host():
        def __init__(self):
            self.name = 'localhost'
    class Play():
        def __init__(self):
            self.hosts = ['localhost']
    class Inventory():
        def __init__(self):
            self.hosts = [Host()]
        def get_hosts(self, pattern="all"):
            return self.hosts
    class Playbook():
        def __init__(self):
            self.inventory = Inventory()
            self.variable_manager = VariableManager(loader=None, inventory=self.inventory)
            self.hostvars = HostVars(self.inventory, self.variable_manager, DataLoader())

# Generated at 2022-06-22 14:34:47.310210
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle

    # Setup
    loader = AnsibleLoaderStub()
    variable_manager = AnsibleVariableManagerStub()
    inventory = AnsibleInventoryStub()
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test
    pickle.dumps(hostvars)
    unpickled_hostvars = pickle.loads(pickle.dumps(hostvars))
    assert unpickled_hostvars._inventory == inventory
    assert unpickled_hostvars._loader == loader
    assert unpickled_hostvars._variable_manager == variable_manager


# Mock classes for testing HostVars class

# Generated at 2022-06-22 14:34:57.330688
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    hosts = ["h1", "h2"]

    class DummyInventory(object):
        hosts = hosts
        def __init__(self):
            pass
        def get_host(self, host_name):
            if host_name in hosts:
                return host_name
            return None

    loader = DummyLoader()
    vm = DummyVariableManager()
    vm._hostvars = None # DummyVariableManager does not have this variable defined
    vm._loader = None # DummyVariableManager does not have this variable defined
    inventory = DummyInventory()
    hostvars = HostVars(inventory, vm, loader)

    # Pickles HostVars and unpickles it again.
    # Check that the following attributes are preserved:
    # _inventory, _loader, _variable_manager

# Generated at 2022-06-22 14:35:08.521885
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Parameters for instantiation of VariableManager
    inventory = dict(
        _meta=dict(
            hostvars=dict(
                test00='test00 value',
                test01='test01 value',
                test02='test02 value'
            )
        ),
        group00=dict(
            hosts=['test00', 'test01', 'test02']
        )
    )
    variable_manager = VariableManager()

    # Instantiate HostVars
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    # HostVars should include all hosts from

# Generated at 2022-06-22 14:35:18.844663
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import json

    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    loader = None
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    inventory.add_host(Host("localhost", port=22))
    hostvars = HostVars(inventory, variable_manager, loader)

    vars = hostvars.raw_get('localhost')
    assert vars == {'ansible_inventory_sources': ['localhost,'],
                    'ansible_inventory_sources_list': ['localhost,'],
                    'inventory_hostname': 'localhost',
                    'inventory_hostname_short': 'localhost'}

    vars = hostvars.raw_

# Generated at 2022-06-22 14:35:24.844742
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources='localhost,')
    hostvars = HostVars(inventory, variables, loader)
    hostvars.raw_get('localhost')

# Generated at 2022-06-22 14:35:31.979577
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from .manager import VariableManager

    # see if HostVars properly restores _loader and _hostvars for VariableManager
    hostvars = HostVars(inventory=None, variable_manager=VariableManager(loader=None), loader=None)

    try:
        hostvars._variable_manager._loader
    except AttributeError:
        assert False

    try:
        hostvars._variable_manager._hostvars
    except AttributeError:
        assert False

    # delete _loader and _hostvars attributes
    del hostvars._variable_manager._loader
    del hostvars._variable_manager._hostvars

    # ensure they were deleted
    try:
        hostvars._variable_manager._loader
    except AttributeError:
        pass
    else:
        assert False


# Generated at 2022-06-22 14:35:39.386845
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import ansible.inventory
    inv = ansible.inventory.Inventory(['localhost'])
    inv.set_variable('foo', 'bar')
    inv.add_host(ansible.inventory.Host(name='localhost'))
    vm = ansible.vars.VariableManager(loader=None)
    vm.set_inventory(inv)
    hv = HostVars(inventory=inv, variable_manager=vm, loader=None)

    assert len(hv) == 1
    assert [x for x in hv] == ['localhost']


# Generated at 2022-06-22 14:35:48.823370
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    assert sorted(HostVarsVars({'a': 1, 'b': 2}, None)) == sorted(['a', 'b'])
    assert sorted(HostVarsVars({'a': 1, 'b': 2, 'c': 3}, None)) == sorted(['a', 'b', 'c'])


# Generated at 2022-06-22 14:35:58.946154
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.vars.unsafe_proxy
    import ansible.template.safe_eval
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.parsing.yaml.objects
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.connection
    import jinja2

    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVars


# Generated at 2022-06-22 14:36:08.669004
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle

    # Create fake objects
    variable_manager = object()
    state = dict()
    loader = object()

    # Create HostVars and call __setstate__
    hostvars = HostVars(None, variable_manager, loader)
    hostvars.__setstate__(state)

    # Check that _loader and _hostvars were assigned to VariableManager
    assert hostvars._variable_manager._loader == loader
    assert hostvars._variable_manager._hostvars == hostvars

    # Call __setstate__ again, but this time provide _loader and _hostvars
    # in state to check that assigning is skipped
    hostvars.__setstate__(state)

    # Check that _loader and _hostvars were not reassigned
    assert hostvars._variable_manager._loader == loader


# Generated at 2022-06-22 14:36:12.663733
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class _Loader:
        def load_from_file(*args, **kwargs):
            return dict()

    variables = dict(
        foo=1,
        bar=dict(baz=2),
    )
    hostvarsvars = HostVarsVars(variables, _Loader())
    assert set(hostvarsvars) == set(['foo', 'bar'])

# Generated at 2022-06-22 14:36:22.823613
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    vm = HostVars({}, {}, {})
    assert vm._variable_manager._loader is None
    assert vm._variable_manager._hostvars is None
    vm.__setstate__({
        "_inventory": "inventory",
        "_loader": "loader",
        "_variable_manager": {
            "_inventory": "inventory",
            "_loader": None,
            "_hostvars": None,
        },
    })
    assert vm._inventory == "inventory"
    assert vm._loader == "loader"
    assert vm._variable_manager._inventory == "inventory"
    assert vm._variable_manager._loader == "loader"
    assert vm._variable_manager._hostvars is vm

# Generated at 2022-06-22 14:36:30.863266
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory())

    hostvars = HostVars(variable_manager.get_inventory(), variable_manager, None)

    variable_manager._loader = None
    variable_manager._hostvars = None

    hostvars.__setstate__(hostvars.__getstate__())

    assert variable_manager._loader is not None
    assert variable_manager._hostvars is not None

# Generated at 2022-06-22 14:36:37.773388
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = vars_loader.VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    for host in hostvars:
        pass

# Generated at 2022-06-22 14:36:47.554519
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader)
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=vars_manager, loader=loader)

    # Methods __getstate__ and __setstate__ of VariableManager do not
    # preserve _loader and _hostvars attributes to improve pickle
    # performance and memory utilization. Since HostVars holds values
    # of those attributes already, assign them if needed.
    hostvars_state = hostvars.__getstate__()
    assert hostvars_state['_variable_manager']._loader is None
   

# Generated at 2022-06-22 14:37:00.091146
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import unittest
    import ansible.utils.shlexsplitter as shlex

    class HostVarsTest(unittest.TestCase):
        def setUp(self):
            # GIVEN
            self.host_vars_instance = HostVars([], [], [])
            # use private _find_host method of HostVars instance
            self.host_vars_instance._find_host = lambda host_name: host_name
            # create fake inventory.hosts containing three hosts
            self.host_vars_instance._inventory.hosts = [
                "host1",
                "host2",
                "host3",
            ]

        def test_iter(self):
            # WHEN
            hosts = [host for host in self.host_vars_instance]
            # THEN
            self.assertEqual

# Generated at 2022-06-22 14:37:10.143072
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'omit': 'xxx'}

    inventory = Inventory(loader=DataLoader(), variable_manager=variable_manager)

    hostvars = HostVars(inventory, variable_manager, DataLoader())

    assert repr(hostvars) == "{}"

    inventory.add_host('example.com')
    hostvars.set_host_variable('example.com', 'foo', 'bar')

# Generated at 2022-06-22 14:37:25.296321
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.playbook import Playbook
    from ansible.plugins import loader as plugin_loader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.constants import DEFAULT_HOST_LIST

    variable_manager = VariableManager()
    loader = plugin_loader.get('loader', 'file')
    inventory = InventoryManager(loader, sources=[DEFAULT_HOST_LIST])

    playbook = Playbook.load('example.yml', variable_manager=variable_manager, loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['foobar'] == {'foo': 'bar'}

# Generated at 2022-06-22 14:37:34.598463
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # create inventory and add localhost
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create HostVars object
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

    # verify the hostvars do not contain the host
    assert 'localhost' not in hostvars
    assert 'localhost' not in hostvars._variable_manager._vars_cache

    # set hostvars for localhost

# Generated at 2022-06-22 14:37:46.696850
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    source = "localhost ansible_ssh_user=testuser"
    inventory = InventoryManager(loader=DataLoader(), sources=source)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())


# Generated at 2022-06-22 14:37:57.413990
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(None, play_context={})
    inventory.add_group('thegroup')
    inventory.add_host(Host('example.com'))
    inventory.add_host(Host('example.org'))

    play = Play()
    play.hosts = 'thegroup'
    play._inventory = inventory
    h = HostVars(inventory, None, None)
    assert(len(list(h)) == 2)
    assert('example.com' in h)
    assert('example.org' in h)

# Generated at 2022-06-22 14:38:07.501697
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import pytest

    class FakeInventory():

        def __init__(self, hosts):
            self._hosts = hosts

        def hosts(self):
            return self._hosts

    class FakeVariableManager():

        def __init__(self, variables):
            self._variables = variables

        def get_vars(self, host=None, include_hostvars=True):
            if host is None:
                return self._variables
            return self._variables.get(host)

    class FakeHost():

        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name


# Generated at 2022-06-22 14:38:18.609753
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    # create dummy inventory
    class DummyInventory:
        def __init__(self, names):
            self._name_to_host = {name: DummyInventoryHost(name) for name in names}

        def get_host(self, host_name):
            return self._name_to_host.get(host_name)

        def get_hosts(self, pattern):
            return (host for host in self._name_to_host.values() if pattern in host)

        @property
        def hosts(self):
            return self._name_to_host.values()

    # create dummy inventory host
    class DummyInventoryHost:
        def __init__(self, name):
            self._name = name

        @property
        def name(self):
            return self._name

    # create dummy variable manager and loader

# Generated at 2022-06-22 14:38:28.206787
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    host = inventory.get_host("localhost")
    hostvars._variable_manager.set_host_variable(host, "foo", "bar")

    myhostvars = hostvars["localhost"]

    assert "foo" in myhostvars
    assert myhostvars["foo"] == "bar"

# Generated at 2022-06-22 14:38:37.789155
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import os
    import tempfile
    import textwrap
    import yaml

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create inventory
    inventory = InventoryManager(loader=DataLoader(), sources=None)

    # Create variables
    variable_manager = VariableManager(loader=DataLoader())
    variable_manager.set_inventory(inventory=inventory)

    # Create temporary file
    (fd, path) = tempfile.mkstemp(text=True)
    os.write(fd, ''.join([
        '---\n',
        'foo: "{{ bar }}"\n',
        'bar: baz\n',
        '\n',
    ]).encode('utf-8'))

# Generated at 2022-06-22 14:38:44.239049
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars = HostVars('', '', '')
    hostvars._variable_manager = type("", (object,), {})()
    hostvars._variable_manager.get_vars = lambda x, y: {'k1': 'v1', 'k2': 'v2'}
    assert sorted(['k1', 'k2']) == sorted(list(hostvars.__getitem__('host').__iter__()))

# Generated at 2022-06-22 14:38:45.104794
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    pass



# Generated at 2022-06-22 14:38:59.487042
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({}, None)

    assert set(hvv) == set(['hostvars'])

    hvv = HostVarsVars({'foo': 1}, None)

    assert set(hvv) == set(['foo', 'hostvars'])

    hvv = HostVarsVars({'foo': 1, 'bar': 2}, None)

    assert set(hvv) == set(['foo', 'bar', 'hostvars'])

# Generated at 2022-06-22 14:39:10.743653
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    test_filename = 'test_hostvars_vars__getitem__.yml'
    test_variables = {u'a': u'b'}

    # Setup single group with single host
    test_host = '127.0.0.1'
    test_group = 'test_group'
    test_host_variables = {u'a': u'var_a', u'b': u'var_b'}

    inventory = InventoryManager(loader = DataLoader(), sources=test_filename)
    inventory.parse_inventory_sources(inventory, cache=False)

    test_group_obj = inventory.groups[test_group]
    test

# Generated at 2022-06-22 14:39:20.465431
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create inventory
    inventory = InventoryManager(loader=None, sources='')

    # Create variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create HostVars
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    # Create HostVarsVars
    hostvarsvars = HostVarsVars(variables=hostvars, loader=None)

    assert set(hostvarsvars) == set(variable_manager.get_vars(host=None, include_hostvars=False).keys())

# Generated at 2022-06-22 14:39:28.155727
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    host_vars = HostVars(
        inventory=InventoryManager(loader=DataLoader(), sources='local'),
        variable_manager=VariableManager(loader=None, inventory=None),
        loader=DataLoader(),
    )

    assert host_vars.__getitem__('foo') is AnsibleUndefined
    assert host_vars.raw_get('foo') is AnsibleUndefined

# Generated at 2022-06-22 14:39:34.286485
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    import sys

    class HostVarsInternal:
        def __init__(self, inventory, variable_manager, loader):
            self._inventory = inventory
            self._loader = loader
            self._variable_manager = variable_manager

        def set_variable_manager(self, variable_manager):
            self._variable_manager = variable_manager

        def set_inventory(self, inventory):
            self._inventory = inventory

        def _find_host(self, host_name):
            return self._inventory.get_host(host_name)

        def __getitem__(self, host_name):
            host = self._

# Generated at 2022-06-22 14:39:44.130238
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    m_inventory = MagicMock(spec=Inventory)
    m_inventory.hosts.__iter__.return_value = ["foo", "bar", "baz"]
    m_loader = MagicMock(spec=DataLoader)
    m_vars_cache = {"foo": {"a": 1, "b": 2}, "bar": {"c": 3, "d": 4}, "baz": {"e": 5, "f": 6}}
    m_variable_manager = MagicMock(spec=VariableManager,
                                   vars_cache=m_vars_cache,
                                   _hostvars=None)
    hv = HostVars(m_inventory, m_variable_manager, m_loader)
    repr_string = repr(hv)


# Generated at 2022-06-22 14:39:55.849858
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import sys
    import os
    sys.path.append(os.path.dirname(__file__) + "/../")
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.plugins import inventory as inventory_plugin
    # Create an instance of the base inventory plugin
    inventory_plugin_class = inventory_plugin.BaseInventoryPlugin
    # Create a class which extends the base inventory plugin class and overrides method parse with a dummy parse
    class DummyInventoryPluginClass(inventory_plugin_class):
        def parse(self, inventory, loader, path, cache=True):
            self.hosts = ['h1', 'h2', 'h3']

    # Create an instance of the above class
    dummy_inventory_plugin_

# Generated at 2022-06-22 14:40:06.260000
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    templar = Templar(loader=None)

    my_host_vars = HostVars({'ansible_ssh_host': 'x.y.z.t', 'fake_var': '{{ ansible_ssh_host }}'}, templar)

    # Accessing a non-AnsibleUndefined variable
    assert isinstance(my_host_vars['fake_var'], Mapping)
    assert my_host_vars['fake_var'] == {'fake_var': 'x.y.z.t'}

    # Accessing an AnsibleUndefined variable
    assert isinstance(my_host_vars['undefined'], AnsibleUndefined)

# Generated at 2022-06-22 14:40:15.458076
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    class DummyInventory(object):
        def __init__(self):
            pass

        def get_host(self, host_name):
            if host_name == 'local':
                return DummyHost()
            else:
                return None

    class DummyHost(object):
        def __init__(self):
            self.name = 'local'
            self.get_variable = lambda x, self=self: 'local'
            self.vars = {'foo': 'bar'}


# Generated at 2022-06-22 14:40:25.150756
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    data = {
        'user_a': 'alpha',
        'user_b': 'beta',
    }
    vars_vars = HostVarsVars(data, loader=loader)

    assert set([x for x in vars_vars]) == set(['user_a', 'user_b'])
    assert set([x for x in vars_vars]) == set(['user_a', 'user_b'])

# Generated at 2022-06-22 14:41:24.156139
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a=1)

    variable_manager.set_nonpersistent_facts(None, dict(a=2))

    hostvars = HostVars(inventory, variable_manager, loader)

    # check if initial state is as expected
    assert variable_manager.extra_vars == dict(a=1)
    assert variable_manager._hostvars is hostvars
    assert variable_manager._loader is loader

    assert variable_manager.get_vars(host=None) == dict(a=2)

    # remove all that is expected to be pickled
    variable_manager._hostvars = None
    variable_manager._loader = None

    # pickle and unpickle

# Generated at 2022-06-22 14:41:34.893289
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Create HostVars object
    hostvars_object = HostVars(None, None, None)

    # Simulate hosts.get() for host 'x'
    class mHost(object):
        def __init__(self, name):
            self.name = name
    hostx = mHost('x')
    hosty = mHost('y')
    def mFind_host(self, host_name):
        if (host_name == 'x'):
            return hostx
        elif (host_name == 'y'):
            return hosty
        else:
            return None
    hostvars_object._find_host = mFind_host

    # Simulate get_vars
    vars_x = {'a':'1', 'b':'2'}

# Generated at 2022-06-22 14:41:42.942877
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory

    from ansible.vars.manager import VariableManager

    inv = Inventory(host_list=[])
    vm = VariableManager(loader=None, inventory=inv)

    hv = HostVars(inv, vm, None)

    assert [] == list(iter(hv))

    inv.add_host('host0')
    inv.add_host('host1')
    inv.add_host('host2')

    assert list(iter(hv)) == ['host0', 'host1', 'host2']

# Generated at 2022-06-22 14:41:46.991437
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host

    inventory = FakeInventory()
    inventory.get_host('some_host')
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)
    assert repr(hostvars) == repr({'some_host': 'some_value'})



# Generated at 2022-06-22 14:41:52.093313
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Test with empty inventory
    inventory = FakeInventory()
    variable_manager = FakeVariableManager()
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=FakeLoader())
    hostvars.set_variable_manager(variable_manager)

    expected = AnsibleUndefined(name="hostvars['localhost']")
    assert hostvars.raw_get('localhost') == expected, 'hostvars.raw_get() returned value {} instead of {}'.format(
        hostvars.raw_get('localhost'), expected)

    # Test with one host in inventory
    variable_manager._hostvars['localhost']['foo'] = 'bar'
    variable_manager._hostvars['localhost']['baz'] = 'qux'

# Generated at 2022-06-22 14:42:02.803170
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import pytest
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    def get_fake_inventory():
        fake_inventory = InventoryManager(loader=None, sources=[])
        localhost_group = fake_inventory.groups.create('localhost')
        localhost_group.add_host(fake_inventory.get_host('localhost'))
        test_group = fake_inventory.groups.create('test')
        test_group.add_host(fake_inventory.get_host('testhost'))
        return fake_inventory

    def get_fake_variable_manager(fake_inventory, hostvars):
        return VariableManager(loader=None, inventory=fake_inventory, hostvars=hostvars)


# Generated at 2022-06-22 14:42:14.458068
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from collections import namedtuple

    MockVars = namedtuple('MockVars', ['module_defaults'])
    MockModule = namedtuple('MockModule', ['params'])
    MockOptions = namedtuple('MockOptions', ['module_defaults', 'tags', 'skip_tags'])
    MockHost = namedtuple('MockHost', ['name', 'vars'])

    # case 1
    mockHost = MockHost(name='localhost', vars={'varA': 'valA'})
    mockHostVars = HostVars(mockHost, MockVars(MockModule(None)))
    assert mockHostVars.raw_get("localhost") == {'varA': 'valA'}

    # case 2

# Generated at 2022-06-22 14:42:18.031476
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    hostvars_iter = iter(hostvars)
    assert(next(hostvars_iter) is None)

# Generated at 2022-06-22 14:42:30.117640
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    import copy
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class MockVariableManager:

        def __init__(self, loader, inventory):
            self.loader = loader
            self.inventory = inventory

        def set_host_variable(self, host, varname, value):
            assert(host in self.inventory.hosts)
            self.inventory.hosts[host].vars[varname] = value

        def set_nonpersistent_facts(self, host, facts):
            assert(host in self.inventory.hosts)
            self.inventory.hosts[host].set_nonpersistent_facts(facts)

        def set_host_facts(self, host, facts):
            assert(host in self.inventory.hosts)
            self

# Generated at 2022-06-22 14:42:33.992014
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    inventory = MagicMock()
    inventory.hosts = ['HostA', 'HostB']
    loader = Mock()
    vars_manager = Mock()
    hvars = HostVars(inventory, vars_manager, loader)

    assert sorted(hvars) == inventory.hosts