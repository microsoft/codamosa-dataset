

# Generated at 2022-06-22 14:32:56.685744
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    inventory = FakeInventory()
    variable_manager = FakeVariableManager()
    hostvars = HostVars(inventory, variable_manager, None)

    actual = list(iter(hostvars))
    expected = [ inventory.hosts["host1"], inventory.hosts["host2"], inventory.hosts["host3"] ]
    assert actual == expected


# Generated at 2022-06-22 14:33:04.730345
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    assert HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader).raw_get('localhost') == {
        'inventory_hostname': 'localhost',
        'groups': {
            'ungrouped': {
                'hosts': ['localhost'],
                'vars': {}
            }
        }
    }


# Generated at 2022-06-22 14:33:14.790116
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager

    test_vars = {
        'foo': 'bar',
        'bat': ['baz', {'a': 'b'}, 'abc'],
        'ansible_version': '1.0'
    }

    inventory = InventoryManager(loader=None, sources=None, hosts=None)
    vm = FakeVariableManager(loader=None, inventory=inventory)
    vm.set_host_variable('testhost', 'testgroup', test_vars)
    vm.set_host_variable('testhost', 'testhost', test_vars)
    vm.set_host_variable('testhost', 'all', test_vars)

    hv = HostVars(inventory=inventory, variable_manager=vm, loader=FakeDataLoader())


# Generated at 2022-06-22 14:33:24.402505
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Mock objects for Inventory, VariableManager and DataLoader
    # are required for successful import of module `vars`
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.utils.vars import combine_vars

    host_vars = HostVars(inventory=InventoryManager(loader=None, sources=None),
                         variable_manager=VariableManager(loader=None, inventory=None),
                         loader=DataLoader())
    host_vars.set_variable_manager(VariableManager(loader=None, inventory=None))

    # Create dicts that will be used as hosts' variables and inventory vars
    host_vars_1 = {'a': '1'}
    host_vars_2

# Generated at 2022-06-22 14:33:30.741014
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['/dev/null'])

    # Create two hosts and add them to the inventory
    host1 = inventory.hosts.create("hostname")
    host2 = inventory.hosts.create("hostname2")

    inventory.hosts.add(host1)
    inventory.hosts.add(host2)

    # Add variables to the first host
    host1.set_variable('key1', 'value1')
    host1.set_variable('key2', 'value2')

    # Add variables to the second host
    host2.set_variable('key1', 'value3')
    host2.set_variable('key2', 'value4')
    host2.set

# Generated at 2022-06-22 14:33:39.807220
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader_mock = Mock()
    inventory_mock = Mock(spec=InventoryManager)
    inventory_mock.get_host.return_value = 'hoge'
    inventory_mock.hosts = ['hoge', 'fuga']
    variable_manager_mock = Mock(spec=VariableManager)
    variable_manager_mock.get_vars.return_value = {}

    hostvars = HostVars(inventory_mock, variable_manager_mock, loader_mock)
    assert list(hostvars) == ['hoge', 'fuga']
    assert list(hostvars.__iter__()) == ['hoge', 'fuga']

# Generated at 2022-06-22 14:33:45.646858
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    v = VariableManager()
    d = DataLoader()
    i = Inventory(loader=d, variable_manager=v, host_list=[])
    h = HostVars(inventory=i, variable_manager=v, loader=d)

    host = i.add_host("testhost")
    assert h.raw_get('testhost') == {}

    host.set_variable('var1', 'value')
    host.set_variable('var2', {'sub1': 1})
    host.set_variable('var3', ['item1'])

# Generated at 2022-06-22 14:33:48.152645
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    hv = HostVars(None, None, None)
    assert repr(hv) == "{}"

# Generated at 2022-06-22 14:33:55.904816
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.plugins.inventory import InventoryModule
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data = '''
[web]
192.168.1.1
[db]
192.168.1.2
192.168.1.3
    '''

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryModule(loader=loader)
    inventory.parse_inventory(data)
    variable_manager.set_inventory(inventory)

    hv = HostVars(inventory, variable_manager, loader)
    h = hv['192.168.1.1']
    assert isinstance(h, HostVarsVars)
    assert ('groups' in h)
    assert ('web' in h['groups'])

# Generated at 2022-06-22 14:34:06.201533
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.plugins.loader import action_loader, lookup_loader, module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.unicode import to_unicode
    import os
    import pickle
    import shutil

    data_path = 'data'
    if os.path.exists(data_path):
        shutil.rmtree(data_path)

    data_path_subdir_1 = os.path.join(data_path, 'subdir1')
    data_path_subdir_2 = os.path.join(data_path, 'subdir2')

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_

# Generated at 2022-06-22 14:34:19.344552
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')

    # create a temporary variable manager object
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    # create a temporary hostvars object
    hostvars = HostVars(inventory, variable_manager, DataLoader())

    # Add a host and associated variables to the hostvars object
    host = 'localhost'
    hostvars[host]['var1'] = 'value1'

    # Test method __getitem__ of HostVars
    # Expected result: Call to hostvars.__getitem__() returns a dict with a single

# Generated at 2022-06-22 14:34:29.584872
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Create a fake inventory
    inventory = Inventory(host_list=['localhost'])
    inventory.get_host('localhost').vars = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'g': 'f'}

    # Create a fake play

# Generated at 2022-06-22 14:34:38.821273
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import copy
    class FakeInventory(object):
        def __init__(self):
            self.hosts = [
                'localhost',
                '127.0.0.1',
                '192.168.56.101'
            ]

        def get_host(self, host_name):
            if host_name in self.hosts:
                return FakeHost(host_name, self)
            else:
                return None

    class FakeHost(object):
        def __init__(self, name, inventory):
            self.name = name
            self.vars = {
                "a": "{{ b }}",
                "b": "{{ c }}",
                "c": "{{ d }}",
                "d": "{{ e }}",
                "e": "foo",
            }
            self.inventory = inventory



# Generated at 2022-06-22 14:34:47.020092
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()

    inv_manager = InventoryManager(loader=loader)
    inv = inv_manager.get_inventory_from_source('localhost,')
    var_mgr = VariableManager(loader=loader, inventory=inv)

    hvars = HostVars(inventory=inv, variable_manager=var_mgr, loader=loader)

    host = inv.get_host("localhost")
    var_mgr.set_host_variable(host, 'foo', 'bar')

    # localhost has not been created yet

# Generated at 2022-06-22 14:34:57.049575
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    inventory = dict(
        hosts = dict(
            localhost = dict(),
            host2 = dict(),
            host3 = dict(),
        ),
    )

    cached_vars = dict(
        localhost = dict(
            foo = "bar",
        ),
        host2 = dict(
            foo2 = "bar2",
        ),
        host3 = dict(
            foo3 = "bar3",
        ),
    )

    vars_manager = dict(
        _hostvars = dict(),
        get_vars = lambda self, host, include_hostvars=True: cached_vars[host],
    )

    hostvars = HostVars(inventory, vars_manager, None)

    assert list(hostvars) == ['host3', 'host2', 'localhost']

# Generated at 2022-06-22 14:35:08.240099
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host_vars = HostVars(inventory, variable_manager, loader)
    assert host_vars.raw_get('127.0.0.1') == {}
    assert host_vars.raw_get('localhost') == {}
    variable_manager.set_host_variable('127.0.0.1', 'var', 'value')
    assert host_vars.raw_get('127.0.0.1') == {'var': 'value'}
    assert host_

# Generated at 2022-06-22 14:35:12.657875
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = DictDataLoader({})
    variables = { 'a': 1, 'b': 2 }
    hostvars_vars = HostVarsVars(variables, loader)
    assert set(hostvars_vars) == set(variables)


# Generated at 2022-06-22 14:35:13.561430
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    assert HostVars({'a': {'b': 'c'}}) == {}

# Generated at 2022-06-22 14:35:18.495119
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    class Inventory():
        def __init__(self, cache):
            self.vars = cache

        def get_host(self, host_name):
            return self.vars.get(host_name, None)

    class VariableManager():
        # Inject cache from parent class
        def __init__(self, cache):
            self.vars = cache

        def get_vars(self, host=None, include_hostvars=True):
            # Implementation broken, returns only vars of localhost and same vars
            # regardless of host_name argument
            return self.vars.get('localhost', AnsibleUndefined())

        def set_host_variable(self, host, varname, value):
            self.vars.setdefault(host, {})[varname] = value

    class Loader():
        pass



# Generated at 2022-06-22 14:35:26.170563
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Host

    # Test for empty HostVars
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    assert list(hv.__iter__()) == []

    # Test for non empty HostVars
    h1 = Host(name="host1")
    h2 = Host(name="host2")
    h3 = Host(name="host3")
    hv._inventory.hosts = [h1, h2, h3]
    assert list(hv.__iter__()) == [h1, h2, h3]

# Generated at 2022-06-22 14:35:40.646126
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Mocking
    class Inventory(object):
        def __init__(self):
            self.hosts = []
        def get_host(self, host_name):
            if not host_name in ['host1', 'host2']:
                return None
            class Host:
                def __init__(self):
                    self.name = host_name
            return Host()
    class VariableManager(object):
        def __init__(self):
            self._hostvars = None
            self._loader = None
        def get_vars(self, host=None, include_hostvars=True):
            if not host.name in ['host1', 'host2']:
                return AnsibleUndefined(name="hostvars['%s']" % host.name)
            if host.name == 'host1':
                return

# Generated at 2022-06-22 14:35:41.629571
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # TODO
    assert True

# Generated at 2022-06-22 14:35:48.114937
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars = {
        "hostvars": {
            "host1": {
                "host1var": "host1varvalue"
            },
            "host2": {
                "host2var": "host2varvalue"
            }
        }
    }
    hostvarsvars = HostVarsVars(hostvars, None)
    assert sorted(list(hostvarsvars)) == sorted(["host1", "host2"])

# Generated at 2022-06-22 14:35:50.345382
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    hh = HostVarsVars({'a': '{{ b }}', 'b': 'x'}, None)
    assert hh['a'] == 'x'


# Generated at 2022-06-22 14:36:00.724693
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    inventory = Inventory(host_list=[])
    variable_manager = VariableManager()
    play_context = PlayContext()

    hosts = HostVars(inventory, variable_manager, play_context.variable_manager.loader)
    host_names = [host.name for host in hosts]
    assert not host_names

    inventory._hosts = ['host1', 'host2']
    host_names = [host.name for host in hosts]
    assert host_names == ['host1', 'host2']

    inventory._hosts = ['host3', 'host4']
    host_names = [host.name for host in hosts]
    assert host_names == ['host3', 'host4']

# Generated at 2022-06-22 14:36:10.234677
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.plugins.loader import find_plugin, module_loader
    from ansible.inventory.host import Host
    from ansible.vars.variable_manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    # Create the module loader
    plugin = find_plugin(module_loader, 'ping')
    loader = DataLoader()

    # Create a host
    host = Host(name="test")

    # Create the variable manager
    variable_manager = VariableManager()

# Generated at 2022-06-22 14:36:22.109127
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import os

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    inventory_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'lib', 'ansible_test_inventory')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[inventory_path])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test repr()
    hostvars = HostVars(inventory, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-22 14:36:32.645113
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    myhost = Inventory(loader=loader, host_list=['localhost'])
    myhost.add_host('example1', {})

    variables = VariableManager(loader=loader, inventory=myhost)
    hostvars = HostVars(inventory=myhost, variable_manager=variables, loader=loader)
    assert repr(hostvars.raw_get('example1')) == "{}"
    hostvars.set_host_variable('example1', 'foo', 'bar')
    assert hostvars.raw_get('example1') == {'foo': 'bar'}

# Generated at 2022-06-22 14:36:41.107086
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    """Test HostVars.__getitem__()."""
    # Mock inventory and variable manager
    inventory = MagicMock()
    variable_manager = MagicMock()
    variable_manager.get_vars.return_value = {"var_sample": "var_sample_value"}
    # Create HostVars instance
    hostvars = HostVars(inventory, variable_manager, None)
    # Call the method and make sure it returns expected value
    assert hostvars["sample"] == HostVarsVars({"var_sample": "var_sample_value"}, None)

# Generated at 2022-06-22 14:36:49.405539
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    def get_vars(self, host, include_hostvars=True):
        '''
        Return host specific variables.
        '''
        if not isinstance(host, Host):
            host = self._inventory.get_host(host)
        if host is None:
            return dict()
        self._vars_cache[host.name] = dict(self._inventory.get_vars(host))
        if include_hostvars:
            self._hostvars_cache[host.name] = dict(host.vars)
            self._vars_cache[host.name].update(self._hostvars_cache[host.name])
            # since we update _vars_cache, we need to clear the cache
            #

# Generated at 2022-06-22 14:37:03.785278
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import pytest
    from ansible.vars.hostvars import HostVars

    def mock_variable_manager_get_vars(host, include_hostvars):
        return {
            'a': 1,
            'b': 2,
            'c': '{{d}}',
            'd': '4',
            'e': {
                'f': '{{g}}',
                'g': '8',
                'h': '{{a}} {{b}} {{c}} {{d}}',
            },
        }

# Generated at 2022-06-22 14:37:05.846583
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    hostvars = HostVars({})
    for _ in hostvars:
        raise AssertionError()


# Generated at 2022-06-22 14:37:13.415635
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    fake_loader = "fake_loader"
    fake_hosts = MutableSequence()
    fake_hosts.append(Host(name="fake_host_one"))

    fake_variable_manager = "fake_variable_manager"
    fake_inventory = "fake_inventory"
    fake_group_name = "fake_group_name"
    fake_host_name = "fake_host_name"

    # case 1, host is in inventory
    fake_inventory_one = Group(name=fake_group_name)
    fake_inventory_one._hosts = fake_hosts


# Generated at 2022-06-22 14:37:22.067757
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = Dummy()

    class A:
        def __init__(self):
            self.variables = {'a': '1', 'b': '2'}

            # Found out that this fails with
            # self._vars = A().variables
            # but it works if we use self._vars = copy.deepcopy(A().variables)
            # self._vars = A().variables
            self._vars = copy.deepcopy(A().variables)

    for element in HostVarsVars(A()._vars, loader=loader).__iter__():
        assert element

# Generated at 2022-06-22 14:37:33.828023
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import os
    import json
    import unittest
    import collections

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.module_utils.common._collections_compat import MutableMapping

    from six import string_types, text_type
    from units.mock.loader import DictDataLoader

    class AnsibleVars(dict):
        pass

    class AnsibleHost(object):

        def __init__(self, inventory, name):
            self.name = name
            self.inventory = inventory
            self.vars = AnsibleVars()
            self.is_localhost = False
            self.vars['inventory_hostname'] = self.name


# Generated at 2022-06-22 14:37:35.646279
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    HostVars(inventory=None, variable_manager=None, loader=None).__iter__()

# Generated at 2022-06-22 14:37:45.210601
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vm = VariableManager(loader=loader)
    hv = HostVars(inventory=None, loader=loader, variable_manager=vm)
    hv_state = {'_inventory': vm,
                '_loader': loader,
                '_variable_manager': vm,
    }

    hv.__setstate__(hv_state)
    assert vm._loader is loader and vm._hostvars is hv

# Generated at 2022-06-22 14:37:51.693031
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible.inventory
    import ansible.plugins.loader
    from ansible.vars.mapping import VariableManager

    c = ansible.plugins.loader.PluginLoader.get_all_categories()
    for p in c:
        for pl in ansible.plugins.loader.PluginLoader.all(p):
            if hasattr(pl, 'get_host_variables'):
                get_host_variables = pl.get_host_variables
                break

    inv = ansible.inventory.Inventory("localhost", "localhost", loader=None, variable_manager=VariableManager, get_host_variables=get_host_variables)
    hv = HostVars(inv, VariableManager, None)

    # Setup
    inv_var = inv.get_variable("localhost", "foobar")

# Generated at 2022-06-22 14:38:02.139938
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    inv_mgr = InventoryManager(loader=None, sources=None, sources_list=None)
    hv = HostVars(inventory=inv_mgr, variable_manager=vm, loader=None)

    assert tuple(hv) is ()

    inv_mgr.add_host('host1')
    assert tuple(hv) == ('host1',)

    inv_mgr.add_group('group1')
    inv_mgr.add_host('host2', groups=['group1'])
    assert tuple(hv) == ('host1', 'host2')

# Unit test to ensure AnsibleUndefined is returned when not found

# Generated at 2022-06-22 14:38:12.648855
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import os

    variable_manager = VariableManager()
    loader = variable_manager._loader

    # Setup inventory
    variable_manager.extra_vars = {'hostvars': {'local': {'inventory_hostname': 'local'}}}
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    context = PlayContext(variable_manager=variable_manager)
    templar = Templar(loader=loader, variables={}, shared_loader_obj=loader,
            context=context)

    # Test remote_addr

# Generated at 2022-06-22 14:38:30.223238
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import json
    from copy import deepcopy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    loader = DataLoader()
    vault_secrets = VaultLib([])
    hostvars = HostVars(inventory=None, variable_manager=None, loader=loader)

    inventory = InventoryManager(loader=loader, sources=[])
    inventory.set_playbook_basedir('.')
    inventory.add_host('localhost')
    host = inventory.get_host('localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory, variable_manager=None)
    hostvars.set_variable_manager(variable_manager)


# Generated at 2022-06-22 14:38:38.216642
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader
    import pytest
    from pytest_mock import mocker
    import os


# Generated at 2022-06-22 14:38:47.631665
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class DummyHost(object):
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-22 14:38:57.411981
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import copy
    import unittest

    class TestInventory(object):
        '''
        Fake Inventory object to return an empty list of hosts
        '''

        hosts = ['host1', 'host2']

        def get_host(self, host):
            if host in self.hosts:
                return host
            else:
                return None

    class TestVariableManager(object):
        '''
        Fake VariableManager to return a dict with variables for a given host
        '''

        fake_hostvars = {
            'host1': {'var1': 'value1'},
            'host2': {'var2': 'value2'},
        }

        def get_vars(self, host, include_hostvars=True):
            return self.fake_hostvars.get(host)

    test_loader

# Generated at 2022-06-22 14:39:09.503830
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # We use an empty inventory because we do not need it.
    inventory = type('', (), {})()
    inventory.hosts = {}
    inventory.groups = {}


    # Set needed attributes to empty objects
    loader = type('', (), {})()
    variable_manager = type('', (), {})()
    variable_manager._hostvars = None

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Set needed attributes
    hostvars._inventory = inventory
    hostvars._loader = loader
    hostvars._variable_manager = variable_manager
    variable_manager._hostvars = hostvars

    # Set needed attributes to empty objects

    # Set needed attributes
    variable_manager._loader = loader
    variable_manager._hostvars = hostvars



# Generated at 2022-06-22 14:39:21.001279
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager

    inv = InventoryManager(loader=None, sources=['tests/inventory/test_hostvars/hosts'])
    assert inv.get_host("localhost") is not None
    assert inv.get_host("otherhost") is not None

    vars_cache = inv._get_host_variables("localhost")
    assert vars_cache['var1'] == "localhost_var1"

    test_var = HostVars(inventory=inv, variable_manager=None, loader=None)
    assert test_var.raw_get('localhost')['var1'] == "localhost_var1"
    assert test_var.raw_get('otherhost')['var1'] == "otherhost_var1"

# Generated at 2022-06-22 14:39:30.790177
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_obj = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inv_obj)

    hv = HostVars(inv_obj, variable_manager, loader)

    # Since the inventory is not empty, the length and the iterator
    # returned by iter() should be the same length.
    assert len(hv) == len(list(iter(hv)))
    # __iter__ returns an iterator, not a list
    assert not isinstance(iter(hv), list)

    # Empty Inventory

# Generated at 2022-06-22 14:39:34.302336
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Variables for testing
    test_loader = 'test_loader'
    test_variables = 'test_variables'

    test_obj = HostVarsVars(variables=test_variables, loader=test_loader)
    assert test_obj.__iter__() == test_obj._vars.keys()

# Generated at 2022-06-22 14:39:44.552646
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    results_1 = {'hostvars': {'test_host': {'test_key': 'test_value'}}}
    results_2 = {'hostvars': {'test_host': 'test_value'}}
    results_3 = {'hostvars': {'test_host': [1, 2, 3]}}
    results = [results_1, results_2, results_3]

    results_expected_1 = {'test_key': 'test_value'}
    results_expected_2 = 'test_value'
    results_expected_3 = [1, 2, 3]

# Generated at 2022-06-22 14:39:48.165967
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars_vars = HostVarsVars({'foo': 'bar'}, None)
    assert 'foo' in hostvars_vars
    assert next(iter(hostvars_vars)) == 'foo'

# Generated at 2022-06-22 14:40:12.839117
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources="localhost,")
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, None)

    assert hostvars.raw_get("localhost") == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-22 14:40:21.156590
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    """
    Check that HostVars.__getitem__() performs variable substitution
    on values of existing variables.
    """
    variables = dict(
        foo='bar',
        bar='{{ foo }}',
    )
    hostvars = HostVarsVars(variables, None)

    # only 'bar' is substituted because 'foo' is not in the
    # STATIC_VARS list
    assert hostvars['bar'] == 'bar'

# Generated at 2022-06-22 14:40:31.367765
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    from collections import Counter
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory_file = '''
    [all]
    localhost
    '''
    vars_file = '''
    ---
    localhost_name: localhost
    '''

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=inventory_file))
    variable_manager.add_group_vars_file(loader.load_from_file('/dev/null', 'yml', vars_file))

    host_vars = HostVars(variable_manager.inventory, variable_manager, loader)

# Generated at 2022-06-22 14:40:32.504755
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    assert False, "failing so you can see a traceback"

# Generated at 2022-06-22 14:40:43.609732
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import ansible.inventory.host
    inventory = ansible.inventory.host.Host(name='test')
    variable_manager = ansible.vars.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager._hostvars = HostVars(inventory, variable_manager, loader)

    # No hosts in inventory
    assert len(list(variable_manager._hostvars.__iter__())) == 0
    assert list(variable_manager._hostvars.__iter__()) == []

    # Add a host to inventory
    inventory.add_host(ansible.inventory.host.Host(name='test'))
    assert len(list(variable_manager._hostvars.__iter__())) == 1

# Generated at 2022-06-22 14:40:48.665812
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import ansible.inventory
    import ansible.vars.manager
    iv = ansible.inventory.Inventory()
    iv.add_host(host="testhost")
    vm = ansible.vars.manager.VariableManager()
    hv = HostVars(iv, vm, None)
    assert isinstance(hv.raw_get("testhost"), Mapping)

# Generated at 2022-06-22 14:40:55.361741
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars import VariableManager, DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    hostvars = HostVars(inventory, variable_manager, loader)

    output = list(hostvars.__iter__())
    import pprint
    pprint.pprint(output)
    assert type(output) == list
    assert len(output) == 0
    assert output == []



# Generated at 2022-06-22 14:41:06.833472
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.parsing import vault
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    vault_secrets = vault.VaultLib(None)

    inventory = InventoryManager(loader=None, sources='localhost,')
    hosts = [inventory.get_host(hostname) for hostname in inventory.get_hosts()]
    loader = VaultAwareFileLoader(None, vault_secrets)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    variables = combine_vars(hosts[0], inventory, variable_manager, loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)
    # There are two ways to access an attribute with value AnsibleUnd

# Generated at 2022-06-22 14:41:10.300546
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager

    h = HostVars(None, VariableManager(), None)

    assert h.raw_get("localhost") == {}
    assert isinstance(h.raw_get("localhost"), dict)
    h.set_host_variable("localhost", "foo", "bar")
    assert h.raw_get("localhost") == {"foo": "bar"}
    assert h.get("localhost") == {"foo": "bar"}
    assert isinstance(h.get("localhost"), HostVarsVars)

# Generated at 2022-06-22 14:41:16.408239
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # We cannot use standard Ansible test mechanisms here so
    # we need to use some hack. If we get to the line after
    # for loop then the code was executed.
    hv = HostVars(None, None, None)
    for host in hv:
        assert False, "We should never get here"

    assert True, "The code was executed"

# Generated at 2022-06-22 14:41:56.896287
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Sanity check for method __iter__ of class HostVars.
    hostvars = HostVars({}, {}, {})
    assert list(hostvars) == []

    hostvars = HostVars({'localhost': {'hostvars': {'foo': 'bar'}}},
                        {}, {})
    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 14:42:03.269045
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    class InventoryMock(object):
        hosts = set('host1', 'host2', 'host3')

        def __contains__(self, host_name):
            return host_name in self.hosts

        def get_host(self, host_name):
            return host_name

    inventory_mock = InventoryMock()
    host_vars_mock = HostVars(inventory_mock, None, None)

    assert host_vars_mock.__iter__() == inventory_mock.hosts

# Generated at 2022-06-22 14:42:15.672667
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    def test_HostVars(self, host_name):
        '''
        Returns the variables (including facts) from the given host,
        after templating them.
        '''
        host_name = self._get_host_name(host_name)
        host = self._find_host(host_name)
        if host is None:
            return AnsibleUndefined(name="hostvars['%s']" % host_name)
        variables = self._variable_manager.get_vars(host=host, include_hostvars=True)
        templar = Templar(variables=variables, loader=self._loader)
        return templar.template(variables, fail_on_undefined=False, static_vars=STATIC_VARS)
    

# Generated at 2022-06-22 14:42:27.273189
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    """
    >>> class FakeInventory(object):
    ...   hosts = []
    >>> class FakeHost(object):
    ...   def get_name(self):
    ...     return "fake_host_name"

    >>> class FakeVarMgr(object):
    ...   def get_vars(self, host):
    ...     return "fake_get_vars_return"
    >>> fakeInventory = FakeInventory()
    >>> fakeVarMgr = FakeVarMgr()
    >>> fakeHostVars = HostVars(fakeInventory, fakeVarMgr)
    >>> fakeHost = FakeHost()


    >>> fakeHostVars.raw_get("fake_hostname")
    'fake_get_vars_return'
    """



# Generated at 2022-06-22 14:42:34.626057
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    mock_loader = MockLoader()
    mock_inventory = MockInventory()
    mock_variable_manager = MockVariableManager()

    host_vars_obj = HostVars(inventory=mock_inventory, variable_manager=mock_variable_manager, loader=mock_loader)
    templar = Templar(loader=mock_loader)

    hosts = []
    for host in host_vars_obj:
        hosts.append(host)

    assert host_vars_obj._inventory.hosts == hosts



# Generated at 2022-06-22 14:42:45.688358
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    source = '''
    [all:vars]
    ansible_user = foo

    [master]
    localhost
    [slave]
    hostname
    '''
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[source])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    data = hostvars['localhost']
    assert(list(data) == ['ansible_user'])