

# Generated at 2022-06-22 14:33:01.636774
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # If a host is not in the inventory, it should not be in HostVars
    # See https://github.com/ansible/ansible/issues/16964
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(host_list=['localhost', '127.0.0.1'])

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    assert list(hostvars) == ['localhost', '127.0.0.1']

# Generated at 2022-06-22 14:33:07.332781
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    # Create inventory
    inven = Group(name='test')
    inven.add_host(Host(name='host1'))
    inven.add_host(Host(name='host2'))
    # Create HostVars
    vars_cache = {'host1': {}}
    loader = DataLoader()
    manager = DummyVariableManager(vars_cache=vars_cache)
    hostvars = HostVars(inventory=inven, variable_manager=manager, loader=loader)
    # Test __iter__()
    host_names = set(hostvars)
    assert set(['host1', 'host2']) == host_names


# Generated at 2022-06-22 14:33:16.959114
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars._vars_cache = {'localhost': {'foo': 'bar'}}

    assert hostvars.raw_get('localhost') == {'foo': 'bar'}
    assert hostvars.raw_get('localhorst') == AnsibleUndefined(name="hostvars['localhorst']")
    assert hostvars.raw_get('localhost') == {'foo': 'bar'}


#

# Generated at 2022-06-22 14:33:20.019711
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars = HostVarsVars({'foo': 'bar', 'baz': 'qux'}, None)
    assert list(iter(hostvars)) == ['foo', 'baz']

# Generated at 2022-06-22 14:33:28.253861
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import copy
    import sys

    if sys.version_info < (2, 7):
        return

    import pytest
    from ansible.vars.hostvars import HostVars

    class FakeHost():
        pass

    class FakeInventory():
        def __init__(self):
            self.hosts = []
            for i in range(3):
                h = FakeHost()
                h.name = 'host%d' % i
                self.hosts.append(h)

        def get_host(self, host_name):
            for h in self.hosts:
                if h.name == host_name:
                    return h
            return None

    class FakeVariableManager():
        pass

    class FakeLoader():
        pass

    @pytest.fixture
    def fake_inventory():
        return FakeIn

# Generated at 2022-06-22 14:33:37.799724
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import copy
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variables = {
        'foo': {
            'bar': 'test',
            'baz': {
                'a': 1,
                'b': 2,
            },
        },
    }

    templar = Templar(loader=None, variables=variables)

    loader = None
    variable_manager = VariableManager(loader=loader, variables=variables)

    hostvars = HostVarsVars(variables=variables, loader=loader)

    assert templar.template(variables['foo'], fail_on_undefined=False) == hostvars['foo']
    assert templar.template(variables['foo'], fail_on_undefined=False) == hostvars['foo']

    variable

# Generated at 2022-06-22 14:33:42.887606
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    inventory = MockInventory()
    variable_manager = MagicMock()
    loader = MagicMock()
    hostvars = HostVars(inventory, variable_manager, loader)

    # Case 1: host is None
    host = None
    facts = {'sample_fact': 'sample_value'}
    hostvars.set_host_facts(host, facts)
    variable_manager.set_host_facts.assert_not_called()

    # Case 2: host is not None
    host = 'test_host'
    facts = {'sample_fact': 'sample_value'}
    hostvars.set_host_facts(host, facts)
    variable_manager.set_host_facts.assert_called_once_with(inventory.get_host(host), facts)

# Mock classes

# Generated at 2022-06-22 14:33:53.296993
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class MockVariableManager:
        def __init__(self):
            self._host_vars_cache = {'testhost': {'name': 'testhost', 'test_value': 'foo'}}

    class MockLoader:
        def __init__(self):
            self._basedir = '/dev/null'

    class MockInventory:
        def __init__(self):
            self._hosts = ['testhost']
            self._vars_per_host = {}
            self._variable_manager = MockVariableManager()
            self._loader = MockLoader()

    class MockHost:
        def __init__(self, name):
            self.name = name

    inv = MockInventory()
    hv = HostVars(inv, inv._variable_manager, inv._loader)

# Generated at 2022-06-22 14:33:59.702353
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    temp = HostVars({}, {}, {})
    assert temp._variable_manager._loader is None
    assert temp._variable_manager._hostvars is None

    temp.__setstate__({'_variable_manager': temp._variable_manager})
    assert temp._variable_manager._loader is not None
    assert temp._variable_manager._hostvars is not None

# Generated at 2022-06-22 14:34:07.794694
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class MockInventory(object):
        def get_host(self, host):
            return None

    class MockVariableManager(object):
        def get_vars(self, host, include_hostvars):
            return dict(a=1, b=2)

    class MockLoader(object):
        pass

    hv = HostVars(MockInventory(), MockVariableManager(), MockLoader())
    assert isinstance(hv['localhost'], HostVarsVars)

    # number of keys in HostVarsVars is 2 and
    # keys are 'a' and 'b'
    assert len(hv['localhost']) == 2
    for key in hv['localhost']:
        assert key in ['a', 'b']

    # values corresponding to 'a' and 'b' are rendered

# Generated at 2022-06-22 14:34:21.264628
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    # Check that method __setstate__ assigns attribute _loader
    # of VariableManager correctly

    loader = DummyLoader()
    inventory = DummyInventory(loader)
    variable_manager = DummyVariableManager(inventory, loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars._variable_manager._loader is loader

    # Pickling of object hostvars sets attribute _loader of
    # VariableManager to 'None' to improve performance and memory
    # utilization.
    pickled_hostvars = pickle.dumps(hostvars)
    unpickled_hostvars = pickle.loads(pickled_hostvars)
    assert unpickled_hostvars._variable_manager._loader is None

    # Method __setstate__ assigns attribute _loader of VariableManager
    # to the

# Generated at 2022-06-22 14:34:32.041577
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import ansible.playbook.hosts.memory
    import ansible.playbook.vars.manager
    import ansible.vars.unsafe_proxy
    import ansible.template.vars

    loader = ansible.template.vars.VariableLoader(config=dict(), paths=['/foo/bar/'])
    inventory = ansible.playbook.hosts.memory.Inventory(loader=loader)
    variable_manager = ansible.playbook.vars.manager.VariableManager(loader=loader, inventory=inventory)
    variable_manager._vars_cache = dict(
        localhost=dict(
            x=1
        ),
        somehostname=dict(
            x=2
        )
    )

    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-22 14:34:39.584562
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.parsing import DataLoader
    from ansible.inventory import Inventory
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory("localhost", loader=loader)
    inventory.add_host("localhost")
    hv = HostVars(inventory, variable_manager, loader)
    # Simulate pickling
    hv_state = hv.__getstate__()
    # Simulate unpickling
    hv.__setstate__(hv_state)
    assert hv._loader == loader
    assert hv._variable_manager._loader == hv._loader
    assert hv._variable_manager._hostvars == hv

# vim: set expandtab:

# Generated at 2022-06-22 14:34:47.427470
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.module_utils.hashivault import hashivault_argspec

    host = Inventory()
    host.add_host("foohost")
    var = {}
    var["hashivault_password"] = "foobar"
    var["hashivault_token"] = "00000000-0000-0000-0000-000000000000"
    var["hashivault_url"] = "https://vault.example.com"
    var["hashivault_verify"] = True
    var["ansible_connection"] = "local"
    var["ansible_python_interpreter"] = "/usr/bin/python"
    var["ansible_python_interpreter"] = "python"

# Generated at 2022-06-22 14:34:57.157332
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    import os

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=os.devnull)

    variable_manager = VariableManager()
    variable_manager._loader = loader
    variable_manager._hostvars = HostVars(inventory, variable_manager, loader)

    hostvars = HostVars(None, None, None)
    hostvars.__setstate__({'_variable_manager': variable_manager, '_loader': loader})

    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

# Generated at 2022-06-22 14:35:08.362242
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, '/dev/null')

    inventory.hosts = {
        'alpha': 'foobar',
        'beta': 'barfoo',
        'gamma': 'barbar',
        'delta': 'foofoo'
    }

    variable_manager.set_host_variable('alpha', 'foo', 'value')
    variable_manager.set_host_variable('alpha', 'bar', 'value')
    variable_manager.set_host_variable('alpha', 'baz', 'value')
   

# Generated at 2022-06-22 14:35:15.110786
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    data_loader = DataLoader()
    inventory = InventoryManager(loader=data_loader, sources='')
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, None)

    assert list(hostvars.__iter__()) == []

# Generated at 2022-06-22 14:35:25.327202
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    inv_str = '''#!/usr/bin/ansible-inventory -i
{
    "testgroup": {
        "hosts": [
            "testhost"
        ],
        "vars": {
            "testvar": "testval"
        }
    }
}
'''
    inventory = InventoryManager(loader=loader, sources=inv_str)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-22 14:35:26.486703
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Create an instance of HostVars class
    assert False, "Not implemented"

# Generated at 2022-06-22 14:35:32.959807
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # FIXME: should this test be moved to unit/test_hostvars.py?
    # FIXME: should it rather be a test of the module Mapping?
    import unittest

    class TestHostVars___iter__(unittest.TestCase):

        class FakeInventory(object):
            def __init__(self):
                self.hosts = ['host1', 'host2', 'host3']

        def setUp(self):
            self.inventory = self.FakeInventory()
            self.hostvars = HostVars(self.inventory)

        def test_method_returns_iterable(self):
            # The method __iter__ should return an iterable
            result = self.hostvars.__iter__()
            self.assertTrue(hasattr(result, '__iter__'))


# Generated at 2022-06-22 14:35:54.685869
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from pytest import raises
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.errors import AnsibleError

    localhost_inventory = '''
    localhost ansible_connection=local
    '''

    inventory = InventoryManager(loader=DataLoader(), sources=[localhost_inventory])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # HostVars object must not be created with empty inventory
    with raises(AnsibleError) as err:
        hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=DataLoader())

# Generated at 2022-06-22 14:36:05.204589
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create the following inventory file
    # [group1]
    # host1.example.com
    # host2.example.com
    # host3.example.com
    # [group2]
    # host4.example.com
    # host5.example.com
    # host6.example.com
    group1 = []
    group2 = []
    for i in [1,2,3]:
        h = "host%d.example.com" % i
        group1.append(h)
    for i in [4,5,6]:
        h = "host%d.example.com" % i
        group2.append(h)
    hosts = []
    hosts.extend(group1)
    hosts.extend(group2)

    # Initialize Inventory object

# Generated at 2022-06-22 14:36:13.796365
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import unittest

    class HostVarsVarsTest(unittest.TestCase):
        def setUp(self):
            self.variables = {'var1': 1, 'var2': 2, 'var3': 3}
            self.loader = None

        def test_HostVarsVars___iter__(self):
            host_vars_vars = HostVarsVars(self.variables, self.loader)
            host_vars_vars_iter = iter(host_vars_vars)
            for key in self.variables:
                self.assertEqual(next(host_vars_vars_iter), key)

    suite = unittest.TestLoader().loadTestsFromTestCase(HostVarsVarsTest)
    unittest.TextTestRunner(verbosity=2).run

# Generated at 2022-06-22 14:36:26.166273
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager

    managers = {}
    managers['inventory_manager'] = InventoryManager(loader=None, sources=['tests/inventory_hostvars_test'])
    managers['variable_manager'] = managers['inventory_manager'].get_variable_manager()
    hostvars = HostVars(inventory=managers['inventory_manager'], variable_manager=managers['variable_manager'], loader=None)
    assert hostvars.raw_get('localhost')['var_from_vars'] == 'value_from_vars'
    assert hostvars.raw_get('localhost')['var_from_inventory_vars'] == 'value_from_inventory_vars'

# Generated at 2022-06-22 14:36:34.768189
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=DataLoader(), sources="")
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, DataLoader())
    host = Host(name="example.org")
    host.set_variable('ansible_ssh_port', 2222)
    host.set_variable('ansible_connection', 'local')
    inventory._hosts = {"example.org": host}

    # testing a host
    hostvars.set_inventory(inventory)

# Generated at 2022-06-22 14:36:46.060456
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Host, Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host1 = Host('test1')
    host2 = Host('test2')

    inventory = Inventory(loader=DataLoader())
    inventory.add_host(host=host1)
    inventory.add_host(host=host2)

    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hvars = HostVars(inventory, variable_manager, DataLoader())

    # Set host variables on test1
    hvars.set_host_variable(host1, 'a', 1)
    hvars.set_host_variable(host1, 'b.c', 2)

# Generated at 2022-06-22 14:36:57.796116
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    ''' Test method __iter__ of class HostVarsVars. '''
    from ansible.vars.unsafe_proxy import wrap_var

    variables = {
        'foo': wrap_var('fooval'),
        'bar': wrap_var('barval'),
    }
    loader = None
    vars = HostVarsVars(variables, loader)

    # Check iterator of HostVarsVars object
    vars_keys = []
    for var in vars:
        vars_keys.append(var)
    assert sorted(vars_keys) == sorted(['foo', 'bar'])

    # Check iterator of HostVarsVars object after adding new elements

# Generated at 2022-06-22 14:37:07.944976
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    '''Unit test for method __repr__ of class HostVars'''
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    class FakeHost(object):
        '''Fake class for unit test for method __repr__ of class HostVars'''
        def __init__(self, name):
            self.name = name
            self.vars = {}

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test empty hostvars
    assert repr(hostvars) == '{}'

   

# Generated at 2022-06-22 14:37:14.154898
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    variable_manager = VariableManager()
    loader = DataLoader()
    display = Display()
    inventory = InventoryManager(
        loader=loader,
        variable_manager=variable_manager,
        host_list='localhost,otherhost',
    )

    hostvars = HostVars(inventory, variable_manager, loader)

    assert 'a' in hostvars.raw_get('localhost')
    assert 'a' not in hostvars.raw_get('otherhost')
    assert 'a' in hostvars.raw_get('localhost')['b']

# Generated at 2022-06-22 14:37:24.141241
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    '''
    Note that method __getitem__ of class HostVars should not throw an exception if an undefined
    host name is given. Instead an AnsibleUndefined object with a name property
    (e.g. "hostvars['<host_name>']") should be returned. This test checks that this behaviour
    is implemented correctly.
    '''

    # Create a object of type HostVars

    mock_loader = Mock()
    mock_loader.get_basedir.return_value = '/dev/null'
    mock_loader.path_dwim.return_value = '/dev/null'

    mock_variable_manager = Mock()
    mock_variable_manager.get_vars.return_value = dict()

    mock_inventory = Mock()
    mock_inventory.get_host.return_value = None

    host_v

# Generated at 2022-06-22 14:37:57.055503
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Test with regular dict
    regular_dict = {'baffi':'cane', 'faccia':'passera'}
    assert sorted(iter(HostVarsVars(regular_dict, None))) == sorted(["baffi", "faccia"])

    # Test with defaultdict
    from collections import defaultdict
    defdefault_dict = defaultdict(str)
    defdefault_dict["baffi"] = "cane"
    defdefault_dict["faccia"] = "passera"
    assert sorted(iter(HostVarsVars(defdefault_dict, None))) == sorted(["baffi", "faccia"])

# Generated at 2022-06-22 14:38:06.826374
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.utils.vars import combine_vars

    # create Mock objects needed for HostVars.__setstate__
    mock_variable_manager = _create_Mock_VariableManager()
    mock_inventory = _create_Mock_Inventory()

    mock_loader = 'mock_loader'
    mock_host = 'mock_host'
    mock_vars = 'mock_vars'

    # create correct state to set
    correct_state = {'_inventory': mock_inventory,
                     '_loader': mock_loader,
                     '_variable_manager': mock_variable_manager}

    # create incorrect state with the missing values
    incorrect_state = {'_inventory': mock_inventory,
                       '_variable_manager': mock_variable_manager}

    # create new HostVars instance
    hostv

# Generated at 2022-06-22 14:38:18.239953
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = {}
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {}

    inventory['localhost'] = (
        """{
            "vars": {"foo": "My name is {{ name }}"},
            "vars_prompt": {"name": {"description": "Your name",
                                     "prompt": "What is your name?",
                                     "private": true}}
        }""")

    assert hostvars['localhost'] == {'foo': 'My name is {{ name }}'}
    assert hostvars['unknown_host'] == {}



# Generated at 2022-06-22 14:38:28.674722
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import dict2hosts


# Generated at 2022-06-22 14:38:35.324573
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    ''' Unit test for method raw_get of class HostVars '''

    HostVars._find_host = lambda self, host_name: host_name

    variable_manager = object()
    variable_manager.get_vars = lambda host, include_hostvars=False: host

    inventory = object()
    loader = object()

    variables = HostVars(inventory, variable_manager, loader)

    assert variables.raw_get("localhost") == "localhost"

# Generated at 2022-06-22 14:38:43.438779
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    hostvars = HostVars(InventoryManager(loader=loader, sources=[]), None, loader)
    hostvars._vars = {'foo': 'bar'}

    hostvars_vars = hostvars['hostname']
    assert isinstance(hostvars_vars, HostVarsVars)
    assert hostvars_vars['foo'] == 'bar'

# Generated at 2022-06-22 14:38:53.889516
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader, inventory, variable_manager = setup_inventory_manager()
    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.add_host('foobar')
    inventory.add_host('foobar2')
    variable_manager.set_host_variable('foobar', 'foo', 'bar')
    variable_manager.set_host_variable('foobar2', 'foo', 'bar')

    hosts = set()
    try:
        for host in hostvars:
            hosts.add(host.name)
            break

        for host in hostvars:
            hosts.add(host.name)
            break
    except RuntimeError:
        pass


# Generated at 2022-06-22 14:38:59.843551
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    inventory = Group()
    host = Host('localhost')
    inventory.add_host(host)

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    variable_manager.set_host_variable(host, 'first', 'John')
    variable_manager.set_host_variable(host, 'last', 'Doe')
    variable_manager.set_host_variable(host, 'fullname', '{{ first }} {{ last }}')

    hostvars = HostVars(inventory, variable_manager, None)
    assert hostvars['localhost']['fullname'] == 'John Doe'

# Generated at 2022-06-22 14:39:09.475601
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.hostvars import HostVars

    class MockVariableManager():
        def get_vars(self, host, include_hostvars):
            return "get_vars result"

    class MockInventory():
        def __init__(self):
            self.hosts = [ "host1", "host2" ]

    class MockLoader():
        def __init__(self):
            pass

    variable_manager = MockVariableManager()
    inventory = MockInventory()
    loader = MockLoader()

    hostvars = HostVars(inventory, variable_manager, loader)

    for host in hostvars:
        assert(host in inventory.hosts)

# Generated at 2022-06-22 14:39:21.013173
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    hostvars = HostVars(None, None, loader)

# Generated at 2022-06-22 14:40:32.937216
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from io import StringIO

    host_contents = """
[group1]
localhost
[group2]
localhost
"""
    inventory = InventoryManager(loader=None, sources=StringIO(host_contents))
    loader = inventory._loader
    variable_manager = VariableManager(loader=inventory._loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.set_host_facts(host=hostvars._find_host('localhost'), facts={'foo': 'bar'})

    # Test the cache remember
    data = hostvars.raw_get('localhost')
    assert data['foo'] == 'bar'

    # Test the cache overwrite
    hostvars.set

# Generated at 2022-06-22 14:40:44.128623
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class Host:
        def __init__(self, name):
            self.name = name
            self.vars = dict()
            self.groups = list()

    class Group:
        def __init__(self, name, host):
            self.name = name
            self.hosts = dict()
            self.hosts[host.name] = host
            self.vars = dict()

    class Inventory:
        def __init__(self, host, group):
            self.groups = dict()
            self.groups[group.name] = group
            self.hosts = dict()
            self.hosts[host.name] = host
           

# Generated at 2022-06-22 14:40:54.419614
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.module_utils._text import to_bytes

    loader = DataLoader()
    inventory = Inventory(loader=loader)
    inventory.add_host('test_host_1')
    inventory.add_host('test_host_2')
    inventory.add_host('test_host_3')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Configure all hosts
    hosts = inventory.get_hosts()
    variable_manager.set_host_variable(hosts[0], u'var1', u'value1')

# Generated at 2022-06-22 14:41:06.099162
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import pytest
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.vault import VaultLib

    from ansible.template import Templar
    from ansible.utils.sentinel import Sentinel
    from ansible.vars.unsafe_proxy import wrap_var

    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import STATIC_VARS

    class MockTemplar(Templar):
        def __init__(self):
            self.K = Sentinel()

            self.templar = self


# Generated at 2022-06-22 14:41:15.183189
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os

    loader = DataLoader()
    inv_file = os.path.expanduser("~/ansible/1/inventory")

    inventory = InventoryManager(loader=loader, sources=[inv_file])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    test_obj = HostVarsVars(hostvars['one'], loader)

    assert test_obj.get('inventory_file') == inv_file



# Generated at 2022-06-22 14:41:25.454443
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import os
    import StringIO

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=os.devnull)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # dummy values to make pickle load
    variable_manager._hostvars = None
    variable_manager._loader   = None

    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars.raw_get('foobar')
    hostvars.set_host_variable('foobar', 'bar', True)


# Generated at 2022-06-22 14:41:33.495538
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible import context
    from ansible.vars import VariableManager

    loader = 'dummy'
    inventory = 'dummy'
    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader)
    host = 'localhost'
    hostvars.set_variable_manager(variable_manager)
    variables = {'test_variable': 'test_variable_value'}
    hostvars.set_host_variable(host, 'test_variable', variables['test_variable'])

    assert hostvars[host] == variables

# Generated at 2022-06-22 14:41:37.397653
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hvv = HostVarsVars({"var1": 1, "var2": 2}, loader=None)
    assert list(iter(hvv)) == ["var1", "var2"]


# Generated at 2022-06-22 14:41:46.717205
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    inventory = Inventory("tests/inventory")
    variable_manager = VariableManager(inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

# Generated at 2022-06-22 14:41:58.308541
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader='ansible.parsing.dataloader.DataLoader',
                                 sources=['tests/test_inventory.ini'])

    variable_manager = VariableManager(loader='ansible.parsing.dataloader.DataLoader', inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader='ansible.parsing.dataloader.DataLoader')

    assert hostvars.raw_get('fake_host').get('foo') == 'bar'
    assert hostvars.raw_get('fake_host').get('ansible_fqdn') == 'fake_host.example.com'