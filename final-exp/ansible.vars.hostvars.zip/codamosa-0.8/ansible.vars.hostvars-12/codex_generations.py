

# Generated at 2022-06-22 14:33:00.339802
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    import pickle
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import RESERVED_VARS

    vars_data = dict(foo='bar', baz='qux')
    vars_data.update(RESERVED_VARS)

    data = {}
    data['_vars_cache'] = vars_data
    data['_hostvars'] = None
    data['_host_cache'] = {}
    data['_extra_vars'] = {}
    data['_options'] = {}
    data['_loader'] = None

    variable_manager = VariableManager(loader=None, inventory=None)
    variable_manager.__setstate__(data)


# Generated at 2022-06-22 14:33:11.676320
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    group = Group(name="group")
    host = Host(name="host")

    inventory.groups = {'group': group}
    inventory.hosts = {'host': host}

    hostvars.set_host_variable(host, 'foo', 'bar')

    assert len(hostvars) == 1
    assert [ x for x in hostvars ] == ['host']



# Generated at 2022-06-22 14:33:21.365956
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible.playbook.role
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.inventory
    import ansible.vars.hostvars

    loader = DictDataLoader({})
    inventory = ansible.inventory.inventory.Inventory(loader=loader, host_list=[])
    variable_manager = ansible.vars.variable_manager.VariableManager(loader=loader, inventory=inventory)
    play_context = ansible.playbook.play_context.PlayContext()
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = []
    )

    play = ansible.play

# Generated at 2022-06-22 14:33:23.765830
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    target = HostVarsVars({'foo': 'bar', 'baz': '{{ foo }}'}, None)
    assert 'bar' == target['foo']
    assert 'bar' == target['baz']

# Generated at 2022-06-22 14:33:28.068860
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)

    assert hostvars.raw_get('localhost')['ansible_hostname'] == 'localhost'
    assert isinstance(hostvars.raw_get('somenonexistinghost'), AnsibleUndefined)
    assert isinstance(hostvars.raw_get('somenonexistinghost')['ansible_hostname'], AnsibleUndefined)

# Generated at 2022-06-22 14:33:37.723151
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Create dummy inventory which contains localhost
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    inventory.add_host(host='localhost')

    # Create dummy variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a hostvars object
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test normal behavior of __getitem__
    foo = hostvars['localhost']
    assert not isinstance(foo, AnsibleUndefined)

    # Test that hostvars['fake'] raises KeyError

# Generated at 2022-06-22 14:33:44.271787
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Setup inventory, host and variables
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=('localhost,'))
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Check that raw_get returns AnsibleUndefined
    # if target host does not exist
    assert type(hostvars.raw_get('some_bad_host')) is AnsibleUndefined

    # Check that raw_get returns added variable
    # if target host exists

# Generated at 2022-06-22 14:33:53.156706
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    host = Host(name='test.example.com')
    variable_manager.set_nonpersistent_facts(host, {'a': 1, 'b': 2})

    hostvars = HostVars(inventory, variable_manager, loader=None)

    hostvars_raw_get = hostvars.raw_get('test.example.com')
    assert hostvars_raw_get == {'a': 1, 'b': 2}

# Generated at 2022-06-22 14:33:54.788956
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    pass


# Generated at 2022-06-22 14:34:05.538912
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import ansible.playbook.play_context
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory,
                        variable_manager=variable_manager,
                        loader=loader)

    play_context = ansible.playbook.play_context.PlayContext()
    play_context.network_os = 'ios'
    play_context._hostvars = hostvars
    variable_manager.set_context(play_context)


# Generated at 2022-06-22 14:34:19.406172
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    import ansible.constants as C

    host_name = 'test_host'

    inventory = Inventory(C.DEFAULT_HOST_LIST)
    host = inventory.get_host(host_name)
    host.vars['variable1'] = 'value1'
    host.vars['variable2'] = 'value2'

    variable_manager = VariableManager()

    # Create hostvars object and associate it with the variable manager.
    hostvars = HostVars(inventory, variable_manager, None)
    variable_manager._hostvars = hostvars

    data = hostvars.raw_get(host_name)
    assert data['variable1'] == 'value1'
    assert data['variable2'] == 'value2'

# Generated at 2022-06-22 14:34:29.685628
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    class FakeOptions(object):
        def __init__(self, inventory):
            self.inventory = inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    inventory_manager = InventoryManager(loader=loader, sources=FakeOptions(inventory=None))
    hv = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=loader)

    host = inventory_manager.get_host('localhost')

# Generated at 2022-06-22 14:34:38.884865
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    inventory = "test/unit/support/hosts"
    hostvars = HostVars(inventory=inventory)

    # Vars cache is empty after initialization
    assert hostvars._variable_manager._vars_cache == {}

    # Pickle hostvars object
    import cPickle
    pickle = cPickle.dumps(hostvars)

    # Create basic new vars cache
    hostvars._variable_manager._vars_cache = {"new": 1}

    # Unpickle hostvars object
    unpickled_hostvars = cPickle.loads(pickle)

    # hostvars' cache was restored
    assert unpickled_hostvars._variable_manager._vars_cache == {}

    # Also check that _hostvars and _loader were restored
    assert unpickled_hostvars

# Generated at 2022-06-22 14:34:47.070563
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    mock_loader = DataLoader()
    mock_variable_manager = VariableManager()
    mock_inventory = dict()
    mock_inventory['localhost'] = dict()
    mock_variable_manager._vars_cache = dict()
    mock_variable_manager._vars_cache['localhost'] = dict()
    mock_variable_manager._vars_cache['localhost']["foo"] = dict()
    mock_variable_manager._vars_cache['localhost']["foo"]['bar'] = dict()
    mock_variable_manager._vars_cache['localhost']["foo"]['bar']['baz'] = "{{baz}}"

# Generated at 2022-06-22 14:34:57.086635
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Setup
    inventory = mock.Mock()
    variable_manager = mock.Mock()
    loader = mock.Mock()
    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.get_host.return_value = 'my_host'
    variable_manager.get_vars.return_value = { 'name': 'value' }

    # Run
    hostvars_item = hostvars['my_host']

    # Test
    expected_get_vars_call_args = (({}, 'my_host'), {})
    expected_get_vars_call_kwargs = { 'include_hostvars': False }

# Generated at 2022-06-22 14:35:08.281751
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create an empty inventory
    import ansible.inventory
    inventory = ansible.inventory.Inventory(host_list=[])

    # Create empty variables
    import ansible.vars.manager
    variables = ansible.vars.manager.VariableManager()

    # Create an empty loader
    import ansible.template
    loader = ansible.template.AnsibleLoader()

    hostvars = HostVars(inventory, variables, loader)

    # Check that __iter__ returns nothing if there are no hosts
    iterator = hostvars.__iter__()
    assert(iterator.next() is None)

    # Check that __iter__ does not return anything if the hosts do not have
    # variables
    import ansible.inventory.host
    hostname = "test_hostname1"

# Generated at 2022-06-22 14:35:16.438681
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='./test/units/inventory/host_vars_and_group_vars_inventory')
    variable_manager = VariableManager(loader=loader, inventory=inv)

    hv = HostVars(inventory=inv, variable_manager=variable_manager, loader=loader)

    assert hv.__iter__() == ['host1', 'host2', 'host3', 'host4']

# Generated at 2022-06-22 14:35:26.526665
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os
    import sys
    import pickle
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.module_utils._text import to_text

    variable_manager = VariableManager()
    loader = DataLoader()
    groups = Inventory(loader=loader, variable_manager=variable_manager,
                       host_list='test/inventory/test_inventory_with_groups').get_groups_dict()
    hosts = Inventory(loader=loader, variable_manager=variable_manager,
                      host_list='test/inventory/test_inventory_with_groups').get_hosts(False)
    assert len(groups) == 5
    assert len(hosts) == 4

# Generated at 2022-06-22 14:35:36.071166
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    variable_manager = inventory.get_variable_manager()
    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.add_host(host="localhost")

    variable_manager.set_host_variable(host="localhost", varname='testvar', value='{{testtemplatevar}}')

# Generated at 2022-06-22 14:35:47.074225
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader

    class FakeInventory(object):
        def __init__(self):
            self.vars_cache = {}
            self.hosts = []
        def get_host(self, host_name):
            return None
        def set_variable(self, host, varname, value):
            if host is None:
                self.vars_cache[varname] = value
            else:
                host.set_variable(varname, value)
        def get_variables(self, host):
            return self.vars_cache
        def get_host(self, host_name):
            return None

    class FakeVariableManager(object):
        def __init__(self):
            self.vars_cache = {}

# Generated at 2022-06-22 14:36:02.121427
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = DictDataLoader({
        'host_vars_test.yml': '''
---
foo: bar
baz: test
''',
    })

    inventory = InventoryManager(loader=loader, sources=['host_vars_test.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars['localhost']['foo'] == 'bar'
    assert hostvars['localhost']['baz'] == 'test'
    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 14:36:08.625043
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    if hostvars.__repr__() != hostvars['localhost'].__repr__():
        raise AssertionError()

# Generated at 2022-06-22 14:36:15.880098
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible import inventory
    from ansible.vars import VariableManager

    i = inventory.Inventory("")
    h0 = inventory.Host("empty")
    i.add_host(h0)
    h1 = inventory.Host("a")
    h1.set_variable("foo", "bar")
    i.add_host(h1)
    h2 = inventory.Host("b")
    h2.set_variable("baz", 42)
    i.add_host(h2)
    h3 = inventory.Host("both")
    h3.set_variable("foo", "bar")
    h3.set_variable("baz", 42)
    i.add_host(h3)

    v = VariableManager(loader=None, inventory=i)

# Generated at 2022-06-22 14:36:26.815928
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    class FakeData:
        vars = dict(foo='a', bar='b')

    class FakeHost:
        name = 'fake_host'
        __getitem__ = lambda self, key: FakeData()

    class FakeInventory:
        def get_host(self, host):
            return FakeHost()

    class FakeLoader:
        pass

    loader = FakeLoader()
    inventory = FakeInventory()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)

    assert(hostvars['fake_host'] == dict(foo='a', bar='b'))

# Generated at 2022-06-22 14:36:35.128755
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    '''
    Unit test for method __getitem__ of class HostVarsVars.
    '''

    module_args = dict(
        a=dict(required=False),
        b=dict(required=False),
    )


# Generated at 2022-06-22 14:36:46.284263
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    '''
    Test the method `__iter__` of class `HostVars`.
    '''
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')

    host = Host(name="testhost")
    inventory._hosts_cache = [host]
    inventory._patterns_cache = [host.name]
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager=variable_manager, loader=loader)

    hosts = []
    for host in hostvars:
        hosts.append(host)

# Generated at 2022-06-22 14:36:52.215880
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host

    # Create inventory.
    inventory = InventoryManager(loader=None, sources=['localhost,'])
    # Create host.
    host = Host(name='localhost')
    # Set host's variables.
    host.vars = { 'var1': 42 }
    # Add host to inventory.
    inventory.add_host(host)

    # Create loader of variables.
    loader = vars_loader
    # Create manager of variables.
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Test get variables of localhost.
   

# Generated at 2022-06-22 14:36:57.302354
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Create variable manager
    vm = Fake_VariableManager()
    # Create HostVars
    hostvars = HostVars(inventory=None, variable_manager=vm, loader=None)
    # Check raw_get with expected result
    assert hostvars.raw_get('host') == {'a': '1', 'b': 'two'}



# Generated at 2022-06-22 14:37:07.433232
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    inv = Inventory()

# Generated at 2022-06-22 14:37:11.632721
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager

    h = HostVars([], VariableManager(), None)
    h.__setstate__({
        '_inventory': [],
        '_loader': 1,
        '_variable_manager': VariableManager(),
    })

    assert h._loader == 1
    assert h._variable_manager._loader is None
    assert h._variable_manager._hostvars is None

# Generated at 2022-06-22 14:37:49.422006
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class FakeInventory(object):

        def __init__(self):
            self.hosts = ['a', 'b', 'c']

    class FakeOptions(object):
        def __init__(self):
            self.connection = 'local'

    class FakeVariables(dict):

        def get_vars(self, host, include_hostvars=False):
            return {'a': 1, 'b': 2}

    options = FakeOptions()

    inventory = InventoryManager(loader=DataLoader(), sources='localhost')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)



# Generated at 2022-06-22 14:38:01.054094
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class Inventory:
        def __init__(self, hosts):
            self.hosts = hosts

        def get_host(self, host_name):
            if host_name in self.hosts:
                return host_name

            return None

        def set_variable(self, host, varname, value):
            self.hosts[host][varname] = value

    class VariableManager:
        def __init__(self, variables):
            self._vars_cache = variables

        def get_vars(self, host=None, include_hostvars=True):
            if host is None:
                return self._vars_cache

            data = self._vars_cache.copy()

# Generated at 2022-06-22 14:38:06.324952
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    inventory = Inventory("")
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # raw_get should return AnsibleUndefined for non-existent host
    assert isinstance(hostvars.raw_get("non-existent-host"), AnsibleUndefined)

# Generated at 2022-06-22 14:38:16.649540
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources=['tests/inventory/test_inventory.ini'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())

    # Check to make sure we expand all the included variables in a host
    hostvars['localhost']
    assert hostvars['localhost']['my_var'] == 'foo'
    assert hostvars['localhost']['my_grouped_var'] == 'grouped_foo'

# Generated at 2022-06-22 14:38:27.631289
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = Inventory(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create a few valid host_names that we can lookup.
    host = Host('test_inventory_hostname')
    host.vars = {'test_inventory_hostname': 'test_inventory_hostname'}
    inventory.add_host(host)

    # Test a valid host_name.

# Generated at 2022-06-22 14:38:37.708042
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = 'ansible.parsing.dataloader.DataLoader'
    hostvars = HostVars(inventory, variable_manager, loader)
    data = hostvars.__getstate__()

    # Set __loader and __hostvars of VariableManager to None
    variable_manager._loader = None
    variable_manager._hostvars = None

    hostvars.__setstate__(data)

    assert variable_manager._loader == HostVars(inventory, variable_manager, loader)._loader
    assert variable_manager._hostv

# Generated at 2022-06-22 14:38:40.178670
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    HostVars.__iter__(None)


# Generated at 2022-06-22 14:38:47.798350
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import copy
    import ansible.plugins.loader as plugins
    import ansible.plugins.vars as vars
    from ansible.parsing.dataloader import DataLoader

    host_vars = HostVars(inventory=None, variable_manager=None, loader=None)
    host_vars._vars = {
        'foo': 'bar',
        'xyz': 'zzz'
    }
    expected = repr({'localhost': {'foo': 'bar', 'xyz': 'zzz'}})
    assert host_vars.__repr__() == expected, '__repr__() method should return string "{0}", but returned "{1}"'.format(expected, host_vars.__repr__())



# Generated at 2022-06-22 14:38:57.446422
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.host_vars import HostVars
    from ansible.vars import VariableManager

    # When host is in inventory, get its variables from inventory
    inventory = {}
    inventory['host1'] = {}
    inventory['host1']['vars'] = {'var1': 'value1'}
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert hostvars['host1']['var1'] == 'value1'

    # When host is not in inventory, create it
    inventory = {}
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

# Generated at 2022-06-22 14:39:07.001728
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    assert hostvars.__iter__()
    assert list(hostvars) == []

# Generated at 2022-06-22 14:39:33.600782
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # This test uses a HostVars instance that does not need an inventory or
    # loader.
    from ansible.vars.manager import VariableManager
    hostvars = HostVars(None, VariableManager())
    data = {'a': 'b'}
    nested_data = {'a': {'b': {'c': 'd'}}}
    # Test that getitem returns a HostVarsVars
    assert isinstance(hostvars._HostVars__getitem__(data), HostVarsVars)
    # Test that getitem returns the expected value
    assert hostvars._HostVars__getitem__(nested_data) == {'a': {'b': {'c': 'd'}}}

# Generated at 2022-06-22 14:39:43.277952
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    # Create an empty inventory
    inv = Inventory()

    # Create a variable manager with a single host
    var_manager = VariableManager()
    host = inv.get_host("localhost")
    var_manager.set_host_variable(host, "shared_var", 123)

    # Create HostVars with the same variable manager and no inventory
    hvars = HostVars(None, var_manager, None)

    # Verifiy that raw_get returns set host variable
    data = hvars.raw_get("localhost")
    assert(data["shared_var"] == 123)

    # Verifiy that raw_get does not return host variable if HostVars does not
    # have VariableManager

# Generated at 2022-06-22 14:39:55.366761
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():  # pylint: disable=too-many-locals
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventories = inventory_loader.get_inventory_sources(loader=loader, sources="files/mixed_hosts_1")
    inv_source = inventories[0]
    inventory = inv_source.inventory
    from ansible.vars import VariableManager
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    v = HostVars(inventory=inventory, loader=loader, variable_manager=variable_manager)

    # Check if raw_get returns the same dictionary as returned by __getitem__
    # for host=localhost

# Generated at 2022-06-22 14:39:56.898657
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    HostVars(None, None, None)['host_name']

# Generated at 2022-06-22 14:40:00.919807
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host
    host = Host("host")
    variables = {'var': 'value'}
    hostvars = HostVars({host: variables}, None, None)
    repr(hostvars)  # This doesn't fail

# Generated at 2022-06-22 14:40:06.036447
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # type: () -> None
    """
    Test the method __iter__ of class HostVars.
    """
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    assert hostvars.__iter__() is not None

# Generated at 2022-06-22 14:40:15.288986
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import os
    import sys

    if sys.version_info >= (3,):
        from io import StringIO
    else:
        from StringIO import StringIO

    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    script_dir = os.path.dirname(os.path.realpath(__file__))
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[os.path.join(script_dir, "hosts.ini")])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars_hosts = list(hostvars)

# Generated at 2022-06-22 14:40:26.888802
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():  # noqa: N802
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=[])
    hostvars = HostVars(inventory_manager, variable_manager, loader)
    assert repr(hostvars) == "{}"

    inventory_manager._inventory.hosts = [hostvars._find_host("fakehost")]
    hostvars._variable_manager._hostvars = hostvars

    hostvars._variable_manager.set_host_variable("fakehost", "foo", "bar")
    hostvars

# Generated at 2022-06-22 14:40:37.538822
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import collections
    import copy
    import types

    from ansible.vars import VariableManager

    # Set the test variables.
    test_vars = {'foo': 'bar'}

    # Create an instance of the HostVars class.
    test_HostVars_instance = HostVars({}, VariableManager())

    # Setup the expected result.
    expected_result = collections.Mapping.__repr__(test_HostVars_instance)

    # Test that the actual result matches the expected.
    assert repr(test_HostVars_instance) == expected_result

    # Check that the function return type is correct.
    assert isinstance(repr(test_HostVars_instance), types.StringType)

    # Check that the return value is not a reference to the input argument.

# Generated at 2022-06-22 14:40:43.443071
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager

    def __init__(self, inventory_manager, variable_manager, loader):
        self.inventory_manager = inventory_manager
        self.variable_manager = variable_manager
        self.loader = loader


    loader = None
    test = HostVars(InventoryManager(loader, ['/etc/ansible/hosts'], [], [], True), None, loader)
    assert test['all'] is not None



# Generated at 2022-06-22 14:41:36.847383
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from json import loads
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import variable_manager_loader
    from ansible.template import Templar

    input_data = {
        "localhost": {
            "foo": "bar",
            "bar": {"baz": "quux"},
            "dict": {
                "a": 1,
                "b": 2,
            },
            "quux": [
                "a",
                "b",
            ],
        },
    }
    inventory = InventoryManager(loader=None, sources=None)
    host = Host(name="localhost")
    host.set_variable("ansible_connection", "local")
    inventory.add_host(host)
    variable_manager = variable_manager_loader.get

# Generated at 2022-06-22 14:41:44.250221
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inv = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inv)
    variable_manager.set_variable_manager(variable_manager)
    hostvars = HostVars(inventory=inv, variable_manager=variable_manager, loader=None)
    assert isinstance(hostvars.raw_get('localhost'), Mapping)
    assert isinstance(hostvars.raw_get(host_name='localhost'), Mapping)

# Generated at 2022-06-22 14:41:50.703268
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Mock class Matrix
    class Matrix(object):
        def __init__(self):
            pass

    # Mock class Inventory(object):
    class Inventory(object):
        def __init__(self):
            self.matrix = Matrix()

    # Mock class Host(object):
    class Host(object):
        def __init__(self):
            pass

    # Mock class VariableManager(object):
    class VariableManager(object):
        def __init__(self):
            self._hostvars = HostVars(None, None, None)

        def get_vars(self, host, include_hostvars):
            return dict()

    host = Host()
    inventory = Inventory()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, None)

    # __getitem

# Generated at 2022-06-22 14:41:52.503208
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hostVars = HostVars({}, {}, {})
    assert hostVars.raw_get("localhost") == {}

# Generated at 2022-06-22 14:42:02.526094
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    hostvars = HostVars({
        "hostvars": {
            "host1": {
                "simple": "{{ var }}",
                "nested": "{{ var['nested'] }}"
            },
            "host2": {
                "simple": "static",
                "nested": "{{ var['nested'] }}"
            }
        }
    }, Templar({'var': {'nested': 'value'}}))

    expected = "{\n  'host1': {'nested': 'value', 'simple': 'value'},\n  'host2': {'nested': 'value', 'simple': 'static'}\n}"

    import json
    assert(json.dumps(hostvars, indent=2) == expected)

# Generated at 2022-06-22 14:42:14.191166
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import ansible.inventory
    import ansible.vars.manager
    from ansible.template.vars import AnsibleVars
    from ansible.plugins.loader import vars_loader

    # setup hostvars
    inv = ansible.inventory.Inventory(host_list=[])
    vars_mgr = ansible.vars.manager.VariableManager(loader=vars_loader)
    vars_mgr._hostvars = HostVars(inventory=inv, variable_manager=vars_mgr, loader=vars_loader)
    vars_mgr.set_host_variable(host='host1', varname='foo', value='bar')
    vars_mgr.set_host_variable(host='host2', varname='foo', value='baz')
    hostvars = vars_m

# Generated at 2022-06-22 14:42:26.507279
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import ansible.playbook.play_context as pcontext
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    inventory = MockInventory()
    variable_manager = VariableManager()
    loader = MockLoader()

    play_context = pcontext.PlayContext()

    play = Play.load(dict(hosts=inventory.list_hosts(), connection='local'),
                     variable_manager=variable_manager,
                     loader=loader,
                     play_context=play_context)

    hostVars = HostVars(inventory, variable_manager, loader)
    hostVars.set_variable_manager(variable_manager)
    hostVars.set_inventory(inventory)

    repr = repr(hostVars)


# Generated at 2022-06-22 14:42:36.062569
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import os.path
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_manager = VariableManager()
    inv = Inventory(loader=loader, variable_manager=vars_manager, host_list='localhost')

    hvars = HostVars(inv, vars_manager, loader)

    hvars.set_host_variable('localhost', 'test', '{{ x }} and {{ y }}')

    vars_manager.set_host_variable('localhost', 'x', 'Hello')
    vars_manager.set_host_variable('localhost', 'y', 'World')

    assert isinstance(hvars, HostVars)
    assert 'localhost' in hvars
    assert hvars['localhost']['test'] == 'Hello and World'


# Unit test

# Generated at 2022-06-22 14:42:44.414800
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = FakeInventory()
    variable_manager = FakeVariableManager()
    loader = FakeLoader()

    data = {
        'foo': 'foo',
        'bar': 'bar',
    }

    variable_manager.set_vars(data)
    inventory.add_host('test')

    host_vars = HostVars(inventory, variable_manager, loader)
    assert host_vars.raw_get('test') == data
    assert host_vars.raw_get('nope') == AnsibleUndefined(name="hostvars['nope']")
