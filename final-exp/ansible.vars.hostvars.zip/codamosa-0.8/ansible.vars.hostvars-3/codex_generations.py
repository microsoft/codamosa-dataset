

# Generated at 2022-06-22 14:32:59.717613
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Initialize inventory
    inventory = InventoryManager(host_list=["host1", "host2"])
    # Initialize variable manager
    variable_manager = VariableManager()

    # Initialize HostVars
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    # Test if key exists
    assert 'host1' in hostvars
    assert 'host2' in hostvars
    # Test if key not exists
    assert 'host3' not in hostvars

# Generated at 2022-06-22 14:33:06.294548
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import StrategyBase
    from ansible.vars.manager import VariableManager

    class StubbedStrategy(StrategyBase):
        def run(self, iterator, play_context):
            return iterator.get_next_task()

    inventory = Inventory(host_list='tests/units/inventory/hosts')
    play = Play().load({'hosts': 'all', 'gather_facts': 'no', 'tasks': []}, variable_manager=VariableManager(), loader=None)
    play_context = PlayContext()

    host_vars = HostVars(inventory, variable_manager=VariableManager(), loader=None)

# Generated at 2022-06-22 14:33:12.806884
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    variables = HostVars(inventory, VariableManager(loader=loader), loader)
    hostvars = variables.raw_get("localhost")
    hostvars_vars = HostVarsVars(hostvars, loader)

    assert 'inventory_hostname' in hostvars_vars

# Generated at 2022-06-22 14:33:22.500985
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # need a loader to retrieve vars data
    loader = DataLoader()
    # create a variable manager to retrieve vars data
    variable_manager = VariableManager()
    # create an inventory containing hosts to retrieve vars data
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager.set_inventory(inventory)

    # create a HostVars object
    hosts = HostVars(inventory, variable_manager, loader)

    # host without vars should return an AnsibleUndefined
    assert hosts.raw_get('localhost') is AnsibleUndefined

    # host with vars should return a dict containing that vars
    variable_manager.set_host_variable

# Generated at 2022-06-22 14:33:28.090902
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import copy
    from ansible.parsing.dataloader import DataLoader

    variables = dict(
        foo='foo',
        bar='{{ foo }}',
        baz='{{ foo }}{{ foo }}'
    )

    hostvars = HostVars({}, DataLoader())
    hostvars.set_variable_manager(variables)

    assert repr(hostvars) == repr(
        dict(
            foo='foo',
            bar='foo',
            baz='foofoo'
        )
    )

    # Test that method __repr__ of class HostVars returns deepcopy of variables
    variables['foo'] = 'bar'

# Generated at 2022-06-22 14:33:37.722856
# Unit test for method __repr__ of class HostVars

# Generated at 2022-06-22 14:33:42.825370
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    # For example, if we have a host with address 10.10.10.10 and
    # inventory has the following entries:
    # host_a ansible_host=10.10.10.10
    # host_b ansible_host=10.10.10.11
    # we should get 2 different 'ansible_host' values.

    host_a = FakeHost('host_a')
    host_a.set_variable('ansible_host', '10.10.10.10')

    host_b = FakeHost('host_b')
    host_b.set_variable('ansible_host', '10.10.10.11')

    inventory = FakeInventory(hosts=[host_a, host_b])
    variable_manager = FakeVariableManager()

    loader = FakeLoader()

    hostvars = HostV

# Generated at 2022-06-22 14:33:52.943808
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, host_list=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    hostvars.set_host_variable('localhost', 'foo', 'bar')
    assert hostvars.raw_get('localhost')['foo'] == 'bar'
    assert hostvars.raw_get('non-existent-host') == AnsibleUndefined(name="hostvars['non-existent-host']")



# Generated at 2022-06-22 14:34:01.321870
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager

    loader = '<ansible.parsing.dataloader.DataLoader object at 0xb7278dac>'
    loader = None
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = '<ansible.vars.manager.VariableManager object at 0xb7278d2c>'
    variable_manager = None
    hostvars = HostVars(inventory, variable_manager, loader)
    assert repr(hostvars) == "{}"


# Generated at 2022-06-22 14:34:05.648747
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    vm = VariableManager(loader=loader, inventory=inventory)
    hv = HostVars(inventory, vm, loader)

    assert hv.raw_get("localhost").items() == inventory.hosts[0].vars.items()

# Generated at 2022-06-22 14:34:19.375199
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from collections import namedtuple

    # HostVars takes two arguments to its constructor, so we can't use mock
    # with autospec=True.
    InventoryMock = namedtuple('InventoryMock', ['hosts'])
    VariableManagerMock = namedtuple('VariableManagerMock', ['get_vars'])
    HostMock = namedtuple('HostMock', ['name'])

    host1 = HostMock(name='host1')
    host2 = HostMock(name='host2')
    host3 = HostMock(name='host3')

    inventory = InventoryMock(hosts=[host1, host2])
    variable_manager = VariableManagerMock(get_vars=Mock(return_value={'var1': 'value1'}))

# Generated at 2022-06-22 14:34:29.634665
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.playbook.host import Host
    from ansible.vars.manager import VariableManager

    loader_mock = "The loader mock"

    class Inventory:
        def get_host(self, host_name):
            return Host(host_name)

        def hosts(self):
            return ['localhost', 'other_host']

    variables = { 'foo': 'bar',
                  'baz': { 'inner': 'what' } }

    class Loader:
        def get_basedir(self):
            return "The base dir"

    class DataLoader:
        def load(self, name, *args, **kwargs):
            return { 'vars': variables }

    loader = Loader()
    loader.set_vault_password("The file name", "The vault password")


# Generated at 2022-06-22 14:34:38.821359
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import ansible.errors as errors
    from io import BytesIO
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    loader = DataLoader()

    inventory = Inventory(loader=loader, host_list=['localhost'])
    inventory.add_host(Host(name='localhost'))
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    variable_manager._loader = variable_manager._loader or loader
    variable_manager._hostvars = variable_manager._hostvars or HostVars(inventory, variable_manager, loader)

    vars_cache = variable_

# Generated at 2022-06-22 14:34:47.044636
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_context.connection = 'local'
    inventory.set_play_context(play_context)

    host = Host(name='localhost')
    variable_manager.set_host_

# Generated at 2022-06-22 14:34:57.086607
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    def _create_variable_manager(loader):
        return VariableManager(loader=loader)

    def _create_loader(inventory_file):
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager

        loader = DataLoader()
        inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader), host_list=inventory_file)
        return loader

    # check if inventory_file exists
    import os
    assert os.path.isfile('tests/inventory')

    loader = _create_loader('tests/inventory')
    variable_manager = _create_variable_manager(loader)

    # check if 'hostvars' dict exists

# Generated at 2022-06-22 14:35:04.240631
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import collections
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variables = dict(key1=1, key2=2)
    hostvars_vars = HostVarsVars(variables, None)

    # Check that __iter__ returns Iterator that yields variables' keys
    assert isinstance(iter(hostvars_vars), collections.Iterator)
    assert set(variables.keys()) == set(hostvars_vars)


# Generated at 2022-06-22 14:35:14.374681
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)
    hostvars["localhost"] = { "ansible_all_ipv4_addresses" : [ "192.168.56.18" ] }
    assert hostvars.raw_get("localhost") == { "ansible_all_ipv4_addresses" : [ "192.168.56.18" ] }
    assert hostvars.raw_get("localhost") != hostvars["localhost"]

# Generated at 2022-06-22 14:35:24.601252
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # create dummy inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    test_host = Host('testhost')
    test_host.vars = dict(testkey='testvalue')

    test_group = Group('testgroup')
    test_group.add_host(test_host)

    test_inventory = InventoryManager([test_group], 'dummy')

    # create dummy variable manager
    from ansible.vars import VariableManager
    test_variable_manager = VariableManager()

    # create HostVars with dummy inventory and variable manager
    hv = HostVars(test_inventory, test_variable_manager, loader=None)

    # retrieve hostvars via raw_get
    raw_hostvars = hv.raw_get

# Generated at 2022-06-22 14:35:30.908506
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes

    loader = DataLoader()
    host_vars = HostVars(InventoryManager(loader, sources=[]),
                         VariableManager(loader=loader), loader)
    host_vars._vars = {'foo': 'bar', 'blip': 'blap'}
    assert repr(host_vars) == "{'localhost': hostvars['localhost']: {'foo': 'bar', 'blip': 'blap'}}"

# Generated at 2022-06-22 14:35:40.684696
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    '''
    Unit test for method raw_get of class HostVars.
    '''
    class MockHost:
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name

    class MockInventory:
        def __init__(self):
            self.hosts = [ MockHost('localhost'), MockHost('h1'), MockHost('h2') ]
        def get_host(self, host_name):
            if host_name == 'h1':
                return self.hosts[1]
            elif host_name == 'h2':
                return self.hosts[2]
            elif host_name == 'localhost':
                return None
            else:
                return None


# Generated at 2022-06-22 14:35:50.802313
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.plugins import plugin_loader
    from ansible.compat.six import StringIO

    fail_host = 'bad-host'

    plugin_loader.add_directory('./lib')
    inventory = plugin_loader.get('inventory')
    hostvars = inventory.inventory_plugin_class.hostvars_class()

    source = StringIO("""
[foo]
bar
""")

    inventory.parse(source, cache=False)

    assert set(hostvars) == set(('foo', 'bar'))

    assert fail_host not in hostvars

# Generated at 2022-06-22 14:35:57.917205
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from mock import Mock
    from ansible.vars.manager import VariableManager

    inventory = Mock()
    loader = Mock()
    ivm = Mock()
    ivm.get_vars.return_value = dict()

    hv = HostVars(inventory, ivm, loader)

    inventory.get_host.return_value = None
    assert isinstance(hv.raw_get('foo'), AnsibleUndefined)

    inventory.get_host.return_value = Mock()
    assert isinstance(hv.raw_get('foo'), dict)

# Generated at 2022-06-22 14:36:07.857552
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    host_vars = HostVars(InventoryManager(loader=DataLoader(), sources=[]), VariableManager(loader=DataLoader()), DataLoader())

    assert len(list(host_vars)) == 0

    host1 = host_vars._find_host('host1')
    host_vars.set_host_variable(host1, 'foo', 'bar')
    host_vars.set_host_variable(host1, 'ansible_host', 'host1.example.com')

    assert len(list(host_vars)) == 1
    assert list(host_vars) == ['host1']
    host_vars.set_host

# Generated at 2022-06-22 14:36:15.425390
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    '''
    Simple test for HostVars.__setstate__ without inventory and variable_manager
    '''
    class DummyInventory:
        def get_host(self, host_name):
            return None

    class DummyVariableManager:
        def __init__(self):
            self._loader = None
            self._hostvars = None

        def get_vars(self, host=None, include_hostvars=False):
            return AnsibleUndefined(name="HostVars test")

    inventory = DummyInventory()
    loader = None
    variable_manager = DummyVariableManager()

    hv = HostVars(inventory, variable_manager, loader)
    assert hv._inventory is None
    assert hv._loader is None
    assert hv._variable_manager is None

    hv.__set

# Generated at 2022-06-22 14:36:23.469217
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    i = Inventory(host_list=[])
    i.add_host(host='host1')
    i.add_host(host='host2')
    i.add_host(host='host3')

    v = VariableManager()

    h = HostVars(i, v, None)

    assert sorted(h) == [
        'host1',
        'host2',
        'host3',
    ]

# Generated at 2022-06-22 14:36:32.796954
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Hostvars should not return a value in case the host is not found
    assert hostvars.raw_get('non_existing_host') is None

    # Hostvars should return a known host if it exists
    assert hostvars.raw_get('localhost') is not None

# Generated at 2022-06-22 14:36:44.112949
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = True
    inventory = InventoryManager(loader=loader, sources=['unit/inventory/test_pattern.yml'])
    play_context = Play().load(dict(
        name="test play",
        hosts=["test_pattern"],
        gather_facts="no",
        gather_subset=[]
    ), variable_manager=VariableManager(loader=loader, inventory=inventory), loader=loader)

    hostvars = HostVars(inventory, play_context.variable_manager, loader=loader)


# Generated at 2022-06-22 14:36:46.114817
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import pytest
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    hvv = HostVarsVars({'y': '1'}, loader=loader)
    assert hvv['y'] == '1'


# Generated at 2022-06-22 14:36:57.877855
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    loader = DictDataLoader(dict())
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    hostvars = HostVars(inventory, inventory.get_variable_manager(), loader)
    state = hostvars.__getstate__()

    # Mock an empty VariableManager
    variable_manager = MagicMock()
    variable_manager._loader = None
    variable_manager._hostvars = None

    hostvars.set_variable_manager(variable_manager)
    hostvars = HostVars.__new__(HostVars)
    hostvars.__setstate__(state)

    assert hostvars._loader == loader
    assert hostvars._variable_manager._loader == loader
    assert hostvars._variable_manager._hostvars == hostvars

# Generated at 2022-06-22 14:37:02.467863
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    MockPlugin = namedtuple('Groups', ['name', 'vars'])
    loader = DataLoader()
    inv = VariableManager(loader=loader)
    inv.groups = {}

    hostvars = HostVars(inv, loader=loader)

    group = MockPlugin('group1', {'groupvar': 1})
    inv.groups['group1'] = group
    host = group.get_host('test_host')
    host.vars = {'hostvar': 2}

    assert not hostvars.raw_get('test_host')
    hostvars.set_inventory(inv)

# Generated at 2022-06-22 14:37:13.156217
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_data = b"""
    localhost   ansible_connection=local
    [web]
    foo         ansible_host=1.1.1.1
    [db]
    bar         ansible_host=2.2.2.2
    """
    inv = InventoryManager(loader=loader, sources=inv_data)
    variable_manager = VariableManager(loader=loader, inventory=inv)
    hostvars = HostVars(inventory=inv, variable_manager=variable_manager, loader=loader)

    host_variables = hostvars.raw_get(host_name='localhost')
    assert host_vari

# Generated at 2022-06-22 14:37:13.882828
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    assert 1

# Generated at 2022-06-22 14:37:23.964973
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    import mock

    variable_manager = VariableManager()
    variable_manager._vars_plugins = [mock.Mock(), mock.Mock()]
    variable_manager._vars_plugins[0].get_vars.return_value = {}
    variable_manager._vars_plugins[1].get_vars.return_value = {}
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=['127.0.0.1'])

    host_vars_view = HostVars(inventory, variable_manager, None)
    assert list(host_vars_view) == inventory.hosts


# Generated at 2022-06-22 14:37:30.126150
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    '''
    Test case for class HostVars method __repr__.
    Returns a string representation of the dict.
    '''
    test_host_vars = {
        'inventory_hostname': 'localhost',
        'inventory_hostname_short': 'localhost',
    }
    assert HostVarsVars(test_host_vars, None).__repr__() == test_host_vars

# Generated at 2022-06-22 14:37:36.776289
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # we need to prepare a fake inventory object that is used by HostVars
    class FakeInventory:
        def __init__(self, hosts, host_list):
            self.hosts = hosts
            self.list_hosts = host_list

        def get_host(self, name):
            if name in self.hosts:
                return self.hosts[name]
            elif name in self.list_hosts:
                return name
            else:
                return None

    # we need to prepare a fake variable manager that is used by HostVars
    class FakeVariableManager:
        def __init__(self, vars):
            self._vars = vars


# Generated at 2022-06-22 14:37:40.437066
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    result = HostVarsVars({'foo': 'bar', 'list': ["{{ foo }}"]}, loader=None)
    assert result['foo'] == 'bar'
    assert result['list'] == ['bar']

# Generated at 2022-06-22 14:37:49.872082
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible import constants as C
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host = Host(name='testhost')
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=None)

    hostvars = HostVars(inventory=None, loader=loader, variable_manager=variable_manager)

    # With variables
    hostvars.set_host_variable(host, 'var1', 'value1')
    hostvars.set_host_variable(host, 'var2', {'a': 1, 'b': 2})

    # With facts

# Generated at 2022-06-22 14:37:59.487155
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    host_vars = HostVars(inventory=inv_manager, variable_manager=variable_manager, loader=loader)
    hosts = list(host_vars)
    assert len(hosts) == 1
    assert hosts[0].name == 'localhost'


# Generated at 2022-06-22 14:38:09.761042
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # AnsibleUndefined is not a simple hashable object, so we need to mock it.
    # We will also use mock to ensure, that __getitem__ of HostVarsVars
    # correctly calls _templar.template().
    class AnsibleUndefinedMock(AnsibleUndefined):
        def __init__(self, name):
            self._name = name
            self._args = None

        def __hash__(self):
            return hash(self._name)

        def __eq__(self, other):
            return isinstance(other, AnsibleUndefinedMock) and self.__hash__() == other.__hash__()

        def __str__(self):
            return ''

        def __repr__(self):
            return "AnsibleUndefinedMock('%s')" % self._name

       

# Generated at 2022-06-22 14:38:21.531207
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    inv_dict = {
        'localhost': [
            'zeroconf',
            'other_zeroconf',
            'only_group'
        ],
        'other': [
            'other_only_group',
            'other_non_zero',
            'other_non_zero2'
        ]
    }
    inventory = InventoryManager(loader=loader, sources=StringIO(unicode(inv_dict)))

# Generated at 2022-06-22 14:38:28.018145
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import pytest

    foo = HostVarsVars(dict(), loader=None)
    assert(foo.__iter__())



# Generated at 2022-06-22 14:38:34.811510
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    class Dummy:
        pass

    loader = Dummy()
    loader.templar = Dummy()
    loader.templar.template = lambda x: x

    sut = HostVarsVars({'foo': 'bar'}, loader)

    # Because the loader.templar.template call is mocked to return the same variable, the result is a dictionary with
    # the same keys.
    assert list(sut) == ['foo']

# Generated at 2022-06-22 14:38:46.013736
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import copy

    playbook_path = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..', 'playbook_data.yml'))
    playbook_loader = DataLoader()
    variable_manager = VariableManager()

    # Create a hostvars instance with a variable manager that has an
    # empty _loader attribute.
    hostvars = HostVars({}, variable_manager=variable_manager)
    variable_manager._loader = None

    # Ensure that setstate method works correctly.
    hostvars.set_inventory(Inventory(loader=playbook_loader, variable_manager=variable_manager, host_list=playbook_path))
    hostvars.set_variable_manager(variable_manager)
    hostvars = copy.deepcopy(hostvars)

# Generated at 2022-06-22 14:38:46.464369
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    assert False

# Generated at 2022-06-22 14:38:56.398123
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.module_utils.ansible_galaxy import AnsibleGalaxy
    from ansible.utils.inventory import Inventory

    inventory = Inventory("", ansible_galaxy=AnsibleGalaxy())
    # Create a fake inventory host.
    inventory.hosts = ["host1", "host2", "host3"]
    host = inventory.get_host("host1")
    host.name = 'host1'
    host.vars = {'foo': 'bar'}
    inventory.get_host("host2")
    inventory.get_host("host3")
    vars_mgr = DummyVarsMgr()
    host_vars = HostVars(inventory, vars_mgr, loader=None)

# Generated at 2022-06-22 14:39:08.576713
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.dataloader import DataLoader

    h = Host('server')
    g = Group('g2')
    g.add_host(h)

    p = Play.load({
        'name': "Ansible Play",
        'hosts': 'g2',
        'gather_facts': 'no',
        'tasks': []
    }, loader=DataLoader())


# Generated at 2022-06-22 14:39:20.832857
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    data = dict(
        plugin='static',
        host_list=[
            dict(name='host1', port=22),
            dict(name='host2', port=22),
        ]
    )
    inventory = InventoryManager(loader=DataLoader(), sources=data)
    hostvars = HostVars(inventory=inventory, variable_manager=None, loader=None)

    # Test HostVars of hosts
    assert set(hostvars) == set([Host(name='host1', port=22, variables={}), Host(name='host2', port=22, variables={})])

    # Test HostVars of groups

# Generated at 2022-06-22 14:39:30.401445
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    data = {'a': 1, 'b': 2}
    variable_manager = VariableManager()
    variable_manager.extra_vars = data
    variable_manager.options_vars = data
    variable_manager.host_vars = data
    variable_manager.group_vars = data
    variable_manager.set_inventory(VariableManager(loader=None).get_inventory())
    hostvars = HostVars(variable_manager.get_inventory(), variable_manager, None)
    assert sorted(list(hostvars['localhost'].keys())) == sorted(['a', 'b', 'groups', 'omit', 'playbook_dir'])

# Generated at 2022-06-22 14:39:38.258456
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager._hostvars = None
    variable_manager._loader = None
    variable_manager.set_nonpersistent_facts(None, dict())

    data = variable_manager.__getstate__()

    variable_manager.__setstate__(data)

    assert variable_manager._loader is None

    loader = DataLoader()
    variable_manager._loader = loader

    data = variable_manager.__getstate__()

    variable_manager.__setstate__(data)

    assert variable_manager._loader is None

# Generated at 2022-06-22 14:39:42.960557
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    import sys
    if sys.version_info[0] == 3:
        raw_input = input
    else:
        # Python 2 backport
        raw_input = __import__("__builtin__").raw_input

    # DataLoader and InventoryManager are mocked.
    # Maybe we could use the real ones with a real inventory file ?
    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader, sources='localhost,')
    host = Host(name='localhost')
    inv_mgr.hosts = {'localhost': host}
    inv_mgr.groups = {}

    # Host

# Generated at 2022-06-22 14:39:54.756170
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    inventory_instance = 'INVENTORY INSTANCE'
    inventory_instance.hosts = ['HOST']
    variable_manager_instance = 'VARIABLE MANAGER INSTANCE'
    loader_instance = 'LOADER INSTANCE'

    hostvars = HostVars(inventory_instance, variable_manager_instance, loader_instance)

    assert next(iter(hostvars)) == 'HOST'

# Generated at 2022-06-22 14:40:07.617994
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    FACT_NAME = 'ansible_e'
    FACT_VALUE = 'example.com'
    ANSIBLE_E_HOST = 'ansible_e.example.com'
    NESTED_VARIABLE_NAME = 'nested_var'
    NESTED_VARIABLE_VALUE = 'nested_value'
    ANSIBLE_VAR_NAME = 'ansible_var'
    ANSIBLE_VAR_VALUE = 'ansible_value'
    VAR_NAME1 = 'var1'
    VAR_VALUE1 = 'hostvars'
    VAR_NAME2 = 'var2'
    VAR_VALUE2 = 'hostvars_ansible'
    # variable for Ansible host variable 'ansible_e' is the host name
    hostname = ANSIBLE_E

# Generated at 2022-06-22 14:40:16.104317
# Unit test for method __repr__ of class HostVars

# Generated at 2022-06-22 14:40:21.104759
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    my_var = {'var1': 'value1'}
    my_HostVarsVars = HostVarsVars(my_var, None)
    assert 'var1' in my_HostVarsVars
    assert len(my_HostVarsVars) == 1

# Generated at 2022-06-22 14:40:25.883239
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    hostvars_variables = dict(foo=dict(bar=dict(baz='test')))
    hostvars_variables_obj = HostVarsVars(hostvars_variables, loader=None)

    assert hostvars_variables_obj['foo']['bar']['baz'] == 'test'

# Generated at 2022-06-22 14:40:29.275329
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    inventory = InventoryManager(loader=loader, sources='tests/files/hostvars.ini')

    hostvars = HostVars(inventory=inventory, variable_manager=VariableManager(loader=loader, inventory=inventory), loader=loader)

    data = hostvars.raw_get(host_name='test1')
    assert data['test_v_host'] == 'host value'

# Generated at 2022-06-22 14:40:39.521673
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import copy
    from ansible.playbook.attribute import FieldAttribute

    loader = DictDataLoader({
        "vars": {
            "firstvar": "firstvalue",
            "secondvar": "secondvalue",
            "thirdvar": "{{ firstvar }}",
            "lastvar": "{{ firstvar }} and {{ secondvar }}"
        }
    })
    variables = {
        "firstvar": FieldAttribute(loader=loader, name="firstvar"),
        "secondvar": FieldAttribute(loader=loader, name="secondvar"),
        "thirdvar": FieldAttribute(loader=loader, name="thirdvar"),
        "lastvar": FieldAttribute(loader=loader, name="lastvar")
    }
    variables = copy.deepcopy(variables)

    class Foo(Mapping):
        def __init__(self):
            pass

# Generated at 2022-06-22 14:40:49.495002
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    def _find_host(host_name):
        if host_name == 'host1':
            return 'host1'
        raise ValueError('host %s not found' % host_name)

    class _VariableManager(object):

        def get_vars(self, host, include_hostvars=False):
            if include_hostvars:
                raise AssertionError('include_hostvars must be False')
            if host == 'host1':
                return {'foo': 'bar', 'name': 'host1'}
            raise AssertionError('Unknown host: %s' % host)

    class _Loader(object):
        pass

    class _Inventory(object):
        hosts = ['host1']

    loader = _Loader()
    inventory = _Inventory()
    variable_manager = _VariableManager()


# Generated at 2022-06-22 14:40:57.199233
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    inventory.hosts = set()
    for i in range(10):
        inventory.hosts.add('host%s' % i)

    variable_manager = VariableManager()
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    for i, host in enumerate(hostvars):
        assert host == 'host%s' % i



# Generated at 2022-06-22 14:41:07.992217
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    result = hostvars.raw_get('localhost')
    assert result['inventory_hostname'] == 'localhost'

    # set inventory_hostname in the inventory
    inventory.add_group('group')
    inventory.add_host(host='localhost', group='group', port=22)
    inventory.set_variable(host='localhost', varname='inventory_hostname', value='newhost')

    # verify that setting the inventory_hostname

# Generated at 2022-06-22 14:41:26.898365
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['tests/test_static_variables/host_vars'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    for host in hostvars:
        assert isinstance(host, basestring)

# Generated at 2022-06-22 14:41:27.858852
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    pass # FIXME: need test

# Generated at 2022-06-22 14:41:36.170903
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=hosts)
    hostvars = HostVars(inventory=hosts, variable_manager=variable_manager, loader=loader)

    assert hostvars.raw_get(host_name='localhost') == {
        'group_names': [],
        'inventory_hostname': 'localhost',
        'inventory_hostname_short': 'localhost'
    }


# Generated at 2022-06-22 14:41:41.498842
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    host_vars_vars = HostVarsVars(variables={'var1': 'value1', 'var2': 'value2'}, loader=None)
    variables = [variable for variable in host_vars_vars]
    assert len(variables) == 2 and 'var1' in variables and 'var2' in variables


# Generated at 2022-06-22 14:41:48.682044
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.unsafe_proxy import wrap_var

    class FakeLoader:
        def __init__(self, *args, **kwargs):
            # Dummy attributes included to test that they are not used
            self.path_info = None
            self.path_info_orig = None
            self.searchpath = []

    fake_loader = FakeLoader()

    test_vars = {'foo': 'bar', 'baz': 'qux'}
    test_vars = wrap_var(test_vars)
    test_obj = HostVarsVars(test_vars, fake_loader)
    assert sorted(['foo', 'baz']) == sorted(list(test_obj.__iter__()))


# Generated at 2022-06-22 14:41:56.399410
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hvars = HostVars(inventory, variable_manager, loader=DataLoader())

    assert hvars.raw_get('localhost') == {}

# Generated at 2022-06-22 14:41:59.969746
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    h = HostVars(inventory=None, variable_manager=VariableManager(), loader=DataLoader())
    assert h.raw_get('localhost') == {}

# Generated at 2022-06-22 14:42:11.681129
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory('/my/path/to/inventory')
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'foo_value'}
    variable_manager.options_vars = {'bar': 'bar_value'}
    variable_manager._loader = None
    variable_manager._hostvars = None
    hostvars = HostVars(inventory, variable_manager, None)
    assert hostvars._loader is None and hostvars._variable_manager._loader is None
    assert hostvars._variable_manager._hostvars is None

    new_variable_manager = VariableManager()
    new_variable_manager.extra_vars = {'foo': 'foo_value'}
    new_

# Generated at 2022-06-22 14:42:22.697791
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager

    inventory_manager = InventoryManager(loader=None)
    inventory = inventory_manager.inventory
    inventory.add_host('local')
    inventory.add_host('remote')
    inventory.add_group('all')
    inventory.add_group('all2')
    inventory.add_child('all', 'local')
    inventory.add_child('all', 'remote')
    inventory.add_child('all2', 'remote')

    hostvars = HostVars(inventory, None, None)

    assert repr(hostvars) == "{'all': {}, 'all2': {}, 'remote': {}, 'local': {}}"


# Generated at 2022-06-22 14:42:26.343565
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = DictDataLoader(dict())
    hvv = HostVarsVars(dict(a=1, b=2, c=3), loader=loader)
    assert set(hvv.keys()) == {'a', 'b', 'c'}