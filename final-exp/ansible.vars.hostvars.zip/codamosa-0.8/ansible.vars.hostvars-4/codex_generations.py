

# Generated at 2022-06-22 14:33:02.260334
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class Inventory:
        def __init__(self):
            self.hosts = [Host(i) for i in [1, 2]]
            pass
        def get_host(self, host_name):
            for host in self.hosts:
                if host.name == host_name:
                    return host
            return None

    class Host:
        def __init__(self, name):
            self.name = str(name)
        def get_name(self):
            return self.name

    inventory = Inventory()
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

   

# Generated at 2022-06-22 14:33:05.790434
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    hostvars['localhost']

# Generated at 2022-06-22 14:33:15.433658
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    """
    Make sure __iter__ returns a generator
    """

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

    class FakeInventory(object):
        def __init__(self, hosts):
            self.hosts = hosts

    class FakeLoader(object):
        def __init__(self):
            pass

    class FakeVariableManager(object):
        def __init__(self, loader):
            self._loader = loader
            self._hostvars = None

    hosts = [FakeHost('host0'), FakeHost('host1'), FakeHost('host2'), FakeHost('host3')]
    inventory = FakeInventory(hosts)
    loader = FakeLoader()
    variable_manager = FakeVariableManager(loader)


# Generated at 2022-06-22 14:33:24.820845
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os
    import sys
    import json
    import yaml
    from ansible.inventory.manager import InventoryManager
    host_vars = HostVars(InventoryManager(['localhost']), None, None)
    host_vars.set_host_facts('localhost', { 'foo': 'bar' })
    host_vars['localhost']['foo'] = 'baz'
    host_vars.set_host_variable('localhost', 'baz', 'boo')
    host_vars.set_nonpersistent_facts('localhost', { 'qux': 'quux' })
    raw_vars = host_vars.raw_get('localhost')
    raw_vars_baz = raw_vars['baz']
    assert(raw_vars_baz == 'boo')

# Generated at 2022-06-22 14:33:30.968851
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    context._init_global_context(loader=loader)
    variable_manager = VariableManager(loader=loader)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)
    host_vars = HostVars(None, variable_manager, loader)

    # hostvars should not be run through the templating engine to expand
    # variables in the hostvars.
    host_vars.set_nonpersistent_facts('localhost', {'type': '{{ type }}'})
    # Templating still occurs for host variables to support using facts in

# Generated at 2022-06-22 14:33:40.006615
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    ''' Unit test for method __iter__ of class HostVarsVars '''

    # Iterable object
    obj = HostVarsVars({'foo': 'bar', 'baz': 'qux'}, None)
    actual = []
    for val in obj:
        actual.append(val)

    expected = ['foo', 'baz']
    assert len(actual) == len(expected), "Expected {} to equal {}".format(actual, expected)
    for actual_item, expected_item in zip(actual, expected):
        assert actual_item == expected_item, "Expected {} to equal {}".format(actual_item, expected_item)

    # Non-iterable object
    obj = HostVarsVars(None, None)

# Generated at 2022-06-22 14:33:43.987892
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    host = 'testhost'
    vars = {'test1': 'test1'}
    variable_manager.set_host_variable(inventory.get_host(host), 'vars', vars)
    variable_manager.set_host_variable(inventory.get_host(host), 'groups', ['testgroup'])
    facts = {'test2': 'test2'}

# Generated at 2022-06-22 14:33:53.767517
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os
    import ansible.inventory.manager
    import ansible.constants as C
    import ansible.vars.manager

    loader = DictDataLoader({
      'yaml': '''
      hostvars:
        localhost:
          key_01: val_01
          key_02: val_02
          key_03:
            - val_03_a
            - val_03_b
            - val_03_c
      '''
    })
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources='yaml')
    variable_manager = ansible.vars.manager.VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-22 14:33:55.234381
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # TODO
    pass

# Generated at 2022-06-22 14:34:05.858265
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os
    import sys

    import ansible.inventory
    import ansible.variable_manager
    import ansible.utils.vars

    inventory_base_path = os.path.join(os.path.dirname(__file__), "..", "inventory")

    # =========================================
    # Set up inventory, variables and loader

    # The (short) hostname of a host that is not in the inventory
    host_name = 'some_unknown_host'

    # Create an inventory with a host whose name is host_name
    inventory = ansible.inventory.Inventory([os.path.join(inventory_base_path, 'host_vars', "hosts")])

    # Create a variable manager with empty variables
    variables = ansible.utils.vars.AnsibleVars({}, None, None)

# Generated at 2022-06-22 14:34:19.201998
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Deeply nested variables
    x = [
        'item1',
        {'item2': 'item2'},
        {'item3': {'item4': 'item4'}},
    ]
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    variables = VariableManager()
    loader = DataLoader()
    hostvars = HostVarsVars(variables, loader)
    hostvars._vars = x
    assert hostvars['item2'] == 'item2'
    assert hostvars['item3']['item4'] == 'item4'
    assert hostvars[1]['item2'] == 'item2'
    assert hostvars[2]['item3'] == {'item4': 'item4'}


# Generated at 2022-06-22 14:34:29.313109
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = MagicMock()
    inventory.hosts = ['a', 'b', 'c']
    host_a = MagicMock()
    host_b = MagicMock()
    host_c = MagicMock()
    inventory.get_host.side_effect = [host_a, host_b, host_c]
    variable_manager = MagicMock()
    variable_manager.get_vars.return_value = {'a': 'A', 'b': 'B', 'c': 'C'}
    loader = MagicMock()
    host_vars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-22 14:34:36.886816
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inventory = InventoryManager(loader, 'localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host_vars = HostVars(inventory, variable_manager, loader)
    host_vars._vars.update({'hostname': 'host1', 'var': 'foo'})
    assert str(host_vars) == "{'host1': {'var': 'foo'}}"

# Generated at 2022-06-22 14:34:45.874039
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import json
    import pytest
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ds = DataLoader()
    t = Templar(variables={'hostvars': 'hostvars'}, loader=ds)
    vm = VariableManager(loader=ds)

    hostvars = HostVars(inventory=None, loader=ds, variable_manager=vm)

    # Setup data

# Generated at 2022-06-22 14:34:55.075719
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from collections import namedtuple

    inventory = namedtuple('Inventory', ['hosts'])(['hostA', 'hostB', 'hostC'])
    variable_manager = namedtuple('VariableManager', ['_hostvars', '_vars_plugins', '_extra_vars'])({}, {}, {})
    loader = namedtuple('Loader', ['_basedir'])('/')
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.raw_get = lambda host_name: 'foo'

    expected = "{'hostA': 'foo', 'hostB': 'foo', 'hostC': 'foo'}"
    assert repr(hostvars) == expected


# Generated at 2022-06-22 14:35:05.113578
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None)
    variable_manager = VariableManager(loader=None)

    inventory.set_variable('localhost', 'foo', 'bar')
    host = Host('localhost')
    inventory.add_host(host)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # The variable foo should be present in hostvars
    assert 'foo' in hostvars['localhost']

    # Get the variables dict without templating
    variables = hostvars.raw_get('localhost')

    # Now the variable foo should be a string, not a Template
    assert isinstance(variables['foo'], str)

# Generated at 2022-06-22 14:35:14.823291
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from collections import Iterable

    inventory_file = "./test/units/data/hostvars/hosts"
    inventory = InventoryManager(loader=DataLoader(), sources=inventory_file)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())

    assert isinstance(hostvars.__iter__(), Iterable)
    hosts = []
    for host in hostvars:
        hosts.append(host)
    assert hosts == inventory.hosts

# Generated at 2022-06-22 14:35:19.869495
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # pylint: disable=too-many-function-args
    mocker = Mocker()
    hostname = 'testhost'
    allvars = {'a': 'b'}
    inventory = mocker.mock()
    variable_manager = mocker.mock()
    loader = mocker.mock()
    # a host is required for all _find_host method calls
    host = mocker.mock()
    host.get_name.return_value = hostname
    inventory.get_host(hostname)
    mocker.result(host)
    variable_manager.get_vars(host=host, include_hostvars=False)
    mocker.result(allvars)
    mocker.replay()

# Generated at 2022-06-22 14:35:29.010833
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # vars_cache for the localhost host
    vars_cache = {'a': 'A', 'b': 'B'}
    # Create a HostVars object and set the vars cacne for the localhost host
    hostvars = HostVars(None, variable_manager, loader)
    hostvars.set_variable_manager(variable_manager)
    variable_manager.set_vars(vars=vars_cache, host=variable_manager._loader.get_basedir())

    # HostVars object has a hostvars value for localhost host, but it is
    # not yet expanded (variables in the value are not yet

# Generated at 2022-06-22 14:35:38.504700
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import ansible.constants as C
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    vars = VariableManager(loader=loader)

    hosts = Inventory(loader=loader, variable_manager=vars)
    hosts.add_host('1')

    vars.set_host_variable('1', 'a', 'b')

    hostvars = HostVars(hosts, vars, loader)
    assert str(hostvars['1']) == "{u'a': u'b'}"
    assert isinstance(hostvars['1'], HostVarsVars)
    assert isinstance(hostvars.raw_get('1'), dict)


# Generated at 2022-06-22 14:35:50.850210
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    hostvars = HostVars(
        inventory=None,
        variable_manager=None,
        loader=None
    )

    hostvars.raw_get = lambda host_name: {'var_1': 1} if host_name == 'host_1' else AnsibleUndefined('host_2')
    hostvars._find_host = lambda host_name: 'host_1' if host_name == 'host_1' else None

    assert hostvars['host_1'] == {'var_1': 1}
    assert isinstance(hostvars['host_2'], AnsibleUndefined)

# Generated at 2022-06-22 14:35:56.680132
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars_vars = HostVarsVars({'key_1': 'value_1', 'key_2': 'value_2'}, None)
    key_list = []
    for key in hostvars_vars:
        key_list.append(key)
    assert len(key_list) == 2
    assert 'key_1' in key_list
    assert 'key_2' in key_list



# Generated at 2022-06-22 14:36:02.669233
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.plugins import vars_loader

    inventory = MagicMock()
    variable_manager = vars_loader.VariableManager(loader=None)

    hostvars = HostVars(inventory, variable_manager, loader=None)
    for x in hostvars:
        print(x)

    # Check if inventory.hosts was called
    assert inventory.hosts.called == True, 'inventory.hosts was not called'


# Generated at 2022-06-22 14:36:06.334281
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = DictDataLoader({})
    my_vars = HostVarsVars({u'a': u'1', u'b': u'2'}, loader=loader)
    assert list(my_vars) == [u'a', u'b']



# Generated at 2022-06-22 14:36:14.532586
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vars_manager = VariableManager()
    loader._vault = VaultSecret('secret', loader)

    # create an empty inventory
    inventory = InventoryManager(loader=loader, variable_manager=vars_manager, sources=[])
    hostvars = HostVars(inventory, vars_manager, loader)

    # create a group
    group = InventoryGroup('test_hostvars')
    inventory.add_group(group)

    # create a host
    host = InventoryHost('hostname')
    host.vars['var1'] = '1'
    host.vars['var2'] = '2'
   

# Generated at 2022-06-22 14:36:18.464528
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = {'test': '{{test2}}', 'test2': 'foo'}
    loader = None
    hostvarsvars = HostVarsVars(variables, loader)
    assert hostvarsvars['test'] == 'foo'

# Generated at 2022-06-22 14:36:28.626714
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Build mocks and a host
    class MockHost(object):
        name = 'foo'
    variable_manager = Mock()
    variable_manager.get_vars.return_value = {'a': {'b': 'c'}}
    variable_manager.set_nonpersistent_facts.return_value = None
    variable_manager.set_host_facts.return_value = None
    inventory = Mock()
    inventory.hosts = [MockHost()]
    loader = Mock()

    # Create object
    hv = HostVars(inventory, variable_manager, loader)

    # Test
    assert repr(hv) == "{'foo': {'a': {'b': 'c'}}}"

# Generated at 2022-06-22 14:36:34.347770
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.host import Host

    h = Host('testing')
    h.set_variable('foo', 'bar')
    h.set_variable('nested', {'value': '42'})

    v = HostVars({'localhost': h}, None, None)

    assert v.raw_get('localhost') == {'foo': 'bar', 'nested': {'value': '42'}}
    assert v.raw_get('non-exist') == AnsibleUndefined(name="hostvars['non-exist']")

# Generated at 2022-06-22 14:36:44.232784
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    h1 = Host('h1')
    h2 = Host('h2')

    g1 = Group('g1')
    g1.add_host(h1)

    g2 = Group('g2')
    g2.add_host(h2)

    i = FakeInventory([h1, h2, g1, g2])

    vars_manager = FakeVariableManager()
    hostvars = HostVars(i, vars_manager, loader=None)

    assert set(hostvars) == {h1, h2}



# Generated at 2022-06-22 14:36:51.099079
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from collections import MutableMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    assert isinstance(hostvars, MutableMapping)

    inventory.hosts.append(Host(name="test_host"))
    variable_manager.set_host_variable(inventory.hosts[0], "test_var", "test_value")


# Generated at 2022-06-22 14:37:09.040159
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Host
    from ansible.vars import VariableManager
    host_a = Host('host_a')
    host_b = Host('host_b')
    host_c = Host('host_c')
    host_d = Host('host_d')

    inventory = type('Inventory', (object,), {'hosts': set([host_a, host_b, host_c, host_d])})

    hostvars = HostVars(inventory, VariableManager(), None)
    iterated_hosts = set()

    for host in hostvars:
        iterated_hosts.add(host)

    assert iterated_hosts == inventory.hosts

# Generated at 2022-06-22 14:37:18.317863
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Note: we cannot use mock in unittests because it replaces the original
    # objects and methods.
    class Inventory(object):
        def __init__(self):
            self.hosts = ['host1', 'host2', 'host3']
        def get_host(self, host_name):
            if host_name in self.hosts:
                return host_name
            return None

    hostvars = HostVars(Inventory(), None, None)
    hosts = []
    for host in hostvars:
        hosts.append(host)
    assert hosts == ['host1', 'host2', 'host3']

# Generated at 2022-06-22 14:37:25.196776
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    variables = hostvars['localhost']
    assert isinstance(variables, HostVarsVars)

    names = [name for name in variables]
    assert isinstance(names, list)
    assert len(names) > 0
    assert 'omit' in names


# Generated at 2022-06-22 14:37:34.542975
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class TestInventory(object):
        def __init__(self):
            self.hosts = {}

        def add_host(self, host):
            self.hosts[host.name] = host

        def get_host(self, name):
            return self.hosts.get(name)

    inventory = TestInventory()
    inventory.add_host(InventoryManager._create_dummy_host('localhost'))
    loader = None
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable('localhost', 'new_var', 'new_value')

    assert 'new_var' in hostvars.raw_get

# Generated at 2022-06-22 14:37:45.636852
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    hv = HostVars(inventory=None, variable_manager=None, loader=None)

    class MockHost:
        def __init__(self, name):
            self.name = name

    # If host is not found in the inventory, returns AnsibleUndefined
    assert isinstance(hv.raw_get("invalid_host"), AnsibleUndefined)

    # If host is found in the inventory, returns the host's variables
    host_name = "test_host"
    hv._inventory.hosts = [MockHost(host_name)]
    assert hv.raw_get(host_name) is hv._variable_manager.get_vars(host=host_name, include_hostvars=False)

# Generated at 2022-06-22 14:37:57.506768
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._loader = loader

    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    variable_manager.set_inventory(inventory)

    group = Group('group1')
    inventory.add_group(group)

    host = Host('localhost')
    group.add_host(host)

    variable_manager.set_nonpersistent_facts(host, dict(key1='value1'))


# Generated at 2022-06-22 14:38:06.552355
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager._hostvars = HostVars(None, variable_manager, None)

    variable_manager.set_host_variable(None, 'foo', 'bar')
    variable_manager.set_host_variable(None, 'baz', ['ban', 'foo', 'bar'])
    variable_manager.set_host_variable(None, 'val', {'v1': 1, 'v2': 2})

    assert str(variable_manager._hostvars['localhost']) == "{'baz': ['ban', 'foo', 'bar'], 'foo': 'bar', 'val': {'v2': 2, 'v1': 1}}"

# Generated at 2022-06-22 14:38:18.032872
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # This example is based on the inventory unit test in test_script.py

    # base configuration
    root_dir = os.path.join(os.path.dirname(__file__), '../..')
    inventory = InventoryManager(loader=DataLoader(), sources=root_dir + '/test/units/inventory/host_vars')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager._fact_cache = dict(all=dict(inventory_hostname='localhost', foo='bar'))

    hostvars = HostVars(inventory, variable_manager, DataLoader())
    repr_hostvars = repr(hostvars)



# Generated at 2022-06-22 14:38:24.549029
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    hv = HostVars(None, None, None)
    hv._inventory = _MockInventory()
    assert repr(hv) == "{'host1': {'foo': 'bar'}, 'host2': {'foo': 'baz'}, 'host3': {'foo': 'bip'}, 'host4': {}}"



# Generated at 2022-06-22 14:38:36.444023
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    inventory.add_host(host='localhost')

    # fake inventory data
    i_p = inventory.get_host('localhost').get_vars()
    i_p['foo'] = 'bar'
    i_p['bar'] = 'baz'

# Generated at 2022-06-22 14:39:01.024329
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    '''
    Unit tests for method __setstate__ of class HostVars.
    '''

    # Create loader object
    loader = DictDataLoader({})

    # Create variable manager object
    variable_manager = VariableManager(loader=loader)

    # Create inventory object
    inventory = Inventory(loader=loader)

    # Create HostVars object
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create state object
    state = {
        '_inventory': inventory,
        '_loader': loader,
        '_variable_manager': variable_manager,
    }

    # Call method and verify results
    hostvars.__setstate__(state)
    assert(hostvars._inventory is inventory)
    assert(hostvars._loader is loader)

# Generated at 2022-06-22 14:39:11.002571
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar

    # A dict with a dict inside
    foo = dict(bar=dict(a=1, b=2), baz=dict(c=3, d=4))

    # A dict with a dict inside that contains a dict with a dict inside
    bar = dict(bar=UnsafeProxy(dict(a=1, b=2, c=dict(d=3, e=4))))

    # A variable manager to evaluate the dicts above
    variable_manager = dict(loader=None, _fact_cache={})

    # Two Templars to evaluate the dicts above
    foo_templar = Templar(variables=variable_manager['_fact_cache'], loader=variable_manager['loader'])
    bar_templar = Templar

# Generated at 2022-06-22 14:39:21.197121
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    vm = inventory._variable_manager
    hostvars1 = HostVars(inventory, vm, loader)

    variables = {'foo': 'bar'}
    hostvars2 = HostVarsVars(variables, loader)
    # test with hostvars1 inside hostvars2
    variables['hostvars'] = hostvars1
    assert repr(hostvars2) == repr(variables)
    # test with hostvars2 inside hostvars1
    hostvars1['hostvars'] = hostvars2


# Generated at 2022-06-22 14:39:30.879500
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    """
    # Test method __repr__ of class HostVars
    """
    import ansible.errors

    # We need to stub some objects, classes and functions to avoid the
    # call of functions which are not implemented by this test.
    class StubInventory(object):
        hosts = {"host_1", "host_2"}
        def get_host(self, host_name):
            return None

    class StubVariableManager(object):
        def get_vars(self, host=None, include_hostvars=True):
            return {}

    loader = ansible.errors.AnsibleError

    hostvars = HostVars(inventory=StubInventory(), variable_manager=StubVariableManager(), loader=loader)

    # The goal of this test is to ensure that the method __repr__ of
    # class HostV

# Generated at 2022-06-22 14:39:39.834920
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    mock_inventory = MutableMapping()
    mock_inventory.hosts = ['foo']
    mock_loader = DataLoader()
    mock_variable_manager = VariableManager()
    mock_host = Host('foo')

    hostvars = HostVars(mock_inventory, mock_variable_manager, mock_loader)
    assert isinstance(hostvars, Mapping)

    mock_variable_manager.set_host_variable(mock_host, 'var', 'val')
    for host in hostvars:
        assert isinstance(host, Host)
        assert host

# Generated at 2022-06-22 14:39:51.715694
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import ansible.plugins.loader as plugin_loader
    loader = plugin_loader.PluginLoader('.')
    inventory = None

    # Check if 'ansible_version' is present in the iterator.
    # Note that 'ansible_version' is not present in vars_cache.
    variables = {'ansible_version': '1.2.3'}
    hostvars_vars = HostVarsVars(variables, loader)
    assert 'ansible_version' in hostvars_vars.__iter__()

    # Check if 'ansible_version' is not present in the iterator.
    # Note that 'ansible_version' is present in vars_cache.
    variables = {}
    hostvars = HostVars(inventory, None, loader)
    hostvars.set_variable_manager(None)

# Generated at 2022-06-22 14:39:59.198418
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    inventory = MockInventory([Host(name='foo')])
    variable_manager = MockVariableManager(
        {'foo': {'var1': 'value1', 'var2': '{{ var1 }}', 'var3': '{{ var5 }}'}},
        {'var5': 'value5'}
    )
    loader = MockLoader()

    hvars = HostVars(inventory, variable_manager, loader)

    # We expect the value of var2 to be the result of the template expansion
    # of '{{ var1 }}', which was replaced by the raw value 'value1' in the mock.
    assert hvars

# Generated at 2022-06-22 14:40:05.401681
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext

    c = PlayContext()
    c.vars = {'x': 'y'}
    a = HostVarsVars(c.vars, c)

    for element in a:
        print(element)

# Generated at 2022-06-22 14:40:14.800837
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import sys
    import imp
    import os
    import tempfile
    import textwrap
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 3

    # Make sure we have a caller_file, so Python 2.6 doesn't refuse to write the cache file.
    caller_file = os.path.abspath(__file__)

    tmp_path = tempfile.mkdtemp()
    test_hosts = os.path.join(tmp_path, "hosts")

# Generated at 2022-06-22 14:40:26.469195
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Get a stub of class HostVars
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)

    # Store original values of attributes
    _loader = hostvars._loader
    _inventory = hostvars._inventory
    _vars = hostvars._variable_manager._vars
    _hostvars = hostvars._variable_manager._hostvars

    # Set attribute values to None to imitate a situation when
    # the object is taken from the disk.
    hostvars.set_variable_manager(variable_manager=None)
    hostvars.set_inventory(inventory=None)

    # Dict containing the data to be assigned to attributes.

# Generated at 2022-06-22 14:41:10.366193
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.plugins.loader as plugin_loader

    host_name = 'test_host'
    hostvars = HostVars(InventoryManager(plugin_loader.load_inventory('localhost')), VariableManager(),
                        plugin_loader)
    assert len(hostvars.raw_get(host_name)) == 2
    assert 'groups' in hostvars.raw_get(host_name)
    assert 'all' in hostvars.raw_get(host_name)['groups']
    assert 'children' in hostvars.raw_get(host_name)
    assert 'ungrouped' in hostvars.raw_get(host_name)['children']
    assert 'localhost' in hostvars.raw_get

# Generated at 2022-06-22 14:41:14.300546
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {"data": "test_HostVarsVars___iter__"}
    loader = None
    host_vars_vars = HostVarsVars(variables, loader)

    assert list(iter(host_vars_vars)) == list(iter(variables))

# Generated at 2022-06-22 14:41:24.859792
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Setup
    vars_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    hostvars = HostVars(inventory=inventory, variable_manager=vars_manager, loader=loader)

    # Test
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_variable(inventory.get_host('localhost'), 'ansible_ssh_host', '127.0.0.1')

# Generated at 2022-06-22 14:41:35.046139
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context
    import ansible.constants as C
    import os


# Generated at 2022-06-22 14:41:45.722942
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create and add a host to the inventory
    host = inventory.get_host(u'testhost')
    host.vars = dict(foo=u'"Hello world"')
    inventory.add_host(host)
    # Value of variable "foo" from the inventory is the same as from HostVars

# Generated at 2022-06-22 14:41:54.135388
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Test for the method __getitem__ of class HostVars.
    '''
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    host = ["localhost"]
    inventory = InventoryManager(host_list=host)
    variable_manager = VariableManager()

    hv = HostVars(inventory, variable_manager, loader=None)
    assert hv["localhost"] == hv.raw_get("localhost")


# Generated at 2022-06-22 14:42:04.637168
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    variable_manager.set_nonpersistent_facts(inventory.get_host('localhost'), {
        'hostvarstest': {'key1': 'val1', 'key2': 'val2'},
        'hostvarstest2': {'key3': 'val3', 'key4': 'val4'}
    })
    variable_manager

# Generated at 2022-06-22 14:42:17.076827
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    hostvars = HostVars(InventoryManager(loader=loader, sources=[]),
                        VariableManager(loader=loader, inventory=None), loader)

    hostvars.set_variable_manager(VariableManager(loader=loader, inventory=None))
    assert hostvars.raw_get('foo') == {}

    inventory = InventoryManager(loader=loader, sources=['localhost'])
    hostvars.set_inventory(inventory)

    assert hostvars.raw_get('foo') == {}

    inventory.add_host(Host(name='foo'))
    assert hostvars

# Generated at 2022-06-22 14:42:28.823981
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class Inventory(Mapping):
        def __init__(self, items):
            self._items = items
            self.hosts = items.keys()

        def __getitem__(self, key):
            return self._items.get(key)

        def __contains__(self, item):
            return item in self._items
        def __iter__(self):
            for item in self._items:
               yield item
        def __len__(self):
            return len(self._items)
    class VariableManager:
        def __init__(self):
            self.vars = {'host': 'host'}

        def set_host_variable(self, host, varname, value):
            self.vars['host'] = host
    class Host:
        def __init__(self, name):
            self.name

# Generated at 2022-06-22 14:42:34.403938
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = {
        'var_one': '{{var_two}}',
        'var_two': '{{var_three}}',
        'var_three': 'I am var_three',
    }
    host_vars_vars = HostVarsVars(variables, loader=None)
    assert host_vars_vars['var_one'] == 'I am var_three'