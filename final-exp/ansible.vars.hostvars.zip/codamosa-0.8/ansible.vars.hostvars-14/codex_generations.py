

# Generated at 2022-06-22 14:33:02.661286
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert "localhost" in hostvars
    assert len(hostvars) == 1

    # iterate over objects of class HostVars
    assert "localhost" in [ x for x in hostvars ]

    # iterate over objects of class dict
    assert "localhost" in [ x for x in hostvars.items() ]

    # iterate over objects of class dict
    assert "localhost" in [ x for x in hostvars.keys() ]

    # iterate over objects of class dict

# Generated at 2022-06-22 14:33:10.848211
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = MockInventory()
    loader = MockLoader()
    variable_manager = MockVariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)
    foo = repr(hostvars)
    assert(foo == "{'host1': {'hostvars': {'hostvars_foo': 'bar', 'other_var': 'baz'}}, 'host2': {'hostvars': {'hostvars_foo': 'bar', 'other_var': 'baz'}}}")


# Generated at 2022-06-22 14:33:14.964127
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    #This is possible because HostVars class calls __repr__ method of HostVarsVars
    #There is no need to test both methods
    vars = HostVarsVars({'a': 'a_value'}, None)
    assert repr(vars) == "{'a': 'a_value'}"

# Generated at 2022-06-22 14:33:24.246188
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create an inventory
    inve = InventoryManager(loader=None, sources=['localhost'])

    # Create a variable manager
    var_manager = VariableManager(loader=None, inventory=inve)

    # Create a HostVars object
    hostvars = HostVars(inventory=inve, variable_manager=var_manager, loader=None)

    # Iterate over the hosts of the inventory
    hv_iter = iter(hostvars)
    hosts = []
    for host in hv_iter:
        hosts.append(host)
    assert hosts == [inve.get_host('localhost')], 'Test of method __iter__ of class HostVars failed!'

# Generated at 2022-06-22 14:33:29.675718
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import connection_loader
    inventory_data = dict(
        all=dict(
            hosts=dict(
                host1=dict(),
                host2=dict(),
                host3=dict(),
            )
        )
    )
    inventory = InventoryManager(inventory=inventory_data, loader=None, variable_manager=None)

    hostvars = HostVars(inventory=inventory, variable_manager=None, loader=None)
    assert sorted([str(h) for h in hostvars]) == sorted(["host1", "host2", "host3"])

# Generated at 2022-06-22 14:33:38.845259
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    class Host:
        name = 'localhost'
    class PlayContext:
        def __init__(self):
            self.hostvars = {}
    class Play:
        def __init__(self):
            self._variable_manager = []
            self._loader = []
            self.context = PlayContext()
    class HostVarsVars:
        def __init__(self, variables, loader):
            self._vars = variables
            self._loader = loader
    class HostVars:
        def __init__(self, inventory, variable_manager, loader):
            self._inventory = inventory
            self._loader = loader
            self._variable_manager = variable_manager


# Generated at 2022-06-22 14:33:45.036920
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # FIXME: This is copy of similar code in test_inventory.py
    #        Find a way to avoid duplication.
    from decimal import Decimal
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.hostvars import HostVarsVars

    class DummyLoader:
        pass

    class DummyTemplar:

        def __init__(self):
            self.template_data = None

        def template(self, template_data, fail_on_undefined=False, static_vars=None):
            self.template_data = template_data
            return self

        def is_failed(self):
            return self.template_data is None


# Generated at 2022-06-22 14:33:54.038486
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # FIXME - the current inventory code is quite bad, but this is at least a
    # little bit easier to test against than using a proper inventory
    inventory = InventoryManager(
        loader=DataLoader(),
        sources=['localhost,'],
    )
    var_mgr = VariableManager(inventory=inventory)
    var_mgr.extra_vars = {
        'foo': 'bar',
    }
    host_vars = HostVars(inventory, var_mgr, None)

    assert 'foo' in host_vars['localhost']



# Generated at 2022-06-22 14:33:57.321032
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    h = HostVars(inventory=None, variable_manager=None, loader=None)
    assert h['localhost'] == {}, h['localhost']

# Generated at 2022-06-22 14:34:06.595003
# Unit test for method raw_get of class HostVars

# Generated at 2022-06-22 14:34:18.397516
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = DummyLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    # In the test inventory 'localhost,' there is one host.
    assert len(hostvars) == 1

    # There is a way to loop over hosts
    for host in hostvars:
        assert host.name == 'localhost'
        assert host == inventory.get_host('localhost')



# Generated at 2022-06-22 14:34:23.721731
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars = {}
    hostvars['_loader'] = None
    hostvars['_vars'] = {'a': 1, 'b': 2, 'c': 3}
    vars_obj = HostVarsVars(hostvars['_vars'], hostvars['_loader'])
    assert sorted(list(vars_obj)) == ['a', 'b', 'c']


# Generated at 2022-06-22 14:34:33.988086
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a temporary directory for inventory
    tmp_dir = tempfile.mkdtemp()
    inv_fname = os.path.join(tmp_dir, "hosts")

    # Write a valid inventory file in the temporary directory
    with open(inv_fname, 'w') as fh:
        fh.write("""
[group1]
host1
host2
host3
host4
host5

[group2]
host6
host7
host8
host9
host10
""")

    # init inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=inv_fname)

    # init variable manager

# Generated at 2022-06-22 14:34:43.731688
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.host import Host

    vars = dict(a='1', b='2')
    hostvars = HostVarsVars(vars, loader=None)
    assert set(hostvars.__iter__()) == set(vars.keys())

    vars = UnsafeProxy({'a': 1, 'b': 2}, 'dict')
    hostvars = HostVarsVars(vars, loader=None)
    assert set(hostvars.__iter__()) == set(vars.keys())

    vars = dict(a='1')
    host = Host(name='test')
    host.vars = UnsafeProxy(vars, 'dict')

# Generated at 2022-06-22 14:34:53.894113
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars


# Generated at 2022-06-22 14:35:04.156609
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.hostvars import HostVars
    class TestClass:
        def __setstate__(self, state):
            self.state = state

    class TestVariableManager:
        _loader = None
        _hostvars = None

        def __setstate__(self, state):
            self.state = state

    inventory = TestClass()
    loader = TestClass()
    variable_manager = TestVariableManager()

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.__setstate__({'_inventory': inventory, '_loader': loader})

    assert hostvars._inventory == inventory
    assert hostvars._loader == loader
    assert hostvars._variable_manager.state == {'_hostvars': hostvars}

    hostvars.__setstate__

# Generated at 2022-06-22 14:35:07.633306
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = None
    variable_manager = None
    loader = None
    hostvars = HostVars(inventory, variable_manager, loader)

    assert(hostvars.__repr__() == '{}')

# Generated at 2022-06-22 14:35:14.780214
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    cb = MagicMock()

    class _HostVars(HostVars):
        def __contains__(self, var):
            cb(var)
            return True
    vars = _HostVars(MagicMock(), MagicMock(), MagicMock())
    vars._inventory.hosts = {'host1': MagicMock(), 'host2': MagicMock()}
    for host in vars:
        pass
    cb.assert_has_calls([call('host1'), call('host2')])


# Generated at 2022-06-22 14:35:19.830232
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.hostvars import HostVarsVars
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    secrets = '$ANSIBLE_VAULT;1.1;AES256\n36313964346339623935666535313866356331383837353836393132633734353234613362333137\n63663830336635333166336439376231333133356662636630623330363562316138323135653563\n3766333035633739313133613962626163336335333233356139616332373262666366396566\n'
    secret_vars = VaultLib(secrets).decrypt(secrets)
    secret_vars_

# Generated at 2022-06-22 14:35:28.980384
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()
    hostvars = HostVars(inventory, variable_manager, loader)

    data = dict(hostvars.__dict__)
    state = dict(hostvars.__getstate__())

    for key in data.keys():
        assert key in state
        for subkey in data[key].keys():
            assert subkey in state[key]

    assert hostvars._loader is None
    assert hostvars._variable_manager._loader is None
    assert hostvars._variable_manager._hostvars is None

    hostvars.__setstate__(state)

    assert hostvars._loader is loader
   

# Generated at 2022-06-22 14:35:43.134091
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    hostvars = HostVars(inventory=InventoryManager(loader=DataLoader(), sources=[]),
                        variable_manager=VariableManager(loader=DataLoader()),
                        loader=DataLoader())

    assert hostvars.raw_get('localhost')['ansible_play_hosts'] == ['localhost', '127.0.0.1']

# Generated at 2022-06-22 14:35:51.961722
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    When a HostVars object is accessed like a normal dict, the values are
    templated, so things like {{inventory_hostname}} are expanded.  It needs to
    use the AnsibleUndefined values.
    '''
    hostvars = HostVars({
        'foo': 'bar',
        'inventory_hostname': 'baz',
        'inventory_hostname_short': 'quux'
    })
    assert hostvars['foo'] == 'bar'
    assert hostvars['inventory_hostname'] == 'baz'
    assert hostvars['inventory_hostname_short'] == 'quux'
    assert hostvars['missing'] is None


# Generated at 2022-06-22 14:36:02.681030
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    import os

    vault_pass = 'secret'
    vault = VaultLib([(vault_pass, None)])
    loader = DataLoader()
    vars_dict = {
        'var1': {'k1': 'foo'},
        'var2': b'bar',
        'var3': vault.encrypt(b'vault')
    }
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    group = inventory.get_group('all')

# Generated at 2022-06-22 14:36:08.458335
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    hosts = ['localhost', 'example1.org']
    inventory = InventoryManager(hosts, None)
    variable_manager = VariableManager(inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    assert list(hostvars) == hosts

# Generated at 2022-06-22 14:36:15.765819
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import copy
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.dataloader import DataLoader
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from units.mock.vault import DictVaultSecret

    loader = DictDataLoader({})
    inventory = MockInventory(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory, vault_secrets=DictVaultSecret())

# Generated at 2022-06-22 14:36:27.981389
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    host = Host('localhost')
    host.set_variable('my_var', 'my_value')
    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.set_host_variable(host, 'my_var2', 'my_value2')
    hv = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)
    hv.set_host_variable(host, 'my_var3', 'my_value3')


# Generated at 2022-06-22 14:36:34.847412
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(loader=DataLoader(), sources='')
    variables = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variables, loader=DataLoader())
    hostvars['localhost'] = dict(a=1, b=2, c=3)
    ans = []
    for var in hostvars['localhost']:
        ans.append(var)
    assert sorted(ans) == ['a', 'b', 'c']

# Generated at 2022-06-22 14:36:44.112588
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create in-memory inventory
    loader = DataLoader()
    host_list = ['localhost']
    inventory = InventoryManager(loader=loader, sources=['localhost,' + ','.join(host_list)])

    # Create HostVars
    hv = HostVars(inventory, None, loader)

    # Check that all hosts in inventory are represented in HostVars by method __iter__
    hosts = list(hv.__iter__())
    assert hosts == host_list


# Generated at 2022-06-22 14:36:51.050685
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,' + os.getcwd() + '/test/test_hostvars.ini'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost']['hostvar'] == 'hostvar'
    assert hostvars['localhost']['groupvar'] == 'groupvar'
    assert hostvars['localhost']['childgroupvar'] == 'childgroupvar'

# Generated at 2022-06-22 14:36:59.062323
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    class FakeLoader:
        pass

    variables = {'foo' : 'bar'}
    loader = FakeLoader()
    hostvars_vars = HostVarsVars(variables, loader)

    assert isinstance(hostvars_vars, HostVarsVars)

    assert isinstance(hostvars_vars, Mapping)

    assert list(hostvars_vars.__iter__()) == list(variables.keys())

    assert isinstance(hostvars_vars.__iter__(), type(iter([])))


# Generated at 2022-06-22 14:37:21.800764
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    class MockVariableManager:
        def __init__(self):
            self._loader = None
            self._hostvars = None

    variable_manager = MockVariableManager()
    loader = 'mock_loader'

    hostvars = HostVars('mock_inventory', variable_manager, loader)

    assert variable_manager._loader is not None
    assert variable_manager._hostvars is not None

    state = {
        '_inventory': 'mock_inventory',
        '_loader': 'state_loader',
        '_variable_manager': variable_manager,
    }

    hostvars.__setstate__(state)

    assert hostvars._variable_manager is variable_manager
    assert hostvars._loader == 'state_loader'
    assert hostvars._inventory == 'mock_inventory'
    assert variable

# Generated at 2022-06-22 14:37:33.496445
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._loader = loader
    variable_manager._hostvars = {}
    variable_manager._cache = {}
    variable_manager._host_cache = {}
    variable_manager._host_specific_vars = {}


# Generated at 2022-06-22 14:37:39.525354
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import yaml

    inventory = yaml.safe_load("""
    all:
      hosts:
        host1:
          ansible_host: 127.0.0.1
    """)

    vm = DummyVariableManager()

    hv = HostVars(inventory, vm, None)

    assert set(hv['host1']) == set(('ansible_host',))


# Generated at 2022-06-22 14:37:45.922161
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_object = HostVars({}, None, None)
    ansible_facts = {"ansible_processor_count": 2, "ansible_all_ipv4_addresses": ["127.0.0.1"]}
    test_object._variable_manager = MockVariableManager(ansible_facts)
    assert test_object['foo'] == ansible_facts


# Generated at 2022-06-22 14:37:51.852580
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory

    loader = DictDataLoader({})
    inventory = MockInventory(loader=loader)
    variable_manager = inventory.get_variable_manager(loader=loader)

    inventory.add_host('host1')
    inventory.add_group('group1')

    hostvars = HostVars(inventory, variable_manager, loader)

    # test that HostVars is iterable
    iter(hostvars)

    # test that HostVars is iterable when iterating over groups
    inventory.groups_for('group1')

    # test that HostVars is iterable when iterating over hosts
    inventory.hosts_for('host1')



# Generated at 2022-06-22 14:38:02.568204
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Set up test
    variables = {
        "a": 1,
        "b": "2",
        "c": 3.3,
        "d": [1, 2, 3],
    }
    hostvarsvars = HostVarsVars(variables, loader=None)

    # Check that HostVarsVars works like dict for non-templated data
    for k, v in variables.items():
        assert k in hostvarsvars
        assert hostvarsvars[k] == v
        assert len(hostvarsvars) == len(variables)

    # Assert that templated data is returned in correct type
    hostvarsvars["e"] = "{{ a + 1 }}"
    assert isinstance(hostvarsvars["e"], int)

# Generated at 2022-06-22 14:38:07.822485
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class MockLoader(object):
        pass

    loader = MockLoader()
    vars = {'hostvar1': 'hostvar1_value', 'hostvar2': 'hostvar2_value'}
    hvv = HostVarsVars(vars, loader=loader)
    hvv_dict = dict(hvv)
    assert hvv_dict == vars

# Generated at 2022-06-22 14:38:18.486651
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    templar = Templar(loader=None)
    hvv = HostVarsVars({'foo': 'bar', 'baz': '{{ not_exist }}'}, loader=templar)

    assert list(hvv.keys()) == list(hvv)
    assert set(hvv.keys()) == set(['foo', 'baz'])
    assert set(hvv.values()) == set(['bar', AnsibleUndefined(name='not_exist')])
    assert set(hvv.items()) == set([('foo', 'bar'), ('baz', AnsibleUndefined(name='not_exist'))])
    assert repr(hvv) == "HostVarsVars({'foo': 'bar', 'baz': AnsibleUndefined(name='not_exist')})"

# Generated at 2022-06-22 14:38:28.840349
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import os
    import sys
    import unittest

    if sys.version_info < (2, 7):
        import unittest2 as unittest

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')

    class TestHostVars(unittest.TestCase):
        def setUp(self):
            self.loader = DataLoader()
            self.inventory = InventoryManager(loader=self.loader, sources=[os.path.join(DATA_DIR, 'host_vars')])


# Generated at 2022-06-22 14:38:36.500753
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None

    inv_data = dict(
        all=dict(children=['ungrouped', 'all_hosts']),
        all_hosts=dict(hosts=['example.org']),
        ungrouped=dict(hosts=['localhost']),
    )

    hosts = ['localhost', 'example.org']
    variables = dict(foo='bar')

    inventory = InventoryManager(loader=loader, sources=inv_data)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    counter = 0
    for host in hostvars:
        assert host in hosts
        counter += 1

# Generated at 2022-06-22 14:39:10.306693
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    class VariableManager:
        _hostvars = None
        _loader = None
        def __init__(self):
            pass
        def __setstate__(self, state):
            self.__dict__.update(state)
        def __getstate__(self):
            state = {}
            for key in self.__dict__:
                if key not in ['_loader', '_hostvars']:
                    state[key] = self.__dict__[key]
            return state
        def set_host_variable(self, host, varname, value):
            pass
        def set_nonpersistent_facts(self, host, facts):
            pass
        def set_host_facts(self, host, facts):
            pass

    class Inventory:
        hosts = {}
        def __init__(self):
            pass


# Generated at 2022-06-22 14:39:14.230330
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    loader = True
    hostvars = HostVars({}, {}, loader)

    vm = VariableManager()
    vm._hostvars = None
    vm._loader = None

    hostvars.set_variable_manager(vm)

    assert vm._hostvars == hostvars
    assert vm._loader == loader

# Generated at 2022-06-22 14:39:20.433529
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    host_name = 'test_host'
    # Empty hostvars of HostVars
    hostvars = HostVars({}, None, None)
    assert hostvars[host_name] == AnsibleUndefined(name="hostvars['test_host']")
    # Not empty hostvars of HostVars
    hostvars = HostVars({host_name: {'key': 'value'}}, None, None)
    assert hostvars[host_name]['key'] == 'value'


# Generated at 2022-06-22 14:39:30.333377
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class VariableManager():
        def __init__(self, hostvars):
            self._hostvars = hostvars
        def __getitem__(self, host):
            return self._hostvars[host]['vars']
    class Inventory():
        def __init__(self):
            self.hosts = ['host1', 'host2']
        def get_host(self, host):
            return host
    class Loader():
        def __init__(self):
            self._basedir = 'x'
    hostvars = HostVars(inventory=Inventory(), variable_manager=VariableManager({'host1': {'vars': {'x': 1}}, 'host2': {'vars': {'x': 2}}}), loader=Loader())
    assert hostvars['host1']['x'] == 1

# Generated at 2022-06-22 14:39:39.358482
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.template import Templar


# Generated at 2022-06-22 14:39:51.140938
# Unit test for method __getitem__ of class HostVars

# Generated at 2022-06-22 14:39:58.875447
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    h = Host(name="example.com")
    g = Group(name="some_group")
    g.add_host(h)
    i = Inventory()
    i.add_group(g)
    i.add_host(h)
    play_context = Play()
    variable_manager = VariableManager(loader=None, inventory=i)

    hv = HostVars(inventory=i, variable_manager=variable_manager, loader=None)

# Generated at 2022-06-22 14:40:06.184858
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import pytest

    class MockInventory:
        def __init__(self):
            self.hosts = ['a', 'b']

        def get_host(self, name):
            if name in self.hosts:
                return name

    inventory = MockInventory()
    hv = HostVars(inventory, variables=None, loader=None)
    assert list(hv) == inventory.hosts

# Generated at 2022-06-22 14:40:13.449664
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    loader = DictDataLoader({
        'group_vars/all': """
            host_var: "{{ group_var }}"
        """
    })
    templar = Templar(loader=loader)
    variables = {
        'group_var': "group_var",
        'host_var': "host_var"
    }
    host_vars = HostVarsVars(variables, loader=loader)
    assert host_vars['host_var'] == 'host_var'
    assert host_vars['group_var'] == 'group_var'

# Generated at 2022-06-22 14:40:25.599407
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    ansible_version = {'full': '2.4.0.0'}

    host = MagicMock()
    host.name = 'test_host'
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, 'ansible_version', ansible_version)

    hostvars = HostVars(MagicMock(), variable_manager, loader)

    variable_manager.set_host_variable(host, 'test_variable', 'test_value_1')

    assert hostvars[host.name]['test_variable'] == 'test_value_1'
    assert hostvars[host.name]['ansible_version'] == ansible_

# Generated at 2022-06-22 14:41:35.197572
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # pylint: disable=too-few-public-methods
    class Host:
        def __init__(self, name):
            self.name = name

    class MockInventory:
        def __init__(self):
            self.hosts = [Host('host1'), Host('host2')]

        def get_host(self, name):
            return next((h for h in self.hosts if h.name == name), None)

    inventory = MockInventory()
    hv = HostVars(inventory, None, None)
    actual_set_of_names = set(iter(hv))
    expected_set_of_names = set(['host1', 'host2'])
    assert actual_set_of_names == expected_set_of_names


# Generated at 2022-06-22 14:41:45.722916
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    variable_manager.set_nonpersistent_facts(inventory.get_host('localhost'), dict(foo=1, bar='2', baz='{{ foo }}'))

    assert hostvars['localhost']['foo'] == 1
    assert hostvars['localhost']['bar'] == '2'
    assert hostvars['localhost']['baz'] == 1

    assert hostvars

# Generated at 2022-06-22 14:41:58.351399
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    """Check return values of HostVars.__getitem__()"""
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play

    # Create instances of Inventory and VariableManager
    inventory = Inventory("/some/path")
    variable_manager = VariableManager()

    # Valid hostname
    host = "testhost"

    # Create a play for validating hosts
    play_source = dict(
        name="Ansible Play",
        hosts=host,
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ hostvars[inventory_hostname] }}')))
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=None)

# Generated at 2022-06-22 14:42:08.701188
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders

    context = PlayContext()
    loader = get_all_plugin_loaders()
    templar = Templar(loader=loader, variables=context.__dict__, shared_loader_obj=loader)

    result = templar.template('{{ foo }}', fail_on_undefined=False, static_vars=STATIC_VARS)
    assert isinstance(result, AnsibleUndefined)

    foo = {'foo': 'bar'}
    foo_vars = HostVarsVars(foo, loader)
    result = foo_vars['foo']
    assert result == 'bar'

# Generated at 2022-06-22 14:42:18.071934
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    vars = {}
    hv = HostVars(None, None, vars)
    assert repr(hv) == "{}"

    vars = {'foo': 'bar'}
    hv = HostVars(None, None, vars)
    assert repr(hv) == "{'foo': 'bar'}"

    vars = {'foo': 'bar', 'baz': {'qux': 'quux'}}
    hv = HostVars(None, None, vars)
    assert repr(hv) == "{'foo': 'bar', 'baz': {'qux': 'quux'}}"

# Generated at 2022-06-22 14:42:30.181495
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

    hosts = {"ungrouped": {"hosts": ["127.0.0.1"], "vars": {"a": "b"}}}

    inventory = InventoryManager(loader=loader, sources=hosts)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Basic get
    assert hostvars['127.0.0.1'] == {"a": "b"}

    # Issue #23695
    variable_manager._fact_cache['127.0.0.1'] = {}

# Generated at 2022-06-22 14:42:38.074367
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    class MockInventory(Inventory):
        def get_host(self, name):
            return Host(name, self, variables={'a': 10, 'b': 20})

    class MockVariableManager(VariableManager):
        def get_vars(self, host=None, include_hostvars=True):
            return {'c': 30, 'd': 40}

    inventory = MockInventory()
    variable_manager = MockVariableManager()
    loader = DataLoader()
    hostvars = HostVars(inventory, variable_manager, loader)
    raw = hostvars