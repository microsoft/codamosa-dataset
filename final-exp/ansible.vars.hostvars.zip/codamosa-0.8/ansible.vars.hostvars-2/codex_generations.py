

# Generated at 2022-06-22 14:33:00.308409
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import os

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=os.devnull)

    # Initialize some inventory and set variables to hosts
    inventory_manager.add_host(host='host1', groups=['group1'])
    inventory_manager.add_host(host='host2', groups=['group2'])
    host1 = inventory_manager.get_host('host1')
    host2 = inventory_manager.get_host('host2')
    variable_manager.set_host_variable(host1, 'foo', 'bar')
    variable_manager.set_host_variable

# Generated at 2022-06-22 14:33:06.631499
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible import inventory

    def _make_variable_manager(loader):
        return inventory.get_variable_manager(loader)

    # Create a loader and a variable manager
    loader = DictDataLoader(dict())
    vars_manager = _make_variable_manager(loader)

    # Initialize an empty host "foo"
    foo = inventory.Host('foo')

    # Create an empty task with variable managers attached
    task = Task(name="Dummy", play=Play(), variable_manager=vars_manager)
    task._variable_manager = vars_manager

    # Test __setstate__
    hostvars = HostVars({foo: {}}, variable_manager=vars_manager, loader=loader)
    hostv

# Generated at 2022-06-22 14:33:16.466117
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    mock_host = 'fakehost'
    mock_var = 'mock_var'
    mock_value = 'mock_value'

    loader = DataLoader()
    vars_manager = VariableManager()

    inventory = Inventory(loader)
    host = inventory.get_host(mock_host)

    hostvars = HostVars(inventory=inventory, variable_manager=vars_manager, loader=loader)

    assert hostvars.raw_get(mock_host) == {}
    assert hostvars.raw_get(mock_host) != {mock_var: mock_value}


# Generated at 2022-06-22 14:33:25.804708
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Host
    from ansible.vars.manager import VariableManager

    variables = {
        'one': 1,
        'two': 2,
    }
    inventory = {
        'foo': Host(name='foo', vars=variables),
        'bar': Host(name='bar', vars=variables),
    }
    variables = {
        'ansible_hosts': inventory,
    }

    loader = DictDataLoader(variables)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    count = 0
    for host in hostvars:
        count += 1
    assert len(hostvars) == count


# Generated at 2022-06-22 14:33:31.524020
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    import pytest
    from ansible.inventory import Host, Inventory
    from ansible.vars.manager import VariableManager

    # inventory_hostname is not in STATIC_VARS and it's not a host variable
    defined_host_vars = {'inventory_hostname': 'test_host', 'defined': 1}

    def mock_get_vars(host, include_hostvars):
        return defined_host_vars

    hosts = [
        Host('first_host'),
        Host('second_host'),
    ]

    inventory = Inventory(hosts)

    variable_manager = VariableManager()
    variable_manager.get_vars = mock_get_vars
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # inventory.hosts and hostvars should be the same length


# Generated at 2022-06-22 14:33:37.442313
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory import Inventory
    import ansible.utils.vars as vars_m
    import ansible.vars.hostvars as hostvars_m

    # Create a hostvars object
    inventory_path = "./test/support/hostvars/hosts"
    inventory = Inventory(host_list=inventory_path)
    play = dict(hosts=inventory.get_groups_dict())
    iterator = PlayIterator(play, inventory)
    run_once = False
    variable_manager = vars_m.VariableManager()
    loader = False
    hostvars = hostvars_m.HostVars(inventory, variable_manager, loader)

    # Run method __repr__
    out = hostvars.__repr__()



# Generated at 2022-06-22 14:33:42.482701
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host_vars = HostVars(inventory, variable_manager, loader)
    host_vars.set_variable_manager(variable_manager)
    host_vars.set_inventory(inventory)

    assert host_vars.raw_get('localhost') == {}

    host_vars.set_host_variable('localhost', 'foo', 'bar=baz')

# Generated at 2022-06-22 14:33:53.221901
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Create a fake inventory and variable manager for test.
    inventory = MagicMock()
    variable_manager = MagicMock()

    # Create a fake variable manager class for test.
    class variable_manager_class:

        def get_vars(self, host=None, include_hostvars=True):
            return dict(foo='bar')

    variable_manager.get_vars = variable_manager_class().get_vars

    # Create a fake loader class for test.
    class loader_class:
        pass

    loader = loader_class()

    # Create a HostVars instance.
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check the result of __getitem__ when the host exists in the inventory.
    actual = hostvars['testhost']

# Generated at 2022-06-22 14:34:02.654454
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    hosts = ['localhost', 'foohost']
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=hosts)
    hv = HostVars(inventory, VariableManager(), loader)

    assert len(inventory.hosts) == len(hv)
    assert len(inventory.hosts) == len(list(hv))
    assert ['localhost', 'foohost'] == list(hv)

# Generated at 2022-06-22 14:34:09.149697
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class Options(object):
        def __init__(self):
            self.inventory = None

    class FakeVariableManager(VariableManager):
        def __init__(self):
            self._vars_cache = {}

    class FakeInventoryManager(InventoryManager):
        def __init__(self, loader):
            self._loader = loader
            self._inventory = None

        def get_host(self, hostname):
            if hostname in self._inventory._hosts_cache:
                return self._inventory.get_host(hostname)

# Generated at 2022-06-22 14:34:24.576207
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Load vars of a host and try to expand every variable of them.
    '''

    class Inventory():
        def __init__(self, host_name, hostvars):
            self.host_name = host_name
            self.hostvars = hostvars

        def get_host(self, host_name):
            if host_name == self.host_name:
                class Host():
                    def __init__(self, host_name):
                        self.name = host_name
                return Host(host_name)
            else:
                return None

        def hosts(self):
            class Host():
                def __init__(self, host_name):
                    self.name = host_name

            return [Host(self.host_name)]


# Generated at 2022-06-22 14:34:34.750902
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class InventoryMock(object):
        def __init__(self):
            self.hosts = ['example.org']

        def get_host(self, name):
            if name == 'example.org':
                return 'example.org'
            else:
                return None

    class HostMock(object):
        def __init__(self, hostname):
            self.name = hostname

    variables = {'foo': '{{ bar }}', 'bar': 'bogus'}

    class VariableManagerMock(object):
        def __init__(self):
            self.hostvars = None
            self._host_cache = {}
            self._loader = None

        def get_vars(self, host=None, include_hostvars=False):
            return variables


# Generated at 2022-06-22 14:34:38.946566
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class MyLoader(object):
        def __init__(self):
            pass

        def get(self, path):
            return path

    loader = MyLoader()
    variables = dict(x=1, y=2)
    hostvars_vars = HostVarsVars(variables, loader)

    for variable in ['x', 'y']:
        assert variable in hostvars_vars

# Generated at 2022-06-22 14:34:47.095363
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources="localhost,")
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    hostvars = HostVars(inv_manager, variable_manager, loader)
    variables = hostvars.raw_get('localhost')
    assert(isinstance(variables, dict))

    # Test that the supplied value for ansible_connection is returned
    assert(variables['ansible_connection'] == 'local')

    # inventory_hostname can be defined by the hostvars being loaded from the
    # cache, we only want to test the value from the cache if it exists

# Generated at 2022-06-22 14:34:57.121124
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var

    def _find_host(self, host_name):
        return self._inventory.get_host(host_name)

    # HostVars.raw_get() is a method (not a property, or __getitem__), which
    # expects 1 argument.
    variables = {'foo': 'bar'}
    assert variables['foo'] == 'bar'
    assert wrap_var(variables)['foo'] == 'bar'

    # wrap_var() is using __getitem__ internally, so it returns a
    # surrogate object and not 'bar'
    hv = HostVars(None, VariableManager(), None)
    assert isinstance(hv.raw_get('localhost'), dict)

# Generated at 2022-06-22 14:35:08.322445
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    import ansible.parsing.dataloader
    import ansible.vars.variable_manager

    class Host:
        vars = {'test': 'TEST'}
        name = 'testhost'

    class Inventory:
        hosts = ['testhost']

    class VariableManager:
        _host_cache = {'testhost': Host()}

        def _gethostvars(self, host):
            return self._host_cache[host].vars

        def get_vars(self, host=None, include_hostvars=True):
            variables = self._gethostvars(host).copy()
            if include_hostvars:
                variables['inventory_hostname'] = host
                variables['groups'] = {}
                variables['group_names'] = []
            return variables


# Generated at 2022-06-22 14:35:18.317977
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # This test requires ansible to be available, because VariableManager
    # needs to be initialized with a proper _loader attribute.
    ansible_import = True
    try:
        import ansible
        from ansible.vars.manager import VariableManager
    except ImportError:
        ansible_import = False

    if ansible_import:
        from ansible.parsing.dataloader import DataLoader

        class MockInventory(object):
            def __init__(self, *args, **kwargs):
                pass

            def __getitem__(self, *args, **kwargs):
                return {'hosts': [MockHost('hostname')]}

            def get_host(self, *args, **kwargs):
                return MockHost(*args, **kwargs)


# Generated at 2022-06-22 14:35:28.014885
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    inv = Inventory()
    inv.add_host(host=inv.localhost)
    variable_manager = VariableManager(loader=None)
    variable_manager.host_vars_handler = HostVars(inventory=inv, variable_manager=variable_manager, loader=None)
    variable_manager.set_host_variable(inv.localhost, 'ansible_play_hosts', 'localhost')
    variable_manager.set_host_variable(inv.localhost, 'ansible_play_role_names', ['foo'])
    variable_manager.set_host_variable(inv.localhost, 'ansible_role_names', ['bar'])
    variable_manager.set_host_variable(inv.localhost, 'inventory_hostname', 'localhost')
    variable

# Generated at 2022-06-22 14:35:33.918427
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    group = Group()
    group.hosts = ['host1', 'host2', 'host3']

    # Create a fake inventory
    inv = Inventory(groups=[group])

    # Create a fake variable manager
    var_manager = VariableManager(loader=None, inventory=inv)

    # Create a fake loader
    loader = DictDataLoader({'host1': dict(foo='bar'), 'host2': dict(foo='baz'), 'host3': dict(foo='fozz')})

    # Create an instance of HostVars class
    hostvars = HostVars(inventory=inv, variable_manager=var_manager, loader=loader)

    # Test the method hostvars.raw_get

# Generated at 2022-06-22 14:35:42.111484
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inv = InventoryManager(loader=DataLoader())
    host = inv.get_host('localhost')
    varmgr = VariableManager(loader=DataLoader())
    varmgr.set_host_variable(host, 'foo_bar', 'baz')
    hostvars = HostVars(inv, varmgr, DataLoader())

    expected = dict()
    expected['foo_bar'] = 'baz'
    assert hostvars.raw_get('localhost') == expected

# Generated at 2022-06-22 14:35:58.486893
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    # Create an example variables' dict, with nested dict-like objects
    variables = dict(A='1', B=dict(C='2', D='3'), E=[1,2,3])

    # Create an example loader that does not expand variables in the templates
    class DummyLoader:
        def get_basedir(self, *args, **kwargs):
            return '.'
        def path_dwim(self, *args, **kwargs):
            return '.'
    loader = DummyLoader()

    # We expect HostVarsVars class to return the same variables' dict
    # as it is given
    expected = dict(A='1', B=dict(C='2', D='3'), E=[1,2,3])
    hvv = HostVarsVars(variables, loader=loader)
    actual = hvv

# Generated at 2022-06-22 14:36:05.028586
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = DictDataLoader({})
    templar = Templar(variables=dict(), loader=loader)
    variables = {'k1': 'v1', 'k2': 2, 'k3': [1, 2, 3]}
    host_vars_vars = HostVarsVars(variables, loader)

    variables_keys = list()
    for variable in host_vars_vars:
        variables_keys.append(variable)
    assert variables_keys == variables.keys()



# Generated at 2022-06-22 14:36:13.689909
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=[])
    host_vars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Create some host variables, which should be available via raw_get but
    # not via __getitem__ or __contains__
    variable_manager.extra_vars = {'foo': 'bar', 'baz': 'quux'}
    variable_manager.set_nonpersistent_facts(host=inventory.localhost, facts={'com': 'puter'})

    # Check that the existing variables are visible
   

# Generated at 2022-06-22 14:36:24.444301
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    loader = DictDataLoader({})
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    definitions = dict(
        all=dict(hosts=dict(g=dict(a=42))),
        g=dict(hosts=dict(g=dict(b='{{a}}')))
    )
    inventory.add_group('all')
    inventory.add_group(Group('g'))
    inventory.parse_sources('inventory', definitions)
    variable_manager = inventory.get_variable_manager()
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['g'] == dict(a=42, b='{{a}}')

# Generated at 2022-06-22 14:36:34.023803
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from six import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host

    loader = AnsibleLoader(StringIO(), None)
    variable_manager = VariableManager(loader=loader)
    inventory = Inventory(loader=loader)
    host = Host('test')
    inventory.add_host(host)

    hostvars = HostVars(inventory, variable_manager, loader)
    assert hostvars._inventory == inventory
    assert hostvars._loader == loader
    assert hostvars._variable_manager == variable_manager

    assert variable_manager._loader == loader
    assert variable_manager._hostvars == hostvars

    state = hostvars.__getstate__()


# Generated at 2022-06-22 14:36:45.288887
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    assert HostVarsVars({'var1': '{{var0}}'}, None)['var1'] == '{{var0}}'
    assert HostVarsVars({'var1': '{{ var0 }}'}, None)['var1'] == '{{ var0 }}'
    assert HostVarsVars({'var1': '{{ var0 }}'}, None)['var1'] == '{{ var0 }}'
    assert HostVarsVars({'var1': '{{ var0 }}'}, None)['var1'] == '{{ var0 }}'
    assert HostVarsVars({'var1': '{{ var0 }}'}, None)['var1'] == '{{ var0 }}'
    assert HostVarsVars({'var1': '{{ var0 }}'}, None)['var1'] == '{{ var0 }}'
   

# Generated at 2022-06-22 14:36:54.391209
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    pc = PlayContext()
    inventory = InventoryManager(loader=loader, sources="[host1]\nhost1")
    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info=pc.ansible_version_info)

    hostvars = HostVars(inventory, variable_manager, loader)

    keys = [key for key in hostvars]
    assert keys == ['host1']

# Generated at 2022-06-22 14:37:04.164889
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils import context_objects as co

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources='localhost,')

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    localhost = hostvars['localhost']
    assert localhost is not None
    assert 'hostvars' in localhost
    assert localhost['hostvars'] is not None
    assert localhost['hostvars']['localhost'] is localhost

    # an exception should be raised

# Generated at 2022-06-22 14:37:12.503632
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    class TestInventory(object):
        def __init__(self):
            self.hosts = ['host1', 'host2']

        def get_host(self, name):
            return 'host3' if name == 'host3' else None

    class TestVariableManager(object):
        def __init__(self):
            self.vars = {'host1': {'x': 'y'}, 'host3': {'z': 'a'}, 'host4': {'b': 'c'}}
            self._loader = None
            self._hostvars = None

        def get_vars(self, host, include_hostvars):
            return self.vars[host.name]

    class TestLoader(object):
        pass

    inventory = TestInventory()
    variable_manager = TestVariableManager()
    loader

# Generated at 2022-06-22 14:37:17.432489
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = HostVarsVars({'a': '{{ b }}', 'b': '{{ c }}', 'c': 'd'}, None)
    assert variables['a'] == 'd'
    assert variables['b'] == 'd'
    assert variables['c'] == 'd'

# Generated at 2022-06-22 14:37:34.748423
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.vars.manager import VariableManager

    class Host(object):
        pass

    class Inventory(object):
        def __init__(self):
            # 3 different objects to check if __repr__ of HostVars
            # calls __repr__ of each object at most once
            h1 = Host()
            h1.name = 'h1'
            h2 = Host()
            h2.name = 'h2'
            h3 = Host()
            h3.name = 'h3'
            self._hosts = [h1, h2, h3]

        def hosts(self):
            return self._hosts


# Generated at 2022-06-22 14:37:46.816818
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Test case with host in Inventory
    inventory = mock.Mock()
    inventory.hosts = inventory.get_host.return_value = mock.Mock()
    inventory.hosts.get_vars.return_value = {'a': 'b'}
    variable_manager = mock.Mock()
    loader = mock.Mock()
    hostvars = HostVars(inventory, variable_manager, loader)

    assert {'a': 'b'} == hostvars.raw_get('host')
    inventory.get_host.assert_called_with('host')
    inventory.hosts.get_vars.assert_called_with(only_facts=False, only_raw_facts=False, per_host_overrides=None)

    # Test case with host not in Inventory
    inventory.hosts = inventory

# Generated at 2022-06-22 14:37:55.268160
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class InventoryMock(object):
        def __iter__(self):
            return iter([1,2,3])

        hosts = ('host1', 'host2', 'host3')

    class VariableManagerMock(object):
        def get_vars(self, *args, **kwargs):
            return {}

    hostvars = HostVars(InventoryMock(), VariableManagerMock(), None)
    assert list(hostvars) == [(1, 'host1'), (2, 'host2'), (3, 'host3')]

# Generated at 2022-06-22 14:38:02.443015
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Create a dict and some iterable values
    data = {'list': ['a', 'b', 'c'], 'dict': {'key1': 'val1', 'key2': 'val2'}}

    # Create an instance of HostVarsVars with the data
    hvv = HostVarsVars(data, None)

    # Verify that using __iter__ on the dict results in the keys being returned in the expected order
    assert list(data.keys()) == ['list', 'dict']
    assert list(hvv.__iter__()) == ['list', 'dict']

# Generated at 2022-06-22 14:38:12.998950
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import pytest
    from ansible.vars.hostvars import HostVars

    inventory = pytest.helpers.get_inventory()
    variable_manager = pytest.helpers.get_variable_manager()
    loader = pytest.helpers.get_loader()

    vars = HostVars(inventory, variable_manager, loader)
    host = vars._find_host('localhost')

    assert vars.raw_get(host.name)['ansible_facts']['service_mgr'] == 'init'

    variable_manager._extra_vars['ansible_service_mgr'] = 'systemd'
    variable_manager._extra_vars['ansible_system'] = 'Linux'
    variable_manager.update_cache_variables()


# Generated at 2022-06-22 14:38:15.322254
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert HostVars.raw_get.__doc__



# Generated at 2022-06-22 14:38:26.757672
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    test_host = Host(name='localhost')

    test_loader = DataLoader()

    test_inventory = InventoryManager(
        loader=test_loader,
        sources=['localhost,']
    )

    test_variable_manager = VariableManager(loader=test_loader, inventory=test_inventory)

    test_variable_manager._fact_cache['localhost'] = dict(
        fact1='fact1',
        fact2='fact2',
        fact3='fact3',
    )


# Generated at 2022-06-22 14:38:37.498939
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    class Inventory(object):

        all = { 'hosts': ['example.com', 'example.org'] }
        hosts = ['example.com', 'example.org']
        vars = { 'example.com': {}, 'example.org': {} }

        def get_host(self, name):
            return { 'name': name }

    class Loader(object):

        def __init__(self):
            self.paths = []

    class VariableManager(object):

        def __init__(self):
            self._loader = None
            self._hostvars = None

    h = HostVars(Inventory(), VariableManager(), Loader())
    h._variable_manager._loader = None
    h._variable_manager._hostvars = None

# Generated at 2022-06-22 14:38:47.261774
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager, load_extra_vars
    from ansible.parsing.dataloader import DataLoader

    vars_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_hostvars'])
    vars_manager.set_inventory(inventory)
    vars_manager._vars_per_host = {}
    vars_manager._vars_per_host[inventory.hosts] = {
        'myvar': 'bar',
        'newvar': 'newvalue',
    }

    hostvars = HostVars(inventory, vars_manager, loader)

    assert hostvars.raw_get('foobar') == AnsibleUndefined

# Generated at 2022-06-22 14:38:57.129648
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    inv_gen = Inventory(loader=loader, variable_manager=variable_manager)
    inv_gen.add_host('host1')
    inv_gen.add_host('host2')
    inv_gen.add_host('host3')

    variable_manager.set_inventory(inv_gen)

    play = Play()
    play_context = PlayContext()

    variable_manager.set_play_context(play_context)


# Generated at 2022-06-22 14:40:08.884721
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # The test checks that __getitem__ returns the same value as raw_get,
    # when there is no special Jinja2 template logic in the value.  For
    # example, raw_get may return a string with a "{{var}}" substring,
    # and __getitem__ may return a string with a value substituted for
    # "var".
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources='localhost,')

    # Let's check that the value for key "foo" is returned unchanged
    #

# Generated at 2022-06-22 14:40:16.777723
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    import ansible.vars.unsafe_proxy
    import ansible.vars.manager
    import ansible.utils.unsafe_proxy
    import ansible.inventory.manager
    import ansible.inventory.host

    # Prepare test data

    class TestProxy(ansible.utils.unsafe_proxy.AnsibleUnsafeText):
        ''' Class to test that AnsibleUnsafeText proxies work in hostvars '''
        def __init__(self, value, **kwargs):
            self._text = value
            self._kwargs = kwargs


# Generated at 2022-06-22 14:40:28.260670
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():

    class FakeLoader():

        def __init__(self):
            self.cache = {}

        def set_basedir(self, basedir):
            pass

        def template_from_file(self, path, cache=True):
            return self.cache[path]

        def list_templates(self):
            pass

    loader = FakeLoader()

    test_data = {
        'var1': 'value1',
        'var2': 'value2',
        'var3': 'value3',
        'var4': 'value4',
        'var5': { 'var6': 'value6'},
    }

    hostvars = HostVarsVars(test_data, loader=loader)


# Generated at 2022-06-22 14:40:37.441725
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    inventory = InventoryManager(loader=loader, sources="")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # case 1: call __getitem__ method with a host not exist in inventory
    hostvars['fake_host']
    # case 2: call __getitem__ with a host exists in inventory

    # case 3: call __getitem__ with a host exists in inventory and the hostvars contain ansible_facts
    # TODO

# Generated at 2022-06-22 14:40:47.757665
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader,
                           sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    hostvars = HostVars(inventory=inv, variable_manager=variable_manager, loader=loader)
    assert list(hostvars.__iter__()) == []

    inv = InventoryManager(loader=loader,
                           sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    hostvars = HostVars(inventory=inv, variable_manager=variable_manager, loader=loader)
    assert list(hostvars.__iter__())

# Generated at 2022-06-22 14:40:57.270689
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
   from ansible.inventory.manager import InventoryManager
   from build_inventory import make_inventory
   from ansible.vars.manager import VariableManager
   inventory = InventoryManager(loader=None, sources=make_inventory().get_sources())
   variable_manager = VariableManager(loader=None, inventory=inventory)
   hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)
   hostvars._vars_cache = {
       'first': {},
       'second': {}
   }
   hostvars._variable_manager._hostvars._vars_cache = {
       'first': {},
       'second': {}
   }
   assert set(hostvars.__iter__()) == { 'first', 'second' }

# Generated at 2022-06-22 14:41:05.024484
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = ansible.inventory.Inventory("localhost ansible_connection=local")
    variable_manager = ansible.vars.VariableManager(inventory)
    variable_manager.set_host_variable(inventory.get_host("localhost"), "foo", "bar")

    hostvars = HostVars(inventory, variable_manager, None)
    raw_data = hostvars.raw_get("localhost")

    assert raw_data['foo'] == "bar"

# Generated at 2022-06-22 14:41:07.991875
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    _hostvars = HostVars(dict(host1=dict(a=1), host2=dict(b=3)))
    assert _hostvars.__repr__() == "{'host1': {u'a': 1}, 'host2': {u'b': 3}}"

# Generated at 2022-06-22 14:41:20.394344
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    host = inventory.get_host("foobar")
    variable_manager.set_host_variable(host, "foo", 42)
    assert hostvars["foobar"]["foo"] == 42
    assert "foo" in hostvars["foobar"]
    assert "bar" not in hostvars["foobar"]

    # Test __getitem__ with AnsibleUndefined value
    assert hostvars.raw_

# Generated at 2022-06-22 14:41:30.478870
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Hostvars holds a reference to `variable_manager` instead of using a
    # full blown inventory that requires a lot more machinery we do not need
    # here. For more information, please see commit 83687da.
    import copy
    import os

    import ansible.inventory
    import ansible.playbook.play_context
    import ansible.template
    import ansible.vars.manager
    import ansible.vars.hostvars

    # Ansible needs a real file, so create a temporary file
    code_str = "foo = 2"
    (fd, path) = tempfile.mkstemp()
    # Write `code_str` to `path`
    os.write(fd, code_str.encode("utf-8"))
    os.close(fd)
    # Load a simple python file
    loader