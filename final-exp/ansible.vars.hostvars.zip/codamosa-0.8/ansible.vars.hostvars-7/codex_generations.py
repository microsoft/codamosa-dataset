

# Generated at 2022-06-22 14:33:00.451684
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    playbook_dir = 'tests/playbooks'
    inventory_file = playbook_dir + '/host_vars_inventory_2'
    inventory = InventoryManager(loader=DataLoader(), sources=[inventory_file])
    host1 = inventory.get_host("host1")
    host2 = inventory.get_host("host2")
    host3 = inventory.get_host("host3")
    host4 = inventory.get_host("host4")
    host5 = inventory.get_host("host5")
    host6 = inventory.get_host("host6")

    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-22 14:33:11.774715
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import ansible.inventory.manager
    from ansible.inventory.host import Host
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.vars.manager import Variables
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    class FakeGroup(MutableMapping):
        def __init__(self, hostvars=None, *args, **kwargs):
            self._vars = dict(*args, **kwargs)
            self._vars.update(hostvars or {})
        def __getitem__(self, var):
            return self._vars[var]
        def __setitem__(self, var, value):
            self._vars[var] = value

# Generated at 2022-06-22 14:33:21.447451
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context.remote_addr = '1.2.3.4'

    loader = None
    inventory = dict(
        hosts=dict(
            i1=dict(vars=dict(key_of_i1='value_of_i1'))
        ),
        groups=dict(
            g1=dict(hosts=['i1'])
        )
    )

    host_vars = dict(key_of_hv1='value_of_hv1')
    facts = dict(key_of_facts1='value_of_facts1')

    variable_manager = VariableManager(loader=loader)

# Generated at 2022-06-22 14:33:29.049076
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create inventory and variable manager
    loader = C.DEFAULT_LOADER
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)

    # Create HostVars instance
    hostvars = HostVars(inventory, variable_manager, loader)

    # Use pickle to create dump of HostVars and restore it again
    import pickle
    dump = pickle.dumps(hostvars)
    restored_hostvars = pickle.loads(dump)

    assert hostvars._inventory == restored_hostvars._inventory
    assert hostvars

# Generated at 2022-06-22 14:33:38.173288
# Unit test for method set_host_variable of class HostVars
def test_HostVars_set_host_variable():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    context = PlayContext()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=loader)

    foo_host = inventory.add_host('foo')

    hostvars.set_host_variable(foo_host, 'bar', 12)

    assert hostvars.get(foo_host)['bar'] == 12
    assert foo_host.vars['bar'] == 12

# Generated at 2022-06-22 14:33:41.376518
# Unit test for method __len__ of class HostVars
def test_HostVars___len__():
    # Test single-host inventory
    inventory = MockInventory()
    hostvars = HostVars(inventory, None, None)
    assert len(hostvars) == 1

    # Test multi-host inventory
    inventory = MockInventory([{'hostname': 'host1'}, {'hostname': 'host2'}])
    hostvars = HostVars(inventory, None, None)
    assert len(hostvars) == 2


# Generated at 2022-06-22 14:33:46.822739
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    context = PlayContext()

    # Set up inventory manager and hostvars
    inven = InventoryManager(loader=None, sources='')
    hostvars = HostVars(inven, VariableManager(loader=None), None)

    # Add a test host
    host = inven.get_host(name='test')

    # Add a few test variables to the host
    hostvars.set_host_variable(host, 'one', 1)
    hostvars.set_host_variable(host, 'two', 2)

    # Iterate over the hostvars dictionary and verify that the variables
    # are returned

# Generated at 2022-06-22 14:33:55.446854
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    HOSTS = 'localhost ansible_connection=local'

    def _get_play_and_variable_manager():
        play_source = dict(
            name="Ansible Play",
            hosts=HOSTS,
            gather_facts='no',
            tasks=[],
        )

        inventory = InventoryManager(loader=None, sources=HOSTS)
        variable_manager = VariableManager(loader=None, inventory=inventory)
        play = Play().load(play_source, variable_manager=variable_manager, loader=None)

        variable_manager._extra_vars = dict(foo='bar')

        return play, variable_manager


# Generated at 2022-06-22 14:34:05.234641
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory_manager = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)

    inventory_manager.add_host("host1")
    variable_manager.set_host_variable("host1", "test_var", "Hello, world!")

    hostvars = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=DataLoader())

    assert hostvars.raw_get("host1") == {"test_var": "Hello, world!"}

# Generated at 2022-06-22 14:34:17.156157
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = TestLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    variable_manager.set_inventory(inventory)
    variable_manager.set_play_context(play_context)

    variable_manager.set_local_variable('a', 1)
    variable_manager.set_local_variable('b', 2)
    variable_manager.set_local_variable('c', 3)
    variable_manager.set_local_variable('z', 'z')


# Generated at 2022-06-22 14:34:29.264748
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.playbook.play import Play

    vm = VariableManager()
    host = Host(name="example.com")
    play = Play()
    loader = 'fake-loader'
    hostvars = HostVars(vm, loader)

    hostvars_data = {
        '_variable_manager': vm,
        '_loader': loader
    }
    hostvars.__setstate__(hostvars_data)

    assert vm._loader == loader
    assert vm._hostvars == hostvars

# Generated at 2022-06-22 14:34:38.494706
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    import mock
    import ansible.error as ansible_error

    hostvars = HostVars(None, None, None)

    class DummyHost(object):
        def __init__(self, host_name):
            self.name = host_name

    # Create mock vars_cache in order to test if HostVars._variable_manager.get_vars
    # is called correctly
    mvars_cache = mock.Mock()
    mvars_cache.get.side_effect = lambda x: 'foo'

    # Create mock variable_manager in order to test if HostVars.raw_get
    # is called correctly
    mvariable_manager = mock.Mock()
    mvariable_manager.get_vars.side_effect = lambda x: 'foo'

# Generated at 2022-06-22 14:34:46.823377
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import copy

    loader = DictDataLoader({
        'oop.yml': '''ansible:
  host_vars:
    localhost:
      foo: 1
      bar: 2
      baz: 3
'''
    })

    inventory = InventoryManager(loader, sources='oop.yml')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test the result of __iter__
    result = set()
    for host in hostvars:
        result.add(host)

    assert result == set(['localhost'])

    # Test the result of __iter__ if the hostvars are accessed
    # at least once
    hostvars.get('localhost')
    result = set()

# Generated at 2022-06-22 14:34:47.311521
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    assert False

# Generated at 2022-06-22 14:34:57.288638
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import inventory_loader

    hostvars_data = {'first': 'Foo', 'second': 'Bar', 'third': 'Baz', 'fourth': 'Qux'}
    i_mock = MagicMock()
    i_mock.hosts = ['host1', 'host2']
    i_mock.get_host.side_effect = lambda n: n

    vm_mock = MagicMock()
    vm_mock.get_vars.side_effect = lambda host: hostvars_data

    hostvars = HostVars(i_mock, vm_mock, inventory_loader)

    hv_repr = '{'

# Generated at 2022-06-22 14:35:08.481135
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Test HostVars class.

    :return: True if test passes or False if test fails.
    :rtype: bool
    '''
    # Create some fake variables
    variables = { 'foo': 'bar', 'baz': '{{ foo }}'}

    # Create a fake host
    class FakeHost(object):
        name = 'fake_host'
        vars = {'greeting': 'hello'}

    # Create a fake variable manager

# Generated at 2022-06-22 14:35:18.802074
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class AnsibleHost(object):
        def __init__(self, hostname):
            self._hostvars = {'hostvar': 'foo'}
            self.vars = dict(ansible_host='bar')
            self.name = hostname

    class AnsibleInventory(object):
        def __init__(self):
            self.hosts = {}

        def get_host(self, hostname):
            return self.hosts.get(hostname)

    class AnsibleVariableManager(object):
        def __init__(self):
            self._vars_cache = {'cachedvar1': 'x', 'cachedvar2': 'y'}
            self._hostvars = {}


# Generated at 2022-06-22 14:35:28.234940
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import ansible.parsing.dataloader
    import ansible.vars.variable_manager
    import ansible.inventory.manager

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.variable_manager.VariableManager()
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources=[], variable_manager=variable_manager)

    hv = HostVars(inventory=inventory, loader=loader, variable_manager=variable_manager)
    assert repr(hv) == "{}"

    # Add two hosts to the inventory and assign them different variables.

# Generated at 2022-06-22 14:35:36.865977
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    host_list = ['localhost']
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Now create hostvars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Create play context
    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo='bar')
    variable_manager.options_vars = dict(foo='baz')
    variable_manager._options_vars

# Generated at 2022-06-22 14:35:47.883088
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import copy
    import sys
    import yaml
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.inventory import Host
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.template import Templar

    g_vars = dict(foo=dict(bar='baz'), some_list=['a', 'b', 'c'])
    g_vars.update(dict.fromkeys(STATIC_VARS, {}))

    h_vars = dict(foo='baz', some_list=[dict(foo='bar')])

    h_vars_raw = h_vars.copy()
    h_vars_raw["some_list"][0] = AnsibleUndefined()


# Generated at 2022-06-22 14:36:07.420408
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostname = 'localhost'
    hostvars_localhost = hostvars.raw_get(hostname)

    # At this point, no variables have been assigned to localhost
    assert 'ansible_version' not in hostvars_localhost
    assert 'inventory_hostname' not in hostvars_localhost

    # Assign some variables to localhost

# Generated at 2022-06-22 14:36:14.072720
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Create fake objects to pass to constructor of HostVars
    class FakeInventory(object):
        def get_host(self, host_name):
            return 'host_name'

    class FakeVariableManager(object):
        def get_vars(self, host, include_hostvars):
            return 'hostvars'

    class FakeLoader(object):
        pass

    variable_manager = FakeVariableManager()
    inventory = FakeInventory()
    loader = FakeLoader()

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('Fake host') == 'hostvars'

# Generated at 2022-06-22 14:36:19.128056
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    inventory = Inventory()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)
    assert hostvars.__repr__() == '{}'

# Generated at 2022-06-22 14:36:30.319490
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import unittest

    from ansible.inventory import Inventory

    class TestHostVars(unittest.TestCase):
        def test___iter__(self):
            inventory = Inventory()

            # Test iteration over empty inventory
            hostvars = HostVars(inventory, None, None)
            i = 0
            for _ in hostvars:
                i += 1
            self.assertTrue(i == 0)

            # Test iteration over non-empty inventory
            inventory.add_host('foo')
            inventory.add_host('bar')
            hostvars = HostVars(inventory, None, None)
            i = 0
            for _ in hostvars:
                i += 1
            self.assertTrue(i == 2)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestHostVars)


# Generated at 2022-06-22 14:36:40.929337
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from collections import namedtuple
    from ansible import constants as C
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.vars import VarsModule
    from ansible.template.templar import Templar

    # fake inventory
    group = namedtuple('group', ('name',))(name='fake_group')
    host = Host(name='fake_host')
    host.set_variable('ansible_connection', 'local')
    host.groups = [group]
    inventory = InventoryManager(loader=DataLoader(), sources='')
    inventory._hosts_cache

# Generated at 2022-06-22 14:36:43.346382
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Without this test __iter__ of HostVars would not be tested
    assert '__iter__' in dir(HostVars)

# Generated at 2022-06-22 14:36:50.381510
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.__setstate__({"_inventory": inventory,
                           "_loader": loader,
                           "_variable_manager": variable_manager})
    assert hostvars._inventory is inventory
    assert hostvars._loader is loader
    assert hostvars._variable_manager is variable_manager
    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

# Generated at 2022-06-22 14:36:56.708765
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    assert True

    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager

    C.HOST_VARS_PARSED = True
    host_vars = HostVars(InventoryManager([], [], loader=None), None, None)
    assert len(list(host_vars)) == 0
    assert list(host_vars) == []

# Generated at 2022-06-22 14:37:06.538363
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.utils.path import path_dwim

    vault_pass = 'secret'

    loader = DataLoader()
    vault_secrets = VaultLib([('default', vault_pass)])
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    templar = Templar(loader=loader, variables=variable_manager.get_vars())


# Generated at 2022-06-22 14:37:13.783766
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible import utils
    class MyVariableManager:
        def __init__(self):
            self._loader = None
            self._hostvars = None

        def __setstate__(self, state):
            self.__dict__.update(state)

        def get_vars(self, host=None, include_hostvars=True):
            return {}

    from ansible.inventory.manager import InventoryManager

    vm = MyVariableManager()
    loader = utils.plugin_loader.ActionModuleLoader()
    hv = HostVars(InventoryManager(), vm, loader)
    hv._loader = loader

    saved_hv = hv.__getstate__()
    hv.__setstate__(saved_hv)

    # Make sure that __setstate__ didn't remove references to _loader and _

# Generated at 2022-06-22 14:37:34.371345
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Test data
    inventory = {
        'variables': {
            'var': 'foo'
        },
        'hosts': {
            'localhost': {
                'ansible_play_hosts': ['localhost'],
                'inventory_hostname': 'localhost',
                'inventory_hostname_short': 'localhost',
                'vars': {
                    'var_local': 'bar'
                }
            }
        }
    }
    variable_manager = DummyVariableManager(inventory)

    # Test cases
    hostvars = HostVars(inventory, variable_manager, None)
    hv = hostvars['localhost']

    assert hv['var'] == 'foo'
    assert hv['var_local'] == 'bar'

    # Expect AnsibleUndefined exception

# Generated at 2022-06-22 14:37:46.537229
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    '''
    The method raw_get of class HostVars implements the behavior of
    getting information from the inventory, without running the change
    through the templating engine to expand variables in the hostvars.
    '''

    import json

    # Create and load an inventory file
    inventory_file = open('test.inventory', 'w')
    inventory_file.write('''
    [webservers]
    foo [foo_var1: foo_val1, foo_var2: foo_val2]
    bar
    ''')
    inventory_file.close()

    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

# Generated at 2022-06-22 14:37:51.669975
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inv_data = StringIO("""
    [all]
    localhost
    """)

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[inv_data])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert len(hostvars) == 1
    assert list(hostvars) == [inventory.hosts['localhost']]

# Generated at 2022-06-22 14:37:57.925334
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    host = Host('testhost')
    variable_manager = VariableManager()
    hostvars = HostVars({host: {'test_group': {'testvar': 'testvalue'}}}, variable_manager, '/dev/null')
    assert hostvars[host].test_group.testvar == 'testvalue'

# Generated at 2022-06-22 14:38:08.259202
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Prepare test data
    host_names = ['host1', 'host2', 'host3']

    class HostMock:
        def __init__(self, name):
            self.name = name
            self.vars = {}

    class VariableManagerMock:
        def __init__(self):
            self._hostvars = None

        def get_vars(self, include_hostvars=True, include_delegate_to=True):
            return self._hostvars[include_hostvars][include_delegate_to]

    class InventoryMock:
        def __init__(self):
            self.hosts = host_names
            self.host_vars = {}

        def get_host(self, host_name):
            return HostMock(host_name)


# Generated at 2022-06-22 14:38:19.103008
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Emulate object pickling and unpickling
    import pickle
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.variable_manager import VariableManager

    loader = DataLoader()
    hostvars = HostVars(inventory=None, variable_manager=VariableManager(loader=loader), loader=loader)
    hostvars.set_variable_manager(VariableManager(loader=loader))

    hostvars_serialized = pickle.dumps(hostvars, -1)
    hostvars_deserialized = pickle.loads(hostvars_serialized)

    assert hostvars_deserialized._variable_manager._loader is not None
    assert hostvars_deserialized._variable_manager._hostvars is not None

# Generated at 2022-06-22 14:38:29.162808
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    i = Inventory()
    i.add_host(Inventory().Host('h1'))
    i.add_host(Inventory().Host('h2'))

    h = Play().load({'hosts': ['h1', 'h2']}, i, variable_manager=VariableManager())
    h.vars_prompt = {}

    # Need to initialize variable_manager because HostVars does it
    # in constructor.
    h.variable_manager.add_group_vars_file('tests/inventory/group_vars/all', i)
    h.variable_manager.add_host_vars_file('tests/inventory/host_vars/h1', i)
    h.variable

# Generated at 2022-06-22 14:38:37.920492
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    mock_host = MockHost()
    mock_host_2 = MockHost()
    mock_host.name = 'localhost'
    mock_host_2.name = 'test'
    mock_inventory = MockInventory()
    mock_groups = {'all': {'hosts': ['test', 'localhost'], 'children': []}}
    mock_inventory.groups = mock_groups
    mock_inventory.hosts = [mock_host, mock_host_2]
    mock_loader = MockLoader()

    host_vars = HostVars(mock_inventory, None, mock_loader)
    host_vars.__iter__()

    assert mock_host.name in host_vars.__iter__()
    assert mock_host_2.name in host_vars.__iter__()



# Generated at 2022-06-22 14:38:47.601183
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create some hosts, groups and an inventory
    inventory_hostname_short = "foo"
    inventory_hostname = "foo.example.com"
    inventory_host = Host(
        name=inventory_hostname,
        port=22,
        variables=dict(foo="bar", baz=["a", "b", "c"])
    )
    group_name = "group"
    group_hosts = [inventory_hostname]
    group_vars = dict(foo="overridden", bar="baz")

# Generated at 2022-06-22 14:38:57.375903
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import mock
    import sys

    with mock.patch.dict(sys.modules, {'__main__': mock.Mock(__file__='/foo/__main__.py')}):
        from ansible.inventory.manager import HostVars
        from ansible.playbook.play_context import PlayContext
        from ansible.template import Templar
        from ansible.vars.manager import VariableManager

        mock_loader = mock.MagicMock()
        inventory = mock.MagicMock()
        variable_manager = VariableManager(loader=mock_loader)
        context = PlayContext(variable_manager=variable_manager)
        templar = Templar(loader=mock_loader, variables=context.vars_cache)
        hostvars = HostVars(inventory, variable_manager, mock_loader)

        inventory.hosts

# Generated at 2022-06-22 14:39:29.546398
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory')


# Generated at 2022-06-22 14:39:38.780424
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    inventory = MagicMock()
    inventory.hosts = [
        "{{inventory_hostname}}",
        "{{inventory_hostname_short}}",
        "{{ansible_default_ipv4.address}}",
        "{{ansible_default_ipv4.network}}"
        ]
    variable_manager = MagicMock()
    loader = MagicMock()
    hostvars = HostVars(inventory, variable_manager, loader)
    for play_host in inventory.hosts:
        setattr(hostvars, play_host, {})
        var = "test_{0}".format(play_host)
        if len(play_host) <= 10:
            setattr(hostvars[play_host], var, play_host)

# Generated at 2022-06-22 14:39:45.899977
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    inventory = Inventory(host_list=[])
    variable_manager = VariableManager()
    play_context = PlayContext()
    variable_manager.set_inventory(inventory)
    variable_manager.set_play_context(play_context)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert repr({}) == repr(hostvars)

# Generated at 2022-06-22 14:39:56.477684
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class VariableManagerStub(object):
        _hostvars = None

        def get_vars(self, host, include_hostvars=True):
            return {}

    class InventoryStub(object):
        def get_host(self, host):
            return host

    variable_manager = VariableManagerStub()
    inventory = InventoryStub()
    loader = None
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_inventory(inventory)
    hostvars.set_variable_manager(variable_manager)

    assert list(hostvars) == []

    inventory.get_host = lambda host: host if host in ['a', 'b'] else None
    assert list(hostvars) == ['a', 'b']

# Generated at 2022-06-22 14:39:58.035247
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    HostVars(None, None, None).__repr__()


# Generated at 2022-06-22 14:40:10.533137
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.unsafe_proxy import UnsafeProxy

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory, version_info={"git_repo": "foo"})
    hv = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())

    h = Host("localhost")
    h.vars = UnsafeProxy({ 'foo': "bar" })
    inventory.add_host(h)

    assert len(list(hv.__iter__())) == 1

# Generated at 2022-06-22 14:40:17.240917
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import vars_loader
    import pytest

    class TestInventory(object):
        def __init__(self):
            self.hosts = ['localhost','localhost']
            self.groups = []

        def get_host(self, host):
            return TestInventoryHost(host)


# Generated at 2022-06-22 14:40:28.363460
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    import pickle

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager._hostvars = HostVars(InventoryManager(loader=loader), variable_manager, loader)

    hostvars = variable_manager._hostvars
    hostvars_pickle = pickle.dumps(hostvars)

    del loader, variable_manager, hostvars

    hostvars = pickle.loads(hostvars_pickle)

    assert hostvars._variable_manager._loader is not None
    assert hostvars._variable_manager._hostvars is not None

# Generated at 2022-06-22 14:40:36.880771
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from six import StringIO

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=StringIO(u'[localhost]\nlocalhost ansible_connection=local'))
    var_mgr = VariableManager(loader=loader, inventory=inv)

    hostvars = HostVars(inv, var_mgr, loader)
    assert hostvars[u'localhost'][u'ansible_connection'] == u'local'

# Generated at 2022-06-22 14:40:47.272467
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play import Play

    vault_secrets_file = '/tmp/ansible-vault'
    inventory_file = '/tmp/ansible-hosts'

    vault_pass = 'secret'
    vault_secrets_content = "vault_password: %s\n" % vault_pass
    open(vault_secrets_file, 'w').write(vault_secrets_content)


# Generated at 2022-06-22 14:41:42.831943
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    class TestLoader(object):
        pass
    loader = TestLoader()

    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'], variable_manager=vars_manager, vault_password=None)
    hostvars = HostVars(inventory=inventory, variable_manager=vars_manager, loader=loader)

    # Check undefined host
    assert isinstance(hostvars.raw_get('unknown'), AnsibleUndefined)

    # Check localhost
    hostvars_localhost = hostvars.raw_get('localhost')
    assert 'localhost' in hostvars_localhost
    assert 'groups' in hostvars_localhost

# Generated at 2022-06-22 14:41:49.493130
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible import inventory
    from ansible import variable_manager
    from ansible import release
    from ansible.vars.manager import VariableManager

    inv = inventory.Inventory(host_list=[])
    hv = HostVars(inventory=inv, variable_manager=VariableManager(loader=None), loader=None)
    assert isinstance(hv.raw_get('localhost'), variable_manager.HostVars)

    # Require creating localhost node
    inv = inventory.Inventory(host_list=[])
    hv = HostVars(inventory=inv, variable_manager=VariableManager(loader=None), loader=None)
    assert hv.raw_get('localhost')['ansible_version']['full'] == release.__version__

# Generated at 2022-06-22 14:42:00.700559
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader=loader)
    variable_manager.set_inventory(inventory)
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'omit': '123'}
    variable_manager.options_vars = {'role_names': '456'}
    variable_manager._fact_cache['localhost'] = {'ansible_facter': '789'}

# Generated at 2022-06-22 14:42:12.441997
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # Setup variables
    host_name = 'test_host'
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var_1': 'This is my favorite variable'}
    variable_manager._fact_cache['test_host'] = {'ansible_os_family': 'Debian'}
    host = Host(name=host_name)
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=[host])

    # Setup HostVars
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    # Test raw_get method

# Generated at 2022-06-22 14:42:24.337217
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.plugins.loader import lookup_loader
    from ansible.utils import context_objects as co
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lookup = lookup_loader.get('vars', loader=loader)
    tqm = co.TQM(variables=co.VariableManager(loader=loader, lookup_loader=lookup))

    hostvars = HostVars(inventory=tqm.inventory, variable_manager=tqm.variable_manager, loader=loader)
    host = tqm.inventory.get_host('localhost')
    hostvars.set_variable_manager(variable_manager=tqm.variable_manager)
    hostvars.set_host_variable(host=host, varname='test', value='test')


# Generated at 2022-06-22 14:42:34.727107
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    class MockInventory():
        def __init__(self, *args, **kwargs):
            pass

    class MockLoader():
        def __init__(self, *args, **kwargs):
            pass

    class MockVariableManager():
        def __init__(self, *args, **kwargs):
            self._loader = None
            self._hostvars = None

    loader = MockLoader()
    variable_manager = MockVariableManager()

    hostvars = HostVars(MockInventory(), variable_manager, loader)
    hostvars.set_variable_manager(variable_manager)

    assert variable_manager._loader == loader, '_loader was not set'
    assert variable_manager._hostvars == hostvars, '_hostvars was not set'

# Generated at 2022-06-22 14:42:46.392029
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Settings
    inventory_vars = dict()
    loader = BaseLoader()

    # Create VariableManager and HostVars
    variable_manager = VariableManager()
    variable_manager.extra_vars = inventory_vars
    variable_manager.set_loader(loader)
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)

    # Get current state of hostvars
    state = hostvars.__getstate__()

    # Assign to new hostvars and apply saved state
    new_hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)
    new_hostvars.__setstate__(state)

    # Save state again
    new_state = new_hostvars.__getstate__()

    # Check that