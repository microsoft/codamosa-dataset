

# Generated at 2022-06-22 14:33:04.269502
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Since HostVars.__getitem__ does contain templating code, it makes sense
    # to make sure it does what it is expected when dealing with strings.
    # So the following method translates all strings (which are not None) to
    # AnsibleUndefined objects.
    def translate_string(var):
        if isinstance(var, str):
            return AnsibleUndefined(name="dummy")
        return var

    class MockHost:
        def __init__(self, name):
            self.name = name
            self.vars = {}

        def get_vars(self):
            return self.vars

    class MockInventory:
        def __init__(self, hosts):
            self.hosts = []
            self.vars = {}

# Generated at 2022-06-22 14:33:12.473496
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.errors import AnsibleParserError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    test_inventory = "tests/inventory/hostvars_test_inventory"
    try:
        loader = DataLoader()
        inventory = InventoryManager(loader=loader, sources=test_inventory)
    except AnsibleParserError:
        pass
    else:
        hostvars = HostVars(inventory, variable_manager=None, loader=loader)
        hosts = list(hostvars)
        assert hosts == ['localhost', 'localhost', 'host1', 'host2']

# Generated at 2022-06-22 14:33:20.446165
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager, HostVars
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    inventory.add_host("foobar")
    inventory.set_variable("foobar", "bar", "baz")
    hv = HostVars(inventory, VariableManager(), loader)
    assert("bar" in hv.raw_get("foobar"))
    assert("baz" == hv.raw_get("foobar")["bar"])

# Generated at 2022-06-22 14:33:28.422571
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():

    import os
    import unittest
    import ansible
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    class TestHostVars(unittest.TestCase):

        def setUp(self):
            directory = os.path.join(ansible.__path__[0], 'lib', 'ansible', 'test', 'units', 'vars', 'inventory')
            inventory_file = os.path.join(directory, 'test_inventory_included_vars.yml')
            self.inventory = Inventory(loader=None, variable_manager=VariableManager(), host_list=inventory_file)
            self.inventory.parse_inventory(inventory_file)

        def test_hostvars_raw_get(self):
            hostvars = HostVars(self.inventory, VariableManager(), None)

# Generated at 2022-06-22 14:33:37.642090
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=inventory_loader, sources=None)
    loader = DataLoader()
    context = PlayContext()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvars._inventory.add_host("foo")
    hostvars._inventory.add_host("bar")

    assert list(hostvars.__iter__()) == ["foo", "bar"]

# Generated at 2022-06-22 14:33:42.736426
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=DataLoader(), sources="127.0.0.1")
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_context = PlayContext(variable_manager=variable_manager)

    localhost = inventory.get_host('127.0.0.1')
    localhost.vars = {'foo': 'bar'}

    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

# Generated at 2022-06-22 14:33:53.260301
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.vars.results import ResultAggregate

    class CustomHost:
        name = 'customhost'
        vars = {'hostvars': 'hostvars'}

    class CustomGroup:
        hostvars = {'groupname': 'groupname'}
        name = 'groupname'

    class CustomInventory:
        root_vars = {'inventory_dir': 'inventory_dir'}
        host_vars = {CustomHost: {'inventory_file': 'inventory_file'}}
        group_vars = {CustomGroup: {'playbook_dir': 'playbook_dir'}}

        def __init__(self):
            self.hosts = Sequence

# Generated at 2022-06-22 14:34:03.481696
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from collections import namedtuple
    Host = namedtuple("Host", "name")
    Inventory = namedtuple("Inventory", "hosts")

    inventory = Inventory(hosts=[Host("one"), Host("two")])
    hostvars = HostVars(inventory=inventory, variable_manager=None, loader=None)

    # check if type of returned value is what we want
    assert(isinstance(hostvars.__iter__(), type(iter([]))))
    # check if we get all hosts
    assert(set(map(lambda x: x.name, hostvars.__iter__())) == set(map(lambda x: x.name, inventory.hosts)))

# Generated at 2022-06-22 14:34:09.513026
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import copy
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.manager import InventoryManager

    # Create InventoryManager
    inv_manager = InventoryManager(loader=inventory_loader, sources='localhost,')

    # Create HostVars
    vars_cache = {}
    var_manager = inv_manager._variable_manager
    hostvars = HostVars(inv_manager._inventory, var_manager, var_manager._loader)

    # Create HostVarsVars
    hostvars_vars = hostvars[inv_manager.localhost.name]

    # Test inline templates in variables
    var_manager.set_host_variable(inv_manager.localhost, 'var_name', 'var_value')

# Generated at 2022-06-22 14:34:19.686162
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.inventory
    import ansible.playbook.play
    import ansible.plugins.loader
    import ansible.stdlib.filter.core as fcore
    import ansible.template.safe_eval
    import ansible.template.template
    import ansible.utils.plugin_docs
    import ansible.utils.unsafe_proxy

    dataloader = DataLoader()
    variable_manager = VariableManager()
    inventory_obj = ansible.inventory.Inventory(dataloader, variable_manager, True)
    variable_manager.set_inventory(inventory_obj)
    hostvars = HostVars(inventory_obj, variable_manager, dataloader)

    # Sample inventory

# Generated at 2022-06-22 14:34:33.581098
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    loader = FakeLoader({'hello': 'world'})
    inventory = Inventory(loader=loader, host_list=[])

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'type': 'galaxy_far_away'}
    variable_manager._loader = loader
    variable_manager.set_inventory(inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    host_name = "star_destroyer"
    # Note: Host should be created on demand and do not appear in
    # variable_manager._hostvars because we use include_hostvars=False
    assert host_name not in variable_manager._hostvars


# Generated at 2022-06-22 14:34:40.923916
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.template.safe_eval import safe_eval
    from ansible.module_utils.six import string_types

    test_vars = {'test_var_1': 'val_1', 'test_var_2': 'val_2'}

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    hostvarsvars = HostVarsVars(test_vars, loader)


# Generated at 2022-06-22 14:34:47.880627
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    '''
    This test actually runs the method __iter__ of the class HostVars,
    but it needs a lot of setup in order to do so.
    This test is meant to ensure the implementation of HostVars is not changed
    in a way that breaks this method.
    '''
    import ansible.inventory
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.vars.manager

    # Create a temporary inventory, with two hosts
    inventory = ansible.inventory.Inventory(host_list=[])
    inventory.add_host('host1')
    inventory.add_host('host2')

    # Create a temporary data loader
    loader = ansible.parsing.dataloader.DataLoader()

    # Create a temporary variable manager

# Generated at 2022-06-22 14:34:49.622277
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    pass # TODO


# Generated at 2022-06-22 14:34:58.196920
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import sys
    import os
    import unittest

    class InventoryMock():
        def __init__(self, host_list):
            self._host_list = host_list

        def get_host(self, host_name):
            return self._host_list.get(host_name, None)

    class HostMock():
        pass

    class LoaderMock():
        pass

    class VariableManagerMock():
        def get_vars(self, host, include_hostvars):
            return {
                'foo': 'bar',
                'baz': 'xyzzy',
            }

    class TestHostVars(unittest.TestCase):

        def setUp(self):
            self.loader = LoaderMock()
            self.variable_manager = VariableManagerMock()

# Generated at 2022-06-22 14:35:04.815117
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    loader = DataLoader()
    play_context = PlayContext()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)

    for var in hostvars['localhost'].keys():
        assert var in hostvars['localhost']

# Generated at 2022-06-22 14:35:15.508599
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = Hosts()
    hostvars = HostVars(inventory, vars_manager, loader)

    # No inventory nor variable manager defined
    assert not hostvars.raw_get("localhost")

    # Inventory with host but no variable manager
    inventory.add_host(Host("localhost"))
    assert not hostvars.raw_get("localhost")

    # Inventory with host and variable manager
    vars_manager.set_inventory(inventory)
    assert not hostvars.raw_get("localhost")

    # Host with vars in variable manager
    vars_manager.extra_vars = {"some": "1"}

# Generated at 2022-06-22 14:35:25.731750
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager()
    variable_manager.set_inventory(inv_manager)
    hostvars = HostVars(inventory=inv_manager, variable_manager=variable_manager, loader=loader)

    # test case 1 test variables are set in inventory
    hostvars._vars_cache = {None: {'item1': 'value1', 'item2': 'value2'}}

# Generated at 2022-06-22 14:35:35.401878
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory import Inventory
    import tempfile

    tempfile = tempfile.NamedTemporaryFile()

    inventory = InventoryManager(loader=DataLoader(), sources=tempfile.name)

    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    host_vars = HostVars(inventory, variable_manager, DataLoader())

    templar = Templar(loader=DataLoader())

    # FIXME: Add test for value of undefined host
    assert (host_vars['localhost'] == templar.template({}, fail_on_undefined=False, static_vars=STATIC_VARS))

    # FIXME: Add test for single

# Generated at 2022-06-22 14:35:46.338945
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    def get_hosts():
        hosts = [
            "example.org",
        ]
        return [{
            'hostname': h,
            'vars': {'ansible_user': 'root'},
            'groups': ['ungrouped'],
            '_ansible_no_log': False,
        } for h in hosts]


# Generated at 2022-06-22 14:36:01.482401
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # pylint: disable=protected-access
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory(loader=None, variable_manager=VariableManager())
    inventory.set_variable(u'foo', u'bar')
    host = inventory.get_host(u'localhost')
    host.set_variable(u'foo', u'localhost')
    hostvars = HostVars(inventory, VariableManager(), loader=None)

    assert dict(hostvars) == {u'localhost': {u'foo': u'localhost', u'ansible_foo': u'bar'}}
    assert repr(hostvars) == "{'localhost': {'ansible_foo': 'bar', 'foo': 'localhost'}}"

# Generated at 2022-06-22 14:36:06.598182
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    # Given
    variables = {'var1': 1, 'var2': 2, 'var3': 3}
    loader = None
    # When
    inst = HostVarsVars(variables, loader)
    # Then
    assert [tuple(i) for i in enumerate(inst)] == [(0, 'var1'), (1, 'var2'), (2, 'var3')]


# Generated at 2022-06-22 14:36:11.687368
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = MockLoader()
    variables = {'a': 'a', 'b': 'b'}
    hvv = HostVarsVars(variables, loader)

    actual = set(iter(hvv))

    # HostVarsVars will not return any vars that contain
    # non-ansible objects, so it will not return any vars at all
    expected = set()
    assert expected == actual


# Generated at 2022-06-22 14:36:16.688502
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import ansible.parsing.dataloader
    from ansible.vars.manager import VariableManager

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory=None, variable_manager=variable_manager, loader=loader)

    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

    hostvars.__setstate__(state=dict())

    assert hostvars._variable_manager._loader is loader
    assert hostvars._variable_manager._hostvars is hostvars

# Generated at 2022-06-22 14:36:28.582281
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible import constants as C
    from ansible.vars import VariableManager

    loader = DictDataLoader({C.DEFAULT_HOST_LIST: 'localhost'})
    variable_manager = VariableManager.VariableManager(loader=loader)
    variable_manager.extra_vars = dict(my_var='my_value')

    host_vars = HostVars(loader.inventory, variable_manager, loader)
    assert host_vars['localhost']['my_var'] == 'my_value'

    import pickle
    data = pickle.dumps(host_vars)
    host_vars_restored = pickle.loads(data)

    assert host_vars_restored['localhost']['my_var'] == 'my_value'

    # Access _variable_manager and _loader attributes to check that

# Generated at 2022-06-22 14:36:33.843052
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class MockLoader:
        # we need a loader only because constructor of Templar needs it
        pass

    class MockTemplate:
        def render(self, value, fail_on_undefined=False, static_vars=[]):
            return value

    def test(vars):
        v = HostVarsVars(vars, MockLoader())
        assert sorted(v) == sorted(vars)

    test({'a': 1, 'b': 2})
    test([])

# Generated at 2022-06-22 14:36:41.641170
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])

    hostvars = HostVars(inventory, VariableManager(), loader)

    # Test that undefined host returns AnsibleUndefined and not a dict.
    assert isinstance(hostvars.raw_get('undefined_host'), AnsibleUndefined)

# Generated at 2022-06-22 14:36:47.454974
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = '''
        [first_group]
        localhost
    '''
    in_mem_inventory = Inventory(loader=DataLoader(vault_password='secret'))
    in_mem_inventory.parse_inventory(inventory)
    vars_manager = VariableManager(loader=None, inventory=in_mem_inventory)
    hostvars = HostVars(inventory, vars_manager, DataLoader(vault_password='secret'))

    hostvars.set_host_variable('localhost', 'first_var', 'first_value')
    hostvars.set_host_variable('localhost', 'second_var', 'second_value')
    hostvars.set_host_variable('localhost', 'third_var', 'third_value')


# Generated at 2022-06-22 14:36:52.908708
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class MockTemplar:
        def __init__(self):
            self.template_calls = []
        def template(self, variable, fail_on_undefined=False, static_vars=STATIC_VARS):
            self.template_calls.append((variable, fail_on_undefined, static_vars))
            return '{}[{}]'.format(variable['key'], variable['index'])

    class MockVariableManager:
        def __init__(self):
            self.get_vars_calls = []
            self.cached_result = {'key': 'value', 'index': 1}
        def get_vars(self, host, include_hostvars=False):
            self.get_vars_calls.append((host, include_hostvars))
            return self

# Generated at 2022-06-22 14:37:03.272815
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory("tests/inventory", loader=loader)
    variable_manager = VariableManager(loader=loader)

    hv = HostVars(inventory, variable_manager, loader)
    assert isinstance(hv["localhost"], Mapping)
    assert hv["localhost"]["inventory_hostname"] == "localhost"
    assert hv["localhost"]["foo"] == "bar"

    hv["localhost"]["new_var"] = "new_value"
    assert hv["localhost"].get("new_var") == "new_value"
    assert hv["localhost"].get("new_var2") is None


# Generated at 2022-06-22 14:37:26.662608
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    hv = HostVars({'foo': {'bar': 'var'}}, hostvars_vars=True)
    assert hv['foo']['bar'] == 'var'

    v2 = VariableManager()
    hv2 = HostVars({'foo': {'bar': 'var'}}, hostvars_vars=True)
    hv2.set_variable_manager(v2)
    assert hv2['foo']['bar'] == 'var'

    hv3 = HostVars({'foo': {'bar': 'var'}}, hostvars_vars=True)
    assert hv3.raw_get('foo') == {'bar': 'var'}


# Generated at 2022-06-22 14:37:35.101212
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var

    inventory = Inventory(host_list=[])
    variable_manager = VariableManager(loader=None)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # hostvars.raw_get(host_name) should return a valid AnsibleVariable
    # instance for an existing host in inventory.
    host = inventory.get_host('bad_host')
    host_name = host.get_name()
    assert hostvars.raw_get(host_name) == AnsibleUndefined(name="hostvars['bad_host']")

    # hostvars.raw_get(host_name) should return a valid AnsibleVariable
    # instance for existing

# Generated at 2022-06-22 14:37:47.120202
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_host_variable(inventory.get_host("localhost"), "foo", "bar")
    variable_manager.set_host_variable(inventory.get_host("localhost"), "bar", {"foo": "bar"})
    variable_manager.set_host_variable(inventory.get_host("localhost"), "baz", [{"foo": "bar"}, "foo"])
    hostvars = HostVars(inventory, variable_manager, loader)


# Generated at 2022-06-22 14:37:58.679292
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    v = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-22 14:38:09.142177
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory_path = 'tests/unit/inventory/hosts'
    loader = 'ansible.loader.DictDataLoader'
    inventory_manager = InventoryManager(loader=loader, sources=inventory_path)
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)
    hostvars = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=loader)
    assert hostvars['localhost'] is not None
    assert hostvars['nonexistent_host'] is None
    assert "ansible_version" in hostvars['localhost']
    assert hostvars['localhost']["ansible_version"] is not None
    assert "omit" in hostvars['localhost']
   

# Generated at 2022-06-22 14:38:12.483452
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvarsvars = HostVarsVars({'var1': 1, 'var2': 2, 'var3': 3}, None)
    assert set(iter(hostvarsvars)) == {'var1', 'var2', 'var3'}

# Generated at 2022-06-22 14:38:25.284804
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Mocking object AnsibleUndefined
    class MockAnsibleUndefined:
        def __init__(self, name):
            self.name = name

    # Mocking object Inventory
    class MockInventory:
        def get_host(self, host_name):
            return "host"

        hosts = [
            "host",
        ]

    # Mocking object VariableManager
    class MockVariableManager:
        loader = "loader"

        def get_vars(self, host, include_hostvars):
            return { "host": { "var": "{{ var }}" } }

    # Mocking object HostVars
    class MockHostVars:
        def __init__(self):
            self._inventory = MockInventory()
            self._loader = "loader"
            self._variable_manager = MockVariableManager()


# Generated at 2022-06-22 14:38:36.840236
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import yaml
    from ansible.errors import AnsibleParserError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inv_filename = os.path.join(os.path.dirname(__file__), 'hosts')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[inv_filename])

    test = "{{ hostvars['localhost']['ansible_facts']['distribution'] }}"
    template = Templar(loader=loader)
    var_manager = inventory.get_variable_manager()
    var_manager._hostvars = HostVars(inventory, var_manager, loader)
    assert template.template(test, fail_on_undefined=False, variable_manager=var_manager) == "Debian"

# Generated at 2022-06-22 14:38:46.739602
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars.set_host_variable("localhost", "test_var", "test_value")
    hostvars.set_host_variable("localhost", "test_dict", {'test_key': 'test_value'})

    templar = Templar(loader=loader, variables={})
    assert templar.template

# Generated at 2022-06-22 14:38:56.617086
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    """
    HostVars.__iter__() returns an iterator over Host objects
    """

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from collections import Sequence

    inv_data = """
    all:
      vars:
        foo: hello
      hosts:
        foo0.example.com:
        foo1.example.com:
    """

    inv = InventoryManager(loader=None, sources=inv_data)
    vars = VariableManager(loader=None, inventory=inv)
    hv = HostVars(inventory=inv, loader=None, variable_manager=vars)

    # HostVars.__iter__() returns an iterator over Host objects
    assert isinstance(hv.__iter__(), Sequence)

# Generated at 2022-06-22 14:39:23.623129
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    host = Host(name="test")
    inventory._hosts_cache["test"] = host
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable(host=host, varname="foo", value="bar")
    host_vars_vars = hostvars[host.name]
    assert host_vars_vars.__iter__() == ['foo']
    hostvars

# Generated at 2022-06-22 14:39:31.971238
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import copy
    variable_manager = MockVariableManager()
    variable_manager.set_nonpersistent_facts("test_host1", dict(a="b", c=1))
    variable_manager.set_host_facts("test_host1", dict(x="y", y=2))
    variable_manager.set_host_variable("test_host1", "z", 3)
    variable_manager.set_host_variable("test_host2", "h", 4)
    inventory = MockInventory()
    HostVars._variable_manager = variable_manager
    HostVars._inventory = inventory

# Generated at 2022-06-22 14:39:36.378278
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {'v1': 123, 'v2': [1, 2], 'v3': {'k1': 'v1', 'k2': 'v2'}}
    loader = None

    hostvars_vars = HostVarsVars(variables, loader)

    assert set(hostvars_vars) == set(variables)

# Generated at 2022-06-22 14:39:41.880841
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    results = [x for x in HostVarsVars(None, None)]
    assert results == []

    results = [x for x in HostVarsVars({}, None)]
    assert results == []

    results = [x for x in HostVarsVars({"foo": "bar"}, None)]
    assert results == ["foo"]

    results = [x for x in HostVarsVars({"foo": "bar", "baz": "foobar"}, None)]
    assert results == ["foo", "baz"]

# Generated at 2022-06-22 14:39:53.483811
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    HostVars_instance = HostVars(inventory=None, variable_manager=None, loader=None)

    # We need this because HostVars depends on _variable_manager
    # and _inventory and we cannot create them in tests.
    # As a result hostvars['localhost'] will be undefined.
    def __contains__(self, host_name):
        return host_name == 'localhost'

    def __iter__(self):
        for host_name in ['localhost']:
            yield host_name

    HostVars_instance.__contains__ = __contains__
    HostVars_instance.__iter__ = __iter__

    assert HostVars_instance.__repr__() == "{'localhost': Undefined}"

# Generated at 2022-06-22 14:39:59.713957
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader

    # prepare all we need to emulate the real Ansible
    loader = DataLoader()
    add_all_plugin_dirs()

    # create a fake inventory
    inventory = InventoryManager(loader=loader, sources=['localhost'])

    # create a fake play with a task

# Generated at 2022-06-22 14:40:11.712303
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(
        loader=loader,
        sources=["localhost,"]
    )
    variable_manager = VariableManager(
        loader=loader,
        inventory=inventory,
        version_info=dict(major=2, minor=0, micro=0)
    )
    variable_manager._fact_cache = dict(
        localhost=dict(
            hostvar1='{{ foo }}',
            hostvar2='{{ bar }}',
            hostvar3='{{ baz }}',
        )
    )
    variable_manager._vars_cache = dict(
        hostvar2='bar',
    )
    variable

# Generated at 2022-06-22 14:40:17.780012
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class DummyInventory():
        def __init__(self, host_name):
            self.hosts = [(host_name, {})]
            self.get_host = self.hosts.__getitem__

        def get_host(self, host_name):
            if self.hosts[0][0] == host_name:
                return self.hosts[0]
            else:
                return None

        def set_variable(self, host, varname, value):
            self.hosts[0][1][varname] = value

    loader = lambda name: __import__(name)
    inventory = DummyInventory('example.com')

    hostvars = HostVars(inventory, None, loader)
    # Test the getitem function with a simple set of variables
    hostvars.set_host_variable

# Generated at 2022-06-22 14:40:22.115036
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    if hasattr(HostVars, '__getitem__'):
        assert True
    else:
        assert False, "HostVars class should have attribute __getitem__"


# Generated at 2022-06-22 14:40:32.028668
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.plugins.loader import vars_loader

    class DummyInventory(object):
        hosts = []
        _vars_per_host = {}
        _vars_per_group = {}
        _vars_per_hostgroup = {}

        def get_host(self, hostname):
            return Host(name=hostname)

        def add_group(self, groupname):
            self.groups.append(groupname)

    dummy_inventory = DummyInventory()

    loader = DataLoader()
    vars_manager = VariableManager(loader=loader)
    vars_manager.set_inventory(dummy_inventory)
    hostvars

# Generated at 2022-06-22 14:41:21.908758
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    host = 'host1'

    inventory.add_host(host=host)
    inventory.set_variable(host, 'foo', 'bar')
    assert str(hostvars) == "{'host1': {'foo': 'bar'}}"

# Generated at 2022-06-22 14:41:27.798852
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Unit test for method ``__getitem__`` of class ``HostVars``.

    :returns: ``True`` if test is successful
    :rtype: ``bool``
    '''
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources="")
    variable_manager = VariableManager(loader=DataLoader())
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())
    hostvars.set_host_variable(inventory.get_host('localhost'), 'test_hostvars', 'localhost')

# Generated at 2022-06-22 14:41:31.796349
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    ''' HostVarsVars.__iter__() '''
    hh = HostVarsVars(dict(foo=1, bar=2), None)
    assert list(hh) == ['foo', 'bar']



# Generated at 2022-06-22 14:41:43.269429
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVarsVars

    host_vars_vars = HostVarsVars({'var1': [], 'var2': {}, 'var3': True, 'var4': None}, None)

    variable_manager = VariableManager()

# Generated at 2022-06-22 14:41:46.116563
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # When
    variables = dict(foo="{{ bar }}", bar="baz")
    hostvars = HostVars(None, None)

    # Then
    assert hostvars.raw_get("localhost") == variables


# Generated at 2022-06-22 14:41:50.283450
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inv = InventoryManager(loader=None, sources=["localhost,"])
    var_mgr = VariableManager(loader=None, inventory=inv)
    hostvars = HostVars(inventory=inv, loader=None, variable_manager=var_mgr)
    assert repr(hostvars) == "{'localhost': {}}"

# Generated at 2022-06-22 14:42:01.209481
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class FakeInventory(object):
        def __init__(self, data):
            self._data = data

        def __iter__(self):
            # Use static values to avoid test failures if HostVars
            # uses actual host names in some cases.
            return iter(['h1', 'h2'])

        def get_host(self, host):
            if host == 'h1':
                return FakeHost('h1', 'g1', self._data[0])
            elif host == 'h2':
                return FakeHost('h2', 'g2', self._data[1])
            else:
                return None

    class FakeHost(object):
        def __init__(self, name, primary_group, vars):
            self.name = name
            self.groups = [FakeGroup(primary_group)]
           

# Generated at 2022-06-22 14:42:13.201279
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle

    # Create a host and a variable manager
    from ansible import inventory
    host = inventory.Host('some_host')
    variable_manager = inventory.VariableManager()

    # Create an instance of HostVars
    # Note: the variable_manager is assigned to self._variable_manager
    # attribute in the constructor
    from ansible import variables
    hostvars = variables.HostVars(None, variable_manager, None)

    # Dump the hostvars
    state = hostvars.__getstate__()
    serialized_hostvars = pickle.dumps(state)

    # Load the hostvars
    loaded_state = pickle.loads(serialized_hostvars)

    # Create a variable manager and a loader
    variable_manager = inventory.VariableManager()
    loader = 'anything'



# Generated at 2022-06-22 14:42:24.801134
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Unit test for method __getitem__ of class HostVars
    '''

    # There are two scenarios:
    #
    # 1. Host is not in the inventory
    #
    # 2. Host is in the inventory:
    #  a) facts for the host are defined in the inventory
    #  b) facts for the host are not defined in the inventory
    #
    # Additionally, the returned value from __getitem__ is a HostVarsVars
    # instance, so we do not need to test the HostVarsVars class here.

    # 1. Host is not in the inventory
    hv = HostVars({}, {}, mock.Mock)
    with pytest.raises(AnsibleUndefined) as excinfo:
        hv['non_existing_host']

# Generated at 2022-06-22 14:42:35.388677
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader)
    variables = VariableManager(loader)

    inventory.add_group('all_hosts')
    inventory.add_host(host='localhost', group='all_hosts')
    inventory.hosts['localhost'].set_variable('first_var', value='FIRST_VALUE')
    inventory.hosts['localhost'].set_variable('second_var', value='SECOND_VALUE')

    hostvars = HostVars(inventory, variables, loader)

    assert hostvars['localhost'] == hostvars