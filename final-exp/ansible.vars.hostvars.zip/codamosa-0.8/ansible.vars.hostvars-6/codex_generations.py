

# Generated at 2022-06-22 14:32:54.479263
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {'aaa': 123, 'bbb': 'abc'}
    varsvars = HostVarsVars(variables, lambda: None)
    assert set(varsvars) == set(variables)


# Generated at 2022-06-22 14:33:03.241359
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inv = InventoryManager(loader, sources=['localhost,'])
    variable_manager = VariableManager(loader, inventory=inv)
    hostvars = HostVars(inv, variable_manager, loader)
    host = Host('localhost', variable_manager=variable_manager)
    inv.add_host(host)
    hostvars.set_host_facts(host, dict(ansible_facts=dict(key1='value')))
    assert hostvars['localhost']['key1'] == 'value'

# Generated at 2022-06-22 14:33:08.188213
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inv)
    temp_host = type('host', (object,), dict(name='testhost'))()
    hostvars = HostVars(inv, variable_manager, loader)
    hostvars.set_host_facts(temp_host, dict(ansible_facts=dict(platform=dict(os_family="FreeBSD"))))
    assert hostvars.raw_get('testhost')['ansible_os_family'] == 'FreeBSD'

# Generated at 2022-06-22 14:33:17.301622
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    inventory = [Host(name="example.org", port=22)]
    variable_manager = VariableManager()
    loader = DataLoader()
    hostvars = HostVars(inventory, variable_manager, loader)
    assert loader.get_basedir() == hostvars._loader.get_basedir()
    assert variable_manager._hostvars is hostvars
    variable_manager._loader = None
    variable_manager._hostvars = None
    hostvars.__setstate__(hostvars.__getstate__())
    assert variable_manager._loader is hostvars._loader
   

# Generated at 2022-06-22 14:33:20.928970
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    obj = HostVarsVars({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}, object())
    assert list(iter(obj)) == ['key1', 'key2', 'key3']

# Generated at 2022-06-22 14:33:28.728415
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader, sources=["tests/inventory"])
    inventory = inv_mgr.get_inventory()
    var_mgr = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, var_mgr, loader)

    # Facts has not been set
    hostname = 'testhost'
    assert hostvars.raw_get(hostname)['foo'] == 'test'
    # Set facts
    fact = dict(bar='bar')
    host = inventory.get_host(hostname)

# Generated at 2022-06-22 14:33:38.252100
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    hostvars = {'var1': 1, 'var2': 'two'}
    hostvarsvars = HostVarsVars(hostvars, loader)

    vm = VariableManager(loader=loader)

    # Nothing is rendered
    assert hostvarsvars.__repr__() == repr(hostvars)

    vm.set_nonpersistent_facts(None, hostvars)

    # Everything is rendered
    assert hostvarsvars.__repr__() == repr({'var1': 1, 'var2': 'two'})

    # Test recursive rendering

# Generated at 2022-06-22 14:33:42.365261
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import os
    import sys
    import tempfile
    import textwrap
    import yaml
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Create a temporary directory
    tmp_path = tempfile.mkdtemp()

    # Create a temporary inventory
    yaml_inventory = textwrap.dedent("""
        all:
          vars:
            foo: 'bar'
        """)

    inventory_path = os.path.join(tmp_path, "hosts")
    inventory_file = open(inventory_path, 'w')
    inventory_file.write(yaml_inventory)
    inventory_file.close()

    # Read the inventory file
    loader = DataLoader()

# Generated at 2022-06-22 14:33:53.182317
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    import tempfile
    import os

    # Create a temporary files to store variables
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    # Initialize the variable manager
    variable_manager = VariableManager()

    # Create an instance of HostVars
    hostvars = HostVars(None, variable_manager, None)

    # Call method __getstate__ of VariableManager
    state = variable_manager.__getstate__()

    # Verify that _hostvars is stored in the state
    assert state.has_key('_hostvars')

    # Verify that _hostvars instance stored in the state is the same as
    # the one previously assigned to the variable manager
    assert hash(state['_hostvars']) == hash(hostvars)

# Generated at 2022-06-22 14:34:04.837414
# Unit test for method set_host_facts of class HostVars
def test_HostVars_set_host_facts():
    from ansible.inventory import Inventory
    import ansible.vars.hostvars
    import ansible.parsing.vault
    import ansible.vars.variable_manager
    import ansible.vars.hostvars

    host = "test_hostvars_set_host_facts"
    hostvars = ansible.vars.hostvars.HostVars(ansible.inventory.Inventory(""), ansible.vars.hostvars.HostVarsVars)

    # Decrypt_method is the first time call
    ansible.parsing.vault.VaultLib.decrypt_method("decrypt")

    # File format:
    # {
    #     "key": "value"
    # }

# Generated at 2022-06-22 14:34:19.238007
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from unittest import TestCase
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs
    import jinja2

    class TestHostVars(object):
        def test(self):
            loader = DataLoader()
            variable_manager = VariableManager()
            inventory = Inventory(loader, variable_manager, None)
            variable_manager.set_inventory(inventory)
            inventory._hosts_cache['localhost'] = {'vars': {'foo': 'bar', 'baz': 'quux'}}
            hostvars = HostVars(inventory, variable_manager, loader)

            # Test that a HostVarsVars is returned
            hostvars_

# Generated at 2022-06-22 14:34:29.378104
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, variable_manager._loader)
    hostvars._inventory._hosts_cache = {
        'localhost': {
            'hostname': 'localhost',
            'vars': {
                'foo': 'bar',
                'one': 'two'
            }
        }
    }
    assert hostvars.get('localhost').keys() == set(['foo', 'one'])

# Generated at 2022-06-22 14:34:31.425370
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert isinstance(HostVars(None, None, None).raw_get("localhost"), dict)


# Generated at 2022-06-22 14:34:35.146092
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager

    inventory = "file:///foo/bar"
    hostvars = HostVars(inventory, VariableManager(), loader=None)

    # Calling the method should be safe.
    hostvars.__setstate__({})


# Generated at 2022-06-22 14:34:36.698805
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    assert isinstance(HostVars.__iter__, type(Mapping.__iter__))


# Generated at 2022-06-22 14:34:45.020991
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # Test is done on Python 3.4 because in Python 2.6 there is no support for
    # annotations.
    # Note: This test does not validate result of method. It just checks the
    #       test itself.
    from __future__ import annotations
    import pickle

    # Catch exception to check if it is raised in __getstate__
    try:
        # Get result of __repr__
        result = repr(HostVars({}, loader={}, variable_manager={}))

        # Check that __repr__ returns correct type
        assert isinstance(result, str)
    except AttributeError:
        # We should not get here because we made sure that all the necessary
        # attributes exist.
        assert False

# Generated at 2022-06-22 14:34:53.645000
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Ugly dependency on a private attribute: Avoid it if we can
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert sorted(hostvars) == []

    inventory.add_host('hostA')
    inventory.add_host('hostB')
    inventory.add_host('hostC')
    assert sorted(hostvars) == ['hostA', 'hostB', 'hostC']


# Generated at 2022-06-22 14:35:03.321094
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = {}
    variable_manager = VariableManager(loader=loader)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Verify that initial state of HostVars is correct
    assert hostvars._variable_manager._loader == loader
    assert hostvars._variable_manager._hostvars is hostvars
    assert variable_manager._loader == loader
    assert variable_manager._hostvars is hostvars

    # Verify that __setstate__ preserves _loader and _hostvars attributes
    # set by the constructor
    hostvars_state = hostvars.__getstate__()

# Generated at 2022-06-22 14:35:14.415069
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import pytest
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    inventory = Inventory(loader=None, host_list=[])
    loader = None
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # Add a new host to the inventory and inventory cache
    host = inventory.add_host('test')
    hostvars[host.name] = {'hello':'world'}
    assert host.name in hostvars
    assert host in hostvars

    # Make sure the __iter__ method of hostvars returns an generator with the expected host as only member
    generator = hostvars.__iter__()
    assert next(generator) == host

# Generated at 2022-06-22 14:35:19.458166
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    def create_manager(vars):
        return VariableManager(loader=DictDataLoader({}),
                               variables=vars)

    h = HostVars(inventory=Inventory('localhost'),
                 variable_manager=create_manager({}),
                 loader=DictDataLoader({}))

    # Make sure _loader and _hostvars attributes are not in manager
    manager = h._variable_manager
    assert not hasattr(manager, '_loader')
    assert not hasattr(manager, '_hostvars')

    # Pickle instance of HostVars
    s = pickle.dumps(h)
    # Unpickle instance of HostVars
    h = pickle.loads(s)

    manager = h._variable_manager
    assert manager._loader is h._loader
    assert manager._hostvars is h

# Generated at 2022-06-22 14:35:30.168062
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class FakeInventory:
        def __init__(self):
            self.hosts = ["foo", "bar"]

    class FakeVariableManager:
        def __init__(self):
            self._hostvars = None

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role import Role

    play = Play().load(dict(name="test", hosts=["foo", "bar"]), variable_manager=None, loader=None)
    play._included_files = [IncludedFile("/foo/roles/role1/tasks/main.yml")]

# Generated at 2022-06-22 14:35:33.655588
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory_manager = InventoryManager(loader=None, sources=["localhost,"])
    variable_manager = VariableManager(loader=None, inventory=inventory_manager)

    hostvars = HostVa

# Generated at 2022-06-22 14:35:39.890591
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    class FakeInventory(Inventory):
        def __init__(self):
            self.hosts = ['1', '2']

    class FakeVariableManager(VariableManager):
        def __init__(self):
            pass

    h = HostVars(FakeInventory(), FakeVariableManager(), 'loader')
    assert list(iter(h)) == ['1', '2']



# Generated at 2022-06-22 14:35:45.102836
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    data = dict(a=1, b=2, c=3)
    hostvarsvars = HostVarsVars(data, loader=DataLoader())
    keys = set()
    for key in hostvarsvars:
        keys.add(key)
    assert keys == set(data.keys())

# Generated at 2022-06-22 14:35:54.685646
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Create a mock of HostVars
    class Host:
        def __init__(self, hostname):
            self.name = hostname

    class Hosts:
        def __init__(self):
            self.hosts = [Host(hostname) for hostname in ['host1', 'host2', 'host3']]

    class Loader:
        def __init__(self):
            pass

    class Inventory:
        def __init__(self):
            self._hosts = Hosts()

        def hosts(self):
            return self._hosts

    class VariableManager:
        def __init__(self):
            pass

    loader = Loader()
    inventory = Inventory()
    variable_manager = VariableManager()
    hostvars = HostVars(inventory, variable_manager, loader)

    # Check that each

# Generated at 2022-06-22 14:36:03.621544
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager

    inventory = FakeInventory()
    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager)

    assert hostvars._inventory is inventory
    assert hostvars._variable_manager is variable_manager

    assert variable_manager._hostvars is hostvars

    # It's a private method so we have to use _ to avoid pylint's warnings
    hostvars._variable_manager = None
    hostvars.__setstate__({})

    assert hostvars._variable_manager is not None
    assert hostvars._variable_manager._hostvars is hostvars


# Generated at 2022-06-22 14:36:08.967248
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, DataLoader())

    assert len(list(hostvars)) == 1

# Generated at 2022-06-22 14:36:16.034206
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=loader)

    # If everything works correctly, _loader and _hostvars of
    # VariableManager will be set to hostvars
    hostvars.__setstate__({'_inventory': inventory, '_loader': loader, '_variable_manager': variable_manager})
    assert variable_manager._loader is hostvars._loader
    assert variable_manager._hostvars is hostvars._hostvars

# Generated at 2022-06-22 14:36:28.251443
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import ansible.plugins.loader as loader_pkg
    loaders = loader_pkg.all(class_only=True)

    class Inventory(object):
        def __init__(self, loader, variable_manager):
            self.loader = loader
            self.variable_manager = variable_manager

        def get_host(self, host_name):
            host = Host(host_name)
            host.vars = {
                'ansible_connection': 'local',
            }
            host.groups = ['ungrouped']
            return host

        def set_variable_manager(self, variable_manager):
            self.variable_manager = variable_manager


    class Host(object):
        def __init__(self, name):
            self.name = name



# Generated at 2022-06-22 14:36:35.546930
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(variable_manager=variable_manager, loader=loader)
    variable_manager.set_inventory(None)
    var = {'a': 'a', 'b': 'b'}
    variables = HostVarsVars(var, loader=loader)
    res = []
    for i in variables:
        res.append(i)
    assert len(res) == 2
    assert res[0] == 'a'
    assert res[1] == 'b'


# Generated at 2022-06-22 14:36:48.841664
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({
        "host_vars": {
            "host1": {
                "foo": "1",
                "bar": "2"
            },
            "host2": {
                "foo": "3",
                "bar": "4"
            }
        }
    })

    inventory = InventoryManager(loader=loader, sources="host_vars")

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert set(hostvars.keys()) == {"host1", "host2"}

    hostvars.set_variable_manager(VariableManager(loader=loader, inventory=inventory))

# Generated at 2022-06-22 14:36:57.918837
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.vars.variable_manager import VariableManager

    variable_manager = VariableManager()

    test_subject = HostVars(inventory=None, variable_manager=variable_manager, loader=None)

    assert variable_manager._loader is None
    assert variable_manager._hostvars is None

    test_subject.__setstate__({'_inventory': None, '_loader': None, '_variable_manager': variable_manager})

    assert variable_manager._loader is None
    assert variable_manager._hostvars is test_subject

# Generated at 2022-06-22 14:37:02.467495
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader

    inventory_dir = os.path.join(os.getcwd(), 'tests', 'inventory_examples')
    inventory = InventoryManager(loader=inventory_loader,
                                 sources=['localhost,',
                                          'hosts',
                                          os.path.join(inventory_dir, 'hosts_override')])

# Generated at 2022-06-22 14:37:11.389631
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Test that __getstate__ and __setstate__ are symmetric.
    # In addition, verify that the following vars are preserved:
    # _loader and _hostvars

    # Create variables manager
    # (methods __getstate__ and __setstate__ don't try to
    # save _loader and _hostvars variables)
    from ansible.vars.manager import VariableManager
    vm = VariableManager()

    # Create HostVars
    from ansible.inventory.manager import InventoryManager
    iom = InventoryManager('localhost,')
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    hv = HostVars(iom, vm, loader)

    # Add _loader

# Generated at 2022-06-22 14:37:22.501730
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    loader = DictDataLoader({
        "group_vars/group1": "key1: value1",
        "group_vars/group2": "key2: value2",
        "host_vars/host": "---\nkey3: value3"
    })
    variable_manager = VariableManager(loader=loader)
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=["host"])
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a known host
    data = hostvars.raw_get("host")
    assert "key1" not in data
    assert "key2" not in data
    assert "key3" in data
    assert "value3" == data["key3"]

    # Test with an unknown host
    data

# Generated at 2022-06-22 14:37:33.862484
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():

    # Ensure external iterators don't disturb iteration
    class ExternalIterator:

        # Iterator for the template engine
        def __iter__(self):
            return self

        # Iterator for the external iterator
        def __getitem__(self, i):
            return self

    # Ensure that neither types nor keys are iterated over
    variables = { 'foo': 'bar', 'baz': ExternalIterator() }
    variables_copy = dict(variables)
    hostvars_vars = HostVarsVars(variables, loader=None)

    assert set(hostvars_vars.keys()) == set(variables_copy.keys())
    for key in hostvars_vars.keys():
        assert hostvars_vars[key] == variables_copy[key]

    assert len(hostvars_vars) == len

# Generated at 2022-06-22 14:37:38.171832
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    hv = HostVars({'a': 1, 'b': 2}, loader=None)
    assert hv['a'] == 1
    assert hv['b'] == 2
    assert hv['c'] == AnsibleUndefined(name="hostvars['c']")



# Generated at 2022-06-22 14:37:48.340382
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader)
    host = Host("testhost")
    inventory.add_host(host)
    inventory.get_host("testhost").set_variable("testvar", "testvalue")
    var_manager = VariableManager(loader=loader, inventory=inventory)

    hv = HostVars(inventory, var_manager, loader)

    assert hv.raw_get("testhost") is not None
    assert hv.raw_get("testhost")["testvar"] == "testvalue"

# Generated at 2022-06-22 14:38:00.373799
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    ''' Validates if we can iterate over HostVarsVars '''
    from .vars_plugins.host_variables import HostVarsVarsPlugin
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hostvars_vars_plugin = HostVarsVarsPlugin(loader=loader)
    var_manager = VariableManager(loader=loader, inventory=InventoryManager(loader=loader), use_task_vars=True, extra_vars={'foo': 'bar'},  vars_plugins=[hostvars_vars_plugin])
    templar = Templar(loader=loader, variables=var_manager.get_vars())


# Generated at 2022-06-22 14:38:08.792967
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible import inventory
    from ansible import variable_manager

    loader = 'dummy'
    inventory_file = 'dummy'
    variable_manager_object = variable_manager.VariableManager()

    inventory_object = inventory.Inventory(loader=loader, variable_manager=variable_manager_object, host_list=[])
    hostvars_object = HostVars(inventory_object, variable_manager_object, loader)

    hostvars_object.raw_get('test_host')
    assert hostvars_object.raw_get('test_host') == {
        "group_names": [],
        "groups": {}
    }

# Generated at 2022-06-22 14:38:26.387891
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Host, Inventory

    hv = HostVars(Inventory(host_list=[Host(name='localhost')]), variable_manager=None, loader=None)
    assert [h.name for h in hv] == ['localhost']

    hv = HostVars(Inventory(host_list=[Host(name='localhost'), Host(name='other')]), variable_manager=None, loader=None)
    assert [h.name for h in hv] == ['localhost', 'other']

# Generated at 2022-06-22 14:38:37.489867
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    '''
    Make sure that the _loader and _hostvars attributes are assigned to
    the instance of VariableManager if they are not present in pickled
    dictionary.
    '''
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager._hostvars = None
    variable_manager._loader = None

    hostvars = HostVars(None, variable_manager, loader)
    hostvars._variable_manager = variable_manager
    hostvars._loader = loader

    state = hostvars.__getstate__()
    new_hostvars = HostVars(None, variable_manager, loader)


# Generated at 2022-06-22 14:38:45.260746
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    inventory = mock.MagicMock()
    inventory.get_host.side_effect = lambda x: mock.MagicMock()
    inventory.hosts = [('server1', 'server2')]

    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)

    assert list(hostvars) == ['server1', 'server2']

# Generated at 2022-06-22 14:38:50.761347
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # load inventory
    current_dir = os.path.dirname(os.path.realpath(__file__))
    inventory_dir = '%s/../../../test/integration/inventory' % current_dir
    inventory_file = '%s/hosts' % inventory_dir
    inventory = InventoryManager(loader=loader, sources=inventory_file)
    variable_manager.set_inventory(inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # hostvars['localhost'] returns a dict
    # whose keys are from inventory
    dict_result = host

# Generated at 2022-06-22 14:38:58.733514
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    '''
    Verify that HostVars.raw_get returns a value unchanged if not a dict or AnsibleUndefined.
    '''
    class FakeVariableManager(object):

        def __init__(self):
            self._hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
            self._hostvars.set_variable_manager(self)

        def set_host_variable(self, host, varname, value):
            None

        def get_vars(self, host=None, include_hostvars=True, include_delegate_to=True):
            '''Fake for get_vars, for use by HostVars.'''
            if host is None:
                return "raw_get_test"
            return self._hostvars.raw_get(host)

    fake_

# Generated at 2022-06-22 14:39:10.240853
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    hostvars = HostVars(InventoryManager(DataLoader()), VariableManager(), DataLoader())

    # Attribute _hostvars of VariableManager initialized during HostVars
    # initialization always references HostVar instance itself.
    assert hostvars is hostvars._variable_manager._hostvars

    # Pickling and unpickling of Hostvar instance. It will also pickle
    # VariableManager.
    hostvars_pickled = pickle.dumps(hostvars)
    hostvars_unpickled = pickle.loads(hostvars_pickled)

    # Check if

# Generated at 2022-06-22 14:39:21.054198
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, host_list='/dev/null')
    play = Play().load({'hosts': 'all', 'gather_facts': 'no'}, variable_manager=variable_manager, loader=loader)

    hostvars = HostVars(inventory, variable_manager, loader)

    # Method __getstate__ of VariableManager returns a list
    # of attributes to pickle, _loader and _hostvars are not
    # included by design
    state = hostvars._variable_manager.__getstate__()
    assert host

# Generated at 2022-06-22 14:39:30.849362
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from collections import MutableMapping
    from ansible.variables import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    inventory.add_host(host)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert isinstance(hostvars, MutableMapping)
    assert hostvars.raw_get('localhost') == {}
   

# Generated at 2022-06-22 14:39:34.344490
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    hv = HostVars(inventory=InventoryManager('localhost'),
                  variable_manager=VariableManager(),
                  loader=None)
    assert repr(hv) == repr({'localhost': {}})

# Generated at 2022-06-22 14:39:44.552391
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    myvars = {}
    myvars['foo'] = 'bar'

    # Setup Inventory and variables
    inventory = MockInventory()
    inventory.hosts['host1'] = MockHost("host1")
    inventory.hosts['host2'] = MockHost("host2")
    inventory.hosts['host3'] = MockHost("host3")
    inventory.hosts['host1'].vars = myvars
    inventory.hosts['host2'].vars = myvars
    inventory.hosts['host3'].vars = myvars

    # Setup VariableManager
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-22 14:40:35.236152
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    h = HostVars(
        inventory=InventoryManager(loader=None, sources='foo'),
        variable_manager=VariableManager(loader=None),
        loader=None
    )
    assert isinstance(h, HostVars)
    assert h.__iter__() is not None
    assert hasattr(h.__iter__(), '__iter__')


# Generated at 2022-06-22 14:40:45.026915
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_text

    class MockLoader(object):
        ''' A simple mock object to mock the ansible.parsing.dataloader.DataLoader object.'''

        def __init__(self):
            self.base_path = None

    class TestHostVars(unittest.TestCase):

        def setUp(self):
            self.loader = MockLoader()

# Generated at 2022-06-22 14:40:55.327442
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import ansible.inventory.host
    import ansible.vars.manager
    class MockVarsManager:
        def get_vars(self, *args, **kwargs):
            return {'_ansible_managed': 'ansible managed'}
    class MockInventory:
        def __init__(self):
            self.hosts = ['hosta', 'hostb', 'hostc']
    class MockHostA:
        def get_name(self):
            return 'hosta'
    mock_loader = MockVarsManager()
    mock_inventory = MockInventory()
    mock_vars_manager = MockVarsManager()

# Generated at 2022-06-22 14:41:01.471022
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    vars = dict(
        foo='{{ foo }}',
        bar='{{ bar }}')
    vars_vars = HostVarsVars(vars, None)
    assert vars_vars['foo'] is vars['foo']
    assert vars_vars['bar'] is vars['bar']

# Generated at 2022-06-22 14:41:09.200994
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.vars import VariableManager
    from ansible import inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory_manager = inventory.manager.InventoryManager(loader=loader, sources=["localhost,"])

    hostvars = HostVars(inventory_manager, VariableManager(loader=loader), loader=loader)
    hostvars['localhost'] = {'foo':'bar'}

    for host in hostvars:
        if host.name != 'localhost':
            raise AssertionError("HostVars did not return localhost as the only host in the inventory")

    # hostvars should include localhost but not some_other_host

# Generated at 2022-06-22 14:41:21.261116
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-22 14:41:28.913629
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variables = VariableManager(loader=loader, inventory=inventory, version_info=dict(ansible_version=2.2))
    hostvars = HostVarsVars(vars(inventory.hosts), loader)
    assert hostvars.raw_get('127.0.0.1') == {}

# Generated at 2022-06-22 14:41:36.665644
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = None
    # Empty variables
    variables = {}
    hvv = HostVarsVars(variables, loader)
    assert(len(hvv) == 0)
    assert(len(list(hvv.__iter__())) == 0)
    # One item variables
    variables = {'foo': 'bar'}
    hvv = HostVarsVars(variables, loader)
    assert(len(hvv) == 1)
    assert(list(hvv.__iter__()) == ['foo'])
    # More than one item variables
    variables = {'foo': 'bar', 'baz': 'qux'}
    hvv = HostVarsVars(variables, loader)
    assert(len(hvv) == 2)
    # The order of items is unspecified

# Generated at 2022-06-22 14:41:44.593365
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(
            loader=None,
            sources='localhost,',
    )
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)
    hostvars.raw_get('localhost')

    # The next line should not raise an exception.
    # Either it will iterate at least once or raise a StopIteration exception.
    next(iter(hostvars))


# Generated at 2022-06-22 14:41:50.878815
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    inventory_manager = InventoryManager(loader=DataLoader())
    inventory_manager.hosts = inventory_manager.inventory._hosts_cache

    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)
    loader = DataLoader()
    variable_hostvars = HostVars(inventory_manager, variable_manager, loader)

    variable_hostvars._variable_manager._loader = None
    variable_hostvars._variable_manager._hostvars = None

    variable_hostvars.set_variable_manager(variable_manager)

    assert variable_hostvars._variable_manager._loader == loader
    assert variable_hostvars._variable

# Generated at 2022-06-22 14:42:38.435161
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from .inventory import Inventory
    from .vars_cache import VarsCache
    from .variable_manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class VariableManagerStub(VariableManager):
        def __init__(self, *args, **kwargs):
            super(VariableManagerStub, self).__init__(*args, **kwargs)
            self._hostvars = HostVars(self._inventory, self, self._loader)

    def get_invocations_of_method(method):
        return [call_args for call_args in method.call_args_list if call_args[0][0] == 'hostvars']

    hostvars = HostVars(Inventory(loader=DataLoader()), VariableManagerStub(), DataLoader())
    vars_cache = Vars