

# Generated at 2022-06-22 14:33:00.381535
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    class FakeLoader:
        def __init__(self):
            self._templar = None

    class FakeTemplar:
        pass

    class FakeVariableManager:
        pass

    class FakeInventory:
        def __init__(self):
            self.hosts = [
                FakeHost('foo'),
                FakeHost('bar'),
            ]

    class FakeHost:
        def __init__(self, name):
            self.name = name

    class FakeHostVarsVars:
        def __init__(self, variables, loader=None, templar=None):
            self._vars = variables
            self._loader = loader
            self._templar = templar

        def __contains__(self, var):
            return (var in self._vars)


# Generated at 2022-06-22 14:33:11.709222
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    import os

    try:
        tree = InventoryManager(loader=C.DEFAULT_LOADER, sources=['localhost,'])
    except AnsibleError as e:
        print(e)
        sys.exit(1)

    hv = HostVars(tree, VariableManager(), C.DEFAULT_LOADER)

    h1 = Host(name='h1')
    h2 = Host(name='h2')
    h3 = Host(name='h3')

    hv.set_host_variable(h1, 'x', 1)
    hv

# Generated at 2022-06-22 14:33:21.407070
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping

    class DummyLoader(object):
        pass

    class DummyInventory(Inventory):
        pass

    class DummyVariableManager(VariableManager):
        def __init__(self):
            super(DummyVariableManager, self).__init__()
            self._vars = MutableMapping()
            self._hosts = MutableMapping()
            self._host_cache = MutableMapping()
            self._hostvars = None
            self._loader = None

    inventory = DummyInventory()
    loader = DummyLoader()
    variable_manager = DummyVariableManager()

# Generated at 2022-06-22 14:33:24.674033
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    vars = {}
    vars['x'] = 9
    vars['y'] = 8
    hostvars = HostVarsVars(vars, None)
    assert hostvars.__repr__() == "{'x': 9, 'y': 8}"


# Generated at 2022-06-22 14:33:30.902149
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.playbook.play_context import PlayContext

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    c_static_vars = [
            'ansible_version',
            'ansible_play_hosts',
            'ansible_dependent_role_names',
            'ansible_play_role_names',
            'ansible_role_names',
            'inventory_hostname',
            'inventory_hostname_short',
            'inventory_file',
            'inventory_dir',
            'groups',
            'group_names',
            'omit',
            'playbook_dir',
            'play_hosts',
            'role_names',
            'ungrouped'
        ]

# Generated at 2022-06-22 14:33:37.188541
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from copy import deepcopy

    # prepare test data
    host_vars = HostVars(inventory=None, variable_manager=None, loader=None)
    host_vars._find_host = lambda _: object()
    host_vars._find_host("host1")
    host_vars._find_host("host2")
    expected = deepcopy(host_vars)

    # test
    actual = list(host_vars)

    # verify
    assert actual == expected


# Generated at 2022-06-22 14:33:43.916146
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    first_host = MockHost('test_host_1')
    second_host = MockHost('test_host_2')
    hosts = [first_host, second_host]
    inventory = MockInventory(hosts)
    variable_manager = MockVariableManager(inventory)
    variable_manager.add_host_variable(first_host, 'foo', 'bar')
    variable_manager.add_host_variable(first_host, 'baz', 'qux')
    variable_manager.add_host_variable(second_host, 'foo', 'bar')
    variable_manager.add_host_variable(second_host, 'baz', 'qux')

    # Test HostVars
    hostvars = HostVars(inventory, variable_manager, None)
    assert hostvars.raw_get('not_existing_host')

# Generated at 2022-06-22 14:33:52.504759
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    import ansible.constants as C
    import ansible.plugins.loader as loader

    inventory_manager = InventoryManager(loader=loader, sources=[C.DEFAULT_HOST_LIST])
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)
    variables = variable_manager.get_vars(host=inventory_manager.get_host(name='localhost'), include_hostvars=False)
    hostvars = HostVars(inventory=inventory_manager, variable_manager=variable_manager, loader=loader)

    assert hostvars['localhost'] == variables

# Generated at 2022-06-22 14:34:04.607581
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    """
    >>> inventory = ansible.inventory.Inventory(host_list=[])
    >>> v2_variables = ansible.vars.VariableManager(loader=DictDataLoader(dict()), inventory=inventory)
    >>> vars_cache = ansible.vars.HostVars(inventory, v2_variables, DictDataLoader(dict()))
    >>> vars_cache._variable_manager.set_host_variable('mock_host', 'xyz', ['foo', 'bar'])
    >>> hostvars = ansible.vars.HostVarsVars(vars_cache._variable_manager.get_vars(host='mock_host'), DictDataLoader(dict()))
    >>> hostvars['xyz'] == ['foo', 'bar']
    True
    """
    pass


# Generated at 2022-06-22 14:34:15.079487
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    test_data = dict(one=1,
                     two=dict(three='{{four}}',
                              four='{{five}}',
                              five='{{six}}'),
                     six='{{seven}}',
                     seven='seven')

    hostvars = HostVars(test_data, loader=None)
    assert hostvars['one'] == 1
    assert hostvars['two']['three'] == 'seven'
    assert hostvars['two']['four'] == 'seven'
    assert hostvars['two']['five'] == 'seven'
    assert hostvars['six'] == 'seven'
    assert hostvars['seven'] == 'seven'


# Generated at 2022-06-22 14:34:26.828545
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import sys
    import pickle

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inv = InventoryManager(inventory=None, loader=None, sources=["tests/inventory"])
    variable_manager = VariableManager(loader=None, inventory=inv)

    hostvars = HostVars(inventory=inv, variable_manager=variable_manager, loader=None)

    # For Python 3
    if sys.version_info[0] == 3:
        assert list(hostvars) == ['jumper', 'localhost', 'example', 'mars', 'alpha']

    # For Python 2
    elif sys.version_info[0] == 2:
        assert list(hostvars) == [u'jumper', u'localhost', u'example', u'mars', u'alpha']

# Generated at 2022-06-22 14:34:36.887125
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs()

    # Create an empty inventory
    inv = InventoryManager(
        loader=None, sources=''
    )

    # Create empty groups
    groups = dict()

    # Create empty inventory hosts
    hosts = dict()

    # Create empty inventory variables
    vars = dict()

    # Create empty inventory group variables
    group_vars = dict()

    # Create empty inventory host variables
    host_vars = dict()

    # Create group from group name

# Generated at 2022-06-22 14:34:45.873480
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())

    variable_manager.set_host_variable(host=inventory.get_host('127.0.0.1'), varname='foo', value='bar')
    variable_manager.set_host_variable(host=inventory.get_host('127.0.0.1'), varname='bar', value='foo')
    variable_manager.set_host_variable

# Generated at 2022-06-22 14:34:55.074824
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inventory = InventoryManager(loader=loader)

    group = Group('foo')
    group.add_host(Host('first', variables={'foo': 'bar'}))
    group.add_host(Host('second', variables={'foo': 'baz'}))

    inventory.add_group(group)

    assert repr({'first': {'foo': 'bar'}, 'second': {'foo': 'baz'}}) == repr(HostVars(inventory, None, loader))

# Generated at 2022-06-22 14:35:00.688902
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # We need to create a class that behaves like a dict, but that returns
    # a copy of its content when __repr__ is called.
    class Dict(dict):
        def __init__(self, *args, **kwargs):
            super(Dict, self).__init__(*args, **kwargs)

        def __repr__(self):
            return repr(self.copy())

    # Create a dict that contains all the needed attributes
    # and create the instance of HostVars from it.
    tmp = Dict()
    tmp.hosts = ['localhost']
    tmp._variable_manager = Dict()
    tmp._loader = Dict()
    hostvars = HostVars(tmp, tmp._variable_manager, tmp._loader)
    # Check that the repr is what we expect

# Generated at 2022-06-22 14:35:11.874035
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    a = dict(a=1)
    b = dict(b=2)
    c = dict(c=3)
    d = dict(d=4)
    e = dict(e=5)
    assert HostVars(None, None, None) == {}
    assert HostVars(None, None, None) != dict()
    assert HostVars(None, None, None) != dict(a=a)
    assert HostVars(None, None, None) == dict(a=a.copy())
    assert HostVars(None, None, None) != dict(a=a.copy(), b=b.copy())
    assert HostVars(None, None, None) == dict(a=a.copy(), b=b.copy(), c=c.copy(), d=d.copy(), e=e.copy())

#

# Generated at 2022-06-22 14:35:20.366686
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Define variables.
    inventory_hostname = 'example.com'
    inventory_hostname_short = 'example'
    foo = 'bar'
    my_hostvars = {
        'inventory_hostname': inventory_hostname,
        'inventory_hostname_short': inventory_hostname_short,
        'foo': foo,
    }

    # Create HostVars object.
    hvv = HostVarsVars(my_hostvars, DataLoader())

    # Test HostVars.__repr__().

# Generated at 2022-06-22 14:35:29.397857
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():

    # Set up test data with a HostVars containing two hosts: one with
    # a variable, one without.
    # A real HostVars object would contain more hosts, but testing them all
    # would be redundant, because they should behave exactly the same as the
    # two test hosts.
    hosts = ['host1', 'host2']
    vars_cache = {
        'host1': {
            'var': 'value',
        },
        'host2': {},
    }
    class DummyInventory:
        def __init__(self):
            self.hosts = []
            for host in hosts:
                self.hosts.append(DummyHost(host))
            self.hosts.append(DummyHost('localhost'))

# Generated at 2022-06-22 14:35:38.918050
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle

    inventory_parser = MagicMock()
    inventory_parser._hosts = [1, 2, 3]

    variable_manager = MagicMock()
    variable_manager._hostvars = None
    variable_manager._loader = None

    loader = MagicMock()
    loader.get_basedir = lambda x: None

    host_vars = HostVars(inventory_parser, variable_manager, loader)

    host_vars.set_variable_manager(variable_manager)
    host_vars.set_inventory(inventory_parser)

    host_vars_serialized = pickle.dumps(host_vars)

    host_vars_deserialized = pickle.loads(host_vars_serialized)

    assert host_vars._loader is host_vars_deserialized._loader

# Generated at 2022-06-22 14:35:49.035824
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import collections
    import unittest
    import sys

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Python 2.6 does not support TestCase.assertCountEqual
    # Python 2.7 does not support TestCase.assertRegex
    if sys.version_info < (2, 7):
        from ansible.utils.unit_tests import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableMapping

    ##################
    # AnsibleUndefined
    ##################


# Generated at 2022-06-22 14:36:02.630419
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])

    hostvars = HostVars(inventory=inventory, variable_manager=VariableManager(loader=None, inventory=inventory), loader=None)

    hostvars._inventory.hosts = [ 'host1', 'host2', 'host3' ]

    # Unit test for method __iter__ of class HostVars
    assert [host for host in hostvars] == hostvars._inventory.hosts == [ 'host1', 'host2', 'host3' ]



# Generated at 2022-06-22 14:36:11.804302
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['examples/hosts'])

    # By default group_names does not have a value
    def _check_group_names(host_vars):
        for host in host_vars:
            assert 'group_names' not in host_vars[host]

    host_vars = HostVars(inventory, None, loader)
    _check_group_names(host_vars)

    # Add a value to group_names
    host_vars['test']
    host_vars['test']['group_names'] = ['all']
    # This change affects the whole HostVars instance
    _check_group_

# Generated at 2022-06-22 14:36:16.822262
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = None
    variables = {'a': 1, 'b': 2, 'c': 3}
    hostvars = HostVarsVars(variables, loader)
    assert hostvars.__iter__() == ['a', 'b', 'c']
    for var in hostvars:
        assert var in variables.keys()

# Generated at 2022-06-22 14:36:28.715549
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class AnsibleOptions(object):
        def __init__(self, connection, remote_user, private_key_file, host_key_checking, module_name, module_path, timeout, forks, ask_pass, become_method, become_user, become_ask_pass, check, diff, syntax, vault_password_file, inventory):
            self.connection = connection
            self.remote_user = remote_user
            self.private_key_file = private_key_file
            self.host_key_checking = host_key_checking
            self.module_name = module_name
            self.module_path = module

# Generated at 2022-06-22 14:36:35.925571
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from configparser import ConfigParser
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars, HostVarsVars

    loader = DataLoader()
    config = ConfigParser()
    config.read("./test_files/hosts.ini")

    inventory = InventoryManager(loader=loader, sources="./test_files/hosts.ini")


# Generated at 2022-06-22 14:36:44.841832
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import mock
    import pprint

    test_inv = mock.MagicMock()
    test_inv.hosts = ['alpha', 'bravo', 'charlie']

    test_var_man = mock.MagicMock()
    test_var_man.get_vars.return_value = {}

    expected = ['alpha', 'bravo', 'charlie']

    hv = HostVars(test_inv, test_var_man, None)

    results = []
    for host in hv:
        results.append(host)

    assert expected == results, pprint.pformat(results)



# Generated at 2022-06-22 14:36:50.841519
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    h = HostVars({}, variable_manager=None, loader=None)

    assert h.raw_get("foo") == AnsibleUndefined(name="hostvars['foo']")

    h._inventory = Inventory(hosts={"foo": "foo"})
    assert isinstance(h.raw_get("foo"), dict)
    assert h.raw_get("foo") == {"foo": "foo"}

    h._variable_manager = VariableManager()
    h._variable_manager._hostvars = h

    h._variable_manager.set_host_variable(h._find_host("foo"), "bar", "baz")
    assert h.raw_get("foo") == {"bar": "baz", "foo": "foo"}

# Generated at 2022-06-22 14:37:02.193664
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    import os
    import sys
    import shutil
    import tempfile

    global_vars = dict()
    loader = None
    inventory = None

    global test_result
    test_result = 0

    # Create temp directory to hold test fixtures
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-22 14:37:04.913171
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    my_hostvars = HostVars(None, None, None)
    assert isinstance(my_hostvars, HostVars)
    assert my_hostvars.__iter__()


# Generated at 2022-06-22 14:37:09.608654
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    inventory = Inventory("localhost")
    variable_manager = VariableManager()

    loader = None
    hostvars = HostVars(inventory, variable_manager, loader)

    # Ensure that hostvars is iterable
    it = iter(hostvars)
    assert next(it)

# Generated at 2022-06-22 14:37:26.355073
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Create HostVars object.
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)

    # Create new state.
    new_state = dict()

    # Pickle HostVars object.
    pickled_hostvars = pickle.dumps(hostvars)

    # Assign new state to object.
    hostvars.__setstate__(new_state)

    # Unpickle HostVars object.
    unpickled_hostvars = pickle.loads(pickled_hostvars)

    # Check values of _loader and _hostvars.
    assert unpickled_hostvars._variable_manager._loader is None
    assert unpickled_hostvars._variable_manager._hostvars is unpickled_hostvars

# Generated at 2022-06-22 14:37:33.011111
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.plugins.loader import module_loader
    from ansible.plugins.inventory import InventoryModule

    inventory = InventoryModule('', 'localhost,')
    variable_manager = module_loader.variable_manager_class('', inventory=inventory)

    hv = HostVars(inventory, variable_manager, module_loader)

    # Test that variables are expanded
    assert hv['localhost']['inventory_file'] == hv['localhost']['inventory_dir'] + '/localhost,'
    assert hv['localhost']['inventory_hostname'] == 'localhost'

# Generated at 2022-06-22 14:37:45.296136
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    my_hosts = ["host1", "host3", "host3"]
    my_inventory = Inventory(loader=DataLoader(), host_list=my_hosts)
    my_variable_manager = VariableManager(loader=DataLoader(), inventory=my_inventory)
    my_loader = DataLoader()
    my_host_vars = HostVars(my_inventory, my_variable_manager, my_loader)

    # test HostVarsVars object iterating all hostvars
    hostvars_vars = HostVarsVars(my_host_vars, my_loader)
    for key in hostvars_vars:
        mydict = hostvars_v

# Generated at 2022-06-22 14:37:51.770274
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_options_vars

    # set up required objects
    loader = DataLoader()
    options_vars = load_options_vars(loader=loader, options=dict(connection='local'))
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-22 14:37:59.995863
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # pylint: disable=unused-variable
    inventory = _get_fake_inventory()
    loader = _get_fake_loader()
    variable_manager = _get_fake_variable_manager(loader)
    hostvars = HostVars(inventory, variable_manager, loader)
    # pylint: enable=unused-variable

    result = hostvars['fake_host']
    assert isinstance(result, HostVarsVars)
    assert result['foo'] == 'bar'
    assert result['test_facts']['foo'] == 'bar'


# Generated at 2022-06-22 14:38:09.147375
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    hosts = ['localhost']
    inventory = Inventory(loader=None, sources=hosts)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hv = HostVars(inventory=inventory, loader=None, variable_manager=variable_manager)
    localhost_vars = hv.raw_get('localhost')

    assert localhost_vars['inventory_hostname'] == 'localhost'
    assert localhost_vars['inventory_hostname_short'] == 'localhost'
    assert 'ansible_python_interpreter' in localhost_vars
    assert 'ansible_python_version' in localhost_vars

# Generated at 2022-06-22 14:38:21.026982
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # Build inventory
    inventory = InventoryManager(loader=None, sources='localhost,')

    # Build variables
    variables = VariableManager(loader=None, inventory=inventory)

    # Build hostvars
    hostvars = HostVars(inventory, variables, loader=None)
    hostvars.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars.set_host_facts(inventory.get_host('localhost'), {'ansible_facts': {'foo': 'baz'}})

    # Get HostVars object attributes to check relationship between
    # _variable_manager and _loader
    hostvars_variable_manager = hostvars._variable_manager
    hostvars_variable_manager_loader = hostvars_variable_manager._loader
    hostvars_variable_manager_

# Generated at 2022-06-22 14:38:29.924395
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # We do not need a real inventory, since we mock the data from it
    inventory = InventoryManager(None)
    inventory.hosts = ['ansible-tests', 'non_ansible_tests']
    context = PlayContext()

    import jinja2
    loader = jinja2.DictLoader({
        'foo': '{{ bar }}, {{ baz }}',
        'bar': '{{ ansible_play_hosts[0] }}',
        'baz': '{{ ansible_play_hosts[-1] }}'
    })

    varman = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-22 14:38:38.122633
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    class TestVariableManager(object):
        def __init__(self):
            self._vars_cache = {}
            self._nonpersistent_fact_cache = {}
            self._fact_cache = {}
            self._vars_plugins = []
            self._hostvars = None
            self._loader = None

        def set_host_variable(self, host, varname, value):
            self._vars_cache.setdefault(host, {})[varname] = value

        def set_nonpersistent_facts(self, host, facts):
            self._nonpersistent_fact_cache[host] = facts

        def set_host_facts(self, host, facts):
            self._fact_cache[host] = facts

    class TestInventory(object):
        def __init__(self):
            self.hosts

# Generated at 2022-06-22 14:38:47.630053
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = None
    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars.raw_get('host_localhost') == {}

    variable_manager.set_host_variable('host_localhost', 'my_var', 'value')
    assert hostvars.raw_get('host_localhost') == {'my_var': 'value'}

    variable_manager.set_host_variable('host_localhost', 'my_var', {'subvar': 'subvalue'})
    assert hostvars.raw_get('host_localhost') == {'my_var': {'subvar': 'subvalue'}}


#

# Generated at 2022-06-22 14:39:08.680163
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hostvars = HostVars({}, {}, {})
    assert isinstance(hostvars.raw_get('foo'), AnsibleUndefined)

# Generated at 2022-06-22 14:39:20.861791
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    data_structure = {}
    hostvars = HostVars(data_structure, None, None)
    assert len(hostvars) == 0

    for host in hostvars:
        assert False

    data_structure['localhost'] = {'foo': 'bar'}
    hostvars = HostVars(data_structure, None, None)
    assert len(hostvars) == 1

    for host in hostvars:
        assert host == 'localhost'
        break
    else:
        assert False

    data_structure['host1'] = {'foo': 'bar'}
    hostvars = HostVars(data_structure, None, None)
    assert len(hostvars) == 2


# Generated at 2022-06-22 14:39:23.295062
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    assert HostVars.__repr__(HostVars(None, None, None)) == '{}'

# Generated at 2022-06-22 14:39:31.746476
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes

    # Remove "foo" host so the test can run
    def get_hosts_from_cache(self):
        hosts = super(InventoryManager, self).get_hosts_from_cache()
        hosts = [host for host in hosts if host.name != 'foo']
        return hosts

    InventoryManager.get_hosts_from_cache = get_hosts_from_cache

    # Create a temporary inventory file

# Generated at 2022-06-22 14:39:34.141372
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    loader = None
    variables = {'var_1': 'value_1'}
    hostvars = HostVarsVars(variables, loader)
    assert hostvars.__iter__() == iter(variables)

# Generated at 2022-06-22 14:39:41.235039
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = Inventory(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variables = HostVars(inventory, variable_manager, loader)

    state = {
        '_loader': loader,
        '_variable_manager': variable_manager,
    }

    variables.__setstate__(state)

    assert variable_manager._loader == loader
    assert variable_manager._hostvars == variables

# Generated at 2022-06-22 14:39:53.909556
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.vars.manager import VariableManager

    hostvars = HostVars(None, VariableManager(), None)
    assert hostvars._variable_manager._loader is None
    assert hostvars._variable_manager._hostvars is None

    # _loader and _hostvars must be set after unpickling
    hostvars_dump = pickle.dumps(hostvars)
    hostvars = pickle.loads(hostvars_dump)
    assert hostvars._variable_manager._loader is not None
    assert hostvars._variable_manager._hostvars is not None

    # Changing _loader and _hostvars must not change values of dictionaries
    hostvars_dump = pickle.dumps(hostvars)
    hostvars._variable_manager._loader = None
    hostvars._variable

# Generated at 2022-06-22 14:39:59.730360
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    '''
    Test __iter__ method of class HostVarsVars
    '''
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from io import BytesIO

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=BytesIO('''
    127.0.0.1 ansible_connection=local
    '''))
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars_vars = hostvars['127.0.0.1']

    # Test1: test default case

# Generated at 2022-06-22 14:40:08.646779
# Unit test for method __getitem__ of class HostVarsVars
def test_HostVarsVars___getitem__():
    variables = {
        'var1': 1,
        'var2': 2,
        'var3': 3
    }
    hostvars = HostVarsVars(variables, None)
    for key, value in variables.items():
        assert hostvars[key] == value, 'Expected {0}, got {1}'.format(value, hostvars[key])

    try:
        hostvars['var4']
    except KeyError as e:
        assert str(e) == 'var4', 'Expected var4, got {0}'.format(str(e))

# Generated at 2022-06-22 14:40:14.465834
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=["tests/test_hostvars/hosts"])
    assert inventory.hosts is not None

    # Use non-empty inventory to check if __repr__ does not fail
    hostvars = HostVars(inventory, 'variable_manager', 'loader')
    hostvars.__repr__()

# Generated at 2022-06-22 14:41:07.633651
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.utils.vars import merge_hash
    from ansible.vars.hostvars import HostVars

    # Configuration variables
    host_name = 'localhost'
    host_name_other = 'localhost_other'
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())

# Generated at 2022-06-22 14:41:16.753489
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory, Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    inventory.add_host(Host("foo"))
    hv = HostVars(inventory, variable_manager, loader)

    assert repr(hv) == "{'foo': {}}"


# Generated at 2022-06-22 14:41:26.781947
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory_manager = InventoryManager(loader=C.DEFAULT_LOADER, sources=['localhost,'])
    variable_manager = VariableManager(loader=C.DEFAULT_LOADER, inventory=inventory_manager)
    hostvars = HostVars(inventory_manager, variable_manager, C.DEFAULT_LOADER)

    # test for ansible_os_family
    raw_vars = hostvars.raw_get('localhost')
    assert raw_vars['ansible_os_family'] == 'Debian'

    # test for ansible_local
    local = hostvars['localhost']
    assert 'ansible_local' in local

# Generated at 2022-06-22 14:41:35.350984
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.sentinel import Sentinel

    play = Play.load({
        'hosts': 'all',
        'any_errors_fatal': False,
        'vars': {'foo': 'bar'}
    }, Sentinel(), variable_manager=VariableManager(), loader=DataLoader())

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    hostvars = HostVars(inventory, VariableManager(), DataLoader())

    assert repr(hostvars) == repr({'localhost': {'foo': 'bar'}})

# Generated at 2022-06-22 14:41:41.751448
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Host, Inventory
    host0 = Host('host0')
    host1 = Host('host1')
    inventory = Inventory(host_list=[host0, host1])

    from ansible.vars import VariableManager
    variable_manager = VariableManager()

    hv = HostVars(inventory, variable_manager, loader=None)

    assert len([x for x in hv]) == 2

# Generated at 2022-06-22 14:41:49.268965
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.module_utils.six import PY3
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create an InventoryManager to create an Inventory and DataLoader
    inv_mgr = InventoryManager(loader=DataLoader())
    # Add a TestHost to the Inventory
    inv_mgr.inventory.add_host(Host(name="TestHost"))
    # Create a VariableManager to create a HostVars
    var_mgr = VariableManager(loader=DataLoader(), inventory=inv_mgr.inventory)
    # Create a HostVars

# Generated at 2022-06-22 14:42:00.525095
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    class Inventory:

        def __getitem__(self, item):
            return None

        def get_host(self, item):
            return None

    class VariableManager:

        def __init__(self):
            # In order to pass the isinstance() check below,
            # all attributes need to be set with correct data type.
            self._vars_per_host = dict()
            self._vars_per_group = dict()
            self._hostvars = HostVars(Inventory(), self, None)

        def _add_host_vars_from_inventory(self, host, hostvars):
            pass


# Generated at 2022-06-22 14:42:12.291145
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import mock

    vars_cache = {
        "host1": {
            "key1": "value1",
            "key2": "value2",
        },
        "host2": {
            "key3": "value3",
            "key4": "value4",
        },
    }

    expected = set(vars_cache.keys())

    with mock.patch('ansible.vars.hostvars._VariableManager.get_vars'):
        v = HostVars(None, None, None)

        for key in expected:
            assert key in v

    with mock.patch('ansible.vars.hostvars._VariableManager.get_vars', return_value=vars_cache):
        v = HostVars(None, None, None)

# Generated at 2022-06-22 14:42:24.217402
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with no host
    inventory = InventoryManager('localhost,')
    loader = DataLoader()
    variable_manager = VariableManager()

    hostvars = HostVars(inventory, variable_manager, loader)
    with pytest.raises(AnsibleUndefined):
        hostvars.__getitem__('localhost')

    # Test with host
    inventory = InventoryManager('localhost,')
    loader = DataLoader()
    variable_manager = VariableManager()

    variable_manager.set_host_variable(inventory.get_host('localhost'), 'foo', 'bar')
    hostvars = HostVars(inventory, variable_manager, loader)

# Generated at 2022-06-22 14:42:34.948694
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    INVENTORY_RESULT = dict(
        hosts=dict(
            foo=dict(),
            bar=dict(),
        ),
    )
    VARS_RESULT = dict(
        foo=dict(
            var1='value1',
            var2='value2',
        ),
        bar=dict(
            var1='value1',
            var2='value2',
        ),
    )

    class Controller(object):
        pass
    controller = Controller()
    controller.inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(loader=DataLoader(), inventory=Inventory(loader=DataLoader())))