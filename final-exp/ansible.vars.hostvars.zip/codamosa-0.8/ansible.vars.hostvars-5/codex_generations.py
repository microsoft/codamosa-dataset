

# Generated at 2022-06-22 14:33:01.454883
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/lib/inventory/hostvars.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    hostvars = HostVars(inventory=inv_manager, variable_manager=variable_manager, loader=loader)

    # Method __iter__ should return an iterator over all hosts in inventory
    assert sorted(hostvars) == sorted(inv_manager.hosts)
    # len(hostvars) should return the number of hosts in inventory
    assert len(hostvars) == len(inv_manager.hosts)
    # hostvars[host] should return a dict with variables for

# Generated at 2022-06-22 14:33:06.388290
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=vars_manager, host_list=[])

    hostvars = HostVars(inventory, vars_manager, loader)

    hostvars.set_host_variable('localhost', 'is_localhost', True)
    assert hostvars.raw_get('localhost')['is_localhost'] is True
    assert hostvars['localhost']['is_localhost'] is True

# Generated at 2022-06-22 14:33:16.255341
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    class MockInventory:
        def __init__(self):
            self.hosts = []
            self.get_host = self._get_host

        def _get_host(self, host_name):
            if host_name not in self.hosts:
                self.hosts.append(host_name)
            return self.hosts.index(host_name)

    class MockVariableManager:
        def __init__(self):
            self._loader = None
            self._hostvars = None
            self._vars = {}

        def get_vars(self, host, include_hostvars=True):
            return self._vars.get(host, {})


# Generated at 2022-06-22 14:33:25.665672
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager

    class FakeLoader:
        def __init__(self, variables):
            self._variables = variables

        def get_basedir(self, *args):
            return None

        def get_vars(self, *args, **kwargs):
            return self._variables

    class FakeVariableManager:
        def __init__(self, all_vars):
            self._all_vars = all_vars

        def get_vars(self, host, include_hostvars=True):
            data = self._all_vars.copy()
            hostvars = self._all_vars.get('hostvars', {})
            if include_hostvars:
                data.update(hostvars.get(host.get_name(), {}))
            return data



# Generated at 2022-06-22 14:33:31.447870
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import pytest
    from collections import Mapping

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

    class FakeInventory(object):
        def __init__(self):
            self.hosts = {}

        def get_host(self, host_name):
            return self.hosts.get(host_name)

    class FakeVariableManager(object):
        def __init__(self):
            self.host_vars = {}

        def get_vars(self, host=None, include_hostvars=True):
            if not include_hostvars:
                return self.host_vars.get(host.name, AnsibleUndefined())

# Generated at 2022-06-22 14:33:37.028352
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import pprint

    loader = MockLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    pprint.pprint(list(hostvars))


# Generated at 2022-06-22 14:33:38.500068
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    repr(HostVars(inventory=None, variable_manager=None, loader=None))


# Generated at 2022-06-22 14:33:42.608769
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # Check that a host that is not in the inventory can not be retrieved
    data = hostvars.raw_get('not_exists')
    assert isinstance(data, AnsibleUndefined)

    # Create a dummy host and check that it can be retrieved
    hostvars.set_host_variable(inventory.get_host('localhost'), 'some_var', 'some_value')
    data = hostvars.raw_

# Generated at 2022-06-22 14:33:53.260114
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_dict = {
        'all': {
            'hosts': ['host1', 'host2']
        }
    }
    inv_source = {
        'host1': {
            'ansible_host': 'host1',
        },
        'host2': {
            'ansible_host': 'host2',
        }
    }
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(ansible_some_var='some_var_value')
    variable_manager._fact_cache = inv_source

# Generated at 2022-06-22 14:33:58.509535
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    class FakeInventory(object):
        def get_host(self, host_name):
            if host_name == 'localhost':
                return 'fake_localhost'
            else:
                return None

    class FakeLoader(object):
        def __init__(self, vars):
            self.vars = vars

        def get_basedir(self):
            return '/'

    class FakeVariableManager(object):
        def __init__(self):
            self._cache = {}
            self._vars_cache = {}

        def set_host_variable(self, host, varname, value):
            self._cache[host.name] = self._cache.get(host.name, {})
            self._cache[host.name][varname] = value


# Generated at 2022-06-22 14:34:05.951889
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {'a': 'b', 'c': 'd'}
    loader = AnsibleLoader()

    hv = HostVarsVars(variables, loader)
    out = list(hv)
    assert sorted(out) == ['a', 'c'], out

# Generated at 2022-06-22 14:34:14.993683
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import json

    # Don't use a real loader -- just use a dict
    inp = {
        'foo': 'bar',
        'list': [
            'one',
            'two',
            'three',
        ]
    }

    vars = HostVarsVars(inp, None)

    # Convert to a dict so it is ordered
    out = json.loads(json.dumps(list(vars)))

    assert out == ['foo', 'list'], \
        'unexpected iterator output for HostVarsVars: %s' % out

# Generated at 2022-06-22 14:34:22.109731
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create minimalistic instance of HostVars
    inventory = MockInventory(vars={})
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    loader = DataLoader()
    hostvars = HostVars(inventory, variable_manager, loader)
    variable_manager.set_host_variable(MockHost("host1"), "var1", "value1")

    # Pickle and unpickle hostvars instance
    import pickle
    unpickled_hostvars = pickle.loads(pickle.dumps(hostvars))

    # Verify that instance is correctly unpickled
    assert isinstance(unpickled_hostvars, HostVars)

# Generated at 2022-06-22 14:34:33.213104
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=DataLoader(), sources=None)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    host = Host(name='host1')
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=DataLoader())
    hostvars.set_host_variable(host=host, varname='foo', value='bar')
    assert hostvars[host.name] == {'foo': 'bar'}
    assert hostvars.raw_get(host.name) == {'foo': 'bar'}

    # Test that changes

# Generated at 2022-06-22 14:34:40.663288
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os

    loader = DataLoader()
    inv_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'inventory_manager')
    inventory = InventoryManager(loader=loader, sources=[os.path.join(inv_path, 'hosts')])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host_vars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-22 14:34:47.807158
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    # Create Inventory
    groups = dict(
        group1=dict(
            hosts=['localhost']
        ),
        group2=dict(
            hosts=['host1']
        )
    )
    inventory = Inventory(host_list=[], groups=groups)
    # Create PlayContext and VariableManager
    play_context = PlayContext()
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Test HostVars
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=None)
    expected_hostnames = ['localhost', 'host1']
    assert all([host in expected_hostnames for host in hostvars])


# Generated at 2022-06-22 14:34:57.657218
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestHost:

        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class TestInventory(InventoryManager):

        def __init__(self):
            self.hosts = [TestHost('host1'), TestHost('host2')]

        def get_host(self, hostname):
            if hostname not in [self.hosts[0].name, self.hosts[1].name]:
                return None
            return self.hosts[0] if hostname == self.hosts[0].name else self.hosts[1]


# Generated at 2022-06-22 14:35:08.843544
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    source = dict(
        plugin='auto',
        hosts=dict(
            nyc3=dict(
                ansible_ssh_host='127.0.0.1',
                ansible_ssh_user='michael',
                ansible_ssh_port=2222,
                ansible_connection='local'
            )
        )
    )

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    inventory.parse_sources(sources=source)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-22 14:35:19.183724
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    import os

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    dirname = os.path.dirname(__file__)
    inventory = InventoryManager(loader=DataLoader(), sources=os.path.join(dirname, '../../../test/hosts'))
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory=inventory, loader=DataLoader(), variable_manager=variable_manager)

    assert 'foo' in hostvars
    assert 'bar' in hostvars
    assert 'undefined' not in hostvars

    hostvars_foo = hostvars.raw_get('foo')

# Generated at 2022-06-22 14:35:28.563386
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    inv_data = """
    all:
      children:
        one:
          hosts:
            foo:
            bar:
            baz:
        two:
          hosts:
            qux:
            zot:
        three:
          children:
            four:
              hosts:
                quux:
    """

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=inv_data)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-22 14:35:37.239249
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    inventory = InventoryManager(loader=C.DEFAULT_LOADER, sources='localhost,')
    variable_manager = VariableManager(loader=C.DEFAULT_LOADER, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, C.DEFAULT_LOADER)

    # check that we get an AnsibleUndefined object from an unknown host
    assert isinstance(hostvars.raw_get('bla1bla1'), AnsibleUndefined)

    # check that we get an AnsibleUndefined object from an invalid host
    invalid_host = inventory.get_host('doesnotexist')

# Generated at 2022-06-22 14:35:42.023725
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    variables = {
        'test_var1': 'test1',
        'test_var2': 'test2',
        'test_var3': 'test3',
    }

    hostvarsvars = HostVarsVars(variables, loader=None)

    assert hostvarsvars.__iter__() == variables.__iter__()

# Generated at 2022-06-22 14:35:52.049011
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=[])

    host1 = Host(name="test1")
    host1.set_variable('testvar', 'foo1')
    inventory.add_host(host1)

    host2 = Host(name="test2")
    host2.set_variable('testvar', 'foo2')
    inventory.add_host(host2)

    context = PlayContext()
    context._inventory = inventory
    context._loader = loader
    vm

# Generated at 2022-06-22 14:36:02.542481
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    # Make sure we count only hosts with a specific attribute
    def host_iterator(hosts):
        for host in hosts:
            if host.get_vars().has_key("foo"):
                yield host

    # Override default host iterator method
    import ansible.inventory
    ansible.inventory.BaseHost.all = classmethod(host_iterator)

    # Prepare variables
    import ansible.playbook.vars
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.vars.manager

    host_vars = ansible.playbook.vars.HostVars(None, ansible.vars.manager.VariableManager(), None)

# Generated at 2022-06-22 14:36:11.726231
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.module_utils.six import iteritems
    from ansible.parsing.yaml.objects import AnsibleUnicode

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    loader = DictDataLoader({})

    hostvars = HostVars({'_meta': {'hostvars': {'host_name_a': {'variable_name_a': 'variable_value_a'},
                                                'host_name_b': {'variable_name_b': 'variable_value_b'},
                                                'host_name_c': {'variable_name_c': 'variable_value_c'}}}},
                        variable_manager=None,
                        loader=loader)

    hostvars.set_variable_

# Generated at 2022-06-22 14:36:23.571305
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    # TODO: to be refactored
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.includer import Include
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager, Host

    inventory_manager = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory_manager)

    host = Host(name='localhost')
    inventory_manager.add_host(host)


# Generated at 2022-06-22 14:36:33.453649
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_data = '''
        [group1]
        host1 v1=1
        [group2]
        host2 v2=2
    '''
    var_data = '''
        ---
        host_specific:
           host1:
              hello: world1
           host2:
              hello: world2
        playbook_dir: playbook
        groups:
            - group1
            - group2
    '''
    inventory = InventoryManager(loader=loader, sources=inv_data)

# Generated at 2022-06-22 14:36:44.923906
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from collections import namedtuple
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader=DataLoader()
    inv_plugin = inventory_loader.get('host_list')
    inventory = inv_plugin.get_inventory('localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host_vars=HostVars(inventory,variable_manager,loader)

    #Test if inventory.hosts is empty
    #Test for expected output
    if host_vars.__repr__() != repr({}):
        raise AssertionError("Failed test_HostVars___repr__")

    #Add new host to inventory

# Generated at 2022-06-22 14:36:51.470044
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # The following test code is from method test_vars_from_host()
    # of test/unit/test_templating.py.
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)

    # add a host
    foo_host = inventory.get_host("foo")
    foo_vars = {"ansible_ssh_host": "foo"}
    variable_manager.set_host_variable

# Generated at 2022-06-22 14:37:02.591980
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=DataLoader())


# Generated at 2022-06-22 14:37:22.570444
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import pickle
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.cli.adhoc import AdHocCLI

    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import combine_vars
    from ansible.config.manager import ensure_type
    from ansible.config.manager import var_list_to_dict

    args_adhoc_connection = 'smart'
    args_adhoc_inventory = '/data/dev/qa/project/ansible/inventory/hosts'

# Generated at 2022-06-22 14:37:33.867732
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}
    variable_manager.options_vars['inventory'] = ["tests/inventory"]
    variable_manager.set_inventory(inventory=variable_manager.get_inventory(variable_manager.options_vars))
    hostvars = HostVars(inventory=variable_manager.inventory, variable_manager=variable_manager, loader=None)
    all = hostvars['all']
    assert type(all) == HostVarsVars
    allkeys = set(all.keys())
    assert allkeys == set(['all'])
    localhost = hostvars["localhost"]

# Generated at 2022-06-22 14:37:46.089111
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    mock_loader = DataLoader()
    mock_variable_manager = VariableManager()
    mock_inventory = Inventory(loader=mock_loader, variable_manager=mock_variable_manager)

    mock_inventory.add_host(Host('test.example.com'))

    hostvars = HostVars(mock_inventory, mock_variable_manager, mock_loader)

# Generated at 2022-06-22 14:37:50.628739
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import HostVars
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    hostvars = HostVars(
        inventory=Inventory(loader=DataLoader()),
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader()
    )

    # Test hostvars.raw_get on host that exist
    group = Group(name='group')
    host = Host(name='host', groups=[group])
    host.set_variable('foo', 'bar')
    hostvars.set_inventory(inventory=Inventory(hosts=[host]))
    assert hostvars.raw

# Generated at 2022-06-22 14:38:01.970200
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    hostvars.set_variable_manager(variable_manager=None)

    # undefined variables are returned as is
    assert hostvars[0] is hostvars[1]
    assert hostvars[0] is hostvars[2]
    assert hostvars[0] is hostvars[3]
    assert hostvars[0] is hostvars[4]

    # test for a simple dictionary
    v = dict(a=1, b=2, c=3)
    h = hostvars.__getitem__('localhost')
    h.update(v)
    assert h.raw_get('localhost') == {'a': 1, 'b': 2, 'c': 3}

    # test for the value that

# Generated at 2022-06-22 14:38:06.869448
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    class DummyLoader:
        pass
    hvv = HostVarsVars({'a': AnsibleUnsafeText('b'), 'c': AnsibleUnsafeText('d')}, DummyLoader())
    assert list(iter(hvv)) == ['a', 'c']


# Generated at 2022-06-22 14:38:18.281588
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # math.ceil(1.1) cannot be pickled, fix the problem by monkey patching
    import math
    import types
    math.ceil = types.MethodType(lambda x: int(x) if x == int(x) else int(x + 1), math)
    import pickle
    class MockInventory:
        def __init__(self, hosts):
            self.hosts = hosts
        def get_host(self, host_name):
            if host_name in self.hosts:
                return host_name
            return None
    class MockVariableManager:
        def __init__(self, variables):
            self.variables = variables
            self._hostvars = None
        def get_vars(self, host, include_hostvars):
            return self.variables

# Generated at 2022-06-22 14:38:27.729816
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    h = Host(name='localhost')
    i = Inventory(loader=DataLoader())
    i.add_host(h)

    v = VariableManager(loader=DataLoader(), inventory=i)
    v.set_host_variable(host=h, varname='foo', value='bar')
    hv = HostVars(inventory=i, variable_manager=v, loader=DataLoader())
    assert repr(hv) == "{'localhost': {'foo': u'bar'}}"

# Generated at 2022-06-22 14:38:37.707185
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars['localhost'] == {'ansible_connection': 'local'}

    inventory.hosts['localhost'].set_variable('ansible_connection', 'smart')

    assert hostvars['localhost'] == {'ansible_connection': 'smart'}

    # cached
    inventory.hosts['localhost'].set_variable('ansible_connection', 'ssh')


# Generated at 2022-06-22 14:38:47.446880
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    '''
    Unit test for method raw_get of class HostVars.
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    loader = DataLoader()

    # Create empty HostVars
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    # Assert that hostvars._variable_manager is None
    assert hostvars._variable_manager is None

    # Create empty variable manager
    variable_manager = HostVarsVars({}, loader)
    # Assert variable_manager._hostvars is None
    assert variable_manager._hostvars is None
    # Copy variable manager and assert hostvars._variable_manager is not None
    variable_

# Generated at 2022-06-22 14:39:09.026569
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    # pylint: disable=import-error,unused-import
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    # pylint: enable=import-error,unused-import
    # Here we are testing only the HostVars class, but to test it we need an
    # InventoryManager and a VariableManager. It is not necessary to make their
    # initialization as accurate as possible, but it is necessary to initialize
    # them.
    loader = 'loader'
    inventory_manager = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory_manager, variable_manager, loader)

    # Create a host
    host_name = 'test_host'

# Generated at 2022-06-22 14:39:20.919472
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    '''
    Validate behavior of HostVars_raw_get()

    :kwarg loader: An AnsibleFileLoader object.
    :kwarg inventory: An InventoryManager object.
    :kwarg variable_manager: A VariableManager object.
    :returns: a dict of variables for a given host.
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader,
                                 sources=[])
    variable_manager = VariableManager(loader=loader,
                                       inventory=inventory)

    host1 = inventory.add_host(host='host1')

# Generated at 2022-06-22 14:39:30.729420
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.template.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleVars
    from ansible.vars.hostvars import HostVarsVars

    variables = {'foo': 'bar'}
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variables)
    safe_env = templar._create_tmp_path()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory, cache=False)
    hostvars = Host

# Generated at 2022-06-22 14:39:39.659889
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    print('Running test_HostVars___getitem__')

    # Simple tests
    variables = {'a': 'A', 'b': 'B'}
    hostvars = HostVarsVars(variables, None)
    assert(isinstance(hostvars, Mapping))
    assert(hostvars['a'] == 'A')
    assert(hostvars['b'] == 'B')
    assert('a' in hostvars)
    assert('b' in hostvars)
    assert('c' not in hostvars)
    assert(list(hostvars) == ['a', 'b'])
    assert(len(hostvars) == 2)
    assert(repr(hostvars) == "{'a': 'A', 'b': 'B'}")

    # Test that HostVars is an immutable

# Generated at 2022-06-22 14:39:51.525463
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager   # to avoid circular import
    from ansible.vars.manager import VariableManager        # to avoid circular import
    from ansible.parsing.dataloader import DataLoader       # to avoid circular import


# Generated at 2022-06-22 14:39:59.117973
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    fake_loader = FakeLoader({
        u'host1.example.org': {
            u'hostvars': {
                u'foo': u'bar'
            }
        },
        u'host2.example.org': {
            u'hostvars': {
                u'foo': u'baz'
            }
        }
    })
    inventory = InventoryManager(loader=fake_loader, sources=u'hosts')
    variable_manager = VariableManager(loader=fake_loader, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, fake_loader)


# Generated at 2022-06-22 14:40:11.414421
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Host, Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create mock loader
    def get_basedir(path):
        return '/path/to/basedir'

    mocked_loader = type('Object', (object,), {'get_basedir': get_basedir})()

    # Create mock variables
    mocked_variables = {'Foo': 'Bar', 'Baz': AnsibleVaultEncryptedUnicode('Bar')}

    # Create inventory and host
    mocked_inventory = Inventory(loader=mocked_loader)
    host = Host('localhost')
    mocked_inventory.add_host(host)

    # Create variable manager

# Generated at 2022-06-22 14:40:17.676971
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible import constants as C
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar

    # Test data
    _host1_vars = {'var1': 'host1_var1'}
    host1 = 'host1.example.org'
    _host2_vars = {'var2': 'host2_var2'}

# Generated at 2022-06-22 14:40:28.800336
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = None
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=['hosts'])

    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.add_host('localhost')
    variable_manager.set_host_variable('localhost', 'var1', 'localhost_var1')
    variable_manager.set_host_variable('localhost', 'var2', 'localhost_var2')

    localhost_vars = hostvars.raw_get('localhost')
    assert localhost_vars['var1'] == 'localhost_var1'
    assert localhost_vars['var2'] == 'localhost_var2'

# Generated at 2022-06-22 14:40:39.483556
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class DummyLoader():
        def __init__(self):
            pass

    class DummyJV():
        def __init__(self):
            self.vars = {
                'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd',
            }

    variables = DummyJV()
    loader = DummyLoader()
    hostvars_vars = HostVarsVars(variables.vars, loader)

    iterator = iter(hostvars_vars)
    assert(hasattr(iterator, '__iter__'))
    hostvars_vars_list = list(iterator)
    assert(isinstance(hostvars_vars_list, list))

    for key in hostvars_vars_list:
        assert(key in variables.vars.keys())

# Generated at 2022-06-22 14:41:23.013106
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory import Host, Inventory
    from ansible.vars.manager import VariableManager

    host_1 = Host('host_1')
    host_2 = Host('host_2')
    inventory = Inventory([host_1, host_2])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = None
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    hostvars.set_variable_manager(variable_manager=variable_manager)
    hostvars.set_inventory(inventory=inventory)

    # Variable 'var_1' is not defined
    host_1.vars['var_1'] = '{{ var_2 }}'

    # Variable 'var_2' is not defined

# Generated at 2022-06-22 14:41:28.225423
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    import ansible.inventory
    inventory = ansible.inventory.Inventory()

    import ansible.vars.manager
    variable_manager = ansible.vars.manager.VariableManager()

    import ansible.parsing.dataloader
    loader = ansible.parsing.dataloader.DataLoader()

    import ansible.playbook.play
    play = ansible.playbook.play.Play()

    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords={},
        stdout_callback='',
    )

    hostvars_vars = HostVarsVars({}, loader=loader)

# Generated at 2022-06-22 14:41:28.787851
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    pass

# Generated at 2022-06-22 14:41:36.565075
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import sys

    class Inventory(object):
        def __init__(self):
            self.hosts = []

        def get_host(self, name):
            return self.find_host(name)

        def find_host(self, name):
            for host in self.hosts:
                if host.name == name:
                    return host

            return self.localhost

        def get_hosts(self):
            return self.hosts

        def list_hosts(self, pattern="all"):
            hosts = self.get_hosts()

# Generated at 2022-06-22 14:41:46.406775
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    fake_inventory = InventoryManager(loader=loader, sources=[])
    host1 = fake_inventory.add_host('host1')
    fake_inventory.add_group('fake_group')
    fake_inventory.add_group('fake_group2')
    fake_inventory.add_child('fake_group', host1)
    host2 = fake_inventory.add_host('host2')
    fake_inventory.add_child('fake_group2', host2)

    variable_manager = VariableManager(loader=loader, inventory=fake_inventory)
    hostvars = HostVars(fake_inventory, variable_manager, loader)

# Generated at 2022-06-22 14:41:58.806544
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from .inventory import Inventory
    from .playbook.play_context import PlayContext
    from .vars import VariableManager

    class DummyData:
        pass

    loader = DummyData()
    loader.get_basedir = lambda: '.'
    c2 = DummyData()
    c2.loader = loader
    pc = PlayContext()
    c2.get_play_context = lambda: pc
    c2.get_host = lambda x: x
    c2.host_list = [
        'a',
        'b',
        'c'
    ]
    i = Inventory(loader=loader, variable_manager=VariableManager(), host_list=c2.host_list)

    # hostvars is a Proxy to VariableManager.hostvars
    hostvars = i.get_host('a').vars_

# Generated at 2022-06-22 14:42:10.705136
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    from unittest import TestCase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.module_utils.six import iteritems
    from ansible.template import Templar as Templar_module

    ###########################################################################
    # define test data

    # dict of variables, used to populate the variable manager

    vars = dict(
        foo = 'foo',
        bar = 'bar',
        nested = dict(
            baz = 'baz',
        ),
    )

    # dict of groups, used to populate the inventory
    groups

# Generated at 2022-06-22 14:42:18.112687
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    class DummyLoader:
        pass

    variable_manager = VariableManager()
    variable_manager._loader = DummyLoader()

    hostvars = HostVars(InventoryManager(host_list=[]), variable_manager, DummyLoader())

    hostvars.__getstate__()

    variable_manager._loader = None
    variable_manager._hostvars = None

    hostvars.__setstate__(hostvars.__getstate__())

# Generated at 2022-06-22 14:42:30.171247
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    import unittest
    import ansible.inventory

    class AnsibleVariableManager(object):
        def __init__(self):
            self._vars_cache = {}
            self._hostvars = None
            self._loader = None

        def set_host_variable(self, host, varname, value):
            raise NotImplementedError

        def set_nonpersistent_facts(self, host, facts):
            raise NotImplementedError

        def set_host_facts(self, host, facts):
            raise NotImplementedError

        def get_vars(self, host=None, include_hostvars=True):
            if host is not None:
                host_vars = self._vars_cache.get(host)
                if host_vars is None:
                    host_vars = {}
                   

# Generated at 2022-06-22 14:42:38.074790
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager

    class InventoryPlugin(object):
        def __init__(self):
            self.host_vars = dict(host1=dict(var1=1, var2=2),
                                  host2=dict(var1=2, var2=1))

        def get_hosts(self, pattern=None):
            if pattern is None:
                pattern = "all"
            output = []
            for host in self.host_vars:
                if isinstance(pattern, (list, tuple, set)):
                    if host in pattern:
                        output.append(host)
                elif isinstance(pattern, basestring):
                    if isinstance(host, basestring):
                        if pattern in host:
                            output.append(host)