

# Generated at 2022-06-22 14:32:57.778139
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    vars = {'a': 1, 'b': 2}
    hvv = HostVarsVars(vars, None)
    keys = set(hvv)
    assert keys == set('ab')
    assert list(iter(hvv)) == ['a', 'b']

# Generated at 2022-06-22 14:33:05.216817
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    variable_manager.set_inventory(inventory)
    variable_manager.set_loader(loader)
    variable_manager.set_play_context(play_context)
    hostvars = HostVars(inventory, variable_manager, loader)

    inventory.add_host(host='foo1')
    inventory.add_host(host='foo2')

# Generated at 2022-06-22 14:33:10.530544
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    class Inventory():
        def get_host(self, host_name):
            return host_name
    class VariableManager():
        def get_vars(self, host, include_hostvars):
            return host
    hostvars = HostVars(Inventory(), VariableManager(), None)
    assert hostvars.raw_get('test_host') == 'test_host'

# Generated at 2022-06-22 14:33:20.845053
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestHostVarsVars(unittest.TestCase):

        def test___iter__(self):
            hvv = HostVarsVars(dict(a=1, b=2, c=3), None)
            self.assertEqual(list(iter(hvv)), ['a', 'b', 'c'])

    with patch.dict(globals(), {'unittest': unittest}):
        with patch('ansible.compat.tests.mock.patch'):
            with patch('ansible.compat.tests.mock.MagicMock'):
                with patch('ansible.template.Templar'):
                    unittest.main()

# Generated at 2022-06-22 14:33:28.673624
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, loader=None)

    # For example, this state is created in function serialize_attrs
    # of class TaskExecutor.
    state = {
        '_inventory': inventory,
        '_loader': 'loader',
        '_variable_manager': variable_manager
    }

    hostvars.__setstate__(state)

    loader = hostvars._variable_manager._loader
    hostvars_ = hostvars._variable_manager._hostvars

    assert loader == 'loader'
    assert hostvars_ is hostvars

# Generated at 2022-06-22 14:33:33.098476
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class DummyLoader(object):
        def __init__(self):
            pass
    dummy_loader = DummyLoader()
    hvv = HostVarsVars({'a': 1, 'b': 2}, loader=dummy_loader)
    assert (set(hvv) == set(['a', 'b']))


# Generated at 2022-06-22 14:33:38.675720
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # TODO: skip this test if python is older than 2.7
    assert repr(hostvars) == repr({'localhost': {}})

# Generated at 2022-06-22 14:33:44.940557
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    inventory = InventoryManager(loader=loader, sources='localhost,')
    inventory.add_host('localhost')
    inventory.set_variable('localhost', 'var1', 'value1')
    inventory.set_variable('localhost', 'var2', 'value2')
    inventory.set_variable('localhost', 'var3', 'value3')

    hostvars = HostVars(inventory, variable_manager, loader)


# Generated at 2022-06-22 14:33:52.504559
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    class FakeTemplateLoader:
        pass

    class FakeVars:
        pass

    fake_vars = FakeVars()
    fake_vars.foo = "bar"
    fake_vars.bar = "foo"
    fake_vars.foobar = "foobar"
    fake_vars.barfoo = "barfoo"

    hostvarsvars = HostVarsVars(fake_vars, FakeTemplateLoader())

    for var in hostvarsvars:
        assert(var in fake_vars.__dict__.keys())

# Generated at 2022-06-22 14:34:04.646020
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vault_loader
    from ansible.utils.vars import load_extra_vars

    vl = VaultLib(password_file='blah')
    loader = vault_loader.VaultAwareFileLoader(
      vault_password=vl.get_password(None, None),
      loader_class=vault_loader.AnsibleLoader
    )

    path = 'tests/test_inventories/inventory_with_vault'
    inventory = InventoryManager(loader, sources=path)
    inventory._parse_inventory(inventory.hosts, inventory.groups)


# Generated at 2022-06-22 14:34:18.282770
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    inventory = FakeInventory()
    inventory.hosts = "127.0.0.1"
    host = Host(inventory, "127.0.0.1")
    variable_manager = VariableManager(inventory, loader=None)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    fake_variables = {
        'foo': 'bar',
        'bar': 'baz',
        'test': True,
        'not-test': False,
        'omg': None,
        'omg-lists': [1, 2, 3],
        'omg-dict': {'a': 1, 'b': 2},
    }


# Generated at 2022-06-22 14:34:20.721191
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    h = HostVarsVars({"a": "b"}, None)

    assert set(h) == set(['a'])
    assert set(iter(h)) == set(['a'])


# Generated at 2022-06-22 14:34:31.379053
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, "hosts")
    host = inventory.get_host("localhost")
    inventory.add_host(host, 'test_group1')
    inventory.add_host(host, 'test_group2')

    hostvars = HostVars(inventory, variable_manager, loader)
    localhost_vars = hostvars["localhost"]
    assert isinstance(localhost_vars, Mapping)

# Generated at 2022-06-22 14:34:39.761596
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    '''
    This is a tester for HostVars.__repr__()
    '''
    import os
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    cur_dir = os.path.dirname(__file__)
    # init inventory
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=os.path.join(cur_dir, '../../test/inventory'))
    # init HostVars
    variables = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variables, loader)
    # run test
    variables.extra_vars = {'var':'value'}
    hostvars_repr = host

# Generated at 2022-06-22 14:34:47.514766
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host as InventoryHost
    import os

    temp_directory = os.path.realpath(tempfile.mkdtemp())
    inventory_path = os.path.join(temp_directory, 'inventory')
    variable_manager_path = os.path.join(temp_directory, 'vars')

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader())

    loader = DataLoader()

    host = Host(name='host')
    group = Group(name='group')

# Generated at 2022-06-22 14:34:57.475829
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo='bar')
    variable_manager.host_vars = dict(host1=dict(faz='baz'))
    variable_manager.group_vars = dict(group1=dict(biz='buz'), group2=dict(biz='qux'))

    inventory = InventoryManager(loader=DataLoader(), variable_manager=variable_manager)
    host1 = inventory.add_host("host1")

# Generated at 2022-06-22 14:35:08.640767
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inv_data = '''
        local1 ansible_connection=local ansible_host=127.0.0.1
        local2 ansible_connection=local ansible_host=127.0.0.1
        local3 ansible_connection=local ansible_host=127.0.0.1
        localhost ansible_host=127.0.0.1
        localhost
        '''.strip()

    inventory = InventoryManager(loader=loader, sources=[inv_data], host_pattern='all')
    var_mgr = inventory._variable_manager

    hv = HostVars(inventory, var_mgr, loader)


# Generated at 2022-06-22 14:35:19.012721
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import tempfile

    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    context.CLIARGS = {'inventory': ['localhost,']}
    fake_loader = DataLoader()
    test_inventory = InventoryManager(loader=fake_loader, sources=[])
    test_inventory.hosts = [Host('testhost1'), Host('testhost2')]
    test_vars_manager = VariableManager(loader=fake_loader, inventory=test_inventory)
    test_vars_manager.set_host_variable('testhost1', 'somevar', 'somevalue')

# Generated at 2022-06-22 14:35:28.418876
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager

    import os
    import sys

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # TODO: these tests aren't great since we're using a HostVars object outside of the context of a PlayContext, so
    #       things like the inventory and vars_cache don't exist.

    # FIXME: this test should probably be written to use a real inventory, but not sure we can guarantee the existence
    #        of such an inventory in the source tree

# Generated at 2022-06-22 14:35:37.639311
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    import copy
    import pytest

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    inventory = HostVars(None, None, None)

    groups = [copy.copy(Group(name=x)) for x in ['group1', 'group2', 'group3']]
    hosts = [copy.copy(Host(name=x)) for x in ['host1', 'host2', 'host3']]

    inventory._inventory._groups.extend(groups)
    inventory._inventory._hosts.extend(hosts)

    groups[0].hosts.extend([hosts[0], hosts[1]])
    groups[1].hosts.append(hosts[1])
    groups[2].hosts.append(hosts[2])

    result = [x for x in inventory]

# Generated at 2022-06-22 14:35:50.223050
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyBase

    class Playbook():
        def __init__(self):
            self._loader = DataLoader()
            self._variable_manager = VariableManager()
            self._hostvars = HostVars(Inventory(), self._variable_manager, self._loader)

        def set_hostvars(self):
            self._hostvars.set_variable_manager(self._variable_manager)

        def get_host_variable(self):
            return self._hostvars.raw_get('test_host')

    playbook = Playbook()
    inventory = playbook._hostvars._

# Generated at 2022-06-22 14:35:56.807363
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    # ansible.utils.unsafe_proxy.AnsibleUnsafeText object can't be
    # pickled while pickling objects
    # For example:
    #   pickle.dumps(HostVars({'foo': 'text'}))
    #
    # If it's necessary to pickle objects as ansible.utils.unsafe_proxy
    # use plain strings instead
    assert repr(HostVars({"foo": u"bar"}, None, None)) == "{'foo': 'bar'}"

# Generated at 2022-06-22 14:36:02.795052
# Unit test for method __iter__ of class HostVarsVars
def test_HostVarsVars___iter__():
    hostvars = HostVars(inventory=None, variable_manager=None, loader=None)
    assert isinstance(hostvars, Mapping)

    hostvarsvars = HostVarsVars(variables=None, loader=None)
    assert isinstance(hostvarsvars, Mapping)

    iter_hostvars = iter(hostvars)
    iter_hostvarsvars = iter(hostvarsvars)

# Generated at 2022-06-22 14:36:11.920673
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():

    loader = MockLoader()
    inventory = MockInventory()
    variable_manager = MockVariableManager(loader)

    # Create HostVars with empty attribute _inventory
    hostvars = HostVars(None, variable_manager, loader)

    # Assert that the inventory object has not been changed
    assert hostvars._inventory is None

    # Assign inventory object to attribute _inventory
    inventory = MockInventory()
    hostvars._inventory = inventory

    # Create pickle data to simulate serialization
    data = {}
    data['_inventory'] = None
    data['_loader'] = loader
    data['_variable_manager'] = variable_manager

    # Assign variables to the VariableManager object
    variable_manager._loader = None
    variable_manager._hostvars = None

    # Assign pickle data into object
    hostv

# Generated at 2022-06-22 14:36:23.850456
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    class Inventory():

        def get_host(self, host):
            return None

        def __iter__(self):
            yield 1

        def __len__(self):
            return 1

    class VariableManager():

        def get_vars(self, host, include_hostvars=True):
            return 1

        def set_host_variable(self, host, varname, value):
            pass

        def set_nonpersistent_facts(self, host, facts):
            pass

        def set_host_facts(self, host, facts):
            pass

    class Loader():

        def get_basedir(self):
            return "some string returned by get_basedir"

    loader = Loader()
    inventory = Inventory()
    variable_manager = VariableManager()

# Generated at 2022-06-22 14:36:33.657007
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.module_utils.six.moves import StringIO
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    host = "host1"
    inventory = InventoryManager(loader=DataLoader(), sources='')
    inventory.hosts[host] = inventory.get_host(host)
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)

    assert hostvars[host] == {}

    # Next, define "ansible_ssh_user"
    variable_manager.set_host_variable(inventory.hosts[host], 'ansible_ssh_user', "root")

    # Add to inventory

# Generated at 2022-06-22 14:36:45.042920
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    class InventoryMock(object):
        def __init__(self):
            self.hosts = ['localhost', 'remotehost']
        def get_host(self, host_name):
            if host_name in self.hosts:
                return object()
            return None
    class LoaderMock(object):
        class _get_basedir(object):
            def __repr__(self):
                return 'loader._get_basedir'
    class HostVarsMock(Mapping):
        def __init__(self):
            self.hosts = ['localhost', 'remotehost']
        def get(self, host_name, default=None):
            if host_name in self.hosts:
                return {'key': 'value'}
            return default

# Generated at 2022-06-22 14:36:50.973783
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    # When host exists in the inventory
    hostvars.raw_get('localhost')
    assert 'localhost' in inventory.hosts

    # When host does not exists in the inventory
    assert hostvars.raw_get('non-existent-host') is None
    assert 'non-existent-host' not in inventory.hosts

# Generated at 2022-06-22 14:37:02.237180
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.vars.hostvars

    state = {
        '_inventory': ansible.inventory.host.Host("localhost"),
        '_loader': None,
        '_variable_manager': ansible.vars.manager.VariableManager(),
    }
    state['_variable_manager'].__dict__.update({
        '_host_cache': {
            'localhost': {
                'test_variable': 'test_value',
            },
        },
        '_loader': None,
        '_hostvars': None,
    })

    newobj = ansible.vars.hostvars.HostVars(None, None, None)
    newobj.__setstate__(state)
    assert newobj._loader is None


# Generated at 2022-06-22 14:37:11.217340
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # This test checks if variables are correctly expanded.
    # Issue #29278
    class FakeLoader:
        def get_basedir(self):
            return "."

    class FakeHost:
        is_localhost = False
        name = "fake-host"
        vars = {
            "x": "{{ value }}",
            "y": "{{ x }}",
        }

    class FakeInventory:
        def __init__(self, hosts=[]):
            self._hosts = hosts
        def get_hosts(self, pattern="all"):
            return self._hosts

    class FakeVariableManager:
        # Container for hostvars
        _hostvars = {}
        # Container for variables
        _vars_cache = {}
        def add_group_vars_file(self, path):
            pass
       

# Generated at 2022-06-22 14:37:31.691234
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    class Dummy(Mapping):

        def __getitem__(self, key):
            return key

        def __iter__(self):
            return iter([1, 2, 3])

        def __len__(self):
            return 3

    hostvars = HostVars(inventory=Dummy(), variable_manager=Dummy(), loader=Dummy())
    repr_hostvars = repr(hostvars)
    assert repr_hostvars == "{1: 1, 2: 2, 3: 3}"

# Generated at 2022-06-22 14:37:44.445175
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.plugin import plugin_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    import ansible.constants as C

    class StubInventory(object):
        def __init__(self, hosts):
            self._hosts = hosts

        def get_host(self, key):
            for host in self._hosts:
                if host.name == key:
                    return host
            return None

        @property
        def hosts(self):
            return self._hosts

    class StubHost(object):
        def __init__(self, name):
            self.name = name

        def get_vars(self):
            return {
                'hostvar': 'hostvars'
            }

        def get_groups(self):
            return []


# Generated at 2022-06-22 14:37:50.952235
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a dummy inventory
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    hostvars = HostVars(inventory, variable_manager, loader)

    # Ensure it contains no hosts
    assert len(hostvars) == 0
    assert list(hostvars) == []

    # Create host
    inventory.hosts.append({'name': 'localhost'})

    # Ensure it contains one host
    assert len(hostvars) == 1
    assert list(hostvars) == ['localhost']

# Generated at 2022-06-22 14:37:54.093367
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    hostvars = HostVars(None, None, None)
    assert {'foo': 'bar'} == hostvars['some_host']

# Generated at 2022-06-22 14:37:57.717274
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    assert HostVars.raw_get.__doc__ == '''
        Similar to __getitem__, however the returned data is not run through
        the templating engine to expand variables in the hostvars.
        '''


# Generated at 2022-06-22 14:38:07.823278
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    class Foo:
        pass
    inventory = Foo()
    inventory.hosts = ["foo", "bar"]
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    hostvars = HostVars(inventory, variable_manager, loader)
    assert repr(hostvars) == "{'foo': {}, 'bar': {}}"

    variable_manager.set_host_variable("foo", "foo", "bar")
    assert repr(hostvars) == "{'foo': {u'foo': u'bar'}, 'bar': {}}"

    variable_manager.set_host_variable("bar", "foo", "bar")


# Generated at 2022-06-22 14:38:12.886704
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    inv = '{"_meta":{"hostvars":{"a":{"one":1},"b":{"two":2},"c":{"three":3}}}}'
    inv = json.loads(inv)

    hv = HostVars(inventory=AnsibleInventory(inv), variable_manager=None, loader=None)
    assert [x for x in hv] == ['a', 'b', 'c']

# Generated at 2022-06-22 14:38:24.013724
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import pytest

    loader = DataLoader()
    inv_data = """
    localhost ansible_connection=local
    """
    hosts = InventoryManager(loader=loader, sources=inv_data)

    vars_manager = VariableManager(loader=loader, inventory=hosts)
    hostvars = HostVars(inventory=hosts, variable_manager=vars_manager, loader=loader)
    assert next(iter(hostvars)) == 'localhost'



# Generated at 2022-06-22 14:38:36.414359
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from collections import Mapping
    import mock

    def test_hosts():
        for host in ['host1', 'host2', 'host3']:
            yield host

    def test_get(host):
        if host == 'host1':
            return {'a': 1, 'b': 2}
        elif host == 'host2':
            return {'c': 3, 'd': 4}
        elif host == 'host3':
            return {'e': 5, 'f': 6}

    inventory = mock.MagicMock()
    inventory.__iter__.side_effect = test_hosts
    inventory.__getitem__.side_effect = test_get
    inventory.__contains__.side_effect = lambda host: host in test_hosts()

# Generated at 2022-06-22 14:38:46.362364
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class Options():
        def __init__(self):
            self.host_file = 'tests/host_file'
            self.inventory = self.host_file
            self.listhosts = None
            self.subset = None

        def _parse_options(self):
            pass

    # Create hostvars
    hostvars = HostVars(None, None, None)

    # Populate vars_manager
    vars_manager = VariableManager()
    vars_manager.set_inventory(InventoryManager(Options()))
    hostvars.set_variable_manager(vars_manager)

    # Retrieve variables prior to templating


# Generated at 2022-06-22 14:39:00.891093
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    # Create empty inventory
    inventory = Inventory("")

    # Create mock loader
    class MockLoader:
        pass
    loader = MockLoader()

    # Create variable manager
    variable_manager = VariableManager(loader=loader)

    # Create HostVars
    hostvars = HostVars(inventory, variable_manager, loader)

    # Set hostvars for localhost
    host = inventory.get_host("localhost")
    variable_manager.set_host_variable(host, "foo", "bar")
    variable_manager.set_host_variable(host, "hello", "world")

    # Create temporary file
    with tempfile.NamedTemporaryFile() as tmp_file:
        # Write temporary file
        tmp_file.write("hello {{ foo }}".encode())
        tmp_file.flush()

        # Test that the

# Generated at 2022-06-22 14:39:03.618472
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    hostvars = HostVars(None, None, None)
    assert hostvars.raw_get('localhost') == dict()

# Generated at 2022-06-22 14:39:12.588905
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    filename = 'test/units/inventory/hostvars_iter.yml'
    inventory = InventoryManager(loader=None, sources=filename)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    var_a = 'a'
    var_b = 'b'
    expected_iterator = [var_a, var_b]

    hostvars = HostVars(inventory, variable_manager, loader=None)
    assert isinstance(hostvars, HostVars)

    iterator = hostvars.__iter__()
    assert isinstance(iterator, type(iter([])))

    j = 0
    for i in iterator:
        expected_value = expected_iterator[j]
        assert expected_value

# Generated at 2022-06-22 14:39:21.534885
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from ansible.inventory.host import Host

    class FakeInventory(object):
        def __init__(self):
            self.hosts = {
                Host('192.168.0.0'),
                Host('192.168.0.1'),
                Host('192.168.0.2'),
                Host('192.168.0.3'),
                Host('192.168.0.4'),
            }

        def __iter__(self):
            for host in self.hosts:
                yield host

        def get_host(self, host_name):
            for host in self.hosts:
                if host.name == host_name:
                    return host

    class FakeLoader(object):
        pass



# Generated at 2022-06-22 14:39:26.172883
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    group = ("all", {"hosts": ["foo", "bar"]})
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[group])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)

    hosts = set()
    for host in hostvars:
        hosts.add(host)
    assert hosts == set(["foo", "bar"])

# Generated at 2022-06-22 14:39:33.371242
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    """
    Method raw_get of class HostVars should return a dictionary of the
    variables only for a host.  The variables returned should not be
    templated.
    """
    import mock
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common._collections_compat import Sequence

    play_context = PlayContext()
    variable_manager = VariableManager(loader=mock.MagicMock(), inventory=mock.MagicMock())
    variable_manager.set_inventory(InventoryManager(mock.MagicMock()))

# Generated at 2022-06-22 14:39:42.816921
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import DictInventory
    from ansible.vars import VariableManager

    loader = DictDataLoader({})
    inventory = DictInventory(dict(all=dict(hosts=['127.0.0.1'])))
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory=inventory, loader=loader, variable_manager=vars_manager)

    # Test that if host is not found in inventory, a key error is raised
    try:
        hostvars['not-a-host']
        raise AssertionError('test failed, key not-a-host should not be found in hostvars')
    except KeyError:
        pass

    # Test that an undefined variable for

# Generated at 2022-06-22 14:39:55.264695
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Setup a minimal InventoryManager to test HostVars.__getitem__
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources='localhost,')

    # Create HostVars instance
    hostvars = HostVars(inventory, variable_manager, loader)

    # Test with a host that exists in the inventory
    hostname = 'localhost'
    host_vars = hostvars[hostname]
    assert isinstance(host_vars, HostVarsVars)
    assert host_vars['ansible_play_hosts'] == "'localhost'"

    # Test with a host that does

# Generated at 2022-06-22 14:40:07.491628
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import copy
    from ansible.vars import VariableManager

    class MyInventory():
        pass

    class MyLoader():
        pass

    class MyVariableManager():
        pass

    inv = MyInventory()
    loader = MyLoader()
    var_mgr = MyVariableManager()

    hostvars = HostVars(inv, var_mgr, loader)

    # Make sure _hostvars and _loader are available.
    assert hostvars._variable_manager._hostvars is not None
    assert hostvars._variable_manager._loader is not None

    # Create a deepcopy of hostvars for testing.
    hostvars_copy = copy.deepcopy(hostvars, None)

    # Make sure _hostvars and _loader are not available after deepcopy.
    assert hostvars_copy._variable_manager

# Generated at 2022-06-22 14:40:14.357386
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    inventory = Inventory()
    variable_manager = VariableManager(loader=None, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader=None)

    assert hostvars.raw_get('foo') == AnsibleUndefined()

    host = inventory.add_host('foo')
    variable_manager.set_host_variable(host, 'my_var', 'my_val')

    assert hostvars.raw_get('foo') == {'my_var': 'my_val', 'hostvars': AnsibleUndefined(), 'groups': AnsibleUndefined()}

# Generated at 2022-06-22 14:40:38.633137
# Unit test for method __repr__ of class HostVars
def test_HostVars___repr__():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    h = HostVars(inventory=Inventory(loader=DataLoader(), variable_manager=VariableManager(loader=DataLoader(), inventory=Inventory(loader=DataLoader()))), variable_manager=VariableManager(loader=DataLoader(), inventory=Inventory(loader=DataLoader())),loader=DataLoader())
    assert repr(h) == "{}"

# Generated at 2022-06-22 14:40:43.443310
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    vars_manager = VariableManager()
    host = Host('localhost', vars=dict(foo='bar'))

    hostvars = HostVars({}, vars_manager, loader=None)
    assert hostvars.raw_get('localhost') == {'foo': 'bar'}

# Generated at 2022-06-22 14:40:53.806582
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    hv = HostVars(inventory=None, variable_manager=None, loader=None)
    from ansible.parsing.vault import get_vault_secrets
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    class AnsibleVars(dict):
        def __getitem__(self, key):
            return "A"
    h = Host()
    h.vars = AnsibleVars()
    ret = hv.raw_get(h)
    assert ret == AnsibleVars()
    v = VariableManager()
    v.set_host_variable(host=h, varname="var", value="value")
    templar = Templar(loader=None)

# Generated at 2022-06-22 14:41:05.489423
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    '''
    Test method to see if it behaves as expected
    '''

    # Test expected behavior
    # NOTE: ansible.inventory.manager.InventoryManager also contains a
    # class called HostVars which differs from the one we are testing.
    # To prevent confusion, we are going to import the class under test
    # directly:
    #
    #    from ansible.vars import HostVars
    #
    # instead of:
    #
    #    from ansible import HostVars

    from ansible.vars import HostVars

    # create a variable manager for testing:
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.compat.tests import unittest



# Generated at 2022-06-22 14:41:10.957974
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    # Create mock objects
    class MockInventory(object):

        def __init__(self):
            self.hosts = []

        def get_host(self, host_name):
            self.hosts.append(host_name)
            return host_name

    class MockVariableManager(object):

        def __init__(self):
            self.host = None
            self.include_hostvars = None
            self.hostvars = None

        def get_vars(self, host, include_hostvars):
            return {'a': 'b'}

        def set_host_variable(self, host, varname, value):
            pass

        def set_nonpersistent_facts(self, host, facts):
            pass

        def set_host_facts(self, host, facts):
            pass


# Generated at 2022-06-22 14:41:20.824211
# Unit test for method __setstate__ of class HostVars
def test_HostVars___setstate__():
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.inventory.host
    import ansible.vars.variable_manager

    hostvars = HostVars(ansible.inventory.Inventory(), ansible.vars.variable_manager.VariableManager(), None)

    hostvars._variable_manager._loader = 'fake loader'
    hostvars._variable_manager._hostvars = 'fake host vars'

    hostvars.__setstate__({})

    assert hostvars._variable_manager._loader == 'fake loader'
    assert hostvars._variable_manager._hostvars == 'fake host vars'

# Generated at 2022-06-22 14:41:27.901174
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    vm = MagicMock()
    hv = HostVars(MagicMock(), vm)
    vm.get_vars.side_effect = [{'foo': 'bar'}, AnsibleUndefined()]
    assert list(hv.__iter__()) == [MagicMock(), MagicMock()]
    vm.get_vars.assert_has_calls([call(host=mock.ANY, include_hostvars=False), call(host=mock.ANY, include_hostvars=False)])


# Generated at 2022-06-22 14:41:36.196569
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():

    class FakeLoader():
        def __init__(self):
            pass
    loader = FakeLoader()

    class FakeVariableManager():
        def __init__(self):
            pass
        def get_vars(self, host=None, include_hostvars=False):
            return {'foo': 'bar', 'fiz': 'buz'}
    variable_manager = FakeVariableManager()

    class FakeInventory():
        def __init__(self):
            pass
        def get_host(self, host_name):
            if host_name in ('localhost', 'foo', 'bar'):
                return 'some host object'
            else:
                return None
        @property
        def hosts(self):
            return ['localhost', 'foo', 'bar']
    inventory = FakeInventory()

    hostvars = HostVars

# Generated at 2022-06-22 14:41:46.191385
# Unit test for method __iter__ of class HostVars
def test_HostVars___iter__():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    inventory = InventoryManager(loader=DataLoader(), sources='')
    host1 = Host(name='localhost')
    host2 = Host(name='beta')
    host3 = Host(name='warp')
    inventory.add_host(host1)
    inventory.add_host(host2)
    inventory.add_host(host3)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    hostvars = HostVars(inventory, variable_manager, DataLoader())

    names = {host.name for host in hostvars}


# Generated at 2022-06-22 14:41:58.518355
# Unit test for method raw_get of class HostVars
def test_HostVars_raw_get():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(inventory, variable_manager, loader)
    hostvars.set_host_variable('localhost', 'first', 1)
    assert hostvars.raw_get('localhost')['first'] == 1
    assert isinstance(hostvars.raw_get('localhost')['first'], int)
    hostvars.set_host_variable('localhost', 'second', 2)
    assert hostvars.raw_get('localhost')['second'] == 2
    assert isinstance

# Generated at 2022-06-22 14:42:36.535262
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inv_data = '''
    [all]
    localhost
    [local]
    localhost
    '''
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=inv_data)
    variable_manager = inventory.get_variable_manager()
    hostvars = HostVars(inventory=inventory, variable_manager=variable_manager, loader=loader)
    assert isinstance(hostvars['localhost'], HostVarsVars)

# Generated at 2022-06-22 14:42:47.034252
# Unit test for method __getitem__ of class HostVars
def test_HostVars___getitem__():
    global STATIC_VARS
    import base64
    from ansible import constants as C
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class TestHostVars(HostVars):
        def __init__(self):
            self._loader = DataLoader()
            self._inventory = TestInventory()
            self._variable_manager = VariableManager()

    class TestInventory:
        def __init__(self):
            self.hosts = [TestHost('localhost')]
            self.groups = []

        def get_host(self, host_name):
            if host_name == 'localhost':
                return self.hosts[0]
            return