

# Generated at 2022-06-21 11:04:42.578482
# Unit test for function config
def test_config():
    # type: () -> None
    from dataclasses import dataclass
    from typing import Optional

    def lower(x):
        # type: (str) -> str
        return x.lower()

    def upper(x):
        # type: (str) -> str
        return x.upper()

    @dataclass
    class Config:
        lower_class_field: str = "lower_class_field"
        LOWER_CLASS_FIELD: str = "LOWER_CLASS_FIELD"

        @config(field_name="UPPER_CLASS_FIELD")
        def upper_class_field(self):
            # type: () -> str
            return "UPPER_CLASS_FIELD"

        @config(letter_case=lower)
        def lower_method(self):
            # type: () -> str
            return "lower"



# Generated at 2022-06-21 11:04:44.007779
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False


# Generated at 2022-06-21 11:04:47.476160
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Case 1: default
    assert global_config.mm_fields == {}
    assert global_config.encoders == {}
    assert global_config.decoders == {}

    return True


# Generated at 2022-06-21 11:04:51.956720
# Unit test for function config
def test_config():
    meta = config(encoder=int, decoder=str, mm_field=str)
    assert meta == {'dataclasses_json': {'encoder': int, 'decoder': str,
                                         'mm_field': str}}



# Generated at 2022-06-21 11:05:01.356546
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert Exclude.ALWAYS('a') == True
   assert Exclude.ALWAYS('b') == True
   assert Exclude.ALWAYS(1) == True
   assert Exclude.ALWAYS(2) == True
   assert Exclude.ALWAYS(1.1) == True
   assert Exclude.ALWAYS(1.2) == True
   assert Exclude.ALWAYS((1, 2, 3)) == True
   assert Exclude.ALWAYS((1.1, 2.2, 3.3)) == True
   assert Exclude.ALWAYS([1, 2, 3]) == True
   assert Exclude.ALWAYS([1.1, 2.2, 3.3]) == True
   assert Exclude.ALWAYS({'a': 1, 'b': 2}) == True

# Generated at 2022-06-21 11:05:04.754297
# Unit test for function config
def test_config():
    # mypy error: Argument 3 to "config" has incompatible type "Callable[[str], Callable[[str], str]]"; expected "Callable[[str], str]"
    config(letter_case=lambda _: _.upper())

# Generated at 2022-06-21 11:05:08.286217
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-21 11:05:14.415577
# Unit test for function config
def test_config():
    from dataclasses import is_dataclass, asdict

    @config(letter_case=str.upper,
            field_name="example")
    @dataclass
    class Example:
        attr1: int

    assert is_dataclass(Example)

    # Config keys
    assert Example.__dataclasses_json__.letter_case("test") == "test".upper()
    assert Example.__dataclasses_json__.field_name("test") == "example"

    # Exclude
    assert isinstance(Example.attr1, int)
    assert asdict(Example(attr1=100)) == {"example": 100}

    # Field name
    assert Example.__dataclasses_json__.field_name("test") == "example"

    # Undefined

# Generated at 2022-06-21 11:05:17.066280
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    try:
        assert(Exclude.ALWAYS(1) == True)
    except:
        print("Test of Exclude.ALWAYS() failed!")


# Generated at 2022-06-21 11:05:22.231541
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    """
    Just testing if the class is constructed correctly.
    """
    tests = (
        (type(global_config.encoders), dict),
        (type(global_config.decoders), dict),
        (type(global_config.mm_fields), dict),
    )
    for check, expected_type in tests:
        assert check == expected_type, \
            f"Expected {expected_type}, found {check}"

# Generated at 2022-06-21 11:05:26.960711
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _config = _GlobalConfig()
    # test constuctor
    assert _config
    # test default variables
    assert _config.encoders == {}
    assert _config.decoders == {}
    assert _config.mm_fields == {}


# Generated at 2022-06-21 11:05:34.072127
# Unit test for function config
def test_config():
    # Test internal functions
    def assert_config(expected_config_dict, actual_config_dict):
        print(expected_config_dict, actual_config_dict)
        assert expected_config_dict == actual_config_dict

    def assert_exception_message(exception, msg):
        assert exception.args[0] == msg

    # Test default case
    assert_config(config(), {'dataclasses_json': {}})

    from dataclasses import dataclass

    @dataclass
    class Point:
        x: int
        y: int

    @dataclass
    class NamedPoint:
        x: int

    @dataclasses.dataclass
    class User:
        username: str
        is_valid: bool = False

    @dataclass
    class User2:
        username: str

# Generated at 2022-06-21 11:05:41.333654
# Unit test for function config
def test_config():
    import pytest

    class Config:
        def __init__(self):
            self.data = {'key': 'value'}

    class MetadataConfig(Config):

        def __init__(self):
            super().__init__()
            self.data['metadata'] = {}

    class EncoderConfig(MetadataConfig):

        def __init__(self):
            super().__init__()
            self.data['encoder'] = 'encoder_value'

    class DecoderConfig(MetadataConfig):

        def __init__(self):
            super().__init__()
            self.data['decoder'] = 'decoder_value'

    class MMFieldConfig(MetadataConfig):

        def __init__(self):
            super().__init__()

# Generated at 2022-06-21 11:05:51.184022
# Unit test for function config
def test_config():
    """
    A function unit test was created for config to test the dictionary creation
    """
    from uuid import UUID
    from marshmallow import fields

    @dataclass
    @config(encoder=str)
    class MyClass:
        id: UUID

        @classmethod
        def _encoder(cls, o: UUID):
            return str(o)

    assert MyClass.__dataclass_json__.encoder == str

    @dataclass
    @config(decoder=UUID)
    class MyClass2:
        id: UUID

        @classmethod
        def _decoder(cls, o: str):
            return UUID(o)

    assert MyClass2.__dataclass_json__.decoder == UUID


# Generated at 2022-06-21 11:05:52.503372
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:06:01.189523
# Unit test for function config
def test_config():
    metadata = config(field_name='name', letter_case='upper')
    assert metadata['dataclasses_json']['letter_case']('') == 'NAME'
    assert (metadata['dataclasses_json']['undefined'] ==
            Undefined.RAISE)

    # Check invalid undefined value
    with pytest.raises(UndefinedParameterError):
        config(undefined='RISE_UP')
    # Check invalid exclude value
    with pytest.raises(UndefinedParameterError):
        config(exclude=Exclude.NEVER)



# Generated at 2022-06-21 11:06:02.613583
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-21 11:06:05.354763
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders is not None
    assert global_config.decoders is not None
    assert global_config.mm_fields is not None

# Generated at 2022-06-21 11:06:07.204574
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    output = Exclude.ALWAYS(1)
    assert output == True, "Exclude.ALWAYS is not working properly"


# Generated at 2022-06-21 11:06:08.734111
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(42) == True


# Generated at 2022-06-21 11:06:20.984668
# Unit test for function config
def test_config():
    metadata = {'dataclasses_json': {'letter_case': 'snake'}}

    def abc(s):
        return s
    assert config(metadata, letter_case=abc) == {'dataclasses_json': {'letter_case': abc}}
    assert config(metadata, letter_case='upper') == {'dataclasses_json': {'letter_case': 'upper'}}
    assert config(metadata, mm_field=None) == {'dataclasses_json': {'letter_case': 'snake', 'mm_field': None}}
    assert config(metadata, undefined=Undefined.EXCLUDE) == {'dataclasses_json': {'letter_case': 'snake', 'undefined': Undefined.EXCLUDE}}

# Generated at 2022-06-21 11:06:24.694978
# Unit test for function config
def test_config():
    @config(encoder=list, decoder=list)
    @dataclass
    class DataClass:
        pass
    assert global_config.encoders[DataClass] == list
    assert global_config.decoders[DataClass] == list

# Generated at 2022-06-21 11:06:27.139876
# Unit test for function config
def test_config():
    assert config(encoder=int, mm_field=int) == {'dataclasses_json': {'encoder': int, 'mm_field': int}}

# Generated at 2022-06-21 11:06:38.509286
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields as mm_fields
    from typing import Any, NoReturn

    @dataclass
    class X:
        a: Any
        b: NoReturn

        class Config:
            encoder = str
            decoder = int
            mm_field = mm_fields.String()

            @staticmethod
            def field_name(n):
                return n.upper()

            @staticmethod
            def letter_case(s):
                return s.upper()

    assert X.__config__["encoder"] == str
    assert X.__config__["decoder"] == int
    assert X.__config__["mm_field"] == mm_fields.String()
    assert X.__config__["letter_case"] == X.Config.letter_case
    assert X.__config__

# Generated at 2022-06-21 11:06:41.581717
# Unit test for constructor of class Exclude
def test_Exclude():
    test_always = Exclude.ALWAYS('abc')
    test_never = Exclude.NEVER('123')

    assert test_always, "The lambda function should always return true."
    assert not test_never, "The lambda function should always return false."

# Generated at 2022-06-21 11:06:51.300343
# Unit test for function config
def test_config():
    import marshmallow
    @config(encoder = int, decoder = float)
    class A:
        pass

    assert A.__annotations__['dataclasses_json']['encoder'] == int
    assert A.__annotations__['dataclasses_json']['decoder'] == float

    # When config is used to add marshmallow field to a field, the field name
    # is added to the marshmallow field
    assert A.__annotations__['dataclasses_json']['mm_field'].attribute == None
    @config(mm_field=marshmallow.fields.String(attribute='f_name'))
    class A:
        f_name: str
    assert A.__annotations__['dataclasses_json']['mm_field'].attribute == 'f_name'

    # Test for

# Generated at 2022-06-21 11:06:52.993583
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}

# Generated at 2022-06-21 11:06:55.245151
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("_1")
    assert Exclude.NEVER("_2")

# Generated at 2022-06-21 11:07:05.248628
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(3.141) == False
    assert Exclude.NEVER(0.000) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(-3.141) == False
    assert Exclude.NEVER(-0.000) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('abc') == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({}) == False


# Generated at 2022-06-21 11:07:17.527313
# Unit test for function config

# Generated at 2022-06-21 11:07:26.897963
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    """
    Test the method ALWAYS of class Exclude.
    """

    exclude = Exclude.ALWAYS

    # Test with a valid input
    assert exclude('abc')



# Generated at 2022-06-21 11:07:29.236333
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders
    assert global_config.decoders
    assert global_config.mm_fields


# Generated at 2022-06-21 11:07:31.179149
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:07:33.070384
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(1)


# Generated at 2022-06-21 11:07:37.127731
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    assert e.ALWAYS(1)
    assert not e.NEVER(1)
    assert e.ALWAYS(1)
    assert not e.NEVER(1)

# Generated at 2022-06-21 11:07:37.923874
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)



# Generated at 2022-06-21 11:07:39.697506
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("") is True
    assert Exclude.NEVER("") is False

# Generated at 2022-06-21 11:07:44.518890
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert callable(Exclude.ALWAYS)

    assert Exclude.ALWAYS('test_string') == True
    assert Exclude.ALWAYS(1234) == True
    assert Exclude.ALWAYS(1234.12) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-21 11:07:45.086012
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-21 11:07:46.657277
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    expected = False
    result = Exclude.NEVER(1)
    assert result == expected


# Generated at 2022-06-21 11:08:04.244163
# Unit test for function config
def test_config():
    # Create empty dataclass
    @dataclasses.dataclass
    class Empty:
        pass
        
    # Create an Empty object
    empty_obj = Empty()
    
    # Assert metadata
    assert config(empty_obj) == {}

# Generated at 2022-06-21 11:08:11.483263
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(0.5)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS([])

# Generated at 2022-06-21 11:08:13.001939
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-21 11:08:23.992312
# Unit test for function config
def test_config():
    assert 'dataclasses_json' in config()
    assert config() == config(metadata=None)
    assert config({}) == config(metadata={})
    assert config(encoder=None) == config(metadata={}, encoder=None)
    assert config(encoder=None) == config(encoder=None, metadata={})
    assert config(decoder=None) == config(metadata={}, decoder=None)
    assert config(decoder=None) == config(decoder=None, metadata={})
    assert config(mm_field=None) == config(metadata={}, mm_field=None)
    assert config(mm_field=None) == config(mm_field=None, metadata={})
    assert config(letter_case=None) == config(metadata={}, letter_case=None)

# Generated at 2022-06-21 11:08:25.515945
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test = Exclude.NEVER("Test")
    assert test == False

# Generated at 2022-06-21 11:08:27.156018
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER(3)
    assert x == False


# Generated at 2022-06-21 11:08:38.261668
# Unit test for function config
def test_config():
    assert config(letter_case="camel") == {
        "dataclasses_json": {
            "letter_case": "camel"
        }
    }
    assert config(field_name="custom_name") == {
        "dataclasses_json": {
            "letter_case": "custom_name"
        }
    }
    assert config(undefined="Raise") == {
        "dataclasses_json": {
            "undefined": Undefined.RAISE
        }
    }
    assert config(undefined=Undefined.RAISE) == {
        "dataclasses_json": {
            "undefined": Undefined.RAISE
        }
    }

# Generated at 2022-06-21 11:08:39.106472
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()

# Generated at 2022-06-21 11:08:42.528325
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(123)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("a string")


# Generated at 2022-06-21 11:08:44.194740
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({}) is True
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-21 11:09:18.590908
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == Exclude.ALWAYS(2)
    assert not Exclude.ALWAYS(1) != Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(1) != Exclude.NEVER(2)
    assert not Exclude.ALWAYS(1) == Exclude.NEVER(2)
    assert Exclude.NEVER(1) == Exclude.NEVER(2)
    assert not Exclude.NEVER(1) != Exclude.NEVER(2)

# Generated at 2022-06-21 11:09:22.069112
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(100) == True
    assert Exclude.NEVER(100) == False
    assert Exclude.ALWAYS("100") == True


# Generated at 2022-06-21 11:09:32.990897
# Unit test for function config
def test_config():
    assert {
        "dataclasses_json": {
            "undefined": Undefined.EXCLUDE.name,
            "letter_case": "lower",
            "encoder": str,
            "decoder": str,
            "mm_field": MarshmallowField,
            "exclude": Exclude.ALWAYS,
            "field_name": "field_name",
        },
    } == config(undefined="exclude", letter_case=str.lower, encoder=str,
                decoder=str, mm_field=MarshmallowField, exclude=Exclude.ALWAYS,
                field_name="field_name")

# Generated at 2022-06-21 11:09:34.340857
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-21 11:09:35.372812
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('x') == False

# Generated at 2022-06-21 11:09:42.207425
# Unit test for function config
def test_config():
    """
    >>> from dataclasses import dataclass
    >>> from dataclasses_json import config
    >>> @dataclass
    ... class Foo:
    ...     x: int
    ...     y: int = config(exclude=lambda f, v: f == 'y')
    ...     z: int = config(undefined=Undefined.EXCLUDE)
    >>> print(Foo.__config__)  # doctest: +ELLIPSIS
    <dataclasses_json.config.Config object at 0x...>
    """
    pass

# Generated at 2022-06-21 11:09:43.830761
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-21 11:09:45.589519
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = [1, 2, 3]

    b = Exclude.NEVER(a)
    assert b == False

# Generated at 2022-06-21 11:09:47.170390
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('true') == True
    assert Exclude.NEVER('true') == False

# Generated at 2022-06-21 11:09:49.103327
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('x') == True


# Generated at 2022-06-21 11:10:54.295821
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field

    @dataclass
    class Person:
        name: str
        age: int = field(metadata=config(exclude=Exclude.ALWAYS))
        grade: int = field(metadata=config(undefined=Undefined.RAISE))

    p = Person("John")


# TODO: parser, custom json module
# TODO: remove file_name, line_number

# Generated at 2022-06-21 11:11:01.150207
# Unit test for function config
def test_config():
    # default value
    metadata = config()
    assert 'dataclasses_json' in metadata
    assert 'letter_case' not in metadata['dataclasses_json']

    # pass in a value
    metadata = config(letter_case=lambda s: s.lower())
    assert 'dataclasses_json' in metadata
    assert 'letter_case' in metadata['dataclasses_json']
    letter_case = metadata['dataclasses_json']['letter_case']
    assert letter_case("FOO") == 'foo'

    # ensure the passed value is not a copy
    metadata['dataclasses_json']['letter_case'] = lambda s: s.upper()
    letter_case = metadata['dataclasses_json']['letter_case']
    assert letter_case("foo") == 'FOO'

# Generated at 2022-06-21 11:11:03.525080
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.NEVER(1) == False)
    assert(Exclude.ALWAYS(1) == True)

# Generated at 2022-06-21 11:11:07.082150
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}
    #assert gc.json_module == json


# Generated at 2022-06-21 11:11:11.117285
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print('Test for method ALWAYS of class Exclude')
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(1.2) == True


# Generated at 2022-06-21 11:11:12.687511
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-21 11:11:13.945239
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc is not None

# Generated at 2022-06-21 11:11:17.333833
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("hello")
    assert Exclude.ALWAYS({1: 1, 2: 2})
    assert Exclude.ALWAYS(Exclude)


# Generated at 2022-06-21 11:11:18.688876
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("some_string") == True


# Generated at 2022-06-21 11:11:22.150050
# Unit test for function config
def test_config():
    class Test:
        def __init__(self):
            pass

    assert hasattr(Test, '__dataclass_fields__')
    assert hasattr(Test, '__dataclass_params__')

# Generated at 2022-06-21 11:13:38.879309
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-21 11:13:41.130640
# Unit test for function config
def test_config():
    @dataclass
    class TestConfig:
        test_field: str
        
    config(encoder=str)


# Generated at 2022-06-21 11:13:43.132888
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("abc") == True


# Generated at 2022-06-21 11:13:45.612965
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-21 11:13:48.522015
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("hi") == True


# Generated at 2022-06-21 11:13:51.598222
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()

    assert isinstance(obj.encoders, dict)
    assert isinstance(obj.decoders, dict)
    assert isinstance(obj.mm_fields, dict)



# Generated at 2022-06-21 11:13:55.978588
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    

# Generated at 2022-06-21 11:13:57.714534
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER() == False


# Generated at 2022-06-21 11:13:59.034560
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True



# Generated at 2022-06-21 11:14:00.673125
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc")
