

# Generated at 2022-06-21 11:04:34.748591
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print('Testing the method NEVER of class Exclude')
    global_config = _GlobalConfig()
    if Exclude.NEVER == False:
        print('Testing the method NEVER of class Exclude: passed')
    else:
        print('Testing the method NEVER of class Exclude: failed')


# Generated at 2022-06-21 11:04:36.050233
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:04:38.682029
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    if Exclude.ALWAYS(None):
        print("Success")
    else:
        print("Failed")


# Generated at 2022-06-21 11:04:42.996023
# Unit test for function config
def test_config():
    assert config(undefined='INCLUDE')['dataclasses_json']['undefined'] \
           == Undefined.INCLUDE
    assert config(undefined='EXCLUDE')['dataclasses_json']['undefined'] \
           == Undefined.EXCLUDE

# Generated at 2022-06-21 11:04:44.416165
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude().NEVER("") == False


# Generated at 2022-06-21 11:04:48.520868
# Unit test for constructor of class Exclude
def test_Exclude():
    # 1. test for the default value of Exclude.ALWAYS
    assert Exclude.ALWAYS(None) == True

    # 2. test for the default value of Exclude.NEVER
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:04:50.768340
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:04:52.562467
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def _function():
        return False
    assert Exclude.NEVER == _function


# Generated at 2022-06-21 11:05:01.691114
# Unit test for function config
def test_config():
    import typing
    from marshmallow.fields import String
    from marshmallow_dataclass import class_schema
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.undefined import Undefined

    @config(mm_field=String())
    @dataclass()
    class Test:
        field: str

    assert Test.__dataclass_fields__['field'].metadata['dataclasses_json'].get('mm_field') == String()
    assert class_schema(Test).fields['field']._field == String()

    @config(metadata={'spam': 'eggs'})
    @dataclass()
    class Test2:
        field: str


# Generated at 2022-06-21 11:05:03.314338
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:05:12.929947
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field, asdict
    from dataclasses_json.api import dump, encoder, decoder
    from marshmallow import Schema, fields

    class CustomSchema(Schema):
        a = fields.Integer()
        b = fields.Str()
        c = fields.UUID()
        d = fields.Integer()

    @dataclass
    @config(encoder=int,
            decoder=float,
            mm_field=fields.Float(),
            letter_case=lambda s: s.lower(),
            # TODO: See if there's a better way to do this
            undefined=Undefined.RAISE,
            exclude=Exclude.NEVER,
            field_name='FOO')
    class Example:
        a: int
        b: str
        c: uuid.U

# Generated at 2022-06-21 11:05:15.209638
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-21 11:05:16.432854
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

if __name__ == '__main__':
    test_Exclude_NEVER()

# Generated at 2022-06-21 11:05:18.842078
# Unit test for constructor of class Exclude
def test_Exclude():
    exp = True
    act1 = Exclude.ALWAYS(None)
    assert exp == act1
    act2 = Exclude.NEVER(None)
    assert exp != act2

# Generated at 2022-06-21 11:05:27.452452
# Unit test for function config
def test_config():
    import pytest
    from dataclasses_json.metadata import Metadata
    from dataclasses_json.undefined import EXCLUDE, RAISE
    import marshmallow as mm
    field = mm.fields.Str()
    config(encoder=str, decoder=int, mm_field=field, field_name="Foo", letter_case=str.lower,
           undefined=EXCLUDE, exclude=Exclude.NEVER)
    config(metadata={'dataclasses_json': {'encoder': str, 'decoder': int, 'mm_field': field,
                                           'letter_case': str.lower, 'undefined': EXCLUDE,
                                           'exclude': Exclude.NEVER}}, field_name="Bar")

# Generated at 2022-06-21 11:05:29.045178
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("a") == True
    assert Exclude.NEVER("b") == False

# Generated at 2022-06-21 11:05:35.549221
# Unit test for function config
def test_config():
    import dataclasses
    import pytest
    from marshmallow import fields
    import marshmallow
    from .pre_encoders import to_tuple
    from .pre_decoders import from_tuple
    from .mm_fields import ListField

    @config(
        encoder=to_tuple,
        decoder=from_tuple,
        mm_field=ListField(),
        field_name='name',
        letter_case=lambda x: x.upper(),
        undefined=Undefined.RAISE,
        exclude=Exclude.NEVER
        )
    @dataclasses.dataclass(frozen=True)
    class DC:
        a: int
        b: int
        renamed: bool = False

    # Check to_tuple pre-encoder
    dc = DC(1, 2)
   

# Generated at 2022-06-21 11:05:36.773828
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)

# Generated at 2022-06-21 11:05:39.057380
# Unit test for constructor of class Exclude
def test_Exclude():
    class Exclude_Test():
        def __init__(self):
            assert Exclude.ALWAYS(None)
            assert not Exclude.NEVER(None)
    test = Exclude_Test()
    assert test

# Generated at 2022-06-21 11:05:43.361932
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    global test_Exclude_NEVER_arg
    test_Exclude_NEVER_arg = "test"
    s = Exclude.NEVER("test")
    assert s == False


# Generated at 2022-06-21 11:05:48.943563
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('Hello') == True
    assert Exclude.NEVER('Hello') == False

# Generated at 2022-06-21 11:05:49.829591
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-21 11:05:50.960013
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-21 11:05:56.420280
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @config(undefined=Undefined.RAISE)
    @dataclass
    class Raise:
        pass

    @config(undefined=Undefined.EXCLUDE)
    @dataclass
    class Exclude:
        pass

    # TODO: enable this test
    # @config(undefined=Undefined.PASS)
    # @dataclass
    # class Pass:
    #     pass

    # TODO: enable this test
    # @config(undefined=Undefined.FAIL)
    # @dataclass
    # class Fail:
    #     pass

    assert Raise.__dataclass_params__.undefined is Undefined.RAISE
    assert Exclude.__dataclass_params__.undefined is Undefined.EXCLUDE
    #

# Generated at 2022-06-21 11:06:02.166214
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders[1] = lambda x: x
    assert global_config.encoders[1](2) == 2

    global_config.decoders[1] = lambda x: x
    assert global_config.decoders[1](3) == 3

    global_config.mm_fields[1] = lambda x: x
    assert global_config.mm_fields[1](4) == 4


# Generated at 2022-06-21 11:06:03.563231
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:06:04.884142
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-21 11:06:05.771138
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False

# Generated at 2022-06-21 11:06:06.955108
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test') is True


# Generated at 2022-06-21 11:06:14.856580
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("a")
    assert Exclude.NEVER("test")
    assert Exclude.NEVER("123")
    assert Exclude.NEVER(123)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(1.2)
    assert Exclude.NEVER([])
    assert Exclude.NEVER((1,))
    assert Exclude.NEVER({"name": "Joe"})
    assert Exclude.NEVER({"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-21 11:06:20.261587
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:06:23.012742
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    method = Exclude.NEVER
    assert(method("foo") == False)
    assert(method("bar") == False)
    assert(method("baz") == False)


# Generated at 2022-06-21 11:06:26.796630
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert a.encoders == {}
    assert a.decoders == {}
    assert a.mm_fields == {}
test__GlobalConfig()



# Generated at 2022-06-21 11:06:38.106850
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses import dataclass

    # convert 'A' from int-like to integer, and 'B' to string
    @dataclass
    class Example:
        A: int

    # validation using marshmallow
    @dataclass
    class Example2:
        A: int

    @dataclass
    class Outer:
        b: str
        C: Example2

    # attach a converter when loading data
    @dataclass
    class Example3:
        A: int

    @dataclass
    class Outer2:
        E: int
        B: Example3

    # TODO: and other examples

    Example = Example(1)
    Example2 = Example2(2)
    Example3 = Example3(3)

    json_str = Example.to_json()

# Generated at 2022-06-21 11:06:39.703399
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    bool_value = Exclude.ALWAYS(0)
    assert bool_value == True



# Generated at 2022-06-21 11:06:41.532595
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("hello") == False


# Generated at 2022-06-21 11:06:51.263922
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(metadata={}) == {'dataclasses_json': {}}
    assert config(metadata={'dataclasses_json': {}}) == {'dataclasses_json': {}}
    assert config(encoder=lambda x: x) == {'dataclasses_json': {'encoder': lambda x: x}}
    assert config(decoder=lambda x: x) == {'dataclasses_json': {'decoder': lambda x: x}}
    assert config(mm_field=None) == {'dataclasses_json': {'mm_field': None}}
    assert config(letter_case=lambda x: x) == {'dataclasses_json': {'letter_case': lambda x: x}}

# Generated at 2022-06-21 11:06:52.662471
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-21 11:06:54.083329
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a')

# Generated at 2022-06-21 11:06:57.213329
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('test') == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-21 11:07:13.024717
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-21 11:07:14.753355
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS("abc"))

# Generated at 2022-06-21 11:07:17.580617
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_obj = _GlobalConfig()
    assert global_obj.encoders == {}
    assert global_obj.decoders == {}
    assert global_obj.mm_fields == {}

# Generated at 2022-06-21 11:07:22.153388
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1.1) == False


# Generated at 2022-06-21 11:07:25.687156
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-21 11:07:27.068023
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False



# Generated at 2022-06-21 11:07:39.323025
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(3.14) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(-0.5) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(1.7e308) == False
    assert Exclude.NEVER(-1.7e308) == False
    assert Exclude.NEVER(1.7e-308) == False
    assert Exclude.NEVER(-1.7e-308) == False
    assert Exclude.NEVER('hello') == False

# Generated at 2022-06-21 11:07:40.767933
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER is not None
    assert Exclude.ALWAYS is not None

# Generated at 2022-06-21 11:07:44.054808
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    c.encoders = {type: Callable}
    c.decoders = {type: Callable}
    c.mm_fields = {type: MarshmallowField}
    # c._json_module = json

# Generated at 2022-06-21 11:07:49.270943
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    @config(field_name='test')
    class WrapperConfig:
        value: int

        def __post_init__(self):
            self.value = self.value + 1

    wc = WrapperConfig(value=9)

    assert wc.value == 10
    assert wc.test == 10

    assert wc.__dict__['value'] == 10
    assert wc.__dict__['test'] == 10

# Generated at 2022-06-21 11:08:09.721002
# Unit test for constructor of class Exclude
def test_Exclude():
  assert Exclude.ALWAYS('a') == True
  assert Exclude.NEVER('a') == False

# Generated at 2022-06-21 11:08:10.325849
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-21 11:08:13.279806
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    data = _GlobalConfig()
    assert data.encoders == {}
    assert data.decoders == {}
    assert data.mm_fields == {}


# Generated at 2022-06-21 11:08:17.120522
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0
    assert global_config._json_module == json


# Generated at 2022-06-21 11:08:22.764577
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    @config(exclude=Exclude.NEVER)
    class Simple:
        one: int = 1
        two: int = 2

    assert Simple(one=4, two=5).json() == "{\"one\":4,\"two\":5}"


# Generated at 2022-06-21 11:08:26.474634
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1.encoders == {}
    assert global_config1.decoders == {}
    assert global_config1.mm_fields == {}
    # assert global_config1._json_module == json

# Generated at 2022-06-21 11:08:28.324361
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(17) == True)


# Generated at 2022-06-21 11:08:29.806393
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("TEST") is False


# Generated at 2022-06-21 11:08:31.536670
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS is not None


# Generated at 2022-06-21 11:08:34.987210
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS('1') is True
    assert Exclude.ALWAYS('abc') is True
    assert Exclude.ALWAYS('abc') is True



# Generated at 2022-06-21 11:09:09.820507
# Unit test for function config
def test_config():
    pass



# Generated at 2022-06-21 11:09:11.969234
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert Exclude.NEVER(1) == False
	assert Exclude.NEVER(0) == False
	assert Exclude.NEVER(0.0) == False

# Generated at 2022-06-21 11:09:13.338367
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS({}) == True
    assert Exclude.NEVER({}) == False

# Generated at 2022-06-21 11:09:21.065586
# Unit test for function config
def test_config():
    metadata = dict()
    metadata2 = dict()
    assert config(metadata) == {'dataclasses_json': {}}
    assert config(metadata2) == {'dataclasses_json': {}}
    assert metadata == metadata2

    assert config(metadata, encoder=1) == {'dataclasses_json': {'encoder': 1}}
    assert config(metadata2, encoder=1) == {'dataclasses_json': {'encoder': 1}}
    assert metadata == metadata2


# Generated at 2022-06-21 11:09:23.841349
# Unit test for constructor of class Exclude
def test_Exclude():
    # create an object
    obj = Exclude()

    # check if the object is of expected class
    assert (isinstance(obj, Exclude))


# Generated at 2022-06-21 11:09:26.176322
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('0') == True
    assert Exclude.NEVER('0') == False

# Generated at 2022-06-21 11:09:30.652627
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude_obj=Exclude()
    print(type(exclude_obj))
    print(exclude_obj.ALWAYS)
    print(exclude_obj.ALWAYS("se"))
    print(exclude_obj.NEVER("se"))
    print(exclude_obj.NEVER)


# Generated at 2022-06-21 11:09:32.302292
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    try:
        _GlobalConfig.__init__(global_config)
    except Exception:
        assert False
    assert True

# Generated at 2022-06-21 11:09:38.937561
# Unit test for function config
def test_config():
    import marshmallow
    import marshmallow.fields
    assert config(metadata={},
                  encoder=lambda x: x,
                  decoder=lambda x: x,
                  letter_case=lambda x: x,
                  mm_field=marshmallow.fields.Int,
                  undefined=str(Undefined.EXCLUDE),
                  field_name='test_field') == {
                      'dataclasses_json': {
                          'encoder': lambda x: x,
                          'decoder': lambda x: x,
                          'mm_field': marshmallow.fields.Int,
                          'letter_case': lambda x: x,
                          'undefined': Undefined.EXCLUDE,
                      }
                  }


# Generated at 2022-06-21 11:09:49.990989
# Unit test for function config
def test_config():
    # assert config() == {"dataclasses_json": {}}
    assert config(encoder=1) == {"dataclasses_json": {"encoder": 1}}
    assert config(decoder=2) == {"dataclasses_json": {"decoder": 2}}
    assert config(mm_field=3) == {"dataclasses_json": {"mm_field": 3}}
    assert config(letter_case=4) == {"dataclasses_json": {"letter_case": 4}}
    assert config(undefined=5) == {"dataclasses_json": {"undefined": 5}}
    assert config(field_name=6) == {"dataclasses_json": {"letter_case": 6}}
    assert config(exclude=7) == {"dataclasses_json": {"exclude": 7}}


# Generated at 2022-06-21 11:11:05.832630
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("x") == True



# Generated at 2022-06-21 11:11:07.183998
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:11:16.748621
# Unit test for function config
def test_config():
    import pytest
    @pytest.mark.parametrize("undefined", [
        'fail',
        'fallback',
        'default',
        'ignore'
    ])
    def test_undefined(undefined):
        cc = globals()['config']({'undefined': undefined})
        assert cc == {'dataclasses_json': {'undefined': Undefined[undefined.upper()]}}

    test_undefined()

    from dataclasses_json.undefined import Undefined
    cc = globals()['config']({'undefined': Undefined.IGNORE})
    assert cc == {'dataclasses_json': {'undefined': Undefined.IGNORE}}


# Generated at 2022-06-21 11:11:18.035224
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-21 11:11:19.724382
# Unit test for constructor of class Exclude
def test_Exclude():
	assert Exclude.NEVER(1) == False
	assert Exclude.ALWAYS(0) == True

# Generated at 2022-06-21 11:11:24.613833
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER("hello")
    assert Exclude.NEVER(["a","b"])
    assert Exclude.NEVER({1:"a",2:"b"})
    assert Exclude.NEVER(("a","b"))


# Generated at 2022-06-21 11:11:28.246397
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    class Foo:
        foo: str
        bar: str = field(metadata=config(exclude=Exclude.NEVER))
    foo = Foo('a', 'b')
    assert(foo.foo == 'a')
    assert(foo.bar == 'b')


# Generated at 2022-06-21 11:11:29.512152
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False


# Generated at 2022-06-21 11:11:38.215709
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field

    import marshmallow
    from marshmallow import fields

    @dataclass
    class C:

        @dataclass
        class Inner:
            s: str
            exclude_s: str = field(metadata=config(exclude=Exclude.NEVER))
            include_s: str = field(metadata=config(exclude=Exclude.ALWAYS))

        s: str = field(metadata=config(exclude=Exclude.NEVER))
        exclude_s: str = field(metadata=config(exclude=Exclude.ALWAYS))
        include_s: str = field(metadata=config(exclude=Exclude.NEVER))
        inner: Inner = field(metadata=config(exclude=Exclude.NEVER))


# Generated at 2022-06-21 11:11:39.857971
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) is True

test_Exclude_ALWAYS()
